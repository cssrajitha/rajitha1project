import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import * as DOMPurify from 'dompurify';
import PropTypes from 'prop-types';
import {
  getQueryParamByName,
  isIpad,
  executeShellFunction,
  isAsurion,
  isD2D,
  isTelesales,
  isChatStore,
} from 'onevzsoemfeframework/DomService';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { Input } from '@vds/inputs';
import { Icon } from '@vds/icons';
import { Checkbox } from '@vds/checkboxes';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import TimeoutManager from 'onevzsoemfecommon/TimeoutManager';
import { useDispatch } from 'react-redux';
import Emitter from 'onevzsoemfeframework/Emitter';
// import { useLazyDeviceInventoryStatusCheckQuery } from 'onevzsoemfecommon/CartAPIService';

// eslint-disable-next-line you-dont-need-lodash-underscore/get
import { get as getProp } from 'lodash';
import {
  useLazyDeviceInventoryStatusCheckQuery,
  useLazyFraudRiskScoreQuery,
} from '../../modules/services/APIService/APIServiceHooks';
import { getDeviceEnforApiPayload, isFraudRiskApiEnabledForDeviceChange } from '../FlexPDP/pdputils';
import { trainingFlag } from 'onevzsoemfecommon/Helpers/validation';

const InputWrapper = styled.div`
  display: flex;
  align-items: center;
  width: ${({ scmDeviceEnable ,etrFlow}) => (scmDeviceEnable ? '16rem' : etrFlow?'25rem':'21rem')};
  padding-right: ${({ scmDeviceEnable }) => scmDeviceEnable && '5%'};
  div[id='deviceId'] > span > span > div[class^='InputTextWrapper'] > p {
    display: none;
  }
    .checkbox-wrapper{
    padding-left:4rem;
    padding-top:2rem}
`;


const BarcodeIconWrapper = styled.div`
  display: flex;
  margin-top: 15px;
  padding-left: 15px;
`;

const ESIMWRAPPER = styled.div`
  font-size: small !important;
`;

function getIsInsideSalesUser(props){
  let isInsideSalesUser = window?.mfe?.isInsideSalesUser && props?.isNewlyAddedLine !== undefined
      ? window?.mfe?.isInsideSalesUser
      : false;
  isInsideSalesUser = window?.mfe?.isProspectNewCustomerTab ? false : isInsideSalesUser;
  return isInsideSalesUser;
} 

function DeviceScan(props) {
  const {
    deviceIdEsimCheck,
    shouldDisplayESIMMessage,
    lineDeviceIdFromLanding,
    lineActivityType,
    isRfexFlow,
    selectedDeviceId,
    ivrDeviceId,
    handleChangeDeviceIDs,
    LineDeviceId,
    isPdpPage,
    showScanner,
    ScanFromLanding,
    isDeviceFromCart,
    isprepaycart,
    activeMtn,
    isFiveG,
    isIndirect,
    selectedSimId,
    validateDeviceSimIdRequest,
    CustomerData,
    SecNumFlow,
    imeiOfPrimaryMtn,
    primaryMtnofSecondNumber,
    isSelectedDevice,
    setRepSelectedSimType,
    cartDetails,
    deviceInput,
    setDeviceInput,
    simSwapNotificationHighRiskMsg,
  } = props;
  const simSwapNotify = window?.mfe?.acssAANotify;
  const isSecureSimSwap = window?.mfe?.acssAAEnable;
  const customerInfo = CustomerData || {};
  const lookUpMtn = customerInfo?.lookupMtn;
  const billAccounts = getProp(customerInfo, 'billAccounts', []);
  const mtns = billAccounts?.[0]?.mtns || [];
  const equipmentInfo = mtns?.find((obj) => obj.mtn === lookUpMtn)?.equipmentInfos?.[0] || {};
  const locationCd = sessionStorage.getItem('location') || '';
  const cleanUpEmitterFFlag = /true/i.test(getAssistedCradlePropertyV2(['cleanUpEmitterFFlag'])?.[0]);
  const timeoutManager = new TimeoutManager({ fileName: 'DeviceScan.js', enableFF: cleanUpEmitterFFlag });
  const [flexFlowServiceChangeFFlag] = getAssistedCradlePropertyV2(['flexFlowServiceChangeFFlag']);
  const flexFlowServiceChange = /true/i.test(flexFlowServiceChangeFFlag) && getQueryParamByName('etrServiceChanges');

  // console.log('Device scan component log ->',{  customerInfo, equipmentInfo, locationCd });

  const scmDeviceEnable = window?.mfe?.scmDeviceMfeEnable;
  const isDark = (window?.mfe?.scmDeviceMfeEnable && window?.mfe?.isDark) || false;
  const [deviceId, setDeviceId] = useState(isIndirect && selectedDeviceId ? selectedDeviceId : '');
  const [deviceError, setDeviceError] = useState(false);
  const [isNoPayError, setIsNoPayError] = useState(false); // only for OMNI-INDIRECT Channel
  const [isSimIdScanActive, setSimIdScanActive] = useState(false);
  const [simId, setSimId] = useState('');
  const [deviceChangeEvent, setdeviceChangeEvent] = useState('');
  const isCCHorPADFlow = isIndirect && isRfexFlow && (lineActivityType === 'CCH' || lineActivityType === 'PAD');
  const isWSAPCpeError = Boolean(getQueryParamByName('isWSAPCpeError')) || false;
  const cpeDeviceId = String(getQueryParamByName('deviceId')) || '';
  const existingDeviceId = LineDeviceId;
  const deviceErrorMsg = showScanner ? 'Please scan or enter a valid device ID' : 'Please enter a valid device ID';
  const showScannerForIndirect = isIndirect ? isIpad || (!ScanFromLanding && isprepaycart) : true;
  const [isScanActive, setScanActive] = useState(false);
  const [showInput, setShowInput] = useState(false);
  const isByodUpdate = getQueryParamByName('isByodUpdate');
  const [getfraudRiskScore, fraudRiskScoreResult] = useLazyFraudRiskScoreQuery();
  const isFraudRiskEnabled = props?.isNewlyAddedLine
    ? false
    : isFraudRiskApiEnabledForDeviceChange({ isSecureSimSwap });
  const isInsideSalesUser = getIsInsideSalesUser(props)

  const isBYODAAEnabled = window?.mfe?.isAAEnabledAAL || false;
  const isNtfnIndFlagEnabled = window?.mfe?.isNotfnIndAA || false;

  // const isSimIdScanActive = false;
  const deviceSku = getQueryParamByName('deviceSKU');
  const dispatch = useDispatch();
  let device;
  const isSecondNumber =
    sessionStorage.getItem('secondNumber') || /true/i.test(sessionStorage.getItem('isSecondNumLocal'));
  const cartDetailsOfPrimaryMtn = cartDetails?.cart?.lineDetails?.lineInfo?.find(
    (line) => line?.mobileNumber === primaryMtnofSecondNumber,
  );
  const imie2 = cartDetailsOfPrimaryMtn?.itemsInfo?.[0]?.cartItems?.cartItem?.[0]?.imei2;
  const secondImei = imie2 || '';
  const [DeviceInventoryStatusCheckRequestBody, DeviceInventoryStatusCheckResult] =
    useLazyDeviceInventoryStatusCheckQuery();
  const DeviceInventoryStatusCheckResultStatus = DeviceInventoryStatusCheckResult?.status;

  const isAsurionExpansionEnabled = props?.isFromPDPPage && isAsurion();
  let disableDeviceDetailsForAsurion = false;
  if (isAsurionExpansionEnabled && !props?.isNewlyAddedLine && props?.isByodUpdate) {
    disableDeviceDetailsForAsurion = true;
  }
  const appProperties = DOMPurify.sanitize(sessionStorage.getItem('APP_PROPERTIES'));
  const pearlBYODFlow = appProperties ? JSON.parse(appProperties)?.pearlBYODFlow === 'TRUE' : false;
  const isPearl = pearlBYODFlow && DOMPurify.sanitize(sessionStorage.getItem('isPearl')) === 'true';

  const isDeviceInputDisabled = () => {
    if (isPearl) {
      return false;
    }
    if (
      (isByodUpdate === 'true' &&
        ((!flexFlowServiceChange && (isTelesales() || isChatStore())) || (isIndirect && !isIpad()))) ||
      disableDeviceDetailsForAsurion ||
      props?.isDisabled
    ) {
      return true;
    }
    if (isSecondNumber) {
      return true;
    }
    return false;
  };

  useEffect(() => {
    window.deviceIdBarCodeScannerCallback = deviceIdBarCodeScannerCallback;
    setDeviceId(props?.deviceId || (isIndirect ? selectedDeviceId : ''));

    Emitter.on('CONT_SIM_VALIDATION', (value) => {
      if (value.respCode) {
        setDeviceId(value.oldVal);
        setDeviceInput(value.oldVal);
      } else {
        callValidateDeviceAndSIM(value.newVal);
      }
    });

    return () => {
      Emitter.off('CONT_SIM_VALIDATION');
      timeoutManager.clearAllTimeouts();
    };
  }, []);

  useEffect(() => {
    if (deviceId !== props?.deviceId && props.deviceId !== '') {
      setDeviceId(props?.deviceId || (isIndirect ? selectedDeviceId : ''));
    }
  }, [props?.deviceId]);

  useEffect(() => {
    if (scmDeviceEnable && deviceInput && deviceInput !== props?.LineDeviceId && !deviceError && isFraudRiskEnabled) {
      const soeguivalue = sessionStorage.getItem('encryptedActInfo') || '';
      const mfeIccid = props.simSkuInput;
      const mfeImei = deviceInput;
      const payload = getDeviceEnforApiPayload({
        mfeIccid,
        mfeImei,
        customerInfo,
        equipmentInfo,
        locationCd,
        simSwapNotify,
      });
      getfraudRiskScore(
        {
          body: payload,
          customHeaders: {
            soeguivalue,
          },
        },
        { refetchOnMountOrArgChange: true },
      );
    }
  }, [deviceInput]);

  useEffect(() => {
    if (fraudRiskScoreResult?.data) {
      if (fraudRiskScoreResult?.data?.data?.fraudRiskLevel?.toLowerCase() === 'high risk') {
        dispatch(
          appMessageActions.addAppMessage(
            simSwapNotificationHighRiskMsg || 'Something went wrong, kindly try again.',
            'error',
            true,
            false,
          ),
        );
      } else if (
        fraudRiskScoreResult?.status === 'fulfilled' &&
        fraudRiskScoreResult?.data?.responseInfo?.errors?.length
      ) {
        dispatch(appMessageActions.addAppMessage('Something went wrong, kindly try again.', 'error', true, false));
      } else {
        dispatch(appMessageActions.clearAppMessages());
        handleOnBlurDeviceID(
          {
            target: {
              value: deviceInput,
            },
          },
          true,
        );
      }
    }
  }, [fraudRiskScoreResult?.data]);

  useEffect(() => {
    if (
      SecNumFlow === true &&
      primaryMtnofSecondNumber &&
      cartDetails &&
      (CustomerData?.billAccounts?.[0]?.mtns?.length > 0 ||
        (cartDetails?.featureFlags?.posSNDeviceIdFixFFlag && cartDetails?.cart?.lineDetails?.lineInfo?.length > 0))
    ) {
      setDeviceId(isSelectedDevice ? secondImei : imeiOfPrimaryMtn?.pairedImei);
      handleChangeDeviceIDs(null, isSelectedDevice ? secondImei : imeiOfPrimaryMtn?.pairedImei);

      if (sessionStorage.getItem('secondNumber') && !imeiOfPrimaryMtn?.pairedImei) {
        const lineData = props?.cartDetails?.cart?.lineDetails?.lineInfo?.find(
          (item) => item?.mobileNumber === props?.primaryMtnofSecondNumber,
        );
        const imei2 = lineData?.itemsInfo?.[0]?.cartItems?.cartItem?.[0]?.imei2;
        setDeviceId(imei2);
      }
    }
  }, [
    SecNumFlow,
    imeiOfPrimaryMtn,
    cartDetails,
    primaryMtnofSecondNumber,
    CustomerData?.billAccounts?.[0]?.mtns?.length > 0,
  ]);

  useEffect(() => {
    if (DeviceInventoryStatusCheckResultStatus === 'fulfilled') {
      if (DeviceInventoryStatusCheckResult?.data?.data?.isDeviceAvailableInStoreInventory) {
        dispatch(
          appMessageActions.addAppMessage(
            'Device ID is from new store inventory and cannot be processed on the CPE page. New inventory can only be sold in Shop Devices.',
            'error',
            true,
            60000,
          ),
        );
        if (props?.setEnableBYODbtn) {
          props?.setEnableBYODbtn(false);
        }
        if (props?.setDisableUpdateButton) {
          props?.setDisableUpdateButton(true);
        }
      } else if (handleOnBlurDeviceID && deviceChangeEvent) {
        handleOnBlurDeviceID(deviceChangeEvent);
        if (props?.setDisableUpdateButton) {
          props?.setDisableUpdateButton(false);
        }
      }
    } else if (DeviceInventoryStatusCheckResultStatus === 'rejected') {
      if (handleOnBlurDeviceID && deviceChangeEvent) {
        handleOnBlurDeviceID(deviceChangeEvent);
      }
      if (props?.setDisableUpdateButton) {
        props?.setDisableUpdateButton(false);
      }
    }
  }, [DeviceInventoryStatusCheckResult?.data, DeviceInventoryStatusCheckResultStatus]);

  const inputRegEx = /^[a-zA-Z0-9]{10,16}$/;
  const inputSimRegEx = /^\d{19,20}$/;

  const deviceIdBarCodeScannerCallback = (data) => {
    console.log(`devicescan -1 - inside callback , ${JSON.stringify(data)}`);
    try {
      if (isIpad()) {
        if (data.dataset.barcode === 'cancel') {
          setScanActive(false);
          setSimIdScanActive(false);
        } else {
          const barcodeData = data.dataset.barcode.replace(/'/g, '"');
          const barcode = JSON.parse(barcodeData);
          console.log(
            `devicescan -1a - ,data , barcode ,barcode.MEID ,barcode.ICCID , ${JSON.stringify(data)} , ${barcode}, ${
              barcode?.MEID
            } , ${barcode?.ICCID}`,
          );
          if (barcode.MEID || barcode.GENERIC) {
            console.log(
              `devicescan -2 - ,data , barcode ,barcode.MEID ,barcode.ICCID , ${JSON.stringify(data)} , ${barcode}, ${
                barcode?.MEID
              } , ${barcode?.ICCID}`,
            );
            setDeviceId(barcode.GENERIC ? barcode.GENERIC : barcode.MEID);
            setSimId(barcode.ICCID ?? '');
            setDeviceError(false);
            // setSimError(false);
            setScanActive(false);
            setSimIdScanActive(false);
            callValidateDeviceAndSIM(barcode.MEID || barcode.GENERIC);
          }
        }
      } else {
        // handled desktop scan data
        handleChangeDeviceID(data);
      }
    } catch (e) {
      console.log(`error in catch block, ${e}`);
    }
  };

  const isBYODRefundFlow = () => {
    const channelName = sessionStorage.getItem('channel');
    const isRfexFlowBYOD =
      (sessionStorage.getItem('refundexchange') && sessionStorage.getItem('refundexchange') === 'true') || false;
    const appPropertiesFromSessionStorage = sessionStorage.getItem('APP_PROPERTIES');
    let checkDeviceAvailableLocalInventory;
    if (typeof appPropertiesFromSessionStorage === 'string') {
      checkDeviceAvailableLocalInventory =
        JSON.parse(appPropertiesFromSessionStorage)?.blockLocalInventoryRetailBYOD === 'TRUE';
    } else {
      checkDeviceAvailableLocalInventory = appPropertiesFromSessionStorage?.blockLocalInventoryRetailBYOD === 'TRUE';
    }

    return (
      checkDeviceAvailableLocalInventory &&
      ['OMNI-RETAIL', 'OMNI-RETAIL-TAB'].includes(channelName) &&
      ((isRfexFlowBYOD && props?.fromCpe) ||
        props?.isByodUpdate === 'true' ||
        (props?.isProspectflow && (props?.lineActivityType === 'AAL' || props?.lineActivityType === 'NSE')) ||
        props?.fromCpe)
    );
  };

  const handleChangeDeviceID = (e) => {
    const input = e.target.value.trim();
    setDeviceId(input);
    /*istanbul ignore else*/
    if (handleChangeDeviceIDs) {
      handleChangeDeviceIDs(e);
    }
  };

  const handleOnBlurSimID = (e) => {
    const input = e.target.value.trim();
    /*istanbul ignore else*/
    if (input === '') {
      return true;
    }
    const isValid = inputSimRegEx.test(input);
    /*istanbul ignore else*/
    if (isValid) {
      callValidateDeviceAndSIM();
    }
  };

  const scanDeviceIdBarCode = (e) => {
    const channelName = sessionStorage.getItem('channel');
    const newLocal = 'deviceIdScanner';
    // let isSimIdScanActive = this.state.isSimIdScanActive;
    const isDeviceID = e?.currentTarget?.id === newLocal;
    let scanActive;
    // eslint-disable-next-line no-unused-expressions
    if (isDeviceID) {
      if (!simId)
        setScanActive({
          isScanActive: !isScanActive,
        });
      scanActive = true;
    } else if (!simId)
      setSimIdScanActive({
        isSimIdScanActive: !isSimIdScanActive,
      });
    if (ScanFromLanding && !channelName?.includes('OMNI-INDIRECT')) {
      if (!simId) setShowInput({ showInput: !showInput });
    }

    if (e) e.preventDefault();

    /* istanbul ignore next */
    if (isIpad()) {
      const str = 'window.deviceIdBarCodeScannerCallback';
      timeoutManager.scheduleTimeout(() => {
        if (scanActive || isSimIdScanActive) {
          const bundleName = {};
          if (isFiveG && bundleName.includes('5GHomeSelfInstall')) {
            const params = { barcodeLength: '9' };
            executeShellFunction('HolsterManager', 'activateBarcodeGeneric', str, params);
            timeoutManager.scheduleTimeout(() => {
              executeShellFunction('HolsterManager', 'deactivateBarcode', 'none', null);
            }, 20000);
          } else {
            const activeBarCode = isDeviceID ? 'activateBarcodeMulti' : 'activateBarcodeICCID';
            executeShellFunction('HolsterManager', activeBarCode, str, null);
            timeoutManager.scheduleTimeout(() => {
              executeShellFunction('HolsterManager', 'deactivateBarcode', 'none', null);
            }, 20000);
          }
        } else {
          executeShellFunction('HolsterManager', 'deactivateBarcode', 'none', null);
        }
      }, 100);
    } else {
      // desktop: set callback function first, then init scanner events for barcode scanning

      device?.barcodeScan?.registerBarcodeCallback(deviceIdBarCodeScannerCallback);
      device?.barcodeScan?.scanBarcode();
    }
  };

  const updateActiveMtn = () => {
    const updateActiveMTN = getQueryParamByName('activeMtn') || activeMtn;
    return updateActiveMTN;
  };
  const handleOnBlurDeviceID = (e, ignoreInputChange) => {
    if (activeMtn) {
      updateActiveMtn();
    }
    const input = e.target.value.trim();
    if (input === '') {
      return true;
    }
    const isValid = inputRegEx.test(input);
    setDeviceId(input);
    if (!ignoreInputChange && setDeviceInput) {
      fraudRiskScoreResult.status = '';
      setDeviceInput(input);
    }
    const isFraudRiskSafe =
      isFraudRiskEnabled &&
      ((fraudRiskScoreResult?.status === 'fulfilled' &&
        fraudRiskScoreResult?.data?.data?.fraudRiskLevel &&
        fraudRiskScoreResult?.data?.data?.fraudRiskLevel?.toLowerCase() !== 'high risk') ||
        fraudRiskScoreResult?.status === 'rejected');
    const isNotfnIndicatorDisabled = fraudRiskScoreResult?.data?.data?.fraudRiskLevel &&
    fraudRiskScoreResult?.data?.data?.fraudRiskLevel?.toLowerCase() !== 'high risk' && isNtfnIndFlagEnabled && fraudRiskScoreResult?.data?.data?.notificationIndicator &&
      fraudRiskScoreResult?.data?.data?.notificationIndicator === 'N';
    if (isFiveG === true) {
      setDeviceId(input);
      setDeviceError(false);
      if (scmDeviceEnable) {
        if (isFraudRiskSafe) {
          props?.setEnableBYODbtn(false);
          Emitter.emit('DEVICE_SIM_VALIDATION', { newVal: { deviceId: input }, oldVal: props?.LineDeviceId });
        } else if (!isFraudRiskEnabled) {
          callValidateDeviceAndSIM();
        }
      } else {
        callValidateDeviceAndSIM();
      }
    } else if (isIndirect && input === LineDeviceId) {
      setDeviceId(input);
      setDeviceError(true);
      dispatch(appMessageActions.addAppMessage('Device is already active on account'));
    } else {
      setDeviceId(input);
      setDeviceError(!isValid);
    }

    if (isValid) {
      if (scmDeviceEnable) {
        if(isNtfnIndFlagEnabled && isNotfnIndicatorDisabled === true){
          callValidateDeviceAndSIM();
        }else if ((isFraudRiskSafe && !props?.isNewlyAddedLine) || (props?.isNewlyAddedLine && isBYODAAEnabled)) {
          Emitter.emit('DEVICE_SIM_VALIDATION', {
            newVal: { deviceId: input },
            oldVal: props?.LineDeviceId,
            eventType: props?.isNewlyAddedLine && isBYODAAEnabled ? 'ACSS_BYOD_AAL_AA' : '',
          });
        } else if (!isFraudRiskEnabled) {
          callValidateDeviceAndSIM();
        }
      } else {
        callValidateDeviceAndSIM();
      }
    } else {
      dispatch(
        appMessageActions.addAppMessage(
          scmDeviceEnable
            ? 'The entered Device ID is not valid. Please check the Device ID (IMEI) and try again'
            : `${input} was scanned, please scan a valid device id`,
          'error',
          true,
          true,
        ),
      );
    }
  };

  const handleDeviceChangeID = (e) => {
    dispatch(appMessageActions.clearAppMessages());
    if (existingDeviceId === e.target.value && isPdpPage) {
      dispatch(appMessageActions.addAppMessage('Device is already active on account'));
      setDeviceError(true);
      return false;
    }

    if (isBYODRefundFlow()) {
      setdeviceChangeEvent(e);
      DeviceInventoryStatusCheckRequestBody({ body: { serialNumber: e.target.value } });
    } else {
      handleOnBlurDeviceID(e);
    }
  };

  const scanOnKeyPress = (e) => {
    /*istanbul ignore else*/
    if (e.charCode === 13 || e.charCode === 32) {
      scanDeviceIdBarCode();
      updateActiveMtn();
    }
  };

  const checkProvisionalId = () => {
      sessionStorage.setItem('provisionalId',!props.isProvisionalId);
      // Clear eSIM regeneration flag when provisional ID is checked/unchecked
      if (props?.setIsESimRegenerated) {
        props?.setIsESimRegenerated(false);
      }
      /*istanbul ignore else*/
    if(props.isProvisionalId && flexFlowServiceChange){
       const request={
        data: {
                sorId: getQueryParamByName('deviceSKU') ,
                deviceId: getQueryParamByName('deviceId'),
                productType: 'device',
                processingMTN: props.activeMtn,
                isCPE:getQueryParamByName('isByodUpdate'),
                enableAssistedTagging: true,
                
              },
      }
      Emitter.emit('PROVISIONAL_ID_UNCHECK', request);
      sessionStorage.setItem("provisonalUncheckedBox",true)
      props.setEnableBYODbtn(false);
     }
   props.setIsProvisionalIdChecked(!props.isProvisionalId)
  }
  
  const callValidateDeviceAndSIM = (val = '') => {
    const fromCpe = props?.fromCpe ? props?.fromCpe : false;
    const fromInterim = props?.fromInterim ? props?.fromInterim : false;
    const isDWOS = props?.isDWOS ? props?.isDWOS : false;
    const isCustomerProvidedEquipment = props?.isCustomerProvidedEquipment ? props?.isCustomerProvidedEquipment : false;
    let sku =
      (ScanFromLanding === false && !isCustomerProvidedEquipment && !fromCpe) || fromInterim === true
        ? props?.sku || deviceSku
        : '';
    const eskuId = '';

    // assisted flags pdp functionalities todo.

    /**
     * When we get error id 3526, we should not display simId field
     */
    const indirectCallbackFns = {};
    if (isIndirect) {
      indirectCallbackFns.setNoPayError = (value) => {
        setIsNoPayError(value);
      };
    }
    // call action to get device  data
    const { homeSalesAddress = {} } = CustomerData;
    const { bundles = [] } = homeSalesAddress;
    let fiveGHomebundle = [];
    if (props?.CustomerData?.qualificationDetails) {
      fiveGHomebundle =
        Object.keys(props?.CustomerData?.qualificationDetails).length !== 0
          ? props?.CustomerData?.qualificationDetails?.fiveGHomebundle
          : bundles || [];
    }
    const isEagle = fiveGHomebundle?.length > 0 && fiveGHomebundle?.find((item) => item.bundleName.includes('Gen4'));
    const qualificationType = sessionStorage.getItem('Qualification_type');
    const homesalesQualification_type = sessionStorage.getItem('homesalesQualification_type');
    const hs_qualificationType =
      typeof homesalesQualification_type === 'object' &&
      JSON.parse(sessionStorage.getItem('homesalesQualification_type'));

    if (isFiveG) {
      if (
        props?.CustomerData?.qualificationDetails?.LTEQualified ||
        qualificationType === 'LTE' ||
        hs_qualificationType?.ltequalified ||
        false
      ) {
        // this.props?.Landingltequalified
        sku = '';
      } else if (
        props?.CustomerData?.qualificationDetails?.cBandQualified ||
        qualificationType === 'CBD' ||
        hs_qualificationType?.cbandQualified ||
        false
      ) {
        // this.props?.Landingltequalified
        sku = '';
      } else if (
        props?.CustomerData?.qualificationDetails?.fiveGHomeQualified ||
        qualificationType === 'MMW' ||
        hs_qualificationType?.fiveGHomeQualified ||
        false
      ) {
        // this.props?.LandingFiveGHomeQualified
        sku = isEagle ? 'LV65' : 'LVSKIHP';
      }
    }

    if (typeof setRepSelectedSimType === 'function') {
      setRepSelectedSimType('');
    }
    validateDeviceSimIdRequest({
      mtn: activeMtn,
      deviceId: val !== '' ? val : deviceId,
      simId: selectedSimId, // Todo for Indirect Sim Scan
      cpSimCard: false,
      fromCpe,
      isCustomerProvidedEquipment: props?.isCustomerProvidedEquipment,
      fromInterim,
      sku,
      eskuId,
      deviceFlow: true,
      isDWOS,
      scanFromLanding: ScanFromLanding,
      ...indirectCallbackFns,
    });

    if (fromInterim !== true && !(isIndirect && ScanFromLanding) && !isPdpPage) {
      setDeviceId('');
    }
  };
  console.log(
    DOMPurify.sanitize(
      isCCHorPADFlow ? lineDeviceIdFromLanding : deviceId || (isWSAPCpeError && cpeDeviceId) || ivrDeviceId || '',
    ),
    'DOm',
  );

  let deviceLabel = '';
  const isDeviceIDfieldDisabled = isDeviceInputDisabled() || props?.isProvisionalId || isInsideSalesUser;
  if (isPdpPage) {
    if (props.isByodUpdate) {
      deviceLabel = 'Enter Customer Provided Device ID';
    } else if (isPearl) {
      deviceLabel = 'Enter Customer Provided Device ID';
    } else deviceLabel = 'Enter Device ID';
  } else if (ScanFromLanding) {
    deviceLabel = 'Enter Device ID';
  }
  let device_id = isCCHorPADFlow
    ? lineDeviceIdFromLanding
    : deviceId || (isWSAPCpeError && cpeDeviceId) || ivrDeviceId || deviceIdEsimCheck || '';
  if (device_id === 'undefined') {
    device_id = '';
  }
  if(flexFlowServiceChange && props.isProvisionalId){
    device_id =  'Provisional';
  }   
  const isPosTrainingEnabled = trainingFlag() || false;                                          
  return (
    <div data-testid='device-scan' className='contains-PII'>
      <InputWrapper scmDeviceEnable={scmDeviceEnable} etrFlow={flexFlowServiceChange}>
        <Input
          type='text'
          iconName=''
          name='deviceId'
          id='deviceId'
          data-testid='handleChangeDeviceID'
          placeholder='Enter Device ID'
          value={DOMPurify.sanitize(device_id)}
          onChange={(e) => handleChangeDeviceID(e)}
          onBlur={(e) => (e.target.value.trim() === '' ? setDeviceError(true) : handleDeviceChangeID(e))}
          disabled={isDeviceIDfieldDisabled || isPosTrainingEnabled}
          error={deviceError}
          errorText={deviceError ? deviceErrorMsg : ''}
          autoComplete='off'
          label={deviceLabel} // Show Label if only from Landing
          required={!!isPdpPage}
          width='100%'
          surface={isDark ? 'dark' : 'light'}
          data-track='Productdetail_deviceId'
        />

        {showScanner && !props?.isByodUpdate && !isTelesales() && !isAsurionExpansionEnabled && !isD2D() && (
          // !isFullFillment &&
          // !isDeviceFromCart &&
          // showScannerForIndirect &&
          <BarcodeIconWrapper>
            <span
              data-testid='isFullFillment'
              key={`${activeMtn}${props?.isDWOS}`}
              style={{
                cursor:
                  // !isFiveG || isFiveG
                  // ? // some checks needs to add
                  'default',
                // : 'not-allowed',
                'pointer-events':
                  // !isFiveG || isFiveG
                  // ? // some checks needs to add
                  'auto',
                // : 'none',
              }}
              tabIndex='0'
              aria-label='scanner'
              role='button'
              onClick={(e) => {
                scanDeviceIdBarCode(e);
                updateActiveMtn();
              }}
              onKeyPress={(e) => scanOnKeyPress(e)}
              id='deviceIdScanner'
              data-track='customer-provided equipment_scan'
            >
              <Icon name='barcode' lineColor={isScanActive ? '#0096E4' : '#000000'} size='XLarge' />
            </span>
          </BarcodeIconWrapper>
        )}
         {
        flexFlowServiceChange && (

            <Checkbox label="Provisional ID" data-testid="provisional-id-checkbox" className="checkbox-wrapper" data-track='provisionId'  selected={props.isProvisionalId} onChange={checkProvisionalId} />

        )}
      </InputWrapper>
      {/* when cradle flag enable skipIccidCall after device scan showing below lebel to user for eSIM */}
      {shouldDisplayESIMMessage && <ESIMWRAPPER>eSIM will populate post activation</ESIMWRAPPER>}

      {/* Show Sim ID field only in Landing after entering valid device id
       * For PDP and interim pages, we have a separate SimScan component
       */} 
      {isIndirect &&
        !deviceError &&
        ScanFromLanding &&
        (isCCHorPADFlow ||
          ((deviceId || selectedDeviceId) && !isDeviceFromCart && !isNoPayError) ||
          isDeviceFromCart) && (
          //  (this.props.simIdInCart || this.props.selectedSimId)))) &&
          <div>
            {showScanner &&
              // !isFullFillment &&
              !isDeviceFromCart &&
              showScannerForIndirect && (
                <span
                  key={`${activeMtn}${props?.isDWOS}`}
                  style={{
                    cursor:
                      // !isFiveG || isFiveG
                      // ? // some checks needs to add
                      'default',
                    // : 'not-allowed',
                    'pointer-events':
                      // !isFiveG || isFiveG
                      // ? // checks needs to add
                      'auto',
                    // : 'none',
                  }}
                  tabIndex='0'
                  aria-label='scanner'
                  role='button'
                  onClick={() => {
                    scanDeviceIdBarCode();
                    updateActiveMtn();
                  }}
                  onKeyPress={(e) => scanOnKeyPress(e)}
                  id='simIDScanner'
                  data-testid='simIDScanner'
                >
                  <Icon name='barcode' size='31' lineColor={isSimIdScanActive ? 'Red' : 'Grey'} />
                </span>
              )}
            <Input
              data-testid='SimId-Input-element'
              name='simId'
              type='text'
              iconName=''
              id='simId'
              placeholder='Enter Sim ID'
              onBlur={(e) => handleOnBlurSimID(e)}
              label='Enter Sim ID'
              surface={isDark ? 'dark' : 'light'}
              required={false}
            />
          </div>
        )}
    </div>
  );
}
DeviceScan.propTypes = {
  isProvisionalId: PropTypes.bool.isRequired,
  isNewlyAddedLine: PropTypes.bool.isRequired,
  setIsESimRegenerated: PropTypes.func,
};

export default DeviceScan;
