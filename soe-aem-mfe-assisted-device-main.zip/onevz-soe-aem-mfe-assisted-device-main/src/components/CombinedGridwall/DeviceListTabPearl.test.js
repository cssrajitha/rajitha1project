import React from 'react';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { render, screen } from '../../modules/test-utils/renderHelper';
import DeviceListTab from './DeviceListTab';
import myOffers from './__mocks__/getMyOffers.json';

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradleProperty: () => ['TRUE', 'TRUE'],
  }),
  { virtual: true },
);

describe('device List component render', () => {
  const trialdevice = {
    tdd: {
      equipmentInfos: [
        {
          deviceInfo: {
            deviceId: '354615755195390',
            deviceSku: 'IPHONE14PRO-NVZW',
            deviceUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
            displayName: 'IPHONE14 PRO GENERIC NVZW',
          },
        },
      ],
    },
  };
  const props = {
    isPearl: true,
    trialDeviceDetail: trialdevice,
    hasIteminCart: true,
    lineActivityType: 'BYOD',
    handleResetChange: jest.fn(),
    getDevices: jest.fn(),
    pagination: { totalNumberRecords: 30 },
    isLoadMore: 'true',
    productList: [{ product: '123' }],
    onAutoCompleteItemSkuSearch: jest.fn(),
    searchStrValue: '2',
    selectedSkuId: '1234',
    resetToggleOptions: jest.fn(),
    deviceSelection: {
      productId: '12345',
      skuId: '1234',
      childSkus: [{ skuId: '1234' }],
      1234: {
        skuId: '1234',
        selectedSku: '1234',
        childSkus: [{ skuId: '1234' }],
      },
    },
    offers: myOffers,
    totalLines: [
      {
        lineActivityType: 'DEO',
        itemsInfo: [
          {
            cartItems: {
              cartItem: [
                {
                  cartItemType: 'DEVICE',
                  deviceId: '354615755195390',
                },
              ],
            },
          },
        ],
      },
    ],
    cartItem: {},
    activeMtn: ['1234'],
    CustomerData: {
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    isDWOS: true,
  };
  beforeEach(() => {
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/sales/assisted/new/device/gridwall.html'),
      configurable: true,
    });
    render(<DeviceListTab {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('component should render', () => {
    const text = screen.getAllByText(/Compare/i)[0];
    expect(text).toBeInTheDocument();
  });
});
