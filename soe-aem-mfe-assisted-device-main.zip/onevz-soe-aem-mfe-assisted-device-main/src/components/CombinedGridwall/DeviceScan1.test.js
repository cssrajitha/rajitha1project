import React from 'react';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { render, screen, fireEvent } from '../../modules/test-utils/renderHelper';
import DeviceScan from './DeviceScan';

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => true,
    isIpad: () => false,
    getQueryParamByName: (value) => {
      if (value === 'deviceId') return '';
    },
  }),
  { virtual: true },
);

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
  useLazyDeviceInventoryStatusCheckQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: { data: {} },
      error: true,
    },
  ],
}));

describe('DeviceScan component for handleOnBlurDeviceID function test', () => {
  const props = {
    isFiveG: true,
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '4567456745674567',
    isPdpPage: false,
    showScanner: true,
    selectedDeviceId: true,
    lineActivityType: 'PAD',
    isIndirect: true,
    isRfexFlow: true,
    deviceError: false,
    ScanFromLanding: false,
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    isDeviceFromCart: true,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    isFromPDPPage: true,
    isNewlyAddedLine: true,
    isByodUpdate: true,
    validateDeviceSimIdRequest: jest.fn(),
  };
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('APP_PROPERTIES', '{"allowLocalInventoryExchangeBYOD": "FALSE"}');
    sessionStorage.setItem('enableSimValidation', false);
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('handleOnBlurDeviceID testings', () => {
    const testid = screen.getAllByRole('textbox')[0];
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.change(testid, { target: { value: '4567456745674567' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567' } });
    expect(testid).toBeInTheDocument();
  });
});
describe('DeviceScan component for handleOnBlurDeviceID function test', () => {
  const props = {
    isFiveG: true,
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '4567456745674567',
    isPdpPage: false,
    showScanner: true,
    selectedDeviceId: true,
    lineActivityType: 'PAD',
    isIndirect: true,
    isRfexFlow: true,
    deviceError: false,
    ScanFromLanding: false,
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    isDeviceFromCart: true,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    isFromPDPPage: true,
    isNewlyAddedLine: true,
    isByodUpdate: true,
    validateDeviceSimIdRequest: jest.fn(),
  };
  beforeEach(() => {
    Object.defineProperty(window, 'mfe', {
      value: { scmDeviceMfeEnable: true },
      configurable: true,
    });
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('APP_PROPERTIES', '{"allowLocalInventoryExchangeBYOD": "FALSE"}');
    sessionStorage.setItem('enableSimValidation', false);
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('handleOnBlurDeviceID testings', () => {
    const testid = screen.getAllByRole('textbox')[0];
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.change(testid, { target: { value: '4567456745674567' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567' } });
    expect(testid).toBeInTheDocument();
  });
  test('handleOnBlurDeviceID testings for inValid DeviceID', () => {
    const testid = screen.getAllByRole('textbox')[0];
    fireEvent.change(testid, { target: { value: '4567AB' } });
    fireEvent.change(testid, { target: { value: '45674567456745AB' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567AB' } });
    expect(testid).toBeInTheDocument();
  });
});
describe('DeviceScan component for handleOnBlurDeviceID function test', () => {
  const props = {
    isFiveG: true,
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '4567456745674567',
    isPdpPage: false,
    showScanner: true,
    selectedDeviceId: true,
    lineActivityType: 'PAD',
    isIndirect: true,
    isRfexFlow: true,
    deviceError: false,
    ScanFromLanding: false,
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    isDeviceFromCart: true,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    isFromPDPPage: true,
    isNewlyAddedLine: true,
    isByodUpdate: true,
    validateDeviceSimIdRequest: jest.fn(),
  };
  beforeEach(() => {
    window.mfe.scmDeviceMfeEnable = false;
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('APP_PROPERTIES', '{"allowLocalInventoryExchangeBYOD": "FALSE"}');
    sessionStorage.setItem('enableSimValidation', false);
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('handleOnBlurDeviceID testings for inValid DeviceID', () => {
    const testid = screen.getAllByRole('textbox')[0];
    fireEvent.change(testid, { target: { value: '4567AB' } });
    fireEvent.change(testid, { target: { value: '45674567456745AB' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567AB' } });
    expect(testid).toBeInTheDocument();
  });
});
describe('DeviceScan component for handleOnBlurDeviceID function test for isFiveG false', () => {
  const props = {
    isFiveG: false,
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '4567456745674567',
    isPdpPage: false,
    showScanner: true,
    selectedDeviceId: true,
    lineActivityType: 'PAD',
    isIndirect: true,
    isRfexFlow: true,
    deviceError: false,
    ScanFromLanding: false,
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    isDeviceFromCart: true,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    isFromPDPPage: true,
    isNewlyAddedLine: true,
    isByodUpdate: true,
    validateDeviceSimIdRequest: jest.fn(),
  };
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('APP_PROPERTIES', '{"allowLocalInventoryExchangeBYOD": "FALSE"}');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('handleOnBlurDeviceID testings', () => {
    const testid = screen.getAllByRole('textbox')[0];
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.change(testid, { target: { value: '4567456745674567' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567' } });
    expect(testid).toBeInTheDocument();
  });
});
describe('DeviceScan component', () => {
  const props = {
    setRepSelectedSimType: jest.fn(),
    ivrDeviceId: true,
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '4567',
    isPdpPage: false,
    lineActivityType: 'PAD',
    isIndirect: true,
    isRfexFlow: true,
    ScanFromLanding: false,
    isprepaycart: true,
    isFiveG: true,
    activeMtn:
      '8482470044 cartDetails?.cart?.lineDetails?.lineInfo?.[0]?.itemsInfo?.[0].cartItems?.cartItem?.[0].imei2',
    cartDetails: {
      cart: { lineDetails: { lineInfo: [{ itemsInfo: [{ cartItems: { cartItem: [{ imei2: '1212122121' }] } }] }] } },
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      channel: 'OMNI-RETAIL',
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        cBandQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    validateDeviceSimIdRequest: jest.fn(),
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    isFromPDPPage: true,
    isNewlyAddedLine: true,
    isByodUpdate: true,
    isProspectflow: true,
  };
  beforeEach(() => {
    sessionStorage.setItem('refundexchange', 'true');
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    sessionStorage.setItem('APP_PROPERTIES', '{"allowLocalInventoryExchangeBYOD": "TRUE"}');
    sessionStorage.getItem('Qualification_type', 'CBD');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('Find by DeviceId text', () => {
    const deviceIdText = screen.getByTestId('handleChangeDeviceID');
    expect(deviceIdText).toBeInTheDocument();
  });

  test('Device Scan testing by entering device Id', async () => {
    const deviceTextBox = await screen.getByTestId('handleChangeDeviceID');
    expect(deviceTextBox).toBeInTheDocument();
    fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
    fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });
  test('test deviceIdBarCodeScannerCallback ', () => {
    window.deviceIdBarCodeScannerCallback({});
  });
});
describe('DeviceScan component 1', () => {
  const props = {
    setRepSelectedSimType: jest.fn(),
    ivrDeviceId: true,
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '4567',
    isPdpPage: false,
    lineActivityType: 'PAD',
    isIndirect: true,
    isRfexFlow: true,
    ScanFromLanding: false,
    isprepaycart: true,
    isFiveG: true,
    activeMtn:
      '8482470044 cartDetails?.cart?.lineDetails?.lineInfo?.[0]?.itemsInfo?.[0].cartItems?.cartItem?.[0].imei2',
    cartDetails: {
      cart: { lineDetails: { lineInfo: [{ itemsInfo: [{ cartItems: { cartItem: [{ imei2: '1212122121' }] } }] }] } },
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      channel: 'OMNI-RETAIL',
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        cBandQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    validateDeviceSimIdRequest: jest.fn(),
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    isFromPDPPage: true,
    isNewlyAddedLine: true,
    isByodUpdate: false,
    isProspectflow: true,
  };
  beforeEach(() => {
    sessionStorage.setItem('refundexchange', 'false');
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    sessionStorage.setItem('APP_PROPERTIES', '{"allowLocalInventoryExchangeBYOD": "TRUE"}');
    sessionStorage.getItem('Qualification_type', 'CBD');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('Find by DeviceId text', () => {
    const deviceIdText = screen.getByTestId('handleChangeDeviceID');
    expect(deviceIdText).toBeInTheDocument();
  });

  test('Device Scan testing by entering device Id', async () => {
    const deviceTextBox = await screen.getByTestId('handleChangeDeviceID');
    expect(deviceTextBox).toBeInTheDocument();
    fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
    fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });
  test('test deviceIdBarCodeScannerCallback ', () => {
    window.deviceIdBarCodeScannerCallback({});
  });
});
