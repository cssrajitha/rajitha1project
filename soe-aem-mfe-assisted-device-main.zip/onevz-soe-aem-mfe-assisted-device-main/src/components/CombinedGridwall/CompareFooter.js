import { useMemo } from 'react';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import styled from 'styled-components';
import { TextLink, Button } from '@vds/buttons';
import { Icon } from '@vds/icons';
import { Body } from '@vds/typography';
import { OverflowEllipsis } from './FlexGlobalStyledConstants';

const FooterArea = styled.div`
  max-width: 1133px !important;
  box-sizing: border-box;
  background: #ffffff;
  position: fixed;
  bottom: 0%;
  left: 50%;
  display: flex;
  width: 100%;
  padding: 1.5rem 2.5rem;
  transform: translate(-50%);
`;
// max-width: 1600px;
const FooterTileWithData = styled.div`
  width: 158px;
  background: #f6f6f6;
  border-radius: 8px;
  margin-right: 1.5rem;
  padding: 1rem;
`;
const FooterTileWrapper = styled.div`
  display: flex;
  justify-content: space-between;
`;
const IconWrapper = styled.div`
  text-align: right;
`;
const FooterTileWithOutData = styled.div`
  width: 158px;
  background: #ffffff;
  border: 1px dashed #a7a7a7;
  border-radius: 8px;
  margin-right: 1.5rem;
  padding: 1rem;
`;
const TileWrapper = styled.div`
  display: flex;
  justify-content: space-between;
`;
const ProductImage = styled.div`
  display: flex;
`;
const ProductDescriptionText = styled.div`
  width: 90px;
  min-height: 60px;
  margin-left: 1rem;
`;
const ButtonWrapper = styled.div`
  margin-left: auto;
`;
const ClearAllText = styled.div`
  margin-top: 1rem;
  text-align: center;
`;
const Img = styled.img`
  width: 36px;
  aspect-ratio: auto 36 / 44;
  height: 44px;
  margin-right: 0px;
`;

// Empty tile component
const EmptyTile = () => (
  <FooterTileWithOutData>
    <Body size='large' color='#6F7171'>
      Add device
    </Body>
  </FooterTileWithOutData>
);

function CompareFooter(props) {
  const { devicestocompare, handleRemoveProductFromFooter, closeCompareDevicesoptions } = props;
  const [optmzCompareFooterFFlag] = getAssistedCradlePropertyV2(['optmzCompareFooterFFlag']);

  const emptyTilesCount = useMemo(() => {
    const maxDevices = 4;
    return Math.max(0, maxDevices - (devicestocompare?.length || 0));
  }, [devicestocompare?.length]);

  const emptyTiles = useMemo(
    () => Array.from({ length: emptyTilesCount }, (_, index) => <EmptyTile key={`empty-${index}`} />),
    [emptyTilesCount],
  );

  return (
    <FooterArea>
      <FooterTileWrapper>
        {devicestocompare?.map((product) => (
          <FooterTileWithData key={`Item ${product?.productDisplayName}`}>
            <TileWrapper>
              <ProductImage>
                <Img
                  src={product?.imgSrc}
                  alt={product?.productDisplayName ? product.productDisplayName : 'device image'}
                />
                <ProductDescriptionText>
                  <OverflowEllipsis lineCount={3}>
                    <Body size='large'>{`${product?.brandName} ${product?.productDisplayName}`}</Body>
                  </OverflowEllipsis>
                </ProductDescriptionText>
              </ProductImage>

              <IconWrapper key={`Item ${product?.productDisplayName}`}>
                <span
                  data-testid='removebutton'
                  onClick={() => handleRemoveProductFromFooter(product?.productId)}
                  onKeyDown={{}}
                  tabIndex={0}
                  role='button'
                >
                  <Icon size='small' name='close' aria-label='remove button' />
                </span>
              </IconWrapper>
            </TileWrapper>
          </FooterTileWithData>
        ))}
        {optmzCompareFooterFFlag === 'TRUE' ? (
          emptyTiles
        ) : (
          <>
            {devicestocompare?.length === 1 && (
              <>
                <FooterTileWithOutData>
                  <Body size='large' color='#6F7171'>
                    Add device
                  </Body>
                </FooterTileWithOutData>
                <FooterTileWithOutData>
                  <Body size='large' color='#6F7171'>
                    Add device
                  </Body>
                </FooterTileWithOutData>
                <FooterTileWithOutData>
                  <Body size='large' color='#6F7171'>
                    Add device
                  </Body>
                </FooterTileWithOutData>
              </>
            )}
            {devicestocompare?.length === 2 && (
              <>
                <FooterTileWithOutData>
                  <Body size='large' color='#6F7171'>
                    Add device
                  </Body>
                </FooterTileWithOutData>
                <FooterTileWithOutData>
                  <Body size='large' color='#6F7171'>
                    Add device
                  </Body>
                </FooterTileWithOutData>
              </>
            )}
            {devicestocompare?.length === 3 && (
              <FooterTileWithOutData>
                <Body size='large' color='#6F7171'>
                  Add device
                </Body>
              </FooterTileWithOutData>
            )}
          </>
        )}
      </FooterTileWrapper>
      <ButtonWrapper>
        <Button
          data-testid='compareDevices'
          type='secondary'
          size='small'
          width='auto'
          surface='light'
          onClick={() => props.compareDevices()}
          disabled={
            !(devicestocompare?.length === 2 || devicestocompare?.length === 3 || devicestocompare?.length === 4)
          }
          data-track='Gridwall-CompareFooter-Compare'
        >
          Compare
        </Button>
        <ClearAllText>
          <TextLink
            data-testid='closeButton'
            type='standAlone'
            onClick={() => closeCompareDevicesoptions()}
            data-track='Gridwall-CompareFooter-Clear all'
          >
            Clear all
          </TextLink>
        </ClearAllText>
      </ButtonWrapper>
    </FooterArea>
  );
}

export default CompareFooter;
