import React from 'react';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { render, screen, fireEvent } from '../../modules/test-utils/renderHelper';
import DeviceScan from './DeviceScan';

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => true,
    isIpad: () => false,
    getQueryParamByName: (value) => {
      if (value === 'deviceId') return '';
      else if (value === 'etrServiceChanges') return true;
    },
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradleProperty: () => [''],
    getAssistedCradlePropertyV2: () => ['TRUE'],
  }),
  { virtual: true },
);

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
  useLazyDeviceInventoryStatusCheckQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: { data: { isDeviceAvailableInStoreInventory: true } },
      error: true,
    },
  ],
}));
describe('DeviceScan component for handleOnBlurDeviceID function test', () => {
  const props = {
    isFiveG: true,
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '4567456745674567',
    isPdpPage: false,
    showScanner: true,
    setIsProvisionalIdChecked:jest.fn(),
    selectedDeviceId: true,
    lineActivityType: 'PAD',
    isIndirect: true,
    isRfexFlow: true,
    deviceError: false,
    ScanFromLanding: false,
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    isDeviceFromCart: true,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    isFromPDPPage: true,
    isNewlyAddedLine: true,
    isByodUpdate: true,
    validateDeviceSimIdRequest: jest.fn(),
  };
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('APP_PROPERTIES', '{"allowLocalInventoryExchangeBYOD": "FALSE"}');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('handleOnBlurDeviceID testings', () => {
    const testid = screen.getAllByRole('textbox')[0];
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.change(testid, { target: { value: '4567456745674567' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567' } });
    expect(testid).toBeInTheDocument();
  });
});
describe('DeviceScan component for handleOnBlurDeviceID function test', () => {
  const props = {
    isFiveG: true,
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    LineDeviceId: '4567456745674567',
    isPdpPage: false,
    showScanner: true,
    setIsProvisionalIdChecked:jest.fn(),
    isProvisionalId:true,
    selectedDeviceId: true,
    lineActivityType: 'PAD',
    isIndirect: true,
    isRfexFlow: true,
    deviceError: false,
    ScanFromLanding: false,
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    isDeviceFromCart: true,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    isFromPDPPage: true,
    isNewlyAddedLine: true,
    isByodUpdate: true,
    validateDeviceSimIdRequest: jest.fn(),
  };
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('APP_PROPERTIES', '{"allowLocalInventoryExchangeBYOD": "FALSE"}');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('handleOnBlurDeviceID testings', () => {
    const testid = screen.getAllByRole('textbox')[0];
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.change(testid, { target: { value: '4567456745674567' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567' } });
    expect(testid).toBeInTheDocument();
    const checkboxInput = screen.getByTestId('test-input');
    fireEvent.change(checkboxInput, { target: { checked: true } });
    fireEvent.click(checkboxInput);
  });
});
