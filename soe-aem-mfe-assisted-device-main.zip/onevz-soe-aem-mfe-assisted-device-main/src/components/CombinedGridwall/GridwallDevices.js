import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import { isEmpty } from 'lodash';
import PropTypes from 'prop-types';
import { useNavigate } from 'react-router-dom';
import { getQueryParamByName, isRetail, isIndirect as isInDirect } from 'onevzsoemfeframework/DomService';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import * as DOMPurify from 'dompurify';
import { decodeHTMLEntities, getUIContextPathBAU, getUIContextPath } from 'onevzsoemfecommon/Helpers';
import cloneDeep from 'lodash/cloneDeep';
import { sendCustomEvent } from 'onevzsoemfeframework/Tagging';
import { useLazyGetSkuListQuery, useLazyGetSkuDetailsQuery } from 'onevzsoemfecommon/BrowseAPIService';
// import { useLazyGetSkuDetailsQuery } from '../../modules/services/APIService/APIServiceHooks';
import { useDispatch } from 'react-redux';
import DeviceListTab from './DeviceListTab';
import { EquipOffers } from '../constants/DeviceConstants';
import SetDeviceListHook from './SetDeviceListHook';
import getPDPEnable from '../../modules/utils/getPDPEnable';
import { isFunctionalityEnabled } from '../../modules/utils';

const isScmfullScreenFix = isFunctionalityEnabled('scmPactCommonFixFFlag', 'scmfullScreenFix');
/* istanbul ignore next */
const TabContainer = styled.div`
  flex: 1;
  padding-bottom: ${(props) => !isEmpty(props?.devicestocompare) && '8rem'};
  overflow-y: ${(window?.mfe?.scmDeviceMfeEnable && isScmfullScreenFix) &&  'scroll'};
  height: ${(window?.mfe?.scmDeviceMfeEnable && isScmfullScreenFix) && '65vh'};
`;

let navigate = '';

function useNavigateMFE() {
  navigate = useNavigate();
}

function GridwallDevices(props) {
  const [rebeatBYODCheck, setRebeatBYODCheck] = useState(false);
  const [activeLineData, setActiveLineData] = useState(null);
  const [categoryValue, setCategoryValue] = useState('');
  const [brandValue, setBrandValue] = useState('');
  const [osValue, setOSValue] = useState('');
  const [sortValue, setSortValue] = useState('');
  const [toggle, setToggle] = useState(false);
  const [errMessage, setErrorMessage] = useState('');
  const [getSkuDetails, SkuDetailsResult] = useLazyGetSkuDetailsQuery();
  const [getSkuListRequest, SkuListResult] = useLazyGetSkuListQuery();
  const [getSearchedSku, setSearchedsku] = useState('');
  const {
    toggleValue,
    toggleOptions,
    products,
    offers,
    totalLines,
    setTab,
    getDevices,
    activeMtn,
    saveTempDeviceSelectionData,
    cartDetails,
    pdpSelectedDevice,
    updateCompareDeviceData,
    compareDeviceDataFromStore,
    errorMessage,
    refinementFilters,
    updateToggleOptions,
    resetSortOptions,
    selectedSkuId,
    isDWOS,
    intentCheck,
    CustomerData,
    lineActivityType,
    hasIteminCart,
    handleByodflag,
    showProspectTile,
    validateDeviceSimIdRequest,
    ValidateDeviceSimIdResult,
    eSimDetailsResult,
    validateDeviceSimId,
    initSimDetailsResp,
    ValidateDeviceSimIdResultStatus,
    eSimDetailsResultStatus,
    ProductListResult,
    isGWByodEUPEnabledFlag,
    installmentTerm,
    updateDevicePayload,
    trialDeviceDetail,
    devicePayload,
    landingLinesInfo
  } = props;
  const { gridWall } = products && products[activeMtn] ? products[activeMtn] : {};
  const {
    productList = [],
    pagination = {},
    sortOptions = {},
    techRecommendation = {},
  } = gridWall || { productList: [] };
  const [deviceList, setDeviceList] = useState([]);
  const ispdpenablePearl = getPDPEnable();
  const selectedTab = totalLines?.length > 0 && totalLines?.findIndex((item) => item.mobileNumber === props.activeMtn);

  const appPropertiesFromSessionStorage = DOMPurify.sanitize(sessionStorage.getItem('APP_PROPERTIES'));
  const pearlBYODFlow = appPropertiesFromSessionStorage
    ? JSON.parse(appPropertiesFromSessionStorage)?.pearlBYODFlow === 'TRUE'
    : false;
  const isPearl = DOMPurify.sanitize(sessionStorage.getItem('isPearl')) === 'true' && pearlBYODFlow;
  let isBytdDeviceAdded = false;
  const trialDeviceInfo = trialDeviceDetail?.tdd?.equipmentInfos?.[0]?.deviceInfo;
  const bytdDeviceId = totalLines?.[0]?.itemsInfo?.[0]?.cartItems?.cartItem?.filter(
    (item) => item?.deviceId === trialDeviceInfo?.deviceId,
  );
  if (isPearl && bytdDeviceId?.length > 0) {
    isBytdDeviceAdded = true;
  }
  const refinements = gridWall?.refinements || refinementFilters;
  let lineOffer = null;
  lineOffer = offers?.lines?.filter((k) => k.mtn.toLowerCase().replace(/\s/g, '') === activeMtn?.toLowerCase());
  const lineHasOffer = !isEmpty(lineOffer);

  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }

  if (!lineHasOffer && totalLines?.length > 0) {
    lineOffer = offers?.lines?.filter(
      (k) => k.mtn.toLowerCase().replace(/\s/g, '') === totalLines[selectedTab]?.lineNumber?.toLowerCase(),
    );
  }

  const handleClickForPearl = () => {
    const eSimDeviceInfoPearl = ValidateDeviceSimIdResult?.serviceBody?.serviceResponse?.context?.deviceInfo;
    const isIndirectPearl = CustomerData?.channel || sessionStorage.getItem('channel');
    const isByodUpdatePearl = !!getQueryParamByName('isByodUpdate');

    const eSimPopUpDataPearl = {
      deviceInfoPearl: eSimDeviceInfoPearl,
      channelPearl: CustomerData?.channel,
      isFromPearl: getQueryParamByName('deviceFromCart'),

      formattedDeviceIdPearl: devicePayload?.formattedDeviceId,
      apiRequestPearl: devicePayload,
      requestFlowTypePearl: devicePayload?.data?.lines[0]?.device?.Flowtype,

      sagaPayloadPearl: devicePayload,
      isByodUpdatePearl,
      scanFromLandingPearl: false,
      sendSimFromLandingPearl: false,
      notRetailAndInDirectPearl: ispdpenablePearl
        ? !!(!isRetail() && !isInDirect())
        : !!(CustomerData?.channel?.indexOf('OMNI-RETAIL') === -1 && !isIndirectPearl),
      contextUrlPearl: getUIContextPath(),
    };
    let isBothSlotsESimCompatiblePearl = false;
    const { deviceInfoPearl = {} } = cloneDeep(eSimPopUpDataPearl);
    const iccidPearl = deviceInfoPearl?.simInfo?.iccid;
    if (
      eSimPopUpDataPearl?.deviceInfoPearl?.simInfo2?.makeEtniPersApi &&
      eSimPopUpDataPearl?.deviceInfoPearl?.simInfo?.makeEtniPersApi
    ) {
      isBothSlotsESimCompatiblePearl = true;
    }
    const searchByNamePearl = getQueryParamByName('searchByName') === 'false' ? 'searchByName=false&' : '';
    const skuIdPearl = deviceInfoPearl?.simInfo?.launchPackageSkuType ?? '';
    const preferredSoftSimPearl = deviceInfoPearl?.simInfo?.preferredSoftSim;
    const trialEId = deviceInfoPearl?.simInfo?.eID ? deviceInfoPearl?.simInfo?.eID : '';
    const deviceTypePearl = deviceInfoPearl?.deviceAttributes?.prodType || '';
    const deviceNamePearl = trialDeviceDetail?.tdd?.equipmentInfos?.[0]?.deviceInfo?.displayName;
    const deviceSkuPearl = trialDeviceDetail?.tdd?.equipmentInfos?.[0]?.deviceInfo?.deviceSku;
    const deviceMfgNamePearl = deviceInfoPearl?.deviceAttributes?.mfgName || '';
    const deviceIdPearl = trialDeviceDetail?.tdd?.equipmentInfos?.[0]?.deviceInfo?.deviceId;

    const {
      sagaPayloadPearl = {},
      notRetailAndInDirectPearl = false,
      channelPearl = '',
      isFromPearl,
      formattedDeviceIdPearl,
      apiRequestPearl,
      requestFlowTypePearl,
      scanFromLandingPearl,
      contextUrlPearl,
    } = eSimPopUpDataPearl;

    if (deviceInfoPearl?.simInfo2?.makeEtniPersApi === true && !isBothSlotsESimCompatiblePearl) {
      deviceInfoPearl.simInfo = deviceInfoPearl?.simInfo2;
    }
    if (isBothSlotsESimCompatiblePearl) {
      if (deviceInfoPearl?.simInfo2?.deviceId === formattedDeviceIdPearl) {
        deviceInfoPearl.simInfo = deviceInfoPearl?.simInfo2;
      }
    }
    const softSimPearl = deviceInfoPearl?.simInfo?.preferredSoftSim;
    const preferredSimPearl = notRetailAndInDirectPearl ? softSimPearl : '';
    const SIMPearl = iccidPearl || preferredSimPearl;
    const payloadPearl = {
      eSimOnlyDevice: !!(
        deviceInfoPearl?.makeEtniPersApi &&
        deviceInfoPearl?.simInfo?.makeEtniPersApi &&
        deviceInfoPearl.simInfo &&
        !deviceInfoPearl.simInfo.dfillCompatibleSim
      ),
      skuId: deviceInfoPearl?.simInfo?.launchPackageSkuType ?? '',
      skuDisplayName: deviceInfoPearl.skuDisplayName ? deviceInfoPearl.skuDisplayName : '',
      simId: SIMPearl, // Entered SIM IDx``
      simLocalId: deviceInfoPearl?.simInfo?.iccid,
      fmipLocked: deviceInfoPearl?.fmipLocked,
      manualEntrySimId: sagaPayloadPearl.simId ? sagaPayloadPearl.simId : '',
      cpSimCard:
        ((channelPearl === 'OMNI-TELESALES' || channelPearl === 'OMNI-CARE' || channelPearl === 'CHAT-STORE') &&
          sagaPayloadPearl.simId) ||
        (requestFlowTypePearl === 'DEVICE' && deviceInfoPearl?.simInfo?.iccid) ||
        sagaPayloadPearl.cpSimCard, // If the device has inbuilt sim, set customerProvidedSim as true
      cpSimCheckboxSelected: sagaPayloadPearl.cpSimCard,
      eid:
        deviceInfoPearl && deviceInfoPearl?.simInfo && deviceInfoPearl?.simInfo?.eID
          ? deviceInfoPearl?.simInfo?.eID
          : '',
      launchPackageSku:
        requestFlowTypePearl === 'SIM'
          ? (deviceInfoPearl && deviceInfoPearl.simInfo && deviceInfoPearl.simInfo.launchPackageSku) || ''
          : '',
      preferredSoftSim:
        deviceInfoPearl && deviceInfoPearl.simInfo && deviceInfoPearl.simInfo.preferredSoftSim
          ? deviceInfoPearl.simInfo.preferredSoftSim
          : '',
      ispuCompatibleSIM:
        deviceInfoPearl && deviceInfoPearl.simInfo && deviceInfoPearl.simInfo.ispuCompatibleSIM
          ? deviceInfoPearl.simInfo.ispuCompatibleSIM
          : '',
      etniApi: true,
      currentSimIdInRequest: formattedDeviceIdPearl ? apiRequestPearl.data.lines[0].device.sim.CurrentSimid : '',
      scanFromPDPLocalFlow: !!(
        isFromPearl === 'isLocal' &&
        scanFromLandingPearl === false &&
        !sagaPayloadPearl.fromCpe &&
        !sagaPayloadPearl.isCustomerProvidedEquipment &&
        !isByodUpdatePearl
      ),
      deviceId: deviceIdPearl,
      ...(deviceInfoPearl?.simClass4G === 'NP' &&
      ['OMNI-INDIRECT', 'OMNI-INDIRECT-TAB', 'OMNI-RETAIL', 'OMNI-RETAIL-TAB'].includes(channelPearl) &&
      props?.scanCheck === 'EUP'
        ? { setOdaIndicatorforEsimCall: true }
        : {}),
    };
    updateDevicePayload(payloadPearl);
    const vzdlPearl = window?.vzdl || {};
    if (vzdlPearl?.user)
      vzdlPearl.user.deviceDetail = `${deviceTypePearl}_${deviceMfgNamePearl}_${deviceNamePearl}_${deviceSkuPearl}_eSim-pSim_eSimSelected`;
    window.vzdl = vzdlPearl;
    sendCustomEvent('openView', window?.vzdl);
    const MTNPearl = getQueryParamByName('activeMtn') || '';

    navigate(
      `${contextUrlPearl}/product-detail.html?${searchByNamePearl}${
        props?.sourcefrom === 'combinedgridwall' ? '&offerEligible=Y' : ''
      }&activeMtn=${props?.activeMtn ? props?.activeMtn : MTNPearl}&deviceSKU=${skuIdPearl}&${
        isByodUpdatePearl ? 'isByodUpdate=true' : 'isFromCPE=true'
      }&deviceId=${deviceIdPearl}&eId=${trialEId}&preferredSoftSim=${preferredSoftSimPearl}&eSim=true${
        props?.ProspectByodFlow ? '&prospectByodFlow=true' : ''
      }&fromPage=${props?.sourcefrom}&isBYTD=true&isBytdDeviceAdded=${isBytdDeviceAdded}&trialEId=${trialEId}`,
    );
  };
  // if (ValidateDeviceSimIdResult !== '') {
  //   const secondImei = ValidateDeviceSimIdResult?.serviceBody?.serviceResponse?.context?.deviceInfo?.imei2 ?? '';
  //   sessionStorage.setItem('secondImei', secondImei ?? '');
  // }
  const deviceTypeSelected =
    totalLines?.length && totalLines?.length > 0 ? totalLines[selectedTab]?.deviceTypeSelected : '';
  const defaultDeviceCategory = lineHasOffer ? `${lineOffer?.[0]?.deviceCategory}s` : deviceTypeSelected || '';

  const cartLines = props?.totalLines || [];
  const activeLine = cartLines?.filter((line) => line?.mobileNumber === props?.activeMtn);

  const [enableUnlockedPhones] = getAssistedCradlePropertyV2(['enableUnlockedPhones']);

  const [samsungPOSFFlag] = getAssistedCradlePropertyV2(['samsungPOSFFlag']);
  const samsungPOSFFlagEnabled = /true/i.test(samsungPOSFFlag);
  const carrierLockInResponse =
    ValidateDeviceSimIdResultStatus === 'fulfilled' &&
    ValidateDeviceSimIdResult?.serviceBody?.serviceResponse?.context?.deviceInfo?.carrierLock;
  const carrierLock = (samsungPOSFFlagEnabled && carrierLockInResponse) || false;
  const samsungCheckFulFilled = samsungPOSFFlagEnabled ? ValidateDeviceSimIdResultStatus === 'fulfilled' : true;
  const dispatch = useDispatch();

  useEffect(() => {
    if (ValidateDeviceSimIdResult && ValidateDeviceSimIdResult?.serviceHeader?.statusMsg === 'SUCCESS' && isPearl) {
      if (samsungCheckFulFilled && !carrierLock) {
        handleClickForPearl();
      }
    }
  }, [ValidateDeviceSimIdResult]);

  useEffect(() => {
    const rebeatOfferId =
      lineHasOffer && lineOffer?.[0]?.offers?.[0]?.offerSubType === 'Virtual Reward'
        ? lineOffer?.[0]?.offers?.[0]?.sku
        : null;
    let rebeatElligible = false;
    offers?.proposition?.map((item) => {
      if (item?.soiEngagementId && rebeatOfferId) {
        if (item?.soiEngagementId === rebeatOfferId) {
          item?.dynamicAttrList?.map((data) => {
            if (data?.attrId === 'isPortIn') {
              if (!data?.value || data?.value === 'false') {
                rebeatElligible = true;
              }
            }
            return true;
          });
        }
      } else {
        return false;
      }
      return true;
    });
    setRebeatBYODCheck(rebeatElligible);
    props?.UpdateBYODCheck();
  }, []);

  useEffect(() => {
    setBrandValue('');
    setOSValue('');
    setSortValue('');
    setErrorMessage('');
    setToggle(toggleValue);
    setCategoryValue(defaultDeviceCategory);
    props.setLoadMore('');
  }, [activeMtn, defaultDeviceCategory, toggleValue]);

  useEffect(() => {
    const gridWallData = ProductListResult?.data?.data?.gridWall;
    const newProductList = gridWallData?.productList
      ? gridWallData?.productList
      : gridWallData?.deviceSku?.parentProducts || [];
    if (productList?.length > 0 && props?.cartItem) {
      const filteredList = productList.filter((item) => item.productId !== props?.cartItem?.productId);
      setErrorMessage('');
      setDeviceList(filteredList);
    } else if (productList?.length > 0) {
      setDeviceList(productList);
      setErrorMessage('');
    } else if (
      activeMtn !== undefined &&
      isEmpty(newProductList) &&
      (ProductListResult?.status === 'fulfilled' || ProductListResult?.status === 'rejected')
    ) {
      setErrorMessage('No devices were found for the chosen filters, please try again.');
    }
  }, [productList, categoryValue, props?.cartItem]);

  useEffect(() => {
    if (!isEmpty(SkuDetailsResult?.data?.data?.deviceSku?.parentProducts)) {
      setErrorMessage('');
      const skudetailsdata = cloneDeep(SkuDetailsResult?.data?.data?.deviceSku?.parentProducts);
      skudetailsdata[0].searchedSku = getSearchedSku;
      setDeviceList(skudetailsdata);
      sessionStorage.setItem('scrollY', 0);
    }
  }, [SkuDetailsResult]);

  useEffect(() => {
    if (!isEmpty(SkuListResult?.data?.data?.productList) && SkuListResult?.data?.data?.productList?.length === 1) {
      const gridWallData = SkuListResult?.data?.data?.productList;
      const deviceSkuData = gridWallData[0];
      const isBundledGW = getQueryParamByName('isBundledGW') ? '&isBundledGW=true' : '';
      const searchedText = SkuListResult?.originalArgs?.body?.data?.searchText;
      const searchedSorId = deviceSkuData?.childSkus.filter((rec) => rec.sorId === searchedText);
      const defaultSku = searchedSorId?.length > 0 ? searchedSorId?.[0]?.sorId : deviceSkuData?.defaultSKU;
      if (deviceSkuData?.productDisplayName?.indexOf('Hum') !== -1) {
        navigate(
          `${getUIContextPathBAU()}/hummodal.html?offerEligible=Y&activeMtn=${activeMtn}&productId=${
            deviceSkuData?.productId
          }&defaultSku=${defaultSku}${isBundledGW}`,
        );
      } else {
        navigate(
          `${getUIContextPathBAU()}/product-detail.html?offerEligible=Y&activeMtn=${activeMtn}&productId=${
            deviceSkuData?.productId
          }&defaultSku=${defaultSku}`,
        );
      }
    }
  }, [SkuListResult?.isSuccess]);

  SetDeviceListHook({ SkuListResult, setDeviceList });

  const brand =
    refinements &&
    refinements.length > 0 &&
    refinements[0] &&
    refinements?.filter((data) => data?.refinementName === 'Brand');
  const OS =
    refinements &&
    refinements.length > 0 &&
    refinements[0] &&
    refinements?.filter((data) => data.refinementName === 'OS');

  const Category =
    refinements &&
    refinements.length > 0 &&
    refinements[0] &&
    refinements?.filter((data) => data.refinementName === 'Category');
  const existingSortOptions =
    sortOptions && sortOptions.length > 0
      ? sortOptions.map((option) => ({
          label: option.label,
          value: option.value,
          isSelected: option.isSelected === 'true',
        }))
      : [];
  const refinementOptions = Category?.[0]?.refinementOptions;
  const brandOptions = brand?.[0]?.refinementOptions;
  const OSOptions = OS?.[0]?.refinementOptions;

  const sortAlphabetically = (array, field) => {
    array.sort((a, b) => {
      if (a[`${field}`].toUpperCase() < b[`${field}`].toUpperCase()) {
        return -1;
      }
      if (a[`${field}`].toUpperCase() > b[`${field}`].toUpperCase()) {
        return 1;
      }
      return 0;
    });
  };

  const brandName =
    brand && brand?.length > 0
      ? brand[0].refinementOptions?.map((option) => ({
          label: option.displayName,
          value: option.displayName,
        }))
      : [];
  sortAlphabetically(brandName, 'label');
  brandName.unshift({ label: 'Brand', value: '' });

  const OSName =
    OS && OS.length > 0
      ? OS[0].refinementOptions.map((osObj) => ({
          label: decodeHTMLEntities(osObj.displayName), // HTML decoding is required to render HTML code properly like ®, ©
          value: osObj.displayName,
        }))
      : [];
  sortAlphabetically(OSName, 'label');
  OSName.unshift({ label: 'OS', value: '' });

  let categories =
    Category && Category.length > 0
      ? Category[0].refinementOptions.map((cat) => ({
          label: cat.displayName,
          value: cat.displayName,
        }))
      : [];

  if (enableUnlockedPhones === 'FALSE' && categories && categories.length > 0) {
    categories = categories.filter((cat) => cat.label !== 'Unlocked Phones');
  }
  if (isInDirect() && categories && categories.length > 0) {
    categories = categories.filter((cat) => cat.label !== 'Certified Pre-owned');
  }

  sortAlphabetically(categories, 'label');
  categories.unshift({ label: 'Category', value: '' });

  sortAlphabetically(existingSortOptions, 'label');
  const handleCategoryChange = (e) => {
    const category = e.target.value;
    setErrorMessage('');
    setCategoryValue(category);
    setDeviceList([]);
    props.setLoadMore('');
    getDevices(toggle, 0, 24, category, brandValue, osValue, sortValue, false, sortOptions);
  };

  const handleBrandChange = (e) => {
    const brand1 = e.target.value;
    setErrorMessage('');
    setBrandValue(brand1);
    setDeviceList([]);
    props.setLoadMore('');
    getDevices(toggle, 0, 24, categoryValue, brand1, osValue, sortValue, false, sortOptions);
  };

  const handleOSChange = (e) => {
    const os = e.target.value;
    setErrorMessage('');
    setOSValue(os);
    setDeviceList([]);
    props.setLoadMore('');
    getDevices(toggle, 0, 24, categoryValue, brandValue, os, sortValue, false, sortOptions);
  };

  const handleSortChange = (sort) => {
    setSortValue(sort);
    setErrorMessage('');
    setDeviceList([]);
    props.setLoadMore('');
    getDevices(toggle, 0, 24, categoryValue, brandValue, osValue, sort, false, sortOptions);
  };

  const handleResetChange = () => {
    setCategoryValue(defaultDeviceCategory);
    setBrandValue('');
    setOSValue('');
    setSortValue('');
    setErrorMessage('');
    setToggle(true);
    props.setLoadMore('');
    getDevices(true, 0, 24, defaultDeviceCategory, '', '', '', false, sortOptions);
  };

  const handleToggleState = () => {
    updateToggleOptions(!toggle, activeMtn);
    setActiveLineData(defaultDeviceCategory);
    setCategoryValue(defaultDeviceCategory);
    setBrandValue('');
    setOSValue('');
    setSortValue('');
    setErrorMessage('');
    setToggle(!toggle);
    props.setLoadMore('');
    getDevices(!toggle, 0, 24, defaultDeviceCategory, '', '', '', false, sortOptions);
  };

  const isNullOrEmpty = (str) =>
    !!(
      !str ||
      (str &&
        typeof str !== 'undefined' &&
        typeof str === 'string' &&
        (str.trim() === '' || str.trim().toUpperCase() === 'NULL'))
    );

  const trimToNull = (str) => (!isNullOrEmpty(str) ? str.trim() : null);

  const onSearchTxtChange = () => {};

  useEffect(() => {
    if (ValidateDeviceSimIdResultStatus === 'fulfilled' && props?.scanCheck !== 'BYOD' && props.popUp) {
      if (!carrierLock) {
        if (samsungPOSFFlagEnabled) {
          dispatch(appMessageActions.clearAppMessages());
        }
        validateDeviceSimId();
      }
      if (carrierLock) {
        dispatch(appMessageActions.addAppMessage('Carrier Lock is on, please unlock to continue.', 'error'));
      }
    }
  }, [ValidateDeviceSimIdResult, ValidateDeviceSimIdResultStatus]);

  useEffect(() => {
    if (eSimDetailsResultStatus === 'fulfilled' && props?.scanCheck !== 'BYOD') {
      initSimDetailsResp(eSimDetailsResult);
    }
  }, [eSimDetailsResult?.data, eSimDetailsResultStatus]);

  const onAutoCompleteItemSkuSearch = (searchSku) => {
    const searchedSKU = trimToNull(searchSku);
    if (searchedSKU) {
      const lineInfo = totalLines.filter((item) => item.mobileNumber === activeMtn);
      const intentType = lineInfo[0]?.lineActivityType === 'NSE' ? 'AAL' : 'EUP';
      const params = {
        data: {
          channel: 'assisted',
          sorId: searchedSKU,
          cartId: cartDetails?.cartHeader?.cartId || '',
          caseId: cartDetails?.cartHeader?.caseId || '',
          orderType: cartDetails?.orderDetails?.orderType || '',
          intentType,
          locationCode: cartDetails?.orderDetails?.locationCode || '',
          processingMTN: activeMtn,
          mtn: '',
          productType: 'device',
        },
      };

      getSkuDetails({ body: params }, false);
      setSearchedsku(searchedSKU);
    }
  };

  const getSkuList = (search, isSearchText = false) => {
    const searchText = trimToNull(search);
    console.log('getSkuList => ', searchText);
    const lineInfo = totalLines.filter((item) => item.mobileNumber === activeMtn);
    const request = {
      data: {
        channel: 'assisted',
        ...(isSearchText
          ? { searchText }
          : {
              sorId: searchText,
              cartId: cartDetails?.cartHeader?.cartId || '',
              caseId: cartDetails?.cartHeader?.caseId || '',
              orderType: cartDetails?.orderDetails?.orderType || '',
              intentType: lineInfo[0]?.lineActivityType === 'NSE' ? 'AAL' : 'EUP',
              locationCode: cartDetails?.orderDetails?.locationCode || '',
              processingMTN: activeMtn,
              mtn: '',
            }),
        productType: 'device',
      },
    };

    getSkuListRequest({ body: request }, false);
  };
  const deviceCatagory = () => {
    if (lineOffer) {
      if (lineOffer?.[0]?.deviceCategory) {
        return `${lineOffer?.[0]?.deviceCategory.toLowerCase()}s`;
      }
      return null;
    }
    return null;
  };

  const isStackbleOffer = () => {
    const fileredOffer = offers?.lines?.filter(
      (line) =>
        line?.mtn?.toLowerCase()?.replace(/\s/g, '') === activeLine?.[0]?.mobileNumber?.toLowerCase() ||
        line?.mtn?.toLowerCase()?.replace(/\s/g, '') === activeLine?.[0]?.lineNumber?.toLowerCase() ||
        line?.mtn?.toLowerCase()?.replace(/\s/g, '') === activeLine?.[0]?.mtn?.toLowerCase() ||
        line?.mtn?.toLowerCase()?.replace(/\s/g, '') === props?.activeMtn,
    );
    const lineHasOffers = !!(fileredOffer?.length && fileredOffer?.length > 0);
    let stackedOffers = [];
    if (lineHasOffers && fileredOffer?.[0]?.offers?.length > 1) {
      stackedOffers = fileredOffer?.[0]?.offers?.filter((item) => EquipOffers?.includes(item?.offerSubType));
    }
    const isOffersStacked = stackedOffers?.length > 1;
    return isOffersStacked;
  };

  // Note: Created one state for this operation i.e. activeLineData, usage  getActivelineCategory={activeLineData}

  return (
    <TabContainer data-testid='gridwallDevices' devicestocompare={props.devicestocompare}>
      <DeviceListTab
        toggleValue={toggleValue}
        setToggle={setToggle}
        isLoadMore={props?.isLoadMore}
        showProspectTile={showProspectTile}
        selectedSkuId={selectedSkuId}
        cartDetails={cartDetails}
        errorMessage={errorMessage}
        pdpSelectedDevice={pdpSelectedDevice}
        toggle={toggleOptions?.[activeMtn] === undefined ? toggle : toggleOptions?.[activeMtn]}
        resetToggleOptions={props.resetToggleOptions}
        showToogle={lineOffer ? lineOffer?.[0]?.offers?.[0]?.sku : null}
        offers={offers}
        deviceCategory={deviceCatagory()}
        offerMessage={lineOffer ? lineOffer?.[0]?.offers?.[0]?.description : null}
        totalLines={totalLines}
        activeMtn={activeMtn}
        landingLinesInfo={landingLinesInfo}
        selectedTab={selectedTab}
        setTab={setTab}
        brandName={brandName}
        brandValue={brandValue}
        categories={categories}
        categoryValue={categoryValue}
        osName={OSName}
        osValue={osValue}
        sortValue={sortValue}
        existingSortOptions={existingSortOptions}
        products={products?.[activeMtn] || {}}
        deviceSelection={props?.cartItem}
        getDevices={getDevices}
        pagination={pagination}
        techRecommendation={techRecommendation}
        productList={errMessage ? [] : deviceList}
        handleCategoryChange={handleCategoryChange}
        handleBrandChange={handleBrandChange}
        handleOSChange={handleOSChange}
        handleSortChange={handleSortChange}
        handleResetChange={handleResetChange}
        resetSortOptions={resetSortOptions}
        handleToggleState={handleToggleState}
        saveTempDeviceSelectionData={saveTempDeviceSelectionData}
        onSearchTxtChange={onSearchTxtChange}
        onAutoCompleteItemSkuSearch={onAutoCompleteItemSkuSearch}
        getSkuList={getSkuList}
        updateCompareDeviceData={updateCompareDeviceData}
        compareDeviceDataFromStore={compareDeviceDataFromStore}
        handleCompareCheckboxChange={props.handleCompareCheckboxChange}
        handleRemoveProductFromCompareInGW={props.handleRemoveProductFromCompareInGW}
        devicestocompare={props.devicestocompare}
        errMessage={errMessage}
        is5GDevice={props.is5gLine}
        CustomerData={CustomerData}
        lineActivityType={lineActivityType}
        hasIteminCart={hasIteminCart}
        handleByodflag={handleByodflag}
        propositionMessage={lineOffer ? lineOffer?.[0]?.offers?.[0]?.propositionMessage : null}
        offerSourceSystem={lineOffer ? offers?.offerSourceSystem : null}
        offerSubType={lineOffer ? lineOffer?.[0]?.offers?.[0]?.offerSubType : null}
        isOffersStacked={isStackbleOffer()}
        isDWOS={isDWOS}
        intentCheck={intentCheck}
        rebeaBYODCheck={rebeatBYODCheck}
        getActivelineCategory={activeLineData}
        sortOptions={sortOptions || {}}
        trialDeviceDetail={trialDeviceDetail}
        prospectByodFlow={props?.prospectByodFlow}
        validateDeviceSimIdRequest={validateDeviceSimIdRequest}
        ValidateDeviceSimIdResult={ValidateDeviceSimIdResult}
        eSimDetailsResult={eSimDetailsResult}
        validateDeviceSimId={validateDeviceSimId}
        initSimDetailsResp={initSimDetailsResp}
        cartItem={props?.cartItem}
        selectedLine={props?.selectedLine}
        setIsCloseByod={props?.setIsCloseByod}
        refinementOptions={refinementOptions}
        brandOptions={brandOptions}
        OSOptions={OSOptions}
        isGWByodEUPEnabledFlag={isGWByodEUPEnabledFlag}
        installmentTerm={installmentTerm}
        isPearl={isPearl}
        setUpcCode={props?.setUpcCode}
      />
    </TabContainer>
  );
}
GridwallDevices.propTypes = {
  ValidateDeviceSimIdResult: PropTypes.shape({
    serviceBody: PropTypes.shape({
      serviceResponse: PropTypes.shape({
        context: PropTypes.shape({
          deviceInfo: PropTypes.shape({
            carrierLock: PropTypes.string.isRequired,
          }),
        }),
      }),
    }),
  }),
};
export default GridwallDevices;
