import { useEffect, useState, useMemo } from 'react';
import { useDispatch } from 'react-redux';
import PropTypes from 'prop-types';
import { Title } from '@vds/typography';
import { Button } from '@vds/buttons';
import styled from 'styled-components';
import { HttpService } from 'onevzsoemfeframework/HTTPService';
import { useCustomApiHooks as createApi } from 'onevzsoemfecommon/APIServiceUtils'; 
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import * as appLoaderActions from 'onevzsoemfecommon/AppLoaderActions';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { isIpad, isChatStore, isTelesales, executeShellFunction } from 'onevzsoemfeframework/DomService';
import * as DOMPurify from 'dompurify';
import { FlexColumnGap } from '../DPBuyoutGlobalStyleConstants';
import LeftPanel from './LeftPanel/LeftPanel';
import Header from './Header';
import RightPanel from './RightPanel/RightPanel';
import AgreementPdfView from './RightPanel/AgreementPdfView';
import {
  useLazyAgreementPDFQuery,
  useLazyReadUserParamDetailsQuery,
} from '../../../modules/services/APIService/APIServiceHooks';

const MainContainer = styled.div`
  background: #f8f7f5;
  min-height: 100vh;
`;
const ContentContainer = styled.div`
  padding: 0rem 2.625rem 1.188rem 2.625rem;
  display: flex;
  flex-direction: row;
  height: calc(100vh - 56px);
  gap: 2.25rem;
  overflow: hidden scroll;
`;

const Phonecards = styled.div`
  width: max-content;
  max-height: calc(100vh - 210px);
  overflow-y: auto !important;
  scrollbar-width: thin !important;
`;

const SelectTitle = styled.div`
  padding: 1rem 0 1rem 0rem;
`;

// once images are avalable we can remove margin-right if needed
const Buttoncontainer = styled.div`
  gap: 1rem;
  padding-top: 3rem;
  flex-direction: row;
  display: flex;
  position: fixed;
  right: 2.625rem;
  bottom: 1.188rem;
  margin-right: 1.2rem;
  z-index: 1000;

  @media (max-width: 1024px) {
    right: 1rem;
    bottom: 3rem;
    margin-right: 0;
    flex-wrap: wrap;
    justify-content: center;
    width: calc(100% - 2rem);
  }
`;
const HeaderContent = styled.div`
  position: sticky;
  top: 0;
  z-index: 10;
`;

const InformationcontainerWrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
`;

const useCustomApiHooks = createApi();

function SelectDevice(props) {
  const [selectedMtnDetails, setSelectedMtnDetails] = useState(null);
  const [leftPanelDetails, setLeftPanelDetails] = useState([]);
  const [selectedIdx, setSelectedIdx] = useState('');
  const [viewAgreement, setViewAgreement] = useState(false);
  const [agreementData, setAgreementData] = useState(null);
  const showParitalPayment = false; // till partial payment flow development complete

  const [getAgreementPdf, getAgreementPdfResult] = useLazyAgreementPDFQuery();
  const [readUserParamDetails] = useLazyReadUserParamDetailsQuery();

  const dispatch = useDispatch();

  const { activeMDN, setActiveMDN, setBuyoutPayModal, posInitiateBuyout, posInitiateBuyOutResult } = props;

  const fetchInitiateBuyout = useMemo(() => posInitiateBuyOutResult?.data?.body, [posInitiateBuyOutResult?.data?.body]);

  const callPosInitiateBuyoutApi = (mdn) => {
    const reqBody = {
      accountNumber: props?.accountNumber,
      mtn: mdn,
      processStep: 'initiate',
      pageName: 'DpBuyout'
    };
    setActiveMDN(mdn);
    setSelectedIdx(mdn);
    posInitiateBuyout({ body: reqBody, spinner: true });
  };

  useEffect(() => {
    if (getAgreementPdfResult?.isSuccess && getAgreementPdfResult?.data?.installmentContractData) {
      setViewAgreement(true);
      setAgreementData(getAgreementPdfResult.data.installmentContractData);
    }
  }, [getAgreementPdfResult]);

  useEffect(() => {
    callPosInitiateBuyoutApi(props?.selectedMtn);
  }, [props?.selectedMtn, props?.accountNumber]);

  useEffect(() => {
    if (posInitiateBuyOutResult?.isSuccess && posInitiateBuyOutResult?.data?.body?.serviceBody) {
      const tempDevicePayOffInfo =
        posInitiateBuyOutResult?.data?.body?.serviceBody?.serviceResponse?.context?.devicePayOffInfo;
      const tempData = [...leftPanelDetails];
      tempDevicePayOffInfo
        ?.filter((item) => /true/i.test(item.active))
        ?.forEach((item) => {
          const obj = {
            mdn: item?.mdn,
            nickName: item?.nickName,
            productName: item?.productName,
            active: item?.active,
            pricePlanInfo: item?.pricePlanInfo?.planDisplayName || '',
            pendingNumberOfInstallments: item?.pendingNumberOfInstallments,
            totalBuyoutAmount: item?.totalBuyoutAmount,
            defaultImage: item?.defaultImage,
            selected: selectedIdx === item?.mdn,
          };
          /* istanbul ignore next */
          const index = leftPanelDetails?.findIndex((i) => i?.mdn === item?.mdn);
          /* istanbul ignore next */
          if (index > -1) {
            tempData[index] = obj;
          } else {
            tempData?.push(obj);
          }
        });
      const tempSelectedMtnDetails = tempDevicePayOffInfo?.find((item) => item?.mdn === activeMDN);
      setLeftPanelDetails(tempData);
      setSelectedMtnDetails(tempSelectedMtnDetails);

      if(props.paymentDone){
        dispatch(appMessageActions.addAppMessage(`The Partial Payment of ${tempSelectedMtnDetails.nickName} ${tempSelectedMtnDetails.productName} agreement is complete.`, 'success', false));
      }
      // dispatch(appLoaderActions?.hide());
    }
  }, [fetchInitiateBuyout, posInitiateBuyOutResult, props?.selectedMtn]);
  const soeguisubkey = sessionStorage.getItem("analyticssessionid")||""
  const isGlassboxEnabled = /true/i.test(getAssistedCradlePropertyV2(['isGlassboxEnabled'])[0]);
  const isQuantumMetricEnabled = /true/i.test(getAssistedCradlePropertyV2(['isQuantumMetricEnabled'])[0]);
  const aiQuoteSessionId = '';
  const elvisFFlag =
    /true/i.test(sessionStorage.getItem('elvisFFlag')) ||
    /true/i.test(JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.elvisFFlag);

  const aiQuoteLineUpgradeNowFFlag = /true/i.test(getAssistedCradlePropertyV2(['aiQuoteLineUpgradeNowFFlag'])[0]);
   
  const inIframe = () => {
          try {
            return window.self !== window.top;
          } catch (e) {
            return true;
          }
        };
  const ipadNavigation = (url)=>{
        let shellParams = {
            name: "order",
            path: "",
            replace: "true",
            params: `rawurl:${url}`
          };
          executeShellFunction(
            "Shell",
            "showScreen",
            "none",
            shellParams
          );
   }
   const inIframeNavigation = (url)=>{
     const message = {
                iframe: "order", // screenName
                path: "",
                replace: true,
                url: url
              };
        let target = window.parent;
        target.postMessage(message, window.location.origin);
   }
   const getUrlNavigation =() =>{
     if (aiQuoteLineUpgradeNowFFlag) {
          return `${window.location.protocol}//${window.location.host}/sales/assisted/new/aiquote.html?soeguisubkey=${soeguisubkey}&isGlassboxEnabled=${isGlassboxEnabled}&isQuantumMetricEnabled=${isQuantumMetricEnabled}&aiQuoteCachedDataSessionId=${aiQuoteSessionId}&elvisFFlag=${elvisFFlag}`;
        }
        else {
          return `${window.location.protocol}//${window.location.host}/sales/assisted/landing.html`;
        }
   }

 const desktopNavigation =(url) =>{
   if (isChatStore() || isTelesales()) {
         // window.open(DOMPurify.sanitize(url), "_blank");
            window.parent.orderTabOpened = window.open(
              DOMPurify.sanitize(url),
              'nsaOrderingWindow',
              "toolbar=yes,scrollbars=yes,resizable=yes,top=50,left=100,width=1000,height=800"
            );
          } else {
            if (inIframe()) {
             inIframeNavigation(url)
            } else {
              window.open(DOMPurify.sanitize(url), "_blank");
            }
          }
 }

 const {
     data: generateJWTData,
     isSuccess: generateJWTIsSuccess,
     fetchData: fetchGenerateJWTData,
   } = useCustomApiHooks('/fraudservice/generateJWT');

    const fetchGenerateJWT = () => {
       const cartId = sessionStorage.getItem("cartId");
       if (HttpService?.defaults?.headers && cartId) {
         HttpService.defaults.headers.cartid = cartId;
         HttpService.defaults.headers.assistedcartid = cartId;
       }
       fetchGenerateJWTData({ },);
     };
 
  useEffect(()=>{
     /* istanbul ignore else */
      if (generateJWTIsSuccess && generateJWTData) {
        const url = getUrlNavigation();
       
        if (isIpad()) {
         ipadNavigation(url)
        } else {
         desktopNavigation(url)
        }
      }
    
  },[generateJWTIsSuccess])

  /* istanbul ignore next */
  const handleUpgradeNow = async () => {
    try {
      dispatch(appLoaderActions?.show());
    const inDirectCheck = (sessionStorage.getItem("channel") === 'OMNI-INDIRECT' || sessionStorage.getItem("channel") === 'OMNI-INDIRECT-TAB')
    if(inDirectCheck) {
       await fetchGenerateJWT();
    } else {
      const apiResponse = await readUserParamDetails({ body: {} });
       const status = apiResponse?.data?.data?.status || apiResponse?.data?.status;
       const readUserStatus = (status === 1 && apiResponse?.data?.data?.salesRepId !== "");
      if (readUserStatus) {
        await fetchGenerateJWT();
    } else {
      let channelId = sessionStorage.getItem('channel');
      let channelCheck = channelId === "OMNI-TELESALES" || channelId === "CHAT-STORE";
      let errorDataMessage = channelCheck ? "Something went wrong. Please reassist the customer." : "Please enter your Sales Rep ID.";

      dispatch(appMessageActions.addAppMessage(errorDataMessage, 'error', true, true));
      dispatch(appLoaderActions?.hide());
      return;
    }
  }
   
    } catch (error) {
        dispatch(appLoaderActions?.hide());
        console.error('API Error:', error);
      }
    };

  return viewAgreement ? (
    <div className='full-page'>
      <AgreementPdfView
        src={agreementData}
        modalName='Agreement'
        locationCode={props.locationCode}
        closeModal={() => setViewAgreement(false)}
        onError={(error) => {
          console.log(error);
        }}
      />
    </div>
  ) : (
    <MainContainer>
      <HeaderContent>
        <Header closeDpBuyoutModal={() => props?.closeDpBuyoutModal()} />
      </HeaderContent>
      <ContentContainer>
        <FlexColumnGap>
          <SelectTitle>
            <Title size='xsmall' color='#000000'>
              Select a device
            </Title>
          </SelectTitle>
          <Phonecards>
            <LeftPanel
              leftPanelDetails={leftPanelDetails}
              selectedIdx={selectedIdx}
              setSelectedIdx={(mdn) => callPosInitiateBuyoutApi(mdn)}
              paymentDone={props.paymentDone}
            />
          </Phonecards>
        </FlexColumnGap>
        <InformationcontainerWrapper>
          <RightPanel
            selectedMtnDetails={selectedMtnDetails}
            locationCode={props.locationCode}
            getAgreementPdf={getAgreementPdf}
            paymentDone = {props.paymentDone}
          />
        </InformationcontainerWrapper>
        <Buttoncontainer>
        {/true/i.test(selectedMtnDetails?.equipmentUpgradeEligibility?.edgeUpEligible) && (
            <Button 
              size='large' 
              data-testid='testUpgradeNow' 
              disabled={false} 
              use='secondary' 
              onClick={handleUpgradeNow}
            >
              Upgrade now
            </Button>
          )}
         { /* istanbul ignore next */
        showParitalPayment && <Button size='large' disabled={false} use='secondary' onClick={() => console.log('clicked partial payment')}>
          Partial payment
        </Button>}
        {!props.paymentDone && <Button size='large' disabled={false} use='primary' onClick={() => setBuyoutPayModal(true)}>
          Buyout
        </Button>}
      </Buttoncontainer>
      </ContentContainer>
      
    </MainContainer>
  );
}

SelectDevice.propTypes = {
  closeDpBuyoutModal: PropTypes.func,
  selectedMtn: PropTypes.any,
  accountNumber: PropTypes.any,
  activeMDN: PropTypes.any,
  setActiveMDN: PropTypes.func,
  setBuyoutPayModal: PropTypes.func,
  paymentDone:PropTypes.any
};

export default SelectDevice;
