import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import Header from './Header';
// Mock window.alert
const mockAlert = jest.fn();
global.alert = mockAlert;
describe('Header Component', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });
  test('renders Header component without crashing', () => {
    const { container } = render(<Header closeDpBuyoutModal ={jest.fn()}/>);
    expect(container.firstChild).toBeInTheDocument();
  });
  test('displays Device Buyout title text', () => {
    render(<Header closeDpBuyoutModal ={jest.fn()} />);
    expect(screen.getByText('Device Buyout')).toBeInTheDocument();
  });
  test('renders back button that triggers alert on click', () => {
    render(<Header closeDpBuyoutModal ={jest.fn()} />);
    const backButton = screen.getByRole('button');

    fireEvent.click(backButton);
  });
});