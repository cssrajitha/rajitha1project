import styled from 'styled-components';
import PropTypes from 'prop-types';
import { Title } from '@vds/typography';
import { Icon } from '@vds/icons';
import { ButtonIcon } from '@vds/button-icons';
import { FlexRowGap } from '../DPBuyoutGlobalStyleConstants';

const HeaderContainer = styled.div`
  background: #ffffff;
  padding: 0.25rem 1rem 0.5rem 1rem;
`;

function Header (props) {
 const closePopup = ()=>{
  props.closeDpBuyoutModal();
 }
  return(
  <HeaderContainer>
    <FlexRowGap gap={16}>
      <ButtonIcon
        kind='ghost'
        size='large'
        surface='light'
        renderIcon={(props) => <Icon name='left-arrow' {...props} />}
        onClick={() => closePopup()}
      />
      <Title size='xsmall' bold color='#000000'>
        Device Buyout
      </Title>
    </FlexRowGap>
  </HeaderContainer>
)};

Header.propTypes = {
  closeDpBuyoutModal : PropTypes.func,
};
export default Header;