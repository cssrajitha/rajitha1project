import { useDispatch } from 'react-redux';
import * as appLoaderActions from 'onevzsoemfecommon/AppLoaderActions';
import { fireEvent, render, screen } from '@testing-library/react';
import SelectDevice from './SelectedDevice';

const mockPosInitiateBuyOut = jest.fn();
const mockPosInitiateBuyOutResult = {
  data: {
    body: {
      serviceBody: {
        serviceResponse: {
          context: {
            devicePayOffInfo: [
              {
                mdn: '1111111111',
                nickName: 'Test Phone 1',
                productName: 'iPhone 13',
                active: 'TRUE',
                pendingNumberOfInstallments: 5,
                totalBuyoutAmount: 500.0,
              },
              {
                mdn: '2222222222',
                nickName: 'Test Phone 2',
                productName: 'Galaxy S21',
                active: 'TRUE',
                pendingNumberOfInstallments: 8,
                totalBuyoutAmount: 800.0,
              },
              {
                mdn: '3333333333',
                nickName: 'Inactive Phone',
                productName: 'Old Phone',
                active: 'FALSE',
                pendingNumberOfInstallments: 2,
                totalBuyoutAmount: 200.0,
              },
            ],
          },
        },
      },
    },
  },
  status: 'fulfilled',
  isSuccess: true,
};

const mockAgreement = jest.fn();
const mockAgreementResult ={
  isSuccess:true,
  data:{
    installmentContractData:"installmentContract here"
  }
}

const mockReadUserParamDetails = jest.fn();
jest.mock('../../../modules/services/APIService/APIServiceHooks', () => ({
  useLazyPosInitiateBuyOutQuery: () => [mockPosInitiateBuyOut, mockPosInitiateBuyOutResult],
  useLazyAgreementPDFQuery : () => [mockAgreement,mockAgreementResult],
  useLazyReadUserParamDetailsQuery: () => [mockReadUserParamDetails],
}));

jest.mock('./LeftPanel/LeftPanel', () => ({
  __esModule: true,
  default: ({ leftPanelDetails, selectedIdx, setSelectedIdx }) => (
    <div data-testid='left-panel'>
      MockLeftPanel
      <button
        type='button'
        data={leftPanelDetails}
        data-attribute={selectedIdx}
        onClick={() => setSelectedIdx('1234567890')}
        data-testid='left-panel-select-btn'
      >
        Select MDN
      </button>
    </div>
  ),
}));

jest.mock('./Header', () => ({
  __esModule: true,
  default: ({ closeDpBuyoutModal }) => (
    <div data-testid='header'>
      MockHeader
      <button type='button' onClick={closeDpBuyoutModal} data-testid='header-close-btn'>
        Close Modal
      </button>
    </div>
  ),
}));

jest.mock('./RightPanel/RightPanel', () => ({
  __esModule: true,
  default: ({ selectedMtnDetails }) => (
    <div data-testid='right-panel'>MockRightPanel - {selectedMtnDetails ? 'Details Loaded' : 'No Details'}</div>
  ),
}));

jest.mock('react-redux');
jest.mock('onevzsoemfecommon/AppLoaderActions');

const mockProps = {
  closeDpBuyoutModal: jest.fn(),
  selectedMtn: '1111111111',
  accountNumber: '123456',
  activeMDN: '1111111111',
  setActiveMDN: jest.fn(),
  setBuyoutPayModal: jest.fn(),
  posInitiateBuyout: jest.fn(),
  posInitiateBuyOutResult: { ...mockPosInitiateBuyOutResult },
};

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradlePropertyV2: () => ['TRUE'],
  }),
  { virtual: true },
);

jest.mock('onevzsoemfecommon/APIServiceUtils', () => {
  const mockCustomAPI = {
    data: {status:"success"},
    isSuccess: true,
    fetchData: jest.fn(),
  };
  
  return {
    useCustomApiHooks: jest.fn(() => {
      // This returns a function that will be called with the URL
      return () => mockCustomAPI;
    }),
  };
});

jest.mock('onevzsoemfeframework/HTTPService', () => {
  // Define the mock data *inside* the factory so it's available when the mock runs
  const mockHTTP = {
    defaults:{
    header:{
      cartid:"",
      assistedcartid:""
    }
  },
  };

  return {
    HttpService :  mockHTTP,
  };
});


const mockedHandleUpgradeNow = jest.fn();

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockedHandleUpgradeNow,
}));

describe('SelectDevice Component', () => {
  const mockDispatch = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
    useDispatch.mockReturnValue(mockDispatch);
    sessionStorage.setItem('cartId',"1234512")
    appLoaderActions.hide.mockReturnValue({ type: 'APP_LOADER_HIDE' });
  });

  it('renders pdf component', async () => {
    render(<SelectDevice {...mockProps} />);

    expect(screen.getByText('Agreement')).toBeInTheDocument();
    const button = screen.getByRole("button",{name:"Back Button"})
    fireEvent.click(button)
   
  });


});
