import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import RightPanel from './RightPanel';

// Mock the helper functions
jest.mock('onevzsoemfecommon/Helpers/validation', () => ({
  formatPhoneNumberWithSymbol: jest.fn((number, symbol) => {
    if (!number) return '';
    // Ensure we return the formatted phone number for testing
    if (number === '3363419849') return '336-341-9849';
    return number.replace(/(\d{3})(\d{3})(\d{4})/, `$1${symbol}$2${symbol}$3`);
  }),
  formatCurrency: jest.fn((amount) => {
    if (amount === null || amount === undefined) return '$0.00';
    return `$${Number(amount).toFixed(2)}`;
  })
}));

const mockSelectedMtnDetails = {
  modelName: 'Apple iPhone 14 128GB in Midnight',
  mdn: '3363419849',
  nickName: 'BRANDON SUAREZ',
  deviceId: '359388539694196',
  remainingBalance: '222.20',
  productName: 'IPHONE 14 128 MIDNIGHT',
  deviceSku: 'MPUA3LL/A',
  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-midnight-fall22-a',
  active: 'true',
  totalPaidAmount: 577.79,
  pendingNumberOfInstallments: 9,
  numberOfInstallmentsBilled: 27,
  downPaymentAmount: 0.00,
  taxAmountUnpaid: '0.00',
  taxAmountUnbilled: '0.00',
  totalBuyoutAmount: 222.20,
  buyoutFlag: 'true',
  nextBuyoutDate: '',
  edgeUpPrincipalAmountUnpaid: '0.00',
  edgeUpOriginalCost: '399.99',
  edgeUpRequiredPercent: '50.00',
  pastTradeInRestrictionTimePeriod: 'true',
  bgPromoActive: '',
  imei: '359388539694196',
  agreementInfo: {
    loanNumber: '1593921839',
    loanMonthlyPaymentAmount: '22.22',
    loanAmount: 799.99,
    loanType: 'E'
  },
  equipmentUpgradeEligibility: {
    edgeUpEligible: 'TRUE'
  }
};

const mockSelectedMtnDetails2 = {
  modelName: 'Apple iPhone 14 128GB in Midnight',
  mdn: '3363419849',
  nickName: 'BRANDON SUAREZ',
  deviceId: '359388539694196',
  remainingBalance: '222.20',
  productName: 'IPHONE 14 128 MIDNIGHT',
  deviceSku: 'MPUA3LL/A',
  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-midnight-fall22-a',
  active: 'true',
  totalPaidAmount: 577.79,
  pendingNumberOfInstallments: 9,
  numberOfInstallmentsBilled: 27,
  downPaymentAmount: 0.00,
  taxAmountUnpaid: '0.00',
  taxAmountUnbilled: '0.00',
  totalBuyoutAmount: 222.20,
  buyoutFlag: 'true',
  nextBuyoutDate: '',
  edgeUpPrincipalAmountUnpaid: '0.00',
  edgeUpOriginalCost: '399.99',
  edgeUpRequiredPercent: '50.00',
  pastTradeInRestrictionTimePeriod: 'true',
  bgPromoActive: '',
  imei: '359388539694196',
  agreementInfo: {
    loanNumber: '1593921839',
    loanMonthlyPaymentAmount: '22.22',
    loanAmount: 799.99,
    loanType: 'E'
  },
};

const mockDevicePayment = [
  {
    PaidPrincipal: '$577.79',
    RemainingPrincipalBalance: '$222.20',
    RemainingPayments: '9',
    MonthlyAmount: '$22.22'
  }
];

const defaultProps = {
  selectedMtnDetails: mockSelectedMtnDetails,
  DevicePayment: [] // Not used in the updated component
};

const defaultProps2 = {
  selectedMtnDetails: mockSelectedMtnDetails2,
  DevicePayment: [] // Not used in the updated component
};

describe('RightPanel Component - Updated Version', () => {
  beforeEach(() => {
    // Mock console.log to avoid test output pollution
    jest.spyOn(console, 'log').mockImplementation(() => {});
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  test('renders RightPanel component without crashing', () => {
    const { container } = render(<RightPanel {...defaultProps} />);
    expect(container.firstChild).toBeInTheDocument();
  });

     test('renders RightPanel component without crashing', () => {
    render(<RightPanel {...defaultProps} paymentDone={true}/>);
    expect (screen.getByText("Partial Payment completed")).toBeInTheDocument();
    expect (screen.getByText("Device Payment Agreement Buyout")).toBeInTheDocument();
  });

  test('displays device nickname and model information', () => {
    render(<RightPanel {...defaultProps} />);
    
    expect(screen.getByText('BRANDON SUAREZ')).toBeInTheDocument();
    expect(screen.getByText(/Apple iPhone 14 128GB in Midnight/)).toBeInTheDocument();
  });

  test('click loan number hyperlink', () => {
    render(<RightPanel {...defaultProps} getAgreementPdf={jest.fn()} />);
    
   const textlink = screen.getByText("1593921839")
   fireEvent.click(textlink)
  });

  test('displays Early Upgrade Eligible badge', () => {
    render(<RightPanel {...defaultProps} />);
    
    expect(screen.getByText('Early Upgrade Eligible')).toBeInTheDocument();
  });

  test('displays Early Upgrade Eligible badge', () => {
    render(<RightPanel {...defaultProps2} />);
    
    expect(screen.getByText('Early Upgrade Eligible: No')).toBeInTheDocument();
  });

  test('handles missing DevicePayment data gracefully', () => {
    const propsWithoutPayment = {
      ...defaultProps,
      DevicePayment: undefined
    };
    
    render(<RightPanel {...propsWithoutPayment} />);
    
    expect(screen.getByText('Device Payment Summary')).toBeInTheDocument();
    expect(screen.getByText('Paid principal')).toBeInTheDocument();
  });

  test('handles empty DevicePayment array', () => {
    const propsWithEmptyPayment = {
      ...defaultProps,
      DevicePayment: []
    };
    
    render(<RightPanel {...propsWithEmptyPayment} />);
    
    expect(screen.getByText('Device Payment Summary')).toBeInTheDocument();
    expect(screen.getByText('Paid principal')).toBeInTheDocument();
  });

  test('handles missing agreementInfo gracefully', () => {
    const propsWithoutAgreement = {
      ...defaultProps,
      selectedMtnDetails: {
        ...mockSelectedMtnDetails,
        agreementInfo: undefined
      }
    };
    
    render(<RightPanel {...propsWithoutAgreement} />);
    
   // expect(screen.getByText('BRANDON SUAREZ')).toBeInTheDocument();
    expect(screen.getByText(/Device Cost:/)).toBeInTheDocument();
  });

  test('calculates device cost with missing agreementInfo', () => {
    const propsWithoutAgreement = {
      ...defaultProps,
      selectedMtnDetails: {
        ...mockSelectedMtnDetails,
        agreementInfo: undefined
      }
    };
    
  //  const { container } = render(<RightPanel {...propsWithoutAgreement} />);
    render(<RightPanel {...propsWithoutAgreement} />);
    expect(screen.getByText(/Device Cost:/)).toBeInTheDocument();
    
    // const { formatCurrency } = require('onevzsoemfecommon/Helpers/validation');
    // expect(formatCurrency).toHaveBeenCalled();
  });

  test('handles missing installment data for calculations', () => {
    const propsWithMissingInstallments = {
      ...defaultProps,
      selectedMtnDetails: {
        ...mockSelectedMtnDetails,
        pendingNumberOfInstallments: undefined,
        numberOfInstallmentsBilled: undefined
      }
    };
    
    render(<RightPanel {...propsWithMissingInstallments} />);
    
    // Should handle missing installment data gracefully
    expect(screen.getByText('Device Payment Summary')).toBeInTheDocument();
  });

  test('calculates percentage with zero device cost', () => {
    const propsWithZeroCost = {
      ...defaultProps,
      selectedMtnDetails: {
        ...mockSelectedMtnDetails,
        agreementInfo: {
          ...mockSelectedMtnDetails.agreementInfo,
          loanAmount: 0
        },
        downPaymentAmount: 0,
        totalPaidAmount: 100
      }
    };
    
    render(<RightPanel {...propsWithZeroCost} />);
    
    // When deviceCost is 0, percentage calculation results in Infinity, Math.floor makes it NaN
    expect(screen.getByText(/paid off/)).toBeInTheDocument();
  });

  test('handles missing nickName for key prop', () => {
    const propsWithoutNickName = {
      ...defaultProps,
      selectedMtnDetails: {
        ...mockSelectedMtnDetails,
        nickName: undefined
      }
    };
    
    const { container } = render(<RightPanel {...propsWithoutNickName} />);
    
    // Should render without crashing even with missing nickName
    expect(container.firstChild).toBeInTheDocument();
  });
  test('renders component structure with proper containers', () => {
    const { container } = render(<RightPanel {...defaultProps} />);
    
    expect(container.querySelector('div')).toBeInTheDocument();
    
    const deviceImages = container.querySelectorAll('img');
    expect(deviceImages.length).toBeGreaterThanOrEqual(1);
  });

  test('displays formatted currency values using formatCurrency helper', () => {
  //  const { container } = render(<RightPanel {...defaultProps} />);
    render(<RightPanel {...defaultProps} />);
    expect(screen.getByText(/Device Cost:/)).toBeInTheDocument();
    expect(screen.getByText(/Down Payment:/)).toBeInTheDocument();
    expect(screen.getByText('Buyout Amount')).toBeInTheDocument();
    
    // const { formatCurrency } = require('onevzsoemfecommon/Helpers/validation');
    // expect(formatCurrency).toHaveBeenCalled();
  });

  test('renders without console logging (console.log removed from component)', () => {
    const consoleSpy = jest.spyOn(console, 'log');
    
    render(<RightPanel {...defaultProps} />);
    
    // Component no longer has console.log statements
    expect(consoleSpy).not.toHaveBeenCalled();
    expect(screen.getByText('BRANDON SUAREZ')).toBeInTheDocument();
  });

  test('verifies PropTypes are correctly defined', () => {
    const validProps = {
      selectedMtnDetails: mockSelectedMtnDetails,
      DevicePayment: mockDevicePayment
    };
    
    expect(() => render(<RightPanel {...validProps} />)).not.toThrow();
  });

  test('handles null values in calculations', () => {
    const propsWithNullValues = {
      ...defaultProps,
      selectedMtnDetails: {
        ...mockSelectedMtnDetails,
        pendingNumberOfInstallments: null,
        numberOfInstallmentsBilled: null,
        downPaymentAmount: null,
        agreementInfo: {
          ...mockSelectedMtnDetails.agreementInfo,
          loanAmount: null
        }
      }
    };
    
    render(<RightPanel {...propsWithNullValues} />);
    
    expect(screen.getByText('Device Payment Summary')).toBeInTheDocument();
  });

  test('displays all required sections', () => {
    render(<RightPanel {...defaultProps} />);
    
   // expect(screen.getByText('BRANDON SUAREZ')).toBeInTheDocument(); // Device info
    expect(screen.getByText('Buyout Amount')).toBeInTheDocument(); // Buyout section
    expect(screen.getByText('Early Upgrade Eligible')).toBeInTheDocument(); // Badge
    expect(screen.getByText('Device Payment Summary')).toBeInTheDocument(); // Payment summary
    expect(screen.getByText('Paid principal')).toBeInTheDocument(); // Payment breakdown
  });


  test('displays paid principal from totalPaidAmount (not DevicePayment array)', () => {
   // const { formatCurrency } = require('onevzsoemfecommon/Helpers/validation');
    
    render(<RightPanel {...defaultProps} />);
    
    expect(screen.getByText('Paid principal')).toBeInTheDocument();
  //  expect(formatCurrency).toHaveBeenCalledWith(577.79); // Direct from selectedMtnDetails.totalPaidAmount
  });

  test('displays amount financed using formatCurrency for loanAmount', () => {
    render(<RightPanel {...defaultProps} />);
    
    expect(screen.getByText('Amount Financed')).toBeInTheDocument();
  });

  test('displays remaining principal balance as empty (commented out)', () => {
    render(<RightPanel {...defaultProps} />);
    
    expect(screen.getByText('Remaining principal Balance')).toBeInTheDocument();
  });

  test('handles missing totalPaidAmount gracefully', () => {
    const propsWithoutPaidAmount = {
      ...defaultProps,
      selectedMtnDetails: {
        ...mockSelectedMtnDetails,
        totalPaidAmount: undefined
      }
    };
    
    render(<RightPanel {...propsWithoutPaidAmount} />);
    
    expect(screen.getByText('Paid principal')).toBeInTheDocument();
    const { container } = render(<RightPanel {...propsWithoutPaidAmount} />);
    expect(container.firstChild).toBeInTheDocument();
  });

  test('handles missing loanMonthlyPaymentAmount gracefully', () => {
    const propsWithoutMonthlyAmount = {
      ...defaultProps,
      selectedMtnDetails: {
        ...mockSelectedMtnDetails,
        agreementInfo: {
          ...mockSelectedMtnDetails.agreementInfo,
          loanMonthlyPaymentAmount: undefined
        }
      }
    };
    
    render(<RightPanel {...propsWithoutMonthlyAmount} />);
    
    expect(screen.getByText('Monthly amount')).toBeInTheDocument();
    const { container } = render(<RightPanel {...propsWithoutMonthlyAmount} />);
    expect(container.firstChild).toBeInTheDocument();
  });

  test('component structure matches updated implementation', () => {
    const { container } = render(<RightPanel {...defaultProps} />);
    
   // const balanceRows = container.querySelectorAll('[class*="BalanceRow"]');
    expect(screen.getByText('Paid principal')).toBeInTheDocument();
    expect(screen.getByText('Remaining principal Balance')).toBeInTheDocument();
    expect(screen.getByText('Remaining payments')).toBeInTheDocument();
    expect(screen.getByText('Monthly amount')).toBeInTheDocument();
  });

  test('component renders without any console logging', () => {
    const consoleSpy = jest.spyOn(console, 'log');
    
    render(<RightPanel {...defaultProps} />);
    
    // Component no longer contains console.log calls
    expect(consoleSpy).not.toHaveBeenCalled();
    expect(screen.getByText('Device Payment Summary')).toBeInTheDocument();
  });

  test('verifies all new variables are calculated correctly', () => {
   // const { formatCurrency } = require('onevzsoemfecommon/Helpers/validation');
    
    render(<RightPanel {...defaultProps} />);
    
    expect(screen.getByText('Paid principal')).toBeInTheDocument();
    expect(screen.getByText('Amount Financed')).toBeInTheDocument();
    expect(screen.getByText('Remaining balance')).toBeInTheDocument();
  });

  test('verifies remaining principal balance field is empty (commented out)', () => {
    render(<RightPanel {...defaultProps} />);
    
    expect(screen.getByText('Remaining principal Balance')).toBeInTheDocument();
    
    const balanceRows = screen.getAllByText('Remaining principal Balance');
    expect(balanceRows.length).toBe(1);
  });

  test('tests percentage calculation edge cases', () => {
    const propsWithEdgeCase = {
      selectedMtnDetails: {
        ...mockSelectedMtnDetails,
        numberOfInstallmentsBilled: 1,
        pendingNumberOfInstallments: 2,
        totalPaidAmount: 266.66, // 1/3 of 799.99 to get 33%
        agreementInfo: {
          ...mockSelectedMtnDetails.agreementInfo,
          loanAmount: 799.99
        },
        downPaymentAmount: 0
      }
    };
    
    render(<RightPanel {...propsWithEdgeCase} />);
    
    // Percentage = (266.66/799.99)*100 = ~33%
    expect(screen.getByText('33% paid off')).toBeInTheDocument();
    expect(screen.getByText('1/3')).toBeInTheDocument();
  });

  test('handles undefined values for all new variables', () => {
    const propsWithUndefinedValues = {
      selectedMtnDetails: {
        ...mockSelectedMtnDetails,
        totalPaidAmount: undefined,
        remainingBalance: undefined,
        agreementInfo: {
          ...mockSelectedMtnDetails.agreementInfo,
          loanAmount: undefined,
          loanMonthlyPaymentAmount: undefined
        }
      }
    };
    
    render(<RightPanel {...propsWithUndefinedValues} />);
    
    // Component should handle undefined values gracefully
    expect(screen.getByText('Paid principal')).toBeInTheDocument();
    expect(screen.getByText('Remaining balance')).toBeInTheDocument();
    expect(screen.getByText('Amount Financed')).toBeInTheDocument();
    expect(screen.getByText('Monthly amount')).toBeInTheDocument();
    
    // const { formatCurrency } = require('onevzsoemfecommon/Helpers/validation');
    // expect(formatCurrency).toHaveBeenCalledWith(undefined);
  });

  test('verifies direct value assignments without DevicePayment mapping', () => {
    // const { formatCurrency } = require('onevzsoemfecommon/Helpers/validation');
    // formatCurrency.mockClear(); // Clear previous calls to get accurate count
    
    render(<RightPanel {...defaultProps} />);
    
    expect(screen.getByText('Paid principal')).toBeInTheDocument(); // Label should always be present
    expect(screen.getByText('Monthly amount')).toBeInTheDocument(); // Label should always be present
    
    expect(screen.getByText('Device Payment Summary')).toBeInTheDocument();
  });

  test('tests component with minimal required data', () => {
    const minimalProps = {
      selectedMtnDetails: {
        nickName: 'Test User',
        modelName: 'Test Phone',
        mdn: '1234567890',
        defaultImage: 'test.jpg',
        deviceSku: 'TEST123',
        deviceId: '123456789',
        downPaymentAmount: 0,
        totalBuyoutAmount: 100,
        numberOfInstallmentsBilled: 10,
        pendingNumberOfInstallments: 5,
        totalPaidAmount: 500,
        remainingBalance: '100',
        agreementInfo: {
          loanNumber: '123',
          loanAmount: 600,
          loanMonthlyPaymentAmount: '20'
        },
        equipmentUpgradeEligibility: {
          edgeUpEligible: 'TRUE'
        }
      }
    };
    
    render(<RightPanel {...minimalProps} />);
    
    // Component should render with minimal data
    expect(screen.getByText('Test User')).toBeInTheDocument();
    expect(screen.getByText(/Test Phone/)).toBeInTheDocument();
  });

  test('verifies all styled components are rendered', () => {
    const { container } = render(<RightPanel {...defaultProps} />);
    
    // Check that all major styled components are rendered
    const allDivs = container.querySelectorAll('div');
    const allImages = container.querySelectorAll('img');
    
    expect(allDivs.length).toBeGreaterThan(10); // Many div containers
    expect(allImages.length).toBe(1); // One device image
    
    // Verify container structure
    expect(container.firstChild).toBeInTheDocument(); // Should have styled components
  });

  test('tests error handling for malformed data', () => {
    const malformedProps = {
      selectedMtnDetails: {
        ...mockSelectedMtnDetails,
        numberOfInstallmentsBilled: 'invalid',
        pendingNumberOfInstallments: 'invalid',
        totalPaidAmount: 'not-a-number',
        agreementInfo: {
          loanAmount: 'invalid',
          loanMonthlyPaymentAmount: 'invalid'
        }
      }
    };
    
    expect(() => render(<RightPanel {...malformedProps} />)).not.toThrow();
    expect(screen.getByText('Device Payment Summary')).toBeInTheDocument();
  });

  test('verifies complete prop structure coverage', () => {
   
    const completeProps = {
      selectedMtnDetails: {
        modelName: 'Complete Test Phone',
        mdn: '9876543210',
        nickName: 'COMPLETE USER',
        deviceId: '987654321',
        remainingBalance: '500.50',
        productName: 'COMPLETE TEST PHONE',
        deviceSku: 'COMPLETE123',
        defaultImage: 'complete.jpg',
        active: 'true',
        totalPaidAmount: 1000.75,
        pendingNumberOfInstallments: 12,
        numberOfInstallmentsBilled: 24,
        downPaymentAmount: 50.25,
        taxAmountUnpaid: '10.00',
        taxAmountUnbilled: '5.00',
        totalBuyoutAmount: 500.50,
        buyoutFlag: 'true',
        nextBuyoutDate: '2024-12-31',
        edgeUpPrincipalAmountUnpaid: '0.00',
        edgeUpOriginalCost: '1200.00',
        edgeUpRequiredPercent: '60.00',
        pastTradeInRestrictionTimePeriod: 'false',
        bgPromoActive: 'true',
        imei: '987654321',
        agreementInfo: {
          loanNumber: '987654321',
          loanMonthlyPaymentAmount: '45.67',
          loanAmount: 1200.00,
          loanType: 'F'
        },
        equipmentUpgradeEligibility: {
          edgeUpEligible: 'TRUE'
        }
      },
      DevicePayment: [] 
    };
    
    // Render the component with complete props
    render(<RightPanel {...completeProps} />);
    
    // Verify that the component renders with the complete prop data
    expect(screen.getByText('COMPLETE USER')).toBeInTheDocument();
    expect(screen.getByText(/Complete Test Phone/)).toBeInTheDocument();
    expect(screen.getByText('Device Payment Summary')).toBeInTheDocument();
  });
});