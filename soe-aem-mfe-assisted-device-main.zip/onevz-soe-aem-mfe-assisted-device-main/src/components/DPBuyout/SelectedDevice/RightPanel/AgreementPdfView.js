import React, { useEffect, useRef, useState } from 'react';
import PropTypes from 'prop-types';
import { isIpad} from 'onevzsoemfeframework/DomService';
import { GlobalWorkerOptions, getDocument } from 'pdfjs-dist';
import pdfjsWorker from 'pdfjs-dist/build/pdf.worker.entry';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import PrinterModal from './PrinterModal';

function AgreementPdfView(props) {
  const pdfCanvasRef = useRef(null);
  const [showIpadPrintModal,setShowIpadPrintModal] = useState(false)


  useEffect(() => {
    removeAllChildNodes();
    generateCanvasFromPDF();
  }, [props.src]);

  useEffect(() => {
    GlobalWorkerOptions.workerSrc = pdfjsWorker;
  }, []);

  
  const removeAllChildNodes = () => {
    const canvasContainer = pdfCanvasRef.current;
    /* istanbul ignore next */
    while (canvasContainer?.firstChild) {
      canvasContainer.removeChild(canvasContainer.firstChild);
    }
  };

  const generateCanvasFromPDF = () => {
    try {
      const { src } = props;
      const pdfData = src && typeof src === 'string' && atob(src);
      const loadingTask = pdfData ? getDocument({ data: pdfData }) : '';
      if (loadingTask) {
        loadingTask.promise.then(
          (pdfDoc) => {
            // setDoc(pdfDoc);
            // setPages(pdfDoc.numPages);

            for (let i = 1; i <= pdfDoc.numPages; i++) {
              pdfDoc.getPage(i)?.then((page) => {
                const viewport = page.getViewport({ scale: 1.65 });
                const canvasContainer = pdfCanvasRef.current;
                const canvas = document.createElement('canvas');
                canvas.id = 'canvas';
                canvas.setAttribute('data-testid', 'myCanvasTestId');
                const ctx = canvas.getContext('2d');
                canvas.height = viewport.height;
                canvas.width = viewport.width;
                /* istanbul ignore else */
                if (canvas && canvasContainer) canvasContainer.appendChild(canvas);
                const renderContext = {
                  canvasContext: ctx,
                  viewport,
                };
                const renderTask = page.render(renderContext);
                renderTask.promise.then(
                  () => {
                    console.log('Page rendered');
                  },
                  (error) => {
                    console.log('Error Rendering the PDF ', error);
                    props.onError();
                  },
                );
              });
            }
          },
          (reason) => {
            props.onError();
            console.error(`Error during ${props.src} loading: ${reason}`);
          },
        );
      } else {
        props.onError();
      }
    } catch (error) {
      console.error(`Fatal error while rendering pdf: ${error && error.message}`);
    }
  };
  const printIcon =
'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAABLCAYAAAA4TnrqAAAACXBIWXMAAC4jAAAuIwF4pT92AAABR0lEQVR4Ae3cQW7CMBBA0XHFvlfpDeDozQ24CieYColVoKr/MFVx9Z/EEiv5clBknIzMjIoxRu2LLyAzR+Uo3lY94b9gLMBYwKFxrEtEnH/9iLmPiHjvGKgz1jkzT43jtRhjfEbEsWMsL0PAWICxAGMBxgKMBRgLMBZgLMBYgLEAYwHGAowFGAswFmAswFiAsQBjAcYCjAUcVt6zUFU9Z2cWYCzAWICxgEextutmr58+L3tGEybPb9uP5MwCjAUYCzAWYCzAWICxAGMBnRtwj/99BcOZBRgLMBZgLKD8A7/6ykOFMwswFmAswFiAsQBjAcYCjAWUb0pvj9Muqfp48jNLNC3PHa/EyxAwFmAsoHNZefO9DjJWhbEAYwHGAowFGAswFnD9O2u/P2H2DWv7G72V3sx2t7l25nuPYukbXoaAsQBjzYqILwJpXI5XtV3RAAAAAElFTkSuQmCC';

            
  const handlePrint = () => {
            setShowIpadPrintModal(true)

    };
 
  

    const renderPrinter = () => {
         /* istanbul ignore else */
        if (showIpadPrintModal) return  <PrinterModal locationCode = {props.locationCode} showModal={showIpadPrintModal} closeModal={()=>setShowIpadPrintModal(false)} content={ [props?.src] } /> 
    };


  
  return (
    <div data-testid="PdfView_wrapper">
      <div className="Grid u-marginXNone u-colorBackgroundSecondary border-bottom-grey-light">
        <div className="Col Col--lg12 u-paddingAllLarge u-paddingTopSmall border-bottom-grey-light">
          <div className="u-flex u-flexAlignItemsEnd u-text-align">
            <div>
              <a aria-label="Back Button" role="button" onClick={props.closeModal} className="pointer u-colorPrimary">
                <span className="Icon Icon--left-caret font-30 u-alignMiddle u-paddingLeftSmall">
                  <span className="u-paddingXLarge font-42">|</span>
                </span>
              </a>
            </div>
            <div className="font-22 bold u-paddingLeftExtraSmall">{props.modalName}</div>
            {isIpad() && <div onClick={handlePrint} className="custom-icon" style={{width:'40px',position:'fixed',right:'10px'}} role="button" aria-label="Print Agreement">
                                <img src={printIcon} alt="" /> 
                            </div>}
          </div>
        </div>
      </div>
      
      {renderPrinter()}
      {isIpad()  && <div className="Grid Grid--gapless u-marginXNone">
        <div ref={pdfCanvasRef} className="pdfFrameIpad" />
        
      </div>}
      {!isIpad() && <div className="Grid Grid--gapless u-marginXNone">
        <object
          data={`data:application/pdf;base64,${encodeURI(props?.src)}`}
          title="Agreement"
          className="modal-height pdfFrame"
          type="application/pdf"
        /></div>}
    </div>
  );
}

AgreementPdfView.propTypes = {
  src: PropTypes.any,
  onError: PropTypes.func,
  onScroll: PropTypes.func,
  
};

export default AgreementPdfView;
