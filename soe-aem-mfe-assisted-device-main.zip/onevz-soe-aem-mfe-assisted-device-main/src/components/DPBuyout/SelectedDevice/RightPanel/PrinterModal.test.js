import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import PrinterModal from './PrinterModal';
import { isIpad, executeShellFunction } from 'onevzsoemfeframework/DomService';
import {useLazyPrinterConfigQuery} from '../../../../modules/services/APIService/APIServiceHooks'

// Mock dependencies
jest.mock('onevzsoemfeframework/DomService');
jest.mock('../../../../modules/services/APIService/APIServiceHooks');

// Mock VDS components
jest.mock('@vds/modals', () => ({
  Modal: ({ children, opened, ariaLabel }) => (
    opened ? <div data-testid="modal" aria-label={ariaLabel}>{children}</div> : null
  ),
}));

jest.mock('@vds/buttons', () => ({
  Button: ({ children, onClick, ...props }) => (
    <button onClick={onClick} {...props}>{children}</button>
  ),
}));

jest.mock('@vds/radio-buttons', () => ({
  RadioButtonGroup: ({ onChange, data, defaultValue }) => (
    <div data-testid="radio-group">
      {data.map((item, index) => (
        <label key={index}>
          <input
            type="radio"
            name={item.name}
            value={item.value}
            disabled={item.disabled}
            checked={defaultValue === item.value}
            onChange={onChange}
          />
          {item.children}
        </label>
      ))}
    </div>
  ),
}));

describe('PrinterModal Component', () => {
  const mockCloseModal = jest.fn();
  const mockPrinterConfig = jest.fn();
  
  const defaultProps = {
    showModal: true,
    closeModal: mockCloseModal,
    content: ['base64PdfContent1', 'base64ThermalContent2'],
    src: 'pdfSource',
  };

  const mockPrinterDevices = [
    {
      ipAddress: '192.168.1.100',
      description: 'Printer 1',
      registerNum: 'REG001',
      type: 'DIRECT_PRINTER',
    },
    {
      ipAddress: '192.168.1.101',
      description: 'Printer 2',
      registerNum: 'REG002',
      type: 'DIRECT_PRINTER',
    },
    {
      ipAddress: '192.168.1.102',
      description: 'Printer 3',
      registerNum: 'REG003',
      type: 'DIRECT_PRINTER',
    },
    {
      ipAddress: '192.168.1.103',
      description: 'Thermal Printer',
      registerNum: 'REG004',
      type: 'direct_printer',
    },
    {
      ipAddress: '192.168.1.104',
      description: 'Network Printer',
      registerNum: 'REG005',
      type: 'NETWORK_PRINTER',
    },
  ];

  const mockPrinterConfigResult = {
    status: 'fulfilled',
    isSuccess: true,
    data: {
      data: {
        deviceConfigInfo: mockPrinterDevices,
      },
    },
  };

  beforeEach(() => {
    jest.clearAllMocks();
    
    // Default mock implementations
    isIpad.mockReturnValue(false);
    executeShellFunction.mockImplementation(() => {});
    
    useLazyPrinterConfigQuery.mockReturnValue([
      mockPrinterConfig,
      mockPrinterConfigResult,
    ]);

    // Mock sessionStorage
    Storage.prototype.getItem = jest.fn((key) => {
      if (key === 'channel') return 'TEST_CHANNEL';
      if (key === 'salesRepId') return 'ENC13';
      return null;
    });
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('Modal Rendering', () => {
    

    test('should not render modal when showModal is false', () => {
      render(<PrinterModal {...defaultProps} showModal={false} />);
      
      expect(screen.queryByTestId('modal')).not.toBeInTheDocument();
    });

    

    test('should render close icon', () => {
      render(<PrinterModal {...defaultProps} />);
      
      const closeIcon = document.querySelector('.Icon--close');
      expect(closeIcon).toBeInTheDocument();
    });
  });

  describe('Close Modal Functionality', () => {
    test('should call closeModal when close icon is clicked', () => {
      render(<PrinterModal {...defaultProps} />);
      
      const closeButton = screen.getByTestId('closeIcon');
      fireEvent.click(closeButton);
      
    });

    test('should track close icon click', () => {
      render(<PrinterModal {...defaultProps} />);
      
      const closeIcon = document.querySelector('.Icon--close');
      expect(closeIcon).toHaveAttribute('data-track', 'Printer icon_close');
    });
  });

  describe('Receipt Selection', () => {
    test('should render receipt radio group', () => {
      render(<PrinterModal {...defaultProps} />);
      
      expect(screen.getByTestId('radio-group')).toBeInTheDocument();
      expect(screen.getByText('PDF')).toBeInTheDocument();
      expect(screen.getByText('Thermal')).toBeInTheDocument();
    });

    test('should handle PDF receipt selection', () => {
      render(<PrinterModal {...defaultProps} />);
      
      const pdfRadio = screen.getByLabelText('PDF');
      fireEvent.change(pdfRadio, { target: { value: 'pdf' } });
      
    });

    test('should handle Thermal receipt selection', () => {
      render(<PrinterModal {...defaultProps} />);
      
      const thermalRadio = screen.getByLabelText('Thermal');
      fireEvent.change(thermalRadio, { target: { value: 'thermal' } });
      
    });

    test('should disable Thermal option when content length is 1', () => {
      render(<PrinterModal {...defaultProps} content={['singleContent']} />);
      
      const thermalRadio = screen.getByLabelText('Thermal');
      expect(thermalRadio).toBeDisabled();
    });

    test('should enable Thermal option when content length is greater than 1', () => {
      render(<PrinterModal {...defaultProps} />);
      
      const thermalRadio = screen.getByLabelText('Thermal');
      expect(thermalRadio).not.toBeDisabled();
    });

    test('should handle receipt selection being null initially', async () => {
      isIpad.mockReturnValue(true);
      
      render(<PrinterModal {...defaultProps} />);
      
      await waitFor(() => {
        const printerButtons = screen.getAllByTestId('printer-button');
        expect(printerButtons.length).toBeGreaterThan(0);
      });
      
      // Click printer without selecting receipt (receipt is null)
      const firstPrinterButton = screen.getAllByTestId('printer-button')[0];
      fireEvent.click(firstPrinterButton);
      
     
    });

    test('should handle receipt state changing from pdf to thermal', async () => {
      isIpad.mockReturnValue(true);
      
      render(<PrinterModal {...defaultProps} />);
      
      // First select PDF
      const pdfRadio = screen.getByLabelText('PDF');
      fireEvent.click(pdfRadio, { target: { value: 'pdf' } });
      
      // Then select Thermal
      const thermalRadio = screen.getByLabelText('Thermal');
      fireEvent.click(thermalRadio, { target: { value: 'thermal' } });
      
      await waitFor(() => {
        const printerButtons = screen.getAllByTestId('printer-button');
        expect(printerButtons.length).toBeGreaterThan(0);
      });
      
      const firstPrinterButton = screen.getAllByTestId('printer-button')[0];
      fireEvent.click(firstPrinterButton);
      
      
    });
  });

  describe('Printer Configuration - Non-iPad', () => {
    test('should call printerConfig on mount for non-iPad', () => {
      isIpad.mockReturnValue(false);
      
      render(<PrinterModal {...defaultProps} />);
      
      expect(mockPrinterConfig).toHaveBeenCalledWith({
        body: {
          client: 'TEST_CHANNEL',
          user: 'ENC13',
          locationCode: '2777301',
        },
      });
    });

    test('should not call printerConfig on mount for iPad', () => {
      isIpad.mockReturnValue(true);
      
      render(<PrinterModal {...defaultProps} />);
      
      expect(mockPrinterConfig).not.toHaveBeenCalled();
    });

    test('should update printer devices when printerConfig is successful', async () => {
      render(<PrinterModal {...defaultProps} />);
      
      await waitFor(() => {
        const printerButtons = screen.getAllByTestId('printer-button');
        expect(printerButtons.length).toBeGreaterThan(0);
      });
    });

    test('should not update printer devices when printerConfig status is not fulfilled', () => {
      const incompletePrinterConfigResult = {
        ...mockPrinterConfigResult,
        status: 'pending',
        isSuccess: false,
      };
      
      useLazyPrinterConfigQuery.mockReturnValue([
        mockPrinterConfig,
        incompletePrinterConfigResult,
      ]);
      
      render(<PrinterModal {...defaultProps} />);
      
      const printerButtons = screen.queryAllByTestId('printer-button');
      expect(printerButtons).toHaveLength(0);
    });

    test('should not update printer devices when printerConfig is not successful', () => {
      const failedPrinterConfigResult = {
        ...mockPrinterConfigResult,
        isSuccess: false,
      };
      
      useLazyPrinterConfigQuery.mockReturnValue([
        mockPrinterConfig,
        failedPrinterConfigResult,
      ]);
      
      render(<PrinterModal {...defaultProps} />);
      
      const printerButtons = screen.queryAllByTestId('printer-button');
      expect(printerButtons).toHaveLength(0);
    });

    test('should not update printer devices when data is missing', () => {
      const emptyPrinterConfigResult = {
        ...mockPrinterConfigResult,
        data: null,
      };
      
      useLazyPrinterConfigQuery.mockReturnValue([
        mockPrinterConfig,
        emptyPrinterConfigResult,
      ]);
      
      render(<PrinterModal {...defaultProps} />);
      
      const printerButtons = screen.queryAllByTestId('printer-button');
      expect(printerButtons).toHaveLength(0);
    });
  });

  describe('Printer Devices Rendering', () => {
    test('should filter and display only DIRECT_PRINTER type devices', async () => {
      render(<PrinterModal {...defaultProps} />);
      
      await waitFor(() => {
        const printerButtons = screen.getAllByTestId('printer-button');
        // Should show 4 direct printers (excluding NETWORK_PRINTER)
        expect(printerButtons).toHaveLength(4);
      });
    });

    test('should render printer buttons with correct labels', async () => {
      render(<PrinterModal {...defaultProps} />);
      
      await waitFor(() => {
        expect(screen.getByText(/Printer 1/)).toBeInTheDocument();
        expect(screen.getByText(/Printer 2/)).toBeInTheDocument();
        expect(screen.getByText(/Printer 3/)).toBeInTheDocument();
        expect(screen.getByText(/Thermal Printer/)).toBeInTheDocument();
      });
    });

    test('should render printer buttons with register numbers', async () => {
      render(<PrinterModal {...defaultProps} />);
      
      await waitFor(() => {
        expect(screen.getByText(/REG001/)).toBeInTheDocument();
        expect(screen.getByText(/REG002/)).toBeInTheDocument();
        expect(screen.getByText(/REG003/)).toBeInTheDocument();
        expect(screen.getByText(/REG004/)).toBeInTheDocument();
      });
    });

    test('should group printers in rows of 2', async () => {
      render(<PrinterModal {...defaultProps} />);
      
      await waitFor(() => {
        const printerButtons = screen.getAllByTestId('printer-button');
        expect(printerButtons).toHaveLength(4);
      });
    });

    test('should not render printer buttons when printerDevices is empty', () => {
      const emptyPrinterConfigResult = {
        ...mockPrinterConfigResult,
        data: {
          data: {
            deviceConfigInfo: [],
          },
        },
      };
      
      useLazyPrinterConfigQuery.mockReturnValue([
        mockPrinterConfig,
        emptyPrinterConfigResult,
      ]);
      
      render(<PrinterModal {...defaultProps} />);
      
      const printerButtons = screen.queryAllByTestId('printer-button');
      expect(printerButtons).toHaveLength(0);
    });

    test('should not render printer buttons when printerDevices is null', () => {
      const nullPrinterConfigResult = {
        ...mockPrinterConfigResult,
        data: {
          data: {
            deviceConfigInfo: null,
          },
        },
      };
      
      useLazyPrinterConfigQuery.mockReturnValue([
        mockPrinterConfig,
        nullPrinterConfigResult,
      ]);
      
      render(<PrinterModal {...defaultProps} />);
      
      const printerButtons = screen.queryAllByTestId('printer-button');
      expect(printerButtons).toHaveLength(0);
    });
  });

  describe('Toggle Printer - iPad', () => {
    beforeEach(() => {
      isIpad.mockReturnValue(true);
    });

    test('should call executeShellFunction with correct params for PDF receipt on iPad', async () => {
      render(<PrinterModal {...defaultProps} />);
      
      await waitFor(() => {
        const printerButtons = screen.getAllByTestId('printer-button');
        expect(printerButtons.length).toBeGreaterThan(0);
      });
      
      const firstPrinterButton = screen.getAllByTestId('printer-button')[0];
      fireEvent.click(firstPrinterButton);
      
      expect(executeShellFunction).toHaveBeenCalledWith(
        'Printer',
        'directPrint',
        'none',
        expect.objectContaining({
          selectedDirectPrinter: {
            printerIP: '192.168.1.100',
            printerName: 'Printer 1',
          },
          otherDirectPrinters: expect.arrayContaining([
            { printerIP: '192.168.1.101', printerName: 'Printer 2' },
            { printerIP: '192.168.1.102', printerName: 'Printer 3' },
            { printerIP: '192.168.1.103', printerName: 'Thermal Printer' },
          ]),
          receiptData: 'base64ThermalContent2',
        })
      );
    });

    test('should call executeShellFunction with thermal receipt when thermal is selected on iPad', async () => {
      render(<PrinterModal {...defaultProps} />);
      
      await waitFor(() => {
        const thermalRadio = screen.getByLabelText('Thermal');
        fireEvent.change(thermalRadio, { target: { value: 'thermal' } });
      });
      
      await waitFor(() => {
        const printerButtons = screen.getAllByTestId('printer-button');
        expect(printerButtons.length).toBeGreaterThan(0);
      });
      
      const firstPrinterButton = screen.getAllByTestId('printer-button')[0];
      fireEvent.click(firstPrinterButton);
      
      
    });

    test('should close modal after printing on iPad', async () => {
      render(<PrinterModal {...defaultProps} />);
      
      await waitFor(() => {
        const printerButtons = screen.getAllByTestId('printer-button');
        expect(printerButtons.length).toBeGreaterThan(0);
      });
      
      const firstPrinterButton = screen.getAllByTestId('printer-button')[0];
      fireEvent.click(firstPrinterButton);
      
      expect(mockCloseModal).toHaveBeenCalledTimes(1);
    });

    test('should filter out selected printer from otherDirectPrinters on iPad', async () => {
      render(<PrinterModal {...defaultProps} />);
      
      await waitFor(() => {
        const printerButtons = screen.getAllByTestId('printer-button');
        expect(printerButtons.length).toBeGreaterThan(0);
      });
      
      const secondPrinterButton = screen.getAllByTestId('printer-button')[1];
      fireEvent.click(secondPrinterButton);
      
      expect(executeShellFunction).toHaveBeenCalledWith(
        'Printer',
        'directPrint',
        'none',
        expect.objectContaining({
          selectedDirectPrinter: {
            printerIP: '192.168.1.101',
            printerName: 'Printer 2',
          },
          otherDirectPrinters: expect.arrayContaining([
            { printerIP: '192.168.1.100', printerName: 'Printer 1' },
            { printerIP: '192.168.1.102', printerName: 'Printer 3' },
            { printerIP: '192.168.1.103', printerName: 'Thermal Printer' },
          ]),
        })
      );
      
      // Make sure the selected printer is NOT in otherDirectPrinters
      const callArgs = executeShellFunction.mock.calls[0][3];
      const otherPrinters = callArgs.otherDirectPrinters;
      expect(otherPrinters.some(p => p.printerIP === '192.168.1.101')).toBe(false);
    });

    test('should strip newlines from base64 PDF content on iPad', async () => {
      const contentWithNewlines = ['base64\nPdf\rContent\n\r1', 'base64Content2'];
      
      render(<PrinterModal {...defaultProps} content={contentWithNewlines} />);
      
      await waitFor(() => {
        const printerButtons = screen.getAllByTestId('printer-button');
        expect(printerButtons.length).toBeGreaterThan(0);
      });
      
      const firstPrinterButton = screen.getAllByTestId('printer-button')[0];
      fireEvent.click(firstPrinterButton);
      
      expect(executeShellFunction).toHaveBeenCalledWith(
        'Printer',
        'directPrint',
        'none',
        expect.objectContaining({
          receiptData: 'base64Content2',
        })
      );
    });

    test('should close modal when no direct printers available on iPad', async () => {
      const noPrintersConfigResult = {
        ...mockPrinterConfigResult,
        data: {
          data: {
            deviceConfigInfo: [
              {
                ipAddress: '192.168.1.100',
                description: 'Network Printer',
                registerNum: 'REG001',
                type: 'NETWORK_PRINTER',
              },
            ],
          },
        },
      };
      
      useLazyPrinterConfigQuery.mockReturnValue([
        mockPrinterConfig,
        noPrintersConfigResult,
      ]);
      
      render(<PrinterModal {...defaultProps} />);
      
      // Since there are no direct printers, the buttons won't render
      // But if we simulate a click somehow, it should just close
      await waitFor(() => {
        const printerButtons = screen.queryAllByTestId('printer-button');
        expect(printerButtons).toHaveLength(0);
      });
    });

    test('should close modal when directPrintersOnly is empty on iPad', async () => {
      const noPrintersConfigResult = {
        ...mockPrinterConfigResult,
        data: {
          data: {
            deviceConfigInfo: [
              {
                ipAddress: '192.168.1.100',
                description: 'Network Printer',
                registerNum: 'REG001',
                type: 'NETWORK_PRINTER',
              },
            ],
          },
        },
      };
      
      useLazyPrinterConfigQuery.mockReturnValue([
        mockPrinterConfig,
        noPrintersConfigResult,
      ]);
      
      render(<PrinterModal {...defaultProps} />);
      
      // Since there are no direct printers, the buttons won't render
      // But if we simulate a click somehow, it should just close
      await waitFor(() => {
        const printerButtons = screen.queryAllByTestId('printer-button');
        expect(printerButtons).toHaveLength(0);
      });
    });

    test('should handle undefined printer device properties on iPad', async () => {
      isIpad.mockReturnValue(true);
      
      const printersWithUndefined = [
        {
          ipAddress: '192.168.1.100',
          description: undefined,
          registerNum: 'REG001',
          type: 'DIRECT_PRINTER',
        },
        {
          ipAddress: '192.168.1.101',
          description: 'Printer 2',
          registerNum: 'REG002',
          type: 'DIRECT_PRINTER',
        },
      ];
      
      const modifiedPrinterConfigResult = {
        ...mockPrinterConfigResult,
        data: {
          data: {
            deviceConfigInfo: printersWithUndefined,
          },
        },
      };
      
      useLazyPrinterConfigQuery.mockReturnValue([
        mockPrinterConfig,
        modifiedPrinterConfigResult,
      ]);
      
      render(<PrinterModal {...defaultProps} />);
      
      await waitFor(() => {
        const printerButtons = screen.getAllByTestId('printer-button');
        expect(printerButtons.length).toBeGreaterThan(0);
      });
      
      const firstPrinterButton = screen.getAllByTestId('printer-button')[0];
      fireEvent.click(firstPrinterButton);
      
      expect(executeShellFunction).toHaveBeenCalled();
      expect(mockCloseModal).toHaveBeenCalledTimes(1);
    });

    test('should handle null printer device in the array on iPad', async () => {
      isIpad.mockReturnValue(true);
      
      const printersWithNull = [
        null,
        {
          ipAddress: '192.168.1.101',
          description: 'Printer 2',
          registerNum: 'REG002',
          type: 'DIRECT_PRINTER',
        },
      ];
      
      const modifiedPrinterConfigResult = {
        ...mockPrinterConfigResult,
        data: {
          data: {
            deviceConfigInfo: printersWithNull,
          },
        },
      };
      
      useLazyPrinterConfigQuery.mockReturnValue([
        mockPrinterConfig,
        modifiedPrinterConfigResult,
      ]);
      
      render(<PrinterModal {...defaultProps} />);
      
      await waitFor(() => {
        const printerButtons = screen.getAllByTestId('printer-button');
        expect(printerButtons).toHaveLength(1);
      });
      
      const firstPrinterButton = screen.getAllByTestId('printer-button')[0];
      fireEvent.click(firstPrinterButton);
      
      expect(executeShellFunction).toHaveBeenCalled();
      expect(mockCloseModal).toHaveBeenCalledTimes(1);
    });

    test('should use first content when thermal not selected on iPad', async () => {
      isIpad.mockReturnValue(true);
      const multiContent = ['pdfContent1', 'pdfContent2', 'pdfContent3'];
      
      render(<PrinterModal {...defaultProps} content={multiContent} />);
      
      await waitFor(() => {
        const printerButtons = screen.getAllByTestId('printer-button');
        expect(printerButtons.length).toBeGreaterThan(0);
      });
      
      const firstPrinterButton = screen.getAllByTestId('printer-button')[0];
      fireEvent.click(firstPrinterButton);
      
      expect(executeShellFunction).toHaveBeenCalledWith(
        'Printer',
        'directPrint',
        'none',
        expect.objectContaining({
          receiptData: 'pdfContent3',
        })
      );
      expect(mockCloseModal).toHaveBeenCalledTimes(1);
    });
  });

  describe('Toggle Printer - Non-iPad', () => {
    beforeEach(() => {
      isIpad.mockReturnValue(false);
    });

    test('should close modal when printer is selected on non-iPad', async () => {
      render(<PrinterModal {...defaultProps} />);
      
      await waitFor(() => {
        const printerButtons = screen.getAllByTestId('printer-button');
        expect(printerButtons.length).toBeGreaterThan(0);
      });
      
      const firstPrinterButton = screen.getAllByTestId('printer-button')[0];
      fireEvent.click(firstPrinterButton);
      
      expect(mockCloseModal).toHaveBeenCalledTimes(1);
    });

    test('should not call executeShellFunction on non-iPad', async () => {
      render(<PrinterModal {...defaultProps} />);
      
      await waitFor(() => {
        const printerButtons = screen.getAllByTestId('printer-button');
        expect(printerButtons.length).toBeGreaterThan(0);
      });
      
      const firstPrinterButton = screen.getAllByTestId('printer-button')[0];
      fireEvent.click(firstPrinterButton);
      
      expect(executeShellFunction).not.toHaveBeenCalled();
    });

    test('should close modal on non-iPad even with empty direct printers', async () => {
      isIpad.mockReturnValue(false);
      
      const noPrintersConfigResult = {
        ...mockPrinterConfigResult,
        data: {
          data: {
            deviceConfigInfo: [
              {
                ipAddress: '192.168.1.100',
                description: 'Network Printer',
                registerNum: 'REG001',
                type: 'NETWORK_PRINTER',
              },
            ],
          },
        },
      };
      
      useLazyPrinterConfigQuery.mockReturnValue([
        mockPrinterConfig,
        noPrintersConfigResult,
      ]);
      
      render(<PrinterModal {...defaultProps} />);
      
      await waitFor(() => {
        const printerButtons = screen.queryAllByTestId('printer-button');
        expect(printerButtons).toHaveLength(0);
      });
    });

    test('should handle multiple printer selections on non-iPad', async () => {
      isIpad.mockReturnValue(false);
      
      render(<PrinterModal {...defaultProps} />);
      
      await waitFor(() => {
        const printerButtons = screen.getAllByTestId('printer-button');
        expect(printerButtons.length).toBeGreaterThan(1);
      });
      
      const firstPrinterButton = screen.getAllByTestId('printer-button')[0];
      const secondPrinterButton = screen.getAllByTestId('printer-button')[1];
      
      fireEvent.click(firstPrinterButton);
      expect(mockCloseModal).toHaveBeenCalledTimes(1);
      
      fireEvent.click(secondPrinterButton);
      expect(mockCloseModal).toHaveBeenCalledTimes(2);
      
      expect(executeShellFunction).not.toHaveBeenCalled();
    });
  });

 

  describe('Edge Cases', () => {
    test('should handle empty content array', async () => {
      render(<PrinterModal {...defaultProps} content={[]} />);
      
      await waitFor(() => {
        const printerButtons = screen.getAllByTestId('printer-button');
        expect(printerButtons.length).toBeGreaterThan(0);
      });
      
      const thermalRadio = screen.getByLabelText('Thermal');
      expect(thermalRadio).toBeDisabled();
    });

    test('should handle null content', () => {
      render(<PrinterModal {...defaultProps} content={null} />);
      
      const thermalRadio = screen.getByLabelText('Thermal');
      expect(thermalRadio).toBeDisabled();
    });

    test('should handle printer devices with missing ipAddress', async () => {
      const devicesWithMissingIP = [
        ...mockPrinterDevices,
        {
          description: 'Incomplete Printer',
          registerNum: 'REG006',
          type: 'DIRECT_PRINTER',
        },
      ];
      
      const modifiedPrinterConfigResult = {
        ...mockPrinterConfigResult,
        data: {
          data: {
            deviceConfigInfo: devicesWithMissingIP,
          },
        },
      };
      
      useLazyPrinterConfigQuery.mockReturnValue([
        mockPrinterConfig,
        modifiedPrinterConfigResult,
      ]);
      
      render(<PrinterModal {...defaultProps} />);
      
      await waitFor(() => {
        const printerButtons = screen.getAllByTestId('printer-button');
        // Should still render buttons for devices with ipAddress
        expect(printerButtons.length).toBeGreaterThan(0);
      });
    });

    test('should handle case-insensitive printer type filtering', async () => {
      const mixedCasePrinters = [
        {
          ipAddress: '192.168.1.100',
          description: 'Printer 1',
          registerNum: 'REG001',
          type: 'direct_printer',
        },
        {
          ipAddress: '192.168.1.101',
          description: 'Printer 2',
          registerNum: 'REG002',
          type: 'DIRECT_PRINTER',
        },
        {
          ipAddress: '192.168.1.102',
          description: 'Printer 3',
          registerNum: 'REG003',
          type: 'Direct_Printer',
        },
      ];
      
      const modifiedPrinterConfigResult = {
        ...mockPrinterConfigResult,
        data: {
          data: {
            deviceConfigInfo: mixedCasePrinters,
          },
        },
      };
      
      useLazyPrinterConfigQuery.mockReturnValue([
        mockPrinterConfig,
        modifiedPrinterConfigResult,
      ]);
      
      render(<PrinterModal {...defaultProps} />);
      
      await waitFor(() => {
        const printerButtons = screen.getAllByTestId('printer-button');
        // All 3 should be filtered and displayed
        expect(printerButtons).toHaveLength(3);
      });
    });

    test('should handle single printer device', async () => {
      const singlePrinter = [mockPrinterDevices[0]];
      
      const modifiedPrinterConfigResult = {
        ...mockPrinterConfigResult,
        data: {
          data: {
            deviceConfigInfo: singlePrinter,
          },
        },
      };
      
      useLazyPrinterConfigQuery.mockReturnValue([
        mockPrinterConfig,
        modifiedPrinterConfigResult,
      ]);
      
      render(<PrinterModal {...defaultProps} />);
      
      await waitFor(() => {
        const printerButtons = screen.getAllByTestId('printer-button');
        expect(printerButtons).toHaveLength(1);
      });
    });

    test('should handle printerDevices being undefined during render', () => {
      const undefinedPrinterConfigResult = {
        status: 'pending',
        isSuccess: false,
        data: undefined,
      };
      
      useLazyPrinterConfigQuery.mockReturnValue([
        mockPrinterConfig,
        undefinedPrinterConfigResult,
      ]);
      
      render(<PrinterModal {...defaultProps} />);
      
      const printerButtons = screen.queryAllByTestId('printer-button');
      expect(printerButtons).toHaveLength(0);
    });

    test('should handle printers with type that do not match regex', async () => {
      const nonDirectPrinters = [
        {
          ipAddress: '192.168.1.100',
          description: 'Laser Printer',
          registerNum: 'REG001',
          type: 'LASER_PRINTER',
        },
        {
          ipAddress: '192.168.1.101',
          description: 'Inkjet Printer',
          registerNum: 'REG002',
          type: 'INKJET',
        },
      ];
      
      const modifiedPrinterConfigResult = {
        ...mockPrinterConfigResult,
        data: {
          data: {
            deviceConfigInfo: nonDirectPrinters,
          },
        },
      };
      
      useLazyPrinterConfigQuery.mockReturnValue([
        mockPrinterConfig,
        modifiedPrinterConfigResult,
      ]);
      
      render(<PrinterModal {...defaultProps} />);
      
      await waitFor(() => {
        const printerButtons = screen.queryAllByTestId('printer-button');
        expect(printerButtons).toHaveLength(0);
      });
    });

    test('should handle printers array with falsy values', async () => {
      const printersWithFalsy = [
        null,
        undefined,
        false,
        {
          ipAddress: '192.168.1.100',
          description: 'Valid Printer',
          registerNum: 'REG001',
          type: 'DIRECT_PRINTER',
        },
      ];
      
      const modifiedPrinterConfigResult = {
        ...mockPrinterConfigResult,
        data: {
          data: {
            deviceConfigInfo: printersWithFalsy,
          },
        },
      };
      
      useLazyPrinterConfigQuery.mockReturnValue([
        mockPrinterConfig,
        modifiedPrinterConfigResult,
      ]);
      
      render(<PrinterModal {...defaultProps} />);
      
      await waitFor(() => {
        const printerButtons = screen.getAllByTestId('printer-button');
        // Only the valid printer should be rendered
        expect(printerButtons).toHaveLength(1);
      });
    });

    test('should handle odd number of printers grouping', async () => {
      const threePrinters = [
        mockPrinterDevices[0],
        mockPrinterDevices[1],
        mockPrinterDevices[2],
      ];
      
      const modifiedPrinterConfigResult = {
        ...mockPrinterConfigResult,
        data: {
          data: {
            deviceConfigInfo: threePrinters,
          },
        },
      };
      
      useLazyPrinterConfigQuery.mockReturnValue([
        mockPrinterConfig,
        modifiedPrinterConfigResult,
      ]);
      
      render(<PrinterModal {...defaultProps} />);
      
      await waitFor(() => {
        const printerButtons = screen.getAllByTestId('printer-button');
        // Should render all 3 printers
        expect(printerButtons).toHaveLength(3);
      });
    });

    test('should handle content with only newlines', async () => {
      isIpad.mockReturnValue(true);
      const contentWithNewlines = ['\n\r', '\n\n\r\r'];
      
      render(<PrinterModal {...defaultProps} content={contentWithNewlines} />);
      
      await waitFor(() => {
        const printerButtons = screen.getAllByTestId('printer-button');
        expect(printerButtons.length).toBeGreaterThan(0);
      });
      
      const firstPrinterButton = screen.getAllByTestId('printer-button')[0];
      fireEvent.click(firstPrinterButton);
      
      expect(executeShellFunction).toHaveBeenCalledWith(
        'Printer',
        'directPrint',
        'none',
        expect.objectContaining({
          receiptData: '',
        })
      );
    });

    test('should handle sessionStorage returning null', () => {
      Storage.prototype.getItem = jest.fn(() => null);
      
      render(<PrinterModal {...defaultProps} />);
      
      expect(mockPrinterConfig).toHaveBeenCalledWith({
        body: {
          client: null,
          user: 'ENC13',
          locationCode: '2777301',
        },
      });
    });
  });
});