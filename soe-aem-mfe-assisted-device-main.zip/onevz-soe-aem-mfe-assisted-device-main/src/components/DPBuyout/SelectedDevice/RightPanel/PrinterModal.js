import React, { useEffect,  useState } from 'react';
import styled from 'styled-components';
 import './PrinterModal.css'
import PropTypes from 'prop-types'; import {Modal} from '@vds/modals';
import { Button } from '@vds/buttons';
import { RadioButtonGroup } from '@vds/radio-buttons';
import { isEmpty } from 'lodash';
import { isIpad,executeShellFunction } from 'onevzsoemfeframework/DomService';
import { useLazyPrinterConfigQuery } from '../../../../modules/services/APIService/APIServiceHooks';

const TitleWrap = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 10px;
  margin-left: 10px;
  margin-right: 10px;
`;

function PrinterModal (props){

    const [receipt,setReceipt] = useState(null)
    const [printerDevices,setPrinterDevices] = useState(null)
    // const [retrievePosDevices,retrievePosDevicesResult] = useLazyRetrievePosDevicesQuery()
    const [printerConfig,printerConfigResult] = useLazyPrinterConfigQuery();

    useEffect(()=>{
        if(isIpad()){
           // retrievePosDevices({body:{}})
        const request = {
            client: sessionStorage.getItem("channel"),
            user: sessionStorage.getItem("salesRepId"),
            locationCode:props.locationCode
    };
           printerConfig({body:request})
        }
    },[])
    
    // useEffect(()=>{
    //     if(retrievePosDevicesResult?.isSuccess && retrievePosDevicesResult.data){
    //         setPrinterDevices(retrievePosDevicesResult?.data?.getLocationByLocationCode?.devices)
    //     }
    // },[retrievePosDevicesResult])

    useEffect(()=>{
        if(printerConfigResult?.status === 'fulfilled' && printerConfigResult.isSuccess && printerConfigResult.data){
            setPrinterDevices(printerConfigResult?.data?.data?.deviceConfigInfo)
        }
    },[printerConfigResult])

    const handleReceiptSelection = (e)=>{
    
        setReceipt(e.target.value)
    }
    const togglePrinter = ({ ipAddress: printerIP, description: printerName }) => {
        //For Ipad
        const { content} = props;
        
        // Always filter printers to 'DIRECT_TYPE' only
        const directPrintersOnly = printerDevices?.filter((printer) => printer && /direct_printer/i.test(printer?.type));
        if (isIpad() && !isEmpty(directPrintersOnly)) {
            const otherDirectPrinters = directPrintersOnly?.filter(({ ipAddress }) => ipAddress !== printerIP).map(({ ipAddress: printerIP, description: printerName }) => ({ printerIP, printerName }));
            // END bulk command
            // Print just the last 'content' PDF (hopefully not thermals)
            let byte64Printable = content?.slice(-1)[0];
            if (receipt === 'thermal') {
                byte64Printable = content[0];
            }
            const shellParams = {
                selectedDirectPrinter: {
                    printerIP,
                    printerName,
                },
                otherDirectPrinters,
                receiptData: byte64Printable?.replace(/[\n\r]/g, ''), // quick fix for base64 pdf format
            };
            executeShellFunction('Printer', 'directPrint', 'none', shellParams);


            props?.closeModal();
        } else {
            props?.closeModal();
        }
    };

     const size = 2;
   
        const {  content } = props;
        // const printerDevices = retrievePosDevicesResult?.getLocationByLocationCode?.devices;
        const printerFilteredDevices = printerDevices?.filter((printer) => printer && /direct_printer/i.test(printer?.type));
        const printerGroup = printerFilteredDevices?.map((printer, index) => (index % size === 0 ? printerFilteredDevices?.slice(index, index + size) : null)).filter((printer) => printer);
        console.log("printGrp",printerGroup)
        return (
            //<h2>here</h2>)
            
             <Modal ariaLabel="Print Receipt"  
              opened={props?.showModal} fullScreenDialog
               closeButton={<div />}
               >
                <div className='dpBuyoutPrinter'>
                <TitleWrap>
                <h2 style={{ 'font-size': '1.5rem' }}>Select a printer/receipt</h2>
                 <a  data-testid={'closeIcon'} onClick={props?.closeModal} className="float-right u-colorPrimary pointer u-paddingYMedium"><span className="Icon Icon--close font-30" data-track="Printer icon_close"/></a>
                </TitleWrap>
                    <div className="receipt-select-wrapper">
                        <h2 className="u-textBold header">Receipt</h2>
                        <div className="receipt-select-content">
                            <RadioButtonGroup
                                onChange={handleReceiptSelection}
                                defaultValue={receipt}
                                data={[
                                    {
                                        name: 'pdf-select',
                                        children: 'PDF',
                                        value: 'pdf',
                                    },
                                    {
                                        name: 'pdf-select',
                                        children: 'Thermal',
                                        value: 'thermal',
                                        disabled: content?.length > 1 ? false : true,
                                    },
                                ]}
                            />
                        </div>
                    </div>
                    <h2 className="u-textBold header">Printer</h2>
                    <div className="printcontent">
                        {!isEmpty(printerGroup) &&
                            printerGroup?.map((printerRow, key) => (
                                <>
                                    {!isEmpty(printerRow) &&
                                        printerRow?.map((device, index) => (
                                            <div className="printer-btn u-textBold u-textLarge" key={device?.description}>
                                                <Button data-testid="printer-button" use="secondary" size="block" onClick={() => togglePrinter(device)}>
                                                    {device?.description} {device?.registerNum}
                                                </Button>
                                            </div>
                                        ))}
                                </>
                            ))}
                    </div>
                    </div>
               
            </Modal>)

}

PrinterModal.propTypes ={
content: PropTypes.any,
src : PropTypes.any,
showModal:PropTypes.any,
closeModal : PropTypes.any,
locationCode : PropTypes.any

}
export default PrinterModal;