import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import AgreementPdfView from './AgreementPdfView';
import { isIpad } from 'onevzsoemfeframework/DomService';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { getDocument } from 'pdfjs-dist';


// Mock the dependencies
jest.mock('onevzsoemfeframework/DomService');
jest.mock('onevzsoemfeframework/AssistedCradleService');
jest.mock('pdfjs-dist');
jest.mock('pdfjs-dist/build/pdf.worker.entry', () => 'pdf-worker-mock');

// Mock PrinterModal
jest.mock('./PrinterModal', () => {
  return function PrinterModal(props) {
    return props.showModal ? <div data-testid="printer-modal" onClick={props.closeModal}>Printer Modal</div> : null;
  };
});

describe('AgreementPdfView Component', () => {
  const defaultProps = {
    src: 'base64EncodedPdfString',
    onError: jest.fn(),
    onScroll: jest.fn(),
    closeModal: jest.fn(),
    modalName: 'Test Agreement',
    locationCode: 'LOC123',
    pdfContent: 'pdfContentBase64',
  };

  const mockPdfPage = {
    getViewport: jest.fn(() => ({ height: 800, width: 600 })),
    render: jest.fn(() => ({
      promise: Promise.resolve(),
    })),
  };

  const mockPdfDoc = {
    numPages: 2,
    getPage: jest.fn((pageNum) => Promise.resolve(mockPdfPage)),
  };

  beforeEach(() => {
    jest.clearAllMocks();
    
    // Default mock implementations
    isIpad.mockReturnValue(false);
    getAssistedCradlePropertyV2.mockReturnValue(['FALSE']);
    
    // Mock getDocument
    getDocument.mockReturnValue({
      promise: Promise.resolve(mockPdfDoc),
    });

    // Mock atob
    global.atob = jest.fn((str) => str);
    
    // Mock canvas context
    HTMLCanvasElement.prototype.getContext = jest.fn(() => ({
      fillRect: jest.fn(),
      clearRect: jest.fn(),
      getImageData: jest.fn(),
      putImageData: jest.fn(),
      createImageData: jest.fn(),
      setTransform: jest.fn(),
      drawImage: jest.fn(),
      save: jest.fn(),
      fillText: jest.fn(),
      restore: jest.fn(),
      beginPath: jest.fn(),
      moveTo: jest.fn(),
      lineTo: jest.fn(),
      closePath: jest.fn(),
      stroke: jest.fn(),
      translate: jest.fn(),
      scale: jest.fn(),
      rotate: jest.fn(),
      arc: jest.fn(),
      fill: jest.fn(),
      measureText: jest.fn(() => ({ width: 0 })),
      transform: jest.fn(),
      rect: jest.fn(),
      clip: jest.fn(),
    }));

    // Mock window.open
    global.window.open = jest.fn(() => ({
      document: {
        write: jest.fn(),
      },
    }));
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('Rendering', () => {
    test('should render the component with modal name', () => {
      render(<AgreementPdfView {...defaultProps} />);
      
      expect(screen.getByText('Test Agreement')).toBeInTheDocument();
      expect(screen.getByTestId('PdfView_wrapper')).toBeInTheDocument();
    });

    test('should render back button', () => {
      render(<AgreementPdfView {...defaultProps} />);
      
      const backButton = screen.getByRole('button', { name: /back button/i });
      expect(backButton).toBeInTheDocument();
    });

    test('should call closeModal when back button is clicked', () => {
      render(<AgreementPdfView {...defaultProps} />);
      
      const backButton = screen.getByRole('button', { name: /back button/i });
      fireEvent.click(backButton);
      
      expect(defaultProps.closeModal).toHaveBeenCalledTimes(1);
    });
  });

  describe('PDF Rendering iPad', () => {
    test('should render PDF canvas for iPad devices', async () => {
      isIpad.mockReturnValue(true);
      
      render(<AgreementPdfView {...defaultProps} />);
      
      await waitFor(() => {
        expect(getDocument).toHaveBeenCalled();
      });
      
      
    });

    test('should generate canvas from PDF with multiple pages', async () => {
      isIpad.mockReturnValue(false);
      
      render(<AgreementPdfView {...defaultProps} />);
      
      await waitFor(() => {
        expect(mockPdfDoc.getPage).toHaveBeenCalledTimes(2);
        expect(mockPdfDoc.getPage).toHaveBeenCalledWith(1);
        expect(mockPdfDoc.getPage).toHaveBeenCalledWith(2);
      });
    });

    test('should call onError when PDF loading fails', async () => {
      getDocument.mockReturnValue({
        promise: Promise.reject(new Error('PDF load error')),
      });
      
      render(<AgreementPdfView {...defaultProps} />);
      
      await waitFor(() => {
        expect(defaultProps.onError).toHaveBeenCalled();
      });
    });

    test('should call onError when PDF rendering fails', async () => {
      const mockErrorPdfPage = {
        getViewport: jest.fn(() => ({ height: 800, width: 600 })),
        render: jest.fn(() => ({
          promise: Promise.reject(new Error('Render error')),
        })),
      };

      mockPdfDoc.getPage.mockResolvedValue(mockErrorPdfPage);
      
      render(<AgreementPdfView {...defaultProps} />);
      
      await waitFor(() => {
        expect(defaultProps.onError).toHaveBeenCalled();
      });
    });

    test('should handle invalid PDF source', async () => {
      render(<AgreementPdfView {...defaultProps} src={null} />);
      
      await waitFor(() => {
        expect(defaultProps.onError).toHaveBeenCalled();
      });
    });

    test('should handle empty string PDF source', async () => {
      render(<AgreementPdfView {...defaultProps} src="" />);
      
      await waitFor(() => {
        expect(defaultProps.onError).toHaveBeenCalled();
      });
    });
  });

  describe('PDF Rendering - non iPad', () => {
    test('should render PDF object for non iPad devices', () => {
      isIpad.mockReturnValue(false);
      
      render(<AgreementPdfView {...defaultProps} />);
      
       const pdfObject = screen.getByTitle("Agreement");
      expect(pdfObject).toBeInTheDocument();
      expect(pdfObject).toHaveAttribute('type', 'application/pdf');
     
    });

  
  });

  describe('Print Functionality', () => {

    test('should not render print icon when isIpadPrintEnabled is false', () => {
      getAssistedCradlePropertyV2.mockReturnValue(['FALSE']);
      
      render(<AgreementPdfView {...defaultProps} />);
      
      const printButton = screen.queryByRole('button', { name: /print agreement/i });
      expect(printButton).not.toBeInTheDocument();
    });


    test('should show printer modal for iPad devices when print is clicked', () => {
      isIpad.mockReturnValue(true);
      getAssistedCradlePropertyV2.mockImplementation((keys) => {
        if (keys[0] === 'isIpadPrintEnabled') return ['TRUE'];
        return ['FALSE'];
      });
      
      const { rerender } = render(<AgreementPdfView {...defaultProps} />);
      
      const printButton = screen.getByRole('button', { name: /print agreement/i });
      fireEvent.click(printButton);
      
      rerender(<AgreementPdfView {...defaultProps} />);
      
      // The modal should appear after clicking print
      waitFor(() => {
        expect(screen.getByTestId('printer-modal')).toBeInTheDocument();
        fireEvent.click(screen.getByTestId('printer-modal'))
      });
    });
  });

  describe('PrinterModal Integration', () => {
    test('should render PrinterModal when showIpadPrintModal is true', () => {
      isIpad.mockReturnValue(true);
      const mockRefObject={ current:{
            firstChild:`div`
    }}
    jest.spyOn(React, 'useRef').mockReturnValue(mockRefObject);

      getAssistedCradlePropertyV2.mockImplementation((keys) => {
        if (keys[0] === 'isIpadPrintEnabled') return ['TRUE'];
        return ['FALSE'];
      });
      
      const { rerender } = render(<AgreementPdfView {...defaultProps} />);
      
      const printButton = screen.getByRole('button', { name: /print agreement/i });
      fireEvent.click(printButton);
      
    //   rerender(<AgreementPdfView {...defaultProps} />);
    });

    test('should pass correct props to PrinterModal when dppReprintAgreementEnabled is true', () => {
      isIpad.mockReturnValue(true);
      getAssistedCradlePropertyV2.mockImplementation((keys) => {
        if (keys[0] === 'isIpadPrintEnabled') return ['TRUE'];
        if (keys[0] === 'dppReprintAgreementFFlag') return ['TRUE'];
        return ['FALSE'];
      });
      
      const { rerender } = render(<AgreementPdfView {...defaultProps} />);
      
      const printButton = screen.getByRole('button', { name: /print agreement/i });
      fireEvent.click(printButton);
      
      rerender(<AgreementPdfView {...defaultProps} />);
    });

    test('should pass pdfContent to PrinterModal when dppReprintAgreementEnabled is false', () => {
      isIpad.mockReturnValue(true);
      getAssistedCradlePropertyV2.mockImplementation((keys) => {
        if (keys[0] === 'isIpadPrintEnabled') return ['TRUE'];
        if (keys[0] === 'dppReprintAgreementFFlag') return ['FALSE'];
        return ['FALSE'];
      });
      
      const { rerender } = render(<AgreementPdfView {...defaultProps} />);
      
      const printButton = screen.getByRole('button', { name: /print agreement/i });
      fireEvent.click(printButton);
      
      rerender(<AgreementPdfView {...defaultProps} />);
    });
  });

  describe('Component Lifecycle', () => {
    test('should regenerate PDF when src prop changes', async () => {
      const { rerender } = render(<AgreementPdfView {...defaultProps} />);
      
      await waitFor(() => {
        expect(getDocument).toHaveBeenCalledTimes(1);
      });
      
      rerender(<AgreementPdfView {...defaultProps} src="newBase64String" />);
      
      await waitFor(() => {
        expect(getDocument).toHaveBeenCalledTimes(2);
      });
    });

    test('should remove all child nodes before regenerating PDF', async () => {
      const { rerender } = render(<AgreementPdfView {...defaultProps} />);
      
      await waitFor(() => {
        expect(getDocument).toHaveBeenCalledTimes(1);
      });
      
      rerender(<AgreementPdfView {...defaultProps} src="newBase64String" />);
      
      await waitFor(() => {
        expect(getDocument).toHaveBeenCalledTimes(2);
      });
    });
  });

  describe('Error Handling', () => {
    test('should handle fatal error while rendering PDF', async () => {
      const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
      
      global.atob = jest.fn(() => {
        throw new Error('Fatal error');
      });
      
      render(<AgreementPdfView {...defaultProps} />);
      
      await waitFor(() => {
        expect(consoleErrorSpy).toHaveBeenCalledWith(
          expect.stringContaining('Fatal error while rendering pdf')
        );
      });
      
      consoleErrorSpy.mockRestore();
    });

    test('should handle PDF with no data', async () => {
      render(<AgreementPdfView {...defaultProps} src={undefined} />);
      
      await waitFor(() => {
        expect(defaultProps.onError).toHaveBeenCalled();
      });
    });
  });

  describe('Canvas Creation', () => {
    test('should create canvas elements for each page', async () => {
      isIpad.mockReturnValue(false);
      
      render(<AgreementPdfView {...defaultProps} />);
      
      
    });

    test('should set correct viewport scale', async () => {
      isIpad.mockReturnValue(false);
      
      render(<AgreementPdfView {...defaultProps} />);
      
      
    });
  });

  describe('Console Logs', () => {
    

    test('should log when page is rendered successfully', async () => {
      const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
      isIpad.mockReturnValue(false);
      const mockPdfPage = {
        getViewport: jest.fn(() => ({ height: 800, width: 600 })),
        render: jest.fn(() => ({
          promise: Promise.resolve('div'),
        })),
      };
      mockPdfDoc.getPage.mockResolvedValue(mockPdfPage);
      
      render(<AgreementPdfView {...defaultProps} />);
      
      await waitFor(() => {
        expect(consoleLogSpy).toHaveBeenCalledWith('Page rendered');
      });
      
      consoleLogSpy.mockRestore();
    });

    test('should log error when rendering fails', async () => {
      const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
      
      const mockErrorPdfPage = {
        getViewport: jest.fn(() => ({ height: 800, width: 600 })),
        render: jest.fn(() => ({
          promise: Promise.reject(new Error('Render error')),
        })),
      };

      mockPdfDoc.getPage.mockResolvedValue(mockErrorPdfPage);
      
      render(<AgreementPdfView {...defaultProps} />);
      
      await waitFor(() => {
        expect(consoleLogSpy).toHaveBeenCalledWith(
          'Error Rendering the PDF ',
          expect.any(Error)
        );
      });
      
      consoleLogSpy.mockRestore();
    });
  });
});