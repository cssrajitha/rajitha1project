import PropTypes from 'prop-types';
import { Title, Body, Micro } from '@vds/typography';
import styled from 'styled-components';

import { Badge } from '@vds/badges';
import { Line } from '@vds/lines';
import { TextLink } from '@vds/buttons';
import { FlexColumnGap, FlexRowGap, FlexRowSpace } from '../../DPBuyoutGlobalStyleConstants';
import { formatPhoneNumberWithSymbol ,formatCurrency  } from 'onevzsoemfecommon/Helpers/validation';

const CustomerPhone = styled.img`
  width: 99px;
  height: 120px;
  object-fit: contain;
`;
const InformationContainer = styled.div`
  padding-top: 3.5rem;
`;
const SelectedDeviceInfo = styled.div`
  border-radius: 10px;
  background-color: #ffffff;
`;
const CustDeviceInfo = styled.div`
  padding: 1rem 1.5rem 1rem 1.5rem;
`;

const BuyoutAmt = styled.div`
  padding-left: 2.75rem;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`;
const DeviceIdCard = styled.div`
  display: flex;
  background-color: #f8f7f5;
  border-radius: 4px;
  padding: 0.25rem 0rem 0.357rem 0.5rem;
  width: 100%;
`;
const DeviceSummary = styled.div`
  padding: 1rem 1.5rem 1rem 1.5rem;
`;
const ProgressBar = styled.div`
  height: 12px;
  border-radius: 9999px;
  background: #e8e8e8;
  overflow: hidden;
  position: relative;
`;
// width: ${(props) => props.percentage || 0}%; since for static we are passing percentage as 90,removing the '||0' for coverage
const ProgressFill = styled.div`
  height: 12px;
  background-color: #0089ec;
  width: ${(props) => props.percentage}%;
  border-radius: 9999px;
`;

const BalanceColumnGap = styled(FlexColumnGap)`
  gap: 0.25rem;
`;
const BalanceRow = styled.div`
  display: flex;
  flex-direction: row;
  flex: 1;
  width: 100%;
  gap: 3.5rem;
  @media screen and (max-width: 820px) {
    display: flex;
    flex-direction: column;
    width: 100%;
  }
`;

const Cardcontainer = styled.div`
  width: 100%;
  overflow-y: auto;
  max-height: calc(100vh - 220px);
`;

const RemainingBalance = styled(FlexColumnGap)`
  gap: 0.25rem;
  align-items: flex-end;
  margin-left: auto;
`;
const PhoneModels = styled(FlexRowGap)`
  gap: 0.5rem;
  @media screen and (max-width: 820px) {
    display: flex;
    flex-direction: column;
  }
`;
const SpaceBwtBuyout = styled.div`
  width: 100%;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
function RightPanel(props) {
  const selectedMtnDetails = props.selectedMtnDetails;
  const deviceCost = Number(selectedMtnDetails?.agreementInfo?.loanAmount || 0) + Number(selectedMtnDetails?.downPaymentAmount || 0);
  const totalInstallment = Number(selectedMtnDetails?.numberOfInstallmentsBilled || 0) + Number(selectedMtnDetails?.pendingNumberOfInstallments || 0);
  const percentagePaid = Math.floor((selectedMtnDetails?.totalPaidAmount/deviceCost)*100);
  const remainingPayments = selectedMtnDetails?.pendingNumberOfInstallments;
  const monthlyAmount = formatCurrency(selectedMtnDetails?.agreementInfo?.loanMonthlyPaymentAmount);
  const paidPrincipal = formatCurrency(selectedMtnDetails?.totalPaidAmount);
  const amountFinanced = formatCurrency(selectedMtnDetails?.agreementInfo?.loanAmount);
  const remainingBalance = formatCurrency(selectedMtnDetails?.remainingBalance);

  const viewPDFAgrrement =(loanNumber)=>{
   const request = {
    installmentNum: loanNumber,
    locationCode:props.locationCode
   }
   props.getAgreementPdf({body:request})
  }

  return (
    <InformationContainer>
      <Cardcontainer>
        <FlexColumnGap gap={12}>
          
            <SelectedDeviceInfo key={selectedMtnDetails?.nickName}>
              <CustDeviceInfo>
                <FlexColumnGap gap={14}>
                  <FlexRowGap gap={32} align='flex-start'>
                    <CustomerPhone src={selectedMtnDetails?.defaultImage} alt={selectedMtnDetails?.modelName} />
                    <SpaceBwtBuyout>
                      <FlexColumnGap gap={8}>
                        <Title size='medium'>{selectedMtnDetails?.nickName}</Title>
                        <Body size='medium' color='#000000B2'>
                          {formatPhoneNumberWithSymbol(selectedMtnDetails?.mdn,'-')} | {selectedMtnDetails?.modelName}
                        </Body>
                        <FlexColumnGap gap={16}>
                          <Body size='medium' color='#000000B2'>
                            Device Cost: <strong>{formatCurrency (deviceCost)}</strong> | Down Payment:{' '}
                            <strong>{formatCurrency(selectedMtnDetails?.downPaymentAmount)}</strong>
                          </Body>
                          <Badge fillColor='blue' maxWidth='fit-content'>
                            {/true/i.test(selectedMtnDetails?.equipmentUpgradeEligibility?.edgeUpEligible) ? 'Early Upgrade Eligible' : 'Early Upgrade Eligible: No'}
                          </Badge>
                        </FlexColumnGap>
                      </FlexColumnGap>
                      <FlexColumnGap gap={8}>
                        <BuyoutAmt>
                          <Body size='medium' color='#000000B2'>
                            Buyout Amount
                          </Body>
                          <Title size='large' bold>
                            {formatCurrency(selectedMtnDetails?.totalBuyoutAmount)}
                          </Title>
                        </BuyoutAmt>
                      </FlexColumnGap>
                    </SpaceBwtBuyout>
                  </FlexRowGap>
                  <PhoneModels>
                    <DeviceIdCard>
                      <FlexColumnGap>
                        <Micro color='#000000B2' bold>
                          SKU#:
                        </Micro>
                        <Micro color='#000000B2'>{selectedMtnDetails?.deviceSku}</Micro>
                      </FlexColumnGap>
                    </DeviceIdCard>
                    <DeviceIdCard>
                      <FlexColumnGap>
                        <Micro color='#000000B2' bold>
                          Device ID#:
                        </Micro>
                        <Micro color='#000000B2'>{selectedMtnDetails?.deviceId}</Micro>
                      </FlexColumnGap>
                    </DeviceIdCard>
                    <DeviceIdCard>
                      <FlexColumnGap>
                        <Micro color='#000000B2' bold>
                          Agreement#:
                        </Micro>
                        <Micro color='#000000B2'>
                          <TextLink onClick={()=>viewPDFAgrrement(selectedMtnDetails?.agreementInfo?.loanNumber)}>{selectedMtnDetails?.agreementInfo?.loanNumber}</TextLink></Micro>
                      </FlexColumnGap>
                    </DeviceIdCard>
                    <DeviceIdCard>
                      <FlexColumnGap>
                        <Micro color='#000000B2' bold>
                          APR:
                        </Micro>
                        <Micro color='#000000B2'>{0}%</Micro>
                      </FlexColumnGap>
                    </DeviceIdCard>
                  </PhoneModels>
                </FlexColumnGap>
              </CustDeviceInfo>
            </SelectedDeviceInfo>
          
          <SelectedDeviceInfo>
            <DeviceSummary>
              <FlexColumnGap gap={16}>
                <FlexRowSpace>
                  <Body size='medium' color='#000000'>
                    Device Payment Summary
                  </Body>
                  {props.paymentDone?(
                    <Badge fillColor='green' maxWidth='fit-content'>
                    Partial Payment completed
                          </Badge>
                  ):(<Body size='medium' color='#AAA8A3'>
                    <span style={{ color: '#000000' }}>{selectedMtnDetails?.numberOfInstallmentsBilled}/{totalInstallment}</span> months
                  </Body>)}
                </FlexRowSpace>
                
                  <FlexRowSpace >
                    <FlexColumnGap gap={4}>
                      <Body size='small' color='#000000'>
                        Amount Financed
                      </Body>
                      <Body size='large' color='#000000' bold>
                        {amountFinanced}
                      </Body>
                    </FlexColumnGap>
                    <RemainingBalance>
                      <Body size='small' color='#000000'>
                        Remaining balance
                      </Body>
                      <Body size='large' color='#000000' bold>
                        {remainingBalance}
                      </Body>
                    </RemainingBalance>
                  </FlexRowSpace>
               
                <FlexColumnGap gap={8}>
                  <ProgressBar>
                    <ProgressFill percentage={percentagePaid} />
                  </ProgressBar>
                  <Title size='medium' color='#003E6C'>
                    {percentagePaid}% paid off
                  </Title>
                </FlexColumnGap>
                <Line type='secondary' />
                  <BalanceRow>
                    <BalanceColumnGap>
                      <Body size='small' color='#716F6D'>
                        Paid principal
                      </Body>
                      <Body size='large' color='#716F6D' bold>
                        {paidPrincipal}
                      </Body>
                    </BalanceColumnGap>
                    <BalanceColumnGap>
                      <Body size='small' color='#716F6D'>
                        Remaining principal Balance
                      </Body>
                      <Body size='large' color='#716F6D' bold>
                        {remainingBalance}
                      </Body>
                    </BalanceColumnGap>
                    <BalanceColumnGap>
                      <Body size='small' color='#716F6D '>
                        Remaining payments
                      </Body>
                      <Body size='large' color='#716F6D ' bold>
                        {remainingPayments + ' out of ' + totalInstallment}
                      </Body>
                    </BalanceColumnGap>
                    <BalanceColumnGap>
                      <Body size='small' color='#716F6D'>
                        Monthly amount
                      </Body>
                      <Body size='large' color='#716F6D ' bold>
                        {monthlyAmount}
                      </Body>
                    </BalanceColumnGap>
                  </BalanceRow>
              </FlexColumnGap>
            </DeviceSummary>
          </SelectedDeviceInfo>


         {props.paymentDone && <SelectedDeviceInfo>
            <DeviceSummary>
              <FlexColumnGap gap={16}>
                <FlexRowSpace>
                <Body size='medium' color='#000000' bold>
                    Device Payment Agreement Buyout
                  </Body>
                  </FlexRowSpace>
                  <FlexRowSpace>
                  <BalanceRow>
                    <BalanceColumnGap>
                      <Body size='small' color='#716F6D'>
                        Payment confirmation number
                      </Body>
                      <Body size='large' color='#716F6D' bold>
                        {32994398}
                      </Body>
                    </BalanceColumnGap>
                    <BalanceColumnGap>
                      <Body size='small' color='#716F6D'>
                        Mode of payment
                      </Body>
                      <Body size='large' color='#716F6D' bold>
                        {"Cash"}
                      </Body>
                    </BalanceColumnGap>
                  </BalanceRow>
                  </FlexRowSpace>
                  <FlexRowSpace>
                  <BalanceRow>
                    <Body size='small' color='#716F6D'>
                        The total amount you paid was <b>$725</b>
                      </Body>
                  </BalanceRow>
                  
                </FlexRowSpace>
              </FlexColumnGap>
            </DeviceSummary>
          </SelectedDeviceInfo>}

        </FlexColumnGap>
      </Cardcontainer>
    </InformationContainer>
  );
}

RightPanel.propTypes = {
  selectedMtnDetails: PropTypes.any,
  getAgreementPdf : PropTypes.any,
  paymentDone: PropTypes.any
};
export default RightPanel;