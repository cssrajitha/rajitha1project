import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import LeftPanel from './LeftPanel';

const mockExistingDeviceData = [
  {
    mdn: '2675427385',
    nickName: 'JHON BELTRAN',
    productName: '4G CONNECTED PDI',
    active: 'true',
    pendingNumberOfInstallments: '12',
    defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-midnight-fall22-a',
    totalBuyoutAmount: '$ 15',
    pricePlanInfo: 'Unlimited Welcome',
  },
  {
    mdn: '3364679305',
    nickName: 'KYLE BELTRAN',
    productName: 'IPHONE X 256G SILVER NVZ OTH',
    active: 'true',
    pendingNumberOfInstallments: '5',
    defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-midnight-fall22-a',
    pricePlanInfo: '',
  },
];

const mockSetSelectedIdx = jest.fn();

const defaultProps = {
  leftPanelDetails: mockExistingDeviceData,
  selectedIdx: '2675427385',
  setSelectedIdx: mockSetSelectedIdx,
};

describe('LeftPanelComponent', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('renders LeftPanelcomponent without crashing', () => {
    const { container } = render(<LeftPanel {...defaultProps} />);
    expect(container.firstChild).toBeInTheDocument();
  });

  test('displays device information correctly', () => {
    render(<LeftPanel {...defaultProps} />);

    expect(screen.getByText('KYLE BELTRAN')).toBeInTheDocument();
    expect(screen.getByText('336-467-9305')).toBeInTheDocument();
    expect(screen.getByText('5 months left:')).toBeInTheDocument();
  });
  test('displays device information correctly payment done', () => {
    render(<LeftPanel {...defaultProps} paymentDone={true} />);

    expect(screen.getByText('KYLE BELTRAN')).toBeInTheDocument();
    expect(screen.getByText('267-542-7385')).toBeInTheDocument();
    expect(screen.getByText('All Paid')).toBeInTheDocument();
  });

  test('applies selected class to the correct device card', () => {
    const { container } = render(<LeftPanel {...defaultProps} />);

    const deviceCards = container.querySelectorAll('div[class*="selected"]');
    expect(deviceCards).toHaveLength(1);
  });

  test('calls setSelectedIdx when device card is clicked', () => {
    const { container } = render(<LeftPanel {...defaultProps} />);

    const allDivs = container.querySelectorAll('div');

    const secondDeviceCard = Array.from(allDivs).find((div) => div.textContent.includes('KYLE BELTRAN'));
    const card = screen.getByTestId(`leftCard2675427385`);
    fireEvent.click(card);

    if (secondDeviceCard) {
      fireEvent.click(secondDeviceCard);
    }
  });
});
