import PropTypes from 'prop-types';
import styled from 'styled-components';
import { Body } from '@vds/typography';
import { Badge } from '@vds/badges';
import { formatPhoneNumberWithSymbol } from 'onevzsoemfecommon/Helpers/validation';
import { FlexColumnGap, FlexRowGap } from '../../DPBuyoutGlobalStyleConstants';

const PhoneCardImage = styled.img`
  width: 71px;
  height: 86px;
  object-fit: contain;
`;

const DeviceCards = styled.div`
  border-radius: 12px;
  border: 2px solid transparent;
  background-color: #ffffff;
  cursor: pointer;
  transition: border 0.2s;
  &.selected {
    border: 2px solid #333332;
  }
`;
const DeviceContent = styled.div`
  padding: 1rem;
`;

function LeftPanel(props) {
  const { leftPanelDetails, selectedIdx, setSelectedIdx } = props;
  return (
    <FlexColumnGap gap={16}>
      {leftPanelDetails?.map((line) => (
        <DeviceCards
          key={line?.mdn}
          className={selectedIdx === line?.mdn ? 'selected' : ''}
          onClick={() => setSelectedIdx(line?.mdn)}
          data-testid={`leftCard${line?.mdn}`}
        >
          <DeviceContent>
            <FlexRowGap gap={16}>
              <PhoneCardImage src={line?.defaultImage} alt={line?.productName} />
              <FlexColumnGap gap={4}>
                <Body size='large' bold>
                  {line?.nickName}
                </Body>
                <Body size='small'>{line?.pricePlanInfo?.length > 0 ? line?.pricePlanInfo : ''}</Body>
                <Body size='small' color='#A7A7A7'>
                  {formatPhoneNumberWithSymbol(line?.mdn, '-')}
                </Body>
                <FlexRowGap gap={4}>
                 {props.paymentDone && selectedIdx === line?.mdn? (
                    <Badge fillColor='green' maxWidth='fit-content'>
                      All Paid
                    </Badge>
                  ) : (<><Body size='small' color='#A7A7A7'>
                    {line?.pendingNumberOfInstallments} months left:
                  </Body>
                    <span>
                      <Body size='medium' bold>
                        {line?.totalBuyoutAmount ? `$${line?.totalBuyoutAmount}` : ''}
                      </Body>
                  </span></>)}
                </FlexRowGap>
              </FlexColumnGap>
            </FlexRowGap>
          </DeviceContent>
        </DeviceCards>
      ))}
    </FlexColumnGap>
  );
}

LeftPanel.propTypes = {
  setSelectedIdx: PropTypes.func,
  selectedIdx: PropTypes.any,
  leftPanelDetails: PropTypes.any,
  paymentDone : PropTypes.any
};
export default LeftPanel;
