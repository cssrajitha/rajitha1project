import React from 'react';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import {  getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import SelectDevice from './SelectedDevice';

const mockPosInitiateBuyOut = jest.fn();
const mockGenerateJWT = jest.fn();
const mockReadUserParamDetails = jest.fn();

const mockPosInitiateBuyOutResult = {
  data: {
    body: {
      serviceBody: {
        serviceResponse: {
          context: {
            devicePayOffInfo: [
              {
                mdn: '1111111111',
                nickName: 'Test Phone 1',
                productName: 'iPhone 13',
                active: 'TRUE',
                pendingNumberOfInstallments: 5,
                totalBuyoutAmount: 500.0,
                pricePlanInfo: {
                  planCategoryCd: '92',
                  planId: '63215',
                  planDisplayName: 'Unlimited Welcome',
                  effectiveDate: '06/02/2024',
                },
                equipmentUpgradeEligibility: {
                  edgeUpEligible: 'TRUE',
                },
              },
              {
                mdn: '2222222222',
                nickName: 'Test Phone 2',
                productName: 'Galaxy S21',
                active: 'TRUE',
                pendingNumberOfInstallments: 8,
                totalBuyoutAmount: 800.0,
                pricePlanInfo: {},
                equipmentUpgradeEligibility: {
                  edgeUpEligible: 'TRUE',
                },
              },
              {
                mdn: '3333333333',
                nickName: 'Inactive Phone',
                productName: 'Old Phone',
                active: 'FALSE',
                pendingNumberOfInstallments: 2,
                totalBuyoutAmount: 200.0,
                pricePlanInfo: {},
                equipmentUpgradeEligibility: {
                  edgeUpEligible: 'FALSE',
                },
              },
            ],
          },
        },
      },
    },
  },
  status: 'fulfilled',
  isSuccess: true,
};


jest.mock('onevzsoemfecommon/APIServiceUtils', () => {
  const mockCustomAPI = {
    data: {status:"success"},
    isSuccess: true,
    fetchData: jest.fn(),
  };
  
  return {
    useCustomApiHooks: jest.fn(() => {
      // This returns a function that will be called with the URL
      return () => mockCustomAPI;
    }),
  };
});

jest.mock('onevzsoemfeframework/HTTPService', () => {
  // Define the mock data *inside* the factory so it's available when the mock runs
  const mockHTTP = {
    defaults:{
    headers:{
      cartid:"",
      assistedcartid:""
    }
  },
  };

  return {
    HttpService : mockHTTP,
  };
});


jest.mock('../../../modules/services/APIService/APIServiceHooks', () => ({
  useLazyPosInitiateBuyOutQuery: () => [mockPosInitiateBuyOut, mockPosInitiateBuyOutResult],
  useLazyAgreementPDFQuery : ()=>[jest.fn(),{}],
  useLazyReadUserParamDetailsQuery: () => [mockReadUserParamDetails],
}));

jest.mock('./LeftPanel/LeftPanel', () => ({
  __esModule: true,
  default: ({ leftPanelDetails, selectedIdx, setSelectedIdx }) => (
    <div data-testid='left-panel'>
      MockLeftPanel
      <button
        type='button'
        data={leftPanelDetails}
        data-attribute={selectedIdx}
        onClick={() => setSelectedIdx('1234567890')}
        data-testid='left-panel-select-btn'
      >
        Select MDN
      </button>
    </div>
  ),
}));

jest.mock('./Header', () => ({
  __esModule: true,
  default: ({ closeDpBuyoutModal }) => (
    <div data-testid='header'>
      MockHeader
      <button type='button' onClick={closeDpBuyoutModal} data-testid='header-close-btn'>
        Close Modal
      </button>
    </div>
  ),
}));

jest.mock('./RightPanel/RightPanel', () => ({
  __esModule: true,
  default: ({ selectedMtnDetails }) => (
    <div data-testid='right-panel'>MockRightPanel - {selectedMtnDetails ? 'Details Loaded' : 'No Details'}</div>
  ),
}));

jest.mock('react-redux', () => ({
  ...jest.requireActual('react-redux'),
  useDispatch: jest.fn(),
}));

// Mock AppLoaderActions with jest functions
const mockShow = jest.fn(() => ({ type: 'APP_LOADER_SHOW' }));
const mockHide = jest.fn(() => ({ type: 'APP_LOADER_HIDE' }));

jest.mock('onevzsoemfecommon/AppLoaderActions', () => ({
  show: (...args) => mockShow(...args),
  hide: (...args) => mockHide(...args),
}), { virtual: true });

const mockAddAppMessage = jest.fn();
jest.mock('onevzsoemfecommon/AppMessageActions', () => ({
  addAppMessage: (...args) => mockAddAppMessage(...args),
}));

// Mock DOMPurify
jest.mock('dompurify', () => ({
  sanitize: jest.fn((url) => url),
}));

// Mock onevzsoemfecommon/Helpers
jest.mock('onevzsoemfecommon/Helpers', () => ({
  getUIContextPathBAU: jest.fn(() => '/vzw/ui'),
}));

// Mock DomService
const mockIsIpad = jest.fn();
const mockIsChatStore = jest.fn();
const mockIsTelesales = jest.fn();
const mockExecuteShellFunction = jest.fn();


jest.mock('onevzsoemfeframework/DomService', () => ({
  isIpad: () => mockIsIpad(),
  isChatStore: () => mockIsChatStore(),
  isTelesales: () => mockIsTelesales(),
  executeShellFunction: (...args) => mockExecuteShellFunction(...args),
}));

const mockProps = {
  closeDpBuyoutModal: jest.fn(),
  selectedMtn: '1111111111',
  accountNumber: '123456',
  activeMDN: '1111111111',
  setActiveMDN: jest.fn(),
  setBuyoutPayModal: jest.fn(),
  posInitiateBuyout: jest.fn(),
  posInitiateBuyOutResult: { ...mockPosInitiateBuyOutResult },
};



jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: jest.fn(),
  }),
  { virtual: true },
);


const mockedHandleUpgradeNow = jest.fn();

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockedHandleUpgradeNow,
}));

describe('SelectDevice Component', () => {
   const mockDispatch = jest.fn();
   let originalWindowSelf;
   let originalWindowTop;
   let originalWindowParent;
   let originalWindowOpen;
    beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  beforeEach(() => {
    jest.clearAllMocks();
    sessionStorage.setItem('cartId',"1234512")
    const { useDispatch } = require('react-redux');
    useDispatch.mockReturnValue(mockDispatch);
    getAssistedCradlePropertyV2.mockReturnValue(['TRUE']);
    
    // Clear the AppLoader action mocks
    mockShow.mockClear();
    mockHide.mockClear();

    // Store original window properties
    originalWindowSelf = window.self;
    originalWindowTop = window.top;
    originalWindowParent = window.parent;
    originalWindowOpen = window.open;

    // Mock window.location properties
    delete window.location;
    window.location = {
      protocol: 'https:',
      host: 'example.com',
      origin: 'https://example.com',
      href: 'https://example.com'
    };
  });

  afterEach(() => {
    // Restore original window properties after each test
    Object.defineProperty(window, 'self', {
      configurable: true,
      value: originalWindowSelf,
      writable: true
    });
    Object.defineProperty(window, 'top', {
      configurable: true,
      value: originalWindowTop,
      writable: true
    });
    Object.defineProperty(window, 'parent', {
      configurable: true,
      value: originalWindowParent,
      writable: true
    });
    window.open = originalWindowOpen;
  });

  it('renders correctly and calls API on initial render/activeMtn change', async () => {
    render(<SelectDevice {...mockProps} />);

    expect(screen.getByText('Select a device')).toBeInTheDocument();
    expect(screen.getByText('Upgrade now')).toBeInTheDocument();
    
    expect(screen.getByText('Buyout')).toBeInTheDocument();

    await waitFor(() => {
      expect(mockProps.posInitiateBuyout).toHaveBeenCalledTimes(1);
      expect(mockProps.posInitiateBuyout).toHaveBeenCalledWith({
        body: {
          accountNumber: mockProps.accountNumber,
          mtn: mockProps.selectedMtn,
          processStep: 'initiate',
        },
        spinner: true,
      });
    });

    expect(mockProps.setActiveMDN).toHaveBeenCalledWith(mockProps.selectedMtn);

    expect(screen.getByText(/MockRightPanel - Details Loaded/i)).toBeInTheDocument();
  });

  it('handles user clicking the Upgrade now button', async () => {
    sessionStorage.setItem('channel', 'OMNI-INDIRECT');
    sessionStorage.setItem('cartId',"12345")
    sessionStorage.setItem('soeguisubkey', 'test-key-123');
    sessionStorage.setItem('elvisFFlag', 'true');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ elvisFFlag: 'true' }));

    render(<SelectDevice {...mockProps} />);

    const buyoutButton = screen.getByRole('button', { name: /Upgrade now/i });
    await fireEvent.click(buyoutButton);
  });

  it('handles user clicking the Upgrade now button', async () => {
    sessionStorage.setItem('channel', 'OMNI-INDIRECT-TAB');
    sessionStorage.setItem('soeguisubkey', 'test-key-123');
    sessionStorage.setItem('cartId',"12345")
    sessionStorage.setItem('elvisFFlag', 'true');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ elvisFFlag: 'true' }));

    render(<SelectDevice {...mockProps} />);

    const buyoutButton = screen.getByRole('button', { name: /Upgrade now/i });
    await fireEvent.click(buyoutButton);
  });

  it('handles user clicking the Upgrade now button', async () => {
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    sessionStorage.setItem('soeguisubkey', 'test-key-123');
    sessionStorage.setItem('cartId',"12345")
    sessionStorage.setItem('elvisFFlag', 'true');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ elvisFFlag: 'true' }));

    render(<SelectDevice {...mockProps} />);

    const buyoutButton = screen.getByRole('button', { name: /Upgrade now/i });
    await fireEvent.click(buyoutButton);
  });

  it.skip('handles user clicking the Partial payment button', async () => {
    render(<SelectDevice {...mockProps} />);

    const buyoutButton = screen.getByRole('button', { name: /Partial payment/i });
    await fireEvent.click(buyoutButton);
  });

  it('handles user clicking the Buyout button', async () => {
    render(<SelectDevice {...mockProps} />);

    const buyoutButton = screen.getByRole('button', { name: /Buyout/i });
    await fireEvent.click(buyoutButton);

    expect(mockProps.setBuyoutPayModal).toHaveBeenCalledWith(true);
  });

  it('handles user clicking the close button on the Header', async () => {
    render(<SelectDevice {...mockProps} />);

    const closeButton = screen.getByTestId('header-close-btn');
    await fireEvent.click(closeButton);

    expect(mockProps.closeDpBuyoutModal).toHaveBeenCalledTimes(1);
  });

  it('Confirmation Screen on mount', async () => {
    render(<SelectDevice {...mockProps} paymentDone={true}/>);
    expect(  screen.queryByText("Select a device")).toBeInTheDocument()
  });
  it('handles MDN selection from LeftPanel', async () => {
    render(<SelectDevice {...mockProps} />);

    const selectMdnButton = screen.getByTestId('left-panel-select-btn');
    await fireEvent.click(selectMdnButton);

    const newMdn = '1234567890';

    await waitFor(() => {
      expect(mockProps.posInitiateBuyout).toHaveBeenCalledTimes(2);
      expect(mockProps.setActiveMDN).toHaveBeenCalledWith(newMdn);
    });
  });
  it(' Handles API failure gracefully (e.g., no data update)', async () => {
    mockPosInitiateBuyOutResult.status = 'rejected';
    mockPosInitiateBuyOutResult.isSuccess = false;
    mockPosInitiateBuyOutResult.data = null;

    render(<SelectDevice {...mockProps} posInitiateBuyOutResult={mockPosInitiateBuyOutResult} />);

    await waitFor(() => {
      expect(mockProps.posInitiateBuyout).toHaveBeenCalled();
    });

    expect(screen.queryByText('Test Phone 1 - 1111111111')).not.toBeInTheDocument();
  });
   

  it('handles Upgrade now with RETAIL channel - readUserParamDetails returns status 1', async () => {
    sessionStorage.setItem('channel', 'RETAIL');
    sessionStorage.setItem('soeguisubkey', 'test-key-123');
    sessionStorage.setItem('cartId',"12345")
    sessionStorage.setItem('elvisFFlag', 'true');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ elvisFFlag: 'true' }));

    // Mock readUserParamDetails to return RTK Query result with data.data.status
    // AND also includes salesRepId to satisfy the condition
    mockReadUserParamDetails.mockResolvedValue({
      data: { 
        data: { 
          status: 1,
          salesRepId: 'REP123'
        } 
      }
    });

    // Mock generateJWT to return RTK Query result
    mockGenerateJWT.mockResolvedValue({
      data: { success: true }
    });

    render(<SelectDevice {...mockProps} />);

    const upgradeButton = screen.getByRole('button', { name: /Upgrade now/i });
    await fireEvent.click(upgradeButton);


    await waitFor(() => {
      expect(mockReadUserParamDetails).toHaveBeenCalledWith({ body: {} });
    }, { timeout: 3000 });
  


    // Window navigation happens instead of navigate function in the actual implementation
    // The test should verify the window location change or the executeShellFunction call
  });

   it('handles Upgrade now with RETAIL channel - readUserParamDetails returns status 0', async () => {
    sessionStorage.setItem('channel', 'RETAIL');
    sessionStorage.setItem('soeguisubkey', 'test-key-123');
    sessionStorage.setItem('cartId',"12345")
    sessionStorage.setItem('elvisFFlag', 'true');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ elvisFFlag: 'true' }));

    // Clear specific mocks (don't clear mockDispatch)
    mockGenerateJWT.mockClear();
    mockReadUserParamDetails.mockClear();
    mockedHandleUpgradeNow.mockClear();
    mockAddAppMessage.mockClear();

    // Mock readUserParamDetails to return status 0 with data.data.status
    mockReadUserParamDetails.mockResolvedValue({
      data: { data: { status: 0 } }
    });

    render(<SelectDevice {...mockProps} />);

    const upgradeButton = screen.getByRole('button', { name: /Upgrade now/i });
    await fireEvent.click(upgradeButton);


    await waitFor(() => {
      expect(mockReadUserParamDetails).toHaveBeenCalledWith({ body: {} });
    }, { timeout: 3000 });

    // When status is 0 for RETAIL channel, it should show this error message
    await waitFor(() => {
      expect(mockAddAppMessage).toHaveBeenCalledWith(
        'Please enter your Sales Rep ID.',
        'error',
        true,
        true
      );
    }, { timeout: 3000 });

    // Verify generateJWT is NOT called (because status is not 1)
    expect(mockGenerateJWT).not.toHaveBeenCalled();
    
   
    
    // Navigation should NOT happen because of the return statement
    expect(mockedHandleUpgradeNow).not.toHaveBeenCalled();
  });

  it('handles Upgrade now with RETAIL channel - readUserParamDetails returns body.status 1', async () => {
    sessionStorage.setItem('channel', 'RETAIL');
    sessionStorage.setItem('cartId',"12345")
    sessionStorage.setItem('soeguisubkey', 'test-key-123');
    sessionStorage.setItem('elvisFFlag', 'true');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ elvisFFlag: 'true' }));

    // Mock readUserParamDetails to return RTK Query response object (NOT unwrapped)
    // The code checks apiResponse?.data?.data?.status || apiResponse?.data?.status
    // AND also checks apiResponse?.data?.data?.salesRepId !== ""
    mockReadUserParamDetails.mockResolvedValue({
      data: { 
        status: 1,
        data: {
          status: 1,
          salesRepId: 'REP123'
        }
      }
    });

    // Mock generateJWT to resolve successfully
    mockGenerateJWT.mockResolvedValue({
      isSuccess:true,
      data: { success: true }
    });

    render(<SelectDevice {...mockProps} />);

    const upgradeButton = screen.getByRole('button', { name: /Upgrade now/i });
    await fireEvent.click(upgradeButton);


    await waitFor(() => {
      expect(mockReadUserParamDetails).toHaveBeenCalledWith({ body: {} });
    }, { timeout: 3000 });

   


    // Window navigation happens instead of navigate function in the actual implementation
    // The test should verify the window location change or the executeShellFunction call
  });

  it('handles user clicking the Upgrade now button', async () => {
    sessionStorage.setItem('channel', 'OMNI-INDIRECT');
    sessionStorage.setItem('cartId',"12345")
    sessionStorage.setItem('soeguisubkey', 'test-key-123');
    sessionStorage.setItem('elvisFFlag', 'true');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ elvisFFlag: 'true' }));

    render(<SelectDevice {...mockProps} />);

    const buyoutButton = screen.getByRole('button', { name: /Upgrade now/i });
    await fireEvent.click(buyoutButton);
  });

  it('handles user clicking the Upgrade now button', async () => {
    sessionStorage.setItem('channel', 'OMNI-INDIRECT-TAB');
    sessionStorage.setItem('soeguisubkey', 'test-key-123');
    sessionStorage.setItem('cartId',"12345")
    sessionStorage.setItem('elvisFFlag', 'true');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ elvisFFlag: 'true' }));

    render(<SelectDevice {...mockProps} />);

    const buyoutButton = screen.getByRole('button', { name: /Upgrade now/i });
    await fireEvent.click(buyoutButton);
  });

  it('handles user clicking the Upgrade now button', async () => {
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    sessionStorage.setItem('soeguisubkey', 'test-key-123');
    sessionStorage.setItem('elvisFFlag', 'true');
    sessionStorage.setItem('cartId',"12345")
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ elvisFFlag: 'true' }));

    render(<SelectDevice {...mockProps} />);

    const buyoutButton = screen.getByRole('button', { name: /Upgrade now/i });
    await fireEvent.click(buyoutButton);
  });

  it.skip('handles user clicking the Partial payment button', async () => {
    render(<SelectDevice {...mockProps} />);

    const buyoutButton = screen.getByRole('button', { name: /Partial payment/i });
    await fireEvent.click(buyoutButton);
  });

  it('handles user clicking the Buyout button', async () => {
    render(<SelectDevice {...mockProps} />);

    const buyoutButton = screen.getByRole('button', { name: /Buyout/i });
    await fireEvent.click(buyoutButton);

    expect(mockProps.setBuyoutPayModal).toHaveBeenCalledWith(true);
  });

  it('handles user clicking the close button on the Header', async () => {
    render(<SelectDevice {...mockProps} />);

    const closeButton = screen.getByTestId('header-close-btn');
    await fireEvent.click(closeButton);

    expect(mockProps.closeDpBuyoutModal).toHaveBeenCalledTimes(1);
  });

  it('handles MDN selection from LeftPanel', async () => {
    render(<SelectDevice {...mockProps} />);

    const selectMdnButton = screen.getByTestId('left-panel-select-btn');
    await fireEvent.click(selectMdnButton);

    const newMdn = '1234567890';

    await waitFor(() => {
      expect(mockProps.posInitiateBuyout).toHaveBeenCalledTimes(2);
      expect(mockProps.setActiveMDN).toHaveBeenCalledWith(newMdn);
    });
  });
  it(' Handles API failure gracefully (e.g., no data update)', async () => {
    mockPosInitiateBuyOutResult.status = 'rejected';
    mockPosInitiateBuyOutResult.isSuccess = false;
    mockPosInitiateBuyOutResult.data = null;

    render(<SelectDevice {...mockProps} posInitiateBuyOutResult={mockPosInitiateBuyOutResult} />);

    await waitFor(() => {
      expect(mockProps.posInitiateBuyout).toHaveBeenCalled();
    });

    expect(screen.queryByText('Test Phone 1 - 1111111111')).not.toBeInTheDocument();
  });

  it('handles Upgrade now in iframe - sends postMessage to parent', async () => {
    sessionStorage.setItem('channel', 'RETAIL');
    sessionStorage.setItem('soeguisubkey', 'test-key-123');
    sessionStorage.setItem('cartId',"12345")
    sessionStorage.setItem('elvisFFlag', 'true');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ elvisFFlag: 'true' }));

    // Mock readUserParamDetails
    mockReadUserParamDetails.mockResolvedValue({
      data: { 
        data: { 
          status: 1,
          salesRepId: 'REP123'
        } 
      }
    });

    mockGenerateJWT.mockResolvedValue({
      isSuccess:true,
      data: { success: true }
    });

    // Mock iframe detection (window.self !== window.top)
    const originalSelf = window.self;
    Object.defineProperty(window, 'self', {
      configurable: true,
      value: { location: { href: '' } }
    });
    Object.defineProperty(window, 'top', {
      configurable: true,
      value: { location: { href: 'different' } }
    });

    // Mock postMessage
    const mockPostMessage = jest.fn();
    Object.defineProperty(window, 'parent', {
      configurable: true,
      value: { postMessage: mockPostMessage }
    });

    // Mock DomService functions to return false (not iPad, chatStore, or telesales)
    mockIsIpad.mockReturnValue(false);
    mockIsChatStore.mockReturnValue(false);
    mockIsTelesales.mockReturnValue(false);

    render(<SelectDevice {...mockProps} />);

    const upgradeButton = screen.getByRole('button', { name: /Upgrade now/i });
    await fireEvent.click(upgradeButton);

    await waitFor(() => {
      expect(mockPostMessage).toHaveBeenCalled();
    }, { timeout: 3000 });

    const postMessageCall = mockPostMessage.mock.calls[0];
    expect(postMessageCall[0]).toMatchObject({
      iframe: 'order',
      path: '',
      replace: true,
    });
    expect(postMessageCall[0].url).toBeTruthy();
    expect(postMessageCall[1]).toBe(window.location.origin);

    // Restore original window.self
    Object.defineProperty(window, 'self', {
      configurable: true,
      value: originalSelf
    });
  });

  it('handles Upgrade now not in iframe - opens window with window.open', async () => {
    sessionStorage.setItem('channel', 'RETAIL');
    sessionStorage.setItem('soeguisubkey', 'test-key-123');
    sessionStorage.setItem('elvisFFlag', 'true');
    sessionStorage.setItem('cartId',"12345")
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ elvisFFlag: 'true' }));

    // Mock readUserParamDetails
    mockReadUserParamDetails.mockResolvedValue({
      data: { 
        data: { 
          status: 1,
          salesRepId: 'REP123'
        } 
      }
    });

    mockGenerateJWT.mockResolvedValue({
      data: { success: true },
      isSuccess:true
    });

    // Ensure not in iframe (window.self === window.top)
    Object.defineProperty(window, 'self', {
      configurable: true,
      value: window
    });
    Object.defineProperty(window, 'top', {
      configurable: true,
      value: window
    });

    // Mock window.open
    const mockWindowOpen = jest.fn();
    window.open = mockWindowOpen;

    // Mock DomService functions to return false (not iPad, chatStore, or telesales)
    mockIsIpad.mockReturnValue(false);
    mockIsChatStore.mockReturnValue(false);
    mockIsTelesales.mockReturnValue(false);

    render(<SelectDevice {...mockProps} />);

    const upgradeButton = screen.getByRole('button', { name: /Upgrade now/i });
    await fireEvent.click(upgradeButton);

    await waitFor(() => {
      expect(mockWindowOpen).toHaveBeenCalled();
    }, { timeout: 3000 });

    // expect(mockWindowOpen).toHaveBeenCalledWith(
    //   expect.stringContaining('/sales/assisted'),
    //   '_blank'
    // );
  });

  it('handles Upgrade now with iPad device - calls executeShellFunction', async () => {
    sessionStorage.setItem('channel', 'RETAIL');
    sessionStorage.setItem('soeguisubkey', 'test-key-123');
    sessionStorage.setItem('elvisFFlag', 'true');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ elvisFFlag: 'true' }));

    // Mock readUserParamDetails
    mockReadUserParamDetails.mockResolvedValue({
      data: { 
        data: { 
          status: 1,
          salesRepId: 'REP123'
        } 
      }
    });

    mockGenerateJWT.mockResolvedValue({
      data: { success: true }
    });

    // Mock DomService functions - iPad is true
    mockIsIpad.mockReturnValue(true);
    mockIsChatStore.mockReturnValue(false);
    mockIsTelesales.mockReturnValue(false);

    render(<SelectDevice {...mockProps} />);

    const upgradeButton = screen.getByRole('button', { name: /Upgrade now/i });
    await fireEvent.click(upgradeButton);

    await waitFor(() => {
      expect(mockExecuteShellFunction).toHaveBeenCalled();
    }, { timeout: 3000 });

    // Verify executeShellFunction was called with correct parameters
    expect(mockExecuteShellFunction).toHaveBeenCalled()
    
  });

  it('handles Upgrade now with ChatStore - opens window with specific parameters', async () => {
    sessionStorage.setItem('channel', 'RETAIL');
    sessionStorage.setItem('cartId',"12345")
    sessionStorage.setItem('soeguisubkey', 'test-key-123');
    sessionStorage.setItem('elvisFFlag', 'true');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ elvisFFlag: 'true' }));

    // Mock readUserParamDetails
    mockReadUserParamDetails.mockResolvedValue({
      data: { 
        data: { 
          status: 1,
          salesRepId: 'REP123'
        } 
      }
    });

    mockGenerateJWT.mockResolvedValue({
      data: { success: true },isSuccess:true
    });

    // Mock window.open
    const mockWindowOpen = jest.fn();
    window.open = mockWindowOpen;
    
    // Mock parent object
    window.parent = { orderTabOpened: null };

    // Mock DomService functions - ChatStore is true
    mockIsIpad.mockReturnValue(false);
    mockIsChatStore.mockReturnValue(true);
    mockIsTelesales.mockReturnValue(false);

    render(<SelectDevice {...mockProps} />);

    const upgradeButton = screen.getByRole('button', { name: /Upgrade now/i });
    await fireEvent.click(upgradeButton);

    await waitFor(() => {
      expect(mockWindowOpen).toHaveBeenCalled();
    }, { timeout: 2000 });

    // Verify window.open was called with correct parameters for chat store
    // expect(mockWindowOpen).toHaveBeenCalledWith(
    //   expect.stringContaining('/sales/assisted'),
    //   'nsaOrderingWindow',
    //   'toolbar=yes,scrollbars=yes,resizable=yes,top=50,left=100,width=1000,height=800'
    // );
  });

  it('handles Upgrade now with Telesales - opens window with specific parameters', async () => {
    sessionStorage.setItem('channel', 'RETAIL');
    sessionStorage.setItem('cartId',"12345")
    sessionStorage.setItem('soeguisubkey', 'test-key-123');
    sessionStorage.setItem('elvisFFlag', 'true');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ elvisFFlag: 'true' }));

    // Mock readUserParamDetails
    mockReadUserParamDetails.mockResolvedValue({
      data: { 
        data: { 
          status: 1,
          salesRepId: 'REP123'
        } 
      }
    });

    mockGenerateJWT.mockResolvedValue({
      data: { success: true },isSuccess:true
    });

    // Mock window.open
    const mockWindowOpen = jest.fn();
    window.open = mockWindowOpen;
    
    // Mock parent object
    window.parent = { orderTabOpened: null };

    // Mock DomService functions - Telesales is true
    mockIsIpad.mockReturnValue(false);
    mockIsChatStore.mockReturnValue(false);
    mockIsTelesales.mockReturnValue(true);

    render(<SelectDevice {...mockProps} />);

    const upgradeButton = screen.getByRole('button', { name: /Upgrade now/i });
    await fireEvent.click(upgradeButton);
  });

  // Test cases for inIframe function
  describe('inIframe function', () => {
    it('should return true when window.self !== window.top', () => {
      // Mock iframe scenario - window.self and window.top are different
      Object.defineProperty(window, 'self', {
        configurable: true,
        value: { location: { href: 'iframe' } }
      });
      Object.defineProperty(window, 'top', {
        configurable: true,
        value: { location: { href: 'parent' } }
      });

      render(<SelectDevice {...mockProps} />);
      
      // The component should render successfully with inIframe detecting iframe context
      expect(screen.getByText('Select a device')).toBeInTheDocument();
    });

    it('should return false when window.self === window.top (not in iframe)', () => {
      // Mock non-iframe scenario - window.self and window.top are the same
      Object.defineProperty(window, 'self', {
        configurable: true,
        value: window
      });
      Object.defineProperty(window, 'top', {
        configurable: true,
        value: window
      });

      render(<SelectDevice {...mockProps} />);
      
      // The component should render successfully with inIframe detecting non-iframe context
      expect(screen.getByText('Select a device')).toBeInTheDocument();
    });

    it('should return true when accessing window.top throws an exception', () => {
      // Mock exception scenario when accessing window.top (cross-origin iframe)
      Object.defineProperty(window, 'self', {
        configurable: true,
        value: window
      });
      Object.defineProperty(window, 'top', {
        configurable: true,
        get() {
          throw new Error('Cross-origin access denied');
        }
      });

      render(<SelectDevice {...mockProps} />);
      
      // The component should render successfully even when exception is thrown
      expect(screen.getByText('Select a device')).toBeInTheDocument();
    });
  });

  // Test cases for useEffect with generateJWT (line 170)
  describe('useEffect with generateJWT result - line 170', () => {
    beforeEach(() => {
      // Reset sessionStorage
      sessionStorage.clear();
      sessionStorage.setItem('analyticssessionid', 'test-session-id');
      sessionStorage.setItem('soeguisubkey', 'test-key-123');
      sessionStorage.setItem('elvisFFlag', 'true');
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ elvisFFlag: 'true' }));
    });

    it('should construct URL with aiQuoteLineUpgradeNowFFlag enabled and open in iPad', async () => {
      // Mock aiQuoteLineUpgradeNowFFlag to return true
      

      // Mock DomService
      mockIsIpad.mockReturnValue(true);
      mockIsChatStore.mockReturnValue(false);
      mockIsTelesales.mockReturnValue(false);

      sessionStorage.setItem('channel', 'OMNI-INDIRECT');

      // Mock generateJWT to return success
      mockGenerateJWT.mockResolvedValue({
        isSuccess:true,
        data: { token: 'test-jwt-token', success: true }
      });

      render(<SelectDevice {...mockProps} />);

      const upgradeButton = screen.getByRole('button', { name: /Upgrade now/i });
      await fireEvent.click(upgradeButton);

      await waitFor(() => {
        expect(mockExecuteShellFunction).toHaveBeenCalled();
      }, { timeout: 3000 });

      // Verify executeShellFunction was called with correct URL containing aiquote parameters
      const shellFunctionCall = mockExecuteShellFunction.mock.calls[0];
      expect(shellFunctionCall[0]).toBe('Shell');
      expect(shellFunctionCall[1]).toBe('showScreen');
      expect(shellFunctionCall[3].params).toContain('aiquote.html');
      
    });

    it('should construct URL without aiQuoteLineUpgradeNowFFlag and open in iPad', async () => {
      // Mock aiQuoteLineUpgradeNowFFlag to return false
     // const { getAssistedCradlePropertyV2 } = require('onevzsoemfeframework/AssistedCradleService');
      getAssistedCradlePropertyV2.mockReturnValue(['FALSE']);

      // Mock DomService
      mockIsIpad.mockReturnValue(true);
      mockIsChatStore.mockReturnValue(false);
      mockIsTelesales.mockReturnValue(false);

      sessionStorage.setItem('channel', 'OMNI-INDIRECT');

      // Mock generateJWT to return success
      mockGenerateJWT.mockResolvedValue({
        data: { token: 'test-jwt-token', success: true }
      });

      render(<SelectDevice {...mockProps} />);

      const upgradeButton = screen.getByRole('button', { name: /Upgrade now/i });
      await fireEvent.click(upgradeButton);

      await waitFor(() => {
        expect(mockExecuteShellFunction).toHaveBeenCalled();
      }, { timeout: 3000 });

      // Verify executeShellFunction was called with landing.html URL
      const shellFunctionCall = mockExecuteShellFunction.mock.calls[0];
      expect(shellFunctionCall[3].params).toContain('landing.html');
    });

    it('should open URL in ChatStore with window.open and specific parameters', async () => {
      // Mock DomService
      mockIsIpad.mockReturnValue(false);
      mockIsChatStore.mockReturnValue(true);
      mockIsTelesales.mockReturnValue(false);

      // Mock window.open
      const mockWindowOpen = jest.fn();
      window.open = mockWindowOpen;
      window.parent = { orderTabOpened: null };

      sessionStorage.setItem('channel', 'OMNI-INDIRECT');

      // Mock generateJWT to return success
      mockGenerateJWT.mockResolvedValue({
        data: { token: 'test-jwt-token', success: true }
      });

      render(<SelectDevice {...mockProps} />);

      const upgradeButton = screen.getByRole('button', { name: /Upgrade now/i });
      await fireEvent.click(upgradeButton);

      await waitFor(() => {
        expect(mockWindowOpen).toHaveBeenCalled();
      }, { timeout: 3000 });

      // Verify window.open was called with nsaOrderingWindow and specific features
      expect(mockWindowOpen).toHaveBeenCalled()
    });

    it('should open URL in Telesales with window.open and specific parameters', async () => {
      // Mock DomService
      mockIsIpad.mockReturnValue(false);
      mockIsChatStore.mockReturnValue(false);
      mockIsTelesales.mockReturnValue(true);

      // Mock window.open
      const mockWindowOpen = jest.fn();
      window.open = mockWindowOpen;
      window.parent = { orderTabOpened: null };

      sessionStorage.setItem('channel', 'OMNI-INDIRECT');

      // Mock generateJWT to return success
      mockGenerateJWT.mockResolvedValue({
        data: { token: 'test-jwt-token', success: true }
      });

      render(<SelectDevice {...mockProps} />);

      const upgradeButton = screen.getByRole('button', { name: /Upgrade now/i });
      await fireEvent.click(upgradeButton);

      await waitFor(() => {
        expect(mockWindowOpen).toHaveBeenCalled();
      }, { timeout: 3000 });

      // Verify window.open was called with nsaOrderingWindow and specific features
      expect(mockWindowOpen).toHaveBeenCalled();
    });

    it('should send postMessage to parent when in iframe (not ChatStore/Telesales/iPad)', async () => {
      // Mock DomService - not iPad, ChatStore, or Telesales
      mockIsIpad.mockReturnValue(false);
      mockIsChatStore.mockReturnValue(false);
      mockIsTelesales.mockReturnValue(false);

      // Mock iframe detection
      Object.defineProperty(window, 'self', {
        configurable: true,
        value: { location: { href: 'iframe' } }
      });
      Object.defineProperty(window, 'top', {
        configurable: true,
        value: { location: { href: 'parent' } }
      });

      // Mock postMessage
      const mockPostMessage = jest.fn();
      Object.defineProperty(window, 'parent', {
        configurable: true,
        value: { postMessage: mockPostMessage }
      });

      sessionStorage.setItem('channel', 'OMNI-INDIRECT');

      // Mock generateJWT to return success
      mockGenerateJWT.mockResolvedValue({
        data: { token: 'test-jwt-token', success: true }
      });

      render(<SelectDevice {...mockProps} />);

      const upgradeButton = screen.getByRole('button', { name: /Upgrade now/i });
      await fireEvent.click(upgradeButton);

      await waitFor(() => {
        expect(mockPostMessage).toHaveBeenCalled();
      }, { timeout: 3000 });

      // Verify postMessage was called with correct message structure
      const postMessageCall = mockPostMessage.mock.calls[0];
      expect(postMessageCall[0]).toMatchObject({
        iframe: 'order',
        path: '',
        replace: true,
      });
      expect(postMessageCall[0].url).toBeTruthy();
      expect(postMessageCall[1]).toBe(window.location.origin);
    });

    it('should open URL with window.open when not in iframe (not ChatStore/Telesales/iPad)', async () => {
      // Mock DomService - not iPad, ChatStore, or Telesales
      mockIsIpad.mockReturnValue(false);
      mockIsChatStore.mockReturnValue(false);
      mockIsTelesales.mockReturnValue(false);

      // Mock not in iframe
      Object.defineProperty(window, 'self', {
        configurable: true,
        value: window
      });
      Object.defineProperty(window, 'top', {
        configurable: true,
        value: window
      });

      // Mock window.open
      const mockWindowOpen = jest.fn();
      window.open = mockWindowOpen;

      sessionStorage.setItem('channel', 'OMNI-INDIRECT');

      // Mock generateJWT to return success
      mockGenerateJWT.mockResolvedValue({
        data: { token: 'test-jwt-token', success: true }
      });

      render(<SelectDevice {...mockProps} />);

      const upgradeButton = screen.getByRole('button', { name: /Upgrade now/i });
      await fireEvent.click(upgradeButton);

      await waitFor(() => {
        expect(mockWindowOpen).toHaveBeenCalled();
      }, { timeout: 3000 });

      // Verify window.open was called with _blank target
      expect(mockWindowOpen).toHaveBeenCalled()
      
    });

    it('should not trigger navigation when generateJWT is not successful', async () => {
      // Mock window.open
      const mockWindowOpen = jest.fn();
      window.open = mockWindowOpen;

      sessionStorage.setItem('channel', 'OMNI-INDIRECT');

      // Mock generateJWT to return failure (no data)
      mockGenerateJWT.mockResolvedValue({
        data: null
      });

      render(<SelectDevice {...mockProps} />);

      const upgradeButton = screen.getByRole('button', { name: /Upgrade now/i });
      await fireEvent.click(upgradeButton);

      // Wait a bit to ensure no navigation happens
      // await waitFor(() => {
      //   expect(mockGenerateJWT).toHaveBeenCalled();
      // }, { timeout: 3000 });

      // // Verify window.open was NOT called since generateJWT was not successful
      // expect(mockWindowOpen).not.toHaveBeenCalled();
      // expect(mockExecuteShellFunction).not.toHaveBeenCalled();
    });

    it('should construct correct URL with all query parameters when aiQuoteLineUpgradeNowFFlag is enabled', async () => {
      // Mock aiQuoteLineUpgradeNowFFlag to return true
     

      // Mock DomService - not in special cases
      mockIsIpad.mockReturnValue(false);
      mockIsChatStore.mockReturnValue(false);
      mockIsTelesales.mockReturnValue(false);

      // Mock not in iframe
      Object.defineProperty(window, 'self', {
        configurable: true,
        value: window
      });
      Object.defineProperty(window, 'top', {
        configurable: true,
        value: window
      });

      // Mock window.open
      const mockWindowOpen = jest.fn();
      window.open = mockWindowOpen;

      sessionStorage.setItem('channel', 'OMNI-INDIRECT');
      sessionStorage.setItem('analyticssessionid', 'analytics-123');

      // Mock generateJWT to return success
      mockGenerateJWT.mockResolvedValue({
        data: { token: 'test-jwt-token', success: true }
      });

      render(<SelectDevice {...mockProps} />);

      const upgradeButton = screen.getByRole('button', { name: /Upgrade now/i });
      await fireEvent.click(upgradeButton);

      await waitFor(() => {
        expect(mockWindowOpen).toHaveBeenCalled();
      }, { timeout: 3000 });
    });

    it('should use landing.html URL when aiQuoteLineUpgradeNowFFlag is disabled', async () => {
      getAssistedCradlePropertyV2.mockReturnValue(['FALSE']);

      // Mock DomService - not in special cases
      mockIsIpad.mockReturnValue(false);
      mockIsChatStore.mockReturnValue(false);
      mockIsTelesales.mockReturnValue(false);

      // Mock not in iframe
      Object.defineProperty(window, 'self', {
        configurable: true,
        value: window
      });
      Object.defineProperty(window, 'top', {
        configurable: true,
        value: window
      });

      // Mock window.open
      const mockWindowOpen = jest.fn();
      window.open = mockWindowOpen;

      sessionStorage.setItem('channel', 'OMNI-INDIRECT');

      // Mock generateJWT to return success
      mockGenerateJWT.mockResolvedValue({
        data: { token: 'test-jwt-token', success: true }
      });

      render(<SelectDevice {...mockProps} />);

      const upgradeButton = screen.getByRole('button', { name: /Upgrade now/i });
      await fireEvent.click(upgradeButton);

      await waitFor(() => {
        expect(mockWindowOpen).toHaveBeenCalled();
      }, { timeout: 3000 });

      
    });
  });
});