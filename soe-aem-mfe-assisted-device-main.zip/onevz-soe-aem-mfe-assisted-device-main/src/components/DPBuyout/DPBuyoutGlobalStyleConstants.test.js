import { render, screen } from '@testing-library/react';
import { FlexRowSpace, FlexRowGap } from './DPBuyoutGlobalStyleConstants';

const TestChild = () => <div data-testid='child'>hello</div>;

test('flexRowSpace with gap, align', () => {
  render(
    <FlexRowSpace align='center' gap={3}>
      <TestChild />
    </FlexRowSpace>,
  );
  expect(screen.getByTestId('child')).toBeInTheDocument();
});
test('flexRowSpace', () => {
  render(
    <FlexRowSpace>
      <TestChild />
    </FlexRowSpace>,
  );
  expect(screen.getByTestId('child')).toBeInTheDocument();
});
test('flexRowGap', () => {
  render(
    <FlexRowGap>
      <TestChild />
    </FlexRowGap>,
  );
  expect(screen.getByTestId('child')).toBeInTheDocument();
});
test('flexRowGap', () => {
  render(
    <FlexRowGap align='center' gap={3}>
      <TestChild />
    </FlexRowGap>,
  );
  expect(screen.getByTestId('child')).toBeInTheDocument();
});

