import styled from "styled-components";
export const FlexRowGap = styled.div`display: flex; flex-direction: row; align-items: ${({ align }) => align === undefined ? 'center' : align}; gap: ${({ gap }) => gap}px;`;
export const FlexRowSpace = styled.div`display: flex; flex-direction: row; align-items: ${({ align }) => align === undefined ? 'center' : align}; ${({ gap }) => gap !== undefined && `gap:${gap}px;`} justify-content: space-between;`;
export const FlexRowStart = styled.div`display: flex; flex-direction: row; align-items: start; justify-content: space-between;`;
export const FlexRowEnd = styled.div`display: flex; flex-direction: row; justify-content: end;`;
export const FlexRowCenter = styled.div`display: flex; flex-direction: row; align-items: center; justify-content: center;`;
export const FlexColumnGap = styled.div`display: flex; flex-direction: column; gap: ${({ gap }) => gap}px;`;