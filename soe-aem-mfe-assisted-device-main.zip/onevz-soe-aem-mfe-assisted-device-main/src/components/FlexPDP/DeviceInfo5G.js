/* eslint-disable no-nested-ternary */
/* eslint-disable react/no-array-index-key */
/* eslint-disable jsx-a11y/no-noninteractive-tabindex */
/* eslint-disable you-dont-need-lodash-underscore/get */
import React, { useEffect, useContext, useState } from 'react';
import styled from 'styled-components';
import { Title, Body } from '@vds/typography';
import { Line } from '@vds/lines';

import { TextLink } from '@vds/buttons';
import { Toggle } from '@vds/toggles';
import { RadioBoxGroup } from '@vds/radio-boxes';
import { RadioSwatchGroup } from '@vds/radio-swatches';
// import { Notification } from '@vds/notifications';
// eslint-disable-next-line you-dont-need-lodash-underscore/get
import { getQueryParamByName, decodeHTMLEntities } from 'onevzsoemfecommon/Helpers';
import { formatCurrency } from 'onevzsoemfecommon/Helpers/validation';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
// eslint-disable-next-line you-dont-need-lodash-underscore/get
import { isEmpty, get, chain } from 'lodash';
import { rfexMfeFlowFlag } from 'onevzsoemfecommon/Helpers/common_functions';

// import { useLazyGetRetrieveURCodeQuery } from 'onevzsoemfecommon/CartAPIService';
import './DeviceInfo.css';
import Footer from '../../pages/PDP5G/Footer';
import { Context } from '../../pages/PDP5G/PDP5gContext';
import DeviceSimID5G from './DeviceSimID5G/DeviceSimID5G';
import { fiveGProfInstallCharges } from '../constants/DeviceConstants';
import { LIGHT_THEME_COLOR } from '../../constants/constants';
import {
  PaddingBot24,
  FlexBoxContainer,
  Padding8,
  Padding16,
  PaddingTop16,
  PaddingTop4,
} from '../CombinedGridwall/FlexGlobalStyledConstants';
import ISPUPage from './ISPUPage';
import { isFunctionalityEnabled } from '../../modules/utils';

const ImgWrapper = styled.div`
  display: flex;
  width: 252px;
  height: 312px;
`;
const PDPWrapper = styled.div`
  margin-top: 4rem;
  max-width: '1133px';
  width: 100%;
  position: 'fixed';
  display: flex;
  top: '3rem';
`;

const InfoWrapper = styled.div`
  display: flex;
  flex-direction: column;
  margin: 2rem 0;
  width: calc(100% - 4rem);
`;
// const TextWrapper = styled.div`
//   color: green;
//   font-family: 'BrandFont-Text';
// `;
const SkuWrapper = styled.div`
  display: flex;
  flex-direction: row;
  margin-top: 1rem;
`;

const PriceWrapper = styled.div`
  display: flex;
  flex-direction: row;
`;

const BackOrderWrapper = styled.div`
  float: left;
  font-weight: 700;
`;
const DiscountedPriceWrapper = styled.div`
  font-size: 24px;
  font-family: 'BrandFont-Text';
  //  u-textLineHeightNormal
`;
const FlexBoxContainerP = styled(FlexBoxContainer)`
  gap: 10px;
`;

const LeftWrapper = styled.div`
  width: 260px;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  gap: 1.2rem;
  margin-top: 0.7rem;
  z-index: 100;
`;

const RightWrapper = styled.div`
  display: flex;
  flex: 1;
  flex-direction: column;
  width: 100%;
  height: 'calc(100vh - 86px);
  overflow-y: auto;
  padding-left: 0.5rem;
`;

export const RadioSwatchGroupWrapper = styled.div`
  [class^='RadioSwatchGroupWrapper-'] {
    label:first-child {
      padding-bottom: 0.5rem;
      width: 100%;
    }
  }

  label {
    width: 2rem;
    height: 2rem;
  }
  input[type='radio']:not(:checked) + label:hover {
    box-shadow: none !important;
    border: none !important;
  }
  input[type='radio']:checked + label {
    box-shadow: rgb(0, 0, 0) 0px 0px 0px 0.0625rem;
    .colorFill {
      width: 1.5rem;
      height: 1.5rem;
    }
  }
  label::before {
    content: '' !important;
    display: none !important;
  }
  [class^='SwatchFill-'] {
    width: 2rem;
    height: 2rem;
  }
`;

const HorizontalLineWrapper = styled.div`
  padding: 1rem 0 1rem 0;
`;

const SetupTypeLabel = styled.span`
  padding: 1rem 0 1rem 0;
  font-weight: 200;
`;

const PaymentOptionsWrapper = styled.div`
  width: 90%;
  div::before {
    content: '';
    display: none;
  }
  label {
    padding: 0.5rem;
    color: #000000 !important;
    width: 300px;
    padding-bottom: 20px;
  }
  & label::before {
    content: '';
    display: none;
  }
`;

const RestrictWrapper = styled.div`
  [class^='ToggleSwitchSlider-'] {
    background-color: ${(props) => (props.disableShipIttoogle ? '#008330' : '')};
    cursor: ${(props) => (props.disableShipIttoogle ? 'not-allowed' : 'pointer')};
  }
`;

const IspuWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  cursor: pointer;
  gap: 1rem;
`;

const TextWrapper = styled.span`
  font-weight: 400;
  font-size: 18px;
}
`;

const SubTextWrapper = styled.span`
  font-size: 13px;
  max-height: 80px;
`;

function HorizontalLine() {
  return (
    <HorizontalLineWrapper>
      <Line type='secondary' surface='light' />
    </HorizontalLineWrapper>
  );
}

function DeviceInfo5G(props) {// NOSONAR
  // const [displayPaymentRadio, setDisplayPaymentRadio] = useState(false);
  const [ispuFromCart, setIspuFromCart] = useState(false);
  const [ispuToggleValEdited, setIspuToggleValEdited] = useState(false);
  const [ispuFromCarts, setIspuFromCarts] = useState(false);
  const [showDeviceModal, setShowDeviceModal] = useState(null);
  const [storeList, setStoreList] = useState(false);
  const [showOnlyAvailableStores, setShowOnlyAvailableStores] = useState(true);
  const {
    details,
    selectedSku,
    setSelectedSku,
    customerProfile,
    bundleProduct = {},
    isfiveGGemini,
    deviceFromCart,
    setInStockLabel,
    setIspuToggleOn,
    isShipItToggleOn,
    setIsShipItToggleOn,
    InStockLabel,
    isEditAndView,
    setDisableShipIttoogle,
    cartDetails,
    activeMtn,
    ispuToggleOn,
    disableShipIttoogle,
    setIsIspuItemInCart,
    selectedStore,
    setSelectedStore,
    tangleWoodQualified,
    isByodUpdate,
  } = useContext(Context);
  // const scmDeviceEnable = window?.mfe?.scmDeviceMfeEnable;
  const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable;
  // const isDark = (scmDeviceEnable && window?.mfe?.isDark) || false;
  // const details = GetDetailsResult?.deviceProduct || '';
  const [oneTimeOfferProInstallFFlag] = getAssistedCradlePropertyV2(['oneTimeOfferProInstallFFlag']);
  const productDetails = details?.productDetails || '';
  const is5gHomeSelfInstall = get(bundleProduct, 'childSkus[0].is5gHomeSelfInstall');
  const is5gHomeProfessionalInstall = get(bundleProduct, 'childSkus[0].is5gHomeProfessionalInstall');
  const { isBackorder = false, shippingDate = {} } =
    get(bundleProduct, 'childSkus[0].bundleLinks.deviceLinks[0].deviceSku.inventoryDetails.dFillInventory') || {};
  const { price = {} } = get(bundleProduct, 'childSkus[0]') || {};
  let displayName = selectedSku?.skuDisplayName;
  if (!isEmpty(bundleProduct)) {
    const { productDisplayName } = bundleProduct;
    displayName = productDisplayName;
  }
  const imageUrlMap = selectedSku && selectedSku.imageUrlMap ? selectedSku.imageUrlMap : {};
  // const skusByColor = groupByColors(details.childSkus);
  const dFillInventoryisInstock =
    get(selectedSku, 'inventoryDetails.dFillInventory.isInStock') ||
    get(productDetails?.deviceSku, 'inventoryDetails.dFillInventory.isInStock');
  const localInventoryisInstock =
    get(selectedSku, 'inventoryDetails.localInventory.isInStock') ||
    get(productDetails?.deviceSku, 'inventoryDetails.localInventory.isInStock');
  const showShipitToggle = customerProfile?.commonInfo?.showShipitToggle;
  const BtaElgible = !selectedSku?.isBillToAccount && 'Not BTA eligible';
  const cartLineInfo = cartDetails?.cart?.lineDetails?.lineInfo || [];
  const filteredLineFromCart =
    cartLineInfo?.find((line) => line?.mobileNumber === activeMtn || line?.lineNumber === activeMtn) || {};
  const deviceFromFilteredCartLine = filteredLineFromCart?.itemsInfo?.[0]?.cartItems?.cartItem?.find(
    (item) => item?.cartItemType === 'DEVICE',
  );
  const devices = {
    id: 'gw.d1',
    devicename: displayName,
    // monthlyprice: selectedSku?.price?.devicePaymentPrice,
    // total: `$${selectedSku?.price?.fullRetailPrice?.originalPrice}`,
    logo: imageUrlMap?.largeImage || '',
    mediumImage: imageUrlMap?.mediumImage,
    upgrade: true,
    upgrademsg: 'Upgrade after 50%',
    sku: selectedSku?.sorId,
    color: selectedSku?.color?.displayName,
    colorvalue: selectedSku?.color?.displayName?.trim().replace(/[^a-zA-Z]/g, ''),
  };
  const isISPUEnabled = !!customerProfile?.commonInfo?.isISPUEnabled && !is5gHomeProfessionalInstall;
  const isSecondNumber = getQueryParamByName('SecondNumber') || false;
  const displayIspuToggle =
    isISPUEnabled &&
    isEmpty(filteredLineFromCart?.edgeUpDetail) &&
    !isSecondNumber &&
    !rfexMfeFlowFlag() &&
    !tangleWoodQualified;
  const secondNumberFromSession = sessionStorage.getItem('isSecondNumDfill')
    ? JSON.parse(sessionStorage.getItem('isSecondNumDfill'))
    : '';
  const isSecondNumberFlow = !!secondNumberFromSession;
  const isSplitShipment = sessionStorage.getItem('isSplitShipment');
  const ispuDisable = /true/i.test(isSplitShipment)
    ? !selectedSku?.isInstorePickup
    : !selectedSku?.isInstorePickup ||((!scmUpgradeMfeEnable && filteredLineFromCart?.ispuItem))

  const isShipThisDevice =
    window?.mfe?.scmDeviceMfeEnable && isFunctionalityEnabled('scmPactCommonFixFFlag', 'scmShipDevice');

  // let sorId = "" ;
  // if(this.props?.deviceDetails?.deviceSku){
  //   imageUrlMap = this.props?.deviceDetails?.deviceSku.imageUrlMap;
  //   sorId = this.props?.deviceDetails?.deviceSku.sorId;
  // }
  // else{
  //   imageUrlMap = this.props?.deviceDetails?.imageUrlMap;
  //   sorId = this.props?.deviceDetails?.sorId;
  // }

  useEffect(() => {
    if (!isEmpty(details)) {
      const defaultSkuFromQueryParam = getQueryParamByName('defaultSku');
      const defaultSkuStringValue = defaultSkuFromQueryParam || details?.defaultSKU || '';
      const defaultSkuObjValue = details?.productDetails?.deviceSku?.sorId;
      const defaultSku = defaultSkuStringValue !== '' ? defaultSkuStringValue : defaultSkuObjValue;
      const defaultSkuDetails = details?.childSkus?.filter((sku) => sku.sorId && sku.sorId === defaultSku);
      setSelectedSku(defaultSkuDetails?.length > 0 ? defaultSkuDetails?.[0] : details?.childSkus?.[0]);
    }
    if (!isEmpty(bundleProduct)) {
      if (isfiveGGemini || deviceFromCart) {
        setSelectedSku(bundleProduct?.childSkus?.[0]);
      } else {
        const skuSelected = get(bundleProduct?.childSkus?.[0]?.bundleLinks?.deviceLinks?.[0], 'deviceSku', '');
        setSelectedSku(skuSelected);
      }
    }
  }, [details, bundleProduct]);

  useEffect(() => {
    if (!isEmpty(selectedSku) && (isEmpty(bundleProduct) || isfiveGGemini)) {
      const localInventory =
        get(selectedSku, 'inventoryDetails.localInventory') ||
        get(productDetails?.deviceSku, 'inventoryDetails.localInventory');
      // eslint-disable-next-line no-shadow
      const localInventoryisInstock =
        get(selectedSku, 'inventoryDetails.localInventory.isInStock') ||
        get(productDetails?.deviceSku, 'inventoryDetails.localInventory.isInStock');
      const localInventoryQty =
        get(selectedSku, 'inventoryDetails.localInventory.qtyAvailable') ||
        get(productDetails?.deviceSku, 'inventoryDetails.localInventory.qtyAvailable');

      const dFillInventoryInventory =
        get(selectedSku, 'inventoryDetails.dFillInventory') ||
        get(productDetails?.deviceSku, 'inventoryDetails.dFillInventory');
      // eslint-disable-next-line no-shadow
      const dFillInventoryisInstock =
        get(selectedSku, 'inventoryDetails.dFillInventory.isInStock') ||
        get(productDetails?.deviceSku, 'inventoryDetails.dFillInventory.isInStock');
      const dFillInventoryQty =
        get(selectedSku, 'inventoryDetails.dFillInventory.qtyAvailable') ||
        get(productDetails?.deviceSku, 'inventoryDetails.dFillInventory.qtyAvailable');
      if (!isEmpty(localInventory) && localInventoryisInstock && localInventoryQty > 0 && showShipitToggle) {
        setInStockLabel(BtaElgible);
        setIspuToggleOn(false);
        setIsShipItToggleOn(false);
      } else if (!isEmpty(dFillInventoryInventory) && dFillInventoryisInstock && dFillInventoryQty > 0) {
        setIspuToggleOn(false);
        setIsShipItToggleOn(true);
        setInStockLabel(
          `Available to ship (Available Quantity) : ${dFillInventoryQty} ${BtaElgible ? ` / ${BtaElgible}` : ''}`,
        );
      } else if (!dFillInventoryisInstock) {
        setIsShipItToggleOn(true);
        setInStockLabel('Out of Stock');
      } else {
        setIsShipItToggleOn(true);
      }

      if (isEditAndView && deviceFromFilteredCartLine && deviceFromFilteredCartLine?.depletionType) {
        let isShipItToggle;
        if (deviceFromFilteredCartLine?.depletionType === 'F') {
          isShipItToggle = true;
        } else if (deviceFromFilteredCartLine?.depletionType === 'L') {
          isShipItToggle = false;
        }
        setIsShipItToggleOn(ispuToggleOn ? false : isShipItToggle);
      }
      // if it's is5GGemini then no need to show stock label
      if (isfiveGGemini) {
        setInStockLabel('');
      }
    } else if (!isEmpty(bundleProduct)) {
      if (is5gHomeProfessionalInstall) {
        setIsShipItToggleOn(false);
      }
      if (isEditAndView && deviceFromFilteredCartLine && deviceFromFilteredCartLine?.depletionType) {
        let isShipItToggle;
        if (deviceFromFilteredCartLine?.depletionType === 'F') {
          isShipItToggle = true;
        } else if (deviceFromFilteredCartLine?.depletionType === 'L') {
          isShipItToggle = false;
        }
        setIsShipItToggleOn(ispuToggleOn ? false : isShipItToggle);
      }
    }
  }, [selectedSku]);

  useEffect(() => {
    if (isEditAndView && filteredLineFromCart?.ispuItem && !ispuToggleValEdited) {
      if (isEmpty(selectedStore)) {
        setIspuFromCart(filteredLineFromCart?.ispuItem);
      }
      /* istanbul ignore next */
      if (isShipThisDevice && ispuFromCarts) {
        setIspuFromCart(!ispuFromCarts);
      }
      /* istanbul ignore next */
      if (isShipItToggleOn && ispuFromCart) {
        setIsShipItToggleOn(false);
      }
      setDisableShipIttoogle(false);
    }
  }, [filteredLineFromCart?.ispuItem, ispuToggleOn, isShipItToggleOn, ispuFromCarts]);

  useEffect(() => {
    if (ispuToggleOn) {
      setIsShipItToggleOn(false);
      setDisableShipIttoogle(false);
    } else {
      const localInventoryStockAvailable = get(selectedSku, 'inventoryDetails.localInventory.isInStock') || false;
      if (!localInventoryStockAvailable) {
        setIsShipItToggleOn(true);
      }
    }
  }, [ispuToggleOn]);

  useEffect(() => {
    if (isShipItToggleOn) {
      setIspuToggleOn(false);
    }
  }, [isShipItToggleOn]);

  // const handlePaymentSelection = (e) => {
  //   const contract = e.target.name;
  //   let { value } = e.target;
  //   let paymentType = '';
  //   if (value.includes('-')) {
  //     [paymentType, value] = value.split('-');
  //   }
  //   console.log(contract, paymentType, value);
  //   // SelectedContractType(contract, value, false, paymentType);
  // };
  const changeShipItToggleState = () => {
    /* istanbul ignore next */
    if (isShipThisDevice) {
      setIspuFromCarts(!ispuFromCarts);
    }
    const dFillInventoryInventory =
      get(selectedSku, 'inventoryDetails.dFillInventory') ||
      get(productDetails?.deviceSku, 'inventoryDetails.dFillInventory');
    const localInventory =
      get(selectedSku, 'inventoryDetails.localInventory') ||
      get(productDetails?.deviceSku, 'inventoryDetails.localInventory');
    const dFillInventoryQty =
      get(selectedSku, 'inventoryDetails.dFillInventory.qtyAvailable') ||
      get(productDetails?.deviceSku, 'inventoryDetails.dFillInventory.qtyAvailable');
    const localInventoryQty =
      get(selectedSku, 'inventoryDetails.localInventory.qtyAvailable') ||
      get(productDetails?.deviceSku, 'inventoryDetails.localInventory.qtyAvailable');
    if (isEmpty(bundleProduct)) {
      if (!isShipItToggleOn) {
        if (!isEmpty(dFillInventoryInventory) && dFillInventoryisInstock && dFillInventoryQty > 0) {
          setInStockLabel(
            `Available to ship (Available Quantity) : ${dFillInventoryQty} ${BtaElgible ? ` / ${BtaElgible}` : ''}`,
          );
          setIsShipItToggleOn(true);
        } else {
          setDisableShipIttoogle(false);
          const labelText = 'Out of Stock';
          setInStockLabel(labelText);
        }
      } else if (BtaElgible) {
        setInStockLabel(BtaElgible);
      } else if (isShipItToggleOn && !isEmpty(localInventory) && localInventoryQty > 0 && localInventoryisInstock) {
        // for indirect no inventory check is required, as they don't have local inventory
        setIsShipItToggleOn(false);
        setInStockLabel('');
      }
      if (
        !isEmpty(dFillInventoryInventory) &&
        !isEmpty(localInventory) &&
        dFillInventoryQty > 0 &&
        localInventoryQty <= 0
      ) {
        setIsShipItToggleOn(true);
        return;
      }
    }
    setIsShipItToggleOn(!isShipItToggleOn);
  };

  const selfOrProfessionSetupMsg = () => {
    let msg = '';
    if (bundleProduct?.childSkus?.[0]?.is5gHomeSelfInstall) msg = ' | Self Setup';
    if (bundleProduct?.childSkus?.[0]?.is5gHomeProfessionalInstall) msg = ' | Professional Setup';
    return msg;
  };

  const updateDeviceData = () => {
    // setDeviceData(data);
  };
  const updateDeviceId = () => {
    // setEnteredDeviceID(data);
  };
  const updateSimId = () => {
    // setEnteredSimID(data);
  };

  const groupByColorsData = (skus) => {
    const result = chain(skus)
      .filter((sku) => sku?.color)
      .groupBy((sku) => sku?.color?.displayName)
      .map((value, key) => ({
        color: key,
        skus: value,
        colorCssStyle: value[0].color.colorCssStyle,
      }))
      .value();
    return result;
  };
  const skusByColor = groupByColorsData(details?.childSkus);
  const deviceColorOptions = skusByColor?.map((sku) => ({
    name: 'group',
    label: `${sku?.color.trim().replace(/[^a-zA-Z]/g, '')}`,
    value: sku?.color.trim().replace(/[^a-zA-Z]/g, ''),
    color: sku?.color.trim().replace(/[^a-zA-Z]/g, ''),
    fillColor: [`${sku?.colorCssStyle}`],
    outOfStock: false,
    'data-track': `Productdetail_color_${sku?.color.trim().replace(/[^a-zA-Z]/g, '')}`,
  }));
  /* istanbul ignore next */
  const chooseColor = (e) => {
    const selectedColorValue = e.target.value;
    console.log(selectedColorValue);
  };
  const handleIspuToggleChanges = () => {
    if (ispuToggleOn || ispuFromCart) {
      setIspuToggleOn(false);
      setIspuFromCart(false);
      setIspuToggleValEdited(true);
      /* istanbul ignore next */
      if (!ispuToggleOn && ispuFromCart) {
        setIsShipItToggleOn(true);
      }
    } else {
      setShowDeviceModal(true);
    }
  };

  const displayDeviceSimId = () => {
    if (
      !tangleWoodQualified &&
      (((!isShipItToggleOn || is5gHomeSelfInstall) && !is5gHomeProfessionalInstall) || isByodUpdate)
    ) {
      return true;
    }
  };
  const navigateToIspu = () => {
    setShowDeviceModal(true);
  };
  const backButtonAction = () => {
    setIspuToggleOn(ispuToggleOn || (isEditAndView && filteredLineFromCart?.ispuItem));
    setShowDeviceModal(false);
  };
  /* istanbul ignore next */
  const chooseSize = () => {};
  return (
    <PDPWrapper data-testid='pdp5g'>
      <LeftWrapper>
        <ImgWrapper>
          <img src={devices?.logo} width='205px' height='312px' alt='deviceslogo' />
        </ImgWrapper>
        {selectedSku && (
          <Footer btnLabel={props?.btnLabel} ispuItemInCart={ispuFromCart} navigateToIspu={navigateToIspu} />
        )}
      </LeftWrapper>
      <RightWrapper>
        <InfoWrapper>
          <Title color={LIGHT_THEME_COLOR} bold size='large'>
            {devices.devicename} <SetupTypeLabel>{selfOrProfessionSetupMsg()}</SetupTypeLabel>
          </Title>
          {!isByodUpdate && (
            <SkuWrapper>
              <Body color={LIGHT_THEME_COLOR} size='large'>
                {InStockLabel}
              </Body>
            </SkuWrapper>
          )}
          <SkuWrapper>
            <Body color={LIGHT_THEME_COLOR} size='large' bold>
              SKU#: {devices.sku}
            </Body>
          </SkuWrapper>
          {is5gHomeProfessionalInstall && <HorizontalLine />}
          <PriceWrapper>
            {tangleWoodQualified && (
              <div>
                <DiscountedPriceWrapper>
                  {price?.fullRetailPrice?.discountedPrice
                    ? formatCurrency(price?.fullRetailPrice?.discountedPrice)
                    : formatCurrency(price?.fullRetailPrice?.originalPrice)}
                </DiscountedPriceWrapper>
                <span>{fiveGProfInstallCharges?.freeofCharge}</span>
              </div>
            )}
            {is5gHomeProfessionalInstall && !/true/i.test(oneTimeOfferProInstallFFlag) && (
              <PaddingTop16>
                {tangleWoodQualified ? (
                  <span className='font-18 w-100 bold u-textLineHeightNormal'>Free</span>
                ) : (
                  <>
                    <span
                      className='font-18 w-100 bold u-textLineHeightNormal'
                      dangerouslySetInnerHTML={{
                        __html: fiveGProfInstallCharges?.profInstallCharge,
                      }}
                      data-testid='displayCharge'
                    />
                    <TextWrapper>{' | Professional setup fee'}</TextWrapper>
                  </>
                )}
                <span
                  className='font-14'
                  dangerouslySetInnerHTML={{
                    __html: `<br/>${fiveGProfInstallCharges?.taxesAndFees}<br/>${fiveGProfInstallCharges?.installDescription}`,
                  }}
                  data-testid='displayTaxesAndFees'
                />{' '}
              </PaddingTop16>
            )}
            {is5gHomeProfessionalInstall && /true/i.test(oneTimeOfferProInstallFFlag) && !tangleWoodQualified && (
              <PaddingTop16>
                <>
                  <span
                    className='font-18 w-100 u-textLineHeightNormal strikeText'
                    style={{ textDecoration: 'line-through', color: '#959595' }}
                    data-testid='displayStrikedOffCharge'
                    dangerouslySetInnerHTML={{
                      __html: decodeHTMLEntities(fiveGProfInstallCharges?.profInstallStrikedAmt),
                    }}
                  />
                  <span
                    className='bold'
                    data-testid='displayZeroCharge'
                    dangerouslySetInnerHTML={{
                      __html: decodeHTMLEntities(fiveGProfInstallCharges?.zeroDollarAmount),
                    }}
                  />
                  <TextWrapper>{' | Professional setup fee'}</TextWrapper>
                  <br />
                  <SubTextWrapper
                    dangerouslySetInnerHTML={{
                      __html: decodeHTMLEntities(fiveGProfInstallCharges?.limitedTimeOffer),
                    }}
                  />
                </>
              </PaddingTop16>
            )}
            <PaddingTop4>
              {isBackorder && shippingDate?.date && (
                <BackOrderWrapper style={{ color: '#0077B4' }}>
                  Back order device ships by {shippingDate.date}
                </BackOrderWrapper>
              )}
            </PaddingTop4>
          </PriceWrapper>
          {!isEmpty(deviceColorOptions) && !isEmpty(devices?.colorvalue) && !isEmpty(skusByColor) && (
            <>
              <HorizontalLine />
              <Title size='small'>Color and storage</Title>
            </>
          )}
          {!is5gHomeProfessionalInstall && (
            <FlexBoxContainerP>
              <Padding8>
                <SkuWrapper>
                  {!isEmpty(deviceColorOptions) && !isEmpty(devices?.colorvalue) && (
                    <RadioSwatchGroupWrapper>
                      <RadioSwatchGroup
                        value={devices?.colorvalue}
                        defaultValue={devices?.colorvalue}
                        data={[...deviceColorOptions]}
                        onChange={chooseColor}
                      />
                    </RadioSwatchGroupWrapper>
                  )}
                </SkuWrapper>
              </Padding8>
            </FlexBoxContainerP>
          )}
          {selectedSku?.price && (
            <>
              <HorizontalLine />
              <div className='Grid Grid--gapless paymentOptions' style={{ position: 'relative', zIndex: 0 }}>
                <Padding8>
                  <PaddingBot24>
                    <Title size='small'>Payment options</Title>
                  </PaddingBot24>
                  <PaymentOptionsWrapper>
                    <RadioBoxGroup
                      // onChange={handlePaymentSelection}
                      defaultValue={`$${selectedSku?.price?.fullRetailPrice?.originalPrice}`}
                      value={`$${selectedSku?.price?.fullRetailPrice?.originalPrice}`}
                      orientation='horizontal'
                      data={[
                        {
                          id: '1S',
                          text: `${
                            selectedSku?.price?.fullRetailPrice?.discountedPrice
                              ? formatCurrency(selectedSku?.price.fullRetailPrice.discountedPrice)
                              : formatCurrency(selectedSku?.price?.fullRetailPrice?.originalPrice)
                          }`,
                          value: `$${selectedSku?.price?.fullRetailPrice?.originalPrice}`,
                          subtext: selectedSku?.price?.fullRetailPrice?.contractText,
                          name: 'RadioBoxGroup',
                        },
                      ]}
                    />
                  </PaymentOptionsWrapper>
                </Padding8>
              </div>
            </>
          )}
          {/* Device id/sim id input placeholder */}
          {!scmUpgradeMfeEnable && displayDeviceSimId() ? (
            <>
              <Padding16>
                <Line type='secondary' surface='light' />
              </Padding16>
              <DeviceSimID5G
                customerProfileDetails={customerProfile}
                cartDetails={cartDetails}
                updateDeviceData={updateDeviceData}
                updateDeviceId={updateDeviceId}
                updateSimId={updateSimId}
                simSwapFlowUpdateButtonDisabled={() => {}}
              />
            </>
          ) : (
            ''
          )}
          <>
            <Padding16>
              <Line type='secondary' surface='light' />
            </Padding16>
            <FlexBoxContainerP>
              {displayIspuToggle && (
                <FlexBoxContainerP>
                  <FlexBoxContainerP>
                    <Title color={LIGHT_THEME_COLOR} size='small'>
                      In store pickup
                    </Title>
                    <div data-testid='ispuToggle' style={{ display: 'flex', flexDirection: 'column' }}>
                      {selectedSku?.isInstorePickup ? (
                        <IspuWrapper>
                          <Toggle
                            ariaLabel={`"Instore pickup Toggle ${ispuToggleOn ? 'On' : 'Off'}"`}
                            disabled={isSecondNumberFlow || ispuDisable}
                            showText={false}
                            value='default'
                            onChange={handleIspuToggleChanges}
                            on={ispuToggleOn || ispuFromCart}
                            surface='light'
                          />
                          {((ispuToggleOn && selectedSku?.isInstorePickup) || ispuFromCart) && (
                            <TextLink
                              type='standAlone'
                              surface='light'
                              disabled={false}
                              onClick={navigateToIspu}
                              onKeyPress={navigateToIspu}
                            >
                              Check availability
                            </TextLink>
                          )}
                        </IspuWrapper>
                      ) : (
                        <Body color={LIGHT_THEME_COLOR} size='large' bold>
                          <u>Not eligible for in store pickup</u>
                        </Body>
                      )}
                    </div>
                  </FlexBoxContainerP>
                </FlexBoxContainerP>
              )}
              {!is5gHomeSelfInstall && !isByodUpdate && !is5gHomeProfessionalInstall && !tangleWoodQualified && (
                <FlexBoxContainerP>
                  <Title color={LIGHT_THEME_COLOR} size='small'>
                    Ship this device
                  </Title>
                  <RestrictWrapper>
                    <Toggle
                      name='shipit toggle'
                      disabled={disableShipIttoogle}
                      onChange={changeShipItToggleState}
                      showText={false}
                      value='default'
                      on={isShipThisDevice ? ispuFromCarts : isShipItToggleOn}
                      surface='light'
                    />
                  </RestrictWrapper>
                </FlexBoxContainerP>
              )}
            </FlexBoxContainerP>
          </>
          {showDeviceModal ? (
            <ISPUPage
              onBack={backButtonAction}
              devices={devices}
              chooseColor={chooseColor}
              ProductDetails={details}
              showDeviceModal={showDeviceModal}
              setShowDeviceModal={setShowDeviceModal}
              deviceColorOptions={deviceColorOptions}
              cartDetails={cartDetails}
              customerProfileDetails={customerProfile}
              selectedSku={selectedSku}
              setIsIspuItemInCart={setIsIspuItemInCart}
              setSelectedStore={setSelectedStore}
              chooseSize={chooseSize}
              setIspuToggleOn={setIspuToggleOn}
              storeList={storeList}
              setStoreList={setStoreList}
              setShowOnlyAvailableStores={setShowOnlyAvailableStores}
              showOnlyAvailableStores={showOnlyAvailableStores}
              ispuSim={props?.ispuSim}
              isBYOD={false}
              setIspufromCart={setIspuFromCart}
              activeMtn={activeMtn}
            />
          ) : null}
        </InfoWrapper>
      </RightWrapper>
    </PDPWrapper>
  );
}
export default DeviceInfo5G;
