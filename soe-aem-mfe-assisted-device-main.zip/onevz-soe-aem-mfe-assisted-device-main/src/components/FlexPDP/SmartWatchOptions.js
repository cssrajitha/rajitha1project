import React from 'react';
import styled from 'styled-components';
import { Line } from '@vds/lines';
// eslint-disable-next-line you-dont-need-lodash-underscore/get
import { chain } from 'lodash';
import SmartWatchBandOptions from './SmartWatchBandOptions';
import SmartWatchSizeOptions from './SmartWatchSizeOptions';

const HorizontalLineWrapper = styled.div`
  padding: 1rem 0 1rem 0;
`;

function HorizontalLine() {
  return (
    <HorizontalLineWrapper>
      <Line type='secondary' surface='light' />
    </HorizontalLineWrapper>
  );
}

function SmartWatchOptions({ chooseSWBand, chooseSWBandSize, selectedSku, details, groupBySmartWatchBand }) {
  const skusByColor = chain(details.childSkus)
    .filter((sku) => sku && sku.color)
    .groupBy((sku) => sku && sku.color && sku.color.displayName)
    .map((value, key) => ({
      color: key,
      skus: value,
      colorCssStyle: value[0].color.colorCssStyle,
      skusGroupedBySWBand: groupBySmartWatchBand(value),
    }))
    .value();

  return (
    <>
      <SmartWatchBandOptions
        skus={skusByColor}
        selectedSku={selectedSku}
        selectedBand=''
        chooseSWBand={chooseSWBand}
        details={details}
      />
      <HorizontalLine />
      <SmartWatchSizeOptions
        skus={skusByColor}
        selectedSku={selectedSku}
        chooseSWBandSize={chooseSWBandSize}
        details={details}
      />
    </>
  );
}
export default SmartWatchOptions;
