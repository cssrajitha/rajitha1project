import { RadioSwatchGroup } from '@vds/radio-swatches';
import { Title, Body } from '@vds/typography';
import { useState, useEffect, useRef } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
// import './DeviceModel.css';
import { chain } from 'lodash';
import { DropdownSelect } from '@vds/selects';
import { Button, TextLink } from '@vds/buttons';
import { Icon } from '@vds/icons';
import { Input } from '@vds/inputs';
import { UnorderedList, ListItem } from '@vds/lists';
import { getQueryParamByName, isRetail, isTelesales } from 'onevzsoemfeframework/DomService';
import { getUIContextPathBAU } from 'onevzsoemfecommon/Helpers';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { useLazyGetCheckInStoreAvailabilityQuery } from 'onevzsoemfecommon/CommonService';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { makeOpenViewCall } from '../../modules/utils/index';
// import { useLazyGetCheckInStoreAvailabilityQuery } from '../../modules/services/APIService/APIServiceHooks';
import StoreDetails from './StoreDetails';
import { RadioSwatchGroupWrapper } from './DeviceInfo';
import { TELESALES_ISPU_SIM_SORID_CPE, TELESALES_ISPU_SIM_SORID } from './PDP_Constants';
import { DARK_THEME_COLOR, LIGHT_THEME_COLOR, DARK_THEME_BGCOLOR, LIGHT_BG_COLOR } from '../../constants/constants';

const DetailContainer = styled.div`
  padding: 6rem 10px 0px;
`;

const IspuWrapper = styled.div`
  display: flex;
  width: 85%;
  margin-top: 1.5rem;
`;

const DeviceContainer = styled.div`
  width: 66.66667% !important;
`;

const FAQContainer = styled.div`
  width: 33.33333% !important;
`;

const DeviceWrapper = styled.div`
  display: flex;
`;

const SearchWrapper = styled.div`
  padding-top: 40px !important;
  width: 80%;
`;

const ButtonWrapper = styled.div`
  display: flex;
`;

// const ColContainer = styled.div`
//   margin: 1.25rem 0;
//   box-sizing: border-box;
//   display: flex;
//   flex-flow: row wrap;
//   margin: 0 -8px 0 0.875rem;
//   padding: 0;
// `;

const RowCont = styled.div`
  display: flex;
  margin: 0.5rem 0 0.25rem 0;
  flex-direction: row;
  gap: ${({ gap }) => gap}px;
`;
const getHeaderContainerWidth = (isAcssDeviceMfe) => {
  if (isAcssDeviceMfe) {
    return window?.mfe?.isProspectNewCustomerTab ? '42%' : '71%';
  }
  return '100%';
};
const HeaderContainer = styled.div`
  border-bottom: 1px solid #d8dada;
  padding: 1.25rem;
  display: flex;
  gap: 10px;
  position: fixed;
  width: ${({ isAcssDeviceMfe }) => getHeaderContainerWidth(isAcssDeviceMfe)};
  z-index: 1;
  background:  ${({ isDarkTheme }) => (isDarkTheme ? DARK_THEME_BGCOLOR : LIGHT_BG_COLOR)};
`;
const TextWrapper = styled.div`
  padding-top: 1rem !important;
  font-size: 1rem;
  color: ${({ isDarkTheme }) => (isDarkTheme ? DARK_THEME_COLOR : LIGHT_THEME_COLOR)};
`;
const PDImgMarginRight = styled.div`
  margin-right: 1.5rem;
`;
const StoreMarginTop = styled.div`
  margin-top: 0.5rem;
`;
const FaqMarginBottom = styled.div`
  margin-bottom: 0.75rem;
`;
const ChangeDeviceLink = styled.div`
  a {
    border: none;
    font-size: 1rem;
  }
`;
const StyledUnorderedList = styled(UnorderedList)`
  & li {
    color: ${({ isDarkTheme }) => (isDarkTheme ? DARK_THEME_COLOR : LIGHT_THEME_COLOR)} !important;
  }
  
  & li * {
    color: ${({ isDarkTheme }) => (isDarkTheme ? DARK_THEME_COLOR : LIGHT_THEME_COLOR)} !important;
  }
`;
function usePrevious(value) {
  const ref = useRef();
  useEffect(() => {
    ref.current = value;
  });
  return ref.current;
}

// Helper function: Determine selected SKU based on conditions
function getSelectedSkuRequest(is5GLineCbandOrLteCheck, fivegTitanSkusList, selectedSku, isBYOD, ispuCompSim) {
  if (is5GLineCbandOrLteCheck) {
    return fivegTitanSkusList || selectedSku.sorId;
  }
  if (selectedSku && selectedSku?.sorId && !isBYOD) {
    return selectedSku.sorId;
  }
  if (isBYOD && !isTelesales()) {
    return TELESALES_ISPU_SIM_SORID_CPE;
  }
  if (isBYOD && isTelesales()) {
    return ispuCompSim;
  }
  return undefined;
}

// Helper function: Get default zip code
function getDefaultZipCode(bestBuyISPUEnableLocalOrderFFlag, cartDetails, customerProfileDetails, isBBYLocalOrder) {
  if (bestBuyISPUEnableLocalOrderFFlag && isBBYLocalOrder) {
    return sessionStorage.getItem('locationZipCode');
  }
  return (
    cartDetails?.cart?.lineDetails?.lineInfo[0]?.serviceInfo?.primaryUserInfo?.address?.zipCode ||
    customerProfileDetails?.customer?.address?.zipCode ||
    ''
  );
}

// Helper function: Check if customer is enterprise
function isEnterpriseCustomer(type) {
  return type === 'E' || type === 'PE';
}

// Helper function: Get customer type
function getCustomerType(type) {
  return isEnterpriseCustomer(type) ? 'E' : 'N';
}

// Helper function: Get 5G line check configuration
function get5GLineCheckConfig(cartDetails, customerProfileDetails, activeMtn, flexRedesign5GFFlag) {
  const { LTEQualified = false, cBandQualified = false } =
    customerProfileDetails?.customer?.qualificationDetails?.addressRequest || {};

  const lines = cartDetails?.cart?.lineDetails?.lineInfo;
  const currentLine = lines && lines.length > 0 && lines.find((item) => item?.mobileNumber === activeMtn);

  const isFiveGHomeInternetSelectedFlow = sessionStorage.getItem('fiveGHomeInternetSelectedFlow') === 'WiFi-Backup';
  const isWifiBackupDeviceSelected = isFiveGHomeInternetSelectedFlow;
  const is5gLine = !isWifiBackupDeviceSelected && currentLine && currentLine?.deviceTypeSelected === '5G Internet';
  const is5GLineCbandOrLteCheck = /true/i.test(flexRedesign5GFFlag) && is5gLine && (cBandQualified || LTEQualified);

  return { is5GLineCbandOrLteCheck };
}

// Helper function: Get exclude indirect value
function getExcludeIndirectValue(isRetailORMaverick, visionCustomerTypeValue) {
  return isRetailORMaverick ? true : !!(visionCustomerTypeValue && visionCustomerTypeValue === 'BE');
}

// Helper function: Get ISPU compatible SIM
function getIspuCompatibleSim(ispuSim) {
  return (
    ispuSim ||
    (getQueryParamByName('ispuCompatibleSIM') ? getQueryParamByName('ispuCompatibleSIM') : TELESALES_ISPU_SIM_SORID)
  );
}

// Helper function: Create request body for check in store details
function createRequestBody(
  zipCode,
  selectedSkuReq,
  customerType,
  excludeIndirectVal,
  showOnlyAvailableStores,
  dataSet,
  is5GLineCbandOrLteCheck
) {
  return {
    meta: {
      clientCorrrelationId:
        'ick-ClrSuZPeM-UmBI-2SFB6t1zB_dFDy3IfCcConCuwmPSIXyrD!1375284084!obsneocgzap08!5106!-1!1564408961747',
      timestamp: '2019-07-29T10:25:59.791-04:00',
    },
    data: {
      zipCode,
      sorIds: selectedSkuReq,
      customerType,
      excludeIndirect: excludeIndirectVal,
      range: 50,
      showOnlyAvailableStores,
      ...(!showOnlyAvailableStores ? { dataSet } : ''),
      ...(is5GLineCbandOrLteCheck ? { sorIdFilter: 'ANY' } : ''),
    },
  };
}

// Helper function: Allow only numbers
function allowOnlyNumbers(value) {
  const rE = /^[0-9\b]+$/;
  return value === '' || rE.test(value);
}

// Helper function: Group skus by capacity
function groupByCapacity(skus) {
  const result = chain(skus)
    .filter((sku) => sku && sku.capacitySize)
    .groupBy((sku) => sku && sku.capacitySize)
    .map((value) => ({
      capacity: value[0].capacity,
    }))
    .value();
  return result;
}

// Helper function: Get capacity size options
function getCapacitySizeOptions(ProductDetails) {
  const skusByCapacity = groupByCapacity(ProductDetails.childSkus);
  return skusByCapacity?.map((sku) => ({
    capacity: [`${sku.capacity}`],
  }));
}

function ISPUPage(props) { // NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk 
  let navigate = '';

  function useNavigateMFE() {
    navigate = useNavigate();
  }

  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }

  const {
    ProductDetails,
    deviceColorOptions,
    chooseColor,
    cartDetails,
    customerProfileDetails,
    selectedSku,
    setShowDeviceModal,
    onBack,
    setIsIspuItemInCart,
    setSelectedStore,
    chooseSize,
    storeList,
    setStoreList,
    setIspuToggleOn,
    setShowOnlyAvailableStores,
    showOnlyAvailableStores,
    ispuSim,
    isBYOD,
    activeMtn,
    bbyPricingDetailsResult,
    handleBestBuyPricingDetails,
    setIsDevicePricingApiCallEnable,
    isBBYLocalOrder,
  } = props;

  const prevSelectedSorId = usePrevious({ selectedSku });
  const dispatch = useDispatch();

  const channel = customerProfileDetails?.customer?.channel;
  const bestBuyISPUEnableLocalOrderFFlag =
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.bestBuyISPUEnableLocalOrderFFlag === 'TRUE';
  const defaultZipCode = getDefaultZipCode(
    bestBuyISPUEnableLocalOrderFFlag,
    cartDetails,
    customerProfileDetails,
    isBBYLocalOrder
  );

  const { cartHeader = {} } = cartDetails?.cart || {};
  const { maverickLocation = false } = cartHeader;
  const isRetailORMaverick = isRetail() || maverickLocation;
  const visionCustomerTypeValue = cartHeader?.visionCustomerType || '';

  const [zipCode, setZipCode] = useState(defaultZipCode);
  const [dataSet, setDataSet] = useState(1);
  const [selectedPage, setSelectedPage] = useState(1);
  const [zipCodeError, setZipCodeError] = useState(false);
  const [findStoreBtnClicked, setFindStoreBtnClicked] = useState(false);

  const customerTypeValue = customerProfileDetails?.customer?.customerAttributes?.customerType;
  const customerType = getCustomerType(customerTypeValue);

  const [fivegTitanSkus, flexRedesign5GFFlag] = getAssistedCradlePropertyV2([
    'fivegTitanSkus',
    'flexRedesign5GFFlag',
  ]);

  const fivegTitanSkusList = fivegTitanSkus?.split(';') ? fivegTitanSkus?.split(';') : '';
  const { is5GLineCbandOrLteCheck } = get5GLineCheckConfig(
    cartDetails,
    customerProfileDetails,
    activeMtn,
    flexRedesign5GFFlag
  );

  const excludeIndirectVal = getExcludeIndirectValue(isRetailORMaverick, visionCustomerTypeValue);
  const ispuCompSim = getIspuCompatibleSim(ispuSim);

  const selectedSkuReq = getSelectedSkuRequest(
    is5GLineCbandOrLteCheck,
    fivegTitanSkusList,
    selectedSku,
    props?.isBYOD,
    ispuCompSim
  );

  console.log(`Props${isBYOD} ispusim> ${ispuSim} telesales flag${isTelesales}`);

  const requestBodyCheckInStoreDetails = createRequestBody(
    zipCode,
    selectedSkuReq,
    customerType,
    excludeIndirectVal,
    showOnlyAvailableStores,
    dataSet,
    is5GLineCbandOrLteCheck
  );

  const [getCheckInStore, checkInStoreResult] = useLazyGetCheckInStoreAvailabilityQuery();
  const stores =
    bestBuyISPUEnableLocalOrderFFlag && isBBYLocalOrder && !bbyPricingDetailsResult?.error
      ? bbyPricingDetailsResult?.data?.stores || []
      : checkInStoreResult?.data?.stores;
  const totalStores = checkInStoreResult?.data?.numberOfStores;

  const navigateToStoreList = () => {
    dispatch(appMessageActions.clearAppMessages());
    setStoreList(true);
    setFindStoreBtnClicked(true);
    if (isBBYLocalOrder) {
      // Update sessionStorage with the new zipCode before calling the API
      sessionStorage.setItem('ispuUpdatedZipCode', zipCode);
      setIsDevicePricingApiCallEnable(true);
      handleBestBuyPricingDetails();
    } else {
      getCheckInStore({ body: requestBodyCheckInStoreDetails });
    }
  };

  const navigatetoCGW = () => {
    navigate(`${getUIContextPathBAU()}/combinedgridwall.html?fromPDP=true&activeMtn=${activeMtn}&backfrompdp=true`);
  };

  useEffect(() => {
    if (storeList && !(bestBuyISPUEnableLocalOrderFFlag && isBBYLocalOrder)) getCheckInStore({ body: requestBodyCheckInStoreDetails });
  }, [showOnlyAvailableStores, dataSet]);

  useEffect(() => {
    makeOpenViewCall('In store pick up');
  }, []);

  useEffect(() => {
    if (prevSelectedSorId?.selectedSku?.sorId !== selectedSku?.sorId) {
      navigateToStoreList();
    }
  }, [selectedSku?.sorId]);

  const handleZipcode = (e) => {
    if (e.target.value) {
      if (allowOnlyNumbers(e.target.value) && e.target.value.length <= 5) {
        setZipCode(e.target.value);
      }
      if (e.target.value.length < 5) {
        setZipCodeError(true);
      } else {
        setZipCodeError(false);
      }
    } else {
      setZipCode('');
      setZipCodeError(true);
    }
  };

  const handleToggleChange = () => {
    setShowOnlyAvailableStores((prevState) => !prevState);
  };

  const capacitySizeOptions = getCapacitySizeOptions(ProductDetails);
  const scmDeviceMfeEnable = window?.mfe?.scmDeviceMfeEnable;
  const isDarkTheme = (window?.mfe?.scmDeviceMfeEnable && window?.mfe?.isDark) || false;
  
  const getThemeColor = () => isDarkTheme ? DARK_THEME_COLOR : LIGHT_THEME_COLOR;
  const getThemeBgColor = () => isDarkTheme ? DARK_THEME_BGCOLOR : LIGHT_BG_COLOR;
  return (
    <div
      className={`${
        scmDeviceMfeEnable &&
        (window?.mfe?.isProspectNewCustomerTab ? 'prospect-acss-device-ispu-modal' : 'acss-device-ispu-modal')
      } Ispu-Modal DeviceInsurance${isDarkTheme ? ' dark-theme' : ''}`}
      style={{
        backgroundColor: getThemeBgColor(),
        color: getThemeColor()
      }}
    >
      <div
        className={`${
          window?.mfe?.isProspectNewCustomerTab ? 'Prospect-BuyoutAmount-Modal-inner' : 'BuyoutAmount-Modal-inner'
        } u-borderTopGray`}
      >
        <HeaderContainer isAcssDeviceMfe={scmDeviceMfeEnable} isDarkTheme={isDarkTheme} onClick={onBack} data-testid='onBackTestId'>
          <Icon name='left-caret' size='XLarge' medium='true' color={getThemeColor()} />
          <span
            // autoFocus='true'
            data-track='Productdetail_ISPU_back'
            style={{ borderRight: `2px solid ${getThemeColor()}` }}
            tabIndex='0'
            aria-label='Back'
            role='button'
          />

          <Title size='small' bold primitive='h1' color={getThemeColor()}>
            In-Store availability
          </Title>
        </HeaderContainer>
        <DetailContainer style={{ backgroundColor: getThemeBgColor() }}>
          <Body>
            <Body size='large' bold color={getThemeColor()}>
              Check In-Store availability
            </Body>
            <Body size='medium' color={getThemeColor()}>
              <StoreMarginTop>
                Store(s) in your area have the device(s) available for store pickup right now
              </StoreMarginTop>
            </Body>
          </Body>
          <IspuWrapper data-testid='insuranceSel'>
            <DeviceContainer>
              {!bestBuyISPUEnableLocalOrderFFlag && !isBBYLocalOrder && (
                <DeviceWrapper>
                  <PDImgMarginRight>
                    <img className='image' src={props.devices?.mediumImage} alt='Device' />
                  </PDImgMarginRight>
                  <div className='flexColContainer'>
                    <RowCont gap={8}>
                      <Title size='small' bold color={getThemeColor()}>
                        <FaqMarginBottom>{props.devices.devicename}</FaqMarginBottom>
                      </Title>
                    </RowCont>
                    <Body size='medium' bold>
                      <ChangeDeviceLink>
                        <TextLink data-testid='ChangeDevice' onClick={navigatetoCGW} style={{ color: isDarkTheme ? '#85BEFF' : undefined }}>
                          Change device
                        </TextLink>
                      </ChangeDeviceLink>
                    </Body>
                    {selectedSku.color && !props?.isBYOD ? (
                      <Body size='medium' bold>
                        <TextWrapper isDarkTheme={isDarkTheme}>Color and storage</TextWrapper>
                        {deviceColorOptions && (
                          <FaqMarginBottom>
                            <RadioSwatchGroupWrapper color={getThemeColor()}>
                              <RadioSwatchGroup
                                defaultValue={props.devices.colorvalue}
                                value={props.devices.colorvalue}
                                data={[...deviceColorOptions]}
                                onChange={chooseColor}
                                surface={isDarkTheme ? 'dark' : 'light'}
                              />
                            </RadioSwatchGroupWrapper>
                          </FaqMarginBottom>
                        )}{' '}
                      </Body>
                    ) : (
                      ''
                    )}
                    {capacitySizeOptions?.length && !props?.isBYOD ? (
                      <Body>
                        <DropdownSelect
                          label=''
                          errorText='Select a phone'
                          error={false}
                          disabled={false}
                          readOnly={false}
                          inlineLabel={false}
                          width='145px'
                          value={selectedSku?.capacity}
                          onChange={chooseSize}
                          data-track='Productdetail_ISPU_capacity'
                          surface={isDarkTheme ? 'dark' : 'light'}
                        >
                          {capacitySizeOptions.map((option) => (
                            <option key={`Item ${option.capacity}`} value={option.capacity}>
                              {option.capacity}{' '}
                            </option>
                          ))}
                        </DropdownSelect>
                      </Body>
                    ) : (
                      ''
                    )}
                  </div>
                </DeviceWrapper>
              )}
              <SearchWrapper>
                <Body size='medium' bold>
                  <FaqMarginBottom>
                    <TextWrapper isDarkTheme={isDarkTheme}>Search for a store</TextWrapper>
                  </FaqMarginBottom>
                </Body>
                <ButtonWrapper>
                  <Input
                    type='text'
                    id='zipCode'
                    value={zipCode}
                    aria-label='Zip code'
                    onChange={(e) => handleZipcode(e)}
                    width='220px'
                    autoFocus
                    error={zipCodeError}
                    data-testid='zipCode'
                    errorText={zipCodeError ? 'Please enter a valid zip code!' : ''}
                    surface={isDarkTheme ? 'dark' : 'light'}
                  />
                  <Button
                    style={{ 'margin-left': '1.75rem', 'align-self': 'flex-start' }}
                    onClick={() => navigateToStoreList()}
                  >
                    Find stores
                  </Button>
                </ButtonWrapper>
              </SearchWrapper>
            </DeviceContainer>
            <FAQContainer>
              <Body>
                <Body size='large' bold color={getThemeColor()}>
                  <FaqMarginBottom>FAQ</FaqMarginBottom>
                </Body>
                <Body style={{ display: 'flex', flexDirection: 'column' }}>
                  <FaqMarginBottom>
                    <Body
                      size='medium'
                      color={getThemeColor()}
                      aria-hidden='true'
                      role='document'
                      aria-label='To make this website accessible to screen reader, Press combination of alt and 1 keys. To stop getting this message, press the combination of alt and 2 keys'
                    >
                      How Does In-Store Pickup Work?
                    </Body>
                  </FaqMarginBottom>
                  <StyledUnorderedList isDarkTheme={isDarkTheme}>
                    <ListItem size='bodyMedium'>
                      {`Check for In-Store Pickup Availability - Search for a
                      store by zip code or by state. Product availability will
                      show for each store. Click the "Pickup From Store" button.`}
                    </ListItem>
                    <ListItem size='bodyMedium'>Place your order online.</ListItem>
                    <ListItem size='bodyMedium'>
                      We will send you an email when your order is ready at the store. Note: Please pick up your
                      items(s) within 3 days of purchase.
                    </ListItem>
                    <ListItem size='bodyMedium'>
                      Go to the store - You will need a valid government-issue photo ID to pick up your order. Only the
                      account owner or account managers will be eligible to pick up your order.
                    </ListItem>
                  </StyledUnorderedList>
                </Body>
              </Body>
            </FAQContainer>
          </IspuWrapper>

          {storeList ? (
            <StoreDetails
              stores={stores}
              handleToggleChange={handleToggleChange}
              showOnlyAvailableStores={showOnlyAvailableStores}
              setShowDeviceModal={setShowDeviceModal}
              setIsIspuItemInCart={setIsIspuItemInCart}
              setSelectedStore={setSelectedStore}
              setDataSet={setDataSet}
              selectedPage={selectedPage}
              setSelectedPage={setSelectedPage}
              totalStores={totalStores}
              selectedSku={selectedSku}
              setIspuToggleOn={setIspuToggleOn}
              setStoreList={setStoreList}
              setIspufromCart={props?.setIspufromCart}
              ProductDetails={ProductDetails}
              activeMtn={activeMtn}
              customerProfileDetails={customerProfileDetails}
              checkInStoreResult={checkInStoreResult}
              findStoreBtnClicked={findStoreBtnClicked}
              setFindStoreBtnClicked={setFindStoreBtnClicked}
              cartDetails={cartDetails}
              bestBuyISPUEnableLocalOrderFFlag={bestBuyISPUEnableLocalOrderFFlag}
              isBBYLocalOrder={isBBYLocalOrder}
              BbyLocalOrderLocDetailsRequest={props.BbyLocalOrderLocDetailsRequest}       
              BbyLocalOrderLocDetailsApiResponse={props.BbyLocalOrderLocDetailsApiResponse}
              isDarkTheme={isDarkTheme}
            />
          ) : null}
        </DetailContainer>
      </div>
    </div>
  );
}

export default ISPUPage;

// Export helper functions for testing
export {
  getSelectedSkuRequest,
  getDefaultZipCode,
  isEnterpriseCustomer,
  getCustomerType,
  get5GLineCheckConfig,
  getExcludeIndirectValue,
  getIspuCompatibleSim,
  createRequestBody,
  allowOnlyNumbers,
  groupByCapacity,
  getCapacitySizeOptions,
};
