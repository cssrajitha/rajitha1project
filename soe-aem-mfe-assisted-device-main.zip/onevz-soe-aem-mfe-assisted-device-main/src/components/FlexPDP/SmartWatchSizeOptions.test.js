import React from 'react';
import SmartWatchSizeOptions from './SmartWatchSizeOptions';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { render, screen } from '../../modules/test-utils/renderHelper';

describe('smartWatch size component render', () => {
  const props = {
    selectedSku: {},
    skus: undefined,
  };
  beforeEach(() => {
    render(<SmartWatchSizeOptions {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('it should mount', () => {
    render(<SmartWatchSizeOptions {...props} />);
  });
});

describe('smartWatch size component render', () => {
  const props = {
    selectedSku: { skuFilters: { band: 'band', size: 124 }, color: { displayName: 'red' } },
    skus: [
      {
        color: 'red',
        skusGroupedBySWBand: [{ band: 'band', bandSkus: [{ sizeInInteger: [{ skuFilters: { size: 124 } }] }] }],
      },
    ],
  };
  beforeEach(() => {
    render(<SmartWatchSizeOptions {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('it should mount', () => {
    const smartWatchSizeId = screen.getByTestId('smartWatchSizeOptions');
    expect(smartWatchSizeId).toBeInTheDocument();
  });
});
