import { fireEvent } from '@testing-library/react';
import React from 'react';
import OmniCareDropDownOptions from './OmniCareDropDownOptions';
import { render, screen } from '../../modules/test-utils/renderHelper';
import { isFunctionalityEnabled } from '../../modules/utils';

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradlePropertyV2: () => ['TRUE'],
  }),
  { virtual: true },
);

jest.mock('../../modules/utils', () => ({
  isFunctionalityEnabled: jest.fn(),
}));

const mockSkuDetailsResult = (parentProducts) => ({
  data: {
    data: {
      deviceSku: {
        parentProducts,
      },
    },
  },
});

describe('OmniCareDropDownOptions Provisional ID Logic Coverage', () => {
  const props = {
    handleDeviceIdSkuHandler: jest.fn(),
    customerProfileDetails: {
      customer: {
        billAccounts: [
          {
            mtns: [
              {
                mtn: 1234567890,
                equipmentInfos: [
                  {
                    deviceInfo: {
                      deviceId: 'device1',
                    },
                  },
                ],
              },
            ],
          },
        ],
      },
    },
    cartDetails: {
      cart: {
        lineDetails: {
          lineInfo: [
            {
              mobileNumber: 1234567890,
              itemsInfo: [
                {
                  cartItems: {
                    cartItem: [
                      {
                        cartItemType: 'DEVICE',
                        deviceId: 'device2',
                      },
                    ],
                  },
                },
              ],
            },
          ],
        },
      },
    },
    activeMtn: 1234567890,
  };
  const baseProps = {
    handleDeviceIdSkuHandler: jest.fn(),
    customerProfileDetails: props.customerProfileDetails, // Re-use existing setup
    cartDetails: props.cartDetails,
    activeMtn: 1234567890,
    SkuDetailsResult: mockSkuDetailsResult([]), // Will be updated per test
  };

  beforeEach(() => {
    window.mfe = { scmDeviceMfeEnable: true, scmProvisionalFFlag: true };
    // Assuming device_id is handled and is not 'undefined'
  });

  test('should include Provisional ID when feature flag is enabled', () => {
    isFunctionalityEnabled.mockReturnValue(true);

    render(<OmniCareDropDownOptions {...baseProps} SkuDetailsResult={mockSkuDetailsResult([])} />);
    expect(screen.getByText('Provisional ID')).toBeInTheDocument();
  });

  test('should include Provisional ID when feature flag is disabled but no 5G products', () => {
    isFunctionalityEnabled.mockReturnValue(false);

    render(
      <OmniCareDropDownOptions
        {...baseProps}
        SkuDetailsResult={mockSkuDetailsResult([{ sorDeviceCategory: 'Mobile Phone' }])}
      />,
    );

    expect(screen.getByText('Provisional ID')).toBeInTheDocument();
  });

  test('should include Provisional ID when feature flag is disabled AND a 5G product is found', () => {
    isFunctionalityEnabled.mockReturnValue(true); // isFunctionalityEnabled is FALSE

    render(
      <OmniCareDropDownOptions
        {...baseProps}
        SkuDetailsResult={mockSkuDetailsResult([{ sorDeviceCategory: '5G Internet' }])}
      />,
    );
    expect(screen.queryByText('Provisional ID')).toBeInTheDocument();
  });
});

describe('OmniCareDropDownOptions component render', () => {
  const props = {
    handleDeviceIdSkuHandler: jest.fn(),
    customerProfileDetails: {
      customer: {
        billAccounts: [
          {
            mtns: [
              {
                mtn: 1234567890,
                equipmentInfos: [
                  {
                    deviceInfo: {
                      deviceId: 'device1',
                    },
                  },
                ],
              },
            ],
          },
        ],
      },
    },
    cartDetails: {
      cart: {
        lineDetails: {
          lineInfo: [
            {
              mobileNumber: 1234567890,
              itemsInfo: [
                {
                  cartItems: {
                    cartItem: [
                      {
                        cartItemType: 'DEVICE',
                        deviceId: 'device2',
                      },
                    ],
                  },
                },
              ],
            },
          ],
        },
      },
    },
    activeMtn: 1234567890,
  };
  test('should render OmniCareDropDownOptions component', () => {
    render(<OmniCareDropDownOptions {...props} />);
    expect(screen.getByTestId('devicesimonlyChange')).toBeInTheDocument();
  });
  test('should render OmniCareDropDownOptions component with DEVICE_CHANGE value', () => {
    window.mfe = { scmDeviceMfeEnable: true, scmProvisionalFFlag: true, isDark: true };
    render(<OmniCareDropDownOptions {...props} />);
    expect(screen.getByTestId('devicesimonlyChange')).toBeInTheDocument();
  });

  test('should render OmniCareDropDownOptions component with DEVICE_CHANGE value', () => {
    window.mfe = { scmDeviceMfeEnable: true };
    render(<OmniCareDropDownOptions {...props} />);
    expect(screen.getByTestId('devicesimonlyChange')).toBeInTheDocument();
    screen.logTestingPlaygroundURL();
    const MoreOptionsId1 = screen.getByTestId('devicesimonlyChange', {
      name: /Optional/i,
    });
    fireEvent.click(MoreOptionsId1);
    fireEvent.change(MoreOptionsId1, { target: { value: 'Device change' } });

    fireEvent.change(MoreOptionsId1, { target: { value: 'SIM only change' } });

    fireEvent.change(MoreOptionsId1, { target: { value: 'Provisional ID' } });

    fireEvent.change(MoreOptionsId1, { target: { value: '' } });

    // expect(MoreOptionsId).not.toBeDisabled();
    // fireEvent.click(MoreOptionsId);

    // fireEvent.change(MoreOptionsId, { target: { value: 'DEVICE_CHANGE' } });
  });
});
describe('OmniCareDropDownOptions component render', () => {
  const props = {
    handleDeviceIdSkuHandler: jest.fn(),
    customerProfileDetails: {
      customer: {
        billAccounts: [
          {
            mtns: [
              {
                mtn: 1234567890,
                equipmentInfos: [
                  {
                    deviceInfo: {
                      deviceId: 'device1',
                    },
                  },
                ],
              },
            ],
          },
        ],
      },
    },
    cartDetails: {
      cart: {
        lineDetails: {
          lineInfo: [
            {
              mobileNumber: 1234567890,
              itemsInfo: [
                {
                  cartItems: {
                    cartItem: [
                      {
                        cartItemType: 'DEVICE',
                        deviceId: 'device2',
                      },
                    ],
                  },
                },
              ],
            },
          ],
        },
      },
    },
    activeMtn: 1234567890,
    removeSimOnlyChange: true,
  };
  test('should render OmniCareDropDownOptions component', () => {
    render(<OmniCareDropDownOptions {...props} />);
    expect(screen.getByTestId('devicesimonlyChange')).toBeInTheDocument();
  });
});
describe('OmniCareDropDownOptions component render with scmUpgradeMfeEnable true', () => {
  const props = {
    handleDeviceIdSkuHandler: jest.fn(),
    customerProfileDetails: {
      customer: {
        billAccounts: [
          {
            mtns: [
              {
                mtn: 1234567890,
                equipmentInfos: [
                  {
                    deviceInfo: {
                      deviceId: 'device1',
                    },
                  },
                ],
              },
            ],
          },
        ],
      },
    },
    cartDetails: {
      cart: {
        lineDetails: {
          lineInfo: [
            {
              mobileNumber: 1234567890,
              lineNumber: 'newLine1',
              itemsInfo: [
                {
                  cartItems: {
                    cartItem: [
                      {
                        cartItemType: 'DEVICE',
                        deviceId: 'device2',
                      },
                    ],
                  },
                },
              ],
            },
          ],
        },
      },
    },
    activeMtn: 1234567890,
    isNewLine: true,
  };
  beforeAll(() => {
    window.mfe = { scmUpgradeMfeEnable: true };
  });
  afterAll(() => {
    window.mfe = { scmUpgradeMfeEnable: false };
  });
  test('should render OmniCareDropDownOptions component', () => {
    render(<OmniCareDropDownOptions {...props} />);
    expect(screen.getByTestId('devicesimonlyChange')).toBeInTheDocument();
  });
  test('should render OmniCareDropDownOptions component with DEVICE_CHANGE value', () => {
    window.mfe = { scmDeviceMfeEnable: true, scmProvisionalFFlag: true, isDark: true };
    render(<OmniCareDropDownOptions {...props} />);
    expect(screen.getByTestId('devicesimonlyChange')).toBeInTheDocument();
  });

  test('should render OmniCareDropDownOptions component with DEVICE_CHANGE value', () => {
    window.mfe = { scmDeviceMfeEnable: true };
    render(<OmniCareDropDownOptions {...props} />);
    expect(screen.getByTestId('devicesimonlyChange')).toBeInTheDocument();
    screen.logTestingPlaygroundURL();
    const MoreOptionsId1 = screen.getByTestId('devicesimonlyChange', {
      name: /Optional/i,
    });
    fireEvent.click(MoreOptionsId1);
    fireEvent.change(MoreOptionsId1, { target: { value: 'Device change' } });

    fireEvent.change(MoreOptionsId1, { target: { value: 'SIM only change' } });

    fireEvent.change(MoreOptionsId1, { target: { value: 'Provisional ID' } });

    fireEvent.change(MoreOptionsId1, { target: { value: '' } });
  });
});

describe('Test OmniCareDropDownOptions component render with scmDeviceMfeEnable= true & isShowGetESIM = true', () => {
  const props = {
    handleDeviceIdSkuHandler: jest.fn(),
    customerProfileDetails: {
      customer: {
        billAccounts: [
          {
            mtns: [
              {
                mtn: 1234567890,
                equipmentInfos: [
                  {
                    deviceInfo: {
                      deviceId: 'device1',
                    },
                  },
                ],
              },
            ],
          },
        ],
      },
    },
    cartDetails: {
      cart: {
        lineDetails: {
          lineInfo: [
            {
              mobileNumber: 1234567890,
              lineNumber: 'newLine1',
              itemsInfo: [
                {
                  cartItems: {
                    cartItem: [
                      {
                        cartItemType: 'DEVICE',
                        deviceId: 'device2',
                      },
                    ],
                  },
                },
              ],
            },
          ],
        },
      },
    },
    activeMtn: 1234567890,
    isShowGetESIM: true,
  };
  beforeAll(() => {
    window.mfe = { scmDeviceMfeEnable: true };
  });
  afterAll(() => {
    window.mfe = { scmDeviceMfeEnable: false };
  });

  test('should render OmniCareDropDownOptions component with Generate ESIM Profile value', () => {
    window.mfe = { scmDeviceMfeEnable: true };
    render(<OmniCareDropDownOptions {...props} />);
    expect(screen.getByTestId('devicesimonlyChange')).toBeInTheDocument();
    screen.logTestingPlaygroundURL();
    const MoreOptionsId1 = screen.getByTestId('devicesimonlyChange', {
      name: /Optional/i,
    });
    fireEvent.click(MoreOptionsId1);
    fireEvent.change(MoreOptionsId1, { target: { value: 'Generate ESIM Profile' } });
  });
});
