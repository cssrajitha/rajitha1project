import { Button, ButtonGroup } from '@vds/buttons';
import { Modal, ModalTitle } from '@vds/modals';
import { Body } from '@vds/typography';
import { RadioButtonGroup } from '@vds/radio-buttons';
import styled from 'styled-components';
import { PaddingTop20 } from '../CombinedGridwall/FlexGlobalStyledConstants';

const SubStyle = styled.div`
  padding: 1.5rem 0;
`;

function CustomModal({ continueClickHandler }) {
  return (
    <Modal
      toggleButton={<Button surface='light'> Show Modal </Button>}
      surface='light'
      fullScreenDialog={false}
      disableAnimation={false}
      disableOutsideClick={false}
      ariaLabel='Testing Modal'
      width={560}
    >
      <ModalTitle>The selected device and offer are incompatible</ModalTitle>
      <SubStyle>
        <Body size='large' primitive='p'>
          Please select one from the below options to continue shopping.
        </Body>
      </SubStyle>
      <RadioButtonGroup
        // onChange={() => {}}
        error={false}
        data={[
          {
            name: 'group',
            label: 'Continue with selected device',
            children: 'This will drop the selected offer',
            value: 'radioOne',
            ariaLabel: 'radio one',
            disabled: false,
          },
          {
            name: 'group',
            label: 'Continue with selected offer',
            children: 'This will drop the selected device. You can select another compatible device with this offer.',
            value: 'radioTwo',
            ariaLabel: 'radio two',
          },
        ]}
      />
      <PaddingTop20>
        <ButtonGroup
          childWidth='100%'
          rowQuantity={{ desktop: 1 }}
          data={[
            {
              children: 'Continue',
              size: 'large',
              use: 'primary',
              width: 'auto',
              onClick: continueClickHandler,
            },
          ]}
          alignment='left'
        />
      </PaddingTop20>
    </Modal>
  );
}
export default CustomModal;
