import { TextLink, Button } from '@vds/buttons';
import { Body } from '@vds/typography';
import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import { getQueryParamByName, getUIContextPathBAU } from 'onevzsoemfecommon/Helpers';
import PropTypes from 'prop-types';
import DownPaymentDevice from 'onevzsoemfecommon/DownPaymentDevice';
import { isD2D, isAsurion, isIndirect } from 'onevzsoemfeframework/DomService';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { Modal, ModalBody } from '@vds/modals';
import { Line } from '@vds/lines';
import { rfexMfeFlowFlag } from 'onevzsoemfecommon/Helpers/common_functions';
import { getSCMFilteredDfillAndBulkSims, isFunctionalityEnabled, makeOpenViewCall } from '../../modules/utils/index';
import Header from './Header';
import ComatibleSims from './MoreOptions/CompatibleSims';
import DownPayment from './MoreOptions/DownPayment';
import ByodED from './MoreOptions/ByodED';
import UpgradeReason from './MoreOptions/UpgradeReason';
import { contractTerms } from '../../constants/ContractTerms';
import { isVbg } from 'onevzsoemfeframework/VbgAemUtil';
import FFLAGS from '../../constants/fFlag.constant';

const scmDeviceEnable = window?.mfe?.scmDeviceMfeEnable || false;

const CustomBox = styled.div`
  box-sizing: border-box;
  background-color: rgb(255, 255, 255);
  border: 0.0625rem solid rgb(217, 217, 217);
  border-radius: 1rem;
  left: 87%;
  top: 4rem;
  position: absolute;
  padding: 0.75rem 0.75rem 0px;
  min-height: auto;
  height: fit-content;
  max-width: 19rem;
  min-width: 17rem;
  text-align: left;
  transform: translateX(-50%);
  visibility: visible;
  width: 9rem;
  z-index: 998;
  outline: none;
  bottom: 1.875rem;
`;

const BottomBorder = styled.div`
  padding: 0.75rem 0;
  border-bottom: 1px solid lightgray;
  cursor: pointer;
`;
const LinkWrap = styled.div`
  [class^='StyledAnchor-'] {
    border-bottom-style: none;
  }
  a {
    border-bottom-style: none;
  }
`;

const ModelWrap = styled(Modal)`
  padding: 0px;
  max-width: 1133px;
  margin: 0 auto;
`;
const HorizontalLineWrapper = styled.div`
  padding: 1.5rem 2rem 1rem 2rem;
`;
const BtnCenter = styled.div`
  margin: 0 auto;
  width: 10%;
`;
const FooterWraper = styled.div`
position: ${scmDeviceEnable ? /* istanbul ignore next */ '' : 'fixed'}
bottom: 2rem;
width: 100%;
max-width: 1133px;
`;

let navigate = '';

function useNavigateMFE() {
  navigate = useNavigate();
}

const showDownPaymentLink = ({ deviceContract, isInStock, isByod, elvisFFlag, bbPaymentOptionsSelected }) => {
  const isEligibleContract = deviceContract && deviceContract !== 'MONTH_TO_MONTH';
  const isVbgNSAEnabled = isVbg();
  const isTermCompatible = !isVbgNSAEnabled || (contractTerms && !Object.values(contractTerms).includes(deviceContract));
  const isValidProductState = isInStock &&
    !isByod &&
    (isVbgNSAEnabled || !elvisFFlag) &&
    !bbPaymentOptionsSelected;
  const showDownPaymentLink = isEligibleContract && isTermCompatible && isValidProductState;
  return showDownPaymentLink;
};
const scmBulkDFillSimFixEnabled = isFunctionalityEnabled(FFLAGS?.scmCommonDefectFixFFlag?.name, FFLAGS?.scmCommonDefectFixFFlag?.attribute?.scmBulkDFillSimFix, FFLAGS?.scmCommonDefectFixFFlag?.attribute?.scmBulkDFillSimDbFlag);

const MoreOptions = (props) => { /* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */
  try {
    useNavigateMFE();
  } catch (e) {
    console.log('');
  }

  const {
    productDetails,
    CustomerData,
    mtn,
    selectedSku,
    setUpgradeReasonType,
    deviceContract,
    isRfexFlow,
    isNewLine,
    isFromCPE,
    orderDetails,
    selectedPaymentInfo,
    isInStock,
    CustomerProfileCommonInfo,
    cartDetails,
    activeMtn,
    computeDPPriceBody,
    computeDPPriceResult,
    isDownPaymentAlertNeedToEnable,
    setIsDownPaymentAlertNeedToEnable,
    setDownPaymentObj,
    downPaymentObj,
    retailPrice,
    bbPaymentOptionsSelected,
    bbyContractTerm,
  } = props;
  const isDark = (window?.mfe?.scmDeviceMfeEnable && window?.mfe?.isDark) || false;
  const [bestBuyIntegrationFFlag] = getAssistedCradlePropertyV2(['bestBuyIntegrationFFlag']);
  const cleanUpEmitterFFlag = /true/i.test(getAssistedCradlePropertyV2(['cleanUpEmitterFFlag'])?.[0]);
  const elvisFromSession = sessionStorage.getItem('elvisFFlag');
  const elvisFFlag = /true/i.test(elvisFromSession);
  const fromPDP = true;
  const tradeinLinkEnabled = productDetails?.commonInfo?.flexPDPTradeInLinkEnabled;
  let compatibleSimSorIds =
    productDetails?.deviceProduct?.compatibleSimSorIds ||
    productDetails?.deviceSku?.parentProducts?.[0]?.compatibleSimSorIds;

  if (window?.mfe?.scmDeviceMfeEnable && scmBulkDFillSimFixEnabled) {
    compatibleSimSorIds = getSCMFilteredDfillAndBulkSims(compatibleSimSorIds);
  }

  const [moreOptionList, setMoreOptionList] = useState(false);
  const [selectedOption, setSelectedOption] = useState('');
  const ref = useRef(null);
  const { displayReasonCode = false } = productDetails?.commonInfo || {};
  const isByod = getQueryParamByName('isByodUpdate') || getQueryParamByName('isFromCPE');

  const options = [
    isRfexFlow || (displayReasonCode && !isFromCPE && !isNewLine && (!isD2D() || isAsurion()))
      ? { label: 'View upgrade reason code' }
      : null,
    !rfexMfeFlowFlag() &&
    !isIndirect() &&
    !isByod &&
    (tradeinLinkEnabled || CustomerProfileCommonInfo?.showTradeinTab) &&
    (!isD2D() || isAsurion())
      ? { label: 'Trade In' }
      : null,
    (!isD2D() || isAsurion()) && !isIndirect() ? { label: 'BYOD Eligibility Details' } : null,
    showDownPaymentLink({ deviceContract, isInStock, isByod, elvisFFlag, bbPaymentOptionsSelected })
      ? { label: 'Down Payment' }
      : null,
    { label: 'Compatible Sims' },
  ];
  const isOptionsHasNull = options?.filter((item) => item !== null);
  const moreOptionClickHandler1 = () => {
    setMoreOptionList(!moreOptionList);
  };

  useEffect(() => {
    const useOnClickOutside = (e) => {
      const outsideClick = e.target.closest('#dropdownContainer');
      if (ref.current && !ref.current.contains(e.target) && !outsideClick) {
        setMoreOptionList(false);
      }
    };
    document.addEventListener('mousedown', useOnClickOutside);
    return () => {
      cleanUpEmitterFFlag && document.removeEventListener('mousedown', useOnClickOutside);
    };
  }, []);

  const moreOptionsSelected = (e) => {
    setSelectedOption(e);
    makeOpenViewCall(e);
    if (e === 'Trade In') {
      navigate(`${getUIContextPathBAU()}/shop-tradein.html?isFromPDP${fromPDP}`);
    }
  };

  let headerTitle;
  if (selectedOption === 'View upgrade reason code') {
    headerTitle = 'Upgrade reason code';
  } else if (selectedOption === 'BYOD Eligibility Details') {
    headerTitle = 'BYOD Details';
  } else if (selectedOption === 'Down Payment') {
    headerTitle = 'Device Balance Due Today/Down Payments';
  } else if (selectedOption === 'Compatible Sims') {
    headerTitle = 'Compatible SIMs';
  } else {
    headerTitle = selectedOption;
  }
  const handleClick = () => {
        /* istanbul ignore next */

    if(!scmDeviceEnable){
      navigate(-1);
    }
    setSelectedOption('');
  };
  const headerData = {
    header: headerTitle,
    line: '',
    mdn: '',
    closeIcon: { popupModalclose: false },
    closeClickHandler: handleClick,
  };

  const lineDetails = CustomerData?.billAccounts[0]?.mtns?.filter((mtns) => mtns?.mtn === props.mtn);
  const activeMtnEqpInfo = lineDetails?.[0]?.equipmentInfos[0] ? lineDetails?.[0]?.equipmentInfos[0] : {};
  const { deviceInfo = {} } = activeMtnEqpInfo;
  const { deviceId = '' } = deviceInfo;
  const cartLineInfo = cartDetails?.cart?.lineDetails?.lineInfo || [];
  const filteredLineFromCart =
    cartLineInfo?.find((line) => line?.mobileNumber === activeMtn || line?.lineNumber === activeMtn) || {};

  const footerSection = () => (
    <FooterWraper scmDeviceEnable={scmDeviceEnable}>
      <HorizontalLineWrapper>
        <Line type='secondary' surface={isDark ? 'dark' : 'light'} />
      </HorizontalLineWrapper>
      <BtnCenter>
        <Button
          data-testid='DownPaymentBtn'
          size='large'
          width='125px'
          disabled={false}
          use='primary'
          onClick={handleClick}
          surface={isDark ? 'dark' : 'light'}
        >
          {selectedOption === 'Down Payment' ? 'Done' : 'Ok'}
        </Button>
      </BtnCenter>
    </FooterWraper>
  );
  return (
    <>
        <TextLink type='standAlone' onClick={moreOptionClickHandler1} surface={isDark ? 'dark' : 'light'}>
          More options
        </TextLink>
      {moreOptionList && (
        <CustomBox ref={ref} id='dropdownContainer'>
          {isOptionsHasNull.map((mopt) => (
            <BottomBorder
              data-testid='mpre-options'
              onClick={() => moreOptionsSelected(mopt.label)}
              key={`${mopt.label}_opt`}
            >
              <Body data-testid='moreOptions' size='small' key={mopt.label} data-track={`more-options_${mopt.label}`}>
                <LinkWrap>
                  <TextLink type='standAlone' size='large'>
                    {mopt.label}
                  </TextLink>
                </LinkWrap>
              </Body>
            </BottomBorder>
          ))}
        </CustomBox>
      )}
      {selectedOption === 'View upgrade reason code' && (
        <UpgradeReason
          mtn={mtn}
          productDetails={productDetails}
          deviceContract={deviceContract}
          setUpgradeReasonType={setUpgradeReasonType}
          headerData={headerData}
          selectedOption={selectedOption}
          footerSection={footerSection}
        />
      )}
      {selectedOption && selectedOption !== 'View upgrade reason code' && (
        <ModelWrap
          id='modalcontainer1'
          opened={selectedOption}
          surface={isDark ? 'dark' : 'light'}
          fullScreenDialog = {!scmDeviceEnable}
          disableAnimation={false}
          disableOutsideClick
          closeButton={null}
          ariaLabel='Testing Modal'
        >
          {selectedOption !== 'View upgrade reason code' && !isIndirect() && /false/i.test(bestBuyIntegrationFFlag) && (
            /* istanbul ignore next */
            <Header data={headerData} closePopup={scmDeviceEnable}/>
          )}
          <ModalBody>
            {selectedOption === 'BYOD Eligibility Details' && <ByodED deviceIdNum={deviceId} />}
            {selectedOption === 'Down Payment' && (isIndirect() || /true/i.test(bestBuyIntegrationFFlag)) && (
              <DownPaymentDevice
                CustomerData={CustomerData}
                selectedSku={selectedSku}
                mtn={mtn}
                orderDetails={orderDetails}
                paymentObject={selectedPaymentInfo}
                filteredLineFromCart={filteredLineFromCart}
                isDownPaymentAlertNeedToEnable={isDownPaymentAlertNeedToEnable}
                setIsDownPaymentAlertNeedToEnable={setIsDownPaymentAlertNeedToEnable}
                setDownPaymentObj={setDownPaymentObj}
                downPaymentObj={downPaymentObj}
                fromPage='PDP'
                retailPrice={retailPrice}
                closeClickHandler={handleClick}
                bbyContractTerm={bbyContractTerm}
              />
            )}
            {selectedOption === 'Down Payment' && !isIndirect() && /false/i.test(bestBuyIntegrationFFlag) && (
              <DownPayment
                CustomerData={CustomerData}
                selectedSku={selectedSku}
                mtn={mtn}
                orderDetails={orderDetails}
                paymentObject={selectedPaymentInfo}
                filteredLineFromCart={filteredLineFromCart}
                computeDPPriceBody={computeDPPriceBody}
                computeDPPriceResult={computeDPPriceResult}
                isDownPaymentAlertNeedToEnable={isDownPaymentAlertNeedToEnable}
                setIsDownPaymentAlertNeedToEnable={setIsDownPaymentAlertNeedToEnable}
                setDownPaymentObj={setDownPaymentObj}
                downPaymentObj={downPaymentObj}
                customerTypefromCart={cartDetails?.cart?.orderDetails?.customerType}
                retailPrice={retailPrice}
              />
            )}
            {selectedOption === 'Compatible Sims' && <ComatibleSims compatibleSimSorIds={compatibleSimSorIds} />}
            {(selectedOption === 'View upgrade reason code' ||
              selectedOption === 'Compatible Sims' ||
              (selectedOption === 'Down Payment' && !isIndirect() && /false/i.test(bestBuyIntegrationFFlag))) && (
              <>{footerSection()}</>
            )}
          </ModalBody>
        </ModelWrap>
      )}
    </>
  );
};
export default MoreOptions;

MoreOptions.propTypes = {
  productDetails: PropTypes.object.isRequired,
  CustomerData: PropTypes.object.isRequired,
  mtn: PropTypes.string.isRequired,
  selectedSku: PropTypes.string.isRequired,
  setUpgradeReasonType: PropTypes.func.isRequired,
  deviceContract: PropTypes.object.isRequired,
  isRfexFlow: PropTypes.bool.isRequired,
  isNewLine: PropTypes.bool.isRequired,
  isFromCPE: PropTypes.bool.isRequired,
  orderDetails: PropTypes.object.isRequired,
  selectedPaymentInfo: PropTypes.object.isRequired,
  isInStock: PropTypes.bool.isRequired,
  CustomerProfileCommonInfo: PropTypes.object.isRequired,
  cartDetails: PropTypes.object.isRequired,
  activeMtn: PropTypes.string.isRequired,
  computeDPPriceBody: PropTypes.object.isRequired,
  computeDPPriceResult: PropTypes.object.isRequired,
  isDownPaymentAlertNeedToEnable: PropTypes.bool.isRequired,
  setIsDownPaymentAlertNeedToEnable: PropTypes.func.isRequired,
  setDownPaymentObj: PropTypes.func.isRequired,
  downPaymentObj: PropTypes.object.isRequired,
  retailPrice: PropTypes.number.isRequired,
  bbyContractTerm: PropTypes.any.isRequired,
};
