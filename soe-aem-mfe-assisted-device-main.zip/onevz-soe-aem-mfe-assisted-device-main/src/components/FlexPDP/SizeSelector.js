import React from 'react';
// import sortBy from 'lodash/sortBy';
import { isEmpty, chain, sortBy } from 'lodash';
import { RadioBoxGroup } from '@vds/radio-boxes';
import PropTypes from 'prop-types';
import styled from 'styled-components';

const RadioBoxWrap = styled.div`
  [class^='RadioBoxGroupWrapper-'] {
    gap: 10px;
  }
  div {
    label {
      padding: 0.5rem;
      ::before {
        content: '';
        display: none;
      }
    }
  }
`;
const RadioStorageWrapper = styled.div`
  [class^='RadioBoxLabelWrapper-'] {
    align-items: center;
    border-radius: 4px;
    border: 1px solid rgb(111, 113, 113);
    display: block;
    flex: 0 0 200px;
    font-size: 1rem;
    letter-spacing: 0.03125rem;
    line-height: 1.25rem;
    font-family: Verizon-NHG-eDS;
    height: 100%;
    min-height: 2.75rem;
    position: relative;
    width: 200px;
    max-width: 100%;
    box-sizing: border-box;
    background-color: rgb(255, 255, 255);
    color: rgb(0, 0, 0);
    outline: 0px;
  }
  [class^='StyledDiv-'] {
    height: 100%;
  }
`;

function SizeSelector(props) {
  const { skus, selectedSku = {}, chooseSize } = props;
  const { color = {} } = selectedSku;
  if (!skus || !color) {
    return '';
  }
  const defaultSkuCapacity = selectedSku && selectedSku.capacity;
  const colorObj = skus?.length > 0 && skus.filter((sku) => sku.color === color.displayName);
  const sizeSkus = (colorObj && colorObj[0] && colorObj[0].skus) || [];
  const skusSorted = sortBy(sizeSkus, ['capacitySize']);
  const sizeSkusSorted = skusSorted?.sort((a, b) => {
    if (a?.capacity?.includes('TB')) return 1;
    if (b?.capacity?.includes('TB')) return -1;
    if (b?.capacity?.includes('64 GB')) return 0;
    return a?.capacity?.localeCompare(b?.capacity);
  });

  const result = chain(sizeSkusSorted)
    .filter((sku) => sku?.capacity)
    .groupBy((sku) => sku?.capacity)
    .map((value, key) => ({
      capacity: key,
      skus: value,
      capacitySize: value?.[0].capacitySize,
    }))
    .value();
  const data =
    (result?.length > 0 &&
      result.map((sku) =>
        sku.capacitySize === 0
          ? {}
          : {
              id: sku.capacity,
              text: sku.capacity,
              value: sku.capacity,
              subtext: ' ',
              name: 'RadioBoxGroup',
              'data-track': `Productdetail_capacity_${sku.capacity}`,
            },
      )) ||
    [];

  const defaultSKUCapacitySize = {
    id: props?.selectedSize,
    text: props?.selectedSize,
    value: props?.selectedSize,
    name: 'RadioBoxGroup',
    'data-track': `Productdetail_capacity_${props?.selectedSize}`,
  };
  return (
    <RadioBoxWrap className='PriceSelector--Row Margin_payment_0'>
      {data?.length > 0 && !isEmpty(defaultSkuCapacity) && (
        <RadioStorageWrapper>
          <RadioBoxGroup
            childHeight='3.5rem'
            defaultValue={defaultSkuCapacity}
            value={defaultSkuCapacity}
            orientation='horizontal'
            data={props?.isBYOD || props?.isIndirectScan ? [defaultSKUCapacitySize] : [...data]}
            onChange={chooseSize}
          />
        </RadioStorageWrapper>
      )}
    </RadioBoxWrap>
  );
}

SizeSelector.propTypes = {
  skus: PropTypes.array,
  selectedSku: PropTypes.shape({
    color: PropTypes.shape({
      displayName: PropTypes.string.isRequired,
    }),
  }),
  chooseSize: PropTypes.func,
};

export default SizeSelector;
