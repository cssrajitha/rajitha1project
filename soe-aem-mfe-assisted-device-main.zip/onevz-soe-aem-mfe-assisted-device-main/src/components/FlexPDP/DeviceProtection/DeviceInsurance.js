import './DeviceInsurance.css';
import React, { useState, useEffect } from 'react';
import { Button } from '@vds/buttons';
import styled from 'styled-components';
import { Title, Body } from '@vds/typography';
import { Icon } from '@vds/icons';
import { isEmpty } from 'lodash';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import { useAddFeaturesMutation } from 'onevzsoemfecommon/APIService';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { useDispatch } from 'react-redux';
import Emitter from 'onevzsoemfeframework/Emitter';
import { sendCustomEvent } from 'onevzsoemfeframework/Tagging';
import { useGetProtectionFeaturesQuery } from 'onevzsoemfecommon/DeviceAPIService';
import { MarginRight4, Padding8 } from '../../CombinedGridwall/FlexGlobalStyledConstants';
import { DARK_THEME_COLOR, LIGHT_BG_COLOR, LIGHT_THEME_COLOR } from '../../../constants/constants';
import { isVbg } from 'onevzsoemfeframework/VbgAemUtil';
// import { useGetProtectionFeaturesQuery } from '../../../modules/services/APIService/APIServiceHooks';

const DetailContainer = styled.div`
  padding: 2rem;
  overflow: ${({ isAcssDeviceMfe }) => isAcssDeviceMfe && 'auto'};
  height: ${({ isAcssDeviceMfe }) => isAcssDeviceMfe && (window?.mfe?.isProspectNewCustomerTab ? '35rem' : '26rem')};
`;
const ButtonWrapper = styled.div`
  padding: 0rem 0rem 0rem 1.5rem;
  margin-left: auto;
  display: flex;
  margin-right: 20px;
`;

const ColContent = styled.div`
  padding: 1.25rem;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  position: relative;
`;
const DeviceProtectionTile = styled.div`
  width: 100%;
  height: 100%;
  border: 1px black solid;
  justify-content: flex-start;
`;

const ColContainer = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  margin: 1.25rem 0;
`;

// const ColRow = styled.div`
//   flex-direction: row;
//   display: flex;
// `;

const ColHead = styled.div`
  display: flex;
  margin: 0.75rem 0 0.25rem 0;
  flex-direction: row;
  justify-content: space-between;
`;

const ColSpace = styled.div`
  padding: 0;
`;

const RecBtn = styled.div`
  margin: 0 0 3.25rem;
`;

const ColTop = styled.div`
  padding: 1rem 1.25rem;
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
`;

const HeaderSpace = styled.div`
  margin: 0.25rem 0;
`;

const RowCont = styled.div`
  display: flex;
  margin: 0.5rem 0 0.25rem 0;
  flex-direction: row;
  gap: ${({ gap }) => gap}px;
`;

const HeaderContainer = styled.div`
  border-bottom: 1px solid #d8dada;
  padding: 1.25rem;
`;

const FlexRowSpace = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
`;
const PopUpWrapper = styled.div`
  width: 45rem;
  background-color: white;
  padding: 0.5rem;
  border-radius: 15px;
  position: absolute;
  top: 40%;
  left: 20%;
`;
const getPopUpWidth = (isAcssDeviceMfe) => {
  if (isAcssDeviceMfe) {
    return window?.mfe?.isProspectNewCustomerTab ? '55%' : '88%';
  }
  return '100%';
};
const PopUp = styled.div`
  z-index: 1000;
  position: fixed;
  width: ${({ isAcssDeviceMfe }) => getPopUpWidth(isAcssDeviceMfe)};
  border: 1px solid;
  height: ${({ isAcssDeviceMfe }) => (isAcssDeviceMfe ? '70%' : '100%')};
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  margin: auto;
  overflow-y: auto;
`;
const FooterPopUp = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
`;

function DeviceInsurance(props) {
  const bgColor = window?.mfe?.scmDeviceMfeEnable && window?.mfe?.themeProps?.background;
  const isDark = (window?.mfe?.scmDeviceMfeEnable && window?.mfe?.isDark) || false;
  const [addFeature, addFeatureResult] = useAddFeaturesMutation();
  const [dataFromLanding, setDataFromLanding] = useState({});
  const [modalFL, setModalFL] = useState(false);
  const [fromLandingFeature, setFromLandingFeature] = useState('');
  const [selectedInsuranceForAIQuote, setSelectedInsuranceForAIQuote] = useState({});
  const isVbgEnabled = isVbg();
  useEffect(() => {
    const listenerValue = true;
    Emitter.emit('Input_For_Device_Protection_listen', listenerValue);
    Emitter.on('Input_For_Device_Protection', (details) => {
      setDataFromLanding(details);
      if (details?.page === 'landing') {
        setModalFL(true);
        setFromLandingFeature('landing');
        setSelectedInsuranceForAIQuote(details?.selectedProtection);
      }
    });
    if (props?.deviceProtectionModal?.page === 'landing') {
      setModalFL(true);
      setFromLandingFeature('landing');
      setSelectedInsuranceForAIQuote(props?.deviceProtectionModal?.selectedProtection);
    }
    return () => {
      Emitter.off('Input_For_Device_Protection');
      Emitter.off('Input_For_Device_Protection_listen');
    };
  }, []);
  const initialRequestBodyProtectionFeatures = {
    mtn: dataFromLanding?.activeMtn || props?.deviceProtectionModal?.activeMtn,
    deviceSorId: dataFromLanding?.deviceSku || props?.deviceProtectionModal?.deviceSku,
    getHomeProtectionEligibility: false,
  };

  const ProtectionFeaturesResult = useGetProtectionFeaturesQuery(
    { body: initialRequestBodyProtectionFeatures },
    { refetchOnMountOrArgChange: props?.deviceProtectionModal?.page === 'landing', skip: !modalFL }
  );

  const currentProtection = ProtectionFeaturesResult?.data?.payload?.currentProtection;
  const {
    selectedProtectionFeature,
    showDeviceProtectionModal,
    isTMPScreenOpen,
    tmpLinkClicked,
    protectionShownStatusInDevice,
    legalMessage,
    isPromoBundleFlow,
    deviceName,
    isByodUpdate,
    setEnableBYODbtn,
    cartDetails,
    activeMtn,
    customerType,
  } = props;
  const [state] = useState({
    selectedOption: selectedProtectionFeature || null,
    showMore: false,
    legalMessageModal: false,
    featureIndex: null,
    showViewEligibility: false,
    eligibilityFeatureIndex: null,
    enableScroll: false,
  });
  const [legalMessageModal, setLegalMessageModal] = useState(false);
  const [showCaseFeatures, setshowCaseFeatures] = useState();
  const [continueWithCurrentfeature, setContinueWithCurrentfeature] = useState(false);
  const [showContinueButtonForcurrentFeature, setShowContinueButtonForcurrentFeature] = useState(false);
  const [protectionFeatures, setprotectionFeatures] = useState(props?.protectionFeatures);
  const [updateprotectionFeature, setUpdateprotectionFeature] = useState(props?.selectedProtectionFeature);
  const headerContent = '';
  const dispatch = useDispatch();
  const multilineProtectionFind = showCaseFeatures?.find((x) =>
    x.displayName.includes('Verizon Mobile Protect Multi-Device')
  );
  const isMultiDeviceBundle = !!(isPromoBundleFlow && getQueryParamByName('sorId') && getQueryParamByName('sorId2'));
  useEffect(() => {
    if (fromLandingFeature === 'landing') {
      setprotectionFeatures(ProtectionFeaturesResult?.data?.payload);
      const currentProtectionForAIQuote = ProtectionFeaturesResult?.data?.payload?.currentProtection;
      const features =
        ProtectionFeaturesResult?.data?.payload?.features?.filter((feature) => feature.showCaseFlag) || [];
      setshowCaseFeatures(features);
      setShowContinueButtonForcurrentFeature(false);
      /* istanbul ignore else */
      if (currentProtectionForAIQuote?.sorId) setSelectedInsuranceForAIQuote(currentProtectionForAIQuote);
    }
  }, [ProtectionFeaturesResult?.data?.payload]);

  useEffect(() => {
    const features = protectionFeatures?.features?.filter((feature) => feature.showCaseFlag) || [];
    setshowCaseFeatures(features);
    if ((!isTMPScreenOpen && !tmpLinkClicked) || (protectionShownStatusInDevice === false && !tmpLinkClicked)) {
      setShowContinueButtonForcurrentFeature(true);
    }
  }, []);
  useEffect(() => {
    if (addFeatureResult?.isSuccess === true) {
      hideProtectionModal();
    }
    if (addFeatureResult?.isError === true) {
      dispatch(
        appMessageActions.addAppMessage(
          'Sorry could not add device protection, please try again after sometime.',
          'error',
          true,
          true
        )
      );
      hideProtectionModal();
    }
  }, [addFeatureResult?.isError, addFeatureResult?.isSuccess, addFeatureResult?.data]);

  const hideProtectionModal = (e) => {
    e?.stopPropagation();
    e?.nativeEvent.stopImmediatePropagation();
    if (fromLandingFeature === 'landing' && addFeatureResult?.isSuccess) {
      const DpCLose = true;
      Emitter.emit('Closing_Device_Protection_Modal', DpCLose);
      Emitter.emit('Update_Show_Device_Protection_Modal', false);
      Emitter.emit('Call_Device_Add_Cart_Success', addFeatureResult?.originalArgs?.body);
      setModalFL(false);
    } else if (
      addFeatureResult?.status === 'uninitialized' &&
      addFeatureResult?.isSuccess === false &&
      addFeatureResult?.isError === false
    ) {
      setModalFL(false);
      // Emitter.emit('TRIGGER_AIQUOTE_FPS_CALL', true);
      Emitter.emit('Update_Show_Device_Protection_Modal', false);
      Emitter.emit('Update_Protection_Show_Status_InDevice', true);
    } else {
      Emitter.emit('Update_Show_Device_Protection_Modal', false);
      setModalFL(false);
    }
  };

  const updateSelectedInsurance = (selectedInsurance) => {
    if (selectedInsurance) {
      Emitter.emit('Update_Selected_Insurance', selectedInsurance);
      const cartLineInfo = cartDetails?.cart?.lineDetails?.lineInfo || [];
      const filteredLineFromCart =
        cartLineInfo?.find((line) => line?.mobileNumber === activeMtn || line?.lineNumber === activeMtn) || {};
      const lineActivityType = filteredLineFromCart?.lineActivityType;
      if (
        isByodUpdate &&
        (customerType === 'N' || lineActivityType?.includes('BYOD')) &&
        protectionFeatures?.currentProtection &&
        protectionFeatures?.currentProtection?.sorId !== selectedInsurance?.sorId
      ) {
        setEnableBYODbtn(true);
      }
    }
  };

  const callAddDeviceToCart = (selectedInsurance) => {
    if (
      (!isTMPScreenOpen && isTMPScreenOpen !== undefined && !tmpLinkClicked) ||
      (protectionShownStatusInDevice === false && !tmpLinkClicked)
    ) {
      Emitter.emit('Call_Device_Add_Cart', selectedInsurance);
    } else if (fromLandingFeature) {
      const request = {
        cartInfo: {
          intendType: props?.deviceProtectionModal?.page ? 'EUP' : 'FEA',
          processStep: 'FeaturesPDP',
          processingMTN: dataFromLanding?.activeMtn,
        },
        data: {
          lines: [
            {
              features: {
                add: [
                  {
                    actionIndicator: 'A',
                    id: selectedInsurance?.sorId,
                    quantity: '1',
                    type: selectedInsurance?.featureType,
                  },
                ],
                ...(selectedInsuranceForAIQuote?.sorId
                  ? {
                      remove: [
                        {
                          actionIndicator: 'D',
                          id: selectedInsuranceForAIQuote?.sorId,
                          quantity: '1',
                          type: selectedInsuranceForAIQuote?.featureType
                            ? selectedInsuranceForAIQuote?.featureType
                            : currentProtection?.featureType,
                        },
                      ],
                    }
                  : {}),
              },
              mtn: dataFromLanding?.activeMtn || props?.deviceProtectionModal?.activeMtn,
            },
          ],
        },
      };
      /* istanbul ignore else */
      if (props?.fromAiQuote) request.cartInfo.intendType = props?.lineActivityType;
      
      addFeature({ body: request });
      // hideProtectionModal();
    }
    console.log('lint issues resolving', continueWithCurrentfeature, addFeatureResult, setContinueWithCurrentfeature);
  };

  const handleOnChange = (e, value) => {
    e.stopPropagation();
    e.nativeEvent.stopImmediatePropagation();
    const getItemIndex = protectionFeatures.features.findIndex((x) => x.sorId === value);
    checkLegalMessage(protectionFeatures.features[getItemIndex], e);
    // Act171-46 EUP Missing Tagging: AddToQuote to be fired for Adding Device Protection
    const devicePDPTaggingFFlag = JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.devicePDPTaggingFFlag;
    if (/true/i.test(devicePDPTaggingFFlag) && !props.fromAiQuote) {
      const currentFeature = protectionFeatures?.features[getItemIndex].displayName;
      const currentFeatureFamily = protectionFeatures?.features[getItemIndex].featureFamily;
      /* istanbul ignore else */
      if (currentFeatureFamily !== 'DECLINED_PROTECTION') {
        const currentFeatureId = protectionFeatures?.features[getItemIndex]?.sorId;
        const currentFeatureRecurrsionPrice = protectionFeatures?.features[getItemIndex]?.price?.discountedPrice;
        const currentFeatureShared = protectionFeatures?.features[getItemIndex]?.eligibleLines;
        const vzdl = window?.vzdl;
        if (vzdl?.txn) {
          const index = vzdl?.txn?.product?.current?.findIndex((current) => current.category === 'Features');
          if (index !== -1) vzdl?.txn?.product?.current?.splice(index, 1);

          const featureDeviceProtection = {
            category: 'Features',
            contractType: '',
            line: '',
            discount: '',
            id: currentFeatureId,
            name: currentFeature,
            nonRecurringPrice: '',
            qty: '1',
            shared: currentFeatureShared ? 'Y' : 'N',
            sku: '',
            shippingType: '',
            shippingCharge: '',
            merchCat: '',
            offer: '',
            recurringPrice: currentFeatureRecurrsionPrice,
            lineHash: vzdl?.txn?.product?.current[0]?.lineHash,
            orderType: vzdl?.txn?.product?.current[0]?.orderType,
          };
          vzdl.txn.product.current.push(featureDeviceProtection);
          console.log('AddtoQuote has been fired', vzdl);
          sendCustomEvent('AddtoQuote', vzdl);
          window.vzdl = vzdl;
        }
      } else {
        const vzdl = window?.vzdl;
        const index = vzdl?.txn?.product?.current?.findIndex((current) => current.category === 'Features');
        if (index !== -1) vzdl?.txn?.product?.current?.splice(index, 1);
        window.vzdl = vzdl;
      }
    }
    setModalFL(false);
  };

  const clickOnContinue = (e) => {
    if (fromLandingFeature) {
      callAddDeviceToCart(state.selectedOption);
    } else {
      Emitter.emit('Update_Protection_Show_Status_InDevice', true);
      updateSelectedInsurance(state.selectedOption);
      hideProtectionModal(e);
      callAddDeviceToCart(state.selectedOption);
    }
  };

  const clickOk = (e) => {
    if (fromLandingFeature) {
      setLegalMessageModal(false);
      callAddDeviceToCart(updateprotectionFeature);
      updateSelectedInsurance(selectedProtectionFeature);
    } else {
      Emitter.emit('Update_Protection_Show_Status_InDevice', true);
      updateSelectedInsurance(selectedProtectionFeature);
      hideProtectionModal(e);
      callAddDeviceToCart(selectedProtectionFeature);
    }
    // setLegalMessageModal(false);
  };

  const clickCancel = () => {
    setLegalMessageModal(false);
  };

  const isRecommendedFeature = (item) => {
    return (
      item.displayName.includes('Verizon Mobile Protect Multi-Device') ||
      (!multilineProtectionFind && item.displayName.includes('Verizon Mobile Protect')) ||
      (isVbgEnabled && item.displayName.includes('Total Mobile Protection Multi-Device for Business (3-10 eligible lines)'))
    );
  };

  const checkLegalMessage = (selectedOption, e) => {
    const sameSorId = !!(isPromoBundleFlow && getQueryParamByName('sorId') === getQueryParamByName('sorId2'));

    if (selectedOption?.coverageType === 'ACCOUNTLEVEL') {
      setLegalMessageModal(true); // , featureIndex: getItemIndex
      const vzdl = window?.vzdl || {};
      if (vzdl?.event) vzdl.event.value = '';
      if (vzdl?.page) vzdl.page.detail = `Equipment Protection | Verizon Device Protect Multi Device`;
      window.vzdl = vzdl;
      sendCustomEvent('openView', window?.vzdl);
      updateSelectedInsurance(selectedOption);
      setUpdateprotectionFeature(selectedOption);
    } else if (fromLandingFeature && fromLandingFeature === 'landing') {
      callAddDeviceToCart(selectedOption);
      if (isPromoBundleFlow && sameSorId) {
        props.sameSorIDforBOGO(true);
      }
    } else {
      Emitter.emit('Update_Protection_Show_Status_InDevice', true);
      updateSelectedInsurance(selectedOption);
      hideProtectionModal(e);
      callAddDeviceToCart(selectedOption);
      if (isPromoBundleFlow && sameSorId) {
        props.sameSorIDforBOGO(true);
      }
    }
  };
  const insuranceSelectionOptions =
    !isEmpty(showCaseFeatures) &&
    showCaseFeatures?.map((item) => (
      <ColContent key={`key-${item?.sorId}`}>
        {(fromLandingFeature === 'landing'
          ? selectedInsuranceForAIQuote?.sorId
          : !!state.selectedOption && state.selectedOption.sorId) === item.sorId && (
          <RecBtn>
            <ColTop
              style={{
                backgroundColor: isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR,
                color: isDark ? LIGHT_THEME_COLOR : DARK_THEME_COLOR,
              }}
            >
              <Body color={isDark ? LIGHT_THEME_COLOR : DARK_THEME_COLOR} size='large' primitive='p' bold>
                Selected
              </Body>
            </ColTop>
          </RecBtn>
        )}
        {!(!!state.selectedOption && state.selectedOption.sorId === item.sorId) &&
          isRecommendedFeature(item) && (
            <RecBtn>
              <ColTop
                style={{
                  backgroundColor: isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR,
                  color: isDark ? LIGHT_THEME_COLOR : DARK_THEME_COLOR,
                }}
              >
                <Body color={isDark ? LIGHT_THEME_COLOR : DARK_THEME_COLOR} size='large' primitive='p' bold>
                  Recommended
                </Body>
              </ColTop>
            </RecBtn>
          )}
        {/* <ColHeadTop> */}
        <ColHead>
          <ColSpace>
            <Title size='medium' bold color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR}>
              {item.displayName}
            </Title>
            <HeaderSpace>
              {item.price && (
                <Title size='large' bold color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR}>
                  ${item.price.regularPrice}&nbsp;{item.priceTerm || '/mo'}
                </Title>
              )}
            </HeaderSpace>
          </ColSpace>
          <ColSpace>
            <Button
              ariaLabel={
                item.featureFamily === 'DECLINED_PROTECTION'
                  ? `${`Decline protection_${item?.displayName}`}`
                  : `${`Add_${item?.displayName}`}`
              }
              data-testid='testBtnProtection'
              data-track={
                item.featureFamily === 'DECLINED_PROTECTION' ? 'Decline Device Protection' : `${item?.displayName}_Add`
              }
              size='large'
              disabled={
                !item.sellable ||
                (fromLandingFeature === 'landing'
                  ? selectedInsuranceForAIQuote?.sorId
                  : !!state.selectedOption && state.selectedOption.sorId) === item.sorId
              }
              secondary
              onClick={(e) => handleOnChange(e, item.sorId)}
              surface={isDark ? 'dark' : 'light'}
            >
              {item.featureFamily === 'DECLINED_PROTECTION' ? 'Decline protection' : 'Add'}
            </Button>
          </ColSpace>
        </ColHead>
        <div
          dangerouslySetInnerHTML={{
            __html: item.description,
          }}
        />
      </ColContent>
    ));
  const deviceProtectionsGrid =
    !isEmpty(insuranceSelectionOptions) &&
    insuranceSelectionOptions.map((insuranceSelectionOption, index) => (
      <DeviceProtectionTile key={`insuranceSel-${insuranceSelectionOptions[index]}`}>
        {insuranceSelectionOption}
      </DeviceProtectionTile>
    ));
  return (
    (modalFL || showDeviceProtectionModal) && ( // make this as one flag according mfe or pdp
      <div
        style={{
          visibility: showDeviceProtectionModal ? 'visible' : 'none',
        }}
      >
        <PopUp
          isAcssDeviceMfe={window?.mfe?.scmDeviceMfeEnable}
          data-testid='DeviceInsurance'
          style={{
            backgroundColor: isDark ? bgColor : LIGHT_BG_COLOR,
            overflow: state.legalMessageModal || state.showViewEligibility ? 'hidden' : '',
          }}
        >
          {legalMessageModal && (
            <div className='legalMessageContainer'>
              <PopUpWrapper>
                <Padding8>
                  <Body size='medium'>
                    {legalMessage ||
                      'By adding this Multi-Device Protection, any single line device protection on lines covered by this Multi-Device Protection will be removed.'}
                  </Body>
                </Padding8>
                <FooterPopUp>
                  <Button data-track='DeviceInsurance_ok' onClick={clickOk} size='small' width='90px'>
                    OK
                  </Button>
                  <MarginRight4 />
                  <Button data-track='DeviceInsurance_cancel' onClick={clickCancel} size='small' width='90px'>
                    CANCEL
                  </Button>
                </FooterPopUp>
              </PopUpWrapper>
            </div>
          )}
          <div
            className={`${window?.mfe?.isProspectNewCustomerTab ? 'Prospect-BuyoutAmount-Modal-inner' : 'BuyoutAmount-Modal-inner'} u-borderTopGray`}
            style={{
              backgroundColor: isDark ? bgColor : LIGHT_BG_COLOR,
              color: isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR,
            }}
          >
            <HeaderContainer>
              <FlexRowSpace>
                <Title
                  data-testid='headerText'
                  color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR}
                  size='small'
                  primitive='p'
                  bold
                >{`Device Protection ${isPromoBundleFlow && isMultiDeviceBundle ? headerContent : ''}`}</Title>

                {showContinueButtonForcurrentFeature && state.selectedOption && (
                  <ButtonWrapper data-testid='testContinuedeviceProtection' onClick={clickOnContinue}>
                    <Button
                      type='secondary'
                      size='small'
                      width='auto'
                      surface={isDark ? 'dark' : 'light'}
                      data-track='DeviceProtection-Continue'
                    >
                      Continue
                    </Button>
                  </ButtonWrapper>
                )}
                <div
                  data-testid='closeButton'
                  data-track='DeviceProtection_Close'
                  onClick={hideProtectionModal}
                  onKeyDown={{}}
                  tabIndex={0}
                  role='button'
                >
                  <Icon name='close' size={18} surface={isDark ? 'dark' : 'light'} />
                </div>
              </FlexRowSpace>
            </HeaderContainer>
            <DetailContainer isAcssDeviceMfe={window?.mfe?.scmDeviceMfeEnable}>
              <Title size='large' bold={false} color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR}>
                Protect your device against loss, theft and damage.
              </Title>
              <RowCont gap={8}>
                <Title size='small' bold color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR}>
                  {deviceName}
                </Title>
              </RowCont>

              <ColContainer data-testid='insuranceSel'>{deviceProtectionsGrid}</ColContainer>
            </DetailContainer>
          </div>
        </PopUp>
      </div>
    )
  );
}

export default DeviceInsurance;
