import React from 'react';
import { render, screen, fireEvent } from '../../modules/test-utils/renderHelper';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import ShowPastbalPreBackOrder from './ShowPastbalPreBackOrder';

jest.setTimeout(60000);
describe('ShowPastbalPreBackOrder component', () => {
  beforeAll(() => {});
  beforeEach(() => {
    render(<ShowPastbalPreBackOrder setShowModalPastbalPreBackOrder={jest.fn()} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('pastDueModalInPDP should render', async () => {
    const pastDueModalInPDPBtn = await screen.findByTestId('pastDueModalInPDP');
    expect(pastDueModalInPDPBtn).toBeInTheDocument();
  });

  test('pastDueModalInPDP click on Ok button', async () => {
    const okBtn = await screen.getAllByLabelText('OK');
    expect(okBtn[0]).toBeInTheDocument();
    fireEvent.click(okBtn[0]);
  });
});
