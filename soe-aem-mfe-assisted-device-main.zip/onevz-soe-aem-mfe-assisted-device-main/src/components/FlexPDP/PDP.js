import React, { useState, useEffect, lazy, Suspense, useMemo } from 'react';
import PropTypes from 'prop-types';
import Emitter from 'onevzsoemfeframework/Emitter';
// eslint-disable-next-line you-dont-need-lodash-underscore/get
import { chain, isEmpty, get as getProp, cloneDeep } from 'lodash';
import sortBy from 'lodash/sortBy';
import { useNavigate } from 'react-router-dom';
import { getQueryParamByName, getUIContextPathBAU, isNumeric } from 'onevzsoemfecommon/Helpers';
import {
  isIpad,
  isRetail,
  isD2D,
  isTelesales,
  isOmniCare,
  isChatStore,
  isIndirect as indirect,
} from 'onevzsoemfeframework/DomService';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import styled from 'styled-components';
import {
  useAddDeviceMutation,
  useLazyComputeDPPricesQuery,
  useAddFeaturesMutation,
} from 'onevzsoemfecommon/APIService';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { useDispatch } from 'react-redux';
import E911Validation from 'onevzsoemfecommon/E911Validation';
import { Notification } from '@vds/notifications';
import * as DOMPurify from 'dompurify';
import { sendCustomEvent } from 'onevzsoemfeframework/Tagging';
import { useLazyAdd_buyoutQuery } from 'onevzsoemfecommon/CartAPIService';
import { isVbg, isVbgAem } from 'onevzsoemfeframework/VbgAemUtil';
import { getAddressInfo, isFunctionalityEnabled, makeOpenViewCall, mPosFormatDate } from '../../modules/utils/index';
import {
  useGetOffersPdpMutation,
  useGetCartExceedsLimitMutation,
} from '../../modules/services/APIService/APIServiceHooks';
import Header from './Header';
import { Padding32 } from '../CombinedGridwall/FlexGlobalStyledConstants';
import { initialRequestAddDevice } from '../../modules/services/APIService/APIRequestBody';
import Home5g from '../../assests/images/Home5g.png';
import DevicePlanCompatible from './DevicePlanCompatible';
import {
  getRetrieveCartInfo,
  determineBBOrderType,
  isDWOSAllowed,
  hasISPUAndLocalConflict,
  shouldHideISPUToggle,
} from './pdputils';
import getIspuSimEnable from '../../modules/utils/getIspuSimEnable';
import { TELESALES_ISPU_SIM_SORID } from './PDP_Constants';
import ApplyVVCModal from './ApplyVVCModal';
import { LIGHT_BG_COLOR } from '../../constants/constants';
import { contractTerms, contractTermLabels } from '../../constants/ContractTerms';
import { getLteCbdIntendType, getVhiLiteQualifiedForIntentType } from '../../pages/PDP5G/pdp5gutils';
import FFLAGS from '../../constants/fFlag.constant';

const DeviceInfo = lazy(() => import('./DeviceInfo'));
const Home5G = lazy(() => import('./Home5G'));
const BuyoutAmount = lazy(() => import('./BuyoutModel/BuyoutAmount'));
const RemoveLinesModal = lazy(() => import('./RemoveLinesModal'));
const ShowPastbalPreBackOrder = lazy(() => import('./ShowPastbalPreBackOrder'));

const HeaderWraper = styled.div`
  position: absolute;
  background: ${(props) => (props.isDark ? props.bgColor : LIGHT_BG_COLOR)};
  width: 100%;
  top: 0;
  max-width: 1133px;
  z-index: ${({ scmDeviceMfeEnable }) => (scmDeviceMfeEnable ? '1' : 'inherit')};
`;

let navigate = '';

function useNavigateMFE() {
  navigate = useNavigate();
}

/**
 * Determines if the cart button should be enabled based on various business rules
 * Exported for unit testing purposes
 * @param {Object} ctx - Context object containing all required properties
 * @returns {boolean} - True if cart button should be enabled
 */
export const shouldEnableCartButton = (ctx) => {
  const {
    isIndirectChannel,
    fromCPE,
    numberShare,
    shareValue,
    rfexFlowBtn,
    contractChange,
    ispuToggle,
    sku,
    shipItToggle,
    prePay,
    preOrder,
    backorder,
    dFillQty,
    contract,
    pastbalPreBackOrder,
    cashOnlyCustomer,
    devId,
    simCardId,
    numberShareAndByod,
    orderDet,
    lineActivityType,
    protectionFeat,
    selectedProtection,
    simLocalCardId,
    lineDeviceId,
    lineSimId,
    channelType,
  } = ctx;

  // Indirect - for local orders Add to Cart CTA will be always enable
  if (isIndirectChannel && !shipItToggle && (!numberShare || (numberShare && shareValue !== ''))) {
    return true;
  }

  // CPE flow conditions
  if (fromCPE && !numberShare) return true;
  if (fromCPE && numberShare && shareValue) return true;

  // Refund/Exchange flow
  if (rfexFlowBtn && contractChange) return true;

  // ISPU conditions
  if (ispuToggle && sku?.isInstorePickup) return true;
  if (ispuToggle || (fromCPE && (!numberShare || (numberShare && shareValue !== '')))) return true;

  // Pre-pay condition
  if (prePay && !preOrder && !backorder && dFillQty && contract) return true;

  // Pre-order and backorder conditions
  if (!pastbalPreBackOrder && !cashOnlyCustomer && (preOrder || backorder) && (!numberShare || shareValue !== '')) {
    return true;
  }

  // CPE with device and SIM conditions
  /* istanbul ignore if */ 
  if (fromCPE && devId && simCardId && (!numberShare || (numberShare && shareValue !== ''))) return true;

  // Number share and BYOD
  if (numberShareAndByod) return true;

  // Protection feature change condition
  /* istanbul ignore if */
  if (
    (orderDet.customerType === 'N' || lineActivityType === 'BYOD' || lineActivityType === 'EUPBYOD') &&
    protectionFeat?.currentProtection &&
    selectedProtection &&
    protectionFeat?.currentProtection?.sorId !== selectedProtection.sorId
  ) {
    return true;
  }

  // Device/SIM ID matching condition
  if (
    devId === lineDeviceId &&
    simLocalCardId !== lineSimId &&
    (channelType.includes('RETAIL') || channelType.includes('TELESALES'))
  ) {
    return true;
  }

  return false;
};

/**
 * Check number share conditions for BYOD and CPE flows
 * @param {boolean} fromCPE - is from CPE flow
 * @param {boolean} byodUpdate - is BYOD update flow
 * @param {boolean} numberShare - is number share enabled
 * @param {string} shareValue - number share value
 * @param {boolean} shareMandatory - is number share mandatory
 * @returns {boolean} whether number share conditions are met
 */
export const checkNumberShareConditions = (fromCPE, byodUpdate, numberShare, shareValue, shareMandatory) => {
  let isNumberShareAndByod = false;
  if ((byodUpdate || fromCPE) && numberShare && shareValue !== '') {
    isNumberShareAndByod = true;
  } else if ((byodUpdate || fromCPE) && (!numberShare || shareMandatory === false) && shareValue !== '') {
    isNumberShareAndByod = true;
  }
  return isNumberShareAndByod;
};

function PDP(props) {
  const scmDeviceEnable = window?.mfe?.scmDeviceMfeEnable;
  const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable || false;
  const scmCombinedGridwallFlow = window?.mfe?.scmCombinedGridwallFlow || false;
  const scmQuoteEnable = window?.mfe?.scmQuoteEnable || false;
  const cleanUpEmitterFFlag = /true/i.test(getAssistedCradlePropertyV2(['cleanUpEmitterFFlag'])?.[0]);
  const skipICCIDFFlag = getAssistedCradlePropertyV2(['skipICCIDFFlag'])?.[0];
  const editbyodSimIdFFlag = /true/i.test(getAssistedCradlePropertyV2(['editbyodSimIdFFlag'])?.[0]);
  const indirectSellerPriceFFlag = /true/i.test(getAssistedCradlePropertyV2(['indirectSellerPriceFFlag'])?.[0]);
  const esimAPIskipFFlag = /true/i.test(getAssistedCradlePropertyV2(['esimAPIskipFFlag'])?.[0]);

  // const navigate = scmDeviceEnable ? "" :useNavigate();
  const isVbgEnabled = isVbg();
  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }

  const {
    lineDeviceIdFromLanding,
    lineSimIdFromLanding,
    productDetails,
    customerProfileDetails,
    activeMtn,
    cartDetails,
    protectionFeatures,
    isPreorderCountDownEnabled,
    isPreorderTestingEnabled,
    buyoutUpgradeResult,
    buyoutUpgradeReq,
    removeLinesAPI,
    RemoveLinesAPIResult,
    setSimIdResult,
    setSelectedDeviceData,
    ValidateDeviceSimIdResult,
    SkuDetailsResult,
    GetDetailsResult,
    simSwapNotificationHighRiskMsg,
  } = props;
  const skuRealAgentCode = SkuDetailsResult?.data?.data?.accountInfo?.realAgentCode || '0281'; // hardcoding for testing purpose until api it not ready
  const [simSkuEntered, setSimSkuEntered] = useState('');
  const [bbPaymentOptionsSelected, setBbPaymentOptionsSelected] = useState(false);
  const scmDeviceMfeEnable = window?.mfe?.scmDeviceMfeEnable;
  const isDark = (scmDeviceMfeEnable && window?.mfe?.isDark) || false;
  const bgColor = scmDeviceMfeEnable && window?.mfe?.themeProps?.background;
  const dispatch = useDispatch();
  const { lineDetails = {}, orderDetails = {} } = getProp(cartDetails, 'cart') || {};
  const [addDevices, AddDevicesResult] = useAddDeviceMutation();
  const [addFeature] = useAddFeaturesMutation();
  const [getOffers, getOffersResults] = useGetOffersPdpMutation();
  const elvisFFlag = /true/i.test(sessionStorage.getItem('elvisFFlag'));
  const [getCardLimitDetails, getCardLimitResults] = useGetCartExceedsLimitMutation();
  const [
    enableDefaultedShipToHome,
    includePdpBuyoutToggle,
    isMitekSimSwapEnabled,
    isMitekDeviceSwapEnabled,
    enableEUPDualNum,
    disableEsimAtLocalInventory,
    localPreBackQuoteFFlag,
    bestBuyIntegrationFFlag,
    cpeSimFixFFlag,
    dwosIndirectFFlag,
    negativeBuyoutAmountFixFlexFFlag,
    snPerkSideRailCacheFixFFlag,
    bestBuyEmpMasterAgentFFlag,
    addFeatureCallInPDPFFlag,
    removeFeatureCallInPDPFFlag,
    bestBuyISPUEnableLocalOrderFFlag,
  ] = getAssistedCradlePropertyV2([
    'enableDefaultedShipToHome',
    'includePdpBuyoutToggle',
    'isMitekSimSwapEnabled',
    'isMitekDeviceSwapEnabled',
    'enableEUPDualNum',
    'disableEsimAtLocalInventory',
    'localPreBackQuoteFFlag',
    'bestBuyIntegrationFFlag',
    'cpeSimFixFFlag',
    'dwosIndirectFFlag',
    'negativeBuyoutAmountFixFlexFFlag',
    'snPerkSideRailCacheFixFFlag',
    'bestBuyEmpMasterAgentFFlag',
    'addFeatureCallInPDPFFlag',
    'removeFeatureCallInPDPFFlag',
    'bestBuyISPUEnableLocalOrderFFlag',
  ]);
  let [skipIccidCall] = getAssistedCradlePropertyV2(['skipIccidCall']);
  const [flexFlowServiceChangeFFlag] = getAssistedCradlePropertyV2(['flexFlowServiceChangeFFlag']);
  const flexFlowServiceChange = /true/i.test(flexFlowServiceChangeFFlag) && getQueryParamByName('etrServiceChanges');
  skipIccidCall = /true/i.test(skipICCIDFFlag) ? skipICCIDFFlag : skipIccidCall;
  const isDWOS = isDWOSAllowed(dwosIndirectFFlag, getQueryParamByName('isDWOS'));
  const isProspectByodFlow = getQueryParamByName('prospectByodFlow');
  const [addBuyoutReq, addBuyoutResult] = useLazyAdd_buyoutQuery();
  // DownPayment call
  const [computeDPPriceBody, computeDPPriceResult] = useLazyComputeDPPricesQuery();
  const [isDownPaymentAlertNeedToEnable, setIsDownPaymentAlertNeedToEnable] = useState(false);
  const [buyoutToggleChange, setBuyoutToggleChange] = useState(false);
  const [localPreBackDevice, setLocalPreBackDevice] = useState(false);
  const [localPreBackErrMsg, setLocalPreBackErrMsg] = useState('');
  const [showLocalPreBackErrBanner, setShowLocalPreBackErrBanner] = useState(false);
  const [showISPULocalConflictBanner, setShowISPULocalConflictBanner] = useState(false);
  const [isESimRegenerated, setIsESimRegenerated] = useState(false);
  const [shouldHideISPU, setShouldHideISPU] = useState(false);
  const [showNonISPULocalBanner, setShowNonISPULocalBanner] = useState(false);
  const [bbyPaymetOptionPriceId, setBbyPaymetOptionPriceId] = useState('');
  const [taxBasisCharge, setTaxBasisCharge] = useState('');
  const [bbyContractTerm, setBbyContractTerm] = useState('');
  const [upcCodeFromPdpScan, setUpcCodeFromPdpScan] = useState(getQueryParamByName('upcCodeValue'));
  const {
    lcLocationCode = '',
    masterAgentId = '',
    agVisionOutletId = '',
    lcClusture = '',
  } = props?.BbyLocalOrderLocDetailsResponse || {};
  const outletIdFromCart = orderDetails?.outletId || '';
  const locationCodeFromCart = orderDetails?.locationCode || '';
  const fromPage = getQueryParamByName('fromPage');
  const isLocal = getQueryParamByName('isLocal'); // Retail Local Scan
  const isSecondNumberFlow =
    /true/i.test(sessionStorage.getItem('isSecondNumDfill')) ||
    /true/i.test(sessionStorage.getItem('isSecondNumFlow')) ||
    /true/i.test(sessionStorage.getItem('isSecondNumLocal')) ||
    sessionStorage.getItem('secondNumber');

  const getVbgFwaProfInstallOrderingFlag = () => {
    const appProperties = JSON.parse(sessionStorage.getItem('APP_PROPERTIES')) || {};
    const isVbgFwaProfInstallFlagEnabled = appProperties.vbgFwaProfInstallOrderingFFlag === 'TRUE';
    return isVbgAem() && isVbgFwaProfInstallFlagEnabled;
  };

  const vbgFwaProfInstallOrderingFFlag = getVbgFwaProfInstallOrderingFlag();

   const getVbgFwaProfInstallAcc = () => {
    const addressRequest = customerProfileDetails?.customer?.qualificationDetails?.addressRequest || {};
    const fiveGHomeQualified = addressRequest?.fiveGHomeQualified;
    const isTanglewoodQualified = addressRequest?.tanglewoodQualified || false;
    const vbgAccesories =  vbgFwaProfInstallOrderingFFlag && (fiveGHomeQualified === 'true' || isTanglewoodQualified);
    return vbgAccesories;
  };

  const handleRedirectionLogic = () => {
    /* istanbul ignore else */
    if (!scmDeviceEnable) {
      if (fromPage === 'Landing' || isSecondNumberFlow) {
        if (snPerkSideRailCacheFixFFlag === 'TRUE' && isSecondNumberFlow) {
          navigate(`${getUIContextPathBAU()}/landing.html`);
        } else {
          navigate(`${getUIContextPathBAU()}/landing.html?fromPDP=true&activeMtn=${activeMtn}`);
        }
      } else {
        /* istanbul ignore next */
        if (flexFlowServiceChange || /true/i.test(sessionStorage.getItem('provisionalId'))) {
          navigate(`${getUIContextPathBAU()}/landing.html?activeMtn=${activeMtn}&frometrserviceflow=true`);
          return;
        }
        navigate(
          `${getUIContextPathBAU()}/combinedgridwall.html?fromPDP=true&activeMtn=${activeMtn}&backfrompdp=true${
            isDWOS ? '&isDWOS=true' : ''
          }`
        );
      }
    }
  };

  const isScmSecondNumPerkEnabled = getQueryParamByName('isScmSecondNumPerkEnabled') || false;
  const handleCompatibleLogic = (AddDevicesResults) => {
    /* istanbul ignore next */
    const { cartInfo } = AddDevicesResults?.data?.serviceBody?.serviceResponse?.context || {};
    const processStep = AddDevicesResults?.data?.serviceBody?.serviceResponse?.context?.contextInfo?.processStep;
    displayAddDeviceBanner(cartInfo);
    
    /**
     * Coverage Issue: This condition is not covered in tests because:
     * 1. This function is triggered in useEffect after addToCart API call
     * 2. Istanbul ignore statements used in many places due to testing limitations
     */
    
    /* istanbul ignore if  */
    if ( getVbgFwaProfInstallAcc() && processStep === 'Accessories') {
      navigate(`${getUIContextPathBAU()}/shop-accessories.html?accessoryflow=true`);
      return true;
    }
    if (processStep !== 'ShoppingCart' && !ispuToggleOn) {
      if (isNewLine) {
        /* istanbul ignore if  */
        if (processStep === 'PlanSelection') {
          sessionStorage.setItem('incompatiblePlan', true);
          setShowDeviceCompModal(true);
        } else {
          handleRedirectionLogic();
        }
      } else if (scmDeviceEnable) {
        Emitter.emit('SCM_DEVICE_PLAN_COMPATIBLITY_FLOW');
      } else {
        sessionStorage.setItem('incompatiblePlan', true);
        setShowDeviceCompModal(true);
      }
    } else {

      handleRedirectionLogic();

    }
  };
  const cartLineInfoVal = cartDetails?.cart?.lineDetails?.lineInfo || [];
  const filteredLineFromCart =
    cartLineInfoVal?.find((line) => line?.mobileNumber === activeMtn || line?.lineNumber === activeMtn) || {};
  const deviceFromFilteredCartLine = filteredLineFromCart?.itemsInfo?.[0]?.cartItems?.cartItem?.find(
    (item) => item?.cartItemType === 'DEVICE'
  );
  const simFromFilteredCartLine = filteredLineFromCart?.itemsInfo?.[0]?.cartItems?.cartItem?.find(
    (item) => item?.cartItemType === 'SIM'
  );
  const iSscanLocal = getQueryParamByName('iSscan');
  const { isBBYLocalOrder, isBBYDfillOrder } = determineBBOrderType(iSscanLocal, cartDetails);
  const [retailPrice, setRetailPrice] = useState(null);
  const [paymentDetails, setPaymentDetails] = useState({
    taxBasis: '',
    bbyDownPayment: '',
    regularPrice: '',
    currentPrice: '',
    downPaymentAmount: '',
  });
  console.log(
    retailPrice,
    'priceId',
    paymentDetails?.taxBasis,
    'dnp',
    paymentDetails?.downPaymentAmount,
    'rp',
    paymentDetails?.regularPrice,
    paymentDetails?.currentPrice,
    'cp',
    'bbydp',
    paymentDetails?.bbyDownPayment
  );
  useEffect(() => {
    handleFullRetailPrice();
    updatePaymentDetails();
  }, [isBBYLocalOrder]);

  useEffect(() => {
    if (localPreBackDevice) {
      callDeviceAddToCart();
    }
  }, [localPreBackDevice]);

  const callLocalPreBackAddToCart = () => {
    setLocalPreBackDevice(true);
  };

  useEffect(() => {/* NOSONAR: Bypassing Existing Sonar issues */
    if (AddDevicesResult?.data) {
      const details = {
        PAGE_LOADED: 'true',
        CUSTOM_EVENT: 'AddtoQuote',
        NEED_CALLBACK: true,
      };
      Emitter.emit('PAGE_LOADED', details);
      if (!scmUpgradeMfeEnable) {
        window?.store?.dispatch(fetchPricingApiRequired());
      }
      if (scmDeviceEnable) {
        if (isNewLine) {
          const activenewLineMTN = getQueryParamByName('activeMtn');
          sessionStorage.setItem('activeMTN', activenewLineMTN);
        }
        if (!scmCombinedGridwallFlow) {
          Emitter.emit('ADD_SELECTED_DEVICE_TO_CART', { newLine: isNewLine });
        } else {
          Emitter.emit('ADD_SELECTED_DEVICE_TO_CART', { newLine: isNewLine, navToPlanTab: false });
        }
      }
      if (scmUpgradeMfeEnable && !isByodUpdate) {
        const addDeviceResonse = AddDevicesResult?.data?.serviceBody?.serviceResponse?.context;
        const selectedMTN = addDeviceResonse?.customerInfo?.processingMTN;
        const defaultSkuId = addDeviceResonse?.cartInfo?.lines?.filter((i) => i.mtn === selectedMTN)[0]?.device?.id;
        const productId = getQueryParamByName('productId');
        if (scmCombinedGridwallFlow) {
          Emitter.emit('ACSS_SCM_DEVICE_SUBTAB', { subTab: 'CombinedGridwall', activeMtn: selectedMTN });
        } else {
          const genQueryparams = `offerEligible=Y&activeMtn=${selectedMTN}&productId=${productId}&deviceSKU=${defaultSkuId}&deviceFromCart=true&isEditAndView=true&fromPage=CombinedGridwall&deviceId=&simId=`;
          Emitter.emit('ACSS_SCM_DEVICE_SUBTAB', { subTab: 'PDP', queryParams: genQueryparams });
        }
        handleCompatibleLogic(AddDevicesResult);
      }
      if (scmQuoteEnable) {
        Emitter.emit('ACSS_FLEX_FETCHPRICING_RETRIEVECART', { value: true });
      }
      Emitter.on('TAGGING_COMPLETED', () => {
        handleCompatibleLogic(AddDevicesResult);
      });

      const isETRserviceOnly = /true/i.test(sessionStorage.getItem('isEtrServiceChangesFlow'));
      const isEtrServiceOnlyFlow = isETRserviceOnly && /true/i.test(flexFlowServiceChangeFFlag);
      const selectedMTN = AddDevicesResult.data?.serviceBody?.serviceResponse?.context?.customerInfo?.processingMTN;
      const cartLines = AddDevicesResult.data?.serviceBody?.serviceResponse?.context?.cartInfo?.lines || [];
      const matchedLine = cartLines.find((line) => line?.mtn === selectedMTN);
      const defaultSkuId = matchedLine?.device?.id;
      /* istanbul ignore next */
      if (isEtrServiceOnlyFlow && AddDevicesResult?.status === 'fulfilled' && selectedMTN && defaultSkuId) {
        const queryParams = new URLSearchParams({
          etrServiceChanges: 'true',
          isByodUpdate: 'true',
          isEditAndView: 'true',
          deviceSKU: defaultSkuId,
          activeMtn: selectedMTN,
          ...(matchedLine?.sim?.id && { simId: matchedLine.sim.id }),
        });

        navigate(`${getUIContextPathBAU()}/combinedgridwall.html?${queryParams.toString()}`);
      }
    } else if (
      AddDevicesResult?.error?.data?.errors?.[0]?.name === 'DEVICE_LOCAL_AND_PREBACK_CANNOT_BE_TOGETHER' &&
      localPreBackQuoteFFlag === 'TRUE'
    ) {
      dispatch(appMessageActions.clearAppMessages());
      setLocalPreBackErrMsg(AddDevicesResult?.error?.data?.errors?.[0]?.message || '');
      setShowLocalPreBackErrBanner(true);
    }
  }, [AddDevicesResult, AddDevicesResult?.status]);

  // for omni-indirect by default all orders will be local
  const [isFullFillment, setIsFullFillment] = useState(false);
  const [selectedColor, setSelectedColor] = useState();
  const [isPastbalPreBackOrder, setIsPastbalPreBackOrder] = useState(false);
  const [ispuToggleOn, setIspuToggleOn] = useState(false);
  const [isShipItToggleOn, setIsShipItToggleOn] = useState(false);
  const [selectedSku, setSelectedSku] = useState();
  const [selectedProtectionFeature, setSelectedProtectionFeature] = useState(null);
  const [selectedSize, setSelectedSize] = useState();
  const [isNumberShare, setIsNumberShare] = useState(false);
  const [numberShareValue, setNumberShareValue] = useState('');
  const [sharedMtnValue, setSharedMtnValue] = useState('');
  const [enteredDeviceID, setEnteredDeviceID] = useState('');
  const [enteredSimID, setEnteredSimID] = useState('');
  const [devicedata, setDeviceData] = useState({});

  const [downPaymentObj, setDownPaymentObj] = useState();
  const [upgradeReasonType, setUpgradeReasonType] = useState('');
  const [activatedDate, setActivatedDate] = useState('');
  const [selectedPaymentInfo, setSelectedPaymentInfo] = useState('');
  const [deviceContract, setDeviceContract] = useState('');
  const [isBuyoutModalVisible, setIsBuyoutModalVisible] = useState(false);
  const [isBuyoutEligible, setIsBuyoutEligible] = useState(false);
  const { home5g } = props;
  const isByodUpdate = getQueryParamByName('isByodUpdate');
  const prospectByodFlow = getQueryParamByName('prospectByodFlow');
  const [showDeviceProtectionModal, setShowDeviceProtectionModal] = useState(false);
  const [isBuyOutSet, setIsBuyOutSet] = useState(false);
  const [isDeclineBuyout, setIsDeclineBuyout] = useState(false);
  const [buyOutAccepted, setBuyOutAccepted] = useState(false);
  const [isIspuItemInCart, setIsIspuItemInCart] = useState(false);
  const [selectedStore, setSelectedStore] = useState('');
  // Remove line modal
  const [removeLineModal, setRemoveLineModal] = useState(false);
  const [updatePlanChange, setUpdatePlanChange] = useState(false);
  const [isCardExceedLimit, setIsCardExceedLimit] = useState(false);

  console.log(isBuyOutSet, isDeclineBuyout, updatePlanChange);
  const [isTMPScreenOpened, setIsTMPScreenOpened] = useState(false);
  const [tmpLinkClicked, setTmpLinkClicked] = useState(false);
  const [protectionShownStatusInDevice, setProtectionShownStatusInDevice] = useState(false);
  const isFromCPE = !!getQueryParamByName('isFromCPE');
  const [details, setDetails] = useState(productDetails?.deviceProduct || productDetails?.deviceSku?.parentProducts[0]);
  const [detailsUpdate, setDetailsUpdate] = useState();
  const [stockAvailable, setisInStock] = useState(false);
  const [showModalPastbalPreBackOrder, setShowModalPastbalPreBackOrder] = useState(false);
  const [MitekIdVerifyStatus, setMitekIdVerifyStatus] = useState('');
  const [isE911Opened, setIsE911Opened] = useState();
  const [isE911Visible, setIsE911Visible] = useState(false);
  const [initiateAddDeviceCall, SetInitiateAddDeviceCall] = useState('');
  const [skipRedirection, setSkipRedirection] = useState(false);
  const [secondNumDeviceId, setSecondNumDeviceId] = useState('');
  const [secondNumSimId, setSecondNumSimId] = useState('');
  const [secondNumData, setSecondNumData] = useState(productDetails?.dualNumberDetails?.mtns || []);
  const [incompatibleSim, setIncompatibleSim] = useState(false);
  const [ispuSim, setIspuSim] = useState('');
  const isLocalScanFromGridwallDSDS = getQueryParamByName('isLocalScanFromGridwallDSDS');
  const scanFromLanding = getQueryParamByName('scanFromLanding');
  const [displayBuyoutAmount, setDisplayBuyoutAmount] = useState('0.00');
  const [showApplyVVCModal, setShowApplyVVCModal] = useState(false);
  const [vvcEligibleType, setVvcEligibleType] = useState('');
  const [isaacPromo, setIsaacPromo] = useState('');

  // WiFi Backup Transaction Type Logic
    const addWifiTransactionType = sessionStorage.getItem("fiveGHomeInternetSelectedFlow") === "WiFi-Backup";
    let onlyWifiFlowType = "";
    /* istanbul ignore if */
    if (addWifiTransactionType) {
      /* istanbul ignore else */
      if (sessionStorage.getItem("wifiBackupCbandQualified") === "true") {
        onlyWifiFlowType = "WIFIBACKUP_CBD";
      } else if (sessionStorage.getItem("wifiBackupLteQualified") === "true") {
        onlyWifiFlowType = "WIFIBACKUP_LTE";
      }
   }

  // it will execute on sku change update (show warning messages for preorder/backorder)
  useEffect(() => {
    let updateDeviceDetails = productDetails?.deviceProduct || productDetails?.deviceSku?.parentProducts[0];
    const isEditAndView = getQueryParamByName('isEditAndView') === 'true';
    const deviceFromCart = /true/i.test(getQueryParamByName('deviceFromCart'));
    // when childSkus is empty array then set childskus from deviceSku as per BAU
    if (!updateDeviceDetails?.childSkus?.[0] || (isEditAndView && indirect() && !deviceFromCart)) {
      const deviceSku = cloneDeep(productDetails.deviceSku) || {};
      const deviceProduct = deviceSku?.parentProducts?.[0] || {};
      deviceProduct.childSkus = [deviceSku];
      updateDeviceDetails = deviceProduct;
    }
    setDetails(updateDeviceDetails);
  }, [productDetails]);

  useEffect(() => {

    if (SkuDetailsResult?.status === 'fulfilled'&& SkuDetailsResult?.data?.data && flexFlowServiceChange && !/true/i.test(sessionStorage.getItem('provisionalId'))) {

      setDetails(SkuDetailsResult?.data?.data?.deviceSku?.parentProducts?.[0]);
    }
  },[SkuDetailsResult]);

  useEffect(() => {
    const isPreOrder = selectedSku?.inventoryDetails?.dFillInventory?.isPreOrder;
    const isBackOrder = selectedSku?.inventoryDetails?.dFillInventory?.isBackorder;
    const isInStock = selectedSku?.localInventory?.isInStock;
    const isRfexFlow = /true/i.test(sessionStorage.getItem('refundexchange'));
    const btnLabel = getButtonLabel();
    const isPrepayCart = cartDetails?.cart?.orderDetails?.isPrePayCart === 'Y';
    const qtyAvailable = selectedSku?.inventoryDetails?.dFillInventory?.qtyAvailable;

    if (isBackOrder && btnLabel === 'Ship It' && isPrepayCart) {
      const errorMsg = 'Backorder device is not available in prepay orders';
      dispatch(appMessageActions.addAppMessage(errorMsg, 'error', true, true));
    }
    if ((isPreOrder || qtyAvailable === 0) && !isBackOrder && btnLabel === 'Ship It' && isPrepayCart) {
      const errorMsg = 'Preorder device is not available in prepay orders';
      dispatch(appMessageActions.addAppMessage(errorMsg, 'error', true, true));
    }
    if (isRfexFlow && (isPreOrder || isBackOrder) && !isInStock) {
      const errorMsg = 'Cannot add a Pre/Back device as Exchange device. Please pick a different device';
      dispatch(appMessageActions.addAppMessage(errorMsg, 'error', true, true));
    }
    const paymentInfo = customerProfileDetails?.customer?.billAccounts?.[0]?.paymentInfo || {};
    const isBalancePastDueAmount = paymentInfo?.isBalancePastDue || false;
    // show modal for past due amount for pre/back order devices for all channels
    if ((isBackOrder || isPreOrder) && isBalancePastDueAmount) {
      setShowModalPastbalPreBackOrder(true);
      setIsPastbalPreBackOrder(true);
    }
  }, [selectedSku]);
  const [showDeviceCompModal, setShowDeviceCompModal] = useState(false); // To show the Device Plan Compatable Modal

  useEffect(() => {
    const hasConflict = hasISPUAndLocalConflict(cartDetails, bestBuyISPUEnableLocalOrderFFlag);
    setShowISPULocalConflictBanner(hasConflict);
  }, [cartDetails, bestBuyISPUEnableLocalOrderFFlag]);

  useEffect(() => {
    const hideISPU = shouldHideISPUToggle(cartDetails, bestBuyISPUEnableLocalOrderFFlag);
    setShouldHideISPU(hideISPU);
    setShowNonISPULocalBanner(hideISPU);
  }, [cartDetails, bestBuyISPUEnableLocalOrderFFlag]);

  // useEffect(() => {
  //   // when scanned from landing (passing data using moduleProps from ordering to mfe)
  //   if (!isEmpty(transformedValidateDeviceSimIdData) && !isFromCPE) {
  //     updateDeviceData(transformedValidateDeviceSimIdData);
  //   }
  // }, [transformedValidateDeviceSimIdData]);

  /**
   * will display "Device was successfully added to cart" banner and hide after 3 sec
   * @param {Object} cartInfoResponse cartInfo from add-device response
   */
  const displayAddDeviceBanner = (cartInfoResponse) => {
    /* istanbul ignore next */
    if (sessionStorage.getItem('fromLostStolenFlow') === 'true') {
      sessionStorage.removeItem('fromLostStolenFlow');
      return;
    }
    let bannerMessage = ``;
    const downPaymentAmount = cartInfoResponse?.lines?.[0]?.downPaymentAmtApplied;
    let upgradeReasonCodeMsg = '';
    const upgradeReasonCode = cartInfoResponse?.lines?.[0]?.device?.upgradeReasonCode;
    /* istanbul ignore else */
    if (upgradeReasonCode) {
      upgradeReasonCodeMsg = ` with upgrade reason code: ${upgradeReasonCode}`;
    }

    if (isNewLine) {
      bannerMessage = `Device was successfully added to cart`;
    } else if (downPaymentAmount) {
      bannerMessage = `Device with Down Payment of $${downPaymentAmount} was successfully added to cart ${upgradeReasonCodeMsg}`;
    } else {
      bannerMessage = scmDeviceMfeEnable
        ? `Device / SIM ID changed`
        : `Device was successfully added to cart ${upgradeReasonCodeMsg}`;
    }
    dispatch(appMessageActions.addAppMessage(bannerMessage, 'success', true, true));
  };

  const updateDeviceData = (data) => {
    setDeviceData(data);
  };

  const updateDeviceId = (data) => {
    setEnteredDeviceID(data);
    setSelectedDeviceData({ deviceId: data });
  };

  const updateSimId = (data) => {
    setEnteredSimID(data);
  };

  const fetchPricingApiRequired = () => ({
    type: 'FETCHPRICING_API_REQUIRED',
  });

  const landingMtn = customerProfileDetails?.customer?.billAccounts[0]?.mtns?.filter(
    (mtnList) => mtnList.mtn === activeMtn
  );

  const edgeUpEligible = landingMtn?.[0]?.equipmentUpgradeEligibility?.edgeUpEligible ?? false;
  const disableFooter = edgeUpEligible && isBBYLocalOrder && /true/i.test(bestBuyIntegrationFFlag);

  const totalLines = lineDetails?.lineInfo || [];
  const lineInfo = totalLines?.filter((line) => line?.mobileNumber === activeMtn);
  const PdpBuyoutToggle = /true/i.test(includePdpBuyoutToggle);
  const selectedLine = totalLines?.find((line) => line.mobileNumber === activeMtn);
  const buyOutDetail = !!(PdpBuyoutToggle && selectedLine && selectedLine.buyOutDetail);
  const is5GDevice = !!(
    lineInfo &&
    lineInfo.length > 0 &&
    lineInfo[0] &&
    lineInfo[0].deviceTypeSelected === '5G Internet'
  );
  const isAAl = !!(
    lineInfo &&
    lineInfo.length > 0 &&
    lineInfo[0] &&
    (lineInfo[0]?.lineActivityType === 'AAL' ||
      lineInfo[0]?.lineActivityType.includes('NSE') ||
      lineInfo[0]?.lineActivityType === 'BYOD')
  );
  const appPropertiesFromSessionStorage = DOMPurify.sanitize(sessionStorage.getItem('APP_PROPERTIES'));
  const pearlBYODFlow = appPropertiesFromSessionStorage
    ? JSON.parse(appPropertiesFromSessionStorage)?.pearlBYODFlow === 'TRUE'
    : false;
  const isPearl = DOMPurify.sanitize(sessionStorage.getItem('isPearl')) === 'true' && pearlBYODFlow;
  const secondNumLine = totalLines?.filter((line) => line?.secondNumber?.primaryMtn === activeMtn);
  const isNewlyAddedLine = landingMtn && landingMtn[0] ? landingMtn[0].isNewlyAddedLine : isAAl;
  const AALFirstName = lineInfo?.[0]?.serviceInfo?.primaryUserInfo?.firstName || '';
  const preferFirstName = isNewlyAddedLine
    ? AALFirstName
    : landingMtn && landingMtn[0] && landingMtn[0]?.primaryUser?.preferFirstName;
  const primaryfirstname = preferFirstName || (landingMtn && landingMtn[0] && landingMtn[0]?.primaryUser?.firstName);
  const primaryUserName = primaryfirstname ? `${primaryfirstname}` : '';
  const FirstName = primaryUserName || AALFirstName;
  const channel = customerProfileDetails?.customer?.channel;
  const isRfexFlow =
    (sessionStorage.getItem('refundexchange') && sessionStorage.getItem('refundexchange') === 'true') || false;
  let isNewLine = false;
  if (getQueryParamByName('mtn')?.includes('newLine')) {
    isNewLine = true;
  } else if (isNewlyAddedLine) {
    isNewLine = true;
  }

  const fixSCMDeviceChangeIccid = isFunctionalityEnabled(
    FFLAGS?.scmCommonFixFFlag?.name,
    FFLAGS?.scmCommonFixFFlag?.attribute?.fixSCMDeviceChangeIccid
  );
  const isEsimActivationEnabled = isFunctionalityEnabled(
    FFLAGS?.scmCommonDefectFixFFlag?.name,
    FFLAGS?.scmCommonDefectFixFFlag?.attribute?.EsimActivationEnabled,
    FFLAGS?.scmCommonDefectFixFFlag?.attribute?.eSimDbFlag,
  );
  const fiveGDetails = cartLineInfoVal?.filter(
    (line) => line?.deviceTypeSelected && line?.deviceTypeSelected === '5G Internet'
  );
  const isFiveG = isVbg() ? fiveGDetails?.length > 0 : false;

  const getLineValue = () => {
    if (home5g) {
      return 'new line';
    }
    if (isVbgEnabled) {
      const spocName = cartDetails?.data?.cart?.orderDetails?.spocs?.spoc?.name;
      return spocName || FirstName;
    }
    return FirstName;
  };

  const headerData = {
    header: home5g ? '5G Home' : details?.productDisplayName,
    line: getLineValue(),
    mdn: home5g ? '123-456-7891' : activeMtn,
    closeIcon: !!home5g,
  };

  const specsData = details?.techSpecs;
  const inbox = details?.includedAccessories;
  const overview = details?.description;
  const getDfillSim = () => {
    const iccid = ValidateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo?.simInfo?.iccid;
    const isDfill = iccid && Number.isNaN(Number(iccid));
    const flowType = ValidateDeviceSimIdResult?.originalArgs?.body?.data?.lines[0]?.device?.Flowtype;
    if (scmDeviceEnable && isDfill && flowType === 'SIM') {
      return true;
    }
    return false;
  };
  const getButtonLabel = () => {
    const ADDTOCART = 'Add to Cart';
    const SHIPIT = 'Ship It';
    const FINDSTORES = 'Find Stores';
    const UPDATE = 'Update';
    const PICKUP = 'Pick Up';
    const BYOD = 'BYOD';
    const BYTD = 'BYTD';

    let label = ADDTOCART;
    const isWSAPCpeError = Boolean(getQueryParamByName('isWSAPCpeError')) || false;
    const deviceInfo = props?.validateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo;

    const etniApi = deviceInfo?.simInfo2 ? false : deviceInfo?.makeEtniPersApi;
    const isContractChange = !!getQueryParamByName('isContractChange');
    const isBYTDDeviceClicked = getQueryParamByName('isBYTD');
    const showBYTD = getQueryParamByName('isBytdDeviceAdded');
    // const exsistingmtns = props?.cartDetails?.cart?.customerProfile?.billAccounts?.[0]?.mtns || [];
    // const exsistingline = exsistingmtns.some((item) => item?.mtn === props?.activeMtn);

    /* istanbul ignore else */
    if (isShipItToggleOn && !isFromCPE && !isByodUpdate && !isBBYLocalOrder) {
      label = SHIPIT;
    } else if (ispuToggleOn && isIspuItemInCart) {
      label = PICKUP;
    } else if ((!isShipItToggleOn && !ispuToggleOn && !isFromCPE && !isByodUpdate) || isBBYLocalOrder) {
      label = ADDTOCART;
    } else if (isFromCPE && !isWSAPCpeError) {
      const buttonLabel = !(isPearl && (isBYTDDeviceClicked || showBYTD)) ? UPDATE : BYTD;
      label = ispuToggleOn && !etniApi && !isFromCPE ? FINDSTORES : buttonLabel;
    } else if (isByodUpdate) {
      label = BYOD;
    } else if ((isRfexFlow && isContractChange) || isFromCPE) {
      label = UPDATE;
    }
    if (scmDeviceEnable && !scmUpgradeMfeEnable) {
      label = BYOD;
    }
    if (getDfillSim()) {
      label = SHIPIT;
    }
    if (isDWOS) {
      label = SHIPIT;
    }
    return label;
  };

  /**
   * Extract inventory details from selected SKU or product details
   * @returns {Object} inventory details including quantities and stock status
   */
  const getInventoryDetails = () => {
    const localInventory =
      selectedSku?.inventoryDetails?.localInventory || productDetails?.deviceSku?.inventoryDetails?.localInventory;
    const localInventoryisInstock =
      selectedSku?.inventoryDetails?.localInventory?.isInStock ||
      productDetails?.deviceSku?.inventoryDetails?.localInventory?.isInStock;
    const localInventoryQty =
      selectedSku?.inventoryDetails?.localInventory?.qtyAvailable ||
      productDetails?.deviceSku?.inventoryDetails?.localInventory?.qtyAvailable;

    const dFillInventoryInventory =
      selectedSku?.inventoryDetails?.dFillInventory || productDetails?.deviceSku?.inventoryDetails?.dFillInventory;
    const dFillInventoryisInstock =
      selectedSku?.inventoryDetails?.dFillInventory?.isInStock ||
      productDetails?.deviceSku?.inventoryDetails?.dFillInventory?.isInStock;
    const dFillInventoryQty =
      selectedSku?.inventoryDetails?.dFillInventory?.qtyAvailable ||
      productDetails?.deviceSku?.inventoryDetails?.dFillInventory?.qtyAvailable;

    const isPreOrder = selectedSku?.inventoryDetails?.dFillInventory?.isPreOrder;
    const isBackorder = selectedSku?.inventoryDetails?.dFillInventory?.isBackorder;

    return {
      localInventory,
      localInventoryisInstock,
      localInventoryQty,
      dFillInventoryInventory,
      dFillInventoryisInstock,
      dFillInventoryQty,
      isPreOrder,
      isBackorder,
    };
  };

  /**
   * Extract customer and cart context details
   * @returns {Object} customer profile, account attributes, and cart line info
   */
  const getCustomerContext = () => {
    const isIndirect = customerProfileDetails?.commonInfo?.isIndirect || false;
    const accountAttributes = customerProfileDetails?.customer?.billAccounts?.[0]?.accountAttributes || {};
    const { isCashOnly, isCashOnlyExceptCO } = accountAttributes;
    const isCashOnlyCustomer = !!(isCashOnly && isCashOnlyExceptCO && !isIndirect);
    const cartLineInfo = cartDetails?.cart?.lineDetails?.lineInfo || [];
    const lineActivityTypeFromCart = cartLineInfo?.length ? cartLineInfo[0].lineActivityType : '';

    return {
      isIndirect,
      isCashOnlyCustomer,
      lineActivityTypeFromCart,
    };
  };

  // Note: checkNumberShareConditions is defined and exported above (line 178) for unit testing
  // It is used here directly via the exported function

  /**
   * Check inventory availability for ship-it and local pickup
   * @param {Object} invParams - inventory and context parameters
   * @returns {boolean} whether inventory is available
   */
  const checkInventoryAvailability = (invParams) => {
    const {
      contract,
      shipItToggle,
      dFillInventory,
      dFillInstock,
      dFillQty,
      byodUpdate,
      numberShare,
      shareValue,
      ispuToggle,
      localInv,
      localInstock,
      localQty,
    } = invParams;

    // Ship-it toggle enabled
    if (
      contract &&
      shipItToggle &&
      !isEmpty(dFillInventory) &&
      dFillInstock &&
      dFillQty > 0 &&
      !byodUpdate &&
      (!numberShare || (numberShare && shareValue !== ''))
    ) {
      return true;
    }

    // Local pickup (ship-it and ISPU toggles disabled)
    if (
      contract &&
      !shipItToggle &&
      !ispuToggle &&
      !isEmpty(localInv) &&
      localInstock &&
      localQty > 0 &&
      !byodUpdate &&
      (!numberShare || (numberShare && shareValue !== ''))
    ) {
      return true;
    }

    return false;
  };

  const isCartBtnEnable = () => {
    if (hasISPUAndLocalConflict(cartDetails, bestBuyISPUEnableLocalOrderFFlag)) {
      return false;
    }

    if (isBBYLocalOrder) {
      return true;
    }

    if (!isEmpty(selectedSku) || isFromCPE) {
      const inventory = getInventoryDetails();
      const { isIndirect, isCashOnlyCustomer, lineActivityTypeFromCart } = getCustomerContext();

      const isPrePay = cartDetails?.orderDetails?.isPrePayCart === 'Y';
      const isContractChange = /true/i.test(getQueryParamByName('isContractChange'));
      const isRfexFlowBtn = /true/i.test(sessionStorage.getItem('refundexchange'));
      const { deviceId, simId, simLocalId } = devicedata;
      const detailsP = productDetails?.deviceProduct || productDetails?.deviceSku?.parentProducts[0];
      const { isNumberShareMandatory } = detailsP;

      const isNumberShareAndByod = checkNumberShareConditions(
        isFromCPE,
        isByodUpdate,
        isNumberShare,
        numberShareValue,
        isNumberShareMandatory
      );

      // Check early return conditions
      const earlyReturnContext = {
        isIndirectChannel: isIndirect,
        fromCPE: isFromCPE,
        numberShare: isNumberShare,
        shareValue: numberShareValue,
        rfexFlowBtn: isRfexFlowBtn,
        contractChange: isContractChange,
        ispuToggle: ispuToggleOn,
        sku: selectedSku,
        shipItToggle: isShipItToggleOn,
        prePay: isPrePay,
        preOrder: inventory.isPreOrder,
        backorder: inventory.isBackorder,
        dFillQty: inventory.dFillInventoryQty,
        contract: deviceContract,
        pastbalPreBackOrder: isPastbalPreBackOrder,
        cashOnlyCustomer: isCashOnlyCustomer,
        devId: deviceId,
        simCardId: simId,
        numberShareAndByod: isNumberShareAndByod,
        orderDet: orderDetails,
        lineActivityType: lineActivityTypeFromCart,
        protectionFeat: protectionFeatures,
        selectedProtection: selectedProtectionFeature,
        simLocalCardId: simLocalId,
        lineDeviceId: lineDeviceIdFromLanding,
        lineSimId: lineSimIdFromLanding,
        channelType: channel,
      };

      if (shouldEnableCartButton(earlyReturnContext)) {
        return true;
      }

      // Check inventory availability
      const inventoryParams = {
        contract: deviceContract,
        shipItToggle: isShipItToggleOn,
        dFillInventory: inventory.dFillInventoryInventory,
        dFillInstock: inventory.dFillInventoryisInstock,
        dFillQty: inventory.dFillInventoryQty,
        byodUpdate: isByodUpdate,
        numberShare: isNumberShare,
        shareValue: numberShareValue,
        ispuToggle: ispuToggleOn,
        localInv: inventory.localInventory,
        localInstock: inventory.localInventoryisInstock,
        localQty: inventory.localInventoryQty,
      };

      if (checkInventoryAvailability(inventoryParams)) {
        return true;
      }
    }

    console.log('in last return');
    return false;
  };

  const getContractTerm = (selectedContract) => {
    let contractTerm;
    if (selectedContract === 'DEVICE_PAYMENT') {
      contractTerm = 'VERIZON_EDGE';
    } else if (selectedContract === 'MONTH_TO_MONTH' || isByodUpdate || (indirect() && selectedContract === 'M2M')) {
      contractTerm = 'MONTH_TO_MONTH';
    } else if (selectedContract === contractTermLabels.twoYearPrice || selectedContract === contractTerms.TWO_YEAR) {
      contractTerm = contractTerms.TWO_YEAR;
    } else if (isVbg()) {
      if (selectedContract === contractTermLabels.oneYearPrice || selectedContract === contractTerms.ONE_YEAR) {
        contractTerm = contractTerms.ONE_YEAR;
      } else if (selectedContract === contractTermLabels.threeYearPrice || selectedContract === contractTerms.THREE_YEAR) {
        contractTerm = contractTerms.THREE_YEAR;

      } else if (selectedContract === contractTermLabels.thirtyMonthPrice || selectedContract === contractTerms.THIRTY_MONTHS) {
        contractTerm = contractTerms.THIRTY_MONTHS;
      }
    }
    return contractTerm;
  };
  /* istanbul ignore next */
  const tmpScreenOpened = () => {
    setIsTMPScreenOpened(true);
  };

  useEffect(() => {
    const contract = getContractTerm(selectedPaymentInfo?.contractType);
    setDeviceContract(contract);
  }, [selectedPaymentInfo?.contractType]);

  /**
   * get the simid of active mtn from customer profile
   * @returns @string
   */
  const getActiveMtnSimInfo = () => {
    const customerInfo = customerProfileDetails?.customer;
    const activeMtnLineInfo = customerInfo?.billAccounts?.[0]?.mtns?.filter((line) => line?.mtn === activeMtn);
    return activeMtnLineInfo?.[0]?.equipmentInfos?.[0]?.simInfo?.simId;
  };

  /**
   * get the deviceid of active mtn from customer profile
   * @returns @string
   */
  const getActiveMtnDevicenfo = () => {
    const customerInfo = customerProfileDetails?.customer;
    const activeMtnLineInfo = customerInfo?.billAccounts?.[0]?.mtns?.filter((line) => line?.mtn === activeMtn);
    return activeMtnLineInfo?.[0]?.equipmentInfos?.[0]?.deviceInfo?.deviceId;
  };
  const scmFlow = (isSimOnlyChange, validatedSimId) => scmDeviceEnable && isSimOnlyChange && validatedSimId;

  const shouldProcessSimInfo = (validatedSimId, isSimOnlyChange) => {
    const flexFlowSimSale = flexFlowServiceChange && /true/i.test(sessionStorage.getItem('simSaleFlow'));
    const scmFlowValue = scmFlow(isSimOnlyChange, validatedSimId);
    return scmFlowValue || flexFlowSimSale;
  };

  const generateSimInfo = (isProvisionalId, simInfo, deviceSkuId) => {
    const flexFlowProvisional = flexFlowServiceChange && /true/i.test(sessionStorage.getItem('provisionalId'));
    // const addDeviceSimSku = ValidateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo?.simInfo?.launchPackageSku;
    const skuDetailsData = SkuDetailsResult?.data?.data?.deviceSku;

    // avoid reassigning parameters
    let sim = simInfo;
    let skuId = deviceSkuId;
    /* istanbul ignore next */
    if (isProvisionalId || flexFlowProvisional) {
      sim = {
        id: skuDetailsData?.simSku,
        iccid: enteredSimID,
        isCustomerProvidedSIM: true,
      };
      skuId = skuDetailsData?.sorId;
      console.log('SkuDetailsResult', SkuDetailsResult);
    }

    return { simInfo: sim, deviceSkuId: skuId };
  };

  const addEtrServiceChangesIfEnabled = (reqBody) => {
    if (flexFlowServiceChange) {
      return {
        ...reqBody,
        data: {
          ...reqBody.data,
          etrServiceChanges: true,
        },
      };
    }
    return reqBody;
  };

  const isVbgProfessionalInstall = () => {
    const addressRequest = customerProfileDetails?.customer?.qualificationDetails?.addressRequest || {};
    const fiveGHomeQualified = addressRequest.fiveGHomeQualified === 'true' || addressRequest.fiveGHomeQualified === true;
    const isTanglewoodQualified = addressRequest.tanglewoodQualified === 'true' || addressRequest.tanglewoodQualified === true;
    return vbgFwaProfInstallOrderingFFlag && (fiveGHomeQualified || isTanglewoodQualified);
  };

  const getOneTalkConfig = (isOneTalkDevice, vbgnsaOneTalkFFlag) =>
    isVbg() && vbgnsaOneTalkFFlag && isOneTalkDevice ? { isOnetalk: isOneTalkDevice } : {};

  const addToCart = async (cartInfo, reqData, fetData) => {/* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */
    /* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */
    const lineDetailsInfo = cartDetails?.cart?.lineDetails?.lineInfo;
    const newLineInfo = lineDetailsInfo?.find((line) => line?.mobileNumber === activeMtn);
    const is5GDeviceSelected = newLineInfo?.deviceTypeSelected === '5G Internet';
    const fiveGSelected = scmUpgradeMfeEnable && is5GDeviceSelected;
    const is5GDeviceSimplification = is5GDeviceSelected;
    /* istanbul ignore next */
    const { homeSalesAddress = {} } = customerProfileDetails?.customer || {};
    const { cbandQualified = false } = homeSalesAddress;
    const cbandValues = {
      cbandQualified,
    };
    const wifiBackupCbandQualified = /true/i.test(sessionStorage.getItem('wifiBackupCbandQualified'));
    const wifiBackupLteQualified = /true/i.test(sessionStorage.getItem('wifiBackupLteQualified'));
    const vbgnsaOneTalkFFlag = /true/i.test(JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.vbgnsaOneTalkFFlag?.toLowerCase() ?? 'false');
    /* istanbul ignore next */
    const LandingCband = Boolean(cbandValues.cbandQualified);
    const isHomeSales = /true/i.test(customerProfileDetails?.customer?.isHomeSales);
    /* istanbul ignore next */
    const getHomeSalesAddressDetails = customerProfileDetails?.customer?.homeSalesAddressList?.[0] ?? {};
    const addressRequest = customerProfileDetails?.customer?.qualificationDetails?.addressRequest || {};
    const isOneTalkDevice = details?.isOneTalkDevice;
    let isESimOnly = getQueryParamByName('eSim') || devicedata?.eSimOnlyDevice;
    const isBYODUpg = getQueryParamByName('isByodUpdate'); // Upgrade DEVICE_ONLY change
    const isBYODAAL = (getQueryParamByName('isByodUpdate') || getQueryParamByName('isFromCPE') === 'true') && isNewLine; // AAL BYOD
    const isSecondNumDfill = sessionStorage.getItem('isSecondNumDfill');
    const hashMTN = getQueryParamByName('mtn');
    const isEditAndView = getQueryParamByName('isEditAndView') === 'true'; // edit pdp scenario
    const isLocalFromQuery = getQueryParamByName('isLocal') ? 'L' : 'F';
    const isBYTDDeviceClicked = getQueryParamByName('isBYTD');
    const trialEId = getQueryParamByName('trialEId');
    const ByodDeviceCompitable = /true/i.test(getQueryParamByName('ByodDeviceCompitable'));
    const UpcCodeData = upcCodeFromPdpScan || '';
    /* istanbul ignore next */
    const isProvisionalId =
      scmDeviceEnable &&
      ValidateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo?.deviceAttributes?.mfgCode ===
        'PDI';
    const isVideoAssistFlow = /true/.test(productDetails?.accountInfo?.isVideoAssistFlow);
    let depletionType = isLocalFromQuery;
    const isByod = !!(isBYODUpg || isBYODAAL || isFromCPE);
    // eslint-disable-next-line no-nested-ternary
    const depletionLocationCode = isBBYLocalOrder
      ? lcLocationCode
      : selectedStore && isIspuItemInCart && (ispuToggleOn || (isFromCPE && channel === 'OMNI-TELESALES'))
      ? selectedStore?.netaceLocationCode
      : '';
    const ispuItemOnCart =
      !isESimOnly &&
      isIspuItemInCart &&
      (ispuToggleOn || (isFromCPE && channel === 'OMNI-TELESALES')) &&
      depletionLocationCode
        ? isIspuItemInCart
        : false;

    // device and sim items in the cart for the active/selected line
    const simItemInCart = getRetrieveCartInfo(cartDetails, activeMtn, 'SIM');
    const deviceItemInCart = getRetrieveCartInfo(cartDetails, activeMtn, 'DEVICE');

    // get the sim id from the cart for the active/selected line
    const cartEsimVal = simItemInCart?.eSIM;

    // check if deviceFromCart param or if device item object is there in cart for the active/selected line
    const deviceFromCart =
      /true/i.test(getQueryParamByName('deviceFromCart')) ||
      (!getQueryParamByName('isLocal') && !isFromCPE && deviceItemInCart);

    // If actionIndicator not send from API Handling it from UI
    const actionIndicator = fetData?.actionIndicator ? fetData?.actionIndicator : '';

    const ESimYes = Boolean(devicedata?.etniApi);
    if (!isESimOnly) {
      isESimOnly = !isEmpty(devicedata) ? ESimYes : deviceFromCart && Boolean(cartEsimVal);
    }
    // when channel is retail and ship it toggle ON pass deplationtype as F
    if (
      ispuToggleOn ||
      (((isRetail() && !isD2D()) || indirect()) && (isBYODUpg || isBYODAAL)) ||
      (lineInfo[0] && lineInfo[0]?.lineActivityType === 'CCH') ||
      (!isShipItToggleOn && !ispuToggleOn && !isD2D()) ||
      isBBYLocalOrder
    ) {
      depletionType = 'L';
    } else if (isTelesales() || isD2D() || (isRetail() && isShipItToggleOn) || (indirect() && isShipItToggleOn)) {
      depletionType = 'F';
    } else {
      depletionType = isLocalFromQuery;
    }
    if (isVideoAssistFlow && isRetail() && isIpad() && isFromCPE && !isESimOnly) {
      depletionType = 'F';
    }
    if (isDWOS) {
      depletionType = 'F';
    }
    const qualificationType = sessionStorage.getItem('Qualification_type');
    const hs_qualificationType = JSON.parse(sessionStorage.getItem('homesalesQualification_type'));
    const LTEorCBandQualified =
      is5GDevice &&
      (qualificationType === 'CBD' ||
        qualificationType === 'LTE' ||
        hs_qualificationType?.cbandQualified ||
        hs_qualificationType?.ltequalified);
    const validatedSimId = enteredSimID || getQueryParamByName('simId') || devicedata?.simLocalId || '';
    const preferredSoftSim =
      isLocalScanFromGridwallDSDS || getQueryParamByName('preferredSoftSim')
        ? getQueryParamByName('preferredSoftSim')
        : devicedata?.preferredSoftSim;
    const launchPackageSku = devicedata?.launchPackageSku || getQueryParamByName('launchPackageSku');
    let cpSimCard = true;
    // when scanning from landing and gridwall then get it from queryparams;
    if (isEmpty(devicedata) && getQueryParamByName('cpSimCard') === 'false') cpSimCard = false;
    if (devicedata?.cpSimCard === false) cpSimCard = devicedata?.cpSimCard;
    let isCustomerProvidedSIM = getActiveMtnSimInfo() === validatedSimId ? false : cpSimCard;
    if (isBYODUpg && getActiveMtnSimInfo() === validatedSimId) {
      isCustomerProvidedSIM = true;
    }
    let simSku = '';
    if (validatedSimId && preferredSoftSim) {
      simSku = preferredSoftSim;
    } else if (!validatedSimId && getQueryParamByName('simId')) {
      simSku = getQueryParamByName('simId');
    } else if (
      skipIccidCall === 'TRUE' &&
      !validatedSimId &&
      (isBYODUpg || isBYODAAL || isLocal) &&
      isESimOnly &&
      preferredSoftSim
    ) {
      simSku = preferredSoftSim;
    } else if (selectedSku?.simSku && !isBYODUpg && !isBYODAAL) {
      // Local flow when user has not entered sim id or there is no existing sim id and validate response does not send us iccid
      simSku = selectedSku?.simSku;
    } else if (selectedSku?.simSku && devicedata?.eSimEtniApi === true && skipIccidCall === 'TRUE') {
      simSku = selectedSku?.simSku;
    }

    // logic specific to care only
    let simSkuChange = false;
    let isSimOnlyChange = false;
    if (isOmniCare && isBYODUpg && simSkuEntered) {
      simSku = simSkuEntered;
      simSkuChange = true;
    }
    if (isBYODUpg && !isNewLine && reqData?.validatedDeviceId === getActiveMtnDevicenfo() && validatedSimId !== '') {
      isSimOnlyChange = true;
    }

    if ((isBYODUpg || isBYODAAL) && launchPackageSku && enteredSimID && !isESimOnly) {
      // BYOD casese when sim id is entered and not esim
      simSku = launchPackageSku;
    }

    if (isSecondNumDfill) {
      simSku = getQueryParamByName('simId');
    }

    const simFourG = {
      id: 'DFILLSIM-TRI-A',
      iccid:
        (qualificationType === 'LTE' ||
          qualificationType === 'CBD' ||
          hs_qualificationType?.ltequalified ||
          hs_qualificationType?.cbandQualified) &&
        productDetails &&
        productDetails?.simId
          ? productDetails?.simId
          : '',
      isCustomerProvidedSIM: false,
    };
    const detailsList = productDetails?.deviceProduct || productDetails?.deviceSku?.parentProducts[0];
    const cartLineInfo = cartDetails?.cart?.lineDetails?.lineInfo || [];
    let lineActivityTypeFromCart = cartLineInfo?.length ? cartLineInfo[0].lineActivityType : '';
    if (lineActivityTypeFromCart === '' && !isNewLine) {
      lineActivityTypeFromCart = 'EUP';
    }
    const customerType = orderDetails?.customerType || '';
    const isCustomerTypeNew =
      orderDetails?.customerType === 'N' || lineActivityTypeFromCart === 'BYOD' || lineActivityTypeFromCart === 'AAL';
    // const iccidDfill = devicedata?.etniApi === false && devicedata?.eid === '' && !isRetail() && isByod;
    // eslint-disable-next-line no-restricted-globals
    const isEnteredSimNAN = validatedSimId && isNaN(validatedSimId);
    const iccidDfill = devicedata?.etniApi === false && devicedata?.eid === '' && isEnteredSimNAN && isByod;
    let eSIMObj = {};
    if (!isByod && isShipItToggleOn) {
      eSIMObj = {};
    }
    if (
      (skipIccidCall === 'TRUE' || /true/i.test(sessionStorage.getItem('isSecondNumFlow'))) &&
      (isESimOnly || !isEmpty(devicedata?.eid))
    ) {
      eSIMObj = { eSIM: devicedata?.eid || getQueryParamByName('eId') || cartEsimVal };
    } else if (ESimYes || isESimOnly) {
      eSIMObj = { eSIM: scmDeviceEnable ? devicedata.eid : validatedSimId };
    }
    const simId = {
      id: '',
      iccid: (skipIccidCall === 'TRUE' && isESimOnly) || iccidDfill ? '' : validatedSimId,
      ...eSIMObj,
      isCustomerProvidedSIM,
    };

    // omni care sim only change scenario making iccid as empty
    if (
      !(scmDeviceEnable && getActiveMtnDevicenfo() !== devicedata.deviceId) &&
      simSkuChange &&
      (!ESimYes || !isESimOnly)
    )
      simId.iccid = '';
    // CXTDT-564065 edit byod scenario - setting sim object info in add-device request
    if (
      isEditAndView &&
      isByod &&
      isESimOnly &&
      !isRetail() &&
      getQueryParamByName('simId') &&
      skipIccidCall !== 'TRUE'
    ) {
      if (scmDeviceEnable) {
        simId.id = devicedata.preferredSoftSim;
      } else simId.id = simItemInCart?.itemCode || '';
      simId.iccid = getQueryParamByName('simId');
    } else if (
      !devicedata?.preferredSoftSim &&
      !getQueryParamByName('eSim') &&
      !isRetail() &&
      getQueryParamByName('simId') &&
      !getQueryParamByName('isConnectedDevice')
    ) {
      // omni care psim only scenario taking dfill sku from params and iccid making empty
      simId.id = simSkuEntered || getQueryParamByName('simId');
      simId.iccid = '';
    } else if (isLocalScanFromGridwallDSDS) {
      simId.id = preferredSoftSim;
    } else if (devicedata?.preferredSoftSim) {
      simId.id = devicedata.preferredSoftSim;
    } else if (simSku === validatedSimId) {
      simId.id = detailsList?.defaultSKUObj?.simSku;
    } else if (
      !isRetail() &&
      skipIccidCall === 'TRUE' &&
      isEditAndView &&
      !devicedata?.preferredSoftSim &&
      !getQueryParamByName('eSim') &&
      !getQueryParamByName('isConnectedDevice')
    ) {
      simId.id = simFromFilteredCartLine?.itemCode;
      simId.iccid = '';
    } else {
      simId.id = simSku || '';
    }

    if ((isBYODUpg || isBYODAAL) && launchPackageSku && enteredSimID && !isESimOnly && (isRetail() || indirect())) {
      // BYOD casese when sim id is entered and not esim
      simId.id = simSku;
    }
    /* istanbul ignore next */
    if (editbyodSimIdFFlag && isEditAndView && (isBYODUpg || isBYODAAL) && !isESimOnly && (isRetail() || indirect())) {
      const cartSimId = simFromFilteredCartLine?.itemCode;
      simId.id = launchPackageSku && enteredSimID ? simSku : cartSimId;
    }

    if ((isBYODAAL || isBYODUpg) && ispuItemOnCart && getIspuSimEnable()) {
      // BYOD AAL case When ISPU Item is in cart
      if (ispuSim) {
        simId.id = ispuSim;
        simId.iccid = '';
      } else {
        simId.id = TELESALES_ISPU_SIM_SORID;
        simId.iccid = '';
      }
    }
    const SimId = simId.id && !incompatibleSim ? simId : null;
    const isfourGAddress = LTEorCBandQualified;
    const e911Address = details?.isE911Address || isNumberShare ? isE911Opened : undefined;
    const tanglewoodQualified =
      cartDetails?.cart?.lineDetails?.lineInfo?.length > 0 &&
      cartDetails?.cart?.lineDetails?.lineInfo?.find((line) => line.mobileNumber === activeMtn)?.tanglewoodSelected ===
        'Y';
    let deviceSkuId;
    if (devicedata?.etniApi || (isByod && devicedata?.skuId)) {
      deviceSkuId = devicedata?.skuId;
    } else {
      deviceSkuId = reqData?.id;
    }

    if (isSecondNumDfill) {
      simId.isCustomerProvidedSIM = false;
      simId.iccid = '';
      depletionType = 'F';
    }
    /* istanbul ignore else */
    if (isScmSecondNumPerkEnabled) {
      depletionType = 'F';
      simId.iccid = '';
    }
    // Handle eSIM regeneration - clear ICCID and set isCustomerProvidedSIM to false
     /* istanbul ignore next */
    if (
      isESimRegenerated &&
      ((esimAPIskipFFlag && flexFlowServiceChange) || (scmDeviceEnable && isEsimActivationEnabled))
    ) {
      simId.isCustomerProvidedSIM = false;
      simId.iccid = '';
      if (scmDeviceEnable && isEsimActivationEnabled) {
        simId.eSIM = devicedata.eid;
      }
    }

    let actionIndicatorValue;

    if (actionIndicator === '') {
      if (!isSimOnlyChange && isCustomerTypeNew) {
        actionIndicatorValue = 'A';
      } else {
        actionIndicatorValue = 'Z';
      }
    } else {
      actionIndicatorValue = actionIndicator;
    }
    const lineNumber =
      cartDetails?.cart?.lineDetails?.lineInfo?.length > 0 &&
      cartDetails?.cart?.lineDetails?.lineInfo?.find((line) => line?.mobileNumber === activeMtn)?.lineNumber;
    const preBackOrderDate =
      isBYODUpg || isBYODAAL ? '' : getProp(selectedSku, 'inventoryDetails.dFillInventory.shippingDate.date') || '';
    const preBackOrderDateFormatted = preBackOrderDate
      ? mPosFormatDate(preBackOrderDate, 'MM-DD-YYYY', 'MM/DD/YYYY')
      : '';
    const isDfoSelected = true;
    let sellerPrice = downPaymentObj?.sellerPrice || deviceFromFilteredCartLine?.sellerPrice || 0;

    /* istanbul ignore next */
    if (indirectSellerPriceFFlag) {
      const cartSellerPrice =
        deviceSkuId === deviceFromFilteredCartLine?.sorId ? deviceFromFilteredCartLine?.sellerPrice : 0;

      // Prioritize the down payment seller price, fallback to the cart seller price
      sellerPrice = downPaymentObj?.sellerPrice || cartSellerPrice;
    }

    /* istanbul ignore next */
    let simInfo = isfourGAddress ? simFourG : SimId;
    // /* istanbul ignore if */ throws error in icov report test file
    const imeiIssueFielddt4360fixFFlag =
      JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.imeiIssueFielddt4360fixFFlag === 'TRUE';
    const deviceIdIssueFFlag = JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.deviceIdIssueFFlag === 'TRUE';
    const estimateReadyDateFFlag =
      JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.estimateReadyDateFFlag === 'TRUE';
    const byodSearchDeviceIdFFlag =
      JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.byodSearchDeviceIdFFlag === 'TRUE';
    const getWifiBackupIntendType = (customerTypeParam, wifiCbandQualifiedParam, wifiLteQualifiedParam) => {
      const isNewCustomer = customerTypeParam === 'N';
      /* istanbul ignore next */
      if (wifiCbandQualifiedParam) {
        return isNewCustomer ? 'NSE_5G' : 'AAL_5G';
      }
      /* istanbul ignore next */
      if (wifiLteQualifiedParam) {
        return isNewCustomer ? 'NSE_LTE' : 'AAL_LTE';
      }
      /* istanbul ignore next */
      return '';
    };
    const {
      LTEQualified = false,
      cBandQualified = false,
      VHILiteQualified = false,
      fiveGHomeQualified = false,
      tanglewoodQualified: isTanglewoodQualified = false,
    } = customerProfileDetails?.customer?.qualificationDetails?.addressRequest || {};
    const isFWASimplificationEnabledEC = customerProfileDetails?.customer?.isFWASimplificationEnabled;
    const isSimplifiedCband = '';
    const isVHILiteQualified = getVhiLiteQualifiedForIntentType(VHILiteQualified);
    let LTECBDIntendType = getLteCbdIntendType(LTEQualified, isVHILiteQualified, qualificationType, customerType);
    // Refactored logic for LTECBDIntendType assignment based on customerType and wifiBackup qualification
    /* istanbul ignore if */
    if (onlyWifiFlowType && addWifiTransactionType) {
      const intendType = getWifiBackupIntendType(customerType, wifiBackupCbandQualified, wifiBackupLteQualified);
      if (intendType) {
        LTECBDIntendType = intendType;
      }
    }
    const imei1 = ValidateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo?.imei1;
    const imei2 = ValidateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo?.imei2;
    let imeiToBeSent =
      imeiIssueFielddt4360fixFFlag && imei2 === reqData?.validatedDeviceId && !isByod
        ? imei1
        : reqData?.validatedDeviceId;
    let fourGAddressRequest = {};
    /* istanbul ignore if */
    if (LTEorCBandQualified) {
      if (cBandQualified || LTEQualified || qualificationType === 'LTE' || qualificationType === 'CBD') {
        fourGAddressRequest = getAddressInfo(addressRequest, '');
      }
    }
    const multiLineSeqNumber = lineDetails?.lineInfo
      ?.find((line) => line?.mobileNumber === activeMtn)
      ?.multiLineSeqNumber?.toString();

    let wifibackupAddressDetails = {};
    /* istanbul ignore if */
    if (onlyWifiFlowType !== '') {
      wifibackupAddressDetails = getAddressInfo(addressRequest, '');
    }
    const homeSalesFourGHomeRequest = getAddressInfo(getHomeSalesAddressDetails, '');
    // CXTDT-723185: BYOD search by device scenario
    // get the deviceId from the validateDeviceSimIdResult (whatever was scanned/entered)
    if (byodSearchDeviceIdFFlag && ByodDeviceCompitable && isByod) {
      const imeiValidateDeviceSimid =
        ValidateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo?.deviceId || '';
      if (imeiValidateDeviceSimid === '' && deviceIdIssueFFlag && getQueryParamByName('deviceId')) {
        imeiToBeSent = getQueryParamByName('deviceId');
      } else {
        imeiToBeSent = imeiValidateDeviceSimid;
      }
    }
    let deviceIdReq = '';
    const assignDeviceID = () => {
      /**
       * Passing the device id if byod flag is true and changing the depletionType as "L"
       */
      const deviceIdPassForByod =
        JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.deviceIdPassForByodFFlag === 'TRUE';
      if (deviceIdPassForByod && getQueryParamByName('deviceId') && (isBYODAAL || isBYODUpg) && isRetail()) {
        depletionType = 'L';
        deviceIdReq = imeiToBeSent;
      }
    };
    deviceIdReq = isRetail() && depletionType === 'F' ? '' : imeiToBeSent;
    assignDeviceID();
    const getSimInfo = generateSimInfo(isProvisionalId, simInfo, deviceSkuId);
    simInfo = getSimInfo.simInfo;
    deviceSkuId = getSimInfo.deviceSkuId;

    const simSaleInfo = shouldProcessSimInfo(validatedSimId, isSimOnlyChange);
    const simSaleSku = SkuDetailsResult?.data?.data?.deviceSku?.simSku;
    /* istanbul ignore next */
    if (simSaleInfo && !(isEsimActivationEnabled && isESimRegenerated && scmDeviceEnable)) {
      simInfo = {
        id: simSaleSku,
        iccid: validatedSimId,
        isCustomerProvidedSIM: true,
      };
      if (validatedSimId && !isNumeric(validatedSimId)) {
        simInfo.iccid = '';
        simInfo.id = validatedSimId;
        simInfo.isCustomerProvidedSIM = false;
      }
    }

    const getLoanOfferId = (loanOfferId) => {
      if (elvisFFlag && deviceContract === 'VERIZON_EDGE') {
        return { loanOfferId };
      }
      return {};
    };
    // Helper function to determine VBG bandwidth type
    const getVbgBandwidthType = (isCBDQualified) => {
      if (vbgFwaProfInstallOrderingFFlag) {
        // From BE we are getting  fiveGHomeQualified as string
        if (fiveGHomeQualified === 'true') return 'MMW';
        if (isTanglewoodQualified) return 'TGW';
      }
      return isCBDQualified ? 'CBD' : 'LTE';
    };

    // Helper function to determine network bandwidth type based on conditions
    const getNetworkBandwidthType = () => {
      const isCBDQualified = cBandQualified || qualificationType === 'CBD' || hs_qualificationType?.cbandQualified;

      if (isVbgEnabled && is5GDeviceSimplification) {
        return getVbgBandwidthType(isCBDQualified);
      }

      if (onlyWifiFlowType === 'WIFIBACKUP_CBD') {
        return 'CBD';
      }
      /* istanbul ignore if */
      if (onlyWifiFlowType === '' && isfourGAddress === true) {
        return isCBDQualified || LandingCband ? 'CBD' : 'LTE';
      }

      /* istanbul ignore if */
      if (is5GDeviceSimplification === true && isFWASimplificationEnabledEC === true) {
        return isCBDQualified || isSimplifiedCband ? 'CBD' : 'LTE';
      }

      return 'LTE';
    };

    // Helper function to get network bandwidth configuration
    const getNetworkBandwidthConfig = () => {
      if (isVbgEnabled && is5GDeviceSimplification) {
        return { networkBandwidthType: getNetworkBandwidthType() };
      }
      if (!fiveGSelected) {
        return {};
      }

      return { networkBandwidthType: getNetworkBandwidthType() };
    };

    // Helper function to get 5G related configurations
    const getFiveGRelatedConfigs = () => {
      if (!fiveGSelected) {
        return {};
      }

      return {
        isNewLine,
        multiLineSeqNumber,
        newLineOrAAL: isNewLine,
      };
    };
    const numbersharePairingMode = getNumberSharePairingMode();
    // if(getActiveMtnSimInfo() === validatedSimId && getActiveMtnDevicenfo() === reqData?.validatedDeviceId && scmDeviceEnable){
    //    simInfo.iccid = '';
    //     // simInfo.id = validatedSimId;
    //     simInfo.isCustomerProvidedSIM = false;
    // }
    /*istanbul ignore next */
    if (details?.sorDeviceCategory === 'IP Virtual Device' && vbgnsaOneTalkFFlag) {
      depletionType = 'O';
    }

    let fiveGConfig = {};
    /* istanbul ignore next */
    if (fiveGSelected && isfourGAddress) {
      fiveGConfig = { fiveG: isHomeSales ? fourGAddressRequest : homeSalesFourGHomeRequest };
    } else if (fiveGSelected && onlyWifiFlowType !== '') {
      fiveGConfig = { fiveG: wifibackupAddressDetails };
    } else if (isVbgEnabled && is5GDeviceSimplification) {
      fiveGConfig = { fiveG: getAddressInfo(addressRequest, '') };
    }
    let reqBody = {
      ...initialRequestAddDevice,
      cartInfo,
      /* istanbul ignore next */
      data: {
        lines: [
          {
            mtn: getQueryParamByName('offerEligible') ? getQueryParamByName('activeMtn') : cartInfo.processingMTN,
            lineDeviceDollar: 0,
            lineNumber,
            activateLaterDate: activatedDate || '',
            upgradeReasonCode: upgradeReasonType || '',
            device: {
              category: reqData?.category,
              deviceId: deviceIdReq,
              id: deviceSkuId,
              sorType: '',
              contractTerm: isByod ? 'MONTH_TO_MONTH' : deviceContract,
              dppMonths:
                selectedPaymentInfo?.contractType === 'MONTH_TO_MONTH' ||
                Object.values(contractTermLabels).includes(selectedPaymentInfo?.contractType) ||
                isByod
                  ? ''
                  : selectedPaymentInfo?.term ||
                    selectedSku?.price?.devicePaymentPrice?.[0]?.dpTermPrices?.dpTerm ||
                    '',
              isCustomerProvidedEquipment: isByod,
              isNonVZDeviceSku: false,
              isDfoSelected: selectedPaymentInfo?.paymentType === '$vvcPaymentOption' ? isDfoSelected : false,
              dfoTerms: selectedPaymentInfo?.paymentType === '$vvcPaymentOption' ? selectedPaymentInfo?.term : '',
              ...getLoanOfferId(
                selectedSku?.price?.devicePaymentPrice?.[0]?.dpTermPrices?.loanOfferDetails?.loanOfferId
              ),
              ...getNetworkBandwidthConfig(),
            },
            ...fiveGConfig,
            ...getFiveGRelatedConfigs(),
            sim: simInfo,
            ...(tanglewoodQualified ? {} : { sim: simInfo }),
            ...numbersharePairingMode,
            addFeatures: [
              {
                id: fetData?.sorId,
                quantity: 1,
                actionIndicator: actionIndicatorValue,
                type: fetData?.featureType || (isFromCPE ? 'SFO' : selectedProtectionFeature?.featureType),
              },
            ],
            downPayment: {
              amount:
                downPaymentObj?.downPayment || filteredLineFromCart?.installmentInfo?.userSelectedDownPayment || 0,
              verizonDollars:
                downPaymentObj?.verizonDollars || filteredLineFromCart?.installmentInfo?.verizonDollarsDownpayment || 0,
            },
            e911Address,
            isKeepingExistingEqProtection: false,
            ispuFlow: ispuItemOnCart,
            ...getOneTalkConfig(isOneTalkDevice, vbgnsaOneTalkFFlag),
            estimatedReadyByDate: estimateReadyDateFFlag ? selectedStore?.estimatedReadyByDate || '' : '',
            depletionLocationCode,
            depletionType,
            sddZipCode: '',
            preBackOrderDate:
              depletionType && depletionType === 'L' && !ispuItemOnCart ? '' : preBackOrderDateFormatted,
            isByod,
            ...(numberShareValue !== '' &&
            isNumberShare &&
            (details?.isNumberShareCapable || details?.isNumberShareMandatory)
              ? { trunkMtn: numberShareValue }
              : {}),
            triggerPricingValidation: true,
            sellerPrice,
          },
        ],
        selectedMtn: hashMTN || '',
        totalDeviceDollar: null,
        enableAssistedTagging: true,
      },
    };

    const updatedReqBody = addEtrServiceChangesIfEnabled(reqBody);
    reqBody = updatedReqBody;
    // Helper function to determine intent type based on customer and flow conditions
    const getBaseIntentType = () => {
      const isNewCustomer = customerType === 'N';
      const hasByodFlow = isBYODAAL || isProspectByodFlow;
      /* istanbul ignore next */
      if (isNewCustomer && hasByodFlow) {
        return 'NSEBYOD';
      }
      /* istanbul ignore if */
      if (isNewCustomer) {
        return 'NSE';
      }
      /* istanbul ignore if */
      if (isBYODAAL) {
        return 'BYOD';
      }
      /* istanbul ignore next */
      if (isBYODUpg) {
        return 'EUPBYOD';
      }
      /* istanbul ignore next */
      if (isNewLine) {
        return 'AAL';
      }
      /* istanbul ignore next */
      return 'EUP';
    };

    // Helper function to handle second number data fill override
    const getIntentTypeWithSecondNumOverride = (baseIntentType) => {
      // use outer isSecondNumDfill instead of redeclaring
      /* istanbul ignore if */
      if (!isSecondNumDfill) {
        return baseIntentType;
      }
      /* istanbul ignore next */
      return customerType !== 'N' ? 'BYOD' : 'NSEBYOD';
    };

    // Helper function to handle 5G transaction type configuration
    const configure5GTransactionType = () => {
      const transactionType = sessionStorage.getItem('fiveGHomeInternetSelectedFlow');
      if (fiveGSelected && transactionType === 'WiFi-Backup') {
        // mutate outer reqBody (not a function parameter) to avoid no-param-reassign
        reqBody.data.lines[0].transactionType = 'WIFIBACKUP';
        reqBody.cartInfo.transactionType = 'WIFIBACKUP';
      }
    };

    // Helper function to set intent type for 5G flows
    const set5GIntentType = (intentTypeData) => {
      /* istanbul ignore next */
      if (fiveGSelected) {
        const shouldUseLTECBD = is5GDevice || onlyWifiFlowType !== '';
        reqBody.cartInfo.intendType = shouldUseLTECBD ? LTECBDIntendType : intentTypeData;
      }
      /* istanbul ignore next */
      if (isVbgEnabled && is5GDeviceSimplification) {
        reqBody.cartInfo.intendType = getNetworkBandwidthType() === 'LTE' ? 'NSE_LTE' : 'NSE_5G';
      }
    };

    // Apply the logic using helper functions
    const baseIntentType = getBaseIntentType();
    const intentTypeData = getIntentTypeWithSecondNumOverride(baseIntentType);

    configure5GTransactionType();
    set5GIntentType(intentTypeData);

    if (isProvisionalId || (flexFlowServiceChange && /true/i.test(sessionStorage.getItem('provisionalId')))) {
      reqBody.data.lines[0].device.provisionalIdIndicator = 'Y';
    }
    if (
      details?.childSkus?.[0]?.skuDisplayName?.includes('Iconic Service') &&
      (prospectByodFlow || isBYODAAL || isBYODUpg)
    ) {
      reqBody.data.lines[0].device.isNonVZDeviceSku = true;
      if (reqBody.data.lines[0].device.id === 'ICONIC-SERVICE-SKU') {
        reqBody.data.lines[0].device.id = getQueryParamByName('deviceSKU');
      }
    }
    const networkBandwidthTypes = ['MMW', 'TGW'];
    if (vbgFwaProfInstallOrderingFFlag && networkBandwidthTypes.includes(getNetworkBandwidthType())) {
      reqBody.data.lines[0].depletionType = 'O';
    }
    const channelNames = ['OMNI-INDIRECT', 'OMNI-INDIRECT-TAB', 'OMNI-RETAIL', 'OMNI-RETAIL-TAB'];
    if (disableEsimAtLocalInventory !== 'TRUE' && !isBYODUpg && !isBYODAAL && channelNames.includes(channel)) {
      const lineDetailsInfoLocal = cartDetails?.cart?.lineDetails?.lineInfo;
      const newLineInfoLocal = lineDetailsInfoLocal?.find((line) => line?.mobileNumber === activeMtn);
      const selectedNewLineSimInfo = getProp(newLineInfoLocal, 'itemsInfo[0].cartItems.cartItem', []).find(
        (cartItem) => cartItem.cartItemType === 'SIM'
      );
      const selectedNewLineDeviceInfo = getProp(newLineInfoLocal, 'itemsInfo[0].cartItems.cartItem', []).find(
        (cartItem) => cartItem.cartItemType === 'DEVICE'
      );

      // samsung motorola devices
      if (
        getQueryParamByName('isScanDsDs') ||
        (devicedata?.simClass4G === 'NP' && scanFromLanding && devicedata?.eDeviceId)
      ) {
        const skuId = devicedata?.skuId || getQueryParamByName('skuId');
        const pDeviceId = devicedata?.pDeviceId || getQueryParamByName('pDeviceId');
        const eDeviceId = devicedata?.eDeviceId || getQueryParamByName('eDeviceId');
        const physicalSku = devicedata?.physicalSku || getQueryParamByName('physicalSku');

        reqBody.data.lines[0].device.id = physicalSku;
        reqBody.data.lines[0].device.eDeviceSku = skuId;
        reqBody.data.lines[0].device.deviceId = pDeviceId;
        reqBody.data.lines[0].device.pDeviceId = pDeviceId;
        reqBody.data.lines[0].device.eDeviceId = eDeviceId;

        // sim info object
      } else if (deviceFromCart && selectedNewLineDeviceInfo?.eDeviceId) {
        reqBody.data.lines[0].device.deviceId = selectedNewLineDeviceInfo.deviceId;
        reqBody.data.lines[0].device.pDeviceId = selectedNewLineDeviceInfo.deviceId;
        reqBody.data.lines[0].device.eDeviceId = selectedNewLineDeviceInfo.eDeviceId || '';
        reqBody.data.lines[0].device.eDeviceSku = selectedNewLineDeviceInfo.eDeviceSku || '';
        reqBody.data.lines[0].sim = {
          id: simSku,
          iccid: '',
          eSIM: selectedNewLineSimInfo?.eSIM,
          isCustomerProvidedSIM,
        };
      }
    }
    // NSADT-142755 Adding condition for OMNI-CARE to avaoid activation fallout
    if (
      (isTelesales() || isOmniCare() || scmDeviceEnable || isChatStore() || isRetail() || isD2D() || indirect()) &&
      (reqBody?.data?.lines?.[0]?.sim?.iccid === '' || isESimOnly) &&
      reqBody?.data?.lines?.[0]?.sim?.isCustomerProvidedSIM
    ) {
      reqBody.data.lines[0].sim.isCustomerProvidedSIM = false;
    }
    // CXTDT-623630 bestbuy/walmart/telesales byod flow - setting isCustomerProvidedSIM to true
    if (
      /true/i.test(cpeSimFixFFlag) &&
      reqBody?.data?.lines[0]?.sim?.isCustomerProvidedSIM === false &&
      reqBody?.data?.lines?.[0]?.sim?.iccid !== '' &&
      !isESimOnly &&
      (isBYODAAL || isBYODUpg) &&
      (cartDetails?.cart?.cartHeader?.locationSubType === 'GN' || isTelesales() || isOmniCare() || scmDeviceEnable)
    ) {
      reqBody.data.lines[0].sim.isCustomerProvidedSIM = true;
    }

    if (
      reqBody?.data?.lines[0]?.sim?.isCustomerProvidedSIM === true &&
      (isBYODAAL || isBYODUpg) &&
      scmDeviceEnable &&
      reqBody?.data?.lines?.[0]?.sim?.iccid === '' &&
      !isESimOnly &&
      reqBody?.data?.lines?.[0]?.sim?.id !== '' &&
      !reqBody?.data?.lines?.[0]?.sim?.eSIM
    ) {
      reqBody.data.lines[0].sim.isCustomerProvidedSIM = false;
    }

    if (isOmniCare() && isSimOnlyChange) {
      delete reqBody.data.lines[0].device;
      delete reqBody.data.lines[0].addFeatures;
      delete reqBody.data.lines[0].downPayment;
      reqBody.cartInfo.processAction = 'addSIM';
    }
    const highRiskSimswapDelayActivation =
      MitekIdVerifyStatus === 'Unverified' || MitekIdVerifyStatus === 'ExceptionReview';
    const isCustConsentAcceptedSMSBlast =
      MitekIdVerifyStatus === 'Unverified' || MitekIdVerifyStatus === 'ExceptionReview';
    if (/true/i.test(isMitekSimSwapEnabled) || /true/i.test(isMitekDeviceSwapEnabled)) {
      reqBody.data.lines[0].idVerifyStatus =
        MitekIdVerifyStatus !== '' && MitekIdVerifyStatus !== undefined && MitekIdVerifyStatus
          ? MitekIdVerifyStatus
          : '';
      reqBody.data.lines[0].highRiskSimswapDelayActivation = highRiskSimswapDelayActivation;
      reqBody.data.lines[0].isCustConsentAcceptedSMSBlast = isCustConsentAcceptedSMSBlast;
    }
    const secondNumberEUP = secondNumData && secondNumData?.length > 0 && !isNewLine;
    if (
      secondNumberEUP &&
      secondNumData?.[0]?.primaryNumber &&
      secondNumData?.[0]?.equipmentInfos?.[0]?.deviceInfo?.pairedDeviceDetails?.[0]?.pairedImeiMtn &&
      enableEUPDualNum === 'TRUE'
    ) {
      const secondLineObj = JSON.parse(JSON.stringify(reqBody.data.lines[0]));
      const SecNumber = secondNumData?.[0]?.equipmentInfos?.[0]?.deviceInfo?.pairedDeviceDetails?.[0]?.pairedImeiMtn;
      secondLineObj.mtn = SecNumber;
      secondLineObj.secondNumber = {
        isSecondNumber: true,
        primaryMtn: secondNumData?.[0]?.mtn,
        secondMtn: SecNumber,
      };

      if (depletionType === 'L') {
        secondLineObj.device.deviceId = secondNumDeviceId;
        secondLineObj.sim.iccid = '';
        secondLineObj.sim.eSIM = devicedata?.eid2;
      }
      reqBody.data.lines[0].purchasePath = 'EUP';
      secondLineObj.purchasePath = 'EUPBYOD';
      reqBody?.data?.lines.push(secondLineObj);
    }

    if (
      depletionType === 'L' &&
      lineActivityTypeFromCart !== 'EUPBYOD' &&
      (lineActivityTypeFromCart === 'AAL' || lineActivityTypeFromCart === 'NSE' || lineActivityTypeFromCart === 'EUP')
    ) {
      reqBody.data.lines[0].device.imei2 =
        ValidateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo?.imei2 ||
        getQueryParamByName('imei2') ||
        '';
      if (/true/i.test(sessionStorage.getItem('isSecondNumLocal'))) {
        reqBody.data.lines[0].device.deviceId =
          ValidateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo?.imei2 ||
          getQueryParamByName('deviceId') ||
          getQueryParamByName('imei2') ||
          '';
        sessionStorage.setItem('isSecondNumLocal', false);
      }
    }

    if (/true/i.test(sessionStorage.getItem('isSAExist'))) {
      reqBody.cartInfo.intendType = 'BYOD';
      sessionStorage.removeItem('isSAExist');
    }
    if (/true/i.test(sessionStorage.getItem('isSANew'))) {
      reqBody.cartInfo.intendType = 'NSEBYOD';
      sessionStorage.removeItem('isSANew');
    }
    if (isDWOS) {
      reqBody.cartInfo.intendType = 'DEO';
    }
    if (isBYTDDeviceClicked) {
      reqBody.data.lines[0].sim.eSIM = trialEId;
    }
    if (isSecondNumDfill && reqBody?.data?.lines?.[0]?.device) {
      reqBody.data.lines[0].device.isCustomerProvidedEquipment = false;
      // eslint-disable-next-line no-param-reassign
      cartInfo.processAction = 'addDeviceSim';
    }
    if (isBBYLocalOrder) {
      reqBody.cartInfo.masterAgentId = masterAgentId;
      reqBody.cartInfo.outletId = agVisionOutletId;
      reqBody.cartInfo.cluster = lcClusture || null;
      reqBody.data.lines[0].device.upc = UpcCodeData;
      reqBody.data.lines[0].device.priceId = bbyPaymetOptionPriceId;
      reqBody.data.lines[0].device.taxBasis = taxBasisCharge;
      reqBody.data.lines[0].device.dpp = bbyContractTerm;
      reqBody.data.lines[0].device.dppMonths = bbyContractTerm;
      reqBody.data.lines[0].sellerPrice = retailPrice;
      reqBody.data.lines[0].device.regularPrice = paymentDetails?.regularPrice;
      reqBody.data.lines[0].device.currentPrice = paymentDetails?.currentPrice;
      reqBody.data.lines[0].device.downPaymentAmount = paymentDetails?.downPaymentAmount;
      reqBody.data.lines[0].device.bbyDownPayment = paymentDetails?.bbyDownPayment;
      reqBody.cartInfo.orderLocation = lcLocationCode;
      sessionStorage.setItem('cluster', lcClusture);
      if (/true/i.test(bestBuyEmpMasterAgentFFlag)) {
        reqBody.cartInfo.masterAgentId = 'BBEMPLOC';
      }
      /* istanbul ignore else */
      if (reqBody?.data?.lines?.[0]) {
        reqBody.data.lines[0].nrIspuPickUpLocation = {
          pickUpStoreId: selectedStore?.id || '',
          estMinDate: selectedStore?.estMinDate || '',
          estMaxDate: selectedStore?.estMaxDate || '',
          availabilityToken: selectedStore?.availabilityToken || '',
        };
      }
    }
    if (depletionType === 'F' && isBBYDfillOrder && /true/i.test(bestBuyIntegrationFFlag)) {
      reqBody.cartInfo.masterAgentId = null;
      reqBody.cartInfo.outletId = outletIdFromCart;
      reqBody.cartInfo.orderLocation = locationCodeFromCart;
    }
    /* istanbul ignore next */
    if (scmDeviceEnable && (devicedata?.etniApi || devicedata?.eSimOnlyDevice) && !lineNumber) {
      /* istanbul ignore next */
      const simPayload = {
        id: fixSCMDeviceChangeIccid ? devicedata?.preferredSoftSim : devicedata.simId,
        eSIM: devicedata.eid,
        isCustomerProvidedSIM: false,
      };
      if (isEsimActivationEnabled) {
        simPayload.iccid = '';
      }
      reqBody.data.lines[0].sim = simPayload;
      reqBody.data.lines[0].device.deviceId = ValidateDeviceSimIdResult?.originalArgs?.body?.data?.lines[0]?.device?.id;
      reqBody.data.lines[0].device.imei2 =
        ValidateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo?.imei2;
    }

    const isFromCombinedGridWallFlow = getQueryParamByName('isFromCombinedGridWall') === 'true';

    if (
      scmDeviceEnable &&
      enteredDeviceID === getQueryParamByName('deviceId') &&
      enteredSimID !== getQueryParamByName('simId') &&
      !isFromCombinedGridWallFlow &&
      !isScmSecondNumPerkEnabled &&
      !(window?.mfe?.isProspectNewCustomerTab && prospectByodFlow)
    ) {
      delete reqBody.data.lines[0].device;
      delete reqBody.data.lines[0].addFeatures;
      delete reqBody.data.lines[0].downPayment;
      reqBody.cartInfo.processAction = 'addSIM';
    }

    if (
      /true/i.test(addFeatureCallInPDPFFlag) &&
      fetData?.sorId !== protectionFeatures?.payload?.currentProtection?.sorId
    ) {
      const requestFeatures = {
        cartInfo: {
          accountNumber: customerProfileDetails?.customer?.accountNo,
          cartCreator: cartDetails?.cart?.cartHeader?.cartCreator,
          intendType: lineActivityTypeFromCart,
          creditAppNum: '',
          cartId: sessionStorage.getItem('jfyCartId'),
          caseId: '',
          processStep: 'FeaturesPDP',
          processingMTN: props?.activeMtn,
        },
        data: {
          lines: [
            {
              features: {
                add: [
                  {
                    actionIndicator: actionIndicatorValue,
                    id: fetData?.sorId,
                    quantity: '1',
                    type: fetData?.featureType,
                  },
                ],
                ...(!isEmpty(protectionFeatures?.payload?.currentProtection?.sorId)
                  ? {
                      remove: [
                        {
                          actionIndicator: 'A',
                          id: protectionFeatures?.payload?.currentProtection?.sorId,
                          quantity: '1',
                          type: protectionFeatures?.payload?.currentProtection?.featureType,
                        },
                      ],
                    }
                  : {}),
              },
              mtn: props?.activeMtn,
            },
          ],
        },
      };
      /* istanbul ignore next */
      if (/true/i.test(removeFeatureCallInPDPFFlag)) {
        const addDeviceRes = await addDevices({ body: reqBody });
        console.log(addDeviceRes, 'addDeviceRes');
        if (addDeviceRes?.data?.serviceHeader?.statusMsg === 'SUCCESS') {
          addFeature({ body: requestFeatures });
          // Clear eSIM regeneration flag after successful cart addition
          setIsESimRegenerated(false);
        }
      } else {
        await addDevices({ body: reqBody });
        addFeature({ body: requestFeatures });
        // Clear eSIM regeneration flag after successful cart addition
        setIsESimRegenerated(false);
      }
    } else {
      addDevices({ body: reqBody });
      // Clear eSIM regeneration flag after cart addition
      setIsESimRegenerated(false);
    }
  };

  const getNumberSharePairingMode = () => {
    const linkSMSharedToMyPlanFFlag =
      JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.linkSMSharedToMyPlanFFlag === 'TRUE' || false;
    if (
      linkSMSharedToMyPlanFFlag &&
      !isNumberShare &&
      selectedSku?.skuFilters?.deviceFilterType?.toLowerCase() === 'smartwatch'
    ) {
      return { numbersharePairingMode: 'UNPAIR' };
    }
    return {};
  };

  const groupBySmartWatchBand = (skus) => {
    const result = chain(skus)
      .filter((sku) => sku?.skuFilters?.band && sku?.skuFilters?.deviceFilterType === 'SmartWatch')
      .groupBy((sku) => sku?.skuFilters?.band)
      .map((value, key) => ({
        band: key,
        bandSkus: value,
      }))
      .value();
    return result;
  };
  const groupByColors = (skus) => {
    const result = chain(skus)
      .filter((sku) => sku?.color)
      .groupBy((sku) => sku?.color?.displayName)
      .map((value, key) => ({
        color: key,
        skus: value,
        colorCssStyle: value[0].color.colorCssStyle,
        skusGroupedBySWBand: groupBySmartWatchBand(value),
      }))
      .value();
    return result;
  };

  const cpoConditions = ['Like New', 'Great', 'Very Good', 'Good'];
  const groupByPreOwnedCondition = (skus) => {
    const isBYODUpg = getQueryParamByName('isByodUpdate'); // Upgrade BYOD
    const isBYODAAL = getQueryParamByName('isFromCPE'); // AAL BYOD

    // Skipping preOwnedDevice Logic For BYOD & local scan flows (as per BAU)
    let result = [];
    if (!isBYODUpg && !isBYODAAL && !isLocal && !(deviceFromFilteredCartLine?.depletionType === 'L')) {
      const skusSortedBySize = sortBy(skus, ['capacitySize']);
      result = chain(skusSortedBySize)
        .filter((sku) => sku?.deviceConditionDisplayName)
        .groupBy((sku) => sku?.deviceConditionDisplayName)
        .map((value, key) => ({
          condition: key,
          skus: value,
          skusGroupedByColor: groupByColors(value),
          description: value?.[0].deviceConditionDescription ? value?.[0].deviceConditionDescription : '',
        }))
        .value();
    }
    return result;
  };

  const groupPreOwnedConditionSkus = groupByPreOwnedCondition(details?.childSkus);

  /* istanbul ignore next */
  const getInventoryStatus = (sku) => {
    let isInStock = false;
    const { inventoryDetails = {} } = sku;
    const { dFillInventory = {}, localInventory = {} } = inventoryDetails || {};
    const { isPreOrder = false, isBackorder = false } = dFillInventory || {};
    if (isPreOrder || isBackorder) {
      isInStock = true;
    } else if (localInventory?.isInStock && localInventory?.qtyAvailable > 0) {
      isInStock = true;
    } else if (dFillInventory?.isInStock && dFillInventory?.qtyAvailable > 0) {
      isInStock = true;
    }
    return isInStock;
  };
  /* istanbul ignore next */
  const handlePreOwnedDeviceRadioChangeParent = (value) => {
    const filteredPreOwnedCondition = groupPreOwnedConditionSkus?.filter(
      (deviceCondition) => deviceCondition?.condition === value
    );
    const filterInStockSkus = filteredPreOwnedCondition?.[0]?.skus?.filter(
      (sku) => getInventoryStatus(sku) && getInventoryStatus(sku) === true
    );
    const defaultSKU =
      filterInStockSkus?.length > 0 ? filterInStockSkus[0].sorId : filteredPreOwnedCondition?.[0]?.skus?.[0]?.sorId;
    const childSkusByColorU = filteredPreOwnedCondition?.[0]?.skusGroupedByColor;
    const childSkusU = filteredPreOwnedCondition?.[0]?.skus || [];
    const newDetails = {
      ...details,
      defaultSKU,
      childSkusByColor: childSkusByColorU,
      childSkus: childSkusU,
    };
    setDetailsUpdate(newDetails);
  };
  /* istanbul ignore next */
  const callDeviceAddToCart = (fetData = selectedProtectionFeature, fromProtection = false) => {
    const isVVCAplicationCreated = /true/i.test(sessionStorage.getItem('isVVCAplicationCreated'));
    if (
      vvcEligibleType &&
      selectedPaymentInfo?.paymentType === '$vvcPaymentOption' &&
      orderDetails?.customerType !== 'N' &&
      !fromProtection &&
      !isVVCAplicationCreated
    ) {
      setShowApplyVVCModal(true);
    } else {
      processAddToCartNextSteps(fetData);
    }
  };
  const handleFullRetailPrice = (id) => {
    setRetailPrice(id);
  };
  const updatePaymentDetails = (bbPrice) => {
    setPaymentDetails(bbPrice);
  };
  const processAddToCart5G = (cartInfo, reqData, fetData) => {
    if (isFiveG) {
      addToCart(cartInfo, reqData, fetData);
    }
  };
  const processAddToCartNextSteps = (fetData) => {
    setShowApplyVVCModal(false);
    if (!scmDeviceEnable && isOmniCare() && simSkuEntered && !simSkuEntered?.includes('DFILL')) {
      dispatch(
        appMessageActions.addAppMessage(
          `Only DFILL SIM's are allowed for shippment.Please enter a valid DFILL SIM SKU if it is compatable with device.`,
          'error'
        )
      );
      return;
    }
    const isSimOnlyChange = false;
    const validatedDeviceId =
      enteredDeviceID || (getQueryParamByName('deviceId') ? getQueryParamByName('deviceId') : '');
    const isBYODUpg = getQueryParamByName('isByodUpdate'); // Upgrade DEVICE_ONLY change
    const validatedSimId = enteredSimID || getQueryParamByName('simId') || devicedata?.simLocalId || '';
    const cartInfo = {
      processStep: 'GridWallPDP',
      processingMTN: activeMtn,
      processAction: isFromCPE || isScmSecondNumPerkEnabled ? 'addDeviceSim' : 'addDevice',
      ...(!isSimOnlyChange ? { number_share_capable: isNumberShare ? 'Y' : 'N' } : {}),
      isQuoteCart: !!localPreBackDevice,
      enableDefaultedShipToHome: /true/i.test(enableDefaultedShipToHome),
      bogoEnabled: isFromCPE ? true : '',
    };
    const reqData = {
      id: selectedSku?.sorId,
      category: selectedSku?.skuFilters?.deviceFilterType,
      validatedDeviceId,
    };

    if (
      isBYODUpg &&
      !isNewLine &&
      (isOmniCare() || scmDeviceEnable) &&
      selectedProtectionFeature !== null &&
      validatedDeviceId === getActiveMtnDevicenfo() &&
      validatedSimId !== ''
    ) {
      setIsTMPScreenOpened(true);
      addToCart(cartInfo, reqData, fetData?.sorId ? fetData : selectedProtectionFeature);
    } else if (
      !scmDeviceEnable &&
      selectedProtectionFeature !== null &&
      !protectionFeatures?.payload?.currentProtection?.editable &&
      ((!details?.isE911Address && !isNumberShare) || isE911Opened?.address?.zipCode)
    ) {
      setIsTMPScreenOpened(true);
      addToCart(cartInfo, reqData, fetData?.sorId ? fetData : selectedProtectionFeature);
      if (isE911Opened) {
        setIsE911Visible(false);
      }
    } else if (
      selectedProtectionFeature !== null &&
      (tmpLinkClicked || isTMPScreenOpened) &&
      ((!details?.isE911Address && !isNumberShare) || isE911Opened?.address?.zipCode)
    ) {
      addToCart(cartInfo, reqData, fetData?.sorId ? fetData : selectedProtectionFeature);
      if (isE911Opened) {
        setIsE911Visible(false);
      }
    } else if ((details?.isE911Address || (isNumberShare && numberShareValue)) && !isE911Opened?.address?.zipCode) {
      setIsE911Visible(true);
    } else if (
      isE911Opened?.address?.zipCode &&
      ((selectedProtectionFeature !== null && !tmpLinkClicked) || !isTMPScreenOpened)
    ) {
      setIsE911Visible(false);
      setShowDeviceProtectionModal(true);
      setIsTMPScreenOpened(true);
    } else if (isDWOS) {
      /* istanbul ignore next */
      addToCart(cartInfo, reqData, fetData?.sorId ? fetData : selectedProtectionFeature);
    } else {
      setShowDeviceProtectionModal(true);
      const vzdl = window?.vzdl || {};
      if (vzdl?.event) vzdl.event.value = '';
      if (vzdl?.page) vzdl.page.detail = `Equipment Protection Modal`;
      window.vzdl = vzdl;
      sendCustomEvent('openView', window?.vzdl);
      setIsTMPScreenOpened(true);
      processAddToCart5G(cartInfo, reqData, fetData);
    }
    if (localPreBackDevice) {
      setLocalPreBackDevice(false);
      setShowLocalPreBackErrBanner(false);
      setLocalPreBackErrMsg('');
      dispatch(appMessageActions.clearAppMessages());
    }
    if (showLocalPreBackErrBanner && localPreBackQuoteFFlag === 'TRUE') {
      setShowLocalPreBackErrBanner(false);
    }
  };
  /* istanbul ignore next */
  useEffect(() => {
    if (isE911Opened?.address?.zipCode) callDeviceAddToCart();
  }, [isE911Opened]);

  // creating default data object for E911 validation component
  const isNewCustomer = cartDetails?.cart?.lineDetails?.lineInfo?.filter(
    (lineData) => lineData.lineActivityType === 'NSE' && lineData?.mobileNumber === activeMtn
  )?.[0];
  const RetriveCartAddress = isNewCustomer?.serviceInfo?.primaryUserInfo?.address;
  const CustomerData = customerProfileDetails?.customer;
  const CustomerProfileAddress = CustomerData?.address;

  // Memoize E911DefaultData so it only recalculates when dependencies change
  const E911DefaultData = useMemo(
    () => ({
      firstName: isNewCustomer
        ? isNewCustomer?.serviceInfo?.primaryUserInfo?.firstName
        : CustomerData?.customerName?.firstName,
      lastName: isNewCustomer
        ? isNewCustomer?.serviceInfo?.primaryUserInfo?.lastName
        : CustomerData?.customerName?.lastName,
      addressLine1: isNewCustomer ? RetriveCartAddress?.addressLine1 : CustomerProfileAddress?.addressLine1,
      addressLine2: isNewCustomer ? RetriveCartAddress?.apartmentNo : CustomerProfileAddress?.addressLine2,
      city: isNewCustomer ? RetriveCartAddress?.city : CustomerProfileAddress?.city,
      state: isNewCustomer ? RetriveCartAddress?.state : CustomerProfileAddress?.state,
      zipCode: isNewCustomer ? RetriveCartAddress?.zipCode : CustomerProfileAddress?.zipCode,
      zipCodePlus4: isNewCustomer ? RetriveCartAddress?.zipCode4 : CustomerProfileAddress?.zipCodePlus4,
    }),
    [isNewCustomer, RetriveCartAddress, CustomerData, CustomerProfileAddress]
  );

  const device = {
    id: details?.productId,
    devicename: details?.productDisplayName,
    monthlyprice: `$${
      selectedSku?.price?.devicePaymentPrice?.[0] ? selectedSku?.price?.devicePaymentPrice?.[0]?.originalPrice : []
    }/mo. for
                     ${
                       selectedSku?.price &&
                       selectedSku?.price?.devicePaymentPrice?.[0] &&
                       selectedSku?.price?.devicePaymentPrice?.[0]?.dpTermPrices?.dpTerm
                     } mos`,
    total: selectedSku?.price?.fullRetailPrice?.originalPrice,
    logo: Home5g,
    upgrade: !details?.cannotBeUpgraded,
    sku: selectedSku?.skuId,
    color: selectedSku?.color,
  };

  const updateNumberShare = (value) => {
    setIsNumberShare(value);
  };
  const updateNumberShareValue = (value) => {
    setNumberShareValue(value);
  };
  const updateSharedMtnValue = (value) => {
    setSharedMtnValue(value);
  };

  const doCallBuyOutEligible = () => {
    const request = {
      mtn: activeMtn,
    };
    buyoutUpgradeReq({ body: request });
  };
  useEffect(() => {
    const accountInfo = productDetails?.accountInfo;
    const buyoutDisplay = accountInfo?.buyoutDisplay?.toLowerCase() === 'true';
    const filteredLineDetails = customerProfileDetails?.customer?.billAccounts?.[0]?.mtns || [];
    const index = filteredLineDetails?.length > 0 ? filteredLineDetails.findIndex((x) => x.mtn === activeMtn) : -1;
    const newLineCheck = false;
    const cartDeviceEnabled = !!getQueryParamByName('deviceFromCart');
    const isBYODEnabled = !!getQueryParamByName('isByodUpdate');
    const buyoutDisplayCheck =
      accountInfo && (accountInfo?.buyoutDisplay === 'True' || accountInfo?.buyoutDisplay === '');
    const equipmentUpgradeEligibility = landingMtn?.[0]?.equipmentUpgradeEligibility;
    if (
      PdpBuyoutToggle &&
      !newLineCheck &&
      orderDetails?.customerType !== 'N' &&
      !isBYODEnabled &&
      cartDeviceEnabled &&
      !equipmentUpgradeEligibility?.isWithInWFGperiod &&
      ((buyoutDisplayCheck && buyOutDetail) || (accountInfo && accountInfo?.buyoutDisplay === ''))
    ) {
      doCallBuyOutEligible();
    }
    if (buyoutDisplay) {
      if (
        index !== -1 &&
        !filteredLineDetails[index].isInEligibleUpgradeSuccess &&
        !buyOutDetail &&
        !isBYODEnabled &&
        !equipmentUpgradeEligibility?.isWithInWFGperiod &&
        buyoutDisplay
      ) {
        doCallBuyOutEligible();
      }
    }
    const selectedLineForFilter = lineInfo && lineInfo.find((line) => line.mobileNumber === activeMtn);
    const buyOutDetailChecking = !!(selectedLineForFilter && selectedLineForFilter?.buyOutDetail);
    if (buyOutDetailChecking) {
      setIsBuyoutEligible(true);
      setBuyOutAccepted(true);
      setDisplayBuyoutAmount(selectedLineForFilter?.buyOutDetail?.buyOutAmt);
    }
    const isVVCFlowEnabled =
      !!/true/i.test(JSON.parse(sessionStorage.getItem('assistedFlags'))?.isVVCFlowEnabled) ||
      !!/true/i.test(JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.isVVCFlowEnabled);
    const customerData = customerProfileDetails?.customer;
    const customerType = customerData?.customerAttributes?.customerType;
    const vvcEligibleCustomerTypes = ['PE', 'ME', 'SL'];
    if (
      orderDetails?.customerType !== 'N' &&
      isVVCFlowEnabled &&
      customerData &&
      vvcEligibleCustomerTypes.includes(customerType)
    ) {
      const payload = {
        customerInfo: {
          firstName: customerData?.customerName?.firstName,
          lastName: customerData?.customerName?.lastName,
          isNewCustomer: false,
          customerId: customerData?.accountNo,
          locationCode: customerData?.orderLocationCode,
          loggedInUser: customerData?.loggedInUser,
        },
        pageContext: 'VVC-DFO',
      };
      getOffers({ body: payload, spinner: false });
    }
    if (indirect()) {
      if (getQueryParamByName('deviceSimCompatible') === 'N') {
        dispatch(
          appMessageActions.addAppMessage('Sim is not compatible with the selected device', 'error', true, true)
        );
      } else if (getQueryParamByName('deviceSimCompatible') === 'Y') {
        dispatch(appMessageActions.addAppMessage('Device is compartible with currentsim id', 'success', true, true));
      }
    }

    const floridaDiscountFFlag = JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.floridaDiscountFFlag === 'TRUE';
    if (floridaDiscountFFlag) {
      const floridaDiscountedLines = sessionStorage.getItem('floridaDiscountLinesCount');
      if (floridaDiscountedLines) {
        const existingDeviceType = sessionStorage.getItem('upgradeDeviceCategoryType');
        const currentDeviceType =
          productDetails?.deviceProduct?.childSkus?.[0]?.skuFilters?.deviceFilterType?.toLowerCase();
        const promoLoss_5 = "By changing to this device, customer's Florida 55+ Mobile Discount will be removed";
        const promoLoss_25 =
          'By changing to this device, customer’s Florida 55+ Mobile Discount will be reduced to $20/mo.';
        if (
          existingDeviceType &&
          existingDeviceType.includes('phone') &&
          currentDeviceType &&
          !currentDeviceType.includes('phone')
        ) {
          const promoMsg = floridaDiscountedLines === '2' ? promoLoss_25 : promoLoss_5;
          dispatch(appMessageActions.addAppMessage(promoMsg, 'warning', true, true));
        }
      }
    }

    setIsFullFillment(props.cartDetails?.cart?.orderDetails?.orderDepletionType === 'F');
  }, []);

  useEffect(() => {
    if (getOffersResults?.data) {
      const proposition = getOffersResults?.data?.data?.issacPromo?.proposition;
      setIsaacPromo(getOffersResults?.data?.data?.issacPromo);
      const eligiblePropositionIds = ['GC_01', 'GC_05', 'GC_07'];
      const activeMTNObj = customerProfileDetails?.customer?.billAccounts?.[0]?.mtns?.find(
        (mtnObj) => mtnObj.mtn === activeMtn
      );
      const isHavingLineLevelVVC = activeMTNObj?.marketingOption?.vzCCHolder;
      const isHavingAccountLevelVVC = customerProfileDetails?.customer?.billAccounts?.[0]?.mtns?.some(
        (mtnObj) => mtnObj?.marketingOption?.vzCCHolder === true
      );
      if (
        !isHavingLineLevelVVC &&
        !isHavingAccountLevelVVC &&
        getOffersResults?.data?.featureFlags?.accountLevelVVCFFlag
      ) {
        if (eligiblePropositionIds.includes(proposition?.propositionId)) {
          setVvcEligibleType('prescreen');
        } else {
          setVvcEligibleType('preQualify');
        }
      }
      // cart limit check
      const customerActions = proposition?.customerActions || [];
      const customerAction =
        customerActions.length > 0 && customerActions.every((item) => item.action !== 'View Details');
      const applicationStatus = proposition?.applicationStatus;
      const isHavingActiveCard = !customerAction && !(applicationStatus === 'Application-Pending');
      const isVVCAplicationCreated = /true/i.test(sessionStorage.getItem('isVVCAplicationCreated'));
      if (isVVCAplicationCreated && isHavingActiveCard) {
        getCardLimitDetails({
          body: {
            mtn: activeMtn,
            accountNumber: props?.customerProfileDetails?.customer?.accountNo,
            paymentAmt: cartDetails?.cart?.orderDetails?.totalDueToday,
          },
          spinner: false,
        });
      }
    }
  }, [getOffersResults]);

  useEffect(() => {
    if (
      getCardLimitResults?.data?.data?.paymentAmtExceedingThanTempLimit &&
      getCardLimitResults?.data?.data?.vvcTempCreditLimit
    ) {
      setIsCardExceedLimit(true);
    }
  }, [getCardLimitResults]);

  useEffect(() => {
    if (buyoutUpgradeResult?.data) {
      setBuyoutModel();
    }
  }, [buyoutUpgradeResult?.data]);

  useEffect(() => {
    if (RemoveLinesAPIResult?.data && RemoveLinesAPIResult?.status === 'fulfilled') {
      if (RemoveLinesAPIResult?.data?.errors) {
        /* istanbul ignore else */
        if (RemoveLinesAPIResult?.data?.errors?.[0]?.id === '9656') {
          setRemoveLineModal(true);
        }
      } else {
        if (scmUpgradeMfeEnable) {
          Emitter.emit('ACSS_SCM_REMOVE_DEVICE', { mtn: props.activeMtn });
          const genQueryparams = `offerEligible=Y&activeMtn=${props.activeMtn}&productId=${device.id}&defaultSku=${device.sku}`;
          Emitter.emit('ACSS_SCM_DEVICE_SUBTAB', { subTab: 'PDP', queryParams: genQueryparams });
        }
        const removeCartDetails = {
          PAGE_LOADED: 'true',
          CUSTOM_EVENT: 'RemovefromQuote',
          NEED_CALLBACK: true,
        };

        Emitter.emit('PAGE_LOADED', removeCartDetails);
        if (!scmUpgradeMfeEnable) {
          window?.store?.dispatch(fetchPricingApiRequired());
        }
        Emitter.on('TAGGING_COMPLETED', () => {
          const processStep =
            RemoveLinesAPIResult.data.serviceBody &&
            RemoveLinesAPIResult.data.serviceBody.serviceResponse &&
            RemoveLinesAPIResult.data.serviceBody.serviceResponse.context &&
            RemoveLinesAPIResult.data.serviceBody.serviceResponse.context.contextInfo &&
            RemoveLinesAPIResult.data.serviceBody.serviceResponse.context.contextInfo.processStep;
          if (processStep === 'MandatoryPlanSelectionPage') {
            setUpdatePlanChange(true);
          } else if (!skipRedirection) {
            if (!scmDeviceEnable) navigate(`${getUIContextPathBAU()}/landing.html`);
          }
          if (buyoutToggleChange && window?.vzdl?.event?.value !== '') {
            window.vzdl.event.value = '';
          }
        });
      }
    }
  }, [RemoveLinesAPIResult, RemoveLinesAPIResult?.status]);

  const totalBuyoutAmount = buyoutUpgradeResult?.data?.totalBuyoutAmount || displayBuyoutAmount.toString();
  const installmentLoanNumber = buyoutUpgradeResult?.data?.installmentLoanNumber || '';
  const buyoutEligibilityMessage = buyoutUpgradeResult?.data?.buyoutEligibilityMessage || '';
  const isPreOrder = selectedSku?.inventoryDetails?.dFillInventory?.isPreOrder;
  const isBackorder = selectedSku?.inventoryDetails?.dFillInventory?.isBackorder;
  /* istanbul ignore next */
  const setBuyoutModel = () => {
    const buyoutPositiveValue = totalBuyoutAmount > 0;

    if (totalBuyoutAmount !== '0.00' && buyoutPositiveValue) {
      setIsBuyoutEligible(true);
      setIsBuyoutModalVisible(true);
      makeOpenViewCall('BuyoutAmountModel');
    } else {
      dispatch(appMessageActions.clearAppMessages());
      // dispatch(appMessageActions.addAppMessage(buyoutEligibilityMessage, 'error'));

      if (negativeBuyoutAmountFixFlexFFlag && totalBuyoutAmount < 0) buyoutHandler('decline');
    }
  };

  const buyOutcall = () => {
    const dollarValue = totalBuyoutAmount;
    const requestbody = {
      cartInfo: {
        processingMTN: activeMtn,
        buyOutFlag: 'Y',
        buyOutSelected: 'Y',
        edgeUpSelected: 'N',
      },
      data: {
        lines: [
          {
            mtn: activeMtn,
            buyoutAmt: dollarValue && dollarValue.replace(/[^0-9.]/g, ''),
          },
        ],
      },
    };
    addBuyoutReq({ body: requestbody });
  };

  const closeBuyoutModel = () => {
    setIsBuyoutModalVisible(false);
  };

  const buyoutHandler = (option) => {
    /* istanbul ignore else */
    if (PdpBuyoutToggle) {
      setIsBuyOutSet(true);
    }
    // Clear all the variables for opening buyout modal
    if (option === 'accept' || option === undefined) {
      setIsBuyoutModalVisible(false);
      setIsDeclineBuyout(false);
      setBuyOutAccepted(true);
    } else {
      setIsBuyoutModalVisible(false);
      setIsDeclineBuyout(true);
    }
    dispatch(appMessageActions.clearAppMessages());
  };
  // To remove added device
  const removeLines = () => {
    const defaultSKU = getProp(details, 'defaultSKU');
    const request = {
      cartInfo: {
        processingMTN: activeMtn,
        processAction: isNewLine || isRfexFlow ? 'removeDevice' : '',
      },
      data: {
        lines: [
          {
            mtn: activeMtn,
          },
        ],
        enableAssistedTagging: true,
      },
    };
    /* istanbul ignore else */
    if (secondNumLine && secondNumLine.length > 0) {
      request.data.lines.push({ mtn: secondNumLine?.[0]?.mobileNumber });
    }
    if (isDWOS) {
      request.data.lines[0].removeDevice = { id: defaultSKU };
    }
    removeLinesAPI({ body: request });
  };

  useEffect(() => {
    const handleDeviceSimIdInfo = (deviceSimIdData) => {
      setSimSkuEntered(deviceSimIdData?.simSkuEntered);
    };
    const handleSelectedInsurance = (value) => {
      setSelectedProtectionFeature(value);
      setIsTMPScreenOpened(true);
      console.log('Update_Selected_Insurance', value);
    };
    const handleDeviceProtectionModal = (value) => {
      setShowDeviceProtectionModal(value);
      console.log('Update_Show_Device_Protection_Modal', value);
    };
    const handleProtectionStatus = (value) => {
      setProtectionShownStatusInDevice(value);
      console.log('Update_Protection_Show_Status_InDevice', value);
    };
    const handleAddCart = (value) => {
      SetInitiateAddDeviceCall(value);
      console.log('Call_Device_Add_Cart', value);
    };
    Emitter.on('Update_DeviceSimId_Info', handleDeviceSimIdInfo);
    Emitter.on('Update_Selected_Insurance', handleSelectedInsurance);
    Emitter.on('Update_Show_Device_Protection_Modal', handleDeviceProtectionModal);
    Emitter.on('Update_Protection_Show_Status_InDevice', handleProtectionStatus);
    Emitter.on('Call_Device_Add_Cart', handleAddCart);
    return () => {
      Emitter.off('TAGGING_COMPLETED');
      if (cleanUpEmitterFFlag) {
        Emitter.off('Update_DeviceSimId_Info', handleDeviceSimIdInfo);
        Emitter.off('Update_Selected_Insurance', handleSelectedInsurance);
        Emitter.off('Update_Show_Device_Protection_Modal', handleDeviceProtectionModal);
        Emitter.off('Update_Protection_Show_Status_InDevice', handleProtectionStatus);
        Emitter.off('Call_Device_Add_Cart', handleAddCart);
      }
    };
  }, []);
  useEffect(() => {
    if (selectedProtectionFeature) {
      const fromProtection = true;
      callDeviceAddToCart(initiateAddDeviceCall, fromProtection);
      console.log('Call_Device_Add_Cart', initiateAddDeviceCall);
    }
  }, [initiateAddDeviceCall]);

  const vbgProfInstall = isVbgProfessionalInstall();

  const buyOutModalCheck = () => {
    let isBuyoutModalVisibleChecking = true;
    const selectedLineForFilter = lineInfo && lineInfo.find((line) => line.mobileNumber === activeMtn);
    const buyOutDetailChecking = !!(selectedLineForFilter && selectedLineForFilter?.buyOutDetail);
    const deviceFromCart = /true/i.test(getQueryParamByName('deviceFromCart'));
    if (buyOutDetailChecking || deviceFromCart) {
      isBuyoutModalVisibleChecking = false;
    }
    return isBuyoutModalVisibleChecking;
  };

  const simFreezeInfo = JSON.parse(sessionStorage.getItem('simFreezeInfo'));
  const assistedFlags = JSON.parse(sessionStorage.getItem('assistedFlags'))?.IS_VALID_USER;

  let showSimFreezeinfoBanner = '';
  const simProtectionTaggingFFlag = JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.simProtectionTaggingFFlag;
  if (simFreezeInfo?.isBlocked === 'Y' && (assistedFlags === 'TRUE' || scmDeviceEnable)) {
    let subtileCheck = '';
    if (simFreezeInfo?.simFreezeCode === 'F') {
      subtileCheck = 'SIM changes and upgrades are restricted. Customer must disable via My Verizon before processing.';
      if (/true/i.test(simProtectionTaggingFFlag)) {
        const vzdl = window?.vzdl;
        if (vzdl?.target) vzdl.target.message = 'SIM Protection Enable';
        sendCustomEvent('notification', vzdl);
        window.vzdl = vzdl;
      }
    } else if (simFreezeInfo?.simFreezeCode === 'N') {
      subtileCheck = `SIM Protection was recently removed from this line but the protection period has not yet expired. To upgrade or complete SIM change, please retry this transaction after ${simFreezeInfo?.simUnfreezeTimeStamp}.Please refresh this page if updates have already been made.`;
      if (/true/i.test(simProtectionTaggingFFlag)) {
        const vzdl = window?.vzdl;
        if (vzdl?.target) vzdl.target.message = 'Sim protection enabled-Line thawing';
        sendCustomEvent('notification', vzdl);
        window.vzdl = vzdl;
      }
    }
    showSimFreezeinfoBanner = (
      <div id='AppMessage' className='AppMessage top-fixed'>
        <Notification
          type='warning'
          title='SIM Protection enabled'
          subtitle={subtileCheck}
          surface='light'
          disableAnimation={false}
          fullBleed={false}
          hideCloseButton={false}
          disableFocus
          inline={false}
          layout={null}
          data-testid='ProdtenbInfoBannerEnb'
        />
      </div>
    );
  }
  return (
    <>
      {!scmDeviceEnable && showSimFreezeinfoBanner}
      {showLocalPreBackErrBanner && localPreBackQuoteFFlag === 'TRUE' && (
        <div id='AppMessage' className='AppMessage top-fixed BannerBtn' data-testid='localPreBackErrMsg'>
          <Notification
            type='error'
            title={localPreBackErrMsg}
            layout='vertical'
            buttonData={[
              {
                children: 'Add to cart',
                onClick: () => callLocalPreBackAddToCart(),
              },
            ]}
          />
        </div>
      )}

      {showISPULocalConflictBanner && (
        <div id='AppMessage' className='AppMessage top-fixed' data-testid='ispuLocalConflictBanner'>
          <Notification
            type='error'
            title='Cannot combine multiple ISPU and Local in a single order, switch all lines to either Local or ISPU'
            surface='light'
            disableAnimation={false}
            fullBleed={false}
            hideCloseButton={false}
            disableFocus
            inline={false}
            layout={null}
          />
        </div>
      )}

      {showNonISPULocalBanner && (
        <div id='AppMessage' className='AppMessage top-fixed' data-testid='nonISPULocalBanner'>
          <Notification
            type='error'
            title='Cannot combine multiple ISPU and Local in a single order, switch all lines to either Local or ISPU'
            surface='light'
            disableAnimation={false}
            fullBleed={false}
            hideCloseButton={false}
            disableFocus
            inline={false}
            layout={null}
          />
        </div>
      )}

      {!flexFlowServiceChange && (
        <HeaderWraper isDark={isDark} bgColor={bgColor} scmDeviceMfeEnable={window?.mfe?.scmDeviceMfeEnable}>
          <Header
            data={headerData}
            closeClickHandler={() => {}}
            moreOptionClickHandler={() => {}}
            FirstName={FirstName}
            CustomerData={customerProfileDetails?.customer}
            CustomerProfileCommonInfo={customerProfileDetails?.commonInfo}
            productDetails={productDetails}
            selectedSku={selectedSku}
            setDownPaymentObj={setDownPaymentObj}
            downPaymentObj={downPaymentObj}
            setUpgradeReasonType={setUpgradeReasonType}
            deviceContract={deviceContract}
            isFromCPE={isFromCPE}
            isRfexFlow={isRfexFlow}
            isNewLine={isNewLine}
            channel={channel}
            orderDetails={orderDetails}
            selectedPaymentInfo={selectedPaymentInfo}
            isInStock={stockAvailable || false}
            isNumberShare={isNumberShare}
            numberShareValue={numberShareValue}
            cartDetails={cartDetails}
            activeMtn={activeMtn}
            computeDPPriceBody={computeDPPriceBody}
            computeDPPriceResult={computeDPPriceResult}
            isDownPaymentAlertNeedToEnable={isDownPaymentAlertNeedToEnable}
            setIsDownPaymentAlertNeedToEnable={setIsDownPaymentAlertNeedToEnable}
            retailPrice={retailPrice}
            taxBasisCharge={taxBasisCharge}
            bbyContractTerm={bbyContractTerm}
            bbPaymentOptionsSelected={bbPaymentOptionsSelected}
            closePopup={!scmDeviceEnable}
          />
          {showSimFreezeinfoBanner}
        </HeaderWraper>
      )}
      <Padding32>
       <Suspense fallback={null}>
        {home5g === true ? (
          <Home5G device={device} importantDeviceClickHandler={() => {}} />
        ) : (
          <DeviceInfo
            showISPULocalConflictBanner={showISPULocalConflictBanner}
            SkuDetailsResult={SkuDetailsResult}
            GetDetailsResult={GetDetailsResult}
            isAcssDfillSim={getDfillSim()}
            isFullFillment={isFullFillment}
            productDetailsAemContent={props?.productDetailsAemContent}
            lineActivityType={lineInfo?.[0]?.lineActivityType}
            productDetails={productDetails}
            protectionFeatures={protectionFeatures}
            cartDetails={cartDetails}
            customerProfileDetails={customerProfileDetails}
            activeMtn={activeMtn}
            selectedColor={selectedColor}
            getContractTerm={getContractTerm}
            setSelectedColor={setSelectedColor}
            ispuToggleOn={ispuToggleOn}
            setIspuToggleOn={setIspuToggleOn}
            isShipItToggleOn={isShipItToggleOn}
            setIsShipItToggleOn={setIsShipItToggleOn}
            selectedSku={selectedSku}
            setSelectedSku={setSelectedSku}
            selectedProtectionFeature={selectedProtectionFeature}
            setSelectedProtectionFeature={setSelectedProtectionFeature}
            selectedSize={selectedSize}
            setSelectedSize={setSelectedSize}
            specsData={specsData}
            inbox={inbox}
            OverviewDetails={overview}
            btnLabel={getButtonLabel()}
            callDeviceAddToCart={callDeviceAddToCart}
            isCartBtnEnable={isCartBtnEnable()}
            disableFooter={disableFooter}
            isNumberShare={isNumberShare}
            numberShareValue={numberShareValue}
            sharedMtnValue={sharedMtnValue}
            updateNumberShare={updateNumberShare}
            updateNumberShareValue={updateNumberShareValue}
            updateSharedMtnValue={updateSharedMtnValue}
            setSelectedPaymentInfo={setSelectedPaymentInfo}
            showDeviceProtectionModal={showDeviceProtectionModal}
            setShowDeviceProtectionModal={setShowDeviceProtectionModal}
            updateDeviceId={updateDeviceId}
            updateSimId={updateSimId}
            totalBuyoutAmount={totalBuyoutAmount}
            buyOutAccepted={buyOutAccepted}
            setBuyOutAccepted={setBuyOutAccepted}
            PdpBuyoutToggle={PdpBuyoutToggle}
            buyOutcall={buyOutcall}
            BuyoutResult={!isEmpty(addBuyoutResult?.data) || false}
            buyOutDetail={buyOutDetail}
            isBuyoutEligible={isBuyoutEligible}
            buyAmountMessage={buyoutEligibilityMessage}
            isBackorder={isBackorder}
            isPreOrder={isPreOrder}
            updateDeviceData={updateDeviceData}
            selectedPaymentInfo={selectedPaymentInfo}
            removeLines={removeLines}
            isPreorderCountDownEnabled={isPreorderCountDownEnabled}
            isPreorderTestingEnabled={isPreorderTestingEnabled}
            tmpScreenOpened={tmpScreenOpened}
            isTMPScreenOpened={isTMPScreenOpened}
            protectionShownStatusInDevice={protectionShownStatusInDevice}
            setProtectionShownStatusInDevice={setProtectionShownStatusInDevice}
            tmpLinkClicked={tmpLinkClicked}
            setTmpLinkClicked={setTmpLinkClicked}
            setUpgradeReasonType={setUpgradeReasonType}
            upgradeReasonType={upgradeReasonType}
            details={detailsUpdate || details}
            setDetails={setDetails}
            groupByPreOwnedCondition={groupByPreOwnedCondition}
            groupPreOwnedConditionSkus={groupPreOwnedConditionSkus}
            handlePreOwnedDeviceRadioChangeParent={handlePreOwnedDeviceRadioChangeParent}
            cpoConditions={cpoConditions}
            groupByColors={groupByColors}
            getInventoryStatus={getInventoryStatus}
            groupBySmartWatchBand={groupBySmartWatchBand}
            setIsIspuItemInCart={setIsIspuItemInCart}
            selectedStore={selectedStore}
            setSelectedStore={setSelectedStore}
            setSimIdResult={setSimIdResult}
            setisInStock={setisInStock}
            setMitekIdVerifyStatus={setMitekIdVerifyStatus}
            setSkipRedirection={setSkipRedirection}
            setSecondNumDeviceId={setSecondNumDeviceId}
            setSecondNumSimId={setSecondNumSimId}
            secondNumSimId={secondNumSimId}
            secondNumData={secondNumData}
            setSecondNumData={setSecondNumData}
            incompatibleSim={incompatibleSim}
            setIncompatibleSim={setIncompatibleSim}
            ispuSim={ispuSim}
            setIspuSim={setIspuSim}
            computeDPPriceResult={computeDPPriceResult}
            isNewlyAddedLine={isNewLine}
            setBuyoutToggleChange={setBuyoutToggleChange}
            isaacPromo={isaacPromo}
            isIndirect={indirect()}
            isBBYLocalOrder={isBBYLocalOrder}
            setBbyPaymetOptionPriceId={setBbyPaymetOptionPriceId}
            setBbyContractTerm={setBbyContractTerm}
            setTaxBasisCharge={setTaxBasisCharge}
            bbyPaymetOptionPriceId={bbyPaymetOptionPriceId}
            bbyContractTerm={bbyContractTerm}
            taxBasisCharge={taxBasisCharge}
            isCardExceedLimit={isCardExceedLimit}
            setUpcCodeFromPdpScan={setUpcCodeFromPdpScan}
            upcCodeFromPdpScan={upcCodeFromPdpScan}
            sendFullRetailPrice={handleFullRetailPrice}
            skuRealAgentCode={skuRealAgentCode}
            computeDPPriceBody={computeDPPriceBody}
            downPayment={downPaymentObj?.downPayment}
            bbComputeDPPriceResult={downPaymentObj?.computeDPPriceResult}
            isDeclineBuyout={isDeclineBuyout}
            simSwapNotificationHighRiskMsg={simSwapNotificationHighRiskMsg}
            setBbPaymentOptionsSelected={setBbPaymentOptionsSelected}
            updatePaymentDetails={updatePaymentDetails}
            showPlanChange={showDeviceCompModal && flexFlowServiceChange}
            setIsESimRegenerated={setIsESimRegenerated}
            isFiveG={isFiveG}
            lcLocationCode={lcLocationCode}
            BbyLocalOrderLocDetailsRequest={props.BbyLocalOrderLocDetailsRequest}       
            BbyLocalOrderLocDetailsApiResponse={props.BbyLocalOrderLocDetailsApiResponse}
            BbyLocalOrderLocDetailsResponse={props?.BbyLocalOrderLocDetailsResponse}
            isVbgProfessionalInstall={vbgProfInstall}
            setActivatedDate={setActivatedDate}
          />
        )}
       </Suspense>
      </Padding32>

      {isE911Visible && (
        <E911Validation
          mtn={activeMtn}
          callDeviceAddToCart={callDeviceAddToCart}
          setIsE911Opened={setIsE911Opened}
          setIsE911Visible={setIsE911Visible}
          E911DefaultData={E911DefaultData}
        />
      )}
      {isBuyoutModalVisible && buyOutModalCheck() && (
        <Suspense fallback={null}>
          <BuyoutAmount
            opened={isBuyoutModalVisible}
            buyAmountMessage={buyoutEligibilityMessage}
            totalBuyoutAmount={totalBuyoutAmount}
            installmentLoanNumber={installmentLoanNumber}
            isBackorder={isBackorder}
            isPreOrder={isPreOrder}
            buyOutcall={buyOutcall}
            buyoutHandler={buyoutHandler}
            closeBuyoutModel={closeBuyoutModel}
          />
        </Suspense>
      )}
      {removeLineModal && (
        <Suspense fallback={null}>
          <RemoveLinesModal setRemoveLineModal={setRemoveLineModal} removeLines={removeLines} />
        </Suspense>
      )}
      {!scmDeviceEnable && showModalPastbalPreBackOrder && (
        <Suspense fallback={null}>
          <ShowPastbalPreBackOrder setShowModalPastbalPreBackOrder={setShowModalPastbalPreBackOrder} />
        </Suspense>
      )}
      <DevicePlanCompatible
        showModal={showDeviceCompModal && !flexFlowServiceChange}
        onClose={() => setShowDeviceCompModal(false)}
        customerProfileDetails={customerProfileDetails}
        cartDetails={cartDetails}
        removeLines={removeLines}
        activeMtn={activeMtn}
      />
      {showApplyVVCModal && (
        <ApplyVVCModal
          vvcEligibleType={vvcEligibleType}
          customerProfileDetails={customerProfileDetails}
          isaacPromo={isaacPromo}
          processAddToCartNextSteps={processAddToCartNextSteps}
          setShowApplyVVCModal={setShowApplyVVCModal}
          selectedSku={selectedSku}
        />
      )}
    </>
  );
}
PDP.propTypes = {
  productDetails: PropTypes.shape({
    deviceProduct: PropTypes.shape({
      productDisplayName: PropTypes.string.isRequired,
      techSpecs: PropTypes.object.isRequired,
      includedAccessories: PropTypes.string.isRequired,
      description: PropTypes.string,
      productId: PropTypes.string,
    }),
  }),
  customerProfileDetails: PropTypes.object,
  activeMtn: PropTypes.string,
  cartDetails: PropTypes.object,
  protectionFeatures: PropTypes.shape({}),
  home5g: PropTypes.bool,
  lineDeviceIdFromLanding: PropTypes.object,
  lineSimIdFromLanding: PropTypes.object,
  productDetailsAemContent: PropTypes.object,
};
export default PDP;
