import { Button } from '@vds/buttons';
import { Modal } from '@vds/modals';
import { RadioButtonGroup } from '@vds/radio-buttons';
import styled from 'styled-components';
import { useState } from 'react';
import { useDispatch } from 'react-redux';
import { Line } from '@vds/lines';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { Title } from '@vds/typography';
import { Icon } from '@vds/icons';
import { BackClickable, OverflowEllipsis } from '../CombinedGridwall/FlexGlobalStyledConstants';
import { LIGHT_BG_COLOR, LIGHT_THEME_COLOR, DARK_THEME_BGCOLOR } from '../../constants/constants';
import { getFFlag } from '../../modules/utils';

const ModelWrap = styled(Modal)`
  padding: 0px;
  width: ${({ isAcssDeviceMFe }) => isAcssDeviceMFe && '50%'};
  height: ${({ isAcssDeviceMFe }) => isAcssDeviceMFe && '60%'};
  border: ${({ isAcssDeviceMFe }) => isAcssDeviceMFe && '1px solid'};
  background-color: ${({ isDark }) => (isDark ? DARK_THEME_BGCOLOR : LIGHT_BG_COLOR)};
`;

const BodyWrap = styled.div`
  margin-top: ${({ isAcssDeviceMFe }) => (isAcssDeviceMFe ? '8px' : '20px')};
  padding-left: 45px;
  padding-right: 0px;
  position: ${({ isAcssDeviceMFe }) => (isAcssDeviceMFe ? 'inherit' : 'fixed')};
  height: ${({ isAcssDeviceMFe }) => (isAcssDeviceMFe ? '17rem' : 'auto')};
  top: 64px;
  left: 0;
  right: 0px;
  bottom: 90px;
  overflow: auto;
`;

const FooterWrap = styled.div`
  position: ${({ isAcssDeviceMFe }) => (isAcssDeviceMFe ? 'inherit' : 'fixed')};
  top: ${({ isAcssDeviceMFe }) => isAcssDeviceMFe && '5rem'};
  bottom: 0;
  width: ${({ isAcssDeviceMFe }) => (isAcssDeviceMFe ? '50rem' : '64rem')};
  background: ${({ isDark }) => (isDark ? DARK_THEME_BGCOLOR : LIGHT_BG_COLOR)};
  border-top: 1px solid #d8dada;
  padding-top: 0.875rem;
  padding-bottom: 0.875rem;
  text-align: center;
`;
const CenterDivWrap = styled.div`
  display: flex;
  justify-content: center;
`;
export const FlexAlignContainerItemsCenter = styled.div`
  display: flex;
  align-items: center;
  padding: 0 2rem;
  justify-content: space-between;
`;
const FlexBoxGrowOne = styled.div`
  display: flex;
  flex-grow: 1;
`;

const ShopWrapper = styled.div`
  padding: 1.5rem 0.5rem;
`;

const RadioButtonStyle = styled.div`
  div[class^='RadioButtonGroupWrapper'] {
    padding-top: 7px !important;
    margin-top: 5px;
  }
  div[class^='ChildWrapper'] {
    padding-bottom: 18px !important;
  }
  & label::before {
    content: none !important;
    display: none !important;
  }
  .radioWrapper,
  div[class*='radioWrapper'],
  div[class^='ComponentWrapper'],
  div[class*='ComponentWrapper'] {
    &::before,
    &::after {
      content: none !important;
      display: none !important;
    }
  }
`;
const LineWrapper = styled.div`
  padding: 0 2rem;
`;

const NumberTitle = styled.div`
  font-weight: bold;
  font-size: 18px;
`;

const NumberText = styled.div`
  margin-top: 20px;
`;
const enableSCMNumberShare = getFFlag('enableNumberShareForVZWACSSFFlag') === 'Y';

function NumberShareModal({
  closeClickHandler,
  opened,
  numberShareDetails,
  updateNumberShareValue,
  numberShareValue,
  setEnableBYODbtn,
  onSelectNumberShare,
}) {
  const { numberShareList = [] } = numberShareDetails || {};
  const isDark = (window?.mfe?.scmDeviceMfeEnable && window?.mfe?.isDark) || false;
  const [selectedMtn, setSelectedMtn] = useState(numberShareValue);
  const scmDeviceMfeEnable = window?.mfe?.scmDeviceMfeEnable;
  const dispatch = useDispatch();
  const updateNumberShare = () => {
    const value = selectedMtn;
    if (value === '' && numberShareList && numberShareList.length > 0) {
      dispatch(appMessageActions.clearAppMessages());
      dispatch(appMessageActions.addAppMessage('Please select MTN'));
    } else if (value === '' && numberShareList && numberShareList.length === 0) {
      closeClickHandler();
    } else {
      updateNumberShareValue(value);
      closeClickHandler();
      /* istanbul ignore next */
      if (enableSCMNumberShare) {
        onSelectNumberShare(value);
      } else {
        setEnableBYODbtn(true);
      }
    }
  };

  const getSelectedtrunkMtn = () => {
    const selectedtrunkMtn = numberShareList && numberShareList.find((item) => selectedMtn === item.trunkMtn);
    const selectedmldTrunkMtn = numberShareList && numberShareList.find((item) => selectedMtn === item.mldTrunkMtn);
    if (selectedtrunkMtn && selectedtrunkMtn.trunkMtn) return selectedtrunkMtn.trunkMtn;
    if (selectedmldTrunkMtn && selectedmldTrunkMtn.mldTrunkMtn) return selectedmldTrunkMtn.mldTrunkMtn;
    return '';
  };

  const numShareHeader = (
    <>
      <FlexAlignContainerItemsCenter>
        <FlexBoxGrowOne>
          <BackClickable
            data-testid='testBackGridwall'
            data-track='NumberShareModal-back'
            onClick={() => closeClickHandler()}
            tabIndex={0}
            role='button'
          >
            <Icon name='left-caret' size='XLarge' medium='true' surface={isDark ? 'dark' : 'light'} />
          </BackClickable>
          <ShopWrapper>
            <OverflowEllipsis lineCount={1}>
              <Title size='<small' bold primitive='h1' color={isDark ? LIGHT_BG_COLOR : LIGHT_THEME_COLOR}>
                Number Share
              </Title>
            </OverflowEllipsis>
          </ShopWrapper>
        </FlexBoxGrowOne>
      </FlexAlignContainerItemsCenter>
      <LineWrapper>
        <Line type='secondary' />
      </LineWrapper>
    </>
  );

  const defaultValue = getSelectedtrunkMtn();

  const numShareBody =
    numberShareList && numberShareList.length > 0 ? (
      <BodyWrap isAcssDeviceMFe={window?.mfe?.scmDeviceMfeEnable}>
        {numberShareList && (
          <RadioButtonStyle>
            <RadioButtonGroup
              onChange={(e) => setSelectedMtn(e.target.value)}
              defaultValue={defaultValue || true}
              key='numberShare_radio'
              surface={isDark ? 'dark' : 'light'}
              data={numberShareList.map((item) => {
                const children = (
                  <div>
                    <NumberTitle>{item.customerName && <div>{item.customerName}</div>}</NumberTitle>
                    <div className={scmDeviceMfeEnable && 'acss-number-share-mtn-section'}>
                      <NumberText>{item.trunkMtn ? item.trunkMtn : item.mldTrunkMtn}</NumberText>
                      {scmDeviceMfeEnable && (
                        <div className='acss-number-share-devicename'>{item.deviceDisplayName}</div>
                      )}
                    </div>
                  </div>
                );
                return {
                  name: 'trunkMtn',
                  children,
                  value: item.trunkMtn ? item.trunkMtn : item.mldTrunkMtn,
                };
              })}
            />
          </RadioButtonStyle>
        )}
      </BodyWrap>
    ) : (
      <BodyWrap>
        <p style={{ textAlign: 'left', marginLeft: '32px' }}>No compatible devices to share</p>
      </BodyWrap>
    );

  const numShareFooter = (
    <FooterWrap isAcssDeviceMFe={window?.mfe?.scmDeviceMfeEnable} isDark={isDark}>
      <CenterDivWrap>
        <Button
          data-track='ok'
          data-testid='OkButton'
          onClick={() => {
            updateNumberShare();
          }}
        >
          OK
        </Button>
      </CenterDivWrap>
      <div />
    </FooterWrap>
  );

  return (
    opened && (
      <ModelWrap
        isAcssDeviceMFe={window?.mfe?.scmDeviceMfeEnable}
        opened={opened}
        surface={isDark ? 'dark' : 'light'}
        fullScreenDialog={!(window?.mfe?.scmDeviceMfeEnable && enableSCMNumberShare)}
        disableAnimation={false}
        disableOutsideClick={false}
        closeButton={null}
        ariaLabel='Testing Modal'
        isDark={isDark}
      >
        {numShareHeader}
        {numShareBody}
        {numShareFooter}
      </ModelWrap>
    )
  );
}
export default NumberShareModal;
