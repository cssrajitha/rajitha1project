import React, { useState, useEffect, useLayoutEffect, useRef, useMemo, useCallback } from 'react';
import styled from 'styled-components';
import { Icon } from '@vds/icons';
import { formatCurrency } from 'onevzsoemfecommon/Helpers';



const EligibilityInfoWrapper = styled.div`
  font-size: 0.75rem;
  color: #333;
  margin-top: 1rem;
  font-family: 'BrandFont-Text';
  white-space: normal;
  line-height: 1.4; 
`;

const IconWrapper = styled.div`
  display: inline-flex;
  vertical-align: middle;
  margin-left: 0.3rem;
  cursor: pointer;
  
  /* --- CHANGE 1: Make the icon the positioning anchor --- */
  position: relative; 
`;

const TableContainer = styled.div`
  /* --- Default styles for larger screens --- */
  position: absolute;
  bottom: calc(100% + 12px);
  ${({ alignRight }) => alignRight ? `
    right: 0;
    left: auto;
  ` : `
    left: 0;
    right: auto;
  `}
  background-color: white;
  border: 1px solid #999;
  border-radius: 4px;
  box-shadow: 0 2px 8px rgba(8, 6, 6, 0.15);
  width: 420px;
  z-index: 10;
  padding: 8px;
  max-height: 235px;
  overflow-y: auto;

  &::after {
    content: '';
    position: absolute;
    top: 100%;
    right: 10px;
    border-width: 8px;
    border-style: solid;
    border-color: white transparent transparent transparent;
  }

 /* --- CHANGE STARTS HERE --- */
  /* This media query targets typical tablet screen sizes */
  @media (min-width: 768px) and (max-width: 1024px) {
    right: auto; /* Unset the default right alignment */
    left: '20px';     /* Align to the left edge of the icon on tablet screens */
  }
  /* --- CHANGE ENDS HERE --- */
`; 

const TableSection = styled.div`
  border: 1px solid #d4d4d4;
  border-radius: 0px; 
  overflow: hidden;

  & + & {
    margin-top: 8px;
  }
`;

const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
  table-layout: fixed;
`;

const Th = styled.th`
  padding: 10px !important;
  text-align: center;
  vertical-align: middle;
  font-size: 0.8rem;
  font-family: 'BrandFont-Text';
  font-weight: bold; 
  border-bottom: 1px solid #d4d4d4;
  
  &:not(:last-child) {
    border-right: 1px solid #d4d4d4;
  }
`;

const Td = styled.td`
  padding: 10px;
  text-align: center;
  vertical-align: middle;
  font-size: 0.85rem;
  font-family: 'BrandFont-Text';
  
  &:not(:last-child) {
    border-right: 1px solid #d4d4d4;
  }
`;

const SubHeaderTh = styled(Th)`
  font-weight: bold;
  border-top: 1px solid #d4d4d4;
`;




const PaymentOptionsDisclaimer = ({ dpEligibilityResult, selectedSku }) => {
  const [showEligibility, setShowEligibility] = useState(false);
  const popupRef = useRef(null);
  const iconRef = useRef(null); 
  const [alignRight, setAlignRight] = useState(true);

  // Recalculate alignRight when popup is shown
  // Use layout effect to measure after DOM update
  useLayoutEffect(() => {
    if (showEligibility && iconRef.current && popupRef.current) {
      const iconRect = iconRef.current.getBoundingClientRect();
      const popupRect = popupRef.current.getBoundingClientRect();
      // If popup would overflow right, align right
      if (iconRect.right + popupRect.width > window.innerWidth) {
        setAlignRight(true); // align popup's right edge to icon's right
      } else if (iconRect.left - popupRect.width < 0) {
        setAlignRight(false); // align popup's left edge to icon's left
      } else {
        setAlignRight(window.innerWidth - iconRect.right < iconRect.left);
      }
    }
  }, [showEligibility]);

  const updateAlignment = useCallback(() => {
    const calculateAlignment = () => {
      const rect = iconRef.current.getBoundingClientRect();
      setAlignRight(window.innerWidth - rect.right < rect.left);
    }
    iconRef.current && calculateAlignment();
  }, []);

  const handleClickOutside = (event) => {
      if (iconRef.current?.contains(event.target)) {
        return;
      }
      if (popupRef.current && !popupRef.current.contains(event.target)) {
        setShowEligibility(false);
      }
    };  
   
    
    useEffect(() => {
      document.addEventListener('mousedown', handleClickOutside);
      return () => {
        document.removeEventListener('mousedown', handleClickOutside);
      };
    }, [handleClickOutside]); 
  
  useEffect(() => {
    window.addEventListener('resize', updateAlignment);
    return () => window.removeEventListener('resize', updateAlignment);
  }, [updateAlignment]);
    const eligibleDevicePaymentTerms = useMemo(() => 
      new Set(
        selectedSku?.devicePaymentPrice?.map(item => item.contractDuration) || []
      ), 
      [selectedSku] 
    );  


     if (!dpEligibilityResult?.data) {
    return null;
  } 


  const {
    isDevicePaymentEligible,
    totalFinanceLimit,
    downPaymentPercentage,
  
  } = dpEligibilityResult.data;   



  return (
    <EligibilityInfoWrapper>
      <span>
        Price and contract terms display based on the customer's contract with Verizon and device payment information on the credit application.
      </span>
      
     
      <IconWrapper
        ref={iconRef} 
        data-testid="icon"
        onClick={() => setShowEligibility(!showEligibility)}
        role="button"
        tabIndex="0"
        onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && setShowEligibility(!showEligibility)}
        aria-expanded={showEligibility}
        aria-label="View eligibility details"
      >
        <Icon name='info' size='small' color='neutral' />
        
        {showEligibility && (
          <TableContainer ref={popupRef} alignRight={alignRight} data-testid="popup" data-alignright={alignRight} >
            <TableSection>
              <Table>
                <thead>
                  <tr>
                    <Th style={{ width: '25%' }}>Dpp Eligible</Th>
                    <Th style={{ width: '37%' }}>Dpp Spending Limit</Th>
                    <Th style={{ width: '38%' }}>Dpp Down Payment</Th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <Td>{isDevicePaymentEligible ? 'Y' : 'N'}</Td>
                    <Td>{formatCurrency(totalFinanceLimit || 0)}</Td>
                    <Td>{downPaymentPercentage || 0}%</Td>
                  </tr>
                </tbody>
              </Table>
            </TableSection> 

            <TableSection>
              <Table>
                <thead>
                  <tr>
                    <SubHeaderTh colSpan="2">Contract Term Eligibility</SubHeaderTh>
                  </tr>
                  <tr>
                    <Th>Term</Th>
                    <Th>Ecpd Eligibility</Th>
                  </tr>
                </thead>
                <tbody>
                  <>
                  <tr>
                      <Td>1 Year</Td>
                      <Td>{selectedSku?.oneYearPrice ? 'Y' : 'N'}</Td>
                  </tr>
                  <tr>
                      <Td>2 Year</Td>
                      <Td>{selectedSku?.twoYearPrice ? 'Y' : 'N'}</Td>
                  </tr>
                  <tr>
                      <Td>30 Month</Td>
                      <Td>{selectedSku?.thirtyMonthPrice ? 'Y' : 'N'}</Td>
                  </tr>
                  <tr>
                      <Td>3 Year</Td>
                      <Td>{selectedSku?.threeYearPrice ? 'Y' : 'N'}</Td>
                  </tr>
                  </>
                </tbody>
              </Table>
           
              <Table>
                <thead>
                  <tr>
                    <SubHeaderTh colSpan="2">Device Payment Eligibility</SubHeaderTh>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <Td>DP 36 Month</Td>
                    <Td>{eligibleDevicePaymentTerms.has(36) ? 'Y' : 'N'}</Td>
                  </tr>
                  <tr>
                    <Td>DP 24 Month</Td>
                    <Td>{eligibleDevicePaymentTerms.has(24) ? 'Y' : 'N'}</Td>
                  </tr>
                  <tr>
                    <Td>DP 30 Month</Td>
                    <Td>{eligibleDevicePaymentTerms.has(30) ? 'Y' : 'N'}</Td>
                  </tr>
                </tbody>
              </Table>
            </TableSection>
          </TableContainer>
        )}
      </IconWrapper>
    </EligibilityInfoWrapper> 
  );   
}

export default PaymentOptionsDisclaimer;