import { UI_SELECTORS } from '../../constants/uiSelectors';
import { FEATURE_FLAGS } from '../../constants/featureFlags';
import React from 'react';
import { render, screen, waitFor, cleanup } from '../../modules/test-utils/renderHelper';
import userEvent from '@testing-library/user-event';
// Ensure VBG channel for gating and avoid DomService isTelesales runtime errors
jest.mock('onevzsoemfeframework/VbgAemUtil', () => ({
  isVbg: jest.fn(() => true),
  isVbgAem: jest.fn(() => true),
}));
jest.mock('onevzsoemfeframework/DomService', () => {
  const actual = jest.requireActual('onevzsoemfeframework/DomService');
  return { ...actual, isTelesales: jest.fn(() => false) };
});
import DeviceInfo from './DeviceInfo';
import { toFullYear } from '../../modules/utils/dateUtils';
import { ThemeProvider } from 'styled-components';

// Environment stubs used by DeviceInfo
beforeAll(() => {
  // Avoid undefined access in component guarded by feature flags
  window.mfe = window.mfe || {};
});

afterEach(() => {
  cleanup();
  sessionStorage.clear();
  jest.clearAllMocks();
});

// Minimal product details and device details to satisfy early effects
const minimalDetails = {
  isNumberShareMandatory: false,
  isNumberShareCapable: false,
  defaultSKU: 'SKU1',
  defaultSku: 'SKU1',
  defaultSKUObj: { inventoryDetails: { dFillInventory: { isPreOrder: false } } },
  childSkus: [
    {
      sorId: 'SKU1',
      capacity: '64GB',
      color: { displayName: 'Black', colorCssStyle: {} },
      imageUrlMap: {},
      inventoryDetails: { dFillInventory: { isPreOrder: false, isInStock: true }, localInventory: { isInStock: true } },
    },
  ],
};

const baseProps = {
  // Required data
  details: minimalDetails,
  productDetails: { commonInfo: { showPrice: false, showShipitToggle: false }, deviceSku: {} },
  selectedPaymentInfo: { contractType: 'MONTH_TO_MONTH' },

  // Setters and utilities used in effects
  setSelectedSku: jest.fn(),
  setSelectedColor: jest.fn(),
  setSelectedBYODCss: jest.fn(),
  setSelectedSize: jest.fn(),
  callNumberShareInfo: jest.fn(),
  callWFGbannerInfo: jest.fn(),
  callDpEligibilityBanner: jest.fn(),
  groupByColors: jest.fn(() => []),
  // Ship-it / ISPU toggles expected as props by DeviceInfo
  isShipItToggleOn: false,
  setIsShipItToggleOn: jest.fn(),
  ispuToggleOn: false,
  setIspuToggleOn: jest.fn(),

  // Query result placeholders
  InventoryDetailsResult: { status: 'idle', data: {} },
  upgradeReasonCodeResponse: { isSuccess: false },
  dpEligibilityResult: { isSuccess: false, data: {} },

  // Customer profile used in many guards
  customerProfileDetails: {
    customer: {
      channel: 'OMNI-CARE',
      billAccounts: [{ mtns: [], paymentInfo: {} }],
      customerAttributes: { customerType: 'N' },
    },
    commonInfo: {
      isIndirect: false,
      disableDfillRadioButton: false,
      isISPUEnabled: false,
      showShipitToggle: false,
    },
  },

  // Activate Later interaction callback (what we assert on)
  setActivatedDate: jest.fn(),
  updateDeviceData: jest.fn(),
  updateDeviceId: jest.fn(),
  updateSimId: jest.fn(),
  updateShowISPUForVA: jest.fn(),
  showISPUForVA: false,
  cartDetails: {},
  setMitekIdVerifyStatus: jest.fn(),
  setUpcCodeFromPdpScan: jest.fn(),
  upcCodeFromPdpScan: '',
  isActiveNewLine: false,
  getBestBuyPricingDetails: jest.fn(),
  skuRealAgentCode: '',
  simSwapNotificationHighRiskMsg: '',
  setUpgradeReasonType: jest.fn(),
  upgradeReasonType: '',

  // Misc flags consumed in guards
  isNewlyAddedLine: false,
  isVbgProfessionalInstall: false,
};

describe('DeviceInfo Activate Later (lines 1814–1850)', () => {
  test('toggle ON generates 8-day list starting from today with MM/DD/YY format and clicking a day sets activated date', async () => {
    // Enable the feature flag via sessionStorage (read at mount)
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ vbgNSAAALActivateLaterFFlag: 'TRUE' }));
    const { isVbg } = require('onevzsoemfeframework/VbgAemUtil');
    isVbg.mockReturnValue(true);

    const setActivatedDate = jest.fn();
    const { container } = render(
      <DeviceInfo
        {...baseProps}
        selectedPaymentInfo={{ contractType: 'MONTH_TO_MONTH' }}
        setActivatedDate={setActivatedDate}
      />,
    );

  // eslint-disable-next-line no-console
    console.debug('DOM snapshot (test 1):', container.innerHTML?.slice(0, 2000));
    const toggleEl = await waitFor(() => {
      const el = container.querySelector(`[name="${UI_SELECTORS.ACTIVATE_LATER_TOGGLE_NAME}"]`);
      if (!el) {
        // Try alternative selection by label/title proximity
        const titleEl = Array.from(container.querySelectorAll('div,h3,p,span')).find(x => /Activate Later/i.test(x.textContent || ''));
        if (titleEl) {
          const possibleSwitch = titleEl.closest('div')?.querySelector('[role="switch"],button,a');
          if (possibleSwitch) return possibleSwitch;
        }
      }
      expect(el).toBeTruthy();
      return el;
    });
    userEvent.click(toggleEl);

    // Wait for 7 dates to be generated by the effect bound to isActivateLater
    // Date format should be MM/DD/YY
    const dateRegex = /\d{2}\/\d{2}\/\d{2}/;
    const dayButtons = await waitFor(() => {
      const buttons = screen
        .getAllByRole('button')
        .filter((btn) => /^(Sun|Mon|Tue|Wed|Thu|Fri|Sat)$/.test((btn.textContent || '').trim()));
      expect(buttons.length).toBeGreaterThanOrEqual(8);
      return buttons;
    });
    const dateTexts = screen.getAllByText(dateRegex);
    expect(dateTexts.length).toBeGreaterThanOrEqual(8);

    // Verify first date is today's date in MM/DD/YY format
    const today = new Date();
    const expectedFirstDate = `${String(today.getMonth() + 1).padStart(2, '0')}/${String(today.getDate()).padStart(2, '0')}/${String(today.getFullYear()).slice(-2)}`;
    expect(dateTexts[0].textContent).toBe(expectedFirstDate);

    // Click first day; callback should be invoked with the corresponding date value
    userEvent.click(dayButtons[0]);
    expect(setActivatedDate).toHaveBeenCalledWith((dateTexts[0].textContent || '').trim());
  });

  test('toggle OFF clears the list (effect dependency on isActivateLater)', async () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ vbgNSAAALActivateLaterFFlag: 'TRUE' }));
    const { isVbg } = require('onevzsoemfeframework/VbgAemUtil');
    isVbg.mockReturnValue(true);

    const { container } = render(
      <DeviceInfo
        {...baseProps}
        selectedPaymentInfo={{ contractType: 'MONTH_TO_MONTH' }}
        setActivatedDate={jest.fn()}
      />,
    );

    // eslint-disable-next-line no-console
    console.debug('DOM snapshot (test 2):', container.innerHTML?.slice(0, 2000));
    const toggleEl = await waitFor(() => {
      const el = container.querySelector(`[name="${UI_SELECTORS.ACTIVATE_LATER_TOGGLE_NAME}"]`);
      if (!el) {
        const titleEl = Array.from(container.querySelectorAll('div,h3,p,span')).find(x => /Activate Later/i.test(x.textContent || ''));
        if (titleEl) {
          const possibleSwitch = titleEl.closest('div')?.querySelector('[role="switch"],button,a');
          if (possibleSwitch) return possibleSwitch;
        }
      }
      expect(el).toBeTruthy();
      return el;
    });

    // Turn ON then confirm dates appear
    userEvent.click(toggleEl);
    const dateRegex = /\d{2}\/\d{2}\/\d{2}/;
    await waitFor(() => {
      expect(screen.getAllByText(dateRegex).length).toBeGreaterThanOrEqual(7);
    });

    // Turn OFF and verify the list is cleared
    userEvent.click(toggleEl);
    await waitFor(() => {
      expect(screen.queryAllByText(dateRegex)).toHaveLength(0);
    });
  });

  test('when year-format flag is enabled, clicking a day passes MM/DD/YYYY to setActivatedDate', async () => {
    // Enable both feature flags: show toggle and convert year to YYYY
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({ vbgNSAAALActivateLaterFFlag: 'TRUE', vbgNsaYearFormatActLaterFFlag: 'TRUE' })
    );
    const { isVbg } = require('onevzsoemfeframework/VbgAemUtil');
    isVbg.mockReturnValue(true);

    const setActivatedDate = jest.fn();
    const { container } = render(
      <DeviceInfo
        {...baseProps}
        selectedPaymentInfo={{ contractType: 'MONTH_TO_MONTH' }}
        setActivatedDate={setActivatedDate}
      />,
    );

    // eslint-disable-next-line no-console
    console.debug('DOM snapshot (test 3):', container.innerHTML?.slice(0, 2000));
    const toggleEl = await waitFor(() => {
      const el = container.querySelector(`[name="${UI_SELECTORS.ACTIVATE_LATER_TOGGLE_NAME}"]`);
      if (!el) {
        const titleEl = Array.from(container.querySelectorAll('div,h3,p,span')).find(x => /Activate Later/i.test(x.textContent || ''));
        if (titleEl) {
          const possibleSwitch = titleEl.closest('div')?.querySelector('[role="switch"],button,a');
          if (possibleSwitch) return possibleSwitch;
        }
      }
      expect(el).toBeTruthy();
      return el;
    });
    userEvent.click(toggleEl);

    const dateRegex = /\d{2}\/\d{2}\/\d{2}/;
    const dayButtons = await waitFor(() => {
      const buttons = screen
        .getAllByRole('button')
        .filter((btn) => /^(Sun|Mon|Tue|Wed|Thu|Fri|Sat)$/.test((btn.textContent || '').trim()));
      expect(buttons.length).toBeGreaterThanOrEqual(8);
      return buttons;
    });

    const dateTexts = screen.getAllByText(dateRegex);
    expect(dateTexts.length).toBeGreaterThanOrEqual(8);

    // Click first day; callback should be invoked with YYYY date
    const selectedText = (dateTexts[0].textContent || '').trim(); // MM/DD/YY
    userEvent.click(dayButtons[0]);
    expect(setActivatedDate).toHaveBeenCalledWith(toFullYear(selectedText));
  });
});

describe('DeviceInfo Activate Later styled wrappers and guard coverage (lines 199–217, 1895–1907)', () => {
  test('renders Activate Later section and date list with ThemeProvider (covers styled wrappers 199–217)', async () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ vbgNSAAALActivateLaterFFlag: 'TRUE' }));
    const { isVbg } = require('onevzsoemfeframework/VbgAemUtil');
    isVbg.mockReturnValue(true);

    const theme = { spacing: { small: '11px', medium: '25px', large: '37px' } };
    const { container } = render(
      <ThemeProvider theme={theme}>
        <DeviceInfo
          {...baseProps}
          selectedPaymentInfo={{ contractType: 'MONTH_TO_MONTH' }}
          setActivatedDate={jest.fn()}
        />
      </ThemeProvider>
    );

    // eslint-disable-next-line no-console
    console.debug('DOM snapshot (styled wrappers test):', container.innerHTML?.slice(0, 2000));
    const toggleEl = await waitFor(() => {
      const el = container.querySelector(`[name="${UI_SELECTORS.ACTIVATE_LATER_TOGGLE_NAME}"]`);
      if (!el) {
        const titleEl = Array.from(container.querySelectorAll('div,h3,p,span')).find(x => /Activate Later/i.test(x.textContent || ''));
        if (titleEl) {
          const possibleSwitch = titleEl.closest('div')?.querySelector('[role="switch"],button,a');
          if (possibleSwitch) return possibleSwitch;
        }
      }
      expect(el).toBeTruthy();
      return el;
    });
    userEvent.click(toggleEl);

    // Notification text inside ActivateLaterSection
    const infoTitle = await waitFor(() =>
      Array.from(container.querySelectorAll('div')).find(el => el.textContent?.includes('Activation date can be set'))
    );
    expect(infoTitle).toBeTruthy();

    // Date items under ActivatedDateListWrapper
    const dateRegex = /\d{2}\/\d{2}\/\d{2}/;
    const dateItems = Array.from(container.querySelectorAll('div')).filter(el => dateRegex.test(el.textContent || ''));
    expect(dateItems.length).toBeGreaterThan(0);
  });

  test('onClickActivatedDate guard path when no valid date selected (covers 1895–1902)', async () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ vbgNSAAALActivateLaterFFlag: 'TRUE' }));
    const { isVbg } = require('onevzsoemfeframework/VbgAemUtil');
    isVbg.mockReturnValue(true);

    // Inject a test-only activated date list with undefined date to trigger the guard path
    window.__TEST_ACTIVATED_DATE_LIST__ = [{ date: undefined, dayName: 'Mon', isSelected: false }];
    const warnSpy = jest.spyOn(console, 'warn').mockImplementation(() => {});
    const setActivatedDate = jest.fn();

    const { container } = render(
      <DeviceInfo
        {...baseProps}
        selectedPaymentInfo={{ contractType: 'MONTH_TO_MONTH' }}
        setActivatedDate={setActivatedDate}
      />
    );

    const toggleEl = await waitFor(() => {
      const el = container.querySelector(`[name="${UI_SELECTORS.ACTIVATE_LATER_TOGGLE_NAME}"]`);
      expect(el).toBeTruthy();
      return el;
    });
    userEvent.click(toggleEl);

    const button = Array.from(container.querySelectorAll('button')).find((btn) => btn.textContent?.includes('Mon')) || container.querySelector('button');
    expect(button).toBeTruthy();
    userEvent.click(button);

    expect(warnSpy).toHaveBeenCalledWith('No date selected in Activate Later');
    expect(setActivatedDate).not.toHaveBeenCalled();

    // Cleanup the test seam
    delete window.__TEST_ACTIVATED_DATE_LIST__;
    warnSpy.mockRestore();
  });

  test('onClickActivatedDate keeps original date when year-format flag is FALSE (covers 1904–1907 else path)', async () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ vbgNSAAALActivateLaterFFlag: 'TRUE', vbgNsaYearFormatActLaterFFlag: 'FALSE' }));
    const { isVbg } = require('onevzsoemfeframework/VbgAemUtil');
    isVbg.mockReturnValue(true);

    const setActivatedDateSpy = jest.fn();
    const { container } = render(
      <DeviceInfo
        {...baseProps}
        selectedPaymentInfo={{ contractType: 'MONTH_TO_MONTH' }}
        setActivatedDate={setActivatedDateSpy}
      />
    );

    const toggleEl = await waitFor(() => {
      const el = container.querySelector(`[name="${UI_SELECTORS.ACTIVATE_LATER_TOGGLE_NAME}"]`);
      expect(el).toBeTruthy();
      return el;
    });
    userEvent.click(toggleEl);

    const dateRegex = /\d{2}\/\d{2}\/\d{2}/;
    const dayButtons = await waitFor(() => {
      const buttons = screen
        .getAllByRole('button')
        .filter((btn) => /^(Sun|Mon|Tue|Wed|Thu|Fri|Sat)$/.test((btn.textContent || '').trim()));
      expect(buttons.length).toBeGreaterThanOrEqual(8);
      return buttons;
    });
    const dateTexts = screen.getAllByText(dateRegex);
    expect(dateTexts.length).toBeGreaterThanOrEqual(8);

    const rawDate = (dateTexts[0].textContent || '').trim();
    userEvent.click(dayButtons[0]);
    expect(setActivatedDateSpy).toHaveBeenCalledWith(rawDate);
  });

  test('year-format flag TRUE but test seam forces FALSE (covers lines 514–517 override path)', async () => {
    // Enable both flags in APP_PROPERTIES but force override via test seam
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ vbgNSAAALActivateLaterFFlag: 'TRUE', vbgNsaYearFormatActLaterFFlag: 'TRUE' }));
    const { isVbg } = require('onevzsoemfeframework/VbgAemUtil');
    isVbg.mockReturnValue(true);
    // Test-only seam to force year-format flag to false inside DeviceInfo
    window.__TEST_FORCE_YEAR_FORMAT_FALSE__ = true;

    const setActivatedDateSpy = jest.fn();
    const { container } = render(
      <DeviceInfo
        {...baseProps}
        selectedPaymentInfo={{ contractType: 'MONTH_TO_MONTH' }}
        setActivatedDate={setActivatedDateSpy}
      />
    );

    const toggleEl = await waitFor(() => {
      const el = container.querySelector(`[name="${UI_SELECTORS.ACTIVATE_LATER_TOGGLE_NAME}"]`);
      expect(el).toBeTruthy();
      return el;
    });
    userEvent.click(toggleEl);

    const dateRegex = /\d{2}\/\d{2}\/\d{2}/;
    const dayButtons = await waitFor(() => {
      const buttons = screen
        .getAllByRole('button')
        .filter((btn) => /^(Sun|Mon|Tue|Wed|Thu|Fri|Sat)$/.test((btn.textContent || '').trim()));
      expect(buttons.length).toBeGreaterThanOrEqual(8);
      return buttons;
    });
    const dateTexts = screen.getAllByText(dateRegex);
    expect(dateTexts.length).toBeGreaterThanOrEqual(8);

    const rawDate = (dateTexts[0].textContent || '').trim();
    userEvent.click(dayButtons[0]);
    expect(setActivatedDateSpy).toHaveBeenCalledWith(rawDate);

    // Cleanup seam
    delete window.__TEST_FORCE_YEAR_FORMAT_FALSE__;
  });
});
