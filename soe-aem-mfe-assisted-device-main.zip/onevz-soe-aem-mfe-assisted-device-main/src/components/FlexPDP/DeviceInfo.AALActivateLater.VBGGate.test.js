import React from 'react';
import { render, cleanup } from '../../modules/test-utils/renderHelper';
import { UI_SELECTORS } from '../../constants/uiSelectors';

// Mock VBG util with overridable jest.fn to control channel per test
jest.mock('onevzsoemfeframework/VbgAemUtil', () => ({
  isVbg: jest.fn(() => true),
  isVbgAem: jest.fn(() => true),
}));
// Ensure isTelesales exists to avoid runtime ReferenceError in DeviceInfo
jest.mock('onevzsoemfeframework/DomService', () => {
  const actual = jest.requireActual('onevzsoemfeframework/DomService');
  return {
    ...actual,
    isTelesales: jest.fn(() => false),
  };
});

// Minimal sessionStorage polyfill (in case environment doesn't provide one)
const __sessionStore = {};
if (!global.sessionStorage) {
  global.sessionStorage = {
    getItem: (key) => (key in __sessionStore ? __sessionStore[key] : null),
    setItem: (key, value) => { __sessionStore[key] = String(value); },
    removeItem: (key) => { delete __sessionStore[key]; },
    clear: () => { Object.keys(__sessionStore).forEach((k) => delete __sessionStore[k]); },
  };
}

import DeviceInfo from './DeviceInfo';

// Minimal props to render DeviceInfo without crashing; mirrors prior tests
const minimalDetails = {
  isNumberShareMandatory: false,
  isNumberShareCapable: false,
  defaultSKU: 'SKU1',
  defaultSku: 'SKU1',
  defaultSKUObj: { inventoryDetails: { dFillInventory: { isPreOrder: false } } },
  childSkus: [
    {
      sorId: 'SKU1',
      capacity: '64GB',
      color: { displayName: 'Black', colorCssStyle: {} },
      imageUrlMap: {},
      inventoryDetails: { dFillInventory: { isPreOrder: false, isInStock: true }, localInventory: { isInStock: true } },
    },
  ],
};

const baseProps = {
  details: minimalDetails,
  productDetails: { commonInfo: { showPrice: false, showShipitToggle: false }, deviceSku: {} },
  selectedPaymentInfo: { contractType: 'MONTH_TO_MONTH' },

  // Callbacks and placeholders
  setSelectedSku: jest.fn(),
  setSelectedColor: jest.fn(),
  setSelectedBYODCss: jest.fn(),
  setSelectedSize: jest.fn(),
  callNumberShareInfo: jest.fn(),
  callWFGbannerInfo: jest.fn(),
  callDpEligibilityBanner: jest.fn(),
  groupByColors: jest.fn(() => []),
  isShipItToggleOn: false,
  setIsShipItToggleOn: jest.fn(),
  ispuToggleOn: false,
  setIspuToggleOn: jest.fn(),
  InventoryDetailsResult: { status: 'idle', data: {} },
  upgradeReasonCodeResponse: { isSuccess: false },
  dpEligibilityResult: { isSuccess: false, data: {} },
  customerProfileDetails: {
    customer: { channel: 'OMNI-CARE', billAccounts: [{ mtns: [], paymentInfo: {} }], customerAttributes: { customerType: 'N' } },
    commonInfo: { isIndirect: false, disableDfillRadioButton: false, isISPUEnabled: false, showShipitToggle: false },
  },
  setActivatedDate: jest.fn(),
  updateDeviceData: jest.fn(),
  updateDeviceId: jest.fn(),
  updateSimId: jest.fn(),
  updateShowISPUForVA: jest.fn(),
  showISPUForVA: false,
  cartDetails: {},
  setMitekIdVerifyStatus: jest.fn(),
  setUpcCodeFromPdpScan: jest.fn(),
  upcCodeFromPdpScan: '',
  isActiveNewLine: false,
  getBestBuyPricingDetails: jest.fn(),
  skuRealAgentCode: '',
  simSwapNotificationHighRiskMsg: '',
  setUpgradeReasonType: jest.fn(),
  upgradeReasonType: '',
  isNewlyAddedLine: false,
  isVbgProfessionalInstall: false,
};

describe('DeviceInfo Activate Later VBG gating', () => {
  afterEach(() => {
    cleanup();
    sessionStorage.clear();
    jest.clearAllMocks();
  });

  test('renders Activate Later toggle only when VBG and feature flag are true', () => {
    const { isVbg } = require('onevzsoemfeframework/VbgAemUtil');
    isVbg.mockReturnValue(true);
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ vbgNSAAALActivateLaterFFlag: 'TRUE' }));

    const { container } = render(
      <DeviceInfo {...baseProps} selectedPaymentInfo={{ contractType: 'MONTH_TO_MONTH' }} />
    );

    const toggleEl = container.querySelector(`[name="${UI_SELECTORS.ACTIVATE_LATER_TOGGLE_NAME}"]`);
    expect(toggleEl).toBeTruthy();
  });

  test('does not render Activate Later toggle when not VBG even if feature flag is true', () => {
    const { isVbg } = require('onevzsoemfeframework/VbgAemUtil');
    isVbg.mockReturnValue(false);
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ vbgNSAAALActivateLaterFFlag: 'TRUE' }));

    const { container } = render(
      <DeviceInfo {...baseProps} selectedPaymentInfo={{ contractType: 'MONTH_TO_MONTH' }} />
    );

    const toggleEl = container.querySelector(`[name="${UI_SELECTORS.ACTIVATE_LATER_TOGGLE_NAME}"]`);
    expect(toggleEl).toBeFalsy();
  });
});
