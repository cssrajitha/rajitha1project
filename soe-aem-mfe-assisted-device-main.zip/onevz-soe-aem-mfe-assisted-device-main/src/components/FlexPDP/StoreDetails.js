import { Body } from '@vds/typography';
import { has } from 'lodash';
import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import styled from 'styled-components';
import { Toggle } from '@vds/toggles';
import { Button, TextLink } from '@vds/buttons';
import { Line } from '@vds/lines';
import { Grid, Row, Col } from '@vds/grids';
import { Tooltip } from '@vds/tooltips';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import moment from 'moment';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import DOMPurify from 'dompurify';
import { useLazyGetCheckZipcodeISPUEligibilityQuery } from '../../modules/services/APIService/APIServiceHooks';
import { statesList, DARK_THEME_COLOR, LIGHT_THEME_COLOR, DARK_THEME_BGCOLOR, LIGHT_BG_COLOR } from '../../constants/constants';
import {
  hasISPUAndLocalConflict,
  shouldHideISPUToggle,
} from './pdputils';

const StyledDiv = styled.div`
  margin-top: 3.5%;
  display: flex;
`;

const StoreListWrapper = styled.div`
  display: flex;
  margin-left: 0.4375rem;
  padding-top: 0.4375rem;
`;

const StoresNearYou = styled.div`
  display: flex;
  padding: 0px 20px 1.75rem 10px;
  font-size: 1.25rem;
`;

const FaqMarginBottom = styled.div`
  margin-bottom: 0.5rem;
  font-size: 20px;
`;

const PDImgMarginRight = styled.div`
  margin-right: 1.5rem;
`;

const DeviceWrapper = styled.div`
  display: flex;
`;

const HorizontalLineWrapper = styled.div`
  padding: 1rem 0 1rem 0;
`;

const PickupStoreBtnWrapper = styled.div`
  display: flex;
  align-items: center;
`;

const PaginationWrapper = styled.div`
  display: flex;
  justify-content: center;
  width: 100%;
  button {
    margin: 0 2%;
  }
`;

const StoreMarginTop = styled.div`
  margin-top: 0.5rem;
`;

const PickUPBtn = styled.div`
  flex-basis: 100%;
  max-width: 100%;
  position: relative;
  box-sizing: inherit;
`;

const ReadyByText = styled.div`
  padding: 0 0 5px 30px;
  line-height: 1.5;
  font-weight: bold !important;
`;
function HorizontalLine() {
  return (
    <HorizontalLineWrapper>
      <Line type='secondary' surface='light' />
    </HorizontalLineWrapper>
  );
}

const Timings = ({ day, timingSchedule, themeColor }) => (
  <Body size='large' color={themeColor}>
    {' '}
    {day}: {timingSchedule}
  </Body>
);

function StoreDetails(props) {
  const {
    stores,
    setShowDeviceModal,
    setIsIspuItemInCart,
    setSelectedStore,
    setDataSet,
    selectedPage,
    setSelectedPage,
    showOnlyAvailableStores,
    totalStores,
    selectedSku,
    setIspuToggleOn,
    setStoreList,
    setIspufromCart,
    ProductDetails,
    activeMtn,
    customerProfileDetails,
    checkInStoreResult,
    findStoreBtnClicked,
    setFindStoreBtnClicked,
    cartDetails,
    isBBYLocalOrder,
    BbyLocalOrderLocDetailsRequest,
    BbyLocalOrderLocDetailsApiResponse,
    bestBuyISPUEnableLocalOrderFFlag,
    isDarkTheme = false,
  } = props;
   const [showISPULocalConflictBanner, setShowISPULocalConflictBanner] = useState(false);
    const [showNonISPULocalBanner, setShowNonISPULocalBanner] = useState(false);
    const [shouldHideISPU, setShouldHideISPU] = useState(false);

  const themeColor = isDarkTheme ? DARK_THEME_COLOR : LIGHT_THEME_COLOR;
  const channel = 'OMNI-TELESALES';
  const getStateFullName = (code) => statesList[code];
  const getStoreType = (storeType) => {
    if (storeType === 'Y') {
      return '(Direct store)';
    }
    if (storeType === 'N') {
      return '(Indirect store)';
    }
    return '';
  };

  const [isApplyISPURestrictionFFlag] = getAssistedCradlePropertyV2(['isApplyISPURestrictionFFlag']);

  const dispatch = useDispatch();
  const [getCheckZipCodeIspu, checkZipCodeIspuResult] = useLazyGetCheckZipcodeISPUEligibilityQuery();
  const isIspuEligible = checkZipCodeIspuResult?.data?.data?.deviceCatalogItems?.[0]?.skus?.find(
    (sku) => sku.sorId === selectedSku?.sorId
  );
  const isPickupButtonDisabled = isIspuEligible && isIspuEligible?.isInstorePickupRestricted;
  const storeState = checkInStoreResult?.data?.stores.map((store) => store.state);
  const newStoreState = [...new Set(storeState)];
  const [isWaitingForBbyResponse, setIsWaitingForBbyResponse] = React.useState(false);

  const checkZipCodeStores = () => {
    dispatch(appMessageActions.clearAppMessages());
    newStoreState.forEach(async (stateId) => {
      const requestBodyCheckZipCode = {
        productId: ProductDetails?.productId,
        intentType:
          cartDetails?.cart?.lineDetails?.lineInfo?.[0]?.lineActivityType ||
          cartDetails?.cart?.orderDetails?.orderList?.[0]?.orderActivityType ||
          '',
        defaultSku: selectedSku?.sorId,
        processingMTN: activeMtn,
        cartId: customerProfileDetails?.customer?.cartId,
        state: stateId,
        channel: customerProfileDetails?.customer?.channel || sessionStorage.getItem('channel'),
        isApplyISPURestriction: !!isApplyISPURestrictionFFlag,
      };
      getCheckZipCodeIspu({ body: requestBodyCheckZipCode, customHeaders: { 'CHANNEL-TYPE': 'assisted' } });
      setFindStoreBtnClicked(false);
    });
  };

  useEffect(() => {
    if (isApplyISPURestrictionFFlag && stores && stores?.length > 0) {
      checkZipCodeStores();
    }
  }, [stores, findStoreBtnClicked]);

  useEffect(() => {
      const hasConflict = hasISPUAndLocalConflict(cartDetails, bestBuyISPUEnableLocalOrderFFlag);
      setShowISPULocalConflictBanner(hasConflict);
    }, [cartDetails, bestBuyISPUEnableLocalOrderFFlag]);
  
    useEffect(() => {
      const hideISPU = shouldHideISPUToggle(cartDetails, bestBuyISPUEnableLocalOrderFFlag);
      setShouldHideISPU(hideISPU);
      setShowNonISPULocalBanner(hideISPU);
    }, [cartDetails, bestBuyISPUEnableLocalOrderFFlag]);

  useEffect(() => {
    if (stores && isPickupButtonDisabled) {
      const url = 'https://infomanager.verizon.com/content/km/categories/channel-operations/204096.html';
     dispatch(
      appMessageActions.addAppMessage(
        <>
          Due to current business rules, In-Store Pickup for this item and order type is restricted in ${getStateFullName(newStoreState?.[newStoreState.length - 1])}. See <TextLink type='standAlone' size='large' onClick={() => window.open(DOMPurify.sanitize(url), '_blank',)} style={{
            color: 'blue',
            textDecoration: 'underline',
            fontWeight: 'bold',
          }}>
                    OST 204096
                </TextLink> for Details
        </>,
        'warning',
        true,
        15000,
        undefined,
        true,
      ),
    );

    }
  }, [stores, isPickupButtonDisabled]);
  
  // NEW: Listen for the API response coming from props
  useEffect(() => {
    if (isWaitingForBbyResponse && BbyLocalOrderLocDetailsApiResponse) {
      /* istanbul ignore else */
      if (BbyLocalOrderLocDetailsApiResponse.status === 'fulfilled') {
        setShowDeviceModal(false);
        setIspuToggleOn(true);
        setStoreList(false);
        setIspufromCart(false);
        setIsWaitingForBbyResponse(false);
      } else if (BbyLocalOrderLocDetailsApiResponse.status === 'rejected') {
        setIsWaitingForBbyResponse(false);
      }
    }
  }, [BbyLocalOrderLocDetailsApiResponse, isWaitingForBbyResponse]);

  const checkQuantity = (data) => {
    const itemArray = has(data, 'items.item') ? data.items.item : '';
    const itemCount = has(data, 'items.itemCount') ? data.items.itemCount : 0;
    const fivegCheck = '5G Internet';
    let quantityValue = '';
    if (itemCount > 0) {
      if (itemArray && fivegCheck) {
        quantityValue = itemArray.map((item) => item.quantity > 0).includes(true);
      } else {
        quantityValue = itemArray.map((item) => item.quantity > 0).includes(false);
      }
    } else {
      quantityValue = !fivegCheck;
    }
    return fivegCheck ? quantityValue : !quantityValue;
  };
  const storeEnable = (data) => {
    if (
      data &&
      checkQuantity(data) &&
      data.storeAvailableServices &&
      data.storeAvailableServices.includes('CURBSIDE') &&
      (data.storeAvailableServices.includes('LOCKER') || data.storeAvailableServices.includes('LOCKER24'))
    ) {
      return <div>Curbside, Locker Pickup Enabled</div>;
    }
    if (
      data &&
      checkQuantity(data) &&
      data.storeAvailableServices &&
      // !is5GDevice &&
      (data.storeAvailableServices.includes('LOCKER') || data.storeAvailableServices.includes('LOCKER24'))
    ) {
      return <div>Locker Pickup Enabled</div>;
    }
    if (
      data &&
      checkQuantity(data) &&
      data.storeAvailableServices &&
      data.storeAvailableServices.includes('CURBSIDE')
    ) {
      return <div>Curb Side Pickup Enabled</div>;
    }
  };

  const formatTimings = (data) => {
    const daysofWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const scheduleTimings = daysofWeek?.map((day) => {
      const key = `hours${day}`;
      const dayHours = data[key] || 'Closed';
      const timingSchedule = dayHours.toLowerCase().includes('Closed')
        ? 'Closed-'
        : dayHours.replace(/(\d{1,2}:\d{2} [APM]{2}) (\d{1,2}:\d{2} [APM]{2})/, '$1 - $2');
      return <Timings key={day} day={day} timingSchedule={timingSchedule} themeColor={themeColor} />;
    });
    return scheduleTimings;
  };

 const pickFromTheStore = (data) => {
    setSelectedStore(data);
    setIsIspuItemInCart(true);
    // NEW: Trigger the API call using the function passed from props
    if (bestBuyISPUEnableLocalOrderFFlag && isBBYLocalOrder) {
      const requestBody = {
        realAgentCode: data?.id?.padStart(4, '0'),
        masterAgentId: 'BBEMPLOC',
      };
      setIsWaitingForBbyResponse(true);
      // This triggers the API call in the parent/hook.
      // The response will flow back down via BbyLocalOrderLocDetailsApiResponse prop.
      /* istanbul ignore else */
      if (BbyLocalOrderLocDetailsRequest) {
        BbyLocalOrderLocDetailsRequest({ body: requestBody });
      }
    } else {
      setShowDeviceModal(false);
      setIspuToggleOn(true);
      setStoreList(false);
      setIspufromCart(false);
    }
  };

  const pickupButtonText = (data) => {
    if (
      data &&
      data.storeAvailableServices &&
      data.storeAvailableServices.includes('CURBSIDE') &&
      data.storeAvailableServices.includes('LOCKER')
    ) {
      return 'Pickup \tfrom this store';
    }
    if (data && data.storeAvailableServices && data.storeAvailableServices.includes('CURBSIDE')) {
      return 'Curbside Pickup';
    }
    return 'Pickup \tfrom this store';
  };

  const handleSelectPage = (pageNo) => {
    setSelectedPage(pageNo);
    setDataSet(pageNo);
  };
  const gridParamsScm = {
    rowGutter: '10px',
    colSizes: {
      mobile: 1,
      tablet: 2,
      desktop: 3,
    },
  };
  const gridParamsReg = {
    bleed: '1272',
    rowGutter: '10px',
    colSizes: {
      mobile: 1,
      tablet: 2,
      desktop: 3,
    },
  };
  const gridParams = window?.mfe?.scmDeviceMfeEnable ? gridParamsScm : gridParamsReg;
  const storeList =
    stores &&
    stores.length > 0 &&
    stores.map((data, index) => (
      <>
        <StoreListWrapper key={`key-${data?.phoneNumber}`} className='Flex_Details'>
          <Grid {...gridParams}>
            <Row>
              <div style={{ maxWidth: '10%' }}>
                <Col>
                  <Body size='large' bold color={themeColor}>
                    {index + 1}
                  </Body>
                </Col>
              </div>
              <Col>
                <div style={{ width: '100%' }}>
                  <div>
                    <Body size='large' bold color={themeColor}>
                      <FaqMarginBottom>{data.storeName}</FaqMarginBottom>
                    </Body>
                    <div>{getStoreType(data.direct)}</div>
                    {storeEnable(data)}
                    {(channel === 'OMNI-TELESALES' || channel === 'CHAT-STORE') &&
                    data &&
                    checkQuantity(data) &&
                    data.storeAvailableServices &&
                    data.storeAvailableServices.includes('DS') ? (
                      <div>Door Side Pickup Enabled</div>
                    ) : (
                      ''
                    )}

{/* Only show Address if address1 exists */}
                    {data.address1 && (
                        <div>{data.address1}</div>
                    )}

                   <div>
                       {[data.city, data.state].filter(Boolean).join(', ')}
                  </div>

                    {/* Only show Phone if phoneNumber exists */}
                    {data.phoneNumber && (
                        <div>Phone : {data.phoneNumber}</div>
                    )}
                    <Body size='large' bold color={themeColor}>
                      {`${data?.items?.item?.[0]?.quantity > 0 ? data?.items?.itemCount : 0} ${'of'} ${data?.items?.item?.[0]?.quantity || 0} ${'item(s) available'}`}
                      {data?.items?.item?.[0]?.quantity > 0 && (
                        <Tooltip id='upgradeTT' size='small'>
                          <Body bold>
                            Available Cart item(s) in this store <br />
                            {(selectedSku?.color?.description || ' ') + (selectedSku?.capacity || ' ')}
                          </Body>
                        </Tooltip>
                      )}
                    </Body>
                    <Body size='large' bold>
                      {data.availableQty === 0 && <div>notavailabletext</div>}
                    </Body>
                  </div>
                </div>
              </Col>
              <Col>
                <div style={{ width: '100%' }}>
                  <div>
                    <Body size='large' bold color={themeColor}>
                      <FaqMarginBottom>{Number(data.distance).toFixed(2)} Miles away</FaqMarginBottom>
                    </Body>
                    {!bestBuyISPUEnableLocalOrderFFlag && !isBBYLocalOrder && formatTimings(data)}
                    <br />
                  </div>
                </div>
              </Col>
              <PickupStoreBtnWrapper>
                <Col>
                  <div className='Vertical_Middle'>
                    <div className='Grid Container'>
                      {data.storeAvailableServices && data.storeAvailableServices.includes('LIMITEDCURB') && (
                        <div>
                          Let customer know we will bring it to pick up spot until 4PM, but after pick up in store
                        </div>
                      )}
                      {checkQuantity(data) && data.inStorePickupFlag === 'Y' && !data?.estimatedReadyByDate && (
                        <div>
                          <Button
                            data-track={pickupButtonText(data)}
                            type='button'
                            label={pickupButtonText(data)}
                            disabled={isPickupButtonDisabled}
                            className='u-marginLeftSmall'
                            onClick={() => pickFromTheStore(data)}
                          >
                            {pickupButtonText(data)}
                          </Button>
                        </div>
                      )}
                      {(data?.estimatedReadyByDate || data?.estMaxDate) && (
                        //  this.getAvailableItems(data).length === 0 &&
                        <React.Fragment>
                          <ReadyByText>
                            Ready By&nbsp;
                            {data?.estimatedReadyByDate && (
                              <span>{moment(new Date(data?.estimatedReadyByDate)).format('MMMM Do')}</span>
                            )}
                            {data.estMaxDate && <span>{moment(data?.estMaxDate).format('MMMM Do')}</span>}{' '}
                          </ReadyByText>
                          <PickUPBtn>
                            <Button
                              data-track='Pickup \tfrom this store'
                              type='button'
                              label='Pickup \tfrom this store'
                              className='u-marginLeftSmall'
                              onClick={() => pickFromTheStore(data)}
                              disabled={showNonISPULocalBanner}
                            >
                              Pickup from this store
                            </Button>
                          </PickUPBtn>
                        </React.Fragment>
                      )}
                    </div>
                  </div>
                </Col>
              </PickupStoreBtnWrapper>
            </Row>
          </Grid>
        </StoreListWrapper>
        <HorizontalLine />
      </>
    ));

  return (
    <div>
      <StyledDiv>
        <FaqMarginBottom>
          <Body size='large' bold color={themeColor}>
            <DeviceWrapper>
              <PDImgMarginRight>Show only inventory available stores</PDImgMarginRight>
              <Toggle type='toggle' on={showOnlyAvailableStores} onChange={(e) => props.handleToggleChange(e)} />
            </DeviceWrapper>
          </Body>
        </FaqMarginBottom>
      </StyledDiv>
      <Body size='large' bold color={themeColor}>
        <div>
          {!storeList || storeList.length === 0 ? (
            <StoresNearYou>
              <StoreMarginTop>
                {' '}
                Inventory is not available in stores nearby the searched location, please try in a different location or
                turn-off the toggle to explore more stores
              </StoreMarginTop>
            </StoresNearYou>
          ) : (
            <StoresNearYou> Stores near you </StoresNearYou>
          )}
        </div>
      </Body>
      <HorizontalLine />
      <div>{storeList}</div>
      {!showOnlyAvailableStores && storeList && (
        <>
          <PaginationWrapper>
            <Button onClick={() => handleSelectPage(selectedPage - 1)} disabled={selectedPage === 1}>
              Previous
            </Button>
            <Button onClick={() => handleSelectPage(selectedPage + 1)} disabled={selectedPage === totalStores / 10}>
              Next
            </Button>
            {/* <PaginationWrapper>
            <Pagination
              selectedPage={selectedPage}
              selectPage={(e) => handleSelectPage(selectedPage + 1)}
              pageNumber={selectedPage}
              total={20}
            />
          </PaginationWrapper> */}
          </PaginationWrapper>
          <HorizontalLine />
        </>
      )}
    </div>
  );
}
export default StoreDetails;
