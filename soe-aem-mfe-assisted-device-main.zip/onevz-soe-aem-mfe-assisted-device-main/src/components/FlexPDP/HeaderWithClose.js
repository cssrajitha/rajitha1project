import React from 'react';
import styled from 'styled-components';

import { Icon } from '@vds/icons';
import { StyledHeaderWithClose, FlexJustify, BlackClickable } from '../CombinedGridwall/FlexGlobalStyledConstants';

const PaddingTop12 = styled.div`
  padding: 1rem 0 1rem 0;
  display: flex;
  justify-content: center;
  align-items: center;
`;
const PaddingTop4 = styled.span`
  padding: 0 1.25rem 0 1.5rem;
`;

function HeaderWithClose(props) {
  // clickEvent(e) {
  //   this.props.action(e);
  // }

  return (
    <StyledHeaderWithClose>
      <FlexJustify>
        <PaddingTop12>
          <PaddingTop4>
            <BlackClickable href={props.href ? props.href : '#'}>
              <Icon name='left-caret' size='small' medium />
            </BlackClickable>
          </PaddingTop4>

          {props.title}
        </PaddingTop12>
      </FlexJustify>
    </StyledHeaderWithClose>
  );
}
export default HeaderWithClose;
