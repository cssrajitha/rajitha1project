import { showDownPaymentOptions, addDynamicContractPrices } from './deviceinfoutils';

describe('deviceinfoutils', () => {
  describe('showDownPaymentOptions', () => {
    it('should return true when all conditions are met', () => {
      const result = showDownPaymentOptions(false, false, false, false);
      expect(result).toBe(true);
    });
    it('should return false when down payment is visible', () => {
      const result = showDownPaymentOptions(true, false, false, false);
      expect(result).toBe(false);
    });
    it('should return false when DPP indicator is true', () => {
      const result = showDownPaymentOptions(false, true, false, false);
      expect(result).toBe(false);
    });
    it('should return false when buyout is declined and toggle is off', () => {
      const result = showDownPaymentOptions(false, false, true, false);
      expect(result).toBe(false);
    });
    it('should return true when buyout is declined but toggle is on', () => {
      const result = showDownPaymentOptions(false, false, true, true);
      expect(result).toBe(true);
    });
  });
  describe('addDynamicContractPrices', () => {
    it('should add dynamic contract prices to the payment options', () => {
      const paymentOptions = [];
      addDynamicContractPrices({
        selectedSku: {
          price: {
            vvcDeviceFinancingOfferPrice: {
              originalMonthlyPrice: 33.88,
              installmentTerm: '36',
            },
            devicePaymentPrice: [
              {
                allPromotions: [
                  {
                    promoBadgeMessages: [
                      {
                        badgeText: 'Buy one, get one up to $800 off.  ',
                        badgeToolTipUrl:
                          '/us/promotion/details?promoId=promo4371691&deviceId=dev21413074&skuId=sku6033088&flow=AAL&loanTerm=36',
                        masterpageId: 'PDP',
                        pageId: 'PDP',
                        placement: 'PROMO-HEADER',
                        offerType: 'BOGO_PHONE',
                        flow: 'AAL',
                        aemOfferIds: [],
                        promoOverlayEnable: true,
                        promotionId: 'promo4371691',
                      },
                      {
                        badgeText: 'Buy one, get one up to $800 off.  ',
                        badgeToolTipUrl:
                          '/us/promotion/details?promoId=promo4371691&deviceId=dev21413074&skuId=sku6033088&flow=EUP&loanTerm=36',
                        masterpageId: 'PDP',
                        pageId: 'PDP',
                        placement: 'PROMO-HEADER',
                        offerType: 'BOGO_PHONE',
                        flow: 'EUP',
                        aemOfferIds: [],
                        promoOverlayEnable: true,
                        promotionId: 'promo4371691',
                      },
                    ],
                    discountedPrice: 11.66,
                    contractDuration: 36,
                    contractText:
                      'Monthly payments shown are for customers who qualify to pay $0 Down, $11.66/mo. for 36 months; 0% APR. Retail Price: $1219.99',
                    promoType: 'BICBOGO',
                    promotionId: 'promo4371691',
                    promoPriority: 0,
                    online: '',
                    lineRequired: '',
                    flashSale: '',
                    discAmount: 800.0,
                    discountedPricePercentage: 66.0,
                    getProductsCategory: '',
                    upto: '',
                    planReqmt: '',
                    selectPlan: '',
                    strategicBanner: '',
                    discountMonthlyPrice: 22.22,
                    selectableOffer: false,
                    defaultSelected: false,
                    redeemableOffer: false,
                    defaultDisplayFP: false,
                    isOneClickEligible: false,
                    showRecommendedPlan: false,
                  },
                  {
                    promoBadgeMessages: [
                      {
                        badgeText: 'Save $170 on a Galaxy Watch Ultra. ',
                        badgeToolTipUrl:
                          '/us/promotion/details?promoId=promo4381909&deviceId=dev21413074&skuId=sku6033088&flow=AAL&loanTerm=36',
                        masterpageId: 'PDP',
                        pageId: 'PDP',
                        placement: 'PROMO-HEADER',
                        offerType: 'BMSM_PHONE_CONNECTED',
                        flow: 'AAL',
                        aemOfferIds: [],
                        promoOverlayEnable: true,
                        promotionId: 'promo4381909',
                      },
                      {
                        badgeText: 'Save $170 on a Galaxy Watch Ultra. ',
                        badgeToolTipUrl:
                          '/us/promotion/details?promoId=promo4381909&deviceId=dev21413074&skuId=sku6033088&flow=EUP&loanTerm=36',
                        masterpageId: 'PDP',
                        pageId: 'PDP',
                        placement: 'PROMO-HEADER',
                        offerType: 'BMSM_PHONE_CONNECTED',
                        flow: 'EUP',
                        aemOfferIds: [],
                        promoOverlayEnable: true,
                        promotionId: 'promo4381909',
                      },
                    ],
                    discountedPrice: 29.16,
                    contractDuration: 36,
                    contractText:
                      'Monthly payments shown are for customers who qualify to pay $0 Down, $29.16/mo. for 36 months; 0% APR. Retail Price: $1219.99',
                    promoType: 'BICBMSM',
                    promotionId: 'promo4381909',
                    promoPriority: 0,
                    online: '',
                    lineRequired: '',
                    flashSale: '',
                    discAmount: 170.0,
                    discountedPricePercentage: 14.0,
                    getProductsCategory: '',
                    upto: '',
                    planReqmt: '',
                    selectPlan: '',
                    strategicBanner: '',
                    discountMonthlyPrice: 4.72,
                    selectableOffer: false,
                    defaultSelected: false,
                    redeemableOffer: false,
                    defaultDisplayFP: false,
                    isOneClickEligible: false,
                    showRecommendedPlan: false,
                  },
                ],
                originalPrice: 33.88,
                contractDuration: 36,
                contractText:
                  'Monthly payments shown are for customers who qualify to pay $0 Down, $33.88/mo. for 36 months; 0% APR. Retail Price: $1219.99',
                dpTermPrices: {
                  downPayment: 0,
                  downPaymentRequired: false,
                  upgradeOptionPercentage: 100,
                  upgradeOptionCode: 'DP',
                  dpTerm: 36,
                  ugradeEligibilityCategory: [],
                  firstMonthPrice: 34.19,
                  remainingMonthPrice: 35.88,
                },
              },
              {
                allPromotions: [
                  {
                    promoBadgeMessages: [
                      {
                        badgeText: 'Buy one, get one up to $800 off.  ',
                        badgeToolTipUrl:
                          '/us/promotion/details?promoId=promo4371691&deviceId=dev21413074&skuId=sku6033088&flow=AAL&loanTerm=36',
                        masterpageId: 'PDP',
                        pageId: 'PDP',
                        placement: 'PROMO-HEADER',
                        offerType: 'BOGO_PHONE',
                        flow: 'AAL',
                        aemOfferIds: [],
                        promoOverlayEnable: true,
                        promotionId: 'promo4371691',
                      },
                      {
                        badgeText: 'Buy one, get one up to $800 off.  ',
                        badgeToolTipUrl:
                          '/us/promotion/details?promoId=promo4371691&deviceId=dev21413074&skuId=sku6033088&flow=EUP&loanTerm=36',
                        masterpageId: 'PDP',
                        pageId: 'PDP',
                        placement: 'PROMO-HEADER',
                        offerType: 'BOGO_PHONE',
                        flow: 'EUP',
                        aemOfferIds: [],
                        promoOverlayEnable: true,
                        promotionId: 'promo4371691',
                      },
                    ],
                    discountedPrice: 11.66,
                    contractDuration: 36,
                    contractText:
                      'Monthly payments shown are for customers who qualify to pay $0 Down, $11.66/mo. for 36 months; 0% APR. Retail Price: $1219.99',
                    promoType: 'BICBOGO',
                    promotionId: 'promo4371691',
                    promoPriority: 0,
                    online: '',
                    lineRequired: '',
                    flashSale: '',
                    discAmount: 800.0,
                    discountedPricePercentage: 66.0,
                    getProductsCategory: '',
                    upto: '',
                    planReqmt: '',
                    selectPlan: '',
                    strategicBanner: '',
                    discountMonthlyPrice: 22.22,
                    selectableOffer: false,
                    defaultSelected: false,
                    redeemableOffer: false,
                    defaultDisplayFP: false,
                    isOneClickEligible: false,
                    showRecommendedPlan: false,
                  },
                  {
                    promoBadgeMessages: [
                      {
                        badgeText: 'Save $170 on a Galaxy Watch Ultra. ',
                        badgeToolTipUrl:
                          '/us/promotion/details?promoId=promo4381909&deviceId=dev21413074&skuId=sku6033088&flow=AAL&loanTerm=36',
                        masterpageId: 'PDP',
                        pageId: 'PDP',
                        placement: 'PROMO-HEADER',
                        offerType: 'BMSM_PHONE_CONNECTED',
                        flow: 'AAL',
                        aemOfferIds: [],
                        promoOverlayEnable: true,
                        promotionId: 'promo4381909',
                      },
                      {
                        badgeText: 'Save $170 on a Galaxy Watch Ultra. ',
                        badgeToolTipUrl:
                          '/us/promotion/details?promoId=promo4381909&deviceId=dev21413074&skuId=sku6033088&flow=EUP&loanTerm=36',
                        masterpageId: 'PDP',
                        pageId: 'PDP',
                        placement: 'PROMO-HEADER',
                        offerType: 'BMSM_PHONE_CONNECTED',
                        flow: 'EUP',
                        aemOfferIds: [],
                        promoOverlayEnable: true,
                        promotionId: 'promo4381909',
                      },
                    ],
                    discountedPrice: 29.16,
                    contractDuration: 36,
                    contractText:
                      'Monthly payments shown are for customers who qualify to pay $0 Down, $29.16/mo. for 36 months; 0% APR. Retail Price: $1219.99',
                    promoType: 'BICBMSM',
                    promotionId: 'promo4381909',
                    promoPriority: 0,
                    online: '',
                    lineRequired: '',
                    flashSale: '',
                    discAmount: 170.0,
                    discountedPricePercentage: 14.0,
                    getProductsCategory: '',
                    upto: '',
                    planReqmt: '',
                    selectPlan: '',
                    strategicBanner: '',
                    discountMonthlyPrice: 4.72,
                    selectableOffer: false,
                    defaultSelected: false,
                    redeemableOffer: false,
                    defaultDisplayFP: false,
                    isOneClickEligible: false,
                    showRecommendedPlan: false,
                  },
                ],
                originalPrice: 36.88,
                contractDuration: 30,
                contractText:
                  'Monthly payments shown are for customers who qualify to pay $0 Down, $33.88/mo. for 36 months; 0% APR. Retail Price: $1219.99',
                dpTermPrices: {
                  downPayment: 0,
                  downPaymentRequired: false,
                  upgradeOptionPercentage: 100,
                  upgradeOptionCode: 'DP',
                  dpTerm: 30,
                  ugradeEligibilityCategory: [],
                  firstMonthPrice: 37.19,
                  remainingMonthPrice: 38.88,
                },
              },
              {
                allPromotions: [
                  {
                    promoBadgeMessages: [
                      {
                        badgeText: 'Buy one, get one up to $800 off.  ',
                        badgeToolTipUrl:
                          '/us/promotion/details?promoId=promo4371691&deviceId=dev21413074&skuId=sku6033088&flow=AAL&loanTerm=36',
                        masterpageId: 'PDP',
                        pageId: 'PDP',
                        placement: 'PROMO-HEADER',
                        offerType: 'BOGO_PHONE',
                        flow: 'AAL',
                        aemOfferIds: [],
                        promoOverlayEnable: true,
                        promotionId: 'promo4371691',
                      },
                      {
                        badgeText: 'Buy one, get one up to $800 off.  ',
                        badgeToolTipUrl:
                          '/us/promotion/details?promoId=promo4371691&deviceId=dev21413074&skuId=sku6033088&flow=EUP&loanTerm=36',
                        masterpageId: 'PDP',
                        pageId: 'PDP',
                        placement: 'PROMO-HEADER',
                        offerType: 'BOGO_PHONE',
                        flow: 'EUP',
                        aemOfferIds: [],
                        promoOverlayEnable: true,
                        promotionId: 'promo4371691',
                      },
                    ],
                    discountedPrice: 11.66,
                    contractDuration: 36,
                    contractText:
                      'Monthly payments shown are for customers who qualify to pay $0 Down, $11.66/mo. for 36 months; 0% APR. Retail Price: $1219.99',
                    promoType: 'BICBOGO',
                    promotionId: 'promo4371691',
                    promoPriority: 0,
                    online: '',
                    lineRequired: '',
                    flashSale: '',
                    discAmount: 800.0,
                    discountedPricePercentage: 66.0,
                    getProductsCategory: '',
                    upto: '',
                    planReqmt: '',
                    selectPlan: '',
                    strategicBanner: '',
                    discountMonthlyPrice: 22.22,
                    selectableOffer: false,
                    defaultSelected: false,
                    redeemableOffer: false,
                    defaultDisplayFP: false,
                    isOneClickEligible: false,
                    showRecommendedPlan: false,
                  },
                  {
                    promoBadgeMessages: [
                      {
                        badgeText: 'Save $170 on a Galaxy Watch Ultra. ',
                        badgeToolTipUrl:
                          '/us/promotion/details?promoId=promo4381909&deviceId=dev21413074&skuId=sku6033088&flow=AAL&loanTerm=36',
                        masterpageId: 'PDP',
                        pageId: 'PDP',
                        placement: 'PROMO-HEADER',
                        offerType: 'BMSM_PHONE_CONNECTED',
                        flow: 'AAL',
                        aemOfferIds: [],
                        promoOverlayEnable: true,
                        promotionId: 'promo4381909',
                      },
                      {
                        badgeText: 'Save $170 on a Galaxy Watch Ultra. ',
                        badgeToolTipUrl:
                          '/us/promotion/details?promoId=promo4381909&deviceId=dev21413074&skuId=sku6033088&flow=EUP&loanTerm=36',
                        masterpageId: 'PDP',
                        pageId: 'PDP',
                        placement: 'PROMO-HEADER',
                        offerType: 'BMSM_PHONE_CONNECTED',
                        flow: 'EUP',
                        aemOfferIds: [],
                        promoOverlayEnable: true,
                        promotionId: 'promo4381909',
                      },
                    ],
                    discountedPrice: 29.16,
                    contractDuration: 36,
                    contractText:
                      'Monthly payments shown are for customers who qualify to pay $0 Down, $29.16/mo. for 36 months; 0% APR. Retail Price: $1219.99',
                    promoType: 'BICBMSM',
                    promotionId: 'promo4381909',
                    promoPriority: 0,
                    online: '',
                    lineRequired: '',
                    flashSale: '',
                    discAmount: 170.0,
                    discountedPricePercentage: 14.0,
                    getProductsCategory: '',
                    upto: '',
                    planReqmt: '',
                    selectPlan: '',
                    strategicBanner: '',
                    discountMonthlyPrice: 4.72,
                    selectableOffer: false,
                    defaultSelected: false,
                    redeemableOffer: false,
                    defaultDisplayFP: false,
                    isOneClickEligible: false,
                    showRecommendedPlan: false,
                  },
                ],
                originalPrice: 39.88,
                contractDuration: 24,
                contractText:
                  'Monthly payments shown are for customers who qualify to pay $0 Down, $33.88/mo. for 36 months; 0% APR. Retail Price: $1219.99',
                dpTermPrices: {
                  downPayment: 0,
                  downPaymentRequired: false,
                  upgradeOptionPercentage: 100,
                  upgradeOptionCode: 'DP',
                  dpTerm: 24,
                  ugradeEligibilityCategory: [],
                  firstMonthPrice: 40.19,
                  remainingMonthPrice: 41.88,
                },
              },
            ],
            oneYearPrice: {
              originalPrice: 829.99,
              contractText: 'One Year Price',
            },
            twoYearPrice: {
              originalPrice: 729.99,
              contractText: 'Two Year Price',
            },
            threeYearPrice: {
              originalPrice: 629.99,
              contractText: 'Three Year Price',
            },
            thirtyMonthPrice: {
              originalPrice: 709.99,
              contractText: 'Thirty Month Price',
            },
          },
        },
        paymentOptions,
      });
      expect(paymentOptions).toHaveLength(4);
      expect(paymentOptions[0]).toMatchObject({
        id: expect.stringMatching(/DEVICE_CONTRACT_/),
        text: expect.stringMatching(/^\$\d+(\.\d{2})?$/),
        value: expect.stringMatching(/^\$\d+(\.\d{2})?:[A-Z0-9_]+:$/),
        subtext: expect.any(String),
        name: expect.any(String),
        'data-track': expect.any(String),
      });
    });
    it('should not add any prices if no dynamic prices are found', () => {
      const paymentOptions = [];
      addDynamicContractPrices({
        selectedSku: {
          price: {},
        },
        paymentOptions,
      });
      expect(paymentOptions).toHaveLength(0);
    });
    it('should handle missing selectedSku gracefully', () => {
      const paymentOptions = [];
      addDynamicContractPrices({
        selectedSku: null,
        paymentOptions,
      });
      expect(paymentOptions).toHaveLength(0);
    });
    it('should handle missing price object gracefully', () => {
      const paymentOptions = [];
      addDynamicContractPrices({
        selectedSku: { price: null },
        paymentOptions,
      });
      expect(paymentOptions).toHaveLength(0);
    });
    it('should skip prices with missing originalPrice', () => {
      const paymentOptions = [];
      addDynamicContractPrices({
        selectedSku: {
          price: {
            oneYearPrice: {
              originalPrice: null,
              contractText: 'One Year Price',
            },
          },
        },
        paymentOptions,
      });
      expect(paymentOptions).toHaveLength(0);
    });
    it('should skip prices with missing contractText', () => {
      const paymentOptions = [];
      addDynamicContractPrices({
        selectedSku: {
          price: {
            oneYearPrice: {
              originalPrice: 499.99,
              contractText: null,
            },
          },
        },
        paymentOptions,
      });
      expect(paymentOptions).toHaveLength(0);
    });
    it('should skip prices with null dynamic price', () => {
      const paymentOptions = [];
      addDynamicContractPrices({
        selectedSku: {
          price: {
            oneYearPrice: null
          },
        },
        paymentOptions,
      });
      expect(paymentOptions).toHaveLength(0);
    });
  });
});
