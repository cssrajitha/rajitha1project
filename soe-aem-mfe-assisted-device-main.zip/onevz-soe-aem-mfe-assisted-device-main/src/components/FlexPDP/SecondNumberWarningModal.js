import React from 'react';
import { ModalBody, ModalFooter, Modal } from '@vds/modals';
import PropTypes from 'prop-types';

function SecondNumberWarningModal(props) {
  const primaryLastfourDigits = props?.activeMtn?.slice(-4);
  const secondaryLastfourDigits = props?.pairedMtn?.slice(-4);
  return (
    <Modal
      opened
      surface='light'
      fullScreenDialog={false}
      disableAnimation={false}
      disableOutsideClick={false}
      ariaLabel='Testing Modal'
      onOpenedChange={(opened) => {
        if (!opened) props.handleShopNavigation(false);
      }}
    >
      <ModalBody>
        The selected line(s) ending in {primaryLastfourDigits} are on a Second Number plan and share the same device(s)
        as the line(s) ending in {secondaryLastfourDigits}. Please select DUAL SIM device.
      </ModalBody>
      <ModalFooter
        buttonData={{
          primary: {
            children: 'Shop',
            onClick: () => props?.handleShopNavigation(true),
          },
        }}
      />
    </Modal>
  );
}

export default SecondNumberWarningModal;

SecondNumberWarningModal.propTypes = {
  handleShopNavigation: PropTypes.func,
  activeMtn: PropTypes.string,
  pairedMtn: PropTypes.string,
};
