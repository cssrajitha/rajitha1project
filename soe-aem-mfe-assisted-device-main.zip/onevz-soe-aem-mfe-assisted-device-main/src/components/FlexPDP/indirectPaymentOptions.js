import React, { memo, useEffect, useState } from 'react';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { RadioBoxGroup } from '@vds/radio-boxes';
import styled from 'styled-components';

const PaymentOptionsWrapper = styled.div`
  width: 90%;
  div::before {
    content: '';
    display: none;
  }
  label {
    padding: 0.5rem;
    color: #000000 !important;
    font-weight: 700;
  }
  & label::before {
    content: '';
    display: none;
  }
  [class^='RadioBoxLabelWrapper-'] {
    max-width: 40%;
  }
`;

function IndirectPaymentOptions(props) {
  const [selectedDefaultTerm, setSelectedDefaultTerm] = useState('');
  const {
    productDetails,
    selectPayment,
    selectedPaymentInfo,
    selectedPaymentType,
    customerProfileDetails,
    isAddEdgeUpSuccess,
    selectedSku,
    isBYODUpg,
    isBYODAAL,
    deviceFromCart,
    isIndirect,
    isDpVisible,
    setSelectedPaymentInfo,
    isFromCPE,
    // isBYOD,
    isByodUpdate,
    lineActivityTypeFromCart,
    isNewLine,
  } = props;

  let [installmentLoanStatusCheckCradle, installmentLoanStatusCheckFFlag, cradleToFFlagControllerFFlag] = getAssistedCradlePropertyV2(['installmentLoanStatusCheck','installmentLoanStatusCheckFFlag', 'cradleToFFlagControllerFFlag']);
  const installmentLoanStatusCheckVal = /true/i.test(cradleToFFlagControllerFFlag) ?  installmentLoanStatusCheckFFlag : installmentLoanStatusCheckCradle;
  const installmentLoanStatusCheck = /true/i.test(installmentLoanStatusCheckVal);

  const accountAttributes = customerProfileDetails?.customer?.billAccounts?.[0]?.accountAttributes || {};
  const { isCashOnly, isCashOnlyExceptCO } = accountAttributes;
  const indirectCashOnlyCustomer = isIndirect && isCashOnly && isCashOnlyExceptCO;
  const commonInfo = productDetails?.commonInfo;

  useEffect(() => {
    if (isIndirect && !isBYODUpg && !isBYODAAL && !deviceFromCart) {
      indirectPreSelectDP();
    }
  }, []);

  useEffect(() => {
    if (isIndirect && !isBYODUpg && !isBYODAAL && !deviceFromCart) {
      indirectPreSelectDP();
    }
  }, [selectedSku]);

  const indirectPreSelectDP = () => {
    const price = selectedSku?.price || {};
    const { devicePaymentPrice = [], preferredTerm = 0 } = price;
    const dpEligible = installmentLoanStatusCheck ? commonInfo?.dpEligible : true;
    if (preferredTerm && devicePaymentPrice?.length > 0) {
      const preferredDPTerm = devicePaymentPrice?.find((term) => term?.dpTermPrices?.dpTerm === preferredTerm);
      let sltdDefaultTerm = null;
      if (preferredDPTerm && dpEligible) {
        selectPayment(preferredDPTerm, 'DEVICE_PAYMENT', selectedSku?.selectedDevice);
      }
      devicePaymentPrice?.forEach((devicePaymentPriceItem, index) => {
        if (devicePaymentPriceItem?.contractDuration === preferredTerm && dpEligible) {
          sltdDefaultTerm = `${index}~DEVICE_PAYMENT`;
        }
      });
      if (sltdDefaultTerm) {
        setSelectedDefaultTerm(sltdDefaultTerm);
      }
    }
  };

  const getIndirectPaymentOptions = (isCashOnlyCustomer) => {
    const radioOptions = [];
    const price = selectedSku?.price || {};
    const { devicePaymentPrice = [] } = price;
    if (isByodUpdate) {
      if (!isNewLine) {
        radioOptions.push({
          name: 'indirect-payment-option',
          value: 'device-only-change~M2M',
          children: 'Device Only Change',
        });
      }
    } else if (!isByodUpdate && isFromCPE) {
      radioOptions.push({ name: 'month-to-month', value: 'month-to-month', children: 'CPE Month To Month contract' });
    } else {
      /**
       * For both UPG / AAL - Dont display DP options for Cash Only customers
       * */
      if (!isCashOnlyCustomer && (installmentLoanStatusCheck ? commonInfo?.dpEligible : true) && props?.showDPOptions) {
        devicePaymentPrice?.forEach((devicePaymentPriceItem, index) => {
          radioOptions.push({
            name: 'indirect-payment-option',
            value: `${index}~DEVICE_PAYMENT`,
            children: `${devicePaymentPriceItem.contractDuration} mo Device Payment`,
            id: 'creditRadioButton',
            disabled: !isDpVisible || (installmentLoanStatusCheck && !commonInfo?.dpEligible),
          });
        });
      }

      if (price.twoYearPrice && !isAddEdgeUpSuccess) {
        radioOptions.push({
          name: 'indirect-payment-option',
          value: 'twoYearPrice~TWO_YEAR',
          children: 'Two Years Payment',
        });
      }

      if (price.fullRetailPrice && !isAddEdgeUpSuccess) {
        radioOptions.push({
          name: 'indirect-payment-option',
          value: 'fullRetailPrice~MONTH_TO_MONTH',
          children: 'Month To Month',
        });
      }
    }
    return radioOptions;
  };

  const getIndirectSelectedPayment = () => {
    const price = selectedSku?.price || {};
    const dpEligible = installmentLoanStatusCheck ? commonInfo?.dpEligible : true;
    let selectedPaymentMode = '';
    switch (selectedPaymentInfo?.contractType) {
      case 'DEVICE_PAYMENT':
        price?.devicePaymentPrice?.forEach((devicePaymentPriceItem, index) => {
          if (devicePaymentPriceItem?.contractDuration === selectedPaymentType?.contractDuration && dpEligible) {
            selectedPaymentMode = `${index}~DEVICE_PAYMENT`;
          }
        });
        break;
      case 'TWO_YEAR':
        selectedPaymentMode = 'twoYearPrice~TWO_YEAR';
        break;
      case 'MONTH_TO_MONTH':
        selectedPaymentMode = 'fullRetailPrice~MONTH_TO_MONTH';
        break;
      case 'M2M':
        selectedPaymentMode = 'device-only-change~M2M';
        break;
      default:
        selectedPaymentMode = '';
    }

    /**
     * When Buyout is declined, select MONTH_TO_MONTH by default
     */
    // if (!selectedPaymentMode && (!isDpVisible || !dpEligible)) {
    //   selectPayment(price?.fullRetailPrice, "MONTH_TO_MONTH");
    //   selectedPaymentMode = "fullRetailPrice~MONTH_TO_MONTH"
    //   return;
    // }

    /**
     * For BYOD, select CPE month-to-month contract as the default value
     */
    if (!isByodUpdate && isFromCPE) {
      return 'month-to-month';
    }

    if (lineActivityTypeFromCart === 'EUPBYOD') {
      selectedPaymentMode = 'device-only-change~M2M';
    }

    return selectedPaymentMode;
  };

  const selectIndirectPaymentOption = (e) => {
    /* eslint-disable-next-line no-unsafe-optional-chaining */
    const [selectedPrice, selectedPlan] = e?.target?.value?.split('~');
    let price = selectedSku?.price || {};
    const parsedPrice = price?.toString()?.replace('$', '');
    const skuPrice = selectedSku?.price?.devicePaymentPrice?.filter(
      (pri) => pri?.originalPrice === parseFloat(parsedPrice),
    );
    if (typeof price === 'string') {
      price = parseFloat(price?.replace('$', ''));
    }

    let sltdPaymentType = '';
    switch (selectedPlan) {
      case 'DEVICE_PAYMENT':
        sltdPaymentType = price.devicePaymentPrice[selectedPrice];
        break;
      case 'TWO_YEAR':
        sltdPaymentType = price.twoYearPrice;
        break;
      case 'MONTH_TO_MONTH':
      case 'M2M':
        sltdPaymentType = price.fullRetailPrice;
        break;
      default:
        sltdPaymentType = '';
    }
    selectPayment(sltdPaymentType, selectedPlan);
    setSelectedPaymentInfo({
      contractType: selectedPlan,
      price,
      term: skuPrice?.[0]?.contractDuration,
      paymentType: '',
    });
  };

  const indirectSelectedPayment = isIndirect && getIndirectSelectedPayment();
  return (
    <PaymentOptionsWrapper>
      <RadioBoxGroup
        onChange={selectIndirectPaymentOption}
        value={indirectSelectedPayment || selectedDefaultTerm}
        orientation='horizontal'
        defaultValue={indirectSelectedPayment || selectedDefaultTerm}
        data={getIndirectPaymentOptions(indirectCashOnlyCustomer)}
      />
    </PaymentOptionsWrapper>
  );
}

export default memo(IndirectPaymentOptions);
