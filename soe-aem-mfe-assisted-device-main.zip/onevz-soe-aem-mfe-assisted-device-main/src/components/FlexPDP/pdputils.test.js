import * as DomService from 'onevzsoemfeframework/DomService';
import {
  getRetrieveCartInfo,
  updateModalStateCommon,
  getLineActivityType,
  checkDeviceSimCompatibility,
  initiateDeviceSimCompatibilityCheck,
  displaySimCompartibleBanner,
  getCartSimSku,
  isDfillOrderForIndirect,
  isLocalOrderForIndirect,
  isDisableShipIttoogle,
  determineBBOrderType,
  getBestBuyPricingDetails,
  getDeviceEnforApiPayload,
  isFraudRiskApiEnabledForDeviceChange,
  getAdobeSubKeyContract,
  isRefundExcahngeFlow,
  refundExchangeFlowIntent,
  hasISPUAndLocalConflict,
  shouldHideISPUToggle,
  isDropshipSku,
} from './pdputils';
import pdpCartResponse from './mocks/mockPdpCart.json';
import { DROPSHIP_PRODCODE5_ALLOWED_LIST } from './PDP_Constants';

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isIndirect: () => true,
    isIpad: () => false,
  }),
  { virtual: true }
);

describe('getRetrieveCartInfo', () => {
  it('getRetrieveCartInfo match with device cartItemType', () => {
    const props = {
      cartDetails: pdpCartResponse,
      activeMtn: '4782303946',
      cartItemType: 'DEVICE',
    };
    const output = {
      cartItemType: 'DEVICE',
      mobileNumber: '4782303946',
      deviceId: '1234',
    };
    const input = getRetrieveCartInfo(props.cartDetails, props.activeMtn, props.cartItemType);
    expect(input).toEqual(output);
  });

  it('getRetrieveCartInfo match with sim cart item type', () => {
    const props = {
      cartDetails: pdpCartResponse,
      activeMtn: '4782303946',
      cartItemType: 'SIM',
    };
    const output = {
      cartItemType: 'SIM',
      mobileNumber: '4782303946',
      eSIM: '1234',
    };
    const input = getRetrieveCartInfo(props.cartDetails, props.activeMtn, props.cartItemType);
    expect(input).toEqual(output);
  });

  it('getRetrieveCartInfo display empty object with line data', () => {
    const props = {
      cartDetails: {
        cart: {
          lineDetails: {},
        },
      },
      activeMtn: '4782303946',
      cartItemType: 'SIM',
    };
    const output = {};
    const input = getRetrieveCartInfo(props.cartDetails, props.activeMtn, props.cartItemType);
    expect(input).toEqual(output);
  });

  it('getRetrieveCartInfo match with device cartItemType', () => {
    const props = {
      cartDetails: pdpCartResponse,
      activeMtn: '4782303946',
      cartItemType: 'DEVICE',
    };
    const output = {
      cartItemType: 'DEVICE',
      mobileNumber: '4782303946',
      deviceId: '1234',
    };
    const input = getRetrieveCartInfo(props.cartDetails, props.activeMtn, props.cartItemType);
    expect(input).toEqual(output);
  });

  it('getRetrieveCartInfo match with sim cart item type', () => {
    const props = {
      cartDetails: {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                mobileNumber: '4782303946',
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: [
                        {
                          cartItemType: 'SIM',
                        },
                      ],
                    },
                  },
                ],
              },
            ],
          },
        },
      },
      activeMtn: '4782303946',
      cartItemType: 'SIM',
    };
    const output = {};
    const input = getRetrieveCartInfo(props.cartDetails, props.activeMtn, props.cartItemType);
    expect(input).toEqual(output);
  });
  it('getRetrieveCartInfo match with sim cart item type', () => {
    const props = {
      cartDetails: {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                mobileNumber: '4782303946',
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: [
                        {
                          cartItemType: 'DEVICE',
                          eSIM: '1234',
                        },
                      ],
                    },
                  },
                ],
              },
            ],
          },
        },
      },
      activeMtn: '4782303946',
      cartItemType: 'DEVICE',
    };
    const output = {};
    const input = getRetrieveCartInfo(props.cartDetails, props.activeMtn, props.cartItemType);
    expect(input).toEqual(output);
  });
});

describe('updateModalStateCommon', () => {
  let originalVzdl;
  const onCloseMock = jest.fn();
  const sendCustomEventMock = jest.fn();

  beforeEach(() => {
    originalVzdl = window.vzdl;
    window.vzdl = {};
    window.sendCustomEvent = sendCustomEventMock;
    onCloseMock.mockClear();
    sendCustomEventMock.mockClear();
  });

  afterEach(() => {
    window.vzdl = originalVzdl;
  });

  test('should clear event value if event exists', () => {
    window.vzdl.event = { value: 'someValue' };
    updateModalStateCommon(true, onCloseMock);
    expect(window.vzdl.event.value).toBe('');
  });

  test('should clear event value if event exists', () => {
    window.vzdl.page = {
      detail: '',
    };
    updateModalStateCommon(true, onCloseMock);
    expect(window.vzdl.page.detail).toBe('Plan Incompatible');
  });
  test('should handle closed state correctly', () => {
    window.vzdl = {};
    updateModalStateCommon(false, onCloseMock);
    expect(onCloseMock).toHaveBeenCalled();
  });
  test('should handle closed state correctly', () => {
    window.vzdl.page = {};
    updateModalStateCommon(false, onCloseMock);
    expect(onCloseMock).toHaveBeenCalled();
    expect(window.vzdl.page.detail).toBe('Product-detail');
  });
  test('should initialize vzdl if not defined', () => {
    window.vzdl = undefined;
    updateModalStateCommon(true, onCloseMock);
    expect(window.vzdl).toBeDefined();
  });
});

describe('getLineActivityType', () => {
  const cart = {
    lineDetails: {
      lineInfo: [
        {
          mobileNumber: '4782303946',
          lineActivityType: 'ACT',
        },
        {
          mobileNumber: '1234567890',
          lineActivityType: 'SUS',
        },
      ],
    },
  };

  it('should return the line activity type for the given activeMtn', () => {
    const activeMtn = '4782303946';
    const intendType = getLineActivityType(cart, activeMtn);
    expect(intendType).toBe('ACT');
  });

  it('should return "EUP" when line activity type is not found for the given activeMtn', () => {
    const activeMtn = '9876543210';
    const intendType = getLineActivityType(cart, activeMtn);
    expect(intendType).toBe('EUP');
  });

  it('should return "EUP" when line activity type is not found for the given activeMtn', () => {
    const intendType = getLineActivityType();
    expect(intendType).toBe('EUP');
  });
});

describe('initiateDeviceSimCompatibilityCheck', () => {
  it('should call validateDeviceSimIdRequest if all conditions are met EUP', () => {
    const reqData = {
      isIndirect: true,
      intendType: 'EUP',
      isByodUpdate: true,
      deviceInfo: {},
      previousPayload: {
        data: {
          lines: [
            {
              device: {
                sim: {
                  CurrentSimid: null,
                },
              },
            },
          ],
        },
      },
      payload: {
        mtn: '1234567890',
        deviceId: 'device-123',
        simId: 'sim-123',
        isCustomerProvidedEquipment: false,
      },
      validateDeviceSimIdRequest: jest.fn(),
    };

    initiateDeviceSimCompatibilityCheck(reqData);

    expect(reqData.validateDeviceSimIdRequest).toHaveBeenCalledWith({
      mtn: '1234567890',
      deviceId: 'device-123',
      simId: 'sim-123',
      cpSimCard: false,
      fromCpe: true,
      isCustomerProvidedEquipment: false,
      deviceFlow: true,
      isDWOS: false,
      sendSimFromLanding: true,
    });
  });

  it('should call validateDeviceSimIdRequest if all conditions are met isByodUpdate', () => {
    const reqData = {
      isIndirect: true,
      intendType: 'BYOD',
      isByodUpdate: true,
      deviceInfo: {},
      previousPayload: {
        data: {
          lines: [
            {
              device: {
                sim: {
                  CurrentSimid: null,
                },
              },
            },
          ],
        },
      },
      payload: {
        mtn: '1234567890',
        deviceId: 'device-123',
        simId: 'sim-123',
        isCustomerProvidedEquipment: false,
      },
      validateDeviceSimIdRequest: jest.fn(),
    };

    initiateDeviceSimCompatibilityCheck(reqData);

    expect(reqData.validateDeviceSimIdRequest).toHaveBeenCalledWith({
      mtn: '1234567890',
      deviceId: 'device-123',
      simId: 'sim-123',
      cpSimCard: false,
      fromCpe: true,
      isCustomerProvidedEquipment: false,
      deviceFlow: true,
      isDWOS: false,
      sendSimFromLanding: true,
    });
  });

  it('should not call validateDeviceSimIdRequest if all conditions are not met', () => {
    const reqData = {
      isIndirect: false,
      intendType: 'BYOD',
      isByodUpdate: true,
      deviceInfo: {},
      previousPayload: {
        data: {
          lines: [
            {
              device: {
                sim: {
                  CurrentSimid: null,
                },
              },
            },
          ],
        },
      },
      payload: {
        mtn: '1234567890',
        deviceId: 'device-123',
        simId: 'sim-123',
        isCustomerProvidedEquipment: false,
      },
      validateDeviceSimIdRequest: jest.fn(),
    };

    initiateDeviceSimCompatibilityCheck(reqData);
  });

  it('should not call validateDeviceSimIdRequest if intentType is EUP and simClass4G is NP', () => {
    const reqData = {
      isIndirect: true,
      intendType: 'EUP',
      isByodUpdate: true,
      deviceInfo: {
        simClass4G: 'NP',
      },
      previousPayload: {
        data: {
          lines: [
            {
              device: {
                sim: {
                  CurrentSimid: null,
                },
              },
            },
          ],
        },
      },
      payload: {
        mtn: '1234567890',
        deviceId: 'device-123',
        simId: 'sim-123',
        isCustomerProvidedEquipment: false,
      },
      validateDeviceSimIdRequest: jest.fn(),
    };

    initiateDeviceSimCompatibilityCheck(reqData);

    expect(reqData.validateDeviceSimIdRequest).not.toHaveBeenCalled();
  });

  it('return nothing if there is any axception in the function', () => {
    initiateDeviceSimCompatibilityCheck();
  });
  // Add more test cases for different scenarios
});

// Added targeted coverage for getDeviceEnforApiPayload lines 344-350
describe('getDeviceEnforApiPayload lines 344-350 coverage', () => {
  const baseCustomerInfo = {
    customerId: '12345',
    billAccounts: [{ billAccountNo: '987654321' }],
    lookupMtn: '123-456-7890',
    customerAttributes: { customerType: 'PE', hasEcpd: '0000000000' },
    loggedInUser: 'tester',
  };
  const baseEquipmentInfo = {
    deviceInfo: { deviceId: 'IMEI-ABC', deviceSku: 'SKU-1' },
    simInfo: { simId: 'ICCID-OLD' },
  };

  it('SIM_AND_DEVICE_CHANGE: sets newIccid when different and newImei from mfeImei', () => {
    const payload = getDeviceEnforApiPayload({
      mfeIccid: 'ICCID-NEW',
      mfeImei: 'IMEI-NEW',
      customerInfo: baseCustomerInfo,
      equipmentInfo: baseEquipmentInfo,
      locationCd: 'LOC1',
      simSwapNotify: 'y',
    });
    expect(payload.transactionType).toBe('SIM_AND_DEVICE_CHANGE');
    expect(payload.newIccid).toBe('ICCID-NEW');
    expect(payload.newImei).toBe('IMEI-NEW');
    expect(payload.mdn).toBe('1234567890');
    expect(payload.custId).toBe('0000012345');
    expect(payload.acctNum).toBe('987654321');
  });

  it('SIM_ONLY_CHANGE: clears newIccid when same and uses deviceId as newImei when flag enabled', () => {
    const originalWindowMfe = window.mfe;
    window.mfe = { simOnlyChgFixFlag: true };

    const payload = getDeviceEnforApiPayload({
      mfeIccid: 'ICCID-OLD',
      mfeImei: 'IMEI-ABC',
      customerInfo: baseCustomerInfo,
      equipmentInfo: baseEquipmentInfo,
      locationCd: 'LOC2',
      simSwapNotify: 'n',
    });

    expect(payload.transactionType).toBe('SIM_ONLY_CHANGE');
    expect(payload.newIccid).toBe('');
    expect(payload.newImei).toBe('IMEI-ABC');

    window.mfe = originalWindowMfe;
  });
});

describe('checkDeviceSimCompatibility', () => {
  it('should return true when all conditions are met', () => {
    const reqData = {
      isIndirect: true,
      intendType: 'EUP',
      isByodUpdate: true,
      deviceInfo: {},
      previousPayload: {
        data: {
          lines: [
            {
              device: {
                sim: {
                  CurrentSimid: null,
                },
              },
            },
          ],
        },
      },
    };

    const result = checkDeviceSimCompatibility(reqData);

    expect(result).toBe(true);
  });

  it('should return true when all conditions are isByodUpdate', () => {
    const reqData = {
      isIndirect: true,
      intendType: 'BYOD',
      isByodUpdate: true,
      deviceInfo: {},
      previousPayload: {
        data: {
          lines: [
            {
              device: {
                sim: {
                  CurrentSimid: null,
                },
              },
            },
          ],
        },
      },
    };

    const result = checkDeviceSimCompatibility(reqData);
    expect(result).toBe(true);
  });

  it('should return false for simClass4G devices', () => {
    const reqData = {
      isIndirect: true,
      intendType: 'EUP',
      isByodUpdate: true,
      deviceInfo: {
        simClass4G: 'NP',
      },
      previousPayload: {
        data: {
          lines: [
            {
              device: {
                sim: {
                  CurrentSimid: null,
                },
              },
            },
          ],
        },
      },
    };

    const result = checkDeviceSimCompatibility(reqData);
    expect(result).toBe(false);
  });

  it('should return false when any acception met', () => {
    const result = checkDeviceSimCompatibility();
    expect(result).toBe(false);
  });
});

describe('displaySimCompartibleBanner', () => {
  let deviceInfo;
  let validateDeviceSimRequest;
  let dispatch;

  beforeEach(() => {
    deviceInfo = {};
    validateDeviceSimRequest = {};
    dispatch = jest.fn();
    jest.mock('onevzsoemfecommon/AppMessageActions', () => ({
      addAppMessage: jest.fn(),
    }));
  });

  afterEach(() => {
    jest.resetAllMocks();
  });

  it('should dispatch addAppMessage with success message when deviceSimCompatible is "Y" and currentSimId is not empty and simId is empty', () => {
    deviceInfo.deviceSimCompatible = 'Y';
    validateDeviceSimRequest.data = {
      lines: [
        {
          device: {
            sim: {
              CurrentSimid: 'currentSimIdValue',
              id: '',
            },
          },
        },
      ],
    };

    displaySimCompartibleBanner(deviceInfo, validateDeviceSimRequest, dispatch);
    expect(dispatch).toHaveBeenCalledTimes(1);
  });

  it('should dispatch addAppMessage with error message when deviceSimCompatible is "N" and simInfo.iccid is not empty', () => {
    deviceInfo.deviceSimCompatible = 'N';
    deviceInfo.simInfo = {
      iccid: 'iccidValue',
    };

    displaySimCompartibleBanner(deviceInfo, validateDeviceSimRequest, dispatch);
    expect(dispatch).toHaveBeenCalledTimes(1);
  });

  it('should not dispatch addAppMessage when deviceSimCompatible is "Y" but currentSimId is empty', () => {
    deviceInfo.deviceSimCompatible = 'Y';
    validateDeviceSimRequest.data = {
      lines: [
        {
          device: {
            sim: {
              CurrentSimid: '',
              id: '',
            },
          },
        },
      ],
    };

    displaySimCompartibleBanner(deviceInfo, validateDeviceSimRequest, dispatch);
  });

  it('should not dispatch addAppMessage when deviceSimCompatible is "Y" but simId is not empty', () => {
    deviceInfo.deviceSimCompatible = 'Y';
    validateDeviceSimRequest.data = {
      lines: [
        {
          device: {
            sim: {
              CurrentSimid: 'currentSimIdValue',
              id: 'simIdValue',
            },
          },
        },
      ],
    };

    displaySimCompartibleBanner(deviceInfo, validateDeviceSimRequest, dispatch);
  });

  it('should not dispatch addAppMessage when deviceSimCompatible is "N" and simInfo.iccid is empty', () => {
    deviceInfo.deviceSimCompatible = 'N';
    deviceInfo.simInfo = {
      iccid: '',
    };

    displaySimCompartibleBanner(deviceInfo, validateDeviceSimRequest, dispatch);
  });
});

describe('determineBBOrderType', () => {
  // Test case 1: Should return isBBYLocalOrder as true
  test('should return isBBYLocalOrder true when isLocalBBYLocal is true and conditions match', () => {
    const isLocalBBYLocal = 'true';
    const isIndirect = jest.fn(() => true);
    const cartDetails = {
      cart: {
        cartHeader: {
          locationSubType: 'GN',
          maid: 'BBX',
        },
      },
    };

    const result = determineBBOrderType(isLocalBBYLocal, cartDetails, isIndirect);
    expect(result).toEqual({
      isBBYLocalOrder: true,
      isBBYDfillOrder: false,
    });
  });

  // Test case 2: Should return isBBYDfillOrder as true
  test('should return isBBYDfillOrder true when isLocalBBYLocal is null and conditions match', () => {
    const isLocalBBYLocal = null;
    const isIndirect = jest.fn(() => true);
    const cartDetails = {
      cart: {
        cartHeader: {
          locationSubType: 'GN',
          maid: 'BBX',
        },
      },
    };

    const result = determineBBOrderType(isLocalBBYLocal, cartDetails, isIndirect);
    expect(result).toEqual({
      isBBYLocalOrder: false,
      isBBYDfillOrder: true,
    });
  });

  // Test case 3: Should return both flags as false when locationSubType doesn't match
  test('should return both flags as false when locationSubType does not match', () => {
    const isLocalBBYLocal = 'true';
    const isIndirect = jest.fn(() => true);

    const cartDetails = {
      cart: {
        cartHeader: {
          locationSubType: 'XX', // Different locationSubType
          maid: 'BBX',
        },
      },
    };

    const result = determineBBOrderType(isLocalBBYLocal, cartDetails, isIndirect);
    expect(result).toEqual({
      isBBYLocalOrder: false,
      isBBYDfillOrder: false,
    });
  });

  // Test case 4: Should return both flags as false when maid doesn't match
  test('should return both flags as false when maid does not match', () => {
    const isLocalBBYLocal = 'true';
    const isIndirect = jest.fn(() => true);

    const cartDetails = {
      cart: {
        cartHeader: {
          locationSubType: 'GN',
          maid: 'XXX', // Different maid
        },
      },
    };

    const result = determineBBOrderType(isLocalBBYLocal, cartDetails, isIndirect);
    expect(result).toEqual({
      isBBYLocalOrder: false,
      isBBYDfillOrder: false,
    });
  });

  // Test case 5: Should handle undefined/null cartDetails
  test('should handle undefined/null cartDetails', () => {
    const isLocalBBYLocal = 'true';
    const isIndirect = jest.fn(() => true);

    const cartDetails = null;

    const result = determineBBOrderType(isLocalBBYLocal, cartDetails, isIndirect);
    expect(result).toEqual({
      isBBYLocalOrder: false,
      isBBYDfillOrder: false,
    });
  });

  // Test case 6: Should handle missing cart header properties
  test('should handle missing cart header properties', () => {
    const isLocalBBYLocal = 'true';
    const isIndirect = jest.fn(() => true);

    const cartDetails = {
      cart: {
        cartHeader: {}, // Empty cart header
      },
    };

    const result = determineBBOrderType(isLocalBBYLocal, cartDetails, isIndirect);
    expect(result).toEqual({
      isBBYLocalOrder: false,
      isBBYDfillOrder: false,
    });
  });

  // Test case 7: Should handle different isLocalBBYLocal values
  test('should handle different isLocalBBYLocal values', () => {
    const cartDetails = {
      cart: {
        cartHeader: {
          locationSubType: 'GN',
          maid: 'BBX',
        },
      },
    };

    // Test with 'false' string
    expect(determineBBOrderType('false', cartDetails)).toEqual({
      isBBYLocalOrder: false,
      isBBYDfillOrder: false,
    });

    // Test with empty string
    expect(determineBBOrderType('', cartDetails)).toEqual({
      isBBYLocalOrder: false,
      isBBYDfillOrder: false,
    });

    // Test with undefined
    expect(determineBBOrderType(undefined, cartDetails)).toEqual({
      isBBYLocalOrder: false,
      isBBYDfillOrder: false,
    });
  });

  // Test case 8: Should return isBBYLocalOrder true when bestBuyISPUEnableLocalOrderFFlag is true and isIndirect() returns true
  test('should return isBBYLocalOrder true when bestBuyISPUEnableLocalOrderFFlag is true, conditions match, and isIndirect() is true', () => {
    // Mock sessionStorage to return bestBuyISPUEnableLocalOrderFFlag as true
    const mockAppProperties = { bestBuyISPUEnableLocalOrderFFlag: 'true' };
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify(mockAppProperties));

    const isLocalBBYLocal = 'false'; // Not using the first condition
    const cartDetails = {
      cart: {
        cartHeader: {
          locationSubType: 'GN',
          maid: 'BBX',
        },
      },
    };

    const result = determineBBOrderType(isLocalBBYLocal, cartDetails);
    expect(result).toEqual({
      isBBYLocalOrder: true,
      isBBYDfillOrder: false,
    });

    // Clean up
    sessionStorage.clear();
  });

  // Test case 9: Should return isBBYLocalOrder false when bestBuyISPUEnableLocalOrderFFlag is false even with other conditions true
  test('should return isBBYLocalOrder false when bestBuyISPUEnableLocalOrderFFlag is false', () => {
    // Mock sessionStorage to return bestBuyISPUEnableLocalOrderFFlag as false
    const mockAppProperties = { bestBuyISPUEnableLocalOrderFFlag: 'false' };
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify(mockAppProperties));

    const isLocalBBYLocal = 'false';
    const cartDetails = {
      cart: {
        cartHeader: {
          locationSubType: 'GN',
          maid: 'BBX',
        },
      },
    };

    const result = determineBBOrderType(isLocalBBYLocal, cartDetails);
    expect(result).toEqual({
      isBBYLocalOrder: false,
      isBBYDfillOrder: false,
    });

    // Clean up
    sessionStorage.clear();
  });

  // Test case 10: Should return isBBYLocalOrder false when bestBuyISPUEnableLocalOrderFFlag is true but locationSubType doesn't match
  test('should return isBBYLocalOrder false when bestBuyISPUEnableLocalOrderFFlag is true but locationSubType does not match', () => {
    // Mock sessionStorage to return bestBuyISPUEnableLocalOrderFFlag as true
    const mockAppProperties = { bestBuyISPUEnableLocalOrderFFlag: 'true' };
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify(mockAppProperties));

    const isLocalBBYLocal = 'false';
    const cartDetails = {
      cart: {
        cartHeader: {
          locationSubType: 'XX', // Different locationSubType
          maid: 'BBX',
        },
      },
    };

    const result = determineBBOrderType(isLocalBBYLocal, cartDetails);
    expect(result).toEqual({
      isBBYLocalOrder: false,
      isBBYDfillOrder: false,
    });

    // Clean up
    sessionStorage.clear();
  });

  // Test case 11: Should return isBBYLocalOrder false when bestBuyISPUEnableLocalOrderFFlag is true but maidCode doesn't match
  test('should return isBBYLocalOrder false when bestBuyISPUEnableLocalOrderFFlag is true but maidCode does not match', () => {
    // Mock sessionStorage to return bestBuyISPUEnableLocalOrderFFlag as true
    const mockAppProperties = { bestBuyISPUEnableLocalOrderFFlag: 'true' };
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify(mockAppProperties));

    const isLocalBBYLocal = 'false';
    const cartDetails = {
      cart: {
        cartHeader: {
          locationSubType: 'GN',
          maid: 'XXX', // Different maidCode
        },
      },
    };

    const result = determineBBOrderType(isLocalBBYLocal, cartDetails);
    expect(result).toEqual({
      isBBYLocalOrder: false,
      isBBYDfillOrder: false,
    });

    // Clean up
    sessionStorage.clear();
  });

  // Test case 12: Should handle undefined APP_PROPERTIES in sessionStorage
  test('should handle undefined APP_PROPERTIES in sessionStorage', () => {
    // Clear sessionStorage to simulate undefined APP_PROPERTIES
    sessionStorage.clear();

    const isLocalBBYLocal = 'false';
    const cartDetails = {
      cart: {
        cartHeader: {
          locationSubType: 'GN',
          maid: 'BBX',
        },
      },
    };

    const result = determineBBOrderType(isLocalBBYLocal, cartDetails);
    expect(result).toEqual({
      isBBYLocalOrder: false,
      isBBYDfillOrder: false,
    });
  });

  // Test case 13: Should return isBBYLocalOrder true when both conditions are satisfied (first condition takes precedence)
  test('should return isBBYLocalOrder true when both first and second conditions are satisfied', () => {
    // Mock sessionStorage to return bestBuyISPUEnableLocalOrderFFlag as true
    const mockAppProperties = { bestBuyISPUEnableLocalOrderFFlag: 'true' };
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify(mockAppProperties));

    const isLocalBBYLocal = 'true'; // First condition is also true
    const cartDetails = {
      cart: {
        cartHeader: {
          locationSubType: 'GN',
          maid: 'BBX',
        },
      },
    };

    const result = determineBBOrderType(isLocalBBYLocal, cartDetails);
    expect(result).toEqual({
      isBBYLocalOrder: true,
      isBBYDfillOrder: false,
    });

    // Clean up
    sessionStorage.clear();
  });
});

// Test case 1: simFromFilteredCartLine has itemCode
test('getCartSimSku should return the itemCode when simFromFilteredCartLine has itemCode', () => {
  // Arrange
  const simFromFilteredCartLine = { itemCode: 'ABC123', eSIM: false };

  // Act
  const result = getCartSimSku(simFromFilteredCartLine);

  // Assert
  expect(result).toBe('ABC123');
});

// Test case 2: simFromFilteredCartLine has eSIM
test('getCartSimSku should return an empty string when simFromFilteredCartLine has eSIM', () => {
  // Arrange
  const simFromFilteredCartLine = { itemCode: 'ABC123', eSIM: true };

  // Act
  const result = getCartSimSku(simFromFilteredCartLine);

  // Assert
  expect(result).toBe('');
});

// Test case 3: simFromFilteredCartLine is undefined
test('getCartSimSku should return undefined when simFromFilteredCartLine is undefined', () => {
  // Arrange
  const simFromFilteredCartLine = undefined;

  // Act
  const result = getCartSimSku(simFromFilteredCartLine);

  // Assert
  expect(result).toBeUndefined();
});

describe('isLocalOrderForIndirect', () => {
  it('should return true when isIndirect is true and all other conditions are false', () => {
    const result = isLocalOrderForIndirect(false, false, false, false);
    expect(result).toBe(true);
  });

  it('should return false when isFullFillment is true', () => {
    const result = isLocalOrderForIndirect(true, false, false, false);
    expect(result).toBe(false);
  });

  it('should return false when isBackOrder is true', () => {
    const result = isLocalOrderForIndirect(false, true, false, false);
    expect(result).toBe(false);
  });

  it('should return false when isPreOrder is true', () => {
    const result = isLocalOrderForIndirect(false, false, true, false);
    expect(result).toBe(false);
  });

  it('should return true when scanned from gridwall irrespective of first line type i,e dfill or local', () => {
    const result = isLocalOrderForIndirect(true, false, true, true);
    expect(result).toBe(true);
  });

  it('should return true when scanned from gridwall and is a back order', () => {
    const result = isLocalOrderForIndirect(false, true, false, true);
    expect(result).toBe(true);
  });
});

describe('isDfillOrderForIndirect', () => {
  it('should return true when isIndirect is true, isFullFillment is true, and dFillInventoryQty is true', () => {
    const result = isDfillOrderForIndirect(true, true);
    expect(result).toBe(true);
  });

  it('should return false when dFillInventoryQty is false', () => {
    const result = isDfillOrderForIndirect(true, false);
    expect(result).toBe(false);
  });
});

describe('isDisableShipIttoogle & getDeviceEnforApiPayload', () => {
  it('should return true when channel is indirect and a preorder', () => {
    const isPreOrder = true;
    const result = isDisableShipIttoogle(isPreOrder);
    expect(result).toBe(true);
  });

  it('should return false when channel is indirect and not a preorder', () => {
    const isPreOrder = false;
    const result = isDisableShipIttoogle(isPreOrder);
    expect(result).toBe(false);
  });
  it('getDeviceEnforApiPayload  should return payload', () => {
    const payload = getDeviceEnforApiPayload({
      locationCd: '',
      mfeIccid: '123',
      mfeImei: '456',
      ctiUser: {},
      customerInfo: {
        caseId: 'SOP-17646952-C01',
        cartId: '10ced43c-bff7-4e7d-9acd-ea40f362c6ca',
        availablePaths: [],
        customerId: '787408248',
        customerHash: '6c668a826627c68d1f133de42e3b9961f479da08b6c9f8eb1681a482767b697a',
        contactAddress: { state: 'CA' },
        customerName: {
          firstName: '',
          lastName: 'SMITH',
          businessName: '',
          preferFirstName: '',
          preferLastName: '',
          preferPronoun: '',
        },
        address: {
          addressLine1: '2345 NEWPORT BLVD APT G204',
          addressLine2: '',
          city: 'COSTA MESA',
          state: 'CA',
          zipCode: '92627',
          fipsCode: '0605916532',
          geoCode: 'USA06059165320',
          zipCodePlus4: '1833',
          scrubbedAddress: {
            streetName: 'NEWPORT',
            streetNumber: '2345',
            streetType: 'BLVD',
            streetDirection: '',
            apartmentNo: 'G204',
            pobox: '',
            ruralDeliveryNo: '',
            ruralRouteNo: '',
            city: 'COSTA MESA',
            state: 'CA',
            zipCode: '92627',
            zipCodePlus4: '6527',
          },
        },
        email: 'NZIRZ8780@VZW.COM',
        lookupMtn: '5104689682',
        billingSystem: 'VISION_NORTH',
        customerAttributes: {
          hasEcpd: 'false',
          autoPayDiscountEligibleCustomerType: true,
          customerType: 'PE',
          associationIdNo: null,
        },
        billAccounts: [
          {
            billAccountNo: '1',
            recommendation: {
              recommendedPlan: {
                usageInfo: { accountUsageInfo: { dataUsageInfos: [] } },
                unbilledAccountUsageInfo: {
                  totalData: null,
                  unitOfMeasure: null,
                  usageType: null,
                  dataAllowance: null,
                },
              },
            },
            billCycle: { billCycleDate: '12/12/2024', remainingDays: '0', nextBillCycleAutoRedeemPaymentDate: null },
            programEligibility: {
              programEligible: false,
              spendingLimitAmount: '7000.00',
              BTALimitAmount: '750.00',
              RemainingBTAAmount: '750.00',
              RemainingSpendingLimitAmount: '0',
            },
            sharePlan: { planId: null, description: null, chargeAmount: null, planImageUrl: null },
            accountOffers: { productOffers: [] },
            accountLevelChangeEligibility: {
              isAddNewLineAllowed: true,
              isBundleChangeAllowed: true,
              isSharePlanChangeAllowed: true,
              pendingOrderDetail: null,
            },
            paymentInfo: {
              arPastDueBalance: '377.71',
              currentBalance: '0.00',
              isBalancePastDue: true,
              pastDueBalance: '0.00',
              invoiceDate: '09/12/2024',
              isAutoPayEnrolled: true,
              isPaperFreeEnrolled: true,
              recentActivityAmount: '0.00',
              outstandingBalance: null,
              vzWalletInfo: {
                eligibleToUseVzDollar: null,
                maximumPropositionAmount: null,
                minimumPropositionAmount: null,
                vzDollarsBalance: null,
              },
              vzdAutoRedeemDetails: {
                vzdAutoRedeemEnrolled: null,
                vzdAutoRedeemAmount: null,
                vzdAutoRedeemFullBillAmount: null,
                vzdAutoRedeemEnrollDate: null,
              },
              lastVzdollarsAutoRedeemAmt: null,
              lastVzdollarsAutoRedeemPaymentDate: null,
              lastVzPmtDate: null,
              currentBCVzdollarsRedeemAmt: null,
            },
            accountAttributes: {
              isAutoPayWithPaperless: true,
              mixedPlanCategories: true,
              isOverThreshHold: false,
              isCashOnly: false,
              isCashOnlyExceptCA: false,
              isCashOnlyExceptCC: false,
              isCashOnlyExceptCO: false,
              fraudInfo: { fraud_X: false, fraud_Y: false },
              isMyVerizonEnrolled: true,
            },
            mtns: [
              {
                mtn: '5104689682',
                lineLevelServiceOffers: [],
                numberShare: null,
                mtnHashCode: '3d9b7bbcee0558204fafaf5f61d456562483fe97b0653ab8480e7989db10685b',
                nickName: 'LUKE IPHONE 15 PROMA 9682',
                benefitPair: {
                  pairedPhoneMtn: '5106028996',
                  eligibleToPair: false,
                  existingPair: false,
                  grantee: false,
                  grantor: false,
                },
                primaryUser: {
                  firstName: 'KYLE',
                  lastName: 'SMITH',
                  preferFirstName: null,
                  preferLastName: null,
                  preferPronoun: null,
                },
                primaryAddress: {
                  addressLine1: '2345 NEWPORT BLVD APT E108',
                  city: 'COSTA MESA',
                  state: 'CA',
                  zipCode: '92627',
                  countryCode: 'USA',
                },
                mtnStatus: {
                  isActive: true,
                  isDisconnected: false,
                  isReassignedAndInActive: false,
                  isSuspendedWithBilling: false,
                  isSuspendedWithoutBilling: false,
                  mtnSuspendAllowed: false,
                  isMtnSuspended: false,
                  mtnStatusReasonCode: '',
                  isMtnChanged: null,
                  isReassigned: null,
                  isTransfered: false,
                  isMtnNotEditable: false,
                  status: 'A',
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      deviceId: '356371486088359',
                      deviceSku: 'IPHONE15PROM-US-2',
                      deviceUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/DU-fallback-smartphone-03152023',
                      productDisplayName: 'iPhone 15 Pro Max NON VZW NA-2',
                      category: {
                        smartphone: true,
                        tablet: false,
                        basicphone: false,
                        connectedDevice: false,
                        internetDevice: false,
                        homePC: false,
                        telematics: false,
                        virtualDevice: false,
                        WSOnly: false,
                      },
                      tradeInValue: '',
                      displayName: 'IPHONE15 PROMAX GENERIC US-2',
                      capacity: null,
                      deviceType: {
                        backupRouter4G: null,
                        device4G: null,
                        device3G: null,
                        device5GA: false,
                        device5GE: true,
                        antenna5G: false,
                        home5G: false,
                        deviceType: '5GE',
                        home4GLte: false,
                      },
                      numberShareCapability: null,
                      cdmaRestrictedDevice: false,
                      fixedWirelessInfos: null,
                      pairedDeviceDetails: null,
                      router: false,
                      prodClass1: null,
                      multiMeterWave: false,
                      n77Band: null,
                      fwaDeviceCurrentStatus: null,
                      noOfDaysDeviceActiveInAccountFromToday: null,
                    },
                    simInfo: { simId: '89148000009710862519', simSku: 'UNIVESIM5G-SAB-S', skuType: null },
                  },
                ],
                pricePlanInfo: {
                  planId: '50432',
                  description: '5G DO MORE',
                  planDisplayName: null,
                  planImageUrl: null,
                  planCategoryName: 'UNLIMITED FOR ALL',
                  planCategoryCd: '67',
                  effectiveDate: null,
                  noOfDaysLeft: null,
                  trialEndDate: null,
                  planAttributes: {
                    sharePlan: false,
                    isJax: false,
                    isFelix: false,
                    hasStandardPlan: true,
                    hasSecondNumPlan: false,
                  },
                  accessCharge: null,
                  imageUrlMap: null,
                  planPromotions: null,
                  pearlTrialFlow: false,
                  suspendPearlEnabledFFlag: false,
                  trialEndDateOrThirtyDays: null,
                  trialEndDateOrFortyFiveDays: null,
                },
                currentSPOs: null,
                currentFeatures: [
                  {
                    sfoId: '48526',
                    description: 'TXT MSG W PER MSG CHARGES',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '48553',
                    description: 'STREAMLINED BILLING - $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68869',
                    description: 'CALLER ID',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68870',
                    description: 'BUSY TRANSFER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68871',
                    description: 'CONFERENCE CALLING',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/3way_Calling_012918',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68872',
                    description: 'CALL DELIVERY',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68873',
                    description: 'CALL WAITING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68874',
                    description: 'NO ANSWER TRANSFER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68876',
                    description: 'CALL FORWARDING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '73502',
                    description: 'UNL PICTURE/VIDEO MSG',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'MM' }],
                    existing: false,
                  },
                  {
                    sfoId: '73503',
                    description: 'UNL TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'SMALIN' }, { featureTypeCode: 'SMAL' }],
                    existing: false,
                  },
                  {
                    sfoId: '75706',
                    description: 'TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75802',
                    description: 'DYNAMIC-PRIVATE IP',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75836',
                    description: '4G INTERNET ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75837',
                    description: '4G APPLICATION ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '76404',
                    description: 'MOBILE HOTSPOT 4G PROVISIONING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '76600',
                    description: 'SHARE NAME ID $0.00',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Caller_ID_012918',
                    embeddedFeatures: [{ featureTypeCode: 'SEUN' }],
                    existing: false,
                  },
                  {
                    sfoId: '77556',
                    description: '4G PROVISIONING $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '77568',
                    description: 'EMAIL ACCESS PDA $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '79708',
                    description: 'VISUAL VOICEMAIL SPEC',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Voicemail_012918',
                    embeddedFeatures: [{ featureTypeCode: 'VMGE' }],
                    existing: false,
                  },
                  {
                    sfoId: '80148',
                    description: 'INTL MESSAGES WHILE IN US $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '81143',
                    description: 'ACCESS - ADVANCED CALLING $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '81158',
                    description: 'HD VOICE $0',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/HD_Voice_012918',
                    embeddedFeatures: [
                      { featureTypeCode: 'HDV' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                    ],
                    existing: false,
                  },
                  {
                    sfoId: '81186',
                    description: 'ACCESS - HD VOICE $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '81495',
                    description: 'TOTAL EQUIPMNT COVERAGE $12.10',
                    price: '12.10',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/device_protection_120817',
                    embeddedFeatures: [{ featureTypeCode: 'EXWAR' }, { featureTypeCode: 'INHS' }],
                    existing: false,
                  },
                  {
                    sfoId: '82419',
                    description: 'ACCESS-WI-FI CALLING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '83186',
                    description: 'ROAM ALTERNATE FEATURE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '83856',
                    description: 'CDMA-LESS DEVICE PROVISIONING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '84094',
                    description: 'INTL SERVICES ENABLED LITE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'IDLITE' }],
                    existing: false,
                  },
                  {
                    sfoId: '86189',
                    description: 'EMAIL AND WEB UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Data_012918',
                    embeddedFeatures: [
                      { featureTypeCode: '' },
                      { featureTypeCode: '1XKB' },
                      { featureTypeCode: 'DUNKB' },
                    ],
                    existing: false,
                  },
                  {
                    sfoId: '86209',
                    description: 'INCLUDE CANADA/MEXICO',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/International_Long_Distance_012918',
                    embeddedFeatures: [{ featureTypeCode: 'TAPIN' }, { featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '86211',
                    description: 'VERIZON CLOUD 600 GB INCL',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Cloud_012918',
                    embeddedFeatures: [{ featureTypeCode: 'VL9' }],
                    existing: false,
                  },
                  {
                    sfoId: '86848',
                    description: '4G SERVICE ON 5G DEVICE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '5GM4S' }],
                    existing: false,
                  },
                  {
                    sfoId: '86869',
                    description: 'CALL FILTER $0.00',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/filter_0319',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '88882',
                    description: 'RTR 5G DO MORE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'RDI3' }, { featureTypeCode: 'RTRUDP' }],
                    existing: false,
                  },
                  {
                    sfoId: '88886',
                    description: 'RTR/UC TRIGGER 5G DO MORE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'TRGHX8' }],
                    existing: false,
                  },
                  {
                    sfoId: '88888',
                    description: 'ENTITLEMENT TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'TRGENT' }],
                    existing: false,
                  },
                  {
                    sfoId: '88889',
                    description: 'ENTITLEMENT FOR UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                    ],
                    existing: false,
                  },
                  {
                    sfoId: '88891',
                    description: 'MOBILE HOTSPOT 25GB',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'MHDTL' }],
                    existing: false,
                  },
                  {
                    sfoId: '88932',
                    description: 'VERIZON CLOUD TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '89405',
                    description: '5G CORE TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                ],
                addOnDueMonthly: null,
                equipmentUpgradeEligibility: {
                  upgradeEligible: true,
                  annualUpgradeEligible: true,
                  buyoutEligible: true,
                  earlyUpgradeEligible: false,
                  edgeUpEligible: true,
                  upgradeEligibilityDate: '09/23/2026',
                  upgradeEligibilityLabel: '$272.00 Eligible to upgrade early',
                  buyoutAmountLabel: 'Buyout $972.00 + tax',
                  pendingOrderDetail: null,
                  isWithInWFGperiod: false,
                  isWFGPeriodWithIn90Days: false,
                  discountEligibility: { discountEligible: false, eligibilityLabel: 'NOT DISCOUNT ELIGIBLE' },
                  hadTwoBuyoutInCurrentMonth: false,
                  transferUpgradeEligibility: { giverEligible: false, takerEligible: false, takerMtns: [] },
                },
                lineLevelChangeEligibility: {
                  isDeviceOnlyChangeAllowed: true,
                  isFeatureChangeAllowed: true,
                  isLLBChangeAllowed: true,
                  isMtnChangeAllowed: true,
                  isMtnSuspendAllowed: true,
                  isPricePlanChangeAllowed: true,
                  pendingOrderDetail: null,
                },
                mobileInfoAttributes: {
                  paidInsuranceExist: false,
                  numberShareParent: '',
                  accountOwner: false,
                  accessRoles: null,
                  hasReferAFriend: false,
                },
                tradeInPromo: null,
                inServiceDate: null,
                lineSharingIndicator: '',
                lineAccessCharge: null,
                installmentLoans: [
                  {
                    deviceId: '356371486088359',
                    loanMonthlyPaymentAmount: '38.88',
                    edgeUpPrincipalAmountUnpaid: '272.00',
                    loanTransferEligibility: true,
                    loanAmount: '1399.99',
                    paidAmountToDate: '427.99',
                    totalPrincipalAmountUnpaid: '972.00',
                    loanTermMonths: '36',
                    pendingNumberOfInstallments: 24,
                    daysLeftForNextEligibleUpgrade: 649,
                    paidAmountPercentage: '0.31',
                    edgeUpRequiredPercent: '50.00',
                    firstInstallmentAmount: '39.19',
                    loanNumber: '1803266293',
                    pastTradeInRestrictionTimePeriod: true,
                    displayKeepOption: true,
                    displayReturnOption: true,
                    deviceMismatch: false,
                    loanStatus: {
                      active: true,
                      buyout: true,
                      canceled: false,
                      earlyUpgrade: false,
                      edgeUp: false,
                      forceBuyout: false,
                      indirectPendingApproval: false,
                      indirectRejectedFinal: false,
                      indirectRejectedInitial: false,
                      indirectWaitingForFax: false,
                      paid: false,
                      pending: false,
                      reassign: false,
                      suspendedForMilitaryService: false,
                      transferedToAnotherLoan: false,
                      aol: false,
                    },
                  },
                ],
                earlyTermination: null,
                mobileInfoInsurance: {
                  insuranceId: '81495',
                  insuranceCategory: 'SFO',
                  insuranceName: 'TOTAL EQUIPMNT COVERAGE $12.10',
                  insuranceType: 'MOBILE',
                  price: '12.10',
                },
                availableMTNsForLoanTransfer: { mtnDetails: [{ mtn: '5106028996' }, { mtn: '9492309926' }] },
                offers: null,
                recentPurchaseOrder: { purchasePrice: '1399.99', retailPrice: '1399.99' },
                marketingOption: { vzCCHolder: false },
                totalDueMonthly: null,
                planChangeHoldOrdersFound: null,
                mtnEffectiveDate: null,
                isEqpOrAccOfferAccepted: null,
                lineLevelCurrentCostData: {},
                networkBandwidthType: '',
                deviceMtnIndicator: '',
                showSUGToggle: true,
                balanceAmount: null,
                isNewLine: false,
                sharePlan: null,
                fiosEligibilityCategory: null,
                accountAddress: null,
                fwaRedeemDetails: null,
                showAddSecondNumTile: false,
                primaryNumber: false,
                secondaryNumber: false,
                secondNumberInfo: null,
                equipmentOrders: [{ statusCode: { isOpened: false } }],
                simFreezeInfo: null,
                whwSpoOffer: null,
                newLine: false,
              },
              {
                mtn: '5106028996',
                lineLevelServiceOffers: [],
                numberShare: null,
                mtnHashCode: 'c6299787f732a0821c84ca06ed70f59ccd03901f75f0a5afa14ca64cef952477',
                nickName: 'LUKE APPLE WATCH',
                benefitPair: {
                  pairedPhoneMtn: '5104689682',
                  eligibleToPair: false,
                  existingPair: false,
                  grantee: false,
                  grantor: false,
                },
                primaryUser: {
                  firstName: 'RAVI',
                  lastName: 'SMITH',
                  preferFirstName: null,
                  preferLastName: null,
                  preferPronoun: null,
                },
                primaryAddress: {
                  addressLine1: '2345 NEWPORT BLVD APT F204',
                  city: 'COSTA MESA',
                  state: 'CA',
                  zipCode: '92627',
                  countryCode: 'USA',
                },
                mtnStatus: {
                  isActive: true,
                  isDisconnected: false,
                  isReassignedAndInActive: false,
                  isSuspendedWithBilling: false,
                  isSuspendedWithoutBilling: false,
                  mtnSuspendAllowed: false,
                  isMtnSuspended: false,
                  mtnStatusReasonCode: '',
                  isMtnChanged: null,
                  isReassigned: null,
                  isTransfered: false,
                  isMtnNotEditable: false,
                  status: 'A',
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      deviceId: '359654473120609',
                      deviceSku: 'MQEW3LL/A',
                      deviceUrl:
                        'https://ss7.vzw.com/is/image/VerizonWireless/apple-watch-ultra-cellular-49mm-titanium-green-alpine-loop-m-mqew3ll-a-a',
                      productDisplayName: 'Watch Ultra',
                      category: {
                        smartphone: false,
                        tablet: false,
                        basicphone: false,
                        connectedDevice: true,
                        internetDevice: false,
                        homePC: false,
                        telematics: false,
                        virtualDevice: false,
                        WSOnly: false,
                      },
                      tradeInValue: '',
                      displayName: 'Apple Watch Ultra 49mm Titanium Case with Green Alpine Loop - M',
                      capacity: null,
                      deviceType: {
                        backupRouter4G: null,
                        device4G: null,
                        device3G: null,
                        device5GA: false,
                        device5GE: false,
                        antenna5G: false,
                        home5G: false,
                        deviceType: '4GE',
                        home4GLte: false,
                      },
                      numberShareCapability: null,
                      cdmaRestrictedDevice: false,
                      fixedWirelessInfos: null,
                      pairedDeviceDetails: null,
                      router: false,
                      prodClass1: null,
                      multiMeterWave: false,
                      n77Band: null,
                      fwaDeviceCurrentStatus: null,
                      noOfDaysDeviceActiveInAccountFromToday: null,
                    },
                    simInfo: { simId: '89148000009215309370', simSku: 'UNIVESIM5G-SA-D', skuType: null },
                  },
                ],
                pricePlanInfo: {
                  planId: '18056',
                  description: 'NUMBER SHARE',
                  planDisplayName: null,
                  planImageUrl: null,
                  planCategoryName: 'UNLIMITED CONNECTED PLANS',
                  planCategoryCd: '88',
                  effectiveDate: null,
                  noOfDaysLeft: null,
                  trialEndDate: null,
                  planAttributes: {
                    sharePlan: false,
                    isJax: false,
                    isFelix: false,
                    hasStandardPlan: false,
                    hasSecondNumPlan: false,
                  },
                  accessCharge: null,
                  imageUrlMap: null,
                  planPromotions: null,
                  pearlTrialFlow: false,
                  suspendPearlEnabledFFlag: false,
                  trialEndDateOrThirtyDays: null,
                  trialEndDateOrFortyFiveDays: null,
                },
                currentSPOs: null,
                currentFeatures: [
                  {
                    sfoId: '48526',
                    description: 'TXT MSG W PER MSG CHARGES',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '48553',
                    description: 'STREAMLINED BILLING - $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '66332',
                    description: 'DECLINE DEVICE PROTECTION',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68869',
                    description: 'CALLER ID',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68871',
                    description: 'CONFERENCE CALLING',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/3way_Calling_012918',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68872',
                    description: 'CALL DELIVERY',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68873',
                    description: 'CALL WAITING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '73502',
                    description: 'UNL PICTURE/VIDEO MSG',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'MM' }],
                    existing: false,
                  },
                  {
                    sfoId: '73503',
                    description: 'UNL TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'SMALIN' }, { featureTypeCode: 'SMAL' }],
                    existing: false,
                  },
                  {
                    sfoId: '73733',
                    description: 'DECLINE VOICE MAIL',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Voicemail_012918',
                    embeddedFeatures: [{ featureTypeCode: 'VMGE' }],
                    existing: false,
                  },
                  {
                    sfoId: '75706',
                    description: 'TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75802',
                    description: 'DYNAMIC-PRIVATE IP',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75836',
                    description: '4G INTERNET ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75837',
                    description: '4G APPLICATION ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75875',
                    description: 'USA ONLY NO DATA OUTSIDE US',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '77556',
                    description: '4G PROVISIONING $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '77568',
                    description: 'EMAIL ACCESS PDA $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '80148',
                    description: 'INTL MESSAGES WHILE IN US $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '82419',
                    description: 'ACCESS-WI-FI CALLING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '83856',
                    description: 'CDMA-LESS DEVICE PROVISIONING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '84215',
                    description: '4G VOICE $0',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/HD_Voice_012918',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '85464',
                    description: 'ENTITLEMENT $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '86201',
                    description: 'RTR/UC TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'TRGHX2' }],
                    existing: false,
                  },
                  {
                    sfoId: '86202',
                    description: 'RTR FOR UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'RTRUDP' }],
                    existing: false,
                  },
                  {
                    sfoId: '86216',
                    description: 'UNLIMITED DATA',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '1XKB' }],
                    existing: false,
                  },
                  {
                    sfoId: '86330',
                    description: 'ENTITLEMENT FOR UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                    ],
                    existing: false,
                  },
                ],
                addOnDueMonthly: null,
                equipmentUpgradeEligibility: {
                  upgradeEligible: true,
                  annualUpgradeEligible: false,
                  buyoutEligible: false,
                  earlyUpgradeEligible: false,
                  edgeUpEligible: false,
                  upgradeEligibilityDate: '06/17/2018',
                  upgradeEligibilityLabel: 'Upgrade Now - Not Transferable',
                  buyoutAmountLabel: null,
                  pendingOrderDetail: null,
                  isWithInWFGperiod: false,
                  isWFGPeriodWithIn90Days: false,
                  discountEligibility: { discountEligible: true, eligibilityLabel: 'DISCOUNT ELIGIBLE' },
                  hadTwoBuyoutInCurrentMonth: false,
                  transferUpgradeEligibility: { giverEligible: false, takerEligible: false, takerMtns: [] },
                },
                lineLevelChangeEligibility: {
                  isDeviceOnlyChangeAllowed: true,
                  isFeatureChangeAllowed: true,
                  isLLBChangeAllowed: true,
                  isMtnChangeAllowed: true,
                  isMtnSuspendAllowed: true,
                  isPricePlanChangeAllowed: true,
                  pendingOrderDetail: null,
                },
                mobileInfoAttributes: {
                  paidInsuranceExist: false,
                  numberShareParent: '5104689682',
                  accountOwner: false,
                  accessRoles: null,
                  hasReferAFriend: false,
                },
                tradeInPromo: null,
                inServiceDate: null,
                lineSharingIndicator: 'R',
                lineAccessCharge: null,
                installmentLoans: [],
                earlyTermination: null,
                mobileInfoInsurance: {
                  insuranceId: '66332',
                  insuranceCategory: 'SFO',
                  insuranceName: 'DECLINE DEVICE PROTECTION',
                  insuranceType: 'MOBILE',
                  price: '0.00',
                },
                availableMTNsForLoanTransfer: {},
                offers: null,
                recentPurchaseOrder: null,
                marketingOption: { vzCCHolder: false },
                totalDueMonthly: null,
                planChangeHoldOrdersFound: null,
                mtnEffectiveDate: null,
                isEqpOrAccOfferAccepted: null,
                lineLevelCurrentCostData: {},
                networkBandwidthType: '',
                deviceMtnIndicator: '',
                showSUGToggle: true,
                balanceAmount: null,
                isNewLine: false,
                sharePlan: null,
                fiosEligibilityCategory: null,
                accountAddress: null,
                fwaRedeemDetails: null,
                showAddSecondNumTile: false,
                primaryNumber: false,
                secondaryNumber: false,
                secondNumberInfo: null,
                equipmentOrders: [],
                simFreezeInfo: null,
                whwSpoOffer: null,
                newLine: false,
              },
              {
                mtn: '6572400150',
                lineLevelServiceOffers: [],
                numberShare: null,
                mtnHashCode: '6c5f54f714fe1a8cecbd0829b5b6f5ca2fb9f3b2152fad6930960d78f7564af3',
                nickName: 'RAVI E SMITH-0150',
                benefitPair: {
                  pairedPhoneMtn: null,
                  eligibleToPair: false,
                  existingPair: false,
                  grantee: false,
                  grantor: false,
                },
                primaryUser: {
                  firstName: 'RAVI',
                  lastName: 'SMITH',
                  preferFirstName: null,
                  preferLastName: null,
                  preferPronoun: null,
                },
                primaryAddress: {
                  addressLine1: '2345 NEWPORT BLVD APT G204',
                  city: 'COSTA MESA',
                  state: 'CA',
                  zipCode: '92627',
                  countryCode: 'USA',
                },
                mtnStatus: {
                  isActive: true,
                  isDisconnected: false,
                  isReassignedAndInActive: false,
                  isSuspendedWithBilling: false,
                  isSuspendedWithoutBilling: false,
                  mtnSuspendAllowed: false,
                  isMtnSuspended: false,
                  mtnStatusReasonCode: '',
                  isMtnChanged: null,
                  isReassigned: null,
                  isTransfered: false,
                  isMtnNotEditable: false,
                  status: 'A',
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      deviceId: '357660160842795',
                      deviceSku: 'QTAX57M',
                      deviceUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/gizmo-watch-3-vz-1235158-3-mint',
                      productDisplayName: 'Gizmo Watch 3',
                      category: {
                        smartphone: false,
                        tablet: false,
                        basicphone: false,
                        connectedDevice: true,
                        internetDevice: false,
                        homePC: false,
                        telematics: false,
                        virtualDevice: false,
                        WSOnly: false,
                      },
                      tradeInValue: '',
                      displayName: 'Gizmo Watch 3 in Mint',
                      capacity: null,
                      deviceType: {
                        backupRouter4G: null,
                        device4G: null,
                        device3G: null,
                        device5GA: false,
                        device5GE: false,
                        antenna5G: false,
                        home5G: false,
                        deviceType: '4GE',
                        home4GLte: false,
                      },
                      numberShareCapability: null,
                      cdmaRestrictedDevice: false,
                      fixedWirelessInfos: null,
                      pairedDeviceDetails: null,
                      router: false,
                      prodClass1: null,
                      multiMeterWave: false,
                      n77Band: null,
                      fwaDeviceCurrentStatus: null,
                      noOfDaysDeviceActiveInAccountFromToday: null,
                    },
                    simInfo: { simId: '89148000009379851506', simSku: 'NI-DPSIM', skuType: null },
                  },
                ],
                pricePlanInfo: {
                  planId: '36909',
                  description: 'UNLIMITED PLAN',
                  planDisplayName: null,
                  planImageUrl: null,
                  planCategoryName: 'UNLIMITED CONNECTED PLANS',
                  planCategoryCd: '88',
                  effectiveDate: null,
                  noOfDaysLeft: null,
                  trialEndDate: null,
                  planAttributes: {
                    sharePlan: false,
                    isJax: false,
                    isFelix: false,
                    hasStandardPlan: false,
                    hasSecondNumPlan: false,
                  },
                  accessCharge: null,
                  imageUrlMap: null,
                  planPromotions: null,
                  pearlTrialFlow: false,
                  suspendPearlEnabledFFlag: false,
                  trialEndDateOrThirtyDays: null,
                  trialEndDateOrFortyFiveDays: null,
                },
                currentSPOs: null,
                currentFeatures: [
                  {
                    sfoId: '48526',
                    description: 'TXT MSG W PER MSG CHARGES',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '48553',
                    description: 'STREAMLINED BILLING - $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '66332',
                    description: 'DECLINE DEVICE PROTECTION',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68869',
                    description: 'CALLER ID',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68870',
                    description: 'BUSY TRANSFER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68871',
                    description: 'CONFERENCE CALLING',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/3way_Calling_012918',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68872',
                    description: 'CALL DELIVERY',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68873',
                    description: 'CALL WAITING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68874',
                    description: 'NO ANSWER TRANSFER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68876',
                    description: 'CALL FORWARDING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '73502',
                    description: 'UNL PICTURE/VIDEO MSG',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'MM' }],
                    existing: false,
                  },
                  {
                    sfoId: '73503',
                    description: 'UNL TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'SMALIN' }, { featureTypeCode: 'SMAL' }],
                    existing: false,
                  },
                  {
                    sfoId: '73733',
                    description: 'DECLINE VOICE MAIL',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Voicemail_012918',
                    embeddedFeatures: [{ featureTypeCode: 'VMGE' }],
                    existing: false,
                  },
                  {
                    sfoId: '74774',
                    description: 'SDM REMOTE QUERY ENABLED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'SDM' }],
                    existing: false,
                  },
                  {
                    sfoId: '75622',
                    description: '4G DATA TRANSPORT',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75706',
                    description: 'TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75802',
                    description: 'DYNAMIC-PRIVATE IP',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75836',
                    description: '4G INTERNET ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75837',
                    description: '4G APPLICATION ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75875',
                    description: 'USA ONLY NO DATA OUTSIDE US',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '83856',
                    description: 'CDMA-LESS DEVICE PROVISIONING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '84215',
                    description: '4G VOICE $0',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/HD_Voice_012918',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '86201',
                    description: 'RTR/UC TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'TRGHX2' }],
                    existing: false,
                  },
                  {
                    sfoId: '86202',
                    description: 'RTR FOR UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'RTRUDP' }],
                    existing: false,
                  },
                  {
                    sfoId: '86216',
                    description: 'UNLIMITED DATA',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '1XKB' }],
                    existing: false,
                  },
                  {
                    sfoId: '86330',
                    description: 'ENTITLEMENT FOR UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                    ],
                    existing: false,
                  },
                ],
                addOnDueMonthly: null,
                equipmentUpgradeEligibility: {
                  upgradeEligible: true,
                  annualUpgradeEligible: false,
                  buyoutEligible: true,
                  earlyUpgradeEligible: false,
                  edgeUpEligible: false,
                  upgradeEligibilityDate: '07/10/2026',
                  upgradeEligibilityLabel: '$91.52 to Upgrade',
                  buyoutAmountLabel: 'Buyout $91.52 + tax',
                  pendingOrderDetail: null,
                  isWithInWFGperiod: false,
                  isWFGPeriodWithIn90Days: false,
                  discountEligibility: { discountEligible: false, eligibilityLabel: 'NOT DISCOUNT ELIGIBLE' },
                  hadTwoBuyoutInCurrentMonth: false,
                  transferUpgradeEligibility: { giverEligible: false, takerEligible: false, takerMtns: [] },
                },
                lineLevelChangeEligibility: {
                  isDeviceOnlyChangeAllowed: true,
                  isFeatureChangeAllowed: true,
                  isLLBChangeAllowed: true,
                  isMtnChangeAllowed: true,
                  isMtnSuspendAllowed: true,
                  isPricePlanChangeAllowed: true,
                  pendingOrderDetail: null,
                },
                mobileInfoAttributes: {
                  paidInsuranceExist: false,
                  numberShareParent: '',
                  accountOwner: false,
                  accessRoles: null,
                  hasReferAFriend: false,
                },
                tradeInPromo: null,
                inServiceDate: null,
                lineSharingIndicator: '',
                lineAccessCharge: null,
                installmentLoans: [
                  {
                    deviceId: '357660160842795',
                    loanMonthlyPaymentAmount: '4.16',
                    edgeUpPrincipalAmountUnpaid: '0.00',
                    loanTransferEligibility: true,
                    loanAmount: '149.99',
                    paidAmountToDate: '58.47',
                    totalPrincipalAmountUnpaid: '91.52',
                    loanTermMonths: '36',
                    pendingNumberOfInstallments: 21,
                    daysLeftForNextEligibleUpgrade: 574,
                    paidAmountPercentage: '0.39',
                    edgeUpRequiredPercent: '100.00',
                    firstInstallmentAmount: '4.39',
                    loanNumber: '1803067785',
                    pastTradeInRestrictionTimePeriod: true,
                    displayKeepOption: true,
                    displayReturnOption: false,
                    deviceMismatch: false,
                    loanStatus: {
                      active: true,
                      buyout: true,
                      canceled: false,
                      earlyUpgrade: false,
                      edgeUp: false,
                      forceBuyout: false,
                      indirectPendingApproval: false,
                      indirectRejectedFinal: false,
                      indirectRejectedInitial: false,
                      indirectWaitingForFax: false,
                      paid: false,
                      pending: false,
                      reassign: false,
                      suspendedForMilitaryService: false,
                      transferedToAnotherLoan: false,
                      aol: false,
                    },
                  },
                ],
                earlyTermination: null,
                mobileInfoInsurance: {
                  insuranceId: '66332',
                  insuranceCategory: 'SFO',
                  insuranceName: 'DECLINE DEVICE PROTECTION',
                  insuranceType: 'MOBILE',
                  price: '0.00',
                },
                availableMTNsForLoanTransfer: { mtnDetails: [{ mtn: '5106028996' }, { mtn: '9492309926' }] },
                offers: null,
                recentPurchaseOrder: { purchasePrice: '149.99', retailPrice: '149.99' },
                marketingOption: { vzCCHolder: false },
                totalDueMonthly: null,
                planChangeHoldOrdersFound: null,
                mtnEffectiveDate: null,
                isEqpOrAccOfferAccepted: null,
                lineLevelCurrentCostData: {},
                networkBandwidthType: '',
                deviceMtnIndicator: '',
                showSUGToggle: true,
                balanceAmount: null,
                isNewLine: false,
                sharePlan: null,
                fiosEligibilityCategory: null,
                accountAddress: null,
                fwaRedeemDetails: null,
                showAddSecondNumTile: false,
                primaryNumber: false,
                secondaryNumber: false,
                secondNumberInfo: null,
                equipmentOrders: [{ statusCode: { isOpened: false } }],
                simFreezeInfo: null,
                whwSpoOffer: null,
                newLine: false,
              },
              {
                mtn: '9173493589',
                lineLevelServiceOffers: [],
                numberShare: null,
                mtnHashCode: '209daaab47501829fd97588b5925723765aa7c2e01453557a607e47e08b25e32',
                nickName: 'RAVI E SMITH-3589',
                benefitPair: {
                  pairedPhoneMtn: '9492309926',
                  eligibleToPair: false,
                  existingPair: false,
                  grantee: false,
                  grantor: false,
                },
                primaryUser: {
                  firstName: 'RAVI',
                  lastName: 'SMITH',
                  preferFirstName: null,
                  preferLastName: null,
                  preferPronoun: null,
                },
                primaryAddress: {
                  addressLine1: '2345 NEWPORT BLVD APT G204',
                  city: 'COSTA MESA',
                  state: 'CA',
                  zipCode: '92627',
                  countryCode: 'USA',
                },
                mtnStatus: {
                  isActive: true,
                  isDisconnected: false,
                  isReassignedAndInActive: false,
                  isSuspendedWithBilling: false,
                  isSuspendedWithoutBilling: false,
                  mtnSuspendAllowed: false,
                  isMtnSuspended: false,
                  mtnStatusReasonCode: '',
                  isMtnChanged: null,
                  isReassigned: null,
                  isTransfered: false,
                  isMtnNotEditable: false,
                  status: 'A',
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      deviceId: '354934255796874',
                      deviceSku: 'IPHONE15PROM-US',
                      deviceUrl:
                        'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-pro-max-256gb-black-titanium-mu663ll-a-a',
                      productDisplayName: 'iPhone 15 Pro Max NON VZW NA',
                      category: {
                        smartphone: true,
                        tablet: false,
                        basicphone: false,
                        connectedDevice: false,
                        internetDevice: false,
                        homePC: false,
                        telematics: false,
                        virtualDevice: false,
                        WSOnly: false,
                      },
                      tradeInValue: '',
                      displayName: 'IPHONE15 PROMAX GENERIC US',
                      capacity: null,
                      deviceType: {
                        backupRouter4G: null,
                        device4G: null,
                        device3G: null,
                        device5GA: false,
                        device5GE: true,
                        antenna5G: false,
                        home5G: false,
                        deviceType: '5GE',
                        home4GLte: false,
                      },
                      numberShareCapability: null,
                      cdmaRestrictedDevice: false,
                      fixedWirelessInfos: null,
                      pairedDeviceDetails: null,
                      router: false,
                      prodClass1: null,
                      multiMeterWave: false,
                      n77Band: null,
                      fwaDeviceCurrentStatus: null,
                      noOfDaysDeviceActiveInAccountFromToday: null,
                    },
                    simInfo: { simId: '89148000010805260312', simSku: 'UNIVESIM5G-SAB-S', skuType: null },
                  },
                ],
                pricePlanInfo: {
                  planId: '50432',
                  description: '5G DO MORE',
                  planDisplayName: null,
                  planImageUrl: null,
                  planCategoryName: 'UNLIMITED FOR ALL',
                  planCategoryCd: '67',
                  effectiveDate: null,
                  noOfDaysLeft: null,
                  trialEndDate: null,
                  planAttributes: {
                    sharePlan: false,
                    isJax: false,
                    isFelix: false,
                    hasStandardPlan: true,
                    hasSecondNumPlan: false,
                  },
                  accessCharge: null,
                  imageUrlMap: null,
                  planPromotions: null,
                  pearlTrialFlow: false,
                  suspendPearlEnabledFFlag: false,
                  trialEndDateOrThirtyDays: null,
                  trialEndDateOrFortyFiveDays: null,
                },
                currentSPOs: null,
                currentFeatures: [
                  {
                    sfoId: '48526',
                    description: 'TXT MSG W PER MSG CHARGES',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '48553',
                    description: 'STREAMLINED BILLING - $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68869',
                    description: 'CALLER ID',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68870',
                    description: 'BUSY TRANSFER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68871',
                    description: 'CONFERENCE CALLING',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/3way_Calling_012918',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68872',
                    description: 'CALL DELIVERY',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68873',
                    description: 'CALL WAITING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68874',
                    description: 'NO ANSWER TRANSFER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68876',
                    description: 'CALL FORWARDING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '73502',
                    description: 'UNL PICTURE/VIDEO MSG',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'MM' }],
                    existing: false,
                  },
                  {
                    sfoId: '73503',
                    description: 'UNL TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'SMALIN' }, { featureTypeCode: 'SMAL' }],
                    existing: false,
                  },
                  {
                    sfoId: '75706',
                    description: 'TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75802',
                    description: 'DYNAMIC-PRIVATE IP',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75836',
                    description: '4G INTERNET ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75837',
                    description: '4G APPLICATION ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '76404',
                    description: 'MOBILE HOTSPOT 4G PROVISIONING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '76600',
                    description: 'SHARE NAME ID $0.00',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Caller_ID_012918',
                    embeddedFeatures: [{ featureTypeCode: 'SEUN' }],
                    existing: false,
                  },
                  {
                    sfoId: '77556',
                    description: '4G PROVISIONING $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '77568',
                    description: 'EMAIL ACCESS PDA $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '79708',
                    description: 'VISUAL VOICEMAIL SPEC',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Voicemail_012918',
                    embeddedFeatures: [{ featureTypeCode: 'VMGE' }],
                    existing: false,
                  },
                  {
                    sfoId: '80148',
                    description: 'INTL MESSAGES WHILE IN US $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '81143',
                    description: 'ACCESS - ADVANCED CALLING $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '81158',
                    description: 'HD VOICE $0',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/HD_Voice_012918',
                    embeddedFeatures: [
                      { featureTypeCode: 'HDV' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                    ],
                    existing: false,
                  },
                  {
                    sfoId: '81186',
                    description: 'ACCESS - HD VOICE $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '83186',
                    description: 'ROAM ALTERNATE FEATURE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '83856',
                    description: 'CDMA-LESS DEVICE PROVISIONING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '84094',
                    description: 'INTL SERVICES ENABLED LITE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'IDLITE' }],
                    existing: false,
                  },
                  {
                    sfoId: '86189',
                    description: 'EMAIL AND WEB UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Data_012918',
                    embeddedFeatures: [
                      { featureTypeCode: '' },
                      { featureTypeCode: '1XKB' },
                      { featureTypeCode: 'DUNKB' },
                    ],
                    existing: false,
                  },
                  {
                    sfoId: '86209',
                    description: 'INCLUDE CANADA/MEXICO',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/International_Long_Distance_012918',
                    embeddedFeatures: [{ featureTypeCode: 'TAPIN' }, { featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '86211',
                    description: 'VERIZON CLOUD 600 GB INCL',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Cloud_012918',
                    embeddedFeatures: [{ featureTypeCode: 'VL9' }],
                    existing: false,
                  },
                  {
                    sfoId: '86848',
                    description: '4G SERVICE ON 5G DEVICE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '5GM4S' }],
                    existing: false,
                  },
                  {
                    sfoId: '88689',
                    description: 'VERIZON MOBILE PROTECT $19',
                    price: '19.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/device_protection_120817',
                    embeddedFeatures: [
                      { featureTypeCode: 'GURU' },
                      { featureTypeCode: '' },
                      { featureTypeCode: 'EXWAR' },
                      { featureTypeCode: 'INHS' },
                    ],
                    existing: false,
                  },
                  {
                    sfoId: '88882',
                    description: 'RTR 5G DO MORE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'RDI3' }, { featureTypeCode: 'RTRUDP' }],
                    existing: false,
                  },
                  {
                    sfoId: '88886',
                    description: 'RTR/UC TRIGGER 5G DO MORE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'TRGHX8' }],
                    existing: false,
                  },
                  {
                    sfoId: '88888',
                    description: 'ENTITLEMENT TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'TRGENT' }],
                    existing: false,
                  },
                  {
                    sfoId: '88889',
                    description: 'ENTITLEMENT FOR UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                    ],
                    existing: false,
                  },
                  {
                    sfoId: '88891',
                    description: 'MOBILE HOTSPOT 25GB',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'MHDTL' }],
                    existing: false,
                  },
                  {
                    sfoId: '88932',
                    description: 'VERIZON CLOUD TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '89405',
                    description: '5G CORE TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                ],
                addOnDueMonthly: null,
                equipmentUpgradeEligibility: {
                  upgradeEligible: true,
                  annualUpgradeEligible: true,
                  buyoutEligible: true,
                  earlyUpgradeEligible: false,
                  edgeUpEligible: true,
                  upgradeEligibilityDate: '06/29/2027',
                  upgradeEligibilityLabel: '$533.22 Eligible to upgrade early',
                  buyoutAmountLabel: 'Buyout $1133.22 + tax',
                  pendingOrderDetail: null,
                  isWithInWFGperiod: false,
                  isWFGPeriodWithIn90Days: false,
                  discountEligibility: { discountEligible: false, eligibilityLabel: 'NOT DISCOUNT ELIGIBLE' },
                  hadTwoBuyoutInCurrentMonth: false,
                  transferUpgradeEligibility: { giverEligible: false, takerEligible: false, takerMtns: [] },
                },
                lineLevelChangeEligibility: {
                  isDeviceOnlyChangeAllowed: true,
                  isFeatureChangeAllowed: true,
                  isLLBChangeAllowed: true,
                  isMtnChangeAllowed: true,
                  isMtnSuspendAllowed: true,
                  isPricePlanChangeAllowed: true,
                  pendingOrderDetail: null,
                },
                mobileInfoAttributes: {
                  paidInsuranceExist: false,
                  numberShareParent: '',
                  accountOwner: false,
                  accessRoles: null,
                  hasReferAFriend: false,
                },
                tradeInPromo: null,
                inServiceDate: null,
                lineSharingIndicator: 'L',
                lineAccessCharge: null,
                installmentLoans: [
                  {
                    deviceId: '354934255796874',
                    loanMonthlyPaymentAmount: '33.33',
                    edgeUpPrincipalAmountUnpaid: '533.22',
                    loanTransferEligibility: true,
                    loanAmount: '1199.99',
                    paidAmountToDate: '66.77',
                    totalPrincipalAmountUnpaid: '1133.22',
                    loanTermMonths: '36',
                    pendingNumberOfInstallments: 33,
                    daysLeftForNextEligibleUpgrade: 928,
                    paidAmountPercentage: '0.06',
                    edgeUpRequiredPercent: '50.00',
                    firstInstallmentAmount: '33.44',
                    loanNumber: '1333539209',
                    pastTradeInRestrictionTimePeriod: true,
                    displayKeepOption: true,
                    displayReturnOption: true,
                    deviceMismatch: false,
                    loanStatus: {
                      active: true,
                      buyout: true,
                      canceled: false,
                      earlyUpgrade: false,
                      edgeUp: false,
                      forceBuyout: false,
                      indirectPendingApproval: false,
                      indirectRejectedFinal: false,
                      indirectRejectedInitial: false,
                      indirectWaitingForFax: false,
                      paid: false,
                      pending: false,
                      reassign: false,
                      suspendedForMilitaryService: false,
                      transferedToAnotherLoan: false,
                      aol: false,
                    },
                  },
                ],
                earlyTermination: null,
                mobileInfoInsurance: {
                  insuranceId: '88689',
                  insuranceCategory: 'SFO',
                  insuranceName: 'VERIZON MOBILE PROTECT $19',
                  insuranceType: 'MOBILE',
                  price: '19.00',
                },
                availableMTNsForLoanTransfer: { mtnDetails: [{ mtn: '5106028996' }, { mtn: '9492309926' }] },
                offers: null,
                recentPurchaseOrder: { purchasePrice: '1199.99', retailPrice: '1199.99' },
                marketingOption: { vzCCHolder: false },
                totalDueMonthly: null,
                planChangeHoldOrdersFound: null,
                mtnEffectiveDate: null,
                isEqpOrAccOfferAccepted: null,
                lineLevelCurrentCostData: {},
                networkBandwidthType: '',
                deviceMtnIndicator: '',
                showSUGToggle: true,
                balanceAmount: null,
                isNewLine: false,
                sharePlan: null,
                fiosEligibilityCategory: null,
                accountAddress: null,
                fwaRedeemDetails: null,
                showAddSecondNumTile: false,
                primaryNumber: false,
                secondaryNumber: false,
                secondNumberInfo: null,
                equipmentOrders: [{ statusCode: { isOpened: false } }],
                simFreezeInfo: null,
                whwSpoOffer: null,
                newLine: false,
              },
              {
                mtn: '9492309926',
                lineLevelServiceOffers: [],
                numberShare: null,
                mtnHashCode: '2a59668f2b10786caa33038be7d6cc40011388f10d8ad3bf067bdf413925c17e',
                nickName: 'RAVI E SMITH-9926',
                benefitPair: {
                  pairedPhoneMtn: '9173493589',
                  eligibleToPair: false,
                  existingPair: false,
                  grantee: false,
                  grantor: false,
                },
                primaryUser: {
                  firstName: 'RAVI',
                  lastName: 'SMITH',
                  preferFirstName: null,
                  preferLastName: null,
                  preferPronoun: null,
                },
                primaryAddress: {
                  addressLine1: '2345 NEWPORT BLVD APT E108',
                  city: 'COSTA MESA',
                  state: 'CA',
                  zipCode: '92627',
                  countryCode: 'USA',
                },
                mtnStatus: {
                  isActive: true,
                  isDisconnected: false,
                  isReassignedAndInActive: false,
                  isSuspendedWithBilling: false,
                  isSuspendedWithoutBilling: false,
                  mtnSuspendAllowed: false,
                  isMtnSuspended: false,
                  mtnStatusReasonCode: '',
                  isMtnChanged: null,
                  isReassigned: null,
                  isTransfered: false,
                  isMtnNotEditable: false,
                  status: 'A',
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      deviceId: '358643099875994',
                      deviceSku: 'MTUJ2LL/A',
                      deviceUrl:
                        'https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA',
                      productDisplayName: 'Watch Series 4',
                      category: {
                        smartphone: false,
                        tablet: false,
                        basicphone: false,
                        connectedDevice: true,
                        internetDevice: false,
                        homePC: false,
                        telematics: false,
                        virtualDevice: false,
                        WSOnly: false,
                      },
                      tradeInValue: '',
                      displayName: 'Apple Watch Series 4, 40mm Gold Aluminum Case with Pink Sand Sport Band',
                      capacity: null,
                      deviceType: {
                        backupRouter4G: null,
                        device4G: null,
                        device3G: null,
                        device5GA: false,
                        device5GE: false,
                        antenna5G: false,
                        home5G: false,
                        deviceType: '4GE',
                        home4GLte: false,
                      },
                      numberShareCapability: null,
                      cdmaRestrictedDevice: false,
                      fixedWirelessInfos: null,
                      pairedDeviceDetails: null,
                      router: false,
                      prodClass1: null,
                      multiMeterWave: false,
                      n77Band: null,
                      fwaDeviceCurrentStatus: null,
                      noOfDaysDeviceActiveInAccountFromToday: null,
                    },
                    simInfo: { simId: '89148000004888472464', simSku: 'SOFTSIM-CMR-D', skuType: null },
                  },
                ],
                pricePlanInfo: {
                  planId: '18056',
                  description: 'NUMBER SHARE',
                  planDisplayName: null,
                  planImageUrl: null,
                  planCategoryName: 'UNLIMITED CONNECTED PLANS',
                  planCategoryCd: '88',
                  effectiveDate: null,
                  noOfDaysLeft: null,
                  trialEndDate: null,
                  planAttributes: {
                    sharePlan: false,
                    isJax: false,
                    isFelix: false,
                    hasStandardPlan: false,
                    hasSecondNumPlan: false,
                  },
                  accessCharge: null,
                  imageUrlMap: null,
                  planPromotions: null,
                  pearlTrialFlow: false,
                  suspendPearlEnabledFFlag: false,
                  trialEndDateOrThirtyDays: null,
                  trialEndDateOrFortyFiveDays: null,
                },
                currentSPOs: null,
                currentFeatures: [
                  {
                    sfoId: '48526',
                    description: 'TXT MSG W PER MSG CHARGES',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '48553',
                    description: 'STREAMLINED BILLING - $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68869',
                    description: 'CALLER ID',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68871',
                    description: 'CONFERENCE CALLING',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/3way_Calling_012918',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68872',
                    description: 'CALL DELIVERY',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68873',
                    description: 'CALL WAITING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '73502',
                    description: 'UNL PICTURE/VIDEO MSG',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'MM' }],
                    existing: false,
                  },
                  {
                    sfoId: '73503',
                    description: 'UNL TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'SMALIN' }, { featureTypeCode: 'SMAL' }],
                    existing: false,
                  },
                  {
                    sfoId: '73733',
                    description: 'DECLINE VOICE MAIL',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Voicemail_012918',
                    embeddedFeatures: [{ featureTypeCode: 'VMGE' }],
                    existing: false,
                  },
                  {
                    sfoId: '75706',
                    description: 'TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75802',
                    description: 'DYNAMIC-PRIVATE IP',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75836',
                    description: '4G INTERNET ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75837',
                    description: '4G APPLICATION ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75875',
                    description: 'USA ONLY NO DATA OUTSIDE US',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '77556',
                    description: '4G PROVISIONING $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '77568',
                    description: 'EMAIL ACCESS PDA $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '80148',
                    description: 'INTL MESSAGES WHILE IN US $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '82419',
                    description: 'ACCESS-WI-FI CALLING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '83856',
                    description: 'CDMA-LESS DEVICE PROVISIONING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '84215',
                    description: '4G VOICE $0',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/HD_Voice_012918',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '85464',
                    description: 'ENTITLEMENT $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '86201',
                    description: 'RTR/UC TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'TRGHX2' }],
                    existing: false,
                  },
                  {
                    sfoId: '86202',
                    description: 'RTR FOR UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'RTRUDP' }],
                    existing: false,
                  },
                  {
                    sfoId: '86216',
                    description: 'UNLIMITED DATA',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '1XKB' }],
                    existing: false,
                  },
                  {
                    sfoId: '86330',
                    description: 'ENTITLEMENT FOR UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                    ],
                    existing: false,
                  },
                ],
                addOnDueMonthly: null,
                equipmentUpgradeEligibility: {
                  upgradeEligible: true,
                  annualUpgradeEligible: false,
                  buyoutEligible: false,
                  earlyUpgradeEligible: false,
                  edgeUpEligible: false,
                  upgradeEligibilityDate: '12/25/2018',
                  upgradeEligibilityLabel: 'Upgrade Now - Not Transferable',
                  buyoutAmountLabel: null,
                  pendingOrderDetail: null,
                  isWithInWFGperiod: false,
                  isWFGPeriodWithIn90Days: false,
                  discountEligibility: { discountEligible: true, eligibilityLabel: 'DISCOUNT ELIGIBLE' },
                  hadTwoBuyoutInCurrentMonth: false,
                  transferUpgradeEligibility: { giverEligible: false, takerEligible: false, takerMtns: [] },
                },
                lineLevelChangeEligibility: {
                  isDeviceOnlyChangeAllowed: true,
                  isFeatureChangeAllowed: true,
                  isLLBChangeAllowed: true,
                  isMtnChangeAllowed: true,
                  isMtnSuspendAllowed: true,
                  isPricePlanChangeAllowed: true,
                  pendingOrderDetail: null,
                },
                mobileInfoAttributes: {
                  paidInsuranceExist: false,
                  numberShareParent: '9173493589',
                  accountOwner: false,
                  accessRoles: null,
                  hasReferAFriend: false,
                },
                tradeInPromo: null,
                inServiceDate: null,
                lineSharingIndicator: 'R',
                lineAccessCharge: null,
                installmentLoans: [],
                earlyTermination: null,
                mobileInfoInsurance: {},
                availableMTNsForLoanTransfer: {},
                offers: null,
                recentPurchaseOrder: null,
                marketingOption: { vzCCHolder: false },
                totalDueMonthly: null,
                planChangeHoldOrdersFound: null,
                mtnEffectiveDate: null,
                isEqpOrAccOfferAccepted: null,
                lineLevelCurrentCostData: {},
                networkBandwidthType: '',
                deviceMtnIndicator: '',
                showSUGToggle: true,
                balanceAmount: null,
                isNewLine: false,
                sharePlan: null,
                fiosEligibilityCategory: null,
                accountAddress: null,
                fwaRedeemDetails: null,
                showAddSecondNumTile: false,
                primaryNumber: false,
                secondaryNumber: false,
                secondNumberInfo: null,
                equipmentOrders: [],
                simFreezeInfo: null,
                whwSpoOffer: null,
                newLine: false,
              },
              {
                mtn: '9492395813',
                lineLevelServiceOffers: [],
                numberShare: null,
                mtnHashCode: '2329f1726c5aab207fa5e6a9f98d579fb945ee0dbebf42ecfdd67a27f4c8fb94',
                nickName: 'RAVI E SMITH-5813',
                benefitPair: {
                  pairedPhoneMtn: null,
                  eligibleToPair: false,
                  existingPair: false,
                  grantee: false,
                  grantor: false,
                },
                primaryUser: {
                  firstName: 'RAVI',
                  lastName: 'SMITH',
                  preferFirstName: null,
                  preferLastName: null,
                  preferPronoun: null,
                },
                primaryAddress: { addressLine1: null, city: null, state: null, zipCode: null, countryCode: null },
                mtnStatus: {
                  isActive: false,
                  isDisconnected: true,
                  isReassignedAndInActive: false,
                  isSuspendedWithBilling: false,
                  isSuspendedWithoutBilling: false,
                  mtnSuspendAllowed: false,
                  isMtnSuspended: false,
                  mtnStatusReasonCode: 'LL',
                  isMtnChanged: null,
                  isReassigned: null,
                  isTransfered: false,
                  isMtnNotEditable: false,
                  status: 'D',
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      deviceId: '868312040894222',
                      deviceSku: 'ZW20P',
                      deviceUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/zte-gizmowatch-pink',
                      productDisplayName: 'GizmoWatch 2',
                      category: {
                        smartphone: false,
                        tablet: false,
                        basicphone: false,
                        connectedDevice: true,
                        internetDevice: false,
                        homePC: false,
                        telematics: false,
                        virtualDevice: false,
                        WSOnly: false,
                      },
                      tradeInValue: '',
                      displayName: 'Verizon GizmoWatch 2 in Pink',
                      capacity: null,
                      deviceType: {
                        backupRouter4G: null,
                        device4G: null,
                        device3G: null,
                        device5GA: false,
                        device5GE: false,
                        antenna5G: false,
                        home5G: false,
                        deviceType: '4GE',
                        home4GLte: false,
                      },
                      numberShareCapability: null,
                      cdmaRestrictedDevice: false,
                      fixedWirelessInfos: null,
                      pairedDeviceDetails: null,
                      router: false,
                      prodClass1: null,
                      multiMeterWave: false,
                      n77Band: null,
                      fwaDeviceCurrentStatus: null,
                      noOfDaysDeviceActiveInAccountFromToday: null,
                    },
                    simInfo: { simId: '89148000006278303514', simSku: 'NI-DPSIM', skuType: null },
                  },
                ],
                pricePlanInfo: {
                  planId: null,
                  description: null,
                  planDisplayName: null,
                  planImageUrl: null,
                  planCategoryName: null,
                  planCategoryCd: null,
                  effectiveDate: null,
                  noOfDaysLeft: null,
                  trialEndDate: null,
                  planAttributes: null,
                  accessCharge: null,
                  imageUrlMap: null,
                  planPromotions: null,
                  pearlTrialFlow: false,
                  suspendPearlEnabledFFlag: false,
                  trialEndDateOrThirtyDays: null,
                  trialEndDateOrFortyFiveDays: null,
                },
                currentSPOs: null,
                currentFeatures: [],
                addOnDueMonthly: null,
                equipmentUpgradeEligibility: {
                  upgradeEligible: false,
                  annualUpgradeEligible: false,
                  buyoutEligible: false,
                  earlyUpgradeEligible: false,
                  edgeUpEligible: false,
                  upgradeEligibilityDate: null,
                  upgradeEligibilityLabel: 'Upgrade Now - Not Transferable',
                  buyoutAmountLabel: null,
                  pendingOrderDetail: null,
                  isWithInWFGperiod: false,
                  isWFGPeriodWithIn90Days: false,
                  discountEligibility: { discountEligible: true, eligibilityLabel: 'DISCOUNT ELIGIBLE' },
                  hadTwoBuyoutInCurrentMonth: false,
                  transferUpgradeEligibility: { giverEligible: false, takerEligible: false, takerMtns: [] },
                },
                lineLevelChangeEligibility: {
                  isDeviceOnlyChangeAllowed: false,
                  isFeatureChangeAllowed: false,
                  isLLBChangeAllowed: false,
                  isMtnChangeAllowed: false,
                  isMtnSuspendAllowed: false,
                  isPricePlanChangeAllowed: false,
                  pendingOrderDetail: null,
                },
                mobileInfoAttributes: {
                  paidInsuranceExist: false,
                  numberShareParent: '',
                  accountOwner: false,
                  accessRoles: null,
                  hasReferAFriend: false,
                },
                tradeInPromo: null,
                inServiceDate: null,
                lineSharingIndicator: '',
                lineAccessCharge: null,
                installmentLoans: [],
                earlyTermination: null,
                mobileInfoInsurance: {},
                availableMTNsForLoanTransfer: {},
                offers: null,
                recentPurchaseOrder: null,
                marketingOption: { vzCCHolder: false },
                totalDueMonthly: null,
                planChangeHoldOrdersFound: null,
                mtnEffectiveDate: null,
                isEqpOrAccOfferAccepted: null,
                lineLevelCurrentCostData: {},
                networkBandwidthType: '',
                deviceMtnIndicator: '',
                showSUGToggle: true,
                balanceAmount: null,
                isNewLine: false,
                sharePlan: null,
                fiosEligibilityCategory: null,
                accountAddress: null,
                fwaRedeemDetails: null,
                showAddSecondNumTile: false,
                primaryNumber: false,
                secondaryNumber: false,
                secondNumberInfo: null,
                equipmentOrders: [],
                simFreezeInfo: null,
                whwSpoOffer: null,
                newLine: false,
              },
              {
                mtn: '9492446182',
                lineLevelServiceOffers: [],
                numberShare: null,
                mtnHashCode: '4d5b6675674dcd79e4825b65ec60a4d9faade024c1c28d396f2431e927a13c51',
                nickName: 'RAVI E SMITH-6182',
                benefitPair: {
                  pairedPhoneMtn: null,
                  eligibleToPair: false,
                  existingPair: false,
                  grantee: false,
                  grantor: false,
                },
                primaryUser: {
                  firstName: 'RAVI',
                  lastName: 'SMITH',
                  preferFirstName: null,
                  preferLastName: null,
                  preferPronoun: null,
                },
                primaryAddress: {
                  addressLine1: '2345 NEWPORT BLVD APT G204',
                  city: 'COSTA MESA',
                  state: 'CA',
                  zipCode: '92627',
                  countryCode: 'USA',
                },
                mtnStatus: {
                  isActive: true,
                  isDisconnected: false,
                  isReassignedAndInActive: false,
                  isSuspendedWithBilling: false,
                  isSuspendedWithoutBilling: false,
                  mtnSuspendAllowed: false,
                  isMtnSuspended: false,
                  mtnStatusReasonCode: '',
                  isMtnChanged: null,
                  isReassigned: null,
                  isTransfered: false,
                  isMtnNotEditable: false,
                  status: 'A',
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      deviceId: '355549915850157',
                      deviceSku: 'MPUN3LL/A',
                      deviceUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-starlight-fall22-a',
                      productDisplayName: 'iPhone 14',
                      category: {
                        smartphone: true,
                        tablet: false,
                        basicphone: false,
                        connectedDevice: false,
                        internetDevice: false,
                        homePC: false,
                        telematics: false,
                        virtualDevice: false,
                        WSOnly: false,
                      },
                      tradeInValue: '',
                      displayName: 'Apple iPhone 14 128GB in Starlight',
                      capacity: null,
                      deviceType: {
                        backupRouter4G: null,
                        device4G: null,
                        device3G: null,
                        device5GA: false,
                        device5GE: true,
                        antenna5G: false,
                        home5G: false,
                        deviceType: '5GE',
                        home4GLte: false,
                      },
                      numberShareCapability: null,
                      cdmaRestrictedDevice: false,
                      fixedWirelessInfos: null,
                      pairedDeviceDetails: [
                        {
                          pairedImei: '355549915207580',
                          pairedImeiMtn: '',
                          isPairedImeiActive: false,
                          isPairedMTNSameAccount: false,
                        },
                      ],
                      router: false,
                      prodClass1: null,
                      multiMeterWave: false,
                      n77Band: null,
                      fwaDeviceCurrentStatus: null,
                      noOfDaysDeviceActiveInAccountFromToday: null,
                    },
                    simInfo: { simId: '89148000010807925276', simSku: 'UNIVESIM5G-SA-S', skuType: null },
                  },
                ],
                pricePlanInfo: {
                  planId: '63215',
                  description: 'UNLIMITED WELCOME',
                  planDisplayName: null,
                  planImageUrl: null,
                  planCategoryName: 'MY PLAN',
                  planCategoryCd: '92',
                  effectiveDate: null,
                  noOfDaysLeft: null,
                  trialEndDate: null,
                  planAttributes: {
                    sharePlan: false,
                    isJax: false,
                    isFelix: false,
                    hasStandardPlan: true,
                    hasSecondNumPlan: false,
                  },
                  accessCharge: null,
                  imageUrlMap: null,
                  planPromotions: null,
                  pearlTrialFlow: false,
                  suspendPearlEnabledFFlag: false,
                  trialEndDateOrThirtyDays: null,
                  trialEndDateOrFortyFiveDays: null,
                },
                currentSPOs: null,
                currentFeatures: [
                  {
                    sfoId: '48526',
                    description: 'TXT MSG W PER MSG CHARGES',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '48553',
                    description: 'STREAMLINED BILLING - $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68869',
                    description: 'CALLER ID',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68870',
                    description: 'BUSY TRANSFER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68871',
                    description: 'CONFERENCE CALLING',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/3way_Calling_012918',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68872',
                    description: 'CALL DELIVERY',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68873',
                    description: 'CALL WAITING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68874',
                    description: 'NO ANSWER TRANSFER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68876',
                    description: 'CALL FORWARDING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '73502',
                    description: 'UNL PICTURE/VIDEO MSG',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'MM' }],
                    existing: false,
                  },
                  {
                    sfoId: '73503',
                    description: 'UNL TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'SMALIN' }, { featureTypeCode: 'SMAL' }],
                    existing: false,
                  },
                  {
                    sfoId: '75622',
                    description: '4G DATA TRANSPORT',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75706',
                    description: 'TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75802',
                    description: 'DYNAMIC-PRIVATE IP',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75836',
                    description: '4G INTERNET ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75837',
                    description: '4G APPLICATION ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '77568',
                    description: 'EMAIL ACCESS PDA $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '78485',
                    description: 'BLOCK MOBILE HOTSPOT',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '79708',
                    description: 'VISUAL VOICEMAIL SPEC',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Voicemail_012918',
                    embeddedFeatures: [{ featureTypeCode: 'VMGE' }],
                    existing: false,
                  },
                  {
                    sfoId: '80148',
                    description: 'INTL MESSAGES WHILE IN US $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '81143',
                    description: 'ACCESS - ADVANCED CALLING $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '81158',
                    description: 'HD VOICE $0',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/HD_Voice_012918',
                    embeddedFeatures: [
                      { featureTypeCode: 'HDV' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                    ],
                    existing: false,
                  },
                  {
                    sfoId: '81186',
                    description: 'ACCESS - HD VOICE $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '83186',
                    description: 'ROAM ALTERNATE FEATURE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '83856',
                    description: 'CDMA-LESS DEVICE PROVISIONING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '84094',
                    description: 'INTL SERVICES ENABLED LITE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'IDLITE' }],
                    existing: false,
                  },
                  {
                    sfoId: '85553',
                    description: 'VERIZON CLOUD ELIGIBLE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Cloud_012918',
                    embeddedFeatures: [{ featureTypeCode: 'VLX' }],
                    existing: false,
                  },
                  {
                    sfoId: '86189',
                    description: 'EMAIL AND WEB UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Data_012918',
                    embeddedFeatures: [
                      { featureTypeCode: '' },
                      { featureTypeCode: '1XKB' },
                      { featureTypeCode: 'DUNKB' },
                    ],
                    existing: false,
                  },
                  {
                    sfoId: '86209',
                    description: 'INCLUDE CANADA/MEXICO',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/International_Long_Distance_012918',
                    embeddedFeatures: [{ featureTypeCode: 'TAPIN' }, { featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '86848',
                    description: '4G SERVICE ON 5G DEVICE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '5GM4S' }],
                    existing: false,
                  },
                  {
                    sfoId: '86905',
                    description: 'GSM ROAMING PRIORITY',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '88689',
                    description: 'VERIZON MOBILE PROTECT $19',
                    price: '19.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/device_protection_120817',
                    embeddedFeatures: [
                      { featureTypeCode: 'GURU' },
                      { featureTypeCode: '' },
                      { featureTypeCode: 'EXWAR' },
                      { featureTypeCode: 'INHS' },
                    ],
                    existing: false,
                  },
                  {
                    sfoId: '89405',
                    description: '5G CORE TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '89668',
                    description: 'TEXT BLOCK ALLOW TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'SMSTRG' }],
                    existing: false,
                  },
                  {
                    sfoId: '89670',
                    description: 'ENTITLEMENT FOR UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                    ],
                    existing: false,
                  },
                  {
                    sfoId: '89671',
                    description: 'RTR/UC TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'TRGBY1' }],
                    existing: false,
                  },
                  {
                    sfoId: '89673',
                    description: 'RTR PROVISIONING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'RDI3' }, { featureTypeCode: 'RTRUDP' }],
                    existing: false,
                  },
                ],
                addOnDueMonthly: null,
                equipmentUpgradeEligibility: {
                  upgradeEligible: true,
                  annualUpgradeEligible: false,
                  buyoutEligible: true,
                  earlyUpgradeEligible: false,
                  edgeUpEligible: false,
                  upgradeEligibilityDate: '06/29/2027',
                  upgradeEligibilityLabel: '$689.18 to Upgrade',
                  buyoutAmountLabel: 'Buyout $689.18 + tax',
                  pendingOrderDetail: null,
                  isWithInWFGperiod: false,
                  isWFGPeriodWithIn90Days: false,
                  discountEligibility: { discountEligible: false, eligibilityLabel: 'NOT DISCOUNT ELIGIBLE' },
                  hadTwoBuyoutInCurrentMonth: false,
                  transferUpgradeEligibility: { giverEligible: false, takerEligible: false, takerMtns: [] },
                },
                lineLevelChangeEligibility: {
                  isDeviceOnlyChangeAllowed: true,
                  isFeatureChangeAllowed: true,
                  isLLBChangeAllowed: true,
                  isMtnChangeAllowed: true,
                  isMtnSuspendAllowed: true,
                  isPricePlanChangeAllowed: true,
                  pendingOrderDetail: null,
                },
                mobileInfoAttributes: {
                  paidInsuranceExist: false,
                  numberShareParent: '',
                  accountOwner: false,
                  accessRoles: null,
                  hasReferAFriend: false,
                },
                tradeInPromo: null,
                inServiceDate: null,
                lineSharingIndicator: '',
                lineAccessCharge: null,
                installmentLoans: [
                  {
                    deviceId: '355549915850157',
                    loanMonthlyPaymentAmount: '20.27',
                    edgeUpPrincipalAmountUnpaid: '0.00',
                    loanTransferEligibility: true,
                    loanAmount: '729.99',
                    paidAmountToDate: '40.81',
                    totalPrincipalAmountUnpaid: '689.18',
                    loanTermMonths: '36',
                    pendingNumberOfInstallments: 33,
                    daysLeftForNextEligibleUpgrade: 928,
                    paidAmountPercentage: '0.06',
                    edgeUpRequiredPercent: '100.00',
                    firstInstallmentAmount: '20.54',
                    loanNumber: '1333539210',
                    pastTradeInRestrictionTimePeriod: true,
                    displayKeepOption: true,
                    displayReturnOption: false,
                    deviceMismatch: false,
                    loanStatus: {
                      active: true,
                      buyout: true,
                      canceled: false,
                      earlyUpgrade: false,
                      edgeUp: false,
                      forceBuyout: false,
                      indirectPendingApproval: false,
                      indirectRejectedFinal: false,
                      indirectRejectedInitial: false,
                      indirectWaitingForFax: false,
                      paid: false,
                      pending: false,
                      reassign: false,
                      suspendedForMilitaryService: false,
                      transferedToAnotherLoan: false,
                      aol: false,
                    },
                  },
                ],
                earlyTermination: null,
                mobileInfoInsurance: {
                  insuranceId: '88689',
                  insuranceCategory: 'SFO',
                  insuranceName: 'VERIZON MOBILE PROTECT $19',
                  insuranceType: 'MOBILE',
                  price: '19.00',
                },
                availableMTNsForLoanTransfer: { mtnDetails: [{ mtn: '5106028996' }, { mtn: '9492309926' }] },
                offers: null,
                recentPurchaseOrder: { purchasePrice: '729.99', retailPrice: '729.99' },
                marketingOption: { vzCCHolder: false },
                totalDueMonthly: null,
                planChangeHoldOrdersFound: null,
                mtnEffectiveDate: null,
                isEqpOrAccOfferAccepted: null,
                lineLevelCurrentCostData: {},
                networkBandwidthType: '',
                deviceMtnIndicator: '',
                showSUGToggle: true,
                balanceAmount: null,
                isNewLine: false,
                sharePlan: null,
                fiosEligibilityCategory: null,
                accountAddress: null,
                fwaRedeemDetails: null,
                showAddSecondNumTile: true,
                primaryNumber: false,
                secondaryNumber: false,
                secondNumberInfo: null,
                equipmentOrders: [{ statusCode: { isOpened: false } }],
                simFreezeInfo: null,
                whwSpoOffer: null,
                newLine: false,
              },
            ],
            fiosEligibilityCategory: null,
            accountAddress: {
              addressLine1: '2345 NEWPORT BLVD APT G204',
              addressLine2: '',
              city: 'COSTA MESA',
              state: 'CA',
              zipCode: '92627',
              fipsCode: '0605916532',
              geoCode: 'USA06059165320',
              zipCodePlus4: '1833',
              scrubbedAddress: {
                streetName: 'NEWPORT',
                streetNumber: '2345',
                streetType: 'BLVD',
                streetDirection: '',
                apartmentNo: 'G204',
                pobox: '',
                ruralDeliveryNo: '',
                ruralRouteNo: '',
                city: 'COSTA MESA',
                state: 'CA',
                zipCode: '92627',
                zipCodePlus4: '6527',
              },
            },
            establishedDate: '12/11/2012',
            establishedInLastThirtyDays: false,
            contactInfo: { decline: false, declineReasonCode: '' },
            vzwVztCustomerInfo: {
              totalDiscountAmountMH: null,
              perlineDiscountMH: null,
              discountAppliedMH: null,
              discountVersionMH: null,
              tenDollarMNHDiscount: null,
              fiveDollarMNHDiscount: null,
              fiosBonusDiscount: null,
              vzwBonusDiscount: null,
              subtotalBaseAmountMH: null,
              bonusDiscountMNH: null,
              vztAccountInfo: [],
            },
            accountSubscriptions: { lineLevelSubscriptions: [] },
          },
        ],
        customerCbrInfo: { cbrNos: [{ phoneNumber: '2866726432' }, { phoneNumber: '2866726432' }] },
        isSalesRepIdMismatch: false,
        accountNo: '0787408248-00001',
        repId: 'ENC',
        loggedInUser: 'mangva5',
        channel: 'OMNI-CARE',
        orderLocationCode: 'P332201',
        orderNumber: '0',
        homeLocationCode: 'P332201',
        regNo: '01',
        isComboOrderAllowed: false,
        isFWASimplificationEnabled: false,
        storeLocationState: 'NC',
        repSecurityClassCode: '00000007',
        homeSalesAddressList: [],
        isAsurionExpansionEnabled: false,
        secondNumPlanExists: false,
        featureFlags: {},
      },
      equipmentInfo: {
        deviceInfo: {
          deviceId: '356371486088359',
          deviceSku: 'IPHONE15PROM-US-2',
          deviceUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/DU-fallback-smartphone-03152023',
          productDisplayName: 'iPhone 15 Pro Max NON VZW NA-2',
          category: {
            smartphone: true,
            tablet: false,
            basicphone: false,
            connectedDevice: false,
            internetDevice: false,
            homePC: false,
            telematics: false,
            virtualDevice: false,
            WSOnly: false,
          },
          tradeInValue: '',
          displayName: 'IPHONE15 PROMAX GENERIC US-2',
          capacity: null,
          deviceType: {
            backupRouter4G: null,
            device4G: null,
            device3G: null,
            device5GA: false,
            device5GE: true,
            antenna5G: false,
            home5G: false,
            deviceType: '5GE',
            home4GLte: false,
          },
          numberShareCapability: null,
          cdmaRestrictedDevice: false,
          fixedWirelessInfos: null,
          pairedDeviceDetails: null,
          router: false,
          prodClass1: null,
          multiMeterWave: false,
          n77Band: null,
          fwaDeviceCurrentStatus: null,
          noOfDaysDeviceActiveInAccountFromToday: null,
        },
        simInfo: { simId: '89148000009710862519', simSku: 'UNIVESIM5G-SAB-S', skuType: null },
      },
    });
    expect(Object.keys(payload).length).toBeGreaterThan(0);
  });
  it('getDeviceEnforApiPayload BE should return payload', () => {
    const payload = getDeviceEnforApiPayload({
      locationCd: '',
      mfeIccid: '123',
      mfeImei: '456',
      ctiUser: {},
      customerInfo: {
        caseId: 'SOP-17646952-C01',
        cartId: '10ced43c-bff7-4e7d-9acd-ea40f362c6ca',
        availablePaths: [],
        customerId: '787408248',
        customerHash: '6c668a826627c68d1f133de42e3b9961f479da08b6c9f8eb1681a482767b697a',
        contactAddress: { state: 'CA' },
        customerName: {
          firstName: 'RAVI',
          lastName: 'SMITH',
          businessName: '',
          preferFirstName: '',
          preferLastName: '',
          preferPronoun: '',
        },
        address: {
          addressLine1: '2345 NEWPORT BLVD APT G204',
          addressLine2: '',
          city: 'COSTA MESA',
          state: 'CA',
          zipCode: '92627',
          fipsCode: '0605916532',
          geoCode: 'USA06059165320',
          zipCodePlus4: '1833',
          scrubbedAddress: {
            streetName: 'NEWPORT',
            streetNumber: '2345',
            streetType: 'BLVD',
            streetDirection: '',
            apartmentNo: 'G204',
            pobox: '',
            ruralDeliveryNo: '',
            ruralRouteNo: '',
            city: 'COSTA MESA',
            state: 'CA',
            zipCode: '92627',
            zipCodePlus4: '6527',
          },
        },
        email: 'NZIRZ8780@VZW.COM',
        lookupMtn: '5104689682',
        billingSystem: 'VISION_NORTH',
        customerAttributes: {
          hasEcpd: '0000000000',
          autoPayDiscountEligibleCustomerType: true,
          customerType: 'BE',
          associationIdNo: null,
        },
        billAccounts: [
          {
            billAccountNo: '12345',
            recommendation: {
              recommendedPlan: {
                usageInfo: { accountUsageInfo: { dataUsageInfos: [] } },
                unbilledAccountUsageInfo: {
                  totalData: null,
                  unitOfMeasure: null,
                  usageType: null,
                  dataAllowance: null,
                },
              },
            },
            billCycle: { billCycleDate: '12/12/2024', remainingDays: '0', nextBillCycleAutoRedeemPaymentDate: null },
            programEligibility: {
              programEligible: false,
              spendingLimitAmount: '7000.00',
              BTALimitAmount: '750.00',
              RemainingBTAAmount: '750.00',
              RemainingSpendingLimitAmount: '0',
            },
            sharePlan: { planId: null, description: null, chargeAmount: null, planImageUrl: null },
            accountOffers: { productOffers: [] },
            accountLevelChangeEligibility: {
              isAddNewLineAllowed: true,
              isBundleChangeAllowed: true,
              isSharePlanChangeAllowed: true,
              pendingOrderDetail: null,
            },
            paymentInfo: {
              arPastDueBalance: '377.71',
              currentBalance: '0.00',
              isBalancePastDue: true,
              pastDueBalance: '0.00',
              invoiceDate: '09/12/2024',
              isAutoPayEnrolled: true,
              isPaperFreeEnrolled: true,
              recentActivityAmount: '0.00',
              outstandingBalance: null,
              vzWalletInfo: {
                eligibleToUseVzDollar: null,
                maximumPropositionAmount: null,
                minimumPropositionAmount: null,
                vzDollarsBalance: null,
              },
              vzdAutoRedeemDetails: {
                vzdAutoRedeemEnrolled: null,
                vzdAutoRedeemAmount: null,
                vzdAutoRedeemFullBillAmount: null,
                vzdAutoRedeemEnrollDate: null,
              },
              lastVzdollarsAutoRedeemAmt: null,
              lastVzdollarsAutoRedeemPaymentDate: null,
              lastVzPmtDate: null,
              currentBCVzdollarsRedeemAmt: null,
            },
            accountAttributes: {
              isAutoPayWithPaperless: true,
              mixedPlanCategories: true,
              isOverThreshHold: false,
              isCashOnly: false,
              isCashOnlyExceptCA: false,
              isCashOnlyExceptCC: false,
              isCashOnlyExceptCO: false,
              fraudInfo: { fraud_X: false, fraud_Y: false },
              isMyVerizonEnrolled: true,
            },
            mtns: [
              {
                mtn: '5104689682',
                lineLevelServiceOffers: [],
                numberShare: null,
                mtnHashCode: '3d9b7bbcee0558204fafaf5f61d456562483fe97b0653ab8480e7989db10685b',
                nickName: 'LUKE IPHONE 15 PROMA 9682',
                benefitPair: {
                  pairedPhoneMtn: '5106028996',
                  eligibleToPair: false,
                  existingPair: false,
                  grantee: false,
                  grantor: false,
                },
                primaryUser: {
                  firstName: 'KYLE',
                  lastName: 'SMITH',
                  preferFirstName: null,
                  preferLastName: null,
                  preferPronoun: null,
                },
                primaryAddress: {
                  addressLine1: '2345 NEWPORT BLVD APT E108',
                  city: 'COSTA MESA',
                  state: 'CA',
                  zipCode: '92627',
                  countryCode: 'USA',
                },
                mtnStatus: {
                  isActive: true,
                  isDisconnected: false,
                  isReassignedAndInActive: false,
                  isSuspendedWithBilling: false,
                  isSuspendedWithoutBilling: false,
                  mtnSuspendAllowed: false,
                  isMtnSuspended: false,
                  mtnStatusReasonCode: '',
                  isMtnChanged: null,
                  isReassigned: null,
                  isTransfered: false,
                  isMtnNotEditable: false,
                  status: 'A',
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      deviceId: '356371486088359',
                      deviceSku: 'IPHONE15PROM-US-2',
                      deviceUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/DU-fallback-smartphone-03152023',
                      productDisplayName: 'iPhone 15 Pro Max NON VZW NA-2',
                      category: {
                        smartphone: true,
                        tablet: false,
                        basicphone: false,
                        connectedDevice: false,
                        internetDevice: false,
                        homePC: false,
                        telematics: false,
                        virtualDevice: false,
                        WSOnly: false,
                      },
                      tradeInValue: '',
                      displayName: 'IPHONE15 PROMAX GENERIC US-2',
                      capacity: null,
                      deviceType: {
                        backupRouter4G: null,
                        device4G: null,
                        device3G: null,
                        device5GA: false,
                        device5GE: true,
                        antenna5G: false,
                        home5G: false,
                        deviceType: '5GE',
                        home4GLte: false,
                      },
                      numberShareCapability: null,
                      cdmaRestrictedDevice: false,
                      fixedWirelessInfos: null,
                      pairedDeviceDetails: null,
                      router: false,
                      prodClass1: null,
                      multiMeterWave: false,
                      n77Band: null,
                      fwaDeviceCurrentStatus: null,
                      noOfDaysDeviceActiveInAccountFromToday: null,
                    },
                    simInfo: { simId: '89148000009710862519', simSku: 'UNIVESIM5G-SAB-S', skuType: null },
                  },
                ],
                pricePlanInfo: {
                  planId: '50432',
                  description: '5G DO MORE',
                  planDisplayName: null,
                  planImageUrl: null,
                  planCategoryName: 'UNLIMITED FOR ALL',
                  planCategoryCd: '67',
                  effectiveDate: null,
                  noOfDaysLeft: null,
                  trialEndDate: null,
                  planAttributes: {
                    sharePlan: false,
                    isJax: false,
                    isFelix: false,
                    hasStandardPlan: true,
                    hasSecondNumPlan: false,
                  },
                  accessCharge: null,
                  imageUrlMap: null,
                  planPromotions: null,
                  pearlTrialFlow: false,
                  suspendPearlEnabledFFlag: false,
                  trialEndDateOrThirtyDays: null,
                  trialEndDateOrFortyFiveDays: null,
                },
                currentSPOs: null,
                currentFeatures: [
                  {
                    sfoId: '48526',
                    description: 'TXT MSG W PER MSG CHARGES',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '48553',
                    description: 'STREAMLINED BILLING - $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68869',
                    description: 'CALLER ID',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68870',
                    description: 'BUSY TRANSFER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68871',
                    description: 'CONFERENCE CALLING',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/3way_Calling_012918',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68872',
                    description: 'CALL DELIVERY',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68873',
                    description: 'CALL WAITING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68874',
                    description: 'NO ANSWER TRANSFER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68876',
                    description: 'CALL FORWARDING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '73502',
                    description: 'UNL PICTURE/VIDEO MSG',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'MM' }],
                    existing: false,
                  },
                  {
                    sfoId: '73503',
                    description: 'UNL TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'SMALIN' }, { featureTypeCode: 'SMAL' }],
                    existing: false,
                  },
                  {
                    sfoId: '75706',
                    description: 'TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75802',
                    description: 'DYNAMIC-PRIVATE IP',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75836',
                    description: '4G INTERNET ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75837',
                    description: '4G APPLICATION ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '76404',
                    description: 'MOBILE HOTSPOT 4G PROVISIONING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '76600',
                    description: 'SHARE NAME ID $0.00',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Caller_ID_012918',
                    embeddedFeatures: [{ featureTypeCode: 'SEUN' }],
                    existing: false,
                  },
                  {
                    sfoId: '77556',
                    description: '4G PROVISIONING $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '77568',
                    description: 'EMAIL ACCESS PDA $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '79708',
                    description: 'VISUAL VOICEMAIL SPEC',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Voicemail_012918',
                    embeddedFeatures: [{ featureTypeCode: 'VMGE' }],
                    existing: false,
                  },
                  {
                    sfoId: '80148',
                    description: 'INTL MESSAGES WHILE IN US $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '81143',
                    description: 'ACCESS - ADVANCED CALLING $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '81158',
                    description: 'HD VOICE $0',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/HD_Voice_012918',
                    embeddedFeatures: [
                      { featureTypeCode: 'HDV' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                    ],
                    existing: false,
                  },
                  {
                    sfoId: '81186',
                    description: 'ACCESS - HD VOICE $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '81495',
                    description: 'TOTAL EQUIPMNT COVERAGE $12.10',
                    price: '12.10',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/device_protection_120817',
                    embeddedFeatures: [{ featureTypeCode: 'EXWAR' }, { featureTypeCode: 'INHS' }],
                    existing: false,
                  },
                  {
                    sfoId: '82419',
                    description: 'ACCESS-WI-FI CALLING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '83186',
                    description: 'ROAM ALTERNATE FEATURE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '83856',
                    description: 'CDMA-LESS DEVICE PROVISIONING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '84094',
                    description: 'INTL SERVICES ENABLED LITE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'IDLITE' }],
                    existing: false,
                  },
                  {
                    sfoId: '86189',
                    description: 'EMAIL AND WEB UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Data_012918',
                    embeddedFeatures: [
                      { featureTypeCode: '' },
                      { featureTypeCode: '1XKB' },
                      { featureTypeCode: 'DUNKB' },
                    ],
                    existing: false,
                  },
                  {
                    sfoId: '86209',
                    description: 'INCLUDE CANADA/MEXICO',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/International_Long_Distance_012918',
                    embeddedFeatures: [{ featureTypeCode: 'TAPIN' }, { featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '86211',
                    description: 'VERIZON CLOUD 600 GB INCL',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Cloud_012918',
                    embeddedFeatures: [{ featureTypeCode: 'VL9' }],
                    existing: false,
                  },
                  {
                    sfoId: '86848',
                    description: '4G SERVICE ON 5G DEVICE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '5GM4S' }],
                    existing: false,
                  },
                  {
                    sfoId: '86869',
                    description: 'CALL FILTER $0.00',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/filter_0319',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '88882',
                    description: 'RTR 5G DO MORE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'RDI3' }, { featureTypeCode: 'RTRUDP' }],
                    existing: false,
                  },
                  {
                    sfoId: '88886',
                    description: 'RTR/UC TRIGGER 5G DO MORE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'TRGHX8' }],
                    existing: false,
                  },
                  {
                    sfoId: '88888',
                    description: 'ENTITLEMENT TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'TRGENT' }],
                    existing: false,
                  },
                  {
                    sfoId: '88889',
                    description: 'ENTITLEMENT FOR UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                    ],
                    existing: false,
                  },
                  {
                    sfoId: '88891',
                    description: 'MOBILE HOTSPOT 25GB',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'MHDTL' }],
                    existing: false,
                  },
                  {
                    sfoId: '88932',
                    description: 'VERIZON CLOUD TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '89405',
                    description: '5G CORE TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                ],
                addOnDueMonthly: null,
                equipmentUpgradeEligibility: {
                  upgradeEligible: true,
                  annualUpgradeEligible: true,
                  buyoutEligible: true,
                  earlyUpgradeEligible: false,
                  edgeUpEligible: true,
                  upgradeEligibilityDate: '09/23/2026',
                  upgradeEligibilityLabel: '$272.00 Eligible to upgrade early',
                  buyoutAmountLabel: 'Buyout $972.00 + tax',
                  pendingOrderDetail: null,
                  isWithInWFGperiod: false,
                  isWFGPeriodWithIn90Days: false,
                  discountEligibility: { discountEligible: false, eligibilityLabel: 'NOT DISCOUNT ELIGIBLE' },
                  hadTwoBuyoutInCurrentMonth: false,
                  transferUpgradeEligibility: { giverEligible: false, takerEligible: false, takerMtns: [] },
                },
                lineLevelChangeEligibility: {
                  isDeviceOnlyChangeAllowed: true,
                  isFeatureChangeAllowed: true,
                  isLLBChangeAllowed: true,
                  isMtnChangeAllowed: true,
                  isMtnSuspendAllowed: true,
                  isPricePlanChangeAllowed: true,
                  pendingOrderDetail: null,
                },
                mobileInfoAttributes: {
                  paidInsuranceExist: false,
                  numberShareParent: '',
                  accountOwner: false,
                  accessRoles: null,
                  hasReferAFriend: false,
                },
                tradeInPromo: null,
                inServiceDate: null,
                lineSharingIndicator: '',
                lineAccessCharge: null,
                installmentLoans: [
                  {
                    deviceId: '356371486088359',
                    loanMonthlyPaymentAmount: '38.88',
                    edgeUpPrincipalAmountUnpaid: '272.00',
                    loanTransferEligibility: true,
                    loanAmount: '1399.99',
                    paidAmountToDate: '427.99',
                    totalPrincipalAmountUnpaid: '972.00',
                    loanTermMonths: '36',
                    pendingNumberOfInstallments: 24,
                    daysLeftForNextEligibleUpgrade: 649,
                    paidAmountPercentage: '0.31',
                    edgeUpRequiredPercent: '50.00',
                    firstInstallmentAmount: '39.19',
                    loanNumber: '1803266293',
                    pastTradeInRestrictionTimePeriod: true,
                    displayKeepOption: true,
                    displayReturnOption: true,
                    deviceMismatch: false,
                    loanStatus: {
                      active: true,
                      buyout: true,
                      canceled: false,
                      earlyUpgrade: false,
                      edgeUp: false,
                      forceBuyout: false,
                      indirectPendingApproval: false,
                      indirectRejectedFinal: false,
                      indirectRejectedInitial: false,
                      indirectWaitingForFax: false,
                      paid: false,
                      pending: false,
                      reassign: false,
                      suspendedForMilitaryService: false,
                      transferedToAnotherLoan: false,
                      aol: false,
                    },
                  },
                ],
                earlyTermination: null,
                mobileInfoInsurance: {
                  insuranceId: '81495',
                  insuranceCategory: 'SFO',
                  insuranceName: 'TOTAL EQUIPMNT COVERAGE $12.10',
                  insuranceType: 'MOBILE',
                  price: '12.10',
                },
                availableMTNsForLoanTransfer: { mtnDetails: [{ mtn: '5106028996' }, { mtn: '9492309926' }] },
                offers: null,
                recentPurchaseOrder: { purchasePrice: '1399.99', retailPrice: '1399.99' },
                marketingOption: { vzCCHolder: false },
                totalDueMonthly: null,
                planChangeHoldOrdersFound: null,
                mtnEffectiveDate: null,
                isEqpOrAccOfferAccepted: null,
                lineLevelCurrentCostData: {},
                networkBandwidthType: '',
                deviceMtnIndicator: '',
                showSUGToggle: true,
                balanceAmount: null,
                isNewLine: false,
                sharePlan: null,
                fiosEligibilityCategory: null,
                accountAddress: null,
                fwaRedeemDetails: null,
                showAddSecondNumTile: false,
                primaryNumber: false,
                secondaryNumber: false,
                secondNumberInfo: null,
                equipmentOrders: [{ statusCode: { isOpened: false } }],
                simFreezeInfo: null,
                whwSpoOffer: null,
                newLine: false,
              },
              {
                mtn: '5106028996',
                lineLevelServiceOffers: [],
                numberShare: null,
                mtnHashCode: 'c6299787f732a0821c84ca06ed70f59ccd03901f75f0a5afa14ca64cef952477',
                nickName: 'LUKE APPLE WATCH',
                benefitPair: {
                  pairedPhoneMtn: '5104689682',
                  eligibleToPair: false,
                  existingPair: false,
                  grantee: false,
                  grantor: false,
                },
                primaryUser: {
                  firstName: 'RAVI',
                  lastName: 'SMITH',
                  preferFirstName: null,
                  preferLastName: null,
                  preferPronoun: null,
                },
                primaryAddress: {
                  addressLine1: '2345 NEWPORT BLVD APT F204',
                  city: 'COSTA MESA',
                  state: 'CA',
                  zipCode: '92627',
                  countryCode: 'USA',
                },
                mtnStatus: {
                  isActive: true,
                  isDisconnected: false,
                  isReassignedAndInActive: false,
                  isSuspendedWithBilling: false,
                  isSuspendedWithoutBilling: false,
                  mtnSuspendAllowed: false,
                  isMtnSuspended: false,
                  mtnStatusReasonCode: '',
                  isMtnChanged: null,
                  isReassigned: null,
                  isTransfered: false,
                  isMtnNotEditable: false,
                  status: 'A',
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      deviceId: '359654473120609',
                      deviceSku: 'MQEW3LL/A',
                      deviceUrl:
                        'https://ss7.vzw.com/is/image/VerizonWireless/apple-watch-ultra-cellular-49mm-titanium-green-alpine-loop-m-mqew3ll-a-a',
                      productDisplayName: 'Watch Ultra',
                      category: {
                        smartphone: false,
                        tablet: false,
                        basicphone: false,
                        connectedDevice: true,
                        internetDevice: false,
                        homePC: false,
                        telematics: false,
                        virtualDevice: false,
                        WSOnly: false,
                      },
                      tradeInValue: '',
                      displayName: 'Apple Watch Ultra 49mm Titanium Case with Green Alpine Loop - M',
                      capacity: null,
                      deviceType: {
                        backupRouter4G: null,
                        device4G: null,
                        device3G: null,
                        device5GA: false,
                        device5GE: false,
                        antenna5G: false,
                        home5G: false,
                        deviceType: '4GE',
                        home4GLte: false,
                      },
                      numberShareCapability: null,
                      cdmaRestrictedDevice: false,
                      fixedWirelessInfos: null,
                      pairedDeviceDetails: null,
                      router: false,
                      prodClass1: null,
                      multiMeterWave: false,
                      n77Band: null,
                      fwaDeviceCurrentStatus: null,
                      noOfDaysDeviceActiveInAccountFromToday: null,
                    },
                    simInfo: { simId: '89148000009215309370', simSku: 'UNIVESIM5G-SA-D', skuType: null },
                  },
                ],
                pricePlanInfo: {
                  planId: '18056',
                  description: 'NUMBER SHARE',
                  planDisplayName: null,
                  planImageUrl: null,
                  planCategoryName: 'UNLIMITED CONNECTED PLANS',
                  planCategoryCd: '88',
                  effectiveDate: null,
                  noOfDaysLeft: null,
                  trialEndDate: null,
                  planAttributes: {
                    sharePlan: false,
                    isJax: false,
                    isFelix: false,
                    hasStandardPlan: false,
                    hasSecondNumPlan: false,
                  },
                  accessCharge: null,
                  imageUrlMap: null,
                  planPromotions: null,
                  pearlTrialFlow: false,
                  suspendPearlEnabledFFlag: false,
                  trialEndDateOrThirtyDays: null,
                  trialEndDateOrFortyFiveDays: null,
                },
                currentSPOs: null,
                currentFeatures: [
                  {
                    sfoId: '48526',
                    description: 'TXT MSG W PER MSG CHARGES',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '48553',
                    description: 'STREAMLINED BILLING - $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '66332',
                    description: 'DECLINE DEVICE PROTECTION',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68869',
                    description: 'CALLER ID',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68871',
                    description: 'CONFERENCE CALLING',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/3way_Calling_012918',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68872',
                    description: 'CALL DELIVERY',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68873',
                    description: 'CALL WAITING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '73502',
                    description: 'UNL PICTURE/VIDEO MSG',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'MM' }],
                    existing: false,
                  },
                  {
                    sfoId: '73503',
                    description: 'UNL TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'SMALIN' }, { featureTypeCode: 'SMAL' }],
                    existing: false,
                  },
                  {
                    sfoId: '73733',
                    description: 'DECLINE VOICE MAIL',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Voicemail_012918',
                    embeddedFeatures: [{ featureTypeCode: 'VMGE' }],
                    existing: false,
                  },
                  {
                    sfoId: '75706',
                    description: 'TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75802',
                    description: 'DYNAMIC-PRIVATE IP',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75836',
                    description: '4G INTERNET ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75837',
                    description: '4G APPLICATION ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75875',
                    description: 'USA ONLY NO DATA OUTSIDE US',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '77556',
                    description: '4G PROVISIONING $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '77568',
                    description: 'EMAIL ACCESS PDA $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '80148',
                    description: 'INTL MESSAGES WHILE IN US $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '82419',
                    description: 'ACCESS-WI-FI CALLING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '83856',
                    description: 'CDMA-LESS DEVICE PROVISIONING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '84215',
                    description: '4G VOICE $0',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/HD_Voice_012918',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '85464',
                    description: 'ENTITLEMENT $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '86201',
                    description: 'RTR/UC TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'TRGHX2' }],
                    existing: false,
                  },
                  {
                    sfoId: '86202',
                    description: 'RTR FOR UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'RTRUDP' }],
                    existing: false,
                  },
                  {
                    sfoId: '86216',
                    description: 'UNLIMITED DATA',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '1XKB' }],
                    existing: false,
                  },
                  {
                    sfoId: '86330',
                    description: 'ENTITLEMENT FOR UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                    ],
                    existing: false,
                  },
                ],
                addOnDueMonthly: null,
                equipmentUpgradeEligibility: {
                  upgradeEligible: true,
                  annualUpgradeEligible: false,
                  buyoutEligible: false,
                  earlyUpgradeEligible: false,
                  edgeUpEligible: false,
                  upgradeEligibilityDate: '06/17/2018',
                  upgradeEligibilityLabel: 'Upgrade Now - Not Transferable',
                  buyoutAmountLabel: null,
                  pendingOrderDetail: null,
                  isWithInWFGperiod: false,
                  isWFGPeriodWithIn90Days: false,
                  discountEligibility: { discountEligible: true, eligibilityLabel: 'DISCOUNT ELIGIBLE' },
                  hadTwoBuyoutInCurrentMonth: false,
                  transferUpgradeEligibility: { giverEligible: false, takerEligible: false, takerMtns: [] },
                },
                lineLevelChangeEligibility: {
                  isDeviceOnlyChangeAllowed: true,
                  isFeatureChangeAllowed: true,
                  isLLBChangeAllowed: true,
                  isMtnChangeAllowed: true,
                  isMtnSuspendAllowed: true,
                  isPricePlanChangeAllowed: true,
                  pendingOrderDetail: null,
                },
                mobileInfoAttributes: {
                  paidInsuranceExist: false,
                  numberShareParent: '5104689682',
                  accountOwner: false,
                  accessRoles: null,
                  hasReferAFriend: false,
                },
                tradeInPromo: null,
                inServiceDate: null,
                lineSharingIndicator: 'R',
                lineAccessCharge: null,
                installmentLoans: [],
                earlyTermination: null,
                mobileInfoInsurance: {
                  insuranceId: '66332',
                  insuranceCategory: 'SFO',
                  insuranceName: 'DECLINE DEVICE PROTECTION',
                  insuranceType: 'MOBILE',
                  price: '0.00',
                },
                availableMTNsForLoanTransfer: {},
                offers: null,
                recentPurchaseOrder: null,
                marketingOption: { vzCCHolder: false },
                totalDueMonthly: null,
                planChangeHoldOrdersFound: null,
                mtnEffectiveDate: null,
                isEqpOrAccOfferAccepted: null,
                lineLevelCurrentCostData: {},
                networkBandwidthType: '',
                deviceMtnIndicator: '',
                showSUGToggle: true,
                balanceAmount: null,
                isNewLine: false,
                sharePlan: null,
                fiosEligibilityCategory: null,
                accountAddress: null,
                fwaRedeemDetails: null,
                showAddSecondNumTile: false,
                primaryNumber: false,
                secondaryNumber: false,
                secondNumberInfo: null,
                equipmentOrders: [],
                simFreezeInfo: null,
                whwSpoOffer: null,
                newLine: false,
              },
              {
                mtn: '6572400150',
                lineLevelServiceOffers: [],
                numberShare: null,
                mtnHashCode: '6c5f54f714fe1a8cecbd0829b5b6f5ca2fb9f3b2152fad6930960d78f7564af3',
                nickName: 'RAVI E SMITH-0150',
                benefitPair: {
                  pairedPhoneMtn: null,
                  eligibleToPair: false,
                  existingPair: false,
                  grantee: false,
                  grantor: false,
                },
                primaryUser: {
                  firstName: 'RAVI',
                  lastName: 'SMITH',
                  preferFirstName: null,
                  preferLastName: null,
                  preferPronoun: null,
                },
                primaryAddress: {
                  addressLine1: '2345 NEWPORT BLVD APT G204',
                  city: 'COSTA MESA',
                  state: 'CA',
                  zipCode: '92627',
                  countryCode: 'USA',
                },
                mtnStatus: {
                  isActive: true,
                  isDisconnected: false,
                  isReassignedAndInActive: false,
                  isSuspendedWithBilling: false,
                  isSuspendedWithoutBilling: false,
                  mtnSuspendAllowed: false,
                  isMtnSuspended: false,
                  mtnStatusReasonCode: '',
                  isMtnChanged: null,
                  isReassigned: null,
                  isTransfered: false,
                  isMtnNotEditable: false,
                  status: 'A',
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      deviceId: '357660160842795',
                      deviceSku: 'QTAX57M',
                      deviceUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/gizmo-watch-3-vz-1235158-3-mint',
                      productDisplayName: 'Gizmo Watch 3',
                      category: {
                        smartphone: false,
                        tablet: false,
                        basicphone: false,
                        connectedDevice: true,
                        internetDevice: false,
                        homePC: false,
                        telematics: false,
                        virtualDevice: false,
                        WSOnly: false,
                      },
                      tradeInValue: '',
                      displayName: 'Gizmo Watch 3 in Mint',
                      capacity: null,
                      deviceType: {
                        backupRouter4G: null,
                        device4G: null,
                        device3G: null,
                        device5GA: false,
                        device5GE: false,
                        antenna5G: false,
                        home5G: false,
                        deviceType: '4GE',
                        home4GLte: false,
                      },
                      numberShareCapability: null,
                      cdmaRestrictedDevice: false,
                      fixedWirelessInfos: null,
                      pairedDeviceDetails: null,
                      router: false,
                      prodClass1: null,
                      multiMeterWave: false,
                      n77Band: null,
                      fwaDeviceCurrentStatus: null,
                      noOfDaysDeviceActiveInAccountFromToday: null,
                    },
                    simInfo: { simId: '89148000009379851506', simSku: 'NI-DPSIM', skuType: null },
                  },
                ],
                pricePlanInfo: {
                  planId: '36909',
                  description: 'UNLIMITED PLAN',
                  planDisplayName: null,
                  planImageUrl: null,
                  planCategoryName: 'UNLIMITED CONNECTED PLANS',
                  planCategoryCd: '88',
                  effectiveDate: null,
                  noOfDaysLeft: null,
                  trialEndDate: null,
                  planAttributes: {
                    sharePlan: false,
                    isJax: false,
                    isFelix: false,
                    hasStandardPlan: false,
                    hasSecondNumPlan: false,
                  },
                  accessCharge: null,
                  imageUrlMap: null,
                  planPromotions: null,
                  pearlTrialFlow: false,
                  suspendPearlEnabledFFlag: false,
                  trialEndDateOrThirtyDays: null,
                  trialEndDateOrFortyFiveDays: null,
                },
                currentSPOs: null,
                currentFeatures: [
                  {
                    sfoId: '48526',
                    description: 'TXT MSG W PER MSG CHARGES',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '48553',
                    description: 'STREAMLINED BILLING - $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '66332',
                    description: 'DECLINE DEVICE PROTECTION',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68869',
                    description: 'CALLER ID',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68870',
                    description: 'BUSY TRANSFER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68871',
                    description: 'CONFERENCE CALLING',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/3way_Calling_012918',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68872',
                    description: 'CALL DELIVERY',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68873',
                    description: 'CALL WAITING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68874',
                    description: 'NO ANSWER TRANSFER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68876',
                    description: 'CALL FORWARDING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '73502',
                    description: 'UNL PICTURE/VIDEO MSG',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'MM' }],
                    existing: false,
                  },
                  {
                    sfoId: '73503',
                    description: 'UNL TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'SMALIN' }, { featureTypeCode: 'SMAL' }],
                    existing: false,
                  },
                  {
                    sfoId: '73733',
                    description: 'DECLINE VOICE MAIL',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Voicemail_012918',
                    embeddedFeatures: [{ featureTypeCode: 'VMGE' }],
                    existing: false,
                  },
                  {
                    sfoId: '74774',
                    description: 'SDM REMOTE QUERY ENABLED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'SDM' }],
                    existing: false,
                  },
                  {
                    sfoId: '75622',
                    description: '4G DATA TRANSPORT',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75706',
                    description: 'TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75802',
                    description: 'DYNAMIC-PRIVATE IP',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75836',
                    description: '4G INTERNET ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75837',
                    description: '4G APPLICATION ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75875',
                    description: 'USA ONLY NO DATA OUTSIDE US',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '83856',
                    description: 'CDMA-LESS DEVICE PROVISIONING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '84215',
                    description: '4G VOICE $0',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/HD_Voice_012918',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '86201',
                    description: 'RTR/UC TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'TRGHX2' }],
                    existing: false,
                  },
                  {
                    sfoId: '86202',
                    description: 'RTR FOR UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'RTRUDP' }],
                    existing: false,
                  },
                  {
                    sfoId: '86216',
                    description: 'UNLIMITED DATA',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '1XKB' }],
                    existing: false,
                  },
                  {
                    sfoId: '86330',
                    description: 'ENTITLEMENT FOR UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                    ],
                    existing: false,
                  },
                ],
                addOnDueMonthly: null,
                equipmentUpgradeEligibility: {
                  upgradeEligible: true,
                  annualUpgradeEligible: false,
                  buyoutEligible: true,
                  earlyUpgradeEligible: false,
                  edgeUpEligible: false,
                  upgradeEligibilityDate: '07/10/2026',
                  upgradeEligibilityLabel: '$91.52 to Upgrade',
                  buyoutAmountLabel: 'Buyout $91.52 + tax',
                  pendingOrderDetail: null,
                  isWithInWFGperiod: false,
                  isWFGPeriodWithIn90Days: false,
                  discountEligibility: { discountEligible: false, eligibilityLabel: 'NOT DISCOUNT ELIGIBLE' },
                  hadTwoBuyoutInCurrentMonth: false,
                  transferUpgradeEligibility: { giverEligible: false, takerEligible: false, takerMtns: [] },
                },
                lineLevelChangeEligibility: {
                  isDeviceOnlyChangeAllowed: true,
                  isFeatureChangeAllowed: true,
                  isLLBChangeAllowed: true,
                  isMtnChangeAllowed: true,
                  isMtnSuspendAllowed: true,
                  isPricePlanChangeAllowed: true,
                  pendingOrderDetail: null,
                },
                mobileInfoAttributes: {
                  paidInsuranceExist: false,
                  numberShareParent: '',
                  accountOwner: false,
                  accessRoles: null,
                  hasReferAFriend: false,
                },
                tradeInPromo: null,
                inServiceDate: null,
                lineSharingIndicator: '',
                lineAccessCharge: null,
                installmentLoans: [
                  {
                    deviceId: '357660160842795',
                    loanMonthlyPaymentAmount: '4.16',
                    edgeUpPrincipalAmountUnpaid: '0.00',
                    loanTransferEligibility: true,
                    loanAmount: '149.99',
                    paidAmountToDate: '58.47',
                    totalPrincipalAmountUnpaid: '91.52',
                    loanTermMonths: '36',
                    pendingNumberOfInstallments: 21,
                    daysLeftForNextEligibleUpgrade: 574,
                    paidAmountPercentage: '0.39',
                    edgeUpRequiredPercent: '100.00',
                    firstInstallmentAmount: '4.39',
                    loanNumber: '1803067785',
                    pastTradeInRestrictionTimePeriod: true,
                    displayKeepOption: true,
                    displayReturnOption: false,
                    deviceMismatch: false,
                    loanStatus: {
                      active: true,
                      buyout: true,
                      canceled: false,
                      earlyUpgrade: false,
                      edgeUp: false,
                      forceBuyout: false,
                      indirectPendingApproval: false,
                      indirectRejectedFinal: false,
                      indirectRejectedInitial: false,
                      indirectWaitingForFax: false,
                      paid: false,
                      pending: false,
                      reassign: false,
                      suspendedForMilitaryService: false,
                      transferedToAnotherLoan: false,
                      aol: false,
                    },
                  },
                ],
                earlyTermination: null,
                mobileInfoInsurance: {
                  insuranceId: '66332',
                  insuranceCategory: 'SFO',
                  insuranceName: 'DECLINE DEVICE PROTECTION',
                  insuranceType: 'MOBILE',
                  price: '0.00',
                },
                availableMTNsForLoanTransfer: { mtnDetails: [{ mtn: '5106028996' }, { mtn: '9492309926' }] },
                offers: null,
                recentPurchaseOrder: { purchasePrice: '149.99', retailPrice: '149.99' },
                marketingOption: { vzCCHolder: false },
                totalDueMonthly: null,
                planChangeHoldOrdersFound: null,
                mtnEffectiveDate: null,
                isEqpOrAccOfferAccepted: null,
                lineLevelCurrentCostData: {},
                networkBandwidthType: '',
                deviceMtnIndicator: '',
                showSUGToggle: true,
                balanceAmount: null,
                isNewLine: false,
                sharePlan: null,
                fiosEligibilityCategory: null,
                accountAddress: null,
                fwaRedeemDetails: null,
                showAddSecondNumTile: false,
                primaryNumber: false,
                secondaryNumber: false,
                secondNumberInfo: null,
                equipmentOrders: [{ statusCode: { isOpened: false } }],
                simFreezeInfo: null,
                whwSpoOffer: null,
                newLine: false,
              },
              {
                mtn: '9173493589',
                lineLevelServiceOffers: [],
                numberShare: null,
                mtnHashCode: '209daaab47501829fd97588b5925723765aa7c2e01453557a607e47e08b25e32',
                nickName: 'RAVI E SMITH-3589',
                benefitPair: {
                  pairedPhoneMtn: '9492309926',
                  eligibleToPair: false,
                  existingPair: false,
                  grantee: false,
                  grantor: false,
                },
                primaryUser: {
                  firstName: 'RAVI',
                  lastName: 'SMITH',
                  preferFirstName: null,
                  preferLastName: null,
                  preferPronoun: null,
                },
                primaryAddress: {
                  addressLine1: '2345 NEWPORT BLVD APT G204',
                  city: 'COSTA MESA',
                  state: 'CA',
                  zipCode: '92627',
                  countryCode: 'USA',
                },
                mtnStatus: {
                  isActive: true,
                  isDisconnected: false,
                  isReassignedAndInActive: false,
                  isSuspendedWithBilling: false,
                  isSuspendedWithoutBilling: false,
                  mtnSuspendAllowed: false,
                  isMtnSuspended: false,
                  mtnStatusReasonCode: '',
                  isMtnChanged: null,
                  isReassigned: null,
                  isTransfered: false,
                  isMtnNotEditable: false,
                  status: 'A',
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      deviceId: '354934255796874',
                      deviceSku: 'IPHONE15PROM-US',
                      deviceUrl:
                        'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-pro-max-256gb-black-titanium-mu663ll-a-a',
                      productDisplayName: 'iPhone 15 Pro Max NON VZW NA',
                      category: {
                        smartphone: true,
                        tablet: false,
                        basicphone: false,
                        connectedDevice: false,
                        internetDevice: false,
                        homePC: false,
                        telematics: false,
                        virtualDevice: false,
                        WSOnly: false,
                      },
                      tradeInValue: '',
                      displayName: 'IPHONE15 PROMAX GENERIC US',
                      capacity: null,
                      deviceType: {
                        backupRouter4G: null,
                        device4G: null,
                        device3G: null,
                        device5GA: false,
                        device5GE: true,
                        antenna5G: false,
                        home5G: false,
                        deviceType: '5GE',
                        home4GLte: false,
                      },
                      numberShareCapability: null,
                      cdmaRestrictedDevice: false,
                      fixedWirelessInfos: null,
                      pairedDeviceDetails: null,
                      router: false,
                      prodClass1: null,
                      multiMeterWave: false,
                      n77Band: null,
                      fwaDeviceCurrentStatus: null,
                      noOfDaysDeviceActiveInAccountFromToday: null,
                    },
                    simInfo: { simId: '89148000010805260312', simSku: 'UNIVESIM5G-SAB-S', skuType: null },
                  },
                ],
                pricePlanInfo: {
                  planId: '50432',
                  description: '5G DO MORE',
                  planDisplayName: null,
                  planImageUrl: null,
                  planCategoryName: 'UNLIMITED FOR ALL',
                  planCategoryCd: '67',
                  effectiveDate: null,
                  noOfDaysLeft: null,
                  trialEndDate: null,
                  planAttributes: {
                    sharePlan: false,
                    isJax: false,
                    isFelix: false,
                    hasStandardPlan: true,
                    hasSecondNumPlan: false,
                  },
                  accessCharge: null,
                  imageUrlMap: null,
                  planPromotions: null,
                  pearlTrialFlow: false,
                  suspendPearlEnabledFFlag: false,
                  trialEndDateOrThirtyDays: null,
                  trialEndDateOrFortyFiveDays: null,
                },
                currentSPOs: null,
                currentFeatures: [
                  {
                    sfoId: '48526',
                    description: 'TXT MSG W PER MSG CHARGES',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '48553',
                    description: 'STREAMLINED BILLING - $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68869',
                    description: 'CALLER ID',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68870',
                    description: 'BUSY TRANSFER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68871',
                    description: 'CONFERENCE CALLING',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/3way_Calling_012918',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68872',
                    description: 'CALL DELIVERY',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68873',
                    description: 'CALL WAITING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68874',
                    description: 'NO ANSWER TRANSFER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68876',
                    description: 'CALL FORWARDING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '73502',
                    description: 'UNL PICTURE/VIDEO MSG',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'MM' }],
                    existing: false,
                  },
                  {
                    sfoId: '73503',
                    description: 'UNL TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'SMALIN' }, { featureTypeCode: 'SMAL' }],
                    existing: false,
                  },
                  {
                    sfoId: '75706',
                    description: 'TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75802',
                    description: 'DYNAMIC-PRIVATE IP',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75836',
                    description: '4G INTERNET ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75837',
                    description: '4G APPLICATION ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '76404',
                    description: 'MOBILE HOTSPOT 4G PROVISIONING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '76600',
                    description: 'SHARE NAME ID $0.00',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Caller_ID_012918',
                    embeddedFeatures: [{ featureTypeCode: 'SEUN' }],
                    existing: false,
                  },
                  {
                    sfoId: '77556',
                    description: '4G PROVISIONING $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '77568',
                    description: 'EMAIL ACCESS PDA $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '79708',
                    description: 'VISUAL VOICEMAIL SPEC',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Voicemail_012918',
                    embeddedFeatures: [{ featureTypeCode: 'VMGE' }],
                    existing: false,
                  },
                  {
                    sfoId: '80148',
                    description: 'INTL MESSAGES WHILE IN US $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '81143',
                    description: 'ACCESS - ADVANCED CALLING $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '81158',
                    description: 'HD VOICE $0',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/HD_Voice_012918',
                    embeddedFeatures: [
                      { featureTypeCode: 'HDV' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                    ],
                    existing: false,
                  },
                  {
                    sfoId: '81186',
                    description: 'ACCESS - HD VOICE $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '83186',
                    description: 'ROAM ALTERNATE FEATURE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '83856',
                    description: 'CDMA-LESS DEVICE PROVISIONING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '84094',
                    description: 'INTL SERVICES ENABLED LITE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'IDLITE' }],
                    existing: false,
                  },
                  {
                    sfoId: '86189',
                    description: 'EMAIL AND WEB UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Data_012918',
                    embeddedFeatures: [
                      { featureTypeCode: '' },
                      { featureTypeCode: '1XKB' },
                      { featureTypeCode: 'DUNKB' },
                    ],
                    existing: false,
                  },
                  {
                    sfoId: '86209',
                    description: 'INCLUDE CANADA/MEXICO',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/International_Long_Distance_012918',
                    embeddedFeatures: [{ featureTypeCode: 'TAPIN' }, { featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '86211',
                    description: 'VERIZON CLOUD 600 GB INCL',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Cloud_012918',
                    embeddedFeatures: [{ featureTypeCode: 'VL9' }],
                    existing: false,
                  },
                  {
                    sfoId: '86848',
                    description: '4G SERVICE ON 5G DEVICE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '5GM4S' }],
                    existing: false,
                  },
                  {
                    sfoId: '88689',
                    description: 'VERIZON MOBILE PROTECT $19',
                    price: '19.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/device_protection_120817',
                    embeddedFeatures: [
                      { featureTypeCode: 'GURU' },
                      { featureTypeCode: '' },
                      { featureTypeCode: 'EXWAR' },
                      { featureTypeCode: 'INHS' },
                    ],
                    existing: false,
                  },
                  {
                    sfoId: '88882',
                    description: 'RTR 5G DO MORE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'RDI3' }, { featureTypeCode: 'RTRUDP' }],
                    existing: false,
                  },
                  {
                    sfoId: '88886',
                    description: 'RTR/UC TRIGGER 5G DO MORE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'TRGHX8' }],
                    existing: false,
                  },
                  {
                    sfoId: '88888',
                    description: 'ENTITLEMENT TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'TRGENT' }],
                    existing: false,
                  },
                  {
                    sfoId: '88889',
                    description: 'ENTITLEMENT FOR UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                    ],
                    existing: false,
                  },
                  {
                    sfoId: '88891',
                    description: 'MOBILE HOTSPOT 25GB',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'MHDTL' }],
                    existing: false,
                  },
                  {
                    sfoId: '88932',
                    description: 'VERIZON CLOUD TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '89405',
                    description: '5G CORE TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                ],
                addOnDueMonthly: null,
                equipmentUpgradeEligibility: {
                  upgradeEligible: true,
                  annualUpgradeEligible: true,
                  buyoutEligible: true,
                  earlyUpgradeEligible: false,
                  edgeUpEligible: true,
                  upgradeEligibilityDate: '06/29/2027',
                  upgradeEligibilityLabel: '$533.22 Eligible to upgrade early',
                  buyoutAmountLabel: 'Buyout $1133.22 + tax',
                  pendingOrderDetail: null,
                  isWithInWFGperiod: false,
                  isWFGPeriodWithIn90Days: false,
                  discountEligibility: { discountEligible: false, eligibilityLabel: 'NOT DISCOUNT ELIGIBLE' },
                  hadTwoBuyoutInCurrentMonth: false,
                  transferUpgradeEligibility: { giverEligible: false, takerEligible: false, takerMtns: [] },
                },
                lineLevelChangeEligibility: {
                  isDeviceOnlyChangeAllowed: true,
                  isFeatureChangeAllowed: true,
                  isLLBChangeAllowed: true,
                  isMtnChangeAllowed: true,
                  isMtnSuspendAllowed: true,
                  isPricePlanChangeAllowed: true,
                  pendingOrderDetail: null,
                },
                mobileInfoAttributes: {
                  paidInsuranceExist: false,
                  numberShareParent: '',
                  accountOwner: false,
                  accessRoles: null,
                  hasReferAFriend: false,
                },
                tradeInPromo: null,
                inServiceDate: null,
                lineSharingIndicator: 'L',
                lineAccessCharge: null,
                installmentLoans: [
                  {
                    deviceId: '354934255796874',
                    loanMonthlyPaymentAmount: '33.33',
                    edgeUpPrincipalAmountUnpaid: '533.22',
                    loanTransferEligibility: true,
                    loanAmount: '1199.99',
                    paidAmountToDate: '66.77',
                    totalPrincipalAmountUnpaid: '1133.22',
                    loanTermMonths: '36',
                    pendingNumberOfInstallments: 33,
                    daysLeftForNextEligibleUpgrade: 928,
                    paidAmountPercentage: '0.06',
                    edgeUpRequiredPercent: '50.00',
                    firstInstallmentAmount: '33.44',
                    loanNumber: '1333539209',
                    pastTradeInRestrictionTimePeriod: true,
                    displayKeepOption: true,
                    displayReturnOption: true,
                    deviceMismatch: false,
                    loanStatus: {
                      active: true,
                      buyout: true,
                      canceled: false,
                      earlyUpgrade: false,
                      edgeUp: false,
                      forceBuyout: false,
                      indirectPendingApproval: false,
                      indirectRejectedFinal: false,
                      indirectRejectedInitial: false,
                      indirectWaitingForFax: false,
                      paid: false,
                      pending: false,
                      reassign: false,
                      suspendedForMilitaryService: false,
                      transferedToAnotherLoan: false,
                      aol: false,
                    },
                  },
                ],
                earlyTermination: null,
                mobileInfoInsurance: {
                  insuranceId: '88689',
                  insuranceCategory: 'SFO',
                  insuranceName: 'VERIZON MOBILE PROTECT $19',
                  insuranceType: 'MOBILE',
                  price: '19.00',
                },
                availableMTNsForLoanTransfer: { mtnDetails: [{ mtn: '5106028996' }, { mtn: '9492309926' }] },
                offers: null,
                recentPurchaseOrder: { purchasePrice: '1199.99', retailPrice: '1199.99' },
                marketingOption: { vzCCHolder: false },
                totalDueMonthly: null,
                planChangeHoldOrdersFound: null,
                mtnEffectiveDate: null,
                isEqpOrAccOfferAccepted: null,
                lineLevelCurrentCostData: {},
                networkBandwidthType: '',
                deviceMtnIndicator: '',
                showSUGToggle: true,
                balanceAmount: null,
                isNewLine: false,
                sharePlan: null,
                fiosEligibilityCategory: null,
                accountAddress: null,
                fwaRedeemDetails: null,
                showAddSecondNumTile: false,
                primaryNumber: false,
                secondaryNumber: false,
                secondNumberInfo: null,
                equipmentOrders: [{ statusCode: { isOpened: false } }],
                simFreezeInfo: null,
                whwSpoOffer: null,
                newLine: false,
              },
              {
                mtn: '9492309926',
                lineLevelServiceOffers: [],
                numberShare: null,
                mtnHashCode: '2a59668f2b10786caa33038be7d6cc40011388f10d8ad3bf067bdf413925c17e',
                nickName: 'RAVI E SMITH-9926',
                benefitPair: {
                  pairedPhoneMtn: '9173493589',
                  eligibleToPair: false,
                  existingPair: false,
                  grantee: false,
                  grantor: false,
                },
                primaryUser: {
                  firstName: 'RAVI',
                  lastName: 'SMITH',
                  preferFirstName: null,
                  preferLastName: null,
                  preferPronoun: null,
                },
                primaryAddress: {
                  addressLine1: '2345 NEWPORT BLVD APT E108',
                  city: 'COSTA MESA',
                  state: 'CA',
                  zipCode: '92627',
                  countryCode: 'USA',
                },
                mtnStatus: {
                  isActive: true,
                  isDisconnected: false,
                  isReassignedAndInActive: false,
                  isSuspendedWithBilling: false,
                  isSuspendedWithoutBilling: false,
                  mtnSuspendAllowed: false,
                  isMtnSuspended: false,
                  mtnStatusReasonCode: '',
                  isMtnChanged: null,
                  isReassigned: null,
                  isTransfered: false,
                  isMtnNotEditable: false,
                  status: 'A',
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      deviceId: '358643099875994',
                      deviceSku: 'MTUJ2LL/A',
                      deviceUrl:
                        'https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA',
                      productDisplayName: 'Watch Series 4',
                      category: {
                        smartphone: false,
                        tablet: false,
                        basicphone: false,
                        connectedDevice: true,
                        internetDevice: false,
                        homePC: false,
                        telematics: false,
                        virtualDevice: false,
                        WSOnly: false,
                      },
                      tradeInValue: '',
                      displayName: 'Apple Watch Series 4, 40mm Gold Aluminum Case with Pink Sand Sport Band',
                      capacity: null,
                      deviceType: {
                        backupRouter4G: null,
                        device4G: null,
                        device3G: null,
                        device5GA: false,
                        device5GE: false,
                        antenna5G: false,
                        home5G: false,
                        deviceType: '4GE',
                        home4GLte: false,
                      },
                      numberShareCapability: null,
                      cdmaRestrictedDevice: false,
                      fixedWirelessInfos: null,
                      pairedDeviceDetails: null,
                      router: false,
                      prodClass1: null,
                      multiMeterWave: false,
                      n77Band: null,
                      fwaDeviceCurrentStatus: null,
                      noOfDaysDeviceActiveInAccountFromToday: null,
                    },
                    simInfo: { simId: '89148000004888472464', simSku: 'SOFTSIM-CMR-D', skuType: null },
                  },
                ],
                pricePlanInfo: {
                  planId: '18056',
                  description: 'NUMBER SHARE',
                  planDisplayName: null,
                  planImageUrl: null,
                  planCategoryName: 'UNLIMITED CONNECTED PLANS',
                  planCategoryCd: '88',
                  effectiveDate: null,
                  noOfDaysLeft: null,
                  trialEndDate: null,
                  planAttributes: {
                    sharePlan: false,
                    isJax: false,
                    isFelix: false,
                    hasStandardPlan: false,
                    hasSecondNumPlan: false,
                  },
                  accessCharge: null,
                  imageUrlMap: null,
                  planPromotions: null,
                  pearlTrialFlow: false,
                  suspendPearlEnabledFFlag: false,
                  trialEndDateOrThirtyDays: null,
                  trialEndDateOrFortyFiveDays: null,
                },
                currentSPOs: null,
                currentFeatures: [
                  {
                    sfoId: '48526',
                    description: 'TXT MSG W PER MSG CHARGES',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '48553',
                    description: 'STREAMLINED BILLING - $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68869',
                    description: 'CALLER ID',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68871',
                    description: 'CONFERENCE CALLING',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/3way_Calling_012918',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68872',
                    description: 'CALL DELIVERY',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68873',
                    description: 'CALL WAITING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '73502',
                    description: 'UNL PICTURE/VIDEO MSG',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'MM' }],
                    existing: false,
                  },
                  {
                    sfoId: '73503',
                    description: 'UNL TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'SMALIN' }, { featureTypeCode: 'SMAL' }],
                    existing: false,
                  },
                  {
                    sfoId: '73733',
                    description: 'DECLINE VOICE MAIL',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Voicemail_012918',
                    embeddedFeatures: [{ featureTypeCode: 'VMGE' }],
                    existing: false,
                  },
                  {
                    sfoId: '75706',
                    description: 'TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75802',
                    description: 'DYNAMIC-PRIVATE IP',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75836',
                    description: '4G INTERNET ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75837',
                    description: '4G APPLICATION ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75875',
                    description: 'USA ONLY NO DATA OUTSIDE US',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '77556',
                    description: '4G PROVISIONING $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '77568',
                    description: 'EMAIL ACCESS PDA $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '80148',
                    description: 'INTL MESSAGES WHILE IN US $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '82419',
                    description: 'ACCESS-WI-FI CALLING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '83856',
                    description: 'CDMA-LESS DEVICE PROVISIONING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '84215',
                    description: '4G VOICE $0',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/HD_Voice_012918',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '85464',
                    description: 'ENTITLEMENT $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '86201',
                    description: 'RTR/UC TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'TRGHX2' }],
                    existing: false,
                  },
                  {
                    sfoId: '86202',
                    description: 'RTR FOR UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'RTRUDP' }],
                    existing: false,
                  },
                  {
                    sfoId: '86216',
                    description: 'UNLIMITED DATA',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '1XKB' }],
                    existing: false,
                  },
                  {
                    sfoId: '86330',
                    description: 'ENTITLEMENT FOR UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                    ],
                    existing: false,
                  },
                ],
                addOnDueMonthly: null,
                equipmentUpgradeEligibility: {
                  upgradeEligible: true,
                  annualUpgradeEligible: false,
                  buyoutEligible: false,
                  earlyUpgradeEligible: false,
                  edgeUpEligible: false,
                  upgradeEligibilityDate: '12/25/2018',
                  upgradeEligibilityLabel: 'Upgrade Now - Not Transferable',
                  buyoutAmountLabel: null,
                  pendingOrderDetail: null,
                  isWithInWFGperiod: false,
                  isWFGPeriodWithIn90Days: false,
                  discountEligibility: { discountEligible: true, eligibilityLabel: 'DISCOUNT ELIGIBLE' },
                  hadTwoBuyoutInCurrentMonth: false,
                  transferUpgradeEligibility: { giverEligible: false, takerEligible: false, takerMtns: [] },
                },
                lineLevelChangeEligibility: {
                  isDeviceOnlyChangeAllowed: true,
                  isFeatureChangeAllowed: true,
                  isLLBChangeAllowed: true,
                  isMtnChangeAllowed: true,
                  isMtnSuspendAllowed: true,
                  isPricePlanChangeAllowed: true,
                  pendingOrderDetail: null,
                },
                mobileInfoAttributes: {
                  paidInsuranceExist: false,
                  numberShareParent: '9173493589',
                  accountOwner: false,
                  accessRoles: null,
                  hasReferAFriend: false,
                },
                tradeInPromo: null,
                inServiceDate: null,
                lineSharingIndicator: 'R',
                lineAccessCharge: null,
                installmentLoans: [],
                earlyTermination: null,
                mobileInfoInsurance: {},
                availableMTNsForLoanTransfer: {},
                offers: null,
                recentPurchaseOrder: null,
                marketingOption: { vzCCHolder: false },
                totalDueMonthly: null,
                planChangeHoldOrdersFound: null,
                mtnEffectiveDate: null,
                isEqpOrAccOfferAccepted: null,
                lineLevelCurrentCostData: {},
                networkBandwidthType: '',
                deviceMtnIndicator: '',
                showSUGToggle: true,
                balanceAmount: null,
                isNewLine: false,
                sharePlan: null,
                fiosEligibilityCategory: null,
                accountAddress: null,
                fwaRedeemDetails: null,
                showAddSecondNumTile: false,
                primaryNumber: false,
                secondaryNumber: false,
                secondNumberInfo: null,
                equipmentOrders: [],
                simFreezeInfo: null,
                whwSpoOffer: null,
                newLine: false,
              },
              {
                mtn: '9492395813',
                lineLevelServiceOffers: [],
                numberShare: null,
                mtnHashCode: '2329f1726c5aab207fa5e6a9f98d579fb945ee0dbebf42ecfdd67a27f4c8fb94',
                nickName: 'RAVI E SMITH-5813',
                benefitPair: {
                  pairedPhoneMtn: null,
                  eligibleToPair: false,
                  existingPair: false,
                  grantee: false,
                  grantor: false,
                },
                primaryUser: {
                  firstName: 'RAVI',
                  lastName: 'SMITH',
                  preferFirstName: null,
                  preferLastName: null,
                  preferPronoun: null,
                },
                primaryAddress: { addressLine1: null, city: null, state: null, zipCode: null, countryCode: null },
                mtnStatus: {
                  isActive: false,
                  isDisconnected: true,
                  isReassignedAndInActive: false,
                  isSuspendedWithBilling: false,
                  isSuspendedWithoutBilling: false,
                  mtnSuspendAllowed: false,
                  isMtnSuspended: false,
                  mtnStatusReasonCode: 'LL',
                  isMtnChanged: null,
                  isReassigned: null,
                  isTransfered: false,
                  isMtnNotEditable: false,
                  status: 'D',
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      deviceId: '868312040894222',
                      deviceSku: 'ZW20P',
                      deviceUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/zte-gizmowatch-pink',
                      productDisplayName: 'GizmoWatch 2',
                      category: {
                        smartphone: false,
                        tablet: false,
                        basicphone: false,
                        connectedDevice: true,
                        internetDevice: false,
                        homePC: false,
                        telematics: false,
                        virtualDevice: false,
                        WSOnly: false,
                      },
                      tradeInValue: '',
                      displayName: 'Verizon GizmoWatch 2 in Pink',
                      capacity: null,
                      deviceType: {
                        backupRouter4G: null,
                        device4G: null,
                        device3G: null,
                        device5GA: false,
                        device5GE: false,
                        antenna5G: false,
                        home5G: false,
                        deviceType: '4GE',
                        home4GLte: false,
                      },
                      numberShareCapability: null,
                      cdmaRestrictedDevice: false,
                      fixedWirelessInfos: null,
                      pairedDeviceDetails: null,
                      router: false,
                      prodClass1: null,
                      multiMeterWave: false,
                      n77Band: null,
                      fwaDeviceCurrentStatus: null,
                      noOfDaysDeviceActiveInAccountFromToday: null,
                    },
                    simInfo: { simId: '89148000006278303514', simSku: 'NI-DPSIM', skuType: null },
                  },
                ],
                pricePlanInfo: {
                  planId: null,
                  description: null,
                  planDisplayName: null,
                  planImageUrl: null,
                  planCategoryName: null,
                  planCategoryCd: null,
                  effectiveDate: null,
                  noOfDaysLeft: null,
                  trialEndDate: null,
                  planAttributes: null,
                  accessCharge: null,
                  imageUrlMap: null,
                  planPromotions: null,
                  pearlTrialFlow: false,
                  suspendPearlEnabledFFlag: false,
                  trialEndDateOrThirtyDays: null,
                  trialEndDateOrFortyFiveDays: null,
                },
                currentSPOs: null,
                currentFeatures: [],
                addOnDueMonthly: null,
                equipmentUpgradeEligibility: {
                  upgradeEligible: false,
                  annualUpgradeEligible: false,
                  buyoutEligible: false,
                  earlyUpgradeEligible: false,
                  edgeUpEligible: false,
                  upgradeEligibilityDate: null,
                  upgradeEligibilityLabel: 'Upgrade Now - Not Transferable',
                  buyoutAmountLabel: null,
                  pendingOrderDetail: null,
                  isWithInWFGperiod: false,
                  isWFGPeriodWithIn90Days: false,
                  discountEligibility: { discountEligible: true, eligibilityLabel: 'DISCOUNT ELIGIBLE' },
                  hadTwoBuyoutInCurrentMonth: false,
                  transferUpgradeEligibility: { giverEligible: false, takerEligible: false, takerMtns: [] },
                },
                lineLevelChangeEligibility: {
                  isDeviceOnlyChangeAllowed: false,
                  isFeatureChangeAllowed: false,
                  isLLBChangeAllowed: false,
                  isMtnChangeAllowed: false,
                  isMtnSuspendAllowed: false,
                  isPricePlanChangeAllowed: false,
                  pendingOrderDetail: null,
                },
                mobileInfoAttributes: {
                  paidInsuranceExist: false,
                  numberShareParent: '',
                  accountOwner: false,
                  accessRoles: null,
                  hasReferAFriend: false,
                },
                tradeInPromo: null,
                inServiceDate: null,
                lineSharingIndicator: '',
                lineAccessCharge: null,
                installmentLoans: [],
                earlyTermination: null,
                mobileInfoInsurance: {},
                availableMTNsForLoanTransfer: {},
                offers: null,
                recentPurchaseOrder: null,
                marketingOption: { vzCCHolder: false },
                totalDueMonthly: null,
                planChangeHoldOrdersFound: null,
                mtnEffectiveDate: null,
                isEqpOrAccOfferAccepted: null,
                lineLevelCurrentCostData: {},
                networkBandwidthType: '',
                deviceMtnIndicator: '',
                showSUGToggle: true,
                balanceAmount: null,
                isNewLine: false,
                sharePlan: null,
                fiosEligibilityCategory: null,
                accountAddress: null,
                fwaRedeemDetails: null,
                showAddSecondNumTile: false,
                primaryNumber: false,
                secondaryNumber: false,
                secondNumberInfo: null,
                equipmentOrders: [],
                simFreezeInfo: null,
                whwSpoOffer: null,
                newLine: false,
              },
              {
                mtn: '9492446182',
                lineLevelServiceOffers: [],
                numberShare: null,
                mtnHashCode: '4d5b6675674dcd79e4825b65ec60a4d9faade024c1c28d396f2431e927a13c51',
                nickName: 'RAVI E SMITH-6182',
                benefitPair: {
                  pairedPhoneMtn: null,
                  eligibleToPair: false,
                  existingPair: false,
                  grantee: false,
                  grantor: false,
                },
                primaryUser: {
                  firstName: 'RAVI',
                  lastName: 'SMITH',
                  preferFirstName: null,
                  preferLastName: null,
                  preferPronoun: null,
                },
                primaryAddress: {
                  addressLine1: '2345 NEWPORT BLVD APT G204',
                  city: 'COSTA MESA',
                  state: 'CA',
                  zipCode: '92627',
                  countryCode: 'USA',
                },
                mtnStatus: {
                  isActive: true,
                  isDisconnected: false,
                  isReassignedAndInActive: false,
                  isSuspendedWithBilling: false,
                  isSuspendedWithoutBilling: false,
                  mtnSuspendAllowed: false,
                  isMtnSuspended: false,
                  mtnStatusReasonCode: '',
                  isMtnChanged: null,
                  isReassigned: null,
                  isTransfered: false,
                  isMtnNotEditable: false,
                  status: 'A',
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      deviceId: '355549915850157',
                      deviceSku: 'MPUN3LL/A',
                      deviceUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-starlight-fall22-a',
                      productDisplayName: 'iPhone 14',
                      category: {
                        smartphone: true,
                        tablet: false,
                        basicphone: false,
                        connectedDevice: false,
                        internetDevice: false,
                        homePC: false,
                        telematics: false,
                        virtualDevice: false,
                        WSOnly: false,
                      },
                      tradeInValue: '',
                      displayName: 'Apple iPhone 14 128GB in Starlight',
                      capacity: null,
                      deviceType: {
                        backupRouter4G: null,
                        device4G: null,
                        device3G: null,
                        device5GA: false,
                        device5GE: true,
                        antenna5G: false,
                        home5G: false,
                        deviceType: '5GE',
                        home4GLte: false,
                      },
                      numberShareCapability: null,
                      cdmaRestrictedDevice: false,
                      fixedWirelessInfos: null,
                      pairedDeviceDetails: [
                        {
                          pairedImei: '355549915207580',
                          pairedImeiMtn: '',
                          isPairedImeiActive: false,
                          isPairedMTNSameAccount: false,
                        },
                      ],
                      router: false,
                      prodClass1: null,
                      multiMeterWave: false,
                      n77Band: null,
                      fwaDeviceCurrentStatus: null,
                      noOfDaysDeviceActiveInAccountFromToday: null,
                    },
                    simInfo: { simId: '89148000010807925276', simSku: 'UNIVESIM5G-SA-S', skuType: null },
                  },
                ],
                pricePlanInfo: {
                  planId: '63215',
                  description: 'UNLIMITED WELCOME',
                  planDisplayName: null,
                  planImageUrl: null,
                  planCategoryName: 'MY PLAN',
                  planCategoryCd: '92',
                  effectiveDate: null,
                  noOfDaysLeft: null,
                  trialEndDate: null,
                  planAttributes: {
                    sharePlan: false,
                    isJax: false,
                    isFelix: false,
                    hasStandardPlan: true,
                    hasSecondNumPlan: false,
                  },
                  accessCharge: null,
                  imageUrlMap: null,
                  planPromotions: null,
                  pearlTrialFlow: false,
                  suspendPearlEnabledFFlag: false,
                  trialEndDateOrThirtyDays: null,
                  trialEndDateOrFortyFiveDays: null,
                },
                currentSPOs: null,
                currentFeatures: [
                  {
                    sfoId: '48526',
                    description: 'TXT MSG W PER MSG CHARGES',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '48553',
                    description: 'STREAMLINED BILLING - $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68869',
                    description: 'CALLER ID',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68870',
                    description: 'BUSY TRANSFER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68871',
                    description: 'CONFERENCE CALLING',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/3way_Calling_012918',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68872',
                    description: 'CALL DELIVERY',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68873',
                    description: 'CALL WAITING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68874',
                    description: 'NO ANSWER TRANSFER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '68876',
                    description: 'CALL FORWARDING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '73502',
                    description: 'UNL PICTURE/VIDEO MSG',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'MM' }],
                    existing: false,
                  },
                  {
                    sfoId: '73503',
                    description: 'UNL TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    embeddedFeatures: [{ featureTypeCode: 'SMALIN' }, { featureTypeCode: 'SMAL' }],
                    existing: false,
                  },
                  {
                    sfoId: '75622',
                    description: '4G DATA TRANSPORT',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75706',
                    description: 'TEXT MESSAGING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75802',
                    description: 'DYNAMIC-PRIVATE IP',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75836',
                    description: '4G INTERNET ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '75837',
                    description: '4G APPLICATION ACCESS',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '77568',
                    description: 'EMAIL ACCESS PDA $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '78485',
                    description: 'BLOCK MOBILE HOTSPOT',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '79708',
                    description: 'VISUAL VOICEMAIL SPEC',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Voicemail_012918',
                    embeddedFeatures: [{ featureTypeCode: 'VMGE' }],
                    existing: false,
                  },
                  {
                    sfoId: '80148',
                    description: 'INTL MESSAGES WHILE IN US $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '81143',
                    description: 'ACCESS - ADVANCED CALLING $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '81158',
                    description: 'HD VOICE $0',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/HD_Voice_012918',
                    embeddedFeatures: [
                      { featureTypeCode: 'HDV' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                    ],
                    existing: false,
                  },
                  {
                    sfoId: '81186',
                    description: 'ACCESS - HD VOICE $0',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '83186',
                    description: 'ROAM ALTERNATE FEATURE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '83856',
                    description: 'CDMA-LESS DEVICE PROVISIONING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '84094',
                    description: 'INTL SERVICES ENABLED LITE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'IDLITE' }],
                    existing: false,
                  },
                  {
                    sfoId: '85553',
                    description: 'VERIZON CLOUD ELIGIBLE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Cloud_012918',
                    embeddedFeatures: [{ featureTypeCode: 'VLX' }],
                    existing: false,
                  },
                  {
                    sfoId: '86189',
                    description: 'EMAIL AND WEB UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Data_012918',
                    embeddedFeatures: [
                      { featureTypeCode: '' },
                      { featureTypeCode: '1XKB' },
                      { featureTypeCode: 'DUNKB' },
                    ],
                    existing: false,
                  },
                  {
                    sfoId: '86209',
                    description: 'INCLUDE CANADA/MEXICO',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/International_Long_Distance_012918',
                    embeddedFeatures: [{ featureTypeCode: 'TAPIN' }, { featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '86848',
                    description: '4G SERVICE ON 5G DEVICE',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '5GM4S' }],
                    existing: false,
                  },
                  {
                    sfoId: '86905',
                    description: 'GSM ROAMING PRIORITY',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '88689',
                    description: 'VERIZON MOBILE PROTECT $19',
                    price: '19.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/device_protection_120817',
                    embeddedFeatures: [
                      { featureTypeCode: 'GURU' },
                      { featureTypeCode: '' },
                      { featureTypeCode: 'EXWAR' },
                      { featureTypeCode: 'INHS' },
                    ],
                    existing: false,
                  },
                  {
                    sfoId: '89405',
                    description: '5G CORE TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: '' }],
                    existing: false,
                  },
                  {
                    sfoId: '89668',
                    description: 'TEXT BLOCK ALLOW TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'SMSTRG' }],
                    existing: false,
                  },
                  {
                    sfoId: '89670',
                    description: 'ENTITLEMENT FOR UNLIMITED',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                      { featureTypeCode: '' },
                    ],
                    existing: false,
                  },
                  {
                    sfoId: '89671',
                    description: 'RTR/UC TRIGGER',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'TRGBY1' }],
                    existing: false,
                  },
                  {
                    sfoId: '89673',
                    description: 'RTR PROVISIONING',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    embeddedFeatures: [{ featureTypeCode: 'RDI3' }, { featureTypeCode: 'RTRUDP' }],
                    existing: false,
                  },
                ],
                addOnDueMonthly: null,
                equipmentUpgradeEligibility: {
                  upgradeEligible: true,
                  annualUpgradeEligible: false,
                  buyoutEligible: true,
                  earlyUpgradeEligible: false,
                  edgeUpEligible: false,
                  upgradeEligibilityDate: '06/29/2027',
                  upgradeEligibilityLabel: '$689.18 to Upgrade',
                  buyoutAmountLabel: 'Buyout $689.18 + tax',
                  pendingOrderDetail: null,
                  isWithInWFGperiod: false,
                  isWFGPeriodWithIn90Days: false,
                  discountEligibility: { discountEligible: false, eligibilityLabel: 'NOT DISCOUNT ELIGIBLE' },
                  hadTwoBuyoutInCurrentMonth: false,
                  transferUpgradeEligibility: { giverEligible: false, takerEligible: false, takerMtns: [] },
                },
                lineLevelChangeEligibility: {
                  isDeviceOnlyChangeAllowed: true,
                  isFeatureChangeAllowed: true,
                  isLLBChangeAllowed: true,
                  isMtnChangeAllowed: true,
                  isMtnSuspendAllowed: true,
                  isPricePlanChangeAllowed: true,
                  pendingOrderDetail: null,
                },
                mobileInfoAttributes: {
                  paidInsuranceExist: false,
                  numberShareParent: '',
                  accountOwner: false,
                  accessRoles: null,
                  hasReferAFriend: false,
                },
                tradeInPromo: null,
                inServiceDate: null,
                lineSharingIndicator: '',
                lineAccessCharge: null,
                installmentLoans: [
                  {
                    deviceId: '355549915850157',
                    loanMonthlyPaymentAmount: '20.27',
                    edgeUpPrincipalAmountUnpaid: '0.00',
                    loanTransferEligibility: true,
                    loanAmount: '729.99',
                    paidAmountToDate: '40.81',
                    totalPrincipalAmountUnpaid: '689.18',
                    loanTermMonths: '36',
                    pendingNumberOfInstallments: 33,
                    daysLeftForNextEligibleUpgrade: 928,
                    paidAmountPercentage: '0.06',
                    edgeUpRequiredPercent: '100.00',
                    firstInstallmentAmount: '20.54',
                    loanNumber: '1333539210',
                    pastTradeInRestrictionTimePeriod: true,
                    displayKeepOption: true,
                    displayReturnOption: false,
                    deviceMismatch: false,
                    loanStatus: {
                      active: true,
                      buyout: true,
                      canceled: false,
                      earlyUpgrade: false,
                      edgeUp: false,
                      forceBuyout: false,
                      indirectPendingApproval: false,
                      indirectRejectedFinal: false,
                      indirectRejectedInitial: false,
                      indirectWaitingForFax: false,
                      paid: false,
                      pending: false,
                      reassign: false,
                      suspendedForMilitaryService: false,
                      transferedToAnotherLoan: false,
                      aol: false,
                    },
                  },
                ],
                earlyTermination: null,
                mobileInfoInsurance: {
                  insuranceId: '88689',
                  insuranceCategory: 'SFO',
                  insuranceName: 'VERIZON MOBILE PROTECT $19',
                  insuranceType: 'MOBILE',
                  price: '19.00',
                },
                availableMTNsForLoanTransfer: { mtnDetails: [{ mtn: '5106028996' }, { mtn: '9492309926' }] },
                offers: null,
                recentPurchaseOrder: { purchasePrice: '729.99', retailPrice: '729.99' },
                marketingOption: { vzCCHolder: false },
                totalDueMonthly: null,
                planChangeHoldOrdersFound: null,
                mtnEffectiveDate: null,
                isEqpOrAccOfferAccepted: null,
                lineLevelCurrentCostData: {},
                networkBandwidthType: '',
                deviceMtnIndicator: '',
                showSUGToggle: true,
                balanceAmount: null,
                isNewLine: false,
                sharePlan: null,
                fiosEligibilityCategory: null,
                accountAddress: null,
                fwaRedeemDetails: null,
                showAddSecondNumTile: true,
                primaryNumber: false,
                secondaryNumber: false,
                secondNumberInfo: null,
                equipmentOrders: [{ statusCode: { isOpened: false } }],
                simFreezeInfo: null,
                whwSpoOffer: null,
                newLine: false,
              },
            ],
            fiosEligibilityCategory: null,
            accountAddress: {
              addressLine1: '2345 NEWPORT BLVD APT G204',
              addressLine2: '',
              city: 'COSTA MESA',
              state: 'CA',
              zipCode: '92627',
              fipsCode: '0605916532',
              geoCode: 'USA06059165320',
              zipCodePlus4: '1833',
              scrubbedAddress: {
                streetName: 'NEWPORT',
                streetNumber: '2345',
                streetType: 'BLVD',
                streetDirection: '',
                apartmentNo: 'G204',
                pobox: '',
                ruralDeliveryNo: '',
                ruralRouteNo: '',
                city: 'COSTA MESA',
                state: 'CA',
                zipCode: '92627',
                zipCodePlus4: '6527',
              },
            },
            establishedDate: '12/11/2012',
            establishedInLastThirtyDays: false,
            contactInfo: { decline: false, declineReasonCode: '' },
            vzwVztCustomerInfo: {
              totalDiscountAmountMH: null,
              perlineDiscountMH: null,
              discountAppliedMH: null,
              discountVersionMH: null,
              tenDollarMNHDiscount: null,
              fiveDollarMNHDiscount: null,
              fiosBonusDiscount: null,
              vzwBonusDiscount: null,
              subtotalBaseAmountMH: null,
              bonusDiscountMNH: null,
              vztAccountInfo: [],
            },
            accountSubscriptions: { lineLevelSubscriptions: [] },
          },
        ],
        customerCbrInfo: { cbrNos: [{ phoneNumber: '2866726432' }, { phoneNumber: '2866726432' }] },
        isSalesRepIdMismatch: false,
        accountNo: '0787408248-00001',
        repId: 'ENC',
        loggedInUser: 'mangva5',
        channel: 'OMNI-CARE',
        orderLocationCode: 'P332201',
        orderNumber: '0',
        homeLocationCode: 'P332201',
        regNo: '01',
        isComboOrderAllowed: false,
        isFWASimplificationEnabled: false,
        storeLocationState: 'NC',
        repSecurityClassCode: '00000007',
        homeSalesAddressList: [],
        isAsurionExpansionEnabled: false,
        secondNumPlanExists: false,
        featureFlags: {},
      },
      equipmentInfo: {
        deviceInfo: {
          deviceId: '356371486088359',
          deviceSku: 'IPHONE15PROM-US-2',
          deviceUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/DU-fallback-smartphone-03152023',
          productDisplayName: 'iPhone 15 Pro Max NON VZW NA-2',
          category: {
            smartphone: true,
            tablet: false,
            basicphone: false,
            connectedDevice: false,
            internetDevice: false,
            homePC: false,
            telematics: false,
            virtualDevice: false,
            WSOnly: false,
          },
          tradeInValue: '',
          displayName: 'IPHONE15 PROMAX GENERIC US-2',
          capacity: null,
          deviceType: {
            backupRouter4G: null,
            device4G: null,
            device3G: null,
            device5GA: false,
            device5GE: true,
            antenna5G: false,
            home5G: false,
            deviceType: '5GE',
            home4GLte: false,
          },
          numberShareCapability: null,
          cdmaRestrictedDevice: false,
          fixedWirelessInfos: null,
          pairedDeviceDetails: null,
          router: false,
          prodClass1: null,
          multiMeterWave: false,
          n77Band: null,
          fwaDeviceCurrentStatus: null,
          noOfDaysDeviceActiveInAccountFromToday: null,
        },
        simInfo: { simId: '89148000009710862519', simSku: 'UNIVESIM5G-SAB-S', skuType: null },
      },
    });
    expect(Object.keys(payload).length).toBeGreaterThan(0);
  });
});

describe('getBestBuyPricingDetails', () => {
  let originalVzdl;

  beforeEach(() => {
    originalVzdl = window.vzdl;
    window.vzdl = {};
  });

  afterEach(() => {
    window.vzdl = originalVzdl;
  });

  test('should clear event value if event exists', () => {
    const result = getBestBuyPricingDetails('223', '281', 'qwiruqiryqeiuryq');
    expect(result).toBe(undefined);
  });
  test('should clear event value if event exists', () => {
    const result = getBestBuyPricingDetails('223', '0281', 'qwiruqiryqeiuryq');
    expect(result).toBe(undefined);
  });
  test('should clear event value if event exists', () => {
    const result = getBestBuyPricingDetails('223', null, 'qwiruqiryqeiuryq');
    expect(result).toBe(undefined);
  });
  test('tes isFraudRiskApiEnabledForDeviceChange function', () => {
    expect(
      isFraudRiskApiEnabledForDeviceChange({ simSwapNotify: 'n', enableEnforceApi: 'n', isSecureSimSwap: 'Y' })
    ).toBeTruthy();
    expect(
      isFraudRiskApiEnabledForDeviceChange({ simSwapNotify: 'y', enableEnforceApi: 'y', isSecureSimSwap: 'N' })
    ).toBeFalsy();
  });
  test('tes isFraudRiskApiEnabledForDeviceChange function', () => {
    sessionStorage.setItem('enableSimValidation', 'true');
    expect(isFraudRiskApiEnabledForDeviceChange({ simSwapNotify: 'n', enableEnforceApi: 'n' })).toBeFalsy();
  });
});

describe('getAdobeSubKeyContract', () => {
  beforeEach(() => {
    sessionStorage.clear();
  });

  it('should return an empty object when fFlag is false', () => {
    const result = getAdobeSubKeyContract(false);
    expect(result).toEqual({});
  });

  it('should return an empty object when fFlag is true and sessionStorage is empty', () => {
    const result = getAdobeSubKeyContract(true);
    expect(result).toEqual({});
  });

  it('should return an object with adobeSubkey when fFlag is true and sessionStorage has a value', () => {
    sessionStorage.setItem('adobe-sessionId', 'test-session-id');
    const result = getAdobeSubKeyContract(true);
    expect(result).toEqual({ adobeSubkey: 'test-session-id' });
  });
});

describe('isRefundExcahngeFlow', () => {
  beforeEach(() => {
    // Clear all mocks before each test
    jest.clearAllMocks();
  });

  it('should return true when both refundexchange and refexRedesignGwScanFFlag are true', () => {
    sessionStorage.setItem('refundexchange', 'TRUE');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ refexRedesignGwScanFFlag: true }));
    expect(isRefundExcahngeFlow()).toBe(true);
  });

  it('should return false when refundexchange is true but refexRedesignGwScanFFlag is false', () => {
    sessionStorage.setItem('refundexchange', 'TRUE');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ refexRedesignGwScanFFlag: false }));
    expect(isRefundExcahngeFlow()).toBe(false);
  });

  it('should return false when refundexchange is false and refexRedesignGwScanFFlag is true', () => {
    sessionStorage.setItem('refundexchange', 'false');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ refexRedesignGwScanFFlag: true }));
    expect(isRefundExcahngeFlow()).toBe(false);
  });
});

describe('refundExchangeFlowIntent', () => {
  beforeEach(() => {
    // Clear all mocks before each test
    jest.clearAllMocks();
  });

  it('should return true when both refundexchange and refundExchangeFlowIntent are true', () => {
    sessionStorage.setItem('refundexchange', 'TRUE');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ refexRedesignGwScanFFlag: true }));
    expect(refundExchangeFlowIntent()).toBe('REX');
  });

  it('should return false when refundexchange is true but refexRedesignGwScanFFlag is false', () => {
    sessionStorage.setItem('refundexchange', 'TRUE');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ refexRedesignGwScanFFlag: false }));
    expect(refundExchangeFlowIntent('EUP')).toBe('EUP');
  });
});

describe('hasISPUAndLocalConflict', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Feature Flag Gating', () => {
    it('should return false when feature flag is disabled (undefined)', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, undefined);
      expect(result).toBe(false);
    });

    it('should return false when feature flag is explicitly "false"', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'false');
      expect(result).toBe(false);
    });

    it('should return false when feature flag is "FALSE" (case insensitive)', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'FALSE');
      expect(result).toBe(false);
    });

    it('should return false when channel is not indirect (direct channel)', () => {
      // Mock isIndirect to return false (direct channel)
      jest.spyOn(DomService, 'isIndirect').mockReturnValue(false);

      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false);

      // Restore mock
      jest.restoreAllMocks();
    });
  });

  describe('Conflict Detection', () => {
    it('should return false when cart has only ISPU item with depletionType L (ISPU uses local inventory — not a conflict)', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [
                        {
                          cartItemType: 'DEVICE',
                          itemCode: 'MTLV3LL/A',
                        },
                      ],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should return true when cart has both an ISPU item and a non-ISPU Local item (real conflict)', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                mobileNumber: '1234567890',
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE', itemCode: 'MTLV3LL/A' }],
                    },
                  },
                ],
              },
              {
                mobileNumber: '0987654321',
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE', itemCode: 'MU683LL/A' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(true);
    });

    it('should return false for only ISPU items (case insensitive flag "TRUE") — not a conflict', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'TRUE');
      expect(result).toBe(false);
    });

    it('should return false when ISPU line has multiple cart items with depletionType L — ISPU uses local inventory, not a conflict', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'SIM' }, { cartItemType: 'DEVICE' }, { cartItemType: 'WARRANTY' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should return true when multiple lines exist with real conflict: one ISPU and one non-ISPU Local', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                mobileNumber: '1234567890',
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
              {
                mobileNumber: '0987654321',
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(true);
    });

    it('should return false when multiple lines exist and ALL are ISPU with depletionType L — the defect scenario', () => {
      // Regression test: both devices added as ISPU should NOT trigger the conflict banner
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                mobileNumber: '1234567890',
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
              {
                mobileNumber: '0987654321',
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false);
    });
  });

  describe('No Conflict Scenarios', () => {
    it('should return false when depletionType is L but ispuItem is false', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should return false when ispuItem is true but depletionType is F', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'F',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should return false when ispuItem is true but depletionType is O', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'O',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should return false when cart has only Local items (no ISPU)', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }, { cartItemType: 'SIM' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should return false when cart has only ISPU items (no Local)', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'F',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false);
    });
  });

  describe('Edge Cases and Error Handling', () => {
    it('should return false when cartDetails is undefined', () => {
      const result = hasISPUAndLocalConflict(undefined, 'true');
      expect(result).toBe(false);
    });

    it('should return false when cartDetails is null', () => {
      const result = hasISPUAndLocalConflict(null, 'true');
      expect(result).toBe(false);
    });

    it('should return false when cart is empty object', () => {
      const result = hasISPUAndLocalConflict({}, 'true');
      expect(result).toBe(false);
    });

    it('should return false when lineInfo is empty array', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should return false when lineInfo is undefined', () => {
      const mockCart = {
        cart: {
          lineDetails: {},
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should return false when itemsInfo is empty array', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                itemsInfo: [],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should return false when itemsInfo is undefined (tests OR fallback to [])', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                // itemsInfo is undefined - tests: line?.itemsInfo || []
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should return false when itemsInfo is null (tests OR fallback to [])', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                itemsInfo: null, // tests: line?.itemsInfo || []
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should return false when line object has no itemsInfo property (tests OR fallback)', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                mobileNumber: '1234567890',
                // no itemsInfo property at all - tests OR fallback
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should return false when cartItems is empty array', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false); // ispuItem=true = ISPU line, not a Local order — no conflict
    });

    it('should return false when cartItem is undefined (tests OR fallback to [])', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      // cartItem is undefined - tests: item?.cartItems?.cartItem || []
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false); // ispuItem=true = ISPU line, not a Local order — no conflict
    });

    it('should return false when cartItem is null (tests OR fallback to [])', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: null, // tests: item?.cartItems?.cartItem || []
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false); // ispuItem=true = ISPU line, not a Local order — no conflict
    });

    it('should return false when cartItems object is missing cartItem property (tests OR fallback)', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      // no cartItem property - tests OR fallback
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false); // ispuItem=true = ISPU line, not a Local order — no conflict
    });

    it('should return false when ispuItem is undefined', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                // ispuItem is undefined at line level
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should handle malformed cart structure gracefully', () => {
      const mockCart = {
        cart: {
          lineDetails: 'invalid',
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should not throw error when accessing deeply nested undefined properties', () => {
      const mockCart = {
        cart: undefined,
      };
      expect(() => {
        hasISPUAndLocalConflict(mockCart, 'true');
      }).not.toThrow();
    });

    it('should handle errors gracefully and return false when exception is thrown', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                get itemsInfo() {
                  throw new Error('Test error in itemsInfo getter');
                },
              },
            ],
          },
        },
      };
      const consoleSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false);
      expect(consoleSpy).toHaveBeenCalledWith('Error in hasISPUAndLocalConflict:', expect.any(Error));
      consoleSpy.mockRestore();
    });

    it('should handle errors in nested property access and return false', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            get lineInfo() {
              throw new Error('Test error in lineInfo getter');
            },
          },
        },
      };
      const consoleSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false);
      expect(consoleSpy).toHaveBeenCalledWith('Error in hasISPUAndLocalConflict:', expect.any(Error));
      consoleSpy.mockRestore();
    });

    it('should catch and log error when depletionType access throws exception', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: true,
                itemsInfo: [
                  {
                    get depletionType() {
                      throw new Error('Test error in depletionType getter');
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const consoleSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false);
      expect(consoleSpy).toHaveBeenCalledWith('Error in hasISPUAndLocalConflict:', expect.any(Error));
      consoleSpy.mockRestore();
    });
  });

  describe('Real-world Scenarios', () => {
    it('should handle complex cart with a single ISPU line correctly — ISPU uses local inventory, no conflict', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                mobileNumber: '3176057199',
                lineActivityType: 'EUP',
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [
                        {
                          cartItemType: 'DEVICE',
                          itemCode: 'MTLV3LL/A',
                          description: 'iPhone 15',
                        },
                        {
                          cartItemType: 'SIM',
                          itemCode: 'UNIVESIM5G-SAB-D',
                        },
                        {
                          cartItemType: 'WARRANTY',
                          itemCode: 'WAR6002',
                        },
                      ],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should handle cart matching the provided API response structure — single ISPU line, no conflict', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                mobileNumber: '3176057199',
                lineActivityType: 'EUP',
                totalDueToday: 0.0,
                ispuItem: true,
                itemsInfo: [
                  {
                    itemCount: 1,
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [
                        {
                          discountAmount: 0.0,
                          cartItemType: 'DEVICE',
                          mobileNumber: '3176057199',
                          description: 'iPhone 15',
                          capacity: '128 GB',
                          qty: 1,
                          itemCode: 'MTLV3LL/A',
                          sddEligible: true,
                        },
                      ],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'TRUE');
      expect(result).toBe(false);
    });

    it('should return false for normal retail order without ISPU', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                mobileNumber: '3176057199',
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [
                        {
                          cartItemType: 'DEVICE',
                        },
                      ],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = hasISPUAndLocalConflict(mockCart, 'true');
      expect(result).toBe(false);
    });
  });
});

describe('shouldHideISPUToggle', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Feature Flag Gating', () => {
    it('should return false when feature flag is disabled (undefined)', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, undefined);
      expect(result).toBe(false);
    });

    it('should return false when feature flag is explicitly "false"', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'false');
      expect(result).toBe(false);
    });

    it('should return false when feature flag is "FALSE" (case insensitive)', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'FALSE');
      expect(result).toBe(false);
    });

    it('should return false when channel is not indirect (direct channel)', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      jest.spyOn(DomService, 'isIndirect').mockReturnValue(false);
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(false);
      jest.restoreAllMocks();
    });
  });

  describe('Hide ISPU Toggle Detection', () => {
    it('should return true when feature flag is enabled, channel is indirect, depletionType is "L", and ispuItem is false', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(true);
    });

    it('should return true with case-insensitive feature flag ("TRUE")', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'TRUE');
      expect(result).toBe(true);
    });

    it('should return true when multiple cart items exist in line with ispuItem false', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }, { cartItemType: 'SIM' }, { cartItemType: 'WARRANTY' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(true);
    });

    it('should return true when first line has the non-ISPU Local condition', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
              {
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'F',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(true);
    });

    it('should return true when second line has the non-ISPU Local condition', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'F',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
              {
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(true);
    });
  });

  describe('No Hide Scenarios', () => {
    it('should return false when depletionType is "L" but ispuItem is true at line level', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should return false when ispuItem is false but depletionType is not "L"', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'F',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should return false when depletionType is "I" (ISPU) and ispuItem is false', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'I',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should return false when line has ispuItem true despite depletionType "L"', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }, { cartItemType: 'SIM' }, { cartItemType: 'WARRANTY' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should return false when depletionType is missing', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: false,
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should return false when ispuItem property is missing at line level', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                // ispuItem is undefined
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(false);
    });
  });

  describe('Edge Cases', () => {
    it('should return false when cart is null', () => {
      const result = shouldHideISPUToggle(null, 'true');
      expect(result).toBe(false);
    });

    it('should return false when cart is undefined', () => {
      const result = shouldHideISPUToggle(undefined, 'true');
      expect(result).toBe(false);
    });

    it('should return false when cart is empty object', () => {
      const result = shouldHideISPUToggle({}, 'true');
      expect(result).toBe(false);
    });

    it('should return false when lineInfo is empty array', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should return false when itemsInfo is empty array', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                itemsInfo: [],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should return false when itemsInfo is undefined (tests OR fallback to [])', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                // itemsInfo is undefined - tests: line?.itemsInfo || []
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should return false when itemsInfo is null (tests OR fallback to [])', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                itemsInfo: null, // tests: line?.itemsInfo || []
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should return false when line object has no itemsInfo property (tests OR fallback)', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                mobileNumber: '1234567890',
                lineActivityType: 'AAL',
                // no itemsInfo property at all - tests OR fallback
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should return false when cartItem is empty array', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(true); // ispuItem=false at LINE level + depletionType='L' = HIDE TOGGLE
    });

    it('should return false when cartItem is undefined (tests OR fallback to [])', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      // cartItem is undefined - tests: item?.cartItems?.cartItem || []
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(true); // ispuItem=false at LINE level + depletionType='L' = HIDE TOGGLE
    });

    it('should return false when cartItem is null (tests OR fallback to [])', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: null, // tests: item?.cartItems?.cartItem || []
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(true); // ispuItem=false at LINE level + depletionType='L' = HIDE TOGGLE
    });

    it('should return false when cartItem is missing', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {},
                  },
                ],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(true); // ispuItem=false at LINE level + depletionType='L' = HIDE TOGGLE
    });

    it('should return false when lineDetails is missing', () => {
      const mockCart = {
        cart: {},
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should handle errors gracefully and return false', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                get itemsInfo() {
                  throw new Error('Test error');
                },
              },
            ],
          },
        },
      };
      const consoleSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(false);
      expect(consoleSpy).toHaveBeenCalledWith('Error in shouldHideISPUToggle:', expect.any(Error));
      consoleSpy.mockRestore();
    });

    it('should handle multiple lines with mixed conditions correctly', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'F',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
              {
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should handle multiple itemsInfo entries correctly', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'F',
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE' }],
                    },
                  },
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [{ cartItemType: 'SIM' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(true);
    });
  });

  describe('Real-world Scenarios', () => {
    it('should return true for a typical Best Buy indirect Local order with non-ISPU item', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                mobileNumber: '3176057199',
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [
                        {
                          sorId: 'MTLV3LL/A',
                          cartItemType: 'DEVICE',
                        },
                        {
                          sorId: 'UNIVESIM5G-SAB-D',
                          cartItemType: 'SIM',
                        },
                      ],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(true);
    });

    it('should return false for a typical fulfillment order (depletionType: "F")', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                mobileNumber: '3176057199',
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'F',
                    cartItems: {
                      cartItem: [
                        {
                          sorId: 'MTLV3LL/A',
                          cartItemType: 'DEVICE',
                        },
                      ],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(false);
    });

    it('should return false for an ISPU order with ispuItem: true (Local depletionType)', () => {
      const mockCart = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                mobileNumber: '3176057199',
                ispuItem: true,
                itemsInfo: [
                  {
                    depletionType: 'L',
                    cartItems: {
                      cartItem: [
                        {
                          sorId: 'MTLV3LL/A',
                          cartItemType: 'DEVICE',
                        },
                      ],
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const result = shouldHideISPUToggle(mockCart, 'true');
      expect(result).toBe(false);
    });
  });
});

describe('isDropshipSku Use cases', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('returns true when prodCode4 is "000" and prodCode5 is in allowed list (string)', () => {
    const sku = { prodCode4: '000', prodCode5: 'DCD' };
    console.log('DROPSHIP_PRODCODE5_ALLOWED_LIST', DROPSHIP_PRODCODE5_ALLOWED_LIST);
    expect(isDropshipSku(sku)).toBe(true);
  });
  it('returns false when prodCode4 is "000" but prodCode5 is not allowed', () => {
    const sku = { prodCode4: '000', prodCode5: 'CPO' };
    expect(isDropshipSku(sku)).toBe(false);
  });

  it('returns false when prodCode4 is not "000" even if prodCode5 is allowed', () => {
    const sku = { prodCode4: '001', prodCode5: 'DCD' };
    expect(isDropshipSku(sku)).toBe(false);
  });

  it('returns false for null/undefined skuDetails', () => {
    expect(isDropshipSku(null)).toBe(false);
    expect(isDropshipSku(undefined)).toBe(false);
  });

  it('returns false when prodCode4 is numeric 0 (String(0) !== "000")', () => {
    const sku = { prodCode4: 0, prodCode5: 'DCD' };
    expect(isDropshipSku(sku)).toBe(false);
  });

  it('is resilient when prodCode5 is missing', () => {
    const sku = { prodCode4: '000' };
    expect(isDropshipSku(sku)).toBe(false);
  });
});