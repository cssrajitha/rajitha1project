/* eslint-disable no-import-assign */
/* eslint-disable no-promise-executor-return */
// eslint-disable-next-line you-dont-need-lodash-underscore/get
import { get as getProp } from 'lodash';
import * as AssistedCradleService from 'onevzsoemfeframework/AssistedCradleService';
import * as DomService from 'onevzsoemfeframework/DomService';
import { executeShellFunction } from 'onevzsoemfeframework/DomService';
import { act } from '@testing-library/react';
import { render, screen, fireEvent } from '../../modules/test-utils/renderHelper';
import DeviceInfo from './DeviceInfo';
import { CHANNELS, setupChannel } from '../../modules/test-utils/utils';
import protectionFeatures from '../../pages/PDP/mocks/api/getProtectionFeatures.json';
import productDetails from '../../pages/PDP/mocks/api/getDetails.json';
import productDetails2 from '../../pages/PDP/mocks/api/getDetails2.json';
import cartDetails from '../../pages/PDP/mocks/api/retrieveCart.json';
import cartDetails2 from '../../pages/PDP/mocks/api/retrieveCartAnotherResponse.json';
import cartDetails3 from '../../pages/PDP/mocks/api/retrieveCartItemTypeResponse.json';
import cartDetails4 from '../../pages/PDP/mocks/api/cartItemDeviceWithContractPrices.json';
import customerProfileDetails from '../../pages/PDP/mocks/api/customerProfile.json';
import getSkuDetails from '../../pages/PDP/mocks/api/getSkuDetails.json';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { setupServer } from '../../pages/PDP/mocks/setupServer';
import mockDeviceInfoCredit from './mocks/mockDeviceInfoCredit.json';
import editProps from '../../pages/PDP/mocks/api/editProps.json';
import dropshipSkuDetailsResponse from '../../pages/PDP/mocks/api/dropshipSkuDetailsResponse.json';
import * as APIServiceHooks from '../../modules/services/APIService/APIServiceHooks';
import * as deviceInfoUtils from '../../modules/utils';
import { isVbg } from 'onevzsoemfeframework/VbgAemUtil';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';

mockDeviceInfoCredit.fullRetailPrice = {
  allPromotions: [{ discountMonthlyPrice: '234' }],
  originalPrice: 1199.99,
  contractText: 'Full Retail Price',
};
jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => true,
  }),
  { virtual: true },
);
const mockBByData = {
  storeId: '0281',
  upc: '400055816159',
  deviceSku: '5581615',
  priceInfo: [
    {
      priceId: 'cnt302',
      activationType: 'upgrade',
      purchaseType: 'FINANCED',
      contractTerm: 36,
      regularPrice: 8.33,
      currentPrice: 8.33,
      taxBasis: 299.99,
      downPaymentAmount: 0.0,
      bbyDownPayment: 0.0,
    },
    {
      priceId: 'cnt302',
      activationType: 'upgrade',
      purchaseType: 'FULL_SRP',
      contractTerm: 1,
      regularPrice: 299.99,
      currentPrice: 299.99,
      taxBasis: 299.99,
      downPaymentAmount: 0.0,
      bbyDownPayment: 0.0,
    },
    {
      priceId: 'cnt301',
      activationType: 'new',
      purchaseType: 'FINANCED',
      contractTerm: 36,
      regularPrice: 8.33,
      currentPrice: 8.33,
      taxBasis: 299.99,
      downPaymentAmount: 0.0,
      bbyDownPayment: 0.0,
    },
    {
      priceId: 'cnt301',
      activationType: 'new',
      purchaseType: 'FULL_SRP',
      contractTerm: 1,
      regularPrice: 299.99,
      currentPrice: 299.99,
      taxBasis: 299.99,
      downPaymentAmount: 0.0,
      bbyDownPayment: 0.0,
    },
  ],
};
const mockBByDataError = {
  storeId: '0281',
  upc: '400055816159',
  deviceSku: '5581615',
  messages: [
    {
      messageCategory: 'CDC_MOBILE',
      messageCode: '00314',
      messageDescription: 'There are no matching pricing details for the requested parameters.',
      messageReference: 'devicePricingDetails',
      messageType: 1,
    },
  ],
};
jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => false,
    isIpad: () => true,
    executeShellFunction: jest
      .fn()
      .mockImplementation(() => global.window.BbyDevicePricingDetails(JSON.stringify(mockBByData))),
  }),
  { virtual: true },
);

jest.mock('onevzsoemfecommon/CommonService', () => ({
  ...jest.requireActual('onevzsoemfecommon/CommonService'),
  useLazyUpdateConsentQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: false,
      isError: true,
      isFetching: false,
      error: { name: 'System Error', code: '400', Message: 'Could not get device details' },
    },
  ],
}));
jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => true,
  }),
  { virtual: true },
);
jest.mock(
  '../../modules/services/APIService/APIServiceHooks',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
      useLazyEligibleNumberShareListQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                status: 'Success',
                payload: {
                  deviceDetailsAndOffers: {
                    displayName:
                      'Apple Watch Series 9 GPS + Cellular 41mm Pink Aluminum Case with Light Pink Sport Band - S/M',
                    sorId: 'MRHY3LL/A',
                    color: 'Pink (Aluminum)',
                    imageURL:
                      'https://ss7.vzw.com/is/image/VerizonWireless/apple-watch-series-9-gps-cellular-41mm-pink-aluminum-case-light-pink-sport-band-mrhy3ll-a-a',
                    supportsAllVZProtectFeatures: false,
                    eligibleNumberShareOS: ['Apple iOS'],
                    smartLocator: false,
                  },
                  mandatoryPairingNeeded: false,
                  numberShareEligibleDevices: [
                    {
                      customerName: 'RAVI JETER',
                      nickName: 'RAVI-7979',
                      mtn: '5155547979',
                      deviceDisplayName: 'IPHONE 13 MINI 128 MIDNIGHT',
                      deviceImageUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-mini-midnight',
                      currentConnectedDevices: 0,
                      maxConnectedDevicesAllowed: 5,
                      preSelect: true,
                      trunkMtn: '5155547979',
                    },
                  ],
                  mtn: '5154529414',
                  lineActivityType: 'AAL',
                  watchToWatchUpgrade: false,
                  currentPaired: false,
                  accountPairedDevice: {
                    mtn: '12345678',
                  },
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
      useLazyGetRetrieveURCodeQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                meta: {
                  timestamp: 1714739048101,
                  cxpCorrelationId:
                    '2024-05-03T12:24:08.+0000:6d760cb7d9fbe0b1:cxp-shopping-services-684fb47569-9nqsc:nssit2',
                },
                data: {
                  retrieveURCforCartMtnList: {
                    mtnUpgradeReasonCodes: [
                      {
                        mtn: '2697161703',
                        upgradeReasonCodes: [
                          {
                            code: 'MA',
                            description: 'Manager Exception with non-working equipment',
                            contractTermDetails: {
                              contractTerm: 'VERIZON_EDGE',
                            },
                            defaultReasonCode: false,
                          },
                          {
                            code: 'WA',
                            description: 'WFG RETURN - DEVICE PAYMENT PRICE',
                            contractTermDetails: {
                              contractTerm: 'VERIZON_EDGE',
                            },
                            defaultReasonCode: true,
                          },
                        ],
                      },
                    ],
                  },
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
      useLazyRetrievedppQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                data: {
                  dppIndicator: false,
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
      useLazyGetDevicePricingEligibilityQuery: jest.fn().mockReturnValue([
        () => { },
        {
          status: 'fulfilled',
          isUninitialized: false,
          isLoading: false,
          isSuccess: true,
          isError: false,
          isFetching: false,
          data: {
            isDevicePaymentEligible: false,
            dpMessage: {
              message:
                'You are prequalified for Device payment with $2000.00 Device finance limit and $4864.59 Total finance limit remaining',
              type: 'WARNING',
              inEligibleMessage: 'CUSTOMER HAS A PAST DUE BALANCE GREATER THAN  $ 24.99',
            },
          },
        },
      ]),
      useLazyGetBestBuyInventoryQuery: () => [
        () => { },
        {
          status: 'Success',
          isUninitialized: false,
          isLoading: false,
          isSuccess: true,
          isError: false,
          isFetching: false,
          data: {
            availability: [
              {
                storeLocation: 'Minneapolis',
                quantity: 997,
                deviceSku: '5581615',
                storeId: '281',
                upc: '400055816159',
              },
              {
                storeLocation: 'Minneapolis',
                quantity: 997,
                deviceSku: '5581615',
                storeId: '281',
                upc: '400055816159',
              },
            ],
            devicePricingDetails: {
              storeId: '0281',
              upc: '887276053875',
              priceInfo: [
                {
                  priceId: 'cnt302',
                  activationType: 'upgrade',
                  purchaseType: 'FINANCED',
                  contractTerm: 36,
                  regularPrice: 16.66,
                  currentPrice: 16.66,
                  taxBasis: 599.99,
                  downPaymentAmount: 0,
                  bbyDownPaymentAmount: 0,
                },
                {
                  regularPrice: 1299.99,
                  currentPrice: 1166.99,
                  contractTerm: 1,
                  activationType: 'upgrade',
                  downPaymentAmount: 0,
                  priceId: 'cnt302',
                  purchaseType: 'FULL_SRP',
                  taxBasis: 1299.99,
                  bbyDownPayment: 50,
                },
                {
                  priceId: 'cnt301',
                  activationType: 'new',
                  purchaseType: 'FINANCED',
                  contractTerm: 36,
                  regularPrice: 16.66,
                  currentPrice: 16.66,
                  taxBasis: 599.99,
                  downPaymentAmount: 0,
                  bbyDownPaymentAmount: 0,
                },
                {
                  regularPrice: 299.99,
                  currentPrice: 299.99,
                  contractTerm: 1,
                  activationType: 'new',
                  downPaymentAmount: 0,
                  priceId: 'cnt301',
                  purchaseType: 'FULL_SRP',
                  taxBasis: 299.99,
                  bbyDownPayment: 0,
                },
              ],
              deviceSku: '4811019',
            },
          },
        },
      ],
    };
  },
  { virtual: true },
);
jest.mock(
  'onevzsoemfecommon/DeviceAPIService',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('onevzsoemfecommon/DeviceAPIService'),
      useLazyRetrievedppQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                data: {
                  dppIndicator: true,
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
    };
  },
  { virtual: true },
);
jest.mock('./SmartWatchBandOptions', () => ({ chooseSWBand }) => (
  <div
    role='button'
    data-testid='chooseSWBand'
    style={{ height: '150px', width: '300px' }}
    onClick={() => chooseSWBand({ target: { value: 'band' } })}
    onKeyDown={() => chooseSWBand({ target: { value: 'band' } })}
    tabIndex={0}
  >
    Click me
  </div>
));
jest.mock('./SmartWatchSizeOptions', () => ({ chooseSWBandSize }) => (
  <div
    role='button'
    data-testid='chooseSWBandSize'
    style={{ height: '150px', width: '300px' }}
    onClick={() => chooseSWBandSize({ target: { value: 'band' } })}
    onKeyDown={() => chooseSWBandSize({ target: { value: 'band' } })}
    tabIndex={0}
  >
    Click me
  </div>
));
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: jest.fn(() => ['', 'UNL', 'FALSE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', '', 'TRUE']),
  }),
  { virtual: true },
);
jest.mock('onevzsoemfeframework/VbgAemUtil', () => ({
  __esModule: true,
  ...jest.requireActual('onevzsoemfeframework/VbgAemUtil'),
  isVbg: jest.fn(() => false),
}));

describe('DeviceInfo - dpEligibility FALSE - VBG', () => {
  it('should call setSelectedPaymentInfoMock with MONTH_TO_MONTH if isVbg is false', () => {
    const setSelectedPaymentInfoMock = jest.fn();
    const addAppMessage = jest.fn();
    jest.doMock('onevzsoemfecommon/AppMessageActions', () => ({
      addAppMessage,
    }));

    const getDpEligibility = jest.fn();
    const dpEligibilityResult = {
      status: 'rejected',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: {
        deviceFinanceLimit: 2000.0,
        totalFinanceLimit: 4864.59,
        isDevicePaymentEligible: false,
        isDevicePaymentPending: false,
        custTypeCode: 'PE',
        downPaymentPercentage: 0,
        inEligibleMessage: 'CUSTOMER HAS A PAST DUE BALANCE GREATER THAN  $ 24.99',
        isConditionalEligibility: true,
        dpMessage: {
          message: 'You are not eligible for Device Payment at this moment',
          type: 'WARNING',
        },
        price: {
          devicePaymentPrice: [
            {
              dpTermPrices: {
                firstMonthPrice: 16.85,
                remainingMonthPrice: 16.66,
                dpTerm: 30,
                downPayment: 0.0,
              },
            },
            {
              dpTermPrices: {
                firstMonthPrice: 20.9,
                remainingMonthPrice: 20.83,
                dpTerm: 24,
                downPayment: 0.0,
              },
            },
            {
              dpTermPrices: {
                firstMonthPrice: 14.19,
                remainingMonthPrice: 13.88,
                dpTerm: 36,
                downPayment: 0.0,
              },
            },
          ],
          vvcDeviceFinancingOfferPrice: {
            originalMonthlyPrice: 33.33,
            monthlyDiscountPrice: 15.0,
            contractText: 'Monthly Payment with Verizon Visa Card',
            installmentTerm: 36,
          },
          fullRetailPrice: { allPromotions: [{ discountMonthlyPrice: '234' }] },
        },
        totalFinanceLimitRemaining: 4864.59,
      },
    };
    APIServiceHooks.useLazyGetDevicePricingEligibilityQuery = jest.fn(() => [
      getDpEligibility,
      dpEligibilityResult,
    ]);
    isVbg.mockReturnValue(false);
    getAssistedCradlePropertyV2.mockReturnValue(['', 'UNL', 'FALSE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', '', 'TRUE']);

    render(
      <DeviceInfo
        setSelectedSku={jest.fn()}
        details={{ childSkus: [{}] }}
        productDetails={{}}
        protectionFeatures={{}}
        cartDetails={{}}
        customerProfileDetails={{}}
        activeMtn=''
        selectedColor=''
        groupByColors={jest.fn()}
        setSelectedColor={jest.fn()}
        updateNumberShare={jest.fn()}
        updateNumberShareValue={jest.fn()}
        ispuToggleOn={false}
        setIspuToggleOn={jest.fn()}
        isShipItToggleOn={false}
        setIsShipItToggleOn={jest.fn()}
        selectedSku={{
          price: {
            devicePaymentPrice: [{ originalPrice: 10, contractDuration: 24, dpTermPrices: {} }],
            threeYearPrice: { contractText: 'Three Year Price', originalPrice: 999.99 },
            fullRetailPrice: { originalPrice: 1199.99, contractText: 'Full Retail Price' },
          }
        }}
        selectedProtectionFeature={{}}
        setSelectedProtectionFeature={jest.fn()}
        selectedSize=''
        setSelectedSize={jest.fn()}
        setUpgradeReasonType={jest.fn()}
        isAcssDfillSim={false}
        isNewlyAddedLine={false}
        updateDeviceData={jest.fn()}
        updateDeviceId={jest.fn()}
        updateSimId={jest.fn()}
        setSelectedPaymentInfo={setSelectedPaymentInfoMock}
      />,
    );

    expect(setSelectedPaymentInfoMock).toHaveBeenCalledTimes(2);
    expect(setSelectedPaymentInfoMock).toHaveBeenCalledWith({ contractType: 'MONTH_TO_MONTH' });
  });
  it('should call setSelectedPaymentInfoMock with contract text if isVbg is true', () => {
    const setSelectedPaymentInfoMock = jest.fn();
    const addAppMessage = jest.fn();
    jest.doMock('onevzsoemfecommon/AppMessageActions', () => ({
      addAppMessage,
    }));

    const useLazyGetDevicePricingEligibilityQuery = jest.fn();
    const dpEligibilityResult = {
      status: 'rejected',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: {
        deviceFinanceLimit: 2000.0,
        totalFinanceLimit: 4864.59,
        isDevicePaymentEligible: false,
        isDevicePaymentPending: false,
        custTypeCode: 'PE',
        downPaymentPercentage: 0,
        inEligibleMessage: 'CUSTOMER HAS A PAST DUE BALANCE GREATER THAN  $ 24.99',
        isConditionalEligibility: true,
        dpMessage: {
          message: 'You are not eligible for Device Payment at this moment',
          type: 'WARNING',
        },
        price: {
          devicePaymentPrice: [
            {
              dpTermPrices: {
                firstMonthPrice: 16.85,
                remainingMonthPrice: 16.66,
                dpTerm: 30,
                downPayment: 0.0,
              },
            },
            {
              dpTermPrices: {
                firstMonthPrice: 20.9,
                remainingMonthPrice: 20.83,
                dpTerm: 24,
                downPayment: 0.0,
              },
            },
            {
              dpTermPrices: {
                firstMonthPrice: 14.19,
                remainingMonthPrice: 13.88,
                dpTerm: 36,
                downPayment: 0.0,
              },
            },
          ],
          vvcDeviceFinancingOfferPrice: {
            originalMonthlyPrice: 33.33,
            monthlyDiscountPrice: 15.0,
            contractText: 'Monthly Payment with Verizon Visa Card',
            installmentTerm: 36,
          },
          fullRetailPrice: { allPromotions: [{ discountMonthlyPrice: '234' }] },
        },
        totalFinanceLimitRemaining: 4864.59,
      },
    };
    APIServiceHooks.useLazyGetDevicePricingEligibilityQuery = jest.fn(() => [
      useLazyGetDevicePricingEligibilityQuery,
      dpEligibilityResult,
    ]);
    isVbg.mockReturnValue(true);
    getAssistedCradlePropertyV2.mockReturnValue(['', 'UNL', 'FALSE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', '', 'TRUE']);

    render(
      <DeviceInfo
        setSelectedSku={jest.fn()}
        details={{ childSkus: [{}] }}
        productDetails={{}}
        protectionFeatures={{}}
        cartDetails={{}}
        customerProfileDetails={{}}
        activeMtn=''
        selectedColor=''
        groupByColors={jest.fn()}
        setSelectedColor={jest.fn()}
        updateNumberShare={jest.fn()}
        updateNumberShareValue={jest.fn()}
        ispuToggleOn={false}
        setIspuToggleOn={jest.fn()}
        isShipItToggleOn={false}
        setIsShipItToggleOn={jest.fn()}
        selectedSku={{
          price: {
            devicePaymentPrice: [{ originalPrice: 10, contractDuration: 24, dpTermPrices: {} }],
            fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
            thirtyMonthPrice: { originalPrice: 85, contractText: 'Thirty Month Price' },
            preferredTerm: 24,
          },
          color: { displayName: 'Black', colorCssStyle: '#000' },
          sorId: 'sku1',
          capacity: '128GB',
          imageUrlMap: {},
        }}
        selectedProtectionFeature={{}}
        setSelectedProtectionFeature={jest.fn()}
        selectedSize=''
        setSelectedSize={jest.fn()}
        setUpgradeReasonType={jest.fn()}
        isAcssDfillSim={false}
        isNewlyAddedLine={false}
        updateDeviceData={jest.fn()}
        updateDeviceId={jest.fn()}
        updateSimId={jest.fn()}
        setSelectedPaymentInfo={setSelectedPaymentInfoMock}
      />,
    );

    expect(setSelectedPaymentInfoMock).toHaveBeenCalledTimes(2);
    expect(setSelectedPaymentInfoMock).toHaveBeenCalledWith({ contractType: '30_MONTHS', price: 85 });
  });
  it('should hide ISPU toggle and keep Ship It toggle to the right if isVbg is true', () => {
    sessionStorage.setItem('channel', "OMNI-RETAIL");
    const setSelectedPaymentInfoMock = jest.fn();
    const addAppMessage = jest.fn();
    jest.doMock('onevzsoemfecommon/AppMessageActions', () => ({
      addAppMessage,
    }));

    const useLazyGetDevicePricingEligibilityQuery = jest.fn();
    const dpEligibilityResult = {
      status: 'rejected',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: {
        deviceFinanceLimit: 2000.0,
        totalFinanceLimit: 4864.59,
        isDevicePaymentEligible: false,
        isDevicePaymentPending: false,
        custTypeCode: 'PE',
        downPaymentPercentage: 0,
        inEligibleMessage: 'CUSTOMER HAS A PAST DUE BALANCE GREATER THAN  $ 24.99',
        isConditionalEligibility: true,
        dpMessage: {
          message: 'You are not eligible for Device Payment at this moment',
          type: 'WARNING',
        },
        price: {
          devicePaymentPrice: [
            {
              dpTermPrices: {
                firstMonthPrice: 16.85,
                remainingMonthPrice: 16.66,
                dpTerm: 30,
                downPayment: 0.0,
              },
            },
            {
              dpTermPrices: {
                firstMonthPrice: 20.9,
                remainingMonthPrice: 20.83,
                dpTerm: 24,
                downPayment: 0.0,
              },
            },
            {
              dpTermPrices: {
                firstMonthPrice: 14.19,
                remainingMonthPrice: 13.88,
                dpTerm: 36,
                downPayment: 0.0,
              },
            },
          ],
          vvcDeviceFinancingOfferPrice: {
            originalMonthlyPrice: 33.33,
            monthlyDiscountPrice: 15.0,
            contractText: 'Monthly Payment with Verizon Visa Card',
            installmentTerm: 36,
          },
          fullRetailPrice: { allPromotions: [{ discountMonthlyPrice: '234' }] },
        },
        totalFinanceLimitRemaining: 4864.59,
      },
    };
    APIServiceHooks.useLazyGetDevicePricingEligibilityQuery = jest.fn(() => [
      useLazyGetDevicePricingEligibilityQuery,
      dpEligibilityResult,
    ]);
    isVbg.mockReturnValue(true);
    getAssistedCradlePropertyV2.mockReturnValue(['', 'UNL', 'FALSE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', '', 'TRUE']);

    render(
      <DeviceInfo
        setSelectedSku={jest.fn()}
        details={{ childSkus: [{}] }}
        productDetails={{
          commonInfo: {
            showShipitToggle: true
          }
        }}
        protectionFeatures={{}}
        cartDetails={{}}
        customerProfileDetails={{}}
        activeMtn=''
        selectedColor=''
        groupByColors={jest.fn()}
        setSelectedColor={jest.fn()}
        updateNumberShare={jest.fn()}
        updateNumberShareValue={jest.fn()}
        ispuToggleOn={false}
        setIspuToggleOn={jest.fn()}
        isShipItToggleOn={false}
        setIsShipItToggleOn={jest.fn()}
        selectedSku={{
          price: {
            devicePaymentPrice: [{ originalPrice: 10, contractDuration: 24, dpTermPrices: {} }],
            fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
            thirtyMonthPrice: { originalPrice: 85, contractText: 'Thirty Month Price' },
            preferredTerm: 24,
          },
          color: { displayName: 'Black', colorCssStyle: '#000' },
          sorId: 'sku1',
          capacity: '128GB',
          imageUrlMap: {},
        }}
        selectedProtectionFeature={{}}
        setSelectedProtectionFeature={jest.fn()}
        selectedSize=''
        setSelectedSize={jest.fn()}
        setUpgradeReasonType={jest.fn()}
        isAcssDfillSim={false}
        isNewlyAddedLine={false}
        updateDeviceData={jest.fn()}
        updateDeviceId={jest.fn()}
        updateSimId={jest.fn()}
        setSelectedPaymentInfo={setSelectedPaymentInfoMock}
        isBBYLocalOrder={false}
      />,
    );

    expect(setSelectedPaymentInfoMock).toHaveBeenCalledTimes(2);
    expect(setSelectedPaymentInfoMock).toHaveBeenCalledWith({ contractType: '30_MONTHS', price: 85 });
  });
});

describe('DeviceInfo - DPPIndicatorFlag FALSE - VBG - should call setSelectedPaymentInfoMock', () => {
  it('with MONTH_TO_MONTH if isVbg is false', () => {
    const setSelectedPaymentInfoMock = jest.fn();
    const addAppMessage = jest.fn();
    jest.doMock('onevzsoemfecommon/AppMessageActions', () => ({
      addAppMessage,
    }));

    const getDpEligibility = jest.fn();
    const dpEligibilityResult = {
      status: 'rejected',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: {
        deviceFinanceLimit: 2000.0,
        totalFinanceLimit: 4864.59,
        isDevicePaymentEligible: false,
        isDevicePaymentPending: false,
        custTypeCode: 'PE',
        downPaymentPercentage: 0,
        inEligibleMessage: 'CUSTOMER HAS A PAST DUE BALANCE GREATER THAN  $ 24.99',
        isConditionalEligibility: true,
        dpMessage: {
          message: 'You are not eligible for Device Payment at this moment',
          type: 'WARNING',
        },
        price: {
          devicePaymentPrice: [
            {
              dpTermPrices: {
                firstMonthPrice: 16.85,
                remainingMonthPrice: 16.66,
                dpTerm: 30,
                downPayment: 0.0,
              },
            },
            {
              dpTermPrices: {
                firstMonthPrice: 20.9,
                remainingMonthPrice: 20.83,
                dpTerm: 24,
                downPayment: 0.0,
              },
            },
            {
              dpTermPrices: {
                firstMonthPrice: 14.19,
                remainingMonthPrice: 13.88,
                dpTerm: 36,
                downPayment: 0.0,
              },
            },
          ],
          vvcDeviceFinancingOfferPrice: {
            originalMonthlyPrice: 33.33,
            monthlyDiscountPrice: 15.0,
            contractText: 'Monthly Payment with Verizon Visa Card',
            installmentTerm: 36,
          },
          fullRetailPrice: { allPromotions: [{ discountMonthlyPrice: '234' }] },
        },
        totalFinanceLimitRemaining: 4864.59,
      },
    };
    APIServiceHooks.useLazyGetDevicePricingEligibilityQuery = jest.fn(() => [
      getDpEligibility,
      dpEligibilityResult,
    ]);
    isVbg.mockReturnValue(false);
    getAssistedCradlePropertyV2.mockReturnValue(['', 'UNL', 'FALSE', 'TRUE', 'FALSE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', '', 'TRUE']);

    render(
      <DeviceInfo
        setSelectedSku={jest.fn()}
        details={{ childSkus: [{}] }}
        productDetails={{}}
        protectionFeatures={{}}
        cartDetails={{}}
        customerProfileDetails={{}}
        activeMtn=''
        selectedColor=''
        groupByColors={jest.fn()}
        setSelectedColor={jest.fn()}
        updateNumberShare={jest.fn()}
        updateNumberShareValue={jest.fn()}
        ispuToggleOn={false}
        setIspuToggleOn={jest.fn()}
        isShipItToggleOn={false}
        setIsShipItToggleOn={jest.fn()}
        selectedSku={{
          price: {
            devicePaymentPrice: [{ originalPrice: 10, contractDuration: 24, dpTermPrices: {} }],
            threeYearPrice: { contractText: 'Three Year Price', originalPrice: 999.99 },
            fullRetailPrice: { originalPrice: 1199.99, contractText: 'Full Retail Price' },
          }
        }}
        selectedProtectionFeature={{}}
        setSelectedProtectionFeature={jest.fn()}
        selectedSize=''
        setSelectedSize={jest.fn()}
        setUpgradeReasonType={jest.fn()}
        isAcssDfillSim={false}
        isNewlyAddedLine={false}
        updateDeviceData={jest.fn()}
        updateDeviceId={jest.fn()}
        updateSimId={jest.fn()}
        setSelectedPaymentInfo={setSelectedPaymentInfoMock}
      />,
    );

    expect(setSelectedPaymentInfoMock).toHaveBeenCalledTimes(2);
    expect(setSelectedPaymentInfoMock).toHaveBeenCalledWith({ contractType: 'MONTH_TO_MONTH' });
  });
  it('with contract text if isVbg is true and dpTermIndex is -1', () => {
    const setSelectedPaymentInfoMock = jest.fn();
    const addAppMessage = jest.fn();
    jest.doMock('onevzsoemfecommon/AppMessageActions', () => ({
      addAppMessage,
    }));

    const useLazyGetDevicePricingEligibilityQuery = jest.fn();
    const dpEligibilityResult = {
      status: 'rejected',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: {
        deviceFinanceLimit: 2000.0,
        totalFinanceLimit: 4864.59,
        isDevicePaymentEligible: false,
        isDevicePaymentPending: false,
        custTypeCode: 'PE',
        downPaymentPercentage: 0,
        inEligibleMessage: 'CUSTOMER HAS A PAST DUE BALANCE GREATER THAN  $ 24.99',
        isConditionalEligibility: true,
        dpMessage: {
          message: 'You are not eligible for Device Payment at this moment',
          type: 'WARNING',
        },
        price: {
          devicePaymentPrice: [
            {
              dpTermPrices: {
                firstMonthPrice: 16.85,
                remainingMonthPrice: 16.66,
                dpTerm: 30,
                downPayment: 0.0,
              },
            },
            {
              dpTermPrices: {
                firstMonthPrice: 20.9,
                remainingMonthPrice: 20.83,
                dpTerm: 24,
                downPayment: 0.0,
              },
            },
            {
              dpTermPrices: {
                firstMonthPrice: 14.19,
                remainingMonthPrice: 13.88,
                dpTerm: 36,
                downPayment: 0.0,
              },
            },
          ],
          vvcDeviceFinancingOfferPrice: {
            originalMonthlyPrice: 33.33,
            monthlyDiscountPrice: 15.0,
            contractText: 'Monthly Payment with Verizon Visa Card',
            installmentTerm: 36,
          },
          fullRetailPrice: { allPromotions: [{ discountMonthlyPrice: '234' }] },
        },
        totalFinanceLimitRemaining: 4864.59,
      },
    };
    APIServiceHooks.useLazyGetDevicePricingEligibilityQuery = jest.fn(() => [
      useLazyGetDevicePricingEligibilityQuery,
      dpEligibilityResult,
    ]);
    isVbg.mockReturnValue(true);
    getAssistedCradlePropertyV2.mockReturnValue(['', 'UNL', 'FALSE', 'TRUE', 'FALSE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', '', 'TRUE']);

    render(
      <DeviceInfo
        setSelectedSku={jest.fn()}
        details={{ childSkus: [{}] }}
        productDetails={{}}
        protectionFeatures={{}}
        cartDetails={{}}
        customerProfileDetails={{}}
        activeMtn=''
        selectedColor=''
        groupByColors={jest.fn()}
        setSelectedColor={jest.fn()}
        updateNumberShare={jest.fn()}
        updateNumberShareValue={jest.fn()}
        ispuToggleOn={false}
        setIspuToggleOn={jest.fn()}
        isShipItToggleOn={false}
        setIsShipItToggleOn={jest.fn()}
        selectedSku={{
          price: {
            devicePaymentPrice: [{ originalPrice: 10, contractDuration: 24, dpTermPrices: {} }],
            fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
            thirtyMonthPrice: { originalPrice: 85, contractText: 'Thirty Month Price' },
            preferredTerm: 24,
          },
          color: { displayName: 'Black', colorCssStyle: '#000' },
          sorId: 'sku1',
          capacity: '128GB',
          imageUrlMap: {},
        }}
        selectedProtectionFeature={{}}
        setSelectedProtectionFeature={jest.fn()}
        selectedSize=''
        setSelectedSize={jest.fn()}
        setUpgradeReasonType={jest.fn()}
        isAcssDfillSim={false}
        isNewlyAddedLine={false}
        updateDeviceData={jest.fn()}
        updateDeviceId={jest.fn()}
        updateSimId={jest.fn()}
        setSelectedPaymentInfo={setSelectedPaymentInfoMock}
      />,
    );

    expect(setSelectedPaymentInfoMock).toHaveBeenCalledTimes(2);
    expect(setSelectedPaymentInfoMock).toHaveBeenCalledWith({ contractType: '30_MONTHS', price: 85 });
  });
  it('with contract text if isVbg is true and dpTermIndex is -1 and contractPrice is not present', () => {
    const setSelectedPaymentInfoMock = jest.fn();
    const addAppMessage = jest.fn();
    jest.doMock('onevzsoemfecommon/AppMessageActions', () => ({
      addAppMessage,
    }));

    const useLazyGetDevicePricingEligibilityQuery = jest.fn();
    const dpEligibilityResult = {
      status: 'rejected',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: {
        deviceFinanceLimit: 2000.0,
        totalFinanceLimit: 4864.59,
        isDevicePaymentEligible: false,
        isDevicePaymentPending: false,
        custTypeCode: 'PE',
        downPaymentPercentage: 0,
        inEligibleMessage: 'CUSTOMER HAS A PAST DUE BALANCE GREATER THAN  $ 24.99',
        isConditionalEligibility: true,
        dpMessage: {
          message: 'You are not eligible for Device Payment at this moment',
          type: 'WARNING',
        },
        price: {
          devicePaymentPrice: [
            {
              dpTermPrices: {
                firstMonthPrice: 16.85,
                remainingMonthPrice: 16.66,
                dpTerm: 30,
                downPayment: 0.0,
              },
            },
            {
              dpTermPrices: {
                firstMonthPrice: 20.9,
                remainingMonthPrice: 20.83,
                dpTerm: 24,
                downPayment: 0.0,
              },
            },
            {
              dpTermPrices: {
                firstMonthPrice: 14.19,
                remainingMonthPrice: 13.88,
                dpTerm: 36,
                downPayment: 0.0,
              },
            },
          ],
          vvcDeviceFinancingOfferPrice: {
            originalMonthlyPrice: 33.33,
            monthlyDiscountPrice: 15.0,
            contractText: 'Monthly Payment with Verizon Visa Card',
            installmentTerm: 36,
          },
          fullRetailPrice: { allPromotions: [{ discountMonthlyPrice: '234' }] },
        },
        totalFinanceLimitRemaining: 4864.59,
      },
    };
    APIServiceHooks.useLazyGetDevicePricingEligibilityQuery = jest.fn(() => [
      useLazyGetDevicePricingEligibilityQuery,
      dpEligibilityResult,
    ]);
    isVbg.mockReturnValue(true);
    getAssistedCradlePropertyV2.mockReturnValue(['', 'UNL', 'FALSE', 'TRUE', 'FALSE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', '', 'TRUE']);

    render(
      <DeviceInfo
        setSelectedSku={jest.fn()}
        details={{ childSkus: [{}] }}
        productDetails={{}}
        protectionFeatures={{}}
        cartDetails={{}}
        customerProfileDetails={{}}
        activeMtn=''
        selectedColor=''
        groupByColors={jest.fn()}
        setSelectedColor={jest.fn()}
        updateNumberShare={jest.fn()}
        updateNumberShareValue={jest.fn()}
        ispuToggleOn={false}
        setIspuToggleOn={jest.fn()}
        isShipItToggleOn={false}
        setIsShipItToggleOn={jest.fn()}
        selectedSku={{
          price: {
            devicePaymentPrice: [{ originalPrice: 10, contractDuration: 24, dpTermPrices: {} }],
            preferredTerm: 24,
          },
          color: { displayName: 'Black', colorCssStyle: '#000' },
          sorId: 'sku1',
          capacity: '128GB',
          imageUrlMap: {},
        }}
        selectedProtectionFeature={{}}
        setSelectedProtectionFeature={jest.fn()}
        selectedSize=''
        setSelectedSize={jest.fn()}
        setUpgradeReasonType={jest.fn()}
        isAcssDfillSim={false}
        isNewlyAddedLine={false}
        updateDeviceData={jest.fn()}
        updateDeviceId={jest.fn()}
        updateSimId={jest.fn()}
        setSelectedPaymentInfo={setSelectedPaymentInfoMock}
      />,
    );

    expect(setSelectedPaymentInfoMock).toHaveBeenCalledTimes(1);
    expect(setSelectedPaymentInfoMock).toHaveBeenCalledWith({ contractType: 'DEVICE_PAYMENT', paymentType: "" });
  });
  it('with DEVICE_PAYMENT if isVbg is true and dpTermIndex is not -1', () => {
    const setSelectedPaymentInfoMock = jest.fn();
    const addAppMessage = jest.fn();
    jest.doMock('onevzsoemfecommon/AppMessageActions', () => ({
      addAppMessage,
    }));
    const useLazyGetDevicePricingEligibilityQuery = jest.fn();
    const dpEligibilityResult = {
      status: 'rejected',
      isUninitialized: false,
      isLoading: false,
    };
    APIServiceHooks.useLazyGetDevicePricingEligibilityQuery = jest.fn(() => [
      useLazyGetDevicePricingEligibilityQuery,
      dpEligibilityResult,
    ]);
    isVbg.mockReturnValue(true);
    getAssistedCradlePropertyV2.mockReturnValue(['', 'UNL', 'FALSE', 'TRUE', 'FALSE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', '', 'TRUE']);
    render(
      <DeviceInfo
        setSelectedSku={jest.fn()}
        details={{ childSkus: [{}] }}
        productDetails={{}}
        protectionFeatures={{}}
        cartDetails={{}}
        customerProfileDetails={{}}
        activeMtn=''
        selectedColor=''
        groupByColors={jest.fn()}
        setSelectedColor={jest.fn()}
        updateNumberShare={jest.fn()}
        updateNumberShareValue={jest.fn()}
        ispuToggleOn={false}
        setIspuToggleOn={jest.fn()}
        isShipItToggleOn={false}
        setIsShipItToggleOn={jest.fn()}
        selectedSku={{
          price: {
            devicePaymentPrice: [
              {
                originalPrice: 10,
                contractDuration: 24,
                dpTermPrices: {
                  dpTerm: 24,
                  remainingMonthrice: 10,
                },
              },
              {
                originalPrice: 15,
                contractDuration: 36,
                dpTermPrices: {
                  dpTerm: 36,
                  remainingMonthrice: 15,
                },
              },
              {
                originalPrice: 20,
                contractDuration: 30,
                dpTermPrices: {
                  dpTerm: 30,
                  remainingMonthrice: 20,
                },
              },
            ],
            fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
            thirtyMonthPrice: { originalPrice: 85, contractText: 'Thirty Month Price' },
            preferredTerm: 24,
          },
          color: { displayName: 'Black', colorCssStyle: '#000' },
          sorId: 'sku1',
          capacity: '128GB',
          imageUrlMap: {},
        }}
        selectedProtectionFeature={{}}
        setSelectedProtectionFeature={jest.fn()}
        selectedSize=''
        setSelectedSize={jest.fn()}
        setUpgradeReasonType={jest.fn()}
        isAcssDfillSim={false}
        isNewlyAddedLine={false}
        updateDeviceData={jest.fn()}
        updateDeviceId={jest.fn()}
        updateSimId={jest.fn()}
        setSelectedPaymentInfo={setSelectedPaymentInfoMock}
      />,
    );

    expect(setSelectedPaymentInfoMock).toHaveBeenCalledTimes(1);
    expect(setSelectedPaymentInfoMock).toHaveBeenCalledWith({ contractType: 'DEVICE_PAYMENT', price: 15, term: 36, paymentType: "" });
  });
  it('if deviceFromFilteredCartLine.priceType is DEVICE_PAYMENT and isVbg is false', () => {
    const setSelectedPaymentInfoMock = jest.fn();

    const InventoryDetailsResult = {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: dropshipSkuDetailsResponse || [],
    };
    APIServiceHooks.useLazyGetInventoryDetailsQuery = jest.fn(() => [
      useLazyGetInventoryDetailsQuery,
      InventoryDetailsResult,
    ]);

    const useLazyGetDevicePricingEligibilityQuery = jest.fn();
    const dpEligibilityResult = {
      status: 'rejected',
      isUninitialized: false,
      isLoading: false,
    };
    APIServiceHooks.useLazyGetDevicePricingEligibilityQuery = jest.fn(() => [
      useLazyGetDevicePricingEligibilityQuery,
      dpEligibilityResult,
    ]);

    const props = {
      details: {
        childSkus: [
          {
            price: {
              devicePaymentPrice: [{ contractDuration: 36 }],
              fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
              preferredTerm: null,
            },
            color: { displayName: 'Black', colorCssStyle: '#000' },
            sorId: 'sku1',
            capacity: '128GB',
            imageUrlMap: {},
          },
        ],
        defaultSKUObj: {
          price: {
            devicePaymentPrice: [{ contractDuration: 36 }],
            fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
            preferredTerm: null,
          },
          color: { displayName: 'Black', colorCssStyle: '#000' },
          sorId: 'sku1',
          capacity: '128GB',
          imageUrlMap: {},
        },
        childSkusByColor: [],
        isNumberShareMandatory: false,
        isNumberShareCapable: false,
      },
      productDetails: {
        deviceProduct: {},
        deviceSku: {
          sorId: 'sku1'
        },
        commonInfo: {},
      },
      protectionFeatures: {},
      cartDetails: cartDetails4.data.data,
      customerProfileDetails: { customer: { billAccounts: [{ mtns: [] }] }, commonInfo: {} },
      activeMtn: '8976541238',
      selectedColor: 'Black',
      setSelectedColor: jest.fn(),
      ispuToggleOn: false,
      setIspuToggleOn: jest.fn(),
      isShipItToggleOn: false,
      setIsShipItToggleOn: jest.fn(),
      selectedSku: {
        price: {
          devicePaymentPrice: [{ contractDuration: 36 }],
          fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
          preferredTerm: null,
        },
        inventoryDetails: {
          dFillInventory: {
            isInStock: true,
          },
          localInventory: {
            isInStock: true,
          }
        },
        color: { displayName: 'Black', colorCssStyle: '#000' },
        sorId: 'sku1',
        capacity: '128GB',
        imageUrlMap: {},
      },
      setSelectedSku: jest.fn(),
      selectedProtectionFeature: {},
      setSelectedProtectionFeature: jest.fn(),
      selectedSize: '128GB',
      setSelectedSize: jest.fn(),
      setUpgradeReasonType: jest.fn(),
      isAcssDfillSim: false,
      isNewlyAddedLine: false,
      groupByColors: jest.fn(),
      groupBySmartWatchBand: jest.fn(),
      setisInStock: jest.fn(),
      setIncompatibleSim: jest.fn(),
      sendFullRetailPrice: jest.fn(),
      updateNumberShare: jest.fn(),
      updateNumberShareValue: jest.fn(),
      setSelectedPaymentInfo: jest.fn(),
      updateSimId: jest.fn(),
      updateDeviceData: jest.fn(),
      setTmpLinkClicked: jest.fn(),
      PdpBuyoutToggle: false,
      isBuyoutEligible: false,
      buyOutAccepted: false,
      setBuyOutAccepted: jest.fn(),
      setBuyoutToggleChange: jest.fn(),
      totalBuyoutAmount: 0,
      buyOutDetail: {},
      updateDeviceId: jest.fn(),
      isInStock: true,
      setSelectedPaymentInfo: setSelectedPaymentInfoMock,
      setBbPaymentOptionsSelected: jest.fn(),
      setBbyPaymetOptionPriceId: jest.fn()
    };

    const location = {
      ...window.location,
      search: '?isFromCPE=true&deviceFromCart=true',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });

    window.location.href = `http://localhost/?activeMtn=newLine1&eSim=${true}&deviceFromCart=${true}&productId=${true}&isByodUpdate=true&isEditAndView=true`;

    getAssistedCradlePropertyV2.mockReturnValue(['', 'UNL', 'FALSE', 'FALSE', 'FALSE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', '', 'TRUE'])

    isVbg.mockReturnValue(false);
    // Render DeviceInfo
    render(<DeviceInfo {...props} />);
  });
  it('if deviceFromFilteredCartLine.priceType is ONE_YEAR and isVbg is true and dpTermIndex is -1', () => {
    const setSelectedPaymentInfoMock = jest.fn();

    const InventoryDetailsResult = {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: dropshipSkuDetailsResponse || [],
    };
    APIServiceHooks.useLazyGetInventoryDetailsQuery = jest.fn(() => [
      useLazyGetInventoryDetailsQuery,
      InventoryDetailsResult,
    ]);

    const useLazyGetDevicePricingEligibilityQuery = jest.fn();
    const dpEligibilityResult = {
      status: 'rejected',
      isUninitialized: false,
      isLoading: false,
    };
    APIServiceHooks.useLazyGetDevicePricingEligibilityQuery = jest.fn(() => [
      useLazyGetDevicePricingEligibilityQuery,
      dpEligibilityResult,
    ]);

    const props = {
      details: {
        childSkus: [
          {
            price: {
              devicePaymentPrice: [],
              fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
              oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
              preferredTerm: null,
            },
            color: { displayName: 'Black', colorCssStyle: '#000' },
            sorId: 'sku1',
            capacity: '128GB',
            imageUrlMap: {},
          },
        ],
        defaultSKUObj: {
          price: {
            devicePaymentPrice: [],
            fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
            oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
            preferredTerm: null,
          },
          color: { displayName: 'Black', colorCssStyle: '#000' },
          sorId: 'sku1',
          capacity: '128GB',
          imageUrlMap: {},
        },
        childSkusByColor: [],
        isNumberShareMandatory: false,
        isNumberShareCapable: false,
      },
      productDetails: {
        deviceProduct: {},
        deviceSku: {
          sorId: 'sku1'
        },
        commonInfo: {},
      },
      protectionFeatures: {},
      cartDetails: cartDetails4.data.data,
      customerProfileDetails: { customer: { billAccounts: [{ mtns: [] }] }, commonInfo: {} },
      activeMtn: '5185673926',
      selectedColor: 'Black',
      setSelectedColor: jest.fn(),
      ispuToggleOn: false,
      setIspuToggleOn: jest.fn(),
      isShipItToggleOn: false,
      setIsShipItToggleOn: jest.fn(),
      selectedSku: {
        price: {
          devicePaymentPrice: [],
          fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
          oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
          preferredTerm: null,
        },
        inventoryDetails: {
          dFillInventory: {
            isInStock: true,
          },
          localInventory: {
            isInStock: true,
          }
        },
        color: { displayName: 'Black', colorCssStyle: '#000' },
        sorId: 'sku1',
        capacity: '128GB',
        imageUrlMap: {},
      },
      setSelectedSku: jest.fn(),
      selectedProtectionFeature: {},
      setSelectedProtectionFeature: jest.fn(),
      selectedSize: '128GB',
      setSelectedSize: jest.fn(),
      setUpgradeReasonType: jest.fn(),
      isAcssDfillSim: false,
      isNewlyAddedLine: false,
      groupByColors: jest.fn(),
      groupBySmartWatchBand: jest.fn(),
      setisInStock: jest.fn(),
      setIncompatibleSim: jest.fn(),
      sendFullRetailPrice: jest.fn(),
      updateNumberShare: jest.fn(),
      updateNumberShareValue: jest.fn(),
      setSelectedPaymentInfo: jest.fn(),
      updateSimId: jest.fn(),
      updateDeviceData: jest.fn(),
      setTmpLinkClicked: jest.fn(),
      PdpBuyoutToggle: false,
      isBuyoutEligible: false,
      buyOutAccepted: false,
      setBuyOutAccepted: jest.fn(),
      setBuyoutToggleChange: jest.fn(),
      totalBuyoutAmount: 0,
      buyOutDetail: {},
      updateDeviceId: jest.fn(),
      isInStock: true,
      setSelectedPaymentInfo: setSelectedPaymentInfoMock,
      setBbPaymentOptionsSelected: jest.fn(),
      setBbyPaymetOptionPriceId: jest.fn()
    };

    const location = {
      ...window.location,
      search: '?isFromCPE=true&deviceFromCart=true',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });

    window.location.href = `http://localhost/?activeMtn=newLine1&eSim=${true}&deviceFromCart=${true}&productId=${true}&isByodUpdate=true&isEditAndView=true`;

    getAssistedCradlePropertyV2.mockReturnValue(['', 'UNL', 'FALSE', 'FALSE', 'FALSE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', '', 'TRUE'])

    isVbg.mockReturnValue(true);
    // Render DeviceInfo
    render(<DeviceInfo {...props} />);
  });
  it('if deviceFromFilteredCartLine.priceType is ONE_YEAR and isVbg is true and dpTermIndex is -1 and contractPrice is not present', () => {
    const setSelectedPaymentInfoMock = jest.fn();

    const InventoryDetailsResult = {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: dropshipSkuDetailsResponse || [],
    };
    APIServiceHooks.useLazyGetInventoryDetailsQuery = jest.fn(() => [
      useLazyGetInventoryDetailsQuery,
      InventoryDetailsResult,
    ]);

    const useLazyGetDevicePricingEligibilityQuery = jest.fn();
    const dpEligibilityResult = {
      status: 'rejected',
      isUninitialized: false,
      isLoading: false,
    };
    APIServiceHooks.useLazyGetDevicePricingEligibilityQuery = jest.fn(() => [
      useLazyGetDevicePricingEligibilityQuery,
      dpEligibilityResult,
    ]);

    const props = {
      details: {
        childSkus: [
          {
            price: {
              devicePaymentPrice: [],
              preferredTerm: null,
            },
            color: { displayName: 'Black', colorCssStyle: '#000' },
            sorId: 'sku1',
            capacity: '128GB',
            imageUrlMap: {},
          },
        ],
        defaultSKUObj: {
          price: {
            devicePaymentPrice: [],
            preferredTerm: null,
          },
          color: { displayName: 'Black', colorCssStyle: '#000' },
          sorId: 'sku1',
          capacity: '128GB',
          imageUrlMap: {},
        },
        childSkusByColor: [],
        isNumberShareMandatory: false,
        isNumberShareCapable: false,
      },
      productDetails: {
        deviceProduct: {},
        deviceSku: {
          sorId: 'sku1'
        },
        commonInfo: {},
      },
      protectionFeatures: {},
      cartDetails: cartDetails4.data.data,
      customerProfileDetails: { customer: { billAccounts: [{ mtns: [] }] }, commonInfo: {} },
      activeMtn: '5185673926',
      selectedColor: 'Black',
      setSelectedColor: jest.fn(),
      ispuToggleOn: false,
      setIspuToggleOn: jest.fn(),
      isShipItToggleOn: false,
      setIsShipItToggleOn: jest.fn(),
      selectedSku: {
        price: {
          devicePaymentPrice: [],
          preferredTerm: null,
        },
        inventoryDetails: {
          dFillInventory: {
            isInStock: true,
          },
          localInventory: {
            isInStock: true,
          }
        },
        color: { displayName: 'Black', colorCssStyle: '#000' },
        sorId: 'sku1',
        capacity: '128GB',
        imageUrlMap: {},
      },
      setSelectedSku: jest.fn(),
      selectedProtectionFeature: {},
      setSelectedProtectionFeature: jest.fn(),
      selectedSize: '128GB',
      setSelectedSize: jest.fn(),
      setUpgradeReasonType: jest.fn(),
      isAcssDfillSim: false,
      isNewlyAddedLine: false,
      groupByColors: jest.fn(),
      groupBySmartWatchBand: jest.fn(),
      setisInStock: jest.fn(),
      setIncompatibleSim: jest.fn(),
      sendFullRetailPrice: jest.fn(),
      updateNumberShare: jest.fn(),
      updateNumberShareValue: jest.fn(),
      setSelectedPaymentInfo: jest.fn(),
      updateSimId: jest.fn(),
      updateDeviceData: jest.fn(),
      setTmpLinkClicked: jest.fn(),
      PdpBuyoutToggle: false,
      isBuyoutEligible: false,
      buyOutAccepted: false,
      setBuyOutAccepted: jest.fn(),
      setBuyoutToggleChange: jest.fn(),
      totalBuyoutAmount: 0,
      buyOutDetail: {},
      updateDeviceId: jest.fn(),
      isInStock: true,
      setSelectedPaymentInfo: setSelectedPaymentInfoMock,
      setBbPaymentOptionsSelected: jest.fn(),
      setBbyPaymetOptionPriceId: jest.fn()
    };

    const location = {
      ...window.location,
      search: '?isFromCPE=true&deviceFromCart=true',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });

    window.location.href = `http://localhost/?activeMtn=newLine1&eSim=${true}&deviceFromCart=${true}&productId=${true}&isByodUpdate=true&isEditAndView=true`;

    getAssistedCradlePropertyV2.mockReturnValue(['', 'UNL', 'FALSE', 'FALSE', 'FALSE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', '', 'TRUE'])

    isVbg.mockReturnValue(true);
    // Render DeviceInfo
    render(<DeviceInfo {...props} />);
  });
  it('if deviceFromFilteredCartLine.priceType is DEVICE_PAYMENT and isVbg is true and dpTermIndex is not -1', () => {
    const setSelectedPaymentInfoMock = jest.fn();

    const InventoryDetailsResult = {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: dropshipSkuDetailsResponse || [],
    };
    APIServiceHooks.useLazyGetInventoryDetailsQuery = jest.fn(() => [
      useLazyGetInventoryDetailsQuery,
      InventoryDetailsResult,
    ]);

    const useLazyGetDevicePricingEligibilityQuery = jest.fn();
    const dpEligibilityResult = {
      status: 'rejected',
      isUninitialized: false,
      isLoading: false,
    };
    APIServiceHooks.useLazyGetDevicePricingEligibilityQuery = jest.fn(() => [
      useLazyGetDevicePricingEligibilityQuery,
      dpEligibilityResult,
    ]);

    const props = {
      details: {
        childSkus: [
          {
            price: {
              devicePaymentPrice: [
                { contractDuration: 36, dpTermPrices: { remainingMonthPrice: 15 } },
                { contractDuration: 24, dpTermPrices: { remainingMonthPrice: 20 } },
                { contractDuration: 30, dpTermPrices: { remainingMonthPrice: 18 } },
              ],
              fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
              oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
              preferredTerm: null,
            },
            color: { displayName: 'Black', colorCssStyle: '#000' },
            sorId: 'sku1',
            capacity: '128GB',
            imageUrlMap: {},
          },
        ],
        defaultSKUObj: {
          price: {
            devicePaymentPrice: [
              { contractDuration: 36, dpTermPrices: { remainingMonthPrice: 15 } },
              { contractDuration: 24, dpTermPrices: { remainingMonthPrice: 20 } },
              { contractDuration: 30, dpTermPrices: { remainingMonthPrice: 18 } },
            ],
            fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
            oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
            preferredTerm: null,
          },
          color: { displayName: 'Black', colorCssStyle: '#000' },
          sorId: 'sku1',
          capacity: '128GB',
          imageUrlMap: {},
        },
        childSkusByColor: [],
        isNumberShareMandatory: false,
        isNumberShareCapable: false,
      },
      productDetails: {
        deviceProduct: {},
        deviceSku: {
          sorId: 'sku1'
        },
        commonInfo: {},
      },
      protectionFeatures: {},
      cartDetails: cartDetails4.data.data,
      customerProfileDetails: { customer: { billAccounts: [{ mtns: [] }] }, commonInfo: {} },
      activeMtn: '5185673926',
      selectedColor: 'Black',
      setSelectedColor: jest.fn(),
      ispuToggleOn: false,
      setIspuToggleOn: jest.fn(),
      isShipItToggleOn: false,
      setIsShipItToggleOn: jest.fn(),
      selectedSku: {
        price: {
          devicePaymentPrice: [
            { contractDuration: 36, dpTermPrices: { remainingMonthPrice: 15, dpTerm: 36 } },
            { contractDuration: 24, dpTermPrices: { remainingMonthPrice: 20, dpTerm: 24 } },
            { contractDuration: 30, dpTermPrices: { remainingMonthPrice: 18, dpTerm: 30 } },
          ],
          fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
          oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
          preferredTerm: null,
        },
        inventoryDetails: {
          dFillInventory: {
            isInStock: true,
          },
          localInventory: {
            isInStock: true,
          }
        },
        color: { displayName: 'Black', colorCssStyle: '#000' },
        sorId: 'sku1',
        capacity: '128GB',
        imageUrlMap: {},
      },
      setSelectedSku: jest.fn(),
      selectedProtectionFeature: {},
      setSelectedProtectionFeature: jest.fn(),
      selectedSize: '128GB',
      setSelectedSize: jest.fn(),
      setUpgradeReasonType: jest.fn(),
      isAcssDfillSim: false,
      isNewlyAddedLine: false,
      groupByColors: jest.fn(),
      groupBySmartWatchBand: jest.fn(),
      setisInStock: jest.fn(),
      setIncompatibleSim: jest.fn(),
      sendFullRetailPrice: jest.fn(),
      updateNumberShare: jest.fn(),
      updateNumberShareValue: jest.fn(),
      setSelectedPaymentInfo: jest.fn(),
      updateSimId: jest.fn(),
      updateDeviceData: jest.fn(),
      setTmpLinkClicked: jest.fn(),
      PdpBuyoutToggle: false,
      isBuyoutEligible: false,
      buyOutAccepted: false,
      setBuyOutAccepted: jest.fn(),
      setBuyoutToggleChange: jest.fn(),
      totalBuyoutAmount: 0,
      buyOutDetail: {},
      updateDeviceId: jest.fn(),
      isInStock: true,
      setSelectedPaymentInfo: setSelectedPaymentInfoMock,
      setBbPaymentOptionsSelected: jest.fn(),
      setBbyPaymetOptionPriceId: jest.fn()
    };

    const location = {
      ...window.location,
      search: '?isFromCPE=true&deviceFromCart=true',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });

    window.location.href = `http://localhost/?activeMtn=newLine1&eSim=${true}&deviceFromCart=${true}&productId=${true}&isByodUpdate=true&isEditAndView=true`;

    getAssistedCradlePropertyV2.mockReturnValue(['', 'UNL', 'FALSE', 'FALSE', 'FALSE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', '', 'TRUE'])

    isVbg.mockReturnValue(true);
    // Render DeviceInfo
    render(<DeviceInfo {...props} />);
  });
  it('deviceFromFilteredCartLine.priceType is DEVICE_PAYMENT and isVbg is true and dpTermIndex is not -1 and computeDpPriceResult is present and sku matches', () => {
    const setSelectedPaymentInfoMock = jest.fn();

    const InventoryDetailsResult = {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: dropshipSkuDetailsResponse || [],
    };
    APIServiceHooks.useLazyGetInventoryDetailsQuery = jest.fn(() => [
      useLazyGetInventoryDetailsQuery,
      InventoryDetailsResult,
    ]);

    const useLazyGetDevicePricingEligibilityQuery = jest.fn();
    const dpEligibilityResult = {
      status: 'rejected',
      isUninitialized: false,
      isLoading: false,
    };
    APIServiceHooks.useLazyGetDevicePricingEligibilityQuery = jest.fn(() => [
      useLazyGetDevicePricingEligibilityQuery,
      dpEligibilityResult,
    ]);

    const props = {
      details: {
        childSkus: [
          {
            price: {
              devicePaymentPrice: [
                { contractDuration: 36, dpTermPrices: { remainingMonthPrice: 15 } },
                { contractDuration: 24, dpTermPrices: { remainingMonthPrice: 20 } },
                { contractDuration: 30, dpTermPrices: { remainingMonthPrice: 18 } },
              ],
              fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
              oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
              preferredTerm: null,
            },
            color: { displayName: 'Black', colorCssStyle: '#000' },
            sorId: 'sku1',
            capacity: '128GB',
            imageUrlMap: {},
          },
        ],
        defaultSKUObj: {
          price: {
            devicePaymentPrice: [
              { contractDuration: 36, dpTermPrices: { remainingMonthPrice: 15 } },
              { contractDuration: 24, dpTermPrices: { remainingMonthPrice: 20 } },
              { contractDuration: 30, dpTermPrices: { remainingMonthPrice: 18 } },
            ],
            fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
            oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
            preferredTerm: null,
          },
          color: { displayName: 'Black', colorCssStyle: '#000' },
          sorId: 'sku1',
          capacity: '128GB',
          imageUrlMap: {},
        },
        childSkusByColor: [],
        isNumberShareMandatory: false,
        isNumberShareCapable: false,
      },
      productDetails: {
        deviceProduct: {},
        deviceSku: {
          sorId: 'sku1'
        },
        commonInfo: {},
      },
      protectionFeatures: {},
      cartDetails: cartDetails4.data.data,
      customerProfileDetails: { customer: { billAccounts: [{ mtns: [] }] }, commonInfo: {} },
      activeMtn: '5185673926',
      selectedColor: 'Black',
      setSelectedColor: jest.fn(),
      ispuToggleOn: false,
      setIspuToggleOn: jest.fn(),
      isShipItToggleOn: false,
      setIsShipItToggleOn: jest.fn(),
      selectedSku: {
        price: {
          devicePaymentPrice: [
            { contractDuration: 36, dpTermPrices: { remainingMonthPrice: 15, dpTerm: 36 } },
            { contractDuration: 24, dpTermPrices: { remainingMonthPrice: 20, dpTerm: 24 } },
            { contractDuration: 30, dpTermPrices: { remainingMonthPrice: 18, dpTerm: 30 } },
          ],
          fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
          oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
          preferredTerm: null,
        },
        inventoryDetails: {
          dFillInventory: {
            isInStock: true,
          },
          localInventory: {
            isInStock: true,
          }
        },
        color: { displayName: 'Black', colorCssStyle: '#000' },
        sorId: 'SMS911UZEV',
        capacity: '128GB',
        imageUrlMap: {},
      },
      setSelectedSku: jest.fn(),
      selectedProtectionFeature: {},
      setSelectedProtectionFeature: jest.fn(),
      selectedSize: '128GB',
      setSelectedSize: jest.fn(),
      setUpgradeReasonType: jest.fn(),
      isAcssDfillSim: false,
      isNewlyAddedLine: false,
      groupByColors: jest.fn(),
      groupBySmartWatchBand: jest.fn(),
      setisInStock: jest.fn(),
      setIncompatibleSim: jest.fn(),
      sendFullRetailPrice: jest.fn(),
      updateNumberShare: jest.fn(),
      updateNumberShareValue: jest.fn(),
      setSelectedPaymentInfo: jest.fn(),
      updateSimId: jest.fn(),
      updateDeviceData: jest.fn(),
      setTmpLinkClicked: jest.fn(),
      PdpBuyoutToggle: false,
      isBuyoutEligible: false,
      buyOutAccepted: false,
      setBuyOutAccepted: jest.fn(),
      setBuyoutToggleChange: jest.fn(),
      totalBuyoutAmount: 0,
      buyOutDetail: {},
      updateDeviceId: jest.fn(),
      isInStock: true,
      setSelectedPaymentInfo: setSelectedPaymentInfoMock,
      setBbPaymentOptionsSelected: jest.fn(),
      setBbyPaymetOptionPriceId: jest.fn(),
      computeDPPriceResult: {
        status: 'fulfilled',
        endpointName: 'computeDPPrices',
        requestId: 'lf2MRsFlucEKnButXAPgU',
        originalArgs: {
          body: {
            sorId: 'SMS911UZEV',
            mtn: '2164706958',
            term: 36,
            downPayment: 10,
            isPercentage: true,
            agentOrFullRetailPrice: 1029.99,
          },
          spinner: false,
        },
        startedTimeStamp: 1720705629368,
        data: {
          firstMonthPrice: 26.09,
          remainingMonthPrice: 25.74,
          dpTerm: 36,
          downPayment: 103,
          mtn: '2164706958',
        },
        fulfilledTimeStamp: 1720705629906,
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: false,
        currentData: {
          firstMonthPrice: 26.09,
          remainingMonthPrice: 25.74,
          dpTerm: 36,
          downPayment: 103,
          mtn: '2164706958',
        },
        isFetching: false,
      }
    };

    const location = {
      ...window.location,
      search: '?isFromCPE=true&deviceFromCart=true',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });

    window.location.href = `http://localhost/?activeMtn=newLine1&eSim=${true}&deviceFromCart=${true}&productId=${true}&isByodUpdate=true&isEditAndView=true`;

    getAssistedCradlePropertyV2.mockReturnValue(['', 'UNL', 'FALSE', 'FALSE', 'FALSE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', '', 'TRUE'])

    isVbg.mockReturnValue(true);
    // Render DeviceInfo
    render(<DeviceInfo {...props} />);
  });
  it('deviceFromFilteredCartLine.priceType is DEVICE_PAYMENT and isVbg is true and dpTermIndex is not -1 and computeDpPriceResult is present but sku does not match and downPayment is non-zero', () => {
    const setSelectedPaymentInfoMock = jest.fn();

    const InventoryDetailsResult = {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: dropshipSkuDetailsResponse || [],
    };
    APIServiceHooks.useLazyGetInventoryDetailsQuery = jest.fn(() => [
      useLazyGetInventoryDetailsQuery,
      InventoryDetailsResult,
    ]);

    const useLazyGetDevicePricingEligibilityQuery = jest.fn();
    const dpEligibilityResult = {
      status: 'rejected',
      isUninitialized: false,
      isLoading: false,
    };
    APIServiceHooks.useLazyGetDevicePricingEligibilityQuery = jest.fn(() => [
      useLazyGetDevicePricingEligibilityQuery,
      dpEligibilityResult,
    ]);

    const props = {
      details: {
        childSkus: [
          {
            price: {
              devicePaymentPrice: [
                { contractDuration: 36, dpTermPrices: { remainingMonthPrice: 15 } },
                { contractDuration: 24, dpTermPrices: { remainingMonthPrice: 20 } },
                { contractDuration: 30, dpTermPrices: { remainingMonthPrice: 18 } },
              ],
              fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
              oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
              preferredTerm: null,
            },
            color: { displayName: 'Black', colorCssStyle: '#000' },
            sorId: 'sku1',
            capacity: '128GB',
            imageUrlMap: {},
          },
        ],
        defaultSKUObj: {
          price: {
            devicePaymentPrice: [
              { contractDuration: 36, dpTermPrices: { remainingMonthPrice: 15 } },
              { contractDuration: 24, dpTermPrices: { remainingMonthPrice: 20 } },
              { contractDuration: 30, dpTermPrices: { remainingMonthPrice: 18 } },
            ],
            fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
            oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
            preferredTerm: null,
          },
          color: { displayName: 'Black', colorCssStyle: '#000' },
          sorId: 'sku1',
          capacity: '128GB',
          imageUrlMap: {},
        },
        childSkusByColor: [],
        isNumberShareMandatory: false,
        isNumberShareCapable: false,
      },
      productDetails: {
        deviceProduct: {},
        deviceSku: {
          sorId: 'sku1'
        },
        commonInfo: {},
      },
      protectionFeatures: {},
      cartDetails: cartDetails4.data.data,
      customerProfileDetails: { customer: { billAccounts: [{ mtns: [] }] }, commonInfo: {} },
      activeMtn: '5185673926',
      selectedColor: 'Black',
      setSelectedColor: jest.fn(),
      ispuToggleOn: false,
      setIspuToggleOn: jest.fn(),
      isShipItToggleOn: false,
      setIsShipItToggleOn: jest.fn(),
      selectedSku: {
        price: {
          devicePaymentPrice: [
            { contractDuration: 36, dpTermPrices: { remainingMonthPrice: 15, dpTerm: 36 } },
            { contractDuration: 24, dpTermPrices: { remainingMonthPrice: 20, dpTerm: 24 } },
            { contractDuration: 30, dpTermPrices: { remainingMonthPrice: 18, dpTerm: 30 } },
          ],
          fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
          oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
          preferredTerm: null,
        },
        inventoryDetails: {
          dFillInventory: {
            isInStock: true,
          },
          localInventory: {
            isInStock: true,
          }
        },
        color: { displayName: 'Black', colorCssStyle: '#000' },
        sorId: 'sku1',
        capacity: '128GB',
        imageUrlMap: {},
      },
      setSelectedSku: jest.fn(),
      selectedProtectionFeature: {},
      setSelectedProtectionFeature: jest.fn(),
      selectedSize: '128GB',
      setSelectedSize: jest.fn(),
      setUpgradeReasonType: jest.fn(),
      isAcssDfillSim: false,
      isNewlyAddedLine: false,
      groupByColors: jest.fn(),
      groupBySmartWatchBand: jest.fn(),
      setisInStock: jest.fn(),
      setIncompatibleSim: jest.fn(),
      sendFullRetailPrice: jest.fn(),
      updateNumberShare: jest.fn(),
      updateNumberShareValue: jest.fn(),
      setSelectedPaymentInfo: jest.fn(),
      updateSimId: jest.fn(),
      updateDeviceData: jest.fn(),
      setTmpLinkClicked: jest.fn(),
      PdpBuyoutToggle: false,
      isBuyoutEligible: false,
      buyOutAccepted: false,
      setBuyOutAccepted: jest.fn(),
      setBuyoutToggleChange: jest.fn(),
      totalBuyoutAmount: 0,
      buyOutDetail: {},
      updateDeviceId: jest.fn(),
      isInStock: true,
      setSelectedPaymentInfo: setSelectedPaymentInfoMock,
      setBbPaymentOptionsSelected: jest.fn(),
      setBbyPaymetOptionPriceId: jest.fn(),
      computeDPPriceResult: {
        status: 'fulfilled',
        endpointName: 'computeDPPrices',
        requestId: 'lf2MRsFlucEKnButXAPgU',
        originalArgs: {
          body: {
            sorId: 'SMS911UZEV',
            mtn: '2164706958',
            term: 36,
            downPayment: 10,
            isPercentage: true,
            agentOrFullRetailPrice: 1029.99,
          },
          spinner: false,
        },
        startedTimeStamp: 1720705629368,
        data: {
          firstMonthPrice: 26.09,
          remainingMonthPrice: 25.74,
          dpTerm: 36,
          downPayment: 103,
          mtn: '2164706958',
        },
        fulfilledTimeStamp: 1720705629906,
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: false,
        currentData: {
          firstMonthPrice: 26.09,
          remainingMonthPrice: 25.74,
          dpTerm: 36,
          downPayment: 103,
          mtn: '2164706958',
        },
        isFetching: false,
      }
    };

    const location = {
      ...window.location,
      search: '?isFromCPE=true&deviceFromCart=true',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });

    window.location.href = `http://localhost/?activeMtn=newLine1&eSim=${true}&deviceFromCart=${true}&productId=${true}&isByodUpdate=true&isEditAndView=true`;

    getAssistedCradlePropertyV2.mockReturnValue(['', 'UNL', 'FALSE', 'FALSE', 'FALSE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', '', 'TRUE'])

    isVbg.mockReturnValue(true);
    // Render DeviceInfo
    render(<DeviceInfo {...props} />);
  });
  it('deviceFromFilteredCartLine.priceType is DEVICE_PAYMENT and isVbg is true and dpTermIndex is not -1 and computeDpPriceResult is present but sku does not match and downPayment is zero', () => {
    const setSelectedPaymentInfoMock = jest.fn();

    const InventoryDetailsResult = {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: dropshipSkuDetailsResponse || [],
    };
    APIServiceHooks.useLazyGetInventoryDetailsQuery = jest.fn(() => [
      useLazyGetInventoryDetailsQuery,
      InventoryDetailsResult,
    ]);

    const useLazyGetDevicePricingEligibilityQuery = jest.fn();
    const dpEligibilityResult = {
      status: 'rejected',
      isUninitialized: false,
      isLoading: false,
    };
    APIServiceHooks.useLazyGetDevicePricingEligibilityQuery = jest.fn(() => [
      useLazyGetDevicePricingEligibilityQuery,
      dpEligibilityResult,
    ]);

    const props = {
      details: {
        childSkus: [
          {
            price: {
              devicePaymentPrice: [
                { contractDuration: 36, dpTermPrices: { remainingMonthPrice: 15 } },
                { contractDuration: 24, dpTermPrices: { remainingMonthPrice: 20 } },
                { contractDuration: 30, dpTermPrices: { remainingMonthPrice: 18 } },
              ],
              fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
              oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
              preferredTerm: null,
            },
            color: { displayName: 'Black', colorCssStyle: '#000' },
            sorId: 'sku1',
            capacity: '128GB',
            imageUrlMap: {},
          },
        ],
        defaultSKUObj: {
          price: {
            devicePaymentPrice: [
              { contractDuration: 36, dpTermPrices: { remainingMonthPrice: 15 } },
              { contractDuration: 24, dpTermPrices: { remainingMonthPrice: 20 } },
              { contractDuration: 30, dpTermPrices: { remainingMonthPrice: 18 } },
            ],
            fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
            oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
            preferredTerm: null,
          },
          color: { displayName: 'Black', colorCssStyle: '#000' },
          sorId: 'sku1',
          capacity: '128GB',
          imageUrlMap: {},
        },
        childSkusByColor: [],
        isNumberShareMandatory: false,
        isNumberShareCapable: false,
      },
      productDetails: {
        deviceProduct: {},
        deviceSku: {
          sorId: 'sku1'
        },
        commonInfo: {},
      },
      protectionFeatures: {},
      cartDetails: cartDetails4.data.data,
      customerProfileDetails: { customer: { billAccounts: [{ mtns: [] }] }, commonInfo: {} },
      activeMtn: 'newLine3',
      selectedColor: 'Black',
      setSelectedColor: jest.fn(),
      ispuToggleOn: false,
      setIspuToggleOn: jest.fn(),
      isShipItToggleOn: false,
      setIsShipItToggleOn: jest.fn(),
      selectedSku: {
        price: {
          devicePaymentPrice: [
            { contractDuration: 36, dpTermPrices: { remainingMonthPrice: 15, dpTerm: 36 } },
            { contractDuration: 24, dpTermPrices: { remainingMonthPrice: 20, dpTerm: 24 } },
            { contractDuration: 30, dpTermPrices: { remainingMonthPrice: 18, dpTerm: 30 } },
          ],
          fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
          oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
          preferredTerm: null,
        },
        inventoryDetails: {
          dFillInventory: {
            isInStock: true,
          },
          localInventory: {
            isInStock: true,
          }
        },
        color: { displayName: 'Black', colorCssStyle: '#000' },
        sorId: 'sku1',
        capacity: '128GB',
        imageUrlMap: {},
      },
      setSelectedSku: jest.fn(),
      selectedProtectionFeature: {},
      setSelectedProtectionFeature: jest.fn(),
      selectedSize: '128GB',
      setSelectedSize: jest.fn(),
      setUpgradeReasonType: jest.fn(),
      isAcssDfillSim: false,
      isNewlyAddedLine: false,
      groupByColors: jest.fn(),
      groupBySmartWatchBand: jest.fn(),
      setisInStock: jest.fn(),
      setIncompatibleSim: jest.fn(),
      sendFullRetailPrice: jest.fn(),
      updateNumberShare: jest.fn(),
      updateNumberShareValue: jest.fn(),
      setSelectedPaymentInfo: jest.fn(),
      updateSimId: jest.fn(),
      updateDeviceData: jest.fn(),
      setTmpLinkClicked: jest.fn(),
      PdpBuyoutToggle: false,
      isBuyoutEligible: false,
      buyOutAccepted: false,
      setBuyOutAccepted: jest.fn(),
      setBuyoutToggleChange: jest.fn(),
      totalBuyoutAmount: 0,
      buyOutDetail: {},
      updateDeviceId: jest.fn(),
      isInStock: true,
      setSelectedPaymentInfo: setSelectedPaymentInfoMock,
      setBbPaymentOptionsSelected: jest.fn(),
      setBbyPaymetOptionPriceId: jest.fn(),
      computeDPPriceResult: {
        status: 'fulfilled',
        endpointName: 'computeDPPrices',
        requestId: 'lf2MRsFlucEKnButXAPgU',
        originalArgs: {
          body: {
            sorId: 'SMS911UZEV',
            mtn: '2164706958',
            term: 36,
            downPayment: 10,
            isPercentage: true,
            agentOrFullRetailPrice: 1029.99,
          },
          spinner: false,
        },
        startedTimeStamp: 1720705629368,
        data: {
          firstMonthPrice: 26.09,
          remainingMonthPrice: 25.74,
          dpTerm: 36,
          downPayment: 103,
          mtn: '2164706958',
        },
        fulfilledTimeStamp: 1720705629906,
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: false,
        currentData: {
          firstMonthPrice: 26.09,
          remainingMonthPrice: 25.74,
          dpTerm: 36,
          downPayment: 103,
          mtn: '2164706958',
        },
        isFetching: false,
      }
    };

    const location = {
      ...window.location,
      search: '?isFromCPE=true&deviceFromCart=true',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });

    window.location.href = `http://localhost/?activeMtn=newLine1&eSim=${true}&deviceFromCart=${true}&productId=${true}&isByodUpdate=true&isEditAndView=true`;

    getAssistedCradlePropertyV2.mockReturnValue(['', 'UNL', 'FALSE', 'FALSE', 'FALSE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', '', 'TRUE'])

    isVbg.mockReturnValue(true);
    // Render DeviceInfo
    render(<DeviceInfo {...props} />);
  });
  it('deviceFromFilteredCartLine.priceType is DEVICE_PAYMENT and isVbg is false and computeDpPriceResult is present and sku matches', () => {
    const setSelectedPaymentInfoMock = jest.fn();

    const InventoryDetailsResult = {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: dropshipSkuDetailsResponse || [],
    };
    APIServiceHooks.useLazyGetInventoryDetailsQuery = jest.fn(() => [
      useLazyGetInventoryDetailsQuery,
      InventoryDetailsResult,
    ]);

    const useLazyGetDevicePricingEligibilityQuery = jest.fn();
    const dpEligibilityResult = {
      status: 'rejected',
      isUninitialized: false,
      isLoading: false,
    };
    APIServiceHooks.useLazyGetDevicePricingEligibilityQuery = jest.fn(() => [
      useLazyGetDevicePricingEligibilityQuery,
      dpEligibilityResult,
    ]);

    const props = {
      details: {
        childSkus: [
          {
            price: {
              devicePaymentPrice: [
                { contractDuration: 36, dpTermPrices: { remainingMonthPrice: 15 } },
                { contractDuration: 24, dpTermPrices: { remainingMonthPrice: 20 } },
                { contractDuration: 30, dpTermPrices: { remainingMonthPrice: 18 } },
              ],
              fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
              oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
              preferredTerm: null,
            },
            color: { displayName: 'Black', colorCssStyle: '#000' },
            sorId: 'sku1',
            capacity: '128GB',
            imageUrlMap: {},
          },
        ],
        defaultSKUObj: {
          price: {
            devicePaymentPrice: [
              { contractDuration: 36, dpTermPrices: { remainingMonthPrice: 15 } },
              { contractDuration: 24, dpTermPrices: { remainingMonthPrice: 20 } },
              { contractDuration: 30, dpTermPrices: { remainingMonthPrice: 18 } },
            ],
            fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
            oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
            preferredTerm: null,
          },
          color: { displayName: 'Black', colorCssStyle: '#000' },
          sorId: 'sku1',
          capacity: '128GB',
          imageUrlMap: {},
        },
        childSkusByColor: [],
        isNumberShareMandatory: false,
        isNumberShareCapable: false,
      },
      productDetails: {
        deviceProduct: {},
        deviceSku: {
          sorId: 'sku1'
        },
        commonInfo: {},
      },
      protectionFeatures: {},
      cartDetails: cartDetails4.data.data,
      customerProfileDetails: { customer: { billAccounts: [{ mtns: [] }] }, commonInfo: {} },
      activeMtn: '5185673926',
      selectedColor: 'Black',
      setSelectedColor: jest.fn(),
      ispuToggleOn: false,
      setIspuToggleOn: jest.fn(),
      isShipItToggleOn: false,
      setIsShipItToggleOn: jest.fn(),
      selectedSku: {
        price: {
          devicePaymentPrice: [
            { contractDuration: 36, dpTermPrices: { remainingMonthPrice: 15, dpTerm: 36 } },
            { contractDuration: 24, dpTermPrices: { remainingMonthPrice: 20, dpTerm: 24 } },
            { contractDuration: 30, dpTermPrices: { remainingMonthPrice: 18, dpTerm: 30 } },
          ],
          fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
          oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
          preferredTerm: null,
        },
        inventoryDetails: {
          dFillInventory: {
            isInStock: true,
          },
          localInventory: {
            isInStock: true,
          }
        },
        color: { displayName: 'Black', colorCssStyle: '#000' },
        sorId: 'SMS911UZEV',
        capacity: '128GB',
        imageUrlMap: {},
      },
      setSelectedSku: jest.fn(),
      selectedProtectionFeature: {},
      setSelectedProtectionFeature: jest.fn(),
      selectedSize: '128GB',
      setSelectedSize: jest.fn(),
      setUpgradeReasonType: jest.fn(),
      isAcssDfillSim: false,
      isNewlyAddedLine: false,
      groupByColors: jest.fn(),
      groupBySmartWatchBand: jest.fn(),
      setisInStock: jest.fn(),
      setIncompatibleSim: jest.fn(),
      sendFullRetailPrice: jest.fn(),
      updateNumberShare: jest.fn(),
      updateNumberShareValue: jest.fn(),
      setSelectedPaymentInfo: jest.fn(),
      updateSimId: jest.fn(),
      updateDeviceData: jest.fn(),
      setTmpLinkClicked: jest.fn(),
      PdpBuyoutToggle: false,
      isBuyoutEligible: false,
      buyOutAccepted: false,
      setBuyOutAccepted: jest.fn(),
      setBuyoutToggleChange: jest.fn(),
      totalBuyoutAmount: 0,
      buyOutDetail: {},
      updateDeviceId: jest.fn(),
      isInStock: true,
      setSelectedPaymentInfo: setSelectedPaymentInfoMock,
      setBbPaymentOptionsSelected: jest.fn(),
      setBbyPaymetOptionPriceId: jest.fn(),
      computeDPPriceResult: {
        status: 'fulfilled',
        endpointName: 'computeDPPrices',
        requestId: 'lf2MRsFlucEKnButXAPgU',
        originalArgs: {
          body: {
            sorId: 'SMS911UZEV',
            mtn: '2164706958',
            term: 36,
            downPayment: 10,
            isPercentage: true,
            agentOrFullRetailPrice: 1029.99,
          },
          spinner: false,
        },
        startedTimeStamp: 1720705629368,
        data: {
          firstMonthPrice: 26.09,
          remainingMonthPrice: 25.74,
          dpTerm: 36,
          downPayment: 103,
          mtn: '2164706958',
        },
        fulfilledTimeStamp: 1720705629906,
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: false,
        currentData: {
          firstMonthPrice: 26.09,
          remainingMonthPrice: 25.74,
          dpTerm: 36,
          downPayment: 103,
          mtn: '2164706958',
        },
        isFetching: false,
      }
    };

    const location = {
      ...window.location,
      search: '?isFromCPE=true&deviceFromCart=true',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });

    window.location.href = `http://localhost/?activeMtn=newLine1&eSim=${true}&deviceFromCart=${true}&productId=${true}&isByodUpdate=true&isEditAndView=true`;

    getAssistedCradlePropertyV2.mockReturnValue(['', 'UNL', 'FALSE', 'FALSE', 'FALSE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', '', 'TRUE'])

    isVbg.mockReturnValue(false);
    // Render DeviceInfo
    render(<DeviceInfo {...props} />);
  });
  it('deviceFromFilteredCartLine.priceType is DEVICE_PAYMENT and isVbg is false and computeDpPriceResult is present but sku does not match and downPayment is non-zero', () => {
    const setSelectedPaymentInfoMock = jest.fn();

    const InventoryDetailsResult = {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: dropshipSkuDetailsResponse || [],
    };
    APIServiceHooks.useLazyGetInventoryDetailsQuery = jest.fn(() => [
      useLazyGetInventoryDetailsQuery,
      InventoryDetailsResult,
    ]);

    const useLazyGetDevicePricingEligibilityQuery = jest.fn();
    const dpEligibilityResult = {
      status: 'rejected',
      isUninitialized: false,
      isLoading: false,
    };
    APIServiceHooks.useLazyGetDevicePricingEligibilityQuery = jest.fn(() => [
      useLazyGetDevicePricingEligibilityQuery,
      dpEligibilityResult,
    ]);

    const props = {
      details: {
        childSkus: [
          {
            price: {
              devicePaymentPrice: [
                { contractDuration: 36, dpTermPrices: { remainingMonthPrice: 15 } },
                { contractDuration: 24, dpTermPrices: { remainingMonthPrice: 20 } },
                { contractDuration: 30, dpTermPrices: { remainingMonthPrice: 18 } },
              ],
              fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
              oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
              preferredTerm: null,
            },
            color: { displayName: 'Black', colorCssStyle: '#000' },
            sorId: 'sku1',
            capacity: '128GB',
            imageUrlMap: {},
          },
        ],
        defaultSKUObj: {
          price: {
            devicePaymentPrice: [
              { contractDuration: 36, dpTermPrices: { remainingMonthPrice: 15 } },
              { contractDuration: 24, dpTermPrices: { remainingMonthPrice: 20 } },
              { contractDuration: 30, dpTermPrices: { remainingMonthPrice: 18 } },
            ],
            fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
            oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
            preferredTerm: null,
          },
          color: { displayName: 'Black', colorCssStyle: '#000' },
          sorId: 'sku1',
          capacity: '128GB',
          imageUrlMap: {},
        },
        childSkusByColor: [],
        isNumberShareMandatory: false,
        isNumberShareCapable: false,
      },
      productDetails: {
        deviceProduct: {},
        deviceSku: {
          sorId: 'sku1'
        },
        commonInfo: {},
      },
      protectionFeatures: {},
      cartDetails: cartDetails4.data.data,
      customerProfileDetails: { customer: { billAccounts: [{ mtns: [] }] }, commonInfo: {} },
      activeMtn: '5185673926',
      selectedColor: 'Black',
      setSelectedColor: jest.fn(),
      ispuToggleOn: false,
      setIspuToggleOn: jest.fn(),
      isShipItToggleOn: false,
      setIsShipItToggleOn: jest.fn(),
      selectedSku: {
        price: {
          devicePaymentPrice: [
            { contractDuration: 36, dpTermPrices: { remainingMonthPrice: 15, dpTerm: 36 } },
            { contractDuration: 24, dpTermPrices: { remainingMonthPrice: 20, dpTerm: 24 } },
            { contractDuration: 30, dpTermPrices: { remainingMonthPrice: 18, dpTerm: 30 } },
          ],
          fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
          oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
          preferredTerm: null,
        },
        inventoryDetails: {
          dFillInventory: {
            isInStock: true,
          },
          localInventory: {
            isInStock: true,
          }
        },
        color: { displayName: 'Black', colorCssStyle: '#000' },
        sorId: 'sku1',
        capacity: '128GB',
        imageUrlMap: {},
      },
      setSelectedSku: jest.fn(),
      selectedProtectionFeature: {},
      setSelectedProtectionFeature: jest.fn(),
      selectedSize: '128GB',
      setSelectedSize: jest.fn(),
      setUpgradeReasonType: jest.fn(),
      isAcssDfillSim: false,
      isNewlyAddedLine: false,
      groupByColors: jest.fn(),
      groupBySmartWatchBand: jest.fn(),
      setisInStock: jest.fn(),
      setIncompatibleSim: jest.fn(),
      sendFullRetailPrice: jest.fn(),
      updateNumberShare: jest.fn(),
      updateNumberShareValue: jest.fn(),
      setSelectedPaymentInfo: jest.fn(),
      updateSimId: jest.fn(),
      updateDeviceData: jest.fn(),
      setTmpLinkClicked: jest.fn(),
      PdpBuyoutToggle: false,
      isBuyoutEligible: false,
      buyOutAccepted: false,
      setBuyOutAccepted: jest.fn(),
      setBuyoutToggleChange: jest.fn(),
      totalBuyoutAmount: 0,
      buyOutDetail: {},
      updateDeviceId: jest.fn(),
      isInStock: true,
      setSelectedPaymentInfo: setSelectedPaymentInfoMock,
      setBbPaymentOptionsSelected: jest.fn(),
      setBbyPaymetOptionPriceId: jest.fn(),
      computeDPPriceResult: {
        status: 'fulfilled',
        endpointName: 'computeDPPrices',
        requestId: 'lf2MRsFlucEKnButXAPgU',
        originalArgs: {
          body: {
            sorId: 'SMS911UZEV',
            mtn: '2164706958',
            term: 36,
            downPayment: 10,
            isPercentage: true,
            agentOrFullRetailPrice: 1029.99,
          },
          spinner: false,
        },
        startedTimeStamp: 1720705629368,
        data: {
          firstMonthPrice: 26.09,
          remainingMonthPrice: 25.74,
          dpTerm: 36,
          downPayment: 103,
          mtn: '2164706958',
        },
        fulfilledTimeStamp: 1720705629906,
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: false,
        currentData: {
          firstMonthPrice: 26.09,
          remainingMonthPrice: 25.74,
          dpTerm: 36,
          downPayment: 103,
          mtn: '2164706958',
        },
        isFetching: false,
      }
    };

    const location = {
      ...window.location,
      search: '?isFromCPE=true&deviceFromCart=true',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });

    window.location.href = `http://localhost/?activeMtn=newLine1&eSim=${true}&deviceFromCart=${true}&productId=${true}&isByodUpdate=true&isEditAndView=true`;

    getAssistedCradlePropertyV2.mockReturnValue(['', 'UNL', 'FALSE', 'FALSE', 'FALSE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', '', 'TRUE'])

    isVbg.mockReturnValue(false);
    // Render DeviceInfo
    render(<DeviceInfo {...props} />);
  });
  it('deviceFromFilteredCartLine.priceType is DEVICE_PAYMENT and isVbg is false and computeDpPriceResult is present but sku does not match and downPayment is zero', () => {
    const setSelectedPaymentInfoMock = jest.fn();

    const InventoryDetailsResult = {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: dropshipSkuDetailsResponse || [],
    };
    APIServiceHooks.useLazyGetInventoryDetailsQuery = jest.fn(() => [
      useLazyGetInventoryDetailsQuery,
      InventoryDetailsResult,
    ]);

    const useLazyGetDevicePricingEligibilityQuery = jest.fn();
    const dpEligibilityResult = {
      status: 'rejected',
      isUninitialized: false,
      isLoading: false,
    };
    APIServiceHooks.useLazyGetDevicePricingEligibilityQuery = jest.fn(() => [
      useLazyGetDevicePricingEligibilityQuery,
      dpEligibilityResult,
    ]);

    const props = {
      details: {
        childSkus: [
          {
            price: {
              devicePaymentPrice: [
                { contractDuration: 36, dpTermPrices: { remainingMonthPrice: 15 } },
                { contractDuration: 24, dpTermPrices: { remainingMonthPrice: 20 } },
                { contractDuration: 30, dpTermPrices: { remainingMonthPrice: 18 } },
              ],
              fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
              oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
              preferredTerm: null,
            },
            color: { displayName: 'Black', colorCssStyle: '#000' },
            sorId: 'sku1',
            capacity: '128GB',
            imageUrlMap: {},
          },
        ],
        defaultSKUObj: {
          price: {
            devicePaymentPrice: [
              { contractDuration: 36, dpTermPrices: { remainingMonthPrice: 15 } },
              { contractDuration: 24, dpTermPrices: { remainingMonthPrice: 20 } },
              { contractDuration: 30, dpTermPrices: { remainingMonthPrice: 18 } },
            ],
            fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
            oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
            preferredTerm: null,
          },
          color: { displayName: 'Black', colorCssStyle: '#000' },
          sorId: 'sku1',
          capacity: '128GB',
          imageUrlMap: {},
        },
        childSkusByColor: [],
        isNumberShareMandatory: false,
        isNumberShareCapable: false,
      },
      productDetails: {
        deviceProduct: {},
        deviceSku: {
          sorId: 'sku1'
        },
        commonInfo: {},
      },
      protectionFeatures: {},
      cartDetails: cartDetails4.data.data,
      customerProfileDetails: { customer: { billAccounts: [{ mtns: [] }] }, commonInfo: {} },
      activeMtn: 'newLine3',
      selectedColor: 'Black',
      setSelectedColor: jest.fn(),
      ispuToggleOn: false,
      setIspuToggleOn: jest.fn(),
      isShipItToggleOn: false,
      setIsShipItToggleOn: jest.fn(),
      selectedSku: {
        price: {
          devicePaymentPrice: [
            { contractDuration: 36, dpTermPrices: { remainingMonthPrice: 15, dpTerm: 36 } },
            { contractDuration: 24, dpTermPrices: { remainingMonthPrice: 20, dpTerm: 24 } },
            { contractDuration: 30, dpTermPrices: { remainingMonthPrice: 18, dpTerm: 30 } },
          ],
          fullRetailPrice: { originalPrice: 100, contractText: 'Full Retail Price' },
          oneYearPrice: { originalPrice: 80, contractText: 'One Year Price' },
          preferredTerm: null,
        },
        inventoryDetails: {
          dFillInventory: {
            isInStock: true,
          },
          localInventory: {
            isInStock: true,
          }
        },
        color: { displayName: 'Black', colorCssStyle: '#000' },
        sorId: 'sku1',
        capacity: '128GB',
        imageUrlMap: {},
      },
      setSelectedSku: jest.fn(),
      selectedProtectionFeature: {},
      setSelectedProtectionFeature: jest.fn(),
      selectedSize: '128GB',
      setSelectedSize: jest.fn(),
      setUpgradeReasonType: jest.fn(),
      isAcssDfillSim: false,
      isNewlyAddedLine: false,
      groupByColors: jest.fn(),
      groupBySmartWatchBand: jest.fn(),
      setisInStock: jest.fn(),
      setIncompatibleSim: jest.fn(),
      sendFullRetailPrice: jest.fn(),
      updateNumberShare: jest.fn(),
      updateNumberShareValue: jest.fn(),
      setSelectedPaymentInfo: jest.fn(),
      updateSimId: jest.fn(),
      updateDeviceData: jest.fn(),
      setTmpLinkClicked: jest.fn(),
      PdpBuyoutToggle: false,
      isBuyoutEligible: false,
      buyOutAccepted: false,
      setBuyOutAccepted: jest.fn(),
      setBuyoutToggleChange: jest.fn(),
      totalBuyoutAmount: 0,
      buyOutDetail: {},
      updateDeviceId: jest.fn(),
      isInStock: true,
      setSelectedPaymentInfo: setSelectedPaymentInfoMock,
      setBbPaymentOptionsSelected: jest.fn(),
      setBbyPaymetOptionPriceId: jest.fn(),
      computeDPPriceResult: {
        status: 'fulfilled',
        endpointName: 'computeDPPrices',
        requestId: 'lf2MRsFlucEKnButXAPgU',
        originalArgs: {
          body: {
            sorId: 'SMS911UZEV',
            mtn: '2164706958',
            term: 36,
            downPayment: 10,
            isPercentage: true,
            agentOrFullRetailPrice: 1029.99,
          },
          spinner: false,
        },
        startedTimeStamp: 1720705629368,
        data: {
          firstMonthPrice: 26.09,
          remainingMonthPrice: 25.74,
          dpTerm: 36,
          downPayment: 103,
          mtn: '2164706958',
        },
        fulfilledTimeStamp: 1720705629906,
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: false,
        currentData: {
          firstMonthPrice: 26.09,
          remainingMonthPrice: 25.74,
          dpTerm: 36,
          downPayment: 103,
          mtn: '2164706958',
        },
        isFetching: false,
      }
    };

    const location = {
      ...window.location,
      search: '?isFromCPE=true&deviceFromCart=true',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });

    window.location.href = `http://localhost/?activeMtn=newLine1&eSim=${true}&deviceFromCart=${true}&productId=${true}&isByodUpdate=true&isEditAndView=true`;

    getAssistedCradlePropertyV2.mockReturnValue(['', 'UNL', 'FALSE', 'FALSE', 'FALSE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', '', 'TRUE'])

    isVbg.mockReturnValue(false);
    // Render DeviceInfo
    render(<DeviceInfo {...props} />);
  });
});
