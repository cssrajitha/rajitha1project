import React from 'react';
import { RadioBoxGroup } from '@vds/radio-boxes';
import styled from 'styled-components';

const RadioBoxWrap = styled.div`
  [class^='RadioBoxGroupWrapper-'] {
    gap: 10px;
    flex-flow: wrap;
  }
  label {
    padding: 0.5rem;
    color: #000000 !important;
  }
  & label::before {
    content: '';
    display: none;
  }
`;

const SmartWatchBandOptions = (props) => {
  const { skus, selectedSku } = props;
  const { color = {}, skuFilters = {} } = selectedSku;
  const { band = '' } = skuFilters;
  if (!skus || !color) {
    return '';
  }
  const colorObj = skus && skus.length > 0 && skus.filter((sku) => sku.color === color.displayName);
  const bandSkus = colorObj?.[0]?.skusGroupedBySWBand;
  const defaultValue = bandSkus?.[0] && bandSkus?.find((sku) => band === sku?.band);
  return (
    <RadioBoxWrap data-testid='smartWatchBandOptions'>
      {Array.isArray(bandSkus) && bandSkus?.[0] && (
        <RadioBoxGroup
          key={defaultValue?.band}
          defaultValue={defaultValue?.band}
          onChange={props.chooseSWBand}
          orientation='horizontal'
          surface='light'
          data={bandSkus.map((sku) => {
            const bandSku = sku?.band;
            return {
              name: 'bands',
              children: bandSku,
              value: bandSku,
              width: '200px',
              'data-track': `Productdetail_smartwatchband_${bandSku}`,
            };
          })}
        />
      )}
    </RadioBoxWrap>
  );
};
export default SmartWatchBandOptions;
