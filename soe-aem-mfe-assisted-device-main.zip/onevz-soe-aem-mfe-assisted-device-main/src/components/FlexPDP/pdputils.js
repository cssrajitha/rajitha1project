import { sendCustomEvent } from 'onevzsoemfeframework/Tagging';
import { isIndirect, executeShellFunction } from 'onevzsoemfeframework/DomService';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
// eslint-disable-next-line you-dont-need-lodash-underscore/get
import { get as getProp } from 'lodash';
import { DROPSHIP_PRODCODE5_ALLOWED_LIST } from './PDP_Constants';

/**
 * to check the device id or simid from cartdetails
 * @param {Object} cartDetails cartdetails of user
 * @param {String} activeMtn activeMTN
 * @param {String} cartItemType cartItemType DEVICE || SIM
 * @returns Object (deviceid or esim)
 */
export function getRetrieveCartInfo(cartDetails, activeMtn, cartItemType) {
  let cartItemInfo = {};
  const lineInfo = cartDetails?.cart?.lineDetails?.lineInfo || [];
  const lineInfoFind = lineInfo?.find((x) => x?.mobileNumber === activeMtn);
  const cartItemDetails = lineInfoFind?.itemsInfo?.[0]?.cartItems?.cartItem.find(
    (x) => x?.cartItemType === cartItemType
  );
  if (cartItemDetails) {
    if (cartItemType === 'DEVICE') cartItemInfo = cartItemDetails?.deviceId ? cartItemDetails : {};
    if (cartItemType === 'SIM') cartItemInfo = cartItemDetails?.eSIM ? cartItemDetails : {};
  }
  return cartItemInfo;
}

export function updateModalStateCommon(opened, onClose) {
  const vzdl = window?.vzdl || {};
  if (vzdl?.event) vzdl.event.value = '';
  window.vzdl = vzdl;
  if (!opened) {
    onClose();
    if (vzdl?.page) vzdl.page.detail = `Product-detail`;
    sendCustomEvent('closeView', window?.vzdl);
  } else if (opened) {
    if (vzdl?.page) vzdl.page.detail = `Plan Incompatible`;
    window.vzdl = vzdl;
    sendCustomEvent('openView', window?.vzdl);
  }
}

/**
 * Validates the payload for inDirectValidateDeviceSimIdPayload function.
 *
 * @param {boolean} deviceActiveCheck - The device active check.
 * @param {boolean} deviceActiveLoanCheck - The device active loan check.
 * @param {boolean} devicePreorderCheck - The device preorder check.
 * @param {boolean} iccidStatusCheck - The ICCID status check.
 * @param {boolean} disableEsimAtLocalInventory - The disable eSIM at local inventory check.
 * @returns {object} - The validated payload object.
 */
export function inDirectValidateDeviceSimIdPayload(
  deviceActiveCheck,
  deviceActiveLoanCheck,
  devicePreorderCheck,
  iccidStatusCheck,
  disableEsimAtLocalInventory
) {
  let payload = {};
  if (isIndirect()) {
    payload = {
      deviceActiveCheck: /true/i.test(deviceActiveCheck),
      deviceActiveLoanCheck: /true/i.test(deviceActiveLoanCheck),
      devicePreorderCheck: /true/i.test(devicePreorderCheck),
      disableEsimAtLocalInventory: /true/i.test(disableEsimAtLocalInventory),
      iccidStatusCheck: /true/i.test(iccidStatusCheck),
    };
  }
  return payload;
}

/**
 * Checks the compatibility of a device's SIM for a given request data.
 *
 * @param {Object} reqData - The request data containing information about the device and the request.
 * @param {boolean} reqData.isIndirect - Indicates if the request is indirect.
 * @param {string} reqData.intendType - The type of intent.
 * @param {boolean} reqData.isByodUpdate - Indicates if it is a BYOD update.
 * @param {Object} reqData.deviceInfo - Information about the device.
 * @param {Object} reqData.previousPayload - The previous payload data.
 * @returns {boolean} - Returns true if the device's SIM is compatible, false otherwise.
 */
export function checkDeviceSimCompatibility(reqData) {
  try {
    const { intendType, isByodUpdate, deviceInfo, previousPayload } = reqData;
    return (
      isIndirect() &&
      (intendType === 'EUP' || isByodUpdate === true) &&
      !(intendType === 'EUP' && deviceInfo?.simClass4G === 'NP' && isIndirect()) &&
      !deviceInfo?.simInfo?.iccid &&
      !deviceInfo?.makeEtniPersApi &&
      !previousPayload?.data?.lines?.[0]?.device?.sim?.CurrentSimid
    );
  } catch (error) {
    console.error('Error in checkDeviceSimCompatibility:', error);
    return false;
  }
}

/**
 * Initiates the device sim compatibility check.
 *
 * @param {Object} reqData - The request data object.
 * @param {boolean} reqData.isIndirect - Indicates if the device is indirect.
 * @param {string} reqData.intendType - The intend type.
 * @param {boolean} reqData.isByodUpdate - Indicates if it is a BYOD update.
 * @param {Object} reqData.deviceInfo - The device information object.
 * @param {Object} reqData.previousPayload - The previous payload object.
 * @param {Object} reqData.payload - The payload object.
 * @param {Function} reqData.validateDeviceSimIdRequest - The function to validate device sim ID request.
 */
export function initiateDeviceSimCompatibilityCheck(reqData) {
  try {
    const { intendType, isByodUpdate, deviceInfo, previousPayload, payload, validateDeviceSimIdRequest } = reqData;
    if (
      isIndirect() &&
      (intendType === 'EUP' || isByodUpdate === true) &&
      !(intendType === 'EUP' && deviceInfo?.simClass4G === 'NP' && isIndirect()) &&
      !deviceInfo?.simInfo?.iccid &&
      !deviceInfo?.makeEtniPersApi &&
      !previousPayload?.data?.lines?.[0]?.device?.sim?.CurrentSimid
    ) {
      const payloadData = {
        mtn: payload?.mtn,
        deviceId: payload?.deviceId,
        simId: payload?.simId,
        cpSimCard: false,
        fromCpe: true,
        isCustomerProvidedEquipment: payload?.isCustomerProvidedEquipment,
        deviceFlow: true,
        isDWOS: false,
        sendSimFromLanding: true,
      };
      validateDeviceSimIdRequest(payloadData);
    }
  } catch (error) {
    console.error('Error in initiateDeviceSimCompatibilityCheck:', error);
  }
}

/**
 * Retrieves the line activity type for a given cart and active mobile number.
 *
 * @param {Object} cart - The cart object containing line details.
 * @param {string} activeMtn - The active mobile number.
 * @returns {string} - The line activity type.
 */
export function getLineActivityType(cart, activeMtn) {
  try {
    const lineInformation = cart.lineDetails?.lineInfo?.filter((line) => line?.mobileNumber === activeMtn);
    const intendType = lineInformation?.[0]?.lineActivityType || 'EUP';
    return intendType;
  } catch (error) {
    console.error('Error in getLineActivityType:', error);
    return 'EUP';
  }
}

/**
 * Displays a banner message based on the compatibility of the device's SIM card.
 *
 * @param {Object} deviceInfo - The device information.
 * @param {Object} validateDeviceSimRequest - The request to validate the device's SIM card.
 * @param {Function} dispatch - The dispatch function.
 * @returns {void}
 */
export function displaySimCompartibleBanner(deviceInfo, validateDeviceSimRequest, dispatch) {
  const deviceSimCompatible = deviceInfo?.deviceSimCompatible;
  const currentSimId = validateDeviceSimRequest?.data?.lines?.[0]?.device?.sim?.CurrentSimid;
  const simId = validateDeviceSimRequest?.data?.lines?.[0]?.device?.sim?.id;

  const MESSAGES = {
    SUCCESS: 'CurrentSIM is compatible with new device',
    ERROR: 'Sim is not compatible with the selected device',
  };

  if (deviceSimCompatible === 'Y' && currentSimId !== '' && simId === '') {
    dispatch(appMessageActions.addAppMessage(MESSAGES.SUCCESS, 'success', true, true));
  } else if (deviceSimCompatible === 'N' && deviceInfo?.simInfo?.iccid !== '') {
    dispatch(appMessageActions.addAppMessage(MESSAGES.ERROR, 'error', true, true));
  }
}

/**
 * Retrieves the SKU of the cart SIM based on the provided parameters.
 *
 * @param {Object} simFromFilteredCartLine - The SIM object from the filtered cart line.
 * @returns {string} The SKU of the cart SIM.
 */
export function getCartSimSku(simFromFilteredCartLine) {
  let cartSimSKu = simFromFilteredCartLine?.itemCode;
  if (simFromFilteredCartLine?.eSIM) {
    cartSimSKu = '';
  }
  return cartSimSKu;
}

/**
 * Determines if the order is local for indirect fulfillment.
 *
 * @param {boolean} isFullFillment - Indicates if the order is for fullfillment.
 * @param {boolean} isBackOrder - Indicates if the order is on backorder.
 * @param {boolean} isPreOrder - Indicates if the order is a pre-order.
 * @param {boolean} iSscan - Indicates if device is scanned or not.
 * @returns {boolean} - Returns true if the order is local for indirect fulfillment, otherwise false.
 */
export function isLocalOrderForIndirect(isFullFillment, isBackOrder, isPreOrder, iSscan) {
  // 1 - if not fullfillment and not backorder and not preorder
  // 2 - if fullfillment and scanned (multi line scenario - when scanned from gridwall and first line is added as dfill i,e fullfillment)
  // 3 - if scanned and backorder (when scanned from gridwall and it's back order)
  return (
    isIndirect() &&
    ((!isFullFillment && !isBackOrder && !isPreOrder) || (isFullFillment && iSscan) || (iSscan && isBackOrder))
  );
}

/**
 * Determines if the order is for indirect fulfillment and has sufficient inventory quantity.
 *
 * @param {boolean} isFullFillment - Indicates if the order is for full fulfillment.
 * @param {number} dFillInventoryQty - The quantity of inventory for direct fulfillment.
 * @returns {boolean} - Returns true if the order is for indirect fulfillment and has sufficient inventory quantity, otherwise returns false.
 */
export function isDfillOrderForIndirect(isFullFillment, dFillInventoryQty) {
  return isIndirect() && isFullFillment && dFillInventoryQty;
}

/**
 * Determines if the "Ship It" toggle should be disabled.
 * @param {boolean} isPreOrder - Indicates if the product is on pre-order.
 * @returns {boolean} - Returns true if the toggle should be disabled, false otherwise.
 */
export function isDisableShipIttoogle(isPreOrder) {
  let isDisable = true;
  if (isIndirect() && !isPreOrder) isDisable = false;
  return isDisable;
}

/**
 * Determines the BB order type based on provided parameters.
 * @param {string} isLocalBBYLocal - Value from 'iSscan' query parameter
 * @param {Object} cartDetails - Cart details object from retrieveCart header object
 * @returns {Object} An object containing isBBYLocalOrder and isBBYDfillOrder flags
 */
export const determineBBOrderType = (isLocalBBYLocal, cartDetails) => {
  const locationSubType = cartDetails?.cart?.cartHeader?.locationSubType;
  const maidCode = cartDetails?.cart?.cartHeader?.maid;
  const bestBuyISPUEnableLocalOrderFFlag = /true/i.test(
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.bestBuyISPUEnableLocalOrderFFlag
  );
  let isBBYLocalOrder = false;
  let isBBYDfillOrder = false;
  if (
    (isLocalBBYLocal === 'true' && locationSubType === 'GN' && maidCode === 'BBX') ||
    (bestBuyISPUEnableLocalOrderFFlag && locationSubType === 'GN' && maidCode === 'BBX' && isIndirect())
  ) {
    isBBYLocalOrder = true;
  } else if (isLocalBBYLocal === null && locationSubType === 'GN' && maidCode === 'BBX') {
    isBBYDfillOrder = true;
  }

  return { isBBYLocalOrder, isBBYDfillOrder };
};
export const devicePricingDetails = (data, setBByPricing) => {
  const parsedData = JSON.parse(data);
  console.log(data, parsedData, 'shellData');
  setBByPricing(parsedData);
  return parsedData;
};

export const getBestBuyPricingDetails = (setBByPricing, skuRealAgentCode, UpcCodeData) => {
  window.BbyDevicePricingDetails = (data) => devicePricingDetails(data, setBByPricing);
  const StoreIdFormat = skuRealAgentCode?.padStart(4, '0');
  const req = { upc: UpcCodeData, storeId: StoreIdFormat };
  const param = {
    apiName: 'devicePricingDetails',
    method: 'get',
    requestPayloadJson: JSON.stringify(req),
  };

  // Call the actual shell function
  executeShellFunction('Shell', 'executeBestbuyShellFunction', 'window.BbyDevicePricingDetails', param);
};

export function formatBillAccountNo(billAccountNo = '') {
  // format like "00001"
  const DIGITS = 5;
  const numOfDigits = billAccountNo && billAccountNo.toString().length;
  if (numOfDigits === 5) {
    return billAccountNo;
  }
  const numOfPrefixedZeroes = DIGITS - numOfDigits;
  let prefix = '';

  for (let i = 0; i < numOfPrefixedZeroes; i += 1) {
    prefix = `0${prefix}`;
  }
  return prefix + billAccountNo;
}

export function padCustomerId(customerId = '') {
  const customerIdPadding = '0000000000';

  if (customerId && customerId.length < 10) {
    return customerIdPadding.slice(0, 10 - customerId.length) + customerId;
  }
  return customerId;
}

export const unFormatMTN = (strMTN) => {
  if (strMTN == null || strMTN === '') return '';
  return strMTN.replace(/-/g, '');
};

export const getDeviceEnforApiPayload = ({
  mfeIccid = '',
  mfeImei = '',
  customerInfo,
  equipmentInfo,
  locationCd,
  simSwapNotify,
}) => {
  const includeNotificationRequest = () => {
    if (['PE', 'ME', 'SL', 'BD', 'AG'].includes(customerType) && simSwapNotify?.toLowerCase() === 'y') {
      return true;
      // eslint-disable-next-line no-undef
    }
    if (
      customerType === 'BE' &&
      (!ecpdId || ecpdId === null || ecpdId === '' || ecpdId === '0' || ecpdId === '0000000000')
    ) {
      return true;
    }
    return false;
  };
  const simOnlyChgFixFlagEnabled = window?.mfe?.simOnlyChgFixFlag || false;
  const { customerId } = customerInfo;
  const billAccountNo = customerInfo?.billAccounts?.[0]?.billAccountNo;
  const mtn = customerInfo?.lookupMtn;
  const customerType = getProp(customerInfo, 'customerAttributes.customerType', '');
  const ecpdId = getProp(customerInfo, 'customerAttributes.hasEcpd');
  const { deviceInfo, simInfo } = equipmentInfo || {};
  // Compute newImei without default assignment to satisfy Sonar (no redundant assignments)
  const resolveNewImei = () => {
    if (mfeImei && mfeImei !== deviceInfo?.deviceId) return mfeImei;
    if (simOnlyChgFixFlagEnabled) return deviceInfo?.deviceId;
    return '';
  };
  const computedNewImei = resolveNewImei();
  const payload = {
    mdn: unFormatMTN(mtn),
    custId: padCustomerId(customerId),
    acctNum: formatBillAccountNo(billAccountNo),
    transactionType: deviceInfo?.deviceId === mfeImei?.trim() ? 'SIM_ONLY_CHANGE' : 'SIM_AND_DEVICE_CHANGE',
    deviceSku: deviceInfo?.deviceSku,
    cpeIndicator: 'Y',
    imei: deviceInfo?.deviceId,
    oldIccid: simInfo?.simId,
    newIccid: mfeIccid && mfeIccid !== simInfo?.simId ? mfeIccid : '',
    loginId: customerInfo?.loggedInUser,
    locationCd,
    ipAddress: '',
    clientAppName: 'VZW-ACSS-NSA',
    oldImei: deviceInfo?.deviceId,
    newImei: computedNewImei,
    riskScoreEnabled: true,
    indicatorEnabled: true,
    serviceRegion: '', // not available
    serviceDepartment: '', // not available
    workstationId: customerInfo?.loggedInUser,
  };

  if (includeNotificationRequest()) {
    payload.notificationRequest = {
      clientId: 'VZW-ACSS-NSA',
      custId: padCustomerId(customerId),
      transactionType: deviceInfo?.deviceId === mfeImei?.trim() ? 'SIM_ONLY_CHANGE' : 'SIM_AND_DEVICE_CHANGE',
      accountNo: formatBillAccountNo(billAccountNo),
      mdn: unFormatMTN(mtn),
      email: customerInfo?.email,
      deviceId: deviceInfo?.deviceId,
      deviceIdType: mfeImei && mfeImei === deviceInfo?.deviceId ? 'ICC' : 'IME',
      ecpdId: '',
      firstName: customerInfo?.customerName?.firstName,
      swapRequestDate: new Intl.DateTimeFormat('en-US', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
      }).format(new Date()),
      triggerNotification: !!customerInfo?.customerName?.firstName && !!customerInfo?.email,
      languageIndicator: 'E',
      // "customerType": "PE"
    };
  }

  return payload;
};

export function isFraudRiskApiEnabledForDeviceChange({ isSecureSimSwap }) {
  let isFraudRiskEnable = true;
  if (sessionStorage.getItem('enableSimValidation') === 'true' || isSecureSimSwap === 'N') {
    isFraudRiskEnable = false;
  }

  return isFraudRiskEnable;
}

export function isDWOSAllowed(dwosIndirectFFlag, isDWOS) {
  return /true/i.test(dwosIndirectFFlag) && isIndirect() && !!isDWOS;
}

/**
 * Retrieves the Adobe Subkey contract based on the provided flag.
 *
 * @param {boolean} fFlag - A flag indicating whether to retrieve the Adobe Subkey.
 * @returns {Object} An object containing the Adobe Subkey if available; otherwise, an empty object.
 */
export function getAdobeSubKeyContract(fFlag) {
  const contract = {};
  if (fFlag) {
    const adobeSubkey = sessionStorage.getItem('adobe-sessionId') || '';
    if (adobeSubkey) {
      contract.adobeSubkey = adobeSubkey;
    }
  }
  return contract;
}

export function isRefundExcahngeFlow() {
  const rfexFlow = /true/i.test(sessionStorage.getItem('refundexchange')) || false;
  const refexRedesignGwScanFFlag = /true/i.test(
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.refexRedesignGwScanFFlag
  );
  return rfexFlow && refexRedesignGwScanFFlag;
}

export function refundExchangeFlowIntent(intent) {
  if (isRefundExcahngeFlow()) {
    return 'REX';
  }
  return intent;
}

/**
 * Checks if there is a conflict between ISPU (In-Store Pickup) and Local order items in the cart.
 * Returns true if the feature flag is enabled, the channel is indirect, and the cart contains
 * BOTH an ISPU line (ispuItem=true) AND a non-ISPU Local line (ispuItem=false, depletionType='L').
 *
 * NOTE: ISPU items may themselves use local store inventory (depletionType='L'), so depletionType
 * alone is insufficient to detect a conflict — ispuItem must also be false on the local line.
 *
 * @param {Object} cartDetails - The cart details object containing line information
 * @param {boolean} bestBuyISPUEnableLocalOrderFFlag - Feature flag to enable/disable this validation
 * @returns {boolean} - Returns true if there is a conflict, false otherwise
 */
export function hasISPUAndLocalConflict(cartDetails, bestBuyISPUEnableLocalOrderFFlag) {
  try {
    // Check if feature flag is enabled and channel is indirect
    if (/true/i.test(bestBuyISPUEnableLocalOrderFFlag) && isIndirect()) {
      const lineInfo = cartDetails?.cart?.lineDetails?.lineInfo || [];

      const hasISPUItem = lineInfo.some((line) => line?.ispuItem === true);

      // Only flag non-ISPU lines with depletionType='L' as local items.
      // ISPU lines may also use local store inventory (depletionType='L') but
      // are NOT local orders — mixing them with non-ISPU local lines is the conflict.
      const hasLocalItem = lineInfo.some((line) => {
        if (line?.ispuItem === true) return false; // Skip ISPU lines
        const itemsInfo = line?.itemsInfo || [];
        return itemsInfo.some((item) => item?.depletionType === 'L');
      });

      if (hasISPUItem && hasLocalItem) {
        return true;
      }
    }
    return false;
  } catch (error) {
    console.error('Error in hasISPUAndLocalConflict:', error);
    return false;
  }
}

/**
 * Checks if there is a non-ISPU Local order in the cart that should hide the ISPU toggle.
 * Returns true if the feature flag is enabled, channel is indirect, and cart contains items
 * with ispuItem=false and depletionType='L'.
 *
 * @param {Object} cartDetails - The cart details object containing line information
 * @param {boolean} bestBuyISPUEnableLocalOrderFFlag - Feature flag to enable/disable this validation
 * @returns {boolean} - Returns true if ISPU toggle should be hidden, false otherwise
 */
export function shouldHideISPUToggle(cartDetails, bestBuyISPUEnableLocalOrderFFlag) {
  try {
    // Check if feature flag is enabled and channel is indirect
    if (/true/i.test(bestBuyISPUEnableLocalOrderFFlag) && isIndirect()) {
      const lineInfo = cartDetails?.cart?.lineDetails?.lineInfo || [];

      // Check each line in the cart
      for (const line of lineInfo) {
        // ispuItem is at line level
        const ispuItem = line?.ispuItem;
        const itemsInfo = line?.itemsInfo || [];

        for (const item of itemsInfo) {
          const depletionType = item?.depletionType;

          // Check if depletionType is 'L' (Local) and line has ispuItem=false
          if (depletionType === 'L' && ispuItem === false) {
            return true; // Hide ISPU toggle: non-ISPU Local order for indirect channel
          }
        }
      }
    }
    return false;
  } catch (error) {
    console.error('Error in shouldHideISPUToggle:', error);
    return false;
  }
}

/**
 * Determines if the given SKU details correspond to a dropship SKU.
 *
 * @param {Object} skuDetails - The SKU details object containing product codes.
 * @returns {boolean} - Returns true if the SKU is a dropship SKU, otherwise false.
 */
export function isDropshipSku(skuDetails) {
  const prodCode4 = skuDetails?.prodCode4;
  const prodCode5 = skuDetails?.prodCode5;
  return String(prodCode4) === '000' && DROPSHIP_PRODCODE5_ALLOWED_LIST.includes(String(prodCode5));
}