import styled from 'styled-components';
import { Title } from '@vds/typography';
import { Icon } from '@vds/icons';
import { Line } from '@vds/lines';
import PropTypes from 'prop-types';
import Emitter from 'onevzsoemfeframework/Emitter';
import { isNumeric, capitalizeFirstLetter, formatMtnForNewLine, getUIContextPathBAU } from 'onevzsoemfecommon/Helpers';
import { useNavigate } from 'react-router-dom';
import { getQueryParamByName } from 'onevzsoemfeframework/DomService';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { BackClickable, FlexBox } from '../CombinedGridwall/FlexGlobalStyledConstants';
import MoreOptions from './MoreOptions';
import { DARK_THEME_COLOR, LIGHT_THEME_COLOR } from '../../constants/constants';
import { isDWOSAllowed } from './pdputils';

const FlexBoxGrowOne = styled.div`
  display: flex;
  flex-grow: 1;
`;
const ShopWrapper = styled.div`
  padding: 1.5rem 0.5rem;
`;
const LineWrapper = styled.div`
  padding: 0 2rem;
`;
export const FlexAlignContainerItemsCenter = styled.div`
  display: flex;
  align-items: center;
  padding: 0 2rem;
  justify-content: space-between;
`;
const LineSeperator = styled.div`
  width: 1px;
  height: 27px;
  background: ${(props) => (props.isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR)};
  top: 1.5rem;
  position: relative;
`;
const MinimizeDisplayName = styled.div`
  width: 500px;
  white-space: nowrap;
  overflow: hidden;
  float: left;
  text-overflow: ellipsis;
`;
const ACSSLineSpacer = styled.div`
  width: 425px;
`;

let navigate = '';

function useNavigateMFE() {
  navigate = useNavigate();
}
function Header(props) {
  const scmDeviceEnable = window?.mfe?.scmDeviceMfeEnable || false;
  // const navigate = scmDeviceEnable ? "" :useNavigate();

  try {
    useNavigateMFE();
  } catch (e) {
    console.log('');
  }

  const {
    isFromCPE,
    isRfexFlow,
    isNewLine,
    channel,
    orderDetails,
    selectedPaymentInfo,
    isInStock,
    cartDetails,
    activeMtn,
    computeDPPriceBody,
    computeDPPriceResult,
    isDownPaymentAlertNeedToEnable,
    setIsDownPaymentAlertNeedToEnable,
    setDownPaymentObj,
    downPaymentObj,
    retailPrice,
    bbyContractTerm,
    bbPaymentOptionsSelected,
    closePopup,
  } = props;
  const [dwosIndirectFFlag] = getAssistedCradlePropertyV2(['dwosIndirectFFlag']);
  const isDWOS = isDWOSAllowed(dwosIndirectFFlag, getQueryParamByName('isDWOS'));
  const { header, line, mdn, closeIcon, closeClickHandler, moreOptionClickHandler } = props.data;
  const isDark = (window?.mfe?.scmDeviceMfeEnable && window?.mfe?.isDark) || false;
  const phoneRegex = /^\(?(\d{3})\)?[-. ]?(\d{3})[-. ]?(\d{4})$/;
  const MDN = isNumeric(mdn) ? mdn.replace(phoneRegex, '$1-$2-$3') : capitalizeFirstLetter(formatMtnForNewLine(mdn));
  const isByodUpdate = getQueryParamByName('isByodUpdate');
  const fromPage = getQueryParamByName('fromPage');
  const scmCombinedGridwallFlow = window?.mfe?.scmCombinedGridwallFlow || false;
  const gridwallAccessibleFFlag =
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.gridwallAccessibleFFlag === 'TRUE';
  const navigatePdp = () => {
    if (typeof closePopup !== 'undefined' && !closePopup) {
      /* istanbul ignore else */
      if (window?.mfe?.scmUpgradeMfeEnable) {
        if (scmCombinedGridwallFlow) {
          Emitter.emit('ACSS_SCM_DEVICE_SUBTAB', { subTab: 'CombinedGridwall', activeMtn });
        }
        else {
          Emitter.emit('ACSS_SCM_DEVICE_SUBTAB', { subTab: 'DeviceGridwall' });
        }
        return;
      }
    }
    sessionStorage.removeItem('isSecondNumDfill');
      /* istanbul ignore next */
    if (!scmDeviceEnable) {
      if (closeClickHandler) {
        closeClickHandler();
      } else if (fromPage === 'Landing') {
        navigate(`${getUIContextPathBAU()}/landing.html?activeMtn=${mdn}&backfrompdp=true`);
      } else {
        navigate(
          `${getUIContextPathBAU()}/combinedgridwall.html?fromPDP=true&activeMtn=${mdn}&backfrompdp=true${
            isDWOS ? '&isDWOS=true' : ''
          }`
        );
      }
    } else if (scmDeviceEnable) {
      if (closeClickHandler) {
        closeClickHandler();
      }
    } else {
      return;
    }
    sessionStorage.setItem('isFromBack', true);
    sessionStorage.setItem('isSecondNumLocal', false);
    if (sessionStorage.getItem('isSAExist')) {
      sessionStorage.removeItem('isSAExist');
    }
  };
  return (
    <>
      <FlexAlignContainerItemsCenter>
        <FlexBoxGrowOne>
          <BackClickable
            data-testid='testBackGridwall'
            onClick={navigatePdp}
            tabIndex={0}
            role='button'
            aria-label={gridwallAccessibleFFlag ? 'back' : ''}
            data-track={`ProductDetail_${header}_back`}
          >
            <Icon
              surface={isDark ? 'dark' : 'light'}
              ariaHidden={gridwallAccessibleFFlag ? 'true' : ''}
              name='left-caret'
              size='XLarge'
              medium='true'
            />
          </BackClickable>
          <ShopWrapper>
            <Title color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR} size='small' bold primitive='h1'>
              {header?.length > 60 ? <MinimizeDisplayName>{header}</MinimizeDisplayName> : header}
            </Title>
          </ShopWrapper>
          {line && (
            <>
              <LineSeperator isDark={isDark} />
              <ShopWrapper>
                <Title color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR} size='small' bold primitive='h1'>
                  {scmDeviceEnable ? '' : line} {scmDeviceEnable ? '' : MDN}{' '}
                  {scmDeviceEnable && !isByodUpdate ? <ACSSLineSpacer /> : ''}
                  {isByodUpdate && '(Add customer-provided equipment)'}
                </Title>
              </ShopWrapper>
            </>
          )}
        </FlexBoxGrowOne>
        <FlexBox>
          {closeIcon ? (
            <div>
              {closeIcon?.popupModalclose && (
                <span
                  onClick={closeClickHandler || (() => navigate(-1))}
                  onKeyDown={{}}
                  tabIndex={0}
                  role='button'
                  data-track={`ProductDetail_${header}_close`}
                >
                  <Icon surface={isDark ? 'dark' : 'light'} name='close' size='large' />
                </span>
              )}
            </div>
          ) : (
            <MoreOptions
              moreOptionClickHandler={moreOptionClickHandler}
              productDetails={props?.productDetails}
              CustomerData={props?.CustomerData}
              mtn={mdn}
              selectedSku={props.selectedSku}
              setDownPaymentObj={setDownPaymentObj}
              downPaymentObj={downPaymentObj}
              setUpgradeReasonType={props?.setUpgradeReasonType}
              deviceContract={props?.deviceContract}
              isFromCPE={isFromCPE}
              isRfexFlow={isRfexFlow}
              isNewLine={isNewLine}
              channel={channel}
              orderDetails={orderDetails}
              selectedPaymentInfo={selectedPaymentInfo}
              isInStock={isInStock}
              CustomerProfileCommonInfo={props?.CustomerProfileCommonInfo}
              cartDetails={cartDetails}
              activeMtn={activeMtn}
              computeDPPriceBody={computeDPPriceBody}
              computeDPPriceResult={computeDPPriceResult}
              isDownPaymentAlertNeedToEnable={isDownPaymentAlertNeedToEnable}
              setIsDownPaymentAlertNeedToEnable={setIsDownPaymentAlertNeedToEnable}
              retailPrice={retailPrice}
              bbyContractTerm={bbyContractTerm}
              bbPaymentOptionsSelected={bbPaymentOptionsSelected}
            />
          )}
        </FlexBox>
      </FlexAlignContainerItemsCenter>
      <LineWrapper>
        <Line type='secondary' />
      </LineWrapper>
    </>
  );
}
Header.propTypes = {
  data: PropTypes.shape({
    mdn: PropTypes.string,
    header: PropTypes.string,
    line: PropTypes.string,
    closeIcon: PropTypes.bool,
    FirstName: PropTypes.string,
  }),
};
export default Header;
