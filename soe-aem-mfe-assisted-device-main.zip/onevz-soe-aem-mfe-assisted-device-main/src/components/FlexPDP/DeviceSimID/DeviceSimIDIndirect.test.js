import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import { CHANNELS, setupChannel } from '../../../modules/test-utils/utils';
import DeviceSimID from './DeviceSimID';
import customerProfileDetails from '../../../pages/PDP/mocks/api/customerProfile.json';
import getSkuDetails from '../../../pages/PDP/mocks/api/getSkuDetails.json';
import validateDevicePSim from '../../../pages/PDP/mocks/api/validateDevicePSim.json';

jest.setTimeout(50000);

jest.mock(
  'onevzsoemfecommon/Helpers',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getQueryParamByName: jest.fn(() => ({
      isEditAndView: true,
    })),
    getUIContextPath: jest.fn(() => {}),
    getUIContextPathBAU: jest.fn(() => {}),
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => true,
  }),
  { virtual: true },
);
const Test = (channel) => {
  setupChannel(channel);
  const details = getSkuDetails?.data?.deviceSku?.parentProducts[0];

  const compatibleSims = details?.compatibleSimSorIds;
  const updateCpeCheckboxFlag = jest.fn();
  const props = {
    isIndirect: true,
    lineDeviceIdFromLanding: '353756110808409',
    isNewLine: false,
    isVideoAssistFlow: false,
    activeMtn: '5185673926',
    isDWOS: false,
    compatibleSims,
    isBYODUpdateAALRetail: false,
    isCancel: jest.fn(),
    setSecondNumDeviceId: jest.fn(),
    sku: '',
    byodDevice: '',
    isByodUpdate: false,
    deviceFromCart: false,
    isLocal: true,
    isFromCPE: false,
    defaultDeviceId: '353756110808409',
    defaultSimId: '89148000005700881964',
    customerProfileDetails: customerProfileDetails.data,
    cartDetails: { cart: {} },
    updateDeviceId: jest.fn(),
    updateSimId: jest.fn(),
    updateCpeCheckboxFlag,
    updateDeviceData: jest.fn(),
    setSimIdResult: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    simSwapFlowUpdateButtonDisabled: jest.fn(),
    setIsSecNumValidation: jest.fn(),
    setIncompatibleSim: jest.fn(),
    setUpcCodeFromPdpScan: jest.fn(),
  };

  describe(`<DeviceSimID component 1- ${channel}`, () => {
    const validateDevicePSimRes = validateDevicePSim;
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDevicePSimRes));
      }),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });
    const byodProps = { ...props };

    beforeEach(() => {
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });
    test('Device Scan testing by entering wrong device Id', async () => {
      delete window.location;
      window.location = new URL(
        '/product-detail.html?simId=123456&deviceId=54321&isEditAndView=false&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7',
        'http://localhost:3000/content/vcg/assisted',
      );
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 5000);
      });
      expect(deviceTextBox).toHaveValue('350669643749367');
    });
  });
  describe(`<DeviceSimID component 1- ${channel}`, () => {
    jest.mock('onevzsoemfeframework/DomService', () => ({
      isIpad: () => true,
    }));
    const validateDevicePSimRes = validateDevicePSim;
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDevicePSimRes));
      }),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      server.listen();
      // sessionStorage.setItem('customerType', 'N');
    });
    afterAll(() => {
      server.close();
    });
    const byodProps = { ...props, isByodUpdate: true, isPrePay: true };

    beforeEach(() => {
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });
    test('Device Scan testing by entering wrong device Id', async () => {
      delete window.location;
      window.location = new URL(
        '/product-detail.html?simId=123456&deviceId=54321&isEditAndView=false&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7',
        'http://localhost:3000/content/vcg/assisted',
      );
    });
  });
};
Test(CHANNELS.OMNI_INDIRECT);
// Test(CHANNELS.OMNI_CARE);
