import React from 'react';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import SimScan from './SimScan';
import { setUserAgentIPad } from '../../../modules/test-utils/utils';

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradleProperty: () => ['TRUE'],
    getAssistedCradlePropertyV2: () => ['TRUE'],
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => false,
  }),
  { virtual: true },
);

describe('SimScan component', () => {
  beforeAll(() => {
    global.window.simIdBarCodeScannerCallback = jest.fn();
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  const props = {
    isCustomerProvidedEquipment: false,
    fromCpe: false,
    handleChangeSimID: jest.fn(),
    deviceId: '350669643749367',
    isLocal: true,
    simId: '97897978797897978',
    showScanner: false,
    updateDfillSimId: jest.fn(),
    isDeviceBuyout: false,
    updateShowISPUForVA: false,
    isVideoAssistFlow: false,
    isRetail: true,
    getDeviceData: {},
    simDisabled: false,
    channel: 'OMNI-RETAIL',
    deviceInfo: { invokeIdScan: 'Y' },
    validateDeviceSimRequest: { data: { lines: [{ device: { Flowtype: 'SIM' } }] } },
    validateDeviceSimIdRequest: jest.fn(),
    simSwapFlowUpdateButtonDisabled: jest.fn(),
    handleGetUpdateOldSimId: jest.fn(),
    isNewlyAddedLine: true,
    isByodUpdate: true,
    isDisabled: false,
    setSimInputChangedIpad: jest.fn(), 
    setSimValueIpad: jest.fn(),
    flexFlowServiceChange: true,
  };
  beforeEach(() => {
    render(<SimScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('SimScan Component to be rendered on screen', async () => {
    const SimScanLoad = screen.getByTestId('sim-scan');
    expect(SimScanLoad).toBeInTheDocument();
  });

  test('Sim Scan testing by entering sim Id', async () => {
    const simTextBox = await screen.getByRole('textbox', { name: 'Enter Sim ID' });
    fireEvent.change(simTextBox, { target: { value: '89148000005700881964' } });
    fireEvent.blur(simTextBox, { target: { value: '89148000005700881964' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    expect(simTextBox).toHaveValue('89148000005700881964');
  });

  test('Sim Scan testing by entering empty sim Id', async () => {
    const simTextBox = await screen.getByRole('textbox', { name: 'Enter Sim ID' });
    fireEvent.change(simTextBox, { target: { value: '' } });
    fireEvent.blur(simTextBox, { target: { value: '' } });
    expect(simTextBox).toHaveValue('');
  });

  test('Sim Scan testing by entering sim sku', async () => {
    const simTextBox = await screen.getByRole('textbox', { name: 'Enter Sim ID' });
    fireEvent.change(simTextBox, { target: { value: 'BULKSIMTRI-A' } });
    fireEvent.blur(simTextBox, { target: { value: 'BULKSIMTRI-A' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    expect(simTextBox).toHaveValue('BULKSIMTRI-A');
  });

  test('Sim Scan testing by entering invalid sim id', async () => {
    const simTextBox = await screen.getByRole('textbox', { name: 'Enter Sim ID' });
    fireEvent.change(simTextBox, { target: { value: '8914BUl' } });
    fireEvent.blur(simTextBox, { target: { value: '8914BUl' } });
    const simErrorMsg = screen.getByText('Please enter a valid SIM ID');
    expect(simErrorMsg).toBeInTheDocument();
  });

  test('Sim Scan testing for CP Sim confirmation checkbox', async () => {
    const cpSimCheckBox = await screen.getByRole('checkbox', { name: 'This SIM card is customer-provided equipment' });
    expect(cpSimCheckBox).not.toBeChecked();
    fireEvent.change(cpSimCheckBox, { target: { checked: true } });
    expect(cpSimCheckBox).toBeChecked();
    fireEvent.click(cpSimCheckBox);
    fireEvent.change(cpSimCheckBox, { target: { checked: false } });
    expect(cpSimCheckBox).not.toBeChecked();
  });
});

describe('SimScan component Ipad', () => {
  const props = {
    isCustomerProvidedEquipment: false,
    fromCpe: false,
    handleChangeSimID: jest.fn(),
    deviceId: '350669643749367',
    isLocal: true,
    simId: '89148000005700881964',
    showScanner: true,
    updateDfillSimId: jest.fn(),
    isDeviceBuyout: false,
    updateShowISPUForVA: jest.fn(),
    isVideoAssistFlow: true,
    isRetail: true,
    getDeviceData: {},
    simDisabled: false,
    channel: 'OMNI-RETAIL',
    deviceInfo: { invokeIdScan: 'Y' },
    validateDeviceSimRequest: { data: { lines: [{ device: { Flowtype: 'SIM' } }] } },
    validateDeviceSimIdRequest: jest.fn(),
    simSwapFlowUpdateButtonDisabled: jest.fn(),
    handleGetUpdateOldSimId: jest.fn(),
    setSimInputChangedIpad: jest.fn(), 
    setSimValueIpad: jest.fn(),
    flexFlowServiceChange: true,
  };
  setUserAgentIPad();
  beforeEach(() => {
    render(<SimScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('Sim Scan testing by scanning sim Id', async () => {
    const data = { dataset: { barcode: '{"ICCID":"89148000005700881964"}' } };
    window.simIdBarCodeScannerCallback(data);
    const simScanner = await screen.getByTestId('scanSimIdBarCode');
    fireEvent.click(simScanner);
    fireEvent.keyPress(simScanner, { key: 'Enter', charCode: 32 });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    const simTextBox = await screen.getByRole('textbox');
    expect(simTextBox).toHaveValue('89148000005700881964');
  });

  test('Sim Scan testing by scanning sim Id with null', async () => {
    const data = { dataset: { barcode: '{}' } };
    window.simIdBarCodeScannerCallback(data);
    const simScanner = await screen.getByTestId('scanSimIdBarCode');
    fireEvent.click(simScanner);
    fireEvent.keyPress(simScanner, { key: 'Enter', charCode: 10 });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });

  test('Sim Scan testing by with barcode cancel', async () => {
    const data = { dataset: { barcode: 'cancel' } };
    window.simIdBarCodeScannerCallback(data);
    const simScanner = await screen.getByTestId('scanSimIdBarCode');
    fireEvent.click(simScanner);
    fireEvent.keyPress(simScanner, { key: 'Enter', charCode: 32 });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });

  test('Sim Scan testing for CP Sim confirmation checkbox', async () => {
    const cpSimCheckBox = await screen.getByRole('checkbox', {
      name: 'This SIM card is customer-provided equipment',
    });
    expect(cpSimCheckBox).not.toBeChecked();
    fireEvent.click(cpSimCheckBox);
    fireEvent.change(cpSimCheckBox, { target: { checked: true } });
    expect(cpSimCheckBox).toBeChecked();
  });

   test('SimScan Component to be rendered on screen flexflowServiceChange', async () => {
    render(<SimScan {...props} isProvisionalId={true} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    const SimScanLoad = screen.getAllByTestId('handleChangeSimID');
    expect(SimScanLoad[0]).toBeInTheDocument();
  });
});

describe('SimScan component Scanner Test Desktop', () => {
  const props = {
    isCustomerProvidedEquipment: false,
    fromCpe: false,
    handleChangeSimID: jest.fn(),
    deviceId: '350669643749367',
    isLocal: true,
    simId: '97897978797897978',
    showScanner: true,
    updateDfillSimId: jest.fn(),
    isDeviceBuyout: false,
    updateShowISPUForVA: false,
    isVideoAssistFlow: false,
    isRetail: true,
    getDeviceData: {},
    simDisabled: false,
    channel: 'OMNI-RETAIL',
    deviceInfo: { invokeIdScan: 'Y' },
    validateDeviceSimRequest: { data: { lines: [{ device: { Flowtype: 'SIM' } }] } },
    validateDeviceSimIdRequest: jest.fn(),
    simSwapFlowUpdateButtonDisabled: jest.fn(),
    handleGetUpdateOldSimId: jest.fn(),
    setSimInputChangedIpad: jest.fn(), 
    setSimValueIpad: jest.fn(),
    flexFlowServiceChange: true,
  };
  beforeEach(() => {
    render(<SimScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('Sim Scanner testing in desktop', async () => {
    const data = { dataset: { barcode: '{"ICCID":"89148000005700881964"}' } };
    window.simIdBarCodeScannerCallback(data);
    const simScanner = await screen.getByTestId('scanSimIdBarCode');
    fireEvent.click(simScanner);
    fireEvent.keyPress(simScanner, { key: 'Enter', charCode: 5 });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });
});

describe('SimScan component-Default props-Desktop ', () => {
  const props = {
    isCustomerProvidedEquipment: false,
    fromCpe: false,
    handleChangeSimID: jest.fn(),
    deviceId: '350669643749367',
    isLocal: true,
    simId: '97897978797897978',
    showScanner: false,
    updateDfillSimId: jest.fn(),
    isDeviceBuyout: false,
    updateShowISPUForVA: false,
    isVideoAssistFlow: false,
    isRetail: true,
    getDeviceData: {},
    simDisabled: false,
    channel: 'OMNI-RETAIL',
    deviceInfo: { invokeIdScan: 'Y' },
    validateDeviceSimRequest: { data: { lines: [{ device: { Flowtype: 'SIM' } }] } },
    fromInterim: false,
    validateDeviceSimIdRequest: jest.fn(),
    simSwapFlowUpdateButtonDisabled: jest.fn(),
    handleGetUpdateOldSimId: jest.fn(),
    setSimInputChangedIpad: jest.fn(), 
    setSimValueIpad: jest.fn(),
  };
  beforeEach(() => {
    render(<SimScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('it should render with SimScan-Desktop', async () => {
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    const EnterSimId = screen.getByTestId('handleChangeSimID');
    expect(EnterSimId).toBeInTheDocument();
    fireEvent.change(EnterSimId, { target: { value: '89148000007627330562' } });
    fireEvent.blur(EnterSimId, { target: { value: '89148000007627330562' } }, '89148000007627330562');
    const cpSimCard = screen.getByRole('checkbox', { name: 'This SIM card is customer-provided equipment' });
    expect(cpSimCard).toBeInTheDocument();
    fireEvent.click(cpSimCard, { target: { value: '89148000007627330562' } });
  });
});
describe('SimScan component-Default props-Desktop 1 ', () => {
  jest.mock(
    'onevzsoemfeframework/DomService',
    () => ({
      __esModule: true,
      default: jest.fn(() => ({})),
      ...jest.requireActual('onevzsoemfeframework/DomService'),
      isRetail: () => true,
      isIpad: () => true,
    }),
    { virtual: true },
  );
  const props = {
    isCustomerProvidedEquipment: true,
    fromCpe: true,
    handleChangeSimID: jest.fn(),
    deviceId: '350669643749367',
    isLocal: true,
    simId: '97897978797897978',
    showScanner: false,
    updateDfillSimId: jest.fn(),
    isDeviceBuyout: false,
    updateShowISPUForVA: false,
    isVideoAssistFlow: true,
    isRetail: true,
    getDeviceData: {},
    simDisabled: false,
    channel: 'OMNI-RETAIL',
    deviceInfo: { invokeIdScan: 'Y' },
    validateDeviceSimRequest: { data: { lines: [{ device: { Flowtype: 'SIM' } }] } },
    fromInterim: true,
    validateDeviceSimIdRequest: jest.fn(),
    simSwapFlowUpdateButtonDisabled: jest.fn(),
    handleGetUpdateOldSimId: jest.fn(),
    isPaymentOptionVisible: false,
    isNewlyAddedLine: true,
    isByodUpdate: true,
    isDisabled: true,
    setSimInputChangedIpad: jest.fn(), 
    setSimValueIpad: jest.fn(),
  };
  beforeEach(() => {
    window.mfe = { scmDeviceMfeEnable: true, isDark: true };
    render(<SimScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('it should render with SimScan-Desktop', async () => {
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    const EnterSimId = screen.getByTestId('handleChangeSimID');
    expect(EnterSimId).toBeInTheDocument();
    fireEvent.change(EnterSimId, { target: { value: '89148000007627330562' } });
    fireEvent.blur(EnterSimId, { target: { value: '89148000007627330562' } }, '89148000007627330562');
  });
});

describe('SimScan component Ipad', () => {
  const props = {
    hideCPSim: true,
    isCustomerProvidedEquipment: false,
    fromCpe: false,
    handleChangeSimID: jest.fn(),
    deviceId: '350669643749367',
    isLocal: true,
    simId: '89148000005700881964',
    showScanner: true,
    updateDfillSimId: jest.fn(),
    isDeviceBuyout: false,
    updateShowISPUForVA: jest.fn(),
    isVideoAssistFlow: true,
    isRetail: true,
    getDeviceData: {},
    simDisabled: false,
    channel: 'OMNI-RETAIL',
    deviceInfo: { invokeIdScan: 'Y' },
    validateDeviceSimRequest: { data: { lines: [{ device: { Flowtype: 'SIM' } }] } },
    validateDeviceSimIdRequest: jest.fn(),
    simSwapFlowUpdateButtonDisabled: jest.fn(),
    handleGetUpdateOldSimId: jest.fn(),
    setSimInputChangedIpad: jest.fn(), 
    setSimValueIpad: jest.fn(),
  };
  setUserAgentIPad();
  beforeEach(() => {
    render(<SimScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('Sim Scan testing by scanning sim Id', async () => {
    const cpsArea = screen.queryByText('This SIM card is customer-provided equipment');
    expect(cpsArea).toBeNull(); // it doesn't exist
  });
});
