import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import { CHANNELS, setupChannel, setUserAgentIPad } from '../../../modules/test-utils/utils';
import DeviceSimID from './DeviceSimID';
import cartDetails from '../../../pages/PDP/mocks/api/retrieveCart.json';
import customerProfileDetails from '../../../pages/PDP/mocks/api/customerProfile.json';
import omniCareCustomerProfileDetails from '../../../pages/PDP/mocks/api/omniCareCustomerProfile.json';
import getSkuDetails from '../../../pages/PDP/mocks/api/getSkuDetails.json';
import validateDeviceSimId from '../../../pages/PDP/mocks/api/validateDeviceSimId.json';
import validateDeviceEsim from '../../../pages/PDP/mocks/api/validateDeviceEsim.json';
import eSimDetails from '../../../pages/PDP/mocks/api/eSimDetails.json';
import validateDeviceByod from '../../../pages/PDP/mocks/api/validateDeviceByod.json';
import validateDeviceCpe from '../../../pages/PDP/mocks/api/validateDeviceCpe.json';

jest.mock(
  'onevzsoemfecommon/Helpers',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getQueryParamByName: jest.fn(() => {}),
    getUIContextPath: jest.fn(() => {}),
    getUIContextPathBAU: jest.fn(() => {}),
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradleProperty: () => ['TRUE', 'TRUE', '', '', '', '', 'TRUE'],
    getAssistedCradlePropertyV2: () => ['TRUE', 'TRUE', '', '', '', '', 'TRUE'],
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => false,
    isIpad: () => true,
  }),
  { virtual: true },
);
const Test = (channel) => {
  setupChannel(channel);
  const details = getSkuDetails?.data?.deviceSku?.parentProducts[0];

  const compatibleSims = details?.compatibleSimSorIds;
  const updateCpeCheckboxFlag = jest.fn();
  const props = {
    deviceFromFilteredCartLine: {
      deviceId: '350496304834340',
      eDeviceId: '350496304834340',
    },
    simFromFilteredCartLine: {
      eSIM: '456789074683883838',
      simId: '456789074683883838',
    },
    lineDeviceIdFromLanding: '353756110808409',
    isNewLine: false,
    isVideoAssistFlow: false,
    activeMtn: '5185673926',
    isDWOS: false,
    isIndirect: false,
    compatibleSims,
    isBYODUpdateAALRetail: false,
    isCancel: jest.fn(),
    sku: '',
    byodDevice: '',
    isByodUpdate: false,
    deviceFromCart: false,
    isLocal: true,
    isFromCPE: false,
    defaultDeviceId: '353756110808409',
    defaultSimId: '89148000005700881964',
    customerProfileDetails: customerProfileDetails.data,
    cartDetails: cartDetails?.data,
    setUpcCodeFromPdpScan: jest.fn(),
    upcCodeFromPdpScan: '353756110808',
    isBBYLocalOrder: true,
    updateDeviceId: jest.fn(),
    updateSimId: jest.fn(),
    updateCpeCheckboxFlag,
    updateDeviceData: jest.fn(),
    setSimIdResult: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    simSwapFlowUpdateButtonDisabled: jest.fn(),
    setUpcAndDeviceIdCheckEnabled: jest.fn(),
    setIncompatibleSim: jest.fn(),
    setRemoveSimOnlyChange: jest.fn(),
  };
  describe(`<DeviceSimID component - ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceSimId));
      }),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      render(<DeviceSimID {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });

    test('DeviceSimID Component to be rendered on screen', async () => {
      const DeviceSimIDLoad = screen.getByTestId('DeviceSimID');
      expect(DeviceSimIDLoad).toBeInTheDocument();
    });

    test.skip('SimID input should be hidden', async () => {
      const submitButton = screen.queryByText('Enter Sim ID');
      expect(submitButton).toBeNull(); // it doesn't exist
    });

    test('Device Scan testing by entering device Id', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      expect(deviceTextBox).toHaveValue('350669643749367');
    });

    test('Device Scan testing by entering incorrect device Id ', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '35066964374936' } });
      fireEvent.blur(deviceTextBox, { target: { value: '35066964374936' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      expect(deviceTextBox).toHaveValue('35066964374936');
    });

    test('Device Scan testing by entering device Id with string', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: 'abc' } });
      fireEvent.blur(deviceTextBox, { target: { value: 'abc' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
    });
  });

  describe(`<DeviceSimID component Byod flow- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceByod));
      }),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);
    const byodProps = { ...props, isLocal: false, isFromCPE: true, isByodUpdate: true, isRetail: true };
    beforeAll(() => {
      server.listen();
      class ResizeObserver {
        constructor() {
          this.observe = () => jest.fn();
          this.unobserve = () => jest.fn();
          this.disconnect = () => jest.fn();
        }
      }
      window.ResizeObserver = ResizeObserver;
    });
    setUserAgentIPad();
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      Object.defineProperty(window, 'mfe', {
        value: { scmDeviceMfeEnable: true },
        configurable: true,
      });
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
      };
    });

    test('Device Scan testing by entering DualSim device Id', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Customer Provided Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();
      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
      fireEvent.click(screen.getByRole('radio', { name: 'physicalSim' }));
      fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    });
    test('Device Scan testing by entering DualSim device Id', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Customer Provided Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();
      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
      fireEvent.click(screen.getAllByRole('radio')[0]);
      fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    });

    test('Device Scan testing for CP Sim confirmation checkbox', async () => {
      const cpSimCheckBox = await screen.getByRole('checkbox', {
        name: 'This device is customer-provided equipment',
      });
      expect(cpSimCheckBox).toBeChecked();
      fireEvent.change(cpSimCheckBox, { target: { checked: true } });
      fireEvent.click(cpSimCheckBox);
      expect(cpSimCheckBox).not.toBeChecked();
    });

    test('ESim UI popup cancel check', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Customer Provided Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();
      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
      const eSimCancelBtn = await screen.findByTestId('Cancel');
      expect(eSimCancelBtn).toBeInTheDocument();
      fireEvent.click(eSimCancelBtn);
    });
  });

  describe(`<DeviceSimID component Byod flow with Esim model- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceCpe));
      }),
    ];
    const server = setupServer(...handlers);
    const byodProps = { ...props, isLocal: false, isFromCPE: true, isByodUpdate: true, isRetail: true };
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
      };
    });

    test('Device Scan testing by entering Dual Sim device Id with Esim popup', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Customer Provided Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
      const eSimConfirmation = await screen.findByText(
        'This device requires an eSim for activation, do you wish to continue?',
      );
      expect(eSimConfirmation).toBeInTheDocument();
    });
  });

  describe(`<DeviceSimID component Byod flow with Esim model with Single Sim- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceEsim));
      }),
    ];
    const server = setupServer(...handlers);
    const byodProps = { ...props, isLocal: false, isFromCPE: true, isByodUpdate: true, isRetail: true };
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
      };
    });

    test('Device Scan testing by entering Single Sim device Id with Esim popup', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Customer Provided Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
      const eSimConfirmation = await screen.findByText(
        'This device requires an eSim for activation, do you wish to continue?',
      );
      expect(eSimConfirmation).toBeInTheDocument();
    });
  });
  describe(`<DeviceSimID component Byod flow with Non Esim - ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceSimId));
      }),
    ];
    const server = setupServer(...handlers);
    const byodProps = { ...props, isLocal: false, isFromCPE: true, isByodUpdate: true, isRetail: true };
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });

    test('Device Scan testing by entering Non ESim device Id', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Customer Provided Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
      await expect(deviceTextBox).toHaveValue('350669643749367');
    });
  });
  describe(`<DeviceSimID component Local ESim- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceEsim));
      }),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });
    // const eSimProps = { ...props, currentSimId: '1234' };
    beforeEach(() => {
      render(<DeviceSimID {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });

    test('Device Scan testing by entering device Id with Esim Yes', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350321534425745' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350321534425745' } });
      const YesButton = await screen.findByTestId('YesButton');
      fireEvent.click(YesButton);
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      await expect(deviceTextBox).toHaveValue('350321534425745');
    });

    test('Device Scan testing by entering device Id with Esim No', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350321534425745' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350321534425745' } });
      const NoButton = await screen.findByTestId('NoButton');
      fireEvent.click(NoButton);
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      await expect(deviceTextBox).toHaveValue('350321534425745');
    });
  });
  describe(`<DeviceSimID component with out simId wrapper- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceByod));
      }),
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);
    const byodProps = {
      ...props,
      customerProfileDetails: omniCareCustomerProfileDetails?.data,
      isLocal: false,
      isFromCPE: false,
      isRetail: true,
      byodDevice: {
        deviceId: '12345',
        simInfo: {
          preferredSoftSim: '54321',
        },
      },
      sku: 'ICONIC-SERVICE-SKU',
      isByodUpdate: false,
    };
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      window.history.pushState(
        {},
        'Host',
        '/product-detail.html?simId=123456&deviceId=54321&scanFromLanding=true&prospectByodFlow=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7&upcCodeValue=123456789012',
      );
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });
    test('DeviceSimID Component to be rendered on screen', async () => {
      delete window.location;
      window.location = new URL(
        '/product-detail.html?simId=123456&deviceId=54321&isEditAndView=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7&upcCodeValue=123456789012',
        'http://localhost:3000/content/vcg/assisted',
      );
      const DeviceSimIDLoad = screen.getByTestId('DeviceSimID');
      expect(DeviceSimIDLoad).toBeInTheDocument();
    });
  });
  describe(`<DeviceSimID component with out simId wrapper- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceByod));
      }),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);
    const byodProps = {
      ...props,
      customerProfileDetails: customerProfileDetails?.data,
      isLocal: false,
      isFromCPE: false,
      isRetail: true,
      byodDevice: '',
      sku: 'ICONIC-SERVICE-SKU',
      setUpcCodeFromPdpScan: jest.fn(),
      upcCodeFromPdpScan: '353756110808',
      isBBYLocalOrder: true,
    };
    beforeAll(() => {
      window.mfe.scmDeviceMfeEnable = true;
      window.mfe.isDark = true;
      sessionStorage.setItem('channel', 'OMNI-RETAIL');
      sessionStorage.getItem('customerType', 'N');
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      window.history.pushState(
        {},
        'Host',
        '/product-detail.html?simId=123456&deviceId=54321&scanFromLanding=true&prospectByodFlow=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7&upcCodeValue=123456789012',
      );
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });
    test('DeviceSimID Component to be rendered on screen', async () => {
      delete window.location;
      window.location = new URL(
        '/product-detail.html?simId=123456&deviceId=54321&isEditAndView=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7&upcCodeValue=123456789012',
        'http://localhost:3000/content/vcg/assisted',
      );
      const DeviceSimIDLoad = screen.getByTestId('DeviceSimID');
      expect(DeviceSimIDLoad).toBeInTheDocument();
    });
    test('UPC code scan function check', async () => {
      const upcCodeScannerId = await screen.findByTestId('upcCodeScannerId');
      expect(upcCodeScannerId).toBeInTheDocument();
      fireEvent.click(upcCodeScannerId);
      window.upcBarCodeScannerCallback({ dataset: { barcode: "{ 'UPC': '350669643749'}" } });
      window.upcBarCodeScannerCallback({ dataset: { barcode: 'cancel' } });
      window.upcBarCodeScannerCallback();
    });
    test('upcCodeScannerId testing', async () => {
      jest.setTimeout(20000);
      const upcCodeScannerId = screen.getByTestId('upcCodeScannerId');
      expect(upcCodeScannerId).toBeInTheDocument();
      fireEvent.keyPress(upcCodeScannerId, { key: 'Enter', charCode: 32 });
      fireEvent.click(upcCodeScannerId);
    });
    test('UPC code Scan testing by entering correct device Id ', async () => {
      const deviceTextBox = await screen.getByTestId('upcCodeTestId');
      expect(deviceTextBox).toBeInTheDocument();
      fireEvent.change(deviceTextBox, { target: { value: '350669643749' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749' } });
      window.verifyUpcAndSkuCallback('true');
    });
    test('UPC code Scan testing by entering Incorrect device Id ', async () => {
      const deviceTextBox = await screen.getByTestId('upcCodeTestId');
      expect(deviceTextBox).toBeInTheDocument();
      fireEvent.change(deviceTextBox, { target: { value: '350669643749' } });
      fireEvent.blur(deviceTextBox, { target: { value: '' } });
      fireEvent.blur(deviceTextBox, { target: { value: '78797' } });
    });

    test('it should render upcCodeTestId', () => {
      const handleChangeDeviceID = screen.getByTestId('upcCodeTestId');
      expect(handleChangeDeviceID).toBeInTheDocument();
      fireEvent.click(handleChangeDeviceID);
    });
  });
};
Test(CHANNELS.OMNI_RETAIL);
// Test(CHANNELS.OMNI_CARE);
