import React, { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
// eslint-disable-next-line you-dont-need-lodash-underscore/get
import { get as getProp, isEmpty } from 'lodash';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import Emitter from 'onevzsoemfeframework/Emitter';
import { Input } from '@vds/inputs';
import { Line } from '@vds/lines';
import { Checkbox } from '@vds/checkboxes';
import { TextLink } from '@vds/buttons';
import { Body } from '@vds/typography';
import {
  getQueryParamByName,
  isIpad,
  isRetail,
  isTelesales,
  isD2D,
  executeShellFunction,
  aesCipher
} from 'onevzsoemfeframework/DomService';
import { sendCustomEvent } from 'onevzsoemfeframework/Tagging';
import { setErrorTagging } from 'onevzsoemfeframework/APIService';
import UserProfile from 'onevzsoemfeframework/AcssUserProfile';
import {  getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { isVbg } from 'onevzsoemfeframework/VbgAemUtil';
import { getUIContextPath, getUIContextPathBAU, acssMfeBasePath, isNumeric } from 'onevzsoemfecommon/Helpers';
import { rfexMfeFlowFlag } from 'onevzsoemfecommon/Helpers/common_functions';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import * as appLoaderActions from 'onevzsoemfecommon/AppLoaderActions';
import { ConfirmationDialogBox } from 'onevzsoemfecommon/ConfirmationDialogBox';
import { useLazyESimDetailsQuery, useLazyRetrieveSimEidDetailsQuery } from 'onevzsoemfecommon/CartAPIService';
import * as DOMPurify from 'dompurify';
import {
  useLazyRetrieveProvisionalDeviceIdQuery,
  useLazyFraudRiskScoreQuery,
  useLazyRetrieveProvisionalDeviceIdSoeQuery,
} from '../../../modules/services/APIService/APIServiceHooks';
// import { useLazyESimDetailsQuery } from '../../../modules/services/APIService/APIServiceHooks';
import DeviceScan from '../../CombinedGridwall/DeviceScan';
import LostStolenConfirmation from '../../CombinedGridwall/LostStolenConfirmation';
import ESim from '../../CombinedGridwall/ESim/ESim';
import SimScan from './SimScan';
import UpcCodeScan from './UpcCodeScan';
import PDPApiCallHook from '../../../pages/PDP/PDPApiCallHook';
import IDScanModal from '../IDScanSecurity/IDScanModal';
import SecondLineDeviceId from '../SecondLineDeviceId';
import {
  MTN_TYPE_PRE_TO_POST,
  MTN_TYPE_YAHOO,
  MTN_TYPE_VISIBLE,
  MTN_TYPE_HARMONY,
} from '../../constants/DeviceConstants';
import getIspuSimEnable from '../../../modules/utils/getIspuSimEnable';
import {
  checkDeviceSimCompatibility,
  getLineActivityType,
  inDirectValidateDeviceSimIdPayload,
  initiateDeviceSimCompatibilityCheck,
  displaySimCompartibleBanner,
  getCartSimSku,
  getDeviceEnforApiPayload,
  isFraudRiskApiEnabledForDeviceChange,
} from '../pdputils';
import SecondNumActivationModal from '../../CombinedGridwall/SecondNumActivationModal';
import { isFunctionalityEnabled, makeOpenViewCall } from '../../../modules/utils';
import FFLAGS from '../../../constants/fFlag.constant';
import { UI_MESSAGES, THE_DEVICE_ID, HAS_BEEN_SUCCESSFULLY_REMOVED_FROM_THE_LOST_STOLEN_LIST } from '../../../constants/constants';
import RegenerateESimModal from './RegenerateESimModal';
import SimSale from './SimSale';
import { trainingFlag } from 'onevzsoemfecommon/Helpers/validation';

const DivWrapper = styled.div`
  display: block;
  width: ${window?.mfe?.scmDeviceMfeEnable && '16rem'};
  overflow-wrap: ${window?.mfe?.scmDeviceMfeEnable && 'break-word'};
  .etr-title {
    padding-bottom: 1rem;
    font-size: 1rem;
  }
`;
const DeviceWrapper = styled.div`
  ${(props) =>
    `
      display: flex;
      flex-direction: ${props.flexFlowServiceChange ? 'column' : 'row'};
      gap: ${props.flexFlowServiceChange ? '1rem' : '0'};
      align-items: flex-start;
      width: 100%;
      justify-content: space-between;
    `}
`;
/* istanbul ignore next */
const FlexFlowWrapper = styled.div`
  ${(props) =>
    props.flexflow &&
    `
      display: flex;
      align-items: flex-start;
      width: 100%;
      justify-content: space-between;
    `}
`;
const IpadSimContent = styled.div`
  width: max-content;
`;
const InputWrapper = styled.div`
  display: flex;
  align-items: center;
  flex-direction: column;
  align-items: flex-start;
  .eSimRegenerate {
    flex-direction: row !important;
    align-items: center !important;
    justify-content: space-between !important;
    width: 100% !important;
  }
  .regenrate-container {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    row-gap: 10px;
  }
  .simtypefield {
    flex-direction: row !important;
    align-items: center !important;
    gap: 50px;
  }
  .simTypeDisplay {
    padding-top: 30px;
    ${!isIpad() && `padding-left: 57px;`}
  }
  .regenerateEsimLink {
    ${!isIpad() && `padding-left: 60px;`}
  }
`;
const SIMIDWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  width: ${({ scmDeviceEnable }) => (scmDeviceEnable ? '18rem' : '21rem')};
  padding-left: ${({ scmDeviceEnable }) => scmDeviceEnable && '2%'};
`;
const CheckboxWrapper = styled.div`
  margin-top: 10px;
`;
const HorizontalLineWrapper = styled.div`
  padding: 1rem 0 1rem 0;
`;

const DisplayWrapper = styled.div`
  padding: 1rem 0 1rem 0;
`;

const ESimRegenerateMessage = styled.div`
  font-size: small !important;
`;

let navigate = '';
const inputSimRegEx = /^\d{19,20}$/;
const alphaNumericRegEx = /^[A-Za-z0-9-]+$/;

function useNavigateMFE() {
  navigate = useNavigate();
}

function HorizontalLine() {
  return (
    <HorizontalLineWrapper>
      <Line type='secondary' surface='light' />
    </HorizontalLineWrapper>
  );
}

const getIsInsideSalesUser = () => window?.mfe?.isProspectNewCustomerTab ? false : window?.mfe?.isInsideSalesUser || false;

const DeviceSimID = (props) => { /* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */
  const CustomerData = props.customerProfileDetails?.customer;
  const customerInfo = CustomerData || {};
  const fFlagData = FFLAGS.scmCommonDefectFixFFlag;
  const isEsimActivationEnabled = isFunctionalityEnabled(
    fFlagData?.name,
    fFlagData?.attribute?.EsimActivationEnabled,
    fFlagData?.attribute?.eSimDbFlag,
  );
  const lookUpMtn = customerInfo?.lookupMtn;
  const billAccounts = getProp(customerInfo, 'billAccounts', []);
  const mtns = billAccounts?.[0]?.mtns || [];
  const equipmentInfo = mtns?.find((obj) => obj.mtn === lookUpMtn)?.equipmentInfos?.[0] || {};
  const locationCd = sessionStorage.getItem('location') || '';
  const {
    deviceFromFilteredCartLine,
    simFromFilteredCartLine,
    setIsSecNumValidation,
    omnicaredropdownValue,
    simSwapNotificationHighRiskMsg,
    SkuDetailsResult,
    customerProfileDetails,
    cartDetails,
    activeMtn
  } = props;
  const simSwapNotify = window?.mfe?.acssAANotify;
  const isSecureSimSwap = window?.mfe?.acssAAEnable;
  const commonInfo = props.customerProfileDetails?.commonInfo;
  const scmDeviceEnable = window?.mfe?.scmDeviceMfeEnable || false;
  const channel = CustomerData?.channel || sessionStorage.getItem('channel');
  const deviceFromCart = /true/i.test(getQueryParamByName('deviceFromCart'));
  const localScan = /true/i.test(getQueryParamByName('isLocal'));
  const UpcCodeData = getQueryParamByName('upcCodeValue') || '';
  const [flexFlowServiceChangeFFlag, soeNsaProvisionaIdFFlag] = getAssistedCradlePropertyV2(['flexFlowServiceChangeFFlag', 'soeNsaProvisionaIdFFlag']);
  const isFlagEnabled = (flag) => /true/i.test(flag);
  const isFlexFlowFlagEnabled = isFlagEnabled(flexFlowServiceChangeFFlag);
  const isSoeNsaFlagEnabled = isFlagEnabled(soeNsaProvisionaIdFFlag);
  const hasEtrServiceChanges = getQueryParamByName('etrServiceChanges');
  const fixSCMDeviceChangeIccid = isFunctionalityEnabled(FFLAGS?.scmCommonFixFFlag?.name, FFLAGS?.scmCommonFixFFlag?.attribute?.fixSCMDeviceChangeIccid);
  const determineFlexFlowServiceChange = (isFlagEnabled, hasChanges) => {
  return isFlagEnabled && hasChanges;
  };
  const determineRetrieveProvisionalSoe = (isFlowEnabled, isFlagEnabled) => {
    return isFlowEnabled && isFlagEnabled;
  };
  const flexFlowServiceChange = determineFlexFlowServiceChange(isFlexFlowFlagEnabled, hasEtrServiceChanges);
  const retrieveProvisionalSoe = determineRetrieveProvisionalSoe(flexFlowServiceChange, isSoeNsaFlagEnabled);
  const isFraudRiskEnabled = props?.isNewlyAddedLine
    ? false
    : isFraudRiskApiEnabledForDeviceChange({ isSecureSimSwap });
  const [validatedDeviceId, setValidatedDeviceId] = useState(
    props.isByodUpdate || props.isFromCPE || props.isLocal ? getQueryParamByName('deviceId') : props.defaultDeviceId,
  );
  // as per BAU for local scan no need to show previous sim id
  const [isProvisionalIdChecked, setIsProvisionalIdChecked] = useState(false);
  const [validatedSimId, setValidatedSimId] = useState(props.isByodUpdate || props.isFromCPE ? props.defaultSimId : '');
  const [shouldShowSimSale, setShouldShowSimSale] = useState(false);
  const [simIdChanged, setSimIdChanged] = useState(false);
  const [changedSimId, setChangedSimId] = useState('');
  const [simValueIpad, setSimValueIpad] = useState('');
  const [simInputChangedIpad, setSimInputChangedIpad] = useState(false);
  const isEditAndView = /true/i.test(getQueryParamByName('isEditAndView'));
  const isByodUpdate = /true/i.test(getQueryParamByName('isByodUpdate'));
  const [cpeCheckbox, setCpeCheckbox] = useState(true);
  const [simSkuEntered, setSimSkuEntered] = useState('');
  const [simSkuInput, setSimSkuInput] = useState('');
  const [deviceInput, setDeviceInput] = useState('');
  const [simSkuOverride, setSimSkuOverride] = useState(false);
  const [simSkuOnFocus, setSimSkuOnFocus] = useState('');
  const isOmniCare = props.customerProfileDetails?.customer?.channel === 'OMNI-CARE' || scmDeviceEnable;
  const [deviceIdChanged, setDeviceIdChanged] = useState(false);
  const [updatedDeviceId, setUpdatedDeviceId] = useState(false);
  const [simDisabled, setSimDisabled] = useState(false);
  const [isSingleSimEntiLookupModalVisibleByod, setIsSingleSimEntiLookupModalVisibleByod] = useState(false);
  const [isDualSimEntiLookupModalVisible, setIsDualSimEntiLookupModalVisible] = useState(false);
  const [devicedata, setdevicedata] = useState({});
  const [devicePayload, setDevicePayload] = useState({});
  const [popUp, setPopUp] = useState(false);
  const [isIdScanModalOpen, setIdScanModalOpen] = useState(false);
  const [eSimData, eSimDataResults] = useLazyESimDetailsQuery();
  const [retriveSimEIdCall, retriveSimEIdResult] = useLazyRetrieveSimEidDetailsQuery();
  const [validateDeviceSimRequest, setValidateDeviceSimRequest] = useState({});
  const [secondLine, setSecondLine] = useState(false);
  const [repSelectedSimType, setRepSelectedSimType] = useState('');
  const [showSecondNumberActivationModal, setShowSecondNumberActivationModal] = useState(false);
  const { validateDeviceSimIdRequestBody, ValidateDeviceSimIdResult } = PDPApiCallHook();
  const retrieveProvisionalSoeApi = useLazyRetrieveProvisionalDeviceIdSoeQuery();
  const retrieveProvisionalAcssApi = useLazyRetrieveProvisionalDeviceIdQuery();
  const getProvisionalDeviceApi = (useProvisionalSoe, soeApi, acssApi) => {
  return useProvisionalSoe ? soeApi : acssApi;
  };
  // Usage
  const provisionalDeviceApi = getProvisionalDeviceApi(retrieveProvisionalSoe,retrieveProvisionalSoeApi,
  retrieveProvisionalAcssApi);
  const [getRetrieveProvisionalDeviceId, retrieveProvisionalDeviceIdResult] = provisionalDeviceApi;
  const [getfraudRiskScore, fraudRiskScoreResult] = useLazyFraudRiskScoreQuery();
  const ValidateDeviceSimIdResultStatus = ValidateDeviceSimIdResult?.status;
  const simErrorMsg = 'Please enter a valid SIM ID';
  const [simError, setSimError] = useState(false);
  const [simSaleFlow, setSimSaleFlow] = useState(false);
  const [validSimSku, setValidSimSku] = useState('');
  const [eSimRegenerateStatus, setESimRegenerateStatus] = useState({
    initiate: false,
    enable: false,
    showConfirmModal: false,
    deviceId: '',
    simId: '',
  });
  const [showESimRegenerateMessage, setShowESimRegenerateMessage] = useState(false);

  // Lost/Stolen device confirmation states
  const [showLostStolenConfirmation, setShowLostStolenConfirmation] = useState(false);
  const [lostStolenDeviceId, setLostStolenDeviceId] = useState('');

  const isDark = (window?.mfe?.scmDeviceMfeEnable && window?.mfe?.isDark) || false;
  const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable || false;
  const isNtfnIndFlagEnabled = window?.mfe?.isNotfnIndAA || false;
  const isInsideSalesUser = getIsInsideSalesUser();
  const { isVideoAssistFlow = false, isIndirect, isBYODUpdateAALRetail, byodDevice, scanCheck, setSimIdResult } = props;
  const [
    isMitekSimSwapEnabled,
    deviceActiveCheck,
    deviceActiveLoanCheck,
    devicePreorderCheck,
    iccidStatusCheck,
    disableEsimAtLocalInventory,
    bestBuyIntegrationFFlag,
    lostStolenDeviceUIFFlag,
  ] = getAssistedCradlePropertyV2([
    'isMitekSimSwapEnabled',
    'deviceActiveCheck',
    'deviceActiveLoanCheck',
    'devicePreorderCheck',
    'iccidStatusCheck',
    'disableEsimAtLocalInventory',
    'bestBuyIntegrationFFlag',
    'lostStolenDeviceUIFFlag',
  ]);
    const cleanProvisionalIdIndFFlag = /true/i.test(getAssistedCradlePropertyV2(['cleanProvisionalIdIndFFlag'])?.[0])
  const [secondNumActivationModalFFlag] = getAssistedCradlePropertyV2(['secondNumActivationModalFFlag']);
  const checkSimActiveFFlag = /true/i.test(getAssistedCradlePropertyV2(['checkSimActiveFFlag'])?.[0]);
  let skipICCIDFFlag = /true/i.test(getAssistedCradlePropertyV2(['skipICCIDFFlag'])?.[0]);
  const byodBtnFFlag = /true/i.test(getAssistedCradlePropertyV2(['byodButtonFFlag'])?.[0]);
  const watchServiceTransFlowFFlag = /true/i.test(getAssistedCradlePropertyV2(['watchServiceTransFlowFFlag'])?.[0]);
  const deviceFilterType = (SkuDetailsResult?.data?.data?.deviceSku?.parentProducts?.[0].childSkus?.[0].skuFilters?.deviceFilterType || props?.selectedSku?.skuFilters?.deviceFilterType);
  const deviceTypeWatch =(/SmartWatch/i.test(deviceFilterType));
  const isSmartWatchCheck = !deviceTypeWatch || watchServiceTransFlowFFlag;
  const validateSimIdFFlag = /true/i.test(getAssistedCradlePropertyV2(['validateSimIdFFlag'])?.[0]);
  const esimAPIskipFFlag = /true/i.test(getAssistedCradlePropertyV2(['esimAPIskipFFlag'])?.[0]);
  const addDeviceIssueFFlag = /true/i.test(getAssistedCradlePropertyV2(['addDeviceIssueFFlag'])?.[0]);

  
  // Override skipICCIDFFlag for SCM Generate Esim Profile
  if (scmDeviceEnable && props?.callESimApi) {
    skipICCIDFFlag = false;
  }
  /* istanbul ignore next */
  const byodButtonFFlag = channel === 'VZW-ACSS' ? false : byodBtnFFlag;
  let [skipIccidCall] = getAssistedCradlePropertyV2(['skipIccidCall']);
  skipIccidCall = skipICCIDFFlag || /true/i.test(skipIccidCall); // converting String (TRUE/FALSE) to boolean (true/false)
  const appPropertiesFromSessionStorage = DOMPurify.sanitize(sessionStorage.getItem('APP_PROPERTIES'));
  const pearlBYODFlow = appPropertiesFromSessionStorage
    ? JSON.parse(appPropertiesFromSessionStorage)?.pearlBYODFlow === 'TRUE'
    : false;
  const simCompatibilityCheck22417FFlag = appPropertiesFromSessionStorage
    ? JSON.parse(appPropertiesFromSessionStorage)?.simCompatibilityCheck22417FFlag === 'TRUE'
    : false;
  const isPearl = DOMPurify.sanitize(sessionStorage.getItem('isPearl')) === 'true' && pearlBYODFlow;

  const dispatch = useDispatch();

  // const navigate = scmDeviceEnable ? "" :useNavigate();

  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }
  /* istanbul ignore next */
  function assignNumberRedirect() {
    if (scmDeviceEnable) window?.mfe?.historyRef?.push(`${acssMfeBasePath}/numberselection.html`);
    else navigate(`${getUIContextPathBAU()}/numberselection.html`);
  }

  const disableDeviceDetailsForAsurion = false;
  const showScanner = commonInfo?.showScanner;
  const isCustomerProvidedEquipment = !!(props.isByodUpdate || props.isFromCPE);
  const isEsimOnlyDevice = !isEmpty(devicedata)
    ? devicedata?.eSimOnlyDevice
    : getQueryParamByName('eSimOnlyDevice') === 'true' || getQueryParamByName('eSim') === 'true';
  const simProcessOnlyIpad = !!(
    !isIpad() &&
    !scmDeviceEnable &&
    !props.isNewLine &&
    channel &&
    (channel?.indexOf('OMNI-RETAIL') > -1 ||
      channel?.indexOf('OMNI-D2D') > -1 ||
      channel === 'OMNI-TELESALES' ||
      channel === 'OMNI-CARE' ||
      (channel?.includes('OMNI-INDIRECT') && !deviceIdChanged))
  );
  let isByodUpdateOnDekstop = !!(props.isByodUpdate && !isIpad());
  const customerType = sessionStorage.getItem('customerType');
  const deviceInfo = ValidateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo;
  const isDeviceIMEIChange =
    scmDeviceEnable && isEsimActivationEnabled &&
    (deviceInfo?.imei1 === props.lineDeviceIdFromLanding || deviceInfo?.imei2 === props.lineDeviceIdFromLanding);
  const correlationId = ValidateDeviceSimIdResult?.data?.serviceHeader?.correlationId;
  const [deviceIdEsimCheck, setDeviceIdEsimCheck] = useState(
    skipIccidCall && devicedata?.eid !== '' ? devicedata?.deviceId : '',
  );

  const getSimType = (deviceDetails) => {
  let simType = '';
  const pSimCapable = deviceDetails?.simInfo?.eID === '';
  const eSimCapable = deviceDetails?.simInfo?.eID !== '' && deviceDetails?.euiccCapable === 'Y';
  console.log("pSimCapable",pSimCapable);
  console.log("eSimCapable",eSimCapable);
  if (pSimCapable) {
    simType = 'pSIM';
  } else if (eSimCapable) {
    simType = 'eSIM';
  }
  
  return simType;
  };

  const simType = getSimType(deviceInfo);
  console.log("simType",simType);
  const [samsungPOSFFlag] = getAssistedCradlePropertyV2(['samsungPOSFFlag']);
  const samsungPOSFFlagEnabled = /true/i.test(samsungPOSFFlag);
  const carrierLockInResponse =
    ValidateDeviceSimIdResultStatus === 'fulfilled' &&
    ValidateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo?.carrierLock;
  const carrierLock = (samsungPOSFFlagEnabled && carrierLockInResponse) || false;

  useEffect(() => {
    window.verifyUpcAndSkuCallback = verifyUpcAndSkuCallback;
    const deviceIdVal = getQueryParamByName('deviceId');
    let simIdVal = getQueryParamByName('simId');
    if (!isEmpty(byodDevice)) {
      const deviceIdValue = byodDevice.deviceId ? byodDevice.deviceId : deviceIdVal || '';
      const simIdValue = byodDevice.simInfo ? byodDevice.simInfo.preferredSoftSim : simIdVal || '';
      if (!secondLine) {
        setValidatedDeviceId(deviceIdValue);
      }
      setValidatedSimId(simIdValue);
    } else {
      if (deviceIdVal) {
        if (!secondLine) {
          setValidatedDeviceId(deviceIdVal);
        }
      }
      if (simIdVal) {
        if (
          channel?.indexOf('OMNI-RETAIL') > -1 &&
          !props.isByodUpdate &&
          getQueryParamByName('scanFromLanding') !== 'true' &&
          getQueryParamByName('prospectByodFlow') !== 'true'
        ) {
          simIdVal = '';
        }
        setValidatedSimId(simIdVal);
      }
    }
    if (deviceFromCart) setDeviceAndSimIdHandler();
    updateCareDataOnMountAndUpdate(true);

    Emitter.on('CONT_SIM_SKU_VALIDATION', (value) => {
      if (value?.eSimGenerate && value?.eSimGenerate === 'No') {
        return
      }
      if (value?.eSimGenerate && props?.setEnableBYODbtn) {
        props.setEnableBYODbtn(true);
      } else if (value.respCode) {
        setSimSkuEntered(value?.oldVal);
        setSimSkuInput(value?.oldVal);
        setValidatedSimId(value?.oldVal);
      } else {
        callValidateDeviceSku(false, value.newVal, value?.provisionalIdInfo);
      }
    });
    return () => {
      Emitter.off('CONT_SIM_SKU_VALIDATION');
    };
  }, []);

  useEffect(() => {
    if (flexFlowServiceChange) {
      setValidatedDeviceId(getQueryParamByName('deviceId'));
      setValidatedSimId(getQueryParamByName('simId'));
      if(cleanProvisionalIdIndFFlag){
      setIsProvisionalIdChecked(false)
      }
    }
  }, [props?.activeMtn]);
  const getActiveMtnSimInfo = () => {
    const customerInfo = customerProfileDetails?.customer;
    const activeMtnLineInfo = customerInfo?.billAccounts?.[0]?.mtns?.filter((line) => line?.mtn === activeMtn);
    return activeMtnLineInfo?.[0]?.equipmentInfos?.[0]?.simInfo?.simId;
  };
  useEffect(() => {
    updateCareDataOnMountAndUpdate();
  }, [props?.deviceIdSelected]);

  useEffect(() => {
    props.updateDeviceData(devicedata);
    if (devicedata?.deviceId) setUpdatedDeviceId(true);
  }, [devicedata]);

  useEffect(() => {
    props.updateDeviceId(validatedDeviceId);
  }, [validatedDeviceId]);

  useEffect(() => {
    props.updateSimId(validatedSimId);
    if (validatedSimId !== '') {
      props?.setIncompatibleSim(false);
    }
  }, [validatedSimId]);
  useEffect(() => {
    if ((scmDeviceEnable && omnicaredropdownValue === 'Provisional ID')||(flexFlowServiceChange && isProvisionalIdChecked)) {
      const payload = {
        data: {
          flowType: 'PROVISIONAL_ID_INQUIRY',
          mtn: props.activeMtn,
        },
      };
      const soeguivalue = sessionStorage.getItem('encryptedActInfo') || '';
      getRetrieveProvisionalDeviceId(
        {
          body: payload,
          customHeaders: {
            soeguivalue,
            // 'x-nonprod-env':'sit3b' // needed for local testing
          },
        },
        { refetchOnMountOrArgChange: true },
      );
    } else if (scmDeviceEnable || (flexFlowServiceChange && !isProvisionalIdChecked)) {   
      setValidatedDeviceId(
        props.isByodUpdate || props.isFromCPE || props.isLocal
          ? getQueryParamByName('deviceId')
          : props.defaultDeviceId,
      );
    }
    /* istanbul ignore next */
    if (
      ((omnicaredropdownValue === 'Provisional ID')||(flexFlowServiceChange && isProvisionalIdChecked)) &&
      retrieveProvisionalDeviceIdResult?.data?.data?.data?.provisionalDeviceId
    ) {
      setValidatedDeviceId(retrieveProvisionalDeviceIdResult?.data?.data?.data?.provisionalDeviceId);
      handleOnBlurSimSku({
        target: { value: retrieveProvisionalDeviceIdResult?.data?.data?.data?.provisionalDeviceId },
      });
    }
    /* istanbul ignore if  */
    if (flexFlowServiceChange ) {
      setSimDisabled(isProvisionalIdChecked);
    }
  }, [omnicaredropdownValue,isProvisionalIdChecked]);
  useEffect(() => {
    if (retrieveProvisionalDeviceIdResult?.data?.data?.data?.provisionalDeviceId) {
      setValidatedDeviceId(retrieveProvisionalDeviceIdResult?.data?.data?.data?.provisionalDeviceId);
      handleOnBlurSimSku({
        target: { value: retrieveProvisionalDeviceIdResult?.data?.data?.data?.provisionalDeviceId },
      });
    }
  }, [retrieveProvisionalDeviceIdResult?.data?.data?.data?.provisionalDeviceId]);
  
  useEffect(() => {
    if (addDeviceIssueFFlag && flexFlowServiceChange && isEsimOnlyDevice) {
      props?.setIncompatibleSim(false);
    }
  }, [isEsimOnlyDevice]);

  const showSNAModal = () => {
    // second number activation
    let hasSecondNumExist = false;
    const billAccountDetails = props?.customerProfileDetails?.customer?.billAccounts;
    billAccountDetails?.[0]?.mtns?.forEach((item) => {
      if (item?.mtn === props?.activeMtn && item?.primaryNumber && item?.secondNumberInfo) {
        hasSecondNumExist = item?.secondNumberInfo?.some((line) => line?.type === 'Second Number');
      }
    });
    const hasSecondNumPlan = billAccountDetails?.[0]?.mtns?.some(
      (item) => item?.pricePlanInfo?.planId === '70995' && item?.pricePlanInfo?.planAttributes?.hasSecondNumPlan,
    );
    const hasSecondNumPerk = billAccountDetails?.[0]?.accountSubscriptions?.lineLevelSubscriptions
      ?.find((item) => item?.mtn === props?.activeMtn)
      ?.subscriptions?.some((item) => item?.spoId === '3403');
    return hasSecondNumPerk || (hasSecondNumExist && hasSecondNumPlan);
  };

   /* istanbul ignore next */
  function isActiveSim (paramForDeviceSimResoponse) {
    const eSimDeviceInfo = paramForDeviceSimResoponse?.data?.serviceBody?.serviceResponse?.context?.deviceInfo;
    const eSimSimInfo1 = eSimDeviceInfo?.simInfo;
    const eSimSimInfo2 = eSimDeviceInfo?.simInfo2;
    const eSIMOnly = eSimDeviceInfo?.eSIMOnly;
    const eID1 = eSimSimInfo1?.eID?.length > 0;
    const eID2 = eSimSimInfo2?.eID?.length > 0;
    const currentSimId = scmDeviceEnable ? getActiveMtnSimInfo() : getQueryParamByName('simId');
    const checkICCID1 = eSimSimInfo1?.iccid === currentSimId;
    const checkICCID2 = eSimSimInfo2?.iccid === currentSimId;
    const checkActiveMtn1 = props?.activeMtn === eSimSimInfo1?.mtn;
    const checkActiveMtn2 = props?.activeMtn === eSimSimInfo2?.mtn;
    const checkActive1 = eSimSimInfo1?.active || eSimSimInfo1?.available;
    const checkActive2 = eSimSimInfo2?.active || eSimSimInfo2?.available;
    const activeSim =
      ((eSIMOnly || eID1 || eID2) &&
        (checkICCID1 || checkICCID2) &&
        (checkActiveMtn1 || checkActiveMtn2) &&
        (checkActive1 || checkActive2)) ||
      false;
    return activeSim;
  }
   /* istanbul ignore next */
  function isValidateDeviceSimIdResultSuccess() {
    return ValidateDeviceSimIdResult?.isSuccess && ValidateDeviceSimIdResult?.status === 'fulfilled' && !ValidateDeviceSimIdResult?.isFetching;
  }
  /* istanbul ignore next */
  function showLostStolenPopup(){
    const lostStolenDeviceUIFeatureFlag =  /true/i.test(lostStolenDeviceUIFFlag);
     const deviceSimInfo = ValidateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo;
     const isLostandStolenDeviceIdMatch = /true/i.test(
      ValidateDeviceSimIdResult?.error?.data?.errorData?.isLostandStolenDeviceIdMatch
      );
      const authType = sessionStorage.getItem('authenticationType')?.toLocaleLowerCase() || '';
      const retailManagerException = channel?.includes('OMNI-RETAIL') && authType === 'manager-exception';
      const indirectAccPin = channel?.includes('OMNI-INDIRECT') && authType === 'account-pin';
      const isValidAuthType = authType !== '' && !retailManagerException && !indirectAccPin;
      if (lostStolenDeviceUIFeatureFlag && isValidAuthType) {
        if (isLostandStolenDeviceIdMatch && isByodUpdate) {
          const deviceId = deviceSimInfo?.deviceId || validatedDeviceId || deviceInput || '';
          setLostStolenDeviceId(deviceId);
          dispatch(appMessageActions.clearAppMessages());
          setShowLostStolenConfirmation(true);
          const vzdl = window?.vzdl || {};
          if(vzdl?.user){
            vzdl.user = {...vzdl.user, imeiHashed: aesCipher(deviceId)};
          }
          window.vzdl = vzdl;
          makeOpenViewCall('deleteLostStolenDevice');
         }
      }
  }

  useEffect(() => {/* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */
    /* istanbul ignore else */ 
    if (ValidateDeviceSimIdResultStatus === 'fulfilled') {
      if (!carrierLock) {
        if (samsungPOSFFlagEnabled && props?.setCarrierLockDisableButton) {
          props.setCarrierLockDisableButton(false);
        }
        if (secondNumActivationModalFFlag === 'TRUE' && showSNAModal()) {
          setShowSecondNumberActivationModal(true);
        }
        isSingleLookUpModel();
        setSimIdResult(ValidateDeviceSimIdResult);
        const isDeviceIdChangeFlow = validateDeviceSimRequest?.data?.lines?.[0]?.device?.Flowtype === 'DEVICE';
        if (
          isDeviceIdChangeFlow &&
          props?.upcCodeFromPdpScan &&
          props?.isBBYLocalOrder &&
          /true/i.test(bestBuyIntegrationFFlag)
        ) {
          handleUpcAndDeviceIdValidateCheck(props?.upcCodeFromPdpScan);
        }
        if (isOmniCare) {
          const deviceInfoResult = ValidateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo;
          const skuValue = deviceInfo?.simInfo?.dfillCompatibleSim;
          const simSkuEnteredUpdate = simSkuOverride ? simSkuEntered : skuValue;
          Emitter.emit('Update_DeviceSimId_Info', { simSkuEntered: simSkuEnteredUpdate });
          setSimSkuEntered(simSkuEnteredUpdate);
          // show esim warning message as a bannerer for esim
          const simInfo = deviceInfoResult?.simInfo;
          const simInfo2 = deviceInfoResult?.simInfo2;
          /* istanbul ignore next */
          if (!scmDeviceEnable && (simInfo?.eID || simInfo2?.eID) && !sessionStorage.getItem('fromLostStolenFlow')) {
            displayBanner();
          }
        }
      }
      if (carrierLock) {
        dispatch(appMessageActions.addAppMessage('Carrier Lock is on, please unlock to continue.', 'error'));
        dispatch(appLoaderActions.hide());
        // eslint-disable-next-line no-unused-expressions
        props?.setCarrierLockDisableButton && props.setCarrierLockDisableButton(true);
      }

       if (flexFlowServiceChange) {
        setValidSimSku(
          ValidateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo?.simInfo
            ?.launchPackageSku || '',
        );
      }

      // Send data to deviceInfo when validateDeviceSimId call on mounting.
      /** istanbul ignore else */
      if (isFunctionalityEnabled(FFLAGS?.scmMiscFixFFlag?.name, FFLAGS?.scmMiscFixFFlag?.attribute?.generateESimProfile, fFlagData.attribute.eSimDbFlag)) {
         /* istanbul ignore if  */
        if (devicePayload?.mountApi) {
          const mountDeviceInfo = ValidateDeviceSimIdResult.data?.serviceBody?.serviceResponse?.context?.deviceInfo;
           /* istanbul ignore if  */
          if (isActiveSim(ValidateDeviceSimIdResult) && getSimType(mountDeviceInfo) === 'eSIM') {
            props?.setShowGetESimInOption?.(true);
          }
        } else {
          props?.setShowGetESimInOption?.(false);
        }
      }
    } else if (ValidateDeviceSimIdResultStatus === 'rejected') {
      const isLostandStolenDeviceIdMatch = /true/i.test(
        ValidateDeviceSimIdResult?.error?.data?.errorData?.isLostandStolenDeviceIdMatch,
      );
      const lostStolenUIEnabled = /true/i.test(lostStolenDeviceUIFFlag);
      if (lostStolenUIEnabled && !isLostandStolenDeviceIdMatch) {
        setErrorTagging({ payload: ValidateDeviceSimIdResult?.error });
      }
      showLostStolenPopup();

      const errorMsg = ValidateDeviceSimIdResult?.error?.data?.errors?.[0]?.message;
      const errorCode = ValidateDeviceSimIdResult?.error?.data?.errors?.[0]?.code;
      if (lostStolenUIEnabled && !isLostandStolenDeviceIdMatch && errorMsg) {
        dispatch(appMessageActions.addAppMessage(errorMsg, 'error', true, true));
      }
      /* istanbul ignore next */
      if (checkSimActiveFFlag && errorCode === 'SIM_ALREADY_ACTIVE') {
        setValidatedSimId('');
        props?.setDisableUpdateButton(true);
        props?.setEnableBYODbtn(false);
      }
      /* istanbul ignore next */
      if (errorMsg === 'Sim is not compatible with the selected Device') {
        setValidatedSimId('');
        props?.setEnableBYODbtn(false);
        if (props?.isByodUpdate === 'true') {
          props?.setIncompatibleSim(true);
        }
      }
    }
    const isAALByod = getLineActivityType(props?.cartDetails?.cart, props?.activeMtn);
    /* istanbul ignore next */
    if (
      validateDeviceSimRequest?.data?.lines?.[0]?.device?.Flowtype === 'DEVICE' &&
      deviceInfo?.makeEtniPersApi === false &&
      ((repSelectedSimType === 'physicalSim' &&
        (deviceInfo?.simInfo2?.makeEtniPersApi === false || deviceInfo?.simInfo?.makeEtniPersApi === false)) ||
        (!deviceInfo?.simInfo?.makeEtniPersApi && !deviceInfo?.simInfo2)) &&
      props?.isByodUpdate === 'true' &&
      isAALByod === 'BYOD'
    ) {
      setValidatedSimId('');
    }
    if (window?.mfe?.scmDeviceMfeEnable && ValidateDeviceSimIdResult?.isError) {
      props?.setEnableBYODbtn(false);
    }
    if (isValidateDeviceSimIdResultSuccess() && flexFlowServiceChange && eSimRegenerateStatus?.initiate) {
      setESimRegenerateStatus({
        ...eSimRegenerateStatus,
        initiate: false,
        enable: isActiveSim(ValidateDeviceSimIdResult),
      });
    }
    return () => {
      removeBanner();
    };
  }, [ValidateDeviceSimIdResult?.data, ValidateDeviceSimIdResultStatus]);

  useEffect(() => {
    /* istanbul ignore next */
    if (eSimDataResults?.data?.data && eSimDataResults?.status === 'fulfilled') {
      const iccid = eSimDataResults.data.data.iccid || '';
      if (eSimDataResults?.data?.data?.mdn === props?.pairedMtn) {
        props?.setSecondNumSimId(iccid);
      } else {
        setValidatedSimId(iccid);
      }
      setdevicedata((prevData) => ({ ...prevData, eSimOnlyDevice: true }));

      /* istanbul ignore next */
      if (flexFlowServiceChange && iccid && eSimDataResults?.data?.data?.profile) {
         // Emit PAGE_LOADED event to trigger ReadAssistedDL API call 
            Emitter.emit('PAGE_LOADED', {
              PAGE_LOADED: 'true',
              CUSTOM_EVENT: 'pageView', 
              NEED_CALLBACK: true
            });
    
        setSimSkuInput(iccid);
        callValidateDeviceSku(false, { simId: iccid, deviceId: validatedDeviceId }, null, true);
        
        setESimRegenerateStatus({ ...eSimRegenerateStatus, enable: false });
      }

      // Initiate validate device sim api call
      const fFlagData = FFLAGS.scmMiscFixFFlag;
      if (isFunctionalityEnabled(fFlagData.name, fFlagData.attribute.generateESimProfile, fFlagData.attribute.eSimDbFlag)) {
        if (props?.callESimApi && iccid && eSimDataResults?.data?.data?.profile) {
          setSimSkuInput(iccid);
          handleOnBlurSimSku({ target: { value: iccid } });
        } else {
          props?.setCallESimApi(false);
        }
      }
    }
  }, [eSimDataResults, eSimDataResults?.status]);

  useEffect(() => {
    if (deviceFromCart || (isEditAndView && (isRetail() || isIndirect))) {
      setDeviceAndSimIdHandler();
    } else if (isEditAndView && skipIccidCall) {
      // edit and view with skipiccid enabled
      const cartSimSku = getCartSimSku(simFromFilteredCartLine);
      setValidatedSimId(cartSimSku);
    }
  }, [deviceFromFilteredCartLine]);

  useEffect(() => {
    /* istanbul ignore if  */
    if (props?.ispuSim && getIspuSimEnable()) {
      const previousSim = validatedSimId;
      props?.setPreviousIspuSim(previousSim);
      setValidatedSimId(props?.ispuSim);
    }
  }, [props?.ispuToggleOn]);

  useEffect(() => {
    /* istanbul ignore next */
    if (scmDeviceEnable && ((props?.callESimApi&& isEsimActivationEnabled) || (simSkuInput && simSkuInput !== props?.defaultSimId)) && isFraudRiskEnabled) {
      if(props?.callESimApi && props?.activeMtn === fraudRiskScoreResult?.data?.data?.mdn){
        openAAforEsim();
      }else{
      const soeguivalue = sessionStorage.getItem('encryptedActInfo') || '';
      const mfeIccid = simSkuInput;
      const mfeImei = validatedDeviceId;
      const payload = getDeviceEnforApiPayload({
        mfeIccid,
        mfeImei,
        customerInfo,
        equipmentInfo,
        locationCd,
        simSwapNotify,
      });
      getfraudRiskScore(
        {
          body: payload,
          customHeaders: {
            soeguivalue,
            // 'x-nonprod-env':'sit2b' // needed for local testing
          },
        },
        { refetchOnMountOrArgChange: true },
      );
    }
    }
  }, [simSkuInput, props?.callESimApi]);

  useEffect(() => {
    if (fraudRiskScoreResult?.data) {
      if (fraudRiskScoreResult?.data?.data?.fraudRiskLevel?.toLowerCase() === 'high risk') {
        dispatch(
          appMessageActions.addAppMessage(
            simSwapNotificationHighRiskMsg || 'Something went wrong, kindly try again.',
            'error',
            true,
            false,
          ),
        );
      } else if (
        fraudRiskScoreResult?.status === 'fulfilled' &&
        fraudRiskScoreResult?.data?.responseInfo?.errors?.length
      ) {
        dispatch(appMessageActions.addAppMessage('Something went wrong, kindly try again.', 'error', true, false));
      } else {
        dispatch(appMessageActions.clearAppMessages());
        /* istanbul ignore next */
        if (props?.callESimApi) {
          openAAforEsim();
        } else {
          handleOnBlurSimSku(
            {
              target: {
                value: simSkuEntered,
              },
            },
            true,
          );
        }

    }
    }
  }, [fraudRiskScoreResult?.data]);
/* istanbul ignore next */
  const openAAforEsim = () => {
    if (isFraudRiskSafe() && fraudRiskScoreResult?.data?.data?.notificationIndicator === 'Y') {
      Emitter.emit('SIM_SKU_VALIDATION', {
        eSimGenerate: true
      });
    } else {
      props?.setEnableBYODbtn(true);
    }
  }

   // Add useEffect to monitor API success and simId changes for SimSale visibility
  useEffect(() => {
    /* istanbul ignore next */
    if (ValidateDeviceSimIdResult?.status === 'fulfilled' && flexFlowServiceChange && simType === 'pSIM') {
      // Check if simId has actually changed from the previous value
      const iccId = ValidateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo?.simInfo?.iccid;
      if ((simIdChanged && changedSimId === iccId) || (simInputChangedIpad && simValueIpad === iccId)) {
        setShouldShowSimSale(true);
      } else {
        setShouldShowSimSale(false);
      }
    } else {
      setShouldShowSimSale(false);
    }
  }, [
    ValidateDeviceSimIdResult,
    simType,
    simIdChanged,
    changedSimId,
    simInputChangedIpad, 
    simValueIpad,
  ]);

   // Reset eSIM regenerate message when switching between lines or changing provisional ID checkbox
  useEffect(() => {
    if (esimAPIskipFFlag && flexFlowServiceChange && activeMtn) {
      setShowESimRegenerateMessage(false);
      setESimRegenerateStatus((prevStatus) => ({
        ...prevStatus,
        enable: true,
      }));
    }
  }, [activeMtn, isProvisionalIdChecked]);
  
  const updateCareDataOnMountAndUpdate = (mount = false) => {
    // ominn-care sim sku data update
    if (!props.isFromCPE && isOmniCare && !props.deviceSkuSelected) {
      let simSkuFromCart = '';
      let cartItemFound = false;
      props?.cartDetails?.cart?.lineDetails?.lineInfo?.forEach((line) => {
        if (line.mobileNumber === props?.activeMtn) {
          cartItemFound = true;
          const cartItem = line?.itemsInfo?.[0]?.cartItems?.cartItem;
          cartItem?.forEach((item) => {
            if (item?.cartItemType === 'SIM') {
              simSkuFromCart = scmDeviceEnable && item?.simId ? item?.simId : item.sorId;
            }
          });
        }
      });
      if (cartItemFound) {
        setSimSkuEntered(simSkuFromCart);
        if (skipICCIDFFlag && hideSIMArea) {
          setValidatedSimId('');
        } else {
          setValidatedSimId(simSkuFromCart);
        }
      } else if (
        !props.pendingOrderOnLine &&
        isEditAndView &&
        mount &&
        (!scmUpgradeMfeEnable || (scmUpgradeMfeEnable && props.isByodUpdate === 'true'))
      ) {
        setRepSelectedSimType('omni-care');
        callValidateDeviceSku(true);
      }
    }
  };
  /* istanbul ignore next */
  const handleEsimModalShow = () => {
    setESimRegenerateStatus({ ...eSimRegenerateStatus, showConfirmModal: true });
    const vzdl = window?.vzdl || {};
      if (vzdl?.page) {
         vzdl.page.detail = 'eSIM Generated';
         vzdl.page.name = 'product-detail';
         vzdl.page.flow = 'ESO';
         window.vzdl = vzdl;
         sendCustomEvent('openView', window?.vzdl);
      }
  };
   /* istanbul ignore next */
  const handleEsimGenerationCall = () => {
    if (esimAPIskipFFlag) {
      setESimRegenerateStatus({ ...eSimRegenerateStatus, showConfirmModal: false, enable: false });
      setShowESimRegenerateMessage(true);
      if (props?.setEnableBYODbtn) {
        props?.setEnableBYODbtn(true);
      }
      if (props?.setIsESimRegenerated) {
        props?.setIsESimRegenerated(true);
      }
    } else {
      initSimDetailsCall();
      setESimRegenerateStatus({ ...eSimRegenerateStatus, showConfirmModal: false });
    }
  };

  const isAALNumber = () => {
    const lineNumber =
      props.cartDetails?.cart?.lineDetails?.lineInfo?.length > 0 &&
      props.cartDetails?.cart?.lineDetails?.lineInfo?.find((line) => line?.mobileNumber === props.activeMtn)
        ?.lineNumber;
    return lineNumber && lineNumber?.includes('newLine');
  };

  const isDeviceValidationEnabled = () => {
    return scmDeviceEnable || flexFlowServiceChange || isProvisionalIdChecked;
  };

  const isSimValidationEnabled = (inputValue, isSimSkuValid, isCompatibleSim) => {
    return (
      (scmDeviceEnable && (isNumeric(inputValue) || isSimSkuValid || omnicaredropdownValue === 'Provisional ID')) ||
      flexFlowServiceChange || isProvisionalIdChecked ||
      isCompatibleSim
    );
  };

  const shouldBypassFraudRisk = () => {
    return !isFraudRiskEnabled || flexFlowServiceChange || isProvisionalIdChecked;
  };
  const isFraudRiskSafe = () =>
    isFraudRiskEnabled &&
    ((fraudRiskScoreResult?.status === 'fulfilled' &&
      fraudRiskScoreResult?.data?.data?.fraudRiskLevel &&
      fraudRiskScoreResult?.data?.data?.fraudRiskLevel?.toLowerCase() !== 'high risk') ||
      fraudRiskScoreResult?.status === 'rejected');

  const getSimSku = (simSku, eSimRegen) => (scmDeviceEnable && omnicaredropdownValue === 'Provisional ID') || flexFlowServiceChange || eSimRegen
      ? ''
      : simSku;
  
  /* istanbul ignore next */
  const getsimId = (isSimNotChange, formattedSimId, simOnlyChange) => {
    if (simOnlyChange) return '';

    return (scmDeviceEnable && isSimNotChange) || (flexFlowServiceChange && isProvisionalIdChecked)
      ? ''
      : formattedSimId;
  };
  /* istanbul ignore next */
  const getCurrentSimIdVal = (isSimNotChange, currentSimId, isProvisionalId) => {
    const shouldClearSimId = !fixSCMDeviceChangeIccid || isProvisionalId;
    if (flexFlowServiceChange && isProvisionalIdChecked) {
      return '';
    }
    if (scmDeviceEnable && shouldClearSimId) {
        return isSimNotChange ? '' : currentSimId;
    }
    return currentSimId;
  };

  const eSimOstLinkAnchor = `<a target="_blank" href=${props.eSimOstLinkUrl} >here</a>`;
  const esimBannerHtml = `${props.esimEligibilityText}<div class='eSimOSTlink'>${props.eSimOstLinkText}${eSimOstLinkAnchor}&nbsp&nbsp&nbsp</div>`;

  const displayBanner = () => {
    dispatch(appMessageActions.addAppMessage(esimBannerHtml, 'warning', true, true));
  };

  const removeBanner = () => {
    dispatch(appMessageActions.removeAppMessage({ summary: esimBannerHtml }));
  };
  function getValidatedDeviceId(eSimRegen) {
    return (scmDeviceEnable && omnicaredropdownValue === 'SIM only change') || (scmDeviceEnable && validatedDeviceId && validatedDeviceId !== getQueryParamByName('deviceId')) || eSimRegen;
  }
  function getScmValidatedSimId(provisionalIdInfo, eSimRegen, simIdVal) {
    return ((scmDeviceEnable && !provisionalIdInfo?.isProvisionalId) || eSimRegen) && simIdVal ? simIdVal : "";
  }

  function assignDeviceIdAndSmartIMEIForSimSale(deviceIdVal, smartIMEIVal, simIdVal) {
    let smartIMEIValue = smartIMEIVal;
    let deviceIdValue = deviceIdVal;
    if (flexFlowServiceChange) {
      smartIMEIValue = false;
      if (!deviceIdValue) {
        deviceIdValue = simIdVal?.deviceId;
      }
    }
    return { deviceIdValue, smartIMEIValue };
  }

  const callValidateDeviceSku = (careSimOnlyValidation, simIdVal, provisionalIdInfo, eSimRegen) => {
    const isProvisionalId = omnicaredropdownValue === 'Provisional ID' || provisionalIdInfo?.isProvisionalId;
    const careSimOnlyValid = careSimOnlyValidation || false;
    const fromCpeDeviceSku = props.isByodUpdate || props.isFromCPE;
    let deviceId = careSimOnlyValid || getValidatedDeviceId(eSimRegen) ? validatedDeviceId : '';
    let smartIMEI = !careSimOnlyValid && !eSimRegen;
    let simSku = simIdVal?.simId || simSkuEntered;

    if (
      (scmDeviceEnable || (flexFlowServiceChange && isProvisionalIdChecked)) &&
      isProvisionalId &&
      (retrieveProvisionalDeviceIdResult?.data?.data?.data?.provisionalDeviceId ||
        provisionalIdInfo?.provisionalDeviceId)
    ) {
      smartIMEI = false;
      deviceId =
        retrieveProvisionalDeviceIdResult?.data?.data?.data?.provisionalDeviceId ||
        provisionalIdInfo?.provisionalDeviceId;
    }
    let scmSimId = getScmValidatedSimId(provisionalIdInfo, eSimRegen, simIdVal);
    if (scmDeviceEnable && !scmSimId) {
      scmSimId = validatedSimId;
    }
    if (!scmDeviceEnable && flexFlowServiceChange) {
      scmSimId = simIdVal?.simId;
    }
    let deviceFlow = false;
    const isDeviceIdChanged = simIdVal?.deviceId && simIdVal?.deviceId !== activeMtnEqpInfo?.deviceInfo?.deviceId;
    if (scmDeviceEnable) {
      simSku = simInfo?.simSku;
    }
    if (scmDeviceEnable && ((isDeviceIdChanged && !isProvisionalId) || isAALNumber())) {
      deviceFlow = true;
      deviceId = simIdVal?.deviceId;
      smartIMEI = false;
    }
    // if (scmDeviceEnable && simIdVal?.deviceId && !provisionalIdInfo?.isProvisionalId) {
    //   deviceId = simIdVal?.deviceId;
    // }
    // adding mountApi in payload to check if the api is called on load of pdp page and if api is called on load of page we should not show esim popup
    if (flexFlowServiceChange && eSimRegen) {
      setESimRegenerateStatus({ ...eSimRegenerateStatus, deviceId, simId: scmSimId });
    }
    const getDeviceIdAndSmartIMEIForSimSale = assignDeviceIdAndSmartIMEIForSimSale(deviceId, smartIMEI, simIdVal);
    deviceId = getDeviceIdAndSmartIMEIForSimSale?.deviceIdValue;
    smartIMEI = getDeviceIdAndSmartIMEIForSimSale?.smartIMEIValue;
    validateDeviceSimIdRequest(
      {
        mtn: props.activeMtn,
        deviceId,
        simId: scmSimId,
        cpSimCard: false,
        fromCpe: fromCpeDeviceSku,
        isCustomerProvidedEquipment: fromCpeDeviceSku,
        sku: '',
        simSku,
        smartIMEI,
        mountApi: careSimOnlyValid,
        deviceFlow,
      },
      isProvisionalId,
      eSimRegen,
    );
  };

  const handleChangeSimSku = (e) => {
    const input = e.target.value;
    setSimSkuEntered(input);
    if (!simSkuOverride) setSimSkuOverride(true);
  };

  const handleOnFocusSimSku = (e) => {
    setSimSkuOnFocus(e.target?.value?.trim());
  };
  /* istanbul ignore next  */
  const resetInput = () => {
    setValidatedDeviceId(props.lineDeviceIdFromLanding);
  };

  const handleOnBlurSimSku = (e, ignoreInputChange) => {/* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */
    const inputValue = e?.target?.value?.trim();
    const isNotfnIndicatorDisabled = fraudRiskScoreResult?.data?.data?.fraudRiskLevel &&
    fraudRiskScoreResult?.data?.data?.fraudRiskLevel?.toLowerCase() !== 'high risk' && fraudRiskScoreResult?.data?.data?.notificationIndicator &&
          fraudRiskScoreResult?.data?.data?.notificationIndicator === 'N';
    if (!ignoreInputChange && inputValue) {
      fraudRiskScoreResult.status = '';
      setSimSkuInput(inputValue);
    }
    /*istanbul ignore next */
    const provisionalIdInfo = {
      isProvisionalId: omnicaredropdownValue === 'Provisional ID' ||(flexFlowServiceChange && isProvisionalIdChecked),
      provisionalDeviceId: retrieveProvisionalDeviceIdResult?.data?.data?.data?.provisionalDeviceId,
    };
    const inputChanged = inputValue !== '' && inputValue !== simSkuOnFocus;
    if (inputChanged) {
      const isCompatibleSim = props.compatibleSims?.some((compatibleSim) => compatibleSim === inputValue);
      const isSimSkuValid = !isNumeric(inputValue) && alphaNumericRegEx.test(inputValue) && isCompatibleSim;
      /* istanbul ignore next */
      if (isSimValidationEnabled(inputValue, isSimSkuValid, isCompatibleSim)) {
        setSimSkuEntered(inputValue);
        if (isDeviceValidationEnabled()) {
          if(isNtfnIndFlagEnabled && isNotfnIndicatorDisabled === true){
            callValidateDeviceSku();
          } else if (isFraudRiskSafe()) {
            props?.setEnableBYODbtn(false);
            Emitter.emit('SIM_SKU_VALIDATION', {
              newVal: { simId: inputValue, deviceId: validatedDeviceId },
              oldVal: props?.defaultSimId,
              provisionalIdInfo,
            });
          } else if (shouldBypassFraudRisk()) {
            callValidateDeviceSku(false, { simId: inputValue, deviceId: validatedDeviceId }, provisionalIdInfo);
          }
        } else {
          callValidateDeviceSku();
        }
      } else {
        if (scmDeviceEnable) {
          props?.setEnableBYODbtn(false);
        }
        dispatch(
          appMessageActions.addAppMessage(
            scmDeviceEnable ? 'Device and SIM are not compatible' : `Sim is not compatible with the selected Device.`,
            'error',
            true,
            false,
          ),
        );

        // this.props.inValidSimSku({ invalidSim: true });
      }
    }
  };

  useEffect(() => {
    const { isByodUpdate } = props;
    if (
      isByodUpdate &&
      (isRetail() || isIndirect || flexFlowServiceChange) &&
      repSelectedSimType === 'physicalSim' &&
      validateDeviceSimRequest?.data?.lines?.[0]?.device?.sim?.CurrentSimid === '' &&
      (!deviceInfo.makeEtniPersApi || deviceInfo?.simClass4G === 'NP')
    ) {
      const payloadData = {
        mtn: props.activeMtn,
        deviceId: validateDeviceSimRequest?.data?.lines?.[0]?.device?.id,
        simId: validateDeviceSimRequest?.data?.lines?.[0]?.device?.sim?.id,
        cpSimCard: false,
        fromCpe: true,
        isCustomerProvidedEquipment: true,
        deviceFlow: true,
        isDWOS: false,
        sendSimFromLanding: true,
      };
      validateDeviceSimIdRequest(payloadData);
    }
    if (scmDeviceEnable) {
      const deviceInfoResult = ValidateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo;
      const simInfo = deviceInfoResult?.simInfo;
      const simInfo2 = deviceInfoResult?.simInfo2;
      /* istanbul ignore next */
      if (isEsimActivationEnabled && repSelectedSimType === 'eSim' && props?.setIsESimRegenerated) {
        props.setIsESimRegenerated(true);
      }
      if (simInfo?.eID || simInfo2?.eID) {
        /* istanbul ignore else */
        if (repSelectedSimType === 'physicalSim') {
          displayBanner();
        } else {
          removeBanner();
        }
      }
    }
  }, [repSelectedSimType]);

  useEffect(() => {
    const { isByodUpdate, cartDetails } = props;
    const paramActiveMtn = getQueryParamByName('activeMtn');
    const cartLineInfo = cartDetails?.cart?.lineDetails?.lineInfo;
    const cartLineDetails = cartLineInfo?.filter(
      (x) => x?.mobileNumber === paramActiveMtn && x?.lineActivityType?.includes?.('BYOD'),
    );
    const stopValidateDeviceSimID = flexFlowServiceChange && cartLineDetails?.length > 0;

    const shouldAttemptValidation =
      isByodUpdate && flexFlowServiceChange && SkuDetailsResult?.isSuccess && !SkuDetailsResult?.isFetching;

    const isSimValidationFinished = !ValidateDeviceSimIdResult?.isFetching;

    /* istanbul ignore next */
    const requiresRevalidation =
      !ValidateDeviceSimIdResult?.isSuccess || sessionStorage.getItem('flexServiceFlowLineChange')  || /true/i.test(sessionStorage.getItem("provisonalUncheckedBox"));

    if (shouldAttemptValidation && isSimValidationFinished && requiresRevalidation && !stopValidateDeviceSimID) {
      sessionStorage.removeItem('flexServiceFlowLineChange');
      sessionStorage.removeItem('provisonalUncheckedBox');
      const inputValue = getQueryParamByName('simId');
      callValidateDeviceSku(false, { simId: inputValue, deviceId: validatedDeviceId }, null, true);
    }
  }, [SkuDetailsResult]);

  /**
   * device from cart scenario handling to poppulate device and sim id on load
   */
  const setDeviceAndSimIdHandler = () => {
    let iseDeviceId = false;
    if (deviceFromFilteredCartLine) {
      let cartDeviceId = deviceFromFilteredCartLine?.deviceId;
      if (deviceFromFilteredCartLine?.eDeviceId) {
        cartDeviceId = deviceFromFilteredCartLine?.eDeviceId;
        iseDeviceId = true;
      }
      if (!secondLine) {
        setValidatedDeviceId(cartDeviceId);
      }
    }
    if (simFromFilteredCartLine) {
      let cartSimId = simFromFilteredCartLine?.simId;
      if (iseDeviceId && skipIccidCall) {
        cartSimId = '';
      } else if (iseDeviceId) {
        cartSimId = simFromFilteredCartLine?.eSIM;
      }
      setValidatedSimId(cartSimId);
    }
  };

  if (channel?.includes('OMNI-INDIRECT') && !(customerType === 'N') && !isIpad()) {
    isByodUpdateOnDekstop = !deviceIdChanged;
  }

  /* Details for Iconic Sku Start */
  const isIconicServiceSku = !!(props.sku && props.sku === 'ICONIC-SERVICE-SKU');

  const lineInfo = CustomerData?.billAccounts?.[0]?.mtns?.filter((line) => line.mtn === props.activeMtn);
  const isNewlyAddedLine = !!(
    lineInfo &&
    lineInfo.length > 0 &&
    lineInfo[0] &&
    lineInfo[0].isNewLine &&
    lineInfo[0].isNewLine === true
  );
  const activeMtnEqpInfo =
    lineInfo && lineInfo.length > 0 && lineInfo[0] && lineInfo[0].equipmentInfos && lineInfo[0].equipmentInfos[0]
      ? lineInfo[0].equipmentInfos[0]
      : {};

  const { simInfo = {} } = activeMtnEqpInfo;
  const simInfoFromLanding = simInfo && simInfo.simId ? simInfo.simId : '';
  const careDeviceIdSelected =
    (channel === 'OMNI-CARE' || scmDeviceEnable) && (props.deviceIdSelected || props.isFromCPE);
  const careOrTelePactRep =
    isCustomerProvidedEquipment &&
    (channel === 'OMNI-CARE' || scmDeviceEnable || channel === 'OMNI-TELESALES') &&
    props.cartDetails?.cart?.cartHeader?.isCoreRep
      ? props.cartDetails?.cart?.cartHeader?.isCoreRep
      : false;
  let displaySimForIconicSku = true;
  if (isIconicServiceSku === true && isNewlyAddedLine === false) {
    if (simInfoFromLanding === '') {
      displaySimForIconicSku = false;
    }
  }

  /* Details for Iconic Sku End */
  const scanFromLanding = Boolean(getQueryParamByName('scanFromLanding'));
  let upgradeIneligibleFlag = false;
  if (lineInfo && lineInfo.length > 0 && lineInfo[0] && !lineInfo[0]?.isNewLine) {
    upgradeIneligibleFlag = lineInfo[0]?.lineLevelChangeEligibility?.pendingOrderDetail !== null;
  }
  const is5GDevice = !!(
    lineInfo &&
    lineInfo.length > 0 &&
    lineInfo[0].isNewLine &&
    lineInfo[0].deviceTypeSelected === '5G Internet'
  );

  const onCheckBoxChange = () => {
    setCpeCheckbox(!cpeCheckbox);
    props.updateCpeCheckboxFlag(!cpeCheckbox);
  };

  const expandSimID = () => {
    if (isVideoAssistFlow === false || (isVideoAssistFlow === true && isRetail() && isIpad())) {
      return true;
    }
    return false;
  };

  const showSimInfo = () => {
    if (
      (updatedDeviceId || props.isLocal != null || !simProcessOnlyIpad) &&
      ((isByodUpdateOnDekstop &&
        (customerType === 'N' ||
          (props.isPrePay && customerType !== 'N') ||
          (props.isIndirect && props?.cartDetails?.cart?.orderDetails?.customerType === 'E'))) ||
        !isByodUpdateOnDekstop ||
        isBYODUpdateAALRetail) &&
      !careDeviceIdSelected &&
      !isEsimOnlyDevice &&
      !disableDeviceDetailsForAsurion &&
      expandSimID()
    ) {
      return true;
    }
    return false;
  };

  const eSimPopUpData = {
    deviceInfo,
    channel: CustomerData?.channel,
    isFrom: getQueryParamByName('deviceFromCart'),

    formattedDeviceId: devicePayload?.formattedDeviceId,
    apiRequest: devicePayload, // need to check
    requestFlowType: devicePayload?.data?.lines[0]?.device?.Flowtype,

    sagaPayload: devicePayload,
    isByodUpdate: props.isByodUpdate,
    scanFromLanding: false,
    sendSimFromLanding: false,
    notRetailAndInDirect: !!(CustomerData?.channel?.indexOf('OMNI-RETAIL') === -1 && !isIndirect),
    contextUrl: getUIContextPath(),
  };

  /*istanbul ignore next*/
  const updateBYODCTA = () => {
    if (flexFlowServiceChange) {
      props?.setDisableUpdateButton(false);
    }
  }

  /*istanbul ignore next*/
  const isSingleLookUpModel = () => { /* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */
    const { sendSimFromLanding = false } = devicePayload || {};
    const eSimOnlyEtniApi = deviceInfo?.simInfo?.makeEtniPersApi && deviceInfo?.simInfo2?.makeEtniPersApi;
    const notification =
      deviceInfo?.simInfo2 && (deviceInfo?.simInfo.makeEtniPersApi || deviceInfo?.simInfo2.makeEtniPersApi);
    const conectedDeviceNotification = deviceInfo && deviceInfo?.makeEtniPersApi && sendSimFromLanding === false;
    const dfillCompatibleSimsEmpty =
      !deviceInfo?.simInfo.dfillCompatibleSim && !deviceInfo?.simInfo2?.dfillCompatibleSim;
    const requestFlowType = validateDeviceSimRequest?.data?.lines?.[0]?.device?.Flowtype;
    const formattedDeviceId = devicePayload?.deviceId;
    const intentType = validateDeviceSimRequest?.cartInfo?.intent;
    const mtnNotGenerated = props.activeMtn?.includes('newLine');
    let simId;
    const compatibilityCheckParams = {
      isIndirect,
      intendType: getLineActivityType(props?.cartDetails?.cart, props?.activeMtn),
      isByodUpdate: props.isByodUpdate === 'true',
      deviceInfo,
      payload: devicePayload,
      previousPayload: validateDeviceSimRequest,
      validateDeviceSimIdRequest,
    };
    if (deviceInfo?.simInfo2?.iccid) simId = deviceInfo?.simInfo2?.iccid;
    else if (channel?.indexOf('OMNI-RETAIL') === -1 && !isIndirect) simId = deviceInfo?.simInfo2?.preferredSoftSim;
    else simId = '';
    if (mtnNotGenerated && !isCustomerProvidedEquipment) {
      dispatch(
        appMessageActions.addAppMessage(
          `Please generate MDN for the line ${props.activeMtn} to proceed`,
          'error',
          true,
          true,
          false,
          false,
          true,
          'Assign Number',
          () => {
            assignNumberRedirect();
          },
        ),
      );
    }
    /* istanbul ignore else */
    if (ValidateDeviceSimIdResult?.data) {
      const deviceIdStatus =
        ValidateDeviceSimIdResult.data?.serviceBody?.serviceResponse?.context?.deviceInfo?.deviceId !==
        ValidateDeviceSimIdResult?.originalArgs?.body?.data?.lines?.[0]?.device?.CurrentId;
      const isDeviceSimCompatible = ValidateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo?.deviceSimCompatible === 'Y';
      if (devicePayload?.fromCpe) {
        if (notification) {
          if (eSimOnlyEtniApi && dfillCompatibleSimsEmpty) {
            if (!devicePayload?.mountApi) {
              setIsSingleSimEntiLookupModalVisibleByod(true);
            }
            if (isOmniCare && !scmDeviceEnable && deviceIdStatus) {
              const msg =
                'We can not proceed further with eSim in this flow, please select physical sim or Please access the following path in ACSS to complete an add a line order when the customer is using an existing device and SIM/eSIM: Devices tab> Links/Action> Add line/CPE(NSO)';
              dispatch(appMessageActions.addAppMessage(msg));
            }
            const vzdl = window?.vzdl || {};
            if (vzdl?.event) vzdl.event.value = 'event24';
            window.vzdl = vzdl;
            sendCustomEvent('openView', window?.vzdl);
          } else {
            if (!repSelectedSimType && !(fixSCMDeviceChangeIccid && scmDeviceEnable && !isDeviceSimCompatible && !isDeviceIMEIChange)) {
              setIsDualSimEntiLookupModalVisible(true);
            }
            const vzdl = window?.vzdl || {};
            if (vzdl?.event) vzdl.event.value = 'event24';
            if (vzdl?.page) vzdl.page.detail = `CombinedGridwall-Esim-Psim-popup`;
            window.vzdl = vzdl;
            sendCustomEvent('openView', window?.vzdl);
          }
        } else if (conectedDeviceNotification) {
          if (!devicePayload?.mountApi) {
            setIsSingleSimEntiLookupModalVisibleByod(true);
          }
          const vzdl = window?.vzdl || {};
          if (vzdl?.event) vzdl.event.value = 'event24';
          window.vzdl = vzdl;
          sendCustomEvent('openView', window?.vzdl);
        } else {
          const simIdFromResponse = deviceInfo?.simInfo?.iccid && !sendSimFromLanding ? deviceInfo?.simInfo?.iccid : '';
          if (simIdFromResponse && !scmDeviceEnable) {
            const flexFlowService = flexFlowServiceChange && isProvisionalIdChecked;
            if( !flexFlowService) {
              setValidatedSimId(simIdFromResponse);
            }
          }
          if (!!getQueryParamByName('eSim') && deviceInfo?.makeEtniPersApi === false) {
            const simSlot =
              isRetail() || isIndirect ? deviceInfo?.simInfo?.iccid : deviceInfo?.simInfo?.preferredSoftSim;
            navigate(
              `${getUIContextPathBAU()}/product-detail.html?$iSscan=true&offerEligible=Y&activeMtn=${
                props?.activeMtn
              }&deviceSKU=${deviceInfo?.deviceSku}&${
                props?.isByodUpdate ? 'isByodUpdate=true' : 'isFromCPE=true'
              }&deviceId=${validatedDeviceId}&mtn=${props?.activeMtn}&simId=${simSlot}${
                props?.prospectByodFlow ? '&prospectByodFlow=true&ByodDeviceCompitable=true' : ''
              }&ispuCompatibleSIM=${deviceInfo?.simInfo?.ispuCompatibleSIM}`,
            );
            setValidatedSimId(simSlot);
          }
        }
        // condition for pSim only devices to make second validatedevicesim id call (BYOD flow)
        if (!notification && !deviceInfo?.simInfo2?.makeEtniPersApi && !deviceInfo?.simInfo?.makeEtniPersApi) {
          setRepSelectedSimType('physicalSim');
        }
      }
      if (sendSimFromLanding === false) {
        if (
          deviceInfo?.simClass4G === 'NP' &&
          (channel?.includes('OMNI-RETAIL') || channel?.includes('OMNI-INDIRECT')) &&
          deviceInfo?.simInfo2
        ) {
          setdevicedata({
            eSimOnlyDevice: !!(deviceInfo?.makeEtniPersApi && !deviceInfo?.simInfo?.dfillCompatibleSim),
            skuId:
              deviceInfo?.simInfo2?.launchPackageSku ||
              deviceInfo?.simInfo2?.launchPackageSkuType ||
              deviceInfo?.deviceSku,
            imei1: deviceInfo?.imei1,
            skuDisplayName: deviceInfo?.simInfo2?.skuDisplayName ? deviceInfo?.simInfo2?.skuDisplayName : '',
            deviceId: deviceInfo?.simInfo2?.deviceId,
            simId,
            simLocalId: deviceInfo?.simInfo2?.iccid,
            fmipLocked: deviceInfo?.simInfo2?.fmipLocked,
            manualEntrySimId: devicePayload?.simId ? devicePayload?.simId : '',
            cpSimCard:
              ((channel === 'OMNI-TELESALES' ||
                channel === 'OMNI-CARE' ||
                scmDeviceEnable ||
                channel === 'CHAT-STORE') &&
                devicePayload?.simId &&
                true) ||
              (requestFlowType === 'DEVICE' && deviceInfo.simInfo2.iccid && true) ||
              devicePayload?.cpSimCard, // If the device has inbuilt sim, set customerProvidedSim as true
            cpSimCheckboxSelected: devicePayload?.cpSimCard,
            eid: deviceInfo?.simInfo2?.eID,
            eid2: deviceInfo?.pairedImeiData?.eid || '',
            launchPackageSku: requestFlowType === 'SIM' ? deviceInfo?.simInfo2?.launchPackageSku || '' : '',
            preferredSoftSim: deviceInfo?.simInfo2?.preferredSoftSim ? deviceInfo?.simInfo2?.preferredSoftSim : '',
            ispuCompatibleSIM: deviceInfo?.simInfo2?.ispuCompatibleSIM ? deviceInfo?.simInfo2?.ispuCompatibleSIM : '',
            etniApi: deviceInfo?.simInfo2 ? false : deviceInfo?.makeEtniPersApi,
            currentSimIdInRequest: formattedDeviceId ? devicePayload?.data?.lines?.[0]?.device?.sim?.CurrentSimid : '',
            scanFromPDPLocalFlow: !!(
              props?.isLocal &&
              scanFromLanding === false &&
              !devicePayload?.fromCpe &&
              !devicePayload?.isCustomerProvidedEquipment &&
              !props?.isByodUpdate
            ),
            pDeviceId: deviceInfo?.simInfo ? deviceInfo?.simInfo?.deviceId : '',
            simClass4G: deviceInfo?.simClass4G,
            intentType,
            physicalSku: deviceInfo?.deviceSku,
            physicalSimSku: deviceInfo?.simInfo?.dfillCompatibleSim || '',
            eDeviceId: deviceInfo?.simInfo2?.deviceId || '',
          });
        } else {
          // eSim data
          setdevicedata({
            eSimOnlyDevice: !!(deviceInfo?.makeEtniPersApi && !deviceInfo?.simInfo?.dfillCompatibleSim),
            skuId: deviceInfo?.deviceSku,
            skuDisplayName: deviceInfo?.skuDisplayName,
            imei1: deviceInfo?.imei1,
            deviceId: deviceInfo?.deviceId,
            simId: deviceInfo?.simInfo?.iccid ? deviceInfo?.simInfo?.iccid : deviceInfo?.simInfo?.preferredSoftSim,
            simLocalId: deviceInfo?.simInfo?.iccid,
            fmipLocked: deviceInfo?.fmipLocked,
            manualEntrySimId: devicePayload?.simId,
            cpSimCard:
              ((channel === 'OMNI-TELESALES' ||
                channel === 'OMNI-CARE' ||
                scmDeviceEnable ||
                channel === 'CHAT-STORE') &&
                devicePayload?.simId &&
                true) ||
              (requestFlowType === 'DEVICE' && deviceInfo?.simInfo?.iccid && true) ||
              devicePayload?.cpSimCard, // If the device has inbuilt sim, set customerProvidedSim as true
            cpSimCheckboxSelected: devicePayload?.cpSimCard,
            eid: deviceInfo?.simInfo?.eID,
            eid2: deviceInfo?.pairedImeiData?.eid || '',
            launchPackageSku: requestFlowType === 'SIM' ? deviceInfo?.simInfo?.launchPackageSku || '' : '',
            preferredSoftSim: deviceInfo?.simInfo?.preferredSoftSim ? deviceInfo?.simInfo?.preferredSoftSim : '',
            ispuCompatibleSIM: deviceInfo?.simInfo?.ispuCompatibleSIM ? deviceInfo?.simInfo?.ispuCompatibleSIM : '',
            etniApi: deviceInfo?.simInfo2 ? false : deviceInfo?.makeEtniPersApi,
            currentSimIdInRequest: formattedDeviceId ? devicePayload?.data?.lines?.[0]?.device?.sim?.CurrentSimid : '',
            scanFromPDPLocalFlow: !!(
              props?.isLocal &&
              scanFromLanding === false &&
              !devicePayload?.fromCpe &&
              !devicePayload?.isCustomerProvidedEquipment &&
              !props?.isByodUpdate
            ),
          });
        }
      }
      if (intentType === 'EUP' || ((intentType === 'AAL' || intentType === 'NSE') && !devicePayload.fromCpe)) {
        // NON BYOD or LOCAL FLOW ESIM
        if (
          deviceInfo?.simInfo2 ||
          deviceInfo?.makeEtniPersApi ||
          (devicedata?.etniApi === true && devicedata?.deviceId === devicePayload.deviceId)
        ) {
          setIsSingleSimEntiLookupModalVisibleByod(true);
          if (devicePayload?.deviceId)
            if (!secondLine) {
              setValidatedDeviceId(devicePayload?.deviceId);
            }
          const vzdl = window?.vzdl || {};
          if (vzdl?.event) vzdl.event.value = 'event24';
          window.vzdl = vzdl;
          sendCustomEvent('openView', window?.vzdl);
        } else if (checkDeviceSimCompatibility(compatibilityCheckParams)) {
          initiateDeviceSimCompatibilityCheck(compatibilityCheckParams);
        } else {
          // NON BYOD or LOCAL FLOW  NON ESIM
          if (devicePayload?.deviceId) {
            if (!secondLine) {
              setValidatedDeviceId(devicePayload?.deviceId);
            }
          }
          if (devicePayload?.simId) {
            setValidatedSimId(devicePayload?.simId);
          }
          if (isIndirect) {
            if (!sessionStorage.getItem('fromLostStolenFlow')) {
              displaySimCompartibleBanner(deviceInfo, validateDeviceSimRequest, dispatch);
            }
          }
        }
      }
      if (scmDeviceEnable && !simSkuInput && !deviceInput) {
        props?.setEnableBYODbtn(false);
      } else if (
        deviceInfo?.deviceId === props?.lineDeviceIdFromLanding &&
        deviceInfo?.simInfo?.iccid === props?.lineSimIdFromLanding
      ) {
        setValidatedSimId(deviceInfo?.simInfo?.iccid);
        props?.setEnableBYODbtn(false);
      } else if (
        deviceInfo?.deviceId === props?.lineDeviceIdFromLanding &&
        deviceInfo?.simInfo?.iccid !== props?.lineSimIdFromLanding &&
        (channel.includes('RETAIL') || channel.includes('TELESALES') || flexFlowServiceChange)
      ) {
        setValidatedSimId(deviceInfo?.simInfo?.iccid);
        props?.setEnableBYODbtn(true);
        updateBYODCTA();
      } else if (
        props.isByodUpdate === 'true' &&
        (isRetail() || isIndirect) &&
        deviceInfo?.deviceSimCompatible === 'Y' &&
        validateDeviceSimRequest?.data?.lines?.[0]?.device?.sim?.CurrentSimid !== '' &&
        validateDeviceSimRequest?.data?.lines?.[0]?.device?.sim?.id === ''
      ) {
        // Device SIM Compatible toast message
        setValidatedSimId(validateDeviceSimRequest?.data?.lines?.[0]?.device?.sim?.CurrentSimid);
        props?.setEnableBYODbtn(true);
        if (!sessionStorage.getItem('fromLostStolenFlow')) {
          dispatch(appMessageActions.addAppMessage('CurrentSIM is compatible with new device', 'success', true, true));
        }
      } 
      else if (
        !isDeviceIMEIChange &&
        ((omnicaredropdownValue !== 'Provisional ID' && !flexFlowServiceChange) ||
          !(flexFlowServiceChange && isProvisionalIdChecked)) &&
        deviceInfo?.deviceSimCompatible === 'N' &&
        deviceInfo?.simInfo?.iccid !== ''
      ) {
        dispatch(
          appMessageActions.addAppMessage('Sim is not compatible with the selected device', 'error', true, true),
        );

        if (scmDeviceEnable) {
          setValidatedSimId('');
          props?.setEnableBYODbtn(false);
        } else {
          props?.setEnableBYODbtn(true);
        }

        if (props?.isByodUpdate === 'true') {
          props?.setIncompatibleSim(true);
        }
      } else if (
        props.isByodUpdate === 'true' &&
        (deviceInfo?.deviceSimCompatible === 'Y' || deviceInfo?.deviceSimCompatible === '')
      ) {
        if (
          isOmniCare &&
          !deviceIdChanged &&
          !simSkuEntered &&
          props?.isByodUpdate === 'true' &&
          /true/i.test(byodButtonFFlag)
        ) {
          props?.setEnableBYODbtn(false);
        } else {
          props?.setEnableBYODbtn(true);
        }
      } else if (deviceInfo?.deviceSimCompatible === 'N' && deviceInfo?.simInfo?.iccid === '') {
        if (
          isOmniCare &&
          omnicaredropdownValue === 'SIM only change' &&
          props?.isByodUpdate === 'true' &&
          /true/i.test(byodButtonFFlag)
        ) {
          props?.setEnableBYODbtn(false);
        } else {
          props?.setEnableBYODbtn(true);
        }
      } 
      
      else if (
        ((scmDeviceEnable &&
        omnicaredropdownValue === 'Provisional ID')||(flexFlowServiceChange && isProvisionalIdChecked)) &&
        retrieveProvisionalDeviceIdResult?.data?.data?.data?.provisionalDeviceId
      ) {
        props.setEnableBYODbtn(true);
      }
    }
  };

  function getProcessStep(eSimRegen) {
    return isCustomerProvidedEquipment && !eSimRegen ? 'BYODDeviceIDPage' : 'GridWallPDP';
  }

  /*istanbul ignore next */
  const clearLostStolenVzdlPageDetail = () => {
    const vzdl = window?.vzdl || {};
    if (vzdl?.page) {
      vzdl.page.detail = '';
    }
    window.vzdl = vzdl;
  };

  /*istanbul ignore next */
  const handleLostStolenConfirm = (removedDeviceId) => {
    setShowLostStolenConfirmation(false);
    clearLostStolenVzdlPageDetail();
    if (props?.setEnableBYODbtn) {
      props.setEnableBYODbtn(true);
    }

    const successMessage = `${THE_DEVICE_ID} ${removedDeviceId} ${HAS_BEEN_SUCCESSFULLY_REMOVED_FROM_THE_LOST_STOLEN_LIST}`;
    const sanitizedSuccessMessage = `${THE_DEVICE_ID} ${HAS_BEEN_SUCCESSFULLY_REMOVED_FROM_THE_LOST_STOLEN_LIST}`;

    const vzdl = window?.vzdl ? { ...window.vzdl } : {};
    if (vzdl?.event) vzdl.event.value = '';
    if (vzdl?.error) vzdl.error.code = '';
    if (vzdl?.target) vzdl.target.message = sanitizedSuccessMessage;
    sendCustomEvent('notification', vzdl);
    if (window?.vzdl?.target) {
      window.vzdl.target.message = sanitizedSuccessMessage;
    }
    dispatch(
      appMessageActions.addAppMessage(successMessage, 'success', true)
    );
    sessionStorage.setItem('fromLostStolenFlow', 'true');
    setTimeout(() => sessionStorage.removeItem('fromLostStolenFlow'), 4000);

    const deviceIdToValidate = lostStolenDeviceId || validatedDeviceId || deviceInput || '';
    const simIdToValidate = ' ';
  
    if (deviceIdToValidate) {
        validateDeviceSimIdRequest(
          {
            mtn: props.activeMtn,
            deviceId: deviceIdToValidate,
            simId: simIdToValidate,
            cpSimCard: false,
            fromCpe: true,
            isCustomerProvidedEquipment: true,
            deviceFlow: true,
            isDWOS: false,
            sendSimFromLanding: true,
            lostStolenDeviceUIFFlag: lostStolenDeviceUIFFlag
          }
        );   
    } 
  };
  /*istanbul ignore next */
  const handleLostStolenCancel = () => {
    setShowLostStolenConfirmation(false);
    if (props?.setEnableBYODbtn) {
      props.setEnableBYODbtn(false);
    }
    clearLostStolenVzdlPageDetail();
  };

  const validateDeviceSimIdRequest = (payload, provisionalId, eSimRegen) => {/* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */
    const payloadDeviceId =
      scmDeviceEnable && payload?.deviceId?.deviceId ? payload?.deviceId?.deviceId : payload?.deviceId;
      const isProvisionalId = omnicaredropdownValue === 'Provisional ID'||(flexFlowServiceChange && isProvisionalIdChecked) || provisionalId;
    setSecondLine(payload?.isSecondNumLine);
    const isByodUpdate = !!getQueryParamByName('isByodUpdate') || props.isByodUpdate;
    const isPrepayCart = props.cartDetails?.cart?.orderDetails?.isPrePayCart || 'N';
    const lineSimDetailsFromLanding =
      activeMtnEqpInfo?.simInfo?.simId &&
      activeMtnEqpInfo?.simInfo?.simId !== '' &&
      activeMtnEqpInfo?.simInfo?.simId !== null &&
      activeMtnEqpInfo?.simInfo?.simId !== undefined
        ? activeMtnEqpInfo?.simInfo?.simId
        : '';
    const lineDeviceDetailsFromLanding =
      activeMtnEqpInfo?.deviceInfo?.deviceId &&
      activeMtnEqpInfo?.deviceInfo?.deviceId !== '' &&
      activeMtnEqpInfo?.deviceInfo?.deviceId !== null &&
      activeMtnEqpInfo?.deviceInfo?.deviceId !== undefined
        ? activeMtnEqpInfo?.deviceInfo?.deviceId
        : '';
    const intendType = !isEmpty(lineInfo) && lineInfo?.[0]?.lineActivityType ? lineInfo?.[0]?.lineActivityType : 'EUP';
    const isNewLine = !!(intendType && intendType === 'AAL');
    const mtnType = !isEmpty(lineInfo) && lineInfo?.[0]?.mtnDetails?.mtnType ? lineInfo?.[0]?.mtnDetails?.mtnType : '';
    let flowType;
    if (payload.deviceFlow) flowType = 'DEVICE';
    else if (!isProvisionalId && ((payload.simId && payload.simId !== ' ') || (isOmniCare && payload?.simSku)))
      flowType = 'SIM';
    else flowType = 'DEVICE';
    const formattedDeviceId = payloadDeviceId || '';
    const formattedSimId = payload?.simId?.simId ? payload.simId?.simId : payload.simId || '';
    const { cpSimCard, sendSimFromLanding } = payload;
    const { homeSalesAddress = {} } = CustomerData || {};
    const { bundles = [] } = homeSalesAddress;
    const sku = payload.sku ? payload.sku : '';
    const smartIMEI = payload.smartIMEI || false;
    let simSku = payload.simSku ? payload.simSku : '';
    const cpeWthoutDevIdFlag = payload.cpeWthoutDevIdFlag ? payload.cpeWthoutDevIdFlag : false;
    const fiveGDetails =
      !isEmpty(lineInfo) &&
      lineInfo?.filter((line) => line?.deviceTypeSelected && line?.deviceTypeSelected === '5G Internet');
    const deviceIdFromQuery = isByodUpdate && getQueryParamByName('deviceId') ? getQueryParamByName('deviceId') : '';
    const simIdFromQuery = isByodUpdate && getQueryParamByName('simId') ? getQueryParamByName('simId') : '';
    const isFiveG = fiveGDetails?.length > 0;
    const simIdQueryParam = getQueryParamByName('simId') ? getQueryParamByName('simId') : '';
    const getCurrentSimId = lineSimDetailsFromLanding || simIdQueryParam;
    let intent;
    if (customerType === 'N' && isCustomerProvidedEquipment) intent = 'NSEBYOD';
    else if (customerType === 'N') intent = 'NSE';
    else if (isPrepayCart === 'Y' && customerType !== 'N' && isCustomerProvidedEquipment) intent = 'BYOD';
    else if (isFiveG === true) intent = '5GHome';
    else if (isCustomerProvidedEquipment) intent = 'BYOD';
    else if (isNewLine) intent = 'AAL';
    else intent = 'EUP';
    let CurrentSimid;
    /* istanbul ignore next */
    if (sendSimFromLanding) CurrentSimid = lineSimDetailsFromLanding;
    else if (flowType === 'SIM' && (isMitekSimSwapEnabled === 'TRUE' || (validateSimIdFFlag && flexFlowServiceChange))) CurrentSimid = getCurrentSimId;
    else if (isByodUpdate === true) CurrentSimid = '';
    else CurrentSimid = simIdFromQuery;
    // For new customer flow we are setting currentSimid as empty CXTDT-595283
    if (customerType === 'N') CurrentSimid = '';
    /* istanbul ignore if */
    if(payload?.lostStolenDeviceUIFFlag) {
      CurrentSimid = '';
    }
    const formattedDfillSimId = formattedSimId;
    if (
      scmDeviceEnable &&
      props?.omnicaredropdownValue === 'SIM only change' &&
      formattedSimId &&
      !isNumeric(formattedSimId)
    ) {
      simSku = formattedDfillSimId;
    }
    if (scmDeviceEnable && omnicaredropdownValue !== 'Provisional ID' ||(flexFlowServiceChange && isProvisionalIdChecked)) {
      CurrentSimid = lineSimDetailsFromLanding;
      if (/^\d*$/gi.test(formattedSimId)) {
        simSku = '';
      }
    }
    let device;
    if (isFiveG === true && bundles?.bundleName?.includes('5GHomeSelfInstall')) {
      device = {
        Flowtype: 'GIFTBOX',
        giftbox: {
          id: formattedDeviceId,
        },
      };
    } else if (!cpeWthoutDevIdFlag) {
      let isSimNotChange = false;
      if (scmDeviceEnable && (!formattedSimId || formattedSimId === CurrentSimid)) {
        isSimNotChange = true;
        flowType = 'DEVICE';
      }
      /* istanbul ignore next */
      const simOnlyChange = isFunctionalityEnabled(FFLAGS?.scmCommonDefectFixFFlag?.name, FFLAGS?.scmCommonDefectFixFFlag?.attribute?.simOnlyChangeFix) && window?.mfe?.scmDeviceMfeEnable && flowType === 'SIM' && !isNumeric(formattedSimId);
      device = {
        id: formattedDeviceId,
        Flowtype: flowType,
        CurrentId:
          isByodUpdate === true &&
          lineDeviceDetailsFromLanding &&
          lineDeviceDetailsFromLanding !== '' &&
          lineDeviceDetailsFromLanding !== formattedDeviceId
            ? lineDeviceDetailsFromLanding
            : deviceIdFromQuery,
        isCustomerProvidedEquipment,
        sku,
        smartIMEI,
        sim: {
          id: getsimId(isSimNotChange, formattedSimId, simOnlyChange),
          sku:getSimSku(simSku, eSimRegen),
          isCustomerProvidedSIM: cpSimCard,
          CurrentSimid: getCurrentSimIdVal(isSimNotChange, CurrentSimid, isProvisionalId),
          // When user changed only deviceId then, pass current sim should empty and simku
          // ...(scmDeviceEnable && { CurrentSimid: isSimNotChange ? '' : CurrentSimid }),
        },
      };
      if (
        simCompatibilityCheck22417FFlag &&
        validatedDeviceId === formattedDeviceId &&
        flowType === 'DEVICE' &&
        sendSimFromLanding &&
        CurrentSimid !== ''
      ) {
        device.Flowtype = 'SIM';
        device.sim.id = CurrentSimid;
      }
    }
    if (scmDeviceEnable && lineDeviceDetailsFromLanding === formattedDeviceId && flowType === 'DEVICE' && CurrentSimid !== '') {
      device.Flowtype = 'SIM';
      device.sim.id = CurrentSimid;
    }

    // Extract qualification and line information into helper functions
    const getQualificationData = () => {
      const qualificationType = sessionStorage.getItem('Qualification_type');
      const hs_qualificationType = JSON.parse(sessionStorage.getItem('homesalesQualification_type'));
      const { cBandQualified = false } = customerProfileDetails?.customer?.qualificationDetails?.addressRequest || {};
      
      return { qualificationType, hs_qualificationType, cBandQualified };
    };

    const getLineInformation = () => {
      const lineDetailsInfo = cartDetails?.cart?.lineDetails?.lineInfo;
      const newLineInfo = lineDetailsInfo?.find((line) => line?.mobileNumber === activeMtn);
      const is5GDeviceSelected = newLineInfo?.deviceTypeSelected === "5G Internet";
      
      return { is5GDeviceSelected, newLineInfo };
    };

    // Get the extracted data
    const { qualificationType, hs_qualificationType, cBandQualified } = getQualificationData();
    const { is5GDeviceSelected } = getLineInformation();

    // Helper function to determine the intent value
    const getIntentValue = () => {
      if (rfexMfeFlowFlag()) {
        return {}; // Return empty object when rfex flag is true
      }
  
      const shouldUse5GIntent = isVbg() && is5GDeviceSelected;
      return { 
        intent: shouldUse5GIntent ? getActionValue() : intent 
      };
    };

    // Helper function to determine network bandwidth type based on conditions
    const getNwBwType = () => {
      const isCBand = cBandQualified || qualificationType === 'CBD' || hs_qualificationType?.cbandQualified;
      
      if (isVbg() && is5GDeviceSelected) {
        return isCBand ? "CBD" : "LTE";
      }
      
      return "LTE";
    };

    // Simplified action value calculation
    const getActionValue = () => {
      if (!isVbg() || customerType !== 'N') {
        return '';
      }
      
      const nwBwType = getNwBwType();
      return nwBwType === 'LTE' ? 'NSE_LTE' : 'NSE_5G';
    };

    const validateDeviceRequestBody = {
      cartInfo: {
        creditAppNum: null, // Todo for PDP page
        processingMTN: payload?.activeMtn ? payload?.activeMtn : payload?.mtn,
        ...getIntentValue(),
        ...(rfexMfeFlowFlag() ? {} : { intent }),
        processStep: getProcessStep(eSimRegen),
        processAction: isFiveG === true ? 'validateGiftBoxId' : 'validateDeviceSim',
        action: getActionValue(),
        locationCode: CustomerData?.orderLocationCode,
      },
      data: {
        lines: [
          {
            mtn: payload?.activeMtn ? payload?.activeMtn : payload?.mtn,
            mtnType,
            eskuId: payload.eskuId || '',
            device,
          },
        ],
      },
      disableEsimAtLocalInventory: false,
      ...inDirectValidateDeviceSimIdPayload(
        deviceActiveCheck,
        deviceActiveLoanCheck,
        devicePreorderCheck,
        iccidStatusCheck,
        disableEsimAtLocalInventory,
      ),
    };
    // for indirect channel we are sending existing device id from landing page (AAL flow it will be empty)
    if (isIndirect) {
      validateDeviceRequestBody.data.lines[0].device.existingDeviceId = lineDeviceDetailsFromLanding;
    }
    if (flexFlowServiceChange && eSimRegen) {
      setESimRegenerateStatus({ ...eSimRegenerateStatus, initiate: true });
    }
    const lostStolenDeviceUIFeatureFlag = /true/i.test(lostStolenDeviceUIFFlag);
    validateDeviceSimIdRequestBody({ body: validateDeviceRequestBody, spinner: false, showErrorBanner: !lostStolenDeviceUIFeatureFlag });
    setValidateDeviceSimRequest(validateDeviceRequestBody);
    setDevicePayload(payload);
    setPopUp(!popUp);
  };
  console.log(`ValidateDeviceSimIdResult - ${ValidateDeviceSimIdResult}`);
  if (ValidateDeviceSimIdResult?.status === 'pending') {
    dispatch(appLoaderActions.show());
  } else if (ValidateDeviceSimIdResult?.isError) {
    dispatch(appLoaderActions.hide());
  }

  /* istanbul ignore next */
  const updateDevicePayload = (payload) => {
    setDevicePayload((previouspayload) => ({ ...previouspayload, ...payload }));
    setdevicedata(payload);
    setValidatedDeviceId(payload?.deviceId);
    const isPsimSelected = payload?.selectedRadioButton === 'physicalSim';
    if (isPsimSelected) {
      props?.updateSimId('');
      // for retail pSim scenario by default sim input filed will be empty
      const setSimId = isRetail() || isIndirect ? '' : payload?.preferredSoftSim;
      setValidatedSimId(setSimId);
    }
  };

  const updateSetUpPopUp = () => {
    setPopUp(!popUp);
  };
   /* istanbul ignore next */
  const isDualSimEntiLookupModalVisibleUpdate = (isCloseModalSelected) => {
    if (window?.mfe?.scmDeviceMfeEnable && isCloseModalSelected) {
      setRepSelectedSimType('');
      setValidatedSimId(props.isByodUpdate || props.isFromCPE ? props.defaultSimId : '');
    }
    setIsDualSimEntiLookupModalVisible(!isDualSimEntiLookupModalVisible);
  };
  const handleOnBlursimACSS = (e) => {
    const input = e.target.value.trim();
    const isValid = inputSimRegEx.test(input);
    const numberOnly = input && isNumeric(input);

    // Check simId should have only letters,digit & -
    if ((scmDeviceEnable && !alphaNumericRegEx.test(input)) || (flexFlowServiceChange && !alphaNumericRegEx.test(input))) {
      dispatch(appMessageActions.addAppMessage(`Enter valid SimID.`, 'error', true, false));
      return;
    }

    setSimSkuInput(input);
    /* istanbul ignore if  */
    if (numberOnly) {
      if (scmDeviceEnable || flexFlowServiceChange) {
        setSimError(!isValid);
        if (!isValid) {
          return;
        }
      }
    }

    if (
      scmDeviceEnable &&
      e.target.value !== '' &&
      (props?.omnicaredropdownValue === 'SIM only change' || repSelectedSimType === 'physicalSim')
    ) {
      handleOnBlurSimSku(e);
    }
      /* istanbul ignore next */
    if (
      !scmDeviceEnable &&
      e.target.value !== '' &&
      flexFlowServiceChange &&
      simType === 'pSIM'
      // repSelectedSimType === 'physicalSim'
    ) {
      handleOnBlurSimSku(e);
    }
  };
  /* istanbul ignore next */
  function getUpdatedSimInfo() {
    if (flexFlowServiceChange) {
      return deviceInfo?.simInfo?.eID ? deviceInfo?.simInfo : deviceInfo?.simInfo2;
    }
    const hasRequiredProps = deviceInfo?.simInfo?.eID && deviceInfo?.simInfo?.makeEtniPersApi;
    return hasRequiredProps ? deviceInfo?.simInfo : deviceInfo?.simInfo2;
  }
   /* istanbul ignore next */
  const initSimDetailsCall = () => {
    let updatedSimInfo = getUpdatedSimInfo();
    const cartLines = props?.cartDetails?.cart?.lineDetails?.lineInfo || [];
    const lineInformation = cartLines?.filter((line) => line?.mobileNumber === props?.activeMtn);
    const isMtnTypePortIn = lineInformation[0]?.portinMtnAssignment || false;
    const isActiveLineMtnType = lineInformation[0]?.mtnDetails?.mtnType
      ? lineInformation[0]?.mtnDetails?.mtnType.toUpperCase()
      : '';
    const isMtnTypePreToPost = isActiveLineMtnType === MTN_TYPE_PRE_TO_POST;
    const isMtnTypeVisible = isActiveLineMtnType === MTN_TYPE_VISIBLE;
    const isMtnTypeYahoo = isActiveLineMtnType === MTN_TYPE_YAHOO;
    const isMtnTypeHarmony = isActiveLineMtnType === MTN_TYPE_HARMONY;
    const isPrepayCart = props.cartDetails?.cart?.orderDetails?.isPrePayCart || 'N';
    const intendType =
      lineInformation?.length > 0 && lineInformation?.[0]?.lineActivityType
        ? lineInformation?.[0]?.lineActivityType
        : 'EUP';
    const isNewLine =
      intendType && (intendType === 'AAL' || intendType === 'NSE' || intendType === 'BYOD' || intendType === 'NSEBYOD');
    const billingSystemFromCart = props.cartDetails?.cart?.orderDetails?.billingSystem ?? '';
    let billerId = '';
    if (CustomerData?.billingSystem) {
      billerId = CustomerData.billingSystem;
    } else if (billingSystemFromCart) {
      billerId = billingSystemFromCart;
    } else if (props.prospectByodFlow && props.cartDetails?.cart?.orderDetails?.billingSystem) {
      billerId = props.cartDetails?.cart?.orderDetails?.billingSystem;
    }
    const eSimRequestBody = {
      billerId,
      mdn: secondLine ? props?.pairedMtn : props.activeMtn,
      sku: updatedSimInfo?.preferredSoftSim,
      eid: updatedSimInfo?.eID,
      processInd: isNewlyAddedLine || isNewLine ? 'N' : 'D',
    };
    /* istanbul ignore else */
    // No else statement to cover
    if (
      isMtnTypePreToPost ||
      isMtnTypeVisible ||
      isMtnTypeYahoo ||
      isMtnTypeHarmony ||
      isMtnTypePortIn ||
      isPrepayCart === 'Y'
    ) {
      eSimRequestBody.processInd = 'M';
    }
    eSimData({ body: eSimRequestBody });
  };

  // Call InitSimDetailsCall when DeviceSimInfo send callESimApi = true on first call of ValidateDeviceSimId call.
  useEffect(() => {
    if (props?.callESimApi && !isEsimActivationEnabled) {
      const soeguivalue = sessionStorage.getItem('encryptedActInfo') || '';
      const selectSimInfo =
        deviceInfo?.simInfo?.eID && deviceInfo?.simInfo?.makeEtniPersApi ? deviceInfo?.simInfo : deviceInfo?.simInfo2;
      retriveSimEIdCall({
        customHeaders: { soeguivalue },
        body: { eid: selectSimInfo?.eID, applicationId: 'ACSS', userId: UserProfile.getAttribute('userId') },
      });
    }
  }, [props?.callESimApi]);

  useEffect(() => {
    if (retriveSimEIdResult?.status === 'fulfilled' && retriveSimEIdResult?.data?.data) {
      const isRegenerateProfile = retriveSimEIdResult?.data?.data?.simProfileExist;
      if (isRegenerateProfile) {
        dispatch(appMessageActions.addAppMessage(UI_MESSAGES.MULTI_ESIM_PROFILE_ERROR, 'error', true, false));
      }
      initSimDetailsCall();
    }
  }, [retriveSimEIdResult?.status]);

  const onClickEntiLookupOption = (option) => {
    if (option === 'yes') {
      setIsSingleSimEntiLookupModalVisibleByod(!isSingleSimEntiLookupModalVisibleByod);
      if (!skipIccidCall && !props?.isSecNumValidation) initSimDetailsCall();
      updateSetUpPopUp();
      props.setEnableBYODbtn(true);
      if (props?.isSimultaneousUpgrade) {
        setIsSecNumValidation(!props?.isSecNumValidation);
      }
    } else if (option === 'no') {
      setIsSingleSimEntiLookupModalVisibleByod(!isSingleSimEntiLookupModalVisibleByod);
      updateSetUpPopUp();
      if (!scmDeviceEnable) {
        if (getQueryParamByName('fromPage') === 'combinedgridwall' && isOmniCare) {
          navigate(`${getUIContextPathBAU()}/combinedgridwall.html?activeMtn=${props.activeMtn}`);
        } else {
          navigate(`${getUIContextPathBAU()}/landing.html`);
        }
      }
    }
  };

  const handleChangeSimID = (e, ivrSimID) => {
    if ((e && e.target && e.target.value) || ivrSimID) {
      const input = ivrSimID || e.target.value?.trim();
      setValidatedSimId(input);
      // Clear eSIM regeneration flag when user starts typing
      if (props?.setIsESimRegenerated) {
        props?.setIsESimRegenerated(false);
      }
      setShowESimRegenerateMessage(false);
      // Re-enable Regenerate eSIM button when user types
      setESimRegenerateStatus({ ...eSimRegenerateStatus, enable: true });
    } else if (e && e.target && e.target.value === '') {
      setValidatedSimId(e.target.value);
      if (flexFlowServiceChange) {
        props?.setEnableBYODbtn(false);
      }
      // Clear eSIM regeneration flag when field is cleared
      if (props?.setIsESimRegenerated) {
        props?.setIsESimRegenerated(false);
      }
      setShowESimRegenerateMessage(false);
      // Re-enable Regenerate eSIM button when field is cleared
      setESimRegenerateStatus({ ...eSimRegenerateStatus, enable: true });
    }
  };

  const updateDfillSimId = (simId) => {
    setValidatedSimId(simId);
  };

  const allowOnlyNumbers = (value) => {
    const rE = /^[0-9\b]+$/;
    return value === '' || rE.test(value);
  };

  const handleChangeDeviceIDs = (e) => {
    let txtfieldVal;
    if (scmDeviceEnable) {
      setDeviceIdEsimCheck('');
      dispatch(appMessageActions.clearAppMessages());
    }
    if (e && e.target && e.target.value) {
      const input = e.target.value;
      setValidatedDeviceId(input);
      if (allowOnlyNumbers(e.target.value) && e.target.value.length <= 15) {
        if (e.target.value.length === 15) {
          txtfieldVal = e.target.value;
          setValidatedDeviceId(input);
          setDeviceIdChanged(true);
        }
      } else {
        e.target.value = txtfieldVal || '';
      }
    } else if (e && e.target && e.target.value === '') {
      setValidatedDeviceId(e.target.value);
      // will override eSimDevice id if user clears the device id
      setDeviceIdEsimCheck('');
    }
  };
  const handleGetUpdateOldSimId = (data) => {
    const currentSimIdInRequest = validateDeviceSimRequest?.data?.lines?.[0]?.device?.CurrentSimid;
    const queryParamSim = getQueryParamByName('simId') ? getQueryParamByName('simId') : '';
    const currentSimId = currentSimIdInRequest || queryParamSim;
    const msg =
      '&#9888; This account is currently restricted. Please exit and re-access the account using Adaptive Authentication.';
    setValidatedSimId(currentSimId);
    props?.simSwapFlowUpdateButtonDisabled(true);
    if (data === 'NotApproved') {
      setSimDisabled(true);
      dispatch(appMessageActions.clearAppMessages());
      dispatch(appMessageActions.addAppMessage(msg, 'warning', true, false));
    }
  };
  const idScanModalValue = (data) => {
    setIdScanModalOpen(data);
  };

  const handleModelChange = (data) => {
    setIdScanModalOpen(data);
    dispatch(appMessageActions.clearAppMessages());
    dispatch(appMessageActions.addAppMessage('Device ID is updated successfully', 'success', true, false));
  };

  const disableUpdate = () => {
    props?.simSwapFlowUpdateButtonDisabled(true);
  };
  const closeModal = () => {
    setIdScanModalOpen(false);
  };
  const handleChangeSimIDFlow = (e) => {
    /* istanbul ignore else */
    // No else statement to cover
    if ((validatedSimId !== e.target.value) && flexFlowServiceChange) {
      setSimIdChanged(true);
      // setPreviousSimId(validatedSimId);
      setChangedSimId(e.target.value);
    }
     if (flexFlowServiceChange) {
      handleChangeSimID(e);
      setSimSkuEntered(e.target.value);
    }
    if (window?.mfe?.scmDeviceMfeEnable) {
      handleChangeSimID(e);
      setSimSkuEntered(e?.target?.value?.trim());
    }
  };
  const verifyUpcAndSkuCallback = (data) => {
    console.log(`upc barcode and device id validate check inside callback , ${JSON.stringify(data)}`);
    try {
      if (isIpad()) {
        if (/true/i.test(data)) {
          props?.setUpcAndDeviceIdCheckEnabled(false);
          props?.setIsDevicePricingApiCallEnable(true);
          dispatch(
            appMessageActions.addAppMessage('UPC Code is compatible with the selected device', 'success', true, true),
          );
        } else {
          props?.setUpcAndDeviceIdCheckEnabled(true);
          props?.setIsDevicePricingApiCallEnable(false);
          dispatch(
            appMessageActions.addAppMessage('UPC Code is not compatible with the selected device', 'error', true, true),
          );
        }
      }
    } catch (e) {
      console.log(`error in catch block, ${e}`);
    }
  };
  const handleUpcAndDeviceIdValidateCheck = (UpcData) => {
    const deviceSku = deviceInfo?.deviceSku || getQueryParamByName('deviceSKU') || '';
    const req = { upc: UpcData, skuId: deviceSku };
    const param = {
      apiName: 'verifyUpcAndSku',
      method: 'get',
      requestPayloadJson: JSON.stringify(req),
    };
    executeShellFunction('Shell', 'executeBestbuyShellFunction', 'window.verifyUpcAndSkuCallback', param);
  };
  // if sim input field is disaabled and desktop then show label message
  const showSimProcessingMsg = () => !showSimInfo() && !isIpad();
  // hide sim are if skipICCID: "TRUE" for edit scenario
  const isEsimRetrieveCartFlow = (deviceFromCart || isEditAndView) && simFromFilteredCartLine?.eSIM;
  const isESimFromUrl = Boolean(getQueryParamByName('eSim'));
  const isEIDVal = devicedata?.eid;
  const eSimEtniApi = devicedata?.eSimEtniApi;
  const etniApi = devicedata?.etniApi;
  const isEsimFlow = !isEmpty(devicedata)
    ? (etniApi || eSimEtniApi || devicedata?.eSimOnlyDevice) && isEIDVal
    : isESimFromUrl;
  let shouldDisplayESIMMessage = false;

  /*istanbul ignore next*/
  const checkInitialcondition = () => {
    const isFlexflow = isEmpty(validatedSimId) || flexFlowServiceChange;
    const checkEsimFlow = isEsimRetrieveCartFlow || isEsimFlow;
    const eSimEtniApi = devicedata?.eSimEtniApi;
    const eId = devicedata?.eid !== '';
    const condition1 = isFlexflow && checkEsimFlow && skipIccidCall;
    const condition2 = eSimEtniApi && eId && skipIccidCall
    return condition1 || condition2 || false;
  }

  shouldDisplayESIMMessage = checkInitialcondition();

  // conditions to hide sim area as per cradle props
  const byodDeviceCheck =
    isCustomerProvidedEquipment || scanFromLanding || localScan
      ? isEsimOnlyDevice
      : !isEmpty(devicedata) && devicedata?.eid !== '';
  const byodDualSimCheck = isCustomerProvidedEquipment && !!getQueryParamByName('eSim');
  const hideSIMArea =
    (isEmpty(validatedSimId) && (isEsimRetrieveCartFlow || isEsimFlow) && skipIccidCall) ||
    ((byodDeviceCheck || byodDualSimCheck) && skipIccidCall);
  if (skipICCIDFFlag) {
    props?.setRemoveSimOnlyChange(hideSIMArea);
  }
  const isSecondNumDfill = sessionStorage.getItem('isSecondNumDfill');
  const alowedTypes = ['AAL', 'NSE', 'BYOD', 'NSEBYOD'];
  const propsLineActivityType = props?.lineActivityType;
  const isDisabled = !isIpad() && isEditAndView && rfexMfeFlowFlag();
  let isSimEnabled = false;
  const isEsimFromParam = getQueryParamByName('eSim');

  if (
    (window?.mfe?.scmDeviceMfeEnable && repSelectedSimType === 'eSim') ||
    isEsimFromParam === 'true' ||
    (!isIpad() && isEditAndView && (isRetail() || isIndirect || isD2D() || rfexMfeFlowFlag()))
  ) {
    isSimEnabled = true;
  }
  const isCareDeviceSIMIdDisabled =
    isSimEnabled ||
    omnicaredropdownValue === 'Provisional ID' ||(flexFlowServiceChange && isProvisionalIdChecked)||
    isInsideSalesUser ||
    (scmDeviceEnable && (isEsimOnlyDevice || repSelectedSimType === 'eSim'));
  function surfaceDarkOrLight() {
    return isDark ? 'dark' : 'light';
  }
  
  function errorMessage() {
    return simError ? simErrorMsg : '';
  }
  const shouldShowSimProcessingMessage = (simProcessOnlyIpad || showSimProcessingMsg()) && channel !== 'OMNI-CARE' &&   channel !== 'OMNI-TELESALES' && !scmDeviceEnable && !isVideoAssistFlow && !flexFlowServiceChange;

  const isPosTrainingEnabled = trainingFlag() || false;
  return (
    !isSecondNumDfill && (
      <div data-testid='DeviceSimID'>
        {!flexFlowServiceChange && ((props.isByodUpdate && isTelesales()) ||
            (!isIpad() && isEditAndView && !props?.isActiveNewLine && isIndirect)) && (
            <DivWrapper>
              <DisplayWrapper className='u-textBold'>Device and SIM processing are available only on iPad</DisplayWrapper>
            </DivWrapper>
          )}
        { flexFlowServiceChange && <DivWrapper>
          <div className='etr-title u-textBold'>Device ID</div>
        </DivWrapper>}
       { <DeviceWrapper flexFlowServiceChange={flexFlowServiceChange}>
          <FlexFlowWrapper flexFlowServiceChange={flexFlowServiceChange}>
          {
            careDeviceIdSelected || channel !== 'OMNI-CARE' || scmDeviceEnable ? (
              <SIMIDWrapper>
                {!disableDeviceDetailsForAsurion && (
                  <DeviceScan
                    setRepSelectedSimType={setRepSelectedSimType}
                    setEnableBYODbtn={props?.setEnableBYODbtn}
                    deviceIdEsimCheck={deviceIdEsimCheck}
                    shouldDisplayESIMMessage={shouldDisplayESIMMessage}
                    isPdpPage
                    isProvisionalId={omnicaredropdownValue === 'Provisional ID'||isProvisionalIdChecked}
                    setIsProvisionalIdChecked={setIsProvisionalIdChecked}
                    setIsESimRegenerated={props?.setIsESimRegenerated}
                    ScanFromLanding={false}
                    upgradeIneligibleFlag={upgradeIneligibleFlag}
                    sku={props.sku}
                    isCancel={(val) => props.isCancel(val)}
                    addressValidation={props.addressValidation}
                    homeSalesBundles={props.homeSalesBundles}
                    isCustomerProvidedEquipment={isCustomerProvidedEquipment}
                    validateDeviceSimIdRequest={validateDeviceSimIdRequest}
                    handleChangeDeviceIDs={(e) => handleChangeDeviceIDs(e)}
                    deviceId={validatedDeviceId || ''}
                    fromCpe={isCustomerProvidedEquipment}
                    showScanner={showScanner}
                    isWSAPCpeError={props.isWSAPCpeError}
                    cpeDeviceId={props.cpeDeviceId}
                    cpeCheckboxFlag={props.cpeCheckboxFlag}
                    isIndirect={props.isIndirect}
                    LineDeviceId={props.lineDeviceIdFromLanding}
                    getHomeSalesAddressDetails={props.getHomeSalesAddressDetails}
                    qualificationDetails={props.getQualificationDetails}
                    LandingCband={props.LandingCband}
                    Landingltequalified={props.Landingltequalified}
                    LandingFiveGHomeQualified={props.LandingFiveGHomeQualified}
                    appPropertiesFromSessionStorage={props.appPropertiesFromSessionStorage}
                    customerType={props.customerType}
                    creditAppNumber={props.creditAppNumber}
                    is5GDevice={is5GDevice}
                    isPaymentOptionVisible={props.isPaymentOptionVisible}
                    updateEsimDialogBoxButtons={props.updateEsimDialogBoxButtons}
                    isByodUpdate={props.isByodUpdate}
                    CustomerData={CustomerData}
                    activeMtn={props.activeMtn}
                    isFromPDPPage
                    isNewlyAddedLine={props?.isNewlyAddedLine}
                    setDisableUpdateButton={props?.setDisableUpdateButton}
                    isDisabled={
                      isDisabled || (!isAALNumber() && scmDeviceEnable && omnicaredropdownValue === 'SIM only change')
                    }
                    simSkuInput={simSkuInput}
                    deviceInput={deviceInput}
                    setDeviceInput={setDeviceInput}
                    simSwapNotificationHighRiskMsg={simSwapNotificationHighRiskMsg}
                  />
                )}
                { (isPearl ||
                  (!disableDeviceDetailsForAsurion && (isByodUpdateOnDekstop || props.isByodUpdate) && isRetail)) && (
                      <CheckboxWrapper>
                        <Checkbox
                          type='checkbox'
                          name='SIMCardProvided'
                          className='cpe-checkbox'
                          selected={cpeCheckbox}
                          checked={cpeCheckbox}
                          disabled={!props.isWSAPCpeError}
                          surface={isDark ? 'dark' : 'light'}
                          onChange={() => onCheckBoxChange()}
                          label='This device is customer-provided equipment'
                          data-track='Productdetail_cpe-checkbox'
                        />
                      </CheckboxWrapper>
                    )}
                  </SIMIDWrapper>
                ) : (
                  <InputWrapper>
                    <SIMIDWrapper scmDeviceEnable={scmDeviceEnable}>
                      <Input
                        type='text'
                        iconName=''
                        name='deviceSku'
                        id='deviceSku'
                        placeholder='Enter Device SKU'
                        surface={isDark ? 'dark' : 'light'}
                        label='Device SKU'
                        value={validatedDeviceId}
                        // onChange={e => this.handleChangeDeviceSKU(e)}
                        // onBlur={e => this.handleOnBlurDeviceSKU(e)}
                        disabled
                      />
                    </SIMIDWrapper>
                  </InputWrapper>
                ) // To do for Omni-Care Sku selection
              }
            </FlexFlowWrapper>
            <FlexFlowWrapper flexFlowServiceChange={flexFlowServiceChange}>
              <InputWrapper>
              {(skipIccidCall && isEsimOnlyDevice) || hideSIMArea  ? (
                  <> </>
                ) : (
                  <SIMIDWrapper className={flexFlowServiceChange ? 'eSimRegenerate' : ''}>
                    {
                      // eslint-disable-next-line no-nested-ternary
                      (props.isByodUpdate &&
                        channel?.indexOf('OMNI-RETAIL') === -1 &&
                        !isIndirect &&
                        !scmDeviceEnable && !flexFlowServiceChange && 
                        (validatedSimId === 'null' || validatedSimId === '') &&
                        !isBYODUpdateAALRetail) ||
                      props.isDWOS === true ||
                      displaySimForIconicSku === false ? (
                        // eslint-disable-next-line react/jsx-no-useless-fragment
                        <></>
                      ) : (careDeviceIdSelected && !careOrTelePactRep) /* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */ ||
                        channel !== 'OMNI-CARE' ||
                        scmDeviceEnable ||
                        omnicaredropdownValue === 'Provisional ID' ? (
                        <>
                          <IpadSimContent>
                            {!showSimInfo() ? (
                              <>
                                <InputWrapper className={flexFlowServiceChange ? 'simtypefield' : ''}>
                                  <Input
                                    name='simId'
                                    id='simId'
                                    placeholder='Enter Sim ID'
                                    surface={surfaceDarkOrLight()}
                                    value={validatedSimId}
                                    onChange={(e) => {
                                      handleChangeSimIDFlow(e);
                                    }}
                                    onBlur={(e) => handleOnBlursimACSS(e)}
                                    onFocus={(e) => handleOnFocusSimSku(e)}
                                    data-testid='handleChangeSimID'
                                    required
                                    disabled={isCareDeviceSIMIdDisabled || (flexFlowServiceChange && simType === 'eSIM') || isPosTrainingEnabled}
                                    label='Enter Sim ID'
                                    data-track='Productdetail_simId'
                                    error={simError}
                                    errorText={errorMessage()}
                                  />
                                </InputWrapper>
                                {esimAPIskipFFlag && flexFlowServiceChange && showESimRegenerateMessage && simType === 'eSIM' && (
                                  <ESimRegenerateMessage data-testid='esim-regenerate-message'>
                                    eSIM will populate post activation
                                  </ESimRegenerateMessage>
                                )}
                              </>
                            ) : (
                              ''
                            )}
                            {shouldShowSimProcessingMessage && (
                                <DivWrapper>
                                  <span className='u-textBold'>
                                    SIM processing only available on iPad {props.deviceIdSelected}
                                  </span>
                                </DivWrapper>
                              )}
                            {isVideoAssistFlow === true && !(isRetail && isIpad()) && (
                              <DivWrapper>
                                <span className='u-textBold'>
                                  SIM processing and device changes are not available during Video Assists or Outbound Leads
                                </span>
                              </DivWrapper>
                            )}
                            {isEsimOnlyDevice && (
                              <DivWrapper>
                                <span className='u-textBold'>Cannot change for eSIM only devices</span>
                              </DivWrapper>
                            )}
                          </IpadSimContent>
                          {showSimInfo() ? (
                            // eslint-disable-next-line react/jsx-no-useless-fragment
                            <>
                              {!props.isDWOS && displaySimForIconicSku === true && (
                                <InputWrapper>
                                  <SIMIDWrapper>
                                    <SimScan
                                      isCustomerProvidedEquipment={isCustomerProvidedEquipment}
                                      validateDeviceSimIdRequest={validateDeviceSimIdRequest}
                                      deviceId={validatedDeviceId || ''}
                                      handleChangeSimID={(e, ivrSimId) => handleChangeSimID(e, ivrSimId)}
                                      fromCpe={isCustomerProvidedEquipment}
                                      isLocal={props.isLocal}
                                      simId={validatedSimId || ''}
                                      showScanner={showScanner}
                                      updateDfillSimId={updateDfillSimId}
                                      isDeviceBuyout={props.isDeviceBuyout}
                                      updateShowISPUForVA={props.updateShowISPUForVA}
                                      isVideoAssistFlow={props.isVideoAssistFlow}
                                      getDeviceData={props.getDeviceData}
                                      simDisabled={simDisabled}
                                      isProvisionalId={flexFlowServiceChange && isProvisionalIdChecked}
                                      channel={channel}
                                      deviceInfo={deviceInfo}
                                      validateDeviceSimRequest={validateDeviceSimRequest}
                                      is5GDevice={is5GDevice}
                                      isPaymentOptionVisible={props?.isPaymentOptionVisible}
                                      cartDetails={props?.cartDetails}
                                      customerProfileDetails={props?.customerProfileDetails}
                                      correlationId={correlationId}
                                      handleGetUpdateOldSimId={handleGetUpdateOldSimId}
                                      simSwapFlowUpdateButtonDisabled={props?.simSwapFlowUpdateButtonDisabled}
                                      setMitekIdVerifyStatus={props?.setMitekIdVerifyStatus}
                                      activeMtn={props.activeMtn}
                                      isNewlyAddedLine={props?.isNewlyAddedLine}
                                      isByodUpdate={props?.isByodUpdate}
                                      isDisabled={isDisabled}
                                      setSimInputChangedIpad={setSimInputChangedIpad}
                                      setSimValueIpad={setSimValueIpad}
                                      flexFlowServiceChange={flexFlowServiceChange}
                                      simType={simType}
                                      showESimRegenerateMessage={showESimRegenerateMessage}
                                    />
                                  </SIMIDWrapper>
                                </InputWrapper>
                              )}
                            </>
                          ) : (
                            ''
                          )}
                          {careDeviceIdSelected && props.isFromCPE && !scmDeviceEnable && isEsimOnlyDevice && (
                            <DisplayWrapper>
                              <span className='u-marginBottom u-textBold'>{props.careUsingExistingSimNote}</span>
                            </DisplayWrapper>
                          )}
                        </>
                      ) : (
                        <InputWrapper>
                          <SIMIDWrapper scmDeviceEnable={scmDeviceEnable}>
                            <Input
                              type='text'
                              iconName=''
                              name='simId'
                              id='simId'
                              data-testid='simId'
                              value={simSkuEntered}
                              placeholder='Enter SIM ID'
                              surface={isDark ? 'dark' : 'light'}
                              label='Sim SKU'
                              onBlur={(e) => handleOnBlurSimSku(e)}
                              onChange={(e) => handleChangeSimSku(e)}
                              onFocus={(e) => handleOnFocusSimSku(e)}
                              autoComplete='off'
                              // value={this.state.deviceId || this.props.selectedDeviceId || ""}
                              // onChange={e => this.handleChangeDeviceID(e)}
                              // onBlur={e => this.handleOnBlurDeviceID(e)}
                              // disabled={channelName === "OMNI-INDIRECT" && this.props.isDeviceFromCart}
                              // error={this.state.simError}
                              // errorText={this.state.simError ? simErrorMsg : ""}
                            />
                          </SIMIDWrapper>
                        </InputWrapper>
                      ) // To do for Omni-Care Sku selection
                    }
                    {flexFlowServiceChange && isSmartWatchCheck && (
                      <FlexFlowWrapper className='regenrate-container'>
                        <InputWrapper className='simTypeDisplay'>
                          <div>
                            <Body size='large'>Sim Type</Body>
                            <div>{simType}</div>
                          </div>
                        </InputWrapper>
                        {simType === 'eSIM' && (
                          <InputWrapper className='regenerateEsimLink'>
                            <TextLink
                              data-testid='regenerateESim'
                              type='standAlone'
                              size='large'
                              style={{ cursor: 'pointer' }}
                              surface={surfaceDarkOrLight()}
                              onClick={() => handleEsimModalShow()}
                              disabled={!eSimRegenerateStatus?.enable}
                              data-track='regressionEsim'
                            >
                              Regenerate eSIM
                            </TextLink>
                          </InputWrapper>
                        )}
                      </FlexFlowWrapper>
                    )}
                  </SIMIDWrapper>
                )}
              </InputWrapper>
            </FlexFlowWrapper>
          </DeviceWrapper>
        }
         {flexFlowServiceChange && simType === 'pSIM' && shouldShowSimSale && !isProvisionalIdChecked && (
          <DeviceWrapper flexFlowServiceChange={flexFlowServiceChange}>
            <InputWrapper>
              <SimSale
                setEnableBYODbtn={props?.setEnableBYODbtn}
                simSaleFlow={simSaleFlow}
                setSimSaleFlow={setSimSaleFlow}
                validSimSku={validSimSku}
              />
            </InputWrapper>
          </DeviceWrapper>
        )}
        {(props?.upcCodeFromPdpScan || UpcCodeData) &&
        props?.isBBYLocalOrder &&
        /true/i.test(bestBuyIntegrationFFlag) ? (
          <UpcCodeScan
            setUpcCodeFromPdpScan={props?.setUpcCodeFromPdpScan}
            upcCodeFromPdpScan={props?.upcCodeFromPdpScan}
            handleUpcAndDeviceIdValidateCheck={handleUpcAndDeviceIdValidateCheck}
            setUpcAndDeviceIdCheckEnabled={props?.setUpcAndDeviceIdCheckEnabled}
          />
        ) : (
          ''
        )}
        {props?.isSimultaneousUpgrade && (
          <>
            <HorizontalLine />
            <SecondLineDeviceId
              {...props}
              isSecNumValidation={props?.isSecNumValidation}
              pairedMtn={props?.pairedMtn}
              validateDeviceSimIdRequest={validateDeviceSimIdRequest}
              deviceInfo={deviceInfo}
            />
          </>
        )}
        {isDualSimEntiLookupModalVisible && (
          <ESim
            lineActivityType={props?.lineActivityType}
            isPdpPage
            eSimModelData={eSimPopUpData}
            totalLines={lineInfo}
            updateDevicePayload={updateDevicePayload}
            activeMtn={props.activeMtn}
            sourcefrom='combinedgridwall'
            initSimDetailsCall={initSimDetailsCall}
            isDualSimEntiLookupModalVisible={isDualSimEntiLookupModalVisible}
            isDualSimEntiLookupModalVisibleUpdate={isDualSimEntiLookupModalVisibleUpdate}
            updateSetUpPopUp={updateSetUpPopUp}
            ProspectByodFlow={false}
            scanCheck={scanCheck}
            deviceInfo={deviceInfo}
            idScanModalValue={(value) => idScanModalValue(value)}
            setRepSelectedSimType={setRepSelectedSimType}
            setEnableBYODbtn={props?.setEnableBYODbtn}
            isDeviceIMEIChange={isDeviceIMEIChange}
            resetInput={resetInput}
          />
        )}
        {isSingleSimEntiLookupModalVisibleByod && !showSecondNumberActivationModal && (
          <ConfirmationDialogBox
            data-testid='confirmationBox'
            message='This device requires an eSim for activation, do you wish to continue?'
            btnYesText='Yes'
            btnNoText='No'
            isNoBtnDisabled={false}
            isYesBtnDisabled={isOmniCare && !scmDeviceEnable && !alowedTypes.includes(propsLineActivityType)}
            handleConfirmationDialogBoxClick={(val) => {
              onClickEntiLookupOption(val);
            }}
          />
        )}
        {isIdScanModalOpen && (
          <IDScanModal
            isOpen={isIdScanModalOpen}
            handleModelChangeEsimFlow={handleModelChange}
            correlationId={correlationId}
            closeModal={closeModal}
            simswapSessionId={deviceInfo?.simswapSessionId}
            cartDetails={props?.cartDetails}
            customerProfileDetails={props?.customerProfileDetails}
            activeMtn={props?.activeMtn || getQueryParamByName('activeMtn')}
            setMitekIdVerifyStatus={props?.setMitekIdVerifyStatus}
            DeviceScanFow
            disableUpdateDeviceSwap={disableUpdate}
          />
        )}
        {showSecondNumberActivationModal && (
          <SecondNumActivationModal
            showSecondNumberActivationModal={showSecondNumberActivationModal}
            setShowSecondNumberActivationModal={setShowSecondNumberActivationModal}
          />
        )}
        {eSimRegenerateStatus?.showConfirmModal && flexFlowServiceChange && (
          <RegenerateESimModal
            showModal={eSimRegenerateStatus?.showConfirmModal}
            setShowModal={(val) => setESimRegenerateStatus({ ...eSimRegenerateStatus, showConfirmModal: val })}
            onConfirmation={() => handleEsimGenerationCall()}
          />
        )}
        <LostStolenConfirmation
          isVisible={showLostStolenConfirmation}
          onSuccess={handleLostStolenConfirm}
          onCancel={handleLostStolenCancel}
          deviceId={lostStolenDeviceId}
          customerInfo={customerInfo}
        />
      </div>
    )
  );
};

DeviceSimID.defaultProps = {
  careUsingExistingSimNote:
    'Please access the following path in ACSS to complete an add a line order when the customer is using an existing device and SIM/eSIM: Devices tab> Links/Action> Add line/CPE(NSO)',
  eSimOstLinkUrl: 'https://infomanager.verizon.com/content/km/categories/features/353215.html',
  eSimOstLinkText: 'eSIM OST click ',
  esimEligibilityText:
    'This device is eSIM capable. Before completing a SIM only order, recommend eSIM activation to the customer',
  disableDeviceSimIdText: 'There is a pending order on this line. Cannot make changes to SIM or Device',
  simSwapNotificationHighRiskMsg:
    'SIM or SIM and Device change has been restricted. Direct the customer to self-serve online or to contact VZ Cust Protection at 888-483-7200',
};
DeviceSimID.propTypes = {
  cartDetails: PropTypes.shape({
    cart: PropTypes.shape({
      lineDetails: PropTypes.shape({
        lineInfo: PropTypes.array.isRequired,
      }),
    }),
  }),
  activeMtn: PropTypes.string,
  isNewlyAddedLine: PropTypes.bool,
  setCarrierLockDisableButton: PropTypes.func,
  careUsingExistingSimNote: PropTypes.string,
  eSimOstLinkUrl: PropTypes.string,
  eSimOstLinkText: PropTypes.string,
  disableDeviceSimIdText: PropTypes.string,
  simSwapNotificationHighRiskMsg: PropTypes.string,
  esimEligibilityText: PropTypes.string,
  setRemoveSimOnlyChange: PropTypes.func,
  setEnableBYODbtn: PropTypes.func,
  setIsESimRegenerated: PropTypes.func,
};

export default DeviceSimID;
