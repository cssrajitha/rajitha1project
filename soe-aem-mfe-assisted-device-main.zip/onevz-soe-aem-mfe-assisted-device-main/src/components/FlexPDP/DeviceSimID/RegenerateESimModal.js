import React from 'react';
import { Title } from '@vds/typography';
import { Modal, ModalFooter, ModalBody } from '@vds/modals';
import PropTypes from 'prop-types';

function RegenerateESimModal(props) {
  const { showModal, setShowModal, onConfirmation } = props;

  return (
    <Modal
      id='regenerate-esim-modal'
      surface='light'
      disableAnimation
      disableOutsideClick
      ariaLabel='Regenerate ESIM Modal'
      opened={showModal}
      closeButton={<div />}
    >
      <ModalBody>
        <Title size='medium' bold>
          A new eSIM will be generated. Proceed?
        </Title>
      </ModalBody>
      <ModalFooter
        buttonData={{
          primary: {
            width: '100%',
            children: 'Yes',
            onClick: () => onConfirmation(),
            'data-track': 'eSIMGenerated_Yes',
          },
          close: {
            width: '100%',
            children: 'No',
            onClick: () => setShowModal(false),
            'data-track': 'eSIMGenerated_No',
          },
        }}
      />
    </Modal>
  );
}
RegenerateESimModal.propTypes = {
  showModal: PropTypes.any,
  setShowModal: PropTypes.any,
  onConfirmation: PropTypes.any,
};

export default RegenerateESimModal;
