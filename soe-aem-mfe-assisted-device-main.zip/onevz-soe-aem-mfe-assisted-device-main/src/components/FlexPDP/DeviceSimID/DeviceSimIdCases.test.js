import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { fireEvent, render, screen, waitFor } from '../../../modules/test-utils/renderHelper';
import { CHANNELS, setupChannel, setUserAgentIPad } from '../../../modules/test-utils/utils';
import DeviceSimID from './DeviceSimID';
import cartDetails from '../../../pages/PDP/mocks/api/retrieveCart.json';
import customerProfileDetails from '../../../pages/PDP/mocks/api/customerProfile.json';
import getSkuDetails from '../../../pages/PDP/mocks/api/getSkuDetails.json';
import validateDeviceSimId from '../../../pages/PDP/mocks/api/validateDeviceSimidRes.json';
import validateDeviceEsim from '../../../pages/PDP/mocks/api/validateDeviceSimIdwithoutSimInfo2.json';

jest.setTimeout(100000);
jest.mock(
  'onevzsoemfecommon/Helpers',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getQueryParamByName: jest.fn(() => {}),
    getUIContextPath: jest.fn(() => {}),
    getUIContextPathBAU: jest.fn(() => {}),
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradleProperty: () => ['TRUE'],
    getAssistedCradlePropertyV2: () => ['TRUE'],
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => false,
  }),
  { virtual: true },
);
const details = getSkuDetails?.data?.deviceSku?.parentProducts[0];

const compatibleSims = details?.compatibleSimSorIds;
const updateCpeCheckboxFlag = jest.fn();
const propsDeviceIdDiff = {
  setMitekIdVerifyStatus: jest.fn(),
  deviceFromFilteredCartLine: {
    deviceId: '350496304834340',
    eDeviceId: '350496304834340',
  },
  simFromFilteredCartLine: {
    eSIM: '456789074683883838',
    simId: '456789074683883838',
  },
  isNewLine: false,
  isVideoAssistFlow: false,
  activeMtn: 'newLine1',
  isDWOS: false,
  isIndirect: false,
  compatibleSims,
  isBYODUpdateAALRetail: false,
  isCancel: jest.fn(),
  sku: '',
  byodDevice: '',
  isByodUpdate: 'true',
  deviceFromCart: false,
  isLocal: true,
  isFromCPE: false,
  defaultDeviceId: '353756110808409',
  defaultSimId: '89148000005700881964',
  customerProfileDetails: customerProfileDetails.data,
  cartDetails: cartDetails?.data,
  updateDeviceId: jest.fn(),
  updateSimId: jest.fn(),
  updateCpeCheckboxFlag,
  updateDeviceData: jest.fn(),
  setSimIdResult: jest.fn(),
  setEnableBYODbtn: jest.fn(),
  simSwapFlowUpdateButtonDisabled: jest.fn(),
  setIncompatibleSim: jest.fn(),
  setUpcCodeFromPdpScan: jest.fn(),
  setRemoveSimOnlyChange: jest.fn(),
};
const propsDeviceId = {
  deviceFromFilteredCartLine: {
    deviceId: '350496304834340',
    eDeviceId: '350496304834340',
  },
  simFromFilteredCartLine: {
    eSIM: '456789074683883838',
    simId: '456789074683883838',
  },
  lineDeviceIdFromLanding: '353756110808409',
  lineSimIdFromLanding: '97797897987987',
  isNewLine: false,
  isVideoAssistFlow: false,
  activeMtn: 'newLine1',
  isDWOS: false,
  isIndirect: false,
  compatibleSims,
  isBYODUpdateAALRetail: false,
  isCancel: jest.fn(),
  sku: '',
  byodDevice: '',
  isByodUpdate: false,
  deviceFromCart: false,
  isLocal: true,
  isFromCPE: false,
  defaultDeviceId: '353756110808409',
  defaultSimId: '89148000005700881964',
  customerProfileDetails: customerProfileDetails.data,
  cartDetails: cartDetails?.data,
  updateDeviceId: jest.fn(),
  updateSimId: jest.fn(),
  updateCpeCheckboxFlag,
  updateDeviceData: jest.fn(),
  setSimIdResult: jest.fn(),
  setEnableBYODbtn: jest.fn(),
  simSwapFlowUpdateButtonDisabled: jest.fn(),
  setIncompatibleSim: jest.fn(),
  setUpcCodeFromPdpScan: jest.fn(),
  setRemoveSimOnlyChange: jest.fn(),
};

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => true,
  }),
  { virtual: true },
);

const Test = (channel, validateDeviceSimidResponse, propsPassed) => {
  setupChannel(channel);
  const props = propsPassed;
  describe(`<DeviceSimID component - ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceSimidResponse));
      }),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });
    setUserAgentIPad();
    beforeEach(() => {
      render(<DeviceSimID {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });

    test('Device Scan testing by entering device Id', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      expect(deviceTextBox).toHaveValue('350669643749367');
    });
  });
};
const TestIDScanModal = (channel, validateDeviceSimidResponse, propsPassed) => {
  setupChannel(channel);
  const props = propsPassed;
  describe(`<DeviceSimID component - ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceSimidResponse));
      }),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      server.listen();
      class ResizeObserver {
        constructor() {
          this.observe = () => jest.fn();
          this.unobserve = () => jest.fn();
          this.disconnect = () => jest.fn();
        }
      }
      window.ResizeObserver = ResizeObserver;
    });
    afterAll(() => {
      server.close();
    });
    setUserAgentIPad();
    beforeEach(() => {
      render(<DeviceSimID {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });
    test('Sim Scan testing by entering sim Id', async () => {
      const simTextBox = await screen.getByRole('textbox', { name: 'Enter Sim ID' });
      fireEvent.change(simTextBox, { target: { value: '89148000005700881964' } });
      fireEvent.blur(simTextBox, { target: { value: '89148000005700881964' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      await waitFor(() => {
        const vaditeShop = screen.getAllByTestId('IdSecureScan')[0];
        expect(vaditeShop).toBeInTheDocument();
        fireEvent.click(vaditeShop);
      });
      const vaditeShop1 = await screen.getAllByTestId('Getdropdown')[0];
      expect(vaditeShop1).toBeInTheDocument();

      fireEvent.change(vaditeShop1, { target: { value: 'Exception Review' } });
      const reviewButton = screen.getByRole('button', { name: 'Review' });
      fireEvent.click(reviewButton);
      const proceedButton = screen.getByRole('button', { name: 'Proceed' });
      fireEvent.click(proceedButton);
      const noButton = screen.getByRole('button', { name: 'Yes' });
      fireEvent.click(noButton);
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
    });
    test('Sim Scan testing by entering sim Id', async () => {
      const simTextBox = await screen.getByRole('textbox', { name: 'Enter Sim ID' });
      fireEvent.change(simTextBox, { target: { value: '89148000005700881964' } });
      fireEvent.blur(simTextBox, { target: { value: '89148000005700881964' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      await waitFor(() => {
        const vaditeShop = screen.getAllByTestId('IdSecureScan')[0];
        expect(vaditeShop).toBeInTheDocument();
        fireEvent.click(screen.getByRole('button', { name: 'Testing Modal close' }));
      });
    });
  });
};
Test(CHANNELS.OMNI_RETAIL, validateDeviceSimId, propsDeviceId);
Test(CHANNELS.OMNI_INDIRECT, validateDeviceEsim, propsDeviceId);
TestIDScanModal(CHANNELS.OMNI_INDIRECT, validateDeviceEsim, propsDeviceIdDiff);
