import React from 'react';
import { render } from '../../../modules/test-utils/renderHelper';
import DeviceSimID from './DeviceSimID';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';

// DeviceSimID.test.js
jest.mock(
    'onevzsoemfeframework/AssistedCradleService',
    () => ({
      __esModule: true,
      ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
      getAssistedCradleProperty: () => ['TRUE', 'TRUE', '', '', '', '', '', 'TRUE'],
      getAssistedCradlePropertyV2: () => ['TRUE', 'TRUE', '', '', '', '', 'TRUE'],
    }),
    { virtual: true },
  );

describe('updateCareDataOnMountAndUpdate', () => {
  let props;

  beforeEach(() => {
    props = {
      isFromCPE: false,
      isByodUpdate: false,
      deviceSkuSelected: false,
      cartDetails: {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                mobileNumber: '1234567890',
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: [
                        { cartItemType: 'SIM', simId: 'SIM123', sorId: 'SOR123' },
                      ],
                    },
                  },
                ],
              },
            ],
          },
        },
      },
      updateDeviceData: jest.fn(),
      updateDeviceId: jest.fn(),
      updateSimId: jest.fn(),
      updateCpeCheckboxFlag: jest.fn(),
      setSimIdResult: jest.fn(),
      setEnableBYODbtn: jest.fn(),
      simSwapFlowUpdateButtonDisabled: jest.fn(),
      setIsSecNumValidation: jest.fn(),
      setIncompatibleSim: jest.fn(),
      setUpcCodeFromPdpScan: jest.fn(),
      setRemoveSimOnlyChange: jest.fn(),
      activeMtn: '1234567890',
      pendingOrderOnLine: false,
      isEditAndView: false,
      isByodUpdate: 'true',
      setSimSkuEntered: jest.fn(),
      setValidatedSimId: jest.fn(),
    };

    global.window = Object.create(window);
    if (window.mfe) {
        delete window.mfe; // Remove the existing property
      }
      Object.defineProperty(window, 'mfe', {
        value: { scmDeviceMfeEnable: true },
        configurable: true,
      });
      window.history.pushState(
        {},
        'Host',
        '/product-detail.html?simId=123456&deviceId=54321&scanFromLanding=true&prospectByodFlow=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7&isEditAndView=true&eSimOnlyDevice=true',
      );
      sessionStorage.setItem('enableSimValidation', false);
      render(<DeviceSimID {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
  });

  test('should set simSkuEntered and validatedSimId when cartItemFound is true', () => {
    render(<DeviceSimID {...props} />);

  });

  // test('should set validatedSimId to empty string when skipICCIDFFlag and hideSIMArea are true', () => {
  //   Object.defineProperty(window, 'mfe', {
  //     value: { scmDeviceMfeEnable: true, skipICCIDFFlag: true },
  //   });
  //   props.hideSIMArea = true;

  //   const { container } = render(<DeviceSimID {...props} />);
    

  //   expect(props.setSimSkuEntered).toHaveBeenCalledWith('SIM123');
  //   expect(props.setValidatedSimId).toHaveBeenCalledWith('');
  // });

  // test('should not set simSkuEntered or validatedSimId when cartItemFound is false', () => {
  //   props.cartDetails.cart.lineDetails.lineInfo = [];

  //   const { container } = render(<DeviceSimID {...props} />);
    

  //   expect(props.setSimSkuEntered).not.toHaveBeenCalled();
  //   expect(props.setValidatedSimId).not.toHaveBeenCalled();
  // });
});