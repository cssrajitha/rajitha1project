import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import { isIpad, executeShellFunction } from 'onevzsoemfeframework/DomService';
import { useDispatch } from 'react-redux';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import TimeoutManager from 'onevzsoemfecommon/TimeoutManager';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { Input } from '@vds/inputs';
import { Icon } from '@vds/icons';

const InputWrapper = styled.div`
  display: flex;
  align-items: center;
  width: ${({ scmDeviceEnable }) => (scmDeviceEnable ? '16rem' : '21rem')};
  padding-right: ${({ scmDeviceEnable }) => scmDeviceEnable && '5%'};
  div[id='deviceId'] > span > span > div[class^='InputTextWrapper'] > p {
    display: none;
  }
`;

const BarcodeIconWrapper = styled.div`
  display: flex;
  margin-top: 15px;
  padding-left: 15px;
`;

function UpcCodeScan(props) {
  const {
    upcCodeFromPdpScan,
    setUpcCodeFromPdpScan,
    handleUpcAndDeviceIdValidateCheck,
    setUpcAndDeviceIdCheckEnabled,
  } = props;
  const scmDeviceEnable = window?.mfe?.scmDeviceMfeEnable;
  const isDark = (window?.mfe?.scmDeviceMfeEnable && window?.mfe?.isDark) || false;
  const [isScanActive, setIsScanActive] = useState(false);
  const [upcCodeError, setUpcCodeError] = useState(false);
  const upcCodeErrorMsg = 'Please scan or enter a valid UPC code';
  const dispatch = useDispatch();
  const cleanUpEmitterFFlag = /true/i.test(getAssistedCradlePropertyV2(['cleanUpEmitterFFlag'])?.[0]);
  const timeoutManager = new TimeoutManager({ fileName: 'UpcCodeScan.js', enableFF: cleanUpEmitterFFlag });
  useEffect(() => {
    window.upcBarCodeScannerCallback = upcBarCodeScannerCallback;
    return () => {
      timeoutManager.clearAllTimeouts();
    };
  }, []);

  const upcBarCodeScannerCallback = (data) => {
    console.log(`upc barcode inside callback , ${JSON.stringify(data)}`);
    try {
      if (isIpad()) {
        if (data?.dataset?.barcode === 'cancel') {
          setIsScanActive(false);
        } else {
          const barcodeData = data?.dataset?.barcode.replace(/'/g, '"');
          const barcode = JSON.parse(barcodeData);
          console.log(
            `upc barcode inside callback barcode.UPC , ${JSON.stringify(data)} , ${barcode}, ${barcode?.UPC}`,
          );
          if (barcode?.UPC) {
            setUpcCodeFromPdpScan(barcode?.UPC);
            setIsScanActive(false);
            handleUpcAndDeviceIdValidateCheck(barcode?.UPC);
          }
        }
      }
    } catch (e) {
      console.log(`error in catch block, ${e}`);
    }
  };

  const scanUpcCodeBarCode = (e) => {
    const newLocal = 'upcCodeScanner';
    const isDeviceID = e?.currentTarget?.id === newLocal;
    let scanActive;
    if (isDeviceID) {
      setIsScanActive({
        isScanActive: !isScanActive,
      });
      scanActive = true;
    }
    if (e) e.preventDefault();
    /* istanbul ignore next */
    if (isIpad()) {
      const str = 'window.upcBarCodeScannerCallback';
      timeoutManager.scheduleTimeout(() => {
        if (scanActive) {
          executeShellFunction('HolsterManager', 'activateBarcodeUPC', str, null);
          timeoutManager.scheduleTimeout(() => {
            executeShellFunction('HolsterManager', 'deactivateBarcode', 'none', null);
          }, 20000);
        } else {
          executeShellFunction('HolsterManager', 'deactivateBarcode', 'none', null);
        }
      }, 100);
    }
  };

  const scanOnKeyPress = (e) => {
    if (e.charCode === 13 || e.charCode === 32) {
      scanUpcCodeBarCode();
    }
  };
  const handleUpcCodeChange = (e) => {
    const input = e.target.value.trim();
    setUpcCodeFromPdpScan(input);
    setUpcCodeError(false);
  };
  const handleUpcCodeOnBlurChange = (e) => {
    const input = e.target.value.trim();
    const inputRegEx = /^[a-zA-Z0-9]{12}$/;
    const isValid = inputRegEx.test(input);
    if (input?.length === 12) {
      handleUpcAndDeviceIdValidateCheck(input);
    }
    setUpcCodeFromPdpScan(input);
    setUpcCodeError(false);
    if (!isValid) {
      setUpcAndDeviceIdCheckEnabled(true);
      dispatch(
        appMessageActions.addAppMessage(
          `${input} was scanned, please enter or scan a valid UPC code`,
          'error',
          true,
          true,
        ),
      );
    }
  };
  return (
    <div data-testid='upc-scan' className='contains-PII'>
      <InputWrapper scmDeviceEnable={scmDeviceEnable}>
        <Input
          type='text'
          iconName=''
          name='upcCode'
          id='upcCode'
          data-testid='upcCodeTestId'
          value={upcCodeFromPdpScan}
          placeholder='Enter UPC Code'
          surface={isDark ? 'dark' : 'light'}
          label='Enter UPC Code'
          autoComplete='off'
          onChange={(e) => handleUpcCodeChange(e)}
          onBlur={(e) => (e.target.value.trim() === '' ? setUpcCodeError(true) : handleUpcCodeOnBlurChange(e))}
          error={upcCodeError}
          errorText={upcCodeError ? upcCodeErrorMsg : ''}
        />
        <BarcodeIconWrapper>
          <span
            data-testid='upcCodeScannerId'
            style={{
              cursor: 'default',
              'pointer-events': 'auto',
            }}
            tabIndex='0'
            aria-label='scanner'
            role='button'
            onClick={(e) => {
              scanUpcCodeBarCode(e);
            }}
            onKeyPress={(e) => scanOnKeyPress(e)}
            id='upcCodeScanner'
            data-track='upc_code_scan'
          >
            <Icon name='barcode' lineColor={isScanActive ? '#0096E4' : '#000000'} size='XLarge' />
          </span>
        </BarcodeIconWrapper>
      </InputWrapper>
    </div>
  );
}
UpcCodeScan.propTypes = {
  upcCodeFromPdpScan: PropTypes.string,
  setUpcCodeFromPdpScan: PropTypes.func,
  handleUpcAndDeviceIdValidateCheck: PropTypes.func,
  setUpcAndDeviceIdCheckEnabled: PropTypes.func,
};
export default UpcCodeScan;
