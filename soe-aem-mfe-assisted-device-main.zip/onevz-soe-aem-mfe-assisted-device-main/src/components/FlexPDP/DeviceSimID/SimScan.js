import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import { useDispatch } from 'react-redux';
import PropTypes from 'prop-types';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import {
  getQueryParamByName,
  isIpad,
  executeShellFunction,
  isRetail,
  isAsurion,
  isD2D,
} from 'onevzsoemfeframework/DomService';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import TimeoutManager from 'onevzsoemfecommon/TimeoutManager';
import { Input } from '@vds/inputs';
import { Icon } from '@vds/icons';
import { Checkbox } from '@vds/checkboxes';
import IDScanModal from '../IDScanSecurity/IDScanModal';

const InputWrapper = styled.div`
  display: flex;
  align-items: center;
  width: 21rem;
  div[id='simId'] > span > span > div[class^='InputTextWrapper'] > p {
    display: none;
  }
  padding-bottom: 15px;
`;
const BarcodeIconWrapper = styled.div`
  display: flex;
  margin-top: 15px;
  padding-left: 15px;
   pointer-events: ${(props) => (props?.clickable ? 'none' : 'auto')};
`;

const DivWrapper = styled.div`
  display: block;
`;

const ESimRegenerateMessage = styled.div`
  font-size: small !important;
`;

const dfillSimsArr = [
  'BULKSIM-TRI-A',
  'BULKSIMTRI-A',
  'DFILLSIM-TRI-A',
  'BULKSIMTRI-D',
  'BULKSIM-TRI-D',
  'BULKSIMTRI-S',
  'BULKSIM-TRI-S',
  'EMBDSIMTRI',
  'DFILLSIM4FF-D',
  'DFILLSIM4FF-S',
  'BULKSIM4FF-A',
  'BULK2SIM4FF-A',
  'BULK2SIM4FF-S',
  'BULKSIM4FF-S',
  'DFILLSIM4FF-A',
  'BULKSIM4FF-D',
  'BULK2SIM4FF-D',
];

const SimScan = (props) => {/* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */
  const {
    lineInfo,
    isLocal,
    simDisabled,
    showScanner,
    activeMtn,
    validateDeviceSimIdRequest,
    deviceInfo,
    validateDeviceSimRequest,
    isPaymentOptionVisible,
    isSecondNumberFlow,
    flexFlowServiceChange,
    simType,
    showESimRegenerateMessage,
  } = props;
  const [simId, setSimId] = useState('');
  const [isScanActive, setScanActive] = useState(false);
  const [simError, setSimError] = useState(false);
  const [cpSimCard, setCpSimCard] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const dispatch = useDispatch();
  const simErrorMsg = showScanner ? 'Please scan or enter a valid SIM ID' : 'Please enter a valid SIM ID';
  const [isMitekSimSwapEnabled] = getAssistedCradlePropertyV2(['isMitekSimSwapEnabled']);
  const checkisMitek = /true/i.test(isMitekSimSwapEnabled) && deviceInfo?.invokeIdScan === 'Y' && isIpad();
  const isDark = (window?.mfe?.scmDeviceMfeEnable && window?.mfe?.isDark) || false;
  const isAsurionExpansionEnabled = isAsurion();
  let disableSIMDetailsForAsurion = false;
  if (isAsurionExpansionEnabled && !props?.isNewlyAddedLine && props?.isByodUpdate) {
    disableSIMDetailsForAsurion = true;
  }
  const cleanUpEmitterFFlag = /true/i.test(getAssistedCradlePropertyV2(['cleanUpEmitterFFlag'])?.[0]);
  const esimAPIskipFFlag = /true/i.test(getAssistedCradlePropertyV2(['esimAPIskipFFlag'])?.[0]);
  const timeoutManager = new TimeoutManager({ fileName: 'SimScan.js', enableFF: cleanUpEmitterFFlag });
  let device;
  let showCPSim = props.fromInterim !== true;
  if (props?.hideCPSim) showCPSim = false; // for 5g devices no need to show checkbox

  useEffect(() => {
    const isBuyoutEligible = lineInfo?.equipmentUpgradeEligibility?.buyoutEligible || false;
    if (isLocal && !props.simId && !props.isDeviceBuyout && !isBuyoutEligible) {
      console.log(
        'point-1 - ComponentDidMount - b4 calling scanner func props.isLocal , props.simId',
        isLocal,
        props.simId,
      );
    }
    setSimId(props.simId ? props.simId : '');
    return () => {
      timeoutManager.clearAllTimeouts();
    };
  }, [props.simId]);
  useEffect(() => {
    const Flowtype = validateDeviceSimRequest?.data?.lines?.[0]?.device?.Flowtype;
    props?.simSwapFlowUpdateButtonDisabled(false);
    if (
      deviceInfo?.invokeIdScan === 'Y' &&
      /true/i.test(isMitekSimSwapEnabled) &&
      isIpad() &&
      !isPaymentOptionVisible &&
      Flowtype === 'SIM'
    ) {
      if (simId !== '') {
        setIsModalOpen(true);
      }
    }
    // simId !== '' && setIsModalOpen(true);
  }, [props?.deviceInfo]);

  const inputSimRegEx = /^\d{19,20}$/;

  const simIdBarCodeScannerCallback = (data) => {
    console.log(`simscan -1 - inside callback , ${JSON.stringify(data)}`);
    try {
      if (isIpad()) {
        if (data.dataset.barcode === 'cancel') {
          setScanActive(false);
        } else {
          const barcodeData = data.dataset.barcode.replace(/'/g, '"');
          const barcode = JSON.parse(barcodeData);
          console.log(
            `simscan -1a - ,data , barcode ,barcode.MEID ,barcode.ICCID , ${JSON.stringify(data)} , ${barcode}, ${
              barcode?.ICCID
            }`,
          );
          if (barcode.ICCID) {
            console.log(
              `devicescan -2 - ,data , barcode ,barcode.MEID ,barcode.ICCID , ${JSON.stringify(data)} , ${barcode} , ${
                barcode?.ICCID
              }`,
            );
            const scanBarcodenumber = barcode.ICCID ?? '';
            setSimId(scanBarcodenumber);
            setSimError(false);
            setScanActive(false);
            callValidateDeviceAndSIM(scanBarcodenumber);
          }
        }
      } else {
        // handled desktop scan data
        handleChangeSimIDDesktop(data);
      }
    } catch (e) {
      console.log(`error in catch block, ${e}`);
    }
  };

  const handleChangeSimID = (e) => {
    const input = e.target.value.trim();
    setSimId(input);
    if ((simId !== input) && flexFlowServiceChange) {
      props.setSimInputChangedIpad(true);
      props.setSimValueIpad(input);
    }
    /* istanbul ignore next */
    // No else statement to cover
    if (!isSecondNumberFlow || ((simId !== input) && flexFlowServiceChange)) {
      props.handleChangeSimID(e);
    }
  };

  const handleOnBlurSimID = (e, ivrSimId) => {
    const input = ivrSimId || e.target.value.trim();
    const isValid = inputSimRegEx.test(input);
    if (isValid) {
      setSimId(input);
      callValidateDeviceAndSIM();
    } else if (dfillSimsArr.includes(input.toUpperCase())) {
      setSimId(input);
      props.updateDfillSimId(input);
    } else {
      setSimError(!isValid);
    }
  };

  const onCheckBoxChange = (e) => {
    const cpSimCardChecked = e.target.checked;
    // if ipad retail videoassist, set hideISPUForVA in pdp redux
    if (props.isVideoAssistFlow && isRetail() && isIpad()) {
      props.updateShowISPUForVA(!cpSimCardChecked);
    }
    setCpSimCard(cpSimCardChecked);
  };

  useEffect(() => {
    /**
     * call validate function again on checkbox change
     * so that store will get updated
     */
    const isValid = inputSimRegEx.test(simId);
    if (isValid) {
      callValidateDeviceAndSIM();
    }
  }, [cpSimCard]);

  const scanSimIdBarCode = (e) => {
    window.simIdBarCodeScannerCallback = simIdBarCodeScannerCallback;
    setScanActive({
      isScanActive: !isScanActive,
    });

    if (e) e.preventDefault();

    if (isIpad()) {
      const str = 'window.simIdBarCodeScannerCallback';
      timeoutManager.scheduleTimeout(() => {
        if (isScanActive && window.simIdBarCodeScannerCallback) {
          console.log('point-3-  inside scanSimIdBarCode - b4 calling shell - isScanActive', isScanActive);
          executeShellFunction('HolsterManager', 'activateBarcodeICCID', str, null);
          /* istanbul ignore next */
          timeoutManager.scheduleTimeout(() => {
            executeShellFunction('HolsterManager', 'deactivateBarcode', 'none', null);
          }, 20000);
        } else {
          console.log(
            'point-4 - inside scanSimIdBarCode - else condition shell not called - isScanActive',
            isScanActive,
          );
          executeShellFunction('HolsterManager', 'deactivateBarcode', 'none', null);
        }
      }, 100);
    } else {
      // desktop: set callback function first, then init scanner events for barcode scanning

      device?.barcodeScan?.registerBarcodeCallback(simIdBarCodeScannerCallback);
      device?.barcodeScan?.scanBarcode();
    }
  };

  const handleChangeSimIDDesktop = (data) => {
    props.handleChangeSimID(data);
    setSimId(data);
    setSimError(false);
    setScanActive(false);

    callValidateDeviceAndSIM();
  };

  const scanOnKeyPress = (e) => {
    if (e.charCode === 13 || e.charCode === 32) {
      scanSimIdBarCode();
    }
  };

  const callValidateDeviceAndSIM = (barcode) => {
    const fromCpe = props?.fromCpe ? props?.fromCpe : false;
    const fromInterim = props?.fromInterim ? props?.fromInterim : false;
    const isCustomerProvidedEquipment = props?.isCustomerProvidedEquipment ? props?.isCustomerProvidedEquipment : false;

    validateDeviceSimIdRequest({
      mtn: activeMtn,
      deviceId: props.deviceId,
      simId: barcode || simId || props.simId,
      flowType: 'SIM',
      cpSimCard,
      fromCpe,
      isCustomerProvidedEquipment,
      fromInterim,
      offerEligible: getQueryParamByName('offerEligible'),
      activeMtn: getQueryParamByName('activeMtn') || activeMtn,
    });
    /* istanbul ignore next */
    if (flexFlowServiceChange) {
      props.setSimInputChangedIpad(true);
      const updateSIMValue = barcode || simId || props.simId;
      props.setSimValueIpad(updateSIMValue);
    }
  };
  const closeModal = () => {
    setIsModalOpen(false);
  };
  const handleModelChange = (data) => {
    setIsModalOpen(data);
    dispatch(appMessageActions.clearAppMessages());
    dispatch(appMessageActions.addAppMessage('Sim ID is updated successfully', 'success', true, false));
  };

  const isScannerDisabled = () => {
    return props?.isProvisionalId || (flexFlowServiceChange && simType === 'eSIM');
  };

  return (
    <div data-testid='sim-scan' className='contains-PII'>
      {!isSecondNumberFlow && (
        <>
          <InputWrapper>
            <Input
              type='text'
              iconName=''
              name='simId'
              id='simId'
              data-testid='handleChangeSimID'
              placeholder='Enter Sim ID'
              value={simId}
              onChange={(e) => handleChangeSimID(e)}
              onBlur={(e) => (e.target.value.trim() === '' ? setSimError(true) : handleOnBlurSimID(e))}
              error={simError}
              errorText={simError ? simErrorMsg : ''}
              label='Enter Sim ID'
              required
              disabled={simDisabled || disableSIMDetailsForAsurion || props.isDisabled || (flexFlowServiceChange && simType === 'eSIM')}
              surface={isDark ? 'dark' : 'light'}
              data-track='Productdetail_simId'
            />
            {showScanner && !isAsurionExpansionEnabled && !isD2D() && (
              <BarcodeIconWrapper clickable ={isScannerDisabled()}>
                {checkisMitek && simDisabled ? (
                  <span data-testid='scanSimIdBarCode'>
                    <Icon name='barcode' size='32' lineColor='#d8dada' />
                  </span>
                ) : (
                  <span
                    data-testid='scanSimIdBarCode'
                    tabIndex='0'
                    aria-label='scanner'
                    role='button'
                    disable={isScannerDisabled()}
                    onClick={() => scanSimIdBarCode()}
                    onKeyPress={(e) => scanOnKeyPress(e)}
                    data-track='Productdetail_scanSimIdBarCode'
                  >
                    <Icon name='barcode' size='XLarge' lineColor={isScanActive ? '#0096E4' : '#000000'} />
                  </span>
                )}
              </BarcodeIconWrapper>
            )}{' '}
          </InputWrapper>
          {showESimRegenerateMessage && esimAPIskipFFlag && flexFlowServiceChange && (
            <ESimRegenerateMessage data-testid='esim-regenerate-message-simscan'>
              eSIM will populate post activation
            </ESimRegenerateMessage>
          )}
        </>
      )}

      {isModalOpen && (
        <IDScanModal
          isOpen={isModalOpen}
          handleGetUpdateOldSimId={props.handleGetUpdateOldSimId}
          handleModelChange={handleModelChange}
          correlationId={props?.correlationId}
          closeModal={closeModal}
          simswapSessionId={deviceInfo?.simswapSessionId}
          cartDetails={props?.cartDetails}
          customerProfileDetails={props?.customerProfileDetails}
          activeMtn={activeMtn || getQueryParamByName('activeMtn')}
          setMitekIdVerifyStatus={props?.setMitekIdVerifyStatus}
        />
      )}

      {showCPSim && (
        <DivWrapper>
          <Checkbox
            type='checkbox'
            name='CPSim Confirmation'
            disabled={(checkisMitek && simDisabled) || disableSIMDetailsForAsurion||props?.isProvisionalId}
            selected={cpSimCard}
            onChange={(e) => onCheckBoxChange(e)}
            surface={isDark ? 'dark' : 'light'}
            label='This SIM card is customer-provided equipment'
            data-track='Productdetail_CPSim Confirmation'
          />
        </DivWrapper>
      )}
    </div>
  );
};
SimScan.propTypes = {
  cartDetails: PropTypes.object,
  fromInterim: PropTypes.bool,
  hideCPSim: PropTypes.bool,
  showESimRegenerateMessage: PropTypes.bool,
  flexFlowServiceChange: PropTypes.bool,
};
export default SimScan;
