import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import { isVbg } from 'onevzsoemfeframework/VbgAemUtil';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { fireEvent, render, screen, waitFor } from '../../../modules/test-utils/renderHelper';
import { CHANNELS, setupChannel } from '../../../modules/test-utils/utils';
import DeviceSimID from './DeviceSimID';
import cartDetails from '../../../pages/PDP/mocks/api/retrieveCart.json';
import customerProfileDetails from '../../../pages/PDP/mocks/api/customerProfile.json';
import getSkuDetails from '../../../pages/PDP/mocks/api/getSkuDetails.json';
import validateDeviceSimId from '../../../pages/PDP/mocks/api/validateDeviceSimId.json';

jest.mock('onevzsoemfeframework/VbgAemUtil', () => ({
  __esModule: true,
  ...jest.requireActual('onevzsoemfeframework/VbgAemUtil'),
  isVbg: jest.fn(),
}));

jest.mock(
  'onevzsoemfecommon/Helpers',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getQueryParamByName: jest.fn(() => ({
      isEditAndView: true,
    })),
    getUIContextPath: jest.fn(() => {}),
    getUIContextPathBAU: jest.fn(() => {}),
    isNumeric: jest.fn(() => {}),
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => true,
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    rfexMfeFlowFlag: () => false,
    // Add other common functions as needed
    getQueryParamByName: () => '',
    getFFlag: () => false,
    formatPhoneNumber: (phone) => phone,
    // Add more mock functions if needed by the tests
  }),
  { virtual: true },
);

jest.mock(
  '../../../modules/services/APIService/APIServiceHooks',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('../../../modules/services/APIService/APIServiceHooks'),
      useLazyDeviceInventoryStatusCheckQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'fulfilled',
              data: {
                status: 'success',
                data: {
                  isDeviceAvailableInStoreInventory: true,
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
    };
  },
  { virtual: true },
);
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradleProperty: () => [''],
    getAssistedCradlePropertyV2: () => ['TRUE','TRUE'],
  }),
  { virtual: true },
);

// Helper function to find device input with fallback strategies
const findDeviceInput = async () => {
  // Try test ID first
  let deviceInput = screen.queryByTestId('handleChangeDeviceID');
  if (deviceInput) return deviceInput;

  // Try flexible role/name matching
  try {
    deviceInput = await screen.findByRole('textbox', {
      name: /Enter.*Device/i,
    });
    if (deviceInput) return deviceInput;
  } catch (error) {
    // Continue to next strategy
  }

  // Try finding by attributes
  const inputs = screen.getAllByRole('textbox');
  deviceInput = inputs.find(
    (input) =>
      input.getAttribute('name')?.includes('device') ||
      input.getAttribute('placeholder')?.toLowerCase().includes('device') ||
      input.getAttribute('id')?.includes('device'),
  );

  return deviceInput;
};

const Test = (channel, flag) => {
  setupChannel(channel);
  const details = getSkuDetails?.data?.deviceSku?.parentProducts[0];

  const compatibleSims = details?.compatibleSimSorIds;
  const updateCpeCheckboxFlag = jest.fn();
  

  describe(`<DeviceSimID component - ${ channel }`, () =>
  {
    const props = {
      setRemoveSimOnlyChange: jest.fn(),
      lineDeviceIdFromLanding: '353756110808409',
      isNewLine: false,
      isVideoAssistFlow: false,
      activeMtn: '5185673926',
      isDWOS: false,
      isIndirect: false,
      compatibleSims,
      isBYODUpdateAALRetail: false,
      isCancel: jest.fn(),
      setSecondNumDeviceId: jest.fn(),
      sku: '',
      byodDevice: '',
      isByodUpdate: false,
      deviceFromCart: false,
      isLocal: true,
      isFromCPE: false,
      defaultDeviceId: '353756110808409',
      defaultSimId: '89148000005700881964',
      customerProfileDetails: customerProfileDetails.data,
      cartDetails: cartDetails?.data?.data,
      updateDeviceId: jest.fn(),
      updateSimId: jest.fn(),
      updateCpeCheckboxFlag,
      updateDeviceData: jest.fn(),
      setSimIdResult: jest.fn(),
      setEnableBYODbtn: jest.fn(),
      simSwapFlowUpdateButtonDisabled: jest.fn(),
      setIsSecNumValidation: jest.fn(),
      setIncompatibleSim: jest.fn(),
      setUpcCodeFromPdpScan: jest.fn(),
      setCarrierLockDisableButton: jest.fn(),
    };
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceSimId));
      }),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      sessionStorage.setItem('Qualification_type', 'CBD');
      window.mfe = {};
      isVbg.mockReturnValue(true);
      render(<DeviceSimID {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });


    test('Device Scan testing by entering device Id', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      expect(deviceTextBox).toHaveValue('350669643749367');
    });
  }); 
  
  describe(`<DeviceSimID component - ${ channel }`, () =>
  {
    const props = {
      setRemoveSimOnlyChange: jest.fn(),
      lineDeviceIdFromLanding: '353756110808409',
      isNewLine: false,
      isVideoAssistFlow: false,
      activeMtn: '5185673789',
      isDWOS: false,
      isIndirect: false,
      compatibleSims,
      isBYODUpdateAALRetail: false,
      isCancel: jest.fn(),
      setSecondNumDeviceId: jest.fn(),
      sku: '',
      byodDevice: '',
      isByodUpdate: false,
      deviceFromCart: false,
      isLocal: true,
      isFromCPE: false,
      defaultDeviceId: '353756110808409',
      defaultSimId: '89148000005700881964',
      customerProfileDetails: customerProfileDetails.data,
      cartDetails: cartDetails?.data?.data,
      updateDeviceId: jest.fn(),
      updateSimId: jest.fn(),
      updateCpeCheckboxFlag,
      updateDeviceData: jest.fn(),
      setSimIdResult: jest.fn(),
      setEnableBYODbtn: jest.fn(),
      simSwapFlowUpdateButtonDisabled: jest.fn(),
      setIsSecNumValidation: jest.fn(),
      setIncompatibleSim: jest.fn(),
      setUpcCodeFromPdpScan: jest.fn(),
      setCarrierLockDisableButton: jest.fn(),
    };
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceSimId));
      }),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      sessionStorage.setItem('Qualification_type', 'CBD');
      window.mfe = {};
      isVbg.mockReturnValue(true);
      render(<DeviceSimID {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });


    test('Device Scan testing by entering device Id', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      expect(deviceTextBox).toHaveValue('350669643749367');
    });
  }); 
};

Test(CHANNELS.OMNI_RETAIL);
