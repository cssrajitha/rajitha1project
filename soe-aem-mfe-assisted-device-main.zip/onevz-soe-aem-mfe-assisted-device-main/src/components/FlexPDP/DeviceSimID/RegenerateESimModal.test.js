import React from 'react';
import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import { CHANNELS, setupChannel } from '../../../modules/test-utils/utils';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import RegenerateESimModal from './RegenerateESimModal';

const Test = (channel) => {
  setupChannel(channel);

  describe('Regenerate eSim', () => {
    beforeAll(() => {
      class ResizeObserver {
        constructor() {
          this.observe = () => jest.fn();
          this.unobserve = () => jest.fn();
          this.disconnect = () => jest.fn();
        }
      }
      window.ResizeObserver = ResizeObserver;
    });
    it('should test Regenerate eSim Modal', () => {
      render(<RegenerateESimModal showModal setShowModal={() => {}} onConfirmation={() => {}} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      const title = screen.getByText('A new eSIM will be generated. Proceed?');
      expect(title).toBeInTheDocument();
    });
    it('should test Regenerate eSim Modal', () => {
      render(<RegenerateESimModal showModal setShowModal={() => {}} onConfirmation={() => {}} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      const title = screen.getByText('A new eSIM will be generated. Proceed?');
      expect(title).toBeInTheDocument();
      const yesBtn = screen.getByRole('button', { name: 'Yes' });
      expect(yesBtn).toBeInTheDocument();
      fireEvent.click(yesBtn);
      const noBtn = screen.getByRole('button', { name: 'No' });
      expect(noBtn).toBeInTheDocument();
      fireEvent.click(noBtn);
    });
  });
};
Test(CHANNELS.OMNI_RETAIL);
