import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import Emitter from 'onevzsoemfeframework/Emitter';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import { CHANNELS, setupChannel } from '../../../modules/test-utils/utils';
import DeviceSimID from './DeviceSimID';
import cartDetails from '../../../pages/PDP/mocks/api/retrieveCart.json';
import customerProfileDetails from '../../../pages/PDP/mocks/api/customerProfile.json';
import getSkuDetails from '../../../pages/PDP/mocks/api/getSkuDetails.json';
import omniCareCustomerProfileDetails from '../../../pages/PDP/mocks/api/omniCareCustomerProfile.json';
import validateDeviceSimId from '../../../pages/PDP/mocks/api/validateDeviceSimId.json';
import validateDeviceEsim from '../../../pages/PDP/mocks/api/validateDeviceEsim.json';
import eSimDetails from '../../../pages/PDP/mocks/api/eSimDetails.json';
import validateDeviceByod from '../../../pages/PDP/mocks/api/validateDeviceByod.json';
import validateDeviceAct from '../../../pages/PDP/mocks/api/validateDeviceAct.json';
import validateDeviceSimSamsung from '../../../pages/PDP/mocks/api/validateDeviceSimSamsung.json';
import validateDeviceCpe from '../../../pages/PDP/mocks/api/validateDeviceCpe.json';
import { validateDeviceSimIDInitial } from '../../../pages/PDP/mocks/api/validateDeviceSimIDESimRegen';

jest.mock(
  'onevzsoemfecommon/Helpers',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getQueryParamByName: jest.fn(() => ({
      isEditAndView: true,
    })),
    getUIContextPath: jest.fn(() => {}),
    getUIContextPathBAU: jest.fn(() => {}),
    isNumeric: jest.fn(() => {}),
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    getQueryParamByName: (val) => {
      if (val === 'etrServiceChanges') return true;
      if (val === 'simId') return '89148000009101017319';
      if (val === 'deviceId') return '352766390095123';
    },
    isIpad: () => true,
    isAsurion: () => true,
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

jest.mock(
  '../../../modules/services/APIService/APIServiceHooks',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('../../../modules/services/APIService/APIServiceHooks'),
      useLazyDeviceInventoryStatusCheckQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'fulfilled',
              data: {
                status: 'success',
                data: {
                  isDeviceAvailableInStoreInventory: true,
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
    };
  },
  { virtual: true },
);
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradleProperty: () => [''],
    getAssistedCradlePropertyV2: () => ['TRUE'],
  }),
  { virtual: true },
);

const SkuDetailsResult = {
  isSuccess: true,
  isFetching: false
}

const Test = (channel) => {
  setupChannel(channel);
  const details = getSkuDetails?.data?.deviceSku?.parentProducts[0];

  const compatibleSims = details?.compatibleSimSorIds;
  const updateCpeCheckboxFlag = jest.fn();
  const props = {
    setRemoveSimOnlyChange: jest.fn(),
    lineDeviceIdFromLanding: '353756110808409',
    isNewLine: false,
    isVideoAssistFlow: false,
    activeMtn: '5185673926',
    isDWOS: false,
    isIndirect: false,
    compatibleSims,
    isBYODUpdateAALRetail: false,
    isCancel: jest.fn(),
    setSecondNumDeviceId: jest.fn(),
    sku: '',
    byodDevice: '',
    isByodUpdate: false,
    deviceFromCart: false,
    isLocal: true,
    isFromCPE: false,
    defaultDeviceId: '353756110808409',
    defaultSimId: '89148000005700881964',
    customerProfileDetails: customerProfileDetails.data,
    cartDetails: cartDetails?.data?.data,
    updateDeviceId: jest.fn(),
    updateSimId: jest.fn(),
    updateCpeCheckboxFlag,
    updateDeviceData: jest.fn(),
    setSimIdResult: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    simSwapFlowUpdateButtonDisabled: jest.fn(),
    setIsSecNumValidation: jest.fn(),
    setIncompatibleSim: jest.fn(),
    setUpcCodeFromPdpScan: jest.fn(),
    setCarrierLockDisableButton: jest.fn(),
    SkuDetailsResult,
  };

  describe(`<DeviceSimID component - ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceSimId));
      }),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      window.mfe = {};
      render(<DeviceSimID {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });

    test('DeviceSimID Component to be rendered on screen', async () => {
      Emitter.emit('CONT_SIM_SKU_VALIDATION', 'sku5600273');
      // const DeviceSimIDLoad = screen.getByTestId('DeviceSimID');
      // expect(DeviceSimIDLoad).toBeInTheDocument();
    });

    test('Find by DeviceId text', () => {
      const deviceIdText = screen.getByText('Enter Device ID');
      expect(deviceIdText).toBeInTheDocument();
      const simIdText = screen.getByText('Enter Sim ID');
      expect(simIdText).toBeInTheDocument();
    });

    test('Device Scan testing by entering device Id', async () => {
      jest.setTimeout(5000);
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      expect(deviceTextBox).toHaveValue('350669643749367');
    });

    test('Device Scan testing by entering incorrect device Id ', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '35066964374936' } });
      fireEvent.blur(deviceTextBox, { target: { value: '35066964374936' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      expect(deviceTextBox).toHaveValue('35066964374936');
    });

    test('Device Scan testing by entering device Id with string', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: 'abc' } });
      fireEvent.blur(deviceTextBox, { target: { value: 'abc' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
    });
    test('Device Scan testing by entering device Id with string', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '1' } });
      fireEvent.change(deviceTextBox, { target: { value: '' } });
      fireEvent.blur(deviceTextBox, { target: { value: '' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
    });
    test('Sim Scan testing by entering sim Id', async () => {
      const simTextBox = await screen.getByRole('textbox', { name: 'Enter Sim ID' });
      fireEvent.change(simTextBox, { target: { value: '8' } });
      fireEvent.change(simTextBox, { target: { value: '' } });
      fireEvent.blur(simTextBox, { target: { value: '' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      expect(simTextBox).toHaveValue('');
    });
    test('Sim Scan testing by entering sim Id', async () => {
      window.mfe = { scmDeviceMfeEnable: true };
      const simTextBox = await screen.getByRole('textbox', { name: 'Enter Sim ID' });
      fireEvent.change(simTextBox, { target: { value: '89148000005700881963' } });
      fireEvent.blur(simTextBox, { target: { value: '89148000005700881963' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      expect(simTextBox).toHaveValue('89148000005700881963');
    });

    test('Sim Scan testing by entering sim Id', async () => {
      const simTextBox = await screen.getByRole('textbox', { name: 'Enter Sim ID' });
      fireEvent.change(simTextBox, { target: { value: 'BULKSIMTRI' } });
      fireEvent.blur(simTextBox, { target: { value: 'BULKSIMTRI' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      expect(simTextBox).toHaveValue('BULKSIMTRI');
    });

    test('Sim Scan testing by entering Dfill sim sku', async () => {
      const simTextBox = await screen.getByRole('textbox', { name: 'Enter Sim ID' });
      fireEvent.change(simTextBox, { target: { value: 'BULKSIMTRI-A' } });
      fireEvent.blur(simTextBox, { target: { value: 'BULKSIMTRI-A' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      expect(simTextBox).toHaveValue('BULKSIMTRI-A');
    });
  });
  describe(`<DeviceSimID component 1- ${channel}`, () => {
    const validateDeviceByod1 = {
      status: 'rejected',
      errors: [{ message: 'Sim is not compatible with the selected Device' }],
    };
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(400), ctx.json(validateDeviceByod1));
      }),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });
    const byodProps = { ...props, isByodUpdate: false };

    beforeEach(() => {
      Emitter.emit('CONT_SIM_SKU_VALIDATION', 'sku5600273');
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });

    test('Device Scan testing by entering device Id', async () => {
      delete window.location;
      window.location = new URL(
        '/product-detail.html?simId=123456&deviceId=54321&isEditAndView=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7',
        'http://localhost:3000/content/vcg/assisted',
      );
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      expect(deviceTextBox).toHaveValue('350669643749367');
    });
    test('Device Scan testing by entering wrong device Id', async () => {
      delete window.location;
      window.location = new URL(
        '/product-detail.html?simId=123456&deviceId=54321&isEditAndView=false&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7',
        'http://localhost:3000/content/vcg/assisted',
      );
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      expect(deviceTextBox).toHaveValue('350669643749367');
      // const textLink = await screen.getAllByTestId('regenerateESim');
      // expect(textLink[0]).toBeInTheDocument();
      // expect(textLink[0]).not.toBeDisabled();
      // fireEvent.click(textLink[0]);
      // const title = screen.getByText('A new eSIM will be generated. Proceed?');
      // expect(title).toBeInTheDocument();
      // const yesBtn = screen.getAllByRole('button', { name: 'Yes' });
      // expect(yesBtn[0]).toBeInTheDocument();
      // fireEvent.click(yesBtn[0]);
      // fireEvent.click(textLink[0]);
      // const noBtn = screen.getAllByRole('button', { name: 'No' });
      // expect(noBtn[0]).toBeInTheDocument();
      // fireEvent.click(noBtn[0]);
    });
  });
  describe(`DeviceSimID component fraud risk enabled- ${channel} with auth - low risk`, () => {
    const callValidateDeviceSku = jest.fn();
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => res(ctx.status(200), ctx.json(validateDeviceByod))),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
      rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
        res(
          ctx.status(200),
          ctx.json({
            responseInfo: {
              errors: [],
              timeStamp: '15-11-2024 05:12:07',
              correlationId: 'smock_enforce_test',
              responseCode: '00',
              responseMessage: 'SUCCESS',
            },
            data: {
              sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
              custId: '0725665601',
              acctNum: '1',
              fraudRiskScore: '0',
              fraudRiskLevel: 'Low Risk',
              loa: '0',
              mdn: '2153709209',
              notificationIndicator: 'Y',
              invokeIdScan: 'N',
            },
            status: 'fulfilled',
          }),
        ),
      ),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      window.mfe = { scmDeviceMfeEnable: true, isDark: true };
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      props.omnicaredropdownValue = 'Provisional ID';
      props.isNewlyAddedLine = false;
      sessionStorage.setItem('enableSimValidation', 'false');
      sessionStorage.setItem('SECURE_SIM_SWAP', 'Y');
      const byodProps = {
        ...props,
        isLocal: false,
        isFromCPE: false,
        isByodUpdate: false,
        isRetail: false,
        omnicaredropdownValue: 'Provisional ID',
        deviceIdSelected: true,
        simSwapNotify: 'Y',
        enableEnforceApi: 'Y',
      };
      byodProps.omnicaredropdownValue = 'Provisional ID';

      byodProps.customerProfileDetails.customer.channel = 'OMNI-CARE';
      render(<DeviceSimID {...byodProps} callValidateDeviceSku={callValidateDeviceSku} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    });

    test('Find by DeviceId text', () => {
      Emitter.emit('SIM_SKU_VALIDATION', {
        newVal: { simId: 'BULKSIM-TRI-D', deviceId: props.defaultDeviceId },
        oldVal: props?.defaultSimId,
        provisionalIdInfo: '',
      });
      const deviceIdText = screen.getByTestId('handleChangeDeviceID');
      expect(deviceIdText).toBeInTheDocument();
    });
    test('Device Scan testing for sim id change', async () => {
      console.log(screen.debug());
      const simId = screen.queryAllByTestId('handleChangeSimID')[0];
      expect(simId).toBeInTheDocument();

      fireEvent.change(simId, { target: { value: '89148000002517712755' } });
      fireEvent.focus(simId, { target: { value: '89148000002517712755' } });
      fireEvent.blur(simId, { target: { value: '89148000002517712755' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });

    test('Sim Scan testing by entering sim Id', async () => {
      const simId = screen.queryAllByTestId('handleChangeSimID')[0];
      expect(simId).toBeInTheDocument();

      fireEvent.change(simId, { target: { value: 'DFILLUNIV5G-SA-A' } });
      fireEvent.focus(simId, { target: { value: 'DFILLUNIV5G-SA-A' } });
      fireEvent.blur(simId, { target: { value: 'DFILLUNIV5G-SA-A' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
      expect(simId).toHaveValue('DFILLUNIV5G-SA-A');
    });
  });
  describe(`DeviceSimID component fraud risk not enabled- ${channel} without auth - low risk`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => res(ctx.status(200), ctx.json(validateDeviceByod))),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
      rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
        res(
          ctx.status(200),
          ctx.json({
            responseInfo: {
              errors: [],
              timeStamp: '15-11-2024 05:12:07',
              correlationId: 'smock_enforce_test',
              responseCode: '00',
              responseMessage: 'SUCCESS',
            },
            data: {
              sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
              custId: '0725665601',
              acctNum: '1',
              fraudRiskScore: '0',
              fraudRiskLevel: 'Low Risk',
              loa: '0',
              mdn: '2153709209',
              notificationIndicator: 'Y',
              invokeIdScan: 'N',
            },
            status: 'fulfilled',
          }),
        ),
      ),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      window.mfe = { scmDeviceMfeEnable: false };
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      props.omnicaredropdownValue = 'SIM only change';
      sessionStorage.setItem('enableSimValidation', 'false');
      const byodProps = {
        ...props,
        isLocal: false,
        isFromCPE: false,
        isByodUpdate: false,
        isRetail: false,
        omnicaredropdownValue: 'SIM only change',
        deviceIdSelected: false,
        simSwapNotify: 'Y',
        enableEnforceApi: 'Y',
        setShowGetESimInOption: jest.fn(),
      };
      byodProps.omnicaredropdownValue = 'SIM only change';
      byodProps.customerProfileDetails.customer.channel = 'OMNI-CARE';
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    });

    test('Device Scan testing for sim id change', async () => {
      const simId = screen.queryAllByTestId('simId')[0];
      expect(simId).toBeInTheDocument();
      console.log();
      fireEvent.change(simId, { target: { value: 'DFILLUNIV5G-SA-A' } });
      fireEvent.blur(simId, { target: { value: 'DFILLUNIV5G-SA-A' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });
  });
  describe(`<DeviceSimID component Byod flow- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceByod));
      }),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);
    const byodProps = { ...props, isLocal: false, isFromCPE: true, isByodUpdate: true, isRetail: true };
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    });

    test('Device Scan testing by entering DualSim device Id', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Customer Provided Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });

    test('Device Scan testing for CP Sim confirmation checkbox', async () => {
      const cpSimCheckBox = await screen.getByRole('checkbox', {
        name: 'This device is customer-provided equipment',
      });
      expect(cpSimCheckBox).toBeChecked();
      fireEvent.change(cpSimCheckBox, { target: { checked: true } });
      fireEvent.click(cpSimCheckBox);
      expect(cpSimCheckBox).not.toBeChecked();
    });
  });

  describe(`Samsung carrier lock - <DeviceSimID component Byod flow`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceSimSamsung));
      }),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);
    const byodProps = { ...props, isLocal: false, isFromCPE: true, isByodUpdate: true, isRetail: true };
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ samsungPOSFFlag: 'TRUE' }));
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    });

    test('Device Scan testing by entering DualSim device Id', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Customer Provided Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });

    test('Device Scan testing for CP Sim confirmation checkbox', async () => {
      const cpSimCheckBox = await screen.getByRole('checkbox', {
        name: 'This device is customer-provided equipment',
      });
      expect(cpSimCheckBox).toBeChecked();
      fireEvent.change(cpSimCheckBox, { target: { checked: true } });
      fireEvent.click(cpSimCheckBox);
      expect(cpSimCheckBox).not.toBeChecked();
    });
  });

  describe(`<DeviceSimID component Byod flow-2 ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceByod));
      }),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);
    const byodProps = { ...props, isLocal: false, isFromCPE: true, isByodUpdate: true, isRetail: true };
    beforeAll(() => {
      window.mfe = { scmDeviceMfeEnable: true };
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      window.mfe = {};
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    });

    test('Device Scan testing by entering DualSim device Id', async () => {
      window.mfe.scmDeviceMfeEnable = true;
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Customer Provided Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });
  });
  describe(`<DeviceSimID component Byod flow-2 ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceByod));
      }),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);
    const byodProps = { ...props, isLocal: false, isFromCPE: true, isByodUpdate: true, isRetail: true };
    beforeAll(() => {
      window.mfe = { scmDeviceMfeEnable: true };
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      window.mfe = {};
      window.vzdl = {};
    });

    test('Device Scan testing by entering DualSim device Id', async () => {
      window.mfe.scmDeviceMfeEnable = true;
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Customer Provided Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });
  });

  describe(`<DeviceSimID component Byod flow with Esim model- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceCpe));
      }),
      rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
        res(
          ctx.status(200),

          ctx.json({
            responseInfo: {
              errors: [],
              timeStamp: '15-11-2024 05:12:07',
              correlationId: 'smock_enforce_test',
              responseCode: '00',
              responseMessage: 'SUCCESS',
            },
            data: {
              sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
              custId: '0725665601',
              acctNum: '1',
              fraudRiskScore: '0',
              fraudRiskLevel: 'Low Risk',
              loa: '0',
              mdn: '2153709209',
              notificationIndicator: 'Y',
              invokeIdScan: 'N',
            },
            status: 'fulfilled',
          }),
        ),
      ),
    ];
    const server = setupServer(...handlers);
    const byodProps = {
      ...props,
      isLocal: false,
      isFromCPE: true,
      isByodUpdate: true,
      isRetail: true,
      deviceIdSelected: true,
    };
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      sessionStorage.setItem('enableSimValidation', 'true');
      const omniProps = { ...byodProps };
      omniProps.customerProfileDetails.customer.channel = 'OMNI-CARE';
      render(<DeviceSimID {...omniProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    });

    afterEach(() => {
      const retailProps = { ...byodProps };
      retailProps.customerProfileDetails.customer.channel = 'OMNI-RETAIL';
    });

    test('Device Scan testing by entering Dual Sim device Id with Esim popup', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Customer Provided Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
      const eSimConfirmation = await screen.findByText(
        'This device requires an eSim for activation, do you wish to continue?',
      );
      expect(eSimConfirmation).toBeInTheDocument();
    });
  });
  describe(`<DeviceSimID component Message displayed on same device id for omni care- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceCpe));
      }),
    ];
    const server = setupServer(...handlers);
    const byodProps = {
      ...props,
      isLocal: false,
      isFromCPE: true,
      isByodUpdate: true,
      isRetail: false,
      isOmniCare: true,
      deviceIdSelected: true,
    };
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      const omniProps = { ...byodProps };
      window.mfe = { someproperty: false };
      omniProps.customerProfileDetails.customer.channel = 'OMNI-CARE';
      render(<DeviceSimID {...omniProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });

    test('Device Scan testing by entering Dual Sim device Id with Esim popup', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Customer Provided Device ID',
        value: '350669643749374',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
      // const omniCareBanner = await screen.findByText(
      //   'We can not proceed further with eSim in this flow, please select physical sim or Please access the following path in ACSS to complete an add a line order when the customer is using an existing device and SIM/eSIM: Devices tab> Links/Action> Add line/CPE(NSO)'
      // );
      // expect(omniCareBanner).toBeInTheDocument();
      // expect(messageBannerOmniCare).toBeInTheDocument();
    });
    afterEach(() => {
      const retailProps = { ...byodProps };
      retailProps.customerProfileDetails.customer.channel = 'OMNI-RETAIL';
    });
  });

  describe(`<DeviceSimID component Byod flow with Esim model with Single Sim- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceEsim));
      }),
      rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
        res(
          ctx.status(200),
          ctx.json({
            responseInfo: {
              errors: [],
              timeStamp: '15-11-2024 05:12:07',
              correlationId: 'smock_enforce_test',
              responseCode: '00',
              responseMessage: 'SUCCESS',
            },
            data: {
              sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
              custId: '0725665601',
              acctNum: '1',
              fraudRiskScore: '0',
              fraudRiskLevel: 'Low Risk',
              loa: '0',
              mdn: '2153709209',
              notificationIndicator: 'Y',
              invokeIdScan: 'N',
            },
            status: 'fulfilled',
          }),
        ),
      ),

      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);
    const byodProps = { ...props, isLocal: false, isFromCPE: true, isByodUpdate: true };
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      sessionStorage.setItem('enableSimValidation', 'true');
      window.history.pushState(
        {},
        'Host',
        '/product-detail.html?simId=123456&deviceId=54321&scanFromLanding=true&prospectByodFlow=true&fromPage=combinedgridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7',
      );
      const omniProps = { ...byodProps };
      omniProps.customerProfileDetails.customer.channel = 'OMNI-CARE';
      render(<DeviceSimID {...omniProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    });

    afterEach(() => {
      const retailProps = { ...byodProps };
      retailProps.customerProfileDetails.customer.channel = 'OMNI-RETAIL';
    });

    test.skip('Device Scan testing by entering Single Sim device Id with Esim popup', async () => {
      // const deviceTextBox = await screen.findByRole('textbox', {
      //   name: 'Enter Customer Provided Device ID',
      // });
      // expect(deviceTextBox).toBeInTheDocument();

      // fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      // fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      const simId = screen.queryAllByTestId('handleChangeSimID')[0];
      expect(simId).toBeInTheDocument();

      fireEvent.change(simId, { target: { value: '89148000002517712755' } });
      fireEvent.focus(simId, { target: { value: '89148000002517712755' } });
      fireEvent.blur(simId, { target: { value: '89148000002517712755' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
      const eSimConfirmation = await screen.findByText(
        'This device requires an eSim for activation, do you wish to continue?',
      );
      expect(eSimConfirmation).toBeInTheDocument();
      const noButton = screen.getByText('No');
      expect(noButton).toBeInTheDocument();
      fireEvent.click(noButton);
    });
  });
  describe(`<DeviceSimID component Byod flow with Esim model with Single Sim- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceEsim));
      }),
      rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
        res(
          ctx.status(200),
          ctx.json({
            responseInfo: {
              errors: [],
              timeStamp: '15-11-2024 05:12:07',
              correlationId: 'smock_enforce_test',
              responseCode: '00',
              responseMessage: 'SUCCESS',
            },
            data: {
              sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
              custId: '0725665601',
              acctNum: '1',
              fraudRiskScore: '0',
              fraudRiskLevel: 'Low Risk',
              loa: '0',
              mdn: '2153709209',
              notificationIndicator: 'Y',
              invokeIdScan: 'N',
            },
            status: 'fulfilled',
          }),
        ),
      ),

      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);
    const byodProps = { ...props, isLocal: false, isFromCPE: true, isByodUpdate: true };
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      sessionStorage.setItem('enableSimValidation', 'true');
      window.history.pushState(
        {},
        'Host',
        '/product-detail.html?simId=123456&deviceId=54321&scanFromLanding=true&prospectByodFlow=true&fromPage=combinedgridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7',
      );
      const omniProps = { ...byodProps };
      omniProps.customerProfileDetails.customer.channel = 'OMNI-CARE';
      render(<DeviceSimID {...omniProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {};
    });

    afterEach(() => {
      const retailProps = { ...byodProps };
      retailProps.customerProfileDetails.customer.channel = 'OMNI-RETAIL';
    });

    test.skip('Device Scan testing by entering Single Sim device Id with Esim popup', async () => {
      const simId = screen.queryAllByTestId('handleChangeSimID')[0];
      expect(simId).toBeInTheDocument();

      fireEvent.change(simId, { target: { value: '89148000002517712755' } });
      fireEvent.focus(simId, { target: { value: '89148000002517712755' } });
      fireEvent.blur(simId, { target: { value: '89148000002517712755' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
      const eSimConfirmation = await screen.findByText(
        'This device requires an eSim for activation, do you wish to continue?',
      );
      expect(eSimConfirmation).toBeInTheDocument();
      const noButton = screen.getByText('No');
      expect(noButton).toBeInTheDocument();
      fireEvent.click(noButton);
    });
  });
  describe(`<DeviceSimID component Byod flow with Non Esim - ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceSimId));
      }),
    ];
    const server = setupServer(...handlers);
    const byodProps = { ...props, isLocal: false, isFromCPE: true, isByodUpdate: true, isRetail: true };
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });

    test('Device Scan testing by entering Non ESim device Id', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Customer Provided Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
      await expect(deviceTextBox).toHaveValue('350669643749367');
    });
  });
  describe(`<DeviceSimID component Local ESim- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceEsim));
      }),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
      rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
        res(
          ctx.status(200),
          ctx.json({
            responseInfo: {
              errors: [],
              timeStamp: '15-11-2024 05:12:07',
              correlationId: 'smock_enforce_test',
              responseCode: '00',
              responseMessage: 'SUCCESS',
            },
            data: {
              sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
              custId: '0725665601',
              acctNum: '1',
              fraudRiskScore: '0',
              fraudRiskLevel: 'Low Risk',
              loa: '0',
              mdn: '2153709209',
              notificationIndicator: 'Y',
              invokeIdScan: 'N',
            },
            status: 'fulfilled',
          }),
        ),
      ),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      server.listen();
      const mockNavigate = jest.fn();
      jest.mock('react-router-dom', () => ({ useNavigate: () => mockNavigate }));
    });
    afterAll(() => {
      server.close();
    });
    // const eSimProps = { ...props, currentSimId: '1234' };
    beforeEach(async () => {
      sessionStorage.setItem('enableSimValidation', 'true');
      render(<DeviceSimID {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });

    test('Device Scan testing by entering device Id with Esim Yes', async () => {
      const simId = screen.queryAllByTestId('handleChangeSimID')[0];
      expect(simId).toBeInTheDocument();

      fireEvent.change(simId, { target: { value: '89148000002517712755' } });
      fireEvent.focus(simId, { target: { value: '89148000002517712755' } });
      fireEvent.blur(simId, { target: { value: '89148000002517712755' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      const YesButton = await screen.findByTestId('YesButton');
      fireEvent.click(YesButton);
    });

    test('Device Scan testing by entering device Id with Esim No', async () => {
      const simId = screen.queryAllByTestId('handleChangeSimID')[0];
      expect(simId).toBeInTheDocument();

      fireEvent.change(simId, { target: { value: '89148000002517712755' } });
      fireEvent.focus(simId, { target: { value: '89148000002517712755' } });
      fireEvent.blur(simId, { target: { value: '89148000002517712755' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      const NoButton = await screen.findByTestId('NoButton');
      fireEvent.click(NoButton);
    });
  });
  describe(`<DeviceSimID component with out simId wrapper- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceByod));
      }),
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);
    const byodProps = {
      ...props,
      customerProfileDetails: omniCareCustomerProfileDetails?.data,
      isLocal: false,
      isFromCPE: false,
      isRetail: true,
      byodDevice: {
        deviceId: '12345',
        simInfo: {
          preferredSoftSim: '54321',
        },
      },
      sku: 'ICONIC-SERVICE-SKU',
      isByodUpdate: false,
    };
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      window.history.pushState(
        {},
        'Host',
        '/product-detail.html?simId=123456&deviceId=54321&scanFromLanding=true&prospectByodFlow=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7',
      );
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });
    test('DeviceSimID Component to be rendered on screen', async () => {
      delete window.location;
      window.location = new URL(
        '/product-detail.html?simId=123456&deviceId=54321&isEditAndView=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7',
        'http://localhost:3000/content/vcg/assisted',
      );
      const DeviceSimIDLoad = screen.getByTestId('DeviceSimID');
      expect(DeviceSimIDLoad).toBeInTheDocument();
    });
  });
  describe(`<DeviceSimID component with out simId wrapper- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceByod));
      }),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);
    const byodProps = {
      ...props,
      customerProfileDetails: customerProfileDetails?.data,
      isLocal: false,
      isFromCPE: false,
      isRetail: true,
      byodDevice: '',
      sku: 'ICONIC-SERVICE-SKU',
    };
    beforeAll(() => {
      sessionStorage.setItem('channel', 'OMNI-RETAIL');
      sessionStorage.getItem('customerType', 'N');
      sessionStorage.setItem('isPearl', 'false');
      sessionStorage.setItem('APP_PROPERTIES', '{"pearlBYODFlow": "TRUE"}');
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      window.history.pushState(
        {},
        'Host',
        '/product-detail.html?simId=123456&deviceId=54321&scanFromLanding=true&prospectByodFlow=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7',
      );
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });
    test('DeviceSimID Component to be rendered on screen', async () => {
      delete window.location;
      window.location = new URL(
        '/product-detail.html?simId=123456&deviceId=54321&isEditAndView=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7',
        'http://localhost:3000/content/vcg/assisted',
      );
      const DeviceSimIDLoad = screen.getByTestId('DeviceSimID');
      expect(DeviceSimIDLoad).toBeInTheDocument();
    });
  });
  describe(`<DeviceSimID component with out customer profile data- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceByod));
      }),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);
    const byodProps = {
      ...props,
      customerProfileDetails: [],
      isLocal: false,
      isFromCPE: false,
      isRetail: true,
      byodDevice: '',
      sku: 'ICONIC-SERVICE-SKU',
    };
    beforeAll(() => {
      sessionStorage.setItem('channel', 'OMNI-INDIRECT');
      sessionStorage.getItem('customerType', 'N');
      sessionStorage.setItem('isPearl', 'true');
      sessionStorage.setItem('APP_PROPERTIES', '{"pearlBYODFlow": "TRUE"}');
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      window.history.pushState(
        {},
        'Host',
        '/product-detail.html?simId=123456&deviceId=54321&scanFromLanding=true&prospectByodFlow=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7',
      );
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });
    test('Device SimID Component to be rendered on screen', async () => {
      delete window.location;
      window.location = new URL(
        '/product-detail.html?simId=123456&deviceId=54321&isEditAndView=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7',
        'http://localhost:3000/content/vcg/assisted',
      );
      const DeviceSimIDLoad = screen.getByTestId('DeviceSimID');
      expect(DeviceSimIDLoad).toBeInTheDocument();
    });
  });
  describe(`<DeviceSimID component VideoAssistFlow - ${channel}`, () => {
    const updatedProps = { ...props, isVideoAssistFlow: true, isRetail: false };

    beforeEach(() => {
      render(<DeviceSimID {...updatedProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });

    test('DeviceSimID Component to be rendered on screen', async () => {
      const DeviceSimIDLoad = screen.getByTestId('DeviceSimID');
      expect(DeviceSimIDLoad).toBeInTheDocument();
    });
  });
  describe(`<DeviceSimID component VideoAssistFlow false - ${channel}`, () => {
    const propsWithoutVideoAssistFlowFlag = props;
    delete propsWithoutVideoAssistFlowFlag.isVideoAssistFlow;
    const updatedProps = { ...propsWithoutVideoAssistFlowFlag, isRetail: false };

    beforeEach(() => {
      render(<DeviceSimID {...updatedProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });

    test('DeviceSimID Component to be rendered on screen', async () => {
      const DeviceSimIDLoad = screen.getByTestId('DeviceSimID');
      expect(DeviceSimIDLoad).toBeInTheDocument();
    });
  });
  describe(`<DeviceSimID component validateDeviceSimIdRequest - ${channel}`, () => {
    const updatedProps = { ...props, activeMtn: '5185673928' };

    beforeEach(() => {
      sessionStorage.setItem('isPearl', 'false');
      sessionStorage.setItem('APP_PROPERTIES', '{"pearlBYODFlow": "TRUE"}');
      render(<DeviceSimID {...updatedProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });

    test('Device Scan testing for 5G flow', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });
  });
  describe(`<DeviceSimID component validateDeviceSimIdRequest1 - ${channel}`, () => {
    beforeAll(() => {
      sessionStorage.setItem('channel', 'OMNI-RETAIL');
      sessionStorage.setItem('customerType', 'N');
    });
    const updatedProps = { ...props, activeMtn: 'newLine1', isByodUpdate: false };

    beforeEach(() => {
      sessionStorage.setItem('isPearl', 'false');
      sessionStorage.setItem('APP_PROPERTIES', '{"pearlBYODFlow": "TRUE"}');
      render(<DeviceSimID {...updatedProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });

    test('Device Scan testing for 5G flow', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });
  });
  describe(`<DeviceSimID component Byod flow- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceAct));
      }),
    ];
    const server = setupServer(...handlers);
    const byodProps = { ...props, activeMtn: 'newLine1', isByodUpdate: true, sendSimFromLanding: true };

    beforeAll(() => {
      window.mfe = { scmDeviceMfeEnable: true };
      server.listen();
      sessionStorage.setItem('customerType', 'E');
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    });

    test('Device Scan testing by entering DualSim device Id', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Customer Provided Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.change(screen.getAllByTestId('handleChangeSimID')[0], { target: { value: '350669643749367' } });
      fireEvent.focus(screen.getAllByTestId('handleChangeSimID')[0], { target: { value: '350669643749367' } });
      fireEvent.blur(screen.getAllByTestId('handleChangeSimID')[0], { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });

    test('Device Scan testing for CP Sim confirmation checkbox', async () => {
      const cpSimCheckBox = await screen.getByRole('checkbox', {
        name: 'This device is customer-provided equipment',
      });
      sessionStorage.setItem('APP_PROPERTIES', '{"pearlBYODFlow": "TRUE","simCompatibilityCheck22417FFlag":"TRUE"}');

      expect(cpSimCheckBox).toBeChecked();
      fireEvent.change(cpSimCheckBox, { target: { checked: true } });
      fireEvent.click(cpSimCheckBox);
      expect(cpSimCheckBox).not.toBeChecked();
    });
    const { rerender } = render(<DeviceSimID {...byodProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    byodProps.omnicaredropdownValue = 'Provisional ID';
    rerender(<DeviceSimID {...byodProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  describe(`<DeviceSimID component Byod flow- ${channel}`, () => {
    const provisionalIdData = {
      data: {
        data: {
          provisionalDeviceId: 'A0000000000512',
        },
      },
    };
    const fraudRiskScoreResult = {
      status: 'fulfill',
      data: { fraudRiskLevel: 'high risk' },
    };
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceAct));
      }),
      rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) => {
        console.log('inside /cpc/fraudRiskScore');
        return res(ctx.status(200), ctx.json(fraudRiskScoreResult));
      }),
      rest.post(`*/cpc/retrieveProvisionalDeviceId`, (req, res, ctx) => {
        console.log('inside /cpc/retrieveProvisionalDeviceId');
        return res(ctx.status(200), ctx.json(provisionalIdData));
      }),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);
    const byodProps = {
      ...props,
      isLocal: false,
      isSimultaneousUpgrade: true,
      isFromCPE: true,
      isByodUpdate: true,
      isRetail: true,
    };
    beforeAll(() => {
      window.mfe = { scmDeviceMfeEnable: true };
      server.listen();
      sessionStorage.setItem('customerType', 'E');
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    });

    test('Device Scan testing by entering DualSim device Id', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Customer Provided Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.change(screen.getAllByTestId('handleChangeSimID')[0], { target: { value: '350669643749367' } });
      fireEvent.focus(screen.getAllByTestId('handleChangeSimID')[0], { target: { value: '350669643749367' } });
      fireEvent.blur(screen.getAllByTestId('handleChangeSimID')[0], { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });

    test('Device Scan testing for CP Sim confirmation checkbox', async () => {
      const cpSimCheckBox = await screen.getByRole('checkbox', {
        name: 'This device is customer-provided equipment',
      });
      expect(cpSimCheckBox).toBeChecked();
      fireEvent.change(cpSimCheckBox, { target: { checked: true } });
      fireEvent.click(cpSimCheckBox);
      expect(cpSimCheckBox).not.toBeChecked();
    });
    const { rerender } = render(<DeviceSimID {...byodProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    byodProps.omnicaredropdownValue = 'Provisional ID';
    rerender(<DeviceSimID {...byodProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  describe(`<DeviceSimID component Byod flow- ${channel}`, () => {
    const provisionalIdData = {
      data: {
        data: {
          provisionalDeviceId: 'A0000000000512',
        },
      },
    };
    const fraudRiskScoreResult = {
      status: 'fulfill',
      data: { fraudRiskLevel: 'high risk' },
    };
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceByod));
      }),
      rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) => {
        console.log('inside /cpc/fraudRiskScore');
        return res(ctx.status(200), ctx.json(fraudRiskScoreResult));
      }),
      rest.post(`*/cpc/retrieveProvisionalDeviceId`, (req, res, ctx) => {
        console.log('inside /cpc/retrieveProvisionalDeviceId');
        return res(ctx.status(200), ctx.json(provisionalIdData));
      }),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);
    const byodProps = {
      ...props,
      isLocal: false,
      isSimultaneousUpgrade: true,
      isFromCPE: true,
      isByodUpdate: true,
      isRetail: true,
    };
    beforeAll(() => {
      window.mfe = { scmDeviceMfeEnable: true };
      sessionStorage.setItem('enableSimValidation', 'false');
      server.listen();
      sessionStorage.setItem('customerType', 'E');
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    });

    test('Device Scan testing by entering DualSim device Id', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Customer Provided Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.change(screen.getAllByTestId('handleChangeSimID')[0], { target: { value: '350669643749367' } });
      fireEvent.focus(screen.getAllByTestId('handleChangeSimID')[0], { target: { value: '350669643749367' } });
      fireEvent.blur(screen.getAllByTestId('handleChangeSimID')[0], { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });

    test('Device Scan testing for CP Sim confirmation checkbox', async () => {
      const cpSimCheckBox = await screen.getByRole('checkbox', {
        name: 'This device is customer-provided equipment',
      });
      expect(cpSimCheckBox).toBeChecked();
      fireEvent.change(cpSimCheckBox, { target: { checked: true } });
      fireEvent.click(cpSimCheckBox);
      expect(cpSimCheckBox).not.toBeChecked();
    });
    const { rerender } = render(<DeviceSimID {...byodProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    byodProps.omnicaredropdownValue = 'Provisional ID';
    rerender(<DeviceSimID {...byodProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  describe(`<DeviceSimID component Byod flow 1- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceByod));
      }),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);
    const byodProps = {
      ...props,
      isLocal: false,
      isSimultaneousUpgrade: true,
      isFromCPE: true,
      isByodUpdate: true,
      isRetail: true,
    };
    beforeAll(() => {
      window.mfe = { scmDeviceMfeEnable: false };
      server.listen();
      sessionStorage.setItem('customerType', 'E');
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    });

    test('Device Scan testing by entering DualSim device Id', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Customer Provided Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.change(screen.getAllByTestId('handleChangeSimID')[0], { target: { value: '350669643749367' } });
      fireEvent.focus(screen.getAllByTestId('handleChangeSimID')[0], { target: { value: '350669643749367' } });
      fireEvent.blur(screen.getAllByTestId('handleChangeSimID')[0], { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });

    test('Device Scan testing for CP Sim confirmation checkbox', async () => {
      const cpSimCheckBox = await screen.getByRole('checkbox', {
        name: 'This device is customer-provided equipment',
      });
      expect(cpSimCheckBox).toBeChecked();
      fireEvent.change(cpSimCheckBox, { target: { checked: true } });
      fireEvent.click(cpSimCheckBox);
      expect(cpSimCheckBox).not.toBeChecked();
    });
  });
  describe(`<DeviceSimID component Byod flow- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceByod));
      }),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => res(ctx.status(200), ctx.json(eSimDetails))),
    ];
    const server = setupServer(...handlers);
    const byodProps = { ...props, isLocal: false, isFromCPE: true, isByodUpdate: true, isRetail: true };
    beforeAll(() => {
      window.mfe = { scmDeviceMfeEnable: true };
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    });

    test('Device Scan testing by entering DualSim device Id', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Customer Provided Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.change(screen.getAllByTestId('handleChangeSimID')[0], { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });

    test('Device Scan testing for CP Sim confirmation checkbox', async () => {
      const cpSimCheckBox = await screen.getByRole('checkbox', {
        name: 'This device is customer-provided equipment',
      });
      expect(cpSimCheckBox).toBeChecked();
      fireEvent.change(cpSimCheckBox, { target: { checked: true } });
      fireEvent.click(cpSimCheckBox);
      expect(cpSimCheckBox).not.toBeChecked();
    });
  });
  describe(`<DeviceSimID component Byod flow- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => res(ctx.status(200), ctx.json(validateDeviceByod))),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);
    const byodProps = { ...props, isLocal: false, isFromCPE: true, isByodUpdate: true, isRetail: true };
    beforeAll(() => {
      window.mfe = { scmDeviceMfeEnable: true, isDark: true };
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ secondNumActivationModalFFlag: 'TRUE' }));
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    });

    test('Device Scan testing by entering DualSim device Id', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Customer Provided Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.change(screen.getAllByTestId('handleChangeSimID')[0], { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });

    test('Device Scan testing for CP Sim confirmation checkbox', async () => {
      const cpSimCheckBox = await screen.getByRole('checkbox', {
        name: 'This device is customer-provided equipment',
      });
      expect(cpSimCheckBox).toBeChecked();
      fireEvent.change(cpSimCheckBox, { target: { checked: true } });
      fireEvent.click(cpSimCheckBox);
      expect(cpSimCheckBox).not.toBeChecked();
    });
  });

  describe(`<DeviceSimID component Byod flow 01- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => res(ctx.status(200), ctx.json(validateDeviceByod))),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);
    const byodProps = {
      ...props,
      isLocal: false,
      isFromCPE: true,
      isByodUpdate: true,
      isRetail: true,
      omnicaredropdownValue: 'Provisional ID',
    };
    beforeAll(() => {
      window.mfe = { scmDeviceMfeEnable: true };
      // sessionStorage.setItem('encryptedActInfo');
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      // const useLazyRetrieveProvisionalDeviceIdQuery = jest.fn();

      // jest.mock(
      //   '../../../modules/services/APIService/APIServiceHooks',
      //   () => {
      //     let index = 1;
      //     return {
      //       __esModule: true,
      //       ...jest.requireActual('../../../modules/services/APIService/APIServiceHooks'),
      //       useLazyRetrieveProvisionalDeviceIdQuery: () => {
      //         if (index === 1) {
      //           return [
      //             () => {
      //               index += 1;
      //               return {};
      //             },
      //             {
      //               status: 'Success',
      //               isUninitialized: false,
      //               isLoading: false,
      //               isSuccess: true,
      //               isError: false,
      //               isFetching: false,
      //               data: {
      //                 data:{
      //                   data:{
      //                     provisionalDeviceId: 'true'
      //                   }
      //                 },
      //                 serviceBody: {
      //                   serviceResponse: {
      //                     context: {
      //                       contextInfo: {
      //                         processStep: '',
      //                       },
      //                       cartInfo: { lines: [{ downPaymentAmtApplied: '15', device: { upgradeReasonCode: 'UN' } }] },
      //                     },
      //                   },
      //                 },
      //               },
      //             },
      //           ];
      //         }
      //         return [() => {}, { data: { id: '1234' } }];
      //       },
      //     };
      //   },
      //   { virtual: true },
      // );

      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    });

    test('Device Scan testing for CP Sim confirmation checkbox', async () => {
      // const useLazyRetrieveProvisionalDeviceIdQuery = jest.fn();
      // useLazyRetrieveProvisionalDeviceIdQuery.mockReturnValue([jest.fn(), APIsuccess]);

      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });
  });
  describe(`<DeviceSimID component - ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceSimId));
      }),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      window.mfe = { scmDeviceMfeEnable: true };
      sessionStorage.setItem('enableSimValidation', 'false');
      props.omnicaredropdownValue = 'Provisional ID';
      render(<DeviceSimID {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });

    test('DeviceSimID Component to be rendered on screen', async () => {
      Emitter.emit('CONT_SIM_SKU_VALIDATION', 'sku5600273');
      // const DeviceSimIDLoad = screen.getByTestId('DeviceSimID');
      // expect(DeviceSimIDLoad).toBeInTheDocument();
    });

    test('Find by DeviceId text', () => {
      const deviceIdText = screen.getByText('Enter Device ID');
      expect(deviceIdText).toBeInTheDocument();
      const simIdText = screen.getByText('Enter Sim ID');
      expect(simIdText).toBeInTheDocument();
    });

    test('Device Scan testing by entering device Id', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      //   expect(deviceTextBox).toHaveValue('350669643749367');
    });

    test('Device Scan testing by entering incorrect device Id ', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '35066964374936' } });
      fireEvent.blur(deviceTextBox, { target: { value: '35066964374936' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      //   expect(deviceTextBox).toHaveValue('35066964374936');
    });

    test('Device Scan testing by entering device Id with string', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: 'abc' } });
      fireEvent.blur(deviceTextBox, { target: { value: 'abc' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
    });
    test('Device Scan testing by entering device Id with string', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '1' } });
      fireEvent.change(deviceTextBox, { target: { value: '' } });
      fireEvent.blur(deviceTextBox, { target: { value: '' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
    });
    test('Sim Scan testing by entering sim Id', async () => {
      const simTextBox = await screen.getByRole('textbox', { name: 'Enter Sim ID' });
      fireEvent.change(simTextBox, { target: { value: '8' } });
      fireEvent.change(simTextBox, { target: { value: '' } });
      fireEvent.blur(simTextBox, { target: { value: '' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      expect(simTextBox).toHaveValue('');
    });
    test('Sim Scan testing by entering sim Id', async () => {
      const simTextBox = await screen.getByRole('textbox', { name: 'Enter Sim ID' });
      fireEvent.change(simTextBox, { target: { value: '89148000005700881964' } });
      fireEvent.blur(simTextBox, { target: { value: '89148000005700881964' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      expect(simTextBox).toHaveValue('89148000005700881964');
    });

    test('Sim Scan testing by entering sim Id', async () => {
      const simTextBox = await screen.getByRole('textbox', { name: 'Enter Sim ID' });
      fireEvent.change(simTextBox, { target: { value: 'BULKSIMTRI' } });
      fireEvent.blur(simTextBox, { target: { value: 'BULKSIMTRI' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      expect(simTextBox).toHaveValue('BULKSIMTRI');
    });

    test('Sim Scan testing by entering Dfill sim sku', async () => {
      const simTextBox = await screen.getByRole('textbox', { name: 'Enter Sim ID' });
      fireEvent.change(simTextBox, { target: { value: 'BULKSIMTRI-A' } });
      fireEvent.blur(simTextBox, { target: { value: 'BULKSIMTRI-A' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      expect(simTextBox).toHaveValue('BULKSIMTRI-A');
    });
  });
  describe(`<DeviceSimID component acss device change - ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceSimId));
      }),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      window.mfe = { scmDeviceMfeEnable: true };
      sessionStorage.setItem('enableSimValidation', 'false');
      props.omnicaredropdownValue = 'Device change';
      render(<DeviceSimID {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });

    test('DeviceSimID Component to be rendered on screen', async () => {
      Emitter.emit('CONT_SIM_SKU_VALIDATION', { newVal: { deviceId: '343345' } });
      // const DeviceSimIDLoad = screen.getByTestId('DeviceSimID');
      // expect(DeviceSimIDLoad).toBeInTheDocument();
    });
    test('DeviceSimID Component to be rendered on screen', async () => {
      Emitter.emit('CONT_SIM_SKU_VALIDATION', {
        newVal: { deviceId: { deviceId: '343345' }, simId: { simId: '4534345' } },
      });
      // const DeviceSimIDLoad = screen.getByTestId('DeviceSimID');
      // expect(DeviceSimIDLoad).toBeInTheDocument();
    });
    test('DeviceSimID Component to be rendered on screen with adaptive auth fail', async () => {
      Emitter.emit('CONT_SIM_SKU_VALIDATION', { respCode: '99' });
    });
    test('DeviceSimID Component to be rendered on screen with adaptive auth fail', async () => {
      Emitter.emit('CONT_SIM_SKU_VALIDATION', {
        provisionalIdInfo: { isProvisionalId: true, provisionalDeviceId: 'A0000000000518' },
      });
    });
    test('DeviceSimID Component to be rendered on screen with adaptive auth fail', async () => {
      Emitter.emit('CONT_SIM_SKU_VALIDATION', { newVal: { deviceId: '4524524', simId: '45245245245' } });
    });

    test('Find by DeviceId text', () => {
      const deviceIdText = screen.getByText('Enter Device ID');
      expect(deviceIdText).toBeInTheDocument();
      const simIdText = screen.getByText('Enter Sim ID');
      expect(simIdText).toBeInTheDocument();
    });

    test('Device Scan testing by entering device Id', async () => {
      const deviceTextBox = await screen.findByRole('textbox', {
        name: 'Enter Device ID',
      });
      expect(deviceTextBox).toBeInTheDocument();

      fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
      fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      expect(deviceTextBox).toHaveValue('350669643749367');
    });

    test('Sim Scan testing by entering sim Id', async () => {
      const simTextBox = await screen.getByRole('textbox', { name: 'Enter Sim ID' });
      fireEvent.change(simTextBox, { target: { value: '89148000005700881964' } });
      fireEvent.blur(simTextBox, { target: { value: '89148000005700881964' } });
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      expect(simTextBox).toHaveValue('89148000005700881964');
    });
  });

  describe(`DeviceSimID component fraud risk tests success- ${channel} without auth`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => res(ctx.status(200), ctx.json(validateDeviceByod))),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
      rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
        res(
          ctx.status(200),
          ctx.json({
            responseInfo: {
              errors: [],
              timeStamp: '15-11-2024 05:12:07',
              correlationId: 'smock_enforce_test',
              responseCode: '00',
              responseMessage: 'SUCCESS',
            },
            data: {
              sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
              custId: '0725665601',
              acctNum: '1',
              fraudRiskScore: '0',
              fraudRiskLevel: 'High Risk',
              loa: '0',
              mdn: '2153709209',
              notificationIndicator: 'Y',
              invokeIdScan: 'N',
            },
            status: 'fulfilled',
          }),
        ),
      ),
    ];
    const server = setupServer(...handlers);

    beforeAll(() => {
      window.mfe = { scmDeviceMfeEnable: true, isDark: true };
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      props.omnicaredropdownValue = 'SIM only change';
      const byodProps = {
        ...props,
        isLocal: false,
        isFromCPE: false,
        isByodUpdate: false,
        isRetail: false,
        omnicaredropdownValue: 'SIM only change',
        deviceIdSelected: true,
        simSwapNotify: 'Y',
        enableEnforceApi: 'Y',
      };
      byodProps.omnicaredropdownValue = 'SIM only change';
      byodProps.customerProfileDetails.customer.channel = 'OMNI-CARE';
      sessionStorage.setItem('enableSimValidation', 'false');
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    });

    test('Device Scan testing for sim id changes', async () => {
      const simId = screen.queryAllByTestId('handleChangeSimID')[0];
      expect(simId).toBeInTheDocument();

      fireEvent.change(simId, { target: { value: '89148000002517712755' } });
      fireEvent.focus(simId, { target: { value: '89148000002517712755' } });
      fireEvent.blur(simId, { target: { value: '89148000002517712755' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });

    // test('Sim Scan testing by entering sim Id', async () => {
    //   const simId = screen.queryAllByTestId('handleChangeSimID')[0];
    //   expect(simId).toBeInTheDocument();

    //   fireEvent.change(simId, { target: { value: '89148000002517712754' } });
    //   fireEvent.blur(simId, { target: { value: '89148000002517712754' } });
    //   await new Promise((res) => {
    //     setTimeout(res, 3000);
    //   });
    //   expect(simId).toHaveValue('89148000002517712754');
    // });
  });

  describe(`DeviceSimID component fraud risk tests error- ${channel} without auth`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => res(ctx.status(200), ctx.json(validateDeviceByod))),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
      rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
        res(
          ctx.status(200),
          ctx.json({
            responseInfo: {
              errors: [
                {
                  externalErrorCode: '74',
                  externalErrorMessage: '500null',
                  apiName: 'refSimSwapService',
                  system: 'CXPREST',
                  errorHolder: {},
                },
              ],
              timeStamp: '13-12-2024 02:25:44',
              correlationId: '9ce78c5a-46f1-426e-88c7-5e7e1c066bdb',
              responseCode: '99',
              responseMessage: 'FAILURE',
            },
            data: {},
            status: 'fulfilled',
          }),
        ),
      ),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      window.mfe = { scmDeviceMfeEnable: true, isDark: true };
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      sessionStorage.setItem('enableSimValidation', 'false');
      props.omnicaredropdownValue = 'SIM only change';
      const byodProps = {
        ...props,
        isLocal: false,
        isFromCPE: false,
        isByodUpdate: false,
        isRetail: false,
        omnicaredropdownValue: 'SIM only change',
        deviceIdSelected: true,
        simSwapNotify: 'Y',
        enableEnforceApi: 'Y',
      };
      byodProps.omnicaredropdownValue = 'SIM only change';
      byodProps.customerProfileDetails.customer.channel = 'OMNI-CARE';
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    });

    test('Device Scan testing for sim id change', async () => {
      const simId = screen.queryAllByTestId('handleChangeSimID')[0];
      expect(simId).toBeInTheDocument();

      fireEvent.change(simId, { target: { value: '89148000002517712755' } });
      fireEvent.focus(simId, { target: { value: '89148000002517712755' } });
      fireEvent.blur(simId, { target: { value: '89148000002517712755' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });

    test('Sim Scan testing by entering sim Id', async () => {
      const simId = screen.queryAllByTestId('handleChangeSimID')[0];
      expect(simId).toBeInTheDocument();

      fireEvent.change(simId, { target: { value: '89148000002517712754' } });
      fireEvent.focus(simId, { target: { value: '89148000002517712754' } });
      fireEvent.blur(simId, { target: { value: '89148000002517712754' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
      expect(simId).toHaveValue('89148000002517712754');
    });

    test('Sim Scan testing when sim includes special chars', async () => {
      const simId = screen.queryAllByTestId('handleChangeSimID')[0];
      expect(simId).toBeInTheDocument();

      fireEvent.change(simId, { target: { value: '8914800000251771275%#$^' } });
      fireEvent.focus(simId, { target: { value: '8914800000251771275%#$^' } });
      fireEvent.blur(simId, { target: { value: '8914800000251771275%#$^' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });
  });

  describe(`DeviceSimID component fraud risk tests success- ${channel} with auth`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => res(ctx.status(200), ctx.json(validateDeviceByod))),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
      rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
        res(
          ctx.status(200),
          ctx.json({
            responseInfo: {
              errors: [],
              timeStamp: '15-11-2024 05:12:07',
              correlationId: 'smock_enforce_test',
              responseCode: '00',
              responseMessage: 'SUCCESS',
            },
            data: {
              sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
              custId: '0725665601',
              acctNum: '1',
              fraudRiskScore: '0',
              fraudRiskLevel: 'High Risk',
              loa: '0',
              mdn: '2153709209',
              notificationIndicator: 'Y',
              invokeIdScan: 'N',
            },
            status: 'fulfilled',
          }),
        ),
      ),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      window.mfe = { scmDeviceMfeEnable: true, isDark: true };
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      sessionStorage.setItem('enableSimValidation', 'true');
      props.omnicaredropdownValue = 'SIM only change';
      const byodProps = {
        ...props,
        isLocal: false,
        isFromCPE: false,
        isByodUpdate: false,
        isRetail: false,
        omnicaredropdownValue: 'SIM only change',
        deviceIdSelected: true,
        simSwapNotify: 'Y',
        enableEnforceApi: 'Y',
      };
      byodProps.omnicaredropdownValue = 'SIM only change';
      byodProps.customerProfileDetails.customer.channel = 'OMNI-CARE';
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    });

    test('Device Scan testing for sim id change', async () => {
      const simId = screen.queryAllByTestId('handleChangeSimID')[0];
      expect(simId).toBeInTheDocument();

      fireEvent.change(simId, { target: { value: '89148000002517712755' } });
      fireEvent.focus(simId, { target: { value: '89148000002517712755' } });
      fireEvent.blur(simId, { target: { value: '89148000002517712755' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });
  });

  describe(`DeviceSimID component fraud risk tests error- ${channel} with auth`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => res(ctx.status(200), ctx.json(validateDeviceByod))),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
      rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
        res(
          ctx.status(200),
          ctx.json({
            responseInfo: {
              errors: [
                {
                  externalErrorCode: '74',
                  externalErrorMessage: '500null',
                  apiName: 'refSimSwapService',
                  system: 'CXPREST',
                  errorHolder: {},
                },
              ],
              timeStamp: '13-12-2024 02:25:44',
              correlationId: '9ce78c5a-46f1-426e-88c7-5e7e1c066bdb',
              responseCode: '99',
              responseMessage: 'FAILURE',
            },
            data: {},
            status: 'fulfilled',
          }),
        ),
      ),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      window.mfe = { scmDeviceMfeEnable: true, isDark: true };
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      props.omnicaredropdownValue = 'SIM only change';
      sessionStorage.setItem('enableSimValidation', 'true');
      const byodProps = {
        ...props,
        isLocal: false,
        isFromCPE: false,
        isByodUpdate: false,
        isRetail: false,
        omnicaredropdownValue: 'SIM only change',
        deviceIdSelected: true,
        simSwapNotify: 'Y',
        enableEnforceApi: 'Y',
      };
      byodProps.omnicaredropdownValue = 'SIM only change';
      byodProps.customerProfileDetails.customer.channel = 'OMNI-CARE';
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    });

    test('Device Scan testing for sim id change', async () => {
      const simId = screen.queryAllByTestId('handleChangeSimID')[0];
      expect(simId).toBeInTheDocument();

      fireEvent.change(simId, { target: { value: '89148000002517712755' } });
      fireEvent.focus(simId, { target: { value: '89148000002517712755' } });
      fireEvent.blur(simId, { target: { value: '89148000002517712755' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });
  });

  describe(`DeviceSimID component fraud risk tests success- ${channel} with auth - low risk`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => res(ctx.status(200), ctx.json(validateDeviceByod))),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
      rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
        res(
          ctx.status(200),
          ctx.json({
            responseInfo: {
              errors: [],
              timeStamp: '15-11-2024 05:12:07',
              correlationId: 'smock_enforce_test',
              responseCode: '00',
              responseMessage: 'SUCCESS',
            },
            data: {
              sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
              custId: '0725665601',
              acctNum: '1',
              fraudRiskScore: '0',
              fraudRiskLevel: 'Low Risk',
              loa: '0',
              mdn: '2153709209',
              notificationIndicator: 'Y',
              invokeIdScan: 'N',
            },
            status: 'fulfilled',
          }),
        ),
      ),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      window.mfe = { scmDeviceMfeEnable: true, isDark: true };
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      props.omnicaredropdownValue = 'SIM only change';
      sessionStorage.setItem('enableSimValidation', 'true');
      const byodProps = {
        ...props,
        isLocal: false,
        isFromCPE: false,
        isByodUpdate: false,
        isRetail: false,
        omnicaredropdownValue: 'SIM only change',
        deviceIdSelected: true,
        simSwapNotify: 'Y',
        enableEnforceApi: 'Y',
      };
      byodProps.omnicaredropdownValue = 'SIM only change';
      byodProps.customerProfileDetails.customer.channel = 'OMNI-CARE';
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    });

    test('Device Scan testing for sim id change', async () => {
      const simId = screen.queryAllByTestId('handleChangeSimID')[0];
      expect(simId).toBeInTheDocument();

      fireEvent.change(simId, { target: { value: '89148000002517712755' } });
      fireEvent.focus(simId, { target: { value: '89148000002517712755' } });
      fireEvent.blur(simId, { target: { value: '89148000002517712755' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });

    test('Sim Scan testing by entering sim Id', async () => {
      const simId = screen.queryAllByTestId('handleChangeSimID')[0];
      expect(simId).toBeInTheDocument();

      fireEvent.change(simId, { target: { value: 'DFILLUNIV5G-SA-A' } });
      fireEvent.focus(simId, { target: { value: 'DFILLUNIV5G-SA-A' } });
      fireEvent.blur(simId, { target: { value: 'DFILLUNIV5G-SA-A' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
      expect(simId).toHaveValue('DFILLUNIV5G-SA-A');
    });
  });

  describe(`DeviceSimID component fraud risk tests success- ${channel} with auth - low risk with notificationindiator = N`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => res(ctx.status(200), ctx.json(validateDeviceByod))),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
      rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
        res(
          ctx.status(200),
          ctx.json({
            responseInfo: {
              errors: [],
              timeStamp: '15-11-2024 05:12:07',
              correlationId: 'smock_enforce_test',
              responseCode: '00',
              responseMessage: 'SUCCESS',
            },
            data: {
              sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
              custId: '0725665601',
              acctNum: '1',
              fraudRiskScore: '0',
              fraudRiskLevel: 'Low Risk',
              loa: '0',
              mdn: '2153709209',
              notificationIndicator: 'N',
              invokeIdScan: 'N',
            },
            status: 'fulfilled',
          }),
        ),
      ),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      window.mfe = { scmDeviceMfeEnable: true, isDark: true };
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      props.omnicaredropdownValue = 'SIM only change';
      sessionStorage.setItem('enableSimValidation', 'true');
      const byodProps = {
        ...props,
        isLocal: false,
        isFromCPE: false,
        isByodUpdate: false,
        isRetail: false,
        omnicaredropdownValue: 'SIM only change',
        deviceIdSelected: true,
        simSwapNotify: 'Y',
        enableEnforceApi: 'Y',
      };
      byodProps.omnicaredropdownValue = 'SIM only change';
      byodProps.customerProfileDetails.customer.channel = 'OMNI-CARE';
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    });

    test('Device Scan testing for sim id change', async () => {
      const simId = screen.queryAllByTestId('handleChangeSimID')[0];
      expect(simId).toBeInTheDocument();

      fireEvent.change(simId, { target: { value: '89148000002517712755' } });
      fireEvent.focus(simId, { target: { value: '89148000002517712755' } });
      fireEvent.blur(simId, { target: { value: '89148000002517712755' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });
  });

  describe(`DeviceSimID component fraud risk tests success- ${channel} without auth - low risk`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => res(ctx.status(200), ctx.json(validateDeviceByod))),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
      rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
        res(
          ctx.status(200),
          ctx.json({
            responseInfo: {
              errors: [],
              timeStamp: '15-11-2024 05:12:07',
              correlationId: 'smock_enforce_test',
              responseCode: '00',
              responseMessage: 'SUCCESS',
            },
            data: {
              sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
              custId: '0725665601',
              acctNum: '1',
              fraudRiskScore: '0',
              fraudRiskLevel: 'Low Risk',
              loa: '0',
              mdn: '2153709209',
              notificationIndicator: 'Y',
              invokeIdScan: 'N',
            },
            status: 'fulfilled',
          }),
        ),
      ),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      window.mfe = { scmDeviceMfeEnable: true, isDark: true };
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      props.omnicaredropdownValue = 'SIM only change';
      sessionStorage.setItem('enableSimValidation', 'false');
      const byodProps = {
        ...props,
        isLocal: false,
        isFromCPE: false,
        isByodUpdate: false,
        isRetail: false,
        omnicaredropdownValue: 'SIM only change',
        deviceIdSelected: true,
        simSwapNotify: 'Y',
        enableEnforceApi: 'Y',
      };
      byodProps.omnicaredropdownValue = 'SIM only change';
      byodProps.customerProfileDetails.customer.channel = 'OMNI-CARE';
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    });

    test('Device Scan testing for sim id change', async () => {
      const simId = screen.queryAllByTestId('handleChangeSimID')[0];
      expect(simId).toBeInTheDocument();
      console.log();
      fireEvent.change(simId, { target: { value: '89148000002517712755' } });
      fireEvent.focus(simId, { target: { value: '89148000002517712755' } });
      fireEvent.blur(simId, { target: { value: '89148000002517712755' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });
  });
  describe(`DeviceSimID component fraud risk tests success- ${channel} without auth - low risk`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => res(ctx.status(200), ctx.json(validateDeviceByod))),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
      rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
        res(
          ctx.status(200),
          ctx.json({
            responseInfo: {
              errors: [],
              timeStamp: '15-11-2024 05:12:07',
              correlationId: 'smock_enforce_test',
              responseCode: '00',
              responseMessage: 'SUCCESS',
            },
            data: {
              sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
              custId: '0725665601',
              acctNum: '1',
              fraudRiskScore: '0',
              fraudRiskLevel: 'Low Risk',
              loa: '0',
              mdn: '2153709209',
              notificationIndicator: 'Y',
              invokeIdScan: 'N',
            },
            status: 'fulfilled',
          }),
        ),
      ),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      window.mfe = { scmDeviceMfeEnable: true, isDark: true };
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      props.omnicaredropdownValue = 'SIM only change';
      sessionStorage.setItem('enableSimValidation', 'false');
      const byodProps = {
        ...props,
        isLocal: false,
        isFromCPE: false,
        isByodUpdate: false,
        isRetail: false,
        omnicaredropdownValue: 'SIM only change',
        deviceIdSelected: true,
        simSwapNotify: 'Y',
        enableEnforceApi: 'Y',
      };
      byodProps.omnicaredropdownValue = 'SIM only change';
      byodProps.customerProfileDetails.customer.channel = 'VZW-ACSS';
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    });

    test('Device Scan testing for sim id change', async () => {
      const simId = screen.queryAllByTestId('handleChangeSimID')[0];
      expect(simId).toBeInTheDocument();
      console.log();
      fireEvent.change(simId, { target: { value: '89148000002517712755' } });
      fireEvent.focus(simId, { target: { value: '89148000002517712755' } });
      fireEvent.blur(simId, { target: { value: '89148000002517712755' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });
  });

  describe(`DeviceSimID component fraud risk tests success- ${channel} onMount and Generate ESim Profile is available`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => res(ctx.status(200), ctx.json(validateDeviceByod))),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
      rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
        res(
          ctx.status(200),
          ctx.json({
            responseInfo: {
              errors: [],
              timeStamp: '15-11-2024 05:12:07',
              correlationId: 'smock_enforce_test',
              responseCode: '00',
              responseMessage: 'SUCCESS',
            },
            data: {
              sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
              custId: '0725665601',
              acctNum: '1',
              fraudRiskScore: '0',
              fraudRiskLevel: 'High Risk',
              loa: '0',
              mdn: '2153709209',
              notificationIndicator: 'Y',
              invokeIdScan: 'N',
            },
            status: 'fulfilled',
          }),
        ),
      ),
    ];
    const server = setupServer(...handlers);

    beforeAll(() => {
      window.mfe = { scmDeviceMfeEnable: true, isDark: true };
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    const renderComponent = () => {
      props.omnicaredropdownValue = 'SIM only change';
      const byodProps = {
        ...props,
        isLocal: false,
        isFromCPE: false,
        isByodUpdate: false,
        isRetail: false,
        omnicaredropdownValue: 'SIM only change',
        deviceIdSelected: true,
        simSwapNotify: 'Y',
        enableEnforceApi: 'Y',
        activeMtn: '7899808989',
        callESimApi: true,
        setCallESimApi: jest.fn(),
        setShowGetESimInOption: jest?.fn(),
      };
      byodProps.omnicaredropdownValue = 'SIM only change';
      byodProps.customerProfileDetails.customer.channel = 'OMNI-CARE';
      sessionStorage.setItem('enableSimValidation', 'false');
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    };

    test('Device Scan testing for sim id changes when isFunctionalityEnabled = true', async () => {
      renderComponent();

      // eslint-disable-next-line global-require
      jest.spyOn(require('../../../modules/utils'), 'isFunctionalityEnabled').mockReturnValue(true);

      const simId = screen.queryAllByTestId('handleChangeSimID')[0];
      expect(simId).toBeInTheDocument();

      fireEvent.change(simId, { target: { value: '89148000002517712755' } });
      fireEvent.focus(simId, { target: { value: '89148000002517712755' } });
      fireEvent.blur(simId, { target: { value: '89148000002517712755' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });

    test('Device Scan testing for sim id changes isFunctionalityEnabled = false', async () => {
      renderComponent();

      // eslint-disable-next-line global-require
      jest.spyOn(require('../../../modules/utils'), 'isFunctionalityEnabled').mockReturnValue(false);

      const simId = screen.queryAllByTestId('handleChangeSimID')[0];
      expect(simId).toBeInTheDocument();

      fireEvent.change(simId, { target: { value: '89148000002517712755' } });
      fireEvent.focus(simId, { target: { value: '89148000002517712755' } });
      fireEvent.blur(simId, { target: { value: '89148000002517712755' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });
  });

  describe(`DeviceSimID component fraud risk tests success- ${channel} onMount and makeEtniPersApi = false`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        const mockResp = { ...validateDeviceByod };
        mockResp.serviceBody.serviceResponse.context.deviceInfo.makeEtniPersApi = false;
        mockResp.serviceBody.serviceResponse.context.deviceInfo.simInfo2.makeEtniPersApi = false;
        return res(ctx.status(200), ctx.json(mockResp));
      }),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
      rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
        res(
          ctx.status(200),
          ctx.json({
            responseInfo: {
              errors: [],
              timeStamp: '15-11-2024 05:12:07',
              correlationId: 'smock_enforce_test',
              responseCode: '00',
              responseMessage: 'SUCCESS',
            },
            data: {
              sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
              custId: '0725665601',
              acctNum: '1',
              fraudRiskScore: '0',
              fraudRiskLevel: 'High Risk',
              loa: '0',
              mdn: '2153709209',
              notificationIndicator: 'Y',
              invokeIdScan: 'N',
            },
            status: 'fulfilled',
          }),
        ),
      ),
    ];
    const server = setupServer(...handlers);

    beforeAll(() => {
      window.mfe = { scmDeviceMfeEnable: true, isDark: true };
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    const renderComponent = () => {
      props.omnicaredropdownValue = 'SIM only change';
      const byodProps = {
        ...props,
        isLocal: false,
        isFromCPE: false,
        isByodUpdate: false,
        isRetail: false,
        omnicaredropdownValue: 'SIM only change',
        deviceIdSelected: true,
        simSwapNotify: 'Y',
        enableEnforceApi: 'Y',
        activeMtn: '7899808989',
        callESimApi: true,
        setCallESimApi: jest.fn(),
        setShowGetESimInOption: jest?.fn(),
      };
      byodProps.omnicaredropdownValue = 'SIM only change';
      byodProps.customerProfileDetails.customer.channel = 'OMNI-CARE';
      sessionStorage.setItem('enableSimValidation', 'false');
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    };

    test('Device Scan testing for sim id changes when isFunctionalityEnabled = true', async () => {
      renderComponent();

      // eslint-disable-next-line global-require
      jest.spyOn(require('../../../modules/utils'), 'isFunctionalityEnabled').mockReturnValue(true);

      const simId = screen.queryAllByTestId('handleChangeSimID')[0];
      expect(simId).toBeInTheDocument();

      fireEvent.change(simId, { target: { value: '89148000002517712755' } });
      fireEvent.focus(simId, { target: { value: '89148000002517712755' } });
      fireEvent.blur(simId, { target: { value: '89148000002517712755' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });
  });

  describe(`DeviceSimID component fraud risk tests success- ${channel} onMount and Generate ESim Profile is available but iccid missing`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => res(ctx.status(200), ctx.json(validateDeviceByod))),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        const mockEsimData = { ...eSimDetails };
        mockEsimData.data.iccid = null;
        return res(ctx.status(200), ctx.json(mockEsimData));
      }),
      rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
        res(
          ctx.status(200),
          ctx.json({
            responseInfo: {
              errors: [],
              timeStamp: '15-11-2024 05:12:07',
              correlationId: 'smock_enforce_test',
              responseCode: '00',
              responseMessage: 'SUCCESS',
            },
            data: {
              sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
              custId: '0725665601',
              acctNum: '1',
              fraudRiskScore: '0',
              fraudRiskLevel: 'High Risk',
              loa: '0',
              mdn: '2153709209',
              notificationIndicator: 'Y',
              invokeIdScan: 'N',
            },
            status: 'fulfilled',
          }),
        ),
      ),
    ];
    const server = setupServer(...handlers);

    beforeAll(() => {
      window.mfe = { scmDeviceMfeEnable: true, isDark: true };
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    const renderComponent = () => {
      props.omnicaredropdownValue = 'SIM only change';
      const byodProps = {
        ...props,
        isLocal: false,
        isFromCPE: false,
        isByodUpdate: false,
        isRetail: false,
        omnicaredropdownValue: 'SIM only change',
        deviceIdSelected: true,
        simSwapNotify: 'Y',
        enableEnforceApi: 'Y',
        activeMtn: '7899808989',
        callESimApi: true,
        setCallESimApi: jest.fn(),
        setShowGetESimInOption: jest?.fn(),
      };
      byodProps.omnicaredropdownValue = 'SIM only change';
      byodProps.customerProfileDetails.customer.channel = 'OMNI-CARE';
      sessionStorage.setItem('enableSimValidation', 'false');
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    };

    test('Device Scan testing for sim id changes', async () => {
      renderComponent();

      // eslint-disable-next-line global-require
      jest.spyOn(require('../../../modules/utils'), 'isFunctionalityEnabled').mockReturnValue(true);

      const simId = screen.queryAllByTestId('handleChangeSimID')[0];
      expect(simId).toBeInTheDocument();

      fireEvent.change(simId, { target: { value: '89148000002517712755' } });
      fireEvent.focus(simId, { target: { value: '89148000002517712755' } });
      fireEvent.blur(simId, { target: { value: '89148000002517712755' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });
  });

  describe(`DeviceSimID component fraud risk not enabled- ${channel} without auth - low risk when isFunctionalityEnabled = true`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => res(ctx.status(200), ctx.json(validateDeviceByod))),
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
      rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
        res(
          ctx.status(200),
          ctx.json({
            responseInfo: {
              errors: [],
              timeStamp: '15-11-2024 05:12:07',
              correlationId: 'smock_enforce_test',
              responseCode: '00',
              responseMessage: 'SUCCESS',
            },
            data: {
              sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
              custId: '0725665601',
              acctNum: '1',
              fraudRiskScore: '0',
              fraudRiskLevel: 'Low Risk',
              loa: '0',
              mdn: '2153709209',
              notificationIndicator: 'Y',
              invokeIdScan: 'N',
            },
            status: 'fulfilled',
          }),
        ),
      ),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      window.mfe = { scmDeviceMfeEnable: false };
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      props.omnicaredropdownValue = 'SIM only change';
      sessionStorage.setItem('enableSimValidation', 'false');
      const byodProps = {
        ...props,
        isLocal: false,
        isFromCPE: false,
        isByodUpdate: false,
        isRetail: false,
        omnicaredropdownValue: 'SIM only change',
        deviceIdSelected: false,
        simSwapNotify: 'Y',
        enableEnforceApi: 'Y',
        setShowGetESimInOption: jest.fn(),
      };
      byodProps.omnicaredropdownValue = 'SIM only change';
      byodProps.customerProfileDetails.customer.channel = 'OMNI-CARE';
      render(<DeviceSimID {...byodProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      window.vzdl = {
        ...window.vzdl,
        event: {
          value: 'event24',
        },
        page: {
          detail: '',
        },
      };
    });

    test('Device Scan testing for sim id change', async () => {
      // eslint-disable-next-line global-require
      jest.spyOn(require('../../../modules/utils'), 'isFunctionalityEnabled').mockReturnValue(true);

      const simId = screen.queryAllByTestId('simId')[0];
      expect(simId).toBeInTheDocument();
      console.log();
      fireEvent.change(simId, { target: { value: 'DFILLUNIV5G-SA-A' } });
      fireEvent.blur(simId, { target: { value: 'DFILLUNIV5G-SA-A' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });
  });
};

const Test1 = (channel) => {
  setupChannel(channel);
  const details = getSkuDetails?.data?.deviceSku?.parentProducts[0];

  const compatibleSims = details?.compatibleSimSorIds;
  const updateCpeCheckboxFlag = jest.fn();
  const props = {
    setRemoveSimOnlyChange: jest.fn(),
    lineDeviceIdFromLanding: '352766390095123',
    isNewLine: false,
    isVideoAssistFlow: false,
    activeMtn: '3193292139',
    isDWOS: false,
    isIndirect: false,
    compatibleSims,
    isBYODUpdateAALRetail: false,
    isCancel: jest.fn(),
    setSecondNumDeviceId: jest.fn(),
    sku: '',
    byodDevice: '',
    isByodUpdate: true,
    deviceFromCart: false,
    isLocal: true,
    isFromCPE: false,
    defaultDeviceId: '352766390095123',
    defaultSimId: '89148000005700881964',
    customerProfileDetails: customerProfileDetails.data,
    cartDetails: cartDetails?.data?.data,
    updateDeviceId: jest.fn(),
    updateSimId: jest.fn(),
    updateCpeCheckboxFlag,
    updateDeviceData: jest.fn(),
    setSimIdResult: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    simSwapFlowUpdateButtonDisabled: jest.fn(),
    setIsSecNumValidation: jest.fn(),
    setIncompatibleSim: jest.fn(),
    setUpcCodeFromPdpScan: jest.fn(),
    setCarrierLockDisableButton: jest.fn(),
    simType: 'eSIM',
  };

  describe(`<DeviceSimID component - ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        // Return mock response with eSIM capability
        const mockResponse = { ...validateDeviceSimIDInitial };
        
        // Make sure euiccCapable is 'Y'
        if (!mockResponse.serviceBody.serviceResponse.context.deviceInfo) {
          mockResponse.serviceBody.serviceResponse.context.deviceInfo = {};
        }
        mockResponse.serviceBody.serviceResponse.context.deviceInfo.euiccCapable = 'Y';
        mockResponse.serviceBody.serviceResponse.context.deviceInfo.eSIMOnly = true;
        
        // Set simInfo with a non-empty eID value
        mockResponse.serviceBody.serviceResponse.context.deviceInfo.simInfo = {
          ...mockResponse.serviceBody.serviceResponse.context.deviceInfo.simInfo,
          eID: 'sample-eid-value',
          iccid: '89148000005700881964',
          makeEtniPersApi: true
        };
        
        return res(ctx.status(200), ctx.json(mockResponse));
      }),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      // Mock query parameter for etrServiceChanges to enable flexFlowServiceChange flag

      window.mfe = { 
        isDark: true, 
        scmDeviceMfeEnable: true 
      };
      window.vzdl = {};
      
      render(<DeviceSimID {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });

    test('Regenerate eSIM link should be visible and clickable when simType is eSIM', async () => {
      // Wait for component to fully render
      
      // Verify the component is in the document
      const component = screen.getByTestId('DeviceSimID');
      expect(component).toBeInTheDocument();
      
      // Force setting the simType through event emission
      Emitter.emit('CONT_SIM_SKU_VALIDATION', {
        newVal: { simId: '89148000009101017319', deviceId: '352766390095123', simType: 'eSIM' },
        oldVal: '89148000005700881964'
      });
      
      // Wait longer for API and state updates
      
      try {
        // Try to find the regenerate eSIM link using findByTestId with a longer timeout
        const textLink = await screen.findByTestId('regenerateESim', {}, { timeout: 5000 });
        expect(textLink).toBeInTheDocument();
        
        // Test clicking the regenerate button
        fireEvent.click(textLink);
        
        // Verify the confirmation modal appears
        const confirmModal = await screen.findByText('A new eSIM will be generated. Proceed?');
        expect(confirmModal).toBeInTheDocument();
        
        // Test Yes button
        const yesBtn = await screen.findByRole('button', { name: 'Yes' });
        expect(yesBtn).toBeInTheDocument();
        fireEvent.click(yesBtn);
        
        // Test clicking the link again
        const textLinkAgain = await screen.findByTestId('regenerateESim', {}, { timeout: 5000 });
        fireEvent.click(textLinkAgain);
        
        // Test No button
        const noBtn = await screen.findByRole('button', { name: 'No' });
        expect(noBtn).toBeInTheDocument();
        fireEvent.click(noBtn);
      } catch (error) {
        // In case of error, dump the DOM content to help with debugging
        console.error('Failed to find regenerateESim element. Current DOM content:', document.body.innerHTML);
        throw error;
      }
    });
  });
};

Test(CHANNELS.OMNI_RETAIL);
Test1(CHANNELS.OMNI_RETAIL);
