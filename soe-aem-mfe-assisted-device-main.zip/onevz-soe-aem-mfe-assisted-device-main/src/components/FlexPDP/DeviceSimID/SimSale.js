import React, { useState } from 'react';
import styled from 'styled-components';
import { Input } from '@vds/inputs';
import { Icon } from '@vds/icons';
import { Checkbox } from '@vds/checkboxes';

import TimeoutManager from 'onevzsoemfecommon/TimeoutManager';
import { isIpad, executeShellFunction } from 'onevzsoemfeframework/DomService';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';

const InputWrapper = styled.div`
  display: flex;
  align-items: center;
  margin-top: 1rem;
  width: 21rem;
  div[id='simSale'] > span > span > div[class^='InputTextWrapper'] > p {
    display: none;
  }
  padding-bottom: 15px;
`;
const BarcodeIconWrapper = styled.div`
  display: flex;
  margin-top: 15px;
  padding-left: 15px;
  pointer-events: auto;
`;
const DivWrapper = styled.div`
  display: block;
  margin-top: 1rem;
`;

const SimSale = (props) => {
  const [simSkuError, setSimSkuError] = useState(false);
  const [isScanActive, setScanActive] = useState(false);
  const [simSkuNumber, setSimSkuNumber] = useState(props?.simSKU || '');

  const cleanUpEmitterFFlag = /true/i.test(getAssistedCradlePropertyV2(['cleanUpEmitterFFlag'])?.[0]);
  const timeoutManager = new TimeoutManager({ fileName: 'SimSale.js', enableFF: cleanUpEmitterFFlag });

  const handleSimSaleChange = (e) => {
    props.setSimSaleFlow(e.target.checked);
    sessionStorage.setItem('simSaleFlow', e.target.checked);
  };

  console.log('isIpad', isIpad());
  const simSkuBarCodeScannerCallback = (data) => {
    console.log(`simscan -1 - inside callback , ${JSON.stringify(data)}`);
    try {
      /* istanbul ignore else */
      if (isIpad()) {
        if (data.dataset.barcode === 'cancel') {
          setScanActive(false);
        } else {
          const barcodeData = data.dataset.barcode;
          /* istanbul ignore else */
          if (barcodeData) {
            const simSKU = barcodeData;

            setSimSkuNumber(simSKU);
            setScanActive(false);
            handleOnChangeSimSku({ target: { value: simSKU } });
          }
        }
      }
      // else {
      //   // handled desktop scan data
      //   handleChangeSimIDDesktop(data);
      // }
    } catch (e) {
      /* istanbul ignore next */
      console.log(`error in catch block, ${e}`);
    }
  };

  const scanSimIdBarCode = (e) => {
    window.simSkuBarCodeScannerCallback = simSkuBarCodeScannerCallback;
    setScanActive({
      isScanActive: !isScanActive,
    });

    console.log('We are in scanSimIdBarCode function');
    console.log('scanSimIdBarCode called');
    console.log(`isScanActive ${isScanActive}`);
    if (e) e.preventDefault();
    /* istanbul ignore else */
    if (isIpad()) {
      const str = 'window.simSkuBarCodeScannerCallback';
      timeoutManager.scheduleTimeout(() => {
        /* istanbul ignore next */
        if (isScanActive && window.simSkuBarCodeScannerCallback) {
          executeShellFunction('HolsterManager', 'activateBarcode', str, null);
          /* istanbul ignore next */
          timeoutManager.scheduleTimeout(() => {
            executeShellFunction('HolsterManager', 'deactivateBarcode', 'none', null);
          }, 20000);
        } else {
          console.log(
            'point-4 - inside scanSimSaleBarCode - else condition shell not called - isScanActive',
            isScanActive,
          );
          executeShellFunction('HolsterManager', 'deactivateBarcode', 'none', null);
        }
      }, 100);
    }
    // else {
    //   // desktop: set callback function first, then init scanner events for barcode scanning

    //   device?.barcodeScan?.registerBarcodeCallback(simSkuBarCodeScannerCallback);
    //   device?.barcodeScan?.scanBarcode();
    // }
  };

  const scanOnKeyDown = (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      scanSimIdBarCode();
    }
  };

  const handleOnChangeSimSku = (e) => {
    console.log('simID sim sale', props.simId);
    setSimSkuNumber(e.target.value);
    /* istanbul ignore else */
    if (props.validSimSku && props.validSimSku !== e.target.value) {
      setSimSkuError(true);
      props.setEnableBYODbtn(false);
    } else {
      setSimSkuError(false);
      props.setEnableBYODbtn(true);
    }
  };
  return (
    <div data-testid='sim-sale'>
      <DivWrapper>
        <Checkbox
          type='checkbox'
          name='SimSale Confirmation'
          onChange={handleSimSaleChange}
          checked={props.simSaleFlow}
          surface='light'
          label='SIM Sale'
          width='21rem'
          data-track='simSale'
        />
      </DivWrapper>
      {props.simSaleFlow && (
        <InputWrapper>
          <Input
            type='text'
            iconName=''
            name='simId'
            id='simSale'
            data-testid='handleChangeSimSKU'
            placeholder='Enter Sim ID'
            onChange={handleOnChangeSimSku}
            value={simSkuNumber}
            error={simSkuError}
            errorText='Please enter a valid SIM SKU'
            label='SIMSKU number'
            required
            surface='light'
            data-track='Productdetail_simSku'
          />
          {isIpad() && (
            <BarcodeIconWrapper>
              <span
                data-testid='scanSimIdBarCode'
                tabIndex='0'
                aria-label='scanner'
                role='button'
                onClick={(e) => scanSimIdBarCode(e)}
                onKeyDown={(e) => scanOnKeyDown(e)}
                data-track='Productdetail_scanSimIdBarCode'
              >
                <Icon name='barcode' size='XLarge' lineColor='#000000' />
              </span>
            </BarcodeIconWrapper>
          )}
        </InputWrapper>
      )}

      {/* {isModalOpen && (
        <IDScanModal
          isOpen={isModalOpen}
          handleGetUpdateOldSimId={props.handleGetUpdateOldSimId}
          handleModelChange={handleModelChange}
          correlationId={props?.correlationId}
          closeModal={closeModal}
          simswapSessionId={deviceInfo?.simswapSessionId}
          cartDetails={props?.cartDetails}
          customerProfileDetails={props?.customerProfileDetails}
          activeMtn={activeMtn || getQueryParamByName('activeMtn')}
          setMitekIdVerifyStatus={props?.setMitekIdVerifyStatus}
        />
      )} */}
    </div>
  );
};

export default SimSale;
