import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import { CHANNELS, setupChannel } from '../../../modules/test-utils/utils';
import DeviceSimID from './DeviceSimID';
import omniCareCustomerProfileDetails from '../../../pages/PDP/mocks/api/omniCareCustomerProfile.json';
import getSkuDetails from '../../../pages/PDP/mocks/api/getSkuDetails.json';
import validateDeviceSimId from '../../../pages/PDP/mocks/api/validateDeviceEsim.json';
import validateDeviceSimId2 from '../../../pages/PDP/mocks/api/validateDeviceSimId2.json';
import eSimDetails from '../../../pages/PDP/mocks/api/eSimDetails.json';

jest.setTimeout(50000);
jest.mock(
  'onevzsoemfecommon/Helpers',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getQueryParamByName: jest.fn(() => {}),
    getUIContextPath: jest.fn(() => {}),
    getUIContextPathBAU: jest.fn(() => {}),
    isNumeric: jest.fn(() => {}),
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradleProperty: () => ['TRUE', 'TRUE', '', '', '', '', '', 'TRUE'],
    getAssistedCradlePropertyV2: () => ['TRUE', 'TRUE', '', '', '', '', 'TRUE'],
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => true,
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);
const Test = (channel) => {
  setupChannel(channel);
  const details = getSkuDetails?.data?.deviceSku?.parentProducts[0];

  const compatibleSims = details?.compatibleSimSorIds;
  const updateCpeCheckboxFlag = jest.fn();
  const props = {
    lineDeviceIdFromLanding: '353756110808409',
    isNewLine: false,
    isVideoAssistFlow: false,
    activeMtn: '5185673926',
    isDWOS: false,
    isIndirect: false,
    compatibleSims,
    isBYODUpdateAALRetail: false,
    isCancel: jest.fn(),
    sku: '',
    byodDevice: '',
    isByodUpdate: false,
    deviceFromCart: false,
    isLocal: true,
    isFromCPE: false,
    defaultDeviceId: '353756110808409',
    defaultSimId: '89148000005700881964',
    customerProfileDetails: omniCareCustomerProfileDetails.data,
    cartDetails: {},
    updateDeviceId: jest.fn(),
    updateSimId: jest.fn(),
    updateCpeCheckboxFlag,
    updateDeviceData: jest.fn(),
    setSimIdResult: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    simSwapFlowUpdateButtonDisabled: jest.fn(),
    setIsSecNumValidation: jest.fn(),
    setIncompatibleSim: jest.fn(),
    setUpcCodeFromPdpScan: jest.fn(),
    setRemoveSimOnlyChange: jest.fn(),
  };
  describe(`<DeviceSimID component with out simId wrapper- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceSimId));
      }),
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);

    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      window.history.pushState(
        {},
        'Host',
        '/product-detail.html?simId=123456&deviceId=54321&scanFromLanding=true&prospectByodFlow=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7&isEditAndView=true',
      );
      render(<DeviceSimID {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });
    test('Should visible Sim SKU Input field', async () => {
      delete window.location;
      window.location = new URL(
        '/product-detail.html?simId=123456&deviceId=54321&isEditAndView=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7',
        'http://localhost:3000/content/vcg/assisted',
      );
      const enterSimSKU = screen.getByLabelText('Sim SKU', { selector: 'input' });
      expect(enterSimSKU).toBeInTheDocument();
      fireEvent.blur(enterSimSKU, { target: { value: '987653563636' } });
      fireEvent.blur(enterSimSKU, { target: { value: 'DFILLUNIV5G-SA-A' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });
  });
  describe(`<DeviceSimID component with out simId wrapper- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceSimId2));
      }),
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);

    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      window.history.pushState(
        {},
        'Host',
        '/product-detail.html?simId=123456&deviceId=54321&scanFromLanding=true&prospectByodFlow=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7&isEditAndView=true',
      );
      const indirectProps = {
        ...props,
        isIndirect: true,
      };
      render(<DeviceSimID {...indirectProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });
    test('Should visible Sim SKU Input field', async () => {
      delete window.location;
      window.location = new URL(
        '/product-detail.html?simId=123456&deviceId=54321&isEditAndView=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7',
        'http://localhost:3000/content/vcg/assisted',
      );
      const enterSimSKU = screen.getByLabelText('Sim SKU', { selector: 'input' });
      expect(enterSimSKU).toBeInTheDocument();
      fireEvent.blur(enterSimSKU, { target: { value: '987653563636' } });
      fireEvent.blur(enterSimSKU, { target: { value: 'DFILLUNIV5G-SA-A' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });
  });

  describe(`<DeviceSimID component with out simId wrapper- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceSimId2));
      }),
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);

    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      Object.defineProperty(window, 'mfe', {
        value: { scmDeviceMfeEnable: true },
        configurable: true,
      });
      window.history.pushState(
        {},
        'Host',
        '/product-detail.html?simId=123456&deviceId=54321&scanFromLanding=true&prospectByodFlow=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7&isEditAndView=true',
      );
      sessionStorage.setItem('enableSimValidation', false);
      render(<DeviceSimID {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });
    test.skip('Should visible Sim SKU Input field', async () => {
      delete window.location;
      window.location = new URL(
        '/product-detail.html?simId=123456&deviceId=54321&isEditAndView=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7',
        'http://localhost:3000/content/vcg/assisted',
      );
      const enterSimSKU = screen.getByLabelText('Sim SKU', { selector: 'input' });
      expect(enterSimSKU).toBeInTheDocument();
      fireEvent.blur(enterSimSKU, { target: { value: '987653563636' } });
      fireEvent.blur(enterSimSKU, { target: { value: 'DFILLUNIV5G-SA-A' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });
  });
};
const Test2 = (channel) => {
  setupChannel(channel);
  const details = getSkuDetails?.data?.deviceSku?.parentProducts[0];

  const compatibleSims = details?.compatibleSimSorIds;
  const updateCpeCheckboxFlag = jest.fn();
  const props = {
    omnicaredropdownValue: 'SIM only change',
    lineDeviceIdFromLanding: '353756110808409',
    isNewLine: false,
    isVideoAssistFlow: false,
    activeMtn: '5185673926',
    isDWOS: false,
    isIndirect: false,
    compatibleSims,
    isBYODUpdateAALRetail: false,
    isCancel: jest.fn(),
    sku: '',
    byodDevice: '',
    isByodUpdate: 'true',
    deviceFromCart: false,
    isLocal: true,
    isFromCPE: false,
    defaultDeviceId: '353756110808409',
    defaultSimId: '89148000005700881964',
    customerProfileDetails: omniCareCustomerProfileDetails.data,
    cartDetails: {},
    updateDeviceId: jest.fn(),
    updateSimId: jest.fn(),
    updateCpeCheckboxFlag,
    updateDeviceData: jest.fn(),
    setSimIdResult: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    simSwapFlowUpdateButtonDisabled: jest.fn(),
    setIsSecNumValidation: jest.fn(),
    setIncompatibleSim: jest.fn(),
    setUpcCodeFromPdpScan: jest.fn(),
  };
  describe(`<DeviceSimID component with out simId wrapper- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceSimId2));
      }),
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);

    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      window.history.pushState(
        {},
        'Host',
        '/product-detail.html?simId=123456&deviceId=54321&scanFromLanding=true&prospectByodFlow=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7&isEditAndView=true',
      );
      render(<DeviceSimID {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });
    test('Should visible Sim SKU Input field', async () => {
      delete window.location;
      window.location = new URL(
        '/product-detail.html?simId=123456&deviceId=54321&isEditAndView=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7',
        'http://localhost:3000/content/vcg/assisted',
      );
      const enterSimSKU = screen.getByLabelText('Sim SKU', { selector: 'input' });
      expect(enterSimSKU).toBeInTheDocument();
      fireEvent.blur(enterSimSKU, { target: { value: '987653563636' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });
  });
  describe(`<DeviceSimID component with out simId wrapper- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceSimId));
      }),
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);

    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      window.history.pushState(
        {},
        'Host',
        '/product-detail.html?simId=123456&deviceId=54321&scanFromLanding=true&prospectByodFlow=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7&isEditAndView=true',
      );
      const indirectProps = {
        ...props,
        isIndirect: true,
      };
      render(<DeviceSimID {...indirectProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });
    test('Should visible Sim SKU Input field', async () => {
      delete window.location;
      window.location = new URL(
        '/product-detail.html?simId=123456&deviceId=54321&isEditAndView=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7',
        'http://localhost:3000/content/vcg/assisted',
      );
      const enterSimSKU = screen.getByLabelText('Sim SKU', { selector: 'input' });
      expect(enterSimSKU).toBeInTheDocument();
      fireEvent.blur(enterSimSKU, { target: { value: '987653563636' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });
  });

  describe(`<DeviceSimID component with out simId wrapper- ${channel}`, () => {
    const handlers = [
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /flexV2/validate-deviceSimId');
        return res(ctx.status(200), ctx.json(validateDeviceSimId));
      }),
      rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(eSimDetails));
      }),
    ];
    const server = setupServer(...handlers);

    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    beforeEach(() => {
      Object.defineProperty(window, 'mfe', {
        value: { scmDeviceMfeEnable: true },
        configurable: true,
      });
      window.history.pushState(
        {},
        'Host',
        '/product-detail.html?simId=123456&deviceId=54321&scanFromLanding=true&prospectByodFlow=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7&isEditAndView=true',
      );
      sessionStorage.setItem('enableSimValidation', false);
      render(<DeviceSimID {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });
    test.skip('Should visible Sim SKU Input field', async () => {
      delete window.location;
      window.location = new URL(
        '/product-detail.html?simId=123456&deviceId=54321&isEditAndView=true&fromPage=CombinedGridwall&defaultSku=GA03850-US&flowType=etrRecommendations&mtn=c066c03a99e1914799dc70a370922c89cc1e2ff4709581e73be3dec03dec97f7',
        'http://localhost:3000/content/vcg/assisted',
      );
      const enterSimSKU = screen.getByLabelText('Sim SKU', { selector: 'input' });
      expect(enterSimSKU).toBeInTheDocument();
      fireEvent.blur(enterSimSKU, { target: { value: '987653563636' } });
      await new Promise((res) => {
        setTimeout(res, 3000);
      });
    });
  });
};

Test(CHANNELS.OMNI_CARE);
Test2(CHANNELS.OMNI_CARE);
