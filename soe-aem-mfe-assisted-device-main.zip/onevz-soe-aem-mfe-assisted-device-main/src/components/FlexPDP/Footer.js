import styled from 'styled-components';
import { Button } from '@vds/buttons';
import PropTypes from 'prop-types';
import { useState } from 'react';
import { getQueryParamByName } from 'onevzsoemfeframework/DomService';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import IncompatibleModal from './IncompatibleModal';
import { LIGHT_BG_COLOR } from '../../constants/constants';
import { Modal, ModalBody, ModalTitle } from '@vds/modals';
import { Title } from '@vds/typography';

const FooterArea = styled.div`
  background-color: ${(props) => (props.isDark ? props.bgColor : LIGHT_BG_COLOR)};
  bottom: 0px;
  display: flex;
  flex-wrap: wrap;
  width: 252px;
  button:enabled:focus {
    color: white;
  }
`;

function Footer(props) { // NOSONAR /* This will be replaced with Legacy code */
  const {
    btnLabel,
    callDeviceAddToCart,
    isCartBtnEnable,
    deviceFromCart,
    isDWOS,
    disableUpdateBtn,
    removeLines,
    disableUpdateButtonSimFlow,
    isPdpUpdated,
    ispuItemInCart,
    navigateToIspu,
    isDropshipDisabled,
    rfexOnProfileFlow,
    isBBYLocalOrder,
    disableFooter,
    devicePricingEnabled,
    upcAndDeviceIdCheckEnabled,
    isAcssDfillSim,
    carrierLockDisableButton,
    isPastbalBackOrderWithDueAmount,
    isShipItToggleOn,
    showPlanChange,
    routeToPlans,
    localOnlyLocation,
    showISPULocalConflictBanner,
    isSelectedDeviceByod
  } = props;
  const bgColor = window?.mfe?.scmDeviceMfeEnable && window?.mfe?.themeProps?.background;
  const isDark = (window?.mfe?.scmDeviceMfeEnable && window?.mfe?.isDark) || false;
  const { isPromoEligible = true } = props;
  const [inEligibleDevice, setIinEligibleDevice] = useState(false);
  const prospectByodFlow = getQueryParamByName('prospectByodFlow');
  const prospectByodFlowcompitable = getQueryParamByName('ByodDeviceCompitable');
  const isDWOSFlow = getQueryParamByName('isDWOS') || ''; // for DWOS flow we are sending Y
  const [isDeviceCompatible, isBackOrderPastDueCheckFFlag, indirectLocalOnlyOrderFFlag] = getAssistedCradlePropertyV2([
    'isDeviceCompatible',
    'isBackOrderPastDueCheckFFlag',
    'indirectLocalOnlyOrderFFlag'
  ]);
  const isSecondNumDfill = sessionStorage.getItem('isSecondNumDfill');
  const [showPaymentConfirmationModal, setShowConfirmationModal] = useState(false);

  const enableInEligibleDevice = () => {
    setIinEligibleDevice(!inEligibleDevice);
  };
  const handleDeviceCall = () => {
    setShowConfirmationModal(true)
  };

  const handleAddDeviceCall = () => {
    if (deviceFromCart || (deviceFromCart && !isDWOS)) {
      callDeviceAddToCart();
    } else {
      AddDeviceCall();
    }
  }

  const handleModalOk = () => {
    setShowConfirmationModal(false)
    handleAddDeviceCall()
  }

  const handleModalClose = () => {
    setShowConfirmationModal(false);
  };

  const handleModal = () => {
    props?.setSecondNumberWarningModal(true);
  };
  const AddDeviceCall = () => {
    if (
      (isPromoEligible === true && !(prospectByodFlow === 'false' && prospectByodFlowcompitable === 'false')) ||
      isDWOSFlow === 'Y'
    ) {
      callDeviceAddToCart();
    } else if (
      !window?.mfe?.scmDeviceMfeEnable &&
      (((prospectByodFlow === null || prospectByodFlow === 'false') && isPromoEligible === false) ||
        (prospectByodFlow === 'false' && prospectByodFlowcompitable === 'false') ||
        (prospectByodFlow === 'true' && prospectByodFlowcompitable === 'false')) &&
      isDeviceCompatible === 'TRUE'
    ) {
      enableInEligibleDevice();
    } else {
      callDeviceAddToCart();
    }
  };

  let enableFooterCTA = isBBYLocalOrder
    ? devicePricingEnabled || upcAndDeviceIdCheckEnabled || disableFooter || showISPULocalConflictBanner
    : !isCartBtnEnable ||
      disableUpdateButtonSimFlow ||
      (props?.dpEligibilityCallFailure && props?.contractType === 'DEVICE_PAYMENT') ||
      isDropshipDisabled ||
      rfexOnProfileFlow || showISPULocalConflictBanner;
  /* istanbul ignore next */   
  enableFooterCTA = enableFooterCTA || (indirectLocalOnlyOrderFFlag === 'TRUE' && btnLabel === 'Ship It' && localOnlyLocation);

  const isBackOrderPastDue = !!isBackOrderPastDueCheckFFlag && isShipItToggleOn && isPastbalBackOrderWithDueAmount;
  const isHandleDeviceCall = isSelectedDeviceByod ? handleDeviceCall : handleAddDeviceCall
  return (
    <>
      {console.log(
        devicePricingEnabled,
        'footerProps',
        upcAndDeviceIdCheckEnabled,
        isCartBtnEnable,
        disableUpdateButtonSimFlow,
        props?.dpEligibilityCallFailure,
        props?.contractType,
        isDropshipDisabled,
        enableFooterCTA,
        devicePricingEnabled && upcAndDeviceIdCheckEnabled,
        disableFooter,
      )}
      <FooterArea isDark={isDark} bgColor={bgColor}>
        {inEligibleDevice && (
          <IncompatibleModal
            showModal={inEligibleDevice}
            setIinEligibleDevice={setIinEligibleDevice}
            onAddDeviceToCart={callDeviceAddToCart}
            activeMtn={props.activeMtn}
            onClose={enableInEligibleDevice}
          />
        )}
        {(btnLabel === 'Add to Cart' ||
          (!isAcssDfillSim && btnLabel === 'Ship It') ||
          btnLabel === 'Update' ||
          btnLabel === 'BYTD' ||
          btnLabel === 'Pick Up') &&
          !deviceFromCart &&
          !isSecondNumDfill && (
            <>
              {isDropshipDisabled && <div>This item is unavailable.</div>}
              <Button
                width='154px'
                size='large'
                inverted
                secondary
                surface={isDark ? 'dark' : 'light'}
                onClick={props?.checkSecondNumberFlag ? handleModal : isHandleDeviceCall}
                disabled={enableFooterCTA}
                data-track={btnLabel}
              >
                {btnLabel}
              </Button>
            </>
          )}
        {showPaymentConfirmationModal && (
          <Modal
            ariaLabel="Confirm phone upgrade"
            opened={showPaymentConfirmationModal}
            onOpenedChange={setShowConfirmationModal}
            disableOutsideClick={true}
            surface={isDark ? 'dark' : 'light'}
            hideCloseButton={false}
            onCloseButtonClick={handleModalClose}
          >
            <ModalTitle>
              <Title size='large' bold={true} style={{ marginBottom: '2rem' }}>
                Confirm phone upgrade
              </Title>
            </ModalTitle>
            <ModalBody style={{ marginBottom: '3rem', fontSize: '1rem', lineHeight: '1.6' }}>
              By upgrading the device, the customers BYOD+ discount will be removed and cannot be readded.
              <div style={{ display: 'flex', gap: '1rem', justifyContent: 'left', marginTop: '3rem' }}>
                <Button
                  use='primary'
                  onClick={handleModalOk}
                  surface={isDark ? 'dark' : 'light'}
                >
                  OK
                </Button>
              </div>
            </ModalBody>
          </Modal>
        )}
        {((isAcssDfillSim && btnLabel === 'Ship It') || btnLabel === 'BYOD') &&
          !deviceFromCart &&
          !isSecondNumDfill && (
            <Button
              width='154px'
              size='large'
              inverted
              secondary
              disabled={
                !props?.enableBYODbtn ||
                disableUpdateButtonSimFlow ||
                (props?.incompatibleSim && props?.rfexMfeFlow) ||
                carrierLockDisableButton
              }
              onClick={showPlanChange ? routeToPlans : callDeviceAddToCart}
              data-track={btnLabel}
              surface={isDark ? 'dark' : 'light'}
            >
              {showPlanChange ? 'Plan Change' : btnLabel}
            </Button>
          )}

        {btnLabel === 'Find Stores' && !deviceFromCart && (
          <Button size='large' disabled={!isCartBtnEnable} data-track={btnLabel}>
            {btnLabel}
          </Button>
        )}
      </FooterArea>
      {(deviceFromCart || isSecondNumDfill) && (
        <FooterArea isDark={isDark} bgColor={bgColor}>
          <>
            {!isSecondNumDfill && (
              <Button
                inverted
                secondary
                size='large'
                data-track='Remove'
                label='Remove'
                data-testid='remove'
                surface={isDark ? 'dark' : 'light'}
                style={{ marginRight: '10px', marginBottom: '10px', width: '154px' }}
                onClick={removeLines}
              >
                Remove
              </Button>
            )}
            {((!isDWOS && !ispuItemInCart) || isSecondNumDfill) && (
              <Button
                inverted
                secondary
                size='large'
                style={{ marginBottom: '10px', width: '154px' }}
                data-track='Update'
                disabled={disableUpdateBtn || disableUpdateButtonSimFlow || isBackOrderPastDue}
                label='Update'
                surface={isDark ? 'dark' : 'light'}
                data-testid='update'
                onClick={handleAddDeviceCall}
              >
                Update
              </Button>
            )}
            {ispuItemInCart && !isPdpUpdated && (
              <Button
                inverted
                secondary
                size='large'
                style={{ marginBottom: '10px', width: '154px' }}
                disabled={!isCartBtnEnable}
                data-track='Find Stores'
                surface={isDark ? 'dark' : 'light'}
                onClick={navigateToIspu}
              >
                Find Stores
              </Button>
            )}
          </>
        </FooterArea>
      )}
    </>
  );
}
export default Footer;

Footer.propTypes = {
  btnLabel: PropTypes.string,
  isAcssDfillSim: PropTypes.bool,
  callDeviceAddToCart: PropTypes.func,
  isCartBtnEnable: PropTypes.bool,
  activeMtn: PropTypes.any,
  isPromoEligible: PropTypes.bool,
  enableBYODbtn: PropTypes.bool,
  isPdpUpdated: PropTypes.bool,
  ispuItemInCart: PropTypes.bool,
  navigateToIspu: PropTypes.func,
  dpEligibilityCallFailure: PropTypes.bool,
  carrierLockDisableButton: PropTypes.bool.isRequired,
  showPlanChange: PropTypes.bool,
  routeToPlans: PropTypes.func,
};
