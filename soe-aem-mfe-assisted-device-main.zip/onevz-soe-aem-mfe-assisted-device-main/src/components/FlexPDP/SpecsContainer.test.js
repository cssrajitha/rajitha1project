import React from 'react';
import SpecsContainer from './SpecsContainer';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { render, screen } from '../../modules/test-utils/renderHelper';

describe('smartWatch size component render', () => {
  const props = {
    selectedSku: {},
    skus: undefined,
  };
  beforeEach(() => {
    render(<SpecsContainer {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('it should mount', () => {
    render(<SpecsContainer {...props} />);
  });
});

describe('smartWatch size component render', () => {
  const props = {
    title: 'test',
    subtitle: 'user',
  };
  beforeEach(() => {
    render(<SpecsContainer {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('it should mount', () => {
    const specsContainerid = screen.getByTestId('specsContainerid');
    expect(specsContainerid).toBeInTheDocument();
  });
});
