import './DeviceLockInfo.css';
import React from 'react';
import styled from 'styled-components';
import { Title } from '@vds/typography';
import { Icon } from '@vds/icons';

const DetailContainer = styled.div`
  padding: 2rem;
`;

const HeaderContainer = styled.div`
  border-bottom: 1px solid #d8dada;
  padding: 1.25rem;
`;

const FlexRowSpace = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
`;

function DeviceLockInfo(props) {
  const { hideModal, htmlContent } = props;
  return (
    <div data-testid='DeviceLockInfo' className='BuyoutAmount-Modal DeviceLockInfo'>
      <div className='BuyoutAmount-Modal-inner u-borderTopGray'>
        <HeaderContainer>
          <FlexRowSpace>
            <span onClick={hideModal} style={{ cursor: 'pointer' }} onKeyDown={{}} tabIndex={0} role='button'>
              <Icon name='left-caret' size='large' color='#000' />
              &nbsp;
            </span>
            <Title data-testid='headerText' color='#000000' size='small' primitive='p' bold>
              Important device lock information
            </Title>
          </FlexRowSpace>
        </HeaderContainer>
        <DetailContainer>
          <div dangerouslySetInnerHTML={{ __html: htmlContent }} />
        </DetailContainer>
      </div>
    </div>
  );
}

export default DeviceLockInfo;
