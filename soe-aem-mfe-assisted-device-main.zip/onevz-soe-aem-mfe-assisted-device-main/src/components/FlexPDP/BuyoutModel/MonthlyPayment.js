import React, { useState } from 'react';
import { Body } from '@vds/typography';
import styled from 'styled-components';
import { Tooltip } from '@vds/tooltips';
import { RadioButtonGroup } from '@vds/radio-buttons';
import { Button } from '@vds/buttons';
import { Modal, ModalBody } from '@vds/modals';
import { trainingFlag } from 'onevzsoemfecommon/Helpers/validation';
import { useLazyUpdateConsentQuery } from 'onevzsoemfecommon/CommonService';
import { DARK_THEME_COLOR } from '../../../constants/constants';
// import { useLazyUpdateConsentQuery } from '../../../modules/services/APIService/APIServiceHooks';

const MarginSides = styled.div`
  margin: 0 3rem;
`;

const MaxWidth = styled.div`
  [class^='ModalDialog-VDS-'] {
    max-width: 1133px;
  }
`;
const StyledButton = styled.div`
  padding-top: 25px;
`;

const ModalBodyContent = styled.div`
  width: 60%;
  margin-left: auto;
  margin-right: auto;
  margin-top: 100px;
`;

const SubBody = styled.p`
  margin-top: 30px;
  line-height: 1.25rem;
  font-size: 1rem;
  font-family: Verizon-NHG-eDS;
  letter-spacing: 0.03125rem;
  cursor: pointer;
  color: ${({ isDark }) => (isDark ? DARK_THEME_COLOR : 'rgb(0, 0, 0)')};
`;
const RadioPanel = styled.div`
  label {
    ::before {
      content: none !important;
    }
    div {
      ::after {
        content: none !important;
      }
      span {
        ::after {
          content: none !important;
        }
      }
    }
  }
`;
const MonthlyPayment = (props) => {
  const { CustomerData, onClose } = props;
  const financeOptions = ['paymentYes', 'paymentNo'];
  const [financeOption, setFinanceOption] = useState('');
  const [updateConsentReq, updateConsentResults] = useLazyUpdateConsentQuery();
  console.log(updateConsentResults, 'updateConsentResults2');
  const isOmniCareTrainingUser = trainingFlag() || false;
  const toolTipContent = (
    <div>
      <div>Evaluates customer's credit without impacting credit score to determine : </div>
      <ul>
        <li>Eligiblity</li>
        <li>Down Payment</li>
        <li>Spending balance</li>
      </ul>
    </div>
  );
  const financeOptionSelection = (e) => {
    setFinanceOption(e.target.value);
  };
  const onContinue = () => {
    const { cartId, customerAttributes } = CustomerData;
    if (financeOption === financeOptions[0]) {
      const request = {
        customerConsent: 'Y',
        cartId,
        intendType: customerAttributes?.customerType === 'N' ? 'NSE' : null,
      };
      updateConsentReq({ body: request });
      onClose();
    } else {
      const request = {
        customerConsent: 'N',
        cartId,
        intendType: customerAttributes?.customerType === 'N' ? 'NSE' : null,
      };
      updateConsentReq({ body: request });
      onClose();
    }
  };
  const scmDeviceEnable = window?.mfe?.scmDeviceMfeEnable || false;
  const isDark = (window?.mfe?.scmDeviceMfeEnable && window?.mfe?.isDark) || false;

  return (
    <MaxWidth data-testid='buyoutamount-modal'>
      <Modal
        opened={props.opened}
        surface={isDark ? 'dark' : 'light'}
        fullScreenDialog={!scmDeviceEnable}
        disableAnimation={false}
        disableOutsideClick={scmDeviceEnable}
        width={scmDeviceEnable ? '850px' : '100%'}
        closeButton={<div />}
        ariaLabel='Testing Modal'
      >
        <MarginSides>
          <ModalBody>
            <ModalBodyContent>
              <Body size='large' bold color={isDark ? DARK_THEME_COLOR : '#000000'}>
                To determine your financing options for a purchase, we need your consent to run a soft credit check.
                This review will not affect your credit score, and your consent will be valid for 30 days.{' '}
              </Body>
              <SubBody isDark={isDark}>
                Customer understands and consents to proceed with the{'  '}
                <b>credit review process?</b>
                <div>
                  <Tooltip id='monthly payment' surface={isDark ? 'dark' : 'light'}>
                    {toolTipContent}
                  </Tooltip>
                </div>
              </SubBody>
              <RadioPanel>
                <RadioButtonGroup
                  onChange={(e) => financeOptionSelection(e)}
                  surface={isDark ? 'dark' : 'light'}
                  defaultValue={props?.VDSUpgradationFFlag || true}
                  data={[
                    {
                      name: 'payment',
                      children: 'Yes, show me my financing options',
                      value: financeOptions[0],
                      ariaLabel: 'yes',
                      selected: financeOption === financeOptions[0],
                    },
                    {
                      name: 'payment',
                      children: 'No, continue without a credit review. Customer not financing device.',
                      value: financeOptions[1],
                      ariaLabel: 'no',
                      selected: financeOption === financeOptions[1],
                      disabled: isOmniCareTrainingUser,
                    },
                  ]}
                />
              </RadioPanel>
              <StyledButton>
                <Button
                  onClick={() => onContinue()}
                  data-testid='continueBtn'
                  disabled={!financeOption}
                  surface={isDark ? 'dark' : 'light'}
                  data-track={
                    financeOption === financeOptions[0]
                      ? 'continue_showFinacingOptions'
                      : 'continue_without_creditReview'
                  }
                >
                  Continue
                </Button>
              </StyledButton>
            </ModalBodyContent>
          </ModalBody>
        </MarginSides>
      </Modal>
    </MaxWidth>
  );
};
export default MonthlyPayment;
