import React from 'react';
import { trainingFlag } from 'onevzsoemfecommon/Helpers/validation';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import MonthlyPayment from './MonthlyPayment';
import * as APIServiceHooks from '../../../modules/services/APIService/APIServiceHooks';

jest.mock('../../../modules/services/APIService/APIServiceHooks', () => ({
  useLazyUpdateConsentQuery: jest.fn(),
}));

// Mock the trainingFlag function
jest.mock('onevzsoemfecommon/Helpers/validation', () => ({
  trainingFlag: jest.fn(),
}));

describe('MonthlyPayment', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  beforeEach(() => {
    jest.resetAllMocks();
    // Mock trainingFlag to return false by default for these tests
    trainingFlag.mockReturnValue(false);
  });
  const mockCustomerData = {
    cartId: 'testCartId',
    customerAttributes: { customerType: 'N' },
  };
  let mockUpdateConsentQuery = jest.fn();
  let mockUpdateConsentResults = {};
  const renderComponent = () => {
    mockUpdateConsentQuery = jest.fn();
    mockUpdateConsentResults = {};
    APIServiceHooks.useLazyUpdateConsentQuery.mockImplementation(() => [
      mockUpdateConsentQuery,
      mockUpdateConsentResults,
    ]);
    render(<MonthlyPayment opened CustomerData={mockCustomerData} onClose={() => {}} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  };

  it('renders MonthlyPayment component with default state', () => {
    renderComponent();

    expect(screen.getByTestId('buyoutamount-modal')).toBeInTheDocument();
    expect(screen.getByText(/To determine your financing options/i)).toBeInTheDocument();
    expect(screen.getByTestId('continueBtn')).toBeDisabled();
  });

  it('selects "Yes, show me my financing options" and clicks Continue', async () => {
    renderComponent();
    fireEvent.click(await screen.getByText('Yes, show me my financing options'));
    fireEvent.click(await screen.getByTestId('continueBtn'));
  });

  it('selects "No, continue without a credit review" and clicks Continue', async () => {
    renderComponent();
    fireEvent.click(screen.getByText('No, continue without a credit review. Customer not financing device.'));
    fireEvent.click(screen.getByTestId('continueBtn'));
  });
});

describe('MonthlyPayment with Device MFE flag enabled', () => {
  beforeAll(() => {
    window.mfe = { scmDeviceMfeEnable: true, isDark: true };
  });
  beforeEach(() => {
    jest.resetAllMocks();
    // Mock trainingFlag to return false by default for these tests
    trainingFlag.mockReturnValue(false);
  });
  const mockCustomerData = {
    cartId: 'testCartId',
    customerAttributes: { customerType: 'N' },
  };
  let mockUpdateConsentQuery = jest.fn();
  let mockUpdateConsentResults = {};
  const renderComponent = () => {
    mockUpdateConsentQuery = jest.fn();
    mockUpdateConsentResults = {};
    APIServiceHooks.useLazyUpdateConsentQuery.mockImplementation(() => [
      mockUpdateConsentQuery,
      mockUpdateConsentResults,
    ]);
    render(<MonthlyPayment opened CustomerData={mockCustomerData} onClose={() => {}} VDSUpgradationFFlag />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  };

  it('renders MonthlyPayment component with default state', () => {
    renderComponent();

    expect(screen.getByTestId('buyoutamount-modal')).toBeInTheDocument();
    expect(screen.getByText(/To determine your financing options/i)).toBeInTheDocument();
    expect(screen.getByTestId('continueBtn')).toBeDisabled();
  });

  it('selects "Yes, show me my financing options" and clicks Continue', async () => {
    renderComponent();
    fireEvent.click(await screen.getByText('Yes, show me my financing options'));
    fireEvent.click(await screen.getByTestId('continueBtn'));
  });

  it('selects "No, continue without a credit review" and clicks Continue', async () => {
    renderComponent();
    fireEvent.click(screen.getByText('No, continue without a credit review. Customer not financing device.'));
    fireEvent.click(screen.getByTestId('continueBtn'));
  });
});

describe('MonthlyPayment - isOmniCareTrainingUser logic', () => {
  beforeEach(() => {
    jest.resetAllMocks();
  });

  it('disables "No" option if isOmniCareTrainingUser is true', () => {
    // Mock trainingFlag to return true
    trainingFlag.mockReturnValue(true);

    const mockCustomerData = {
      cartId: 'testCartId',
      customerAttributes: { customerType: 'N' },
    };
    APIServiceHooks.useLazyUpdateConsentQuery.mockImplementation(() => [jest.fn(), {}]);
    render(<MonthlyPayment opened CustomerData={mockCustomerData} onClose={() => {}} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    const noOption = screen.getByLabelText('no');
    expect(noOption).toBeDisabled();
  });

  it('enables "No" option if isOmniCareTrainingUser is false', () => {
    // Mock trainingFlag to return false
    trainingFlag.mockReturnValue(false);

    const mockCustomerData = {
      cartId: 'testCartId',
      customerAttributes: { customerType: 'N' },
    };
    APIServiceHooks.useLazyUpdateConsentQuery.mockImplementation(() => [jest.fn(), {}]);
    render(<MonthlyPayment opened CustomerData={mockCustomerData} onClose={() => {}} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    const noOption = screen.getByLabelText('no');
    expect(noOption).not.toBeDisabled();
  });

  it('enables "No" option if isOmniCareTrainingUser is not set', () => {
    // Mock trainingFlag to return null/undefined (falsy value)
    trainingFlag.mockReturnValue(null);

    const mockCustomerData = {
      cartId: 'testCartId',
      customerAttributes: { customerType: 'N' },
    };
    APIServiceHooks.useLazyUpdateConsentQuery.mockImplementation(() => [jest.fn(), {}]);
    render(<MonthlyPayment opened CustomerData={mockCustomerData} onClose={() => {}} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    const noOption = screen.getByLabelText('no');
    expect(noOption).not.toBeDisabled();
  });

  it('calls trainingFlag function and verifies isOmniCareTrainingUser behavior', () => {
    // Mock trainingFlag to return true
    trainingFlag.mockReturnValue(true);

    const mockCustomerData = {
      cartId: 'testCartId',
      customerAttributes: { customerType: 'N' },
    };
    APIServiceHooks.useLazyUpdateConsentQuery.mockImplementation(() => [jest.fn(), {}]);
    render(<MonthlyPayment opened CustomerData={mockCustomerData} onClose={() => {}} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    // Verify trainingFlag was called
    expect(trainingFlag).toHaveBeenCalledTimes(1);

    // Verify the "No" option is disabled when trainingFlag returns true
    const noOption = screen.getByLabelText('no');
    expect(noOption).toBeDisabled();
  });

  it('handles undefined trainingFlag return value correctly', () => {
    // Mock trainingFlag to return undefined
    trainingFlag.mockReturnValue(undefined);

    const mockCustomerData = {
      cartId: 'testCartId',
      customerAttributes: { customerType: 'N' },
    };
    APIServiceHooks.useLazyUpdateConsentQuery.mockImplementation(() => [jest.fn(), {}]);
    render(<MonthlyPayment opened CustomerData={mockCustomerData} onClose={() => {}} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    // Verify trainingFlag was called
    expect(trainingFlag).toHaveBeenCalled();

    // Verify the "No" option is enabled when trainingFlag returns undefined (|| false kicks in)
    const noOption = screen.getByLabelText('no');
    expect(noOption).not.toBeDisabled();
  });

  it('handles different truthy values from trainingFlag', () => {
    // Mock trainingFlag to return a truthy string
    trainingFlag.mockReturnValue('training-mode');

    const mockCustomerData = {
      cartId: 'testCartId',
      customerAttributes: { customerType: 'N' },
    };
    APIServiceHooks.useLazyUpdateConsentQuery.mockImplementation(() => [jest.fn(), {}]);
    render(<MonthlyPayment opened CustomerData={mockCustomerData} onClose={() => {}} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    // Verify trainingFlag was called
    expect(trainingFlag).toHaveBeenCalled();

    // Verify the "No" option is disabled for any truthy value
    const noOption = screen.getByLabelText('no');
    expect(noOption).toBeDisabled();
  });
});
