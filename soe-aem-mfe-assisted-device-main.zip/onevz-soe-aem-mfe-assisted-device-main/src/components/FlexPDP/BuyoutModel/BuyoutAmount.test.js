// eslint-disable-next-line max-classes-per-file
import React from 'react';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import BuyoutAmount from './BuyoutAmount';

describe('BuyoutAmount model component render', () => {
  const props = {
    isClose: true,
    closeBuyoutModel: jest.fn(),
    opened: true,
  };
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  beforeEach(() => {
    render(<BuyoutAmount {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('Buyout component shoudl render', () => {
    const BuyoutAmountText = screen.getByText('Buyout Amount');
    expect(BuyoutAmountText).toBeInTheDocument();
  });
  test('close Buyout Amount Model', () => {
    const BuyoutAmountText = screen.getByText('Close');
    expect(BuyoutAmountText).toBeInTheDocument();
    fireEvent.click(BuyoutAmountText);
  });
});

describe('BuyoutAmount model component render', () => {
  const props = {
    isClose: false,
    opened: true,
    isPreOrder: true,
    isBackorder: true,
    buyOutcall: jest.fn(),
    buyoutHandler: jest.fn(),
  };
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  beforeEach(() => {
    render(<BuyoutAmount {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('buyout model shoudl render', () => {
    const BuyoutAmountButton = screen.getByRole('button', { name: 'Accept' });
    expect(BuyoutAmountButton).toBeInTheDocument();
    fireEvent.click(BuyoutAmountButton);
  });
  test('buyout model shoudl render', () => {
    const BuyoutAmountButton = screen.getByRole('button', { name: 'Decline' });
    expect(BuyoutAmountButton).toBeInTheDocument();
    fireEvent.click(BuyoutAmountButton);
  });
});

describe('BuyoutAmount model component render with Device MFE enabled flag', () => {
  const props = {
    isClose: false,
    opened: true,
    isPreOrder: true,
    isBackorder: true,
    buyOutcall: jest.fn(),
    buyoutHandler: jest.fn(),
  };
  beforeAll(() => {
    window.mfe={scmDeviceMfeEnable: true, isDark: true};
  });
  beforeEach(() => {
    render(<BuyoutAmount {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('buyout model shoudl render', () => {
    const BuyoutAmountButton = screen.getByRole('button', { name: 'Accept' });
    expect(BuyoutAmountButton).toBeInTheDocument();
    fireEvent.click(BuyoutAmountButton);
  });
  test('buyout model shoudl render', () => {
    const BuyoutAmountButton = screen.getByRole('button', { name: 'Decline' });
    expect(BuyoutAmountButton).toBeInTheDocument();
    fireEvent.click(BuyoutAmountButton);
  });
});

describe('BuyoutAmount model component render with Device MFE enabled flag', () => {
  const props = {
    isClose: false,
    opened: true,
    isPreOrder: false,
    isBackorder: false,
    buyOutcall: jest.fn(),
    buyoutHandler: jest.fn(),
  };
  beforeAll(() => {
    window.mfe={scmDeviceMfeEnable: true, isDark: true};
  });
  beforeEach(() => {
    render(<BuyoutAmount {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('buyout model shoudl render', () => {
    const BuyoutAmountButton = screen.getByRole('button', { name: 'Accept' });
    expect(BuyoutAmountButton).toBeInTheDocument();
    fireEvent.click(BuyoutAmountButton);
  });
  test('buyout model shoudl render', () => {
    const BuyoutAmountButton = screen.getByRole('button', { name: 'Decline' });
    expect(BuyoutAmountButton).toBeInTheDocument();
    fireEvent.click(BuyoutAmountButton);
  });
});

describe('BuyoutAmount model component render', () => {
  const props = {
    isClose: true,
    closeBuyoutModel: jest.fn(),
    opened: true,
  };
  beforeAll(() => {
    window.mfe={scmDeviceMfeEnable: true, isDark: true};
  });
  beforeEach(() => {    
    render(<BuyoutAmount {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('Buyout component shoudl render', () => {
    const BuyoutAmountText = screen.getByText('Buyout Amount');
    expect(BuyoutAmountText).toBeInTheDocument();
  });
  test('close Buyout Amount Model', () => {
    const BuyoutAmountText = screen.getByText('Close');
    expect(BuyoutAmountText).toBeInTheDocument();
    fireEvent.click(BuyoutAmountText);
  });
});
