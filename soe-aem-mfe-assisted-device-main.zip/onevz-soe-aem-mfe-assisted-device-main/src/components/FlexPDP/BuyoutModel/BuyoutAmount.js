import React from 'react';
import { ButtonGroup } from '@vds/buttons';
import styled from 'styled-components';
import { Body, Title } from '@vds/typography';
import { Modal, ModalBody, ModalTitle } from '@vds/modals';
import { Icon } from '@vds/icons';
import { PaddingTop16, PaddingTopBot48 } from '../../CombinedGridwall/FlexGlobalStyledConstants';
import { DARK_THEME_COLOR } from '../../../constants/constants';

const MaxWidth = styled.div`
  [class^='ModalDialog-VDS-'] {
    max-width: 1133px;
  }
`;

const MarginSides = styled.div`
  padding: 9rem 8rem 0 5rem;
`;

const BuyoutTitle = styled.div`
  display: flex;
  justify-content: space-between;
`;

const BuyoutAmount = (props) => {
  const {
    isClose,
    totalBuyoutAmount,
    isPreOrder,
    isBackorder,
    buyAmountMessage,
    installmentLoanNumber,
    buyOutcall,
    buyoutHandler,
    closeBuyoutModel,
  } = props;
  const isIndirect = sessionStorage.getItem('channel')?.includes('OMNI-INDIRECT');

  const handleClick = (option) => {
    // we are setting isDpVisible as false when devicePaymentEligibility flag is false
    if (option === 'accept') {
      buyOutcall();
      buyoutHandler();
    }
    // when the option is accept, refresh the cart and call the dpEligibility
    else {
      buyoutHandler('decline');
    }
  };

  const scmDeviceEnable = window?.mfe?.scmDeviceMfeEnable || false;
  const isDark = (window?.mfe?.scmDeviceMfeEnable && window?.mfe?.isDark) || false;

  return (
    <MaxWidth data-testid='buyoutamount-modal'>
      <Modal
        opened={props.opened}
        surface={isDark ? 'dark' : 'light'}
        fullScreenDialog={!scmDeviceEnable}
        disableAnimation={false}
        disableOutsideClick={scmDeviceEnable}
        closeButton={<sapn />}
        width={scmDeviceEnable ? '850px' : '100%'}
        ariaLabel='Testing Modal'
      >
        <MarginSides>
          {isClose && (
            <ModalTitle>
              {isClose && (
                <BuyoutTitle>
                  <Title size='large' bold>
                    Buyout Amount
                  </Title>
                  <div data-testid='closeButton' onClick={closeBuyoutModel} onKeyDown={{}} tabIndex={0} role='button'>
                    <Icon name='close' size={18} color='#000000' />
                  </div>
                </BuyoutTitle>
              )}
            </ModalTitle>
          )}
          <ModalBody>
            <Title size='large' bold color={isDark ? DARK_THEME_COLOR : '#000000'}>
              ${totalBuyoutAmount}
            </Title>
            <PaddingTop16>
              {!(isPreOrder || isBackorder) && (
                <Title size='medium' bold color={isDark ? DARK_THEME_COLOR : '#000000'}>
                  {buyAmountMessage}
                </Title>
              )}
            </PaddingTop16>
            <PaddingTop16>
              {!(isPreOrder || isBackorder) && (
                <Body size='large' color={isDark ? DARK_THEME_COLOR : '#000000'}>
                  You are requesting to pay off your device payment agreement balance in full,&nbsp;
                  <b>
                    <u>
                      once this payment is successfully completed it cannot be reversed and installment payments cannot
                      be re-installed.
                    </u>
                  </b>
                  &nbsp;{' '}
                  {`If the payment is cancelled, rejected, or reversed after the completion of the payment in our
                  billing system, a lump sum in that amount will appear on your following month's bill. to apply past
                  due.`}
                </Body>
              )}
              {(isPreOrder || isBackorder) && (
                <Body size='large' color={isDark ? DARK_THEME_COLOR : '#000000'}>
                  {`A buyout of this line's existing Device Payment Agreement`}
                  {isIndirect && installmentLoanNumber !== '' ? ` (Loan# ${installmentLoanNumber})` : ''} in the amount
                  of ${totalBuyoutAmount} will be included with this order. For preorder/backorder devices you will
                  continue to be filled for the device payment installment untill the order ships. If buyout payment
                  exceeds buyout amount at shipment, excess payment will apply to your bill.
                </Body>
              )}
            </PaddingTop16>
            <PaddingTopBot48>
              {isClose && (
                <ButtonGroup
                  surface={isDark ? 'dark' : 'light'}
                  childWidth='100%'
                  viewport='desktop'
                  rowQuantity={{ desktop: 2 }}
                  data={[
                    {
                      children: 'Close',
                      size: 'large',
                      use: 'primary',
                      width: '225px',
                      onClick: () => closeBuyoutModel(),
                    },
                  ]}
                  alignment='left'
                />
              )}
              {!isClose && (
                <ButtonGroup
                  surface={isDark ? 'dark' : 'light'}
                  childWidth='100%'
                  viewport='desktop'
                  rowQuantity={{ desktop: 2 }}
                  data={[
                    {
                      children: 'Accept',
                      size: 'large',
                      use: 'primary',
                      width: '225px',
                      onClick: () => handleClick('accept'),
                    },
                    {
                      children: 'Decline',
                      size: 'large',
                      use: 'secondary',
                      width: '225px',
                      onClick: () => handleClick('decline'),
                    },
                  ]}
                  alignment='left'
                />
              )}
            </PaddingTopBot48>
          </ModalBody>
        </MarginSides>
      </Modal>
    </MaxWidth>
  );
};
export default BuyoutAmount;
