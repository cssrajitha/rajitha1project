import { UI_SELECTORS } from '../../constants/uiSelectors';
import React from 'react';
import { render, screen, waitFor, cleanup } from '../../modules/test-utils/renderHelper';
import userEvent from '@testing-library/user-event';
// Ensure VBG gating allows Activate Later UI
jest.mock('onevzsoemfeframework/VbgAemUtil', () => ({
  isVbg: jest.fn(() => true),
  isVbgAem: jest.fn(() => true),
}));
jest.mock('onevzsoemfeframework/DomService', () => {
  const actual = jest.requireActual('onevzsoemfeframework/DomService');
  return { ...actual, isTelesales: jest.fn(() => false) };
});
import DeviceInfo from './DeviceInfo';

// Environment stubs used by DeviceInfo
beforeAll(() => {
  // Avoid undefined access in component guarded by feature flags
  window.mfe = window.mfe || {};
});

afterEach(() => {
  cleanup();
  sessionStorage.clear();
  jest.clearAllMocks();
});

// Minimal product details and device details to satisfy early effects
const minimalDetails = {
  isNumberShareMandatory: false,
  isNumberShareCapable: false,
  defaultSKU: 'SKU1',
  defaultSku: 'SKU1',
  defaultSKUObj: { inventoryDetails: { dFillInventory: { isPreOrder: false } } },
  childSkus: [
    {
      sorId: 'SKU1',
      capacity: '64GB',
      color: { displayName: 'Black', colorCssStyle: {} },
      imageUrlMap: {},
      inventoryDetails: { dFillInventory: { isPreOrder: false, isInStock: true }, localInventory: { isInStock: true } },
    },
  ],
};

const baseProps = {
  // Required data
  details: minimalDetails,
  productDetails: { commonInfo: { showPrice: false, showShipitToggle: false }, deviceSku: {} },
  selectedPaymentInfo: { contractType: 'MONTH_TO_MONTH' },

  // Setters and utilities used in effects
  setSelectedPaymentInfo: jest.fn(),
  setSelectedSku: jest.fn(),
  setSelectedColor: jest.fn(),
  setSelectedBYODCss: jest.fn(),
  setSelectedSize: jest.fn(),
  callNumberShareInfo: jest.fn(),
  callWFGbannerInfo: jest.fn(),
  callDpEligibilityBanner: jest.fn(),
  groupByColors: jest.fn(() => []),
  // Ship-it / ISPU toggles expected as props by DeviceInfo
  isShipItToggleOn: false,
  setIsShipItToggleOn: jest.fn(),
  ispuToggleOn: false,
  setIspuToggleOn: jest.fn(),

  // Query result placeholders
  InventoryDetailsResult: { status: 'idle', data: {} },
  upgradeReasonCodeResponse: { isSuccess: false },
  dpEligibilityResult: { isSuccess: false, data: {} },

  // Customer profile used in many guards
  customerProfileDetails: {
    customer: {
      channel: 'OMNI-CARE',
      billAccounts: [{ mtns: [], paymentInfo: {} }],
      customerAttributes: { customerType: 'N' },
    },
    commonInfo: {
      isIndirect: false,
      disableDfillRadioButton: false,
      isISPUEnabled: false,
      showShipitToggle: false,
    },
  },

  // Activate Later interaction callback (what we assert on)
  setActivatedDate: jest.fn(),
  updateDeviceData: jest.fn(),
  updateDeviceId: jest.fn(),
  updateSimId: jest.fn(),
  updateShowISPUForVA: jest.fn(),
  showISPUForVA: false,
  cartDetails: {},
  setMitekIdVerifyStatus: jest.fn(),
  setUpcCodeFromPdpScan: jest.fn(),
  upcCodeFromPdpScan: '',
  isActiveNewLine: false,
  getBestBuyPricingDetails: jest.fn(),
  skuRealAgentCode: '',
  simSwapNotificationHighRiskMsg: '',
  setUpgradeReasonType: jest.fn(),
  upgradeReasonType: '',

  // Misc flags consumed in guards
  isNewlyAddedLine: false,
  isVbgProfessionalInstall: false,
};

// Helper to get expected first date strings
const getExpectedFirstDates = () => {
  const today = new Date();
  const mm = String(today.getMonth() + 1).padStart(2, '0');
  const dd = String(today.getDate()).padStart(2, '0');
  const yy = String(today.getFullYear()).slice(-2);
  const yyyy = String(today.getFullYear());
  return {
    short: `${mm}/${dd}/${yy}`,
    long: `${mm}/${dd}/${yyyy}`,
  };
};

describe('DeviceInfo Activate Later year format (lines 1872–1884)', () => {
  test('when vbgNsaYearFormatActLaterFFlag is TRUE, clicking a day sets activated date in MM/DD/YYYY', async () => {
    // Enable AAL feature and year format flag
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({
      vbgNSAAALActivateLaterFFlag: 'TRUE',
      vbgNsaYearFormatActLaterFFlag: 'TRUE',
    }));
    const { isVbg } = require('onevzsoemfeframework/VbgAemUtil');
    isVbg.mockReturnValue(true);

    const setActivatedDate = jest.fn();
    const { container } = render(
      <DeviceInfo
        {...baseProps}
        selectedPaymentInfo={{ contractType: 'MONTH_TO_MONTH' }}
        setActivatedDate={setActivatedDate}
      />,
    );

    // Turn ON Activate Later (wait for async flag initialization)
    const toggleEl = await waitFor(() => {
      const el = container.querySelector(`[name="${UI_SELECTORS.ACTIVATE_LATER_TOGGLE_NAME}"]`);
      if (!el) {
        const titleEl = Array.from(container.querySelectorAll('div,h3,p,span')).find(x => /Activate Later/i.test(x.textContent || ''));
        if (titleEl) {
          const possibleSwitch = titleEl.closest('div')?.querySelector('[role="switch"],button,a');
          if (possibleSwitch) return possibleSwitch;
        }
      }
      expect(el).toBeTruthy();
      return el;
    });
    userEvent.click(toggleEl);

    // Wait for the list and capture first day button and first date text
    const dayButtons = await waitFor(() => {
      const buttons = screen
        .getAllByRole('button')
        .filter((btn) => /^(Sun|Mon|Tue|Wed|Thu|Fri|Sat)$/.test((btn.textContent || '').trim()));
      expect(buttons.length).toBeGreaterThanOrEqual(8);
      return buttons;
    });
    const { short, long } = getExpectedFirstDates();
    const dateShortText = await screen.findByText(short);

    // Click first day; callback should be invoked with long (YYYY) format
    userEvent.click(dayButtons[0]);
    expect(setActivatedDate).toHaveBeenCalledWith((dateShortText.textContent || '').trim().replace(/\/(\d{2})$/, `/${String(new Date().getFullYear())}`));
    // Or directly assert equals computed long
    expect(setActivatedDate).toHaveBeenCalledWith(long);
  });

  test('when vbgNsaYearFormatActLaterFFlag is FALSE, clicking a day sets activated date in MM/DD/YY', async () => {
    // Enable AAL feature but disable year format flag
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({
      vbgNSAAALActivateLaterFFlag: 'TRUE',
      vbgNsaYearFormatActLaterFFlag: 'FALSE',
    }));
    const { isVbg } = require('onevzsoemfeframework/VbgAemUtil');
    isVbg.mockReturnValue(true);

    const setActivatedDate = jest.fn();
    const { container } = render(
      <DeviceInfo
        {...baseProps}
        selectedPaymentInfo={{ contractType: 'MONTH_TO_MONTH' }}
        setActivatedDate={setActivatedDate}
      />,
    );

    const toggleEl = await waitFor(() => {
      const el = container.querySelector(`[name="${UI_SELECTORS.ACTIVATE_LATER_TOGGLE_NAME}"]`);
      if (!el) {
        const titleEl = Array.from(container.querySelectorAll('div,h3,p,span')).find(x => /Activate Later/i.test(x.textContent || ''));
        if (titleEl) {
          const possibleSwitch = titleEl.closest('div')?.querySelector('[role="switch"],button,a');
          if (possibleSwitch) return possibleSwitch;
        }
      }
      expect(el).toBeTruthy();
      return el;
    });
    userEvent.click(toggleEl);

    const { short } = getExpectedFirstDates();
    const dateShortText = await screen.findByText(short);

    // Click first day; callback should be invoked with short (YY) format
    const dayButtons = screen
      .getAllByRole('button')
      .filter((btn) => /^(Sun|Mon|Tue|Wed|Thu|Fri|Sat)$/.test((btn.textContent || '').trim()));
    userEvent.click(dayButtons[0]);
    expect(setActivatedDate).toHaveBeenCalledWith((dateShortText.textContent || '').trim());
  });

  test('selection mapping updates and normalization applies across multiple clicks when year-format flag is TRUE', async () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({
      vbgNSAAALActivateLaterFFlag: 'TRUE',
      vbgNsaYearFormatActLaterFFlag: 'TRUE',
    }));
    const { isVbg } = require('onevzsoemfeframework/VbgAemUtil');
    isVbg.mockReturnValue(true);

    const setActivatedDate = jest.fn();
    const { container } = render(
      <DeviceInfo
        {...baseProps}
        selectedPaymentInfo={{ contractType: 'MONTH_TO_MONTH' }}
        setActivatedDate={setActivatedDate}
      />,
    );

    // Turn ON Activate Later (wait for async flag initialization)
    const toggleEl = await waitFor(() => {
      const el = container.querySelector(`[name="${UI_SELECTORS.ACTIVATE_LATER_TOGGLE_NAME}"]`);
      if (!el) {
        const titleEl = Array.from(container.querySelectorAll('div,h3,p,span')).find(x => /Activate Later/i.test(x.textContent || ''));
        if (titleEl) {
          const possibleSwitch = titleEl.closest('div')?.querySelector('[role="switch"],button,a');
          if (possibleSwitch) return possibleSwitch;
        }
      }
      expect(el).toBeTruthy();
      return el;
    });
    userEvent.click(toggleEl);

    // Capture day buttons (Sun..Sat)
    const dayButtons = await waitFor(() => {
      const buttons = screen
        .getAllByRole('button')
        .filter((btn) => /^(Sun|Mon|Tue|Wed|Thu|Fri|Sat)$/.test((btn.textContent || '').trim()));
      expect(buttons.length).toBeGreaterThanOrEqual(8);
      return buttons;
    });

    // Collect the first two date labels rendered (short form), then compute expected long
    const dateRegex = /\d{2}\/\d{2}\/\d{2}/;
    const dateShortTexts = screen.getAllByText(dateRegex);
    expect(dateShortTexts.length).toBeGreaterThanOrEqual(2);
    const today = new Date();
    const currentCentury = String(today.getFullYear()).slice(0, 2);
    const long0 = (dateShortTexts[0].textContent || '').trim().replace(/\/(\d{2})$/, `/${String(today.getFullYear())}`);
    const long1 = (dateShortTexts[1].textContent || '').trim().replace(/\/(\d{2})$/, `/${currentCentury}$1`);

    // Click first day, then second day; both should normalize to YYYY
    userEvent.click(dayButtons[0]);
    userEvent.click(dayButtons[1]);

    expect(setActivatedDate).toHaveBeenCalledTimes(2);
    expect(setActivatedDate).toHaveBeenNthCalledWith(1, long0);
    expect(setActivatedDate).toHaveBeenNthCalledWith(2, long1);
  });

  test('toFullYear handles already-long year (MM/DD/YYYY) without altering year', async () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({
      vbgNSAAALActivateLaterFFlag: 'TRUE',
      vbgNsaYearFormatActLaterFFlag: 'TRUE',
    }));
    const { isVbg } = require('onevzsoemfeframework/VbgAemUtil');
    isVbg.mockReturnValue(true);

    const setActivatedDate = jest.fn();
    const { container } = render(
      <DeviceInfo
        {...baseProps}
        selectedPaymentInfo={{ contractType: 'MONTH_TO_MONTH' }}
        setActivatedDate={setActivatedDate}
      />,
    );

    const toggleEl = await waitFor(() => {
      const el = container.querySelector(`[name="${UI_SELECTORS.ACTIVATE_LATER_TOGGLE_NAME}"]`);
      if (!el) {
        const titleEl = Array.from(container.querySelectorAll('div,h3,p,span')).find(x => /Activate Later/i.test(x.textContent || ''));
        if (titleEl) {
          const possibleSwitch = titleEl.closest('div')?.querySelector('[role="switch"],button,a');
          if (possibleSwitch) return possibleSwitch;
        }
      }
      expect(el).toBeTruthy();
      return el;
    });
    userEvent.click(toggleEl);

    // Prepare a long (YYYY) date for today
    const { long } = getExpectedFirstDates();

    const origFind = Array.prototype.find;
    const spy = jest.spyOn(Array.prototype, 'find').mockImplementation(function (predicate, ...rest) {
      // Only intercept the isSelected predicate used in onClickActivatedDate
      if (typeof predicate === 'function' && String(predicate).includes('isSelected')) {
        return { date: long, isSelected: true };
      }
      return origFind.call(this, predicate, ...rest);
    });

    // Click a day to trigger handler; the mocked find returns YYYY date
    const dayButtons = await waitFor(() => {
      const buttons = screen
        .getAllByRole('button')
        .filter((btn) => /^(Sun|Mon|Tue|Wed|Thu|Fri|Sat)$/.test((btn.textContent || '').trim()));
      expect(buttons.length).toBeGreaterThanOrEqual(8);
      return buttons;
    });
    userEvent.click(dayButtons[0]);

    expect(setActivatedDate).toHaveBeenCalledWith(long);
    spy.mockRestore();
  });

  test('toFullYear guard returns for malformed or non-string selected date', async () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({
      vbgNSAAALActivateLaterFFlag: 'TRUE',
      vbgNsaYearFormatActLaterFFlag: 'TRUE',
    }));
    const { isVbg } = require('onevzsoemfeframework/VbgAemUtil');
    isVbg.mockReturnValue(true);

    const setActivatedDate = jest.fn();
    const { container } = render(
      <DeviceInfo
        {...baseProps}
        selectedPaymentInfo={{ contractType: 'MONTH_TO_MONTH' }}
        setActivatedDate={setActivatedDate}
      />,
    );

    const toggleEl = await waitFor(() => {
      const el = container.querySelector(`[name="${UI_SELECTORS.ACTIVATE_LATER_TOGGLE_NAME}"]`);
      if (!el) {
        const titleEl = Array.from(container.querySelectorAll('div,h3,p,span')).find(x => /Activate Later/i.test(x.textContent || ''));
        if (titleEl) {
          const possibleSwitch = titleEl.closest('div')?.querySelector('[role="switch"],button,a');
          if (possibleSwitch) return possibleSwitch;
        }
      }
      expect(el).toBeTruthy();
      return el;
    });
    userEvent.click(toggleEl);

    const dayButtons = await waitFor(() => {
      const buttons = screen
        .getAllByRole('button')
        .filter((btn) => /^(Sun|Mon|Tue|Wed|Thu|Fri|Sat)$/.test((btn.textContent || '').trim()));
      expect(buttons.length).toBeGreaterThanOrEqual(8);
      return buttons;
    });

    const origFind = Array.prototype.find;
    const spy = jest.spyOn(Array.prototype, 'find').mockImplementation(function (predicate, ...rest) {
      if (typeof predicate === 'function' && String(predicate).includes('isSelected')) {
        // First click: malformed string (no slashes) -> parts.length !== 3
        return { date: '010126', isSelected: true };
      }
      return origFind.call(this, predicate, ...rest);
    });
    userEvent.click(dayButtons[0]);
    // Expect setActivatedDate called with the original malformed string
    expect(setActivatedDate).toHaveBeenNthCalledWith(1, '010126');

    // Second click: non-string (null) -> first guard branch
    spy.mockImplementation(function (predicate, ...rest) {
      if (typeof predicate === 'function' && String(predicate).includes('isSelected')) {
        return { date: null, isSelected: true };
      }
      return origFind.call(this, predicate, ...rest);
    });
    userEvent.click(dayButtons[1]);
    // Guard with null should not invoke setActivatedDate again
    await waitFor(() => {
      expect(setActivatedDate).toHaveBeenCalledTimes(1);
    });

    spy.mockRestore();
  });
});
