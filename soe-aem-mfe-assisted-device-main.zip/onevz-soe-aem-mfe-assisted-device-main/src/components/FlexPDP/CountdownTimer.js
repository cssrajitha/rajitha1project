import React, { useEffect, useState } from 'react';
import './CountdownTimer.css';
import moment from 'moment-timezone';
import { Line } from '@vds/lines';
import { Padding16 } from '../CombinedGridwall/FlexGlobalStyledConstants';
// import 'moment-timezone';

function CountdownTimer(props) {
  const { isPreOrder, isPreorderTestingEnabled, isPrePay, disableAddToCart } = props;
  const [counterState, setCounterState] = useState({
    days: '',
    hours: '',
    mins: '',
    seconds: '',
    showPreOrderTimer: true,
    totalSeconds: null,
  });
  const [calculateTimeIntervalId, setCalculateTimeIntervalId] = useState('');
  const [isPreOrderTimeValid, setIsPreOrderTimeValid] = useState(true);
  const iconicTimerIssueFFlag = /true/i.test(JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.iconicTimerIssueFFlag);
 

  useEffect(() => {
    const calculatedTimeIntervalId = setInterval(calculateTime, 1000);
    setCalculateTimeIntervalId(calculatedTimeIntervalId);
    checkCTAEnableOrDisable();
  }, []);

  /**
   * it will enable or disbale CTA
   */
  const checkCTAEnableOrDisable = () => {
    // if isPreorderTestingEnabled TRUE then enable ship it button
    if (isPreorderTestingEnabled?.toLowerCase() === 'true') {
      disableAddToCart(false);
    } else {
      disableAddToCart(true);
    }
  };

  useEffect(() => {
    setTimerValues();
    if (counterState.totalSeconds > 0) {
      setIsPreOrderTimeValid(true);
      checkCTAEnableOrDisable();
    } else {
      setIsPreOrderTimeValid(false);
      disableAddToCart(false);
    }
  }, [counterState.totalSeconds]);

  useEffect(
    () => () => {
      clearInterval(calculateTimeIntervalId);
    },
    [],
  );

  const calculateTime = () => {
    const { product = {} } = props;
    const { startDate = {} } = product;
    const { dateLong } = startDate;
    let currentDate;
    let currentMomentDate;
    let preOrderMomentDate;
    let duration;
    let totalSeconds;
    if (counterState.totalSeconds === null) {
      currentDate = sessionStorage.getItem('currentTime') || new Date();
      if(iconicTimerIssueFFlag) {
        currentDate = new Date();
      }
      currentMomentDate = moment.tz(currentDate, 'America/New_York');
      preOrderMomentDate = moment.tz(dateLong, 'America/New_York');
      duration = moment.duration(preOrderMomentDate.diff(currentMomentDate));
      totalSeconds = duration.asSeconds();
      setCounterState({ ...counterState, totalSeconds });
    } else {
      setCounterState({ ...counterState, totalSeconds: counterState.totalSeconds - 1 });
    }
  };

  const setTimerValues = () => {
    if (counterState.totalSeconds !== null && counterState.totalSeconds > 0) {
      const days = Math.floor(counterState.totalSeconds / 3600 / 24);
      const hours = Math.floor(counterState.totalSeconds / 3600) % 24;
      const mins = Math.floor(counterState.totalSeconds / 60) % 60;
      const seconds = Math.floor(counterState.totalSeconds) % 60;
      setCounterState({ ...counterState, days, hours, mins, seconds, showPreOrderTimer: true });
    } else {
      clearInterval(calculateTimeIntervalId);
      setCounterState({ ...counterState, showPreOrderTimer: false });
    }
  };

  const { days, hours, mins, seconds } = counterState;

  return (
    // eslint-disable-next-line react/jsx-no-useless-fragment
    <React.Fragment>
      {isPreOrderTimeValid === true && isPreOrder === true && !isPrePay && (
        <>
          <div className='Grid Grid--gapless u-paddingBottomMedium' data-testid='countdown-timer'>
            <div className='Col u-paddingXNone'>
              <div className='preordertext'>
                <h3>Pre-order starts in</h3>
              </div>
              <div className='countdownTimer' style={{ display: 'flex' }}>
                <div style={{ display: 'flex' }}>
                  <span className='timeStyleFormat'>{days}</span>
                  <div className='labelMargin'>D</div>
                </div>
                <div className='componentLeftMargin' style={{ display: 'flex' }}>
                  <span className='timeStyleFormat'>{hours}</span>
                  <div className='labelMargin'>H</div>
                </div>
                <div className='componentLeftMargin' style={{ display: 'flex' }}>
                  <span className='timeStyleFormat'>{mins}</span>
                  <div className='labelMargin'>M</div>
                </div>
                <div className='componentLeftMargin' style={{ display: 'flex' }}>
                  <span className='timeStyleFormat'>{seconds}</span>
                  <div className='labelMargin'>S</div>
                </div>
              </div>
            </div>
          </div>
          <Padding16>
            <Line type='secondary' surface='light' />
          </Padding16>
        </>
      )}
    </React.Fragment>
  );
}

export default CountdownTimer;
