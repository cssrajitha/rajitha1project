import React from 'react';
import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import { CHANNELS, setupChannel } from '../../../modules/test-utils/utils';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import IDScanModal from './IDScanModal';

const Test = (channel) => {
  setupChannel(channel);
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  describe(`<IDScanModal component`, () => {
    const props = {
      isOpen: true,
      handleGetUpdateOldSimId: jest.fn(),
      handleModelChange: jest.fn(),
      correlationId: '985093805830958038509',
      closeModal: jest.fn(),
      simswapSessionId: '9798798798797978',
      cartDetails: {},
      customerProfileDetails: {
        customer: {
          caseId: '7988989809',
          cartId: '9889080989',
          customerId: '7897979',
          lookupMtn: '879879879879',
          accountNo: '97897987987',
          email: 'mnn@verizon.com',
          customerName: { firstName: 'hjkh', lastName: 'jjkj' },
        },
      },
      activeMtn: '97987978979',
      setMitekIdVerifyStatus: jest.fn(),
    };
    beforeEach(() => {
      render(<IDScanModal {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });
    test('should mount Footer component', async () => {
      const vaditeShop = await screen.getAllByTestId('IdSecureScan')[0];
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);
    });
    test('test it for scanIdCallBack response Approved Scenario', async () => {
      const response = {
        authResultStatus: 'PASSED',
        attemptCount: '1',
        mitekResponseCode: '200',
      };
      const scandata = '';
      window.scanIdCallBack(scandata, response);
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
    });
    test('test it for scanIdCallBack response NoApproved Scenario', async () => {
      const response = {
        authResultStatus: 'FAILED',
        attemptCount: '1',
        mitekResponseCode: '200',
      };
      const scandata = '';
      window.scanIdCallBack(scandata, response);
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      expect(
        screen.getByRole('link', {
          name: /OST 203390./i,
        }),
      ).toBeInTheDocument();
      fireEvent.click(
        screen.getByRole('link', {
          name: /OST 203390./i,
        }),
      );
    });
    test('test it for scanIdCallBack response Unverified Rescan Scenario', async () => {
      const response = {
        authResultStatus: 'FAILED',
        attemptCount: '1',
        mitekResponseCode: '400',
      };
      const scandata = '{"frontPage":  "image.img"}';
      window.scanIdCallBack(scandata, response);
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      fireEvent.click(
        screen.getByRole('button', {
          name: /Rescan ID/i,
        }),
      );
    });
    test('test it for scanIdCallBack response Unverified Scenario', async () => {
      const response = '{"authResultStatus": "FAILED","attemptCount": "3","mitekResponseCode": "400"}';
      const scandata = {
        frontPage: 'image.img',
      };
      window.scanIdCallBack(scandata, response);
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
    });

    test('it should render with SimScan', async () => {
      const vaditeShop1 = await screen.getAllByTestId('Getdropdown')[0];
      expect(vaditeShop1).toBeInTheDocument();

      fireEvent.change(vaditeShop1, { target: { value: 'Exception Review' } });
      const reviewButton = screen.getByRole('button', { name: 'Review' });
      fireEvent.click(reviewButton);
      const proceedButton = screen.getByRole('button', { name: 'Proceed' });
      fireEvent.click(proceedButton);
      const noButton = screen.getByRole('button', { name: 'No' });
      fireEvent.click(noButton);

      fireEvent.change(vaditeShop1, { target: { value: 'Select' } });
      const sendLink1 = screen.getByRole('button', { name: 'Scan ID' });
      expect(sendLink1).toBeDisabled();

      fireEvent.change(vaditeShop1, { target: { value: 'US Passport Ca' } });
      const sendLink = screen.getByRole('button', { name: 'Scan ID' });
      fireEvent.click(sendLink);
      expect(sendLink).not.toBeDisabled();

      window.scanIdCallBack(null, { mitekResponseCode: '200', authResultStatus: 'PASSED', attemptCount: '1' });
      window.scanIdCallBack(null, { mitekResponseCode: '200', authResultStatus: 'FAILED', attemptCount: '1' });
      window.scanIdCallBack(null, { mitekResponseCode: '415' });
      window.scanIdCallBack(null, { mitekResponseCode: '500' });
      window.scanIdCallBack(
        {
          frontPage:
            '/9j/4AAQSkZJRgABAQAASABIAAD/4QBMRXhpZgAATU0AKgAAAAgAAgESAAMAAAABAAEAAIdpAAQAAAABAAAAJgAAAAAAAqACAAQAAAABAAAHgKADAAQAAAABAAAEOAAAAAD',
        },
        null,
      );
      fireEvent.change(vaditeShop1, { target: { value: "Driver's License/State Issued ID" } });
      const scanIdButton = screen.getByRole('button', { name: 'Scan ID' });
      expect(scanIdButton).not.toBeDisabled();
      fireEvent.click(scanIdButton);

      fireEvent.change(vaditeShop1, { target: { value: 'Exception Review' } });
      const reviewButton4 = screen.getByRole('button', { name: 'Review' });
      fireEvent.click(reviewButton4);
      const proceedButton6 = screen.getByRole('button', { name: 'Proceed' });
      fireEvent.click(proceedButton6);
      const yesButton = screen.getByRole('button', { name: 'Yes' });
      fireEvent.click(yesButton);
    });

    test('it should render with SimScan', async () => {
      const vaditeShop1 = await screen.getAllByTestId('Getdropdown')[0];
      expect(vaditeShop1).toBeInTheDocument();

      fireEvent.change(vaditeShop1, { target: { value: 'Exception Review' } });
      const reviewButton = screen.getByRole('button', { name: 'Review' });
      fireEvent.click(reviewButton);
      const proceedButton = screen.getByRole('button', { name: 'Proceed' });
      fireEvent.click(proceedButton);
      const noButton = screen.getByRole('button', { name: 'No' });
      fireEvent.click(noButton);

      fireEvent.change(vaditeShop1, { target: { value: 'Select' } });
      const sendLink1 = screen.getByRole('button', { name: 'Scan ID' });
      expect(sendLink1).toBeDisabled();

      fireEvent.change(vaditeShop1, { target: { value: 'US Passport Ca' } });
      const sendLink = screen.getByRole('button', { name: 'Scan ID' });
      fireEvent.click(sendLink);
      expect(sendLink).not.toBeDisabled();

      window.scanIdCallBack(null, { mitekResponseCode: '200', authResultStatus: 'PASSED', attemptCount: '1' });
      window.scanIdCallBack(null, { mitekResponseCode: '200', authResultStatus: 'FAILED', attemptCount: '1' });
      window.scanIdCallBack(null, { mitekResponseCode: '415' });
      window.scanIdCallBack(null, { mitekResponseCode: '500' });
      window.scanIdCallBack(
        {
          frontPage:
            '/9j/4AAQSkZJRgABAQAASABIAAD/4QBMRXhpZgAATU0AKgAAAAgAAgESAAMAAAABAAEAAIdpAAQAAAABAAAAJgAAAAAAAqACAAQAAAABAAAHgKADAAQAAAABAAAEOAAAAAD',
        },
        null,
      );
      fireEvent.change(vaditeShop1, { target: { value: 'US Passport Card' } });
      const scanIdButton = screen.getByRole('button', { name: 'Scan ID' });
      expect(scanIdButton).not.toBeDisabled();
      fireEvent.click(scanIdButton);

      fireEvent.change(vaditeShop1, { target: { value: 'Exception Review' } });
      const reviewButton4 = screen.getByRole('button', { name: 'Review' });
      fireEvent.click(reviewButton4);
      const proceedButton6 = screen.getByRole('button', { name: 'Proceed' });
      fireEvent.click(proceedButton6);
      const yesButton = screen.getByRole('button', { name: 'Yes' });
      fireEvent.click(yesButton);
    });
  });
  describe(`<IDScanModal component 1`, () => {
    const props = {
      isOpen: true,
      handleGetUpdateOldSimId: jest.fn(),
      handleModelChange: jest.fn(),
      correlationId: '985093805830958038509',
      closeModal: jest.fn(),
      simswapSessionId: '9798798798797978',
      cartDetails: {},
      customerProfileDetails: {
        customer: {
          customerName: {},
        },
      },
      activeMtn: '97987978979',
      setMitekIdVerifyStatus: jest.fn(),
    };
    beforeEach(() => {
      render(<IDScanModal {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });
    test('should mount Footer component', async () => {
      const vaditeShop = await screen.getAllByTestId('IdSecureScan')[0];
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);
    });

    test('it should render with SimScan', async () => {
      const vaditeShop1 = await screen.getAllByTestId('Getdropdown')[0];
      expect(vaditeShop1).toBeInTheDocument();

      fireEvent.change(vaditeShop1, { target: { value: 'Exception Review' } });
      const reviewButton = screen.getByRole('button', { name: 'Review' });
      fireEvent.click(reviewButton);
      const proceedButton = screen.getByRole('button', { name: 'Proceed' });
      fireEvent.click(proceedButton);
      const noButton = screen.getByRole('button', { name: 'No' });
      fireEvent.click(noButton);

      fireEvent.change(vaditeShop1, { target: { value: 'Select' } });
      const sendLink1 = screen.getByRole('button', { name: 'Scan ID' });
      expect(sendLink1).toBeDisabled();

      fireEvent.change(vaditeShop1, { target: { value: 'US Passport Ca' } });
      const sendLink = screen.getByRole('button', { name: 'Scan ID' });
      fireEvent.click(sendLink);
      expect(sendLink).not.toBeDisabled();

      window.scanIdCallBack(null, { mitekResponseCode: '200', authResultStatus: 'PASSED', attemptCount: '1' });
      window.scanIdCallBack(null, { mitekResponseCode: '200', authResultStatus: 'FAILED', attemptCount: '1' });
      window.scanIdCallBack(null, { mitekResponseCode: '415' });
      window.scanIdCallBack(null, { mitekResponseCode: '500' });
      window.scanIdCallBack(
        {
          frontPage:
            '/9j/4AAQSkZJRgABAQAASABIAAD/4QBMRXhpZgAATU0AKgAAAAgAAgESAAMAAAABAAEAAIdpAAQAAAABAAAAJgAAAAAAAqACAAQAAAABAAAHgKADAAQAAAABAAAEOAAAAAD',
        },
        null,
      );
      fireEvent.change(vaditeShop1, { target: { value: 'Canadian Passport' } });
      const scanIdButton = screen.getByRole('button', { name: 'Scan ID' });
      expect(scanIdButton).not.toBeDisabled();
      fireEvent.click(scanIdButton);

      fireEvent.change(vaditeShop1, { target: { value: 'Exception Review' } });
      const reviewButton4 = screen.getByRole('button', { name: 'Review' });
      fireEvent.click(reviewButton4);
      const proceedButton6 = screen.getByRole('button', { name: 'Proceed' });
      fireEvent.click(proceedButton6);
      const yesButton = screen.getByRole('button', { name: 'Yes' });
      fireEvent.click(yesButton);
    });
  });
  describe(`<IDScanModal component 2`, () => {
    const props = {
      isOpen: true,
      handleGetUpdateOldSimId: jest.fn(),
      handleModelChange: jest.fn(),
      correlationId: '985093805830958038509',
      closeModal: jest.fn(),
      simswapSessionId: '9798798798797978',
      cartDetails: {},
      customerProfileDetails: {
        customer: {
          customerName: {},
        },
      },
      activeMtn: '97987978979',
      DeviceScanFow: true,
      setMitekIdVerifyStatus: jest.fn(),
      disableUpdateDeviceSwap: jest.fn(),
    };
    let renderRef = null;
    beforeEach(() => {
      const { rerender } = render(<IDScanModal {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      renderRef = rerender;
    });
    test('should mount Footer component', async () => {
      const vaditeShop = await screen.getAllByTestId('IdSecureScan')[0];
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(screen.getByRole('button', { name: 'Testing Modal close' }));
    });

    test('it should render with SimScan', async () => {
      const vaditeShop1 = await screen.getAllByTestId('Getdropdown')[0];
      expect(vaditeShop1).toBeInTheDocument();

      fireEvent.change(vaditeShop1, { target: { value: 'Exception Review' } });
      const reviewButton = screen.getByRole('button', { name: 'Review' });
      fireEvent.click(reviewButton);
      const proceedButton = screen.getByRole('button', { name: 'Proceed' });
      fireEvent.click(proceedButton);
      const noButton = screen.getByRole('button', { name: 'No' });
      fireEvent.click(noButton);
      renderRef(<IDScanModal {...props} isOpen={false} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });
  });
};
Test(CHANNELS.OMNI_RETAIL);
