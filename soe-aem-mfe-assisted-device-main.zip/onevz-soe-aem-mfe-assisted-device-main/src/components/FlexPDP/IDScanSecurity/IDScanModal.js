import React, { useState, useEffect } from 'react';
import { Modal, ModalTitle, ModalFooter, ModalBody } from '@vds/modals';
import { Title, Body } from '@vds/typography';
import { Button } from '@vds/buttons';
import styled from 'styled-components';
import { Line } from '@vds/lines';
import PropTypes from 'prop-types';
import { isIpad, executeShellFunction } from 'onevzsoemfeframework/DomService';
import { PaddingLeft12, PaddingTop12, PaddingTop24 } from '../../CombinedGridwall/FlexGlobalStyledConstants';
import { DropdownSelect } from '@vds/selects';
import { Icon } from '@vds/icons';
import { ColorTokens } from '@vds-tokens/color';
import greencheckmark from '../../../assests/images/greencheckmark.svg';
import SMSWarningNotify from './SMSWarningNotify';
import { TextLinkCaret } from '@vds/buttons';
const ModalContainer = styled.div`
  display: flex;
  gap: 60px;
`;
const DisplayBox = styled.div`
  display: flex;
  align-items: center;
`;
const LeftContainer = styled.div`
  display: inline-flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 24px;
`;
const RightContainer = styled.div`
  display: inline-flex;
  flex-direction: column;
  align-items: flex-start;
`;
const PlanIncludeContainer = styled.div`
  background-color: #f6f6f6;
  width: 396px;
  height: 216px;
`;
const ImagePath = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  padding-top: 84px;
`;
const ImagePathFront = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
`;
const LeftParent = styled.div`
  display: flex;
  justify-content: center;
  gap: 32px;
`;
const FlexContainer = styled.div`
  display: flex;
  max-width: 435px;
`;
const TextLinkWrapper = styled.div`
  padding: 1rem 0 0.5rem 0;
  margin-top: 30px;
`;
const VerificationStatus = styled.div`
  font-size: 24px;
  font-weight: bold;
  margin-top: 24px;
  margin-right: 4px;
`;
const VerificationType = styled.div`
  font-size: 20px;
  font-weight: bold;
  margin-top: 6px;
  margin-right: 4px;
`;
const VerificationContainer = styled.div`
  display: inline-block;
  font-size: 20px;
  margin-top: 20px;
`;
const ApprovedColor = styled.span`
  color: green;
`;
const NotApprovedColor = styled.span`
  color: #ff8027;
`;
const UnverifiedColor = styled.span`
  color: #006fc1;
`;
const IconWrapper = styled.span`
  padding-left: 0.5rem;
  padding-right: 0.5rem;
  img {
    margin: 0px !important;
  }
`;
const UnverifiedRescan = styled.div`
  display: flex;
  gap: 32px;
`;
const UnverifiedBody = styled.div`
  font-size: 20px;
  font-weight: normal !important;
  padding-top: 4px;
`;
const FontWeightNormal = styled.div`
  font-weight: normal !important;
`;
const BodyFormat = styled.div`
  font-size: 18px;
  line-height: 24px;
`;
const Span = styled.div`
  display: inline-block;
`;

const IDScanModal = (props) => {
  const [documentType, documentTypeInfo] = useState([
    { label: 'Select', value: 'Select' },
    {
      label: "Driver's License/State Issued ID",
      value: "Driver's License/State Issued ID",
    },
    { label: 'US Passport', value: 'US Passport' },
    { label: 'US Passport Card', value: 'US Passport Card' },
    { label: 'Canadian Passport', value: 'Canadian Passport' },
    { label: 'Exception Review', value: 'Exception Review' },
  ]);
  const [selectedDocumentType, selectedDocumentTypeInfo] = useState('Select');
  const [disableButton, setDisableButton] = useState(false);
  const [idVerifiedValidateStatus, setIdVerifiedValidateStatus] = useState('');
  const [frontPageImage, setFrontPageImage] = useState('');
  const [attemptCountNum, setAttemptCountNum] = useState('');
  const [OpenWarningModal, setWarningModal] = useState(false);
  const [getExceptionReview, updateExceptionReview] = useState(false);
  useEffect(() => {
    window.scanIdCallBack = scanIdCallBack;
    if (selectedDocumentType == 'Select') {
      setDisableButton(true);
    }
  }, []);

  const changeDocumentType = (e) => {
    selectedDocumentTypeInfo(e.target.value);
    setIdVerifiedValidateStatus('');
    updateExceptionReview(false);
    setFrontPageImage('');
    if (e.target.value == 'Select') {
      setDisableButton(true);
    } else {
      setDisableButton(false);
    }
  };

  const callScanId = () => {
    let documentType = '';
    if (selectedDocumentType && selectedDocumentType == "Driver's License/State Issued ID") {
      documentType = 'dl';
    } else if (selectedDocumentType && selectedDocumentType == 'US Passport Card') {
      documentType = 'passportCard';
    } else if (
      selectedDocumentType &&
      (selectedDocumentType == 'US Passport' || selectedDocumentType == 'Canadian Passport')
    ) {
      documentType = 'passport';
    }
    const {
      caseId = '',
      cartId = '',
      customerId = '',
      lookupMtn = '',
      accountNo = '',
      email = '',
      customerName = {},
    } = props?.customerProfileDetails?.customer;
    const { firstName = '', lastName = '' } = customerName;
    const creditAppNum = sessionStorage.getItem('creditAppNum');
    const customerType = sessionStorage.getItem('customerType');
    const creditAppNumber =
      props?.cartDetails?.orderDetails?.orderList?.[0]?.creditApplication?.creditApplicationNum || '';
    const str = 'window.scanIdCallBack';
    const param = {
      documentType: documentType,
      flowType: customerType == 'N' ? 'prospect' : 'simSwap', //“prospect”/“simSwap”,
      cartId: cartId,
      creditAppNumber: creditAppNum || creditAppNumber,
      mtn: props?.activeMtn, //<mtn trying to do simSwap>,
      callback: str, //<javascript function for shell to call with verification results>,
      customerId: customerId,
      caseId: caseId,
      accountNumber: accountNo,
      cartCreator: lookupMtn,
      email: email,
      firstName: firstName,
      lastName: lastName,
      attemptCount: attemptCountNum ? attemptCountNum : 1,
      correlationId: props?.correlationId,
      simswapSessionId: props?.simswapSessionId,
    };
    console.log('callback params***', param);
    executeShellFunction('Shell', 'scanAndVerifyDocument', 'none', param);
  };
  const scanIdCallBack = (scanData, responseData) => {
    try {
      console.log('ID verified API response**', scanData, responseData);
      if (responseData) {
        const verifiedIdResponse = /string/i.test(typeof responseData) ? JSON.parse(responseData) : responseData;
        const mitekResponseCode = verifiedIdResponse?.mitekResponseCode;
        let attemptCount = verifiedIdResponse?.attemptCount && Number(verifiedIdResponse?.attemptCount);
        const isUnVerifiedRescan =
          /400|401|403|404|408|415/.test(mitekResponseCode) ||
          (/200/.test(mitekResponseCode) && /AttemptFailed/i.test(verifiedIdResponse?.authResultStatus));
        if (/200|201/.test(mitekResponseCode) && verifiedIdResponse?.authResultStatus === 'PASSED') {
          //Approved
          setIdVerifiedValidateStatus('Approved');
        } else if (/200|201/.test(mitekResponseCode) && verifiedIdResponse?.authResultStatus === 'FAILED') {
          //Not Approved
          setIdVerifiedValidateStatus('NotApproved');
          setDisableButton(true);
        } else if (isUnVerifiedRescan && attemptCount < 3) {
          //Unverified rescan
          setIdVerifiedValidateStatus('Rescan');
          setDisableButton(true);
          setAttemptCountNum(attemptCount + 1);
        } else if (/500|503/.test(mitekResponseCode) || (isUnVerifiedRescan && attemptCount == '3')) {
          //Unverified
          setIdVerifiedValidateStatus('Unverified');
        }
      }
      if (scanData) {
        const scanDataObject = /string/i.test(typeof scanData) ? JSON.parse(scanData) : scanData;
        const image = scanDataObject.frontPage ? 'data:image/jpg;base64,' + scanDataObject.frontPage : '';
        image && setFrontPageImage(image);
      }
    } catch (error) {
      console.log('Inside catch of scanIdCallBack** : ' + error);
    }
  };
  const handleProceedButton = () => {
    selectedDocumentType === 'Exception Review' || idVerifiedValidateStatus === 'Unverified'
      ? setWarningModal(true)
      : props?.DeviceScanFow
      ? props?.handleModelChangeEsimFlow(false)
      : props?.handleModelChange(false);
    const idverifyData =
      idVerifiedValidateStatus !== '' && idVerifiedValidateStatus !== undefined
        ? idVerifiedValidateStatus
        : selectedDocumentType === 'Exception Review'
        ? 'ExceptionReview'
        : '';
    props?.setMitekIdVerifyStatus(idverifyData);
  };
  const modalChanged = (opened) => {
    if (!opened) {
      if (props?.DeviceScanFow == true) {
        props?.disableUpdateDeviceSwap();
      } else {
        props?.handleGetUpdateOldSimId(idVerifiedValidateStatus);
      }
      props?.closeModal();
      props?.setMitekIdVerifyStatus('');
    }
  };
  const handleIdVerificationType = () => {
    return (
      <>
        <VerificationContainer>
          <VerificationType>{props.idVerificationType}</VerificationType>
        </VerificationContainer>
        <VerificationContainer>
          <FontWeightNormal>{selectedDocumentType}</FontWeightNormal>
        </VerificationContainer>
      </>
    );
  };
  const closeModal = () => {
    setWarningModal(false);
  };
  const redirectUrl = () => {
    let url = 'https://infomanager.verizon.com/content/km/categories/accessories/203390.html';
    if (isIpad()) {
      const shellParams = {
        name: 'Infomanager Policy',
        path: '',
        replace: 'true',
        params: `rawurl:${url}`,
        isExternalLink: 'true',
      };
      executeShellFunction('Shell', 'showScreen', 'none', shellParams);
    } else {
      window.open(url, 'blank', 'noopener');
    }
  };

  const handleIdVerificationBody = (data) => {
    if (idVerifiedValidateStatus == 'NotApproved') {
      return (
        <PaddingTop24>
          <Body size='large'>
            <BodyFormat>
              {data}
              <Span>
                <TextLinkCaret surface='light' iconPosition='right' onClick={() => redirectUrl()}>
                  OST 203390.
                </TextLinkCaret>
              </Span>
            </BodyFormat>
          </Body>
        </PaddingTop24>
      );
    } else {
      return (
        <PaddingTop24>
          <Body size='large'>
            <BodyFormat>{data}</BodyFormat>
          </Body>
        </PaddingTop24>
      );
    }
  };

  const exceptionReview = () => {
    if (selectedDocumentType == 'Exception Review') {
      updateExceptionReview(true);
    }
  };
  return (
    <div data-testid='IdSecureScan' className='IdModalScan' style={{ zIndex: '9999' }}>
      <Modal
        surface='light'
        fullScreenDialog={true}
        disableAnimation={false}
        hideCloseButton={false}
        disableOutsideClick={true}
        ariaLabel='Testing Modal'
        opened={props?.isOpen}
        width='100%'
        onOpenedChange={modalChanged}
        closeButton={idVerifiedValidateStatus == 'Approved' ? null : undefined}
      >
        <ModalTitle>
          <DisplayBox>
            <Icon name='warning' color={ColorTokens.palette.black.value} size='large' />
            <PaddingLeft12>
              <Title size='large' bold>
                {props.highRiskTransactionTitle}
              </Title>
            </PaddingLeft12>
          </DisplayBox>
        </ModalTitle>
        <br />
        <Line type='secondary' surface='light' width='90%' size='4px'></Line>
        <ModalBody>
          <ModalContainer>
            <LeftContainer>
              <Body size='large'>
                <BodyFormat>{props.idVerificationSubTitle}</BodyFormat>
              </Body>
              <Title size='small' bold>
                {props.scanIdContinueTitle}
              </Title>
              <LeftParent>
                <DropdownSelect
                  label='Document type'
                  errorText='Select a Document type'
                  error={false}
                  width='80%'
                  disabled={idVerifiedValidateStatus == 'NotApproved'}
                  data-testid='Getdropdown'
                  readOnly={false}
                  inlineLabel={false}
                  onChange={(e) => changeDocumentType(e)}
                >
                  {documentType.map((list) => (
                    <option value={list.value}>{list.label}</option>
                  ))}
                </DropdownSelect>
                {selectedDocumentType == 'Exception Review' ? (
                  <PaddingTop24>
                    <Button size='small' use='primary' onClick={() => exceptionReview()}>
                      {props.ReviewButton}
                    </Button>
                  </PaddingTop24>
                ) : (
                  <PaddingTop24>
                    <Button size='small' disabled={disableButton} use='primary' onClick={() => callScanId()}>
                      {props.scanIdButton}
                    </Button>
                  </PaddingTop24>
                )}
              </LeftParent>
              <FlexContainer>
                <Body size='medium'>
                  <b>Note: </b>
                  {props.exceptionReviewNote}
                </Body>
              </FlexContainer>
            </LeftContainer>
            <RightContainer>
              <PlanIncludeContainer>
                {frontPageImage ? (
                  <ImagePathFront>
                    <img src={frontPageImage} width={435} height={299} />
                  </ImagePathFront>
                ) : (
                  <ImagePath>
                    <Icon name='set-gallery-image' color={ColorTokens.palette.black.value} size='xlarge' />
                  </ImagePath>
                )}
              </PlanIncludeContainer>
              <PaddingTop12 />
              <Body size='medium'>{props.eligibleIdNote}</Body>
            </RightContainer>
          </ModalContainer>
          {getExceptionReview && selectedDocumentType == 'Exception Review' && (
            <PaddingTop24>
              <Line surface='dark' type='secondary' height='4px' />
            </PaddingTop24>
          )}
          {idVerifiedValidateStatus && (
            <PaddingTop24>
              <Line surface='dark' type='secondary' height='4px' />
            </PaddingTop24>
          )}
          {idVerifiedValidateStatus == 'Approved' && (
            <>
              <VerificationStatus>
                {props.idVerificationStatusTitle}
                <IconWrapper>
                  <img src={greencheckmark} alt='greencheckmark' width='20px' height='20px' />
                </IconWrapper>
                <ApprovedColor>{props.approvedStatus}</ApprovedColor>
              </VerificationStatus>
              {handleIdVerificationType()}{' '}
            </>
          )}
          {idVerifiedValidateStatus == 'NotApproved' && (
            <>
              <VerificationStatus>
                {props.idVerificationStatusTitle}
                <IconWrapper>
                  <Icon name='error' color='#FF8027' size='xlarge' />
                </IconWrapper>
                <NotApprovedColor>{props.notApprovedStatus}</NotApprovedColor>
              </VerificationStatus>
              {handleIdVerificationType()}
              {handleIdVerificationBody(props.notApprovedStatusMsg)}
            </>
          )}
          {idVerifiedValidateStatus == 'Rescan' && (
            <>
              <VerificationStatus>
                {props.idVerificationStatusTitle}
                <IconWrapper>
                  <Icon name='error' color='#006FC1' size='xlarge' />
                </IconWrapper>
                <UnverifiedColor>{props.unverifiedStatus}</UnverifiedColor>
              </VerificationStatus>
              {handleIdVerificationType()}
              <PaddingTop24>
                <UnverifiedRescan>
                  <UnverifiedBody>{props.reScanIdNote} </UnverifiedBody>
                  <div>
                    <Button size='small' use='secondary' onClick={() => callScanId()}>
                      {props.reScanIdButton}
                    </Button>
                  </div>
                </UnverifiedRescan>
              </PaddingTop24>
            </>
          )}
          {idVerifiedValidateStatus == 'Unverified' && (
            <>
              <VerificationStatus>
                {props.idVerificationStatusTitle}
                <IconWrapper>
                  <Icon name='error' color='#006FC1' size='xlarge' />
                </IconWrapper>
                <UnverifiedColor>{props.unverifiedStatus}</UnverifiedColor>
              </VerificationStatus>
              {handleIdVerificationType()}
              {handleIdVerificationBody(props.unverifiedNote)}
            </>
          )}
          {getExceptionReview && selectedDocumentType == 'Exception Review' && (
            <>
              <VerificationStatus>{props.exceptionReviewTitle}</VerificationStatus>
              {handleIdVerificationBody(props.exceptionReviewResponseNote)}
            </>
          )}
          {getExceptionReview && selectedDocumentType == 'Exception Review' && (
            <TextLinkWrapper>
              <Button use='primary' size='medium' onClick={handleProceedButton} data-testid='ProceedButton'>
                {props.proceedButton}
              </Button>
            </TextLinkWrapper>
          )}

          {idVerifiedValidateStatus && (
            <TextLinkWrapper>
              <Button
                use='primary'
                disabled={idVerifiedValidateStatus == 'NotApproved' || idVerifiedValidateStatus == 'Rescan'}
                size='medium'
                onClick={handleProceedButton}
                data-testid='ProceedButton'
              >
                {props.proceedButton}
              </Button>
            </TextLinkWrapper>
          )}
          {OpenWarningModal && (
            <SMSWarningNotify
              isOpen={OpenWarningModal}
              closeModal={closeModal}
              idScanCloseModal={props?.closeModal}
              handleModelChange={props?.handleModelChange}
              DeviceScanFow={props?.DeviceScanFow}
              handleModelChangeEsimFlow={props?.handleModelChangeEsimFlow}
            />
          )}
        </ModalBody>
      </Modal>
    </div>
  );
};
IDScanModal.defaultProps = {
  highRiskTransactionTitle: 'High-Risk Transaction',
  idVerificationSubTitle: 'ID Verification is required to complete this transaction.',
  scanIdContinueTitle: 'Please scan an ID to continue',
  exceptionReviewNote:
    'Military IDs, Tribal Identification Cards and Resident Alien Cards cannot be scanned. If no other alternative available, use Exception Review to continue.',
  eligibleIdNote: 'Please select an eligible ID from the Document type dropdown.',
  idVerificationStatusTitle: 'ID verification status:',
  notApprovedStatusMsg:
    'The ID has not been approved and this transaction cannot be processed. Adaptive Authentication is required for account access for 24 hours. For more information see',
  reScanIdNote: 'We were unable to verify the ID. Click rescan to try again.',
  unverifiedNote:
    'We were unable to verify the ID. You can still submit this order, but the activation will be delayed for 60 minutes and will not activate immediately. Click Proceed to continue or close this window to exit.',
  exceptionReviewResponseNote:
    'Based on the document type, Digital ID verification cannot be performed. You can still submit this order, but the activation will be delayed for 60 minutes and will not activate immediately. Click Proceed to continue or close this window to exit.',
  exceptionReviewTitle: 'Exception Review',
  idVerificationType: 'ID verification type:',
  proceedButton: 'Proceed',
  scanIdButton: 'Scan ID',
  reScanIdButton: 'Rescan ID',
  approvedStatus: 'Approved!',
  notApprovedStatus: 'Not Approved',
  unverifiedStatus: 'Unverified',
  ReviewButton: 'Review',
};

IDScanModal.propTypes = {
  highRiskTransactionTitle: PropTypes.string,
  idVerificationSubTitle: PropTypes.string,
  scanIdContinueTitle: PropTypes.string,
  exceptionReviewNote: PropTypes.string,
  eligibleIdNote: PropTypes.string,
  idVerificationStatusTitle: PropTypes.string,
  notApprovedStatusMsg: PropTypes.string,
  reScanIdNote: PropTypes.string,
  unverifiedNote: PropTypes.string,
  exceptionReviewResponseNote: PropTypes.string,
  exceptionReviewTitle: PropTypes.string,
  idVerificationType: PropTypes.string,
  proceedButton: PropTypes.string,
  scanIdButton: PropTypes.string,
  reScanIdButton: PropTypes.string,
  approvedStatus: PropTypes.string,
  notApprovedStatus: PropTypes.string,
  unverifiedStatus: PropTypes.string,
  ReviewButton: PropTypes.string,
};
export default IDScanModal;
