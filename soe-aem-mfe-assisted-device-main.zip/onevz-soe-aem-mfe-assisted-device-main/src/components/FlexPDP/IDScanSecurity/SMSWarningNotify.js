import React from 'react';
import { Modal, ModalTitle, ModalFooter, ModalBody } from '@vds/modals';
import { Title, Body } from '@vds/typography';
import { PaddingTop24 } from '../../CombinedGridwall/FlexGlobalStyledConstants';

const SMSWarningNotify = (props) => {
  const goBack = () => {
    props?.closeModal();
    props?.idScanCloseModal();
    props?.DeviceScanFow ? props?.handleModelChangeEsimFlow(false) : props?.handleModelChange(false);
  };

  return (
    <Modal
      surface='light'
      fullScreenDialog={false}
      hideCloseButton={false}
      disableOutsideClick={false}
      ariaLabel='Testing Modal'
      opened={props?.isOpen}
      onOpenedChange={(opened) => {
        if (!opened) props?.closeModal();
      }}
      width='720px'
      id='IdModalScanFooter'
    >
      <ModalTitle>
        <Title size='large' bold>
          Notify other lines on the account
        </Title>
      </ModalTitle>
      <PaddingTop24>
        <ModalBody>
          Upon order submission an SMS notification will be sent to all eligible lines on the account with an option to
          cancel the pending activation before it completes. This may give non-managing account members the ability to
          cancel this order.
          <br />
          <br />
          Do you have the customer's consent to message other lines on the account?
        </ModalBody>
      </PaddingTop24>

      <ModalFooter
        buttonData={{
          primary: {
            children: 'Yes',
            onClick: () => {
              goBack();
            },
          },
          close: {
            children: 'No',
            onClick: () => {
              props?.closeModal();
            },
          },
        }}
      />
    </Modal>
  );
};
export default SMSWarningNotify;
