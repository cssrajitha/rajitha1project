/* eslint-disable no-nested-ternary */
/* eslint-disable react/no-array-index-key */
/* eslint-disable jsx-a11y/no-noninteractive-tabindex */
/* eslint-disable you-dont-need-lodash-underscore/get */
import React, { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Button , TextLink } from '@vds/buttons';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import Emitter from 'onevzsoemfeframework/Emitter';
import { Title, Body } from '@vds/typography';
import { Line } from '@vds/lines';
import { RadioBoxGroup } from '@vds/radio-boxes';
import { RadioButtonGroup } from '@vds/radio-buttons';
import { RadioSwatchGroup } from '@vds/radio-swatches';
import { Toggle } from '@vds/toggles';
import { Icon } from '@vds/icons';
import { Notification } from '@vds/notifications';
// eslint-disable-next-line you-dont-need-lodash-underscore/get
import { get as getProp, isEmpty } from 'lodash';
import { Modal, ModalBody } from '@vds/modals';
import { Tooltip, TrailingTooltip } from '@vds/tooltips';
import { rfexMfeFlowFlag } from 'onevzsoemfecommon/Helpers/common_functions';
import { sendCustomEvent } from 'onevzsoemfeframework/Tagging';
import {
  getQueryParamByName,
  isIpad,
  isD2D,
  isRetail,
  isTelesales,
  executeShellFunction,
} from 'onevzsoemfeframework/DomService';
import { getUIContextPathBAU, formatCurrency } from 'onevzsoemfecommon/Helpers';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { ConfirmationDialogBox } from 'onevzsoemfecommon/ConfirmationDialogBox';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import TimeoutManager from 'onevzsoemfecommon/TimeoutManager';
import {
  useLazyEligibleNumberShareListQuery,
  useLazyRetrievedppQuery,
  useLazyNumberSharePairUnpairQuery
  // useLazyGetDevicePricingEligibilityQuery,
} from 'onevzsoemfecommon/DeviceAPIService';
import { useLazyGetInventoryDetailsQuery } from 'onevzsoemfecommon/BrowseAPIService';
import { isVbg } from 'onevzsoemfeframework/VbgAemUtil';
import IDLInfo from './MoreOptions/IDLInfo';

import FccInfo from './FccInfo';
// import { useLazyGetRetrieveURCodeQuery } from 'onevzsoemfecommon/CartAPIService';
import { getFFlag, makeOpenViewCall, isFunctionalityEnabled, getSCMFilteredDfillAndBulkSims } from '../../modules/utils/index';
import {
  // useLazyGetInventoryDetailsQuery,
  // useLazyEligibleNumberShareListQuery,
  useLazyGetRetrieveURCodeQuery,
  useLazyGetDevicePricingEligibilityQuery,
  useLazyGetBestBuyInventoryQuery,
} from '../../modules/services/APIService/APIServiceHooks';
import './DeviceInfo.css';
import NumberSharedModal from './NumberShareModal';
import {
  getBestBuyPricingDetails,
  isDfillOrderForIndirect,
  isLocalOrderForIndirect,
  isDisableShipIttoogle,
  isDWOSAllowed,
  isDropshipSku,
} from './pdputils';

import { showDownPaymentOptions, addDynamicContractPrices, sortPaymentOptions } from './deviceinfoutils';

import {
  PaddingBot24,
  FlexBoxContainer,
  PaddingRight16,
  FlexAlignCenterBox,
  PaddingTop16,
  Padding8,
  Padding16,
} from '../CombinedGridwall/FlexGlobalStyledConstants';
import SizeSelector from './SizeSelector';
import DeviceInsurance from './DeviceProtection/DeviceInsurance';
import ISPUPage from './ISPUPage';
import DeviceSpecifications from './DeviceSpecifications';
import Footer from './Footer';
import Header from './Header';
import DeviceSimID from './DeviceSimID/DeviceSimID';
import SmartWatchOptions from './SmartWatchOptions';
import CountdownTimer from './CountdownTimer';
import BuyoutAmount from './BuyoutModel/BuyoutAmount';
import { onKeyPressEvent } from '../../modules/test-utils/utils';
import { doCallGetSkuDetails as doCallGetSkuDetailsUtil } from './DeviceInfo.utils';
import MonthlyPayment from './BuyoutModel/MonthlyPayment';
import PreOwnedDevice from './PreOwnedDevice';
import SecondNumberWarningModal from './SecondNumberWarningModal';
import OmniCareDropDownOptions from './OmniCareDropDownOptions';
import getIspuSimEnable from '../../modules/utils/getIspuSimEnable';
import { DROPSHIP_DEVICE_TOOLTIP, TELESALES_ISPU_SIM_SORID_CPE } from './PDP_Constants';
import IndirectPaymentOptions from './indirectPaymentOptions';
import { DARK_THEME_COLOR, LIGHT_THEME_COLOR } from '../../constants/constants';
import BackorderText from './BackOrderText';

import  PaymentOptionsDisclaimer  from './PaymentOptionsDisclaimer';
import { contractTermLabels, contractTerms, contractTextLabels } from '../../constants/ContractTerms';
import { getDpTermIndex, getPricingPriority } from '../../modules/utils/devicePricingUtils';
import { toFullYear } from '../../modules/utils/dateUtils';
import { isVbgnsaDropshipFFlag } from '../../modules/utils/vbgUtils';
import { FEATURE_FLAGS } from '../../constants/featureFlags';
import { CONTRACT_TYPES } from '../../constants/contractTypes';
import { UI_SELECTORS } from '../../constants/uiSelectors';
import FFLAGS from '../../constants/fFlag.constant';
import { GetAppConfig } from '../../modules/utils/GetAppConfig';

const isScmfullScreenFix = isFunctionalityEnabled('scmPactCommonFixFFlag', 'scmfullScreenFix');
const enableSCMNumberShare = getFFlag('enableNumberShareForVZWACSSFFlag') === 'Y';

const ImgWrapper = styled.div`
  display: flex;
  width: 252px;
  height: 312px;
`;
const getMaxWidthPDPWrapper = (scmDeviceEnable) => {
  if (scmDeviceEnable) {
    return window?.mfe?.isProspectNewCustomerTab ? '920px' : '875px';
  }
  // Default PDP max-width when SCM Device MFE is not enabled
  return '1133px';
};

// Computes position based on SCM Device MFE enablement and Maslow app context
const getPositionValue = (scmDeviceEnable, isMaslowAppProp) => {
  // Keep fixed positioning under SCM Device MFE
  if (scmDeviceEnable) {
    return 'relative';
  }
  // In Maslow app, PDP should be absolutely positioned
  return isMaslowAppProp ? 'absolute' : 'fixed';
};

const PDPWrapper = styled.div`
  margin-top: 2rem;
  max-width: ${({ scmDeviceEnable }) => getMaxWidthPDPWrapper(scmDeviceEnable)};
  width: 100%;
  position: ${({ scmDeviceEnable, isMaslowApp }) => getPositionValue(scmDeviceEnable, isMaslowApp)};
  display: flex;
  top: ${({ scmDeviceEnable }) => (scmDeviceEnable ? '6rem' : '3rem')};
`;
const TextLinkWrapper = styled.div`
  text-align: left;
`;
const ColorTextLinkWrapper = styled.div`
  text-align: left;
  padding-top: 15%;
  padding-left: 30px;
  align-self: center;
`;
const InfoWrapper = styled.div`
  display: flex;
  flex-direction: column;
  margin: 2rem 0;
  width: calc(100% - 4rem);
`;
const TextWrapper = styled.div`
  color: green;
  font-family: 'BrandFont-Text';
`;
const SkuWrapper = styled.div`
  display: flex;
  flex-direction: row;
  margin-top: 1rem;
`;

const StorageCapacityWrapper = styled.div`
  // width: 25rem;
`;
const PaymentOptionsWrapper = styled.div`
  width: 90%;
  div::before {
    content: '';
    display: none;
  }
  label {
    padding: 0.5rem;
    color: #000000 !important;
  }
  & label::before {
    content: '';
    display: none;
  }

  margin-bottom: 0.2em;

  & > div {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1rem;
  }
`;

// Styled wrappers for Activate Later date list using theme spacing tokens
// Fallbacks provided to avoid hardcoded magic numbers when no theme is supplied
const ActivateLaterSection = styled.div`
  margin-top: ${({ theme }) => theme?.spacing?.small ?? '10px'};
`;

const ActivatedDateListWrapper = styled.div`
  margin-top: ${({ theme }) => theme?.spacing?.large ?? '36px'};
  display: flex;
`;

const DateItemButtonContainer = styled.div`
  margin-right: ${({ theme }) => theme?.spacing?.medium ?? '24px'};
`;

const DateItemDate = styled.div`
  margin-top: ${({ theme }) => theme?.spacing?.small ?? '10px'};
`;

const FlexRight = styled.div`
  flex-grow: 1;
  text-align: right;
`;
const HorizontalLineWrapper = styled.div`
  padding: 1rem 0 1rem 0;
`;
const FlexBoxContainerP = styled(FlexBoxContainer)`
  gap: 10px;
`;

const MarginSides = styled.div`
  margin: 0 2rem;
  overflow-y: ${/* istanbul ignore next */ (scmDeviceMfeEnable) => scmDeviceMfeEnable && 'auto'};
  height: ${/* istanbul ignore next */ (scmDeviceMfeEnable) => scmDeviceMfeEnable && '40vh'};
`;

const DivFlexContainer = styled.div`
  display: flex;
`;

const LeftWrapper = styled.div`
  width: 260px;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  gap: 1.2rem;
  margin-top: 0.7rem;
  z-index: ${({ scmDeviceMfeEnable }) => (scmDeviceMfeEnable ? '0' : '100')};
`;
/* istanbul ignore next */
const RightWrapper = styled.div`
  display: flex;
  flex: 1;
  flex-direction: column;
  width: 100%;
  overflow-y: auto;
  padding-left: 0.5rem;
  height: ${({ scmDeviceMfeEnable }) => ((scmDeviceMfeEnable && isScmfullScreenFix) ? '82vh' :  'calc(100vh - 86px)')};
`;

const RadioButtonStyle = styled.div`
  & > div {
    display: flex;
    flex-direction: row !important;
  }
  & label {
    margin-right: 5rem !important;
  }
`;
const ExcludeSubText = styled.span`
  font-size: 0.6rem;
  font-weight: normal !important;
  font-family: sans-serif;
`;
const PaymentSubText = styled.span`
  width: 100%;
  font-size: 0.7rem;
`;

export const RadioSwatchGroupWrapper = styled.div`
  [class^='RadioSwatchGroupWrapper-'] {
    label:first-child {
      padding-bottom: 0.5rem;
      width: 100%;
      ${(props) => !props.isDark && `color: ${props.color || '#000000'};`}
    }
  }

  label {
    width: 2rem;
    height: 2rem;
  }
  input[type='radio']:not(:checked) + label:hover {
    box-shadow: none !important;
    border: none !important;
  }
  input[type='radio']:checked + label {
    box-shadow: rgb(0, 0, 0) 0px 0px 0px 0.0625rem;
    .colorFill {
      width: 1.5rem;
      height: 1.5rem;
    }
  }
  label::before {
    content: '' !important;
    display: none !important;
  }
  [class^='SwatchFill-'] {
    width: 2rem;
    height: 2rem;
  }
`;
const RestrictWrapper = styled.div`
  [class^='ToggleSwitchSlider-'] {
    background-color: ${(props) => (props.localOnlyLocation ? '' : props.disableShipIttoogle ? '#008330' : '')};
    cursor: ${(props) => (props.disableShipIttoogle ? 'not-allowed' : 'pointer')};
  }
`;
const IspuWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  cursor: pointer;
  gap: 1rem;
`;

const SelectHostNum = styled.div`
  padding: 0 1.5rem 0 0;
`;
const ModelWrap = styled(Modal)`
  padding: 0px;
  height: ${({ scmDeviceMfeEnable }) => scmDeviceMfeEnable && '55%'};
  border: ${({ scmDeviceMfeEnable }) => scmDeviceMfeEnable && '1px solid'};
  width: ${({ scmDeviceMfeEnable }) => (scmDeviceMfeEnable ? '55vw !important' : '100%')};
  & > div {
    max-width: 1133px;
    width: 100%;
    margin: 0 auto;
    padding: 0px;
  }
`;
const PaymentOptionsSubtextWrapper = styled.div`
  display: flex;
  width: 69%;
`;

const DivWrapper = styled.div`
  // width: 25rem;
`;

let navigate = '';

function useNavigateMFE() {
  navigate = useNavigate();
}

function HorizontalLine() {
  return (
    <HorizontalLineWrapper>
      <Line type='secondary' surface='light' />
    </HorizontalLineWrapper>
  );
}

/**
 * Handles VBG professional install configuration
 * @param {boolean} isVbgProfessionalInstall - Flag indicating if VBG professional install is enabled
 * @param {function} setIsShipItToggleOn - Function to set ship it toggle state
 * @param {function} setDisableShipIttoogle - Function to set disable ship it toggle state
 */
const handleVbgProfessionalInstall = (isVbgProfessionalInstall, setIsShipItToggleOn, setDisableShipIttoogle) => {
  if (isVbgProfessionalInstall) {
    setIsShipItToggleOn(true);
    setDisableShipIttoogle(true);
  }
};
const scmBulkDFillSimFixEnabled = isFunctionalityEnabled(FFLAGS?.scmCommonDefectFixFFlag?.name, FFLAGS?.scmCommonDefectFixFFlag?.attribute?.scmBulkDFillSimFix, FFLAGS?.scmCommonDefectFixFFlag?.attribute?.scmBulkDFillSimDbFlag);

function DeviceInfo(props) {// NOSONAR
  const [isCLNRon, setCLNRon] = useState(false);
  const [isActivateLater, setIsActivateLater] = useState(false);
  const [activatedDateList, setActivateDateOptions] = useState([]);
  const [showDeviceModal, setShowDeviceModal] = useState(null);
  const [storeList, setStoreList] = useState(false);
  const [showOnlyAvailableStores, setShowOnlyAvailableStores] = useState(true);
  const [dppIndicatorValue, setDppIndicatorValue] = useState();
  const [isMaslowApp, setIsMaslowApp] = useState(false);
  // AAL Activate Later feature flag state (read from sessionStorage APP_PROPERTIES)
  const [isAALActivateLaterFFlag, setIsAALActivateLaterFFlag] = useState(false);
  const [selectedPlanId, setSelectedPlanId] = useState('');
  const [showGetEsimPopup, setShowGetEsimPopup] = useState(false);
  const [callESimApi, setCallESimApi] = useState(false);
  const [showGetESimInOption, setShowGetESimInOption] = useState(props?.genProfileOption || false);
  const [removeSimOnlyChange, setRemoveSimOnlyChange] = useState(false);
  const scmDeviceEnable = window?.mfe?.scmDeviceMfeEnable;
  const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable;
  const scmCombinedGridwallFlow = window?.mfe?.scmCombinedGridwallFlow || false;

  const isScmSecondNumPerkEnabled = getQueryParamByName('isScmSecondNumPerkEnabled') || false;

  const isDark = (scmDeviceEnable && window?.mfe?.isDark) || false;
  const deviceInfoFFlag = getFFlag('scmDeviceInfoPopupFixFFlag') || false;
  const isEsimActivationEnabled = isFunctionalityEnabled(
    FFLAGS?.scmCommonDefectFixFFlag?.name,
    FFLAGS?.scmCommonDefectFixFFlag?.attribute?.EsimActivationEnabled,
    FFLAGS?.scmCommonDefectFixFFlag?.attribute?.eSimDbFlag,
  );
  const {
    productDetails,
    protectionFeatures,
    activeMtn,
    customerProfileDetails,
    selectedColor,
    setSelectedColor,
    ispuToggleOn,
    setIspuToggleOn,
    isShipItToggleOn,
    setIsShipItToggleOn,
    showISPULocalConflictBanner,
    selectedSku,
    setSelectedSku,
    selectedProtectionFeature,
    setSelectedProtectionFeature,
    selectedSize,
    setSelectedSize,
    specsData,
    inbox,
    OverviewDetails,
    btnLabel,
    callDeviceAddToCart,
    isCartBtnEnable,
    cartDetails,
    isNumberShare,
    sharedMtnValue,
    numberShareValue,
    updateNumberShare,
    updateNumberShareValue,
    setSelectedPaymentInfo,
    showDeviceProtectionModal,
    setShowDeviceProtectionModal,
    selectedPaymentInfo,
    removeLines,
    isPreorderCountDownEnabled,
    isPreorderTestingEnabled,
    // tmpScreenOpened,
    isTMPScreenOpened,
    protectionShownStatusInDevice,
    // setProtectionShownStatusInDevice,
    tmpLinkClicked,
    setTmpLinkClicked,
    validateDeviceSimIdResult,
    setIsIspuItemInCart,
    selectedStore,
    setSelectedStore,
    setUpgradeReasonType,
    upgradeReasonType,
    details,
    groupPreOwnedConditionSkus,
    handlePreOwnedDeviceRadioChangeParent,
    groupByColors,
    getInventoryStatus,
    groupBySmartWatchBand,
    setSimIdResult,
    setisInStock,
    setBuyOutAccepted,
    setSkipRedirection,
    isPreOrder,
    setSecondNumDeviceId,
    setSecondNumSimId,
    secondNumSimId,
    secondNumData,
    getContractTerm,
    incompatibleSim,
    setIncompatibleSim,
    ispuSim,
    setIspuSim,
    computeDPPriceResult,
    setBuyoutToggleChange,
    isBBYLocalOrder,
    shouldHideISPU,
    sendFullRetailPrice,
    skuRealAgentCode,
    computeDPPriceBody,
    downPayment,
    GetDetailsResult,
    SkuDetailsResult,
    simSwapNotificationHighRiskMsg,
    updatePaymentDetails,
    bbComputeDPPriceResult,
    setBbPaymentOptionsSelected,
    isAcssDfillSim,
    showPlanChange,
    isFiveG,
    isVbgProfessionalInstall,
    setActivatedDate
  } = props;

  const queryParamIspu = getQueryParamByName('isIspu') === 'true';
  
  /* istanbul ignore next */
  useEffect(() => {
    if (queryParamIspu && scmUpgradeMfeEnable) {
      setShowDeviceModal(true);
    }
  }, [queryParamIspu]);


  const isFWAShowDevice = SkuDetailsResult?.data?.data?.deviceSku?.parentProducts?.find(prd => ['5G Internet','5G Router']?.includes(prd?.sorDeviceCategory));

  const idlInfo =
    productDetails?.deviceProduct?.deviceUnlockPolicy?.text ||
    productDetails?.deviceSku?.parentProducts?.[0]?.deviceUnlockPolicy?.text ||
    '';

  const isVbgFlag = isVbg();
  const cleanUpEmitterFFlag = /true/i.test(getAssistedCradlePropertyV2(['cleanUpEmitterFFlag'])?.[0]);
  const navigateBackToMaslowFFlag = getAssistedCradlePropertyV2(['navigateBackToMaslowFFlag'])[0] === 'TRUE';
  const editDeviceIndirectFFlag = /true/i.test(getAssistedCradlePropertyV2(['editDeviceIndirectFFlag'])?.[0]);
  const timeoutManager = new TimeoutManager({ fileName: 'DeviceInfo.js', enableFF: cleanUpEmitterFFlag });
  const isOmniCare = scmDeviceEnable ? true : customerProfileDetails?.customer?.channel === 'OMNI-CARE';
  const [deviceIdSelected, setDeviceIdSelected] = useState(false);
  const [omnicaredropdownValue, setomnicaredropdownValue] = useState('SIM only change');
  const elvisFFlag = /true/i.test(sessionStorage.getItem('elvisFFlag'));
  const isElvisAndNotVbg = elvisFFlag && !isVbgFlag;
  const vbgNsaIspuForExsCustFFlag = /true/i.test(getAssistedCradlePropertyV2(['vbgNsaIspuForExsCustFFlag'])?.[0]);
  const vbgNsaYearFormatActLaterFFlag = /true/i.test(getAssistedCradlePropertyV2([FEATURE_FLAGS.VBG_NSA_YEAR_FORMAT_ACT_LATER])?.[0]);
  const [
    enableEUPDualNum,
    dropshipProdcode5,
    enableDropship,
    bestBuyIntegrationFFlag,
    dppIndicatorFFlag,
    copyPasteIconFFlag,
    indirectFlexLocalOnlyFFlag,
    removeDPPoptionFFlag,
    dwosIndirectFFlag,
    bestBuyPricingDetailsApiUiIntegrationFFlag,
    bestBuyISPUEnableLocalOrderFFlag,
  ] = getAssistedCradlePropertyV2([
    'enableEUPDualNum',
    'dropshipProdcode5',
    'enableDropship',
    'bestBuyIntegrationFFlag',
    'dppIndicatorFFlag',
    'copyPasteIconFFlag',
    'indirectFlexLocalOnlyFFlag',
    'removeDPPoptionFFlag',
    'dwosIndirectFFlag',
    'bestBuyPricingDetailsApiUiIntegrationFFlag',
    'bestBuyISPUEnableLocalOrderFFlag',
  ]);
  const deviceColorLabelPDPFFlag = /true/i.test(getAssistedCradlePropertyV2(['deviceColorLabelPDPFFlag'])?.[0]);

  const professionalInstallNotification = (devices) => 
    isVbgProfessionalInstall && devices?.isProfessionalInstallDevice;

  useEffect(() => {
    if (isIpad() && navigateBackToMaslowFFlag) {
      window.getisMaslowApp = (value) => {
        sessionStorage.setItem('isMaslowApp', value);
        setIsMaslowApp(value === 'TRUE' && navigateBackToMaslowFFlag);
      };
      executeShellFunction('SharedMemory', 'getData', 'window.getisMaslowApp', { key: 'isMaslowApp' });
    } else {
      const sessionValue = navigateBackToMaslowFFlag && sessionStorage.getItem('isMaslowApp') === 'TRUE';
      setIsMaslowApp(sessionValue);
    }
  }, [navigateBackToMaslowFFlag]);

  const showCopyPasteIcon = /true/i.test(copyPasteIconFFlag);
  const dispatch = useDispatch();
  // const showISPUToggle = (displayIspuToggle && !isBBYLocalOrder) || /true/i.test(bestBuyISPUEnableLocalOrderFFlag)
  
  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }

  const [InStockLabel, setInStockLabel] = useState('');
  const [numberShareDetails, setNumberShareDetails] = useState();
  const [showNumberShareModal, setShowNumberShareModal] = useState(false);
  const [isBackorder, setIsBackOrder] = useState(false);
  const [addToCartDisabled, setAddToCartDisabled] = useState(false);
  const [isPaymentOptionVisible, setIsPaymentOptionVisible] = useState(false);
  const [ispuFromCart, setIspufromCart] = useState(false);
  const [isBuyOutToggleOn, setIsBuyOutToggleOn] = useState(false);
  const [showBuyoutDetails, setShowBuyoutDetails] = useState(false);
  const [showDeclinePopUp, setShowDeclinePopUp] = useState(false);
  const [monthlyPaymentModal, setMonthlyPaymentModal] = useState(false);
  const [selectedPaymentType, setSelectedPaymentType] = useState(null);
  const [disableUpdateButton, setDisableUpdateButton] = useState(false);
  const { activeSubAccountId = '', orderDetails = {} } = getProp(cartDetails, 'cart') || {};
  const [customerConsentCaptured, setCustomerConsentCaptured] = useState(
    orderDetails?.customerConsent ? orderDetails?.customerConsent : 'N',
  );
  const [getInventoryDetails, InventoryDetailsResult] = useLazyGetInventoryDetailsQuery();
  const [getEligibleNumberShareLis, eligibleNumberShareLisResult] = useLazyEligibleNumberShareListQuery();
  const [callNumberSharePairUnpair] = useLazyNumberSharePairUnpairQuery();

  const [disableShipIttoogle, setDisableShipIttoogle] = useState(false);
  const [priceValue, setPriceValue] = useState({});
  const [displayPaymentRadio, setDisplayPaymentRadio] = useState(false);
  const [enableBYODbtn, setEnableBYODbtn] = useState(false);
  const [carrierLockDisableButton, setCarrierLockDisableButton] = useState(false);
  const defaultSkuUpdated = details?.defaultSKUObj;
  const [selectedSWBand, setSelectedSWBand] = useState(defaultSkuUpdated?.skuFilters?.band ?? '');
  const [selectedSWBandSize, setSelectedSWBandSize] = useState(defaultSkuUpdated?.sorId ?? '');
  const [selectedBYODCss, setSelectedBYODCss] = useState('');
  const [isDpInVisible, setIsInDpVisible] = useState(false);
  const [isPdpUpdated, setIsPdpUpdated] = useState(false);
  const [pairedMtn, setPairedMtn] = useState('');
  const [isSimultaneousUpgrade, setIsSimultaneousUpgrade] = useState(false);
  const [ispuToggleValEdited, setIspuToggleValEdited] = useState(false);
  const [isSecNumValidation, setIsSecNumValidation] = useState(getQueryParamByName('scanFromLanding') || false);
  const [secondNumberWarningModal, setSecondNumberWarningModal] = useState(false);
  const [dpEligibilityCallFailure, setDpEligibilityCallFailure] = useState(false);
  const [previousIspuSim, setPreviousIspuSim] = useState('');
  const [clickedCopyColorNames, setClickedCopyColorNames] = useState(false);
  console.log(showDeclinePopUp, selectedPaymentType);
  const isByodUpdate = getQueryParamByName('isByodUpdate');
  const isProspectByodFlow = getQueryParamByName('prospectByodFlow');
  const isFromCPE = getQueryParamByName('isFromCPE');
  const iSscan = !!getQueryParamByName('iSscan');
  const isBYOD = !!(isByodUpdate || isFromCPE || isProspectByodFlow);
  const BtaElgible = !selectedSku?.isBillToAccount && 'Not BTA eligible';
  const cartLineInfo = cartDetails?.cart?.lineDetails?.lineInfo || [];
  const customerType = cartDetails?.cart?.orderDetails?.customerType;
  const filteredLineFromCart =
    cartLineInfo?.find((line) => line?.mobileNumber === activeMtn || line?.lineNumber === activeMtn) || {};
  const deviceFromFilteredCartLine = filteredLineFromCart?.itemsInfo?.[0]?.cartItems?.cartItem?.find(
    (item) => item?.cartItemType === 'DEVICE',
  );
  const cartItemsArray = filteredLineFromCart?.itemsInfo?.[0]?.cartItems?.cartItem;
   // Due to flag is not coming in API, taking it from APP PROPERTIES
  // const earlyUpgradeOrderVVCFFlag = GetDetailsResult?.data?.featureFlags?.earlyUpgradeOrderVVCFFlag;
  const earlyUpgradeOrderVVCFFlag = JSON.parse(sessionStorage.getItem("APP_PROPERTIES"))?.earlyUpgradeOrderVVCFFlag === "TRUE";

  const isDPEdgeUp =
    earlyUpgradeOrderVVCFFlag &&
    cartItemsArray?.some(
      (item) => (item?.cartItemType === 'DEVICE' || item?.cartItemType === 'SOFT_SKU') && item?.itemCode === 'EDGERL',
    );

  const isDFOEdgeUp =
    earlyUpgradeOrderVVCFFlag &&
    cartItemsArray?.some(
      (item) =>
        (item?.cartItemType === 'DEVICE' || item?.cartItemType === 'SOFT_SKU') && item?.itemCode === 'EDGEUPDFO',
    );

  // getting sim info from filteredlinefromcart
  const simFromFilteredCartLine = filteredLineFromCart?.itemsInfo?.[0]?.cartItems?.cartItem?.find(
    (item) => item?.cartItemType === 'SIM',
  );
  const isEditAndView = /true/i.test(getQueryParamByName('isEditAndView'));
  const deviceFromCart = !!getQueryParamByName('deviceFromCart');
  const deviceSKUPdpEdit = getQueryParamByName('deviceSKU');
  const deviceFromCartPdpEdit = Boolean(getQueryParamByName('deviceFromCart'));
  const [getReasonCodeResult, upgradeReasonCodeResponse] = useLazyGetRetrieveURCodeQuery();
  const [getDpEligibility, dpEligibilityResult] = useLazyGetDevicePricingEligibilityQuery();
  const [getBbyPricingDetails, bbyPricingDetailsResult] = useLazyGetBestBuyInventoryQuery();
  const [getRetrievedppRequestBody, RetrievedppResult] = useLazyRetrievedppQuery();
  const isIndirect = customerProfileDetails?.commonInfo?.isIndirect || false;
  const localOnlyLocation =
    (indirectFlexLocalOnlyFFlag === 'TRUE' &&
      isIndirect &&
      customerProfileDetails?.commonInfo?.disableDfillRadioButton) ||
    false;
  let displayIndirectSku =  (((deviceFromCart && deviceFromFilteredCartLine?.depletionType === 'L') || iSscan) && isIndirect) || false;    
  if(editDeviceIndirectFFlag){ 
    displayIndirectSku = false
  }

  const showPrice = productDetails?.commonInfo?.showPrice || false;

  useEffect(() => {
    if ((props.buyOutAccepted || props?.buyOutDetail) && props?.PdpBuyoutToggle) {
      setIsBuyOutToggleOn(true);
    }
    const appPropertiesFromSessionStorage = sessionStorage.getItem('APP_PROPERTIES');
    
    if (typeof appPropertiesFromSessionStorage === 'string') {
      setIsAALActivateLaterFFlag( JSON.parse(appPropertiesFromSessionStorage)?.vbgNSAAALActivateLaterFFlag === 'TRUE');
      }
  }, []);

  /* istanbul ignore next */
  useEffect(() => {  
    if (
      InventoryDetailsResult.status === 'fulfilled' &&
      !isEmpty(InventoryDetailsResult.data?.data?.deviceSku?.inventoryDetails)
    ) {
      setSelectedSku((prevState) => ({
        ...prevState,
        inventoryDetails: InventoryDetailsResult.data.data.deviceSku.inventoryDetails,
      }));
    }
  }, [InventoryDetailsResult]);

  const { isNumberShareMandatory, isNumberShareCapable } = details;
  const isPreOwnedDevice =
    !!(groupPreOwnedConditionSkus?.length > 0) &&
    selectedSku &&
    selectedSku.deviceConditionDisplayName &&
    selectedSku.deviceConditionDisplayName !== '' &&
    props.cpoConditions &&
    props.cpoConditions.length > 0 &&
    props.cpoConditions.includes(
      selectedSku && selectedSku.deviceConditionDisplayName && selectedSku.deviceConditionDisplayName.trim(),
    );
  console.log('==== selectedPaymentType showDeclinePopUp', showDeclinePopUp, selectedPaymentType);
  useEffect(() => {
    /* istanbul ignore else */
    if (details) {
      const eSim = getQueryParamByName('eSim');
      const defaultSkuFromQueryParam = getQueryParamByName('defaultSku');
      const defaultSkuStringValue = isPreOwnedDevice
        ? getProp(details, 'defaultSKU') || ''
        : defaultSkuFromQueryParam || getProp(details, 'defaultSKU') || '';
      const defaultSkuObjValue = getProp(productDetails?.deviceSku, 'sorId');
      const defaultSku = defaultSkuStringValue !== '' ? defaultSkuStringValue : defaultSkuObjValue;
      const deviceFromCartPdpEditFlag = deviceFromCartPdpEdit ? deviceSKUPdpEdit : defaultSku;
      const defaultSkuDetails = details?.childSkus?.filter(
        (sku) => sku.sorId && sku.sorId === (eSim || isBYOD ? defaultSkuObjValue : deviceFromCartPdpEditFlag),
      );
      setSelectedSku(defaultSkuDetails?.length > 0 ? defaultSkuDetails?.[0] : details?.childSkus?.[0]);
      setPriceValue(selectedSku || defaultSkuDetails?.length > 0 ? defaultSkuDetails?.[0] : details?.childSkus?.[0]);
      setSelectedColor(
        defaultSkuDetails?.length > 0
          ? defaultSkuDetails?.[0]?.color?.displayName?.trim().replace(/[^a-zA-Z]/g, '')
          : details?.childSkus?.[0]?.color?.displayName?.trim().replace(/[^a-zA-Z]/g, ''),
      );
      setSelectedBYODCss(
        defaultSkuDetails?.length > 0
          ? defaultSkuDetails?.[0]?.color?.colorCssStyle
          : details?.childSkus?.[0]?.color?.colorCssStyle,
      );
      setSelectedSize(
        defaultSkuDetails?.length > 0 ? defaultSkuDetails?.[0]?.capacity : details?.childSkus?.[0]?.capacity,
      );
      callNumberShareInfo();
    }
  }, [details]);
  /* istanbul ignore next */

  useEffect(() => {
    const { defaultSku = '' } = details;
    callWFGbannerInfo(defaultSku, '', true);
  }, [details, upgradeReasonCodeResponse.isSuccess]);
  const newCustomerWithoutCredit = orderDetails?.quoteWithoutCredit;
  useEffect(() => {
    if (!isByodUpdate && !newCustomerWithoutCredit && !isBYOD) {
      callDpEligibilityBanner();
    }
  }, [dpEligibilityResult.isSuccess, selectedPaymentInfo?.contractType]);

  useEffect(() => {
    if (dpEligibilityResult.isSuccess) {
      const dpMessage = dpEligibilityResult?.data?.dpMessage?.message;
      const dpMessageType = dpEligibilityResult?.data?.dpMessage?.type;
      const inEligibleMessage = dpEligibilityResult?.data?.inEligibleMessage;
      let formattedDpMessage = dpMessage;
      let hideAPPMessage = true;
      if (
        customerType === 'N' &&
        (/tablets|smartwatch|connected smartwatch/i.test(
          GetDetailsResult?.data?.data?.deviceProduct?.childSkus?.[0]?.skuFilters?.deviceFilterType,
        ) ||
          /tablets|smartwatch|connected smartwatch/i.test(selectedSku?.skuFilters?.deviceFilterType)) &&
        dppIndicatorFFlag === 'TRUE'
      ) {
        hideAPPMessage = false;
      }
      if (inEligibleMessage) {
        formattedDpMessage += ` because ${inEligibleMessage}`;
      }
      // eslint-disable-next-line no-unused-expressions
      !dppIndicatorValue &&
        dpMessage &&
        hideAPPMessage &&
        dispatch(appMessageActions.addAppMessage(formattedDpMessage, dpMessageType, true));
      if (dpMessage === 'You are not eligible for Device Payment at this moment') {
        setIsInDpVisible(true);
        if(isVbgFlag) {
          SelectedContractType(
            selectedSku?.price?.[getPricingPriority(selectedSku?.price)]?.contractText,
            selectedSku?.price?.[getPricingPriority(selectedSku?.price)]?.originalPrice,
          )
        } else {
          const contractType = { contractType: 'MONTH_TO_MONTH' };
          setSelectedPaymentInfo(contractType);
        }
      }
    }
  }, [dpEligibilityResult.isSuccess]);

  useEffect(() => {
    if (dpEligibilityResult?.status === 'rejected') {
      setDpEligibilityCallFailure(true);
    }
  }, [dpEligibilityResult?.status]);

  useEffect(() => {
    if (!isEmpty(selectedSku)) {
      setDisplayPaymentRadio(true);
      const localInventory =
        getProp(selectedSku, 'inventoryDetails.localInventory') ||
        getProp(productDetails?.deviceSku, 'inventoryDetails.localInventory');
      const localInventoryisInstock =
        getProp(selectedSku, 'inventoryDetails.localInventory.isInStock') ||
        getProp(productDetails?.deviceSku, 'inventoryDetails.localInventory.isInStock');
      const localInventoryQty =
        getProp(selectedSku, 'inventoryDetails.localInventory.qtyAvailable') ||
        getProp(productDetails?.deviceSku, 'inventoryDetails.localInventory.qtyAvailable');

      const dFillInventoryInventory =
        getProp(selectedSku, 'inventoryDetails.dFillInventory') ||
        getProp(productDetails?.deviceSku, 'inventoryDetails.dFillInventory');
      const dFillInventoryisInstock =
        getProp(selectedSku, 'inventoryDetails.dFillInventory.isInStock') ||
        getProp(productDetails?.deviceSku, 'inventoryDetails.dFillInventory.isInStock');
      const dFillInventoryQty =
        getProp(selectedSku, 'inventoryDetails.dFillInventory.qtyAvailable') ||
        getProp(productDetails?.deviceSku, 'inventoryDetails.dFillInventory.qtyAvailable');
      const isBackOrder = getProp(selectedSku, 'inventoryDetails.dFillInventory.isBackorder');
      setIsBackOrder(isBackOrder);
      setAddToCartDisabled(false);
      if (!isBBYLocalOrder) {
        if (
          (!isEmpty(localInventory) && localInventoryisInstock && localInventoryQty > 0 && showShipitToggle) ||
          isLocalOrderForIndirect(props?.isFullFillment, isBackOrder, isPreOrder, iSscan)
        ) {
          setInStockLabel(BtaElgible);
          setIspuToggleOn(false);
          setDisableShipIttoogle(false);
          setIsShipItToggleOn(false);
        } else if (
          (!isEmpty(dFillInventoryInventory) && dFillInventoryisInstock && dFillInventoryQty > 0) ||
          isBackOrder ||
          isPreOrder ||
          isDfillOrderForIndirect(props?.isFullFillment, dFillInventoryQty)
        ) {
          setDisableShipIttoogle(isDisableShipIttoogle(isPreOrder));
          setIspuToggleOn(false);
          setIsShipItToggleOn(true);
          setInStockLabel(
            `Available to ship (Available Quantity) : ${dFillInventoryQty} ${BtaElgible ? ` / ${BtaElgible}` : ''}`,
          );
        } else if (!dFillInventoryisInstock || isBackOrder || isPreOrder) {
          setIsShipItToggleOn(true);
          setInStockLabel('Out of Stock');
        } else {
          setIsShipItToggleOn(true);
        }
        /* istanbul ignore next */
        if (isEditAndView && deviceFromFilteredCartLine && deviceFromFilteredCartLine?.depletionType) {
          let isShipItToggle;
          if (deviceFromFilteredCartLine?.depletionType === 'F' || isBackorder || isPreOrder) {
            isShipItToggle = true;
          } else if (deviceFromFilteredCartLine?.depletionType === 'L') {
            isShipItToggle = shipItToggleInventory(localInventoryQty) 
          }
          setIsShipItToggleOn(ispuToggleOn ? false : isShipItToggle);
        }
        setSelectedSWBand(selectedSku?.skuFilters?.band);
        console.log('skipping dfill and local inventory check for bestbuy');
      }
    }
    if (localOnlyLocation) {
      setDisableShipIttoogle(true);
    }
    handleVbgProfessionalInstall(isVbgProfessionalInstall, setIsShipItToggleOn, setDisableShipIttoogle);
  }, [selectedSku]);
  useEffect(() => {
    checkForSecondNumberUpgrade();
    const { defaultSKU = '', childSkus = [] } = details;
    const defaultSkuDetails = childSkus.filter((sku) => sku.sorId === defaultSKU);
    if (isPreOwnedDevice) {
      handlePreOwnedDeviceRadioChangeParent(defaultSkuDetails?.[0]?.deviceConditionDisplayName);
    }
  }, []);
  useEffect(() => { /* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */
    /* istanbul ignore else */
    if (!isEmpty(eligibleNumberShareLisResult.data)) {
      const response = eligibleNumberShareLisResult?.data?.payload;
      /* istanbul ignore else */
      if (response && response.numberShareEligibleDevices) {
        setNumberShareDetails({
          numberShareList: response.numberShareEligibleDevices,
          numberShareLoadable: false,
          accountPairedDevice: response.accountPairedDevice,
        });
        if (response.accountPairedDevice && response.accountPairedDevice.mtn)
          updateNumberShareValue(response.accountPairedDevice.mtn);

        const preSelectDetails =
          response.numberShareEligibleDevices &&
          response.numberShareEligibleDevices?.length > 0 &&
          response.numberShareEligibleDevices.filter((line) => line.preSelect && line.preSelect === true);
        const preSelectMTN =
          preSelectDetails && preSelectDetails?.length > 0 && preSelectDetails[0].mtn ? preSelectDetails[0].mtn : '';
        if (preSelectMTN !== '') updateNumberShareValue(preSelectMTN);

        /* By default numberShare toggle will be OFF, to enable it on load when numberShareMandatory is TRUE or there is already a pairing */
        if (
          details.isNumberShareMandatory ||
          numberShareValue !== '' ||
          preSelectMTN !== '' ||
          response?.accountPairedDevice?.mtn
        ) {
          /* istanbul ignore next */
          const acssMfeNumberShare = sessionStorage.getItem('acssMfeNumberShare');
          /* istanbul ignore next */
          if (scmDeviceEnable && enableSCMNumberShare && acssMfeNumberShare)  {   
            const parsedData = JSON.parse(acssMfeNumberShare);
            if (parsedData?.[activeMtn]?.numbersharePairingMode){
              updateNumberShare(parsedData?.[activeMtn]?.numbersharePairingMode === 'PAIR');
            } else {
              updateNumberShare(true);
            }
          } else {
            updateNumberShare(true);
          }
        }
      }
    }
  }, [eligibleNumberShareLisResult]);
  /* istanbul ignore next */
  useEffect(() => {
    if (isEditAndView && filteredLineFromCart?.ispuItem && !ispuToggleValEdited) {
      if (isEmpty(selectedStore)) {
        setIspufromCart(filteredLineFromCart?.ispuItem);
      }
      if (isBackorder || isPreOrder) {
        setIsShipItToggleOn(true);
      } else if (isShipItToggleOn && ispuFromCart) {
        setIsShipItToggleOn(false);
      }
      setDisableShipIttoogle(false);
    }
  }, [filteredLineFromCart?.ispuItem, ispuToggleOn, isShipItToggleOn]);

  useEffect(() => {
    if (dppIndicatorFFlag === 'TRUE' && SkuDetailsResult?.data?.data) {
      if (
        (customerType === 'N' || filteredLineFromCart?.lineActivityType === 'NSE') &&
        (/tablets|smartwatch|connected smartwatch/i.test(
          SkuDetailsResult?.data?.data?.deviceSku?.parentProducts?.[0]?.childSkus?.[0]?.skuFilters?.deviceFilterType,
        ) ||
          /tablets|smartwatch|connected smartwatch/i.test(selectedSku?.skuFilters?.deviceFilterType))
      ) {
        const requestBodyEndPoint = {
          data: {
            mtn: filteredLineFromCart?.mobileNumber,
          },
        };

        getRetrievedppRequestBody({ body: requestBodyEndPoint });
      }
    }
  }, [SkuDetailsResult]);
  useEffect(() => {
    if (dppIndicatorFFlag === 'TRUE' && GetDetailsResult?.data?.data) {
      if (
        (customerType === 'N' || filteredLineFromCart?.lineActivityType === 'NSE') &&
        /tablets|smartwatch|connected smartwatch/i.test(
          GetDetailsResult?.data?.data?.deviceProduct?.childSkus?.[0]?.skuFilters?.deviceFilterType,
        )
      ) {
        const requestBodyEndPoint = {
          data: {
            mtn: filteredLineFromCart?.mobileNumber,
          },
        };

        getRetrievedppRequestBody({ body: requestBodyEndPoint });
      }
    }
  }, [GetDetailsResult]);

  useEffect(() => {
    if (dppIndicatorFFlag === 'TRUE' && RetrievedppResult?.data?.data) {
      setDppIndicatorValue(RetrievedppResult?.data?.data?.dppIndicator);
      if (customerType === 'N' && RetrievedppResult?.data?.data?.dppIndicator) {
        SelectedContractType('Full Retail Price', selectedSku?.price?.fullRetailPrice?.originalPrice);
        dispatch(
          appMessageActions.addAppMessage(
            `Device Financing is not available for stand alone ${GetDetailsResult?.data?.data?.deviceProduct?.childSkus?.[0]?.skuFilters?.deviceFilterType}. To avail financing option add other device types to the cart`,
            'info',
            true,
            60000,
          ),
        );
      }
    }
  }, [RetrievedppResult]);
  const shipItToggleInventory = (localInventoryQty) => {
    const shipToggleFFlag = JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.shipToggleFFlag === 'TRUE';
    if (shipToggleFFlag) {
      if (!filteredLineFromCart?.lineActivityType?.includes('BYOD') && !filteredLineFromCart?.ispuItem && (localInventoryQty <= 0 || !localInventoryQty)) {
        return true;
      } 
        setDisableShipIttoogle(false);
        return false;
    }
    return false
}
  // console.log({ selectedSWBand, selectedSWBandSize });
  /* istanbul ignore next */
  const checkForSecondNumberUpgrade = () => {
    const intentType = secondNumData && secondNumData?.length > 0 && !isNewLine && 'EUP';
    const isPrimaryNumber = secondNumData?.[0]?.primaryNumber || false;
    const pairedMtnVal =
      secondNumData?.[0]?.equipmentInfos?.[0].deviceInfo?.pairedDeviceDetails?.[0]?.pairedImeiMtn || '';
    const pairedMtnDetails = secondNumData?.filter((mtnList) => mtnList.mtn === pairedMtnVal);
    const hasSecondNumPlan = pairedMtnDetails?.[0]?.pricePlanInfo?.planId === '70995';
    /* istanbul ignore next */
    const isSimultaneousUpgradeVal =
      isPrimaryNumber && intentType === 'EUP' && hasSecondNumPlan && enableEUPDualNum === 'TRUE';
    setPairedMtn(pairedMtnVal);
    setIsSimultaneousUpgrade(isSimultaneousUpgradeVal);
  };
  const chooseSWBand = (e) => {
    const band = e.target.value;
    setSelectedSWBand(band);
    let filteredSku = details?.childSkus?.filter(
      (sku) =>
        sku?.skuFilters?.band === band &&
        sku?.sorId === selectedSWBandSize &&
        (sku?.color && sku?.color?.displayName?.trim().replace(/[^a-zA-Z]/g, '')) === selectedColor,
    )[0];
    /* istanbul ignore next */
    if (!filteredSku) {
      const skus = details?.childSkus;
      const colorObj = skus.filter(
        (sku) =>
          sku?.skuFilters?.band === band &&
          (sku?.color && sku?.color?.displayName?.trim().replace(/[^a-zA-Z]/g, '')) === selectedColor,
      )[0];
      filteredSku = colorObj;
    }
    setSelectedSku(filteredSku);
    doCallGetSkuDetails(filteredSku, 'size');
  };

  const chooseSWBandSize = (e) => {
    const bandSize = e.target.value; // we are taking sorid as bandSize
    console.log(bandSize, 'bandSize');
    setSelectedSWBandSize(bandSize);
    /* istanbul ignore next */
    const filteredSku = details?.childSkus.filter(
      (sku) =>
        sku?.skuFilters?.band === selectedSWBand &&
        sku?.sorId === bandSize &&
        (sku?.color && sku?.color?.displayName?.trim().replace(/[^a-zA-Z]/g, '')) === selectedColor,
    )[0];
    setSelectedSku(filteredSku);
    doCallGetSkuDetails(filteredSku, 'size');
  };

  const displayName = selectedSku?.skuDisplayName;
  const imageUrlMap = selectedSku && selectedSku.imageUrlMap ? selectedSku.imageUrlMap : {};
  const skusByColor = groupByColors(details.childSkus);

  const devices = {
    id: 'gw.d1',
    devicename: displayName,
    // monthlyprice: selectedSku?.price?.devicePaymentPrice,
    // total: `$${selectedSku?.price?.fullRetailPrice?.originalPrice}`,
    logo: imageUrlMap?.largeImage || '',
    mediumImage: imageUrlMap?.mediumImage,
    upgrade: true,
    upgrademsg: 'Upgrade after 50%',
    sku: selectedSku?.sorId,
    color: selectedSku?.color?.displayName,
    colorvalue: selectedSku?.color?.displayName?.trim().replace(/[^a-zA-Z]/g, ''),
    isProfessionalInstallDevice: isVbgProfessionalInstall ? selectedSku?.isProfessionalInstallDevice : false
  };
  /* istanbul ignore next */
  const colorOptionData = (skus, selectedSizeVal, skuId, ispuToggleOnVal) => {
    const data = [];
    skus?.map((sku) => {
      let filteredsize = [];
      if (selectedSizeVal) {
        filteredsize = sku && !isEmpty(sku.skus) && sku.skus?.filter((item) => item.capacity === selectedSizeVal);
      } else if (skuId) {
        filteredsize = sku && !isEmpty(sku.skus) && sku.skus?.filter((item) => item.skuId === skuId);
        if (filteredsize.length === 0) {
          filteredsize.push(sku?.skus[0]);
        }
      }
      const localInventoryInStock = getProp(filteredsize[0], 'inventoryDetails.localInventory.isInStock');
      const localInventoryQtyAvailable = getProp(filteredsize[0], 'inventoryDetails.localInventory.qtyAvailable');
      const deviceSkuLocalInventoryInStock = getProp(
        productDetails?.deviceSku,
        'inventoryDetails.localInventory.isInStock',
      );
      const deviceSkuLocalInventoryQtyAvailable = getProp(
        productDetails?.deviceSku,
        'inventoryDetails.localInventory.qtyAvailable',
      );

      /* istanbul ignore next */
      let isAvailable =
        localInventoryInStock &&
        localInventoryInStock !== false &&
        localInventoryInStock !== undefined &&
        localInventoryInStock !== '' &&
        localInventoryInStock !== null
          ? getProp(filteredsize[0], 'inventoryDetails.localInventory.isInStock')
          : getProp(filteredsize[0], 'inventoryDetails.dFillInventory.isInStock');
      isAvailable =
        isAvailable ||
        deviceSkuLocalInventoryInStock ||
        (getProp(productDetails?.deviceSku, 'inventoryDetails.dFillInventory.isInStock')
          ? getProp(productDetails?.deviceSku, 'inventoryDetails.dFillInventory.isInStock')
          : false);

      /* istanbul ignore next */
      let qtyAvailable =
        localInventoryQtyAvailable &&
        localInventoryQtyAvailable !== false &&
        localInventoryQtyAvailable !== undefined &&
        localInventoryQtyAvailable !== '' &&
        localInventoryQtyAvailable !== null &&
        localInventoryQtyAvailable !== 0
          ? getProp(filteredsize[0], 'inventoryDetails.localInventory.qtyAvailable')
          : getProp(filteredsize[0], 'inventoryDetails.dFillInventory.qtyAvailable');

      qtyAvailable =
        qtyAvailable ||
        deviceSkuLocalInventoryQtyAvailable ||
        (getProp(productDetails?.deviceSku, 'inventoryDetails.dFillInventory.qtyAvailable')
          ? getProp(productDetails?.deviceSku, 'inventoryDetails.dFillInventory.qtyAvailable')
          : false);

      const isPreOrderVal =
        getProp(filteredsize[0], 'inventoryDetails.dFillInventory.isPreOrder') ||
        getProp(productDetails?.deviceSku, 'inventoryDetails.dFillInventory.isPreOrder') ||
        false;
      const isBackorderVal =
        getProp(filteredsize[0], 'inventoryDetails.dFillInventory.isBackorder') ||
        getProp(productDetails?.deviceSku, 'inventoryDetails.dFillInventory.isBackorder') ||
        false;

      return (isAvailable === true && qtyAvailable > 0) || ispuToggleOnVal || isPreOrderVal || isBackorderVal
        ? data.push(sku?.color)
        : data.push(sku.color && sku.color.concat(' - out of stock'));
    });
    return data;
  };
  const defaultColorOption = {
    label: (isBYOD || displayIndirectSku) && selectedColor,
    name: 'group',
    value: (isBYOD || displayIndirectSku) && selectedColor,
    color: (isBYOD || displayIndirectSku) && selectedColor,
    fillColor: (isBYOD || displayIndirectSku) && [`${selectedBYODCss}`],
    'data-track': `Productdetail_color_${selectedColor}`,
  };

  // const copyColorNames = isBYOD
  //   ? defaultColorOption?.label
  //   : colorOptionData(skusByColor, selectedSize, selectedSku?.skuId, ispuToggleOn);

  const formattedColorNames = isBYOD
    ? defaultColorOption?.label
    : colorOptionData(skusByColor, selectedSize, selectedSku?.skuId, ispuToggleOn).join('\n');

  const getLabelName = (sku) => {
    if(deviceColorLabelPDPFFlag) {
      return `${sku.color.trim()}`;
    }

    return `${sku.color.trim().replace(/[^a-zA-Z ]/g, '')}`;
  }

  const deviceColorOptions = skusByColor?.map((sku) => ({
    name: 'group',
    label: getLabelName(sku),
    value: sku.color.trim().replace(/[^a-zA-Z]/g, ''),
    color: sku.color.trim().replace(/[^a-zA-Z]/g, ''),
    fillColor: [`${sku.colorCssStyle}`],
    outOfStock: false,
    'data-track': `Productdetail_color_${sku.color.trim().replace(/[^a-zA-Z]/g, '')}`,
  }));
  /* istanbul ignore next */
  const displayColorLink = () => {
    if (isBYOD && defaultColorOption?.label !== undefined && defaultColorOption?.label !== null) {
      return true;
    }
    if (!isBYOD && !isEmpty(deviceColorOptions) && !isEmpty(devices?.colorvalue)) {
      return true;
    }
    return false;
  };

  const radioboxValueSuffix = (paymentInfo) => isVbg() ? `:${paymentInfo?.contractType}:${paymentInfo?.term || ''}` : '';
  const radioValueSuffix = (suffix) => isVbg() ? `:${suffix}` : '';

  const deviceRetailFullPrice = {
    id: `${selectedSku?.price?.devicePaymentPrice?.length}`,
    text: `$${selectedSku?.price?.fullRetailPrice?.originalPrice}`,
    value: `$${selectedSku?.price?.fullRetailPrice?.originalPrice}${radioValueSuffix('MONTH_TO_MONTH:')}`,
    subtext: `${selectedSku?.price?.fullRetailPrice?.contractText}`,
    name: `${selectedSku?.price?.fullRetailPrice?.contractText}`,
    'data-track': 'Productdetail_FullRetailPrice',
  };

  const isVVCFlowEnabled =
    !!/true/i.test(JSON.parse(sessionStorage.getItem('assistedFlags'))?.isVVCFlowEnabled) ||
    !!/true/i.test(JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.isVVCFlowEnabled);

  const isNotHavingPendingCard = () => {
    const applicationStatus = props.isaacPromo?.proposition?.applicationStatus;
    return !(applicationStatus === 'Application-Pending');
  };

  const [BByPricing, setBByPricing] = useState(null);
  const [preservedBByPricing, setPreservedBByPricing] = useState(null); // Preserve pricing when ISPU stores response comes
  const [devicePricingEnabled, setDevicePricingEnabled] = useState(false);
  const [upcAndDeviceIdCheckEnabled, setUpcAndDeviceIdCheckEnabled] = useState(false);
  const [isDevicePricingApiCallEnable, setIsDevicePricingApiCallEnable] = useState(true);
  const [isGetInventoryAPICalled, setIsGetInventoryAPICalled] = useState(true);
  const [hasBByPricingError, setHasBByPricingError] = useState(false);

  const [UpcCodeData, setUpcCode ]= useState(props?.upcCodeFromPdpScan || getQueryParamByName('upcCodeValue'));
  // const postalCode =  sessionStorage.getItem('locationZipCode') || '';

  const handleBestBuyPricingDetails = () => {
    if (
      bestBuyIntegrationFFlag === 'TRUE' &&
      isBBYLocalOrder &&
      !upcAndDeviceIdCheckEnabled &&
      isDevicePricingApiCallEnable &&
      UpcCodeData?.length === 12
    ) {
      setDevicePricingEnabled(true);
      setBbPaymentOptionsSelected(true);
      setIsDevicePricingApiCallEnable(false);
      setIsGetInventoryAPICalled(true);
      // Clear old BByPricing and error state before making new API call
      setBByPricing(null);
      setHasBByPricingError(false);
      const StoreIdFormat = skuRealAgentCode?.padStart(4, '0');
      const userID = sessionStorage.getItem('userId') || '';
     const apiPostalCode =
        sessionStorage.getItem('ispuUpdatedZipCode') || sessionStorage.getItem('locationZipCode') || '';

      // Clear ISPU updated zipCode BEFORE API call to prevent re-triggering
      if (sessionStorage.getItem('ispuUpdatedZipCode')) {
        sessionStorage.removeItem('ispuUpdatedZipCode');
      }
      const requestBody = {
        upcCode: UpcCodeData,
        locationCode: props?.lcLocationCode || '',
        postalCode: apiPostalCode,
        storeId: StoreIdFormat,
        sourceSystemName: 'Omni',
        carrierCode: 'VEZ',
        userId: userID,
        fulfillmentType: showDeviceModal && bestBuyISPUEnableLocalOrderFFlag === 'TRUE' ? 'storePickup':'inStock',
        skipPricingDetail: showDeviceModal && bestBuyISPUEnableLocalOrderFFlag === 'TRUE',
        devices: [
          {
            upc: UpcCodeData,
          },
        ],
      };
      if (bestBuyPricingDetailsApiUiIntegrationFFlag === 'TRUE') {
        getBbyPricingDetails({
          body: requestBody,
          spinner: false,
        });
      } else {
        getBestBuyPricingDetails(setBByPricing, skuRealAgentCode, UpcCodeData);
      }
    }
  };
  useEffect(() => {
    handleBestBuyPricingDetails();
  }, [isBBYLocalOrder, UpcCodeData, upcAndDeviceIdCheckEnabled, isDevicePricingApiCallEnable, bbyPricingDetailsResult]);
  
  useEffect(() => {
    const bbyPricingDetails = bbyPricingDetailsResult?.data || bbyPricingDetailsResult?.error?.data;
    if (
      bbyPricingDetails &&
      bestBuyPricingDetailsApiUiIntegrationFFlag === 'TRUE' &&
      isBBYLocalOrder &&
      isGetInventoryAPICalled &&
      bbyPricingDetailsResult?.originalArgs?.body?.upcCode === UpcCodeData &&
      !bbyPricingDetailsResult?.isFetching &&
      bbyPricingDetailsResult?.status !== 'pending'
    ) {
      console.log('bbyPricingDetailsResult**', bbyPricingDetailsResult);
      setIsGetInventoryAPICalled(false);
      const apiPricing = bbyPricingDetails?.devicePricingDetails;
      /* istanbul ignore next */
      const targetError = bbyPricingDetails?.errors?.find(err => err.id === "00281");
      const errMsg = targetError?.message;
      const errorIdString = targetError?.id;
      // const hasMultipleInStock = bbyPricingDetails?.availability?.some((item) => item.quantity > 1);
      // if (apiPricing && Object.keys(apiPricing).length > 0 && hasMultipleInStock) {
      /* istanbul ignore next */
      if (apiPricing && Object.keys(apiPricing).length > 0) {
        // Store pricing in both states - preserved one never gets overwritten
        setPreservedBByPricing(apiPricing);
        setBByPricing(apiPricing);
        setHasBByPricingError(false);
      } 
      else if (bbyPricingDetails?.stores) {
        // ISPU stores response - use preserved pricing for BByPricing state
        console.log('ISPU stores response received, using preserved BByPricing');
        if (preservedBByPricing) {
          setBByPricing(preservedBByPricing);
        }
      }
      else {
        // Clear BByPricing when there's no valid pricing data
        setBByPricing(null);
        setHasBByPricingError(true);
        if (errorIdString === "00281") {
          dispatch(appMessageActions.clearAppMessages());
          dispatch(
            appMessageActions.addAppMessage(
              errMsg,
              'warning',
              true,
              true,
            ),
          );
        } else if (!isEmpty(bbyPricingDetails?.errors)) {
          const errorMessage = bbyPricingDetails?.errors?.find((part) => !isEmpty(part?.message));
          dispatch(appMessageActions.clearAppMessages())
          dispatch(
            appMessageActions.addAppMessage(
              errorMessage?.message || 'Something went wrong, kindly try again.',
              'error',
              true,
              true,
            ),
          );
        }
      }
    }
  }, [bbyPricingDetailsResult, isBBYLocalOrder, isGetInventoryAPICalled]);

  const displayPaymentOptions = () => {
    let paymentOptions = [];
    const isAddEdgeUpSuccess = filteredLineFromCart?.edgeUpDetail;

    /* ******** 
      Code for Best buy Pricing start
    ****** */
    console.log(
      'BBPricingSku',
      BByPricing,
      computeDPPriceResult,
      'devicePayment',
      selectedPaymentInfo,
      bbComputeDPPriceResult,
      dpEligibilityResult,
      bbyPricingDetailsResult,
    );

    if (bestBuyIntegrationFFlag === 'TRUE' && BByPricing && Object.keys(BByPricing).length > 0) {
      const inEligibleDPMessage = dpEligibilityResult?.data?.inEligibleMessage;
      // if (!BByPricing?.priceInfo && BByPricing?.messages?.length > 0) {
      //   // When no priceInfo exists but messages are present, dispatch the message.
      //   dispatch(appMessageActions.clearAppMessages());
      //   dispatch(appMessageActions.addAppMessage(BByPricing?.messages?.[0]?.messageDescription));
      // }
      const upgradeFinanced = BByPricing?.priceInfo?.find(
        (item) => item.activationType === 'upgrade' && item.purchaseType === 'FINANCED' && item.contractTerm === 36,
      );
      const upgradeFullSRP = BByPricing?.priceInfo?.find(
        (item) => item.activationType === 'upgrade' && item.purchaseType === 'FULL_SRP',
      );
      const newFinanced = BByPricing?.priceInfo?.find(
        (item) => item.activationType === 'new' && item.purchaseType === 'FINANCED' && item.contractTerm === 36,
      );
      const newFullSRP = BByPricing?.priceInfo?.find(
        (item) => item.activationType === 'new' && item.purchaseType === 'FULL_SRP',
      );
      const pricingDetails = {
        upgrade: {
          financed: {
            monthlyPrice: upgradeFinanced?.currentPrice,
            contractTerm: upgradeFinanced?.contractTerm,
            priceId: upgradeFinanced?.priceId,
            taxBasis: upgradeFinanced?.taxBasis,
            bbyDownPayment: upgradeFinanced?.bbyDownPayment,
            regularPrice: upgradeFinanced?.regularPrice,
            currentPrice: upgradeFinanced?.currentPrice,
            downPaymentAmount: upgradeFinanced?.downPaymentAmount,
          },
          fullSRP: {
            price: upgradeFullSRP?.currentPrice,
            contractTerm: upgradeFullSRP?.contractTerm,
            priceId: upgradeFullSRP?.priceId,
            taxBasis: upgradeFullSRP?.taxBasis,
            bbyDownPayment: upgradeFullSRP?.bbyDownPayment,
            regularPrice: upgradeFullSRP?.regularPrice,
            currentPrice: upgradeFullSRP?.currentPrice,
            downPaymentAmount: upgradeFullSRP?.downPaymentAmount,
          },
        },
        new: {
          financed: {
            monthlyPrice: newFinanced?.currentPrice,
            contractTerm: newFinanced?.contractTerm,
            priceId: newFinanced?.priceId,
            taxBasis: newFinanced?.taxBasis,
            bbyDownPayment: newFinanced?.bbyDownPayment,
            regularPrice: newFinanced?.regularPrice,
            currentPrice: newFinanced?.currentPrice,
            downPaymentAmount: newFinanced?.downPaymentAmount,
          },
          fullSRP: {
            price: newFullSRP?.currentPrice,
            contractTerm: newFullSRP?.contractTerm,
            priceId: newFullSRP?.priceId,
            taxBasis: newFullSRP?.taxBasis,
            bbyDownPayment: newFullSRP?.bbyDownPayment,
            regularPrice: newFullSRP?.regularPrice,
            currentPrice: newFullSRP?.currentPrice,
            downPaymentAmount: newFullSRP?.downPaymentAmount,
          },
        },
      };
      const activationType = !isNewLine ? 'upgrade' : 'new';
      const paymentTypes = ['financed', 'fullSRP'];

      // paymentTypes.forEach((paymentType) => {
      //   const BBYdetails = pricingDetails[activationType][paymentType];
      //   if (BBYdetails.monthlyPrice || BBYdetails.price) {
      //     const isFinanced = paymentType === 'financed';
      //     const capitalizedType = activationType.charAt(0).toUpperCase() + activationType.slice(1);
      //     sendFullRetailPrice(BBYdetails.price);
      //     sendPriceId(BBYdetails.priceId);
      //   //  setBbyPriceId(BBYdetails.priceId);
      //   const remainingMonthPrice = computeDPPriceResult?.data?.remainingMonthPrice;

      //     const option = {
      //       id: `BBY${capitalizedType}${paymentType.charAt(0).toUpperCase() + paymentType.slice(1)}`,
      //       text:`${isFinanced ? `${BBYdetails.monthlyPrice}/mo.` : BBYdetails.price}`,
      //       value: `${
      //         isFinanced
      //           ? `${BBYdetails.monthlyPrice}PriceID_${BBYdetails.priceId}`
      //           : `${BBYdetails.price}PriceID_${BBYdetails.priceId}`
      //       }`,
      //       subtext: isFinanced ? `${BBYdetails.contractTerm} Monthly Payments on Verizon bill` : `Full Retail Price`,
      //       name: `${BBYdetails.contractTerm}`,
      //       'data-track': `BBY_Productdetail_${capitalizedType}${isFinanced ? 'MonthlyPayments' : 'FullRetailPrice'}`,
      //     };
      //     paymentOptions.push(option);
      //   }

      // });

      // Handle monthlyPrice
      paymentTypes.forEach((paymentType) => {
        const BBYdetails = pricingDetails[activationType][paymentType];
        const remainingMonthPrice = bbComputeDPPriceResult?.data?.remainingMonthPrice;
        if (BBYdetails?.monthlyPrice && !inEligibleDPMessage) {
          paymentOptions.push({
            id: `DEVICE_PAYMENT-${paymentType}`,
            text:
              bbComputeDPPriceResult?.isSuccess &&
              remainingMonthPrice &&
              bbComputeDPPriceResult?.originalArgs?.body?.sorId === selectedSku?.sorId
                ? `${remainingMonthPrice}/mo`
                : `${BBYdetails.monthlyPrice}/mo`,
            value: `PriceID_${BBYdetails.priceId},TaxBasis_${BBYdetails.taxBasis},bbyDownPayment_${BBYdetails.bbyDownPayment},RegularPrice_${BBYdetails.regularPrice}, Currentprice_${BBYdetails.currentPrice},Downpaymentamount_${BBYdetails.downPaymentAmount}`,
            subtext: `${BBYdetails.contractTerm} Monthly Payments on Verizon bill`,
            name: `${BBYdetails.contractTerm}`,
            'data-track': `BBY_Productdetail_${
              activationType.charAt(0).toUpperCase() + activationType.slice(1)
            }MonthlyPayments`,
            term: `${BBYdetails.contractTerm}`,
            aprRate: '0.00',
          });
        }
      });

      // Handle price
      paymentTypes.forEach((paymentType) => {
        const BBYdetails = pricingDetails[activationType][paymentType];
        if (BBYdetails?.price) {
          // sendFullRetailPrice(BBYdetails?.price);
          paymentOptions.push({
            id: `PRICE_PAYMENT-${paymentType}`,
            text: `${BBYdetails.price}`,
            value: `PriceID_${BBYdetails.priceId},TaxBasis_${BBYdetails.taxBasis},bbyDownPayment_${BBYdetails.bbyDownPayment},RegularPrice_${BBYdetails.regularPrice}, Currentprice_${BBYdetails.currentPrice},Downpaymentamount_${BBYdetails.downPaymentAmount}`,
            subtext: 'Full Retail Price',
            name: ' ',
            'data-track': `BBY_Productdetail_${
              activationType.charAt(0).toUpperCase() + activationType.slice(1)
            }FullRetailPrice`,
          });
        }
      });

      // paymentOptions.push(BBYPaymentOptions);
      /* ****** BEst Buy Pricing end******* */
    } else {
      if (!isDpInVisible && !dppIndicatorValue && !isDFOEdgeUp && !props?.isDeclineBuyout) {
        const firstMonthInstallment =
          selectedSku?.price?.devicePaymentPrice?.[0]?.dpTermPrices?.loanOfferDetails?.firstMonthInstallment ||
          selectedSku?.price?.devicePaymentPrice?.[0]?.dpTermPrices?.remainingMonthPrice ||
          selectedSku?.price?.devicePaymentPrice?.[0]?.originalPrice;
        const aprValue =
          selectedSku?.price?.devicePaymentPrice?.[0]?.dpTermPrices?.loanOfferDetails?.annualPercentageRate;
        const remainingMonthPrice = computeDPPriceResult?.data?.remainingMonthPrice;
        paymentOptions =
          selectedSku?.price?.devicePaymentPrice?.map((sku, index) => ({
            id: `DEVICE_PAYMENT-${index}`,
            text: `$${
              isElvisAndNotVbg
                ? firstMonthInstallment
                : computeDPPriceResult?.isSuccess &&
                    remainingMonthPrice &&
                    computeDPPriceResult?.originalArgs?.body?.sorId === selectedSku?.sorId
                  ? remainingMonthPrice
                  : Number(filteredLineFromCart?.installmentInfo?.downPayment) > 0
                    ? filteredLineFromCart?.installmentInfo?.monthlyInstallment
                    : sku?.originalPrice
            }/mo`,
            value: `$${
              isElvisAndNotVbg
                ? firstMonthInstallment
                : computeDPPriceResult?.isSuccess &&
                    remainingMonthPrice &&
                    computeDPPriceResult?.originalArgs?.body?.sorId === selectedSku?.sorId
                  ? remainingMonthPrice
                  : Number(filteredLineFromCart?.installmentInfo?.downPayment) > 0
                    ? filteredLineFromCart?.installmentInfo?.monthlyInstallment
                    : sku?.originalPrice
            }${radioValueSuffix(`DEVICE_PAYMENT:${  sku?.contractDuration}`)}`,
            subtext: `${sku?.contractDuration} Monthly Payments on Verizon bill `,
            name: `${sku?.contractDuration}`,
            'data-track': 'Productdetail_MonthlyPayments',
            term: sku?.contractDuration,
            aprRate: elvisFFlag ? aprValue || '0.00' : '0.00',
          })) || [];
          paymentOptions = sortPaymentOptions({ paymentOptions, isVbgFlag });
      }

      if(isVbgFlag) {
        addDynamicContractPrices({ selectedSku, paymentOptions });
      }

      const vvcDeviceFinancingOfferPrice = selectedSku?.price?.vvcDeviceFinancingOfferPrice;
      const preOrder = selectedSku?.inventoryDetails?.dFillInventory?.isPreOrder;
      const backorder = selectedSku?.inventoryDetails?.dFillInventory?.isBackorder;
      const vvcDfoPOBOPDPFFlag = GetDetailsResult?.data?.featureFlags?.vvcDfoPOBOPDPFFlag;
      const assistedCustomerType = customerProfileDetails?.customer?.customerAttributes?.customerType;
      const vvcEligibleCustomerTypes = ['PE', 'ME', 'SL'];
      if (
        vvcDeviceFinancingOfferPrice &&
        Object.keys(vvcDeviceFinancingOfferPrice).length > 0 &&
        isVVCFlowEnabled &&
        customerProfileDetails?.customer?.channel !== 'OMNI-INDIRECT' &&
        isNotHavingPendingCard() &&
        orderDetails?.customerType !== 'N' &&
        !props.isCardExceedLimit &&
        (!(preOrder || backorder) || ((preOrder || backorder) && vvcDfoPOBOPDPFFlag)) &&
        vvcEligibleCustomerTypes.includes(assistedCustomerType) &&
        !isDPEdgeUp &&
        !props?.isDeclineBuyout
      ) {
        const vvcPaymentOption = {
          id: `vvcPaymentOption`,
          text: (
            <>
              ${vvcDeviceFinancingOfferPrice.originalMonthlyPrice}/mo <ExcludeSubText>(excludes tax)</ExcludeSubText>
            </>
          ),
          value: `$vvcPaymentOption-${vvcDeviceFinancingOfferPrice.originalMonthlyPrice}`,
          subtext: (
            <>
              {`${vvcDeviceFinancingOfferPrice.installmentTerm} `}
              Monthly Payments with <b>Verizon Visa Card</b>
              {selectedSku?.price?.fullRetailPrice?.allPromotions?.length > 0 &&
                selectedSku?.price?.fullRetailPrice?.allPromotions[0]?.discountMonthlyPrice !== undefined && (
                  <div className='promoMonthlyPrice' data-testid='promoVerbiage'>
                    Eligible for ${selectedSku?.price?.fullRetailPrice.allPromotions[0].discountMonthlyPrice}/mo Verizon
                    Bill Credit
                  </div>
                )}
            </>
          ),
          name: `${vvcDeviceFinancingOfferPrice?.installmentTerm}`,
          'data-track': `${vvcDeviceFinancingOfferPrice?.contractText}`,
          term: vvcDeviceFinancingOfferPrice?.installmentTerm,
          aprRate: '0.00',
        };
        paymentOptions.push(vvcPaymentOption);
      }
      if (selectedSku?.price?.fullRetailPrice && !isAddEdgeUpSuccess && !isDFOEdgeUp) {
        paymentOptions.push(deviceRetailFullPrice);
      }
    }
    return paymentOptions;
  };

  const radioboxGroupDefaultValue = () => isVbgFlag ? displayPaymentOptions()?.[0]?.value : `$${selectedPaymentInfo?.price}${radioboxValueSuffix(selectedPaymentInfo)}`;
  const byodPlusUltimateDPPFFlag = /true/i.test(getAssistedCradlePropertyV2(['byodPlusUltimateDPPFFlag'])?.[0]);

  console.log('BBYRetailFullPrice');
  const SelectedContractType = (contract, priceVal, fromDownPayment = false, paymentType = '', skipfilter = false) => {
    let contractType;
    let price = priceVal;
    const selectedPrice = price?.toString()?.replace('$', '');
    const selectedTerm = parseInt(contract, 10);
    let skuPrice;
    let term;
    if (!isVbgFlag) {
      skuPrice = selectedSku?.price?.devicePaymentPrice?.filter((pri) => pri?.originalPrice === parseFloat(selectedPrice) || skipfilter);
    } else {
      skuPrice = selectedSku?.price?.devicePaymentPrice?.find((pri) => pri?.contractDuration === selectedTerm);
    }

    if (typeof price === 'string') {
      price = parseFloat(price?.replace('$', ''));
    }

    if (!isVbgFlag) {
      term = !fromDownPayment ? skuPrice?.[0]?.contractDuration : contract;
    } else {
      term = !fromDownPayment ? skuPrice?.contractDuration : contract;
    }

    if (contract === 'Full Retail Price') {
      contractType = { contractType: 'MONTH_TO_MONTH', price };
    } else if ((contract?.toString())?.toLowerCase() === contractTextLabels.ONE_YEAR_PRICE.toLowerCase()) {
      contractType = { contractType: contractTermLabels.oneYearPrice, price };
    } else if ((contract?.toString())?.toLowerCase() === contractTextLabels.TWO_YEAR_PRICE.toLowerCase()) {
      contractType = { contractType: contractTermLabels.twoYearPrice, price };
    } else if ((contract?.toString())?.toLowerCase() === contractTextLabels.THREE_YEAR_PRICE.toLowerCase()) {
      contractType = { contractType: contractTermLabels.threeYearPrice, price };
    } else if ((contract?.toString())?.toLowerCase() === contractTextLabels.THIRTY_MONTH_PRICE.toLowerCase()) {
      contractType = { contractType: contractTermLabels.thirtyMonthPrice, price };
    } else {
      contractType = { contractType: 'DEVICE_PAYMENT', price, term, paymentType };
    }
    if (paymentType === '$vvcPaymentOption') {
      contractType = { contractType: 'MONTH_TO_MONTH', price, term: contract, paymentType };
    }
    setSelectedPaymentInfo(contractType);
  };
  useEffect(() => {
    if (computeDPPriceResult?.isSuccess) {
      SelectedContractType(
        computeDPPriceResult?.data?.dpTerm,
        `$${computeDPPriceResult?.data?.remainingMonthPrice}`,
        true,
      );
    }
  }, [computeDPPriceResult?.data?.downPayment, computeDPPriceResult?.data?.firstMonthPrice]);
  useEffect(() => {
    timeoutManager.scheduleTimeout(() => {
      if (selectedPaymentInfo?.price) {
        setDisplayPaymentRadio(true);
      }
    }, [100]);
    return () => {
      setDisplayPaymentRadio(false);
      timeoutManager.clearAllTimeouts();
    };
  }, [InventoryDetailsResult?.data?.data]);

  useEffect(() => {
    if (byodPlusUltimateDPPFFlag) {
      const options = displayPaymentOptions?.();
      if (options && options.length > 0) {
        const defaultValue = radioboxGroupDefaultValue?.();
        const dataTrack = (options.find(opt => String(opt?.value) === String(defaultValue)) || {})['data-track'];
        // Only set if not already set or not in options
        if ((!selectedPlanId || !options.some(opt => opt?.['data-track'] === selectedPlanId)) && dataTrack) {
          setSelectedPlanId(dataTrack);
        }
      }
    }
  }, [selectedSku, selectedPaymentInfo, BByPricing, dpEligibilityResult, selectedPlanId, byodPlusUltimateDPPFFlag]);


  const handlePaymentSelection = (e) => {
    const contract = e.target.name;
    let { value } = e.target;
    let paymentType = '';
    let priceID = '';
    let taxBasis = '';
    let bbyDownPayment = '';
    let currentPrice = '';
    let regularPrice = '';
    let downPaymentAmount = '';
    if (byodPlusUltimateDPPFFlag) {
      const getAllPaymentPlan = displayPaymentOptions()
      const dataTrack = (getAllPaymentPlan?.find(opt => String(opt.value) === String(e.target.value)) || {})['data-track'];
      setSelectedPlanId(dataTrack)
    }
    if (value.includes('-')) {
      [paymentType, value] = value.split('-');
    }
    if(isVbg() && value.includes(':')) {
      value = value.split(':')[0];
    }
    //   [value, priceID] = value.split('PriceID_');
    // }
    const values = value.split(',');

    if (values.length > 1) {
      const [priceIDPart, taxBasisPart, bbyDownPaymentPart, regularPricePart, currentPricePart, downPaymentAmountpart] =
        values;
      console.log(
        values,
        'values',
        priceIDPart,
        taxBasisPart,
        bbyDownPaymentPart,
        regularPricePart,
        currentPricePart,
        downPaymentAmountpart,
      );
      priceID = priceIDPart?.split('_')[1];
      taxBasis = taxBasisPart?.split('_')[1];
      bbyDownPayment = bbyDownPaymentPart?.split('_')[1];
      regularPrice = regularPricePart?.split('_')[1];
      currentPrice = currentPricePart?.split('_')[1];
      downPaymentAmount = downPaymentAmountpart?.split('_')[1];
      updatePaymentDetails({
        taxBasis,
        bbyDownPayment,
        regularPrice,
        currentPrice,
        downPaymentAmount,
      });
    }
    const Full_SRP = parseFloat(taxBasis - bbyDownPayment);
    sendFullRetailPrice(Full_SRP);
    console.log(priceID, taxBasis, bbyDownPayment, 'taxBasis', e.target, Full_SRP);
    setDevicePricingEnabled(false);
    setBbPaymentOptionsSelected(false);
    let contractType = contract;
    if (/FullRetailPrice/i.test(e.target?.dataset?.track) && isBBYLocalOrder && /true/i.test(bestBuyIntegrationFFlag)) {
      contractType = 'Full Retail Price';
      sendFullRetailPrice(currentPrice);
    }
    SelectedContractType(contractType, value, false, paymentType);
    setIsPdpUpdated(true);
    props?.setBbyPaymetOptionPriceId(priceID);
    if (isBBYLocalOrder && /true/i.test(bestBuyIntegrationFFlag)) {
      props?.setBbyContractTerm(contract);
      props?.setTaxBasisCharge(taxBasis);
    }
  };

  const handleDeviceProtection = () => {
    setShowDeviceProtectionModal(true);
    setTmpLinkClicked(true);
    const vzdl = window?.vzdl || {};
    if (vzdl?.event) vzdl.event.value = '';
    if (vzdl?.page) vzdl.page.detail = `Equipment Protection`;
    window.vzdl = vzdl;
    sendCustomEvent('openView', window?.vzdl);
  };

  useEffect(() => {
    const filterPreselect = protectionFeatures?.payload?.features?.filter(
      (feat) => feat?.sorId === protectionFeatures?.payload?.currentProtection?.sorId,
    );
    if (!isEmpty(filterPreselect)) {
      setSelectedProtectionFeature(filterPreselect[0]);
    }
  }, [protectionFeatures?.payload?.features]);
  /* istanbul ignore next */
  const chooseColor = (e) => {
    const selectedCapacity = selectedSize;
    const selectedColorValue = e.target.value;
    let filteredSku = details?.childSkus?.filter(
      (sku) =>
        sku.capacity === selectedCapacity &&
        sku?.color?.displayName.trim().replace(/[^a-zA-Z]/g, '') === selectedColorValue,
    )[0];
    if (!filteredSku) {
      const skus = skusByColor;
      const colorObj = skus.filter(
        (sku) =>
          sku.color &&
          sku.color.trim().replace(/[^a-zA-Z]/g, '') === selectedColorValue.trim().replace(/[^a-zA-Z]/g, ''),
      );
      filteredSku = colorObj && colorObj[0] && colorObj[0].skus && colorObj[0].skus[0];
      setSelectedSize(filteredSku?.capacity);
    }
    setSelectedColor(selectedColorValue);
    setSelectedSku(filteredSku);
    setStoreList(false);
    setIsPdpUpdated(true);
    setShowOnlyAvailableStores(true);
    if (filteredSku && !ispuToggleOn) {
      doCallGetSkuDetails(filteredSku, 'color');
    }
  };

  const chooseSize = (e) => {
    const selectedSkuCapacity = e.target.value;

    const selectedCapacity = selectedSkuCapacity; // .slice(10);

    const filteredSku = details.childSkus.filter(
      (sku) =>
        sku.capacity === selectedCapacity &&
        (sku.color && sku.color.displayName.trim().replace(/[^a-zA-Z]/g, '')) === selectedColor,
    )[0];

    setSelectedSku(filteredSku);
    setSelectedSize(selectedCapacity);
    setIsPdpUpdated(true);
    if (filteredSku && !ispuToggleOn) {
      doCallGetSkuDetails(filteredSku, 'size');
    }
  };

  // const { accountNo = '' } = customerProfileDetails.customer;
  const { productId = '' } = details;

 // Wrapper function that calls the extracted utility function with all dependencies
  const doCallGetSkuDetails = async (filteredSku, type) => {
    const dependencies = {
      activeMtn,
      productId,
      downPayment,
      filteredLineFromCart,
      getInventoryDetails,
      computeDPPriceBody,
      setUpcCode,
      setIsDevicePricingApiCallEnable,
    };

    await doCallGetSkuDetailsUtil(filteredSku, type, dependencies);
  };
  /* istanbul ignore next */
  const changeIspuToggleState = () => {
    if (ispuToggleOn || ispuFromCart) {
      setIspuToggleOn(false);
      setIspufromCart(false);
      setIspuToggleValEdited(true);
      if (getIspuSimEnable()) {
        setIspuSim(previousIspuSim);
      }
      if (!ispuToggleOn && ispuFromCart) {
        setIsShipItToggleOn(true);
      }
    } else {
      setShowDeviceModal(true);
      handleBestBuyPricingDetails();
      setIsDevicePricingApiCallEnable(true)
      if (getIspuSimEnable()) {
        setIspuSim(getQueryParamByName('ispuCompatibleSIM') || TELESALES_ISPU_SIM_SORID_CPE);
      }
    }
  };

  useEffect(() => {
    if (ispuToggleOn) {
      setIsShipItToggleOn(false);
      setDisableShipIttoogle(false);
    } else {
      const localInventoryStockAvailable = getProp(selectedSku, 'inventoryDetails.localInventory.isInStock') || false;
      if (!localInventoryStockAvailable) {
        setIsShipItToggleOn(true);
      }
    }
  }, [ispuToggleOn]);
  /* istanbul ignore next */
  const navigateToIspu = () => {
    setShowDeviceModal(true);
  };
  /* istanbul ignore next */
  const changeShipItToggleState = () => {
    const dFillInventoryInventory =
      getProp(selectedSku, 'inventoryDetails.dFillInventory') ||
      getProp(productDetails?.deviceSku, 'inventoryDetails.dFillInventory');
    const localInventory =
      getProp(selectedSku, 'inventoryDetails.localInventory') ||
      getProp(productDetails?.deviceSku, 'inventoryDetails.localInventory');
    const dFillInventoryQty =
      getProp(selectedSku, 'inventoryDetails.dFillInventory.qtyAvailable') ||
      getProp(productDetails?.deviceSku, 'inventoryDetails.dFillInventory.qtyAvailable');
    const localInventoryQty =
      getProp(selectedSku, 'inventoryDetails.localInventory.qtyAvailable') ||
      getProp(productDetails?.deviceSku, 'inventoryDetails.localInventory.qtyAvailable');
    const isBtaEligible = BtaElgible ? ` / ${BtaElgible}` : '';
    if (!isShipItToggleOn) {
      if (!isEmpty(dFillInventoryInventory) && dFillInventoryisInstock && dFillInventoryQty > 0) {
        setInStockLabel(`Available to ship (Available Quantity) : ${dFillInventoryQty} ${isBtaEligible}`);
        setIsShipItToggleOn(true);
      } else {
        setDisableShipIttoogle(false);
        let labelText = 'Out of Stock';
        if (!isFromCPE && !isByodUpdate && isBackorder) {
          labelText = <BackorderText shippingDate={shippingDate.date} />;
        }
        setInStockLabel(labelText);
      }
    } else if (BtaElgible) {
      setInStockLabel(BtaElgible);
    } else if (
      isShipItToggleOn &&
      ((!isEmpty(localInventory) && localInventoryQty > 0 && localInventoryisInstock) || isIndirect)
    ) {
      // for indirect no inventory check is required, as they don't have local inventory
      setIsShipItToggleOn(false);
      setInStockLabel('');
    }
    if (
      !isEmpty(dFillInventoryInventory) &&
      !isEmpty(localInventory) &&
      dFillInventoryQty > 0 &&
      localInventoryQty <= 0
    ) {
      setIsShipItToggleOn(true);
      return;
    }
    setIsShipItToggleOn(!isShipItToggleOn);
  };

  const activateLaterChange = () => {
    setIsActivateLater(!isActivateLater);
   

  };

 const onClickActivatedDate = (date) => {
  // Create a new array to avoid mutating state directly
  const updatedDates = activatedDateList.map(item => ({
    ...item,
    isSelected: item.date === date
  }));

  // Guard: ensure we have a valid selected date before proceeding
  const selected = updatedDates.find(item => item.isSelected);
  if (!selected?.date) {
    // eslint-disable-next-line no-console
    console.warn('No date selected in Activate Later');
    setActivateDateOptions(updatedDates);
    return;
  }

  // Normalize selected date to MM/DD/YYYY when flag is enabled; otherwise keep original
  const finalDate = vbgNsaYearFormatActLaterFFlag ? toFullYear(selected.date) : selected.date;
  setActivatedDate(finalDate);
  setActivateDateOptions(updatedDates);
};

    useEffect(() => {
      if (isActivateLater) {
        // Test seam: allow injecting a custom activated date list in test environment to exercise guard paths
        if (process.env.NODE_ENV === 'test' && Array.isArray(window?.__TEST_ACTIVATED_DATE_LIST__)) {
          setActivateDateOptions(window.__TEST_ACTIVATED_DATE_LIST__);
          return;
        }
        const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        const today = new Date();
        const activateDateList = Array.from({ length: 8 }, (_, i) => {
          const nextDate = new Date(today);
          nextDate.setDate(today.getDate() + i);
          const day = String(nextDate.getDate()).padStart(2, '0');
          const month = String(nextDate.getMonth() + 1).padStart(2, '0'); // Months are 0-based
          const year = String(nextDate.getFullYear()).slice(-2); // Get last two digits
          const date = `${month}/${day}/${year}`;
          const dayName = days[nextDate.getDay()];

          return {
            date,
            dayName,
            isSelected: false,
          };
        });
        setActivateDateOptions(activateDateList);
      }
  }, [isActivateLater]);


  useEffect(() => {
    if (isShipItToggleOn) {
      setIspuToggleOn(false);
    }
  }, [isShipItToggleOn]);

  const isVisible = (contractType) => {
    let visible = true;
    const existingContract = (deviceFromFilteredCartLine && deviceFromFilteredCartLine?.priceType) || '';
    if (props.isContractChange && props.isRfexFlow) {
      if (existingContract === 'MONTH_TO_MONTH' && contractType === 'DP') {
        visible = true;
      }
      visible = false;
    }
    return visible;
  };

  const channel = customerProfileDetails?.customer?.channel;
  const customerInfo = customerProfileDetails?.customer;
  const lineInfo = customerInfo?.billAccounts?.[0]?.mtns?.filter((line) => line.mtn === activeMtn);
  const isLocal = getQueryParamByName('isLocal');
  const isDWOS = getQueryParamByName('isDWOS');
  const isDwos = isDWOSAllowed(dwosIndirectFFlag, isDWOS);
  const isProductId = !!getQueryParamByName('productId');
  const fullFillment = props.cartDetails?.cart?.orderDetails?.orderDepletionType === 'F';
  const lineDeviceIdFromLanding =
    lineInfo?.[0]?.equipmentInfos?.[0]?.deviceInfo?.deviceId !== '' &&
    lineInfo?.[0]?.equipmentInfos?.[0]?.deviceInfo?.deviceId !== null &&
    lineInfo?.[0]?.equipmentInfos?.[0]?.deviceInfo?.deviceId !== undefined
      ? lineInfo?.[0]?.equipmentInfos?.[0]?.deviceInfo?.deviceId
      : '';
  const lineSimIdFromLanding =
    lineInfo?.[0]?.equipmentInfos?.[0]?.simInfo?.simId !== '' &&
    lineInfo?.[0]?.equipmentInfos?.[0]?.simInfo?.simId !== null &&
    lineInfo?.[0]?.equipmentInfos?.[0]?.simInfo?.simId !== undefined
      ? lineInfo?.[0]?.equipmentInfos?.[0]?.simInfo?.simId
      : '';
  const isNewLine = !!(
    cartLineInfo &&
    cartLineInfo.length > 0 &&
    cartLineInfo[0] &&
    (cartLineInfo[0].lineActivityType === 'AAL' ||
      cartLineInfo[0].lineActivityType?.includes('NSE') ||
      cartLineInfo[0].lineActivityType === 'BYOD')
  );

  const isActiveNewLine = !!(
    filteredLineFromCart &&
    (filteredLineFromCart?.lineActivityType === 'AAL' ||
      filteredLineFromCart?.lineActivityType?.includes('NSE') ||
      filteredLineFromCart?.lineActivityType === 'BYOD')
  );
  const isVideoAssistFlow = /true/.test(productDetails?.accountInfo?.isVideoAssistFlow);
  let compatibleSims = [];
  if (details?.compatibleSimSorIds) {
    compatibleSims = details?.compatibleSimSorIds;
  } else if (isByodUpdate || isFromCPE) {
    compatibleSims =
      !isEmpty(selectedSku?.parentProducts?.[0]?.compatibleSimSorIds) &&
      selectedSku?.parentProducts?.[0]?.compatibleSimSorIds
        ? selectedSku?.parentProducts?.[0]?.compatibleSimSorIds
        : [];
  } else compatibleSims = [];

  /* istanbul ignore next */
  if (window?.mfe?.scmDeviceMfeEnable && scmBulkDFillSimFixEnabled) {
      compatibleSims = getSCMFilteredDfillAndBulkSims(compatibleSims);
  }

  const isEsimFromParam = getQueryParamByName('eSim');
  const simId = getQueryParamByName('simId');
  let defaultSimId = lineInfo?.[0]?.equipmentInfos?.[0]?.simInfo?.simId || isEsimFromParam === 'true' ? simId : '';

  const lineSimSku = lineInfo?.[0]?.equipmentInfos?.[0]?.simInfo?.simId;
  if (scmDeviceEnable) {
    defaultSimId = simId || lineSimSku || '';
  }
  useEffect(() => {
    if (props?.PdpBuyoutToggle && !isBYOD && !deviceFromCart) {
      if (props?.buyOutAccepted) {
        setIsBuyOutToggleOn(true);
      }
    }
  }, [props.buyOutAccepted]);

  /* istanbul ignore next */
  const handleClick = () => {
    if (!scmDeviceEnable) {
      navigate(-1);
    } else {
      window?.mfe?.historyRef?.goBack();
    }
  };
  const headerData = {
    header: 'Device Specification',
    line: '',
    mdn: '',
    closeIcon: true,
    closeClickHandler: handleClick,
  };

  const toggleNumberShare = (value, sharedNumber = '') => { /* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */
    if (scmDeviceEnable && enableSCMNumberShare) {
        const trunkMtn = sharedNumber || numberShareValue || sharedMtnValue;
        if (!sharedNumber && !trunkMtn) {
          return updateNumberShare(value);
        }
        const pairingMode = value ? 'UNPAIR' : 'PAIR';
        const acssMfeNumberShare = sessionStorage.getItem('acssMfeNumberShare');
        let numbershareMap = {};
        if (acssMfeNumberShare) {
          numbershareMap = JSON.parse(acssMfeNumberShare);
        }
      
        const  isActionReverted = numbershareMap?.[activeMtn]?.numbersharePairingMode == pairingMode
        numbershareMap[activeMtn] = { 
          activeMtn, 
          numbersharePairingMode: value ? 'PAIR' : 'UNPAIR',
          trunkMtn,
          accountNumber: customerProfileDetails?.customer?.accountNo,
        };

        const currentAccountNumberShareList = Object.values(numbershareMap)?.filter((val) => val.accountNumber == customerProfileDetails?.customer?.accountNo);

         /* istanbul ignore next */
        if (isActionReverted && currentAccountNumberShareList?.length > 1) {
           delete numbershareMap[activeMtn];
           currentAccountNumberShareList.splice(currentAccountNumberShareList.findIndex((val) => val.activeMtn == activeMtn),1);
        }

        const pairUnpairPayload = {
          cartInfo: {
            clientAppName: "VZW-ACSS",
            cartId: sessionStorage.getItem('acssMfeCartId'),
            caseId: sessionStorage.getItem('acssMfeCaseId'),
            accountNumber: customerProfileDetails?.customer?.accountNo,
            cartCreator: activeMtn,
            ngdFlow: false,
            processingMTN: activeMtn,
            processStep: "NumberSelection",
            processAction: "addNumberShare",
            intendType: "CPC",
            isNumberShareFromCart: false
          },
          data: {
            lines: currentAccountNumberShareList.map((val) => (
              {
                mtn: val.activeMtn,
                currentPairingModeChanged: false,
                numbersharePairingMode: val.numbersharePairingMode,
                trunkMtn: val.numbersharePairingMode === 'PAIR' ? val.trunkMtn : ''
              }
          ))
          }
        }

        // Call unpair/pair API
        callNumberSharePairUnpair({ body : pairUnpairPayload });
        updateNumberShare(value);

        if (isActionReverted && currentAccountNumberShareList?.length === 1 && numbershareMap[activeMtn]) {
           delete numbershareMap[activeMtn];
        }
        sessionStorage.setItem('acssMfeNumberShare', JSON.stringify(numbershareMap));
        Emitter.emit('ACSS_SHARED_NUMBER_TOGGLE', { });

        dispatch(appMessageActions.clearAppMessages());
        if (!isActionReverted)  {
          if (value) {
          dispatch(
            appMessageActions.addAppMessage(
              'Numbershare has been paired. Please review plan and feature for changes due to this pairing.',
            ),
          );
        } else {
          dispatch(
            appMessageActions.addAppMessage(
              'Numbershare has been separated (turned off). Please review plan and feature for changes due to this separation.',
            ),
          );
        }
      }
    } else {
      setEnableBYODbtn(true);
      updateNumberShare(value);
      if (isNumberShare) {
        dispatch(appMessageActions.clearAppMessages());
        dispatch(
          appMessageActions.addAppMessage(
            'Numbershare has been separated (turned off). Please review plan and feature for changes due to this separation.',
          ),
        );
     }
    }
  };

  const getSharedNumber = () => {
    if (isNumberShare === false) {
      return '';
    }
    if (numberShareValue !== '') {
      return numberShareValue;
    }
    if (sharedMtnValue !== '') {
      return sharedMtnValue;
    }
    return 'Select Host Number';
  };

  const getSortId = () => {
    if (
      details.childSkusByColor &&
      details.childSkusByColor.length > 0 &&
      details.childSkusByColor[0] &&
      details.childSkusByColor[0].skus &&
      details.childSkusByColor[0].skus[0].sorId
    )
      return details.childSkusByColor[0].skus[0].sorId;
    if (details && details.childSkus && details.childSkus[0]) return details.childSkus[0].sorId;
    return '';
  };

  const deviceLockHeaderData = {
    header: 'Important device lock information',
    line: '',
    mdn: '',
    closeIcon: true,
    closeClickHandler: handleClick,
  };

  const callNumberShareInfo = () => { /* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */
    if (details.isNumberShareMandatory || details.isNumberShareCapable) {
      updateNumberShare(true);

      if (scmDeviceEnable && enableSCMNumberShare) {
        const acssMfeNumberShare = sessionStorage.getItem('acssMfeNumberShare');
        let numbershareMap = {};
        if (acssMfeNumberShare) {
          numbershareMap = JSON.parse(acssMfeNumberShare);
          /* istanbul ignore else */
          if (numbershareMap?.[activeMtn]?.trunkMtn) {
            updateNumberShareValue(numbershareMap?.[activeMtn]?.trunkMtn);
          }
        }
      }

      const defaultSKU = getProp(details, 'defaultSKU');
      let lineDetails = customerProfileDetails?.customer?.billAccounts?.[0]?.mtns || [];
      const cartLines = cartDetails?.cart?.lineDetails?.lineInfo || [];
      if (cartLines?.length > 0) {
        lineDetails = [...lineDetails, ...cartLines];
      }

      const index =
        lineDetails && lineDetails?.length > 0
          ? lineDetails.findIndex((x) => x.mtn === activeMtn || x.mobileNumber === activeMtn)
          : -1;

      if (index !== -1) {
        let existingTrunkMTN = lineDetails[index]?.benefitPair?.pairedPhoneMtn || '';
        if (!existingTrunkMTN && scmDeviceEnable && enableSCMNumberShare) {
          existingTrunkMTN = numberShareValue || sharedMtnValue || '';
        }
        if (existingTrunkMTN === '' || existingTrunkMTN === null || existingTrunkMTN === undefined) {
          const { isE911Address = false } = details;
          if (isNumberShareMandatory === false && isE911Address === true) {
            dispatch(appMessageActions.clearAppMessages());
            dispatch(
              appMessageActions.addAppMessage(
                'Eligible for NumberShare - Please swipe NumberShare toggle and select Host MDN or leave toggle off to continue as standalone (Non-NumberShare)',
              ),
            );
          } else {
            dispatch(appMessageActions.clearAppMessages());
            dispatch(
              appMessageActions.addAppMessage('Eligible for NumberShare - Please select NumberShare toggle/option'),
            );
          }
        }
      }

      const sorId = getSortId();
      const request = {
        mtn: activeMtn,
        deviceSorId: defaultSKU !== null && defaultSKU !== undefined ? defaultSKU : sorId,
      };
      const { subAccountInfo = [] } = orderDetails;
      const hasSubAccount = subAccountInfo?.length > 0;

      if (hasSubAccount) {
        request.subAccountId = activeSubAccountId;
      }
      getEligibleNumberShareLis({ body: request });
    } else if (scmDeviceEnable && !details.isNumberShareMandatory) {
      updateNumberShare(false);
    }
  };

  const callWFGbannerInfo = (defaultSku, selectedPlan, onInitialLoad) => {
    const reasonCodeType = isByodUpdate
      ? 'BYOD_DEVICE'
      : // : isTransferUpgradeSuccess //need to check with team
        //   ? 'ALTERNATE_UPGRADE'
        //   : isInEligibleUpgradeSuccess  //need to check with team
        //     ? 'INELIGIBLE_UPGRADE'
        '';
    const mtns = props?.customerProfileDetails?.customer?.billAccounts?.[0]?.mtns;
    const lineDetail = mtns && mtns.filter((productDetail) => productDetail?.mtn === activeMtn);
    let { recentPurchaseOrder } = lineDetail?.[0] || {};
    const { equipmentUpgradeEligibility } = lineDetail?.[0] || {};
    const { isWithInWFGperiod = false } = equipmentUpgradeEligibility || {};
    recentPurchaseOrder = recentPurchaseOrder || {};
    if (isWithInWFGperiod) {
      if (onInitialLoad) {
        const contractTermMatched =
          reasonCodeType === 'BYOD_DEVICE' ? 'MONTH_TO_MONTH' : getContractTerm('DEVICE_PAYMENT');
        const reqBody = {
          cartMtnList: [
            {
              mtn: activeMtn,
              deviceSku: defaultSku,
              contractType: contractTermMatched,
              reasonCodeType,
            },
          ],
        };
        if (upgradeReasonCodeResponse?.status !== 'fulfilled') {
          getReasonCodeResult({ body: reqBody });
        }
        if (upgradeReasonCodeResponse?.isSuccess) {
          const UpgradeReasonResult =
            upgradeReasonCodeResponse?.data?.data?.retrieveURCforCartMtnList?.mtnUpgradeReasonCodes?.[0]
              ?.upgradeReasonCodes || [];
          const selectedReason = UpgradeReasonResult.find((reasonCode) => reasonCode.defaultReasonCode);
          const upgradeReasonCode = selectedReason?.code;
          const WFGMsg =
            (upgradeReasonCode === 'WA' &&
              `This line is eligible for WCG. Note that if WCG reason code is selected, 
            ${formatCurrency(recentPurchaseOrder.retailPrice)} less any installments paid will be charged 
              back if equipment is not received in 20 days and does not include any taxes.`) ||
            `This line is eligible for WFG. Note that if WFG reason code is selected, 
            ${formatCurrency(recentPurchaseOrder.retailPrice - recentPurchaseOrder.purchasePrice)} 
            will be charged back if  equipment is not received in 20 days and does not include any taxes.`;
          // eslint-disable-next-line no-unused-expressions
          WFGMsg && dispatch(appMessageActions.addAppMessage(WFGMsg, 'success', true, 60000));
        }
      } else {
        const WFGMsg =
          (selectedPlan === 'DEVICE_PAYMENT' &&
            `This line is eligible for WCG. Note that if WCG reason code is selected, 
      ${formatCurrency(recentPurchaseOrder?.retailPrice)} less any installments paid will be charged 
      back if equipment is not received in 20 days and does not include any taxes.`) ||
          `This line is eligible for WFG. Note that if WFG reason code is selected, 
     ${formatCurrency(recentPurchaseOrder.retailPrice - recentPurchaseOrder.purchasePrice)} 
       will be charged back if  equipment is not received in 20 days and does not include any taxes.`;
        dispatch(appMessageActions.addAppMessage(WFGMsg, 'success', true, 60000));
      }
    }
  };

  const callDpEligibilityBanner = () => {
    if (dpEligibilityResult?.status !== 'fulfilled') {
      const isPrePay = cartDetails?.cart?.orderDetails?.isPrePayCart === 'Y';
      if (
        selectedPaymentInfo?.contractType === 'DEVICE_PAYMENT' ||
        (selectedPaymentInfo?.contractType === 'MONTH_TO_MONTH' && isEditAndView)
      ) {
        if (isPrePay !== 'Y') {
          const value = selectedPaymentInfo?.term;
          const sorId = getSortId();
          const request = { term: value, sorId };
          getDpEligibility({ body: request, spinner: false });
        }
      }
    }
  };

  const showNumberShareModalHandler = () => {
    const accountPair =
      numberShareDetails?.accountPairedDevice && numberShareDetails?.accountPairedDevice?.accountPairingCanBeChanged;
    if (accountPair !== undefined && !accountPair) {
      dispatch(appMessageActions.clearAppMessages());
      dispatch(
        appMessageActions.addAppMessage(
          'Sharing is not allowed. Please proceed with seperate transaction first and then share with another MTN.',
        ),
      );
    } else {
      setShowNumberShareModal(true);
      makeOpenViewCall('Shared Number Model');
    }
  };

  const paymentInfo = customerProfileDetails?.customer?.billAccounts?.[0]?.paymentInfo || {};
  const isBalancePastDue = paymentInfo?.isBalancePastDue || false;
  const isPastbalPreBackOrder = (isIndirect && isBalancePastDue && (isBackorder || isPreOrder)) || false;
  const isPastbalBackOrderWithDueAmount = ((isIndirect || isRetail()) && isBalancePastDue && isBackorder) || false;
  const depletionType = deviceFromFilteredCartLine?.depletionType || '';
  const isLandingLocalFlow = !!getQueryParamByName('scanFromLanding');

  const shippingDate = getProp(selectedSku, 'inventoryDetails.dFillInventory.shippingDate') || {};
  const isSplitShipment = sessionStorage.getItem('isSplitShipment');
  const ispuDisable =
    isSplitShipment === 'true'
      ? !selectedSku?.isInstorePickup && !isFromCPE
      : (!selectedSku?.isInstorePickup && !isFromCPE) || filteredLineFromCart?.ispuItem;

  const isPreOrderBackOrderText = !!(
    !isFromCPE &&
    !isByodUpdate &&
    !isLandingLocalFlow &&
    !(isIndirect && deviceFromCart && depletionType === 'L')
  );

  const preOrderText =
    isPreOrderBackOrderText && isPreOrder && isPreOrder === true ? (
      <div
        className='u-floatLeft u-textBold'
        id='devicePdpPreOrderText'
        name='pre_Order'
        style={{
          color: '#0077B4',
          fontFamily: 'Verizon-NHG-eDS, Helvetica, Arial, Sans-serif !important',
        }}
      >
        {' '}
        Pre order device delivers by {shippingDate?.date}
      </div>
    ) : (
      ''
    );
  const backOrderText =
    isPreOrderBackOrderText && isBackorder && isBackorder === true ? (
      <BackorderText shippingDate={shippingDate.date} />
    ) : (
      ''
    );

  const defaultSkuPreOrderFlag = getProp(details, 'defaultSKUObj.inventoryDetails.dFillInventory.isPreOrder');
  const isPrePay = cartDetails?.cart?.orderDetails?.isPrePayCart === 'Y';
  const annualUpgradeEligible =
    orderDetails?.customerType !== 'N' &&
    !isPrePay &&
    !isNewLine &&
    selectedSku?.price?.devicePaymentPrice?.[0]?.dpTermPrices
      ? selectedSku.price.devicePaymentPrice[0].dpTermPrices?.upgradeOptionCode
      : '';
  const disableAddToCart = (status) => {
    setAddToCartDisabled(status);
  };

  const showBuyOutDetailsModal = () => {
    setShowBuyoutDetails(true);
    makeOpenViewCall('BuyoutAmountModel');
  };

  const toggleBuyOut = () => {
    if (isBuyOutToggleOn) {
      setShowDeclinePopUp(true);
      // tagging changes
    } else {
      setIsBuyOutToggleOn(true);
      setBuyoutToggleChange(false);
      props.buyOutcall();
      setIsInDpVisible(false);
    }
  };

  useEffect(() => {
    const numberOfMonths = filteredLineFromCart?.installmentInfo?.installmentTerm;
    if (deviceFromCart === true && isProductId === true) {
      if (deviceFromFilteredCartLine && deviceFromFilteredCartLine.priceType === 'MONTH_TO_MONTH') {
        selectPayment(selectedSku?.price?.fullRetailPrice, 'MONTH_TO_MONTH');
      } else if (
        ((deviceFromFilteredCartLine && deviceFromFilteredCartLine.priceType === 'VERIZON_EDGE') ||
          (deviceFromFilteredCartLine && deviceFromFilteredCartLine.priceType === 'DEVICE_PAYMENT')) &&
        (numberOfMonths === 24 || numberOfMonths === 30 || numberOfMonths === 36)
      ) {
        let payment = '';
        if (deviceFromCart && deviceFromFilteredCartLine && deviceFromFilteredCartLine.priceType === 'VERIZON_EDGE') {
          payment = { originalPrice: deviceFromFilteredCartLine?.itemPrice, contractText: 'Full Retail Price' };
          selectPayment(payment, 'VERIZON_EDGE');
        } else {
          payment =
            selectedSku?.price?.devicePaymentPrice?.length > 0 &&
            selectedSku?.price?.devicePaymentPrice.filter(
              (price) => price.contractDuration && price.contractDuration === numberOfMonths
            );
          selectPayment(payment?.[0], 'DEVICE_PAYMENT');
        }
      } else if (deviceFromFilteredCartLine && deviceFromFilteredCartLine.priceType === contractTerms.TWO_YEAR) {
        selectPayment(selectedSku?.price?.twoYearPrice, contractTerms.TWO_YEAR);
      } else if (isVbgFlag) {
        if (deviceFromFilteredCartLine && deviceFromFilteredCartLine.priceType === contractTerms.ONE_YEAR) {
          selectPayment(selectedSku?.price?.oneYearPrice, contractTerms.ONE_YEAR);
        } else if (deviceFromFilteredCartLine && deviceFromFilteredCartLine.priceType === contractTerms.THREE_YEAR) {
          selectPayment(selectedSku?.price?.threeYearPrice, contractTerms.THREE_YEAR);
        } else if (deviceFromFilteredCartLine && deviceFromFilteredCartLine.priceType === contractTerms.THIRTY_MONTHS) {
          selectPayment(selectedSku?.price?.thirtyMonthPrice, contractTerms.THIRTY_MONTHS);
        }
      }
    }
    if (
      ((!isFromCPE || (isFromCPE && isWSAPCpeError && isRetail())) &&
        !isByodUpdate &&
        (isPrePayCart || ispuToggleOn || !isVisible())) ||
      (!isBYOD && displayPaymentOptions() && isInStock)
    ) {
      if (!deviceFromCart) {
        preSelectDP();
      }
    } // Need to check Buyout and Credit popup conditions
  }, [priceValue]);

  useEffect(() => {// NOSONAR
    const dppremoveflag =
      !dpEligibilityResult?.data?.isDevicePaymentEligible &&
      removeDPPoptionFFlag === 'TRUE' &&
      typeof dpEligibilityResult?.data?.isDevicePaymentEligible === 'boolean';
    if (deviceFromFilteredCartLine) {
      const paymentPriceTypefromCart = deviceFromFilteredCartLine?.priceType === 'MONTH_TO_MONTH';
      const paymentSkufromCart = deviceFromFilteredCartLine?.sorId === selectedSku?.sorId;
      if (paymentPriceTypefromCart && paymentSkufromCart) {
        SelectedContractType('Full Retail Price', selectedSku?.price?.fullRetailPrice?.originalPrice);
      } else if (selectedSku?.price?.devicePaymentPrice) {
        if ((RetrievedppResult?.data?.data?.dppIndicator && dppIndicatorFFlag === 'TRUE') || dppremoveflag) {
          if(isVbgFlag && getPricingPriority(selectedSku?.price)) {
            SelectedContractType(
              selectedSku?.price?.[getPricingPriority(selectedSku?.price)]?.contractText,
              selectedSku?.price?.[getPricingPriority(selectedSku?.price)]?.originalPrice
            );
          } else {
            SelectedContractType('Full Retail Price', selectedSku?.price?.fullRetailPrice?.originalPrice);
          }
        } else {
          const firstDpTermIndex = getDpTermIndex(selectedSku?.price);
          if(isVbgFlag) {
            if(firstDpTermIndex !== -1) {
              const dppPrice = Number(filteredLineFromCart?.installmentInfo?.downPayment) > 0
                ? filteredLineFromCart?.installmentInfo?.monthlyInstallment
                : selectedSku?.price?.devicePaymentPrice?.[firstDpTermIndex]?.originalPrice;
              SelectedContractType(
                selectedSku?.price?.devicePaymentPrice?.[firstDpTermIndex]?.dpTermPrices?.dpTerm,
                computeDPPriceResult?.isSuccess &&
                  computeDPPriceResult?.data?.remainingMonthPrice &&
                  computeDPPriceResult?.originalArgs?.body?.sorId === selectedSku?.sorId
                  ? computeDPPriceResult?.data?.remainingMonthPrice
                  : dppPrice,
                false,
                '',
                true,
              );
            } else if(getPricingPriority(selectedSku?.price)) {
              SelectedContractType(
                selectedSku?.price?.[getPricingPriority(selectedSku?.price)]?.contractText,
                selectedSku?.price?.[getPricingPriority(selectedSku?.price)]?.originalPrice
              );
            }
          } else {
            const dppPrice = Number(filteredLineFromCart?.installmentInfo?.downPayment) > 0
              ? filteredLineFromCart?.installmentInfo?.monthlyInstallment
              : selectedSku?.price?.devicePaymentPrice?.[0]?.originalPrice;
            SelectedContractType(
              selectedSku?.price?.devicePaymentPrice?.[0]?.contractText,
              computeDPPriceResult?.isSuccess &&
                computeDPPriceResult?.data?.remainingMonthPrice &&
                computeDPPriceResult?.originalArgs?.body?.sorId === selectedSku?.sorId
                ? computeDPPriceResult?.data?.remainingMonthPrice
                : dppPrice,
              false,
              '',
              true,
            );
          }
        }
      } else if(isVbgFlag && getPricingPriority(selectedSku?.price)) {
        SelectedContractType(
          selectedSku?.price?.[getPricingPriority(selectedSku?.price)]?.contractText,
          selectedSku?.price?.[getPricingPriority(selectedSku?.price)]?.originalPrice
        );
      } else if (selectedSku?.price?.fullRetailPrice) {
        SelectedContractType(
          selectedSku?.price?.fullRetailPrice?.contractText,
          selectedSku?.price?.fullRetailPrice?.originalPrice,
        );
      }
    } else if (isDpInVisible) {
      SelectedContractType('Full Retail Price', selectedSku?.price?.fullRetailPrice?.originalPrice);
    } else if (selectedSku?.price?.devicePaymentPrice) {
      if (RetrievedppResult?.data?.data?.dppIndicator && dppIndicatorFFlag === 'TRUE') {
        if(isVbgFlag && getPricingPriority(selectedSku?.price)) {
          SelectedContractType(
            selectedSku?.price?.[getPricingPriority(selectedSku?.price)]?.contractText,
            selectedSku?.price?.[getPricingPriority(selectedSku?.price)]?.originalPrice
          );
        } else {
          SelectedContractType('Full Retail Price', selectedSku?.price?.fullRetailPrice?.originalPrice);
        }
      } else {
        const firstDpTermIndex = getDpTermIndex(selectedSku?.price);
        if(isVbgFlag) {
          if(firstDpTermIndex !== -1) {
            SelectedContractType(
              selectedSku?.price?.devicePaymentPrice?.[firstDpTermIndex]?.dpTermPrices?.dpTerm,
              selectedSku?.price?.devicePaymentPrice?.[firstDpTermIndex]?.originalPrice,
            );
          } else if(getPricingPriority(selectedSku?.price)) {
            SelectedContractType(
              selectedSku?.price?.[getPricingPriority(selectedSku?.price)]?.contractText,
              selectedSku?.price?.[getPricingPriority(selectedSku?.price)]?.originalPrice
            );
          }
        } else {
          SelectedContractType(
            selectedSku?.price?.devicePaymentPrice?.[0]?.contractText,
            selectedSku?.price?.devicePaymentPrice?.[0]?.originalPrice,
          );
        }
      }
    } else if(isVbgFlag && getPricingPriority(selectedSku?.price)) {
      SelectedContractType(
        selectedSku?.price?.[getPricingPriority(selectedSku?.price)]?.contractText,
        selectedSku?.price?.[getPricingPriority(selectedSku?.price)]?.originalPrice
      );
    } else if (selectedSku?.price?.fullRetailPrice) {
      SelectedContractType(
        selectedSku?.price?.fullRetailPrice?.contractText,
        selectedSku?.price?.fullRetailPrice?.originalPrice,
      );
    }
    const isVVCSelected = orderDetails?.accessoryFinancingOfferInfo?.splitPaymentInfo?.find(
      (info) => info.mtn === activeMtn,
    )?.isDfo;
    if (isVVCSelected && isVVCFlowEnabled) {
      const contractType = {
        contractType: 'MONTH_TO_MONTH',
        price: `vvcPaymentOption-${selectedSku?.price?.vvcDeviceFinancingOfferPrice?.originalMonthlyPrice}`,
        term: selectedSku?.price?.vvcDeviceFinancingOfferPrice?.installmentTerm,
        paymentType: '$vvcPaymentOption',
      };
      setSelectedPaymentInfo(contractType);
    }
  }, [selectedSku, cartDetails]);
  useEffect(() => {
    const message = 'Copied to Clipboard';
    if (clickedCopyColorNames) {
      dispatch(appMessageActions.addAppMessage(message, 'success', false));
    } else if (!clickedCopyColorNames) {
      dispatch(appMessageActions.removeAppMessage({ summary: message }));
    }
  }, [clickedCopyColorNames]);

  const selectPayment = (PaymentType, selectedPlan) => {
    if (selectedPlan === 'DEVICE_PAYMENT') {
      if (customerConsentCaptured === 'N' && orderDetails?.customerType !== 'N' && !isPrePay && !isBYOD) {
        setMonthlyPaymentModal(true);
        setCustomerConsentCaptured('Y');
        setSelectedPaymentType(PaymentType);
        makeOpenViewCall('Monthly Payment Model');
      } else {
        setMonthlyPaymentModal(false);
        setSelectedPaymentType(PaymentType);
        callWFGbannerInfo('', selectedPlan, false);
      }
    } else {
      setSelectedPaymentType(PaymentType);
    }
  };

  const displayBuyoutDetails = (buyOutDetail) => (
    <>
      <FlexBoxContainer>
        <Title size='small' color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR}>
          <div data-track={`buyout_toggle:${isBuyOutToggleOn ? 'decline' : 'accept'}`}>
            <span style={{ marginRight: '5px' }}>Buyout Amount</span>
            <span className='u-textBold'>
              {' '}
              ${props.totalBuyoutAmount ? props.totalBuyoutAmount : buyOutDetail && buyOutDetail.buyOutAmt}{' '}
            </span>
            <span style={{ marginLeft: '5px' }}>Accepted</span>
          </div>
        </Title>
        <DivFlexContainer>
          <TextLink
            style={{
              fontFamily: 'BrandFontRegular',
              fontWeight: 'normal',
              paddingRight: '10px',
            }}
            onClick={() => showBuyOutDetailsModal()}
            onKeyPress={(e) => onKeyPressEvent(e) && showBuyOutDetailsModal()}
            data-testid='viewDetails'
            data-track='Productdetail_Viewdetails'
          >
            View details
          </TextLink>
          <div className='u-textBold u-textRight'>
            <div style={{ width: 'fit-content', marginLeft: 'auto' }}>
              <Toggle
                ariaLabel='buyout toggle'
                name='buyout toggle'
                className='u-marginAllNone'
                value='off'
                on={isBuyOutToggleOn}
                disabled={!!deviceFromCart}
                onChange={toggleBuyOut}
              />
            </div>
          </div>
        </DivFlexContainer>
      </FlexBoxContainer>
      <HorizontalLine />
    </>
  );

  const getByodCpePaymentOptions = () => {
    const byodCpePaymentOptions = [];
    console.log(selectedSku, 'selectedSkuuuu');
    const price = selectedSku?.price;
    const dpPaymentOption = {
      name: 'MONTH_TO_MONTH',
      value: 'MONTH_TO_MONTH',
      children: 'CPE month-to-month contract',
      'data-track': `Productdetail_Paymentoption_CPE month-to-month contract`,
    };
    const twoYearPaymentOption = { name: 'TWO_YEAR', value: 'TWO_YEAR', children: 'CPE 2-year contract' };
    byodCpePaymentOptions.push(dpPaymentOption);
    if (price && price.twoYearPrice) {
      byodCpePaymentOptions.push(twoYearPaymentOption);
    }
    return byodCpePaymentOptions;
  };

  // const isRetail = /retail/i.test(sessionStorage.getItem('channel'));
  const showShipItOption = !isBYOD && isVisible() && (isRetail() || isIndirect);
  const isWSAPCpeError = Boolean(getQueryParamByName('isWSAPCpeError')) || false;
  const isPrePayCart = !!(cartDetails?.cart?.orderDetails?.isPrePayCart === 'Y');
  const deviceInfo = validateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo;
  const etniApi = deviceInfo?.simInfo2 ? false : deviceInfo?.makeEtniPersApi;
  const ESimYes = getQueryParamByName('eSim');
  console.log(etniApi, ESimYes);

  const showShipitToggle =
    customerProfileDetails?.commonInfo?.showShipitToggle || productDetails?.commonInfo?.showShipitToggle || '';
  const isISPUEnabled = !!customerProfileDetails?.commonInfo?.isISPUEnabled;
  let emergencyCLNR = '';
  if ((isByodUpdate || isFromCPE) && !isEmpty(selectedSku?.parentProducts?.[0]?.emergencyCLNR)) {
    emergencyCLNR = selectedSku?.parentProducts?.[0]?.emergencyCLNR;
  } else {
    emergencyCLNR = getProp(details, 'emergencyCLNR') || '';
  }
  const secondNumberFromSession = sessionStorage.getItem('isSecondNumDfill')
    ? JSON.parse(sessionStorage.getItem('isSecondNumDfill'))
    : '';
  const isSecondNumberFlow = !!secondNumberFromSession;

  const isAsurionCheck =
    ((((channel && channel?.indexOf('OMNI-RETAIL') > -1) || (channel && channel?.indexOf('OMNI-D2D') > -1)) &&
      selectedPaymentInfo?.contractType === 'MONTH_TO_MONTH' &&
      showShipitToggle &&
      !isShipItToggleOn &&
      emergencyCLNR) ||
      (isTelesales() && selectedPaymentInfo?.contractType === 'MONTH_TO_MONTH' && emergencyCLNR) ||
      ((isByodUpdate || isFromCPE) && emergencyCLNR)) &&
    !isIndirect &&
    !isSecondNumberFlow;

  const handleCLNRRsnCodeUpdate = () => {
    if (isCLNRon) {
      setUpgradeReasonType('WP');
    } else {
      setUpgradeReasonType('');
    }
  };

  const toggleCLNR = () => {
    setCLNRon(!isCLNRon);
  };

  useEffect(() => {
    handleCLNRRsnCodeUpdate();
  }, [isCLNRon]);
  const closeMonthlyPaymentModel = () => {
    setMonthlyPaymentModal(false);
  };
  const closeBuyoutModel = () => {
    setShowBuyoutDetails(false);
  };
  const backAction = () => {
    setIspuToggleOn(ispuToggleOn || (isEditAndView && filteredLineFromCart?.ispuItem));
    setShowDeviceModal(false);
  };
  const isBuyOut = () => {
    const accountInfo = productDetails?.accountInfo;
    const buyoutDisplay = accountInfo?.buyoutDisplay?.toLowerCase() === 'true';
    return !isBYOD && buyoutDisplay;
  };
  const simSwapFlowUpdateButtonDisabled = (data) => {
    setDisableUpdateButton(data);
  };
  const preSelectDP = () => {
    const buyOutSuccess = props?.BuyoutResult;
    const { devicePaymentPrice = [], preferredTerm = 0, fullRetailPrice = {} } = selectedSku?.price || {};
    const dpEligible = isVisible('DP') && selectedSku?.price?.devicePaymentPrice && (!isBuyOut() || buyOutSuccess);
    const preferredDPTerm =
      devicePaymentPrice && devicePaymentPrice?.find((term) => term?.dpTermPrices?.dpTerm === preferredTerm);
    const contractText =
      fullRetailPrice && fullRetailPrice?.contractText && fullRetailPrice?.contractText?.toLowerCase();
    const frp = contractText && contractText.replace(/\s+/g, '_');
    if (props?.PdpBuyoutToggle && props?.isBuyoutEligible) {
      if ((!isBuyOutToggleOn || !dpEligible) && frp === 'full_retail_price') {
        selectPayment(preferredDPTerm, 'MONTH_TO_MONTH');
      } else if (isBuyOutToggleOn && dpEligible && preferredDPTerm) {
        selectPayment(preferredDPTerm, 'DEVICE_PAYMENT');
      }
    } else if (dpEligible && preferredDPTerm && selectedPaymentInfo) {
      selectPayment(preferredDPTerm, selectedPaymentInfo?.contractType);
    } else if (dpEligible && preferredDPTerm) {
      selectPayment(preferredDPTerm, 'DEVICE_PAYMENT');
    } else if (isPrePay) {
      selectPayment(preferredDPTerm, 'MONTH_TO_MONTH');
    }
  };

  let isInStock = false;
  const dFillInventoryisInstock =
    getProp(selectedSku, 'inventoryDetails.dFillInventory.isInStock') ||
    getProp(productDetails?.deviceSku, 'inventoryDetails.dFillInventory.isInStock');
  const localInventoryisInstock =
    getProp(selectedSku, 'inventoryDetails.localInventory.isInStock') ||
    getProp(productDetails?.deviceSku, 'inventoryDetails.localInventory.isInStock');
  // for indirect we don't have local inventory so setting instock true if it's local order
  if (
    dFillInventoryisInstock ||
    localInventoryisInstock ||
    isPreOrder ||
    isBackorder ||
    (isIndirect && !isShipItToggleOn)
  ) {
    isInStock = true;
    setisInStock(true);
  }
  if (
    (((!isFromCPE || (isFromCPE && isWSAPCpeError && isRetail())) &&
      !isByodUpdate &&
      (isPrePayCart || ispuToggleOn || !isVisible())) ||
      (!isBYOD && displayPaymentOptions() && isInStock)) &&
    !isPaymentOptionVisible
  ) {
    setIsPaymentOptionVisible(true);
  }

  const handleConfirmationDecline = (option) => {
    if (option === 'yes') {
      setIsBuyOutToggleOn(false);
      setShowDeclinePopUp(false);
      setBuyOutAccepted(false);
      setSkipRedirection(true);
      setBuyoutToggleChange(true);
      removeLines();
      setIsInDpVisible(true);
      const contractType = { contractType: 'MONTH_TO_MONTH' };
      setSelectedPaymentInfo(contractType);
    } else if (option === 'no') {
      setIsBuyOutToggleOn(true);
      setShowDeclinePopUp(false);
      setBuyOutAccepted(true);
      setIsInDpVisible(false);
    }
  };

  /**
   * executes on change of dropdown value
   * @param {Object} deviceIdSkuData ropdwon data from device or sim only change
   */
  const handleDeviceIdSkuHandler = (deviceIdSkuInfo, skipClearingMessage) => {
    const deviceIdSkuData = deviceIdSkuInfo;
    // TODO - FFlag
    if (deviceIdSkuData?.dropdownValue === 'Generate ESIM Profile') {
      setShowGetEsimPopup(true);
      /* istanbul ignore next */
      if (!isEsimActivationEnabled) {
        deviceIdSkuData.dropdownValue = 'SIM only change';
      }
    }
    /* istanbul ignore next */
    if (callESimApi) {
      setCallESimApi(false);
    }
    if (scmDeviceEnable && !skipClearingMessage) {
      dispatch(appMessageActions.clearAppMessages());
    }
    setDeviceIdSelected(deviceIdSkuData?.deviceIdSelected);
    setomnicaredropdownValue(deviceIdSkuData?.dropdownValue);
  };

  const handleShopDeviceNav = () => {
    if (window?.mfe?.scmUpgradeMfeEnable) {
      if (scmCombinedGridwallFlow) {
        Emitter.emit('ACSS_SCM_DEVICE_SUBTAB', { subTab: 'CombinedGridwall', activeMtn });
      } else {
        Emitter.emit('ACSS_SCM_DEVICE_SUBTAB', { subTab: 'DeviceGridwall' });
      }
      return;
    }
  };

  const checkSecondNumberFlag =
    (!(productDetails?.deviceProduct?.isSecondNumEligible || details?.isDsdsCapable) &&
      secondNumData?.[0]?.primaryNumber &&
      enableEUPDualNum === 'TRUE') ||
    false;
  const handleShopNavigation = (redirect) => {
    if (redirect && !scmDeviceEnable) {
      navigate(`${getUIContextPathBAU()}/combinedgridwall.html?activeMtn=${activeMtn}&devicePlanCompatible=false`);
    }
    setSecondNumberWarningModal(false);
  };
  /* istanbul ignore next */
  const displayBanner = () => {
    setClickedCopyColorNames(true);
    timeoutManager.scheduleTimeout(() => {
      setClickedCopyColorNames(false);
    }, 5000);
  };
  const instorePickupStyle = isBYOD || isTelesales() ? { width: '100%' } : {};

  let editable = protectionFeatures?.payload?.currentProtection?.editable;
  
  if (!isFromCPE && isOmniCare && omnicaredropdownValue === 'SIM only change' && isByodUpdate) {
    editable = false;
  }

  const prodCode5 = selectedSku && selectedSku.prodCode5 ? selectedSku.prodCode5 : null;
  const dropshipProdcode5Value = dropshipProdcode5 && dropshipProdcode5.length > 0 ? dropshipProdcode5 : 'ADS,UNL';
  const enableDropshipValue = enableDropship && enableDropship.length > 0 ? enableDropship.toUpperCase() : 'FALSE';
  const dropshipProdcode5Arr = dropshipProdcode5Value.split(',');
  const disableShipItButton = !isBYOD && enableDropshipValue === 'FALSE' && dropshipProdcode5Arr.includes(prodCode5);
  if (ESimYes && window?.vzdl?.target?.message !== 'Device ID associated with eSIM has been updated.') {
    const vzdl = window?.vzdl;
    if (vzdl?.target) vzdl.target.message = 'Device ID associated with eSIM has been updated.';
    sendCustomEvent('notification', vzdl);
    window.vzdl = vzdl;
  }
  const isSecondNumber = getQueryParamByName('SecondNumber') || false;
  const isRfexMfeFlowFlagEnabled = rfexMfeFlowFlag();
  const rfexOnProfileFlow = isRfexMfeFlowFlagEnabled && /true/i.test(getQueryParamByName('isContractChange'));
  const displayIspuToggle =
    isISPUEnabled && isEmpty(filteredLineFromCart?.edgeUpDetail) && !isSecondNumber && !isRfexMfeFlowFlagEnabled;
  const ispuCustomerType = sessionStorage.getItem('customerType');
  const showISPUToggle = vbgNsaIspuForExsCustFFlag ? 
    ((!isVbgFlag && ((displayIspuToggle && !isBBYLocalOrder) || /true/i.test(bestBuyISPUEnableLocalOrderFFlag))) ||
     (isVbgFlag && ispuCustomerType !== 'N'))
    : !isVbgFlag && ((displayIspuToggle && !isBBYLocalOrder) || /true/i.test(bestBuyISPUEnableLocalOrderFFlag));
  const displayShipItToggle = showShipitToggle && showShipItOption && !isTelesales();

  const [flexFlowServiceChangeFFlag, removeonKeyDownNumberShareScreenFFlag] = getAssistedCradlePropertyV2(['flexFlowServiceChangeFFlag','removeonKeyDownNumberShareScreenFFlag']);
  const onKeyDownHandler = () => {
    if (!removeonKeyDownNumberShareScreenFFlag) {
      showNumberShareModalHandler();
    }
  };
  const flexFlowServiceChange = /true/i.test(flexFlowServiceChangeFFlag) && getQueryParamByName('etrServiceChanges');

  /* istanbul ignore next */
  const routeToPlans = () => {
    if (flexFlowServiceChange && showPlanChange) {
      // navigate(
      //   `${getUIContextPathBAU()}/combinedgridwall.html?fromLanding=TRUE&activeMtn=${activeMtn}&isPlanTabSelect=true&incompatiblePlan=true`,
      // );
      const tabList = document.querySelectorAll('[role="tab"]');
      const plansTab = Array.from(tabList)?.filter((node) => node?.innerText === 'Plans')?.[0];
      if (plansTab) {
        plansTab?.click();
      }
    }
  };

/* istanbul ignore next */
  const handleEsimCall = (option) => {
    setShowGetEsimPopup(false);
    if (option === 'yes') {
      setCallESimApi(true);
      if (isEsimActivationEnabled) {
        props?.setIsESimRegenerated?.(true);
      }
    }
  };
  const getNotificationClassName = () => {
    if (window?.mfe?.isProspectNewCustomerTab) {
      return 'top-fixed-IS';
    }
    if (scmUpgradeMfeEnable) {
      return 'top-fixed-scm';
    }
    return 'top-fixed';
  };
  const renderNotification = () =>
    ESimYes ? (
      <div id='AppMessage' className={`AppMessage ${getNotificationClassName()}`} data-testid='notificationError'>
        <Notification
          type='success'
          title='Device ID associated with eSIM has been updated.'
          layout='vertical'
        />
      </div>
    ) : null;

  const selectedDevicePlanId = lineInfo && lineInfo[0]?.pricePlanInfo?.planId;
  const appConfig = GetAppConfig();
  const byodUltimatePlanIDs = appConfig?.messages?.dqContent?.byodUltimatePlanIDs || [];
  const isSelectedDeviceByod = (
    byodPlusUltimateDPPFFlag &&
    Array.isArray(byodUltimatePlanIDs) &&
    selectedDevicePlanId &&
    byodUltimatePlanIDs.includes(selectedDevicePlanId) &&
    selectedPlanId === 'Productdetail_MonthlyPayments'
  );

  return (
    <>
    {scmUpgradeMfeEnable && renderNotification()}
    <PDPWrapper
      scmDeviceEnable={scmDeviceEnable || flexFlowServiceChange}
      isMaslowApp={isMaslowApp}
      style={{ top: flexFlowServiceChange ? 0 : null }}
    >
       {!scmUpgradeMfeEnable && renderNotification()}
      <LeftWrapper scmDeviceMfeEnable={window?.mfe?.scmDeviceMfeEnable}>
        <ImgWrapper>
          <img src={devices.logo} width='205px' height='312px' alt='deviceslogo' />
        </ImgWrapper>
        {annualUpgradeEligible === 'UO' && (
          <TextWrapper>
            Early Upgrade Eligible
            <Tooltip id='upgradeTT' size='small'>
              You can upgrade after 30 days and 50 % of your device is paid off.
            </Tooltip>
          </TextWrapper>
        )}
        {!isBYOD && (
          <TextLinkWrapper>
            <ModelWrap
              toggleButton={
                <TextLink surface={isDark ? 'dark' : 'light'} type='standAlone' size='large' onClick={() => makeOpenViewCall('View device details')}>
                  View device details
                </TextLink>
              }
              surface='light'
              fullScreenDialog={!(deviceInfoFFlag && scmDeviceEnable)}
              scmDeviceMfeEnable={deviceInfoFFlag && window?.mfe?.scmDeviceMfeEnable}
              disableAnimation={false}
              disableOutsideClick={false}
              closeButton={null}
              ariaLabel='Testing Modal'
            >
              <Header data={headerData} CustomerData={customerProfileDetails.customer} isInStock={isInStock} />
              <ModalBody>
                <MarginSides>
                  <DeviceSpecifications
                    specsData={specsData}
                    inbox={inbox}
                    OverviewDetails={OverviewDetails}
                    openViewCall={makeOpenViewCall}
                    isVbg={isVbgFlag}
                  />
                </MarginSides>
              </ModalBody>
            </ModelWrap>
          </TextLinkWrapper>
        )}
        {selectedSku && (
          <Footer
            isDropshipDisabled={disableShipItButton}
            showISPULocalConflictBanner={showISPULocalConflictBanner}
            btnLabel={rfexOnProfileFlow ? 'Update' : btnLabel}
            localOnlyLocation={localOnlyLocation}
            isPdpUpdated={isPdpUpdated}
            isAcssDfillSim={isAcssDfillSim}
            callDeviceAddToCart={callDeviceAddToCart}
            deviceFromCart={deviceFromCart}
            isDWOS={props.isDWOS || isDWOS || isDwos}
            disableUpdateBtn={!selectedPaymentInfo || !isInStock}
            removeLines={removeLines}
            isCartBtnEnable={isCartBtnEnable && !addToCartDisabled}
            enableBYODbtn={enableBYODbtn}
            activeMtn={activeMtn}
            isPromoEligible={selectedSku?.isPromoEligible}
            disableUpdateButtonSimFlow={disableUpdateButton}
            ispuItemInCart={isPdpUpdated ? false : ispuFromCart}
            navigateToIspu={navigateToIspu}
            checkSecondNumberFlag={checkSecondNumberFlag}
            setSecondNumberWarningModal={setSecondNumberWarningModal}
            dpEligibilityCallFailure={dpEligibilityCallFailure}
            contractType={selectedPaymentInfo?.contractType}
            rfexOnProfileFlow={rfexOnProfileFlow}
            rfexMfeFlow={isRfexMfeFlowFlagEnabled}
            incompatibleSim={incompatibleSim}
            devicePricingEnabled={devicePricingEnabled}
            upcAndDeviceIdCheckEnabled={upcAndDeviceIdCheckEnabled}
            isBBYLocalOrder={isBBYLocalOrder}
            carrierLockDisableButton={carrierLockDisableButton}
            isPastbalBackOrderWithDueAmount={isPastbalBackOrderWithDueAmount}
            isShipItToggleOn={isShipItToggleOn}
            showPlanChange={showPlanChange}
            routeToPlans={routeToPlans}
            isSelectedDeviceByod={isSelectedDeviceByod}
          />
        )}
        {scmUpgradeMfeEnable && !isScmSecondNumPerkEnabled && !isFWAShowDevice &&(
          <div className='shop-devices-link-wrapper'>
            <TextLink
              type='standAlone'
              surface={isDark ? 'dark' : 'light'}
              size='large'
              onClick={() => {
                handleShopDeviceNav();
              }}
            >
              Shop Devices
            </TextLink>
          </div>
        )}
      </LeftWrapper>
      <RightWrapper scmDeviceMfeEnable={window?.mfe?.scmDeviceMfeEnable}>
        <FccInfo productDetailsAemContent={props?.productDetailsAemContent} details={details} />
        <InfoWrapper>
          <Title color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR} bold size='large'>
            {devices.devicename}
          </Title>
          <SkuWrapper>
            {!isBYOD && isShipItToggleOn ? preOrderText : ''}
            {!isBYOD && isShipItToggleOn ? backOrderText : ''}
            {InStockLabel && !isBYOD && !preOrderText && !backOrderText && !ispuToggleOn && (
              <Body
                color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR}
                ariaLabel={InStockLabel === 'Out of Stock' ? 'Out of Stock' : ''}
                role='alert'
                size='large'
              >
                <span role='alert'> {InStockLabel} </span>
              </Body>
            )}
            <FlexRight>
              <Body color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR} size='large' bold>
                SKU#: {devices.sku}
              </Body>
            </FlexRight>
          </SkuWrapper>
          <SkuWrapper>
            {isVbg() && isVbgnsaDropshipFFlag() && isDropshipSku(selectedSku) && (
              <Body color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR} size='large'>
                <TrailingTooltip
                  typographySize="large"
                  typographyPrimitive="p"
                  typographyType="body"
                  tooltipSize="small"
                  tooltipContent={DROPSHIP_DEVICE_TOOLTIP}
                  bold={false}
                  surface="light"
                >
                  Drop-ship SKU
                </TrailingTooltip>
              </Body>
            )}
          </SkuWrapper>

          <FlexRight>
            <PaddingTop16>
              <ModelWrap
                toggleButton={
                  <TextLink
                    data-testid='deviceLockPolicy'
                    type='standAlone'
                    size='large'
                    surface={isDark ? 'dark' : 'light'}
                    onClick={() => makeOpenViewCall('')}
                  >
                    Important device lock information
                  </TextLink>
                }
                surface='light'
                fullScreenDialog
                disableAnimation={false}
                disableOutsideClick={false}
                closeButton={null}
                ariaLabel='Device Lock Policy Dialogue Box'
                scmDeviceMfeEnable={scmDeviceEnable}
              >
                <Header data={deviceLockHeaderData} closePopup={scmDeviceEnable} />
                <ModalBody>
                  <MarginSides scmDeviceMfeEnable={scmDeviceEnable}>
                    <IDLInfo htmlContent={idlInfo} />
                  </MarginSides>
                </ModalBody>
              </ModelWrap>
            </PaddingTop16>
          </FlexRight>

          {isPreOwnedDevice === true && (
            <PreOwnedDevice
              details={details}
              handlePreOwnedDeviceRadioChangeParent={handlePreOwnedDeviceRadioChangeParent}
              getInventoryStatus={getInventoryStatus}
              setSelectedSku={setSelectedSku}
              setSelectedSize={setSelectedSize}
              setSelectedColor={setSelectedColor}
              doCallGetSkuDetails={doCallGetSkuDetails}
              groupPreOwnedConditionSkus={groupPreOwnedConditionSkus}
            />
          )}
          {(!scmDeviceEnable || (scmUpgradeMfeEnable && !isByodUpdate)) &&
            !isEmpty(deviceColorOptions) &&
            !isEmpty(devices.colorvalue) &&
            !isEmpty(selectedSku?.capacity) &&
            !isEmpty(skusByColor) && <Title size='small' color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR}>Color and storage</Title>}
          {(!scmDeviceEnable || (scmUpgradeMfeEnable && !isByodUpdate)) && (
            <FlexBoxContainerP>
              <Padding8>
                <SkuWrapper>
                  {!isEmpty(deviceColorOptions) && !isEmpty(devices.colorvalue) && (
                    <RadioSwatchGroupWrapper color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR}>
                      <RadioSwatchGroup
                        value={devices?.colorvalue}
                        defaultValue={devices.colorvalue}
                        data={isBYOD || displayIndirectSku ? [defaultColorOption] : [...deviceColorOptions]}
                        onChange={chooseColor}
                      />
                    </RadioSwatchGroupWrapper>
                  )}
                  <ColorTextLinkWrapper>
                    {!isIpad() && displayColorLink() && showCopyPasteIcon && (
                      <div
                        role='button'
                        tabIndex='0'
                        onClick={() => {
                          navigator.clipboard.writeText(formattedColorNames);
                          displayBanner();
                        }}
                        onKeyDown={() => {
                          navigator.clipboard.writeText(formattedColorNames);
                          displayBanner();
                        }}
                      >
                        <Icon name='duplicate' size='large' title='Copy color(s)' />
                      </div>
                    )}
                  </ColorTextLinkWrapper>
                </SkuWrapper>
              </Padding8>
            </FlexBoxContainerP>
          )}

          {(!scmDeviceEnable || scmUpgradeMfeEnable) && !isEmpty(selectedSku?.capacity) && !isEmpty(skusByColor) && (
            <HorizontalLine />
          )}
          {(!scmDeviceEnable || (scmUpgradeMfeEnable && !isByodUpdate)) && (
            <StorageCapacityWrapper>
              {!isEmpty(selectedSku) && !isEmpty(skusByColor) && (
                <SizeSelector
                  selectedSku={selectedSku}
                  skus={skusByColor}
                  selectedSize={selectedSize}
                  isBYOD={isBYOD}
                  isIndirectScan={displayIndirectSku}
                  chooseSize={chooseSize}
                />
              )}
            </StorageCapacityWrapper>
          )}
          {((!scmDeviceEnable || (scmUpgradeMfeEnable && !isByodUpdate)) && selectedSku?.skuFilters?.band) && (
            <>
              <HorizontalLine />
              <SmartWatchOptions
                selectedSku={selectedSku}
                chooseSWBand={chooseSWBand}
                chooseSWBandSize={chooseSWBandSize}
                selectedColor={selectedColor}
                doCallGetSkuDetails={doCallGetSkuDetails}
                details={details}
                groupBySmartWatchBand={groupBySmartWatchBand}
              />
            </>
          )}
          {/* Indirect channel payment options */}
          {isIndirect &&
            !isPrePay &&
            !showPrice &&
            !props.isDWOS &&
            !isDwos &&
            !isPastbalPreBackOrder &&
            !(isBBYLocalOrder && bestBuyIntegrationFFlag === 'TRUE') && (
              <>
                {!(isActiveNewLine && isByodUpdate) && <HorizontalLine />}
                <IndirectPaymentOptions
                  setSelectedPaymentInfo={setSelectedPaymentInfo}
                  selectedPaymentInfo={selectedPaymentInfo}
                  customerProfileDetails
                  productDetails={productDetails}
                  isAddEdgeUpSuccess={filteredLineFromCart?.edgeUpDetail}
                  selectedSku={selectedSku}
                  isBYOD={isBYOD}
                  isIndirect={isIndirect}
                  fullFillment={fullFillment}
                  lineActivityTypeFromCart={props?.lineActivityType}
                  isDpVisible={isVisible('DP')}
                  selectPayment={selectPayment}
                  isNewLine={isActiveNewLine}
                  isFromCPE={isFromCPE}
                  isByodUpdate={isByodUpdate}
                  isLocal={isLocal}
                  showDPOptions={showDownPaymentOptions(
                    isDpInVisible,
                    dppIndicatorValue,
                    props?.isDeclineBuyout,
                    isBuyOutToggleOn,
                  )}
                />
              </>
            )}

          {(!isIndirect || isBBYLocalOrder) && (
            <DivWrapper>
              {((!isFromCPE || (isFromCPE && isWSAPCpeError && isRetail())) &&
                !isByodUpdate &&
                (isPrePayCart || ispuToggleOn || !isVisible())) ||
              (!isBYOD &&
                displayPaymentOptions() &&
                isInStock &&
                displayPaymentRadio &&
                bestBuyIntegrationFFlag !== 'TRUE' &&
                !isBBYLocalOrder) ||
              (bestBuyIntegrationFFlag === 'TRUE' &&
                isBBYLocalOrder &&
                BByPricing &&
                Object.keys(BByPricing).length > 0 &&
                !hasBByPricingError &&
                !bbyPricingDetailsResult?.isError &&
                displayPaymentOptions()) ||
              (bestBuyIntegrationFFlag === 'TRUE' && !isBBYLocalOrder) ? (
                <>
                {professionalInstallNotification(devices) && (
                    <Notification
                      type="info"
                      title="Device requires a professional indoor or outdoor setup."
                      subtitle="Device will require assistance by a Verizon tech assistant when installing."
                      fullBleed={false}
                      inline={false}
                      disableFocus
                      hideCloseButton
                    />
                  )}
                  <HorizontalLine />
                  <div className='Grid Grid--gapless paymentOptions' style={{ position: 'relative', zIndex: 0 }}>
                    <Padding8>
                      <PaddingBot24>
                        <Title size='small' color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR}>Payment options</Title>
                      </PaddingBot24>
                      <PaymentOptionsSubtextWrapper data-testid='recommandedSubTextWrapper'>
                        {displayPaymentOptions()?.map((paymentItem) => (
                          <span className='recommandedSubText' key={paymentItem?.id}>
                            {paymentItem?.id?.includes('vvcPaymentOption') && `Recommended`}
                          </span>
                        ))}
                      </PaymentOptionsSubtextWrapper>
                      <PaymentOptionsWrapper>
                        <RadioBoxGroup
                          onChange={handlePaymentSelection}
                          defaultValue={
                            dppIndicatorValue && dppIndicatorFFlag === 'TRUE'
                              ? `$${selectedSku?.price?.fullRetailPrice?.originalPrice}`
                              : radioboxGroupDefaultValue()
                          }
                          value={
                            dppIndicatorValue && dppIndicatorFFlag === 'TRUE'
                              ? `$${selectedSku?.price?.fullRetailPrice?.originalPrice}`
                              : `$${selectedPaymentInfo?.price}${radioboxValueSuffix(selectedPaymentInfo)}`
                          }
                          orientation='horizontal'
                          data={displayPaymentOptions()}
                        />
                      </PaymentOptionsWrapper>
                      {!isVbgFlag &&
                      <PaymentOptionsSubtextWrapper data-testid='PaymentSubTextWrapper'>
                        {displayPaymentOptions()?.map((paymentItem) => (
                          <PaymentSubText key={paymentItem?.id}>
                            {(paymentItem?.id?.includes('DEVICE_PAYMENT') ||
                              paymentItem?.id?.includes('vvcPaymentOption')) &&
                              `${paymentItem?.aprRate}% APR with ${paymentItem?.term} month financing`}
                          </PaymentSubText>
                        ))}
                      </PaymentOptionsSubtextWrapper>}
                    </Padding8>
                  </div>
                  {isVbg() && <PaymentOptionsDisclaimer dpEligibilityResult={dpEligibilityResult} selectedSku={selectedSku?.price} />} 

                </>
              ) : (
                !isByodUpdate &&
                isFromCPE &&
                !isWSAPCpeError && (
                  <>
                    <HorizontalLine />
                    <div className='Grid Grid--gapless u-paddingYMedium'>
                      <RadioButtonStyle>
                        <RadioButtonGroup
                          defaultValue='MONTH_TO_MONTH'
                          // onChange={selectByodCpePaymentOption()}
                          data={
                            !(
                              isPrePayCart && customerProfileDetails?.customer?.customerAttributes?.customerType !== 'N'
                            ) && getByodCpePaymentOptions()
                          }
                        />
                      </RadioButtonStyle>
                    </div>
                  </>
                )
              )}
            </DivWrapper>
          )}

          {/* <Padding8>{!isFromCPE && <Line type='secondary' surface='light' />}</Padding8> */}

          <Padding16>
            <Line type='secondary' surface='light' />
          </Padding16>
          {isPreOrder && isPreorderCountDownEnabled?.toLowerCase() === 'true' && (
            <CountdownTimer
              product={details}
              isPreOrder={isPreOrder}
              defaultSkuPreOrderFlag={defaultSkuPreOrderFlag}
              disableAddToCart={disableAddToCart}
              fromGW={false}
              isPreorderTestingEnabled={isPreorderTestingEnabled}
              isPrePay={isPrePay}
            />
          )}

          {/* {isOmniCare && isBYOD && !isFromCPE && <OmniCareDropDownOptions />} */}
          {isOmniCare && isBYOD && (!isFromCPE || isEditAndView) && (
            <OmniCareDropDownOptions
              handleDeviceIdSkuHandler={handleDeviceIdSkuHandler}
              customerProfileDetails={customerProfileDetails}
              cartDetails={cartDetails}
              activeMtn={activeMtn}
              isShowGetESIM={showGetESimInOption}
              simFromFilteredCartLine={simFromFilteredCartLine}
              removeSimOnlyChange={removeSimOnlyChange}
              SkuDetailsResult={SkuDetailsResult}
            />
          )}

          {isVisible() &&
            !isDwos &&
            !isSecondNumberFlow &&
            ((!isShipItToggleOn && !ispuToggleOn && !ispuFromCart) ||
              isByodUpdate ||
              (channel?.includes('OMNI-INDIRECT') && !props?.isFullFillment && !isShipItToggleOn && !ispuToggleOn) ||
              isFromCPE ||
              (isLocal && !isShipItToggleOn && !ispuToggleOn && !ispuFromCart) ||
              isBBYLocalOrder) && (
              <>
                <DeviceSimID
                  omnicaredropdownValue={omnicaredropdownValue}
                  lineActivityType={props?.lineActivityType}
                  deviceIdSelected={deviceIdSelected}
                  deviceFromFilteredCartLine={deviceFromFilteredCartLine}
                  simFromFilteredCartLine={simFromFilteredCartLine}
                  lineDeviceIdFromLanding={lineDeviceIdFromLanding}
                  lineSimIdFromLanding={lineSimIdFromLanding}
                  updateSearchedSku={props.updateSearchedSku}
                  isNewLine={isNewLine}
                  landing={props.landing}
                  isVideoAssistFlow={isVideoAssistFlow}
                  activeMtn={activeMtn}
                  isDWOS={props.isDWOS}
                  isIndirect={props.isIndirect}
                  compatibleSims={compatibleSims}
                  isBYODUpdateAALRetail={props.isBYODUpdateAALRetail}
                  sku={selectedSku && selectedSku.sorId}
                  byodDevice={isFromCPE && props.byodDevice ? props.byodDevice : {}}
                  isByodUpdate={isByodUpdate}
                  deviceFromCart={props.deviceFromCart}
                  updateSimInventoryInStock={props.updateSimInventoryInStock}
                  isLocal={isLocal}
                  isFromCPE={isFromCPE}
                  defaultDeviceId={props.defaultDeviceId}
                  defaultSimId={defaultSimId}
                  customerProfileDetails={customerProfileDetails}
                  showScanner={props.showScanner}
                  updateDeviceId={props.updateDeviceId}
                  updateSimId={props.updateSimId}
                  updateShowISPUForVA={props.updateShowISPUForVA}
                  showISPUForVA={props.showISPUForVA}
                  simSwapFlowUpdateButtonDisabled={simSwapFlowUpdateButtonDisabled}
                  cartDetails={props.cartDetails}
                  updateDeviceData={props.updateDeviceData}
                  setEnableBYODbtn={setEnableBYODbtn}
                  setDisableUpdateButton={setDisableUpdateButton}
                  setSimIdResult={setSimIdResult}
                  isPaymentOptionVisible={isPaymentOptionVisible}
                  setMitekIdVerifyStatus={props?.setMitekIdVerifyStatus}
                  isSecNumValidation={isSecNumValidation}
                  pairedMtn={pairedMtn}
                  isSimultaneousUpgrade={isSimultaneousUpgrade}
                  setIsSecNumValidation={setIsSecNumValidation}
                  setSecondNumDeviceId={setSecondNumDeviceId}
                  setSecondNumSimId={setSecondNumSimId}
                  secondNumSimId={secondNumSimId}
                  setIncompatibleSim={setIncompatibleSim}
                  incompatibleSim={incompatibleSim}
                  ispuToggleOn={ispuToggleOn}
                  ispuSim={ispuSim}
                  setPreviousIspuSim={setPreviousIspuSim}
                  previousIspuSim={previousIspuSim}
                  isNewlyAddedLine={props?.isNewlyAddedLine}
                  setUpcCodeFromPdpScan={props?.setUpcCodeFromPdpScan}
                  upcCodeFromPdpScan={props?.upcCodeFromPdpScan}
                  isBBYLocalOrder={isBBYLocalOrder}
                  isActiveNewLine={isActiveNewLine}
                  getBestBuyPricingDetails={getBestBuyPricingDetails}
                  setBByPricing={setBByPricing}
                  skuRealAgentCode={skuRealAgentCode}
                  UpcCodeData={UpcCodeData}
                  setUpcAndDeviceIdCheckEnabled={setUpcAndDeviceIdCheckEnabled}
                  setIsDevicePricingApiCallEnable={setIsDevicePricingApiCallEnable}
                  simSwapNotificationHighRiskMsg={simSwapNotificationHighRiskMsg}
                  setCarrierLockDisableButton={setCarrierLockDisableButton}
                  callESimApi={callESimApi}
                  setCallESimApi={setCallESimApi}
                  setShowGetESimInOption={setShowGetESimInOption}
                  setRemoveSimOnlyChange={setRemoveSimOnlyChange}
                  SkuDetailsResult={SkuDetailsResult}
                  selectedSku = {selectedSku}
                  setIsESimRegenerated={props?.setIsESimRegenerated}
                />
                <Padding16>
                  <Line type='secondary' surface='light' />
                </Padding16>
              </>
            )}
          {!isBYOD && props?.PdpBuyoutToggle && props?.isBuyoutEligible && displayBuyoutDetails(props?.buyOutDetail)}
          {!isDwos && (
            <FlexBoxContainerP
              data-testid='testDeviceProtection'
              {...(!selectedProtectionFeature?.displayName && { 'data-track': 'PDP_DP_N/A' })}
              onClick={editable === false ? null : () => handleDeviceProtection()}
            >
              <Title color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR} size='small'>
                Device protection
              </Title>
              <FlexAlignCenterBox>
                <PaddingRight16
                  style={{
                    cursor: editable === false ? 'not-allowed' : 'pointer',
                  }}
                >
                  <Body color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR} size='large' bold>
                    {selectedProtectionFeature?.displayName && selectedProtectionFeature?.displayName !== ''
                      ? selectedProtectionFeature?.displayName
                      : 'N/A'}
                  </Body>
                </PaddingRight16>
                <Icon surface={isDark ? 'dark' : 'light'} name='right-caret' size='large' />
                <div
                  style={{
                    visibility: showDeviceProtectionModal ? 'visible' : 'none',
                  }}
                >
                  {showDeviceProtectionModal && !isFiveG && (
                      <DeviceInsurance
                        protectionFeatures={protectionFeatures?.payload}
                        showCaseFeatures={protectionFeatures?.payload?.features}
                        selectedProtectionFeature={selectedProtectionFeature}
                        showDeviceProtectionModal={showDeviceProtectionModal}
                        isTMPScreenOpen={isTMPScreenOpened}
                        protectionShownStatusInDevice={protectionShownStatusInDevice}
                        tmpLinkClicked={tmpLinkClicked}
                        deviceName={devices.devicename}
                        isByodUpdate={isByodUpdate}
                        setEnableBYODbtn={setEnableBYODbtn}
                        cartDetails={cartDetails}
                        activeMtn={activeMtn}
                        customerType={orderDetails?.customerType}
                      />
                  )}
                </div>
              </FlexAlignCenterBox>
            </FlexBoxContainerP>
          )}
          {!rfexOnProfileFlow && (
            <>
              {(displayIspuToggle || displayShipItToggle) && !isDwos && (
                <Padding16>
                  <Line type='secondary' surface='light' />
                </Padding16>
              )}
              {(!scmDeviceEnable || (scmUpgradeMfeEnable && !isByodUpdate)) && (
                <FlexBoxContainerP>
                  {(showISPUToggle) && (
                    <FlexBoxContainerP style={showShipItOption ? {} : instorePickupStyle}>
                      <Title color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR} size='small'>
                        In store pickup
                      </Title>
                      <div data-testid='ispuToggle' style={{ display: 'flex', flexDirection: 'column' }}>
                        {(selectedSku?.isInstorePickup && !isFromCPE && !isBYOD && !isPreOrder) ||
                        getIspuSimEnable(omnicaredropdownValue) ? (
                          <IspuWrapper>
                            <Toggle
                              ariaLabel='In store pickup'
                              role='checkbox'
                              disabled={isSecondNumberFlow || ispuDisable}
                              data-track={ispuToggleOn || ispuFromCart ? 'inStorePickup_OFF' : 'inStorePickup_ON'}
                              showText={false}
                              value='default'
                              onChange={changeIspuToggleState}
                              on={ispuToggleOn || ispuFromCart || queryParamIspu}
                              surface={isDark ? 'dark' : 'light'}
                            />
                            {((ispuToggleOn && selectedSku?.isInstorePickup && !isFromCPE) ||
                              (isFromCPE && isTelesales() && ispuToggleOn) ||
                              ispuFromCart) && (
                              <TextLink
                                type='standAlone'
                                surface={isDark ? 'dark' : 'light'}
                                disabled={false}
                                onClick={navigateToIspu}
                                onKeyPress={navigateToIspu}
                              >
                                Check availability
                              </TextLink>
                            )}
                          </IspuWrapper>
                        ) : (
                          <Body color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR} size='large' bold>
                            <u>Not eligible for in store pickup</u>
                          </Body>
                        )}
                      </div>
                    </FlexBoxContainerP>
                  )}
                  {displayShipItToggle && !isBBYLocalOrder && !isDwos && (
                    <FlexBoxContainerP style={isVbgFlag || isVbgProfessionalInstall ? { justifyContent: 'flex-end', width: '100%'} : {}}>
                      <Title color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR} size='small'>
                        Ship this device
                      </Title>
                      <RestrictWrapper disableShipIttoogle={disableShipIttoogle} localOnlyLocation={localOnlyLocation}>
                        <Toggle
                          name='shipit toggle'
                          disabled={disableShipIttoogle}
                          showText={false}
                          value='default'
                          data-track={!isShipItToggleOn ? 'shipThisDevice_ON' : 'shipThisDevice_OFF'}
                          onChange={changeShipItToggleState}
                          on={isShipItToggleOn}
                          surface={isDark ? 'dark' : 'light'}
                        />
                      </RestrictWrapper>
                    </FlexBoxContainerP>
                  )}
                </FlexBoxContainerP>
              )}
            </>
          )}
          {showDeviceModal ? (
            <ISPUPage
              onBack={backAction}
              devices={devices}
              chooseColor={chooseColor}
              ProductDetails={details}
              showDeviceModal={showDeviceModal}
              setShowDeviceModal={setShowDeviceModal}
              deviceColorOptions={deviceColorOptions}
              cartDetails={props.cartDetails}
              customerProfileDetails={customerProfileDetails}
              selectedSku={selectedSku}
              setIsIspuItemInCart={setIsIspuItemInCart}
              setSelectedStore={setSelectedStore}
              chooseSize={chooseSize}
              setIspuToggleOn={setIspuToggleOn}
              storeList={storeList}
              setStoreList={setStoreList}
              setShowOnlyAvailableStores={setShowOnlyAvailableStores}
              showOnlyAvailableStores={showOnlyAvailableStores}
              ispuSim={ispuSim}
              isBYOD={isBYOD}
              setIspufromCart={setIspufromCart}
              activeMtn={activeMtn}
              bbyPricingDetailsResult={bbyPricingDetailsResult}
              handleBestBuyPricingDetails={handleBestBuyPricingDetails}
              setIsDevicePricingApiCallEnable={setIsDevicePricingApiCallEnable}
              isBBYLocalOrder={isBBYLocalOrder}
              BbyLocalOrderLocDetailsRequest={props.BbyLocalOrderLocDetailsRequest}       
              BbyLocalOrderLocDetailsApiResponse={props.BbyLocalOrderLocDetailsApiResponse}
            />
          ) : null}
          {monthlyPaymentModal && (
            <MonthlyPayment
              opened={monthlyPaymentModal}
              CustomerData={customerProfileDetails.customer}
              onClose={closeMonthlyPaymentModel}
            />
          )}
          {showBuyoutDetails && (
            <BuyoutAmount
              opened={showBuyoutDetails}
              closeBuyoutModel={closeBuyoutModel}
              isClose
              buyAmountMessage={props.buyAmountMessage}
              totalBuyoutAmount={props.totalBuyoutAmount}
              buyoutMtn={activeMtn}
              isPreOrder={props.isPreOrder}
              isBackorder={props.isBackorder}
            />
          )}
          {showDeclinePopUp && (
            <ConfirmationDialogBox
              message='Removing buyout payment will require full retail pricing payment option.'
              btnYesText='Yes'
              btnNoText='No'
              isNoBtnDisabled={false}
              handleConfirmationDialogBoxClick={(val) => {
                handleConfirmationDecline(val);
              }}
            />
          )}

          {(isNumberShareMandatory || isNumberShareCapable) && (
            <>
              <Padding16>
                <Line type='secondary' surface='light' />
              </Padding16>
              <FlexBoxContainer>
                <Title color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR} size='small'>
                  Shared Number
                </Title>
                <FlexAlignCenterBox>
                  <PaddingRight16>
                    <Body color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR} size='large'>
                      {getSharedNumber()}
                    </Body>
                  </PaddingRight16>
                  <SelectHostNum>
                    <Toggle
                      name='numbershare toggle'
                      disabled={isNumberShareMandatory}
                      showText={false}
                      value='off'
                      on={isNumberShare}
                      data-testid='NumShaToggle'
                      onChange={() => {
                        toggleNumberShare(!isNumberShare);
                      }}
                      surface={isDark ? 'dark' : 'light'}
                    />
                  </SelectHostNum>

                  <div
                    role='button'
                    tabIndex='0'
                    data-testid='sharedNumSharIcon'
                    onClick={() => showNumberShareModalHandler()}
                    onKeyDown={() => onKeyDownHandler()}
                  >
                    <Icon surface={isDark ? 'dark' : 'light'} name='right-caret' size='large' />
                  </div>
                  {showNumberShareModal && (
                    <>
                      <NumberSharedModal
                        numberShareDetails={numberShareDetails}
                        opened={showNumberShareModal}
                        closeClickHandler={() => setShowNumberShareModal(false)}
                        updateNumberShareValue={updateNumberShareValue}
                        numberShareValue={numberShareValue}
                        setEnableBYODbtn={setEnableBYODbtn}
                        onSelectNumberShare={(sharedNumber) => toggleNumberShare(true, sharedNumber)}
                      />
                      <Padding16>
                        <Line type='secondary' surface='light' />
                      </Padding16>
                    </>
                  )}
                </FlexAlignCenterBox>
              </FlexBoxContainer>
            </>
          )}
          {isAsurionCheck && !scmDeviceEnable && (
            <>
              {(!isD2D() || isAsurion()) && (
                <Padding16>
                  <Line type='secondary' surface='light' />
                </Padding16>
              )}
              <FlexBoxContainer>
                <Title size='small'>In-Store Emergency Claim (Asurion Only)</Title>
                <Toggle
                  showText={false}
                  value={upgradeReasonType === 'WP' ? 'on' : 'off'}
                  onChange={toggleCLNR}
                  on={isCLNRon}
                />
              </FlexBoxContainer>
            </>
          )}
          {secondNumberWarningModal && (
            <SecondNumberWarningModal
              pairedMtn={pairedMtn}
              activeMtn={activeMtn}
              handleShopNavigation={handleShopNavigation}
            />
          )}

          {/* Generate ESIM Profile confirm popup */}
          {showGetEsimPopup && (
            <ConfirmationDialogBox
              data-testid='getEsimConfirmationBox'
              message='Do you wish to continue?'
              btnYesText='Yes'
              btnNoText='No'
              handleConfirmationDialogBoxClick={handleEsimCall}
            />
          )}
         
              {
            (isVbgFlag && isAALActivateLaterFFlag && selectedPaymentInfo?.contractType !== CONTRACT_TYPES.DEVICE_PAYMENT &&
              <>
            <Padding16>
              <Line type='secondary' surface='light' />
            </Padding16>
         <FlexBoxContainerP style={{  width: '100%' }}>
                  <Title color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR} size='small'>
                    Activate Later
                  </Title>
                  <RestrictWrapper>
                    <Toggle
                      name={UI_SELECTORS.ACTIVATE_LATER_TOGGLE_NAME}
                      
                      showText={false}
                      value='default'
                      data-track={!isShipItToggleOn ? 'shipThisDevice_ON' : 'shipThisDevice_OFF'}
                      onChange={activateLaterChange}
                      on={isActivateLater}
                      surface={isDark ? 'dark' : 'light'}
                    />
                  </RestrictWrapper>
                </FlexBoxContainerP>
                {isActivateLater &&
                  <ActivateLaterSection>
                    <Notification
                      type='info'
                      title='Activation date can be set with in next 7 days from order date'
                      layout='vertical'
                    />
                    <ActivatedDateListWrapper>
                      {activatedDateList && activatedDateList.map((item) => (
                        <div key={item.date}>
                          <DateItemButtonContainer>
                            <Button size='small' onClick={() => onClickActivatedDate(item.date)} use={item.isSelected ? 'primary' : 'secondary'} >
                              <span>{item.dayName}</span>
                            </Button>
                          </DateItemButtonContainer>
                          <DateItemDate>{item.date}
                          </DateItemDate>
                        </div>
                      ))}

                    </ActivatedDateListWrapper>

                  </ActivateLaterSection>
                }
       </>   
     )
                } 

        </InfoWrapper>
      </RightWrapper>
    </PDPWrapper>
    </>
  );
}
DeviceInfo.propTypes = {
  productDetails: PropTypes.shape({
    deviceProduct: PropTypes.shape({
      productDisplayName: PropTypes.string.isRequired,
    }),
  }),
  customerProfileDetails: PropTypes.shape({
    customer: PropTypes.shape(),
  }),
  cartDetails: PropTypes.shape({}),
  activeMtn: PropTypes.string,
  // upgradeReasonCodes: PropTypes.shape([]),
  protectionFeatures: PropTypes.shape(),
  selectedColor: PropTypes.string,
  setSelectedColor: PropTypes.func,
  ispuToggleOn: PropTypes.bool,
  setIspuToggleOn: PropTypes.func,
  isShipItToggleOn: PropTypes.bool,
  setIsShipItToggleOn: PropTypes.func,
  showISPULocalConflictBanner: PropTypes.func,
  selectedSku: PropTypes.shape(),
  setSelectedSku: PropTypes.func,
  selectedProtectionFeature: PropTypes.shape(),
  setSelectedProtectionFeature: PropTypes.func,
  selectedSize: PropTypes.string,
  setSelectedSize: PropTypes.func,
  setUpgradeReasonType: PropTypes.func,
  isAcssDfillSim: PropTypes.bool,
  isNewlyAddedLine: PropTypes.bool.isRequired,
  showPlanChange: PropTypes.bool,
  setIsESimRegenerated: PropTypes.func,
};
export default DeviceInfo;
