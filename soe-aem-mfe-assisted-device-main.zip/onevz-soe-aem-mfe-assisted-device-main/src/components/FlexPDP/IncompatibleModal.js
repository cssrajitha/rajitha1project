import { useState } from 'react';
import { ButtonGroup } from '@vds/buttons';
import { Modal, ModalTitle } from '@vds/modals';
import { Body } from '@vds/typography';
import { RadioButtonGroup } from '@vds/radio-buttons';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';
import { getUIContextPathBAU } from 'onevzsoemfecommon/Helpers';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { getQueryParamByName } from 'onevzsoemfeframework/DomService';
import { PaddingTop20 } from '../CombinedGridwall/FlexGlobalStyledConstants';
import { updateModalStateCommon } from './pdputils';

const SubStyle = styled.div`
  padding: 1.5rem 0;
`;

const IncompatibleModal = (props) => {
  const [selectedDrop, setSelectedDrop] = useState('selectedDevice');
  const navigate = useNavigate();
  const { showModal, onAddDeviceToCart, setIinEligibleDevice } = props;
  const isFromCPE = getQueryParamByName('isFromCPE');
  const isByodUpdate = getQueryParamByName('isByodUpdate');
  const selectedDropOption = (event) => {
    setSelectedDrop(event.target.value);
  };
  const isDark = (window?.mfe?.scmDeviceMfeEnable && window?.mfe?.isDark) || false;

  const isNewLandingRedesignFlow = () => {
    const [isLandingRedesignFlow, isTysFlow] = getAssistedCradlePropertyV2(['isLandingRedesignFlow', 'isTysFlow']);
    const postPreIndicator = sessionStorage.getItem('newPostToPreIndicator');
    const isCostcoAgent = sessionStorage.getItem('isCostcoAgent');
    if (
      isLandingRedesignFlow === 'TRUE' ||
      JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.isLandingRedesignFlow === 'TRUE'
    ) {
      return !(/true/i.test(isTysFlow) || /true/i.test(postPreIndicator) || /true/i.test(isCostcoAgent));
    }
    return false;
  };
  const compatibleRadioButtons = [
    {
      name: 'group',
      label: 'Continue with selected device',
      children: 'This will drop the selected offer',
      value: 'selectedDevice',
      ariaLabel: 'selectedDevice',
      disabled: false,
    },
    {
      name: 'group',
      label: 'Continue with selected offer',
      children: 'This will drop the selected device. You can select another compatible device with this offer.',
      value: 'selectedOffer',
      ariaLabel: 'selectedOffer',
    },
  ];
  const validateContinue = () => {
    if (selectedDrop === 'selectedDevice') {
      setIinEligibleDevice(false);
      props?.onClose();
      onAddDeviceToCart();
    } else if (isFromCPE || isByodUpdate) {
      if (getQueryParamByName('offerEligible')) {
        navigate(
          `${getUIContextPathBAU()}/combinedgridwall.html?fromPDP=true&activeMtn=${props?.activeMtn}&backfrompdp=true`,
        );
      } else if (isNewLandingRedesignFlow()) {
        navigate(`${getUIContextPathBAU()}/landing.html`);
      } else {
        navigate(`${getUIContextPathBAU()}/home.html`);
      }
    } else navigate(`${getUIContextPathBAU()}/combinedgridwall.html?fromPDP=TRUE&activeMtn=${props?.activeMtn}`);
  };

  const updateModalState = (opened) => {
    updateModalStateCommon(opened, props?.onClose);
  };

  return (
    <div data-testid='ineligibleDevicesModalupdate'>
      <Modal
        onOpenedChange={updateModalState}
        opened={showModal}
        surface={isDark ? 'dark' : 'light'}
        fullScreenDialog={false}
        disableAnimation={false}
        disableOutsideClick
        ariaLabel='Testing Modal'
        width={560}
      >
        <ModalTitle surface={isDark ? 'dark' : 'light'}>The selected device and offer are incompatible</ModalTitle>
        <SubStyle>
          <Body size='large' primitive='p'>
            Please select one from the below options to continue shopping.
          </Body>
        </SubStyle>
        <RadioButtonGroup
          surface={isDark ? 'dark' : 'light'}
          onChange={(e) => selectedDropOption(e)}
          error={false}
          defaultValue='selectedDevice'
          data={compatibleRadioButtons}
        />
        <PaddingTop20>
          <ButtonGroup
            childWidth='100%'
            surface={isDark ? 'dark' : 'light'}
            rowQuantity={{ desktop: 1 }}
            data={[
              {
                children: 'Continue',
                size: 'large',
                use: 'primary',
                width: 'auto',
                disabled: !selectedDrop, //  button is disabled (when no option selected)
                onClick: () => validateContinue(),
              },
            ]}
            alignment='left'
          />
        </PaddingTop20>
      </Modal>
    </div>
  );
};

export default IncompatibleModal;
