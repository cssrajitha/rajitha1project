import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { render, screen } from '../../../modules/test-utils/renderHelper';
import UpgradeReason from './UpgradeReason';
import upgradeReasonCodeMockData from '../__mocks__/upgradeReasonCodeMockData.json';

jest.mock(
  '../../../modules/services/APIService/APIServiceHooks',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('../../../modules/services/APIService/APIServiceHooks'),
      useGetRetrieveURCodeQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                data: {
                  retrieveURCforCartMtnList: {
                    mtnUpgradeReasonCodes: [
                      {
                        mtn: '2405085984',
                        upgradeReasonCodes: [
                          {
                            code: 'EA',
                            description: 'Device Payment Upgrade',
                            contractTermDetails: {
                              contractTerm: 'VERIZON_EDGE',
                            },
                            defaultReasonCode: true,
                          },
                        ],
                      },
                    ],
                  },
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
    };
  },
  { virtual: true },
);

const handlers = [
  rest.post(`*/cartservice/cart/retrieveURC`, (req, res, ctx) => {
    console.log('inside /cartservice/cart/retrieveURC');
    return res(ctx.status(200), ctx.json({ upgradeReasonCodeMockData }));
  }),
];
const server = setupServer(...handlers);

describe('device model component render', () => {
  const handleReasonCode = jest.fn();
  const footerSection = jest.fn();
  const props = {
    retrieveURCforCartMtnList: {
      mtnUpgradeReasonCodes: [
        { upgradeReasonCodes: [{ code: 'EU', description: 'Early Upgrade', defaultReasonCode: true }] },
      ],
    },
    selectedUpgradeReason: 'EU',
  };
  beforeAll(() => {
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
    server.listen();
  });
  afterAll(() => {
    sessionStorage.setItem('APIContext', '');
    //   server.close();
  });
  beforeEach(() => {
    render(<UpgradeReason handleReasonCode={handleReasonCode} footerSection={footerSection} {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('it should mount', () => {
    const upgradeReasonId = screen.getByTestId('upgrade_reason_code');
    expect(upgradeReasonId).toBeInTheDocument();
  });
});

describe('device model component render with Device MFE flag enabled', () => {
  const handleReasonCode = jest.fn();
  const footerSection = jest.fn();
  const props = {
    retrieveURCforCartMtnList: {
      mtnUpgradeReasonCodes: [
        { upgradeReasonCodes: [{ code: 'EU', description: 'Early Upgrade', defaultReasonCode: true }] },
      ],
    },
    selectedUpgradeReason: 'EU',
  };
  beforeAll(() => {
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
    server.listen();
  });
  afterAll(() => {
    sessionStorage.setItem('APIContext', '');
    //   server.close();
  });
  beforeEach(() => {
    window.mfe={scmDeviceMfeEnable: true};
    render(<UpgradeReason handleReasonCode={handleReasonCode} footerSection={footerSection} {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('it should mount', () => {
    const upgradeReasonId = screen.getByTestId('upgrade_reason_code');
    expect(upgradeReasonId).toBeInTheDocument();
  });
});

describe('device model component render with Device MFE flag enabled', () => {
  const handleReasonCode = jest.fn();
  const footerSection = jest.fn();
  const props = {
    retrieveURCforCartMtnList: {
      mtnUpgradeReasonCodes: [
        { upgradeReasonCodes: [{ code: 'EU', description: 'Early Upgrade', defaultReasonCode: true }] },
      ],
    },
    selectedUpgradeReason: 'EU',
  };
  beforeAll(() => {
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
    server.listen();
  });
  afterAll(() => {
    sessionStorage.setItem('APIContext', '');
    //   server.close();
  });
  beforeEach(() => {
    window.mfe={scmDeviceMfeEnable: true, isDark: true};
    render(<UpgradeReason handleReasonCode={handleReasonCode} footerSection={footerSection} {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('it should mount', () => {
    const upgradeReasonId = screen.getByTestId('upgrade_reason_code');
    expect(upgradeReasonId).toBeInTheDocument();
  });
});
