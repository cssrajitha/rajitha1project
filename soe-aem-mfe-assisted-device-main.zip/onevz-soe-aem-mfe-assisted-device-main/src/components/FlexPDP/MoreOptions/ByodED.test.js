import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import ByodED from './ByodED';
import ByodEDUI from './ByodEDUI';

const handlers = [
  rest.post(`*/validateBYODTool`, (req, res, ctx) => {
    console.log('inside /cart/validateBYOD');
    const data = {
      validateBYOD: {
        verizonsDMD: true,
        lostOrStolen: false,
        nonPay: false,
        appleCarrierLock: false,
        fmipLock: false,
        premiumVisualVoiceMail: true,
        voiceOverWifi: true,
        travelPass: '0',
        tradeInValueUpTo: true,
      },
    };
    return res(ctx.status(200), ctx.json(data));
  }),
];

const server = setupServer(...handlers);

describe('device model component render', () => {
  beforeEach(() => {
    render(<ByodED deviceIdNum='12345' />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('ByodEd component shoudl render', () => {
    const ByodEDText = screen.getByText(/Enter the Device ID/i);
    expect(ByodEDText).toBeInTheDocument();
  });
  test('ByodEd component shoudl render', async () => {
    const ByodEd = screen.getByRole('textbox');
    fireEvent.change(ByodEd, { target: { value: '0123456789' } });
    const ByodEDSearch = screen.getByText('Search');
    fireEvent.click(ByodEDSearch);
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });
});

describe('device model component render', () => {
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    render(<ByodED deviceIdNum='12345' />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('ByodEd component shoudl render', () => {
    const ByodEDText = screen.getByText(/Enter the Device ID/i);
    expect(ByodEDText).toBeInTheDocument();
  });
  test('ByodEd component shoudl render', async () => {
    const ByodEd = screen.getByRole('textbox');
    fireEvent.change(ByodEd, { target: { value: '0123456789' } });
    const ByodEDSearch = screen.getByText('Search');
    fireEvent.click(ByodEDSearch);
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });
});

describe('ByodEDUI component render', () => {
  beforeEach(() => {
    render(
      <ByodEDUI
        byodToolData={{
          verizonsDMD: true,
          lostOrStolen: false,
          nonPay: false,
          appleCarrierLock: false,
          fmipLock: false,
          premiumVisualVoiceMail: true,
          voiceOverWifi: true,
          travelPass: 'O',
        }}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('ByodEdUI component should render', () => {
    expect(screen.getByText(/byod validation tool/i)).toBeInTheDocument();
  });
});

describe('ByodEDUI component render', () => {
  beforeEach(() => {
    render(
      <ByodEDUI
        byodToolData={{
          verizonsDMD: false,
          lostOrStolen: true,
          nonPay: true,
          appleCarrierLock: true,
          fmipLock: true,
          premiumVisualVoiceMail: false,
          voiceOverWifi: false,
          travelPass: 'N',
        }}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('ByodEdUI component should render', () => {
    expect(screen.getByText(/byod validation tool/i)).toBeInTheDocument();
  });
});

describe('ByodEDUI component render ACSS isDark and Device flag', () => {
  beforeEach(() => {
    window.mfe={scmDeviceMfeEnable: true, isDark: true};
    render(
      <ByodEDUI
        byodToolData={{
          verizonsDMD: false,
          lostOrStolen: true,
          nonPay: true,
          appleCarrierLock: true,
          fmipLock: true,
          premiumVisualVoiceMail: false,
          voiceOverWifi: false,
          travelPass: 'N',
        }}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('ByodEdUI component should render', () => {
    expect(screen.getByText(/byod validation tool/i)).toBeInTheDocument();
  });
});
