import React from 'react';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { render, screen } from '../../../modules/test-utils/renderHelper';
import IDLInfo from './IDLInfo';

describe('device model component render', () => {
  const props = {
    htmlContent: 'Device Unlocking Policies',
  };
  beforeEach(() => {
    render(<IDLInfo props={props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('IDLInfo component shoudl render', () => {
    const idlInfoId = screen.getByTestId('idlInfo');
    expect(idlInfoId).toBeInTheDocument();
  });
});
