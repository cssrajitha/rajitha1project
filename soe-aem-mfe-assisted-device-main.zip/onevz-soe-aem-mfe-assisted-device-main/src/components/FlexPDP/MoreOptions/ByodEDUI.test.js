import React from 'react';
import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import ByodED from './ByodED';

jest.mock('./ByodEDUI',() => ({ handleByodValidation ,validateByodTool}) => {
    return (<>
      <button
        style={{ height: '150px', width: '300px' }}
        onClick={(_) => handleByodValidation({ target: { value: "12345678901234567" } })}
      >
        Click me
      </button>
      <button
        style={{ height: '150px', width: '300px' }}
        onClick={validateByodTool}
      >
        validateByodTool
      </button>
    </>
    );
  });

describe('device model component render', () => {
  test('ByodEd component should render', async () => {
    render(<ByodED />);
    const button = await screen.findByRole('button', {
      name: /click me/i,
    });
    const button2 = await screen.findByRole('button', {
      name: /validateByodTool/i,
    });
    fireEvent.click(button);
    fireEvent.click(button2);
  });
});
