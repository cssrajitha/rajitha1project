import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import UpgradeReasonRadioGroup from './UpgradeReasonRadioGroup';
import upgradeReasonCodeMockData from '../__mocks__/upgradeReasonCodeMockData.json';

jest.mock(
  '../../../modules/services/APIService/APIServiceHooks',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('../../../modules/services/APIService/APIServiceHooks'),
      useGetRetrieveURCodeQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                data: {
                  retrieveURCforCartMtnList: {
                    mtnUpgradeReasonCodes: [
                      {
                        mtn: '2405085984',
                        upgradeReasonCodes: [
                          {
                            code: 'EA',
                            description: 'Device Payment Upgrade',
                            contractTermDetails: {
                              contractTerm: 'VERIZON_EDGE',
                            },
                            defaultReasonCode: true,
                          },
                        ],
                      },
                    ],
                  },
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
    };
  },
  { virtual: true },
);

// const req = {
//   cartId: '089bf27a-d79a-4580-963f-755a04057cd7',
//   cartMtnList: [{ mtn: '2405085984', deviceSku: 'MU683LL/A', contractType: 'VERIZON_EDGE', reasonCodeType: '' }],
// };
const handlers = [
  rest.post(`*/cartservice/cart/retrieveURC`, (req, res, ctx) => {
    console.log('inside /cartservice/cart/retrieveURC');
    return res(ctx.status(200), ctx.json({ upgradeReasonCodeMockData }));
  }),
];
const server = setupServer(...handlers);

describe('device model component render', () => {
  const handleReasonCode = jest.fn();
  const setSelectedUpgradeReason = jest.fn();
  const setSelectedDescription = jest.fn();
  const setUpgradeReasonType = jest.fn();
  const props = {
    UpgradeReason: [
      {
        code: 'EA',
        description: 'Device Payment Upgrade',
        contractTermDetails: {
          contractTerm: 'VERIZON_EDGE',
        },
        defaultReasonCode: true,
      },
    ],
    defaultCode: {
      code: 'EA',
      description: 'Device Payment Upgrade',
      contractTermDetails: {
        contractTerm: 'VERIZON_EDGE',
      },
      defaultReasonCode: true,
    },
  };

  beforeAll(() => {
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
    server.listen();
  });
  afterAll(() => {
    sessionStorage.setItem('APIContext', '');
    //   server.close();
  });
  beforeEach(() => {
    render(
      <UpgradeReasonRadioGroup
        handleReasonCode={handleReasonCode}
        setSelectedUpgradeReason={setSelectedUpgradeReason}
        setSelectedDescription={setSelectedDescription}
        setUpgradeReasonType={setUpgradeReasonType}
        {...props}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });
  test('it should mount', async () => {
    const upgradeId = screen.getByRole('radiogroup');
    fireEvent.change(upgradeId);
    const upgradeId2 = screen.getByRole('radio', { name: 'radio 0' });
    fireEvent.click(upgradeId2);
  });
});

describe('device model component render', () => {
  const handleReasonCode = jest.fn();
  const setSelectedUpgradeReason = jest.fn();
  const setSelectedDescription = jest.fn();
  const setUpgradeReasonType = jest.fn();
  const props = {
    UpgradeReason: [
      {
        code: 'EA',
        description: '',
        contractTermDetails: {
          contractTerm: 'VERIZON_EDGE',
        },
        defaultReasonCode: true,
      },
      {
        code: 'MN',
        description: '',
        contractTermDetails: {
          contractTerm: 'mock',
        },
        defaultReasonCode: false,
      },
    ],
  };

  beforeAll(() => {
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
    server.listen();
  });
  afterAll(() => {
    sessionStorage.setItem('APIContext', '');
    //   server.close();
  });
  beforeEach(() => {
    render(
      <UpgradeReasonRadioGroup
        handleReasonCode={handleReasonCode}
        setSelectedUpgradeReason={setSelectedUpgradeReason}
        setSelectedDescription={setSelectedDescription}
        setUpgradeReasonType={setUpgradeReasonType}
        {...props}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });
  test('it should mount', async () => {
    const upgradeId = screen.getByRole('radiogroup');
    fireEvent.change(upgradeId);
    const upgradeId2 = screen.getByRole('radio', { name: 'radio 0' });
    const upgradeId3 = screen.getByRole('radio', { name: 'radio 1' });
    fireEvent.click(upgradeId2);
    fireEvent.click(upgradeId3);
  });
});

describe('device model component render', () => {
  const handleReasonCode = jest.fn();
  const setSelectedUpgradeReason = jest.fn();
  const setSelectedDescription = jest.fn();
  const setUpgradeReasonType = jest.fn();
  const props = {
    UpgradeReason: [
      {
        code: 'EA',
        description: '',
        contractTermDetails: {
          contractTerm: 'VERIZON_EDGE',
        },
        defaultReasonCode: true,
      },
    ],
  };

  beforeAll(() => {
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
    server.listen();
  });
  afterAll(() => {
    sessionStorage.setItem('APIContext', '');
    //   server.close();
  });
  beforeEach(() => {
    window.mfe = { scmDeviceMfeEnable: true, isDark: true };
    render(
      <UpgradeReasonRadioGroup
        handleReasonCode={handleReasonCode}
        setSelectedUpgradeReason={setSelectedUpgradeReason}
        setSelectedDescription={setSelectedDescription}
        setUpgradeReasonType={setUpgradeReasonType}
        {...props}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });
  test('it should mount', async () => {
    const upgradeId = screen.getByRole('radiogroup');
    fireEvent.change(upgradeId);
    const upgradeId2 = screen.getByRole('radio', { name: 'radio 0' });
    fireEvent.click(upgradeId2);
  });
});
