import React from 'react';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { render, screen } from '../../../modules/test-utils/renderHelper';
import ComatibleSims from './CompatibleSims';

describe('device model component render', () => {
  const compatibleSimSorIds = [' BULKSIM-TRI-D', ' BULKSIM-TRI-G'];
  beforeEach(() => {
    render(<ComatibleSims compatibleSimSorIds={compatibleSimSorIds} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('CompatibleSim component shoudl render', () => {
    const CompatibleText = screen.getByText(/Compatible SIM's with this device are below/i);
    expect(CompatibleText).toBeInTheDocument();
  });
});

describe('device model component render', () => {
  const compatibleSimSorIds = [' BULKSIM-TRI-D', ' BULKSIM-TRI-G'];
  beforeEach(() => {
    window.mfe={scmDeviceMfeEnable: true, isDark: true};
    render(<ComatibleSims compatibleSimSorIds={compatibleSimSorIds} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('CompatibleSim component shoudl render', () => {
    const CompatibleText = screen.getByText(/Compatible SIM's with this device are below/i);
    expect(CompatibleText).toBeInTheDocument();
  });
});
