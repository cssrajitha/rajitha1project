import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import { getQueryParamByName, isIndirect } from 'onevzsoemfeframework/DomService';
import { isVbg } from 'onevzsoemfeframework/VbgAemUtil';
import { Button } from '@vds/buttons';
// eslint-disable-next-line you-dont-need-lodash-underscore/get
import { get as getProp } from 'lodash';
import { Body, Title } from '@vds/typography';
import { formatDotPhoneNumber, formatCurrency } from 'onevzsoemfecommon/Helpers';
import { useLazyGetFetchDownpaymentQuery, useLazySplitEquallyQuery } from 'onevzsoemfecommon/APIService';
import { RadioBoxGroup } from '@vds/radio-boxes';
import { useDispatch } from 'react-redux';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { FlexAlignCenter, Padding24, PaddingBot24 } from '../../CombinedGridwall/FlexGlobalStyledConstants';
import CurrencyInput from './CurrencyInput';

const MarginSides = styled.div`
  margin: 0 3rem;
`;
const MarginTopBottom = styled.div`
  margin-top: 18px;
  margin-bottom: 6px;
`;
const MarginBottom = styled.div`
  margin-bottom: 6px;
  max-width: 78%;
`;

const DownPaymentBox = styled.div`
  border: 1px solid #979797 !important;
  height: 12 rem;
  // padding; 0.875rem;
`;
const DownPaymentButtons = styled.div`
  [class^='RadioBoxGroupWrapper-'] {
    margin-top: 15px;
  }
  [class^='RadioBoxLabelWrapper-'] {
    margin: 0;
    border: none;
    box-shadow: none;
  }
  [class^='StyledDiv-'] {
    align-items: center;
    background-color: #f6f6f6;
  }
  input[type='radio']:focus + label,
  input[type='radio']:checked + label {
    width: 100%;
    background-color: ${(props) => (props.inputColor ? '#d8dada' : '#f6f6f6')};
  }
  [class^='FlexWrapper-'] {
    justify-content: center;
    font-weight: bold;
  }
  & label::before {
    content: '';
    display: none;
  }
`;
const DeviceTextWrapper = styled.div`
  width: 250px;
`;

const CenterAlign = styled.div`
  text-align: center !important;
  box-sizing: border-box;
  margin-top: 30px;
  padding: 1.3125rem !important;
`;
const PaymentSection = styled.div`
box-sizing: border-box;
display: flex;
justify-content: space-between;
max-width: 100%;
margin: 0px -8px;
padding: 0px;
}
`;
const GrayText = styled.div`
  font-size: 18px;
  color: #747676 !important;
  padding-bottom: 0.75rem;
  max-width: 12rem;
`;
const VzDollarText = styled.div`
  font-size: 18px;
  color: #747676 !important;
  padding: 0 1.3rem 1.3rem 1.3rem;
  font-weight: bold;
`;
const TitleWidth = styled.div`
  width: 154px;
`;
const AmountTextWidth = styled.span`
  font-size: 1rem;
  font-weight: 700;
`;

const RadioBoxGroupWrapper = styled(RadioBoxGroup)`
& > div:nth-child(1){
  & > div{
    background-color: ${(props) => (props.inputColor === '$' ? '#d8dada' : '#f6f6f6')}; !important;
  }
  & input{
    background-color: ${(props) => (props.inputColor === '$' ? '#d8dada' : '#f6f6f6')}; !important;
  }
  & label{
    background-color: ${(props) => (props.inputColor === '$' ? '#d8dada' : '#f6f6f6')}; !important;
  }
}
& > div:nth-child(2){
  & > div{
    background-color: ${(props) => (props.inputColor === '%' ? '#d8dada' : '#f6f6f6')}; !important;
  }
  & input{
    background-color: ${(props) => (props.inputColor === '%' ? '#d8dada' : '#f6f6f6')}; !important;
  }
  & label{
    background-color: ${(props) => (props.inputColor === '%' ? '#d8dada' : '#f6f6f6')}; !important;
  }
}
`;

const ElvisDownPaymentBox = styled.div`
  font-size: 14px;
  color: #747676 !important;
`;

const APRGrayText = styled.div`
  font-size: 14px;
  color: #747676 !important;
  padding-bottom: 0.5rem;
  max-width: 12rem;
`;

const isVbgOrNotElvisFFlag = (elvisFFlag) => isVbg() || !elvisFFlag;
const isNotVbgAndElvisFFlag = (elvisFFlag) => !isVbg() && elvisFFlag;

const renderAprValue = ({ elvisFFlag, aprValue }) =>
  isNotVbgAndElvisFFlag(elvisFFlag) && <APRGrayText>Includes {aprValue ? Math.round(parseFloat(aprValue)) : 0}% APR</APRGrayText>;

const renderAdditionalPaymentText = ({ elvisFFlag }) =>
  (isVbgOrNotElvisFFlag(elvisFFlag)) ? (
    <body size='small'>*Additional down payment may be taken</body>
  ) : (
    <body size='small'>
      *Additional down payment may be taken as a whole dollar amount only
      <br />
      *Can enter only a whole dollar amount without a decimal point as down payment
    </body>
  );

const DownPayment = (props) => {
  const dispatch = useDispatch();
  const {
    manageDownPayment,
    CustomerData,
    orderDetails,
    computeDPPriceBody,
    computeDPPriceResult,
    isDownPaymentAlertNeedToEnable,
    setIsDownPaymentAlertNeedToEnable,
    setDownPaymentObj,
    downPaymentObj,
    customerTypefromCart,
    retailPrice,
  } = props; // need to check
  const { cartId = '', caseId = '', accountNumber = '', lookupMtn = '' } = CustomerData;
  const [splitEquallyData, splitEquallyResponse] = useLazySplitEquallyQuery();
  const [fetchDownPaymentBody, fetchDownPaymentResult] = useLazyGetFetchDownpaymentQuery();
  const [downPaymentData, setDownPaymentData] = useState({});
  const [downPaymentDataNC, setDownPaymentDataNC] = useState({});
  const [dType, setDType] = useState('$');
  const [dPValue, setDPValue] = useState();
  const [originalPrice, setOriginalPrice] = useState('');
  const [downPaymentValue, setDownPaymentValue] = useState('');
  const [sellerPrice, setSellerPrice] = useState('');
  const [verizonDollor, setVerizonDollor] = useState('');
  const [vzlinkClicked, setVzlinkClicked] = useState(false);

  const customerType =
    getQueryParamByName('customerType') || sessionStorage.getItem('customerType') || customerTypefromCart;

  const allowToApplyVZ = isIndirect() && Number(downPaymentData?.vzDollarTotalAmount || 0) > 0; // Only for INDIRECT
  const allowToApplyDevice = isIndirect() && Number(downPaymentData?.totalDeviceDollar || 0) > 0; // Only for INDIRECT

  const splitEqually = () => {
    const isNewCustomer = !!(customerType === 'N');
    const creditAppNumber = sessionStorage.getItem('creditAppNum');
    const splitEquallyBody = {
      cartInfo: {
        clientAppName: 'VZW-NETACE',
        cartId,
        caseId,
        accountNumber,
        cartCreator: isNewCustomer ? creditAppNumber : lookupMtn,
        processingMTN: lookupMtn,
        processStep: 'DownPayment',
        intendType: isNewCustomer ? 'NSE' : 'EUP',
      },
    };
    splitEquallyData({ body: splitEquallyBody });
  };

  const elvisFromSession = sessionStorage.getItem('elvisFFlag');
  const elvisFFlag = /true/i.test(elvisFromSession);

  let sorId = '';
  let selectedSku = {};
  let firstMonthPrice;
  let remainingMonthPrice;
  let price = '';
  let firstPaymentPrice = '';
  let aprValue = '';

  if (props?.selectedSku) {
    selectedSku = props?.selectedSku;

    if (props.selectedSku.sorId) {
      sorId = props?.selectedSku?.sorId;
    }
  }

  const downPaymentToday = (sellerPrice || downPaymentData?.devicePrice) > downPaymentData?.deviceFinanceLimit;
  const RequiredDownPayment = downPaymentToday
    ? parseFloat(sellerPrice || downPaymentData?.devicePrice) - parseFloat(downPaymentData?.deviceFinanceLimit)
    : 0;

  const fetchDownPaymentApi = (originalPriceFromSku, downPayment, dpTerm) => {
    const fetchDownPaymentReq = {
      header: {},
      term: dpTerm,
      sorId,
      downPayment: downPayment || downPaymentValue || 0,
      isPercentage: false,
      agentOrFullRetailPrice: originalPrice || originalPriceFromSku, // need to check this logic in edit scenario
    };
    fetchDownPaymentBody({ body: fetchDownPaymentReq, spinner: false });
  };

  useEffect(() => {
    let contractDuration = '';
    let selectedDownPayment;
    let originalPriceFromSku;
    let downPayment;
    let verizonDollarsDownpayment;
    let UserSellerPrice;
    const selectedNewLineDeviceInfo = getProp(props?.filteredLineFromCart, 'itemsInfo[0].cartItems.cartItem', []).find(
      (cartItem) => cartItem.cartItemType === 'DEVICE',
    );
    console.log(orderDetails, 'props?.filteredLineFromCart');
    if (selectedSku.price?.devicePaymentPrice?.length > 0) {
      originalPriceFromSku = retailPrice || selectedSku?.price?.fullRetailPrice?.originalPrice;
      if (props?.paymentObject?.term) {
        // contractDuration & downPayment values are taken  from selected paymentObject
        selectedDownPayment = selectedSku.price.devicePaymentPrice.filter(
          (devicePaymentPrice) => devicePaymentPrice?.contractDuration === props?.paymentObject?.term,
        );
        if (selectedDownPayment && selectedDownPayment.length > 0) {
          contractDuration = selectedDownPayment[0].contractDuration;
          if (selectedDownPayment[0].dpTermPrices && selectedDownPayment[0].dpTermPrices.downPayment) {
            downPayment = selectedDownPayment[0].dpTermPrices.downPayment;
          } else {
            let userSelectedDownPayment;
            let sellerprice;
            if (props?.filteredLineFromCart?.installmentInfo?.userSelectedDownPayment > 0) {
              userSelectedDownPayment = props?.filteredLineFromCart?.installmentInfo?.userSelectedDownPayment;
            }
            if (selectedNewLineDeviceInfo?.sellerPrice > 0) {
              sellerprice = selectedNewLineDeviceInfo?.sellerPrice;
            }
            downPayment = downPaymentObj?.downPayment ? downPaymentObj?.downPayment : userSelectedDownPayment;
            verizonDollarsDownpayment = downPaymentObj?.verizonDollars
              ? downPaymentObj?.verizonDollars
              : props?.filteredLineFromCart?.installmentInfo?.verizonDollarsDownpayment;
            UserSellerPrice = downPaymentObj?.sellerPrice ? downPaymentObj?.sellerPrice : sellerprice;
          }
        }
      }
    }
    if (orderDetails?.quoteWithoutCredit) {
      if (selectedDownPayment && selectedDownPayment.length > 0) {
        contractDuration = selectedDownPayment[0].contractDuration ? selectedDownPayment[0].contractDuration : '';
        firstMonthPrice =
          selectedDownPayment[0].dpTermPrices && selectedDownPayment[0].dpTermPrices.firstMonthPrice
            ? selectedDownPayment[0].dpTermPrices.firstMonthPrice
            : '';
        remainingMonthPrice = selectedDownPayment[0].dpTermPrices.remainingMonthPrice;
      }
      const fetchDownPaymentResponse = {
        deviceFinanceLimit: '',
        totalFinanceLimit: '',
        sorId,
        firstMonthPrice,
        remaingingMonthPrice: remainingMonthPrice,
        dpTerm: contractDuration,
        downPayment,
        devicePrice: originalPrice || originalPriceFromSku,
        showSellerPrice: false,
        vzDollarTotalAmount: 0.0,
        vzDollarUsedByLine: 0.0,
        vzDollarUsedByAllLines: 0.0,
        discountedPrice: 0.0,
      };
      setDownPaymentDataNC(fetchDownPaymentResponse);
    } else {
      fetchDownPaymentApi(originalPriceFromSku, downPayment, contractDuration);
    }
    setOriginalPrice(originalPriceFromSku);
    setDownPaymentValue(downPayment);
    setVerizonDollor(verizonDollarsDownpayment);
    setSellerPrice(UserSellerPrice);
  }, []);

  /** executes only once feom component did mount */
  // useEffect(() => {
  //   // executes from edit scenario only if user is having downpayment value
  //   if (originalPrice && downPaymentValue && fetchDownPaymentResult?.data?.fetchDownPaymentResponse) fetchComputeDPPriceReq(downPaymentValue);
  // }, [originalPrice]);

  useEffect(() => {
    setDownPaymentData(
      orderDetails?.quoteWithoutCredit
        ? downPaymentDataNC
        : fetchDownPaymentResult?.data?.fetchDownPaymentResponse?.[0],
    );
  }, [fetchDownPaymentResult?.data, downPaymentDataNC]);
  let MaxTotalPrice;
  if (retailPrice && retailPrice > 0) {
    MaxTotalPrice = retailPrice;
  } else if (isIndirect()) {
    MaxTotalPrice = selectedSku?.edgeDeviceCap;
  } else {
    MaxTotalPrice = originalPrice;
  }
  useEffect(() => {
    if (RequiredDownPayment) {
      setDownPaymentValue(RequiredDownPayment);
      setDownPaymentObj((prevState) => ({
        ...prevState,
        downPayment: RequiredDownPayment || 0,
      }));
    }
  }, [RequiredDownPayment]);

  const fetchComputeDPPriceReq = (value = downPaymentValue, fullprice = isIndirect() ? sellerPrice : MaxTotalPrice) => {
    const maxDownPayment = dType === '%' ? 100 : Math.floor(downPaymentData?.devicePrice);
    const errorMsg =
      dType === '%'
        ? 'Please enter a valid downpayment percentage'
        : `Maximum down payment allowed is $${maxDownPayment}`;
    dispatch(appMessageActions.clearAppMessages());
    if (value > maxDownPayment) {
      dispatch(appMessageActions.addAppMessage(errorMsg, '', true, true));
      return '';
    }
    const computeDPPriceReq = {
      sorId,
      mtn: props.mtn,
      term: downPaymentData?.dpTerm,
      downPayment: value !== null ? value : 0,
      isPercentage: dType === '%',
      agentOrFullRetailPrice: fullprice,
    };
    setIsDownPaymentAlertNeedToEnable(true);
    computeDPPriceBody({ body: computeDPPriceReq, spinner: false });
  };

  useEffect(() => {
    if (dPValue && (!isIndirect() || (isIndirect() && sellerPrice))) {
      fetchComputeDPPriceReq(dPValue);
    } else if (isIndirect() && !sellerPrice && dPValue) {
      dispatch(appMessageActions.addAppMessage(`Please enter Seller's price`, '', true, true));
    }
  }, [dType]);

  const maximumDownPayment = MaxTotalPrice - (downPaymentData?.dpTerm || 36) * 0.01;
  const calculateTotalDownPayment =
    parseFloat(downPaymentValue || downPaymentObj?.downPayment || 0) +
    parseFloat(verizonDollor || downPaymentObj?.totalDeviceDollar || 0);
  /* istanbul ignore next */
  const handleDownPayment = (e) => {
    const { value } = e.target;
    const tempValue = value !== '' ? value.replace(/[$%]/g, '') : value;
    const maxPrice = sellerPrice || MaxTotalPrice;
    setDownPaymentValue(tempValue);
    setDownPaymentObj((prevState) => ({
      ...prevState,
      downPayment: tempValue,
    }));
    if (isIndirect() && !sellerPrice) {
      dispatch(appMessageActions.addAppMessage(`Please enter Seller's price`, '', true, true));
    } else if (tempValue > maximumDownPayment) {
      dispatch(
        appMessageActions.addAppMessage(`Maximum down payment allowed is ${maximumDownPayment}`, '', true, true),
      );
      setDPValue('');
      setDownPaymentObj((prevState) => ({
        ...prevState,
        downPayment: '',
        verizonDollars: '',
      }));
      setDownPaymentValue('');
    } else fetchComputeDPPriceReq(calculateTotalDownPayment, maxPrice);
  };

  const handleDownPaymentChange = (e) => {
    const { value } = e.target;
    const tempValue = value !== '' ? value.replace(/[$%]/g, '') : value;
    setDPValue(tempValue);
    setDownPaymentObj((prevState) => ({
      ...prevState,
      downPayment: tempValue,
    }));
    setDownPaymentValue(tempValue);
  };

  const handleSellerPrice = (e) => {
    const { value } = e.target;
    const tempValue = value !== '' ? value.replace(/[$%]/g, '') : value;
    if (parseFloat(tempValue) > parseFloat(MaxTotalPrice)) {
      dispatch(
        appMessageActions.addAppMessage(`Please enter Seller's price lesser than installment price`, '', true, true),
      );
      setDPValue('');
      setDownPaymentObj((prevState) => ({
        ...prevState,
        downPayment: '',
        sellerPrice: '',
        verizonDollars: '',
      }));
      setDownPaymentValue('');
      setSellerPrice('');
    } else {
      setSellerPrice(tempValue);
      setDownPaymentObj((prevState) => ({
        ...prevState,
        sellerPrice: tempValue,
      }));
    }
  };
  /* istanbul ignore next */
  const sellerPriceApi = (e) => {
    const { value } = e.target;
    const tempValue = value !== '' ? value.replace(/[$%]/g, '') : value;
    if (tempValue === '') {
      dispatch(appMessageActions.addAppMessage(`Please enter Seller's price`, '', true, true));
    } else fetchComputeDPPriceReq(calculateTotalDownPayment, tempValue);
  };
  /* istanbul ignore next */
  const vzTextLinkclicked = () => {
    setVzlinkClicked(true);
  };
  /* istanbul ignore next */
  const handleVZDollarDownPayment = (e) => {
    const { value } = e.target;
    const tempValue = value !== '' ? value.replace(/[$%]/g, '') : value;
    setVerizonDollor(tempValue);
    setDownPaymentObj((prevState) => ({
      ...prevState,
      verizonDollars: tempValue,
    }));
  };
  /* istanbul ignore next */
  const handleVZDollarApi = (e) => {
    const { value } = e.target;
    const tempValue = value !== '' ? value.replace(/[$%]/g, '') : value;
    console.log(tempValue, 'downPaymentObj', downPaymentObj);
    fetchComputeDPPriceReq(calculateTotalDownPayment, sellerPrice);
  };
  /* istanbul ignore next */
  useEffect(() => {
    if (computeDPPriceResult?.isSuccess && isDownPaymentAlertNeedToEnable && calculateTotalDownPayment) {
      dispatch(
        appMessageActions.addAppMessage(
          `${formatCurrency(computeDPPriceResult?.data?.downPayment)} down payment added`,
          'success',
          true,
          true,
        ),
      );
    } else if (computeDPPriceResult?.error && isDownPaymentAlertNeedToEnable) {
      dispatch(
        appMessageActions.addAppMessage(`${computeDPPriceResult?.error?.data?.errors[0]?.message}`, '', true, true),
      );
      setDownPaymentObj((prevState) => ({
        ...prevState,
        downPayment: '',
      }));
    }
    setIsDownPaymentAlertNeedToEnable(false);
  }, [computeDPPriceResult?.data?.downPayment]);

  const firstMonthPriceVal = computeDPPriceResult?.data?.remainingMonthPrice;
  const firstPaymentVal = computeDPPriceResult?.data?.firstMonthPrice;
  if (firstMonthPriceVal) {
    price = firstMonthPriceVal;
  } else {
    price = downPaymentData?.remaingingMonthPrice;
  }
  if (firstPaymentVal) {
    firstPaymentPrice = firstPaymentVal;
  } else {
    firstPaymentPrice = downPaymentData?.firstMonthPrice;
  }

  if (computeDPPriceResult?.data?.loanOfferDetails?.annualPercentageRate) {
    aprValue = computeDPPriceResult?.data?.loanOfferDetails?.annualPercentageRate;
  } else {
    aprValue = downPaymentData?.loanOfferDetails?.annualPercentageRate;
  }

  useEffect(() => {
    if (computeDPPriceResult?.data?.downPayment) {
      setDownPaymentObj((prevState) => ({
        ...prevState,
        downPayment: computeDPPriceResult?.data?.downPayment || 0,
      }));
    }
  }, [computeDPPriceResult]);
  const downtype = (e) => {
    setDType(e.target.value);
  };
  console.log('fixing for lint issues', splitEquallyResponse?.data?.data);
  /* istanbul ignore next */
  return (
    <MarginSides>
      <div>
        <div>
          {manageDownPayment && manageDownPayment === 'true' && (
            <div>
              <div style={{ marginTop: '50px' }}>
                {' '}
                Add $XX.XX in down payments to stay under the total finance limit.
              </div>
              <div style={{ marginTop: '35px' }}>
                <Button data-track='Split equally' data-testid='splitEqually' onClick={() => splitEqually()}>
                  <span>Split equally</span>
                </Button>
              </div>
            </div>
          )}
          {/* <div className='Grid Grid--gapless'>{this.getDPLines()}</div> */}
        </div>
      </div>
      <>
        <FlexAlignCenter>
          <Body size='large'>
            Device Finance Limit:{' '}
            {formatCurrency(downPaymentData?.deviceFinanceLimit ? downPaymentData?.deviceFinanceLimit : 0)}
          </Body>
          <Body size='large'>
            Total Finance Limit Remaining:{' '}
            {formatCurrency(downPaymentData?.totalFinanceLimit ? downPaymentData?.totalFinanceLimit : 0)}
          </Body>
          {customerType !== 'N' && (allowToApplyVZ || allowToApplyDevice) && (
            <Body size='large'>
              Available VZ Dollars:{' '}
              {formatCurrency(downPaymentData?.vzDollarTotalAmount ? downPaymentData?.vzDollarTotalAmount : 0)}
            </Body>
          )}
          <div />
        </FlexAlignCenter>
        <DeviceTextWrapper>
          <MarginTopBottom>
            <Body size='large' bold>
              {props?.mtn ? `Line ${formatDotPhoneNumber(props?.mtn)}` : ''}
            </Body>
            {/* remove hardcode value (true) */}
          </MarginTopBottom>
          <MarginBottom>
            <Body size='large'> {`${props?.selectedSku?.skuDisplayName}(${props?.selectedSku?.sorId})`} </Body>
          </MarginBottom>
        </DeviceTextWrapper>
        <PaymentSection>
          {isIndirect() ? (
            <MarginTopBottom>
              <DownPaymentBox>
                <Padding24>
                  <Body size='small'>Sellers Price</Body>
                  <CurrencyInput
                    type='text'
                    width='240px'
                    name='sellerprice'
                    value={sellerPrice}
                    placeholder='$'
                    onBlur={(e) => sellerPriceApi(e)}
                    onChange={(e) => handleSellerPrice(e)}
                    style={{
                      width: '150px',
                      height: '40px',
                      fontSize: 'large',
                    }}
                  />
                </Padding24>
              </DownPaymentBox>
              <MarginTopBottom>
                <Body size='medium' bold>
                  Inst.max {formatCurrency(MaxTotalPrice)}
                </Body>
              </MarginTopBottom>
            </MarginTopBottom>
          ) : (
            <MarginTopBottom>
              <MarginBottom>
                <Title size='small'>${downPaymentData?.devicePrice ? downPaymentData?.devicePrice : retailPrice}</Title>
              </MarginBottom>
              <GrayText>Device Payment retail price</GrayText>
            </MarginTopBottom>
          )}
          <CenterAlign>
            <Title size='small' bold>
              -
            </Title>
          </CenterAlign>
          <MarginTopBottom>
            {customerType !== 'N' && allowToApplyVZ && (
              <>
                <GrayText>Total down payment</GrayText>
                <Title size='small'>{formatCurrency(calculateTotalDownPayment || 0)}</Title>
                <PaddingBot24 />
              </>
            )}
            {(isVbgOrNotElvisFFlag(elvisFFlag)) && (
              <DownPaymentBox>
                <Padding24>
                  <Body size='small'>Down payment</Body>
                  <CurrencyInput
                    type='text'
                    width='15rem'
                    name='price'
                    value={downPaymentValue}
                    placeholder={dType === '$' ? '$0.00' : '0.00%'}
                    onBlur={(e) => handleDownPayment(e)}
                    onChange={(e) => handleDownPaymentChange(e)}
                    maskOptions={{
                      prefix: dType === '%' ? '' : '$',
                      suffix: dType === '%' ? '%' : '',
                    }}
                    style={{
                      width: '15rem',
                      height: '40px',
                      fontSize: 'x-large',
                    }}
                  />
                  <DownPaymentButtons inputColor={dType}>
                    <RadioBoxGroupWrapper
                      inputColor={dType}
                      childWidth='200px'
                      defaultValue='$'
                      orientation='horizontal'
                      transparentBackground
                      onChange={downtype}
                      data={[
                        {
                          id: 'pricedownpayment',
                          text: '$',
                          value: '$',
                          name: 'RadioBoxGroup',
                        },
                        {
                          id: 'percentdownpayment',
                          text: '%',
                          value: '%',
                          name: 'RadioBoxGroup',
                        },
                      ]}
                    />
                  </DownPaymentButtons>
                </Padding24>
                {customerType !== 'N' && allowToApplyVZ && !vzlinkClicked && !verizonDollor && (
                  <VzDollarText onClick={vzTextLinkclicked}>
                    <u>Apply Verizon Dollors</u>
                  </VzDollarText>
                )}
                {allowToApplyVZ && (vzlinkClicked || verizonDollor) && (
                  <VzDollarText>
                    <GrayText>Verizon Dollar</GrayText>
                    <CurrencyInput
                      data-testid='verizonDollar'
                      type='text'
                      width='15rem'
                      name='price'
                      value={verizonDollor}
                      onBlur={(e) => handleVZDollarApi(e)}
                      onChange={(e) => handleVZDollarDownPayment(e)}
                      style={{
                        width: '15rem',
                        height: '40px',
                        fontSize: 'x-large',
                      }}
                    />
                  </VzDollarText>
                )}
              </DownPaymentBox>
            )}
            {isNotVbgAndElvisFFlag(elvisFFlag) && (
              <ElvisDownPaymentBox>
                <GrayText>Down payment</GrayText>
                <CurrencyInput
                  type='text'
                  width='15rem'
                  name='price'
                  value={downPaymentValue}
                  placeholder={dType === '$' ? '$0' : ''}
                  onBlur={(e) => handleDownPayment(e)}
                  onChange={(e) => handleDownPaymentChange(e)}
                  maskOptions={{
                    prefix: dType === '$' ? '$' : '',
                  }}
                  elvisFFlag={elvisFFlag}
                  style={{
                    width: '15rem',
                    height: '40px',
                    fontSize: 'x-large',
                    border: '2px solid #747676 !important',
                  }}
                />
              </ElvisDownPaymentBox>
            )}
            <MarginTopBottom>
              <Title size='small' primitive='span'>
                {isIndirect() ? 'Required:' : 'Device payment due today:'} {formatCurrency(RequiredDownPayment)}{' '}
              </Title>
            </MarginTopBottom>
            <MarginTopBottom>
              {renderAdditionalPaymentText({ elvisFFlag, })}
            </MarginTopBottom>
          </MarginTopBottom>
          <CenterAlign>
            <Title size='small' bold>
              &divide;
            </Title>
          </CenterAlign>
          <MarginTopBottom>
            <GrayText>Months</GrayText>
            <Title size='small'>{downPaymentData?.dpTerm}</Title>
          </MarginTopBottom>
          <CenterAlign>
            <Title size='small' bold>
              =
            </Title>
          </CenterAlign>
          <MarginTopBottom>
            <GrayText>Monthly Payment</GrayText>
            <MarginBottom size='large'>${price}</MarginBottom>
            {(isVbgOrNotElvisFFlag(elvisFFlag)) && (
              <TitleWidth>
                <Title size='small'>
                  First Payment will be <AmountTextWidth>${firstPaymentPrice}</AmountTextWidth>
                </Title>
              </TitleWidth>
            )}
            {renderAprValue({ elvisFFlag, aprValue })}
          </MarginTopBottom>
        </PaymentSection>
      </>
    </MarginSides>
  );
};
export default DownPayment;
