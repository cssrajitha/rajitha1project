import React from 'react';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import DownPayment from './DownPayment';

jest.mock(
  '../../../modules/services/APIService/APIServiceHooks',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('../../../modules/services/APIService/APIServiceHooks'),
      useLazyComputeDPPricesQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                status: 'Success',
                downPayment: 400,
                remainingMonthPrice: 300,
                firstMonthPrice: 200,
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
      useLazyGetFetchDownpaymentQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                status: 'Success',
                fetchDownPaymentResponse: [
                  {
                    mtn: '2158504104',
                    customerName: 'DICK HENDERSON',
                    deviceFinanceLimit: 2500.0,
                    totalFinanceLimit: 6028.05,
                    sorId: 'MU683LL/A',
                    firstMonthPrice: 33.44,
                    remaingingMonthPrice: 33.33,
                    dpTerm: 36,
                    downPayment: '0.0',
                    deviceDescription: 'iPhone 15 Pro Max',
                    devicePrice: '1199.99',
                    maxDownPaymentAmount: 1199.63,
                    showSellerPrice: false,
                    taxAmount: 78.0,
                    spendingLimitAmountExceededBy: '0.0',
                    spendingLimitAmountExceeded: false,
                    mandatoryDownPayment: 0.0,
                    userSelectedDownPayment: 0.0,
                    instantCreditDownPayment: 0.0,
                    totalDeviceDollar: 0.0,
                    totalRemainingDeviceDollar: 0.0,
                    totalUsedDeviceDollar: 0.0,
                    deviceDollarDownpayment: 0.0,
                    deviceDownPayment: 0.0,
                    vzDollarTotalAmount: 1480.0,
                    vzDollarUsedByLine: 0.0,
                    vzDollarUsedByAllLines: 0.0,
                    discountedPrice: 1199.99,
                  },
                ],
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
    };
  },
  { virtual: true }
);

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isIpad: () => true,
    isIndirect: () => true,
    executeShellFunction: jest.fn(),
  }),
  { virtual: true }
);

describe('device model component render', () => {
  const props = {
    paymentObject: { contractDuration: 36 },
    manageDownPayment: 'true',
    retailPrice: 999,
    selectedSku: {
      sorId: '123',
      price: { fullRetailPrice: { originalPrice: 4288.99 }, devicePaymentPrice: [{ contractDuration: 36 }] },
    },
    CustomerData: {
      cartId: '234',
      caseId: '123',
      customerId: '23456',
      lookupMtn: '123456',
      newCustomerWithoutCredit: true,
    },
    setDownPaymentObj: jest.fn(),
    downPayment: 10,
    computeDPPriceBody: jest.fn(),
    setIsDownPaymentAlertNeedToEnable: jest.fn(),
    computeDPPriceResult: {
      status: 'Success',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: {
        status: 'Success',
        downPayment: 400,
        remainingMonthPrice: 300,
        firstMonthPrice: 200,
      },
    },
  };
  beforeEach(() => {
    render(<DownPayment {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('DownPayment component shoudl render', () => {
    const DownPaymentText = screen.getAllByText(/Down Payment/i)[0];
    expect(DownPaymentText).toBeInTheDocument();
    const inputValue = screen.getByPlaceholderText('$0.00');
    fireEvent.blur(inputValue, { target: { value: '56' } });
    fireEvent.change(inputValue, { target: { value: '56' } });
  });
  test('DownPayment component shoudl render', () => {
    const splitEquallyId = screen.getByTestId('splitEqually');
    expect(splitEquallyId).toBeInTheDocument();
    fireEvent.click(splitEquallyId);
  });
  test('DownPayment amount changed', () => {
    const dpAmount = screen.getByRole('radio', { name: '$' });
    expect(dpAmount).toBeInTheDocument();
    fireEvent.click(dpAmount);
    const dpAmount2 = screen.getByRole('radio', { name: '%' });
    expect(dpAmount2).toBeInTheDocument();
    fireEvent.click(dpAmount2);
  });
  test('DownPayment amount changed', () => {
    const inputValue = screen.getByPlaceholderText('$0.00');
    fireEvent.blur(inputValue, { target: { value: '56' } });
    fireEvent.change(inputValue, { target: { value: '56' } });
    const dpAmount = screen.getByRole('radio', { name: '$' });
    expect(dpAmount).toBeInTheDocument();
    fireEvent.click(dpAmount);
    const dpAmount2 = screen.getByRole('radio', { name: '%' });
    expect(dpAmount2).toBeInTheDocument();
    fireEvent.click(dpAmount2);
  });
});

describe('device model component render', () => {
  const props = {
    manageDownPayment: 'true',
    retailPrice: 999,
    selectedSku: {
      sorId: '123',
      price: {
        fullRetailPrice: { originalPrice: 4288.99 },
        devicePaymentPrice: [{ price: '23', contractDuration: 36, dpTermPrices: { downPayment: '200' } }],
      },
    },
    CustomerData: {},
    setDownPaymentObj: jest.fn(),
    setIsDownPaymentAlertNeedToEnable: jest.fn(),
    downPayment: 10,
  };
  beforeEach(() => {
    render(<DownPayment {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('DownPayment component shoudl render', () => {
    const splitEquallyId = screen.getByTestId('splitEqually');
    expect(splitEquallyId).toBeInTheDocument();
    fireEvent.click(splitEquallyId);
  });
});

describe('device model component render empty selectedSKu', () => {
  test('DownPayment component should render with empty selectedSku', () => {
    const props = {
      manageDownPayment: 'true',
      retailPrice: 999,
      selectedSku: {},
      CustomerData: {},
      setDownPaymentObj: jest.fn(),
      setIsDownPaymentAlertNeedToEnable: jest.fn(),
      downPayment: 10,
    };
    render(<DownPayment {...props} />, { reducers: rootReducer, sagas: rootSaga });
    const splitEquallyId = screen.getByTestId('splitEqually');
    expect(splitEquallyId).toBeInTheDocument();
    fireEvent.click(splitEquallyId);
  });

  test('DownPayment component should render without selectedSku', () => {
    const props = {
      manageDownPayment: 'true',
      CustomerData: {},
      setDownPaymentObj: jest.fn(),
      setIsDownPaymentAlertNeedToEnable: jest.fn(),
      downPayment: 10,
    };
    render(<DownPayment {...props} />, { reducers: rootReducer, sagas: rootSaga });
    const splitEquallyId = screen.getByTestId('splitEqually');
    expect(splitEquallyId).toBeInTheDocument();
    fireEvent.click(splitEquallyId);
  });

  test('DownPayment component should render with downpayment', () => {
    const props = {
      manageDownPayment: 'true',
      retailPrice: 999,
      selectedSku: {
        sorId: '123',
        price: {
          fullRetailPrice: { originalPrice: 4288.99 },
          devicePaymentPrice: [{ contractDuration: 36, dpTermPrices: { downPayment: 100 } }],
        },
      },
      CustomerData: {},
      paymentObject: { contractDuration: 36 },
      setDownPaymentObj: jest.fn(),
      setIsDownPaymentAlertNeedToEnable: jest.fn(),
      downPayment: 10,
    };
    render(<DownPayment {...props} />, { reducers: rootReducer, sagas: rootSaga });
    const splitEquallyId = screen.getByTestId('splitEqually');
    expect(splitEquallyId).toBeInTheDocument();
    fireEvent.click(splitEquallyId);
  });
  test('DownPayment component should render without downpayment', () => {
    const props = {
      manageDownPayment: 'true',
      retailPrice: 999,
      selectedSku: {
        sorId: '123',
        price: {
          fullRetailPrice: { originalPrice: 4288.99 },
          devicePaymentPrice: [{ contractDuration: 36, dpTermPrices: { downPayment: 100 } }],
        },
      },
      CustomerData: {},
      paymentObject: { contractDuration: 24 },
      setDownPaymentObj: jest.fn(),
      setIsDownPaymentAlertNeedToEnable: jest.fn(),
      downPayment: 0,
    };
    render(<DownPayment {...props} />, { reducers: rootReducer, sagas: rootSaga });
    const splitEquallyId = screen.getByTestId('splitEqually');
    expect(splitEquallyId).toBeInTheDocument();
    fireEvent.click(splitEquallyId);
  });
  test('DownPayment component should render for New Customer', () => {
    const props = {
      manageDownPayment: 'true',
      retailPrice: 999,
      selectedSku: {
        sorId: '123',
        price: {
          fullRetailPrice: { originalPrice: 4288.99 },
          devicePaymentPrice: [{ contractDuration: 36, dpTermPrices: { downPayment: 0 } }],
        },
      },
      CustomerData: {},
      paymentObject: { term: 36 },
      setDownPaymentObj: jest.fn(),
      setIsDownPaymentAlertNeedToEnable: jest.fn(),
      downPayment: 10,
      orderDetails: { customerType: 'N', quoteWithoutCredit: true },
    };
    render(<DownPayment {...props} />, { reducers: rootReducer, sagas: rootSaga });
    const splitEquallyId = screen.getByTestId('splitEqually');
    expect(splitEquallyId).toBeInTheDocument();
    fireEvent.click(splitEquallyId);
  });
});

describe('device model component render empty selectedSKu for New Customer', () => {
  const props = {
    manageDownPayment: 'true',
    retailPrice: 999,
    selectedSku: {
      sorId: '123',
      price: {
        fullRetailPrice: { originalPrice: 1199.99 },
        devicePaymentPrice: [{ contractDuration: 36, dpTermPrices: { downPayment: 200, firstMonthPrice: 100 } }],
      },
    },
    CustomerData: {},
    paymentObject: { term: 36 },
    setDownPaymentObj: jest.fn(),
    setDownPaymentData: jest.fn(),
    setDownPaymentDataNC: jest.fn(),
    downPayment: 10,
    orderDetails: { customerType: 'N' },
    computeDPPriceBody: jest.fn(),
    setIsDownPaymentAlertNeedToEnable: jest.fn(),
  };

  beforeAll(() => {
    sessionStorage.setItem('customerType', 'N');
  });
  test('DownPayment component should render', () => {
    render(<DownPayment {...props} />, { reducers: rootReducer, sagas: rootSaga });
    const DownPaymentText = screen.getAllByText(/Down Payment/i)[0];
    expect(DownPaymentText).toBeInTheDocument();
    const dpAmount2 = screen.getByRole('radio', { name: '%' });
    expect(dpAmount2).toBeInTheDocument();
    fireEvent.click(dpAmount2);
    // const inputValue = screen.getByPlaceholderText('$0.00');
    // fireEvent.blur(inputValue, { target: { value: '105' } });
    // fireEvent.change(inputValue, { target: { value: '105' } });
  });

  test('DownPayment component should render from filteredLineFromCart ', () => {
    const propsData = { ...props, filteredLineFromCart: { installmentInfo: { userSelectedDownPayment: 20 } } };
    render(<DownPayment {...propsData} />, { reducers: rootReducer, sagas: rootSaga });
    const splitEquallyId = screen.getByTestId('splitEqually');
    expect(splitEquallyId).toBeInTheDocument();
    fireEvent.click(splitEquallyId);
  });
  test('Adding DPPricing amount with Success and having sellerprice', () => {
    const propsData = {
      manageDownPayment: 'true',
      retailPrice: 999,
      selectedSku: {
        sorId: '123',
        price: {
          fullRetailPrice: { originalPrice: 4288.99 },
          devicePaymentPrice: [{ contractDuration: 36, dpTermPrices: { downPayment: 0 } }],
        },
      },
      filteredLineFromCart: {
        installmentInfo: { userSelectedDownPayment: 20 },
        itemsInfo: [{ cartItems: { cartItem: [{ cartItemType: 'DEVICE', sellerPrice: 200 }] } }],
      },
      CustomerData: {},
      paymentObject: { term: 36 },
      setDownPaymentObj: jest.fn(),
      downPayment: 10,
      orderDetails: { customerType: 'N' },
      isDownPaymentAlertNeedToEnable: true,
      setIsDownPaymentAlertNeedToEnable: jest.fn(),
      computeDPPriceBody: jest.fn(),
      computeDPPriceResult: {
        status: 'Success',
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: false,
        isFetching: false,
        data: {
          status: 'Success',
          downPayment: 400,
          remainingMonthPrice: 300,
          firstMonthPrice: 200,
        },
      },
    };
    render(<DownPayment {...propsData} />, { reducers: rootReducer, sagas: rootSaga });
    const splitEquallyId = screen.getByTestId('splitEqually');
    expect(splitEquallyId).toBeInTheDocument();
  });
  test('Adding DPPricing amount with Success and having sellerprice', () => {
    const propsData = {
      manageDownPayment: 'true',
      retailPrice: 999,
      selectedSku: {
        sorId: '123',
        price: {
          fullRetailPrice: { originalPrice: 4288.99 },
          devicePaymentPrice: [{ contractDuration: 36, dpTermPrices: { downPayment: 0 } }],
        },
      },
      filteredLineFromCart: {
        installmentInfo: { userSelectedDownPayment: 20 },
        itemsInfo: [{ cartItems: { cartItem: [{ cartItemType: 'DEVICE', sellerPrice: 200 }] } }],
      },
      CustomerData: {},
      paymentObject: { term: 36 },
      downPaymentObj: { downPayment: 10, sellerPrice: 300, verizonDollars: 60 },
      setDownPaymentObj: jest.fn(),
      downPayment: 10,
      orderDetails: { customerType: 'N' },
      isDownPaymentAlertNeedToEnable: true,
      setIsDownPaymentAlertNeedToEnable: jest.fn(),
      computeDPPriceBody: jest.fn(),
      computeDPPriceResult: {
        status: 'Success',
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: false,
        isFetching: false,
        data: {
          status: 'Success',
          downPayment: 400,
          remainingMonthPrice: 300,
          firstMonthPrice: 200,
        },
      },
    };
    render(<DownPayment {...propsData} />, { reducers: rootReducer, sagas: rootSaga });
    const splitEquallyId = screen.getByTestId('splitEqually');
    expect(splitEquallyId).toBeInTheDocument();
  });
  test('Adding DPPricing amount with Success ', () => {
    const propsData = {
      manageDownPayment: 'true',
      retailPrice: 999,
      selectedSku: {
        sorId: '123',
        price: {
          fullRetailPrice: { originalPrice: 4288.99 },
          devicePaymentPrice: [{ contractDuration: 36, dpTermPrices: { downPayment: 0 } }],
        },
      },
      filteredLineFromCart: { installmentInfo: { userSelectedDownPayment: 20 } },
      CustomerData: {},
      paymentObject: { term: 36 },
      setDownPaymentObj: jest.fn(),
      downPayment: 10,
      orderDetails: { customerType: 'N' },
      isDownPaymentAlertNeedToEnable: true,
      setIsDownPaymentAlertNeedToEnable: jest.fn(),
      computeDPPriceBody: jest.fn(),
      computeDPPriceResult: {
        status: 'Success',
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: false,
        isFetching: false,
        data: {
          status: 'Success',
          downPayment: 400,
          remainingMonthPrice: 300,
          firstMonthPrice: 200,
        },
      },
    };
    render(<DownPayment {...propsData} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('Adding DPPricing amount with Failure ', () => {
    const propsData = {
      manageDownPayment: 'true',
      retailPrice: 999,
      selectedSku: {
        sorId: '123',
        price: {
          fullRetailPrice: { originalPrice: 4288.99 },
          devicePaymentPrice: [{ contractDuration: 36, dpTermPrices: { downPayment: 0 } }],
        },
      },
      filteredLineFromCart: { installmentInfo: { userSelectedDownPayment: 20 } },
      CustomerData: {},
      paymentObject: { term: 36 },
      setDownPaymentObj: jest.fn(),
      downPayment: 10,
      orderDetails: { customerType: 'N' },
      isDownPaymentAlertNeedToEnable: true,
      setIsDownPaymentAlertNeedToEnable: jest.fn(),
      computeDPPriceBody: jest.fn(),
      computeDPPriceResult: {
        status: 'Success',
        isUninitialized: false,
        isLoading: false,
        isSuccess: false,
        isError: true,
        isFetching: false,
        error: {
          data: {
            errors: [{ message: 'System Error' }],
          },
        },
      },
    };
    render(<DownPayment {...propsData} />, { reducers: rootReducer, sagas: rootSaga });
  });
});
describe('Seller price component render', () => {
  const props = {
    paymentObject: { contractDuration: 36 },
    manageDownPayment: 'true',
    retailPrice: 999,
    selectedSku: {
      sorId: '123',
      price: { fullRetailPrice: { originalPrice: 4288.99 }, devicePaymentPrice: [{ contractDuration: 36 }] },
    },
    CustomerData: {
      cartId: '234',
      caseId: '123',
      customerId: '23456',
      lookupMtn: '123456',
      newCustomerWithoutCredit: true,
    },
    setDownPaymentObj: jest.fn(),
    setVzlinkClicked: jest.fn(),
    handleVZDollarApi: jest.fn(),
    handleVZDollarDownPayment: jest.fn(),
    sellerPriceApi: jest.fn(),
    setDownPaymentValue: jest.fn(),
    downPayment: 10,
    computeDPPriceBody: jest.fn(),
    setIsDownPaymentAlertNeedToEnable: jest.fn(),
    isIndirect: jest.fn(() => true),
    computeDPPriceResult: {
      status: 'Success',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: {
        status: 'Success',
        downPayment: 400,
        remainingMonthPrice: 300,
        firstMonthPrice: 200,
      },
    },
  };
  beforeEach(() => {
    render(<DownPayment {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('Seller Price component should render', () => {
    const SellerPriceText = screen.getAllByText(/Sellers Price/i)[0];
    expect(SellerPriceText).toBeInTheDocument();
    const inputValue = screen.getByPlaceholderText('$'); // or screen.getByLabelText('Down Payment Amount');
    fireEvent.blur(inputValue, { target: { value: '56' } });
    fireEvent.change(inputValue, { target: { value: '56' } });
  });

  // test('Verizon Price component should render', () => {
  //   const VzDollorPriceText = screen.getAllByText(/Apply Verizon Dollors/i)[0];
  //   expect(VzDollorPriceText).toBeInTheDocument();
  //   fireEvent.click(VzDollorPriceText);
  //   });

  //   test('Verizon Price component should render', () => {
  //   const VzDollorPriceText = screen.getAllByText(/Verizon Dollar/i)[0];
  //   expect(VzDollorPriceText).toBeInTheDocument();
  //   const inputValue = screen.getByTestId('verizonDollar'); // or screen.getByLabelText('Down Payment Amount');
  //   fireEvent.blur(inputValue, { target: { value: '56' } });
  //   fireEvent.change(inputValue, { target: { value: '56' } });
  //   });
});

describe('APR Value Selection', () => {
  let aprValue;
  const props = {
    paymentObject: { contractDuration: 36 },
    manageDownPayment: 'true',
    retailPrice: 999,
    selectedSku: {
      sorId: '123',
      price: { fullRetailPrice: { originalPrice: 4288.99 }, devicePaymentPrice: [{ contractDuration: 36 }] },
    },
    CustomerData: {
      cartId: '234',
      caseId: '123',
      customerId: '23456',
      lookupMtn: '123456',
      newCustomerWithoutCredit: true,
    },
    setDownPaymentObj: jest.fn(),
    setVzlinkClicked: jest.fn(),
    handleVZDollarApi: jest.fn(),
    handleVZDollarDownPayment: jest.fn(),
    sellerPriceApi: jest.fn(),
    setDownPaymentValue: jest.fn(),
    downPayment: 10,
    computeDPPriceBody: jest.fn(),
    setIsDownPaymentAlertNeedToEnable: jest.fn(),
    isIndirect: jest.fn(() => true),
    computeDPPriceResult: {
      status: 'Success',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: {
        loanOfferDetails: {
          annualPercentageRate: '5.5',
        },
      },
    },
    downPaymentData: {
      data: {
        loanOfferDetails: {
          annualPercentageRate: '7.5',
        },
      },
    },
  };
  beforeEach(() => {
    window.sessionStorage.setItem('elvisFFlag', 'TRUE');
    render(<DownPayment {...props} />, { reducers: rootReducer, sagas: rootSaga });
    aprValue = '';
  });
  it('should set aprValue from computeDPPriceResult if it exist', () => {
    if (props.computeDPPriceResult?.data?.loanOfferDetails?.annualPercentageRate) {
      aprValue = props.computeDPPriceResult?.data?.loanOfferDetails?.annualPercentageRate;
    } else {
      aprValue = props.downPaymentData?.loanOfferDetails?.annualPercentageRate;
    }
    expect(aprValue).toBe('5.5');
  });
});
describe('MaxTotalPrice calculation', () => {
  it('should use retailPrice when it is available and greater than 0', () => {
    const props = {
      paymentObject: { contractDuration: 36 },
      manageDownPayment: 'true',
      retailPrice: 1000,
      selectedSku: { edgeDeviceCap: 800 },
      originalPrice: 900,
      CustomerData: {
        cartId: '234',
        caseId: '123',
        customerId: '23456',
        lookupMtn: '123456',
        newCustomerWithoutCredit: true,
      },
      setDownPaymentObj: jest.fn(),
      downPayment: 10,
      computeDPPriceBody: jest.fn(),
      setIsDownPaymentAlertNeedToEnable: jest.fn(),
      isIndirect: jest.fn(() => false),
      computeDPPriceResult: {
        status: 'Success',
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: false,
        isFetching: false,
        data: {
          status: 'Success',
          downPayment: 400,
          remainingMonthPrice: 300,
          firstMonthPrice: 200,
        },
      },
    };
    let MaxTotalPrice;
    if (props.retailPrice && props.retailPrice > 0) {
      MaxTotalPrice = props.retailPrice;
    } else if (props.isIndirect()) {
      MaxTotalPrice = props.selectedSku?.edgeDeviceCap;
    } else {
      MaxTotalPrice = props.originalPrice;
    }
    render(<DownPayment {...props} />);
    expect(MaxTotalPrice).toBe(1000);
  });

  it('should use retailPrice when it is not available and not greater than 0', () => {
    const props = {
      paymentObject: { contractDuration: 36 },
      manageDownPayment: 'true',
      retailPrice: 0,
      selectedSku: { edgeDeviceCap: 800 },
      originalPrice: 900,
      CustomerData: {
        cartId: '234',
        caseId: '123',
        customerId: '23456',
        lookupMtn: '123456',
        newCustomerWithoutCredit: true,
      },
      setDownPaymentObj: jest.fn(),
      downPayment: 10,
      computeDPPriceBody: jest.fn(),
      setIsDownPaymentAlertNeedToEnable: jest.fn(),
      isIndirect: jest.fn(() => true),
      computeDPPriceResult: {
        status: 'Success',
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: false,
        isFetching: false,
        data: {
          status: 'Success',
          downPayment: 400,
          remainingMonthPrice: 300,
          firstMonthPrice: 200,
        },
      },
    };
    let MaxTotalPrice;
    if (props.retailPrice && props.retailPrice > 0) {
      MaxTotalPrice = props.retailPrice;
    } else if (props.isIndirect()) {
      MaxTotalPrice = props.selectedSku?.edgeDeviceCap;
    } else {
      MaxTotalPrice = props.originalPrice;
    }
    render(<DownPayment {...props} />);
    expect(MaxTotalPrice).toBe(800);
  });
  it('should use retailPrice when it is not available and not greater than 0', () => {
    const props = {
      paymentObject: { contractDuration: 36 },
      manageDownPayment: 'true',
      retailPrice: 0,
      selectedSku: { edgeDeviceCap: 800 },
      originalPrice: 900,
      CustomerData: {
        cartId: '234',
        caseId: '123',
        customerId: '23456',
        lookupMtn: '123456',
        newCustomerWithoutCredit: true,
      },
      setDownPaymentObj: jest.fn(),
      downPayment: 10,
      computeDPPriceBody: jest.fn(),
      setIsDownPaymentAlertNeedToEnable: jest.fn(),
      isIndirect: jest.fn(() => false),
      computeDPPriceResult: {
        status: 'Success',
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: false,
        isFetching: false,
        data: {
          status: 'Success',
          downPayment: 400,
          remainingMonthPrice: 300,
          firstMonthPrice: 200,
        },
      },
    };
    let MaxTotalPrice;
    if (props.retailPrice && props.retailPrice > 0) {
      MaxTotalPrice = props.retailPrice;
    } else if (props.isIndirect()) {
      MaxTotalPrice = props.selectedSku?.edgeDeviceCap;
    } else {
      MaxTotalPrice = props.originalPrice;
    }
    render(<DownPayment {...props} />);
    expect(MaxTotalPrice).toBe(900);
  });
});
