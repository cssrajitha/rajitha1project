import React from 'react';
import styled from 'styled-components';

const MarginSides = styled.div`
  margin: 0 3rem;
`;
const DetailContainer = styled.div`
  padding: 2rem;
`;

const IDLInfo = (props) => {
  const { htmlContent } = props;
  return (
    <MarginSides data-testid='idlInfo'>
      <DetailContainer>
        <div dangerouslySetInnerHTML={{ __html: htmlContent }} />
      </DetailContainer>
    </MarginSides>
  );
};
export default IDLInfo;
