import React from 'react';
import { RadioButtonGroup } from '@vds/radio-buttons';

const UpgradeReasonRadioGroup = (props) => {
  const { UpgradeReason, setSelectedUpgradeReason, setSelectedDescription, setUpgradeReasonType, defaultCode } = props;
  const isDark = (window?.mfe?.scmDeviceMfeEnable && window?.mfe?.isDark) || false;

  const handleReasonCode = (e) => {
    setSelectedUpgradeReason(e.target.value);
    setUpgradeReasonType(e.target.value);
    const selectedReason = UpgradeReason.find((reasonCode) => reasonCode.code === e.currentTarget.value);
    setSelectedDescription(selectedReason?.description || '');
  };
  return (
    <RadioButtonGroup
      onChange={handleReasonCode}
      surface={isDark ? 'dark' : 'light'}
      data-testid='upgrade_reason_radio_group'
      error={false}
      defaultValue={defaultCode}
      data={UpgradeReason?.map((rc, index) => {
        const reasonCode = rc?.code;
        const displayRc = `${reasonCode} ( ${rc?.description})`;
        return {
          name: 'reasons',
          label: displayRc,
          value: reasonCode,
          ariaLabel: `radio ${index}`,
          selected: rc.defaultReasonCode,
        };
      })}
    />
  );
};
export default UpgradeReasonRadioGroup;
