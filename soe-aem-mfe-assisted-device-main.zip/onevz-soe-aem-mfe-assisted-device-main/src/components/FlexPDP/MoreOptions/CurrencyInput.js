/* eslint-disable import/no-extraneous-dependencies */
import React from 'react';
import PropTypes from 'prop-types';
import MaskedInput from 'react-text-mask';
import createNumberMask from 'text-mask-addons/dist/createNumberMask';
import { isVbg } from 'onevzsoemfeframework/VbgAemUtil';

const defaultMaskOptions = {
  prefix: '$',
  suffix: '',
  includeThousandsSeparator: false,
  allowDecimal: true,
  decimalSymbol: '.',
  decimalLimit: 2, // how many digits allowed after the decimal
  integerLimit: 7, // limit length of integer numbers
  allowNegative: false,
  allowLeadingZeroes: false,
};

const CurrencyInput = ({ maskOptions, renderFunc, elvisFFlag, ...inputProps }) => {
  const currencyMask = createNumberMask({
    ...defaultMaskOptions,
    ...maskOptions,
    ...(!isVbg() && elvisFFlag
      ? {
          allowDecimal: false,
          decimalLimit: 0,
        }
      : {}),
  });

  return <MaskedInput mask={currencyMask} {...inputProps} render={renderFunc} data-testid='currencyInput' />;
};

CurrencyInput.defaultProps = {
  maskOptions: {},
};

CurrencyInput.propTypes = {
  maskOptions: PropTypes.shape({
    prefix: PropTypes.string,
    suffix: PropTypes.string,
    includeThousandsSeparator: PropTypes.bool,
    thousandsSeparatorSymbol: PropTypes.string,
    allowDecimal: PropTypes.bool,
    decimalSymbol: PropTypes.string,
    decimalLimit: PropTypes.string,
    requireDecimal: PropTypes.bool,
    allowNegative: PropTypes.bool,
    allowLeadingZeroes: PropTypes.bool,
    integerLimit: PropTypes.number,
  }),
  renderFunc: PropTypes.func,
  elvisFFlag: PropTypes.bool,
};

export default CurrencyInput;
