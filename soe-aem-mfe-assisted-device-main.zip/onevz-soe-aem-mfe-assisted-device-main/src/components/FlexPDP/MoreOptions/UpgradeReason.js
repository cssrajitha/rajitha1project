import React, { useState } from 'react';
import styled from 'styled-components';
import { Body } from '@vds/typography';
import { Modal, ModalBody } from '@vds/modals';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import { useGetRetrieveURCodeQuery } from 'onevzsoemfecommon/CartAPIService';
import Header from '../Header';
// import { useGetRetrieveURCodeQuery } from '../../../modules/services/APIService/APIServiceHooks';
import { Padding16, PaddingTopBot32 } from '../../CombinedGridwall/FlexGlobalStyledConstants';
import UpgradeReasonRadioGroup from './UpgradeReasonRadioGroup';
import { DARK_THEME_COLOR } from '../../../constants/constants';

const MarginSides = styled.div`
  margin: 0 3rem;
`;
const RadioButtonWrapper = styled.div`
  & label::before {
    content: '';
    display: none;
  }
`;
const ModelWrap = styled(Modal)`
  padding: 0px;
  max-width: 1133px;
  margin: 0 auto;
`;

const UpgradeReason = (props) => {
  const { mtn, productDetails, setUpgradeReasonType, deviceContract, headerData, footerSection } = props;

  const [selectedUpgradeReason, setSelectedUpgradeReason] = useState();
  const [selectedDescription, setSelectedDescription] = useState();
  const isByodUpdate = getQueryParamByName('isByodUpdate');
  const defaultSku = productDetails?.deviceProduct?.defaultSKU || productDetails?.deviceSku?.sorId;
  const reasonCodeType = isByodUpdate
    ? 'BYOD_DEVICE'
    : // : isTransferUpgradeSuccess //need to check with team
      //   ? 'ALTERNATE_UPGRADE'
      //   : isInEligibleUpgradeSuccess  //need to check with team
      //     ? 'INELIGIBLE_UPGRADE'
      '';
  const contractTermMatched = reasonCodeType === 'BYOD_DEVICE' ? 'MONTH_TO_MONTH' : deviceContract;
  const reqBody = {
    cartId: '',
    cartMtnList: [
      {
        mtn,
        deviceSku: defaultSku,
        contractType: contractTermMatched,
        reasonCodeType,
      },
    ],
  };
  const ReasonCodeResult = useGetRetrieveURCodeQuery({ body: reqBody });
  const UpgradeReasonResult =
    ReasonCodeResult?.data?.data?.retrieveURCforCartMtnList?.mtnUpgradeReasonCodes?.[0]?.upgradeReasonCodes || [];
  const selectedReason = UpgradeReasonResult.find((reasonCode) => reasonCode.defaultReasonCode);
  const defaultCode = selectedReason?.code;
  const scmDeviceEnable = window?.mfe?.scmDeviceMfeEnable || false;
  const isDark = (window?.mfe?.scmDeviceMfeEnable && window?.mfe?.isDark || false);

  return (
    <div data-testid='upgrade_reason_code'>
      <ModelWrap
        id='modalcontainer1'
        opened={selectedReason}
        surface={isDark ? 'dark' : 'light'}
        fullScreenDialog = {!scmDeviceEnable}
        disableAnimation={false}
        disableOutsideClick
        width={scmDeviceEnable ? '850px': '100%'}
        closeButton={null}
        ariaLabel='Testing Modal'
      >
        <Header data={headerData} closePopup={scmDeviceEnable}/>
        <ModalBody>
          <MarginSides>
            <Padding16>
              <Body size='large' color={isDark? DARK_THEME_COLOR : '#000000'}>
                <b>Current Upgrade Reason Code:</b> {selectedUpgradeReason || selectedReason?.code}
                {selectedDescription ? ` (${selectedDescription})` : ` (${selectedReason?.description || ''})`}
              </Body>
            </Padding16>
            <PaddingTopBot32>
              <Body size='large' bold color={isDark? DARK_THEME_COLOR : '#000000'}>
                Available Reason Codes
              </Body>
            </PaddingTopBot32>
            <RadioButtonWrapper>
              {defaultCode && (
                <UpgradeReasonRadioGroup
                  UpgradeReason={UpgradeReasonResult}
                  setSelectedUpgradeReason={setSelectedUpgradeReason}
                  setSelectedDescription={setSelectedDescription}
                  setUpgradeReasonType={setUpgradeReasonType}
                  selectedUpgradeReason={selectedUpgradeReason}
                  defaultCode={defaultCode}
                />
              )}
            </RadioButtonWrapper>
          </MarginSides>
        </ModalBody>
        {footerSection()}
      </ModelWrap>
    </div>
  );
};
export default UpgradeReason;
