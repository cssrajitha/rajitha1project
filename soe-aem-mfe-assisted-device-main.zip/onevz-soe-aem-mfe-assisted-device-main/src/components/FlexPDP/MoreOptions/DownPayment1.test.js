import React from 'react';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import DownPayment from './DownPayment';

jest.mock(
  '../../../modules/services/APIService/APIServiceHooks',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('../../../modules/services/APIService/APIServiceHooks'),
      useLazyComputeDPPricesQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                status: 'Success',
                downPayment: 400,
                remainingMonthPrice: 300,
                firstMonthPrice: 200,
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
      useLazyGetFetchDownpaymentQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                status: 'Success',
                fetchDownPaymentResponse: [
                  {
                    mtn: '2158504104',
                    customerName: 'DICK HENDERSON',
                    deviceFinanceLimit: 2500.0,
                    totalFinanceLimit: 6028.05,
                    sorId: 'MU683LL/A',
                    firstMonthPrice: 33.44,
                    remaingingMonthPrice: 33.33,
                    dpTerm: 36,
                    downPayment: '0.0',
                    deviceDescription: 'iPhone 15 Pro Max',
                    devicePrice: '1199.99',
                    maxDownPaymentAmount: 1199.63,
                    showSellerPrice: false,
                    taxAmount: 78.0,
                    spendingLimitAmountExceededBy: '0.0',
                    spendingLimitAmountExceeded: false,
                    mandatoryDownPayment: 0.0,
                    userSelectedDownPayment: 0.0,
                    instantCreditDownPayment: 0.0,
                    totalDeviceDollar: 0.0,
                    totalRemainingDeviceDollar: 0.0,
                    totalUsedDeviceDollar: 0.0,
                    deviceDollarDownpayment: 0.0,
                    deviceDownPayment: 0.0,
                    vzDollarTotalAmount: 1480.0,
                    vzDollarUsedByLine: 0.0,
                    vzDollarUsedByAllLines: 0.0,
                    discountedPrice: 1199.99,
                  },
                ],
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
    };
  },
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isIpad: () => true,
    isIndirect: () => false,
    executeShellFunction: jest.fn(),
  }),
  { virtual: true },
);

describe('device model component render', () => {
  const props = {
    paymentObject: { contractDuration: 36 },
    manageDownPayment: 'true',
    selectedSku: {
      sorId: '123',
      price: { fullRetailPrice: { originalPrice: 4288.99 }, devicePaymentPrice: [{ contractDuration: 36 }] },
    },
    CustomerData: {
      cartId: '234',
      caseId: '123',
      customerId: '23456',
      lookupMtn: '123456',
      newCustomerWithoutCredit: true,
    },
    setDownPaymentObj: jest.fn(),
    downPayment: 10,
    computeDPPriceBody: jest.fn(),
    setIsDownPaymentAlertNeedToEnable: jest.fn(),
    computeDPPriceResult: {
      status: 'Success',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: {
        status: 'Success',
        downPayment: 400,
        remainingMonthPrice: 300,
        firstMonthPrice: 200,
      },
    },
  };
  beforeEach(() => {
    render(<DownPayment {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('DownPayment component shoudl render', () => {
    const DownPaymentText = screen.getAllByText(/Down Payment/i)[0];
    expect(DownPaymentText).toBeInTheDocument();
    const inputValue = screen.getByPlaceholderText('$0.00');
    fireEvent.blur(inputValue, { target: { value: '56' } });
    fireEvent.change(inputValue, { target: { value: '56' } });
  });
  test('DownPayment component shoudl render', () => {
    const splitEquallyId = screen.getByTestId('splitEqually');
    expect(splitEquallyId).toBeInTheDocument();
    fireEvent.click(splitEquallyId);
  });
  test('DownPayment amount changed', () => {
    const dpAmount = screen.getByRole('radio', { name: '$' });
    expect(dpAmount).toBeInTheDocument();
    fireEvent.click(dpAmount);
    const dpAmount2 = screen.getByRole('radio', { name: '%' });
    expect(dpAmount2).toBeInTheDocument();
    fireEvent.click(dpAmount2);
  });
  test('DownPayment amount changed', () => {
    const inputValue = screen.getByPlaceholderText('$0.00');
    fireEvent.blur(inputValue, { target: { value: '56' } });
    fireEvent.change(inputValue, { target: { value: '56' } });
    const dpAmount = screen.getByRole('radio', { name: '$' });
    expect(dpAmount).toBeInTheDocument();
    fireEvent.click(dpAmount);
    const dpAmount2 = screen.getByRole('radio', { name: '%' });
    expect(dpAmount2).toBeInTheDocument();
    fireEvent.click(dpAmount2);
  });
});
