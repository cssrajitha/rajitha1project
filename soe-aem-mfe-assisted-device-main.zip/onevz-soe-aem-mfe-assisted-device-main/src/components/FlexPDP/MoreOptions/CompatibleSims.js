import React from 'react';
import { Body } from '@vds/typography';
import styled from 'styled-components';
import { DARK_THEME_COLOR } from '../../../constants/constants';

const MarginSides = styled.div`
  margin: 0 3rem;
`;
const ListWrap = styled.div`
  padding: 0.4375rem 0;
`;

export const ListWrapper = styled.div`
  margin-top: 20px;
`;
const ComatibleSims = (props) => {
  const { compatibleSimSorIds } = props;
  const isDark = (window?.mfe?.scmDeviceMfeEnable && window?.mfe?.isDark || false);

  return (
    <MarginSides>
      <Body size='large' bold color={isDark? DARK_THEME_COLOR : '#000000'}>
        Compatible SIM's with this device are below
      </Body>
      <ListWrapper>
        {compatibleSimSorIds?.length > 0 &&
          compatibleSimSorIds?.map(
            (item, index) =>
              item && (
                <ListWrap>
                  <span>{`${index + 1}. `}</span>
                  {item}
                </ListWrap>
              ),
          )}
      </ListWrapper>
    </MarginSides>
  );
};
export default ComatibleSims;
