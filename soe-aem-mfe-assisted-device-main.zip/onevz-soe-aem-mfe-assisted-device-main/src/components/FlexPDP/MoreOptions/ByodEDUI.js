import { Button } from '@vds/buttons';
import { Input } from '@vds/inputs';
import { Body } from '@vds/typography';
import { Table, TableHead, TableHeader, TableBody, TableRow, Cell } from '@vds/tables';
import React from 'react';
import styled from 'styled-components';
import { Icon } from '@vds/icons';
import { Line } from '@vds/lines';
import { PaddingBottom16, PaddingY24, PaddingTop20 } from '../../CombinedGridwall/FlexGlobalStyledConstants';
import { DARK_THEME_COLOR } from '../../../constants/constants';

const MarginSides = styled.div`
  margin: 0 5rem;
`;

const ByodEDUI = (props) => {
  const { validateByodTool, deviceSku, byodToolData, handleByodValidation, deviceId } = props;
  const isDark = (window?.mfe?.scmDeviceMfeEnable && window?.mfe?.isDark || false);

  return (
    <MarginSides>
      <PaddingBottom16>
        <Body size='large' bold color={isDark? DARK_THEME_COLOR : '#000000'}>
          BYOD Validation Tool
        </Body>
      </PaddingBottom16>
      <Line type='primary' surface={isDark ? 'dark' : 'light'}/>

      <PaddingY24>
        <PaddingBottom16>
          <Body size='large' bold color={isDark? DARK_THEME_COLOR : '#000000'}>
            Enter the Device ID:
          </Body>
        </PaddingBottom16>
        <Input
          type='text'
          width='60%'
          // label='Enter the Device ID:'
          readOnly={false}
          required
          error={false}
          errorText='Enter the Device ID:'
          name='deviceId'
          placeholder='Device ID'
          defaultValue={deviceId}
          valaue={deviceId}
          onChange={handleByodValidation}
          surface={isDark ? 'dark' : 'light'}
        />
      </PaddingY24>
      <Button data-track='search' width='150px' onClick={validateByodTool} surface={isDark ? 'dark' : 'light'}>
        Search
      </Button>
      {byodToolData && (
        <>
          {' '}
          <PaddingTop20>
            <Body size='large' bold color={isDark? DARK_THEME_COLOR : '#000000'}>
              SKU: {deviceSku}
            </Body>
          </PaddingTop20>
          <Table striped bottomLine='secondary' padding='compact' surface={isDark ? 'dark' : 'light'}>
            <TableHead>
              <TableHeader>Activation Check</TableHeader>
              <TableHeader>Eligible</TableHeader>
            </TableHead>
            <TableBody>
              <TableRow>
                <Cell>Verizon's Device Management Database (DMD)</Cell>
                <Cell>
                  {byodToolData?.verizonsDMD ? (
                    <Icon name='checkmark' color='#00b845' />
                  ) : (
                    <Icon name='close' color='#F50A23' />
                  )}
                </Cell>
              </TableRow>
              <TableRow>
                <Cell>Lost/Stolen</Cell>
                <Cell>
                  {byodToolData?.lostOrStolen === false ? (
                    <Icon name='checkmark' color='#00b845' />
                  ) : (
                    <Icon name='close' color='#F50A23' />
                  )}
                </Cell>
              </TableRow>
              <TableRow>
                <Cell>Non Pay</Cell>
                <Cell>
                  {byodToolData?.nonPay === false ? (
                    <Icon name='checkmark' color='#00b845' />
                  ) : (
                    <Icon name='close' color='#F50A23' />
                  )}
                </Cell>
              </TableRow>
              <TableRow>
                <Cell>Apple Carrier Lock</Cell>
                <Cell>
                  {byodToolData?.appleCarrierLock === false ? (
                    <Icon name='checkmark' color='#00b845' />
                  ) : (
                    <Icon name='close' color='#F50A23' />
                  )}
                </Cell>
              </TableRow>
              <TableRow>
                <Cell>Apple Find My Phone Lock</Cell>
                <Cell>
                  {byodToolData?.fmipLock === false ? (
                    <Icon name='checkmark' color='#00b845' />
                  ) : (
                    <Icon name='close' color='#F50A23' />
                  )}
                </Cell>
              </TableRow>
              <TableRow>
                <Cell>
                  <b>Feature Compatibility</b>
                </Cell>
                <Cell />
              </TableRow>
              <TableRow>
                <Cell>Premium Visual Voicemail</Cell>
                <Cell>
                  {byodToolData?.premiumVisualVoiceMail ? (
                    <Icon name='checkmark' color='#00b845' />
                  ) : (
                    <Icon name='close' color='#F50A23' />
                  )}
                </Cell>
              </TableRow>
              <TableRow>
                <Cell>Voice Over WiFi</Cell>
                <Cell>
                  {byodToolData?.voiceOverWifi ? (
                    <Icon name='checkmark' color='#00b845' />
                  ) : (
                    <Icon name='close' color='#F50A23' />
                  )}
                </Cell>
              </TableRow>
              <TableRow>
                <Cell>TravelPass</Cell>
                <Cell>
                  {byodToolData?.travelPass === 'O' ? (
                    <Icon name='checkmark' color='#00b845' />
                  ) : (
                    <Icon name='close' color='#F50A23' />
                  )}
                </Cell>
              </TableRow>
              <TableRow>
                <Cell>Trade In Value Up To</Cell>
                <Cell>${byodToolData?.tradeInValueUpTo}</Cell>
              </TableRow>
            </TableBody>
          </Table>
        </>
      )}
    </MarginSides>
  );
};
export default ByodEDUI;
