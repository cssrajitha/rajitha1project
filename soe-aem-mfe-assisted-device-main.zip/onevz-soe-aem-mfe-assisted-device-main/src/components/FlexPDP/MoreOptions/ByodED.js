import React, { useEffect, useState } from 'react';
import { useLazyValidateBYODToolQuery } from 'onevzsoemfecommon/CartAPIService';
// import { useLazyValidateBYODToolQuery } from '../../../modules/services/APIService/APIServiceHooks';
import ByodEDUI from './ByodEDUI';

const ByodED = (props) => {
  const { deviceIdNum } = props;
  console.log('deviceIdNum', deviceIdNum);
  const [deviceId, setDeviceId] = useState(deviceIdNum);
  const [getValidateByodTool, ValidateByodToolResult] = useLazyValidateBYODToolQuery();

  useEffect(() => {
    const params = {
      deviceId,
    };
    console.log('deviceId', deviceId);
    if (deviceId) {
      getValidateByodTool({ body: params });
    }
  }, []);

  const handleByodValidation = (e) => {
    setDeviceId(e.target.value);
  };

  const validateByodTool = () => {
    if (deviceId && deviceId.length > 9) {
      const params = {
        deviceId,
      };
      getValidateByodTool({ body: params });
    }
  };

  const deviceSku = ValidateByodToolResult?.data?.data?.validateBYOD?.deviceSku;
  const byodToolData = ValidateByodToolResult?.data?.data?.validateBYOD;
  return (
    <ByodEDUI
      deviceSku={deviceSku}
      byodToolData={byodToolData}
      validateByodTool={validateByodTool}
      handleByodValidation={handleByodValidation}
      deviceId={deviceId}
    />
  );
};
export default ByodED;
