// import { fireEvent, waitFor } from '@testing-library/react';
import React from 'react';
import IndirectPaymentOptions from './indirectPaymentOptions';
import { render } from '../../modules/test-utils/renderHelper';

describe('indirectPaymentOptions component render', () => {
  const props = {
    selectedPaymentInfo: {
      contractType: 'M2M',
      price: 30.55,
      term: 36,
      paymentType: '',
    },
    selectPayment: jest.fn(),
    customerProfileDetails: true,
    isBYOD: false,
    isIndirect: true,
    fullFillment: false,
    isDpVisible: true,
    isNewLine: false,
    isFromCPE: null,
    isByodUpdate: true,
    lineActivityTypeFromCart: 'EUPBYOD',
  };
  beforeEach(() => {
    render(<IndirectPaymentOptions {...props} />);
  });
  test('should render indirectPaymentOptions component', () => {});
});
describe('indirectPaymentOptions component render', () => {
  const props = {
    selectedPaymentInfo: {
      contractType: 'DEVICE_PAYMENT',
      price: 30.55,
      term: 36,
      paymentType: '',
    },
    selectPayment: jest.fn(),
    customerProfileDetails: true,
    isBYOD: false,
    isIndirect: true,
    fullFillment: false,
    isDpVisible: true,
    isNewLine: false,
    isFromCPE: true,
    isByodUpdate: false,
    lineActivityTypeFromCart: 'EUPBYOD',
  };
  beforeEach(() => {
    render(<IndirectPaymentOptions {...props} />);
  });
  test('should render indirectPaymentOptions component', () => {});
});
