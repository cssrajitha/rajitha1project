import React, { useState } from 'react';
import styled from 'styled-components';
import { Title, Body } from '@vds/typography';
import { Line } from '@vds/lines';
import { RadioBoxGroup } from '@vds/radio-boxes';
import { RadioButtonGroup } from '@vds/radio-buttons';
import { TextLink } from '@vds/buttons';
import { Toggle } from '@vds/toggles';
import { Input } from '@vds/inputs';
import { Icon } from '@vds/icons';
import { DatePicker } from '@vds/date-pickers';
import { DropdownSelect } from '@vds/selects';
import {
  FlexJustify,
  StyledPaddingTopBot32,
  PaddingTop12,
  PaddingBot24,
  FlexBoxContainer,
  FlexBox,
  PaddingLeft24,
  StyledPaddingTop32,
} from '../CombinedGridwall/FlexGlobalStyledConstants';

const ImgWrapper = styled.div`
  display: flex;
  width: 252px;
  height: 312px;
`;
const LeftSideWrapper = styled.div`
  display: flex;
  flex-direction: column;
  gap: 2rem;
  margin-top: 2rem;
`;
const TextLinkWrapper = styled.div`
  text-align: center;
`;
const InfoWrapper = styled.div`
  display: flex;
  flex-direction: column;
  margin-left: 3.25rem;
  margin-top: 2.5rem;
  width: 100%;
`;
const SkuWrapper = styled.div`
  display: flex;
  flex-direction: row;
  margin-top: 1rem;
`;
const AddressWrapper = styled.div`
  width: 12rem;
  padding-top: 2.75rem;
`;
const PaymentOptionsWrapper = styled.div`
  width: 14.25rem;
`;

const FlexRight = styled.div`
  flex-grow: 1;
  text-align: right;
`;
const SpecCont = styled.div`
  margin-bottom: 10rem;
`;
const HorizontalRadioWrapper = styled.div`
  [class^='RadioButtonGroupWrapper-'] {
    display: flex;
    flex-direction: row;
    > .radioWrapper {
      margin-top: 0px;
      width: auto;
      margin-right: 2rem;
      :last-child {
        margin-right: 0;
        margin-left: 2rem;
      }
    }
  }
`;
function HorizontalLine() {
  return (
    <StyledPaddingTopBot32>
      <Line type='secondary' surface='light' />
    </StyledPaddingTopBot32>
  );
}

function Home5G({ device, importantDeviceClickHandler }) {
  const [professionalSetup, setProfessionalSetup] = useState(false);

  const handleInstallation = () => {
    setProfessionalSetup(!professionalSetup);
  };

  return (
    <SpecCont>
      <FlexBox>
        <LeftSideWrapper>
          <ImgWrapper>
            <img src={device.logo} alt='deviceslogo' />
          </ImgWrapper>
          <TextLinkWrapper>
            <TextLink type='standAlone' size='large' onClick={importantDeviceClickHandler}>
              Important device lock information
            </TextLink>
          </TextLinkWrapper>
        </LeftSideWrapper>

        <InfoWrapper>
          <Title bold size='large'>
            {device.devicename}
          </Title>
          <SkuWrapper>
            <FlexRight>
              <Body size='large' bold>
                SKU#: {device.sku}
              </Body>
            </FlexRight>
          </SkuWrapper>

          <HorizontalLine />

          <PaddingBot24>
            <Title size='small'>Payment options</Title>
          </PaddingBot24>
          <PaymentOptionsWrapper>
            <RadioBoxGroup
              defaultValue=''
              orientation='horizontal'
              data={[
                {
                  id: '1S',
                  text: '$12.50/mo.',
                  value: '$12.50/mo.',
                  subtext: '.',
                  name: 'RadioBoxGroup',
                },
              ]}
            />
          </PaymentOptionsWrapper>
          <HorizontalLine />

          <FlexBoxContainer>
            <HorizontalRadioWrapper>
              <RadioButtonGroup
                onChange={handleInstallation}
                error={false}
                defaultValue='Self setup'
                data={[
                  {
                    name: 'group',
                    label: 'Self setup',
                    children: '',
                    value: 'Self setup',
                    ariaLabel: 'Self setup',
                    disabled: false,
                  },
                  {
                    name: 'group',
                    label: 'Professional setup',
                    children: 'Set a schedule',
                    value: 'Professional setup',
                    ariaLabel: 'Professional setup',
                    disabled: false,
                  },
                ]}
              />
            </HorizontalRadioWrapper>
          </FlexBoxContainer>
          <HorizontalLine />

          {professionalSetup ? (
            <>
              <Title size='small' bold>
                Schedule appointment
              </Title>
              <AddressWrapper>
                <Body size='large' bold>
                  Address
                </Body>
                <PaddingTop12>
                  <Body size='large'>Ravi Johns 11101HUMBOLDT AVE N, 1 MINNEAPOLIS, MN 55411</Body>
                </PaddingTop12>
              </AddressWrapper>
              <StyledPaddingTop32>
                <FlexJustify>
                  <DropdownSelect
                    label='Primary phone'
                    errorText='Select a phone'
                    error={false}
                    disabled={false}
                    readOnly={false}
                    inlineLabel={false}
                    // width="32%"
                  >
                    <option>Select</option>
                    <option>8032164227</option>
                    <option>8032164273</option>
                    <option>8032164299</option>
                  </DropdownSelect>
                  <PaddingLeft24 />
                  <Input
                    type='text'
                    label='Enter MDN'
                    readOnly={false}
                    required
                    disabled={false}
                    error={false}
                    errorText='Enter a valid MDN.'
                  />
                </FlexJustify>
              </StyledPaddingTop32>
              <StyledPaddingTop32>
                <FlexJustify>
                  <DropdownSelect
                    label='Preferred contact method'
                    errorText='Select a phone'
                    error={false}
                    disabled={false}
                    readOnly={false}
                    inlineLabel={false}
                  >
                    <option>Select</option>
                    <option>8032164227</option>
                    <option>8032164273</option>
                    <option>8032164299</option>
                  </DropdownSelect>
                  <PaddingLeft24 />
                  <Input
                    type='text'
                    label='Enter MDN'
                    readOnly={false}
                    required
                    disabled={false}
                    error={false}
                    errorText='Enter a valid MDN.'
                  />
                </FlexJustify>
              </StyledPaddingTop32>
              <StyledPaddingTop32>
                <FlexJustify>
                  <Input
                    type='text'
                    label='Email'
                    readOnly={false}
                    required
                    disabled={false}
                    error={false}
                    errorText='Enter a valid email address.'
                  />
                  <PaddingLeft24 />
                  <DropdownSelect
                    label='Preferred contact method'
                    errorText='Select a category'
                    error={false}
                    disabled={false}
                    readOnly={false}
                    inlineLabel={false}
                  >
                    <option>Select</option>
                    <option>8032164227</option>
                    <option>8032164273</option>
                    <option>8032164299</option>
                  </DropdownSelect>
                </FlexJustify>
              </StyledPaddingTop32>
              <StyledPaddingTop32>
                <FlexJustify>
                  <Input
                    type='text'
                    label='Special instructions'
                    readOnly={false}
                    required
                    disabled={false}
                    error={false}
                    errorText='Enter a valid email address.'
                  />
                </FlexJustify>
              </StyledPaddingTop32>
              <HorizontalLine />

              <Title size='small' bold>
                Installation
              </Title>
              <StyledPaddingTop32>
                <FlexJustify>
                  <DatePicker
                    dateFormat='MM/DD/YYYY'
                    alwaysOpen={false}
                    readOnly={false}
                    disabled={false}
                    surface='light'
                    minDate={new Date(1998, 1, 1)}
                    label=' Select date'
                  />
                  <PaddingLeft24 />
                  <DropdownSelect
                    label='Select a time slot'
                    errorText='Select a time'
                    error={false}
                    disabled={false}
                    readOnly={false}
                    inlineLabel={false}
                  >
                    <option>Select</option>
                    <option>8032164227</option>
                    <option>8032164273</option>
                    <option>8032164299</option>
                  </DropdownSelect>
                </FlexJustify>
              </StyledPaddingTop32>
            </>
          ) : (
            <>
              <FlexBoxContainer>
                <Title size='small'>Device ID</Title>
                <Title size='small'>Enter ID</Title>
              </FlexBoxContainer>
              <HorizontalLine />

              <FlexBoxContainer>
                <Title size='small'>SIM ID</Title>
                <Title size='small'>SIM processing only available on iPad</Title>
              </FlexBoxContainer>
              <HorizontalLine />

              <FlexBoxContainer>
                <Title size='small'>Compatible Sims</Title>
                <Icon name='right-caret' size='large' />
              </FlexBoxContainer>
              <HorizontalLine />

              <FlexBoxContainer>
                <Title size='small'>In store pickup</Title>
                <Toggle disabled={false} showText={false} value='default' />
              </FlexBoxContainer>
            </>
          )}
        </InfoWrapper>
      </FlexBox>
    </SpecCont>
  );
}
export default Home5G;
