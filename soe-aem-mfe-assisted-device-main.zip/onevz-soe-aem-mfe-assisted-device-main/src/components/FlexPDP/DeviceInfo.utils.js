/**
 * DeviceInfo Utility Functions
 *
 * This file contains extracted utility functions from DeviceInfo component
 * to improve testability and maintainability.
 */

/**
 * Calls SKU details and inventory APIs when a device SKU is selected
 *
 * @param {Object} filteredSku - The selected SKU object with sorId, price, etc.
 * @param {string} type - The selection type ('color', 'size', 'PDPLocalScan')
 * @param {Object} dependencies - External dependencies needed by the function
 * @param {string} dependencies.activeMtn - The active MTN (mobile telephone number)
 * @param {string} dependencies.productId - The product ID
 * @param {number|string} dependencies.downPayment - The down payment amount
 * @param {Object} dependencies.filteredLineFromCart - Cart line information
 * @param {Function} dependencies.getInventoryDetails - API function to get inventory details
 * @param {Function} dependencies.computeDPPriceBody - API function to compute down payment price
 * @param {Function} dependencies.setUpcCode - State setter for UPC code
 * @param {Function} dependencies.setIsDevicePricingApiCallEnable - State setter for device pricing API flag
 * @returns {Promise<void>}
 */
export const doCallGetSkuDetails = async (filteredSku, type, dependencies) => {
  const {
    activeMtn,
    productId,
    downPayment,
    filteredLineFromCart,
    getInventoryDetails,
    computeDPPriceBody,
    setUpcCode,
    setIsDevicePricingApiCallEnable,
  } = dependencies;

  const { deviceId = '' } = ''; // deviceData; // scan device ID

  const mtnList = {
    eup: [],
    aal: [],
  };

  if (filteredSku && filteredSku.sorId) {
    const params = {
      data: {
        sorId: filteredSku.sorId,
        productType: 'device',
        ...(type === 'PDPLocalScan' ? { deviceId } : {}),
        processingMTN: activeMtn,
        productId,
        mtnList,
        bogoEnabled: 'true',
        deviceDollarsAccountConvertedInd: '',
      },
    };
    const computeDPPriceReq = {
      sorId: filteredSku?.sorId,
      mtn: activeMtn,
      term: filteredSku?.price?.preferredTerm,
      downPayment: downPayment || filteredLineFromCart?.installmentInfo?.downPayment,
      isPercentage: false,
      agentOrFullRetailPrice: filteredSku?.price?.fullRetailPrice?.originalPrice,
      loanOfferId: filteredSku?.price?.devicePaymentPrice?.[0]?.dpTermPrices?.loanOfferDetails?.loanOfferId || '',
    };
    await getInventoryDetails({ body: params }, false);
    /* istanbul ignore next */
    if (Number(downPayment || filteredLineFromCart?.installmentInfo?.downPayment) > 0) {
      computeDPPriceBody({ body: computeDPPriceReq }, false);
    }
    setUpcCode(filteredSku?.upcCodeFull);
    // handleBestBuyPricingDetails()
    setIsDevicePricingApiCallEnable(true);
  }
};
