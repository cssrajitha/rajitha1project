/* eslint-disable no-promise-executor-return */
// eslint-disable-next-line you-dont-need-lodash-underscore/get
import { get as getProp } from 'lodash';
import { render, screen, fireEvent } from '../../modules/test-utils/renderHelper';
import DeviceInfo from './DeviceInfo';
import { CHANNELS, setupChannel } from '../../modules/test-utils/utils';
import protectionFeatures from '../../pages/PDP/mocks/api/getProtectionFeatures.json';
import cartDetails from '../../pages/PDP/mocks/api/retrieveCart.json';
import customerProfileDetails from '../../pages/PDP/mocks/api/omniCareCustomerProfile.json';
import getSkuDetails from '../../pages/PDP/mocks/api/getSkuDetails.json';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { setupServer } from '../../pages/PDP/mocks/setupServer';

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => false,
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);
const Test = (channel) => {
  setupChannel(channel);
  describe(`<DeviceInfo component Local Flow- ${channel}`, () => {
    setupServer();
    const modProductDetails = getSkuDetails;
    const details = modProductDetails.data.deviceSku?.parentProducts[0] || {};
    const defaultSkuStringValue = getProp(details, 'defaultSKU') || '';
    const defaultSkuObjValue = getProp(details.defaultSKUObj, 'sorId') || '';
    const defaultSku = defaultSkuStringValue !== '' ? defaultSkuStringValue : defaultSkuObjValue;
    const defaultSkuDetails = details.childSkus.filter((sku) => sku.sorId && sku.sorId === defaultSku);
    navigator.clipboard = jest.fn();
    navigator.clipboard.writeText = jest.fn('Pink');
    beforeEach(() => {
      window.history.pushState(
        {},
        'PDP',
        '/sales/assisted/new/device/pdp.html?isByodUpdate=true&activeMtn=5185673926&iSscan=true&deviceSKU=SMS911UZEV&deviceId=350321532631401&productId=1234',
      );
      const inventoryDetails = {
        dFillInventory: {
          isInStock: {},
          qtyAvailable: 1,
        },
      };
      render(
        <DeviceInfo
          details={details}
          productDetails={modProductDetails.data}
          protectionFeatures={protectionFeatures}
          cartDetails={cartDetails.data.data}
          customerProfileDetails={customerProfileDetails.data}
          activeMtn='5185673926'
          selectedColor={defaultSkuDetails[0].color.displayName}
          setSelectedColor={jest.fn()}
          ispuToggleOn
          setIspuToggleOn={jest.fn()}
          isShipItToggleOn
          setIsShipItToggleOn={jest.fn()}
          setIncompatibleSim={jest.fn()}
          selectedSku={{ ...details.childSkus[0], inventoryDetails }}
          setSelectedSku={jest.fn()}
          selectedProtectionFeature={protectionFeatures.payload.features[1]}
          setSelectedProtectionFeature={jest.fn()}
          selectedSize={defaultSkuDetails[0].capacity}
          setSelectedSize={jest.fn()}
          updateNumberShare={jest.fn()}
          isNumberShare='true'
          numberShareValue=''
          sharedMtnValue=''
          updateNumberShareValue={jest.fn()}
          updateSharedMtnValue={jest.fn()}
          setSelectedPaymentInfo={jest.fn()}
          updateDeviceId={jest.fn()}
          updateSimId={jest.fn()}
          updateDeviceData={jest.fn()}
          setTmpLinkClicked={jest.fn()}
          setUpgradeReasonType={jest.fn()}
          groupByColors={jest.fn()}
          groupBySmartWatchBand={jest.fn()}
          setisInStock={jest.fn()}
          computeDPPriceResult={{
            status: 'fulfilled',
            endpointName: 'computeDPPrices',
            requestId: 'lf2MRsFlucEKnButXAPgU',
            originalArgs: {
              body: {
                sorId: 'SMS911UZEV',
                mtn: '2164706958',
                term: 36,
                downPayment: 10,
                isPercentage: true,
                agentOrFullRetailPrice: 1029.99,
              },
              spinner: false,
            },
            startedTimeStamp: 1720705629368,
            data: {
              firstMonthPrice: 26.09,
              remainingMonthPrice: 25.74,
              dpTerm: 36,
              downPayment: 103,
              mtn: '2164706958',
            },
            fulfilledTimeStamp: 1720705629906,
            isUninitialized: false,
            isLoading: false,
            isSuccess: true,
            isError: false,
            currentData: {
              firstMonthPrice: 26.09,
              remainingMonthPrice: 25.74,
              dpTerm: 36,
              downPayment: 103,
              mtn: '2164706958',
            },
            isFetching: false,
          }}
          selectedPaymentInfo={{ contractType: 'DEVICE_PAYMENT' }}
          upcCodeFromPdpScan='123456789012'
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('Should render select dropdown', async () => {
      const devicesimonlyChange = await screen.getAllByTestId('devicesimonlyChange')[0];
      expect(devicesimonlyChange).toBeInTheDocument();
      fireEvent.change(devicesimonlyChange, { target: { value: 'Device change' } });

      const devicesChange = await screen.getAllByTestId('devicesimonlyChange')[0];
      expect(devicesChange).toBeInTheDocument();
      fireEvent.change(devicesChange, { target: { value: 'SIM only change' } });
    });

    test.skip('Should render select dropdown', async () => {
      fireEvent.click(screen.getAllByRole('checkbox', { name: '' })[1]);
    });
    test.skip('Should render select dropdown', async () => {
      fireEvent.click(screen.getAllByRole('checkbox', { name: '' })[2]);
    });
  });
  describe(`<DeviceInfo component Local Flow- ${channel}`, () => {
    setupServer();
    const modProductDetails = getSkuDetails;
    const details = modProductDetails.data.deviceSku?.parentProducts[0] || {};
    const defaultSkuStringValue = getProp(details, 'defaultSKU') || '';
    const defaultSkuObjValue = getProp(details.defaultSKUObj, 'sorId') || '';
    const defaultSku = defaultSkuStringValue !== '' ? defaultSkuStringValue : defaultSkuObjValue;
    const defaultSkuDetails = details.childSkus.filter((sku) => sku.sorId && sku.sorId === defaultSku);
    navigator.clipboard = jest.fn();
    navigator.clipboard.writeText = jest.fn('Pink');
    beforeEach(() => {
      window.mfe = { scmDeviceMfeEnable: true, isDark: true };
      window.history.pushState(
        {},
        'PDP',
        '/sales/assisted/new/device/pdp.html?isByodUpdate=true&activeMtn=5185673926&iSscan=true&deviceSKU=SMS911UZEV&deviceId=350321532631401&productId=1234',
      );
      const inventoryDetails = {
        dFillInventory: {
          isInStock: {},
          qtyAvailable: 1,
        },
      };
      render(
        <DeviceInfo
          details={details}
          productDetails={modProductDetails.data}
          protectionFeatures={protectionFeatures}
          cartDetails={cartDetails.data.data}
          customerProfileDetails={customerProfileDetails.data}
          activeMtn='5185673926'
          selectedColor={defaultSkuDetails[0].color.displayName}
          setSelectedColor={jest.fn()}
          ispuToggleOn
          setIspuToggleOn={jest.fn()}
          isShipItToggleOn
          setIsShipItToggleOn={jest.fn()}
          setIncompatibleSim={jest.fn()}
          selectedSku={{ ...details.childSkus[0], inventoryDetails }}
          setSelectedSku={jest.fn()}
          selectedProtectionFeature={protectionFeatures.payload.features[1]}
          setSelectedProtectionFeature={jest.fn()}
          selectedSize={defaultSkuDetails[0].capacity}
          setSelectedSize={jest.fn()}
          updateNumberShare={jest.fn()}
          isNumberShare='true'
          numberShareValue=''
          sharedMtnValue=''
          updateNumberShareValue={jest.fn()}
          updateSharedMtnValue={jest.fn()}
          setSelectedPaymentInfo={jest.fn()}
          updateDeviceId={jest.fn()}
          updateSimId={jest.fn()}
          updateDeviceData={jest.fn()}
          setTmpLinkClicked={jest.fn()}
          setUpgradeReasonType={jest.fn()}
          groupByColors={jest.fn()}
          groupBySmartWatchBand={jest.fn()}
          setisInStock={jest.fn()}
          computeDPPriceResult={{
            status: 'fulfilled',
            endpointName: 'computeDPPrices',
            requestId: 'lf2MRsFlucEKnButXAPgU',
            originalArgs: {
              body: {
                sorId: 'SMS911UZEV',
                mtn: '2164706958',
                term: 36,
                downPayment: 10,
                isPercentage: true,
                agentOrFullRetailPrice: 1029.99,
              },
              spinner: false,
            },
            startedTimeStamp: 1720705629368,
            data: {
              firstMonthPrice: 26.09,
              remainingMonthPrice: 25.74,
              dpTerm: 36,
              downPayment: 103,
              mtn: '2164706958',
            },
            fulfilledTimeStamp: 1720705629906,
            isUninitialized: false,
            isLoading: false,
            isSuccess: true,
            isError: false,
            currentData: {
              firstMonthPrice: 26.09,
              remainingMonthPrice: 25.74,
              dpTerm: 36,
              downPayment: 103,
              mtn: '2164706958',
            },
            isFetching: false,
          }}
          selectedPaymentInfo={{ contractType: 'DEVICE_PAYMENT' }}
          upcCodeFromPdpScan='123456789012'
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('Should render select dropdown', async () => {
      const devicesimonlyChange = await screen.getAllByTestId('devicesimonlyChange')[0];
      expect(devicesimonlyChange).toBeInTheDocument();
      fireEvent.change(devicesimonlyChange, { target: { value: 'Device change' } });

      const devicesChange = await screen.getAllByTestId('devicesimonlyChange')[0];
      expect(devicesChange).toBeInTheDocument();
      fireEvent.change(devicesChange, { target: { value: 'SIM only change' } });
    });
  });
};
Test(CHANNELS.OMNI_CARE);
