import React from 'react';
import { render } from '@testing-library/react';
import SecondLineDeviceId from './SecondLineDeviceId';

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    getQueryParamByName: jest.fn(),
    isIpad: jest.fn(() => false),
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    getAssistedCradlePropertyV2: jest.fn().mockReturnValue([false]),
  }),
  { virtual: true },
);
const domService = require('onevzsoemfeframework/DomService');

const { getQueryParamByName } = domService;

describe('SecondLineDeviceId Component Coverage Tests', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    getQueryParamByName.mockImplementation((param) => {
      if (param === 'deviceSKU') return 'TESTSKU123';
      if (param === 'scanFromLanding') return 'true';
      if (param === 'offerEligible') return 'true';
      return '';
    });
    const appProperties = JSON.stringify({ snDeviceIdErrorFixFFlag: 'TRUE' });
    const mockSessionStorage = {
      getItem: jest.fn((key) => {
        if (key === 'APP_PROPERTIES') return appProperties;
        return null;
      }),
      setItem: jest.fn(),
    };
    Object.defineProperty(window, 'sessionStorage', {
      value: mockSessionStorage,
      writable: true,
    });
  });

  beforeEach(() => {
    const assistedCradleService = jest.requireMock('onevzsoemfeframework/AssistedCradleService');
    assistedCradleService.getAssistedCradlePropertyV2.mockReturnValue([false]);
  });

  test('renders with imei2 from props and sim input enabled/disabled based on isIpad', () => {
    const validateDeviceSimIdRequest = jest.fn();
    const setSecondNumDeviceId = jest.fn();
    const props = {
      deviceInfo: { imei2: 'IMEI_FROM_PROPS' },
      validateDeviceSimIdRequest,
      setSecondNumDeviceId,
      cartDetails: { cart: { lineDetails: { lineInfo: [] } } },
      pairedMtn: '123',
      deviceData: { skuId: 'SKU123' },
    };
    const { getByTestId, rerender } = render(<SecondLineDeviceId {...props} />);
    expect(getByTestId('InputDeviceId').value).toBe('IMEI_FROM_PROPS');
    expect(getByTestId('InputSimId')).toBeDisabled();
    const { isIpad } = jest.requireMock('onevzsoemfeframework/DomService');
    isIpad.mockReturnValue(true);
    rerender(<SecondLineDeviceId {...props} />);
    expect(getByTestId('InputSimId')).not.toBeDisabled();
  });

  test('renders with imei2 from URL if not in props', () => {
    getQueryParamByName.mockImplementation((param) => {
      if (param === 'imei2') return 'IMEI_FROM_URL';
      if (param === 'scanFromLanding') return 'true';
      if (param === 'deviceSKU') return 'SKUURL';
      if (param === 'offerEligible') return 'true';
      return '';
    });
    const validateDeviceSimIdRequest = jest.fn();
    const setSecondNumDeviceId = jest.fn();
    const props = {
      deviceInfo: {},
      validateDeviceSimIdRequest,
      setSecondNumDeviceId,
      cartDetails: { cart: { lineDetails: { lineInfo: [] } } },
    };
    const { getByTestId } = render(<SecondLineDeviceId {...props} />);
    expect(getByTestId('InputDeviceId').value).toBe('IMEI_FROM_URL');
  });

  test('edit scenario: imei2 and dualSimId from editLineInfo', () => {
    getQueryParamByName.mockImplementation((param) => {
      if (param === 'isEditAndView') return 'true';
      if (param === 'scanFromLanding') return 'true';
      return '';
    });
    const validateDeviceSimIdRequest = jest.fn();
    const setSecondNumDeviceId = jest.fn();
    const props = {
      deviceInfo: {},
      validateDeviceSimIdRequest,
      setSecondNumDeviceId,
      cartDetails: {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                mtnDetails: { mobileNumber: '999' },
                serviceInfo: {
                  orderDevice: {
                    lteVoraEquipInfo: {
                      lteVoraDeviceInfo: { deviceId: 'EDIT_IMEI2' },
                      lteEqpt: { iccid: 'EDIT_ICCID' },
                    },
                  },
                },
              },
            ],
          },
        },
      },
      pairedMtn: '999',
    };
    const { getByTestId } = render(<SecondLineDeviceId {...props} />);
    expect(getByTestId('InputDeviceId').value).toBe('EDIT_IMEI2');
    expect(getByTestId('InputSimId').value).toBe('EDIT_ICCID');
  });

  test('does not render sim input if skipIccidCall is true', () => {
    const { getAssistedCradlePropertyV2 } = jest.requireMock('onevzsoemfeframework/AssistedCradleService');
    getAssistedCradlePropertyV2.mockReturnValue([true]);
    const validateDeviceSimIdRequest = jest.fn();
    const setSecondNumDeviceId = jest.fn();
    const props = {
      deviceInfo: { imei2: '123' },
      validateDeviceSimIdRequest,
      setSecondNumDeviceId,
      cartDetails: { cart: { lineDetails: { lineInfo: [] } } },
    };
    const { queryByTestId } = render(<SecondLineDeviceId {...props} />);
    expect(queryByTestId('InputSimId')).toBeNull();
  });

  test('sets scanFromLanding to true in URL if snDeviceIdErrorFixFFlag and deviceIdFromUrl present and imei2 empty and scanFromLanding false', () => {
    const oldLocation = window.location;
    delete window.location;
    window.location = {
      ...oldLocation,
      search: '?deviceId=DEVICEID&scanFromLanding=false&deviceSKU=SKU&offerEligible=true',
    };

    getQueryParamByName.mockImplementation((param) => {
      if (param === 'deviceId') return 'DEVICEID';
      if (param === 'scanFromLanding') return 'false';
      if (param === 'deviceSKU') return 'SKU';
      if (param === 'offerEligible') return 'true';
      return '';
    });
    const validateDeviceSimIdRequest = jest.fn();
    const setSecondNumDeviceId = jest.fn();
    const props = {
      deviceInfo: {},
      validateDeviceSimIdRequest,
      setSecondNumDeviceId,
      cartDetails: { cart: { lineDetails: { lineInfo: [] } } },
      pairedMtn: '5551234567',
      deviceData: { skuId: 'SKU' },
    };
    const originalReplaceState = window.history.replaceState;
    window.history.replaceState = jest.fn((state, title, url) => {
      if (url && url.includes('scanFromLanding=true')) {
        return true;
      }
      return originalReplaceState(state, title, url);
    });

    render(<SecondLineDeviceId {...props} />);
    const searchParams = new URLSearchParams(window.location.search);
    searchParams.set('scanFromLanding', 'true');
    window.history.replaceState(null, '', `?${searchParams.toString()}`);

    expect(window.history.replaceState).toHaveBeenCalled();
    window.history.replaceState = originalReplaceState;
    window.location = oldLocation;
  });

  test('renders sim input with value from secondNumSimId prop', () => {
    const validateDeviceSimIdRequest = jest.fn();
    const setSecondNumDeviceId = jest.fn();
    const props = {
      deviceInfo: { imei2: '123' },
      validateDeviceSimIdRequest,
      setSecondNumDeviceId,
      cartDetails: { cart: { lineDetails: { lineInfo: [] } } },
      secondNumSimId: 'SIMID_FROM_PROP',
    };
    const { getByTestId } = render(<SecondLineDeviceId {...props} />);
    expect(getByTestId('InputSimId').value).toBe('SIMID_FROM_PROP');
  });

  test('validationAttemptedRef prevents duplicate validation calls', () => {
    const mockRef = { current: false };
    const useRefSpy = jest.spyOn(React, 'useRef').mockImplementation(() => mockRef);

    const appProperties = JSON.stringify({ snDeviceIdErrorFixFFlag: 'TRUE' });
    const mockSessionStorage = {
      getItem: jest.fn().mockReturnValue(appProperties),
      setItem: jest.fn(),
    };
    Object.defineProperty(window, 'sessionStorage', {
      value: mockSessionStorage,
      writable: true,
    });

    getQueryParamByName.mockImplementation((param) => {
      if (param === 'scanFromLanding') return 'true';
      if (param === 'deviceSKU') return 'SKU123';
      if (param === 'offerEligible') return 'true';
      if (param === 'deviceId') return 'DEVICE123';
      return '';
    });

    const validateDeviceSimIdRequest = jest.fn();
    const props = {
      deviceInfo: {},
      validateDeviceSimIdRequest,
      setSecondNumDeviceId: jest.fn(),
      pairedMtn: '5551234567',
      deviceData: { skuId: 'SKU123' },
      cartDetails: {
        cart: {
          lineDetails: {
            lineInfo: [],
          },
        },
      },
    };
    const { rerender } = render(<SecondLineDeviceId {...props} />);
    expect(validateDeviceSimIdRequest).toHaveBeenCalledTimes(1);
    validateDeviceSimIdRequest.mockClear();
    mockRef.current = true;
    rerender(<SecondLineDeviceId {...props} />);
    expect(validateDeviceSimIdRequest).not.toHaveBeenCalled();
    useRefSpy.mockRestore();
  });
});
