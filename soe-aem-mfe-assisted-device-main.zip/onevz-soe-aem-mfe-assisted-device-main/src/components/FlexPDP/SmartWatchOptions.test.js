import { fireEvent, render, screen } from '../../modules/test-utils/renderHelper';
import SmartWatchOptions from './SmartWatchOptions';

jest.mock('./SmartWatchBandOptions', () => () => {
  const chooseSWBand = jest.fn();
  return (
    <button type='button' onClick={() => chooseSWBand({ target: { value: 'band1' } })}>
      Choose band
    </button>
  );
});
jest.mock('./SmartWatchSizeOptions', () => () => {
  const chooseSWBandSize = jest.fn();
  return (
    <button type='button' onClick={() => chooseSWBandSize({ target: { value: 30 } })}>
      Choose band size
    </button>
  );
});

describe('<SmartWatchOptions/>', () => {
  it('should test <SmartWatchOptions/>', () => {
    render(
      <SmartWatchOptions
        doCallGetSkuDetails={jest.fn()}
        selectedColor='green'
        details={{
          childSkus: [{ skuFilters: { band: 'band1', size: 30 }, color: { displayName: 'green' } }],
          defaultSKUObj: { skuFilters: { band: 'band1', size: 30 } },
        }}
        groupBySmartWatchBand={jest.fn()}
      />,
    );
    fireEvent.click(
      screen.getByRole('button', {
        name: 'Choose band',
      }),
    );
    fireEvent.click(
      screen.getByRole('button', {
        name: /choose band size/i,
      }),
    );

    expect(
      screen.getByRole('button', {
        name: 'Choose band',
      }),
    ).toBeInTheDocument();
  });
  it('should test <SmartWatchOptions/>', () => {
    render(
      <SmartWatchOptions
        doCallGetSkuDetails={jest.fn()}
        selectedColor='green'
        details={{ childSkus: [], defaultSKUObj: { skuFilters: {} } }}
        groupBySmartWatchBand={jest.fn()}
      />,
    );
    expect(
      screen.getByRole('button', {
        name: 'Choose band',
      }),
    ).toBeInTheDocument();
  });
});
