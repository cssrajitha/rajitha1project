import { TitleLockup } from '@vds/type-lockups';
import { Line } from '@vds/lines';
import styled from 'styled-components';
import { Padding24, FlexJustify, StyledBorder } from '../CombinedGridwall/FlexGlobalStyledConstants';

const Padding = styled(Padding24)`
  > div:first-child {
    align-items: flex-start;
  }
`;

function SpecsContainer(props) {
  return (
    <FlexJustify data-testid='specsContainerid'>
      <StyledBorder>
        <Padding>
          <TitleLockup
            data={{
              title: {
                bold: false,
                size: 'titleSmall',
                children: props.title,
              },
              subtitle: {
                size: 'bodySmall',
                color: 'secondary',
                children: props.subtitle,
              },
            }}
          />
        </Padding>
        <Line type='secondary' />
      </StyledBorder>
    </FlexJustify>
  );
}
export default SpecsContainer;
