/* eslint-disable max-classes-per-file */
import { render, screen, fireEvent } from '../../modules/test-utils/renderHelper';
import NumberShareModal from './NumberShareModal';
import { CHANNELS, setupChannel } from '../../modules/test-utils/utils';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { setupServer } from '../../pages/PDP/mocks/setupServer';
import * as deviceInfoUtils from '../../modules/utils';

const Test = (channel) => {
  setupChannel(channel);
  describe(`<NumberShareModal component - ${channel}`, () => {
    setupServer();

    const props = {
      closeClickHandler: jest.fn(),
      setEnableBYODbtn: jest.fn(),
      opened: true,
      numberShareDetails: {
        numberShareList: [
          {
            customerName: 'RAVI JETER',
            nickName: 'RAVI-7979',
            mtn: '5155547979',
            deviceDisplayName: 'IPHONE 13 MINI 128 MIDNIGHT',
            deviceImageUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-mini-midnight',
            currentConnectedDevices: 0,
            maxConnectedDevicesAllowed: 5,
            preSelect: false,
            trunkMtn: '5155547979',
          },
          {
            customerName: 'SYAM JETER',
            nickName: 'SYAM-7979',
            mtn: '5155547970',
            deviceDisplayName: 'IPHONE 13 MINI 128 MIDNIGHT',
            deviceImageUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-mini-midnight',
            currentConnectedDevices: 0,
            maxConnectedDevicesAllowed: 5,
            preSelect: false,
            mldTrunkMtn: '5155547970',
          },
        ],
        numberShareLoadable: false,
      },
      updateNumberShareValue: jest.fn(),
    };
    beforeAll(() => {
      class ResizeObserver {
        constructor() {
          this.observe = () => jest.fn();
          this.unobserve = () => jest.fn();
          this.disconnect = () => jest.fn();
        }
      }
      window.ResizeObserver = ResizeObserver;
    });
    beforeEach(() => {
      render(<NumberShareModal {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });

    test('NumberShareModal Component to be rendered on screen', async () => {
      const testDeviceProtection = await screen.getByText('Number Share');
      expect(testDeviceProtection).toBeInTheDocument();
      const btn = await screen.findByTestId('OkButton');
      fireEvent.click(btn);
      const radio = screen.getByText('RAVI JETER');
      fireEvent.click(radio);
      fireEvent.click(btn);
    });

    test('NumberShareModal Component to be rendered on screen', async () => {
      const testDeviceProtection = await screen.getByText('Number Share');
      expect(testDeviceProtection).toBeInTheDocument();
      const btn = await screen.findByTestId('OkButton');
      fireEvent.click(btn);
      const radio = screen.getByText('SYAM JETER');
      fireEvent.click(radio);
      fireEvent.click(btn);
    });
    test('NumberShareModal Component to be rendered on screen', async () => {
      const testDeviceProtection = await screen.getByText('Number Share');
      expect(testDeviceProtection).toBeInTheDocument();
      const btn = await screen.findByTestId('OkButton');
      const radio = screen.getAllByRole('radio')[0];
      fireEvent.change(radio, { target: { value: '5155547979' } });
      fireEvent.click(btn);
    });

    it('should click back button', () => {
      const testBackGridwall = screen.getByTestId('testBackGridwall');
      expect(testBackGridwall).toBeInTheDocument();
      fireEvent.click(testBackGridwall);
    });
  });
};

const Test2 = (channel) => {
  describe(`<NumberShareModal component - ${channel}`, () => {
    setupServer();

    const props = {
      closeClickHandler: jest.fn(),
      setEnableBYODbtn: jest.fn(),
      opened: true,
      numberShareDetails: {
        numberShareList: [],
        numberShareLoadable: false,
      },
      updateNumberShareValue: jest.fn(),
    };
    beforeAll(() => {
      class ResizeObserver {
        constructor() {
          this.observe = () => jest.fn();
          this.unobserve = () => jest.fn();
          this.disconnect = () => jest.fn();
        }
      }
      window.ResizeObserver = ResizeObserver;
    });
    beforeEach(() => {
      render(<NumberShareModal {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });

    test('NumberShareModal Component to be rendered on screen', async () => {
      const testDeviceProtection = await screen.getByText('Number Share');
      expect(testDeviceProtection).toBeInTheDocument();
    });
  });
};

const Test3 = (channel) => {
  setupChannel(channel);
  describe(`<NumberShareModal component - ${channel}`, () => {
    setupServer();

    beforeAll(() => {
      class ResizeObserver {
        constructor() {
          this.observe = () => jest.fn();
          this.unobserve = () => jest.fn();
          this.disconnect = () => jest.fn();
        }
      }
      window.ResizeObserver = ResizeObserver;
      window.mfe = { scmDeviceMfeEnable: true };
    });

    test('NumberShareModal Component to be rendered on screen', async () => {
      const props = {
        closeClickHandler: jest.fn(),
        setEnableBYODbtn: jest.fn(),
        opened: true,
        numberShareValue: '',
        numberShareDetails: {
          numberShareList: [
            {
              customerName: 'RAVI JETER',
              nickName: 'RAVI-7979',
              mtn: '5155547979',
              deviceDisplayName: 'IPHONE 13 MINI 128 MIDNIGHT',
              deviceImageUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-mini-midnight',
              currentConnectedDevices: 0,
              maxConnectedDevicesAllowed: 5,
              preSelect: false,
              trunkMtn: '5155547979',
            },
            {
              customerName: 'SYAM JETER',
              nickName: 'SYAM-7979',
              mtn: '',
              deviceDisplayName: 'IPHONE 13 MINI 128 MIDNIGHT',
              deviceImageUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-mini-midnight',
              currentConnectedDevices: 0,
              maxConnectedDevicesAllowed: 5,
              preSelect: false,
              mldTrunkMtn: '',
            },
          ],
          numberShareLoadable: false,
        },
        updateNumberShareValue: jest.fn(),
      };
      render(<NumberShareModal {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      const testDeviceProtection = await screen.getByText('Number Share');
      expect(testDeviceProtection).toBeInTheDocument();
      const btn = await screen.findByTestId('OkButton');
      const radio = screen.getByText('RAVI JETER');
      fireEvent.click(radio);
      fireEvent.click(btn);
    });
    test('NumberShareModal Component to be rendered on screen', async () => {
      const props = {
        closeClickHandler: jest.fn(),
        opened: true,
        numberShareValue: '',
        numberShareDetails: {
          numberShareList: [],
          numberShareLoadable: false,
        },
        updateNumberShareValue: jest.fn(),
      };
      window.mfe = { scmDeviceMfeEnable: true };
      render(<NumberShareModal {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      const testDeviceProtection = await screen.getByText('Number Share');
      expect(testDeviceProtection).toBeInTheDocument();
      const btn = await screen.findByTestId('OkButton');
      fireEvent.click(btn);
    });
    test('NumberShareModal Component to be rendered on screen when numberShareDetails as empty', async () => {
      const props = {
        closeClickHandler: jest.fn(),
        opened: true,
        numberShareValue: '',
        updateNumberShareValue: jest.fn(),
      };
      window.mfe = { scmDeviceMfeEnable: true };
      render(<NumberShareModal {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      const testDeviceProtection = await screen.getByText('Number Share');
      expect(testDeviceProtection).toBeInTheDocument();
      const btn = await screen.findByTestId('OkButton');
      fireEvent.click(btn);
    });

    test('NumberShareModal Component to be rendered on screen when isDark is true', async () => {
      const props = {
        closeClickHandler: jest.fn(),
        setEnableBYODbtn: jest.fn(),
        opened: true,
        numberShareValue: '',
        numberShareDetails: {
          numberShareList: [
            {
              customerName: 'RAVI JETER',
              nickName: 'RAVI-7979',
              mtn: '',
              deviceDisplayName: 'IPHONE 13 MINI 128 MIDNIGHT',
              deviceImageUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-mini-midnight',
              currentConnectedDevices: 0,
              maxConnectedDevicesAllowed: 5,
              preSelect: false,
              trunkMtn: '',
            },
            {
              customerName: 'SYAM JETER',
              nickName: 'SYAM-7979',
              mtn: '',
              deviceDisplayName: 'IPHONE 13 MINI 128 MIDNIGHT',
              deviceImageUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-mini-midnight',
              currentConnectedDevices: 0,
              maxConnectedDevicesAllowed: 5,
              preSelect: false,
              mldTrunkMtn: '',
            },
          ],
          numberShareLoadable: false,
        },
        updateNumberShareValue: jest.fn(),
      };
      window.mfe = { scmDeviceMfeEnable: true, isDark: true };
      render(<NumberShareModal {...props} />);
      const testDeviceProtection = await screen.getByText('Number Share');
      expect(testDeviceProtection).toBeInTheDocument();
      const btn = await screen.findByTestId('OkButton');
      fireEvent.click(btn);
    });

    test('NumberShareModal Component to be rendered on screen when isDark is false', async () => {
      const props = {
        closeClickHandler: jest.fn(),
        setEnableBYODbtn: jest.fn(),
        opened: true,
        numberShareValue: '',
        numberShareDetails: {
          numberShareList: [
            {
              customerName: 'RAVI JETER',
              nickName: 'RAVI-7979',
              mtn: '',
              deviceDisplayName: 'IPHONE 13 MINI 128 MIDNIGHT',
              deviceImageUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-mini-midnight',
              currentConnectedDevices: 0,
              maxConnectedDevicesAllowed: 5,
              preSelect: false,
              trunkMtn: '',
            },
            {
              customerName: 'SYAM JETER',
              nickName: 'SYAM-7979',
              mtn: '',
              deviceDisplayName: 'IPHONE 13 MINI 128 MIDNIGHT',
              deviceImageUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-mini-midnight',
              currentConnectedDevices: 0,
              maxConnectedDevicesAllowed: 5,
              preSelect: false,
              mldTrunkMtn: '',
            },
          ],
          numberShareLoadable: false,
        },
        updateNumberShareValue: jest.fn(),
      };
      window.mfe = { scmDeviceMfeEnable: false, isDark: false };
      render(<NumberShareModal {...props} />);
      const testDeviceProtection = await screen.getByText('Number Share');
      expect(testDeviceProtection).toBeInTheDocument();
      const btn = await screen.findByTestId('OkButton');
      fireEvent.click(btn);
    });

    test('NumberShareModal Component to be rendered on screen when isDark is true', async () => {
      const props = {
        closeClickHandler: jest.fn(),
        setEnableBYODbtn: jest.fn(),
        opened: true,
        numberShareValue: '7809090900',
        numberShareDetails: {
          numberShareList: [
            {
              customerName: 'RAVI JETER',
              nickName: 'RAVI-7979',
              mtn: '',
              deviceDisplayName: 'IPHONE 13 MINI 128 MIDNIGHT',
              deviceImageUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-mini-midnight',
              currentConnectedDevices: 0,
              maxConnectedDevicesAllowed: 5,
              preSelect: false,
              trunkMtn: '',
            },
            {
              customerName: 'SYAM JETER',
              nickName: 'SYAM-7979',
              mtn: '',
              deviceDisplayName: 'IPHONE 13 MINI 128 MIDNIGHT',
              deviceImageUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-mini-midnight',
              currentConnectedDevices: 0,
              maxConnectedDevicesAllowed: 5,
              preSelect: false,
              mldTrunkMtn: '',
            },
          ],
          numberShareLoadable: false,
        },
        updateNumberShareValue: jest.fn(),
      };
      jest.spyOn(deviceInfoUtils, 'getFFlag').mockReturnValue('Y');
      render(<NumberShareModal {...props} />);
      const testDeviceProtection = await screen.getByText('Number Share');
      expect(testDeviceProtection).toBeInTheDocument();
      const btn = await screen.findByTestId('OkButton');
      fireEvent.click(btn);
    });
  });
};

Test(CHANNELS.OMNI_RETAIL);
Test2(CHANNELS.OMNI_RETAIL);
Test3(CHANNELS.OMNI_RETAIL);
