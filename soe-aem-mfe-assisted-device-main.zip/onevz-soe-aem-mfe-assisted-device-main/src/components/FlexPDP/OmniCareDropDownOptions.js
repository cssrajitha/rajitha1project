import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { DropdownSelect } from '@vds/selects';
import { getQueryParamByName } from 'onevzsoemfeframework/DomService';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { CARE_DROPDOWN_OPTIONS, DEVICE_CHANGE, SIM_ONLY_CHANGE } from './PDP_Constants';
import { isFunctionalityEnabled } from '../../modules/utils';


const getIsInsideSalesUser = () => window?.mfe?.isProspectNewCustomerTab ? false : window?.mfe?.isInsideSalesUser || false;

function OmniCareDropDownOptions(props) { /* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */
  const { handleDeviceIdSkuHandler, customerProfileDetails, cartDetails, activeMtn, isShowGetESIM, SkuDetailsResult } = props;
  const [dropdownValue, setDropDownValue] = useState(SIM_ONLY_CHANGE);
  const isDark = (window?.mfe?.scmDeviceMfeEnable && window?.mfe?.isDark) || false;
  const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable || false;
  const isInsideSalesUser = getIsInsideSalesUser()
  let skipICCIDFFlag = /true/i.test(getAssistedCradlePropertyV2(['skipICCIDFFlag'])?.[0]);

  if (window?.mfe?.scmDeviceMfeEnable && dropdownValue === 'Generate ESIM Profile') {
    skipICCIDFFlag = false;
  }
  useEffect(() => {
    if (window?.mfe?.scmDeviceMfeEnable) {
      setDropDownValue(DEVICE_CHANGE);
      handleDeviceIdSkuHandler({ enteredSimSku: '', deviceIdSelected: true, dropdownValue: DEVICE_CHANGE });
    } else {
      setDropDownValue(SIM_ONLY_CHANGE);
    }
    const CustomerData = customerProfileDetails?.customer;
    const lineInfo = CustomerData?.billAccounts?.[0]?.mtns?.find((line) => line.mtn === activeMtn);
    const previousDeviceId = lineInfo?.equipmentInfos?.[0]?.deviceInfo?.deviceId;

    cartDetails?.cart?.lineDetails?.lineInfo?.forEach((line) => {
      if (line.mobileNumber === activeMtn) {
        const cartItem = line?.itemsInfo?.[0]?.cartItems?.cartItem;
        cartItem?.forEach((item) => {
          if (item?.cartItemType === 'DEVICE') {
            const newDeviceId = item?.deviceId;
            if (newDeviceId !== previousDeviceId) {
              handleDeviceIdSkuHandler({ enteredSimSku: '', deviceIdSelected: true, dropdownValue: DEVICE_CHANGE });
              setDropDownValue(DEVICE_CHANGE);
            } else {
              // handleDeviceIdSkuHandler({ deviceIdSelected: true, dropdownValue: SIM_ONLY_CHANGE });
              setDropDownValue(SIM_ONLY_CHANGE);
            }
          }
        });
      }
    });
  }, []);

  const handleDeviceIdSku = (e) => {
    const selectionType = e?.target?.value;
    setDropDownValue(selectionType);
    if (selectionType === DEVICE_CHANGE) {
      handleDeviceIdSkuHandler({ enteredSimSku: '', deviceIdSelected: true, dropdownValue: selectionType });
      // if(this.state.ispuToggleOn){
      //   this.props.toggleISPU(true);
      //   this.props.setIspuToggle(true,true)
      // }
      if (!scmUpgradeMfeEnable) {
        window?.store?.dispatch(appMessageActions.clearAppMessages());
      }
    } else if (selectionType === SIM_ONLY_CHANGE) {
      handleDeviceIdSkuHandler({ deviceIdSelected: false, dropdownValue: selectionType });
      // this.props.toggleISPU(false)
      // this.props.setIspuToggle(false,true)
      // this.toggleIspu("false")
    } else if (selectionType === 'Provisional ID') {
      handleDeviceIdSkuHandler({ enteredSimSku: '', deviceIdSelected: true, dropdownValue: selectionType });
    } else if (selectionType === 'Generate ESIM Profile') {
      handleDeviceIdSkuHandler({ deviceIdSelected: false, dropdownValue: selectionType });
    }

    // this.props.updatedSimOrDeviceDropDown(dropdownValue)
  };
  const device_id = getQueryParamByName('deviceId');
  const lineNumber =
    cartDetails?.cart?.lineDetails?.lineInfo?.length > 0 &&
    cartDetails?.cart?.lineDetails?.lineInfo?.find((line) => line?.mobileNumber === activeMtn)?.lineNumber;
  let DROPDOWN_OPTIONS = CARE_DROPDOWN_OPTIONS;

  const isProvIdEnabled = () => {
      const isFwaDevice = SkuDetailsResult?.data?.data?.deviceSku?.parentProducts?.find(prd => ['5G Internet','5G Router']?.includes(prd?.sorDeviceCategory));
      if (isFwaDevice) {
          return isFunctionalityEnabled('scmCommonFixFFlag','enableProvIdFWA','ACSS_SC_ENABLE_PROVID_FWA');
      } 
      return true;
  }

  if (
    window?.mfe?.scmDeviceMfeEnable &&
    device_id !== 'undefined' &&
    window?.mfe?.scmProvisionalFFlag &&
    !(lineNumber && lineNumber?.includes('newLine')) &&
    isProvIdEnabled()
  ){
    DROPDOWN_OPTIONS = [
      ...CARE_DROPDOWN_OPTIONS,
      {
        label: 'Provisional ID',
        value: 'Provisional ID',
      },
    ];
  }

  if (window?.mfe?.scmDeviceMfeEnable && isShowGetESIM) {
    DROPDOWN_OPTIONS.push({
      label: 'Generate ESIM Profile',
      value: 'Generate ESIM Profile',
    });
  }
  if (skipICCIDFFlag) {
    if (props?.simFromFilteredCartLine?.eSIM || props?.removeSimOnlyChange) {
      DROPDOWN_OPTIONS = DROPDOWN_OPTIONS.filter((option) => option.value !== SIM_ONLY_CHANGE);
      handleDeviceIdSkuHandler({ enteredSimSku: '', deviceIdSelected: true, dropdownValue: DEVICE_CHANGE }, false);
    } else if (dropdownValue === SIM_ONLY_CHANGE) {
      handleDeviceIdSkuHandler({ deviceIdSelected: false, dropdownValue: SIM_ONLY_CHANGE }, false);
    }
  }
  return (
    <div className='u-marginBottomLarge u-marginTopLarge' style={window?.mfe?.scmDeviceMfeEnable ? { zIndex: 0 } : {}}>
      <DropdownSelect
        width='50%'
        id='careChannel'
        value={dropdownValue}
        surface={isDark ? 'dark' : 'light'}
        // disabled={pendingOrderOnLine}
        disabled={isInsideSalesUser || false}
        onChange={(e) => handleDeviceIdSku(e)}
        data-testid='devicesimonlyChange'
      >
        {DROPDOWN_OPTIONS.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}{' '}
          </option>
        ))}
      </DropdownSelect>
    </div>
  );
}
OmniCareDropDownOptions.propTypes = {
  cartDetails: PropTypes.shape({
    cart: PropTypes.shape({
      lineDetails: PropTypes.shape({
        lineInfo: PropTypes.array.isRequired,
      }),
    }),
  }),
  activeMtn: PropTypes.string,
  customerProfileDetails: PropTypes.object,
  handleDeviceIdSkuHandler: PropTypes.func,
  isShowGetESIM: PropTypes.bool,
};
export default OmniCareDropDownOptions;
