import { render, fireEvent, screen, waitFor } from '../../modules/test-utils/renderHelper';
import PDP5G from './PDP5G';
import { Context } from '../../pages/PDP5G/PDP5gContext';
import {
  Deviceinfo5gMock,
  Deviceinfo5gMockProductDetails,
  Deviceinfo5gMockBundleProduct,
  Deviceinfo5gMockWithoutInventory,
  Deviceinfo5gMockWithoutInventoryDfill,
  Deviceinfo5gMockWithoutInventoryInstock,
  Deviceinfo5gMockWithoutInventoryWithBundle,
  Deviceinfo5gMockWithoutInventoryInstockWithBundle,
  Deviceinfo5gMockWithoutInventoryInstockWithOutBundle,
  Deviceinfo5gMockWithoutInventoryInstockWithOutBundleBillAccount,
  Deviceinfo5gMockWithoutLocal,
} from './mocks/Deviceinfo5gMock';
import {
  PDP5gMock,
  PDP5gMockByodUpdate,
  PDP5gMockContract,
  PDP5gMockWsap,
  PDP5gMockScan,
  PDP5gMockScanBundle,
  PDP5gMockEmpty,
  PDP5gMockIspu,
} from './mocks/PDP5gMock';

describe(`<PDP5G /> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMock}>
        <PDP5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    waitFor(() => {
      expect(
        screen.getByText(
          'The availability of LTE Home Internet Service and the use of the LTE Home Router/antenna is limited to certain areas. The LTE Home Router can only be used at the service address registered at the time of order placement, and the device will not work if moved to another location',
        ),
      ).toBeInTheDocument();
    });
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<PDP5G /> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={PDP5gMockIspu}>
        <PDP5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const shipit = await screen.getByRole('button', {
      name: 'Pick Up',
    });
    fireEvent.click(shipit);
  });
});
describe(`<PDP5G /> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={PDP5gMockEmpty}>
        <PDP5G />
      </Context.Provider>,
    );
  });
  test.skip('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<PDP5G /> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={PDP5gMockScanBundle}>
        <PDP5G />
      </Context.Provider>,
    );
  });
  test.skip('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<PDP5G /> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={PDP5gMock}>
        <PDP5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<PDP5G /> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={PDP5gMockWsap}>
        <PDP5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<PDP5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMockWithoutLocal}>
        <PDP5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<PDP5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={PDP5gMockByodUpdate}>
        <PDP5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const cpsArea = screen.queryByText('Ship this device');
    expect(cpsArea).toBeNull(); // it doesn't exist
  });
});
describe(`<PDP5G/> component mount1`, () => {
  beforeEach(() => {
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/product-detail.html?activeMtn=5139074854&deviceSKU=MQ8R3LL/A&isContractChange=true&isWSAPCpeError=350321532631401',
    );

    render(
      <Context.Provider value={PDP5gMockContract}>
        <PDP5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
  test('should mount', async () => {
    const close = await screen.getByRole('button', {
      name: 'close icon',
    });
    fireEvent.click(close);
  });
});
describe(`<PDP5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMockWithoutInventoryInstockWithOutBundleBillAccount}>
        <PDP5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<PDP5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={PDP5gMockScan}>
        <PDP5G />
      </Context.Provider>,
    );
  });
  test.skip('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<PDP5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMockWithoutInventoryInstockWithOutBundle}>
        <PDP5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<PDP5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMockProductDetails}>
        <PDP5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<PDP5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMockBundleProduct}>
        <PDP5G />
      </Context.Provider>,
    );
  });
  test.skip('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<PDP5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMockWithoutInventory}>
        <PDP5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<PDP5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMockWithoutInventoryInstock}>
        <PDP5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<PDP5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMockWithoutInventoryDfill}>
        <PDP5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<PDP5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMockWithoutInventoryWithBundle}>
        <PDP5G />
      </Context.Provider>,
    );
  });
  test.skip('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<PDP5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMockWithoutInventoryInstockWithBundle}>
        <PDP5G />
      </Context.Provider>,
    );
  });
  test.skip('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
  test('should mount', async () => {
    expect(screen.getAllByRole('radio')[0]).toBeInTheDocument();
    fireEvent.change(screen.getAllByRole('radio')[0]);
  });
});
