import React from 'react';
import { render, screen, fireEvent, within } from '@testing-library/react';
import PaymentOptionsDisclaimer from '../PaymentOptionsDisclaimer';
import { formatCurrency } from 'onevzsoemfecommon/Helpers';

jest.mock('onevzsoemfecommon/Helpers', () => ({
  formatCurrency: jest.fn(),
}));

// Move these mocks to top-level scope for all tests
const mockDpEligibilityResult = {
  data: {
    isDevicePaymentEligible: true,
    totalFinanceLimit: 5000,
    downPaymentPercentage: 10,
  },
};

const mockSelectedSku = {
  oneYearPrice: true,
  twoYearPrice: false,
  thirtyMonthPrice: true,
  threeYearPrice: false,
  devicePaymentPrice: [
    { contractDuration: 24 },
    { contractDuration: 36 },
  ],
};

const mockPropsForFalseCases = {
  dpEligibilityResult: {
    data: {
      isDevicePaymentEligible: false,
      totalFinanceLimit: 0,
      downPaymentPercentage: 0,
    },
  },
  // Renamed from price to selectedSku
  selectedSku: {
    oneYearPrice: false,
    twoYearPrice: false,
    thirtyMonthPrice: false,
    threeYearPrice: false,
    devicePaymentPrice: [{ contractDuration: 12 }],
  },
};

beforeEach(() => {
  formatCurrency.mockImplementation((value) => `$${Number(value).toFixed(2)}`);
});

afterEach(() => {
  jest.clearAllMocks();
});

describe('PaymentOptionsDisclaimer', () => {
  test('renders null when dpEligibilityResult?.data is not provided', () => {
    const { container } = render(<PaymentOptionsDisclaimer dpEligibilityResult={null} selectedSku={mockSelectedSku} />);
    expect(container.firstChild).toBeNull();
  });

  test('renders eligibility information when dpEligibilityResult?.data is provided', () => {
    render(<PaymentOptionsDisclaimer dpEligibilityResult={mockDpEligibilityResult} selectedSku={mockSelectedSku} />);
    expect(screen.getByText(/Price and contract terms display based on the customer's contract/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /View eligibility details/i })).toBeInTheDocument();
  });

  test('toggles popup visibility when the Icon is clicked', () => {
    render(<PaymentOptionsDisclaimer dpEligibilityResult={mockDpEligibilityResult} selectedSku={mockSelectedSku} />);
    const iconButton = screen.getByRole('button', { name: /View eligibility details/i });

    expect(screen.queryByText(/Dpp Eligible/i)).not.toBeInTheDocument();
    fireEvent.click(iconButton);
    expect(screen.getByText(/Dpp Eligible/i)).toBeInTheDocument();
    fireEvent.click(iconButton);
    expect(screen.queryByText(/Dpp Eligible/i)).not.toBeInTheDocument();
  });

  test('closes the popup when clicking outside', () => {
    render(<PaymentOptionsDisclaimer dpEligibilityResult={mockDpEligibilityResult} selectedSku={mockSelectedSku} />);
    const iconButton = screen.getByRole('button', { name: /View eligibility details/i });

    fireEvent.click(iconButton);
    expect(screen.getByText(/Dpp Eligible/i)).toBeInTheDocument();
    fireEvent.mouseDown(document.body);
    expect(screen.queryByText(/Dpp Eligible/i)).not.toBeInTheDocument();
  });

  test('does not close popup when a mousedown event occurs inside the popup', () => {
    render(<PaymentOptionsDisclaimer dpEligibilityResult={mockDpEligibilityResult} selectedSku={mockSelectedSku} />);
    const infoIcon = screen.getByLabelText('View eligibility details');

    fireEvent.click(infoIcon);
    const popup = screen.getByText(/Dpp Eligible/i).closest('div');
    fireEvent.mouseDown(popup);
    expect(screen.getByText(/Dpp Eligible/i)).toBeInTheDocument();
  });

  test('displays correct data in the tables for eligible cases', () => {
    render(<PaymentOptionsDisclaimer dpEligibilityResult={mockDpEligibilityResult} selectedSku={mockSelectedSku} />);
    const iconButton = screen.getByRole('button', { name: /View eligibility details/i });
    fireEvent.click(iconButton);

    const dppDetailsTable = screen.getByText('Dpp Eligible').closest('table');
    expect(within(dppDetailsTable).getByText('Y')).toBeInTheDocument();
    expect(within(dppDetailsTable).getByText('$5000.00')).toBeInTheDocument();
    expect(within(dppDetailsTable).getByText('10%')).toBeInTheDocument();

    const oneYearRow = screen.getByText('1 Year').closest('tr');
    expect(within(oneYearRow).getByText('Y')).toBeInTheDocument();

    const twoYearRow = screen.getByText('2 Year').closest('tr');
    expect(within(twoYearRow).getByText('N')).toBeInTheDocument();

    const thirtyMonthRow = screen.getByText('30 Month').closest('tr');
    expect(within(thirtyMonthRow).getByText('Y')).toBeInTheDocument();

    const threeYearRow = screen.getByText('3 Year').closest('tr');
    expect(within(threeYearRow).getByText('N')).toBeInTheDocument();

    const dp36Row = screen.getByText('DP 36 Month').closest('tr');
    expect(within(dp36Row).getByText('Y')).toBeInTheDocument();

    const dp24Row = screen.getByText('DP 24 Month').closest('tr');
    expect(within(dp24Row).getByText('Y')).toBeInTheDocument();

    const dp30Row = screen.getByText('DP 30 Month').closest('tr');
    expect(within(dp30Row).getByText('N')).toBeInTheDocument();
  });

  test('toggles popup visibility with keyboard events', () => {
    render(<PaymentOptionsDisclaimer dpEligibilityResult={mockDpEligibilityResult} selectedSku={mockSelectedSku} />);
    const iconButton = screen.getByRole('button', { name: /View eligibility details/i });

    fireEvent.keyDown(iconButton, { key: 'Enter', code: 'Enter' });
    expect(screen.getByText(/Dpp Eligible/i)).toBeInTheDocument();

    fireEvent.keyDown(iconButton, { key: ' ', code: 'Space' });
    expect(screen.queryByText(/Dpp Eligible/i)).not.toBeInTheDocument();
  });

  test('returns null if dpEligibilityResult data is missing', () => {
    const { container } = render(
      <PaymentOptionsDisclaimer dpEligibilityResult={{}} selectedSku={mockSelectedSku} />
    );
    expect(container.firstChild).toBeNull();
  });

  test('does not close popup when icon is clicked again', () => {
    render(<PaymentOptionsDisclaimer dpEligibilityResult={mockDpEligibilityResult} selectedSku={mockSelectedSku} />);
    const iconButton = screen.getByRole('button', { name: /View eligibility details/i });

    fireEvent.click(iconButton);
    expect(screen.getByText(/Dpp Eligible/i)).toBeInTheDocument();

    fireEvent.mouseDown(iconButton);
    expect(screen.getByText(/Dpp Eligible/i)).toBeInTheDocument();
  });

  test('displays "N" for ineligible or missing data', () => {
    render(<PaymentOptionsDisclaimer dpEligibilityResult={mockPropsForFalseCases.dpEligibilityResult} selectedSku={mockPropsForFalseCases.selectedSku} />);
    const iconButton = screen.getByRole('button', { name: /View eligibility details/i });
    fireEvent.click(iconButton);

    const dppDetailsTable = screen.getByText('Dpp Eligible').closest('table');
    expect(within(dppDetailsTable).getByText('N')).toBeInTheDocument();
    expect(within(dppDetailsTable).getByText('$0.00')).toBeInTheDocument();
    expect(within(dppDetailsTable).getByText('0%')).toBeInTheDocument();

    const oneYearRow = screen.getByText('1 Year').closest('tr');
    expect(within(oneYearRow).getByText('N')).toBeInTheDocument();

    const twoYearRow = screen.getByText('2 Year').closest('tr');
    expect(within(twoYearRow).getByText('N')).toBeInTheDocument();

    const thirtyMonthRow = screen.getByText('30 Month').closest('tr');
    expect(within(thirtyMonthRow).getByText('N')).toBeInTheDocument();

    const threeYearRow = screen.getByText('3 Year').closest('tr');
    expect(within(threeYearRow).getByText('N')).toBeInTheDocument();

    const dp36Row = screen.getByText('DP 36 Month').closest('tr');
    expect(within(dp36Row).getByText('N')).toBeInTheDocument();

    const dp24Row = screen.getByText('DP 24 Month').closest('tr');
    expect(within(dp24Row).getByText('N')).toBeInTheDocument();

    const dp30Row = screen.getByText('DP 30 Month').closest('tr');
    expect(within(dp30Row).getByText('N')).toBeInTheDocument();
  });

  test('displays "Y" for twoYearPrice and threeYearPrice when true', () => {
    const selectedSkuWithTrueYears = {
      oneYearPrice: false,
      twoYearPrice: true,
      thirtyMonthPrice: false,
      threeYearPrice: true,
      devicePaymentPrice: [],
    };
    render(<PaymentOptionsDisclaimer dpEligibilityResult={mockDpEligibilityResult} selectedSku={selectedSkuWithTrueYears} />);
    fireEvent.click(screen.getByRole('button', { name: /View eligibility details/i }));
  
    const twoYearRow = screen.getByText('2 Year').closest('tr');
    expect(within(twoYearRow).getByText('Y')).toBeInTheDocument();
  
    const threeYearRow = screen.getByText('3 Year').closest('tr');
    expect(within(threeYearRow).getByText('Y')).toBeInTheDocument();
  });

  test('displays "Y" for DP 30 Month when available', () => {
    const selectedSkuWith30MonthDP = {
      devicePaymentPrice: [{ contractDuration: 30 }],
    };
  
    render(<PaymentOptionsDisclaimer dpEligibilityResult={mockDpEligibilityResult} selectedSku={selectedSkuWith30MonthDP} />);
    fireEvent.click(screen.getByRole('button', { name: /View eligibility details/i }));
  
    const dp30Row = screen.getByText('DP 30 Month').closest('tr');
    expect(within(dp30Row).getByText('Y')).toBeInTheDocument();
  });
});

describe('updateAlignment callback', () => {
  let originalGetBoundingClientRect;
  beforeEach(() => {
    originalGetBoundingClientRect = Object.getOwnPropertyDescriptor(HTMLElement.prototype, 'getBoundingClientRect');
  });
  afterEach(() => {
    if (originalGetBoundingClientRect) {
      Object.defineProperty(HTMLElement.prototype, 'getBoundingClientRect', originalGetBoundingClientRect);
    }
  });

  test('sets alignRight to true when icon is closer to right edge', () => {
    Object.defineProperty(HTMLElement.prototype, 'getBoundingClientRect', {
      configurable: true,
      value: jest.fn(() => ({ left: 100, right: window.innerWidth - 10 })),
    });
    render(<PaymentOptionsDisclaimer dpEligibilityResult={mockDpEligibilityResult} selectedSku={mockSelectedSku} />);
    fireEvent(window, new Event('resize'));
    const iconButton = screen.getByRole('button', { name: /View eligibility details/i });
    fireEvent.click(iconButton);
    const popup = screen.getByTestId('popup');
    expect(popup.getAttribute('data-alignright')).toBe('true');
  });

  test('sets alignRight to false when icon is closer to left edge', () => {
    Object.defineProperty(HTMLElement.prototype, 'getBoundingClientRect', {
      configurable: true,
      value: jest.fn(() => ({ left: 10, right: 100 })),
    });
    render(<PaymentOptionsDisclaimer dpEligibilityResult={mockDpEligibilityResult} selectedSku={mockSelectedSku} />);
    fireEvent(window, new Event('resize'));
    const iconButton = screen.getByRole('button', { name: /View eligibility details/i });
    fireEvent.click(iconButton);
    const popup = screen.getByTestId('popup');
    expect(popup.getAttribute('data-alignright')).toBe('false');
  });
});

describe('useLayoutEffect alignment logic', () => {
  let originalIconRect;
  let originalPopupRect;
  beforeEach(() => {
    originalIconRect = Object.getOwnPropertyDescriptor(HTMLElement.prototype, 'getBoundingClientRect');
    originalPopupRect = Object.getOwnPropertyDescriptor(HTMLElement.prototype, 'getBoundingClientRect');
  });
  afterEach(() => {
    if (originalIconRect) {
      Object.defineProperty(HTMLElement.prototype, 'getBoundingClientRect', originalIconRect);
    }
    if (originalPopupRect) {
      Object.defineProperty(HTMLElement.prototype, 'getBoundingClientRect', originalPopupRect);
    }
  });

  function setupRects(iconRect, popupRect) {
    let callCount = 0;
    Object.defineProperty(HTMLElement.prototype, 'getBoundingClientRect', {
      configurable: true,
      value: jest.fn(() => {
        callCount++;
        return callCount === 1 ? iconRect : popupRect;
      }),
    });
  }

  test('aligns right if popup would overflow right', () => {
    setupRects({ left: 100, right: 400 }, { width: window.innerWidth });
    render(<PaymentOptionsDisclaimer dpEligibilityResult={mockDpEligibilityResult} selectedSku={mockSelectedSku} />);
    fireEvent.click(screen.getByRole('button', { name: /View eligibility details/i }));
    const popup = screen.getByTestId('popup');
    expect(popup.getAttribute('data-alignright')).toBe('true');
  });

  test('aligns left if popup would overflow left', () => {
    setupRects({ left: 10, right: 100 }, { width: 200 });
    render(<PaymentOptionsDisclaimer dpEligibilityResult={mockDpEligibilityResult} selectedSku={mockSelectedSku} />);
    fireEvent.click(screen.getByRole('button', { name: /View eligibility details/i }));
    const popup = screen.getByTestId('popup');
    expect(popup.getAttribute('data-alignright')).toBe('false');
  });

  test('aligns based on which side has more space', () => {
    setupRects({ left: 200, right: 400 }, { width: 100 });
    render(<PaymentOptionsDisclaimer dpEligibilityResult={mockDpEligibilityResult} selectedSku={mockSelectedSku} />);
    fireEvent.click(screen.getByRole('button', { name: /View eligibility details/i }));
    const popup = screen.getByTestId('popup');
    // window.innerWidth - iconRect.right < iconRect.left
    const expected = (window.innerWidth - 400 < 200).toString();
    expect(popup.getAttribute('data-alignright')).toBe(expected);
  });
});