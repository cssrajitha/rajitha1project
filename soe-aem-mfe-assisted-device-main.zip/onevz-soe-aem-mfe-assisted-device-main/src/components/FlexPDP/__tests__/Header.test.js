import { fireEvent, render, screen, waitFor } from '../../../modules/test-utils/renderHelper';
import Header from '../Header';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';

const renderComponent = (mdn = '8145772880', closeIcon = { popupModalclose: true }) => {
  const closeClickHandler = jest.fn();
  const moreOptionClickHandler = jest.fn();
  const navigatePdp = jest.fn();
  const setDownPaymentObj = jest.fn();

  const header = 'iPhone 14 Pro';
  const line = 'JOSEPH';
  const downPayment = 10;
  // const mdn = '8145772880';
  render(
    <Header
      data={{
        header,
        line,
        mdn,
        closeIcon,
        closeClickHandler,
        moreOptionClickHandler,
        navigatePdp,
      }}
      productDetails={{
        deviceProduct: {
          commonInfo: {
            showPrice: true,
            displayReasonCode: true,
            showShipitToggle: true,
            flexPDPTradeInLinkEnabled: true,
            containSoftSku: false,
            dpEligible: true,
            indirect: false,
          },
        },
      }}
      isFromCPE={false}
      isRfexFlow={false}
      isNewLine={false}
      channel='OMNI-RETAIL'
      downPayment={downPayment}
      setDownPaymentObj={setDownPaymentObj}
    />,
    {
      reducers: rootReducer,
      sagas: rootSaga,
    },
  );
  return {
    header,
    line,
    mdn,
    closeIcon,
    closeClickHandler,
    moreOptionClickHandler,
  };
};

const renderComponentWithoutClosehandler = (mdn = '8145772880', closeIcon = { popupModalclose: true }) => {
  const closeClickHandler = jest.fn();
  const moreOptionClickHandler = jest.fn();
  const navigatePdp = jest.fn();
  const setDownPaymentObj = jest.fn();

  const header = 'iPhone 14 Pro';
  const line = 'JOSEPH';
  const downPayment = 10;
  // const mdn = '8145772880';
  render(
    <Header
      data={{
        header,
        line,
        mdn,
        closeIcon,
        closeClickHandler: undefined,
        moreOptionClickHandler,
        navigatePdp,
      }}
      productDetails={{
        deviceProduct: {
          commonInfo: {
            showPrice: true,
            displayReasonCode: true,
            showShipitToggle: true,
            flexPDPTradeInLinkEnabled: true,
            containSoftSku: false,
            dpEligible: true,
            indirect: false,
          },
        },
      }}
      isFromCPE={false}
      isRfexFlow={false}
      isNewLine={false}
      channel='OMNI-RETAIL'
      downPayment={downPayment}
      setDownPaymentObj={setDownPaymentObj}
    />,
    {
      reducers: rootReducer,
      sagas: rootSaga,
    },
  );
  return {
    header,
    line,
    mdn,
    closeIcon,
    closeClickHandler,
    moreOptionClickHandler,
  };
};
jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);
describe('<Header/>', () => {
  beforeEach(() => {
    window.mfe = {};
  });
  it('should test header component everything is visible except for more options', () => {
    const { header, closeClickHandler } = renderComponent('8145772880');
    const closeButton = screen.getByRole('img', {
      name: /close icon/i,
    });
    expect(closeButton).toBeInTheDocument();
    expect(screen.queryByText(/more options/i)).toBeNull();
    expect(
      screen.getByRole('heading', {
        name: new RegExp(header, 'i'),
      }),
    ).toBeInTheDocument();
    screen.getByRole('heading', {
      name: /joseph 814-577-2880/i,
    });
    fireEvent.click(closeButton);
    expect(closeClickHandler).toBeCalled();
  });

  it('should test header component everything is visible except for more options when theme is dark', () => {
    window.mfe.scmDeviceMfeEnable = true;
    window.mfe.isDark = true;
    const { header, closeClickHandler } = renderComponent('8145772880');
    const closeButton = screen.getByRole('img', {
      name: /close icon/i,
    });
    expect(closeButton).toBeInTheDocument();
    expect(screen.queryByText(/more options/i)).toBeNull();
    expect(
      screen.getByRole('heading', {
        name: new RegExp(header, 'i'),
      }),
    ).toBeInTheDocument();
    fireEvent.click(closeButton);
    expect(closeClickHandler).toBeCalled();
  });

  it('should test scmDeviceMfeEnable navigatereturn (-1)', () => {
    window.mfe.scmDeviceMfeEnable = false;
    const { header, closeClickHandler } = renderComponentWithoutClosehandler('8145772880');
    const closeButton = screen.getByRole('img', {
      name: /close icon/i,
    });
    expect(closeButton).toBeInTheDocument();
    expect(screen.queryByText(/more options/i)).toBeNull();
    expect(
      screen.getByRole('heading', {
        name: new RegExp(header, 'i'),
      }),
    ).toBeInTheDocument();
    screen.getByRole('heading', {
      name: /joseph 814-577-2880/i,
    });
    fireEvent.click(closeButton);
    expect(closeClickHandler).not.toBeCalled();
  });
  it('should test close icon is not visible when closeIcon prop is false and more options is visible', () => {
    const { header } = renderComponent('8145772880', false);
    const moreOptions = screen.getByText(/more options/i);
    sessionStorage.setItem('isSAExist', true);
    expect(
      screen.queryByRole('img', {
        name: /close icon/i,
      }),
    ).toBeNull();
    expect(moreOptions).toBeInTheDocument();
    expect(
      screen.getByRole('heading', {
        name: new RegExp(header, 'i'),
      }),
    ).toBeInTheDocument();
    screen.getByRole('heading', {
      name: /joseph 814-577-2880/i,
    });
    fireEvent.click(moreOptions);
  });
  it('should test navigate is called with -1 parameter on left caret click', () => {
    renderComponent('linemdn123', false);
    const mockNavigate = jest.fn();
    jest.mock('react-router-dom', () => ({ useNavigate: () => mockNavigate }));

    screen.getByRole('heading', {
      name: /joseph Lin emdn 123/i,
    });
    fireEvent.click(screen.getByTestId('testBackGridwall'));

    waitFor(() => expect(mockNavigate).toBeCalledWith(-1));
  });

  it('should test navigate is called with -1 parameter on left caret click returning empty', () => {
    window.mfe.scmDeviceMfeEnable = true;
    renderComponent('linemdn123', false);
    const mockNavigate = jest.fn();
    jest.mock('react-router-dom', () => ({ useNavigate: () => mockNavigate }));
    fireEvent.click(screen.getByTestId('testBackGridwall'));
  });
});
describe('<Header/>', () => {
  beforeEach(() => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ gridwallAccessibleFFlag: 'TRUE' }));
    window.mfe = {};
  });
  it('should test header component everything is visible except for more options', () => {
    const { header, closeClickHandler } = renderComponent('8145772880');
    const closeButton = screen.getByRole('img', {
      name: /close icon/i,
    });
    expect(closeButton).toBeInTheDocument();
    expect(screen.queryByText(/more options/i)).toBeNull();
    expect(
      screen.getByRole('heading', {
        name: new RegExp(header, 'i'),
      }),
    ).toBeInTheDocument();
    screen.getByRole('heading', {
      name: /joseph 814-577-2880/i,
    });
    fireEvent.click(closeButton);
    expect(closeClickHandler).toBeCalled();
  });

  it('should test header component everything is visible except for more options when theme is dark', () => {
    window.mfe.scmDeviceMfeEnable = true;
    window.mfe.isDark = true;
    const { header, closeClickHandler } = renderComponent('8145772880');
    const closeButton = screen.getByRole('img', {
      name: /close icon/i,
    });
    expect(closeButton).toBeInTheDocument();
    expect(screen.queryByText(/more options/i)).toBeNull();
    expect(
      screen.getByRole('heading', {
        name: new RegExp(header, 'i'),
      }),
    ).toBeInTheDocument();
    fireEvent.click(closeButton);
    expect(closeClickHandler).toBeCalled();
  });

  it('should test scmDeviceMfeEnable navigatereturn (-1)', () => {
    window.mfe.scmDeviceMfeEnable = false;
    const { header, closeClickHandler } = renderComponentWithoutClosehandler('8145772880');
    const closeButton = screen.getByRole('img', {
      name: /close icon/i,
    });
    expect(closeButton).toBeInTheDocument();
    expect(screen.queryByText(/more options/i)).toBeNull();
    expect(
      screen.getByRole('heading', {
        name: new RegExp(header, 'i'),
      }),
    ).toBeInTheDocument();
    screen.getByRole('heading', {
      name: /joseph 814-577-2880/i,
    });
    fireEvent.click(closeButton);
    expect(closeClickHandler).not.toBeCalled();
  });
  it('should test close icon is not visible when closeIcon prop is false and more options is visible', () => {
    const { header } = renderComponent('8145772880', false);
    const moreOptions = screen.getByText(/more options/i);
    sessionStorage.setItem('isSAExist', true);
    expect(
      screen.queryByRole('img', {
        name: /close icon/i,
      }),
    ).toBeNull();
    expect(moreOptions).toBeInTheDocument();
    expect(
      screen.getByRole('heading', {
        name: new RegExp(header, 'i'),
      }),
    ).toBeInTheDocument();
    screen.getByRole('heading', {
      name: /joseph 814-577-2880/i,
    });
    fireEvent.click(moreOptions);
  });
  it('should test navigate is called with -1 parameter on left caret click', () => {
    renderComponent('linemdn123', false);
    const mockNavigate = jest.fn();
    jest.mock('react-router-dom', () => ({ useNavigate: () => mockNavigate }));

    screen.getByRole('heading', {
      name: /joseph Lin emdn 123/i,
    });
    fireEvent.click(screen.getByTestId('testBackGridwall'));

    waitFor(() => expect(mockNavigate).toBeCalledWith(-1));
  });

  it('should test navigate is called with -1 parameter on left caret click returning empty', () => {
    window.mfe.scmDeviceMfeEnable = true;
    renderComponent('linemdn123', false);
    const mockNavigate = jest.fn();
    jest.mock('react-router-dom', () => ({ useNavigate: () => mockNavigate }));
    fireEvent.click(screen.getByTestId('testBackGridwall'));
  });
});
describe('Header Component with large display text', () => {
  beforeEach(() => {
    render(
      <Header
        data={{
          header: 'Iphone 15 Pro Max Iphone 15 Pro Max Iphone 15 Pro Max Iphone 15 Pro Max',
          line: '5g',
          mdn: '8145772880',
        }}
        productDetails={{
          deviceProduct: {
            commonInfo: {
              showPrice: true,
              displayReasonCode: true,
              showShipitToggle: true,
              flexPDPTradeInLinkEnabled: true,
              containSoftSku: false,
              dpEligible: true,
              indirect: false,
            },
          },
        }}
        isFromCPE={false}
        isRfexFlow={false}
        isNewLine={false}
        channel='OMNI-RETAIL'
        downPayment={10}
        setDownPaymentObj={jest.fn()}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('IDLInfo component shoudl render', () => {
    const testBackGridwall = screen.getByTestId('testBackGridwall');
    expect(testBackGridwall).toBeInTheDocument();
  });
});

describe('Header Component for BYOD flow', () => {
  beforeEach(() => {
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/product-detail.html?activeMtn=5139074854&deviceSKU=MQ8R3LL/A&isByodUpdate=true&deviceId=350321532631401',
    );
    render(
      <Header
        data={{
          header: 'Iphone 15 Pro Max',
          mdn: '8145772880',
          line: 'JOSEPH',
        }}
        productDetails={{
          deviceProduct: {
            commonInfo: {
              showPrice: true,
              displayReasonCode: true,
              showShipitToggle: true,
              flexPDPTradeInLinkEnabled: true,
              containSoftSku: false,
              dpEligible: true,
              indirect: false,
            },
          },
        }}
        isFromCPE={false}
        isRfexFlow={false}
        isNewLine={false}
        channel='OMNI-RETAIL'
        downPayment={10}
        setDownPaymentObj={jest.fn()}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('should render with (Add customer-provided equipment)', async () => {
    const byodTxt = await screen.getByText(/Add customer-provided equipment/i);
    expect(byodTxt).toBeInTheDocument();
  });
});

describe('Header Component for Back and Forth Flow', () => {
  beforeEach(() => {
    const navigatePdp = jest.fn();
    window.mfe = {};
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/product-detail.html?fromPage=Landing&activeMtn=5139074854&deviceSKU=MQ8R3LL/A&isByodUpdate=true&deviceId=350321532631401',
    );
    render(
      <Header
        data={{
          header: 'Iphone 15 Pro Max',
          mdn: 'linemdn123',
          line: 'JOSEPH',
          navigatePdp,
          closeClickHandler: undefined,
        }}
        productDetails={{
          deviceProduct: {
            commonInfo: {
              showPrice: true,
              displayReasonCode: true,
              showShipitToggle: true,
              flexPDPTradeInLinkEnabled: true,
              containSoftSku: false,
              dpEligible: true,
              indirect: false,
            },
          },
        }}
        isFromCPE={false}
        isRfexFlow={false}
        isNewLine={false}
        channel='OMNI-RETAIL'
        downPayment={10}
        setDownPaymentObj={jest.fn()}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('should test navigate is called with -1 parameter on left caret click', () => {
    window.mfe = { scmDeviceMfeEnable: false, scmUpgradeMfeEnable: true };
    const mockNavigate = jest.fn();
    jest.mock('react-router-dom', () => ({ useNavigate: () => mockNavigate }));
    screen.getByRole('heading', {
      name: /joseph Lin emdn 123/i,
    });
    fireEvent.click(screen.getByTestId('testBackGridwall'));

    waitFor(() => expect(mockNavigate).toBeCalledWith(-1));
  });
});

describe('Header Component for BYOD flow', () => {
  const props = {
    data: {
      header: 'Header',
      line: 'Line',
      mdn: '1234567890',
      closeIcon: { popupModalclose: true },
      closeClickHandler: undefined,
      moreOptionClickHandler: jest.fn(),
    },
    computeDPPriceBody: jest.fn(),
    computeDPPriceResult: jest.fn(),
    isDownPaymentAlertNeedToEnable: false,
    setIsDownPaymentAlertNeedToEnable: jest.fn(),
  };

  beforeEach(() => {
    // Mock getQueryParamByName to return specific values
    window.mfe = {};
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/product-detail.html?activeMtn=5139074854&deviceSKU=MQ8R3LL/A&isByodUpdate=true&deviceId=350321532631401',
    );
  });
  test('should test navigate is called with -1 parameter on left caret click', () => {
    jest.mock('onevzsoemfeframework/DomService', () => ({
      getQueryParamByName: (value) => {
        if (value === 'isByodUpdate') return 'false';
        if (value === 'fromPage') return 'OtherPage';
      },
    }));
    jest.mock(
      'onevzsoemfecommon/Helpers',
      () => ({
        __esModule: true,
        default: jest.fn(() => ({})),
        getUIContextPath: jest.fn(() => {}),
        getUIContextPathBAU: jest.fn(() => {}),
        capitalizeFirstLetter: jest.fn(() => {}),
        formatMtnForNewLine: jest.fn(() => {}),
        isNumeric: jest.fn(() => {}),
        getQueryParamByName: jest.fn(() => ({
          isByodUpdate: true,
        })),
      }),
      { virtual: true },
    );
    window.mfe.scmDeviceMfeEnable = false;

    render(<Header {...props} />, { reducers: rootReducer, sagas: rootSaga });
    const mockNavigate = jest.fn();
    jest.mock('react-router-dom', () => ({ useNavigate: () => mockNavigate }));
    const testBackGridwall = screen.getByTestId('testBackGridwall');
    fireEvent.click(testBackGridwall);
  });
  jest.mock(
    'onevzsoemfeframework/AssistedCradleService',
    () => ({
      getAssistedCradlePropertyV2: jest.fn().mockReturnValue(['FALSE']),
    }),
    { virtual: true },
  );
  test('should test navigate is called with -1 parameter on left caret click', () => {
    jest.mock(
      'onevzsoemfeframework/AssistedCradleService',
      () => ({
        __esModule: true,
        default: jest.fn(() => ({})),
        getAssistedCradlePropertyV2: () => ['TRUE'],
      }),
      { virtual: true },
    );
    jest.mock('onevzsoemfeframework/DomService', () => ({
      getQueryParamByName: (value) => {
        if (value === 'isByodUpdate') return 'false';
        if (value === 'fromPage') return 'OtherPage';
        if (value === 'isDWOS') return true;
      },
      isIndirect: () => true,
    }));
    jest.mock(
      'onevzsoemfecommon/Helpers',
      () => ({
        __esModule: true,
        default: jest.fn(() => ({})),
        getUIContextPath: jest.fn(() => {}),
        getUIContextPathBAU: jest.fn(() => {}),
        capitalizeFirstLetter: jest.fn(() => {}),
        formatMtnForNewLine: jest.fn(() => {}),
        isNumeric: jest.fn(() => {}),
        getQueryParamByName: jest.fn(() => ({
          isByodUpdate: true,
        })),
      }),
      { virtual: true },
    );
    window.mfe.scmDeviceMfeEnable = false;

    render(<Header {...props} />, { reducers: rootReducer, sagas: rootSaga });
    const mockNavigate = jest.fn();
    jest.mock('react-router-dom', () => ({ useNavigate: () => mockNavigate }));
    const testBackGridwall = screen.getByTestId('testBackGridwall');
    fireEvent.click(testBackGridwall);
  });
});

describe('Header Component for BYOD flow acss', () => {
  const props = {
    data: {
      header: 'Header',
      line: 'Line',
      mdn: '1234567890',
      closeIcon: { popupModalclose: true },
      closeClickHandler: undefined,
      moreOptionClickHandler: jest.fn(),
    },
    computeDPPriceBody: jest.fn(),
    computeDPPriceResult: jest.fn(),
    isDownPaymentAlertNeedToEnable: false,
    setIsDownPaymentAlertNeedToEnable: jest.fn(),
    closePopup: false,
  };

  beforeEach(() => {
    // Mock getQueryParamByName to return specific values
    window.mfe = { scmUpgradeMfeEnable: true, scmDeviceMfeEnable: true };
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/product-detail.html?activeMtn=5139074854&deviceSKU=MQ8R3LL/A&isByodUpdate=true&deviceId=350321532631401',
    );
  });
  test('should test navigate is called with -1 parameter on left caret click', () => {
    jest.mock('onevzsoemfeframework/DomService', () => ({
      getQueryParamByName: (value) => {
        if (value === 'isByodUpdate') return 'false';
        if (value === 'fromPage') return 'OtherPage';
      },
    }));
    jest.mock(
      'onevzsoemfecommon/Helpers',
      () => ({
        __esModule: true,
        default: jest.fn(() => ({})),
        getUIContextPath: jest.fn(() => {}),
        getUIContextPathBAU: jest.fn(() => {}),
        capitalizeFirstLetter: jest.fn(() => {}),
        formatMtnForNewLine: jest.fn(() => {}),
        isNumeric: jest.fn(() => {}),
        getQueryParamByName: jest.fn(() => ({
          isByodUpdate: true,
        })),
      }),
      { virtual: true },
    );
    window.mfe.scmDeviceMfeEnable = false;

    render(<Header {...props} />, { reducers: rootReducer, sagas: rootSaga });
    const mockNavigate = jest.fn();
    jest.mock('react-router-dom', () => ({ useNavigate: () => mockNavigate }));
    const testBackGridwall = screen.getByTestId('testBackGridwall');
    fireEvent.click(testBackGridwall);
  });
  test.skip('should test header component everything is visible except for more options', () => {
    const closeButton = screen.getByRole('img', {
      name: /close icon/i,
    });
    expect(closeButton).toBeInTheDocument();
    expect(screen.queryByText(/more options/i)).toBeNull();
    fireEvent.click(closeButton);
  });
});
