import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import PDP from '../PDP';
import props from './pdpIspu.json';

jest.setTimeout(30000);

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: () => ['TRUE', true, false],
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => false,
  }),
  { virtual: true },
);

const checkInStoreAvailabilityWithShippingDate = {
  stores: [
    {
      id: '329867',
      estimatedReadyByDate: '30 june',
      storeName: 'Baltimore City',
      isExpressStore: 'N',
      storeType: 'Store',
      retailId: '329867',
      storeStatus: 'Open',
      businessName: 'Verizon Wireless',
      zipPlus: '4646',
      fipsCode: '2451004000',
      area: 'Headquarters',
      region: 'North East',
      disasterImpacted: 'N',
      distance: 1.21,
      netaceLocationCode: 'D5672-01',
      zipCode: '21202',
      state: 'MD',
      city: 'Baltimore',
      phoneNumber: '4105285421',
      direct: 'Y',
      inStorePickupFlag: 'Y',
      items: {
        itemCount: 2,
        estimatedReadyByDate: '31 june',
        item: [
          {
            quantity: 5,
            itemCode: 'MG9J3LL/A',
            quantityAllocated: '0',
            estimatedReadyByDate: '29 june',
          },
          {
            quantity: 0,
            itemCode: 'MYMR2LL/A',
            quantityAllocated: '0',
            estimatedReadyByDate: '28 june',
          },
        ],
      },
      hoursMon: '10:00 AM 08:00 PM',
      hoursTue: '10:00 AM 08:00 PM',
      hoursWed: '10:00 AM 08:00 PM',
      hoursThu: '10:00 AM 08:00 PM',
      hoursFri: '10:00 AM 08:00 PM',
      hoursSat: '10:00 AM 08:00 PM',
      hoursSun: '11:00 AM 05:00 PM',
      location: {
        longitude: -76.600006,
        latitude: 39.28442,
      },
      address1: '1002 Fleet St',
      currentGmtOffSet: '-5',
      ispuServices: 'INSTORE',
      eligbleForGoAndGrab: 'false',
      storeAvailableServices: 'INSTORE',
    },
  ],
};
describe('PDP component render for BYOD ISPU Eligible Flow', () => {
  const handlers = [
    rest.post(`*/shippinghandlingservice/ispu/checkInStoreAvailability`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(
        ctx.status(200),
        ctx.json({
          stores: [
            {
              id: '329867',
              storeName: 'Baltimore City',
              isExpressStore: 'N',
              storeType: 'Store',
              retailId: '329867',
              storeStatus: 'Open',
              businessName: 'Verizon Wireless',
              zipPlus: '4646',
              fipsCode: '2451004000',
              area: 'Headquarters',
              region: 'North East',
              disasterImpacted: 'N',
              distance: 1.21,
              netaceLocationCode: 'D5672-01',
              zipCode: '21202',
              state: 'MD',
              city: 'Baltimore',
              phoneNumber: '4105285421',
              direct: 'Y',
              inStorePickupFlag: 'Y',
              items: {
                itemCount: 2,
                item: [
                  {
                    quantity: 5,
                    itemCode: 'MG9J3LL/A',
                    quantityAllocated: '0',
                  },
                  {
                    quantity: 0,
                    itemCode: 'MYMR2LL/A',
                    quantityAllocated: '0',
                  },
                ],
              },
              hoursMon: '10:00 AM 08:00 PM',
              hoursTue: '10:00 AM 08:00 PM',
              hoursWed: '10:00 AM 08:00 PM',
              hoursThu: '10:00 AM 08:00 PM',
              hoursFri: '10:00 AM 08:00 PM',
              hoursSat: '10:00 AM 08:00 PM',
              hoursSun: '11:00 AM 05:00 PM',
              location: {
                longitude: -76.600006,
                latitude: 39.28442,
              },
              address1: '1002 Fleet St',
              currentGmtOffSet: '-5',
              ispuServices: 'INSTORE',
              eligbleForGoAndGrab: 'false',
              storeAvailableServices: 'INSTORE',
            },
          ],
        }),
      );
    }),
  ];
  const server = setupServer(...handlers);
  afterAll(() => {
    server.close();
  });
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('channel', 'care');
    const location = {
      ...window.location,
      search: '?isFromCPE=true&deviceFromCart=true&isWSAPCpeError=true',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?$iSscan=true&offerEligible=Y&activeMtn=7707907431&deviceSKU=MG622LL/A&isFromCPE=true&deviceId=354405060514810&mtn=7707907431&simId=DFILLSIM5G-SA-A&prospectByodFlow=true&ByodDeviceCompitable=true&ispuCompatibleSIM=BULKSIM5G-SA-S&isWSAPCpeError=true`;
  });
  beforeEach(() => {
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...props}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('should click ispu go to ispu page click on find stores after getting available stores click on pickupfromstore and toggle off ispu button ', async () => {
    server.use(
      rest.post(`*/checkInStoreAvailability`, (req, res, ctx) =>
        res.once(
          ctx.status(200),
          ctx.json({
            stores: [
              {
                id: '329867',
                storeName: 'Baltimore City',
                isExpressStore: 'N',
                storeType: 'Store',
                retailId: '329867',
                storeStatus: 'Open',
                businessName: 'Verizon Wireless',
                zipPlus: '4646',
                fipsCode: '2451004000',
                area: 'Headquarters',
                region: 'North East',
                disasterImpacted: 'N',
                distance: 1.21,
                netaceLocationCode: 'D5672-01',
                zipCode: '21202',
                state: 'MD',
                city: 'Baltimore',
                phoneNumber: '4105285421',
                direct: 'Y',
                inStorePickupFlag: 'Y',
                items: {
                  itemCount: 2,
                  item: [
                    {
                      quantity: 5,
                      itemCode: 'MG9J3LL/A',
                      quantityAllocated: '0',
                    },
                    {
                      quantity: 0,
                      itemCode: 'MYMR2LL/A',
                      quantityAllocated: '0',
                    },
                  ],
                },
                hoursMon: '10:00 AM 08:00 PM',
                hoursTue: '10:00 AM 08:00 PM',
                hoursWed: '10:00 AM 08:00 PM',
                hoursThu: '10:00 AM 08:00 PM',
                hoursFri: '10:00 AM 08:00 PM',
                hoursSat: '10:00 AM 08:00 PM',
                hoursSun: '11:00 AM 05:00 PM',
                location: {
                  longitude: -76.600006,
                  latitude: 39.28442,
                },
                address1: '1002 Fleet St',
                currentGmtOffSet: '-5',
                ispuServices: 'INSTORE',
                eligbleForGoAndGrab: 'false',
                storeAvailableServices: 'INSTORE',
              },
            ],
          }),
        ),
      ),
    );
    const isputoggle = await screen.getAllByRole('checkbox');
    fireEvent.click(isputoggle[1]);
    const accountDiv = await screen.getByTestId('ChangeDevice');
    expect(accountDiv).toBeInTheDocument();
    // const band = screen.getByRole('button', { name: 'Find stores' });
    // fireEvent.click(band);
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    // const pickup = await waitFor(() => screen.getByText(/Pickup from this store/i));
    // fireEvent.click(pickup);
    const isputoggleOff = await screen.getAllByRole('checkbox');
    fireEvent.click(isputoggleOff[1]);
  });
});
describe('PDP component render for BYOD ISPU Eligible Flow', () => {
  const handlers = [
    rest.post(`*/shippinghandlingservice/ispu/checkInStoreAvailability`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(
        ctx.status(200),
        ctx.json({
          stores: [
            {
              id: '329867',
              storeName: 'Baltimore City',
              isExpressStore: 'N',
              storeType: 'Store',
              retailId: '329867',
              storeStatus: 'Open',
              businessName: 'Verizon Wireless',
              zipPlus: '4646',
              fipsCode: '2451004000',
              area: 'Headquarters',
              region: 'North East',
              disasterImpacted: 'N',
              distance: 1.21,
              netaceLocationCode: 'D5672-01',
              zipCode: '21202',
              state: 'MD',
              city: 'Baltimore',
              phoneNumber: '4105285421',
              direct: 'Y',
              inStorePickupFlag: 'Y',
              items: {
                itemCount: 2,
                item: [
                  {
                    quantity: 5,
                    itemCode: 'MG9J3LL/A',
                    quantityAllocated: '0',
                  },
                  {
                    quantity: 0,
                    itemCode: 'MYMR2LL/A',
                    quantityAllocated: '0',
                  },
                ],
              },
              hoursMon: '10:00 AM 08:00 PM',
              hoursTue: '10:00 AM 08:00 PM',
              hoursWed: '10:00 AM 08:00 PM',
              hoursThu: '10:00 AM 08:00 PM',
              hoursFri: '10:00 AM 08:00 PM',
              hoursSat: '10:00 AM 08:00 PM',
              hoursSun: '11:00 AM 05:00 PM',
              location: {
                longitude: -76.600006,
                latitude: 39.28442,
              },
              address1: '1002 Fleet St',
              currentGmtOffSet: '-5',
              ispuServices: 'INSTORE',
              eligbleForGoAndGrab: 'false',
              storeAvailableServices: 'INSTORE',
            },
          ],
        }),
      );
    }),
  ];
  const server = setupServer(...handlers);
  afterAll(() => {
    server.close();
  });
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('channel', 'care');
    const location = {
      ...window.location,
      search: '?isFromCPE=true&deviceFromCart=true',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?$iSscan=true&offerEligible=Y&activeMtn=7707907431&deviceSKU=MG622LL/A&isFromCPE=true&deviceId=354405060514810&mtn=7707907431&simId=DFILLSIM5G-SA-A&prospectByodFlow=true&ByodDeviceCompitable=true`;
  });
  beforeEach(() => {
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...props}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('should click ispu go to ispu page click on find stores after getting available stores click on pickupfromstore and click pick up on pdp', async () => {
    server.use(
      rest.post(`*/checkInStoreAvailability`, (req, res, ctx) =>
        res.once(
          ctx.status(200),
          ctx.json({
            stores: [
              {
                id: '329867',
                storeName: 'Baltimore City',
                isExpressStore: 'N',
                storeType: 'Store',
                retailId: '329867',
                storeStatus: 'Open',
                businessName: 'Verizon Wireless',
                zipPlus: '4646',
                fipsCode: '2451004000',
                area: 'Headquarters',
                region: 'North East',
                disasterImpacted: 'N',
                distance: 1.21,
                netaceLocationCode: 'D5672-01',
                zipCode: '21202',
                state: 'MD',
                city: 'Baltimore',
                phoneNumber: '4105285421',
                direct: 'Y',
                inStorePickupFlag: 'Y',
                items: {
                  itemCount: 2,
                  item: [
                    {
                      quantity: 5,
                      itemCode: 'MG9J3LL/A',
                      quantityAllocated: '0',
                    },
                    {
                      quantity: 0,
                      itemCode: 'MYMR2LL/A',
                      quantityAllocated: '0',
                    },
                  ],
                },
                hoursMon: '10:00 AM 08:00 PM',
                hoursTue: '10:00 AM 08:00 PM',
                hoursWed: '10:00 AM 08:00 PM',
                hoursThu: '10:00 AM 08:00 PM',
                hoursFri: '10:00 AM 08:00 PM',
                hoursSat: '10:00 AM 08:00 PM',
                hoursSun: '11:00 AM 05:00 PM',
                location: {
                  longitude: -76.600006,
                  latitude: 39.28442,
                },
                address1: '1002 Fleet St',
                currentGmtOffSet: '-5',
                ispuServices: 'INSTORE',
                eligbleForGoAndGrab: 'false',
                storeAvailableServices: 'INSTORE',
              },
            ],
          }),
        ),
      ),
    );
    const isputoggle = await screen.getAllByRole('checkbox');
    fireEvent.click(isputoggle[1]);
    const accountDiv = await screen.getByTestId('ChangeDevice');
    expect(accountDiv).toBeInTheDocument();
    // const band = screen.getByRole('button', { name: 'Find stores' });
    // fireEvent.click(band);
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    // const pickup = await waitFor(() => screen.getByText(/Pickup from this store/i));
    // fireEvent.click(pickup);
    await screen.getAllByRole('checkbox');
    // const band1 = screen.getByRole('button', { name: 'Pick Up' });
    // fireEvent.click(band1);
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });
});

describe('PDP component render for BYOD ISPU Eligible with estimatedReadyByDate', () => {
  const handlers = [
    rest.post(`*/shippinghandlingservice/ispu/checkInStoreAvailability`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(checkInStoreAvailabilityWithShippingDate));
    }),
  ];
  const server = setupServer(...handlers);
  afterAll(() => {
    server.close();
  });
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('channel', 'care');
    const location = {
      ...window.location,
      search: '?isFromCPE=true&deviceFromCart=true',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?$iSscan=true&offerEligible=Y&activeMtn=7707907431&deviceSKU=MG622LL/A&isFromCPE=true&deviceId=354405060514810&mtn=7707907431&simId=DFILLSIM5G-SA-A&prospectByodFlow=true&ByodDeviceCompitable=true`;
  });
  beforeEach(() => {
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...props}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('should click ispu go to ispu page click on find stores after getting available stores click on pickupfromstore and click pick up on pdp', async () => {
    server.use(
      rest.post(`*/checkInStoreAvailability`, (req, res, ctx) =>
        res.once(ctx.status(200), ctx.json(checkInStoreAvailabilityWithShippingDate)),
      ),
    );
    const isputoggle = await screen.getAllByRole('checkbox');
    fireEvent.click(isputoggle[1]);
    const accountDiv = await screen.getByTestId('ChangeDevice');
    expect(accountDiv).toBeInTheDocument();
    // const band = screen.getByRole('button', { name: 'Find stores' });
    // fireEvent.click(band);
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    // const pickup = await waitFor(() => screen.getByText(/Pickup from this store/i));
    // fireEvent.click(pickup);
    await screen.getAllByRole('checkbox');
    // const band1 = screen.getByRole('button', { name: 'Pick Up' });
    // fireEvent.click(band1);
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });
});
