import * as DomService from 'onevzsoemfeframework/DomService';
import {
  get5GLineCheckConfig,
  getExcludeIndirectValue,
  getIspuCompatibleSim,
  createRequestBody,
  allowOnlyNumbers,
  groupByCapacity,
  getCapacitySizeOptions,
} from '../ISPUPage';

// Mock DomService module
jest.mock('onevzsoemfeframework/DomService', () => ({
  ...jest.requireActual('onevzsoemfeframework/DomService'),
  getQueryParamByName: jest.fn(),
}));

describe('ISPUPage Helper Functions', () => {
  beforeEach(() => {
    // Clear session storage before each test
    sessionStorage.clear();
  });

  describe('get5GLineCheckConfig', () => {
    it('should return is5GLineCbandOrLteCheck as true when all conditions are met', () => {
      const cartDetails = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                mobileNumber: '1234567890',
                deviceTypeSelected: '5G Internet',
              },
            ],
          },
        },
      };
      const customerProfileDetails = {
        customer: {
          qualificationDetails: {
            addressRequest: {
              LTEQualified: true,
              cBandQualified: false,
            },
          },
        },
      };
      const activeMtn = '1234567890';
      const flexRedesign5GFFlag = 'true';

      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'Not WiFi-Backup');

      const result = get5GLineCheckConfig(cartDetails, customerProfileDetails, activeMtn, flexRedesign5GFFlag);

      expect(result.is5GLineCbandOrLteCheck).toBe(true);
    });

    it('should return is5GLineCbandOrLteCheck as false when device is not 5G Internet', () => {
      const cartDetails = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                mobileNumber: '1234567890',
                deviceTypeSelected: '4G LTE',
              },
            ],
          },
        },
      };
      const customerProfileDetails = {
        customer: {
          qualificationDetails: {
            addressRequest: {
              LTEQualified: true,
              cBandQualified: true,
            },
          },
        },
      };
      const activeMtn = '1234567890';
      const flexRedesign5GFFlag = 'true';

      const result = get5GLineCheckConfig(cartDetails, customerProfileDetails, activeMtn, flexRedesign5GFFlag);

      expect(result.is5GLineCbandOrLteCheck).toBe(false);
    });

    it('should return is5GLineCbandOrLteCheck as false when WiFi backup device is selected', () => {
      const cartDetails = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                mobileNumber: '1234567890',
                deviceTypeSelected: '5G Internet',
              },
            ],
          },
        },
      };
      const customerProfileDetails = {
        customer: {
          qualificationDetails: {
            addressRequest: {
              LTEQualified: true,
              cBandQualified: true,
            },
          },
        },
      };
      const activeMtn = '1234567890';
      const flexRedesign5GFFlag = 'true';
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'WiFi-Backup');

      const result = get5GLineCheckConfig(cartDetails, customerProfileDetails, activeMtn, flexRedesign5GFFlag);

      expect(result.is5GLineCbandOrLteCheck).toBe(false);
    });

    it('should handle missing line info gracefully', () => {
      const cartDetails = {
        cart: {
          lineDetails: {
            lineInfo: [],
          },
        },
      };
      const customerProfileDetails = {
        customer: {
          qualificationDetails: {
            addressRequest: {
              LTEQualified: true,
              cBandQualified: true,
            },
          },
        },
      };
      const activeMtn = '1234567890';
      const flexRedesign5GFFlag = 'true';

      const result = get5GLineCheckConfig(cartDetails, customerProfileDetails, activeMtn, flexRedesign5GFFlag);

      expect(result.is5GLineCbandOrLteCheck).toBe(false);
    });

    it('should return false when flexRedesign5GFFlag is not true', () => {
      const cartDetails = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                mobileNumber: '1234567890',
                deviceTypeSelected: '5G Internet',
              },
            ],
          },
        },
      };
      const customerProfileDetails = {
        customer: {
          qualificationDetails: {
            addressRequest: {
              LTEQualified: true,
              cBandQualified: true,
            },
          },
        },
      };
      const activeMtn = '1234567890';
      const flexRedesign5GFFlag = 'false';

      const result = get5GLineCheckConfig(cartDetails, customerProfileDetails, activeMtn, flexRedesign5GFFlag);

      expect(result.is5GLineCbandOrLteCheck).toBe(false);
    });
  });

  describe('getExcludeIndirectValue', () => {
    it('should return true when isRetailORMaverick is true', () => {
      const result = getExcludeIndirectValue(true, 'BE');
      expect(result).toBe(true);
    });

    it('should return true when visionCustomerTypeValue is BE', () => {
      const result = getExcludeIndirectValue(false, 'BE');
      expect(result).toBe(true);
    });

    it('should return false when isRetailORMaverick is false and visionCustomerTypeValue is not BE', () => {
      const result = getExcludeIndirectValue(false, 'OTHER');
      expect(result).toBe(false);
    });

    it('should return false when visionCustomerTypeValue is empty', () => {
      const result = getExcludeIndirectValue(false, '');
      expect(result).toBe(false);
    });
  });

  describe('getIspuCompatibleSim', () => {
    it('should return ispuSim when provided', () => {
      const ispuSim = 'CUSTOM_SIM_ID';
      const result = getIspuCompatibleSim(ispuSim);
      expect(result).toBe('CUSTOM_SIM_ID');
    });

    it('should return query param value when available and ispuSim is not provided', () => {
      DomService.getQueryParamByName.mockReturnValue('QUERY_PARAM_SIM');
      const result = getIspuCompatibleSim(null);
      expect(result).toBe('QUERY_PARAM_SIM');
    });

    it('should return default TELESALES_ISPU_SIM_SORID when nothing is provided', () => {
      DomService.getQueryParamByName.mockReturnValue(null);
      const result = getIspuCompatibleSim(null);
      expect(result).toBe('BULKSIM5G-SA-A');
    });
  });

  describe('createRequestBody', () => {
    it('should create request body with all parameters', () => {
      const result = createRequestBody('12345', 'SKU123', 'N', true, true, 1, false);

      expect(result).toEqual({
        meta: {
          clientCorrrelationId:
            'ick-ClrSuZPeM-UmBI-2SFB6t1zB_dFDy3IfCcConCuwmPSIXyrD!1375284084!obsneocgzap08!5106!-1!1564408961747',
          timestamp: '2019-07-29T10:25:59.791-04:00',
        },
        data: {
          zipCode: '12345',
          sorIds: 'SKU123',
          customerType: 'N',
          excludeIndirect: true,
          range: 50,
          showOnlyAvailableStores: true,
        },
      });
    });

    it('should include dataSet when showOnlyAvailableStores is false', () => {
      const result = createRequestBody('12345', 'SKU123', 'E', false, false, 2, false);

      expect(result.data.dataSet).toBe(2);
    });

    it('should include sorIdFilter when is5GLineCbandOrLteCheck is true', () => {
      const result = createRequestBody('12345', 'SKU123', 'N', true, true, 1, true);

      expect(result.data.sorIdFilter).toBe('ANY');
    });

    it('should not include dataSet when showOnlyAvailableStores is true', () => {
      const result = createRequestBody('12345', 'SKU123', 'N', true, true, 1, false);

      expect(result.data.dataSet).toBeUndefined();
    });
  });

  describe('allowOnlyNumbers', () => {
    it('should return true for valid numeric strings', () => {
      expect(allowOnlyNumbers('12345')).toBe(true);
      expect(allowOnlyNumbers('0')).toBe(true);
      expect(allowOnlyNumbers('99999')).toBe(true);
    });

    it('should return true for empty string', () => {
      expect(allowOnlyNumbers('')).toBe(true);
    });

    it('should return false for strings with letters', () => {
      expect(allowOnlyNumbers('123abc')).toBe(false);
      expect(allowOnlyNumbers('abc123')).toBe(false);
    });

    it('should return false for strings with special characters', () => {
      expect(allowOnlyNumbers('123-456')).toBe(false);
      expect(allowOnlyNumbers('123.45')).toBe(false);
      expect(allowOnlyNumbers('123 456')).toBe(false);
    });
  });

  describe('groupByCapacity', () => {
    it('should group skus by capacity size', () => {
      const skus = [
        { capacitySize: 128, capacity: '128GB' },
        { capacitySize: 256, capacity: '256GB' },
        { capacitySize: 128, capacity: '128GB' },
      ];

      const result = groupByCapacity(skus);

      expect(result).toHaveLength(2);
      expect(result[0].capacity).toBe('128GB');
      expect(result[1].capacity).toBe('256GB');
    });

    it('should filter out skus without capacitySize', () => {
      const skus = [
        { capacitySize: 128, capacity: '128GB' },
        { capacity: '256GB' },
        { capacitySize: null, capacity: '512GB' },
      ];

      const result = groupByCapacity(skus);

      expect(result).toHaveLength(1);
      expect(result[0].capacity).toBe('128GB');
    });

    it('should return empty array for empty input', () => {
      const result = groupByCapacity([]);
      expect(result).toEqual([]);
    });

    it('should handle null or undefined skus in the array', () => {
      const skus = [{ capacitySize: 128, capacity: '128GB' }, null, undefined];

      const result = groupByCapacity(skus);

      expect(result).toHaveLength(1);
      expect(result[0].capacity).toBe('128GB');
    });
  });

  describe('getCapacitySizeOptions', () => {
    it('should return capacity size options from product details', () => {
      const ProductDetails = {
        childSkus: [
          { capacitySize: 128, capacity: '128GB' },
          { capacitySize: 256, capacity: '256GB' },
        ],
      };

      const result = getCapacitySizeOptions(ProductDetails);

      expect(result).toHaveLength(2);
      expect(result[0]).toEqual({ capacity: ['128GB'] });
      expect(result[1]).toEqual({ capacity: ['256GB'] });
    });

    it('should handle empty childSkus array', () => {
      const ProductDetails = {
        childSkus: [],
      };

      const result = getCapacitySizeOptions(ProductDetails);

      expect(result).toEqual([]);
    });

    it('should filter out skus without capacity information', () => {
      const ProductDetails = {
        childSkus: [
          { capacitySize: 128, capacity: '128GB' },
          { color: 'red' },
          { capacitySize: null, capacity: '256GB' },
        ],
      };

      const result = getCapacitySizeOptions(ProductDetails);

      expect(result).toHaveLength(1);
      expect(result[0]).toEqual({ capacity: ['128GB'] });
    });
  });
});
