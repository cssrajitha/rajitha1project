import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import Emitter from 'onevzsoemfeframework/Emitter';
import { cloneDeep } from 'lodash';
import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import PDP from '../PDP';
import props from './pdpDfill.json';
import childSkuBackOrder from './childSkuBackOrder.json';
import childSkuBackOrderShippingDate from './childSkuBackOrderShippingDate.json';
import childSkuPrepayOrder from './childSkuPrepayOrder.json';

const dFillBackOrderProps = cloneDeep(props);
dFillBackOrderProps.productDetails.deviceProduct.childSkus = [childSkuBackOrder];
dFillBackOrderProps.cartDetails.cart.orderDetails.isPrePayCart = 'Y';

const dFillBackOrderPropsShippingDate = cloneDeep(props);
dFillBackOrderPropsShippingDate.productDetails.deviceProduct.childSkus = [childSkuBackOrderShippingDate];

const dFillPrePayOrderProps = cloneDeep(props);
dFillPrePayOrderProps.productDetails.deviceProduct.childSkus = [childSkuPrepayOrder];
dFillPrePayOrderProps.cartDetails.cart.orderDetails.isPrePayCart = 'Y';

const dFillVideoAssistProps = cloneDeep(props);
dFillVideoAssistProps.productDetails.accountInfo.isVideoAssistFlow = true;
dFillVideoAssistProps.cartDetails.cart.orderDetails.isPrePayCart = 'Y';

const dispatchedActions = [];
const mockStore = {
  dispatch: (action) => {
    dispatchedActions.push(action);
  },
};

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradleProperty: () => [false, true, false],
    getAssistedCradlePropertyV2: () => [false, true, false],
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    getClientAppName: () => 'ATG-RTL-NETACE',
    noOfDaysLeftInBillCycle: () => 12,
    isIpad: () => true,
    isRetail: () => true,
    isAsurion: () => false,
    executeShellFunction: jest.fn(),
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

describe('PDP component render for DFill Flow Back order', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  navigator.clipboard = jest.fn();
  navigator.clipboard.writeText = jest.fn('Pink');
  beforeEach(() => {
    window.store = mockStore;
    window.vzdl = { page: {} };
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?offerEligible=Y&activeMtn=9102798662&productId=dev21410695&defaultSku=MTXW3LL/A`;
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...props}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('should click storage and color', async () => {
    const color = screen.getAllByRole('radio', { name: 'Black' });
    fireEvent.click(color[0]);
    const size128GB = await screen.getByRole('radio', { name: '128 GB' });
    expect(size128GB).toBeChecked();
    fireEvent.click(size128GB);
    const oneTB = await screen.getByRole('radio', { name: '512 GB' });
    expect(oneTB).not.toBeChecked();
    fireEvent.click(oneTB);
  });
  test('component should render', async () => {
    const shipIt = await screen.getByRole('button', {
      name: /Ship It/i,
    });
    expect(shipIt).toBeInTheDocument();
    fireEvent.click(shipIt);
    Emitter.emit('TAGGING_COMPLETED', true);
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Decline protection_Decline Device Protection' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });
  jest.setTimeout(10000);
  test.skip('component should render', async () => {
    const copycolor = await screen.getByRole('img', {
      name: 'Copy color(s)',
    });
    expect(copycolor).toBeInTheDocument();
    fireEvent.click(copycolor);
    fireEvent.keyDown(copycolor, { key: 'Enter', charCode: '32' });
    await new Promise((res) => {
      setTimeout(res, 6000);
    });
  });
});

describe('PDP component render for DFill Flow Back order', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  navigator.clipboard = jest.fn();
  navigator.clipboard.writeText = jest.fn('Pink');
  beforeEach(() => {
    window.store = mockStore;
    window.vzdl = {
      page: {},
      target: { message: '' },
      event: { value: '' },
    };
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?offerEligible=Y&activeMtn=9102798662&productId=dev21410695&defaultSku=MTXW3LL/A`;
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...dFillBackOrderProps}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('component should render', async () => {
    const shipIt = await screen.getByRole('button', {
      name: /Ship It/i,
    });
    expect(shipIt).toBeInTheDocument();
    fireEvent.click(shipIt);
    Emitter.emit('TAGGING_COMPLETED', true);
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Decline protection_Decline Device Protection' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });
});

describe('PDP component render for DFill Flow Prepay order', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    sessionStorage.setItem('channel', 'd2d');
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  navigator.clipboard = jest.fn();
  navigator.clipboard.writeText = jest.fn('Pink');
  beforeEach(() => {
    sessionStorage.setItem('channel', 'd2d');
    window.store = mockStore;
    window.vzdl = {
      page: {},
      target: { message: '' },
      event: { value: '' },
    };
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?offerEligible=Y&activeMtn=9102798662&productId=dev21410695&defaultSku=MTXW3LL/A`;
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...dFillPrePayOrderProps}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('component should render', async () => {
    const shipIt = await screen.getByRole('button', {
      name: /Ship It/i,
    });
    expect(shipIt).toBeInTheDocument();
    fireEvent.click(shipIt);
    Emitter.emit('TAGGING_COMPLETED', true);
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Decline protection_Decline Device Protection' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });
});

describe('PDP component render for DFill Flow Videoassist Flow', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('channel', 'retail');
    const location = {
      ...window.location,
      search:
        'offerEligible=Y&activeMtn=9102798662&productId=dev21410695&defaultSku=MTXW3LL/A&isESimOnly=false&isFromCPE=true',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?offerEligible=Y&activeMtn=9102798662&productId=dev21410695&defaultSku=MTXW3LL/A&isESimOnly=false&isFromCPE=true`;
  });
  afterAll(() => {
    server.close();
  });
  navigator.clipboard = jest.fn();
  navigator.clipboard.writeText = jest.fn('Pink');
  beforeEach(() => {
    sessionStorage.setItem('channel', 'retail');
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...dFillVideoAssistProps}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('component should render', async () => {
    const shipIt = await screen.getByRole('button', {
      name: /Update/i,
    });
    expect(shipIt).toBeInTheDocument();
    fireEvent.click(shipIt);
    Emitter.emit('TAGGING_COMPLETED', true);
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Decline protection_Decline Device Protection' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });
});

describe('PDP component render for Back order with Shipping date', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  navigator.clipboard = jest.fn();
  navigator.clipboard.writeText = jest.fn('Pink');
  beforeEach(() => {
    window.store = mockStore;
    window.vzdl = {
      page: {},
      target: { message: '' },
      event: { value: '' },
    };
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?offerEligible=Y&activeMtn=9102798662&productId=dev21410695&defaultSku=MTXW3LL/A`;
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...dFillBackOrderPropsShippingDate}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('component should render', async () => {
    const shipIt = await screen.getByRole('button', {
      name: /Ship It/i,
    });
    expect(shipIt).toBeInTheDocument();
    fireEvent.click(shipIt);
    Emitter.emit('TAGGING_COMPLETED', true);
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Decline protection_Decline Device Protection' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });
});
