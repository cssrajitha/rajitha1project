import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import IneligibleDevicesModal from '../IneligibleDevicesModal';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';

describe('<IneligibleDevicesModal/>', () => {
  it('should test <IneligibleDevicesModal/>', () => {
    const mockContinueClickHandler = jest.fn();
    render(<IneligibleDevicesModal continueClickHandler={mockContinueClickHandler} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    const showButtonModal = screen.getByRole('button', {
      name: /show modal/i,
    });
    expect(showButtonModal).toBeInTheDocument();
    fireEvent.click(showButtonModal);
  });
});
