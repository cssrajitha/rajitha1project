import React from 'react';
import { cloneDeep } from 'lodash';
import { setupServer } from 'msw/node';
import Emitter from 'onevzsoemfeframework/Emitter';
import { rest } from 'msw';
import { render, screen, fireEvent, waitFor } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import PDP from '../PDP';
import props from './PDPOmniCareProps.json';
import validateDeviceSimId from '../../../pages/PDP/mocks/api/validateDeviceSimIdSimOnlyChange.json';
import PDPOmniCareSimOnlyChangeProps from './PDPOmniCareSimOnlyChangeProps.json';

jest.setTimeout(50000);
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: () => ['TRUE', true, 'TRUE', 'TRUE', 'TRUE', 'TRUE'],
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfecommon/APIService',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('onevzsoemfecommon/APIService'),
      useAddDeviceMutation: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                serviceBody: {
                  serviceResponse: {
                    context: {
                      contextInfo: {
                        processStep: 'PlanSelection',
                      },
                      cartInfo: { lines: [{ device: { upgradeReasonCode: 'UN' } }] },
                    },
                  },
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
    };
  },
  { virtual: true },
);
jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => false,
  }),
  { virtual: true },
);

describe('PDP component render for Local Scan DACC Device', () => {
  beforeAll(() => {});

  beforeAll(() => {
    sessionStorage.setItem('refundexchange', 'false');
    const location = {
      ...window.location,
      search: `?deviceId=5666666&imei1=777777&imei2&eDeviceSku=SAMSU&offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&isLocal=true&deviceId=350169643218109&simId=89148000009739425736&scanFromLanding=true`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?deviceId=5666666&imei1=777777&imei2&eDeviceSku=SAMSU&offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&isLocal=true&deviceId=350169643218109&simId=89148000009739425736&scanFromLanding=true`;
  });
  afterAll(() => {});
  beforeEach(() => {
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...props}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
    Emitter.emit('TAGGING_COMPLETED', true);
  });
  test('component should render', async () => {
    const addTocartBtn = await screen.getByRole('button', {
      name: /Add to Cart/i,
    });
    expect(addTocartBtn).toBeInTheDocument();
    fireEvent.click(addTocartBtn);
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Continue' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 5000);
    });
  });
});

describe('PDP component render Omni Care CPE', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });

  beforeAll(() => {
    sessionStorage.setItem('refundexchange', 'false');
    sessionStorage.setItem('channel', 'care');
    Emitter.emit('Update_DeviceSimId_Info', {
      simSkuEntered: 'DFILL-SA-A',
    });

    const location = {
      ...window.location,
      search: `?isFromCPE=true&deviceId=5666666&imei1=777777&imei2&eDeviceSku=SAMSU&offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&isLocal=true&deviceId=350169643218109&simId=89148000009739425736`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?isFromCPE=true&deviceId=5666666&imei1=777777&imei2&eDeviceSku=SAMSU&offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&isLocal=true&deviceId=350169643218109&simId=89148000009739425736`;
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...props}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('Should enter sim sku and pass in payload', async () => {
    Emitter.emit('Update_DeviceSimId_Info', {
      simSkuEntered: 'DFILL-SA-A',
    });
    const addTocartBtn = await screen.getByRole('button', {
      name: /Update/i,
    });
    expect(addTocartBtn).toBeInTheDocument();
    fireEvent.click(addTocartBtn);
    const continueBtn = screen.getByRole('button', { name: 'Continue' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 5000);
    });
  });
});

describe('PDP component render Sim Only Change', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
    rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
      console.log('inside /flexV2/validate-deviceSimId');
      return res(ctx.status(200), ctx.json(validateDeviceSimId));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });

  beforeAll(() => {
    sessionStorage.setItem('refundexchange', 'false');
    sessionStorage.setItem('channel', 'care');
    Emitter.emit('Update_DeviceSimId_Info', {
      simSkuEntered: 'DFILLSIM-TRI-A',
    });
    const location = {
      ...window.location,
      search: `?deviceSKU=MG9D3LL/A&isByodUpdate=true&deviceId=354245334007682&simId=89148000007011862139&isEditAndView=true&activeMtn=7204135054&fromPage=Landing
      `,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?deviceSKU=MG9D3LL/A&isByodUpdate=true&deviceId=354245334007682&simId=89148000007011862139&isEditAndView=true&activeMtn=7204135054&fromPage=Landing`;
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        callDeviceAddToCart={jest.fn()}
        setSimIdResult={jest.fn()}
        {...PDPOmniCareSimOnlyChangeProps}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });

  test('check plan price call', async () => {
    await expect(async () => {
      await waitFor(() => expect(screen.getByText(/price call sucess/i)).toBeInTheDocument());
    }).rejects.toEqual(expect.anything());
  });
  test('Should enter sim sku and pass in payload', async () => {
    const simTextBox = await screen.getByRole('textbox', { name: 'Sim SKU' });
    fireEvent.change(simTextBox, { target: { value: 'DFILLSIM-TRI-A' } });
    fireEvent.blur(simTextBox, { target: { value: 'DFILLSIM-TRI-A' } });
    await new Promise((res) => {
      setTimeout(res, 5000);
    });
    expect(simTextBox).toHaveValue('DFILLSIM-TRI-A');
    Emitter.emit('Update_DeviceSimId_Info', {
      simSkuEntered: 'DFILLSIM-TRI-A',
    });
    const textSku = await screen.getAllByRole('button', { name: 'BYOD' });
    expect(textSku[0]).toBeInTheDocument();
    fireEvent.click(textSku[0]);
  });
  test('Should enter sim sku and pass in payload', async () => {
    const simTextBox = await screen.getByRole('textbox', { name: 'Sim SKU' });
    fireEvent.change(simTextBox, { target: { value: 'DFILLSIM-TRI-A' } });
    fireEvent.focus(simTextBox, { target: { value: 'DFILLSIM-TRI-A' } });
    await new Promise((res) => {
      setTimeout(res, 5000);
    });
    expect(simTextBox).toHaveValue('DFILLSIM-TRI-A');
    Emitter.emit('Update_DeviceSimId_Info', {
      simSkuEntered: 'DFILLSIM-TRI-A',
    });
    const textSku = await screen.getAllByRole('button', { name: 'BYOD' });
    expect(textSku[0]).toBeInTheDocument();
    fireEvent.click(textSku[0]);
  });
  test("Should Only DFILL SIM's are allowed", async () => {
    const simTextBox = await screen.getByRole('textbox', { name: 'Sim SKU' });
    fireEvent.change(simTextBox, { target: { value: 'UNIVPSIM5G-SA-A' } });
    fireEvent.blur(simTextBox, { target: { value: 'UNIVPSIM5G-SA-A' } });
    await new Promise((res) => {
      setTimeout(res, 5000);
    });
    expect(simTextBox).toHaveValue('UNIVPSIM5G-SA-A');
    Emitter.emit('Update_DeviceSimId_Info', {
      simSkuEntered: 'UNIVPSIM5G-SA-A',
    });
    const textSku = await screen.getAllByRole('button', { name: 'BYOD' });
    expect(textSku[0]).toBeInTheDocument();
    fireEvent.click(textSku[0]);
  });
});

describe('PDP component render with no line info in cart', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const clonedProps = cloneDeep(props);
  clonedProps.cartDetails.cart.lineDetails = [];
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });

  beforeAll(() => {
    sessionStorage.setItem('refundexchange', 'false');

    const location = {
      ...window.location,
      search: `?deviceId=5666666&imei1=777777&imei2&eDeviceSku=SAMSU&offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&isLocal=true&deviceId=350169643218109&simId=89148000009739425736&scanFromLanding=true`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?deviceId=5666666&imei1=777777&imei2&eDeviceSku=SAMSU&offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&isLocal=true&deviceId=350169643218109&simId=89148000009739425736&scanFromLanding=true`;
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...clonedProps}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('component should render', async () => {
    const addTocartBtn = await screen.getByRole('button', {
      name: /Add to Cart/i,
    });
    expect(addTocartBtn).toBeInTheDocument();
    fireEvent.click(addTocartBtn);
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Continue' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 5000);
    });
  });
});

describe('PDP component render with sim info in cart', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const clonedProps = cloneDeep(props);
  clonedProps.cartDetails.cart.lineDetails.lineInfo = [
    {
      mobileNumber: '6165029774',
      lineActivityType: 'EUP',
      itemsInfo: [{ cartItems: { cartItem: [{ cartItemType: 'SIM', eSIM: '988847477474774747' }] } }],
    },
  ];
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });

  beforeAll(() => {
    sessionStorage.setItem('refundexchange', 'false');

    const location = {
      ...window.location,
      search: `?deviceId=5666666&imei1=777777&imei2&eDeviceSku=SAMSU&offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&isLocal=true&deviceId=350169643218109&simId=89148000009739425736&scanFromLanding=true`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?deviceId=5666666&imei1=777777&imei2&eDeviceSku=SAMSU&offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&isLocal=true&deviceId=350169643218109&simId=89148000009739425736&scanFromLanding=true`;
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...clonedProps}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('component should render', async () => {
    const addTocartBtn = await screen.getByRole('button', {
      name: /Add to Cart/i,
    });
    expect(addTocartBtn).toBeInTheDocument();
    fireEvent.click(addTocartBtn);
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Continue' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 5000);
    });
  });
});

describe('PDP component render Sim Only Change', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  validateDeviceSimId.serviceBody.serviceResponse.context.deviceInfo.simInfo.makeEtniPersApi = true;
  validateDeviceSimId.serviceBody.serviceResponse.context.deviceInfo.makeEtniPersApi = true;
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
    rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
      console.log('inside /flexV2/validate-deviceSimId');
      return res(ctx.status(200), ctx.json(validateDeviceSimId));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });

  beforeAll(() => {
    sessionStorage.setItem('refundexchange', 'false');
    window.mfe = { scmDeviceMfeEnable: true };
    sessionStorage.setItem('channel', 'care');
    Emitter.emit('Update_DeviceSimId_Info', {
      simSkuEntered: 'DFILLSIM-TRI-A',
    });
    const location = {
      ...window.location,
      search: `?deviceSKU=MG9D3LL/A&isByodUpdate=falses&deviceId=354245334007682&simId=89148000007011862139&isEditAndView=true&activeMtn=7204135054&fromPage=Landing
      `,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?deviceSKU=MG9D3LL/A&isByodUpdate=falses&deviceId=354245334007682&simId=89148000007011862139&isEditAndView=true&activeMtn=7204135054&fromPage=Landing`;
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        callDeviceAddToCart={jest.fn()}
        setSimIdResult={jest.fn()}
        ValidateDeviceSimIdResult={{ originalArgs: { body: { data: { lines: [{ device: { id: '212' } }] } } } }}
        {...PDPOmniCareSimOnlyChangeProps}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });

  test('check plan price call', async () => {
    await expect(async () => {
      await waitFor(() => expect(screen.getByText(/price call sucess/i)).toBeInTheDocument());
    }).rejects.toEqual(expect.anything());
  });
  test('Should enter sim sku and pass in payload', async () => {
    const simTextBox = await screen.getByDisplayValue('89148000007011862139');
    fireEvent.change(simTextBox, { target: { value: 'DFILLSIM-TRI-A' } });
    fireEvent.blur(simTextBox, { target: { value: 'DFILLSIM-TRI-A' } });
    await new Promise((res) => {
      setTimeout(res, 5000);
    });
    expect(simTextBox).toHaveValue('DFILLSIM-TRI-A');
    Emitter.emit('Update_DeviceSimId_Info', {
      simSkuEntered: 'DFILLSIM-TRI-A',
    });
    const textSku = await screen.getAllByRole('button', { name: 'BYOD' });
    expect(textSku[0]).toBeInTheDocument();
    fireEvent.click(textSku[0]);
  });
});
describe('PDP component render Sim Only Change', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
    rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
      console.log('inside /flexV2/validate-deviceSimId');
      return res(ctx.status(200), ctx.json(validateDeviceSimId));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });

  beforeAll(() => {
    sessionStorage.setItem('refundexchange', 'false');
    sessionStorage.setItem('channel', 'vzw-acss');
    window.mfe = { scmDeviceMfeEnable: true };
    Emitter.emit('Update_DeviceSimId_Info', {
      simSkuEntered: 'DFILLSIM-TRI-A',
    });
    const location = {
      ...window.location,
      search: `?deviceSKU=MG9D3LL/A&isByodUpdate=true&deviceId=354245334007682&simId=89148000007011862139&isEditAndView=true&activeMtn=7204135054&fromPage=Landing
      `,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?deviceSKU=MG9D3LL/A&isByodUpdate=true&deviceId=354245334007682&simId=89148000007011862139&isEditAndView=true&activeMtn=7204135054&fromPage=Landing`;
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        ValidateDeviceSimIdResult={{ originalArgs: { body: { data: { lines: [{ device: { id: '212' } }] } } } }}
        callDeviceAddToCart={jest.fn()}
        setSimIdResult={jest.fn()}
        {...PDPOmniCareSimOnlyChangeProps}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });

  test('check plan price call', async () => {
    await expect(async () => {
      await waitFor(() => expect(screen.getByText(/price call sucess/i)).toBeInTheDocument());
    }).rejects.toEqual(expect.anything());
  });
  test('Should enter sim sku and pass in payload', async () => {
    const simTextBox = await screen.getByDisplayValue('89148000007011862139');
    fireEvent.change(simTextBox, { target: { value: 'DFILLSIM-TRI-A' } });
    fireEvent.blur(simTextBox, { target: { value: 'DFILLSIM-TRI-A' } });
    await new Promise((res) => {
      setTimeout(res, 5000);
    });
    expect(simTextBox).toHaveValue('DFILLSIM-TRI-A');
    Emitter.emit('Update_DeviceSimId_Info', {
      simSkuEntered: 'DFILLSIM-TRI-A',
    });
    const textSku = await screen.getAllByRole('button', { name: 'BYOD' });
    expect(textSku[0]).toBeInTheDocument();
    fireEvent.click(textSku[0]);
  });
});
