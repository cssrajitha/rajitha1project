/**
 * Unit tests for DeviceInfo utility functions
 */
import { doCallGetSkuDetails } from '../DeviceInfo.utils';

describe('DeviceInfo.utils - doCallGetSkuDetails', () => {
  let mockDependencies;

  beforeEach(() => {
    mockDependencies = {
      activeMtn: '1234567890',
      productId: 'dev19920005',
      downPayment: 0,
      filteredLineFromCart: null,
      getInventoryDetails: jest.fn().mockResolvedValue({ data: { success: true } }),
      computeDPPriceBody: jest.fn().mockResolvedValue({ data: { success: true } }),
      setUpcCode: jest.fn(),
      setIsDevicePricingApiCallEnable: jest.fn(),
    };
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('TRUE Branch - filteredSku exists with sorId', () => {
    const validFilteredSku = {
      sorId: 'SKU123',
      price: {
        fullRetailPrice: { originalPrice: '999.99' },
        devicePaymentPrice: [
          {
            dpTermPrices: {
              preferredTerm: 36,
              loanOfferDetails: { loanOfferId: 'LOAN123' },
            },
          },
        ],
        preferredTerm: 36,
      },
      upcCodeFull: '123456789012',
    };

    test('should execute IF block and call getInventoryDetails', async () => {
      await doCallGetSkuDetails(validFilteredSku, 'size', mockDependencies);

      expect(mockDependencies.getInventoryDetails).toHaveBeenCalledTimes(1);
      expect(mockDependencies.getInventoryDetails).toHaveBeenCalledWith(
        {
          body: {
            data: {
              sorId: 'SKU123',
              productType: 'device',
              processingMTN: '1234567890',
              productId: 'dev19920005',
              mtnList: { eup: [], aal: [] },
              bogoEnabled: 'true',
              deviceDollarsAccountConvertedInd: '',
            },
          },
        },
        false
      );
    });

    test('should call setUpcCode with upcCodeFull', async () => {
      await doCallGetSkuDetails(validFilteredSku, 'size', mockDependencies);

      expect(mockDependencies.setUpcCode).toHaveBeenCalledTimes(1);
      expect(mockDependencies.setUpcCode).toHaveBeenCalledWith('123456789012');
    });

    test('should call setIsDevicePricingApiCallEnable with true', async () => {
      await doCallGetSkuDetails(validFilteredSku, 'size', mockDependencies);

      expect(mockDependencies.setIsDevicePricingApiCallEnable).toHaveBeenCalledTimes(1);
      expect(mockDependencies.setIsDevicePricingApiCallEnable).toHaveBeenCalledWith(true);
    });

    test('should include deviceId when type is PDPLocalScan', async () => {
      await doCallGetSkuDetails(validFilteredSku, 'PDPLocalScan', mockDependencies);

      expect(mockDependencies.getInventoryDetails).toHaveBeenCalledTimes(1);
      const callArgs = mockDependencies.getInventoryDetails.mock.calls[0][0];
      expect(callArgs.body.data).toHaveProperty('deviceId');
    });

    test('should NOT include deviceId when type is not PDPLocalScan', async () => {
      await doCallGetSkuDetails(validFilteredSku, 'size', mockDependencies);

      expect(mockDependencies.getInventoryDetails).toHaveBeenCalledTimes(1);
      const callArgs = mockDependencies.getInventoryDetails.mock.calls[0][0];
      expect(callArgs.body.data).not.toHaveProperty('deviceId');
    });

    test('should call computeDPPriceBody when downPayment > 0', async () => {
      const depsWithDownPayment = {
        ...mockDependencies,
        downPayment: 100,
      };

      await doCallGetSkuDetails(validFilteredSku, 'size', depsWithDownPayment);

      expect(depsWithDownPayment.computeDPPriceBody).toHaveBeenCalledTimes(1);
      expect(depsWithDownPayment.computeDPPriceBody).toHaveBeenCalledWith(
        {
          body: {
            sorId: 'SKU123',
            mtn: '1234567890',
            term: 36,
            downPayment: 100,
            isPercentage: false,
            agentOrFullRetailPrice: '999.99',
            loanOfferId: 'LOAN123',
          },
        },
        false
      );
    });

    test('should call computeDPPriceBody when filteredLineFromCart downPayment > 0', async () => {
      const depsWithCartDownPayment = {
        ...mockDependencies,
        downPayment: 0,
        filteredLineFromCart: {
          installmentInfo: {
            downPayment: 200,
          },
        },
      };

      await doCallGetSkuDetails(validFilteredSku, 'size', depsWithCartDownPayment);

      expect(depsWithCartDownPayment.computeDPPriceBody).toHaveBeenCalledTimes(1);
      const callArgs = depsWithCartDownPayment.computeDPPriceBody.mock.calls[0][0];
      expect(callArgs.body.downPayment).toBe(200);
    });

    test('should NOT call computeDPPriceBody when downPayment is 0', async () => {
      await doCallGetSkuDetails(validFilteredSku, 'size', mockDependencies);

      expect(mockDependencies.computeDPPriceBody).not.toHaveBeenCalled();
    });

    test('should handle missing preferredTerm gracefully', async () => {
      const skuWithoutTerm = {
        ...validFilteredSku,
        price: {
          ...validFilteredSku.price,
          preferredTerm: undefined,
        },
      };

      const depsWithDownPayment = {
        ...mockDependencies,
        downPayment: 100,
      };

      await doCallGetSkuDetails(skuWithoutTerm, 'size', depsWithDownPayment);

      expect(depsWithDownPayment.computeDPPriceBody).toHaveBeenCalled();
      const callArgs = depsWithDownPayment.computeDPPriceBody.mock.calls[0][0];
      expect(callArgs.body.term).toBeUndefined();
    });

    test('should handle missing loanOfferId with empty string', async () => {
      const skuWithoutLoanId = {
        ...validFilteredSku,
        price: {
          ...validFilteredSku.price,
          devicePaymentPrice: [{}],
        },
      };

      const depsWithDownPayment = {
        ...mockDependencies,
        downPayment: 100,
      };

      await doCallGetSkuDetails(skuWithoutLoanId, 'size', depsWithDownPayment);

      expect(depsWithDownPayment.computeDPPriceBody).toHaveBeenCalled();
      const callArgs = depsWithDownPayment.computeDPPriceBody.mock.calls[0][0];
      expect(callArgs.body.loanOfferId).toBe('');
    });
  });

  describe('FALSE Branch - Condition Not Met', () => {
    test('should NOT execute IF block when filteredSku is null', async () => {
      await doCallGetSkuDetails(null, 'size', mockDependencies);

      expect(mockDependencies.getInventoryDetails).not.toHaveBeenCalled();
      expect(mockDependencies.computeDPPriceBody).not.toHaveBeenCalled();
      expect(mockDependencies.setUpcCode).not.toHaveBeenCalled();
      expect(mockDependencies.setIsDevicePricingApiCallEnable).not.toHaveBeenCalled();
    });

    test('should NOT execute IF block when filteredSku is undefined', async () => {
      await doCallGetSkuDetails(undefined, 'size', mockDependencies);

      expect(mockDependencies.getInventoryDetails).not.toHaveBeenCalled();
      expect(mockDependencies.computeDPPriceBody).not.toHaveBeenCalled();
      expect(mockDependencies.setUpcCode).not.toHaveBeenCalled();
      expect(mockDependencies.setIsDevicePricingApiCallEnable).not.toHaveBeenCalled();
    });

    test('should NOT execute IF block when sorId is undefined', async () => {
      const skuWithoutSorId = {
        price: { fullRetailPrice: { originalPrice: '999.99' } },
        sorId: undefined,
      };

      await doCallGetSkuDetails(skuWithoutSorId, 'size', mockDependencies);

      expect(mockDependencies.getInventoryDetails).not.toHaveBeenCalled();
      expect(mockDependencies.computeDPPriceBody).not.toHaveBeenCalled();
      expect(mockDependencies.setUpcCode).not.toHaveBeenCalled();
      expect(mockDependencies.setIsDevicePricingApiCallEnable).not.toHaveBeenCalled();
    });

    test('should NOT execute IF block when sorId is empty string', async () => {
      const skuWithEmptySorId = {
        price: { fullRetailPrice: { originalPrice: '999.99' } },
        sorId: '',
      };

      await doCallGetSkuDetails(skuWithEmptySorId, 'size', mockDependencies);

      expect(mockDependencies.getInventoryDetails).not.toHaveBeenCalled();
      expect(mockDependencies.computeDPPriceBody).not.toHaveBeenCalled();
      expect(mockDependencies.setUpcCode).not.toHaveBeenCalled();
      expect(mockDependencies.setIsDevicePricingApiCallEnable).not.toHaveBeenCalled();
    });

    test('should NOT execute IF block when sorId is 0', async () => {
      const skuWithZeroSorId = {
        price: { fullRetailPrice: { originalPrice: '999.99' } },
        sorId: 0,
      };

      await doCallGetSkuDetails(skuWithZeroSorId, 'size', mockDependencies);

      expect(mockDependencies.getInventoryDetails).not.toHaveBeenCalled();
      expect(mockDependencies.computeDPPriceBody).not.toHaveBeenCalled();
      expect(mockDependencies.setUpcCode).not.toHaveBeenCalled();
      expect(mockDependencies.setIsDevicePricingApiCallEnable).not.toHaveBeenCalled();
    });
  });

  describe('Edge Cases', () => {
    test('should handle missing upcCodeFull', async () => {
      const skuWithoutUpc = {
        sorId: 'SKU123',
        price: {
          fullRetailPrice: { originalPrice: '999.99' },
          devicePaymentPrice: [
            {
              dpTermPrices: {
                preferredTerm: 36,
                loanOfferDetails: { loanOfferId: 'LOAN123' },
              },
            },
          ],
          preferredTerm: 36,
        },
        upcCodeFull: undefined,
      };

      await doCallGetSkuDetails(skuWithoutUpc, 'size', mockDependencies);

      expect(mockDependencies.setUpcCode).toHaveBeenCalledWith(undefined);
    });

    test('should handle complex downPayment fallback logic', async () => {
      const depsWithCartDownPayment = {
        ...mockDependencies,
        downPayment: 0,
        filteredLineFromCart: {
          installmentInfo: {
            downPayment: 150,
          },
        },
      };

      await doCallGetSkuDetails(
        {
          sorId: 'SKU123',
          price: { fullRetailPrice: { originalPrice: '999.99' } },
        },
        'size',
        depsWithCartDownPayment
      );

      expect(depsWithCartDownPayment.computeDPPriceBody).toHaveBeenCalled();
    });
  });

  describe('Integration Scenarios', () => {
    test('should execute complete TRUE branch flow', async () => {
      const completeSku = {
        sorId: 'COMPLETE_SKU',
        price: {
          fullRetailPrice: { originalPrice: '1099.99' },
          devicePaymentPrice: [
            {
              dpTermPrices: {
                preferredTerm: 24,
                loanOfferDetails: { loanOfferId: 'LOAN456' },
              },
            },
          ],
          preferredTerm: 24,
        },
        upcCodeFull: '111222333444',
      };

      const depsWithDownPayment = {
        ...mockDependencies,
        downPayment: 150,
      };

      await doCallGetSkuDetails(completeSku, 'PDPLocalScan', depsWithDownPayment);

      // All functions should be called
      expect(depsWithDownPayment.getInventoryDetails).toHaveBeenCalled();
      expect(depsWithDownPayment.computeDPPriceBody).toHaveBeenCalled();
      expect(depsWithDownPayment.setUpcCode).toHaveBeenCalled();
      expect(depsWithDownPayment.setIsDevicePricingApiCallEnable).toHaveBeenCalled();

      // Verify params include deviceId
      const inventoryCall = depsWithDownPayment.getInventoryDetails.mock.calls[0][0];
      expect(inventoryCall.body.data).toHaveProperty('deviceId');

      // Verify all values are correct
      expect(depsWithDownPayment.setUpcCode).toHaveBeenCalledWith('111222333444');
      expect(depsWithDownPayment.setIsDevicePricingApiCallEnable).toHaveBeenCalledWith(true);
    });
  });
});
