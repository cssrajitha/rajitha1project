import * as DomService from 'onevzsoemfeframework/DomService';
import { fireEvent, render, screen, waitFor } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import DeviceInfo from '../DeviceInfo';

jest.mock('../../utils/GetAppConfig', () => ({
  GetAppConfig: jest.fn(),
}));

jest.mock('../../utils/assistedCradle', () => ({
  getAssistedCradlePropertyV2: jest.fn(),
  isVbg: jest.fn(),
}));

// ✅ Capture Footer props so we can assert isSelectedDeviceByod
let footerPropsSpy = null;

// ✅ Update Footer import path to match your file
jest.mock('../Footer', () => (props) => {
  footerPropsSpy = props;
  return <div data-testid="footer-mock" />;
});

function baseProps(overrides = {}) {
  return {
    activeMtn: '1112223333',

    // lineInfo is derived from customerProfileDetails.customer.billAccounts[0].mtns filtered by activeMtn
    customerProfileDetails: {
      customer: {
        channel: 'OMNI-CARE',
        billAccounts: [
          {
            mtns: [
              {
                mtn: '1112223333',
                pricePlanInfo: { planId: 'PLAN_ULT_123' }, // <-- selectedDevicePlanId
                equipmentInfos: [{ deviceInfo: { deviceId: 'D1' }, simInfo: { simId: 'S1' } }],
              },
            ],
          },
        ],
      },
      commonInfo: { isIndirect: false },
    },

    // keep cartDetails shape safe (your file reads several nested paths)
    cartDetails: {
      cart: {
        orderDetails: { orderDepletionType: 'N', customerType: 'E' },
        lineDetails: { lineInfo: [] },
      },
    },

    // minimal objects to avoid undefined access in many places
    details: {},
    productDetails: { deviceSku: { parentProducts: [{}] }, accountInfo: {} },
    GetDetailsResult: { data: { featureFlags: {} } },
    SkuDetailsResult: { data: { data: { deviceSku: { parentProducts: [] } } } },
    InventoryDetailsResult: { data: { data: {} } },

    // ensure displayPaymentOptions can build at least one option that carries data-track 'Productdetail_MonthlyPayments'
    selectedSku: {
      sorId: 'SOR1',
      skuFilters: {},
      inventoryDetails: { dFillInventory: {} },
      price: {
        devicePaymentPrice: [
          { contractDuration: 36, originalPrice: 10 }, // used to generate payment option rows
        ],
        fullRetailPrice: { allPromotions: [] },
      },
      parentProducts: [{ compatibleSimSorIds: [] }],
    },

    // props referenced around Footer rendering
    scmDeviceEnable: false,
    scmUpgradeMfeEnable: false,
    showPlanChange: false,
    isAcssDfillSim: false,

    // callbacks used across file (safe no-ops)
    setEnableBYODbtn: jest.fn(),
    updatePaymentDetails: jest.fn(),
    removeLines: jest.fn(),

    ...overrides,
  };
}

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => false,
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

// Ensure APP_PROPERTIES is valid JSON for tests to avoid JSON.parse errors in DeviceInfo
beforeEach(() => {
  const appProps = {
    earlyUpgradeOrderVVCFFlag: "FALSE",
    shipToggleFFlag: "FALSE",
    isVVCFlowEnabled: "FALSE",
    vbgNSAAALActivateLaterFFlag: "FALSE"
  };
  sessionStorage.setItem("APP_PROPERTIES", JSON.stringify(appProps));
});

const getProps = (ispuToggleOn = false, isShipItToggleOn = false) => {
  const mockSetSelectedColor = jest.fn();
  const mockSetIspuToggleOn = jest.fn();
  const mockSetIsShipItToggleOn = jest.fn();
  const mockSetSelectedSku = jest.fn();
  const mockSetSelectedProtectionFeature = jest.fn();
  const mockSetSelectedSize = jest.fn();
  const setSelectedPaymentInfo = jest.fn();
  const setShowDeviceProtectionModal = jest.fn();
  const updateDeviceId = jest.fn();
  const updateSimId = jest.fn();
  const updateDeviceData = jest.fn();
  const setUpgradeReasonType = jest.fn();
  const setisInStock = jest.fn();
  const getContractTerm = jest.fn();
  const setBuyOutAccepted = jest.fn();
  const setSkipRedirection = jest.fn();
  const removeLines = jest.fn();
  const defaultProps = {
    productDetails: {
      deviceProduct: {
        brandName: 'Apple',
        defaultSKU: 'MQ0E3LL/A',
        description:
          'iPhone 14 Pro. Capture incredible detail with a 48MP Main camera. Experience iPhone in a whole new way with Dynamic Island and Always-On display. And get peace of mind with groundbreaking safety features. Pair iPhone 14 Pro with Verizon, the network America relies on. 5G Ultra Wideband is now in more and more places, so more and more people can do amazing things with Verizon and iPhone 14 Pro. ',
        isFreeOverNightShipping: false,
        isComingSoon: false,
        parentCategories: ['cat180001', 'cat4060119', 'cat180004'],
        productId: 'dev19920005',
        productDisplayName: 'iPhone 14 Pro',
        rating: {
          numberOfReviews: '7724',
          averageRating: '4.3756',
          productId: null,
          batteryLife: null,
          callQuality: null,
          design: null,
          display: null,
          easeOfUse: null,
          features: null,
          percentRecommended: null,
          performance: null,
        },
        seo: {
          h1Tag: 'iPhone 14 Pro',
          canonicalUrl: 'smartphones/apple-iphone-14-pro/',
          metaDescription:
            'Order the new Apple iPhone 14 Pro at Verizon, the network America relies on. See reviews, features, colors and more.',
          metaTitle: 'Buy the New iPhone 14 Pro - Price, Colors | Verizon',
          metaRobotsIndex: '1001',
          metaRobotsFollow: '1',
          seoUrlName: 'apple-iphone-14-pro',
        },
        customerAttributes: {
          establishedDate: '01/15/2020',
          customerType: 'PE',
          digitalCustomerType: 'B2C',
          firstName: 'DAN',
          lastName: 'JETER',
          zipCode: '31023',
          zipCodePlus4: '3512',
          inWithVerizonInd: 'N',
          state: 'GA',
          hashedMdn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
          hashedAccountNumber: 'cccff0728bd1a30e896d15347b8ead72f887ea845508d33c3d7ce1a3735b9e95',
          mtnList: ['4782303946'],
          loggedInMtn: 'MASTRAL',
          lineDetails: [
            {
              mtn: '4782303946',
              hashedMtn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
              existingFWA: false,
            },
          ],
        },
        blockCTA: false,
        additionalDisclosures:
          "<ol><li>Splash, Water, and Dust Resistance: iPhone 14 Pro and iPhone 14 Pro Max are splash, water, and dust resistant and were tested under controlled laboratory conditions with a rating of IP68 under IEC standard 60529 (maximum depth of 6 meters up to 30 minutes). Splash, water, and dust resistance are not permanent conditions. Resistance might decrease as a result of normal wear. Do not attempt to charge a wet iPhone; refer to the user guide for cleaning and drying instructions. Liquid damage not covered under warranty.</li><li>FaceTime: FaceTime calling requires a FaceTime-enabled device for the caller and recipient and a Wi-Fi connection. Availability over a cellular network depends on carrier policies; data charges may apply.</li><li>Emergency SOS via Satellite: Available in November 2022. Service is included for free for two years with the activation of any iPhone 14 model. Connection and response times vary based on location, site conditions, and other factors. See <a href='https://www.apple.com/iphone-14/' target='_blank'>apple.com/iphone-14</a> or <a href='https://www.apple.com/iphone-14-pro/' target='_blank'>apple.com/iphone-14-pro</a> for more information.</li><li>Crash Detection: Emergency SOS uses a cellular connection or Wi-Fi calling.</li><li>Camera Resolution: Compared with the previous generation.</li><li>CPU Speed: Compared with the previous generation.</li><li>Power and Battery: All battery claims depend on network configuration and many other factors; actual results will vary. Battery has limited recharge cycles and may eventually need to be replaced. Battery life and charge cycles vary by use and settings. See <a href='https://www.apple.com/batteries/' target='_blank'>apple.com/batteries</a> and <a href='https://www.apple.com/iphone/battery.html' target='_blank'>apple.com/iphone/battery.html</a> for more information.</li></ol>\r",
        childSkus: [
          {
            color: {
              colorCssStyle: '#D0C2AE',
              colorId: 'clr3360032',
              description: 'Gold',
              displayName: 'Gold',
            },
            price: {
              devicePaymentPrice: [
                {
                  originalPrice: 30.55,
                  contractDuration: 36,
                  contractText:
                    'Monthly payments shown are for customers who qualify to pay $0 Down, $30.55/mo. for 36 months; 0% APR. Retail Price: $1099.99',
                  dpTermPrices: {
                    downPayment: 0,
                    downPaymentRequired: false,
                    upgradeOptionPercentage: 50,
                    upgradeOptionCode: 'UO',
                    dpTerm: 36,
                    ugradeEligibilityCategory: [],
                    firstMonthPrice: 30.74,
                    remainingMonthPrice: 30.55,
                  },
                },
              ],
              fullRetailPrice: {
                originalPrice: 1099.99,
                contractText: 'Full Retail Price',
              },
              preferredTerm: 36,
            },
            comingSoonFlag: false,
            imageUrlMap: {
              defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a',
              largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-lg$',
              mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-med$',
              miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-mini$',
              thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-thumb$',
              imageSetUrl:
                'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
            },
            inventoryDetails: {
              dFillInventory: {
                isAvailable: false,
                isBackorder: false,
                isDeliverBy: false,
                isPreOrder: false,
                isShipBy: false,
                isInStock: true,
                locationCode: '9999999',
                qtyAvailable: 49554,
              },
            },
            isBillToAccount: false,
            isRestrictionEnabled: true,
            prodCode1: '5GD',
            prodCode2: 'SMT',
            prodCode3: 'DIG',
            prodCode4: 'VDS',
            prodCode5: 'ISL',
            skuDisplayName: 'iPhone 14 Pro 256GB in Gold',
            skuId: 'sku5600279',
            sorId: 'MQ163LL/A',
            customerAttributes: {
              establishedDate: '01/15/2020',
              customerType: 'PE',
              digitalCustomerType: 'B2C',
              firstName: 'DAN',
              lastName: 'JETER',
              zipCode: '31023',
              zipCodePlus4: '3512',
              inWithVerizonInd: 'N',
              state: 'GA',
              hashedMdn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
              hashedAccountNumber: 'cccff0728bd1a30e896d15347b8ead72f887ea845508d33c3d7ce1a3735b9e95',
              mtnList: ['4782303946'],
              lineDetails: [
                {
                  mtn: '4782303946',
                  hashedMtn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
                  existingFWA: false,
                },
              ],
            },
            capacity: '256 GB',
            capacitySize: 256,
            capacityUnit: '256 GB',
            isDevicePaymentEligible: true,
            isInstorePickup: true,
            isSameDayDelivery: true,
            isHumDevice: false,
            isSmartLocator: false,
            simSku: 'UNIVESIM5G-SA-D',
            edgeDeviceCap: '1110',
            productIdMap: {
              prepayProduct: 'dev20000221',
              postPayProduct: 'dev19920005',
            },
            skuRestricted: false,
            skuFilters: {
              deviceFilterType: 'Smartphones',
              restrictedAccySku: 'false',
            },
            isPreconfigureEnabled: false,
            itemSaleFlag: true,
            isPromoEligible: false,
          },
          {
            color: {
              colorCssStyle: '#655D6C',
              colorId: 'clr12200029',
              description: 'Purple',
              displayName: 'Deep Purple',
            },
            price: {
              devicePaymentPrice: [
                {
                  originalPrice: 36.11,
                  contractDuration: 36,
                  contractText:
                    'Monthly payments shown are for customers who qualify to pay $0 Down, $36.11/mo. for 36 months; 0% APR. Retail Price: $1299.99',
                  dpTermPrices: {
                    downPayment: 0,
                    downPaymentRequired: false,
                    upgradeOptionPercentage: 50,
                    upgradeOptionCode: 'UO',
                    dpTerm: 36,
                    ugradeEligibilityCategory: [],
                    firstMonthPrice: 36.14,
                    remainingMonthPrice: 36.11,
                  },
                },
              ],
              fullRetailPrice: {
                originalPrice: 1299.99,
                contractText: 'Full Retail Price',
              },
              preferredTerm: 36,
            },
            comingSoonFlag: false,
            imageUrlMap: {
              defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a',
              largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-lg$',
              mediumImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-med$',
              miniImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-mini$',
              thumbImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-thumb$',
              imageSetUrl:
                'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
            },
            inventoryDetails: {
              dFillInventory: {
                isAvailable: false,
                isBackorder: true,
                isDeliverBy: false,
                isPreOrder: false,
                isShipBy: true,
                isInStock: false,
                locationCode: '9999999',
                qtyAvailable: 0,
                shippingDate: {
                  date: '12/29/2023',
                  dateTime: '12-29-2023 05:00:00 AM',
                  dateLong: 1703826000000,
                },
              },
            },
            isBillToAccount: false,
            isRestrictionEnabled: true,
            prodCode1: '5GD',
            prodCode2: 'SMT',
            prodCode3: 'DIG',
            prodCode4: 'VDS',
            prodCode5: 'ISL',
            skuDisplayName: 'iPhone 14 Pro 512GB in Deep Purple',
            skuId: 'sku5600181',
            sorId: 'MQ273LL/A',
            customerAttributes: {
              establishedDate: '01/15/2020',
              customerType: 'PE',
              digitalCustomerType: 'B2C',
              firstName: 'DAN',
              lastName: 'JETER',
              zipCode: '31023',
              zipCodePlus4: '3512',
              inWithVerizonInd: 'N',
              state: 'GA',
              hashedMdn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
              hashedAccountNumber: 'cccff0728bd1a30e896d15347b8ead72f887ea845508d33c3d7ce1a3735b9e95',
              mtnList: ['4782303946'],
              lineDetails: [
                {
                  mtn: '4782303946',
                  hashedMtn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
                  existingFWA: false,
                },
              ],
            },
            capacity: '512 GB',
            capacitySize: 512,
            capacityUnit: '512 GB',
            isDevicePaymentEligible: true,
            isInstorePickup: true,
            isSameDayDelivery: true,
            isHumDevice: false,
            isSmartLocator: false,
            simSku: 'UNIVESIM5G-SA-D',
            edgeDeviceCap: '1310',
            productIdMap: {
              prepayProduct: 'dev20000221',
              postPayProduct: 'dev19920005',
            },
            skuRestricted: false,
            skuFilters: {
              deviceFilterType: 'Smartphones',
              restrictedAccySku: 'false',
            },
            isPreconfigureEnabled: false,
            itemSaleFlag: false,
            isPromoEligible: false,
          },
          {
            color: {
              colorCssStyle: '#655D6C',
              colorId: 'clr12200029',
              description: 'Purple',
              displayName: 'Deep Purple',
            },
            price: {
              devicePaymentPrice: [
                {
                  originalPrice: 41.66,
                  contractDuration: 36,
                  contractText:
                    'Monthly payments shown are for customers who qualify to pay $0 Down, $41.66/mo. for 36 months; 0% APR. Retail Price: $1499.99',
                  dpTermPrices: {
                    downPayment: 0,
                    downPaymentRequired: false,
                    upgradeOptionPercentage: 50,
                    upgradeOptionCode: 'UO',
                    dpTerm: 36,
                    ugradeEligibilityCategory: [],
                    firstMonthPrice: 41.89,
                    remainingMonthPrice: 41.66,
                  },
                },
              ],
              fullRetailPrice: {
                originalPrice: 1499.99,
                contractText: 'Full Retail Price',
              },
              preferredTerm: 36,
            },
            comingSoonFlag: false,
            imageUrlMap: {
              defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a',
              largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-lg$',
              mediumImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-med$',
              miniImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-mini$',
              thumbImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-thumb$',
              imageSetUrl:
                'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
            },
            inventoryDetails: {
              dFillInventory: {
                isAvailable: false,
                isBackorder: false,
                isDeliverBy: false,
                isPreOrder: false,
                isShipBy: false,
                isInStock: true,
                locationCode: '9999999',
                qtyAvailable: 49484,
              },
            },
            isBillToAccount: false,
            isRestrictionEnabled: true,
            prodCode1: '5GD',
            prodCode2: 'SMT',
            prodCode3: 'DIG',
            prodCode4: 'VDS',
            prodCode5: 'ISL',
            skuDisplayName: 'iPhone 14 Pro 1TB in Deep Purple',
            skuId: 'sku5600182',
            sorId: 'MQ303LL/A',
            customerAttributes: {
              establishedDate: '01/15/2020',
              customerType: 'PE',
              digitalCustomerType: 'B2C',
              firstName: 'DAN',
              lastName: 'JETER',
              zipCode: '31023',
              zipCodePlus4: '3512',
              inWithVerizonInd: 'N',
              state: 'GA',
              hashedMdn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
              hashedAccountNumber: 'cccff0728bd1a30e896d15347b8ead72f887ea845508d33c3d7ce1a3735b9e95',
              mtnList: ['4782303946'],
              lineDetails: [
                {
                  mtn: '4782303946',
                  hashedMtn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
                  existingFWA: false,
                },
              ],
            },
            capacity: '1 TB',
            capacitySize: 1,
            capacityUnit: '1 TB',
            isDevicePaymentEligible: true,
            isInstorePickup: true,
            isSameDayDelivery: true,
            isHumDevice: false,
            isSmartLocator: false,
            simSku: 'UNIVESIM5G-SA-D',
            edgeDeviceCap: '1510',
            productIdMap: {
              prepayProduct: 'dev20000221',
              postPayProduct: 'dev19920005',
            },
            skuRestricted: false,
            skuFilters: {
              deviceFilterType: 'Smartphones',
              restrictedAccySku: 'false',
            },
            isPreconfigureEnabled: false,
            itemSaleFlag: false,
            isPromoEligible: false,
          },
          {
            color: {
              colorCssStyle: '#655D6C',
              colorId: 'clr12200029',
              description: 'Purple',
              displayName: 'Deep Purple',
            },
            price: {
              devicePaymentPrice: [
                {
                  originalPrice: 30.55,
                  contractDuration: 36,
                  contractText:
                    'Monthly payments shown are for customers who qualify to pay $0 Down, $30.55/mo. for 36 months; 0% APR. Retail Price: $1099.99',
                  dpTermPrices: {
                    downPayment: 0,
                    downPaymentRequired: false,
                    upgradeOptionPercentage: 50,
                    upgradeOptionCode: 'UO',
                    dpTerm: 36,
                    ugradeEligibilityCategory: [],
                    firstMonthPrice: 30.74,
                    remainingMonthPrice: 30.55,
                  },
                },
              ],
              fullRetailPrice: {
                originalPrice: 1099.99,
                contractText: 'Full Retail Price',
              },
              preferredTerm: 36,
            },
            comingSoonFlag: false,
            imageUrlMap: {
              defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a',
              largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-lg$',
              mediumImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-med$',
              miniImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-mini$',
              thumbImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-thumb$',
              imageSetUrl:
                'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
            },
            inventoryDetails: {
              dFillInventory: {
                isAvailable: false,
                isBackorder: false,
                isDeliverBy: false,
                isPreOrder: false,
                isShipBy: false,
                isInStock: true,
                locationCode: '9999999',
                qtyAvailable: 50524,
              },
            },
            isBillToAccount: false,
            isRestrictionEnabled: true,
            prodCode1: '5GD',
            prodCode2: 'SMT',
            prodCode3: 'DIG',
            prodCode4: 'VDS',
            prodCode5: 'ISL',
            skuDisplayName: 'iPhone 14 Pro 256GB in Deep Purple',
            skuId: 'sku5600280',
            sorId: 'MQ1D3LL/A',
            customerAttributes: {
              establishedDate: '01/15/2020',
              customerType: 'PE',
              digitalCustomerType: 'B2C',
              firstName: 'DAN',
              lastName: 'JETER',
              zipCode: '31023',
              zipCodePlus4: '3512',
              inWithVerizonInd: 'N',
              state: 'GA',
              hashedMdn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
              hashedAccountNumber: 'cccff0728bd1a30e896d15347b8ead72f887ea845508d33c3d7ce1a3735b9e95',
              mtnList: ['4782303946'],
              lineDetails: [
                {
                  mtn: '4782303946',
                  hashedMtn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
                  existingFWA: false,
                },
              ],
            },
            capacity: '256 GB',
            capacitySize: 256,
            capacityUnit: '256 GB',
            isDevicePaymentEligible: true,
            isInstorePickup: true,
            isSameDayDelivery: true,
            isHumDevice: false,
            isSmartLocator: false,
            simSku: 'UNIVESIM5G-SA-D',
            edgeDeviceCap: '1110',
            productIdMap: {
              prepayProduct: 'dev20000221',
              postPayProduct: 'dev19920005',
            },
            skuRestricted: false,
            skuFilters: {
              deviceFilterType: 'Smartphones',
              restrictedAccySku: 'false',
            },
            isPreconfigureEnabled: false,
            itemSaleFlag: true,
            isPromoEligible: false,
          },
          {
            color: {
              colorCssStyle: '#D0C2AE',
              colorId: 'clr3360032',
              description: 'Gold',
              displayName: 'Gold',
            },
            price: {
              devicePaymentPrice: [
                {
                  originalPrice: 36.11,
                  contractDuration: 36,
                  contractText:
                    'Monthly payments shown are for customers who qualify to pay $0 Down, $36.11/mo. for 36 months; 0% APR. Retail Price: $1299.99',
                  dpTermPrices: {
                    downPayment: 0,
                    downPaymentRequired: false,
                    upgradeOptionPercentage: 50,
                    upgradeOptionCode: 'UO',
                    dpTerm: 36,
                    ugradeEligibilityCategory: [],
                    firstMonthPrice: 36.14,
                    remainingMonthPrice: 36.11,
                  },
                },
              ],
              fullRetailPrice: {
                originalPrice: 1299.99,
                contractText: 'Full Retail Price',
              },
              preferredTerm: 36,
            },
            comingSoonFlag: false,
            imageUrlMap: {
              defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a',
              largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-lg$',
              mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-med$',
              miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-mini$',
              thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-thumb$',
              imageSetUrl:
                'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
            },
            inventoryDetails: {
              dFillInventory: {
                isAvailable: false,
                isBackorder: false,
                isDeliverBy: false,
                isPreOrder: false,
                isShipBy: false,
                isInStock: true,
                locationCode: '9999999',
                qtyAvailable: 52353,
              },
            },
            isBillToAccount: false,
            isRestrictionEnabled: true,
            prodCode1: '5GD',
            prodCode2: 'SMT',
            prodCode3: 'DIG',
            prodCode4: 'VDS',
            prodCode5: 'ISL',
            skuDisplayName: 'iPhone 14 Pro 512GB in Gold',
            skuId: 'sku5600282',
            sorId: 'MQ213LL/A',
            customerAttributes: {
              establishedDate: '01/15/2020',
              customerType: 'PE',
              digitalCustomerType: 'B2C',
              firstName: 'DAN',
              lastName: 'JETER',
              zipCode: '31023',
              zipCodePlus4: '3512',
              inWithVerizonInd: 'N',
              state: 'GA',
              hashedMdn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
              hashedAccountNumber: 'cccff0728bd1a30e896d15347b8ead72f887ea845508d33c3d7ce1a3735b9e95',
              mtnList: ['4782303946'],
              lineDetails: [
                {
                  mtn: '4782303946',
                  hashedMtn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
                  existingFWA: false,
                },
              ],
            },
            capacity: '512 GB',
            capacitySize: 512,
            capacityUnit: '512 GB',
            isDevicePaymentEligible: true,
            isInstorePickup: true,
            isSameDayDelivery: true,
            isHumDevice: false,
            isSmartLocator: false,
            simSku: 'UNIVESIM5G-SA-D',
            edgeDeviceCap: '1310',
            productIdMap: {
              prepayProduct: 'dev20000221',
              postPayProduct: 'dev19920005',
            },
            skuRestricted: false,
            skuFilters: {
              deviceFilterType: 'Smartphones',
              restrictedAccySku: 'false',
            },
            isPreconfigureEnabled: false,
            itemSaleFlag: false,
            isPromoEligible: false,
          },
          {
            color: {
              colorCssStyle: '#C0C0C0',
              colorId: 'clr40012',
              description: 'Silver',
              displayName: 'Silver',
            },
            price: {
              devicePaymentPrice: [
                {
                  originalPrice: 41.66,
                  contractDuration: 36,
                  contractText:
                    'Monthly payments shown are for customers who qualify to pay $0 Down, $41.66/mo. for 36 months; 0% APR. Retail Price: $1499.99',
                  dpTermPrices: {
                    downPayment: 0,
                    downPaymentRequired: false,
                    upgradeOptionPercentage: 50,
                    upgradeOptionCode: 'UO',
                    dpTerm: 36,
                    ugradeEligibilityCategory: [],
                    firstMonthPrice: 41.89,
                    remainingMonthPrice: 41.66,
                  },
                },
              ],
              fullRetailPrice: {
                originalPrice: 1499.99,
                contractText: 'Full Retail Price',
              },
              preferredTerm: 36,
            },
            comingSoonFlag: false,
            imageUrlMap: {
              defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a',
              largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-lg$',
              mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-med$',
              miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-mini$',
              thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-thumb$',
              imageSetUrl:
                'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
            },
            inventoryDetails: {
              dFillInventory: {
                isAvailable: false,
                isBackorder: false,
                isDeliverBy: false,
                isPreOrder: false,
                isShipBy: false,
                isInStock: true,
                locationCode: '9999999',
                qtyAvailable: 49752,
              },
            },
            isBillToAccount: false,
            isRestrictionEnabled: true,
            prodCode1: '5GD',
            prodCode2: 'SMT',
            prodCode3: 'DIG',
            prodCode4: 'VDS',
            prodCode5: 'ISL',
            skuDisplayName: 'iPhone 14 Pro 1TB in Silver',
            skuId: 'sku5600284',
            sorId: 'MQ2L3LL/A',
            customerAttributes: {
              establishedDate: '01/15/2020',
              customerType: 'PE',
              digitalCustomerType: 'B2C',
              firstName: 'DAN',
              lastName: 'JETER',
              zipCode: '31023',
              zipCodePlus4: '3512',
              inWithVerizonInd: 'N',
              state: 'GA',
              hashedMdn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
              hashedAccountNumber: 'cccff0728bd1a30e896d15347b8ead72f887ea845508d33c3d7ce1a3735b9e95',
              mtnList: ['4782303946'],
              lineDetails: [
                {
                  mtn: '4782303946',
                  hashedMtn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
                  existingFWA: false,
                },
              ],
            },
            capacity: '1 TB',
            capacitySize: 1,
            capacityUnit: '1 TB',
            isDevicePaymentEligible: true,
            isInstorePickup: true,
            isSameDayDelivery: true,
            isHumDevice: false,
            isSmartLocator: false,
            simSku: 'UNIVESIM5G-SA-D',
            edgeDeviceCap: '1510',
            productIdMap: {
              prepayProduct: 'dev20000221',
              postPayProduct: 'dev19920005',
            },
            skuRestricted: false,
            skuFilters: {
              deviceFilterType: 'Smartphones',
              restrictedAccySku: 'false',
            },
            isPreconfigureEnabled: false,
            itemSaleFlag: false,
            isPromoEligible: false,
          },
          {
            color: {
              colorCssStyle: '#D0C2AE',
              colorId: 'clr3360032',
              description: 'Gold',
              displayName: 'Gold',
            },
            price: {
              devicePaymentPrice: [
                {
                  originalPrice: 27.77,
                  contractDuration: 36,
                  contractText:
                    'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
                  dpTermPrices: {
                    downPayment: 0,
                    downPaymentRequired: false,
                    upgradeOptionPercentage: 50,
                    upgradeOptionCode: 'UO',
                    dpTerm: 36,
                    ugradeEligibilityCategory: [],
                    firstMonthPrice: 28.04,
                    remainingMonthPrice: 27.77,
                  },
                },
              ],
              fullRetailPrice: {
                originalPrice: 999.99,
                contractText: 'Full Retail Price',
              },
              preferredTerm: 36,
            },
            comingSoonFlag: false,
            imageUrlMap: {
              defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a',
              largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-lg$',
              mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-med$',
              miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-mini$',
              thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-thumb$',
              imageSetUrl:
                'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
            },
            inventoryDetails: {
              dFillInventory: {
                isAvailable: false,
                isBackorder: false,
                isDeliverBy: false,
                isPreOrder: false,
                isShipBy: false,
                isInStock: true,
                locationCode: '9999999',
                qtyAvailable: 81351,
              },
            },
            isBillToAccount: false,
            isRestrictionEnabled: true,
            prodCode1: '5GD',
            prodCode2: 'SMT',
            prodCode3: 'DIG',
            prodCode4: 'VDS',
            prodCode5: 'ISL',
            skuDisplayName: 'iPhone 14 Pro 128GB in Gold',
            skuId: 'sku5600275',
            sorId: 'MQ063LL/A',
            customerAttributes: {
              establishedDate: '01/15/2020',
              customerType: 'PE',
              digitalCustomerType: 'B2C',
              firstName: 'DAN',
              lastName: 'JETER',
              zipCode: '31023',
              zipCodePlus4: '3512',
              inWithVerizonInd: 'N',
              state: 'GA',
              hashedMdn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
              hashedAccountNumber: 'cccff0728bd1a30e896d15347b8ead72f887ea845508d33c3d7ce1a3735b9e95',
              mtnList: ['4782303946'],
              lineDetails: [
                {
                  mtn: '4782303946',
                  hashedMtn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
                  existingFWA: false,
                },
              ],
            },
            capacity: '128 GB',
            capacitySize: 128,
            capacityUnit: '128 GB',
            isDevicePaymentEligible: true,
            isInstorePickup: true,
            isSameDayDelivery: true,
            isHumDevice: false,
            isSmartLocator: false,
            simSku: 'UNIVESIM5G-SA-D',
            edgeDeviceCap: '1010',
            productIdMap: {
              prepayProduct: 'dev20000221',
              postPayProduct: 'dev19920005',
            },
            skuRestricted: false,
            skuFilters: {
              deviceFilterType: 'Smartphones',
              restrictedAccySku: 'false',
            },
            isPreconfigureEnabled: false,
            itemSaleFlag: true,
            isPromoEligible: false,
          },
          {
            color: {
              colorCssStyle: '#1E1D1B',
              colorId: 'clr12240018',
              description: 'Black',
              displayName: 'Space Black',
            },
            price: {
              devicePaymentPrice: [
                {
                  originalPrice: 30.55,
                  contractDuration: 36,
                  contractText:
                    'Monthly payments shown are for customers who qualify to pay $0 Down, $30.55/mo. for 36 months; 0% APR. Retail Price: $1099.99',
                  dpTermPrices: {
                    downPayment: 0,
                    downPaymentRequired: false,
                    upgradeOptionPercentage: 50,
                    upgradeOptionCode: 'UO',
                    dpTerm: 36,
                    ugradeEligibilityCategory: [],
                    firstMonthPrice: 30.74,
                    remainingMonthPrice: 30.55,
                  },
                },
              ],
              fullRetailPrice: {
                originalPrice: 1099.99,
                contractText: 'Full Retail Price',
              },
              preferredTerm: 36,
            },
            comingSoonFlag: false,
            imageUrlMap: {
              defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
              largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
              mediumImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
              miniImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
              thumbImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
              imageSetUrl:
                'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
            },
            inventoryDetails: {
              dFillInventory: {
                isAvailable: false,
                isBackorder: false,
                isDeliverBy: false,
                isPreOrder: false,
                isShipBy: false,
                isInStock: true,
                locationCode: '9999999',
                qtyAvailable: 49767,
              },
            },
            isBillToAccount: false,
            isRestrictionEnabled: true,
            prodCode1: '5GD',
            prodCode2: 'SMT',
            prodCode3: 'DIG',
            prodCode4: 'VDS',
            prodCode5: 'ISL',
            skuDisplayName: 'iPhone 14 Pro 256GB in Space Black',
            skuId: 'sku5600277',
            sorId: 'MQ0N3LL/A',
            customerAttributes: {
              establishedDate: '01/15/2020',
              customerType: 'PE',
              digitalCustomerType: 'B2C',
              firstName: 'DAN',
              lastName: 'JETER',
              zipCode: '31023',
              zipCodePlus4: '3512',
              inWithVerizonInd: 'N',
              state: 'GA',
              hashedMdn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
              hashedAccountNumber: 'cccff0728bd1a30e896d15347b8ead72f887ea845508d33c3d7ce1a3735b9e95',
              mtnList: ['4782303946'],
              lineDetails: [
                {
                  mtn: '4782303946',
                  hashedMtn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
                  existingFWA: false,
                },
              ],
            },
            capacity: '256 GB',
            capacitySize: 256,
            capacityUnit: '256 GB',
            isDevicePaymentEligible: true,
            isInstorePickup: true,
            isSameDayDelivery: true,
            isHumDevice: false,
            isSmartLocator: false,
            simSku: 'UNIVESIM5G-SA-D',
            edgeDeviceCap: '1110',
            productIdMap: {
              prepayProduct: 'dev20000221',
              postPayProduct: 'dev19920005',
            },
            skuRestricted: false,
            skuFilters: {
              deviceFilterType: 'Smartphones',
              restrictedAccySku: 'false',
            },
            isPreconfigureEnabled: false,
            itemSaleFlag: true,
            isPromoEligible: false,
          },
          {
            color: {
              colorCssStyle: '#655D6C',
              colorId: 'clr12200029',
              description: 'Purple',
              displayName: 'Deep Purple',
            },
            price: {
              devicePaymentPrice: [
                {
                  originalPrice: 27.77,
                  contractDuration: 36,
                  contractText:
                    'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
                  dpTermPrices: {
                    downPayment: 0,
                    downPaymentRequired: false,
                    upgradeOptionPercentage: 100,
                    upgradeOptionCode: 'DP',
                    dpTerm: 36,
                    ugradeEligibilityCategory: [],
                    firstMonthPrice: 28.04,
                    remainingMonthPrice: 27.77,
                  },
                },
              ],
              fullRetailPrice: {
                originalPrice: 999.99,
                contractText: 'Full Retail Price',
              },
              preferredTerm: 36,
            },
            comingSoonFlag: false,
            imageUrlMap: {
              defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a',
              largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-lg$',
              mediumImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-med$',
              miniImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-mini$',
              thumbImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-thumb$',
              imageSetUrl:
                'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
            },
            inventoryDetails: {
              dFillInventory: {
                isAvailable: false,
                isBackorder: false,
                isDeliverBy: false,
                isPreOrder: false,
                isShipBy: false,
                isInStock: true,
                locationCode: '9999999',
                qtyAvailable: 120569,
              },
              localInventory: {
                isAvailable: false,
                isBackorder: false,
                isDeliverBy: false,
                isPreOrder: false,
                isShipBy: false,
                isInStock: true,
                locationCode: '2777301',
                qtyAvailable: 62,
              },
            },
            isBillToAccount: false,
            isRestrictionEnabled: true,
            prodCode1: '5GD',
            prodCode2: 'SMT',
            prodCode3: 'DIG',
            prodCode4: 'VDS',
            prodCode5: 'ISL',
            skuDisplayName: 'iPhone 14 Pro 128GB in Deep Purple',
            skuId: 'sku5600276',
            sorId: 'MQ0E3LL/A',
            customerAttributes: {
              establishedDate: '01/15/2020',
              customerType: 'PE',
              digitalCustomerType: 'B2C',
              firstName: 'DAN',
              lastName: 'JETER',
              zipCode: '31023',
              zipCodePlus4: '3512',
              inWithVerizonInd: 'N',
              state: 'GA',
              hashedMdn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
              hashedAccountNumber: 'cccff0728bd1a30e896d15347b8ead72f887ea845508d33c3d7ce1a3735b9e95',
              mtnList: ['4782303946'],
              lineDetails: [
                {
                  mtn: '4782303946',
                  hashedMtn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
                  existingFWA: false,
                },
              ],
            },
            capacity: '128 GB',
            capacitySize: 128,
            capacityUnit: '128 GB',
            isDevicePaymentEligible: true,
            isInstorePickup: true,
            isSameDayDelivery: true,
            isHumDevice: false,
            isSmartLocator: false,
            simSku: 'UNIVESIM5G-SA-D',
            edgeDeviceCap: '1010',
            productIdMap: {
              prepayProduct: 'dev20000221',
              postPayProduct: 'dev19920005',
            },
            skuRestricted: false,
            skuFilters: {
              deviceFilterType: 'Smartphones',
              restrictedAccySku: 'false',
            },
            isPreconfigureEnabled: false,
            itemSaleFlag: true,
            isPromoEligible: false,
          },
          {
            color: {
              colorCssStyle: '#C0C0C0',
              colorId: 'clr40012',
              description: 'Silver',
              displayName: 'Silver',
            },
            price: {
              devicePaymentPrice: [
                {
                  originalPrice: 30.55,
                  contractDuration: 36,
                  contractText:
                    'Monthly payments shown are for customers who qualify to pay $0 Down, $30.55/mo. for 36 months; 0% APR. Retail Price: $1099.99',
                  dpTermPrices: {
                    downPayment: 0,
                    downPaymentRequired: false,
                    upgradeOptionPercentage: 50,
                    upgradeOptionCode: 'UO',
                    dpTerm: 36,
                    ugradeEligibilityCategory: [],
                    firstMonthPrice: 30.74,
                    remainingMonthPrice: 30.55,
                  },
                },
              ],
              fullRetailPrice: {
                originalPrice: 1099.99,
                contractText: 'Full Retail Price',
              },
              preferredTerm: 36,
            },
            comingSoonFlag: false,
            imageUrlMap: {
              defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a',
              largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-lg$',
              mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-med$',
              miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-mini$',
              thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-thumb$',
              imageSetUrl:
                'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
            },
            inventoryDetails: {
              dFillInventory: {
                isAvailable: false,
                isBackorder: false,
                isDeliverBy: false,
                isPreOrder: false,
                isShipBy: false,
                isInStock: true,
                locationCode: '9999999',
                qtyAvailable: 50626,
              },
            },
            isBillToAccount: false,
            isRestrictionEnabled: true,
            prodCode1: '5GD',
            prodCode2: 'SMT',
            prodCode3: 'DIG',
            prodCode4: 'VDS',
            prodCode5: 'ISL',
            skuDisplayName: 'iPhone 14 Pro 256GB in Silver',
            skuId: 'sku5600278',
            sorId: 'MQ0X3LL/A',
            customerAttributes: {
              establishedDate: '01/15/2020',
              customerType: 'PE',
              digitalCustomerType: 'B2C',
              firstName: 'DAN',
              lastName: 'JETER',
              zipCode: '31023',
              zipCodePlus4: '3512',
              inWithVerizonInd: 'N',
              state: 'GA',
              hashedMdn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
              hashedAccountNumber: 'cccff0728bd1a30e896d15347b8ead72f887ea845508d33c3d7ce1a3735b9e95',
              mtnList: ['4782303946'],
              lineDetails: [
                {
                  mtn: '4782303946',
                  hashedMtn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
                  existingFWA: false,
                },
              ],
            },
            capacity: '256 GB',
            capacitySize: 256,
            capacityUnit: '256 GB',
            isDevicePaymentEligible: true,
            isInstorePickup: true,
            isSameDayDelivery: true,
            isHumDevice: false,
            isSmartLocator: false,
            simSku: 'UNIVESIM5G-SA-D',
            edgeDeviceCap: '1110',
            productIdMap: {
              prepayProduct: 'dev20000221',
              postPayProduct: 'dev19920005',
            },
            skuRestricted: false,
            skuFilters: {
              deviceFilterType: 'Smartphones',
              restrictedAccySku: 'false',
            },
            isPreconfigureEnabled: false,
            itemSaleFlag: false,
            isPromoEligible: false,
          },
          {
            color: {
              colorCssStyle: '#1E1D1B',
              colorId: 'clr12240018',
              description: 'Black',
              displayName: 'Space Black',
            },
            price: {
              devicePaymentPrice: [
                {
                  originalPrice: 27.77,
                  contractDuration: 36,
                  contractText:
                    'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
                  dpTermPrices: {
                    downPayment: 0,
                    downPaymentRequired: false,
                    upgradeOptionPercentage: 50,
                    upgradeOptionCode: 'UO',
                    dpTerm: 36,
                    ugradeEligibilityCategory: [],
                    firstMonthPrice: 28.04,
                    remainingMonthPrice: 27.77,
                  },
                },
              ],
              fullRetailPrice: {
                originalPrice: 999.99,
                contractText: 'Full Retail Price',
              },
              preferredTerm: 36,
            },
            comingSoonFlag: false,
            imageUrlMap: {
              defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
              largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
              mediumImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
              miniImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
              thumbImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
              imageSetUrl:
                'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
            },
            inventoryDetails: {
              dFillInventory: {
                isAvailable: false,
                isBackorder: false,
                isDeliverBy: false,
                isPreOrder: false,
                isShipBy: false,
                isInStock: true,
                locationCode: '9999999',
                qtyAvailable: 60645,
              },
            },
            isBillToAccount: false,
            isRestrictionEnabled: true,
            prodCode1: '5GD',
            prodCode2: 'SMT',
            prodCode3: 'DIG',
            prodCode4: 'VDS',
            prodCode5: 'ISL',
            skuDisplayName: 'iPhone 14 Pro 128GB in Space Black',
            skuId: 'sku5600273',
            sorId: 'MPXT3LL/A',
            customerAttributes: {
              establishedDate: '01/15/2020',
              customerType: 'PE',
              digitalCustomerType: 'B2C',
              firstName: 'DAN',
              lastName: 'JETER',
              zipCode: '31023',
              zipCodePlus4: '3512',
              inWithVerizonInd: 'N',
              state: 'GA',
              hashedMdn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
              hashedAccountNumber: 'cccff0728bd1a30e896d15347b8ead72f887ea845508d33c3d7ce1a3735b9e95',
              mtnList: ['4782303946'],
              lineDetails: [
                {
                  mtn: '4782303946',
                  hashedMtn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
                  existingFWA: false,
                },
              ],
            },
            capacity: '128 GB',
            capacitySize: 128,
            capacityUnit: '128 GB',
            isDevicePaymentEligible: true,
            isInstorePickup: true,
            isSameDayDelivery: true,
            isHumDevice: false,
            isSmartLocator: false,
            simSku: 'UNIVESIM5G-SA-D',
            edgeDeviceCap: '1010',
            productIdMap: {
              prepayProduct: 'dev20000221',
              postPayProduct: 'dev19920005',
            },
            skuRestricted: false,
            skuFilters: {
              deviceFilterType: 'Smartphones',
              restrictedAccySku: 'false',
            },
            isPreconfigureEnabled: false,
            itemSaleFlag: true,
            isPromoEligible: false,
          },
          {
            color: {
              colorCssStyle: '#D0C2AE',
              colorId: 'clr3360032',
              description: 'Gold',
              displayName: 'Gold',
            },
            price: {
              devicePaymentPrice: [
                {
                  originalPrice: 41.66,
                  contractDuration: 36,
                  contractText:
                    'Monthly payments shown are for customers who qualify to pay $0 Down, $41.66/mo. for 36 months; 0% APR. Retail Price: $1499.99',
                  dpTermPrices: {
                    downPayment: 0,
                    downPaymentRequired: false,
                    upgradeOptionPercentage: 50,
                    upgradeOptionCode: 'UO',
                    dpTerm: 36,
                    ugradeEligibilityCategory: [],
                    firstMonthPrice: 41.89,
                    remainingMonthPrice: 41.66,
                  },
                },
              ],
              fullRetailPrice: {
                originalPrice: 1499.99,
                contractText: 'Full Retail Price',
              },
              preferredTerm: 36,
            },
            comingSoonFlag: false,
            imageUrlMap: {
              defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a',
              largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-lg$',
              mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-med$',
              miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-mini$',
              thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-thumb$',
              imageSetUrl:
                'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
            },
            inventoryDetails: {
              dFillInventory: {
                isAvailable: false,
                isBackorder: false,
                isDeliverBy: false,
                isPreOrder: false,
                isShipBy: false,
                isInStock: true,
                locationCode: '9999999',
                qtyAvailable: 52340,
              },
            },
            isBillToAccount: false,
            isRestrictionEnabled: true,
            prodCode1: '5GD',
            prodCode2: 'SMT',
            prodCode3: 'DIG',
            prodCode4: 'VDS',
            prodCode5: 'ISL',
            skuDisplayName: 'iPhone 14 Pro 1TB in Gold',
            skuId: 'sku5600285',
            sorId: 'MQ2T3LL/A',
            customerAttributes: {
              establishedDate: '01/15/2020',
              customerType: 'PE',
              digitalCustomerType: 'B2C',
              firstName: 'DAN',
              lastName: 'JETER',
              zipCode: '31023',
              zipCodePlus4: '3512',
              inWithVerizonInd: 'N',
              state: 'GA',
              hashedMdn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
              hashedAccountNumber: 'cccff0728bd1a30e896d15347b8ead72f887ea845508d33c3d7ce1a3735b9e95',
              mtnList: ['4782303946'],
              lineDetails: [
                {
                  mtn: '4782303946',
                  hashedMtn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
                  existingFWA: false,
                },
              ],
            },
            capacity: '1 TB',
            capacitySize: 1,
            capacityUnit: '1 TB',
            isDevicePaymentEligible: true,
            isInstorePickup: true,
            isSameDayDelivery: true,
            isHumDevice: false,
            isSmartLocator: false,
            simSku: 'UNIVESIM5G-SA-D',
            edgeDeviceCap: '1510',
            productIdMap: {
              prepayProduct: 'dev20000221',
              postPayProduct: 'dev19920005',
            },
            skuRestricted: false,
            skuFilters: {
              deviceFilterType: 'Smartphones',
              restrictedAccySku: 'false',
            },
            isPreconfigureEnabled: false,
            itemSaleFlag: false,
            isPromoEligible: false,
          },
          {
            color: {
              colorCssStyle: '#1E1D1B',
              colorId: 'clr12240018',
              description: 'Black',
              displayName: 'Space Black',
            },
            price: {
              devicePaymentPrice: [
                {
                  originalPrice: 36.11,
                  contractDuration: 36,
                  contractText:
                    'Monthly payments shown are for customers who qualify to pay $0 Down, $36.11/mo. for 36 months; 0% APR. Retail Price: $1299.99',
                  dpTermPrices: {
                    downPayment: 0,
                    downPaymentRequired: false,
                    upgradeOptionPercentage: 50,
                    upgradeOptionCode: 'UO',
                    dpTerm: 36,
                    ugradeEligibilityCategory: [],
                    firstMonthPrice: 36.14,
                    remainingMonthPrice: 36.11,
                  },
                },
              ],
              fullRetailPrice: {
                originalPrice: 1299.99,
                contractText: 'Full Retail Price',
              },
              preferredTerm: 36,
            },
            comingSoonFlag: false,
            imageUrlMap: {
              defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
              largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
              mediumImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
              miniImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
              thumbImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
              imageSetUrl:
                'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
            },
            inventoryDetails: {
              dFillInventory: {
                isAvailable: false,
                isBackorder: false,
                isDeliverBy: false,
                isPreOrder: false,
                isShipBy: false,
                isInStock: true,
                locationCode: '9999999',
                qtyAvailable: 47152,
              },
            },
            isBillToAccount: false,
            isRestrictionEnabled: true,
            prodCode1: '5GD',
            prodCode2: 'SMT',
            prodCode3: 'DIG',
            prodCode4: 'VDS',
            prodCode5: 'ISL',
            skuDisplayName: 'iPhone 14 Pro 512GB in Space Black',
            skuId: 'sku5600180',
            sorId: 'MQ1K3LL/A',
            customerAttributes: {
              establishedDate: '01/15/2020',
              customerType: 'PE',
              digitalCustomerType: 'B2C',
              firstName: 'DAN',
              lastName: 'JETER',
              zipCode: '31023',
              zipCodePlus4: '3512',
              inWithVerizonInd: 'N',
              state: 'GA',
              hashedMdn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
              hashedAccountNumber: 'cccff0728bd1a30e896d15347b8ead72f887ea845508d33c3d7ce1a3735b9e95',
              mtnList: ['4782303946'],
              lineDetails: [
                {
                  mtn: '4782303946',
                  hashedMtn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
                  existingFWA: false,
                },
              ],
            },
            capacity: '512 GB',
            capacitySize: 512,
            capacityUnit: '512 GB',
            isDevicePaymentEligible: true,
            isInstorePickup: true,
            isSameDayDelivery: true,
            isHumDevice: false,
            isSmartLocator: false,
            simSku: 'UNIVESIM5G-SA-D',
            edgeDeviceCap: '1310',
            productIdMap: {
              prepayProduct: 'dev20000221',
              postPayProduct: 'dev19920005',
            },
            skuRestricted: false,
            skuFilters: {
              deviceFilterType: 'Smartphones',
              restrictedAccySku: 'false',
            },
            isPreconfigureEnabled: false,
            itemSaleFlag: false,
            isPromoEligible: false,
          },
          {
            color: {
              colorCssStyle: '#C0C0C0',
              colorId: 'clr40012',
              description: 'Silver',
              displayName: 'Silver',
            },
            price: {
              devicePaymentPrice: [
                {
                  originalPrice: 36.11,
                  contractDuration: 36,
                  contractText:
                    'Monthly payments shown are for customers who qualify to pay $0 Down, $36.11/mo. for 36 months; 0% APR. Retail Price: $1299.99',
                  dpTermPrices: {
                    downPayment: 0,
                    downPaymentRequired: false,
                    upgradeOptionPercentage: 50,
                    upgradeOptionCode: 'UO',
                    dpTerm: 36,
                    ugradeEligibilityCategory: [],
                    firstMonthPrice: 36.14,
                    remainingMonthPrice: 36.11,
                  },
                },
              ],
              fullRetailPrice: {
                originalPrice: 1299.99,
                contractText: 'Full Retail Price',
              },
              preferredTerm: 36,
            },
            comingSoonFlag: false,
            imageUrlMap: {
              defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a',
              largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-lg$',
              mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-med$',
              miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-mini$',
              thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-thumb$',
              imageSetUrl:
                'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
            },
            inventoryDetails: {
              dFillInventory: {
                isAvailable: false,
                isBackorder: false,
                isDeliverBy: false,
                isPreOrder: false,
                isShipBy: false,
                isInStock: true,
                locationCode: '9999999',
                qtyAvailable: 59560,
              },
            },
            isBillToAccount: false,
            isRestrictionEnabled: true,
            prodCode1: '5GD',
            prodCode2: 'SMT',
            prodCode3: 'DIG',
            prodCode4: 'VDS',
            prodCode5: 'ISL',
            skuDisplayName: 'iPhone 14 Pro 512GB in Silver',
            skuId: 'sku5600281',
            sorId: 'MQ1U3LL/A',
            customerAttributes: {
              establishedDate: '01/15/2020',
              customerType: 'PE',
              digitalCustomerType: 'B2C',
              firstName: 'DAN',
              lastName: 'JETER',
              zipCode: '31023',
              zipCodePlus4: '3512',
              inWithVerizonInd: 'N',
              state: 'GA',
              hashedMdn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
              hashedAccountNumber: 'cccff0728bd1a30e896d15347b8ead72f887ea845508d33c3d7ce1a3735b9e95',
              mtnList: ['4782303946'],
              lineDetails: [
                {
                  mtn: '4782303946',
                  hashedMtn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
                  existingFWA: false,
                },
              ],
            },
            capacity: '512 GB',
            capacitySize: 512,
            capacityUnit: '512 GB',
            isDevicePaymentEligible: true,
            isInstorePickup: true,
            isSameDayDelivery: true,
            isHumDevice: false,
            isSmartLocator: false,
            simSku: 'UNIVESIM5G-SA-D',
            edgeDeviceCap: '1310',
            productIdMap: {
              prepayProduct: 'dev20000221',
              postPayProduct: 'dev19920005',
            },
            skuRestricted: false,
            skuFilters: {
              deviceFilterType: 'Smartphones',
              restrictedAccySku: 'false',
            },
            isPreconfigureEnabled: false,
            itemSaleFlag: false,
            isPromoEligible: false,
          },
          {
            color: {
              colorCssStyle: '#C0C0C0',
              colorId: 'clr40012',
              description: 'Silver',
              displayName: 'Silver',
            },
            price: {
              devicePaymentPrice: [
                {
                  originalPrice: 27.77,
                  contractDuration: 36,
                  contractText:
                    'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
                  dpTermPrices: {
                    downPayment: 0,
                    downPaymentRequired: false,
                    upgradeOptionPercentage: 50,
                    upgradeOptionCode: 'UO',
                    dpTerm: 36,
                    ugradeEligibilityCategory: [],
                    firstMonthPrice: 28.04,
                    remainingMonthPrice: 27.77,
                  },
                },
              ],
              fullRetailPrice: {
                originalPrice: 999.99,
                contractText: 'Full Retail Price',
              },
              preferredTerm: 36,
            },
            comingSoonFlag: false,
            imageUrlMap: {
              defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a',
              largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-lg$',
              mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-med$',
              miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-mini$',
              thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-thumb$',
              imageSetUrl:
                'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
            },
            inventoryDetails: {
              dFillInventory: {
                isAvailable: false,
                isBackorder: false,
                isDeliverBy: false,
                isPreOrder: false,
                isShipBy: false,
                isInStock: true,
                locationCode: '9999999',
                qtyAvailable: 50546,
              },
            },
            isBillToAccount: false,
            isRestrictionEnabled: true,
            prodCode1: '5GD',
            prodCode2: 'SMT',
            prodCode3: 'DIG',
            prodCode4: 'VDS',
            prodCode5: 'ISL',
            skuDisplayName: 'iPhone 14 Pro 128GB in Silver',
            skuId: 'sku5600274',
            sorId: 'MQ003LL/A',
            customerAttributes: {
              establishedDate: '01/15/2020',
              customerType: 'PE',
              digitalCustomerType: 'B2C',
              firstName: 'DAN',
              lastName: 'JETER',
              zipCode: '31023',
              zipCodePlus4: '3512',
              inWithVerizonInd: 'N',
              state: 'GA',
              hashedMdn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
              hashedAccountNumber: 'cccff0728bd1a30e896d15347b8ead72f887ea845508d33c3d7ce1a3735b9e95',
              mtnList: ['4782303946'],
              lineDetails: [
                {
                  mtn: '4782303946',
                  hashedMtn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
                  existingFWA: false,
                },
              ],
            },
            capacity: '128 GB',
            capacitySize: 128,
            capacityUnit: '128 GB',
            isDevicePaymentEligible: true,
            isInstorePickup: true,
            isSameDayDelivery: true,
            isHumDevice: false,
            isSmartLocator: false,
            simSku: 'UNIVESIM5G-SA-D',
            edgeDeviceCap: '1010',
            productIdMap: {
              prepayProduct: 'dev20000221',
              postPayProduct: 'dev19920005',
            },
            skuRestricted: false,
            skuFilters: {
              deviceFilterType: 'Smartphones',
              restrictedAccySku: 'false',
            },
            isPreconfigureEnabled: false,
            itemSaleFlag: false,
            isPromoEligible: false,
          },
          {
            color: {
              colorCssStyle: '#1E1D1B',
              colorId: 'clr12240018',
              description: 'Black',
              displayName: 'Space Black',
            },
            price: {
              devicePaymentPrice: [
                {
                  originalPrice: 41.66,
                  contractDuration: 36,
                  contractText:
                    'Monthly payments shown are for customers who qualify to pay $0 Down, $41.66/mo. for 36 months; 0% APR. Retail Price: $1499.99',
                  dpTermPrices: {
                    downPayment: 0,
                    downPaymentRequired: false,
                    upgradeOptionPercentage: 50,
                    upgradeOptionCode: 'UO',
                    dpTerm: 36,
                    ugradeEligibilityCategory: [],
                    firstMonthPrice: 41.89,
                    remainingMonthPrice: 41.66,
                  },
                },
              ],
              fullRetailPrice: {
                originalPrice: 1499.99,
                contractText: 'Full Retail Price',
              },
              preferredTerm: 36,
            },
            comingSoonFlag: false,
            imageUrlMap: {
              defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
              largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
              mediumImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
              miniImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
              thumbImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
              imageSetUrl:
                'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
            },
            inventoryDetails: {
              dFillInventory: {
                isAvailable: false,
                isBackorder: false,
                isDeliverBy: false,
                isPreOrder: false,
                isShipBy: false,
                isInStock: true,
                locationCode: '9999999',
                qtyAvailable: 49371,
              },
            },
            isBillToAccount: false,
            isRestrictionEnabled: true,
            prodCode1: '5GD',
            prodCode2: 'SMT',
            prodCode3: 'DIG',
            prodCode4: 'VDS',
            prodCode5: 'ISL',
            skuDisplayName: 'iPhone 14 Pro 1TB in Space Black',
            skuId: 'sku5600283',
            sorId: 'MQ2E3LL/A',
            customerAttributes: {
              establishedDate: '01/15/2020',
              customerType: 'PE',
              digitalCustomerType: 'B2C',
              firstName: 'DAN',
              lastName: 'JETER',
              zipCode: '31023',
              zipCodePlus4: '3512',
              inWithVerizonInd: 'N',
              state: 'GA',
              hashedMdn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
              hashedAccountNumber: 'cccff0728bd1a30e896d15347b8ead72f887ea845508d33c3d7ce1a3735b9e95',
              mtnList: ['4782303946'],
              lineDetails: [
                {
                  mtn: '4782303946',
                  hashedMtn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
                  existingFWA: false,
                },
              ],
            },
            capacity: '1 TB',
            capacitySize: 1,
            capacityUnit: '1 TB',
            isDevicePaymentEligible: true,
            isInstorePickup: true,
            isSameDayDelivery: true,
            isHumDevice: false,
            isSmartLocator: false,
            simSku: 'UNIVESIM5G-SA-D',
            edgeDeviceCap: '1510',
            productIdMap: {
              prepayProduct: 'dev20000221',
              postPayProduct: 'dev19920005',
            },
            skuRestricted: false,
            skuFilters: {
              deviceFilterType: 'Smartphones',
              restrictedAccySku: 'false',
            },
            isPreconfigureEnabled: false,
            itemSaleFlag: false,
            isPromoEligible: false,
          },
        ],
        compatibleSimSorIds: ['UNIVESIM5G-SA-S', 'UNIVESIM5G-SA-A', 'UNIVESIM5G-SA-D'],
        deviceUnlockPolicy: {
          textId: '11500001',
          textName: 'DEVICE_UNLOCK_POLICY',
          description: null,
          text: '<p><strong>Device Unlocking Policies</strong></p>\r\r<p>In order to mitigate theft and other fraudulent activity, newly purchased devices are\r"u201Clockedu201D" to work exclusively on the Verizon network. We have separate device\runlocking policies that cover postpay and prepaid devices, as well as special rules for\rdeployed military personnel.</p>\r \r\r\r<p>"u201CUnlockingu201D" a device refers only to disabling software that would prevent a consumer\rfrom attempting to activate a device designed for one carrieru2019s network. Due to differing technologies, an unlocked Verizon Wireless device\rmay not work u2013 or may experience limited functionality u2013 on another carrieru2019s network.</p>\r\r \r\r<p><strong>Postpay Device Unlocking Policy</strong></p>\r\r\r\r<p>Devices that you purchase from Verizon are locked for 60 days after purchase. Devices that you purchase from our retail partners are locked for 60 days after activation.After 60 days, we will automatically remove the lock. Following the 60 day lock period, we do not lock our phones at any time.</p>\r\r\r\r\r<p><strong>Prepaid Device Unlocking Policy</strong></p>\r\r\r<p>Devices that you purchase from Verizon and certain devices purchased from our retail partners are locked for 60 days after activation. After 60 days, we will automatically remove the lock. Following the 60 day lock period following device purchase, we do not lock our phones at any time.</p>\r\r<p>If you purchase a 4G Phone&ndash;in&ndash;a&ndash;Box from our retail partners, you should review the back of the box to determine the lock period applicable to that device.</p>\r\r<p><strong>Unlocking Policy for Deployed Military Personnel</strong></p>\r\r<p>If you are a Verizon Wireless customer in the military and receive relocation orders outside of the Verizon Coverage Area, we will unlock your device at your request, even during the 60&ndash;day&ndash;lock period following the purchase of your device.</p>\r\r<p>Effective Date: July 23, 2019</p>',
          applicationFlag: true,
          url: null,
          urlAvailableFlag: false,
          newBrowserFlag: null,
          textType: 'GlobalText',
          displayB2cFlag: true,
          sequenceOrder: null,
          textVersion: null,
          wmsLabel: null,
          currentVersion: 1,
        },
        daccId: '01794',
        deviceType: 300202,
        hasDeviceUnlockPolicy: true,
        includedAccessories:
          '<ul class="features">\r<li>iPhone with iOS 16</li>\r<li>USB-C to Lightning Cable</li>\r<li>Documentation</li>\r</ul>',
        isAnySkuInStock: false,
        isAllSkusOutofStock: false,
        isCPO: false,
        isE911Address: false,
        isNumberShareCapable: false,
        isNumberShareMandatory: false,
        isSupportOnly: false,
        operatingSystem: 'Apple iOS',
        startDate: {
          date: '09-09-2022',
          dateTime: '09-09-2022 07:58:00 AM',
          dateLong: 1662724680000,
        },
        sorDeviceCategory: '5G Smartphone',
        specifications: {
          battery: null,
          depth: 0.31,
          height: 5.81,
          screenSize: '6.1"',
          size: '5.81,2.81,0.31',
          weight: 7.27,
          width: 2.81,
        },
        techSpecs: {
          'Video Playback': 'Up to 23 hrs.',
          Overall: 'Accessibility Shortcut, Siri, Guided Access, Per App Setting',
          'Wi-Fi': 'Yes',
          Screen:
            'Super Retina XDR display; 6.1-inch (diagonal) all-screen OLED display; 2556-by-1179-pixel resolution at 460 ppi',
          '5G Ultra Wideband': 'n260/ n261 (high-band / mmWave) | n77 (mid-band / C-band)',
          'Hearing Aid Compatibility': 'M3/T4',
          Depth: '0.31 in.',
          Weight: '7.27 oz.',
          Type: 'Built-in rechargeable lithium-ion battery',
          '4G': '13, 4, 2, 5, 66, 46, 48',
          Colors: 'Space Black, Silver, Gold, Deep Purple',
          Storage: '128GB, 256GB, 512GB, 1TB (Subject to availability)',
          Auditory: 'Made for iPhone hearing devices, Sound Recognition, Headphone Accommodations, Live Captions',
          'Usage Time': 'Streamed: Up to 20 hrs; Audio playback: Up to 75 hrs.',
          'Rear Camera':
            'Main: 24 mm, ƒ/1.78 aperture, second-generation sensor-shift optical image stabilization, seven-element lens, 100% Focus Pixels',
          'Mobility/Cognitive': 'Voice Control, Switch Control, AssistiveTouch, Back Tap',
          'FCC ID': 'BCG-E4000A',
          'Global & Roaming Network':
            'LTE Roaming 1, 3, 7, 20, 28, 12, 26 | GSM/UMTS 850, 900, 1700/2100, 1900, 2100 MHz) | GSM/EDGE (850, 900, 1800, 1900 Mhz)',
          '5G Nationwide': 'n2/n5/n48/n66',
          Height: '5.81 in.',
          'Operating System': 'Apple iOS',
          camera: '48MP ',
          Width: '2.81 in.',
          Visual: 'VoiceOver, Zoom, Color Filters, Spoken Content',
        },
        categoryDisplayNames: ['GnG Devices', 'Smartphones', 'Postpaid Devices'],
        shortDescription:
          'iPhone 14 Pro. Capture incredible detail with a 48MP Main camera. Experience iPhone in a whole new way with Dynamic Island and Always-On display. And get peace ',
        isIconicPhone: true,
        unlockDevicePDP: false,
        emergencyCLNR: true,
        cannotBeUpgraded: false,
        hostDeviceInCompatible: false,
        sorDeviceType: '5GE',
        ccod: null,
        favoriteId: null,
        inFavorite: false,
        wishListCount: 0,
        imageName: 'iphone-14-pro-deep-purple-fall22-a',
        imageUrlMap: {
          defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a',
          largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-lg$',
          mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-med$',
          miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-mini$',
          thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-thumb$',
          imageSetUrl:
            'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
        },
        deviceRestricted: false,
        skuRestrictions: {
          restrictionMessages: [],
          isAllSkusRestricted: false,
        },
        productSpecification: null,
        notSellableSkus: [
          'RTAPL14P128BK',
          '3L242LL/A',
          '3L260LL/A',
          '3L254LL/A',
          '3L248LL/A',
          'IQMPXT3LL/A',
          'CLNRAPL14P1TBDP',
          'CLNRAPL14P256DP',
          'CLNRAPL14P512DPZ',
          'CLNRAPL14P128SLZ',
          'CLNRAPL14P128GDZ',
          'CLNRAPL14P128DP',
          'CLNRAPL14P512GD',
          'CLNRAPL14P128GD',
          'CLNRAPL14P1TBGD',
          'CLNRAPL14P1TBGDZ',
          'CLNRAPL14P256GD',
          'CLNRAPL14P512DP',
          'CLNRAPL14P512SL',
          'CLNRAPL14P256DPZ',
          'CLNRAPL14P512SBZ',
          'CLNRAPL14P512SB',
          'CLNRAPL14P256SL',
          'CLNRAPL14P256SBZ',
          'CLNRAPL14P128SL',
          'CLNRAPL14P256SB',
          'CLNRAPL14P128SB',
          'CLNRAPL14P1TBSL',
          'CLNRAPL14P1TBSB',
          'OCPO1AAPL14P1TBSB',
          'OCPO1AAPL14P256SL',
          'OCPO1BAPL14P512GD',
          'OCPO1AAPL14P512DP',
          'OCPO1AAPL14P256SB',
          'OCPO1CAPL14P1TBGD',
          'OCPO1CAPL14P256GD',
          'OCPO1BAPL14P256GD',
          'OCPO1BAPL14P128DP',
          'OCPO1AAPL14P128DP',
          'OCPO1AAPL14P1TBSL',
          'OCPO1BAPL14P1TBGD',
          'OCPO1CAPL14P128SL',
          'OCPO1CAPL14P128SB',
          'OCPO1BAPL14P128SL',
          'OCPO1AAPL14P512GD',
          'OCPO1BAPL14P128SB',
          'OCPO1AAPL14P128SL',
          'OCPO1CAPL14P512GD',
          'OCPO1AAPL14P128SB',
          'OCPO1CAPL14P128DP',
          'OCPO1BAPL14P512SB',
          'OCPO1AAPL14P256GD',
          'OCPO1AAPL14P128GD',
          'OCPO1BAPL14P512SL',
          'OCPO1CAPL14P1TBSL',
          'OCPO1BAPL14P256SB',
          'OCPO1CAPL14P1TBSB',
          'OCPO1CAPL14P256SL',
          'OCPO1CAPL14P512DP',
          'OCPO1CAPL14P256SB',
          'OCPO1AAPL14P1TBGD',
          'OCPO1BAPL14P256SL',
          'OCPO1BAPL14P1TBSB',
          'OCPO1AAPL14P1TBDP',
          'OCPO1BAPL14P1TBSL',
          'OCPO1AAPL14P512SB',
          'OCPO1CAPL14P128GD',
          'OCPO1AAPL14P256DP',
          'OCPO1BAPL14P512DP',
          'OCPO1BAPL14P128GD',
          'OCPO1AAPL14P512SL',
          'OCPO1BAPL14P256DP',
          'OCPO1CAPL14P1TBDP',
          'OCPO1CAPL14P256DP',
          'OCPO1CAPL14P512SB',
          'OCPO1BAPL14P1TBDP',
          'OCPO1CAPL14P512SL',
        ],
        modPdp: false,
        defaultSKUObj: {
          color: {
            colorCssStyle: '#655D6C',
            colorId: 'clr12200029',
            description: 'Purple',
            displayName: 'Deep Purple',
          },
          price: {
            devicePaymentPrice: [
              {
                originalPrice: 27.77,
                contractDuration: 36,
                contractText:
                  'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
                dpTermPrices: {
                  downPayment: 0,
                  downPaymentRequired: false,
                  upgradeOptionPercentage: 100,
                  upgradeOptionCode: 'DP',
                  dpTerm: 36,
                  ugradeEligibilityCategory: [],
                  firstMonthPrice: 28.04,
                  remainingMonthPrice: 27.77,
                },
              },
            ],
            fullRetailPrice: {
              originalPrice: 999.99,
              contractText: 'Full Retail Price',
            },
            preferredTerm: 36,
          },
          comingSoonFlag: false,
          imageUrlMap: {
            defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a',
            largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-lg$',
            mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-med$',
            miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-mini$',
            thumbImage:
              'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-thumb$',
            imageSetUrl:
              'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
          },
          inventoryDetails: {
            dFillInventory: {
              isAvailable: false,
              isBackorder: false,
              isDeliverBy: false,
              isPreOrder: false,
              isShipBy: false,
              isInStock: true,
              locationCode: '9999999',
              qtyAvailable: 120569,
            },
            localInventory: {
              isAvailable: false,
              isBackorder: false,
              isDeliverBy: false,
              isPreOrder: false,
              isShipBy: false,
              isInStock: true,
              locationCode: '2777301',
              qtyAvailable: 62,
            },
          },
          isBillToAccount: false,
          isRestrictionEnabled: true,
          prodCode1: '5GD',
          prodCode2: 'SMT',
          prodCode3: 'DIG',
          prodCode4: 'VDS',
          prodCode5: 'ISL',
          skuDisplayName: 'iPhone 14 Pro 128GB in Deep Purple',
          skuId: 'sku5600276',
          sorId: 'MQ0E3LL/A',
          customerAttributes: {
            establishedDate: '01/15/2020',
            customerType: 'PE',
            digitalCustomerType: 'B2C',
            firstName: 'DAN',
            lastName: 'JETER',
            zipCode: '31023',
            zipCodePlus4: '3512',
            inWithVerizonInd: 'N',
            state: 'GA',
            hashedMdn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
            hashedAccountNumber: 'cccff0728bd1a30e896d15347b8ead72f887ea845508d33c3d7ce1a3735b9e95',
            mtnList: ['4782303946'],
            lineDetails: [
              {
                mtn: '4782303946',
                hashedMtn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
                existingFWA: false,
              },
            ],
          },
          capacity: '128 GB',
          capacitySize: 128,
          capacityUnit: '128 GB',
          isDevicePaymentEligible: true,
          isInstorePickup: true,
          isSameDayDelivery: true,
          isHumDevice: false,
          isSmartLocator: false,
          simSku: 'UNIVESIM5G-SA-D',
          edgeDeviceCap: '1010',
          productIdMap: {
            prepayProduct: 'dev20000221',
            postPayProduct: 'dev19920005',
          },
          skuRestricted: false,
          skuFilters: {
            deviceFilterType: 'Smartphones',
            restrictedAccySku: 'false',
          },
          isPreconfigureEnabled: false,
          itemSaleFlag: true,
          isPromoEligible: false,
        },
      },
      commonInfo: {
        showPrice: true,
        displayReasonCode: true,
        showShipitToggle: true,
        flexPDPTradeInLinkEnabled: true,
        containSoftSku: false,
        dpEligible: true,
        indirect: false,
      },
      accountInfo: {
        lastName: 'JETER',
        zipCode: '31023',
        myOfferAccepted: null,
        nickName: null,
        safeTechSessionId: '38235e4ed6f642bb9d1ba29a',
        processingMTN: null,
        accountEupDeviceType: null,
        zipCodePlus4: '3512',
        selectedOfferFlows: null,
        estTradeInValue: null,
        firstName: 'DAN',
        intentType: null,
        preOrderMTNEnable: 'false',
        custType: 'B2C',
        btaEligible: 'false',
        state: 'GA',
      },
      fiveGMobilityInfo: {
        fiveGToFourGOverlay: false,
        fiveGHomeRequired: false,
        fiveGUpSell: false,
      },
      catDL: {
        pageName: 'iPhone 14 Pro',
      },
      getDeviceTradeStatus: {
        promoExists: false,
        bogoOffer: false,
      },
      showReturnTab: false,
    },
    computeDPPriceResult: {
      status: 'fulfilled',
      endpointName: 'computeDPPrices',
      requestId: 'lf2MRsFlucEKnButXAPgU',
      originalArgs: {
        body: {
          sorId: 'SMS911UZEV',
          mtn: '2164706958',
          term: 36,
          downPayment: 10,
          isPercentage: true,
          agentOrFullRetailPrice: 1029.99,
        },
        spinner: false,
      },
      startedTimeStamp: 1720705629368,
      data: {
        firstMonthPrice: 26.09,
        remainingMonthPrice: 25.74,
        dpTerm: 36,
        downPayment: 103,
        mtn: '2164706958',
      },
      fulfilledTimeStamp: 1720705629906,
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      currentData: {
        firstMonthPrice: 26.09,
        remainingMonthPrice: 25.74,
        dpTerm: 36,
        downPayment: 103,
        mtn: '2164706958',
      },
      isFetching: false,
    },
    details: {},
    protectionFeatures: {
      status: 'SUCCESS',
      payload: {
        mtn: '4782303946',
        throttleName: '||',
        features: [
          {
            displayName: 'Verizon Mobile Protect',
            sorId: '88689',
            description:
              "<p>Provides coverage for loss, theft, damage and post&#45;warranty defects.</p>\n\n<p><strong>Unlimited claims</strong><br />\nLive without limits. Get an unlimited number of claims.<sup>1</sup></p>\n\n<p><strong>No extra cost cracked screen repairs</strong><br />\nUnlimited and at no extra cost to you.<sup>2</sup></p>\n\n<p><strong>Same&#45;day delivery and setup</strong><br />\nFor replacement smartphones and new devices<sup>3</sup> purchased here. Enjoy seamless device and content set&#45;up</p>\n\n<p><strong>&#36;99 damage deductible</strong><br />\nThe most you'll pay to replace your damaged device is &#36;99.<sup>4</sup></p>\n\n<p><strong>Other benefits:</strong><br />\nFast battery replacement<sup>5</sup><br />\nData recovery, even if your smartphone is damaged<sup>6</sup><br />\n24/7 tech support plus digital security and privacy tools<sup>7</sup></p>",
            featureFamily: 'VZPROTECT',
            preSelect: true,
            showCaseFlag: true,
            coverageType: 'LINELEVEL',
            sellable: true,
            additionalFeature: false,
            appleCare: false,
            bundledInVzProtect: false,
            price: {
              regularPrice: '17.00',
              discountedPrice: '17.00',
            },
            deductible: '0.0',
            vzProtectEligibleDevices: [
              {
                mtn: '4782303946',
                displayName: 'Apple iPhone 14 Pro',
                imageUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a',
                customerName: 'DAN JETER',
                tmpEligible: false,
                callFilterEligible: true,
                safeWifiEligible: true,
                partialCallFilterFeaturesIncluded: false,
                digitalSecureOSDependent: false,
              },
            ],
            selectedInCart: false,
            onCustomerAccount: true,
            mutualExclusions: [79184, 81495, 85913, 66332, 88703],
            actionIndicator: 'Z',
            addedInCart: false,
            featureType: 'SFO',
            currentProtectionCompatible: true,
            restrictionEnabled: false,
            disclaimerEnabled: false,
            sddSetupEligible: true,
            hasProtectionExceeded10LineCap: false,
            includesCallFilter: false,
            includesDigitalSecure: false,
            includesTechCoach: true,
          },
          {
            displayName: 'Decline Device Protection',
            sorId: '66332',
            description:
              '<p>Replacing your lost, stolen or damaged device can be expensive. Plus, you’ll still need to pay any balance left on your device payment agreement.</p>',
            featureFamily: 'DECLINED_PROTECTION',
            preSelect: false,
            showCaseFlag: true,
            coverageType: 'LINELEVEL',
            sellable: true,
            additionalFeature: false,
            appleCare: false,
            bundledInVzProtect: false,
            price: {
              regularPrice: '0.00',
              discountedPrice: '0.00',
            },
            deductible: '0.0',
            selectedInCart: false,
            onCustomerAccount: false,
            mutualExclusions: [88689, 79184, 81495, 85913, 88703],
            actionIndicator: 'A',
            addedInCart: false,
            featureType: 'SFO',
            currentProtectionCompatible: true,
            restrictionEnabled: false,
            disclaimerEnabled: false,
            sddSetupEligible: false,
            hasProtectionExceeded10LineCap: false,
            includesCallFilter: false,
            includesDigitalSecure: false,
            includesTechCoach: false,
          },
          {
            displayName: 'Total Equipment Coverage',
            sorId: '81495',
            description:
              '<p><strong>No extra cost cracked screen repairs</strong><br />\nUnlimited and at no extra cost to you.<sup>2</sup></p>\n\n<p><strong>Next day delivery replacement</strong><br />\nFor lost, stolen or damaged devices</p>\n\n<p><strong>Battery replacement</strong><br />\nFast replacement at a Verizon&#45;authorized repair facility.<sup>5</sup><br />\nNot available in FL or for FL customers.</p>',
            featureFamily: 'TEC',
            preSelect: false,
            showCaseFlag: true,
            coverageType: 'LINELEVEL',
            sellable: true,
            additionalFeature: false,
            appleCare: false,
            bundledInVzProtect: false,
            price: {
              regularPrice: '11.40',
              discountedPrice: '11.40',
            },
            deductible: '0.0',
            selectedInCart: false,
            onCustomerAccount: false,
            mutualExclusions: [88689, 79184, 85913, 66332, 88703],
            actionIndicator: 'A',
            addedInCart: false,
            featureType: 'SFO',
            currentProtectionCompatible: true,
            restrictionEnabled: false,
            disclaimerEnabled: false,
            sddSetupEligible: false,
            hasProtectionExceeded10LineCap: false,
            includesCallFilter: false,
            includesDigitalSecure: false,
            includesTechCoach: false,
          },
          {
            displayName: 'Wireless Phone Protection',
            sorId: '85913',
            description:
              '<li>Next-day replacement for lost, stolen or damaged devices</li> <li>Enjoy no extra cost cracked screen repairs and unlimited claims<sup>2</sup></li>',
            featureFamily: 'WPP',
            preSelect: false,
            showCaseFlag: true,
            coverageType: 'LINELEVEL',
            sellable: true,
            additionalFeature: false,
            appleCare: false,
            bundledInVzProtect: false,
            price: {
              regularPrice: '7.25',
              discountedPrice: '7.25',
            },
            deductible: '0.0',
            selectedInCart: false,
            onCustomerAccount: false,
            mutualExclusions: [88689, 79184, 81495, 66332, 88703],
            actionIndicator: 'A',
            addedInCart: false,
            featureType: 'SFO',
            currentProtectionCompatible: true,
            restrictionEnabled: false,
            disclaimerEnabled: false,
            sddSetupEligible: false,
            hasProtectionExceeded10LineCap: false,
            includesCallFilter: false,
            includesDigitalSecure: false,
            includesTechCoach: false,
          },
          {
            displayName: 'Mobile Secure',
            sorId: '88703',
            description:
              '<p>Does not provide coverage for loss, theft, damage or post&#45;warranty malfunctions</p>\n\n<p><strong>Same&#45;day delivery and setup</strong><br />\nFor new devices<sup>3</sup> that are in stock and purchased here.</p> \n\n<p><strong>24/7 Security Advisor<sup>8</sup></strong><br />\nExperts optimize your digital security and privacy tools<sup>7</sup> and help resolve security vulnerabilities.</p>\n\n<p><strong>Other benefits:</strong><br />\n<strong>Download the included apps:</strong></p>\n\n<p><strong>Digital Secure</strong><br />\nDigital security and privacy tools<sup>7</sup> to protect your data, avoid risky websites and receive ID theft alerts.</p>\n\n<p><strong>Tech Coach</strong><br />\n24/7 Tech Coach<sup>9</sup> expert support is available to help optimize your device.</p>\n\n<p><strong>Call Filter</strong><br />\nAccess additional controls to screen and block robocalls.<sup>7</sup></p>',
            preSelect: false,
            showCaseFlag: true,
            coverageType: 'LINELEVEL',
            sellable: true,
            additionalFeature: false,
            appleCare: false,
            bundledInVzProtect: false,
            price: {
              regularPrice: '5.60',
              discountedPrice: '5.60',
            },
            deductible: '0.0',
            selectedInCart: false,
            onCustomerAccount: false,
            mutualExclusions: [88689, 79184, 81495, 85913, 66332],
            actionIndicator: 'A',
            addedInCart: false,
            featureType: 'SFO',
            currentProtectionCompatible: true,
            restrictionEnabled: false,
            disclaimerEnabled: false,
            sddSetupEligible: true,
            hasProtectionExceeded10LineCap: false,
            includesCallFilter: false,
            includesDigitalSecure: false,
            includesTechCoach: true,
          },
          {
            displayName: 'Extended Warranty',
            sorId: '79184',
            description:
              '<p><strong>Coverage for post&#45;warranty malfunctions</strong><br />\nIncluding electrical or mechanical malfunctions.</p>\n\n<p><strong>Battery replacement</strong><br />\nFast replacement at a Verizon&#45;authorized repair facility.<sup>5</sup></p>',
            featureFamily: 'EW',
            preSelect: false,
            showCaseFlag: true,
            coverageType: 'LINELEVEL',
            sellable: true,
            additionalFeature: false,
            appleCare: false,
            bundledInVzProtect: false,
            price: {
              regularPrice: '4.15',
              discountedPrice: '4.15',
            },
            deductible: '0.0',
            selectedInCart: false,
            onCustomerAccount: false,
            mutualExclusions: [88689, 81495, 85913, 66332, 88703],
            actionIndicator: 'A',
            addedInCart: false,
            featureType: 'SFO',
            currentProtectionCompatible: true,
            restrictionEnabled: false,
            disclaimerEnabled: false,
            sddSetupEligible: false,
            hasProtectionExceeded10LineCap: false,
            includesCallFilter: false,
            includesDigitalSecure: false,
            includesTechCoach: false,
          },
          {
            displayName: 'Call Filter Plus',
            sorId: '89370',
            description: '<p>Caller ID, real&#45;time spam alerts and blocking, custom call controls<sup>7</sup>.</p>',
            featureFamily: 'CALL_FILTER',
            preSelect: false,
            showCaseFlag: false,
            coverageType: 'LINELEVEL',
            sellable: false,
            additionalFeature: true,
            appleCare: false,
            bundledInVzProtect: true,
            price: {
              regularPrice: '3.99',
              discountedPrice: '3.99',
            },
            deductible: '0.0',
            selectedInCart: false,
            onCustomerAccount: false,
            actionIndicator: 'A',
            addedInCart: false,
            featureType: 'SFO',
            currentProtectionCompatible: true,
            restrictionEnabled: false,
            disclaimerEnabled: false,
            sddSetupEligible: false,
            hasProtectionExceeded10LineCap: false,
            includesCallFilter: false,
            includesDigitalSecure: false,
            includesTechCoach: false,
          },
        ],
        currentProtection: {
          compatible: true,
          displayName: 'Verizon Mobile Protect',
          featureFamily: 'VZPROTECT',
          coverageType: 'LINELEVEL',
          sorId: '88689',
          featureType: 'SFO',
          editable: false,
        },
        protectionSelectionRequired: false,
        vzProtectNotSupportedOnAllDevices: false,
        vzProtectNotSupportedOnCurrentDevice: false,
        vzProtectPartialFeaturesIncludedOnCurrentDevice: false,
        shippingDetails: {
          state: 'GA',
          region: 'GA',
        },
      },
    },
    cartDetails: {
      cart: {
        customerProfile: {
          billAccounts: [
            {
              mtns: [
                {
                  mtn: '4782303946',
                  equipmentUpgradeEligibility: {
                    upgradeEligibilityDate: '01/15/2022',
                    upgradeEligible: true,
                    twoYearContract: {},
                  },
                  mobileInfoAttributes: {
                    smartFamilyParent: false,
                  },
                  equipmentInfos: [
                    {
                      deviceInfo: {
                        modelName: 'Apple iPhone 11 64GB in Purple (2019)',
                        deviceId: '356552104459243',
                        deviceIdType: 'IME',
                        deviceSku: 'MWKR2LL/A',
                      },
                      simInfo: {
                        modelName: 'GTO MULTI-FORM-FACTOR SIM',
                        simId: '89148000005702817800',
                        simSku: 'EMBDSIMTRI',
                      },
                    },
                  ],
                  lineSharingIndicator: '',
                  pricePlanInfo: {
                    planId: '26872',
                    planAttributes: {
                      sharePlan: false,
                    },
                  },
                },
              ],
              fiosEligibilityCategory: '',
              accountAddress: {
                zipCode: '31023',
                zipCodePlus4: '3512',
                fipsCode: '1309100000',
                addressLine1: '674 BAY SPRINGS CHURCH RD',
                addressLine2: '',
                city: 'EASTMAN',
                state: 'GA',
                scrubbedAddress: {
                  streetName: 'BAY SPRINGS CHURCH',
                  streetNumber: '674',
                  streetType: 'RD',
                  streetDirection: '',
                  apartmentNo: '',
                  pobox: '',
                  ruralDeliveryNo: '',
                  ruralRouteNo: '',
                  city: 'EASTMAN',
                  state: 'GA',
                  zipCode: '31023',
                  zipCodePlus4: '3118',
                },
              },
              accountAttributes: {
                autopay: {
                  autoPayDiscount: '10.00',
                },
              },
            },
          ],
          customerAttributes: {
            taxExemptCode: 'N',
          },
        },
        cartHasOnlyAccessories: false,
        cartHeader: {
          winBackAccountNumber: '',
          vendorId: 'NETACE',
          repRole: '',
          locationType: 'S',
          sourceSystem: 'OMNI-RETAIL',
          cartId: '4a833813-e7c5-453c-8e94-a733ca79c36b',
          fullAccountNumber: '0325893599-1',
          status: 'A',
          createTimestamp: '2023-08-14T08:12:23.862622-04:00[US/Eastern]',
          lastUpdateTimestamp: '2023-08-14T08:12:23.862911-04:00[US/Eastern]',
          cartCreator: '4782303946',
          cartCreatorChannelId: 'OMNI-RETAIL',
          cartCreatorOrderLocationCode: '2777301',
          cartCreatorSalesRepId: 'ENC',
          caseId: 'SOP-16650322-E01',
          visionCustomerType: 'PE',
          maverickLocation: false,
          isCoreRep: false,
          isERTRep: false,
        },
        orderDetails: {
          totalUpgradeFee: 0,
          totalDeviceDollar: 0,
          totalRemainingDeviceDollar: 0,
          totalUsedDeviceDollar: 0,
          totalAccountLevelAccCost: 0,
          totalAccountLevelAccCostWithTax: 0,
          hqUser: false,
          returnException: false,
          taxDetailsList: [],
          subTotalDueTodayWithoutUpgradeFee: 0,
          subTotalDueMonthlyForAALBYODEUP: 0,
          shipTogetherPref: true,
          assistanceOptedByCustomer: false,
          locationState: 'IL',
          isShellAccountSelected: false,
          fullfillmentLocation: '1000050',
          guestOrInactiveRefundLines: false,
          totalDueMonthlyOnProfile: 0,
          subTotalDueMonthlyOnProfile: 0,
          totalMonthlyTaxesOnProfile: 0,
          subTotalOtherLinesOnProfile: 0,
          estimatedNextMonthChargeOnProfile: 0,
          originalSubTotalDueMonthly: 0,
          totalDueMonthlyAfterDiscounts: 0,
          totalTaxAdjustmentAmount: 0,
          totalActivationFees: 0,
          fiveGHomeOrder: false,
          totalRefundAmount: 0,
          totalExchangeAmount: 0,
          totalRefundTaxAmount: 0,
          totalExchangeTaxAmount: 0,
          digitalExchange: false,
          remainingAmountAfterAffirmApplied: 0,
          cashOptionEnabled: false,
          affirmCreditCheckFailed: false,
          locationCode: '2777301',
          customerType: 'U',
          billingSystem: 'VE',
          totalDueToday: 0,
          runningTotalDueToday: 0,
          totalDueTodayFlag: false,
          totalDueMonthly: 0,
          subTotalDueMonthly: 0,
          subTotalDueToday: 0,
          subTotalMonthlyTaxes: 0,
          estimatedNextMonthCharge: 0,
          totalMonthlyTaxes: 0,
          subTotalOtherLines: 0,
          subTotalOtherLinesTaxes: 0,
          instantDRCCredit: false,
          isAttachmentCompleted: false,
          nextMonthBillTotal: 0,
          customerNotification: {
            smsLanguage: 'E',
          },
          orderChannelId: 'OMNI-RETAIL',
          orderList: [
            {
              creditApplication: {
                creditApplicationNum: 461941674,
                creditApprovalStatus: 'AP',
                creditStatusReason: 'CA Customer Systematic Approval',
                internationalEligibility: true,
                securityDepositAmount: '0',
                serviceClass: 'B',
                lineCreditClass: '1D',
                creditAppEdited: false,
              },
              orderActivityType: 'EUP',
              orderNumber: 0,
              numOfLinesForOrderActivityType: 0,
              preOrderNumber: 0,
              digitalOrderId: 0,
              managerApprovalRequired: false,
            },
          ],
          outletId: '000027773',
          registerNumber: '10',
          saleType: 'P',
          salesRepId: 'ENC',
          enableSplitShipment: false,
          splitShipmentIndicator: false,
          isSingleModConnectedDevice: false,
          fiveGUpSellAccountLevel: false,
          customerOnTrialPlan: false,
          totalDownPaymentAmt: 0,
          totalEdgeBuyOutAmount: 0,
          expressCheckout: false,
          isEQPandPPLOfferApplied: false,
          memberTotalDueToday: 0,
          customerConsent: 'N',
          billingState: 'GA',
          isTradeInOfferSelected: false,
          isAssignMtnRequired: false,
          fiosCapable: false,
          fiosEligible: false,
          quoteWithoutCredit: false,
          uswinAuthenticationRequired: false,
          newPreToPostInfo: {
            newPreToPostIndicator: 'E',
            newPreToPostMtns: {
              accountOwner: '',
              accountMembers: [],
            },
          },
          totalDueTodayWithoutDiscount: 0,
          subTotalDueTodayWithoutDiscount: 0,
          totalPerksSavings: '0.0',
        },
        lineDetails: {
          lineInfo: [
            {
              mobileNumber: '5185673926',
              installmentInfo: { installmentTerm: 24 },
              itemsInfo: [{ cartItems: { cartItem: [{ cartItemType: 'DEVICE', priceType: 'DEVICE_PAYMENT' }] } }],
            },
          ],
          numOfAccessoryAndDeviceItemsInCart: 0,
          totalEdgeUpAmount: 0,
          totalEdgeBuyOutAmount: 0,
          tradeInDetail: {},
          totalDownPaymentAmt: 0,
          numOfLinesWithDevices: 0,
          numofApprovedLines: 0,
          rfexPayments: [],
          couponDetails: [{}],
          cartId: '4a833813-e7c5-453c-8e94-a733ca79c36b',
          numOfLines: 0,
          numofLinesAAL: 0,
          numofLinesEUP: 0,
          payments: [],
          lineSeq: 0,
          vlcactivePhoneCount: 0,
          fivegOrderind: false,
          aceOrderCreated: false,
          serviceLinesCreated: false,
          aceItemsModified: false,
          clnrOrderFlag: false,
          broadbandInd: false,
          acctMcsSubscription: [],
          numofAccessories: 0,
          subAccountNBSInfo: [],
          bagTax: false,
        },
        refundOrderDetails: {
          orderNum: 0,
          totalDueToday: '0.0',
          subTotalDueToday: '0.0',
          totalTaxAmount: '0.0',
          creditApplicationNum: 0,
        },
        accountEligibility: false,
        displayCartValidationErrors: true,
      },
      warningMessages: [],
      basicORSmartPhoneExists: false,
      fiveGDeviceORLTEHomeExists: false,
      cartHasAccessories: false,
      iscartHasVZHP: false,
      validateCart: false,
      redesignFlow: false,
      orderPlaced: false,
      isLocalStoreOfferEnabled: false,
    },
    customerProfileDetails: {
      commonInfo: {
        showAccessoryTab: true,
        showTradeinTab: true,
        showLocalDfillRadioButton: false,
        showEnterDeviceToggle: true,
        showScanner: true,
        showSearchAccessory: false,
        showViewPriceBreakdown: false,
        showPriceBreakdownTooltip: true,
        showDevicePrices: true,
        showShipitToggle: true,
        showSellersPrice: false,
        isIndirect: false,
        showSalesRep: true,
        isISPUEnabled: true,
        showShopMoreDevices: true,
        showSecurityDeposit: false,
        showViewUpgradeReasonCode: true,
        showIneligibleUpgradeLines: true,
        showPastDueYesNobutton: true,
        maxNewLines: 5,
        showAccessoryShipItToggle: true,
        isTrialUnlimitedAccount: false,
        showCompassOffers: false,
        serviceOfferAccepted: false,
        isIsaacEnabled: true,
        fiveGHomeQualified: false,
        fiosEligible: false,
        basicORSmartPhoneExists: true,
        isVZHPCustomer: false,
        isGridwallRedesignFlow: true,
        disableDfillRadioButton: false,
        showCreditStatus: true,
        showEcpdProfile: true,
        showHomeServicesReferral: true,
        showClickToCall: true,
        showIdCheck: true,
        showFPFCHeck: true,
        showManageDownPayments: true,
        showIntegrateWFM: false,
        showOrderEffectiveDate: true,
        showCartAnalyzer: true,
        showNeedHelp: false,
        ltehomeQualified: false,
      },
      customer: {
        caseId: 'SOP-16650322-E01',
        cartId: '4a833813-e7c5-453c-8e94-a733ca79c36b',
        processStep: 'MTNSelectionPage',
        availablePaths: [
          {
            path: 'MTNSelectionPage',
          },
        ],
        customerId: '325893599',
        customerHash: 'cccff0728bd1a30e896d15347b8ead72f887ea845508d33c3d7ce1a3735b9e95',
        contactAddress: {
          state: 'GA',
        },
        customerName: {
          firstName: 'DAN',
          lastName: 'JETER',
          businessName: '',
          preferFirstName: '',
          preferLastName: '',
          preferPronoun: '',
        },
        address: {
          addressLine1: '674 BAY SPRINGS CHURCH RD',
          addressLine2: '',
          city: 'EASTMAN',
          state: 'GA',
          zipCode: '31023',
          fipsCode: '1309125552',
          geoCode: 'USA13091000000',
          zipCodePlus4: '3512',
          scrubbedAddress: {
            streetName: 'BAY SPRINGS CHURCH',
            streetNumber: '674',
            streetType: 'RD',
            streetDirection: '',
            pobox: '',
            ruralDeliveryNo: '',
            ruralRouteNo: '',
            city: 'EASTMAN',
            state: 'GA',
            zipCode: '31023',
            zipCodePlus4: '3118',
          },
        },
        email: 'DSRGMVBHVDVOO89@VZW.COM',
        lookupMtn: '4782303946',
        billingSystem: 'VISION_EAST',
        customerAttributes: {
          hasEcpd: false,
          autoPayDiscountEligibleCustomerType: true,
          customerType: 'PE',
          associationIdNo: null,
        },
        billAccounts: [
          {
            billAccountNo: '1',
            recommendation: {
              recommendedPlan: {
                usageInfo: {
                  accountUsageInfo: {
                    dataUsageInfos: [],
                  },
                },
                unbilledAccountUsageInfo: {
                  totalData: null,
                  unitOfMeasure: null,
                  usageType: null,
                  dataAllowance: null,
                },
              },
            },
            billCycle: {
              billCycleDate: '08/14/2023',
              remainingDays: '0',
              nextBillCycleAutoRedeemPaymentDate: null,
            },
            programEligibility: {
              programEligible: true,
              spendingLimitAmount: '7000.00',
              BTALimitAmount: '750.00',
              RemainingBTAAmount: '750.00',
              RemainingSpendingLimitAmount: '7000.00',
            },
            sharePlan: {
              planId: null,
              description: null,
              chargeAmount: null,
              planImageUrl: null,
            },
            accountOffers: {
              productOffers: [],
            },
            accountLevelChangeEligibility: {
              isAddNewLineAllowed: true,
              isBundleChangeAllowed: true,
              isSharePlanChangeAllowed: true,
              pendingOrderDetail: null,
            },
            paymentInfo: {
              arPastDueBalance: '0.00',
              currentBalance: '103.46',
              isBalancePastDue: false,
              pastDueBalance: '0.00',
              invoiceDate: '06/14/2023',
              isAutoPayEnrolled: false,
              isPaperFreeEnrolled: false,
              recentActivityAmount: '0.00',
              outstandingBalance: null,
              vzWalletInfo: {
                eligibleToUseVzDollar: null,
                maximumPropositionAmount: null,
                minimumPropositionAmount: null,
                vzDollarsBalance: null,
              },
              vzdAutoRedeemDetails: {
                vzdAutoRedeemEnrolled: null,
                vzdAutoRedeemAmount: null,
                vzdAutoRedeemFullBillAmount: null,
                vzdAutoRedeemEnrollDate: null,
              },
              lastVzdollarsAutoRedeemAmt: null,
              lastVzdollarsAutoRedeemPaymenDate: null,
              lastVzPmtDate: null,
              currentBCVzdollarsRedeemAmt: null,
            },
            accountAttributes: {
              isAutoPayWithPaperless: false,
              mixedPlanCategories: true,
              isOverThreshHold: false,
              isCashOnly: false,
              isCashOnlyExceptCA: false,
              isCashOnlyExceptCC: false,
              isCashOnlyExceptCO: false,
              fraudInfo: {
                fraud_X: false,
                fraud_Y: false,
              },
              isMyVerizonEnrolled: true,
            },
            mtns: [
              {
                mtn: '4782303946',
                numberShare: null,
                mtnHashCode: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
                nickName: 'DAN M JETER-3946',
                benefitPair: {
                  pairedPhoneMtn: null,
                  eligibleToPair: false,
                  existingPair: false,
                  grantee: false,
                  grantor: false,
                },
                primaryUser: {
                  firstName: 'DAN',
                  lastName: 'JETER',
                  preferFirstName: null,
                  preferLastName: null,
                  preferPronoun: null,
                },
                mtnStatus: {
                  isActive: true,
                  isDisconnected: false,
                  isReassignedAndInActive: false,
                  isSuspendedWithBilling: false,
                  isSuspendedWithoutBilling: false,
                  mtnSuspendAllowed: false,
                  isMtnSuspended: false,
                  mtnStatusReasonCode: '',
                  isMtnChanged: null,
                  isReassigned: null,
                  isTransfered: false,
                  status: 'A',
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      deviceId: '356552104459243',
                      deviceSku: 'MWKR2LL/A',
                      deviceUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/Apple_iPhone_11_Purple_09102019',
                      productDisplayName: 'iPhone 11',
                      category: {
                        smartphone: true,
                        tablet: false,
                        basicphone: false,
                        connectedDevice: false,
                        internetDevice: false,
                        homePC: false,
                        telematics: false,
                        virtualDevice: false,
                        WSOnly: false,
                      },
                      tradeInValue: '134.00',
                      displayName: 'Apple iPhone 11 64GB in Purple (2019)',
                      capacity: null,
                      deviceType: {
                        backupRouter4G: null,
                        device4G: null,
                        device3G: null,
                        device5GA: false,
                        device5GE: false,
                        antenna5G: false,
                        home5G: false,
                        deviceType: '4GE',
                        home4GLte: false,
                      },
                      numberShareCapability: null,
                      cdmaRestrictedDevice: false,
                    },
                    simInfo: {
                      simId: '89148000005702817800',
                      simSku: 'EMBDSIMTRI',
                      skuType: null,
                    },
                  },
                ],
                pricePlanInfo: {
                  planId: '26872',
                  description: '5G START',
                  planDisplayName: null,
                  planImageUrl: null,
                  planCategoryName: 'UNLIMITED FOR ALL',
                  effectiveDate: null,
                  planAttributes: {
                    sharePlan: false,
                    isJax: false,
                    isFelix: false,
                  },
                  accessCharge: null,
                  imageUrlMap: null,
                  planPromotions: null,
                },
                currentSPOs: null,
                currentFeatures: [
                  {
                    sfoId: '48526',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                  {
                    sfoId: '48553',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                  {
                    sfoId: '68869',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                  {
                    sfoId: '68870',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                  {
                    sfoId: '68871',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/3way_Calling_012918',
                    existing: false,
                  },
                  {
                    sfoId: '68872',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                  {
                    sfoId: '68873',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                  {
                    sfoId: '68874',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                  {
                    sfoId: '68876',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                  {
                    sfoId: '73502',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    existing: false,
                  },
                  {
                    sfoId: '73503',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918',
                    existing: false,
                  },
                  {
                    sfoId: '75706',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                  {
                    sfoId: '75802',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                  {
                    sfoId: '75836',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                  {
                    sfoId: '75837',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                  {
                    sfoId: '76404',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                  {
                    sfoId: '76600',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Caller_ID_012918',
                    existing: false,
                  },
                  {
                    sfoId: '77556',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                  {
                    sfoId: '77568',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                  {
                    sfoId: '79708',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Voicemail_012918',
                    existing: false,
                  },
                  {
                    sfoId: '80148',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                  {
                    sfoId: '81143',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                  {
                    sfoId: '81158',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/HD_Voice_012918',
                    existing: false,
                  },
                  {
                    sfoId: '81186',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                  {
                    sfoId: '84094',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                  {
                    sfoId: '85405',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                  {
                    sfoId: '85553',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Cloud_012918',
                    existing: false,
                  },
                  {
                    sfoId: '86189',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/Data_012918',
                    existing: false,
                  },
                  {
                    sfoId: '86192',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                  {
                    sfoId: '86195',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                  {
                    sfoId: '86209',
                    price: '0.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/International_Long_Distance_012918',
                    existing: false,
                  },
                  {
                    sfoId: '86905',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                  {
                    sfoId: '88689',
                    price: '17.00',
                    isActive: true,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/device_protection_120817',
                    existing: false,
                  },
                  {
                    sfoId: '89391',
                    price: '0.00',
                    isActive: false,
                    imageUrlMap: 'https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216',
                    existing: false,
                  },
                ],
                addOnDueMonthly: null,
                equipmentUpgradeEligibility: {
                  upgradeEligible: true,
                  annualUpgradeEligible: false,
                  buyoutEligible: false,
                  earlyUpgradeEligible: false,
                  edgeUpEligible: false,
                  upgradeEligibilityDate: '01/15/2022',
                  upgradeEligibilityLabel: 'Upgrade Now - Not Transferable',
                  buyoutAmountLabel: null,
                  pendingOrderDetail: null,
                  isWithInWFGperiod: false,
                  discountEligibility: {
                    discountEligible: true,
                    eligibilityLabel: 'DISCOUNT ELIGIBLE',
                  },
                  hadTwoBuyoutInCurrentMonth: false,
                  transferUpgradeEligibility: {
                    giverEligible: false,
                    takerEligible: false,
                    takerMtns: [],
                  },
                },
                lineLevelChangeEligibility: {
                  isDeviceOnlyChangeAllowed: true,
                  isFeatureChangeAllowed: true,
                  isLLBChangeAllowed: true,
                  isMtnChangeAllowed: true,
                  isMtnSuspendAllowed: true,
                  isPricePlanChangeAllowed: true,
                  pendingOrderDetail: null,
                },
                mobileInfoAttributes: {
                  paidInsuranceExist: false,
                  numberShareParent: '',
                  accountOwner: false,
                  accessRoles: null,
                  hasReferAFriend: false,
                },
                tradeInPromo: null,
                inServiceDate: null,
                lineSharingIndicator: '',
                lineAccessCharge: null,
                installmentLoans: [],
                earlyTermination: null,
                mobileInfoInsurance: {
                  insuranceId: '88689',
                  insuranceCategory: 'SFO',
                  insuranceName: 'VERIZON MOBILE PROTECT $17',
                  insuranceType: 'MOBILE',
                  price: '17.00',
                },
                availableMTNsForLoanTransfer: {},
                offers: null,
                recentPurchaseOrder: null,
                marketingOption: {
                  vzCCHolder: false,
                },
                totalDueMonthly: null,
                planChangeHoldOrdersFound: null,
                mtnEffectiveDate: null,
                isEqpOrAccOfferAccepted: null,
                lineLevelCurrentCostData: {},
                networkBandwidthType: '',
                deviceMtnIndicator: '',
                showSUGToggle: true,
                balanceAmount: null,
                isNewLine: false,
                sharePlan: null,
                fiosEligibilityCategory: null,
                accountAddress: null,
                newLine: false,
              },
              {
                mtn: '4782309486',
                numberShare: null,
                mtnHashCode: '',
                nickName: 'DAN M JETER-9486',
                benefitPair: {
                  pairedPhoneMtn: null,
                  eligibleToPair: false,
                  existingPair: false,
                  grantee: false,
                  grantor: false,
                },
                primaryUser: {
                  firstName: 'DAN',
                  lastName: 'JETER',
                  preferFirstName: null,
                  preferLastName: null,
                  preferPronoun: null,
                },
                mtnStatus: {
                  isActive: false,
                  isDisconnected: false,
                  isReassignedAndInActive: false,
                  isSuspendedWithBilling: false,
                  isSuspendedWithoutBilling: false,
                  mtnSuspendAllowed: false,
                  isMtnSuspended: false,
                  mtnStatusReasonCode: '45',
                  isMtnChanged: null,
                  isReassigned: null,
                  isTransfered: false,
                  status: 'C',
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      deviceId: '356552104459243',
                      deviceSku: 'MWKR2LL/A',
                      deviceUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/Apple_iPhone_11_Purple_09102019',
                      productDisplayName: 'iPhone 11',
                      category: {
                        smartphone: true,
                        tablet: false,
                        basicphone: false,
                        connectedDevice: false,
                        internetDevice: false,
                        homePC: false,
                        telematics: false,
                        virtualDevice: false,
                        WSOnly: false,
                      },
                      tradeInValue: '134.00',
                      displayName: 'Apple iPhone 11 64GB in Purple (2019)',
                      capacity: null,
                      deviceType: {
                        backupRouter4G: null,
                        device4G: null,
                        device3G: null,
                        device5GA: false,
                        device5GE: false,
                        antenna5G: false,
                        home5G: false,
                        deviceType: '4GE',
                        home4GLte: false,
                      },
                      numberShareCapability: null,
                      cdmaRestrictedDevice: false,
                    },
                    simInfo: {
                      simId: '89148000005702817800',
                      simSku: 'EMBDSIMTRI',
                      skuType: null,
                    },
                  },
                ],
                pricePlanInfo: {
                  planId: null,
                  description: null,
                  planDisplayName: null,
                  planImageUrl: null,
                  planCategoryName: null,
                  effectiveDate: null,
                  planAttributes: null,
                  accessCharge: null,
                  imageUrlMap: null,
                  planPromotions: null,
                },
                currentSPOs: null,
                currentFeatures: [],
                addOnDueMonthly: null,
                equipmentUpgradeEligibility: {
                  upgradeEligible: false,
                  annualUpgradeEligible: false,
                  buyoutEligible: false,
                  earlyUpgradeEligible: false,
                  edgeUpEligible: false,
                  upgradeEligibilityDate: null,
                  upgradeEligibilityLabel: '',
                  buyoutAmountLabel: null,
                  pendingOrderDetail: null,
                  isWithInWFGperiod: false,
                  discountEligibility: {
                    discountEligible: false,
                    eligibilityLabel: 'NOT DISCOUNT ELIGIBLE',
                  },
                  hadTwoBuyoutInCurrentMonth: false,
                  transferUpgradeEligibility: {
                    giverEligible: false,
                    takerEligible: false,
                    takerMtns: [],
                  },
                },
                lineLevelChangeEligibility: {
                  isDeviceOnlyChangeAllowed: true,
                  isFeatureChangeAllowed: true,
                  isLLBChangeAllowed: true,
                  isMtnChangeAllowed: true,
                  isMtnSuspendAllowed: true,
                  isPricePlanChangeAllowed: true,
                  pendingOrderDetail: null,
                },
                mobileInfoAttributes: {
                  paidInsuranceExist: false,
                  numberShareParent: '',
                  accountOwner: false,
                  accessRoles: null,
                  hasReferAFriend: false,
                },
                tradeInPromo: null,
                inServiceDate: null,
                lineSharingIndicator: '',
                lineAccessCharge: null,
                installmentLoans: [],
                earlyTermination: null,
                mobileInfoInsurance: {},
                availableMTNsForLoanTransfer: {},
                offers: null,
                recentPurchaseOrder: null,
                marketingOption: {
                  vzCCHolder: false,
                },
                totalDueMonthly: null,
                planChangeHoldOrdersFound: null,
                mtnEffectiveDate: null,
                isEqpOrAccOfferAccepted: null,
                lineLevelCurrentCostData: {},
                networkBandwidthType: '',
                deviceMtnIndicator: '',
                showSUGToggle: true,
                balanceAmount: null,
                isNewLine: false,
                sharePlan: null,
                fiosEligibilityCategory: null,
                accountAddress: null,
                newLine: false,
              },
              {
                mtn: '4782314605',
                numberShare: null,
                mtnHashCode: '14ca6d36f56a2087e4461286fa2e8810e5726e107b4a197e3b0bbd901299684d',
                nickName: 'DAN M JETER-4605',
                benefitPair: {
                  pairedPhoneMtn: null,
                  eligibleToPair: false,
                  existingPair: false,
                  grantee: false,
                  grantor: false,
                },
                primaryUser: {
                  firstName: 'DAN',
                  lastName: 'JETER',
                  preferFirstName: null,
                  preferLastName: null,
                  preferPronoun: null,
                },
                mtnStatus: {
                  isActive: false,
                  isDisconnected: true,
                  isReassignedAndInActive: false,
                  isSuspendedWithBilling: false,
                  isSuspendedWithoutBilling: false,
                  mtnSuspendAllowed: false,
                  isMtnSuspended: false,
                  mtnStatusReasonCode: 'A2',
                  isMtnChanged: null,
                  isReassigned: null,
                  isTransfered: false,
                  status: 'D',
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      deviceId: '352967111976464',
                      deviceSku: 'M07G3LL/A',
                      deviceUrl:
                        'https://ss7.vzw.com/is/image/VerizonWireless/apple-watch-series-6-gold-aluminum-sport-band-44-mm-m07g3lla-a',
                      productDisplayName: 'Watch Series 6 Gold Aluminum 44mm Case with Sport Band in Pink Sand',
                      category: {
                        smartphone: false,
                        tablet: false,
                        basicphone: false,
                        connectedDevice: true,
                        internetDevice: false,
                        homePC: false,
                        telematics: false,
                        virtualDevice: false,
                        WSOnly: false,
                      },
                      tradeInValue: '53.00',
                      displayName:
                        'Apple Watch Series 6 GPS + Cellular, 44mm Gold Aluminum Case with Pink Sand Sport Band',
                      capacity: null,
                      deviceType: {
                        backupRouter4G: null,
                        device4G: null,
                        device3G: null,
                        device5GA: false,
                        device5GE: false,
                        antenna5G: false,
                        home5G: false,
                        deviceType: '4GE',
                        home4GLte: false,
                      },
                      numberShareCapability: null,
                      cdmaRestrictedDevice: false,
                    },
                    simInfo: {
                      simId: '89148000006917142133',
                      simSku: 'SOFTSIM-CMR-A',
                      skuType: null,
                    },
                  },
                ],
                pricePlanInfo: {
                  planId: null,
                  description: null,
                  planDisplayName: null,
                  planImageUrl: null,
                  planCategoryName: null,
                  effectiveDate: null,
                  planAttributes: null,
                  accessCharge: null,
                  imageUrlMap: null,
                  planPromotions: null,
                },
                currentSPOs: null,
                currentFeatures: [],
                addOnDueMonthly: null,
                equipmentUpgradeEligibility: {
                  upgradeEligible: false,
                  annualUpgradeEligible: false,
                  buyoutEligible: false,
                  earlyUpgradeEligible: false,
                  edgeUpEligible: false,
                  upgradeEligibilityDate: null,
                  upgradeEligibilityLabel: 'Upgrade Now',
                  buyoutAmountLabel: null,
                  pendingOrderDetail: null,
                  isWithInWFGperiod: false,
                  discountEligibility: {
                    discountEligible: false,
                    eligibilityLabel: 'NOT DISCOUNT ELIGIBLE',
                  },
                  hadTwoBuyoutInCurrentMonth: false,
                  transferUpgradeEligibility: {
                    giverEligible: false,
                    takerEligible: false,
                    takerMtns: [],
                  },
                },
                lineLevelChangeEligibility: {
                  isDeviceOnlyChangeAllowed: true,
                  isFeatureChangeAllowed: true,
                  isLLBChangeAllowed: true,
                  isMtnChangeAllowed: true,
                  isMtnSuspendAllowed: true,
                  isPricePlanChangeAllowed: true,
                  pendingOrderDetail: null,
                },
                mobileInfoAttributes: {
                  paidInsuranceExist: false,
                  numberShareParent: '',
                  accountOwner: false,
                  accessRoles: null,
                  hasReferAFriend: false,
                },
                tradeInPromo: null,
                inServiceDate: null,
                lineSharingIndicator: '',
                lineAccessCharge: null,
                installmentLoans: [],
                earlyTermination: null,
                mobileInfoInsurance: {},
                availableMTNsForLoanTransfer: {},
                offers: null,
                recentPurchaseOrder: null,
                marketingOption: {
                  vzCCHolder: false,
                },
                totalDueMonthly: null,
                planChangeHoldOrdersFound: null,
                mtnEffectiveDate: null,
                isEqpOrAccOfferAccepted: null,
                lineLevelCurrentCostData: {},
                networkBandwidthType: '',
                deviceMtnIndicator: '',
                showSUGToggle: true,
                balanceAmount: null,
                isNewLine: false,
                sharePlan: null,
                fiosEligibilityCategory: null,
                accountAddress: null,
                newLine: false,
              },
            ],
            fiosEligibilityCategory: null,
            accountAddress: {
              addressLine1: '674 BAY SPRINGS CHURCH RD',
              addressLine2: '',
              city: 'EASTMAN',
              state: 'GA',
              zipCode: '31023',
              fipsCode: '1309125552',
              geoCode: 'USA13091000000',
              zipCodePlus4: '3512',
              scrubbedAddress: {
                streetName: 'BAY SPRINGS CHURCH',
                streetNumber: '674',
                streetType: 'RD',
                streetDirection: '',
                pobox: '',
                ruralDeliveryNo: '',
                ruralRouteNo: '',
                city: 'EASTMAN',
                state: 'GA',
                zipCode: '31023',
                zipCodePlus4: '3118',
              },
            },
            establishedDate: '01/15/2020',
            establishedInLastThirtyDays: false,
            contactInfo: {
              decline: false,
              declineReasonCode: '',
            },
            vzwVztCustomerInfo: {
              totalDiscountAmountMH: null,
              perlineDiscountMH: null,
              discountAppliedMH: null,
              discountVersionMH: null,
              tenDollarMNHDiscount: null,
              fiveDollarMNHDiscount: null,
              fiosBonusDiscount: null,
              vzwBonusDiscount: null,
              subtotalBaseAmountMH: null,
              bonusDiscountMNH: null,
              vztAccountInfo: [],
            },
            accountSubscriptions: {
              lineLevelSubscriptions: [
                {
                  mtn: '4782303946',
                  subscriptions: [
                    {
                      isWithin24HoursOfExpiry: false,
                    },
                  ],
                },
              ],
            },
          },
        ],
        customerCbrInfo: {
          cbrNos: [
            {
              phoneNumber: '9999999999',
            },
          ],
        },
        isSalesRepIdMismatch: false,
        accountNo: '0325893599-00001',
        repId: 'ENC',
        loggedInUser: 'MASTRAL',
        channel: 'OMNI-RETAIL',
        orderLocationCode: '2777301',
        orderNumber: '12',
        homeLocationCode: '2777301',
        regNo: '10',
        isComboOrderAllowed: false,
        storeLocationState: 'IL',
        customerProfileInfoCart: {
          firstName: '',
          lastName: '',
          middleName: '',
          suffix: '',
          businessName: '',
          addressLine1: '',
          addressLine2: '',
          aptNum: '',
          streetNumber: '',
          streetName: '',
          dir: '',
          email: '',
          city: '',
          state: '',
          zipCode: '',
          zipCode4: '',
          phoneNumber: '',
        },
        repSecurityClassCode: '00000007',
        isAsurionExpansionEnabled: false,
        qualificationDetails: {
          cartId: '',
        },
      },
    },
    activeMtn: '4782303946',
    selectedColor: 'DeepPurple',
    ispuToggleOn,
    isShipItToggleOn,
    selectedSku: {
      color: {
        colorCssStyle: '#655D6C',
        colorId: 'clr12200029',
        description: 'Purple',
        displayName: 'Deep Purple',
      },
      price: {
        devicePaymentPrice: [
          {
            originalPrice: 27.77,
            contractDuration: 36,
            contractText:
              'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
            dpTermPrices: {
              downPayment: 0,
              downPaymentRequired: false,
              upgradeOptionPercentage: 100,
              upgradeOptionCode: 'DP',
              dpTerm: 36,
              ugradeEligibilityCategory: [],
              firstMonthPrice: 28.04,
              remainingMonthPrice: 27.77,
            },
          },
        ],
        fullRetailPrice: {
          originalPrice: 999.99,
          contractText: 'Full Retail Price',
        },
        preferredTerm: 36,
      },
      comingSoonFlag: false,
      imageUrlMap: {
        defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a',
        largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-lg$',
        mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-med$',
        miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-mini$',
        thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-thumb$',
        imageSetUrl:
          'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
      },
      inventoryDetails: {
        dFillInventory: {
          isAvailable: false,
          isBackorder: false,
          isDeliverBy: false,
          isPreOrder: false,
          isShipBy: false,
          isInStock: true,
          locationCode: '9999999',
          qtyAvailable: 120569,
        },
        localInventory: {
          isAvailable: false,
          isBackorder: false,
          isDeliverBy: false,
          isPreOrder: false,
          isShipBy: false,
          isInStock: true,
          locationCode: '2777301',
          qtyAvailable: 62,
        },
      },
      isBillToAccount: false,
      isRestrictionEnabled: true,
      prodCode1: '5GD',
      prodCode2: 'SMT',
      prodCode3: 'DIG',
      prodCode4: 'VDS',
      prodCode5: 'ISL',
      skuDisplayName: 'iPhone 14 Pro 128GB in Deep Purple',
      skuId: 'sku5600276',
      sorId: 'MQ0E3LL/A',
      customerAttributes: {
        establishedDate: '01/15/2020',
        customerType: 'PE',
        digitalCustomerType: 'B2C',
        firstName: 'DAN',
        lastName: 'JETER',
        zipCode: '31023',
        zipCodePlus4: '3512',
        inWithVerizonInd: 'N',
        state: 'GA',
        hashedMdn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
        hashedAccountNumber: 'cccff0728bd1a30e896d15347b8ead72f887ea845508d33c3d7ce1a3735b9e95',
        mtnList: ['4782303946'],
        lineDetails: [
          {
            mtn: '4782303946',
            hashedMtn: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
            existingFWA: false,
          },
        ],
      },
      capacity: '128 GB',
      capacitySize: 128,
      capacityUnit: '128 GB',
      isDevicePaymentEligible: true,
      isInstorePickup: true,
      isSameDayDelivery: true,
      isHumDevice: false,
      isSmartLocator: false,
      simSku: 'UNIVESIM5G-SA-D',
      edgeDeviceCap: '1010',
      productIdMap: {
        prepayProduct: 'dev20000221',
        postPayProduct: 'dev19920005',
      },
      skuRestricted: false,
      skuFilters: {
        band: 'Rubber',
        deviceFilterType: 'Smartphones',
        restrictedAccySku: 'false',
      },
      isPreconfigureEnabled: false,
      itemSaleFlag: true,
      isPromoEligible: false,
    },
    selectedProtectionFeature: {
      displayName: 'Verizon Mobile Protect',
      sorId: '88689',
      description:
        "<p>Provides coverage for loss, theft, damage and post&#45;warranty defects.</p>\n\n<p><strong>Unlimited claims</strong><br />\nLive without limits. Get an unlimited number of claims.<sup>1</sup></p>\n\n<p><strong>No extra cost cracked screen repairs</strong><br />\nUnlimited and at no extra cost to you.<sup>2</sup></p>\n\n<p><strong>Same&#45;day delivery and setup</strong><br />\nFor replacement smartphones and new devices<sup>3</sup> purchased here. Enjoy seamless device and content set&#45;up</p>\n\n<p><strong>&#36;99 damage deductible</strong><br />\nThe most you'll pay to replace your damaged device is &#36;99.<sup>4</sup></p>\n\n<p><strong>Other benefits:</strong><br />\nFast battery replacement<sup>5</sup><br />\nData recovery, even if your smartphone is damaged<sup>6</sup><br />\n24/7 tech support plus digital security and privacy tools<sup>7</sup></p>",
      featureFamily: 'VZPROTECT',
      preSelect: true,
      showCaseFlag: true,
      coverageType: 'LINELEVEL',
      sellable: true,
      additionalFeature: false,
      appleCare: false,
      bundledInVzProtect: false,
      price: {
        regularPrice: '17.00',
        discountedPrice: '17.00',
      },
      deductible: '0.0',
      vzProtectEligibleDevices: [
        {
          mtn: '4782303946',
          displayName: 'Apple iPhone 14 Pro',
          imageUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a',
          customerName: 'DAN JETER',
          tmpEligible: false,
          callFilterEligible: true,
          safeWifiEligible: true,
          partialCallFilterFeaturesIncluded: false,
          digitalSecureOSDependent: false,
        },
      ],
      selectedInCart: false,
      onCustomerAccount: true,
      mutualExclusions: [79184, 81495, 85913, 66332, 88703],
      actionIndicator: 'Z',
      addedInCart: false,
      featureType: 'SFO',
      currentProtectionCompatible: true,
      restrictionEnabled: false,
      disclaimerEnabled: false,
      sddSetupEligible: true,
      hasProtectionExceeded10LineCap: false,
      includesCallFilter: false,
      includesDigitalSecure: false,
      includesTechCoach: true,
    },
    selectedSize: '128 GB',
    setSelectedColor: mockSetSelectedColor,
    setIspuToggleOn: mockSetIspuToggleOn,
    setIsShipItToggleOn: mockSetIsShipItToggleOn,
    setSelectedSku: mockSetSelectedSku,
    setSelectedProtectionFeature: mockSetSelectedProtectionFeature,
    setSelectedSize: mockSetSelectedSize,
    setSelectedPaymentInfo,
    setShowDeviceProtectionModal,
    updateDeviceId,
    updateSimId,
    updateDeviceData,
    setUpgradeReasonType,
    setisInStock,
    getContractTerm,
    setBuyOutAccepted,
    setSkipRedirection,
    removeLines,
    groupByColors: jest.fn(),
    groupBySmartWatchBand: jest.fn(),
    upcCodeFromPdpScan: '123456789012',
  };
  return {
    props: defaultProps,
    mockSetSelectedColor,
    mockSetIspuToggleOn,
    mockSetIsShipItToggleOn,
    mockSetSelectedSku,
    mockSetSelectedProtectionFeature,
    mockSetSelectedSize,
    setUpgradeReasonType,
    setisInStock,
    getContractTerm,
    setBuyOutAccepted,
    setSkipRedirection,
    removeLines,
  };
};
jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => false,
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

describe('<DeviceInfo/>', () => {
  describe('First', () => {
    it('should test title and link should be #', () => {
      const { props, mockSetIspuToggleOn } = getProps();
      const newProps = { setBuyoutToggleChange: jest.fn() };
      render(<DeviceInfo {...props} {...newProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      const [ispuToggleOn] = screen.getAllByRole('checkbox');

      fireEvent.click(ispuToggleOn);
      fireEvent.keyPress(ispuToggleOn, { key: 'Enter', charCode: 13 });
      // fireEvent.click(isShipItToggleOn);
      expect(mockSetIspuToggleOn).toBeCalled();
      // expect(mockSetIsShipItToggleOn).toBeCalled();

      expect(screen.queryByText(/Check availability/i)).toBeNull();
    });
  });

  describe('Second', () => {
    it('should test that check avaiability link is visible when in store pickup is enabled', async () => {
      const { props } = getProps(true);
      const props1 = {
        ...props,
        PdpBuyoutToggle: true,
        isBuyoutEligible: true,
        buyOutDetail: true,
        buyOutAccepted: true,
        cartDetails: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  mobileNumber: 5185673926,
                  installmentInfo: { installmentTerm: 24 },
                  itemsInfo: [{ cartItems: { cartItem: [{ cartItemType: 'DEVICE', priceType: 'DEVICE_PAYMENT' }] } }],
                },
              ],
            },
          },
        },
        groupByColors: jest.fn(),
        setBuyoutToggleChange: jest.fn(),
      };
      render(<DeviceInfo {...props} {...props1} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      expect(screen.queryByTestId('insuranceSel')).toBeNull();
      expect(screen.getByText(/Check availability/i)).toBeInTheDocument();
      fireEvent.click(screen.getByText(/Check availability/i));
      expect(screen.queryByTestId('insuranceSel')).toBeInTheDocument();
      fireEvent.click(screen.getByTestId('viewDetails'));
      fireEvent.keyPress(screen.getByTestId('viewDetails'), { key: 'Enter', charCode: 13 });
      fireEvent.click(screen.getByRole('checkbox', { name: 'buyout toggle' }));
      await waitFor(() => {
        expect(screen.getByTestId('confirmationBox')).toBeInTheDocument();
      });

      const yesBtn = screen.getByText('Yes');
      fireEvent.click(yesBtn);
      await waitFor(() => {
        expect(screen.queryByTestId('confirmationBox')).not.toBeInTheDocument();
      });
    });
    it('should test that check avaiability link is visible when in store pickup is enabled', async () => {
      const { props } = getProps(true);
      const props1 = {
        ...props,
        PdpBuyoutToggle: true,
        isBuyoutEligible: true,
        buyOutDetail: true,
        buyOutAccepted: true,
        cartDetails: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  mobileNumber: 5185673926,
                  installmentInfo: { installmentTerm: 24 },
                  itemsInfo: [{ cartItems: { cartItem: [{ cartItemType: 'DEVICE', priceType: 'DEVICE_PAYMENT' }] } }],
                },
              ],
            },
          },
        },
        groupByColors: jest.fn(),
        setBuyoutToggleChange: jest.fn(),
      };
      render(<DeviceInfo {...props} {...props1} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
      expect(screen.queryByTestId('insuranceSel')).toBeNull();
      expect(screen.getByText(/Check availability/i)).toBeInTheDocument();
      fireEvent.keyPress(screen.getByText(/Check availability/i));
      fireEvent.click(screen.getByText(/Check availability/i));
      expect(screen.queryByTestId('insuranceSel')).toBeInTheDocument();
      fireEvent.click(screen.getByTestId('viewDetails'));
      fireEvent.keyPress(screen.getByTestId('viewDetails'), { key: 'Enter', charCode: 13 });
      fireEvent.click(screen.getByRole('checkbox', { name: 'buyout toggle' }));
      await waitFor(() => {
        expect(screen.getByTestId('confirmationBox')).toBeInTheDocument();
      });

      const yesBtn = screen.getByText('No');
      fireEvent.click(yesBtn);
      await waitFor(() => {
        expect(screen.queryByTestId('confirmationBox')).not.toBeInTheDocument();
      });
    });
  });
});

describe('<DeviceInfo/> Notification ClassName', () => {
  // This will clean up the spy after each test
  afterEach(() => {
    jest.restoreAllMocks();
    delete window.mfe;
  });

  it('should have "top-fixed-IS" class when isProspectNewCustomerTab is true', () => {
    window.mfe = { isProspectNewCustomerTab: true, scmUpgradeMfeEnable: true };

    // Create a spy on the imported module and mock its implementation
    jest.spyOn(DomService, 'getQueryParamByName').mockImplementation((param) => {
      if (param === 'eSim') return 'true';
      return null;
    });

    const { props } = getProps();
    render(<DeviceInfo {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    const notificationDiv = screen.getByTestId('notificationError');
    expect(notificationDiv).toBeInTheDocument();
    expect(notificationDiv).toHaveClass('top-fixed-IS');
    expect(notificationDiv).not.toHaveClass('top-fixed-scm');
  });

  it('should have "top-fixed-scm" class when isProspectNewCustomerTab is false', () => {
    window.mfe = { isProspectNewCustomerTab: false, scmUpgradeMfeEnable: true };

    // Create the spy again for this test
    jest.spyOn(DomService, 'getQueryParamByName').mockImplementation((param) => {
      if (param === 'eSim') return 'true';
      return null;
    });

    const { props } = getProps();
    render(<DeviceInfo {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    const notificationDiv = screen.getByTestId('notificationError');
    expect(notificationDiv).toBeInTheDocument();
    expect(notificationDiv).toHaveClass('top-fixed-scm');
    expect(notificationDiv).not.toHaveClass('top-fixed-IS');
  });
});

describe('DeviceInfo - handleBestBuyPricingDetails with ispuUpdatedZipCode', () => {
  let mockGetBbyPricingDetails;

  beforeEach(() => {
    sessionStorage.clear();
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({}));
    sessionStorage.setItem('locationZipCode', '12345');
    mockGetBbyPricingDetails = jest.fn();
  });

  afterEach(() => {
    jest.clearAllMocks();
    sessionStorage.clear();
  });

  describe('sessionStorage.getItem("ispuUpdatedZipCode") - Postal Code Priority', () => {
    it('should use ispuUpdatedZipCode when available over locationZipCode', () => {
      sessionStorage.setItem('ispuUpdatedZipCode', '99999');
      sessionStorage.setItem('locationZipCode', '12345');
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          bestBuyIntegrationFFlag: 'TRUE',
          bestBuyPricingDetailsApiUiIntegrationFFlag: 'TRUE',
          bestBuyISPUEnableLocalOrderFFlag: 'TRUE',
        }),
      );

      const { props } = getProps();
      const testProps = {
        ...props,
        isBBYLocalOrder: true,
        upcCodeFromPdpScan: '123456789012',
        skuRealAgentCode: '1234',
        lcLocationCode: 'LC001',
        getBbyPricingDetails: mockGetBbyPricingDetails,
        setBbPaymentOptionsSelected: jest.fn(),
      };

      render(<DeviceInfo {...testProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      // Wait for the API call
      waitFor(() => {
        expect(mockGetBbyPricingDetails).toHaveBeenCalled();
        const callArgs = mockGetBbyPricingDetails.mock.calls[0][0];
        expect(callArgs.body.postalCode).toBe('99999');
      });
    });

    it('should use locationZipCode when ispuUpdatedZipCode is not available', () => {
      sessionStorage.setItem('locationZipCode', '54321');
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          bestBuyIntegrationFFlag: 'TRUE',
          bestBuyPricingDetailsApiUiIntegrationFFlag: 'TRUE',
        }),
      );

      const { props } = getProps();
      const testProps = {
        ...props,
        isBBYLocalOrder: true,
        upcCodeFromPdpScan: '123456789012',
        skuRealAgentCode: '1234',
        lcLocationCode: 'LC001',
        getBbyPricingDetails: mockGetBbyPricingDetails,
        setBbPaymentOptionsSelected: jest.fn(),
      };

      render(<DeviceInfo {...testProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      waitFor(() => {
        if (mockGetBbyPricingDetails.mock.calls.length > 0) {
          const callArgs = mockGetBbyPricingDetails.mock.calls[0][0];
          expect(callArgs.body.postalCode).toBe('54321');
        }
      });
    });

    it('should use empty string when neither ispuUpdatedZipCode nor locationZipCode are available', () => {
      sessionStorage.removeItem('ispuUpdatedZipCode');
      sessionStorage.removeItem('locationZipCode');
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          bestBuyIntegrationFFlag: 'TRUE',
          bestBuyPricingDetailsApiUiIntegrationFFlag: 'TRUE',
        }),
      );

      const { props } = getProps();
      const testProps = {
        ...props,
        isBBYLocalOrder: true,
        upcCodeFromPdpScan: '123456789012',
        skuRealAgentCode: '1234',
        lcLocationCode: 'LC001',
        getBbyPricingDetails: mockGetBbyPricingDetails,
        setBbPaymentOptionsSelected: jest.fn(),
      };

      render(<DeviceInfo {...testProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      waitFor(() => {
        if (mockGetBbyPricingDetails.mock.calls.length > 0) {
          const callArgs = mockGetBbyPricingDetails.mock.calls[0][0];
          expect(callArgs.body.postalCode).toBe('');
        }
      });
    });
  });

  describe('sessionStorage.removeItem("ispuUpdatedZipCode") - Cleanup Logic', () => {
    it('should remove ispuUpdatedZipCode from sessionStorage when it exists', () => {
      sessionStorage.setItem('ispuUpdatedZipCode', '88888');
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          bestBuyIntegrationFFlag: 'TRUE',
          bestBuyPricingDetailsApiUiIntegrationFFlag: 'TRUE',
        }),
      );

      expect(sessionStorage.getItem('ispuUpdatedZipCode')).toBe('88888');

      const { props } = getProps();
      const testProps = {
        ...props,
        isBBYLocalOrder: true,
        upcCodeFromPdpScan: '123456789012',
        skuRealAgentCode: '1234',
        lcLocationCode: 'LC001',
        getBbyPricingDetails: mockGetBbyPricingDetails,
        setBbPaymentOptionsSelected: jest.fn(),
      };

      render(<DeviceInfo {...testProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      // Wait for the removal to occur
      waitFor(() => {
        expect(sessionStorage.getItem('ispuUpdatedZipCode')).toBeNull();
      });
    });

    it('should NOT attempt to remove ispuUpdatedZipCode when it does not exist', () => {
      sessionStorage.removeItem('ispuUpdatedZipCode');
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          bestBuyIntegrationFFlag: 'TRUE',
          bestBuyPricingDetailsApiUiIntegrationFFlag: 'TRUE',
        }),
      );

      const removeItemSpy = jest.spyOn(Storage.prototype, 'removeItem');

      const { props } = getProps();
      const testProps = {
        ...props,
        isBBYLocalOrder: true,
        upcCodeFromPdpScan: '123456789012',
        skuRealAgentCode: '1234',
        lcLocationCode: 'LC001',
        getBbyPricingDetails: mockGetBbyPricingDetails,
        setBbPaymentOptionsSelected: jest.fn(),
      };

      render(<DeviceInfo {...testProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      // Verify that ispuUpdatedZipCode was not attempted to be removed since it doesn't exist
      expect(sessionStorage.getItem('ispuUpdatedZipCode')).toBeNull();

      removeItemSpy.mockRestore();
    });

    it('should remove ispuUpdatedZipCode BEFORE making the API call', () => {
      sessionStorage.setItem('ispuUpdatedZipCode', '77777');
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          bestBuyIntegrationFFlag: 'TRUE',
          bestBuyPricingDetailsApiUiIntegrationFFlag: 'TRUE',
        }),
      );

      let zipCodeInStorageWhenApiCalled = null;
      const mockGetBbyPricingDetailsWithCheck = jest.fn(() => {
        // Capture the sessionStorage state when API is called
        zipCodeInStorageWhenApiCalled = sessionStorage.getItem('ispuUpdatedZipCode');
      });

      const { props } = getProps();
      const testProps = {
        ...props,
        isBBYLocalOrder: true,
        upcCodeFromPdpScan: '123456789012',
        skuRealAgentCode: '1234',
        lcLocationCode: 'LC001',
        getBbyPricingDetails: mockGetBbyPricingDetailsWithCheck,
        setBbPaymentOptionsSelected: jest.fn(),
      };

      render(<DeviceInfo {...testProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      waitFor(() => {
        if (mockGetBbyPricingDetailsWithCheck.mock.calls.length > 0) {
          // Verify that sessionStorage was cleared BEFORE the API call
          expect(zipCodeInStorageWhenApiCalled).toBeNull();
        }
      });
    });
  });

  describe('Integration - Full Flow with ispuUpdatedZipCode', () => {
    it('should use ispuUpdatedZipCode, then remove it, then make API call with correct postalCode', () => {
      const testZipCode = '66666';
      sessionStorage.setItem('ispuUpdatedZipCode', testZipCode);
      sessionStorage.setItem('locationZipCode', '00000');
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          bestBuyIntegrationFFlag: 'TRUE',
          bestBuyPricingDetailsApiUiIntegrationFFlag: 'TRUE',
        }),
      );

      const { props } = getProps();
      const testProps = {
        ...props,
        isBBYLocalOrder: true,
        upcCodeFromPdpScan: '123456789012',
        skuRealAgentCode: '5678',
        lcLocationCode: 'LC002',
        getBbyPricingDetails: mockGetBbyPricingDetails,
        setBbPaymentOptionsSelected: jest.fn(),
      };

      render(<DeviceInfo {...testProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      waitFor(() => {
        // Check that the API was called with the ispuUpdatedZipCode value
        if (mockGetBbyPricingDetails.mock.calls.length > 0) {
          const callArgs = mockGetBbyPricingDetails.mock.calls[0][0];
          expect(callArgs.body.postalCode).toBe(testZipCode);

          // Verify that ispuUpdatedZipCode was removed after use
          expect(sessionStorage.getItem('ispuUpdatedZipCode')).toBeNull();

          // Verify locationZipCode is still present
          expect(sessionStorage.getItem('locationZipCode')).toBe('00000');
        }
      });
    });

    it('should handle multiple API calls and only use ispuUpdatedZipCode once', () => {
      sessionStorage.setItem('ispuUpdatedZipCode', '11111');
      sessionStorage.setItem('locationZipCode', '22222');
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          bestBuyIntegrationFFlag: 'TRUE',
          bestBuyPricingDetailsApiUiIntegrationFFlag: 'TRUE',
        }),
      );

      const { props } = getProps();
      const testProps = {
        ...props,
        isBBYLocalOrder: true,
        upcCodeFromPdpScan: '123456789012',
        skuRealAgentCode: '1234',
        lcLocationCode: 'LC001',
        getBbyPricingDetails: mockGetBbyPricingDetails,
        setBbPaymentOptionsSelected: jest.fn(),
      };

      const { rerender } = render(<DeviceInfo {...testProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      waitFor(() => {
        if (mockGetBbyPricingDetails.mock.calls.length > 0) {
          // First call should use ispuUpdatedZipCode
          const firstCallArgs = mockGetBbyPricingDetails.mock.calls[0][0];
          expect(firstCallArgs.body.postalCode).toBe('11111');

          // ispuUpdatedZipCode should be removed
          expect(sessionStorage.getItem('ispuUpdatedZipCode')).toBeNull();
        }
      });

      // Re-render to trigger another API call
      rerender(<DeviceInfo {...testProps} />);

      waitFor(() => {
        if (mockGetBbyPricingDetails.mock.calls.length > 1) {
          // Second call should use locationZipCode since ispuUpdatedZipCode is cleared
          const secondCallArgs = mockGetBbyPricingDetails.mock.calls[1][0];
          expect(secondCallArgs.body.postalCode).toBe('22222');
        }
      });
    });

    it('should handle the case where ispuUpdatedZipCode is set after initial render', () => {
      sessionStorage.setItem('locationZipCode', '33333');
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          bestBuyIntegrationFFlag: 'TRUE',
          bestBuyPricingDetailsApiUiIntegrationFFlag: 'TRUE',
        }),
      );

      const { props } = getProps();
      const testProps = {
        ...props,
        isBBYLocalOrder: true,
        upcCodeFromPdpScan: '123456789012',
        skuRealAgentCode: '1234',
        lcLocationCode: 'LC001',
        getBbyPricingDetails: mockGetBbyPricingDetails,
        setBbPaymentOptionsSelected: jest.fn(),
      };

      render(<DeviceInfo {...testProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      waitFor(() => {
        if (mockGetBbyPricingDetails.mock.calls.length > 0) {
          // First call should use locationZipCode
          const firstCallArgs = mockGetBbyPricingDetails.mock.calls[0][0];
          expect(firstCallArgs.body.postalCode).toBe('33333');
        }
      });

      // Now set ispuUpdatedZipCode
      sessionStorage.setItem('ispuUpdatedZipCode', '44444');

      waitFor(() => {
        if (mockGetBbyPricingDetails.mock.calls.length > 1) {
          // Next call should use ispuUpdatedZipCode
          const nextCallArgs = mockGetBbyPricingDetails.mock.calls[1][0];
          expect(nextCallArgs.body.postalCode).toBe('44444');

          // And it should be removed after use
          expect(sessionStorage.getItem('ispuUpdatedZipCode')).toBeNull();
        }
      });
    });
  });

  describe('Edge Cases', () => {
    it('should handle null ispuUpdatedZipCode gracefully', () => {
      sessionStorage.setItem('ispuUpdatedZipCode', null);
      sessionStorage.setItem('locationZipCode', '12345');
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          bestBuyIntegrationFFlag: 'TRUE',
          bestBuyPricingDetailsApiUiIntegrationFFlag: 'TRUE',
        }),
      );

      const { props } = getProps();
      const testProps = {
        ...props,
        isBBYLocalOrder: true,
        upcCodeFromPdpScan: '123456789012',
        skuRealAgentCode: '1234',
        lcLocationCode: 'LC001',
        getBbyPricingDetails: mockGetBbyPricingDetails,
        setBbPaymentOptionsSelected: jest.fn(),
      };

      render(<DeviceInfo {...testProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      waitFor(() => {
        if (mockGetBbyPricingDetails.mock.calls.length > 0) {
          const callArgs = mockGetBbyPricingDetails.mock.calls[0][0];
          // Should fall back to locationZipCode
          expect(callArgs.body.postalCode).toBeTruthy();
        }
      });
    });

    it('should handle empty string ispuUpdatedZipCode', () => {
      sessionStorage.setItem('ispuUpdatedZipCode', '');
      sessionStorage.setItem('locationZipCode', '55555');
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          bestBuyIntegrationFFlag: 'TRUE',
          bestBuyPricingDetailsApiUiIntegrationFFlag: 'TRUE',
        }),
      );

      const { props } = getProps();
      const testProps = {
        ...props,
        isBBYLocalOrder: true,
        upcCodeFromPdpScan: '123456789012',
        skuRealAgentCode: '1234',
        lcLocationCode: 'LC001',
        getBbyPricingDetails: mockGetBbyPricingDetails,
        setBbPaymentOptionsSelected: jest.fn(),
      };

      render(<DeviceInfo {...testProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      waitFor(() => {
        if (mockGetBbyPricingDetails.mock.calls.length > 0) {
          const callArgs = mockGetBbyPricingDetails.mock.calls[0][0];
          // Should use locationZipCode since ispuUpdatedZipCode is empty
          expect(callArgs.body.postalCode).toBe('55555');
        }
      });
    });

    it('should not break when sessionStorage operations fail', () => {
      // Mock sessionStorage to throw errors
      const originalGetItem = Storage.prototype.getItem;
      const originalRemoveItem = Storage.prototype.removeItem;

      Storage.prototype.getItem = jest.fn(() => {
        throw new Error('Storage error');
      });
      Storage.prototype.removeItem = jest.fn(() => {
        throw new Error('Storage error');
      });

      const { props } = getProps();
      const testProps = {
        ...props,
        isBBYLocalOrder: true,
        upcCodeFromPdpScan: '123456789012',
        skuRealAgentCode: '1234',
        lcLocationCode: 'LC001',
        getBbyPricingDetails: mockGetBbyPricingDetails,
        setBbPaymentOptionsSelected: jest.fn(),
      };

      // Should not throw an error
      expect(() => {
        render(<DeviceInfo {...testProps} />, {
          reducers: rootReducer,
          sagas: rootSaga,
        });
      }).not.toThrow();

      // Restore original methods
      Storage.prototype.getItem = originalGetItem;
      Storage.prototype.removeItem = originalRemoveItem;
    });
  });
});

describe('DeviceInfo - Professional Install Line 365 Coverage', () => {
  beforeEach(() => {
    sessionStorage.clear();
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({}));
    sessionStorage.setItem(
      'assistedFlags',
      JSON.stringify({
        bestBuyIntegrationFFlag: 'TRUE',
      }),
    );
  });

  afterEach(() => {
    sessionStorage.clear();
  });

  it('should cover line 365 with both conditions true', () => {
    const { props } = getProps();
    const testProps = {
      ...props,
      isVbgProfessionalInstall: true,
      devices: {
        isProfessionalInstallDevice: true,
        deviceSku: 'TEST123',
        deviceName: 'Test Device',
      },
    };

    const { container } = render(<DeviceInfo {...testProps} />);
    expect(container).toBeDefined();
  });

  it('should cover line 365 with isVbgProfessionalInstall false', () => {
    const { props } = getProps();
    const testProps = {
      ...props,
      isVbgProfessionalInstall: false,
      devices: {
        isProfessionalInstallDevice: true,
        deviceSku: 'TEST123',
      },
    };

    const { container } = render(<DeviceInfo {...testProps} />);
    expect(container).toBeDefined();
  });

  it('should cover line 365 with null devices (optional chaining)', () => {
    const { props } = getProps();
    const testProps = {
      ...props,
      isVbgProfessionalInstall: true,
      devices: null,
    };

    const { container } = render(<DeviceInfo {...testProps} />);
    expect(container).toBeDefined();
  });

  it('should cover line 365 with undefined isProfessionalInstallDevice', () => {
    const { props } = getProps();
    const testProps = {
      ...props,
      isVbgProfessionalInstall: true,
      devices: {
        deviceSku: 'TEST123',
        // isProfessionalInstallDevice is undefined
      },
    };

    const { container } = render(<DeviceInfo {...testProps} />);
    expect(container).toBeDefined();
  });
});

/* eslint-disable global-require */
describe('DeviceInfo - bbyPricingDetails Error Handling in useEffect', () => {
  beforeEach(() => {
    sessionStorage.clear();
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({}));

    // Mock the RTK Query hook
    // eslint-disable-next-line global-require
    jest
      .spyOn(require('../../modules/services/APIService/APIServiceHooks'), 'useLazyGetBestBuyInventoryQuery')
      .mockReturnValue([jest.fn(), {}]);
  });

  afterEach(() => {
    jest.clearAllMocks();
    sessionStorage.clear();
  });

  it('should dispatch clearAppMessages and addAppMessage when bbyPricingDetails has errors', async () => {
    const errorResponse = {
      devicePricingDetails: {},
      errors: [
        {
          id: '195950626179',
          message: 'Unable to retrieve availability details for these UPCs.',
          msgType: 'D',
          cfeMsg: false,
        },
        {
          name: 'bbySkuDetails',
          id: '00281',
          message: 'Unable to retrieve bby Sku details for a given upc, please try again later.',
          type: '1',
          category: 'CDC_MOBILE',
          msgType: 'D',
          cfeMsg: false,
        },
      ],
    };

    // Mock the hook to return error response
    // eslint-disable-next-line global-require
    jest
      .spyOn(require('../../modules/services/APIService/APIServiceHooks'), 'useLazyGetBestBuyInventoryQuery')
      .mockReturnValue([
        jest.fn(),
        {
          data: errorResponse,
          isSuccess: true,
          status: 'fulfilled',
        },
      ]);

    // Mock getAssistedCradlePropertyV2 to return feature flags
    jest.spyOn(require('onevzsoemfeframework/AssistedCradleService'), 'getAssistedCradlePropertyV2').mockReturnValue([
      'FALSE', // enableEUPDualNum
      '', // dropshipProdcode5
      'FALSE', // enableDropship
      'TRUE', // bestBuyIntegrationFFlag
      'FALSE', // dppIndicatorFFlag
      'FALSE', // copyPasteIconFFlag
      'FALSE', // indirectFlexLocalOnlyFFlag
      'FALSE', // removeDPPoptionFFlag
      'FALSE', // dwosIndirectFFlag
      'TRUE', // bestBuyPricingDetailsApiUiIntegrationFFlag
      'FALSE', // bestBuyISPUEnableLocalOrderFFlag
    ]);

    const { props } = getProps();
    const testProps = {
      ...props,
      isBBYLocalOrder: true,
      upcCodeFromPdpScan: '123456789012',
      skuRealAgentCode: '1234',
      lcLocationCode: 'LC001',
      setBbPaymentOptionsSelected: jest.fn(),
    };

    const { container } = render(<DeviceInfo {...testProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    await waitFor(
      () => {
        const notificationError = container.querySelector('[data-testid="notificationError"]');
        expect(notificationError).toBeInTheDocument();
        expect(notificationError.textContent).toContain('Unable to retrieve availability details for these UPCs.');
      },
      { timeout: 3000 },
    );
  });

  it('should display only the first error message from multiple errors', async () => {
    const errorResponse = {
      devicePricingDetails: {},
      errors: [
        {
          id: '195950626179',
          message: 'Unable to retrieve availability details for these UPCs.',
          msgType: 'D',
          cfeMsg: false,
        },
        {
          name: 'bbySkuDetails',
          id: '00281',
          message: 'Unable to retrieve bby Sku details for a given upc, please try again later.',
          type: '1',
          category: 'CDC_MOBILE',
          msgType: 'D',
          cfeMsg: false,
        },
      ],
    };

    jest
      .spyOn(require('../../modules/services/APIService/APIServiceHooks'), 'useLazyGetBestBuyInventoryQuery')
      .mockReturnValue([
        jest.fn(),
        {
          data: errorResponse,
        },
      ]);

    jest
      .spyOn(require('onevzsoemfeframework/AssistedCradleService'), 'getAssistedCradlePropertyV2')
      .mockReturnValue(['FALSE', '', 'FALSE', 'TRUE', 'FALSE', 'FALSE', 'FALSE', 'FALSE', 'FALSE', 'TRUE', 'FALSE']);

    const { props } = getProps();
    const testProps = {
      ...props,
      isBBYLocalOrder: true,
      upcCodeFromPdpScan: '123456789012',
      setBbPaymentOptionsSelected: jest.fn(),
    };

    const { container } = render(<DeviceInfo {...testProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    await waitFor(
      () => {
        const notificationError = container.querySelector('[data-testid="notificationError"]');
        expect(notificationError).toBeInTheDocument();
        // Should only show first error, not both
        expect(notificationError.textContent).toContain('Unable to retrieve availability details for these UPCs.');
        expect(notificationError.textContent).not.toContain('Unable to retrieve bby Sku details');
      },
      { timeout: 3000 },
    );
  });

  it('should use fallback error message when error message is empty or undefined', async () => {
    const errorResponse = {
      devicePricingDetails: {},
      errors: [
        {
          id: '12345',
          message: undefined,
          msgType: 'D',
          cfeMsg: false,
        },
      ],
    };

    jest
      .spyOn(require('../../modules/services/APIService/APIServiceHooks'), 'useLazyGetBestBuyInventoryQuery')
      .mockReturnValue([
        jest.fn(),
        {
          data: errorResponse,
        },
      ]);

    jest
      .spyOn(require('onevzsoemfeframework/AssistedCradleService'), 'getAssistedCradlePropertyV2')
      .mockReturnValue(['FALSE', '', 'FALSE', 'TRUE', 'FALSE', 'FALSE', 'FALSE', 'FALSE', 'FALSE', 'TRUE', 'FALSE']);

    const { props } = getProps();
    const testProps = {
      ...props,
      isBBYLocalOrder: true,
      upcCodeFromPdpScan: '123456789012',
      setBbPaymentOptionsSelected: jest.fn(),
    };

    const { container } = render(<DeviceInfo {...testProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    await waitFor(
      () => {
        const notificationError = container.querySelector('[data-testid="notificationError"]');
        expect(notificationError).toBeInTheDocument();
        expect(notificationError.textContent).toContain('Something went wrong, kindly try again.');
      },
      { timeout: 3000 },
    );
  });

  it('should set BByPricing when apiPricing exists and has valid data', async () => {
    it('should set BByPricing when apiPricing has valid data without showing errors', async () => {
      const successResponse = {
        devicePricingDetails: {
          priceInfo: [
            {
              priceId: 'cnt302',
              activationType: 'upgrade',
              purchaseType: 'FINANCED',
              contractTerm: 36,
              regularPrice: 8.33,
              currentPrice: 8.33,
            },
          ],
        },
        errors: [],
      };

      jest
        .spyOn(require('../../modules/services/APIService/APIServiceHooks'), 'useLazyGetBestBuyInventoryQuery')
        .mockReturnValue([
          jest.fn(),
          {
            data: successResponse,
          },
        ]);

      jest
        .spyOn(require('onevzsoemfeframework/AssistedCradleService'), 'getAssistedCradlePropertyV2')
        .mockReturnValue(['FALSE', '', 'FALSE', 'TRUE', 'FALSE', 'FALSE', 'FALSE', 'FALSE', 'FALSE', 'TRUE', 'FALSE']);

      const { props } = getProps();
      const testProps = {
        ...props,
        isBBYLocalOrder: true,
        upcCodeFromPdpScan: '123456789012',
        setBbPaymentOptionsSelected: jest.fn(),
      };

      const { container } = render(<DeviceInfo {...testProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      await waitFor(
        () => {
          // Verify no error messages are displayed
          const notificationError = container.querySelector('[data-testid="notificationError"]');
          expect(notificationError).not.toBeInTheDocument();
        },
        { timeout: 3000 },
      );
    });
    it('should handle error response from bbyPricingDetailsResult.error.data', async () => {
      const errorResponse = {
        devicePricingDetails: {},
        errors: [
          {
            id: 'ERROR001',
            message: 'API Error from error.data',
            msgType: 'D',
            cfeMsg: false,
          },
        ],
      };

      jest
        .spyOn(require('../../modules/services/APIService/APIServiceHooks'), 'useLazyGetBestBuyInventoryQuery')
        .mockReturnValue([
          jest.fn(),
          {
            error: {
              data: errorResponse,
            },
            isError: true,
            status: 'rejected',
          },
        ]);

      jest
        .spyOn(require('onevzsoemfeframework/AssistedCradleService'), 'getAssistedCradlePropertyV2')
        .mockReturnValue(['FALSE', '', 'FALSE', 'TRUE', 'FALSE', 'FALSE', 'FALSE', 'FALSE', 'FALSE', 'TRUE', 'FALSE']);

      const { props } = getProps();
      const testProps = {
        ...props,
        isBBYLocalOrder: true,
        upcCodeFromPdpScan: '123456789012',
        setBbPaymentOptionsSelected: jest.fn(),
      };

      const { container } = render(<DeviceInfo {...testProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      await waitFor(
        () => {
          const notificationError = container.querySelector('[data-testid="notificationError"]');
          expect(notificationError).toBeInTheDocument();
          expect(notificationError.textContent).toContain('API Error from error.data');
        },
        { timeout: 3000 },
      );
    });

    it('should handle empty devicePricingDetails without errors array', async () => {
      const emptyResponse = {
        devicePricingDetails: {},
      };

      jest
        .spyOn(require('../../modules/services/APIService/APIServiceHooks'), 'useLazyGetBestBuyInventoryQuery')
        .mockReturnValue([
          jest.fn(),
          {
            data: emptyResponse,
          },
        ]);

      jest
        .spyOn(require('onevzsoemfeframework/AssistedCradleService'), 'getAssistedCradlePropertyV2')
        .mockReturnValue(['FALSE', '', 'FALSE', 'TRUE', 'FALSE', 'FALSE', 'FALSE', 'FALSE', 'FALSE', 'TRUE', 'FALSE']);

      const { props } = getProps();
      const testProps = {
        ...props,
        isBBYLocalOrder: true,
        upcCodeFromPdpScan: '123456789012',
        setBbPaymentOptionsSelected: jest.fn(),
      };

      const { container } = render(<DeviceInfo {...testProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      await waitFor(
        () => {
          const notificationError = container.querySelector('[data-testid="notificationError"]');
          expect(notificationError).not.toBeInTheDocument();
        },
        { timeout: 2000 },
      );
    });

    it('should execute clearAppMessages before addAppMessage to prevent duplicate errors', async () => {
      const errorResponse = {
        devicePricingDetails: {},
        errors: [
          {
            id: '195950626179',
            message: 'Duplicate error test',
            msgType: 'D',
            cfeMsg: false,
          },
        ],
      };

      jest
        .spyOn(require('../../modules/services/APIService/APIServiceHooks'), 'useLazyGetBestBuyInventoryQuery')
        .mockReturnValue([
          jest.fn(),
          {
            data: errorResponse,
          },
        ]);

      jest
        .spyOn(require('onevzsoemfeframework/AssistedCradleService'), 'getAssistedCradlePropertyV2')
        .mockReturnValue(['FALSE', '', 'FALSE', 'TRUE', 'FALSE', 'FALSE', 'FALSE', 'FALSE', 'FALSE', 'TRUE', 'FALSE']);

      const { props } = getProps();
      const testProps = {
        ...props,
        isBBYLocalOrder: true,
        upcCodeFromPdpScan: '123456789012',
        setBbPaymentOptionsSelected: jest.fn(),
      };

      const { container } = render(<DeviceInfo {...testProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      await waitFor(
        () => {
          const notificationErrors = container.querySelectorAll('[data-testid="notificationError"]');
          // Should only have one error message, not duplicates
          expect(notificationErrors.length).toBe(1);
          expect(notificationErrors[0].textContent).toContain('Duplicate error test');
        },
        { timeout: 3000 },
      );
    });

    test('should cover isSelectedDeviceByod condition with selectedPlanId === Productdetail_MonthlyPayments', async () => {
      // Mock GetAppConfig at module level
      const GetAppConfigModule = require('../../../modules/utils/GetAppConfig');
      const mockGetAppConfig = jest.fn().mockReturnValue({
        urls: {
          getTrialDeviceDetail: '/api/trialDevice',
          productList: '/api/products',
          getDetails: '/api/details',
          getProtectionFeatures: '/api/protection',
          dpEligibility: '/api/dpEligibility',
          fetchDownPayment: '/api/downPayment',
          retrieveURC: '/api/urc',
          getInventoryDetails: '/api/inventory',
          checkInStoreAvailability: '/api/store',
          checkZipcodeISPUEligibility: '/api/zipcode',
          getSkuList: '/api/sku',
          eSimDetails: '/api/esim',
        },
        messages: {
          dqContent: {
            byodUltimatePlanIDs: ['26872'], // This should match the planId in customerProfileDetails
          },
        },
      });
      GetAppConfigModule.GetAppConfig = mockGetAppConfig;

      // Mock byodPlusUltimateDPPFFlag to return TRUE
      jest
        .spyOn(require('onevzsoemfeframework/AssistedCradleService'), 'getAssistedCradlePropertyV2')
        .mockImplementation((args) => {
          if (args && args[0] === 'byodPlusUltimateDPPFFlag') {
            return ['TRUE'];
          }
          // Return default values for other flags
          return ['', 'UNL', 'FALSE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', '', 'TRUE'];
        });

      const { props } = getProps();

      // Override selectedSku to include devicePaymentPrice
      const testProps = {
        ...props,
        selectedSku: {
          ...props.selectedSku,
          sorId: 'test-sku-123',
          price: {
            devicePaymentPrice: [
              {
                originalPrice: '30.00',
                contractDuration: 36,
                dpTermPrices: {
                  remainingMonthPrice: '30.00',
                },
              },
            ],
            fullRetailPrice: {
              originalPrice: '1080.00',
            },
          },
        },
        selectedPaymentInfo: {
          contractType: 'DEVICE_PAYMENT',
          price: '30.00',
          term: 36,
        },
        // Ensure customerProfileDetails has the right structure with planId 26872
        customerProfileDetails: {
          ...props.customerProfileDetails,
          customer: {
            ...props.customerProfileDetails?.customer,
            billAccounts: [
              {
                mtns: [
                  {
                    mtn: '5185673926', // This matches activeMtn
                    pricePlanInfo: {
                      planId: '26872', // This matches byodUltimatePlanIDs
                    },
                    equipmentInfos: [
                      {
                        deviceInfo: { deviceId: '' },
                        simInfo: { simId: '' },
                      },
                    ],
                  },
                ],
              },
            ],
          },
        },
        activeMtn: '5185673926',
      };

      const { container } = render(<DeviceInfo {...testProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      // Wait for useEffect to set selectedPlanId to 'Productdetail_MonthlyPayments'
      await waitFor(
        () => {
          expect(container).toBeTruthy();
        },
        { timeout: 3000 },
      );

      // Additional wait to ensure all useEffects have fired
      await new Promise((resolve) => {
        setTimeout(resolve, 500);
      });

      // The component should have rendered with isSelectedDeviceByod = true
      expect(container).toBeTruthy();
    });
  });
  /* eslint-enable global-require */
});

describe('DeviceInfo - isSelectedDeviceByod computation', () => {
  beforeEach(() => {
   footerPropsSpy = null;

    // Make BYOD flag TRUE:
    // byodPlusUltimateDPPFFlag = /true/i.test(getAssistedCradlePropertyV2(['byodPlusUltimateDPPFFlag'])?.[0])
    getAssistedCradlePropertyV2.mockImplementation((keys) => {
      if (Array.isArray(keys) && keys.includes('byodPlusUltimateDPPFFlag')) return ['true'];
      return ['false'];
    });

    // Use VBG path to simplify default selectedPlanId setup via useEffect
    // radioboxGroupDefaultValue = () => isVbgFlag ? displayPaymentOptions()?.[0]?.value : ...
    isVbg.mockReturnValue(true);

    // AppConfig provides byodUltimatePlanIDs and MUST include selectedDevicePlanId
    GetAppConfig.mockReturnValue({
      messages: {
        dqContent: {
          byodUltimatePlanIDs: ['PLAN_ULT_123', 'PLAN_ULT_999'],
        },
      },
    });

    // Some code references window.mfe
    window.mfe = window.mfe || {};
  });

  it('sets isSelectedDeviceByod=true when all conditions match', async () => {
    render(<DeviceInfo {...baseProps()} />);

    // selectedPlanId is set asynchronously by useEffect when byodPlusUltimateDPPFFlag is true
    // so wait until Footer receives computed prop = true
    await waitFor(() => {
      expect(footerPropsSpy).toBeTruthy();
      expect(footerPropsSpy.isSelectedDeviceByod).toBe(true);
    });
  });

  it('sets isSelectedDeviceByod=false when planId is not in byodUltimatePlanIDs', async () => {
    GetAppConfig.mockReturnValueOnce({
      messages: { dqContent: { byodUltimatePlanIDs: ['SOME_OTHER_PLAN'] } },
    });

    render(<DeviceInfo {...baseProps()} />);

    await waitFor(() => {
      expect(footerPropsSpy).toBeTruthy();
      expect(footerPropsSpy.isSelectedDeviceByod).toBe(false);
    });
  });
});
});

describe('DeviceInfo - getLabelName with deviceColorLabelPDPFFlag', () => {
  const mockGroupByColorsData = [
    {
      color: 'Space Black',
      colorCssStyle: '#1E1D1B',
      skus: [
        {
          color: { colorCssStyle: '#1E1D1B', colorId: 'clr12240018', description: 'Black', displayName: 'Space Black' },
          capacity: '128 GB',
          inventoryDetails: { dFillInventory: { isInStock: true, qtyAvailable: 100 } },
        },
      ],
    },
    {
      color: 'Deep Purple - Edition 2',
      colorCssStyle: '#655D6C',
      skus: [
        {
          color: { colorCssStyle: '#655D6C', colorId: 'clr12200029', description: 'Purple', displayName: 'Deep Purple - Edition 2' },
          capacity: '128 GB',
          inventoryDetails: { dFillInventory: { isInStock: true, qtyAvailable: 50 } },
        },
      ],
    },
  ];

  let originalGetItem;

  beforeEach(() => {
    // Preserve original
    originalGetItem = Storage.prototype.getItem;
    // Safe guard: if APP_PROPERTIES or assistedFlags are missing or 'undefined', return '{}'
    Storage.prototype.getItem = jest.fn((key) => {
      try {
        const val = originalGetItem.call(sessionStorage, key);
        if ((key === 'APP_PROPERTIES' || key === 'assistedFlags') && (val === null || val === undefined || val === 'undefined')) {
          return '{}';
        }
        return val;
      } catch (e) {
        if (key === 'APP_PROPERTIES' || key === 'assistedFlags') return '{}';
        return null;
      }
    });

    sessionStorage.clear();
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({
      earlyUpgradeOrderVVCFFlag: 'FALSE',
      shipToggleFFlag: 'FALSE',
      isVVCFlowEnabled: 'FALSE',
    }));
    sessionStorage.setItem('assistedFlags', JSON.stringify({ isVVCFlowEnabled: 'FALSE' }));
  });

  afterEach(() => {
    jest.restoreAllMocks();
    // Restore original getItem
    Storage.prototype.getItem = originalGetItem;
    sessionStorage.clear();
  });

  it('should preserve special characters in color label when deviceColorLabelPDPFFlag is TRUE', () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({
      earlyUpgradeOrderVVCFFlag: 'FALSE',
      shipToggleFFlag: 'FALSE',
      deviceColorLabelPDPFFlag: 'TRUE',
    }));

    jest.spyOn(require('onevzsoemfeframework/AssistedCradleService'), 'getAssistedCradlePropertyV2')
      .mockImplementation((keys) => {
        return keys.map((key) => {
          if (key === 'deviceColorLabelPDPFFlag') return 'TRUE';
          return 'FALSE';
        });
      });

    const { props } = getProps();
    const testProps = {
      ...props,
      details: {
        childSkus: mockGroupByColorsData[0].skus.concat(mockGroupByColorsData[1].skus),
        defaultSKU: 'MQ0E3LL/A',
      },
      groupByColors: jest.fn(() => mockGroupByColorsData),
      setBuyoutToggleChange: jest.fn(),
    };

    const { container } = render(<DeviceInfo {...testProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    // Wait for the component to fully render
    waitFor(() => {
      // The label should contain the full color name with special characters
      expect(container.textContent).toContain('Deep Purple - Edition 2');
    });
  });

  it('should strip non-alphabetic characters from color label when deviceColorLabelPDPFFlag is FALSE', () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({
      earlyUpgradeOrderVVCFFlag: 'FALSE',
      shipToggleFFlag: 'FALSE',
      deviceColorLabelPDPFFlag: 'FALSE',
    }));

    jest.spyOn(require('onevzsoemfeframework/AssistedCradleService'), 'getAssistedCradlePropertyV2')
      .mockImplementation((keys) => {
        return keys.map((key) => {
          if (key === 'deviceColorLabelPDPFFlag') return 'FALSE';
          return 'FALSE';
        });
      });

    const { props } = getProps();
    const testProps = {
      ...props,
      details: {
        childSkus: mockGroupByColorsData[0].skus.concat(mockGroupByColorsData[1].skus),
        defaultSKU: 'MQ0E3LL/A',
      },
      groupByColors: jest.fn(() => mockGroupByColorsData),
      setBuyoutToggleChange: jest.fn(),
    };

    const { container } = render(<DeviceInfo {...testProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    waitFor(() => {
      // Should NOT contain special characters like '-' and digits
      expect(container.textContent).not.toContain('Deep Purple - Edition 2');
      // Should contain sanitized version "Deep Purple Edition" (spaces preserved, special chars removed)
      const hasSanitizedDeepPurple = /Deep Purple Edition/.test(container.textContent);
      expect(hasSanitizedDeepPurple).toBe(true);
    });
  });

  it('should strip non-alphabetic characters when deviceColorLabelPDPFFlag is not set', () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({
      earlyUpgradeOrderVVCFFlag: 'FALSE',
      shipToggleFFlag: 'FALSE',
    }));

    jest.spyOn(require('onevzsoemfeframework/AssistedCradleService'), 'getAssistedCradlePropertyV2')
      .mockImplementation((keys) => {
        return keys.map(() => 'FALSE');
      });

    const { props } = getProps();
    const testProps = {
      ...props,
      details: {
        childSkus: mockGroupByColorsData[0].skus.concat(mockGroupByColorsData[1].skus),
        defaultSKU: 'MQ0E3LL/A',
      },
      groupByColors: jest.fn(() => mockGroupByColorsData),
      setBuyoutToggleChange: jest.fn(),
    };

    const { container } = render(<DeviceInfo {...testProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    waitFor(() => {
      expect(container.textContent).not.toContain('Deep Purple - Edition 2');
      const hasSanitizedDeepPurple = /Deep Purple Edition/.test(container.textContent);
      expect(hasSanitizedDeepPurple).toBe(true);
    });
  });

  it('should handle simple color names the same regardless of deviceColorLabelPDPFFlag', () => {
    const simpleColorData = [
      {
        color: 'Gold',
        colorCssStyle: '#D0C2AE',
        skus: [
          {
            color: { colorCssStyle: '#D0C2AE', colorId: 'clr3360032', description: 'Gold', displayName: 'Gold' },
            capacity: '128 GB',
            inventoryDetails: { dFillInventory: { isInStock: true, qtyAvailable: 80 } },
          },
        ],
      },
    ];

    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({
      earlyUpgradeOrderVVCFFlag: 'FALSE',
      shipToggleFFlag: 'FALSE',
      deviceColorLabelPDPFFlag: 'TRUE',
    }));

    jest.spyOn(require('onevzsoemfeframework/AssistedCradleService'), 'getAssistedCradlePropertyV2')
      .mockImplementation((keys) => {
        return keys.map((key) => {
          if (key === 'deviceColorLabelPDPFFlag') return 'TRUE';
          return 'FALSE';
        });
      });

    const { props } = getProps();
    const testProps = {
      ...props,
      details: {
        childSkus: simpleColorData[0].skus,
        defaultSKU: 'MQ0E3LL/A',
      },
      groupByColors: jest.fn(() => simpleColorData),
      setBuyoutToggleChange: jest.fn(),
    };

    const { container } = render(<DeviceInfo {...testProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    waitFor(() => {
      // Gold has no special characters, so it should appear the same regardless of the flag
      expect(/\bGold\b/i.test(container.textContent)).toBe(true);
    });
  });
});

