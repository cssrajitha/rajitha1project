import React from 'react';
import { cloneDeep } from 'lodash';
import { render, screen } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import PDP from '../PDP';
import protectionFeatures from '../../../pages/PDP/mocks/api/getProtectionFeatures.json';
import productDetails4 from '../../../pages/PDP/mocks/api/getDetailsPreBackOrder.json';

import customerProfileDetails from '../../../pages/PDP/mocks/api/customerProfile.json';
import cartDetails from '../../../pages/PDP/mocks/api/retrieveCart.json';

const customerProfileDetails2 = cloneDeep(customerProfileDetails);
customerProfileDetails2.data.customer.billAccounts[0].paymentInfo.isBalancePastDue = true;

const productDetails5 = cloneDeep(productDetails4);
productDetails5.data.deviceProduct.childSkus[0].inventoryDetails.dFillInventory.isBackorder = true;
productDetails5.data.deviceProduct.childSkus[0].inventoryDetails.dFillInventory.isInStock = true;
productDetails5.data.deviceProduct.childSkus[0].inventoryDetails.dFillInventory.qtyAvailable = 600;

const details = productDetails4.data.deviceProduct || {};
const defaultSkuStringValue = details?.defaultSKU || '';
const defaultSkuObjValue = details?.defaultSKUObj?.sorId || '';
const defaultSku = defaultSkuStringValue !== '' ? defaultSkuStringValue : defaultSkuObjValue;
const defaultSkuDetails = details.childSkus.filter((sku) => sku.sorId && sku.sorId === defaultSku);
const RemoveLinesAPIResultWithErrorCode = {
  data: {
    errors: [
      {
        id: '9656',
      },
    ],
  },
  status: 'fulfilled',
};

const defaultSkuDetails4Array = cloneDeep(defaultSkuDetails);
const defaultSkuDetails4 = defaultSkuDetails4Array[0];
jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => false,
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);
jest.setTimeout(60000);
describe('PDP component Cannot add a Pre/Back device as Exchange device', () => {
  const activeMtn = '5185673926';
  beforeAll(() => {
    sessionStorage.setItem('refundexchange', 'true');
    const location = {
      ...window.location,
      search: `?activeMtn=${activeMtn}&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y&mtn=newLine1`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=${activeMtn}&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y&mtn=newLine1`;
  });

  beforeEach(() => {
    render(
      <PDP
        productDetails={productDetails4.data}
        cartDetails={cartDetails.data.data}
        customerProfileDetails={customerProfileDetails2.data}
        activeMtn={activeMtn}
        selectedColor={defaultSkuDetails4.color.displayName}
        setSelectedColor={jest.fn()}
        ispuToggleOn={false}
        setIspuToggleOn={jest.fn()}
        isShipItToggleOn={false}
        setIsShipItToggleOn={jest.fn()}
        selectedSku={defaultSkuDetails4}
        setSelectedSku={jest.fn()}
        selectedProtectionFeature={protectionFeatures.payload.features[1]}
        setSelectedProtectionFeature={jest.fn()}
        selectedSize={defaultSkuDetails4.capacity}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        RemoveLinesAPIResult={RemoveLinesAPIResultWithErrorCode}
        setSelectedDeviceData={jest.fn()}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });

  test('component should render', async () => {
    const backButton = await screen.findByTestId('testBackGridwall');
    expect(backButton).toBeInTheDocument();
  });
});

describe('PDP component Cannot add a Pre/Back device as Exchange device', () => {
  const activeMtn = '5185673926';
  beforeAll(() => {
    sessionStorage.setItem('refundexchange', 'true');
    const location = {
      ...window.location,
      search: `?activeMtn=${activeMtn}&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y&mtn=newLine1`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=${activeMtn}&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y&mtn=newLine1`;
  });

  beforeEach(() => {
    render(
      <PDP
        productDetails={productDetails5.data}
        cartDetails={cartDetails.data.data}
        customerProfileDetails={customerProfileDetails2.data}
        activeMtn={activeMtn}
        selectedColor={defaultSkuDetails4.color.displayName}
        setSelectedColor={jest.fn()}
        ispuToggleOn={false}
        setIspuToggleOn={jest.fn()}
        isShipItToggleOn={false}
        setIsShipItToggleOn={jest.fn()}
        selectedSku={defaultSkuDetails4}
        setSelectedSku={jest.fn()}
        selectedProtectionFeature={protectionFeatures.payload.features[1]}
        setSelectedProtectionFeature={jest.fn()}
        selectedSize={defaultSkuDetails4.capacity}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        RemoveLinesAPIResult={RemoveLinesAPIResultWithErrorCode}
        setSelectedDeviceData={jest.fn()}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });

  test('component should render', async () => {
    const backButton = await screen.findByTestId('testBackGridwall');
    expect(backButton).toBeInTheDocument();
  });
});
