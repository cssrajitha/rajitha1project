import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import Home5G from '../Home5G';
import Home5g from '../../../assests/images/Home5g.png';

describe('<Home5G/>', () => {
  const mockImportantDeviceClickHandler = jest.fn();
  const props = {
    id: 'gw.d1',
    devicename: '5G Home',
    monthlyprice: '$30.55/mo. for 36 mos',
    total: '$1299.00',
    logo: Home5g,
    upgrade: true,
    upgrademsg: 'Upgrade after 50%',
    sku: 'MQ0E3L/A',
    color: 'Grey',
  };
  beforeEach(() => {
    render(<Home5G device={props} importantDeviceClickHandler={mockImportantDeviceClickHandler} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  it('should test static contents of the compnent', () => {
    expect(
      screen.getByRole('img', {
        name: /deviceslogo/i,
      }),
    ).toBeInTheDocument();
    expect(screen.getByText(/important device lock information/i)).toBeInTheDocument();
    expect(
      screen.getByRole('heading', {
        name: new RegExp(props.devicename, 'i'),
      }),
    ).toBeInTheDocument();
    expect(screen.getByText(new RegExp(`sku#: ${props.sku}`, 'i'))).toBeInTheDocument();
    expect(
      screen.getByRole('heading', {
        name: /payment options/i,
      }),
    ).toBeInTheDocument();

    expect(
      screen.getByRole('radio', {
        name: /\$12\.50\/mo\./i,
      }),
    ).toBeInTheDocument();
    expect(screen.getByText(/\$12\.50\/mo\./i)).toBeInTheDocument();

    expect(
      screen.getByRole('radio', {
        name: /self setup/i,
      }),
    ).toBeInTheDocument();
    expect(screen.getByText(/self setup/i)).toBeInTheDocument();

    expect(
      screen.getByRole('radio', {
        name: /professional setup/i,
      }),
    ).toBeInTheDocument();
    expect(screen.getByText(/professional setup/i)).toBeInTheDocument();

    fireEvent.click(screen.getByText(/important device lock information/i));
    expect(mockImportantDeviceClickHandler).toBeCalled();
  });

  it('should test rendered UI when professional setup radio button is not clicked', () => {
    expect(
      screen.getByRole('heading', {
        name: /device id/i,
      }),
    ).toBeInTheDocument();
    expect(
      screen.queryByRole('heading', {
        name: /schedule appointment/i,
      }),
    ).toBeNull();
  });

  it('should test rendered UI when professional setup radio button is clicked', () => {
    fireEvent.click(
      screen.getByRole('radio', {
        name: /professional setup/i,
      }),
    );

    expect(
      screen.getByRole('heading', {
        name: /schedule appointment/i,
      }),
    ).toBeInTheDocument();

    expect(
      screen.queryByRole('heading', {
        name: /device id/i,
      }),
    ).toBeNull();
  });
});
