import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import { cloneDeep } from 'lodash';
import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import PDP from '../PDP';
import propsIndirect from './pdpIndirectProps.json';

const cashOnlyFlowProps = cloneDeep(propsIndirect);
cashOnlyFlowProps.customerProfileDetails.customer.billAccounts = [];

const dispatchedActions = [];
const mockStore = {
  dispatch: (action) => {
    dispatchedActions.push(action);
  },
};

jest.setTimeout(50000);
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: () => [
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
    ],
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    getClientAppName: () => 'ATG-RTL-NETACE',
    noOfDaysLeftInBillCycle: () => 12,
    isIpad: () => true,
    isRetail: () => true,
    isAsurion: () => false,
    executeShellFunction: jest.fn(),
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

describe('PDP component for indirect', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    window.store = mockStore;
    window.vzdl = { page: {} };
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?offerEligible=Y&activeMtn=9102798662&productId=dev21410695&defaultSku=MTXW3LL/A`;
    render(
      <PDP
        setSelectedColor={jest.fn()}
        selectedPaymentInfo={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...propsIndirect}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('It should display Ship It button for Dfill order', async () => {
    const addToCartBtn = await screen.getByRole('button', {
      name: /Ship it/i,
    });
    expect(addToCartBtn).toBeInTheDocument();
  });

  test('Should render 3 payment options in UI ', async () => {
    expect(screen.getByText('Month To Month')).toBeInTheDocument();
    expect(screen.getByText('36 mo Device Payment')).toBeInTheDocument();
    expect(screen.getByText('Two Years Payment')).toBeInTheDocument();

    const monthToMonthPaymentOption = screen.getAllByRole('radio', {
      name: 'Month To Month',
    });
    expect(monthToMonthPaymentOption[0]).not.toBeChecked();
    fireEvent.click(monthToMonthPaymentOption[0]);
    expect(monthToMonthPaymentOption[0]).toBeChecked();

    const installmentMonth36 = screen.getAllByRole('radio', {
      name: '36 mo Device Payment',
    });
    expect(installmentMonth36[0]).not.toBeChecked();
    fireEvent.click(installmentMonth36[0]);
    expect(installmentMonth36[0]).toBeChecked();

    const twoYearsPaymentRadio = screen.getAllByRole('radio', {
      name: 'Two Years Payment',
    });
    expect(twoYearsPaymentRadio[0]).not.toBeChecked();
    fireEvent.click(twoYearsPaymentRadio[0]);
    expect(twoYearsPaymentRadio[0]).toBeChecked();
  });
});

describe('PDP component for indirect - indirectCashOnlyCustomer', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    window.store = mockStore;
    window.vzdl = { page: {} };
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?offerEligible=Y&activeMtn=9102798662&productId=dev21410695&defaultSku=MTXW3LL/A`;
    render(
      <PDP
        setSelectedColor={jest.fn()}
        selectedPaymentInfo={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...cashOnlyFlowProps}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('It should display Ship It button for Dfill order', async () => {
    const addToCartBtn = await screen.getByRole('button', {
      name: /Ship it/i,
    });
    expect(addToCartBtn).toBeInTheDocument();
  });

  test('Should render 2 payment options in UI ', async () => {
    expect(screen.getByText('Month To Month')).toBeInTheDocument();
    expect(screen.getByText('Two Years Payment')).toBeInTheDocument();

    const monthToMonthPaymentOption = screen.getAllByRole('radio', {
      name: 'Month To Month',
    });
    expect(monthToMonthPaymentOption[0]).not.toBeChecked();
    fireEvent.click(monthToMonthPaymentOption[0]);
    expect(monthToMonthPaymentOption[0]).toBeChecked();

    const twoYearsPaymentRadio = screen.getAllByRole('radio', {
      name: 'Two Years Payment',
    });
    expect(twoYearsPaymentRadio[0]).not.toBeChecked();
    fireEvent.click(twoYearsPaymentRadio[0]);
    expect(twoYearsPaymentRadio[0]).toBeChecked();
  });
});
