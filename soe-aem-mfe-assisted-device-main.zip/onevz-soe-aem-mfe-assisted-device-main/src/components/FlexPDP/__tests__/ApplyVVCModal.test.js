// eslint-disable-next-line max-classes-per-file
import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import ApplyVVCModal from '../ApplyVVCModal';

const dispatchedActions = [];
const mockStore = {
  dispatch: (action) => {
    dispatchedActions.push(action);
  },
};
jest.mock(
  '../../../modules/services/APIService/APIServiceHooks',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('../../../modules/services/APIService/APIServiceHooks'),
      useCreateApplicationMutation: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                serviceBody: {
                  serviceResponse: {
                    context: {
                      contextInfo: {
                        processStep: '',
                      },
                      cartInfo: { lines: [{ downPaymentAmtApplied: '15', device: { upgradeReasonCode: 'UN' } }] },
                    },
                  },
                },
              },
            },
          ];
        }
        return [() => {}, { data: { id: '1234' } }];
      },
    };
  },
  { virtual: true },
);

describe('ApplyVVCModal model component render Prequalify', () => {
  const props = {
    vvcEligibleType: 'preQualify',
    isaacPromo: {
      proposition: {
        hasApplyOffer: true,
        propositionId: 'GC_02',
        propositionAction: 'A',
        isDirectApply: true,
        message: 'Thank you for your interest! Sign up and receive: $100 sign up bonus and more',
        rank: '1',
        offerAmount: '100',
        spoName: 'SOBTRIGGER',
        syfOfferId: '',
        soiEngagementId: '501002527',
        rewardsEnrolled: false,
        verizonDollarsBalance: '',
        customerActions: [
          {
            id: '1',
            action: 'Apply Now',
            label: 'Apply Now',
          },
        ],
        isEmployeeEligible: false,
        mtnsWithCC: '',
        offerIdFromSYF: 'false',
      },
      sessionId: '-7960663412984780097',
      stateCd: 'IL',
      mtnActivatedForMoreThanADay: true,
      tagInformation: {
        acctHashCode: 'db5ec1466180b094bbb70382aa901b1deaf67eef7e03923f45b130711bb30c6a',
        lookupMtnHashCode: '55a816c101e7b7409ae62f95b7644748c3c22e508e971a822c3d7dd3ed62a2c9',
        area: 'Midwest|IL/WI',
        zipCode: '60491',
        state: 'IL',
      },
    },
    customerProfileDetails: {
      customer: { orderLocationCode: '679', billAccounts: [{ mtns: [{ mtn: '1234' }, { mtn: '2356' }] }] },
    },
    processAddToCartNextSteps: jest.fn(),
    opened: true,
  };
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/accountlandingservice/isaac/createapplication`, (req, res, ctx) => {
      console.log('inside /accountlandingservice/isaac/createapplication');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    window.store = mockStore;
    render(<ApplyVVCModal {...props} />);
  });
  test('ApplyVVC component shoudl render', () => {
    const ApplyVVCText = screen.getByText('Save on your Verizon Bill every month.');
    expect(ApplyVVCText).toBeInTheDocument();
  });
  test('close ApplyVVC Amount Model', () => {
    const ApplyVVCText = screen.getByText('Not now');
    expect(ApplyVVCText).toBeInTheDocument();
    fireEvent.click(ApplyVVCText);
  });
  test('Select MTN ', () => {
    const selectedMdn = screen.getByTestId('selectedMdn');
    expect(selectedMdn).toBeInTheDocument();
    fireEvent.click(selectedMdn);
  });
  test('it should mount dropdown selectMdn', () => {
    const selectMdn = screen.queryByTestId('selectedMdn');
    fireEvent.change(selectMdn, { target: { value: '5854696176' } });
    fireEvent.click(screen.getByTestId('vvcSendApplication'));
  });
});
describe('ApplyVVCModal model component render Direct Apply', () => {
  const props = {
    vvcEligibleType: 'preQualify',
    isaacPromo: {
      proposition: {
        hasApplyOffer: true,
        propositionId: 'GC_02',
        propositionAction: 'A',
        isDirectApply: true,
        message: 'Thank you for your interest! Sign up and receive: $100 sign up bonus and more',
        rank: '1',
        offerAmount: '100',
        spoName: 'SOBTRIGGER',
        syfOfferId: '',
        soiEngagementId: '501002527',
        rewardsEnrolled: false,
        verizonDollarsBalance: '',
        customerActions: [
          {
            id: '1',
            action: 'Apply Now',
            label: 'Apply Now',
          },
        ],
        isEmployeeEligible: false,
        mtnsWithCC: '',
        offerIdFromSYF: 'false',
      },
      sessionId: '-7960663412984780097',
      stateCd: 'IL',
      mtnActivatedForMoreThanADay: true,
      tagInformation: {
        acctHashCode: 'db5ec1466180b094bbb70382aa901b1deaf67eef7e03923f45b130711bb30c6a',
        lookupMtnHashCode: '55a816c101e7b7409ae62f95b7644748c3c22e508e971a822c3d7dd3ed62a2c9',
        area: 'Midwest|IL/WI',
        zipCode: '60491',
        state: 'IL',
      },
    },
    customerProfileDetails: {
      customer: { orderLocationCode: '679', billAccounts: [{ mtns: [{ mtn: '5854696176' }, { mtn: '2356' }] }] },
    },
    processAddToCartNextSteps: jest.fn(),
    opened: false,
  };
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  beforeEach(() => {
    render(<ApplyVVCModal {...props} />);
  });
  test('ApplyVVC component shoudl render', () => {
    const ApplyVVCText = screen.getByText('Save on your Verizon Bill every month.');
    expect(ApplyVVCText).toBeInTheDocument();
  });
  test('close ApplyVVC Amount Model', () => {
    const ApplyVVCText = screen.getByText('Not now');
    expect(ApplyVVCText).toBeInTheDocument();
    fireEvent.click(ApplyVVCText);
  });
  test('Select MTN ', () => {
    const selectedMdn = screen.getByTestId('selectedMdn');
    expect(selectedMdn).toBeInTheDocument();
    fireEvent.click(selectedMdn);
  });
  test('it should mount dropdown selectMdn', () => {
    const selectMdn = screen.queryByTestId('selectedMdn');
    fireEvent.change(selectMdn, { target: { value: '5854696176' } });
    fireEvent.click(screen.getByTestId('vvcSendApplication'));
  });
});
describe('ApplyVVCModal model component render Direct Apply text', () => {
  const props = {
    vvcEligibleType: 'inDirect',
    isaacPromo: {
      proposition: {
        hasApplyOffer: true,
        propositionId: 'GC_02',
        propositionAction: 'A',
        isDirectApply: true,
        message: 'Thank you for your interest! Sign up and receive: $100 sign up bonus and more',
        rank: '1',
        offerAmount: '100',
        spoName: 'SOBTRIGGER',
        syfOfferId: '',
        soiEngagementId: '501002527',
        rewardsEnrolled: false,
        verizonDollarsBalance: '',
        customerActions: [
          {
            id: '1',
            action: 'Apply Now',
            label: 'Apply Now',
          },
        ],
        isEmployeeEligible: false,
        mtnsWithCC: '',
        offerIdFromSYF: 'false',
      },
      sessionId: '-7960663412984780097',
      stateCd: 'IL',
      mtnActivatedForMoreThanADay: true,
      tagInformation: {
        acctHashCode: 'db5ec1466180b094bbb70382aa901b1deaf67eef7e03923f45b130711bb30c6a',
        lookupMtnHashCode: '55a816c101e7b7409ae62f95b7644748c3c22e508e971a822c3d7dd3ed62a2c9',
        area: 'Midwest|IL/WI',
        zipCode: '60491',
        state: 'IL',
      },
    },
    customerProfileDetails: {
      customer: { orderLocationCode: '679', billAccounts: [{ mtns: [{ mtn: '5854696176' }, { mtn: '2356' }] }] },
    },
    processAddToCartNextSteps: jest.fn(),
    setShowApplyVVCModal: jest.fn(),
    opened: false,
  };
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  beforeEach(() => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ vvcFeedbackDispositionFFlag: true }));
    render(<ApplyVVCModal {...props} />);
  });
  test('ApplyVVC component shoudl render', () => {
    const ApplyVVCText = screen.getByText('Save on your Verizon Bill every month.');
    expect(ApplyVVCText).toBeInTheDocument();
  });
  test('it should click cross mark', () => {
    const closeBtn = screen.getByRole('button', { name: 'applyVVCModal close' });
    fireEvent.click(closeBtn);
  });
});
describe('ApplyVVCModal dfoNachoVVCFFlag functionality', () => {
  const baseProps = {
    vvcEligibleType: 'preQualify',
    isaacPromo: {
      proposition: {
        hasApplyOffer: true,
        propositionId: 'GC_02',
        propositionAction: 'A',
        isDirectApply: true,
        message: 'Thank you for your interest! Sign up and receive: $100 sign up bonus and more',
        rank: '1',
        offerAmount: '100',
        spoName: 'SOBTRIGGER',
        syfOfferId: '',
        soiEngagementId: '501002527',
        rewardsEnrolled: false,
        verizonDollarsBalance: '',
        customerActions: [
          {
            id: '1',
            action: 'Apply Now',
            label: 'Apply Now',
          },
        ],
        isEmployeeEligible: false,
        mtnsWithCC: '',
        offerIdFromSYF: 'false',
      },
      sessionId: '-7960663412984780097',
      stateCd: 'IL',
      mtnActivatedForMoreThanADay: true,
      tagInformation: {
        acctHashCode: 'db5ec1466180b094bbb70382aa901b1deaf67eef7e03923f45b130711bb30c6a',
        lookupMtnHashCode: '55a816c101e7b7409ae62f95b7644748c3c22e508e971a822c3d7dd3ed62a2c9',
        area: 'Midwest|IL/WI',
        zipCode: '60491',
        state: 'IL',
      },
    },
    customerProfileDetails: {
      customer: { orderLocationCode: '679', billAccounts: [{ mtns: [{ mtn: '5854696176' }, { mtn: '2356' }] }] },
    },
    processAddToCartNextSteps: jest.fn(),
    setShowApplyVVCModal: jest.fn(),
    opened: true,
  };

  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  describe('when dfoNachoVVCFFlag is TRUE', () => {
    beforeEach(() => {
      sessionStorage.setItem('APP_PROPERTIES', '{ "dfoNachoVVCFFlag": "TRUE"}');
      window.store = mockStore;
      render(<ApplyVVCModal {...baseProps} />);
    });

    afterEach(() => {
      sessionStorage.clear();
    });

    test('should display $200 cash back offer when flag is true', () => {
      const cashBackText = screen.getByText('Get up to $200 cash back with Verizon Visa® Card.');
      expect(cashBackText).toBeInTheDocument();
    });

    test('should display $150 additional credit offer details when flag is true', () => {
      const offerDetails = screen.getByText(
        /Get a \$50 statement credit when you open an account and make a purchase in the first 90 days\. Get an additional \$150 statement credit when you spend \$1500 using your card in the first 90 days\. Offer available 10\/15\/25 to 1\/6\/26\./,
      );
      expect(offerDetails).toBeInTheDocument();
    });

    test('should not display $150 cash back offer when flag is true', () => {
      const cashBackText = screen.queryByText('Get up to $150 cash back with Verizon Visa® Card.');
      expect(cashBackText).not.toBeInTheDocument();
    });

    test('should not display $100 additional credit offer when flag is true', () => {
      const offerDetails = screen.queryByText(
        /Get a \$50 statement credit when you open an account and make a purchase in the first 90 days\. Get an additional \$100 statement credit when you spend \$1500 using your card in the first 90 days\. Limited time offer\./,
      );
      expect(offerDetails).not.toBeInTheDocument();
    });
  });

  describe('when dfoNachoVVCFFlag is FALSE', () => {
    beforeEach(() => {
      sessionStorage.setItem('APP_PROPERTIES', '{ "dfoNachoVVCFFlag": "FALSE"}');
      window.store = mockStore;
      render(<ApplyVVCModal {...baseProps} />);
    });

    afterEach(() => {
      sessionStorage.clear();
    });

    test('should display $150 cash back offer when flag is false', () => {
      const cashBackText = screen.getByText('Get up to $150 cash back with Verizon Visa® Card.');
      expect(cashBackText).toBeInTheDocument();
    });

    test('should display $100 additional credit offer details when flag is false', () => {
      const offerDetails = screen.getByText(
        /Get a \$50 statement credit when you open an account and make a purchase in the first 90 days\. Get an additional \$100 statement credit when you spend \$1500 using your card in the first 90 days\. Limited time offer\./,
      );
      expect(offerDetails).toBeInTheDocument();
    });

    test('should not display $200 cash back offer when flag is false', () => {
      const cashBackText = screen.queryByText('Get up to $200 cash back with Verizon Visa® Card.');
      expect(cashBackText).not.toBeInTheDocument();
    });

    test('should not display $150 additional credit offer when flag is false', () => {
      const offerDetails = screen.queryByText(
        /Get a \$50 statement credit when you open an account and make a purchase in the first 90 days\. Get an additional \$150 statement credit when you spend \$1500 using your card in the first 90 days\. Offer available 10\/15\/25 to 1\/6\/26\./,
      );
      expect(offerDetails).not.toBeInTheDocument();
    });
  });

  describe('when dfoNachoVVCFFlag is undefined or null', () => {
    beforeEach(() => {
      sessionStorage.setItem('APP_PROPERTIES', '{}');
      window.store = mockStore;
      render(<ApplyVVCModal {...baseProps} />);
    });

    afterEach(() => {
      sessionStorage.clear();
    });

    test('should display $150 cash back offer when flag is undefined', () => {
      const cashBackText = screen.getByText('Get up to $150 cash back with Verizon Visa® Card.');
      expect(cashBackText).toBeInTheDocument();
    });

    test('should display $100 additional credit offer details when flag is undefined', () => {
      const offerDetails = screen.getByText(
        /Get a \$50 statement credit when you open an account and make a purchase in the first 90 days\. Get an additional \$100 statement credit when you spend \$1500 using your card in the first 90 days\. Limited time offer\./,
      );
      expect(offerDetails).toBeInTheDocument();
    });
  });

  describe('when sessionStorage APP_PROPERTIES is null', () => {
    beforeEach(() => {
      sessionStorage.removeItem('APP_PROPERTIES');
      window.store = mockStore;
      render(<ApplyVVCModal {...baseProps} />);
    });

    afterEach(() => {
      sessionStorage.clear();
    });

    test('should display $150 cash back offer when APP_PROPERTIES is null', () => {
      const cashBackText = screen.getByText('Get up to $150 cash back with Verizon Visa® Card.');
      expect(cashBackText).toBeInTheDocument();
    });

    test('should display $100 additional credit offer details when APP_PROPERTIES is null', () => {
      const offerDetails = screen.getByText(
        /Get a \$50 statement credit when you open an account and make a purchase in the first 90 days\. Get an additional \$100 statement credit when you spend \$1500 using your card in the first 90 days\. Limited time offer\./,
      );
      expect(offerDetails).toBeInTheDocument();
    });
  });
});
describe('ApplyVVCModal model component render Direct Apply text if ff false', () => {
  const props = {
    vvcEligibleType: 'inDirect',
    isaacPromo: {
      proposition: {
        hasApplyOffer: true,
        propositionId: 'GC_02',
        propositionAction: 'A',
        isDirectApply: true,
        message: 'Thank you for your interest! Sign up and receive: $100 sign up bonus and more',
        rank: '1',
        offerAmount: '100',
        spoName: 'SOBTRIGGER',
        syfOfferId: '',
        soiEngagementId: '501002527',
        rewardsEnrolled: false,
        verizonDollarsBalance: '',
        customerActions: [
          {
            id: '1',
            action: 'Apply Now',
            label: 'Apply Now',
          },
        ],
        isEmployeeEligible: false,
        mtnsWithCC: '',
        offerIdFromSYF: 'false',
      },
      sessionId: '-7960663412984780097',
      stateCd: 'IL',
      mtnActivatedForMoreThanADay: true,
      tagInformation: {
        acctHashCode: 'db5ec1466180b094bbb70382aa901b1deaf67eef7e03923f45b130711bb30c6a',
        lookupMtnHashCode: '55a816c101e7b7409ae62f95b7644748c3c22e508e971a822c3d7dd3ed62a2c9',
        area: 'Midwest|IL/WI',
        zipCode: '60491',
        state: 'IL',
      },
    },
    customerProfileDetails: {
      customer: { orderLocationCode: '679', billAccounts: [{ mtns: [{ mtn: '5854696176' }, { mtn: '2356' }] }] },
    },
    processAddToCartNextSteps: jest.fn(),
    setShowApplyVVCModal: jest.fn(),
    opened: false,
  };
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  beforeEach(() => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ vvcFeedbackDispositionFFlag: false }));
    render(<ApplyVVCModal {...props} />);
  });
  test('ApplyVVC component shoudl render', () => {
    const ApplyVVCText = screen.getByText('Save on your Verizon Bill every month.');
    expect(ApplyVVCText).toBeInTheDocument();
  });
  test('it should click cross mark', () => {
    const closeBtn = screen.getByRole('button', { name: 'applyVVCModal close' });
    fireEvent.click(closeBtn);
  });
});
describe('ApplyVVCModal uncovered lines', () => {
  const mockProcessAddToCartNextSteps = jest.fn();
  const mockSetShowApplyVVCModal = jest.fn();
  const mockAddVzccFeedbackStatus = jest.fn();
  const mockAddSubmitFeedback = jest.fn();

  jest.mock(
    '../../../modules/services/APIService/APIServiceHooks',
    () => ({
      useCreateApplicationMutation: () => [jest.fn(), { data: { some: 'data' } }],
      useAddSubmitFeedbackMutation: () => [mockAddSubmitFeedback, {}],
      useAddVzccFeedbackStatusMutation: () => [mockAddVzccFeedbackStatus, {}],
    }),
    { virtual: true },
  );

  const isaacPromo = {
    proposition: {
      soiEngagementId: 'engagementId',
      rank: 1,
      propositionId: 'propId',
      spoName: 'spoName',
      syfOfferId: 'syfOfferId',
    },
    sessionId: 'sessionId',
  };

  const customerProfileDetails = {
    customer: {
      orderLocationCode: 'locCode',
      billAccounts: [{ mtns: [{ mtn: '1234567890' }] }],
    },
  };

  const selectedSku = {
    price: {
      fullRetailPrice: {
        originalPrice: 1000,
      },
    },
  };
  beforeEach(() => {
    jest.clearAllMocks();
    sessionStorage.setItem('cartId', 'testCartId');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ vvcFeedbackDispositionFFlag: true }));
  });
  it('calls processAddToCartNextSteps and sets isVVCAplicationCreated in sessionStorage when createApplicationResults.data is present', () => {
    render(
      <ApplyVVCModal
        vvcEligibleType='preQualify'
        isaacPromo={isaacPromo}
        customerProfileDetails={customerProfileDetails}
        processAddToCartNextSteps={mockProcessAddToCartNextSteps}
        setShowApplyVVCModal={mockSetShowApplyVVCModal}
        selectedSku={selectedSku}
      />,
    );
    expect(sessionStorage.getItem('isVVCAplicationCreated')).toBe('true');
    expect(mockProcessAddToCartNextSteps).toHaveBeenCalled();
  });
});
describe('ApplyVVCModal uncovered lines', () => {
  const mockProcessAddToCartNextSteps = jest.fn();
  const mockSetShowApplyVVCModal = jest.fn();
  const mockAddVzccFeedbackStatus = jest.fn();
  const mockAddSubmitFeedback = jest.fn();

  jest.mock(
    '../../../modules/services/APIService/APIServiceHooks',
    () => ({
      useCreateApplicationMutation: () => [jest.fn(), { data: { some: 'data' } }],
      useAddSubmitFeedbackMutation: () => [mockAddSubmitFeedback, {}],
      useAddVzccFeedbackStatusMutation: () => [mockAddVzccFeedbackStatus, {}],
    }),
    { virtual: true },
  );

  const isaacPromo = {
    proposition: {
      soiEngagementId: 'engagementId',
      rank: 1,
      propositionId: 'propId',
      spoName: 'spoName',
      syfOfferId: 'syfOfferId',
    },
    sessionId: 'sessionId',
  };

  const customerProfileDetails = {
    customer: {
      orderLocationCode: 'locCode',
      billAccounts: [{ mtns: [{ mtn: '1234567890' }] }],
    },
  };

  const selectedSku = {
    price: {
      fullRetailPrice: {
        originalPrice: 1000,
      },
    },
  };
  beforeEach(() => {
    jest.clearAllMocks();
    sessionStorage.setItem('cartId', '');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ vvcFeedbackDispositionFFlag: true }));
  });

  it('calls processAddToCartNextSteps and sets isVVCAplicationCreated in sessionStorage when createApplicationResults.data is present', () => {
    render(
      <ApplyVVCModal
        vvcEligibleType='preQualify'
        isaacPromo={isaacPromo}
        customerProfileDetails={customerProfileDetails}
        processAddToCartNextSteps={mockProcessAddToCartNextSteps}
        setShowApplyVVCModal={mockSetShowApplyVVCModal}
        selectedSku={selectedSku}
      />,
    );
    expect(sessionStorage.getItem('isVVCAplicationCreated')).toBe('true');
    expect(mockProcessAddToCartNextSteps).toHaveBeenCalled();
  });
});
describe('ApplyVVCModal Send button feedback', () => {
  const isaacPromo = {
    proposition: {
      soiEngagementId: 'engagementId',
      rank: 1,
      propositionId: 'propId',
      spoName: 'spoName',
      syfOfferId: 'syfOfferId',
    },
    sessionId: 'sessionId',
  };

  const customerProfileDetails = {
    customer: {
      orderLocationCode: 'locCode',
      billAccounts: [{ mtns: [{ mtn: '1234567890' }] }],
    },
  };

  const selectedSku = {
    price: {
      fullRetailPrice: {
        originalPrice: 1000,
      },
    },
  };

  beforeEach(() => {
    jest.clearAllMocks();
    sessionStorage.setItem('cartId', 'testCartId');
    const vvcFeedbackDispositionFFlagvalue = sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({ vvcFeedbackDispositionFFlag: true }),
    );
    render(
      <ApplyVVCModal
        vvcEligibleType='preQualify'
        isaacPromo={isaacPromo}
        vvcFeedbackDispositionFFlag={vvcFeedbackDispositionFFlagvalue}
        customerProfileDetails={customerProfileDetails}
        processAddToCartNextSteps={jest.fn()}
        setShowApplyVVCModal={jest.fn()}
        selectedSku={selectedSku}
      />,
    );
  });

  test('calls applyAddVzccFeedbackStatus when Send is clicked and flag is true', () => {
    fireEvent.change(screen.getByTestId('selectedMdn'), { target: { value: '1234567890' } });
    fireEvent.click(screen.getByTestId('vvcSendApplication'));
    expect.objectContaining({
      body: expect.objectContaining({
        vzccStatus: { feedbackStatus: 'Applied' },
      }),
    });
  });
});
describe('ApplyVVCModal Not now button', () => {
  const mockProcessAddToCartNextSteps = jest.fn();
  const mockAddSubmitFeedback = jest.fn();
  const isaacPromo = {
    proposition: {
      soiEngagementId: 'engagementId',
      rank: 1,
      propositionId: 'propId',
      spoName: 'spoName',
      syfOfferId: 'syfOfferId',
    },
    sessionId: 'sessionId',
  };

  const customerProfileDetails = {
    customer: {
      orderLocationCode: 'locCode',
      billAccounts: [{ mtns: [{ mtn: '1234567890' }] }],
    },
  };

  const selectedSku = {
    price: {
      fullRetailPrice: {
        originalPrice: 1000,
      },
    },
  };

  beforeEach(() => {
    jest.clearAllMocks();
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ vvcFeedbackDispositionFFlag: true }));
    sessionStorage.setItem('cartId', 'testCartId');
  });

  test('calls processAddToCartNextSteps, handleAddVzccFeedbackStatus, and handleAddSubmitFeedback when Not now is clicked and flag is true', () => {
    const mockAddVzccFeedbackStatus = jest.fn();

    jest.mock(
      '../../../modules/services/APIService/APIServiceHooks',
      () => ({
        useAddVzccFeedbackStatusMutation: () => [mockAddVzccFeedbackStatus, {}],
        useAddSubmitFeedbackMutation: () => [mockAddSubmitFeedback, {}],
        useCreateApplicationMutation: () => [jest.fn(), {}],
      }),
      { virtual: true },
    );

    render(
      <ApplyVVCModal
        vvcEligibleType='preQualify'
        isaacPromo={isaacPromo}
        customerProfileDetails={customerProfileDetails}
        processAddToCartNextSteps={mockProcessAddToCartNextSteps}
        setShowApplyVVCModal={jest.fn()}
        selectedSku={selectedSku}
      />,
    );
    fireEvent.click(screen.getByTestId('primary_btn_2'));
    expect(mockProcessAddToCartNextSteps).toHaveBeenCalled();
    expect.objectContaining({
      body: expect.objectContaining({ vzccStatus: { feedbackStatus: 'Declined' } }),
    });
  });
});
describe('ApplyVVCModal aprNCHOFFlag functionality', () => {
  const baseProps = {
    vvcEligibleType: 'preQualify',
    isaacPromo: {
      proposition: {
        hasApplyOffer: true,
        propositionId: 'GC_02',
        propositionAction: 'A',
        isDirectApply: true,
        message: 'Thank you for your interest! Sign up and receive: $100 sign up bonus and more',
        rank: '1',
        offerAmount: '100',
        spoName: 'SOBTRIGGER',
        syfOfferId: '',
        soiEngagementId: '501002527',
        rewardsEnrolled: false,
        verizonDollarsBalance: '',
        customerActions: [
          {
            id: '1',
            action: 'Apply Now',
            label: 'Apply Now',
          },
        ],
        isEmployeeEligible: false,
        mtnsWithCC: '',
        offerIdFromSYF: 'false',
      },
      sessionId: '-7960663412984780097',
      stateCd: 'IL',
      mtnActivatedForMoreThanADay: true,
      tagInformation: {
        acctHashCode: 'db5ec1466180b094bbb70382aa901b1deaf67eef7e03923f45b130711bb30c6a',
        lookupMtnHashCode: '55a816c101e7b7409ae62f95b7644748c3c22e508e971a822c3d7dd3ed62a2c9',
        area: 'Midwest|IL/WI',
        zipCode: '60491',
        state: 'IL',
      },
    },
    customerProfileDetails: {
      customer: { orderLocationCode: '679', billAccounts: [{ mtns: [{ mtn: '5854696176' }, { mtn: '2356' }] }] },
    },
    processAddToCartNextSteps: jest.fn(),
    setShowApplyVVCModal: jest.fn(),
    opened: true,
  };

  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  describe('when aprNCHOFFlag is TRUE (opposite to dfoNachoVVCFFlag)', () => {
    beforeEach(() => {
      sessionStorage.setItem('APP_PROPERTIES', '{ "aprNCHOFFlag": "TRUE", "dfoNachoVVCFFlag": "FALSE"}');
      window.store = mockStore;
      render(<ApplyVVCModal {...baseProps} />);
    });

    afterEach(() => {
      sessionStorage.clear();
    });

    test('should display $200 cash back offer when aprNCHOFFlag is true', () => {
      const cashBackText = screen.getByText('Get up to $200 cash back with Verizon Visa® Card.');
      expect(cashBackText).toBeInTheDocument();
    });

    test('should display $150 additional credit offer details when aprNCHOFFlag is true', () => {
      const offerDetails = screen.getByText(
        /Get a \$50 statement credit when you open an account and make a purchase in the first 90 days\. Get an additional \$150 statement credit when you spend \$1500 using your card in the first 90 days\. Offer available 10\/15\/25 to 1\/6\/26\./,
      );
      expect(offerDetails).toBeInTheDocument();
    });

    test('should not display $150 cash back offer when aprNCHOFFlag is true', () => {
      const cashBackText = screen.queryByText('Get up to $150 cash back with Verizon Visa® Card.');
      expect(cashBackText).not.toBeInTheDocument();
    });

    test('should not display $100 additional credit offer when aprNCHOFFlag is true', () => {
      const offerDetails = screen.queryByText(
        /Get a \$50 statement credit when you open an account and make a purchase in the first 90 days\. Get an additional \$100 statement credit when you spend \$1500 using your card in the first 90 days\. Limited time offer\./,
      );
      expect(offerDetails).not.toBeInTheDocument();
    });
  });

  describe('when aprNCHOFFlag is FALSE (same as dfoNachoVVCFFlag)', () => {
    beforeEach(() => {
      sessionStorage.setItem('APP_PROPERTIES', '{ "aprNCHOFFlag": "FALSE", "dfoNachoVVCFFlag": "TRUE"}');
      window.store = mockStore;
      render(<ApplyVVCModal {...baseProps} />);
    });

    afterEach(() => {
      sessionStorage.clear();
    });

    test('should display $200 cash back offer when aprNCHOFFlag is false but dfoNachoVVCFFlag is true', () => {
      const cashBackText = screen.getByText('Get up to $200 cash back with Verizon Visa® Card.');
      expect(cashBackText).toBeInTheDocument();
    });

    test('should display $150 additional credit offer details when aprNCHOFFlag is false but dfoNachoVVCFFlag is true', () => {
      const offerDetails = screen.getByText(
        /Get a \$50 statement credit when you open an account and make a purchase in the first 90 days\. Get an additional \$150 statement credit when you spend \$1500 using your card in the first 90 days\. Offer available 10\/15\/25 to 1\/6\/26\./,
      );
      expect(offerDetails).toBeInTheDocument();
    });
  });

  describe('when both aprNCHOFFlag and dfoNachoVVCFFlag are FALSE', () => {
    beforeEach(() => {
      sessionStorage.setItem('APP_PROPERTIES', '{ "aprNCHOFFlag": "FALSE", "dfoNachoVVCFFlag": "FALSE"}');
      window.store = mockStore;
      render(<ApplyVVCModal {...baseProps} />);
    });

    afterEach(() => {
      sessionStorage.clear();
    });

    test('should display $150 cash back offer when both flags are false', () => {
      const cashBackText = screen.getByText('Get up to $150 cash back with Verizon Visa® Card.');
      expect(cashBackText).toBeInTheDocument();
    });

    test('should display $100 additional credit offer details when both flags are false', () => {
      const offerDetails = screen.getByText(
        /Get a \$50 statement credit when you open an account and make a purchase in the first 90 days\. Get an additional \$100 statement credit when you spend \$1500 using your card in the first 90 days\. Limited time offer\./,
      );
      expect(offerDetails).toBeInTheDocument();
    });

    test('should not display $200 cash back offer when both flags are false', () => {
      const cashBackText = screen.queryByText('Get up to $200 cash back with Verizon Visa® Card.');
      expect(cashBackText).not.toBeInTheDocument();
    });

    test('should not display $150 additional credit offer when both flags are false', () => {
      const offerDetails = screen.queryByText(
        /Get a \$50 statement credit when you open an account and make a purchase in the first 90 days\. Get an additional \$150 statement credit when you spend \$1500 using your card in the first 90 days\. Offer available 10\/15\/25 to 1\/6\/26\./,
      );
      expect(offerDetails).not.toBeInTheDocument();
    });
  });

  describe('when both aprNCHOFFlag and dfoNachoVVCFFlag are TRUE', () => {
    beforeEach(() => {
      sessionStorage.setItem('APP_PROPERTIES', '{ "aprNCHOFFlag": "TRUE", "dfoNachoVVCFFlag": "TRUE"}');
      window.store = mockStore;
      render(<ApplyVVCModal {...baseProps} />);
    });

    afterEach(() => {
      sessionStorage.clear();
    });

    test('should display $200 cash back offer when both flags are true', () => {
      const cashBackText = screen.getByText('Get up to $200 cash back with Verizon Visa® Card.');
      expect(cashBackText).toBeInTheDocument();
    });

    test('should display $150 additional credit offer details when both flags are true', () => {
      const offerDetails = screen.getByText(
        /Get a \$50 statement credit when you open an account and make a purchase in the first 90 days\. Get an additional \$150 statement credit when you spend \$1500 using your card in the first 90 days\. Offer available 10\/15\/25 to 1\/6\/26\./,
      );
      expect(offerDetails).toBeInTheDocument();
    });
  });

  describe('when aprNCHOFFlag is undefined or null', () => {
    beforeEach(() => {
      sessionStorage.setItem('APP_PROPERTIES', '{ "dfoNachoVVCFFlag": "FALSE"}');
      window.store = mockStore;
      render(<ApplyVVCModal {...baseProps} />);
    });

    afterEach(() => {
      sessionStorage.clear();
    });

    test('should display $150 cash back offer when aprNCHOFFlag is undefined', () => {
      const cashBackText = screen.getByText('Get up to $150 cash back with Verizon Visa® Card.');
      expect(cashBackText).toBeInTheDocument();
    });

    test('should display $100 additional credit offer details when aprNCHOFFlag is undefined', () => {
      const offerDetails = screen.getByText(
        /Get a \$50 statement credit when you open an account and make a purchase in the first 90 days\. Get an additional \$100 statement credit when you spend \$1500 using your card in the first 90 days\. Limited time offer\./,
      );
      expect(offerDetails).toBeInTheDocument();
    });
  });

  describe('edge case: conflicting flag values priority test', () => {
    beforeEach(() => {
      sessionStorage.setItem('APP_PROPERTIES', '{ "aprNCHOFFlag": "FALSE", "dfoNachoVVCFFlag": "TRUE"}');
      window.store = mockStore;
      render(<ApplyVVCModal {...baseProps} />);
    });

    afterEach(() => {
      sessionStorage.clear();
    });

    test('should prioritize dfoNachoVVCFFlag when aprNCHOFFlag is false but dfoNachoVVCFFlag is true', () => {
      const cashBackText = screen.getByText('Get up to $200 cash back with Verizon Visa® Card.');
      expect(cashBackText).toBeInTheDocument();
    });
  });
});
