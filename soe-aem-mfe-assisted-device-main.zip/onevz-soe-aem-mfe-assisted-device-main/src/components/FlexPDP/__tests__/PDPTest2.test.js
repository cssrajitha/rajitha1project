import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import { cloneDeep } from 'lodash';
import Emitter from 'onevzsoemfeframework/Emitter';
import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import PDP from '../PDP';
import protectionFeatures from '../../../pages/PDP/mocks/api/getProtectionFeatures.json';
import productDetails from '../../../pages/PDP/mocks/api/getDetails.json';
import customerProfileDetails from '../../../pages/PDP/mocks/api/customerProfile.json';
import cartDetails from '../../../pages/PDP/mocks/api/retrieveCart.json';

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

const details = productDetails.data.deviceProduct || {};
const defaultSkuStringValue = details?.defaultSKU || '';
const defaultSkuObjValue = details?.defaultSKUObj?.sorId || '';
const defaultSku = defaultSkuStringValue !== '' ? defaultSkuStringValue : defaultSkuObjValue;
const defaultSkuDetails = details.childSkus.filter((sku) => sku.sorId && sku.sorId === defaultSku);
const getOffers = {
  data: {
    issacPromo: {
      proposition: {
        hasApplyOffer: true,
        propositionId: 'GC_14',
        propositionAction: 'A',
        isDirectApply: false,
        message: 'Thank you for your interest! Sign up and receive: $100 sign up bonus and more',
        rank: '1',
        offerAmount: '100',
        spoName: 'SOBTRIGGER',
        syfOfferId: '',
        soiEngagementId: '501002527',
        rewardsEnrolled: false,
        verizonDollarsBalance: '',
        customerActions: [
          {
            id: '1',
            action: 'Apply Now',
            label: 'Apply Now',
          },
        ],
        isEmployeeEligible: false,
        mtnsWithCC: '',
        offerIdFromSYF: 'false',
      },
      sessionId: '-7960663412984780097',
      stateCd: 'IL',
      mtnActivatedForMoreThanADay: true,
      tagInformation: {
        acctHashCode: 'db5ec1466180b094bbb70382aa901b1deaf67eef7e03923f45b130711bb30c6a',
        lookupMtnHashCode: '55a816c101e7b7409ae62f95b7644748c3c22e508e971a822c3d7dd3ed62a2c9',
        area: 'Midwest|IL/WI',
        zipCode: '60491',
        state: 'IL',
      },
    },
  },
};

const RemoveLinesAPIResultWithErrorCode = {
  data: {
    errors: [
      {
        id: '9656',
      },
    ],
  },
  status: 'fulfilled',
};

const RemoveLinesAPIResultWithAPIResponseWithDiffProcessStep = {
  data: {
    serviceBody: {
      serviceResponse: {
        context: {
          contextInfo: {
            processStep: 'CartResponse',
          },
        },
      },
    },
  },
  status: 'fulfilled',
};
const dispatchedActions = [];
const mockStore = {
  dispatch: (action) => {
    dispatchedActions.push(action);
  },
};

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: () => [false, true, false],
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => false,
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfecommon/APIService',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('onevzsoemfecommon/APIService'),
      useAddDeviceMutation: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                serviceBody: {
                  serviceResponse: {
                    context: {
                      contextInfo: {
                        processStep: '',
                      },
                      cartInfo: { lines: [{ device: { upgradeReasonCode: 'UN' } }] },
                    },
                  },
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
    };
  },
  { virtual: true },
);

describe('PDP component render for Proposition ids', () => {
  const activeMtn = '5185673926';
  const props = {
    paymentObject: { contractDuration: 36 },
    buyoutUpgradeResult: { data: { totalBuyoutAmount: '56.7' }, status: 'fulfilled' },
    RemoveLinesAPIResult: {
      data: {
        errors: [
          {
            id: '9656',
          },
        ],
      },
      status: 'fulfilled',
    },
    setSelectedDeviceData: jest.fn(),
  };

  const handlers = [
    rest.post(`*/accountlandingservice/isaac/getoffers`, (req, res, ctx) => res(ctx.status(200), ctx.json(getOffers))),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.setItem('assistedFlags', JSON.stringify({ isVVCFlowEnabled: 'TRUE' }));

    server.use(rest.post(`*/getoffers`, (req, res, ctx) => res.once(ctx.status(200), ctx.json(getOffers))));
    render(
      <PDP
        productDetails={productDetails.data}
        cartDetails={cartDetails.data.data}
        customerProfileDetails={customerProfileDetails.data}
        activeMtn={activeMtn}
        selectedColor={defaultSkuDetails[0].color.displayName}
        setSelectedColor={jest.fn()}
        ispuToggleOn={false}
        setIspuToggleOn={jest.fn()}
        isShipItToggleOn={false}
        setIsShipItToggleOn={jest.fn()}
        selectedSku={defaultSkuDetails[0]}
        setSelectedSku={jest.fn()}
        selectedProtectionFeature={protectionFeatures.payload.features[1]}
        setSelectedProtectionFeature={jest.fn()}
        selectedSize={defaultSkuDetails[0].capacity}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        RemoveLinesAPIResult={RemoveLinesAPIResultWithErrorCode}
        {...props}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
    Emitter.emit('TAGGING_COMPLETED', true);
    Emitter.emit('Call_Device_Add_Cart', { id: '345' });
    Emitter.emit('Update_Selected_Insurance', { sorId: '123' });
  });
  test('component should render', async () => {
    server.use(
      rest.post(`*/getoffers`, (req, res, ctx) => {
        res.once(ctx.status(200), ctx.json(getOffers));
        const band = screen.getAllByRole('radio', {
          name: '$33.33/mo (excludes tax) 36 Monthly Payments with Verizon Visa Card',
        });
        fireEvent.click(band[0]);
        expect(band[0]).toBeChecked();
        fireEvent.click(
          screen.getByRole('button', {
            name: /add to cart/i,
          }),
        );
      }),
    );
    const textSku = await screen.findByText('iPhone 14 Pro');
    expect(textSku).toBeInTheDocument();
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });
});

describe('PDP component render for Proposition ids', () => {
  const activeMtn = '5185673926';
  const props = {
    paymentObject: { contractDuration: 36 },
    buyoutUpgradeResult: { data: { totalBuyoutAmount: '56.7' }, status: 'fulfilled' },
    RemoveLinesAPIResult: {
      data: {
        errors: [
          {
            id: '9656',
          },
        ],
      },
      status: 'fulfilled',
    },
    setSelectedDeviceData: jest.fn(),
  };

  const handlers = [
    rest.post(`*/accountlandingservice/isaac/getoffers`, (req, res, ctx) => res(ctx.status(200), ctx.json(getOffers))),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.setItem('assistedFlags', JSON.stringify({ isVVCFlowEnabled: 'TRUE' }));
    Object.defineProperty(window, 'mfe', {
      value: { scmDeviceMfeEnable: true },
      configurable: true,
    });
    server.use(rest.post(`*/getoffers`, (req, res, ctx) => res.once(ctx.status(200), ctx.json(getOffers))));
    render(
      <PDP
        productDetails={productDetails.data}
        cartDetails={cartDetails.data.data}
        customerProfileDetails={customerProfileDetails.data}
        activeMtn={activeMtn}
        selectedColor={defaultSkuDetails[0].color.displayName}
        setSelectedColor={jest.fn()}
        ispuToggleOn={false}
        setIspuToggleOn={jest.fn()}
        isShipItToggleOn={false}
        setIsShipItToggleOn={jest.fn()}
        selectedSku={defaultSkuDetails[0]}
        setSelectedSku={jest.fn()}
        selectedProtectionFeature={protectionFeatures.payload.features[1]}
        setSelectedProtectionFeature={jest.fn()}
        selectedSize={defaultSkuDetails[0].capacity}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        RemoveLinesAPIResult={RemoveLinesAPIResultWithErrorCode}
        {...props}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
    Emitter.emit('TAGGING_COMPLETED', true);
    Emitter.emit('Call_Device_Add_Cart', { id: '345' });
    Emitter.emit('Update_Selected_Insurance', { sorId: '123' });
  });
  test('component should render', async () => {
    server.use(
      rest.post(`*/getoffers`, (req, res, ctx) => {
        res.once(ctx.status(200), ctx.json(getOffers));
        const band = screen.getAllByRole('radio', {
          name: '$33.33/mo (excludes tax) 36 Monthly Payments with Verizon Visa Card',
        });
        fireEvent.click(band[0]);
        expect(band[0]).toBeChecked();
        fireEvent.click(
          screen.getByRole('button', {
            name: /add to cart/i,
          }),
        );
      }),
    );
    const textSku = await screen.findByText('iPhone 14 Pro');
    expect(textSku).toBeInTheDocument();
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });
});

describe('PDP component render with Removelines Diff Processstep for buyout', () => {
  const activeMtn = '5185673926';
  const newRemoveLineResp = {
    data: {
      serviceBody: {
        serviceResponse: {
          context: {
            contextInfo: {
              processStep: 'GridWallPDP',
            },
          },
        },
      },
    },
    status: 'fulfilled',
  };
  beforeEach(() => {
    window.store = mockStore;
    Object.defineProperty(window, 'mfe', {
      value: { scmDeviceMfeEnable: true, navigate: jest.fn() },
      configurable: true,
    });
    Object.defineProperty(window, 'vzdl', {
      value: { event: { value: '' } },
      configurable: true,
      writable: true,
    });
    window.location.href = `http://localhost/?activeMtn=${activeMtn}&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y&deviceFromCart=true`;
    Emitter.emit('TAGGING_COMPLETED', true);
    Emitter.emit('Call_Device_Add_Cart', { id: '345' });
    Emitter.emit('Update_Selected_Insurance', { sorId: '123' });
    sessionStorage.setItem('isSecondNumLocal', true);
    sessionStorage.setItem('isSAExist', true);
    sessionStorage.setItem('assistedFlags', JSON.stringify({ IS_VALID_USER: 'TRUE' }));
    sessionStorage.setItem('simFreezeInfo', JSON.stringify({ isBlocked: 'Q', simFreezeCode: 'N' }));
  });

  test('component should render buyoutToggle', async () => {
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    const cartDetailsWithBuyout = cloneDeep(cartDetails.data.data);
    cartDetailsWithBuyout.cart.lineDetails.lineInfo[0] = {
      ...cartDetailsWithBuyout.cart.lineDetails.lineInfo[0],
      buyOutDetail: { buyOutAmt: 1.0 },
    };
    const { rerender } = render(
      <PDP
        productDetails={productDetails.data}
        protectionFeatures={protectionFeatures}
        cartDetails={cartDetailsWithBuyout}
        customerProfileDetails={customerProfileDetails.data}
        activeMtn={activeMtn}
        selectedColor={defaultSkuDetails[0].color.displayName}
        setSelectedColor={jest.fn()}
        ispuToggleOn={false}
        setIspuToggleOn={jest.fn()}
        isShipItToggleOn={false}
        setIsShipItToggleOn={jest.fn()}
        selectedSku={defaultSkuDetails[0]}
        setSelectedSku={jest.fn()}
        selectedProtectionFeature={protectionFeatures.payload.features[1]}
        setSelectedProtectionFeature={jest.fn()}
        selectedSize={defaultSkuDetails[0].capacity}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        setIsE911Opened={jest.fn()}
        setIsE911Visible={jest.fn()}
        removeLinesAPI={jest.fn()}
        RemoveLinesAPIResult={RemoveLinesAPIResultWithAPIResponseWithDiffProcessStep}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
    Emitter.emit('TAGGING_COMPLETED', true);
    const buyoutToggle = await screen.findByRole('checkbox', { name: /buyout toggle/i });
    expect(buyoutToggle).not.toBeDisabled();
    fireEvent.click(buyoutToggle);
    const buyoutConfirm = await screen.findByText(
      'Removing buyout payment will require full retail pricing payment option.',
    );
    expect(buyoutConfirm).toBeInTheDocument();
    const confirmBtn = await screen.findByText('Yes');
    expect(confirmBtn).toBeInTheDocument();
    fireEvent.click(confirmBtn);
    window.vzdl.event.value = 'RemoveFromQuote';
    rerender(
      <PDP
        productDetails={productDetails.data}
        protectionFeatures={protectionFeatures}
        cartDetails={cartDetails.data.data}
        customerProfileDetails={customerProfileDetails.data}
        activeMtn={activeMtn}
        selectedColor={defaultSkuDetails[0].color.displayName}
        setSelectedColor={jest.fn()}
        ispuToggleOn={false}
        setIspuToggleOn={jest.fn()}
        isShipItToggleOn={false}
        setIsShipItToggleOn={jest.fn()}
        selectedSku={defaultSkuDetails[0]}
        setSelectedSku={jest.fn()}
        selectedProtectionFeature={protectionFeatures.payload.features[1]}
        setSelectedProtectionFeature={jest.fn()}
        selectedSize={defaultSkuDetails[0].capacity}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        setIsE911Opened={jest.fn()}
        setIsE911Visible={jest.fn()}
        removeLinesAPI={jest.fn()}
        RemoveLinesAPIResult={newRemoveLineResp}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
    Emitter.emit('TAGGING_COMPLETED', true);
  });
});
