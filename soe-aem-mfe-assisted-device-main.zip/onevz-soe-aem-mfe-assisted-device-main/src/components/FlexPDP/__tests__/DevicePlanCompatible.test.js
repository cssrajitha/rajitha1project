import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import { CHANNELS, setupChannel } from '../../../modules/test-utils/utils';
import { DEVICE_PLAN_INCOMPATIBLE_MESSAGE } from '../../constants/DeviceConstants';
import DevicePlanCompatible from '../DevicePlanCompatible';

const DEVICE_PLAN_MODAL_PROPS = {
  cartDetails: {},
  isNewLine: false,
  onClose: jest.fn(),
  showModal: true,
  removeLines: jest.fn(),
};
// jest.mock(
//   'onevzsoemfeframework/AssistedCradleService',
//   () => ({
//     __esModule: true,
//     default: jest.fn(() => ({})),
//     getAssistedCradleProperty: () => ['FALSE'],
//   }),
//   { virtual: true },
// );
jest.mock('onevzsoemfecommon/Helpers', () => ({
  getQueryParamByName: jest.fn(() => ({
    isByodUpdate: true,
  })),
  getUIContextPath: jest.fn(() => {}),
  getUIContextPathBAU: jest.fn(() => {}),
}));

const Test = (channel) => {
  setupChannel(channel);
  beforeAll(() => {
    window.mfe = {};

    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/pdp.html?activeMtn=5139074854&iSscan=true&deviceSKU=MQ8R3LL/A&isLocal=true&deviceId=350321532631401&isByodUpdate=true',
    );
    sessionStorage.setItem('newPostToPreIndicator', false);
    sessionStorage.setItem('isCostcoAgent', true);
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ isLandingRedesignFlow: 'TRUE' }));
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  let history;
  let store;
  let asFragment;
  // eslint-disable-next-line no-unused-vars
  let component;
  describe(`<DevicePlanCompatible component - ${channel}`, () => {
    test('it should mount the component', async () => {
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ ctaVisibleFFlag: 'TRUE' }));
      ({ history, store, asFragment, ...component } = render(<DevicePlanCompatible {...DEVICE_PLAN_MODAL_PROPS} />));
      expect(screen.getByTestId('devicePlanCompatibleModal')).toBeInTheDocument();
      expect(screen.getByText(DEVICE_PLAN_INCOMPATIBLE_MESSAGE)).toBeInTheDocument();
      expect(screen.getByRole('button', { name: 'Ok' })).toBeInTheDocument();
      expect(screen.getByRole('button', { name: 'Cancel and Remove' })).toBeInTheDocument();
    });

    test('close the modal popup', async () => {
      ({ history, store, asFragment, ...component } = render(<DevicePlanCompatible {...DEVICE_PLAN_MODAL_PROPS} />));
      const closeBtn = screen.getByRole('button', { name: 'Device Plan Compatible Modal close' });
      fireEvent.click(closeBtn);
    });
    test('ok onclick function', () => {
      ({ history, store, asFragment, ...component } = render(<DevicePlanCompatible {...DEVICE_PLAN_MODAL_PROPS} />));
      const okButton = screen.getByRole('button', { name: 'Ok' });
      expect(okButton).toBeInTheDocument();
      fireEvent.click(okButton);
    });
    test('ok onclick function with scmDeviceEnable is enabled', () => {
      window.mfe.scmDeviceMfeEnable = true;
      ({ history, store, asFragment, ...component } = render(<DevicePlanCompatible {...DEVICE_PLAN_MODAL_PROPS} />));

      const okButton = screen.getByRole('button', { name: 'Ok' });
      expect(okButton).toBeInTheDocument();
      fireEvent.click(okButton);
    });
    test('cancel and remove onclick function', () => {
      window.mfe.scmDeviceMfeEnable = false;
      const mockFn = jest.fn();
      ({ history, store, asFragment, ...component } = render(
        <DevicePlanCompatible {...DEVICE_PLAN_MODAL_PROPS} removeLines={mockFn} />,
      ));
      const cancelRemove = screen.getByRole('button', { name: 'Cancel and Remove' });
      expect(cancelRemove).toBeInTheDocument();
      fireEvent.click(cancelRemove);
      expect(mockFn).toBeCalled();
    });

    test('cancel and remove onclick function with scmDeviceEnable is enabled', () => {
      window.mfe.scmDeviceMfeEnable = true;
      const mockFn = jest.fn();
      ({ history, store, asFragment, ...component } = render(
        <DevicePlanCompatible {...DEVICE_PLAN_MODAL_PROPS} removeLines={mockFn} />,
      ));
      const cancelRemove = screen.getByRole('button', { name: 'Cancel and Remove' });
      expect(cancelRemove).toBeInTheDocument();
      fireEvent.click(cancelRemove);
      expect(mockFn).toBeCalled();
    });
  });
  describe(`<DevicePlanCompatible component - ${channel}`, () => {
    test('it should mount the component', async () => {
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ ctaVisibleFFlag: 'FALSE' }));
      ({ history, store, asFragment, ...component } = render(<DevicePlanCompatible {...DEVICE_PLAN_MODAL_PROPS} />));
      expect(screen.getByTestId('devicePlanCompatibleModal')).toBeInTheDocument();
      expect(screen.getByText(DEVICE_PLAN_INCOMPATIBLE_MESSAGE)).toBeInTheDocument();
      expect(screen.getByRole('button', { name: 'Ok' })).toBeInTheDocument();
      expect(screen.getByRole('button', { name: 'Cancel and Remove' })).toBeInTheDocument();
    });
  });
};

Test(CHANNELS.OMNI_TELESALES);
