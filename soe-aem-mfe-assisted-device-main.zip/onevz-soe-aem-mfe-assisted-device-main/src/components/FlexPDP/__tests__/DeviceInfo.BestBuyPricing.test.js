/* eslint-disable no-import-assign */
import React from 'react';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { isVbg } from 'onevzsoemfeframework/VbgAemUtil';
import { render } from '../../../modules/test-utils/renderHelper';
import DeviceInfo from '../DeviceInfo';
import customerProfileDetails from '../../../pages/PDP/mocks/api/customerProfile.json';

jest.mock('onevzsoemfeframework/AssistedCradleService');
jest.mock('onevzsoemfeframework/VbgAemUtil');

describe('DeviceInfo - Best Buy Pricing State Management', () => {
  const updateDeviceData = jest.fn();
  const updateDeviceId = jest.fn();
  const updateSimId = jest.fn();
  const setSelectedPaymentInfo = jest.fn();
  const setShowDeviceProtectionModal = jest.fn();
  const setUpgradeReasonType = jest.fn();
  const setisInStock = jest.fn();
  const getContractTerm = jest.fn();
  const setBuyOutAccepted = jest.fn();
  const setSkipRedirection = jest.fn();
  const removeLines = jest.fn();

  const mockProductDetails = {
    childSkus: [
      {
        sorId: 'TEST123',
        sku: '123456',
        capacity: '128GB',
        color: 'Black',
        colorvalue: 'Black',
        devicename: 'Test Device',
        logo: 'test-logo.png',
        isInStock: true,
        devicePricing: {
          devicePayment: [{ price: 33.33, contractType: 'DEVICE_PAYMENT', term: 36 }],
          fullRetailPrice: { originalPrice: 1199.99 }
        },
        price: {
          devicePayment: [{ price: 33.33, contractType: 'DEVICE_PAYMENT', term: 36 }],
          fullRetailPrice: { originalPrice: 1199.99 }
        }
      }
    ]
  };

  const mockBByPricingData = {
    storeId: '0281',
    upc: '195949046070',
    deviceSku: '5581615',
    priceInfo: [
      {
        priceId: 'cnt302',
        activationType: 'upgrade',
        purchaseType: 'FINANCED',
        contractTerm: 36,
        regularPrice: 8.33,
        currentPrice: 8.33,
        taxBasis: 299.99,
        downPaymentAmount: 0.0,
        bbyDownPayment: 0.0,
      }
    ],
  };

  const mockErrorResponse = {
    storeId: '0281',
    upc: '195949046070',
    deviceSku: '5581615',
    messages: [
      {
        messageCategory: 'CDC_MOBILE',
        messageCode: '00314',
        messageDescription: 'There are no matching pricing details for the requested parameters.',
        messageReference: 'devicePricingDetails',
        messageType: 1,
      },
    ],
  };

  beforeEach(() => {
    getAssistedCradlePropertyV2.mockReturnValue([
      '',
      'UNL',
      'FALSE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      '',
      'TRUE',
    ]);
    isVbg.mockReturnValue(false);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('UPC Code Validation', () => {
    it('should render when UPC code does not match (prevents stale data)', () => {
      render(
        <DeviceInfo
          details={mockProductDetails}
          productDetails={mockProductDetails}
          customerProfileDetails={customerProfileDetails.data}
          activeMtn="1234567890"
          selectedSku={mockProductDetails.childSkus[0]}
          setSelectedSku={jest.fn()}
          selectedColor="Black"
          setSelectedColor={jest.fn()}
          selectedSize="128GB"
          setSelectedSize={jest.fn()}
          selectedProtectionFeature={{}}
          setSelectedProtectionFeature={jest.fn()}
          ispuToggleOn={false}
          setIspuToggleOn={jest.fn()}
          isShipItToggleOn={false}
          setIsShipItToggleOn={jest.fn()}
          updateNumberShare={jest.fn()}
          setUpgradeReasonType={jest.fn()}
          updateDeviceData={updateDeviceData}
          updateDeviceId={updateDeviceId}
          updateSimId={updateSimId}
          setSelectedPaymentInfo={setSelectedPaymentInfo}
          setShowDeviceProtectionModal={setShowDeviceProtectionModal}
          setisInStock={setisInStock}
          getContractTerm={getContractTerm}
          setBuyOutAccepted={setBuyOutAccepted}
          setSkipRedirection={setSkipRedirection}
          removeLines={removeLines}
          groupByColors={jest.fn()}
          isBBYLocalOrder
          UpcCodeData="195949046070"
          bbyPricingDetailsResult={{
            data: mockBByPricingData,
            currentData: undefined,
            isError: false,
            isFetching: false,
            status: 'fulfilled',
            originalArgs: { body: { upcCode: '195949045998' } }
          }}
        />
      );
    });

    it('should render when UPC code matches current request', () => {
      render(
        <DeviceInfo
          details={mockProductDetails}
          productDetails={mockProductDetails}
          customerProfileDetails={customerProfileDetails.data}
          activeMtn="1234567890"
          selectedSku={mockProductDetails.childSkus[0]}
          setSelectedSku={jest.fn()}
          selectedColor="Black"
          setSelectedColor={jest.fn()}
          selectedSize="128GB"
          setSelectedSize={jest.fn()}
          selectedProtectionFeature={{}}
          setSelectedProtectionFeature={jest.fn()}
          ispuToggleOn={false}
          setIspuToggleOn={jest.fn()}
          isShipItToggleOn={false}
          setIsShipItToggleOn={jest.fn()}
          updateNumberShare={jest.fn()}
          setUpgradeReasonType={jest.fn()}
          updateDeviceData={updateDeviceData}
          updateDeviceId={updateDeviceId}
          updateSimId={updateSimId}
          setSelectedPaymentInfo={setSelectedPaymentInfo}
          setShowDeviceProtectionModal={setShowDeviceProtectionModal}
          setisInStock={setisInStock}
          getContractTerm={getContractTerm}
          setBuyOutAccepted={setBuyOutAccepted}
          setSkipRedirection={setSkipRedirection}
          removeLines={removeLines}
          groupByColors={jest.fn()}
          isBBYLocalOrder
          UpcCodeData="195949046070"
          bbyPricingDetailsResult={{
            data: mockBByPricingData,
            currentData: mockBByPricingData,
            isError: false,
            isFetching: false,
            status: 'fulfilled',
            originalArgs: { body: { upcCode: '195949046070' } }
          }}
        />
      );
    });
  });

  describe('Fetching State Validation', () => {
    it('should render when isFetching is true (prevents stale data)', () => {
      render(
        <DeviceInfo
          details={mockProductDetails}
          productDetails={mockProductDetails}
          customerProfileDetails={customerProfileDetails.data}
          activeMtn="1234567890"
          selectedSku={mockProductDetails.childSkus[0]}
          setSelectedSku={jest.fn()}
          selectedColor="Black"
          setSelectedColor={jest.fn()}
          selectedSize="128GB"
          setSelectedSize={jest.fn()}
          selectedProtectionFeature={{}}
          setSelectedProtectionFeature={jest.fn()}
          ispuToggleOn={false}
          setIspuToggleOn={jest.fn()}
          isShipItToggleOn={false}
          setIsShipItToggleOn={jest.fn()}
          updateNumberShare={jest.fn()}
          setUpgradeReasonType={jest.fn()}
          updateDeviceData={updateDeviceData}
          updateDeviceId={updateDeviceId}
          updateSimId={updateSimId}
          setSelectedPaymentInfo={setSelectedPaymentInfo}
          setShowDeviceProtectionModal={setShowDeviceProtectionModal}
          setisInStock={setisInStock}
          getContractTerm={getContractTerm}
          setBuyOutAccepted={setBuyOutAccepted}
          setSkipRedirection={setSkipRedirection}
          removeLines={removeLines}
          groupByColors={jest.fn()}
          isBBYLocalOrder
          UpcCodeData="195949046070"
          bbyPricingDetailsResult={{
            data: mockBByPricingData,
            currentData: undefined,
            isError: false,
            isFetching: true,
            status: 'pending',
            originalArgs: { body: { upcCode: '195949046070' } }
          }}
        />
      );
    });

    it('should render when status is pending (prevents stale data)', () => {
      render(
        <DeviceInfo
          details={mockProductDetails}
          productDetails={mockProductDetails}
          customerProfileDetails={customerProfileDetails.data}
          activeMtn="1234567890"
          selectedSku={mockProductDetails.childSkus[0]}
          setSelectedSku={jest.fn()}
          selectedColor="Black"
          setSelectedColor={jest.fn()}
          selectedSize="128GB"
          setSelectedSize={jest.fn()}
          selectedProtectionFeature={{}}
          setSelectedProtectionFeature={jest.fn()}
          ispuToggleOn={false}
          setIspuToggleOn={jest.fn()}
          isShipItToggleOn={false}
          setIsShipItToggleOn={jest.fn()}
          updateNumberShare={jest.fn()}
          setUpgradeReasonType={jest.fn()}
          updateDeviceData={updateDeviceData}
          updateDeviceId={updateDeviceId}
          updateSimId={updateSimId}
          setSelectedPaymentInfo={setSelectedPaymentInfo}
          setShowDeviceProtectionModal={setShowDeviceProtectionModal}
          setisInStock={setisInStock}
          getContractTerm={getContractTerm}
          setBuyOutAccepted={setBuyOutAccepted}
          setSkipRedirection={setSkipRedirection}
          removeLines={removeLines}
          groupByColors={jest.fn()}
          isBBYLocalOrder
          UpcCodeData="195949046070"
          bbyPricingDetailsResult={{
            data: mockBByPricingData,
            currentData: undefined,
            isError: false,
            isFetching: false,
            status: 'pending',
            originalArgs: { body: { upcCode: '195949046070' } }
          }}
        />
      );
    });

    it('should render when request is fulfilled', () => {
      render(
        <DeviceInfo
          details={mockProductDetails}
          productDetails={mockProductDetails}
          customerProfileDetails={customerProfileDetails.data}
          activeMtn="1234567890"
          selectedSku={mockProductDetails.childSkus[0]}
          setSelectedSku={jest.fn()}
          selectedColor="Black"
          setSelectedColor={jest.fn()}
          selectedSize="128GB"
          setSelectedSize={jest.fn()}
          selectedProtectionFeature={{}}
          setSelectedProtectionFeature={jest.fn()}
          ispuToggleOn={false}
          setIspuToggleOn={jest.fn()}
          isShipItToggleOn={false}
          setIsShipItToggleOn={jest.fn()}
          updateNumberShare={jest.fn()}
          setUpgradeReasonType={jest.fn()}
          updateDeviceData={updateDeviceData}
          updateDeviceId={updateDeviceId}
          updateSimId={updateSimId}
          setSelectedPaymentInfo={setSelectedPaymentInfo}
          setShowDeviceProtectionModal={setShowDeviceProtectionModal}
          setisInStock={setisInStock}
          getContractTerm={getContractTerm}
          setBuyOutAccepted={setBuyOutAccepted}
          setSkipRedirection={setSkipRedirection}
          removeLines={removeLines}
          groupByColors={jest.fn()}
          isBBYLocalOrder
          UpcCodeData="195949046070"
          bbyPricingDetailsResult={{
            data: mockBByPricingData,
            currentData: mockBByPricingData,
            isError: false,
            isFetching: false,
            status: 'fulfilled',
            originalArgs: { body: { upcCode: '195949046070' } }
          }}
        />
      );
    });
  });

  describe('Error State Handling', () => {
    it('should render when API returns error response', () => {
      render(
        <DeviceInfo
          details={mockProductDetails}
          productDetails={mockProductDetails}
          customerProfileDetails={customerProfileDetails.data}
          activeMtn="1234567890"
          selectedSku={mockProductDetails.childSkus[0]}
          setSelectedSku={jest.fn()}
          selectedColor="Black"
          setSelectedColor={jest.fn()}
          selectedSize="128GB"
          setSelectedSize={jest.fn()}
          selectedProtectionFeature={{}}
          setSelectedProtectionFeature={jest.fn()}
          ispuToggleOn={false}
          setIspuToggleOn={jest.fn()}
          isShipItToggleOn={false}
          setIsShipItToggleOn={jest.fn()}
          updateNumberShare={jest.fn()}
          setUpgradeReasonType={jest.fn()}
          updateDeviceData={updateDeviceData}
          updateDeviceId={updateDeviceId}
          updateSimId={updateSimId}
          setSelectedPaymentInfo={setSelectedPaymentInfo}
          setShowDeviceProtectionModal={setShowDeviceProtectionModal}
          setisInStock={setisInStock}
          getContractTerm={getContractTerm}
          setBuyOutAccepted={setBuyOutAccepted}
          setSkipRedirection={setSkipRedirection}
          removeLines={removeLines}
          groupByColors={jest.fn()}
          isBBYLocalOrder
          UpcCodeData="195949046070"
          bbyPricingDetailsResult={{
            data: mockErrorResponse,
            currentData: undefined,
            error: { messages: mockErrorResponse.messages },
            isError: true,
            isFetching: false,
            status: 'rejected',
            originalArgs: { body: { upcCode: '195949046070' } }
          }}
        />
      );
    });

    it('should render when priceInfo is missing', () => {
      const dataWithoutPriceInfo = {
        ...mockBByPricingData,
        priceInfo: undefined
      };

      render(
        <DeviceInfo
          details={mockProductDetails}
          productDetails={mockProductDetails}
          customerProfileDetails={customerProfileDetails.data}
          activeMtn="1234567890"
          selectedSku={mockProductDetails.childSkus[0]}
          setSelectedSku={jest.fn()}
          selectedColor="Black"
          setSelectedColor={jest.fn()}
          selectedSize="128GB"
          setSelectedSize={jest.fn()}
          selectedProtectionFeature={{}}
          setSelectedProtectionFeature={jest.fn()}
          ispuToggleOn={false}
          setIspuToggleOn={jest.fn()}
          isShipItToggleOn={false}
          setIsShipItToggleOn={jest.fn()}
          updateNumberShare={jest.fn()}
          setUpgradeReasonType={jest.fn()}
          updateDeviceData={updateDeviceData}
          updateDeviceId={updateDeviceId}
          updateSimId={updateSimId}
          setSelectedPaymentInfo={setSelectedPaymentInfo}
          setShowDeviceProtectionModal={setShowDeviceProtectionModal}
          setisInStock={setisInStock}
          getContractTerm={getContractTerm}
          setBuyOutAccepted={setBuyOutAccepted}
          setSkipRedirection={setSkipRedirection}
          removeLines={removeLines}
          groupByColors={jest.fn()}
          isBBYLocalOrder
          UpcCodeData="195949046070"
          bbyPricingDetailsResult={{
            data: dataWithoutPriceInfo,
            currentData: dataWithoutPriceInfo,
            isError: false,
            isFetching: false,
            status: 'fulfilled',
            originalArgs: { body: { upcCode: '195949046070' } }
          }}
        />
      );
    });
  });

  describe('UI Rendering - RTK Query Error State', () => {
    it('should render when bbyPricingDetailsResult.isError is true', () => {
      render(
        <DeviceInfo
          details={mockProductDetails}
          productDetails={mockProductDetails}
          customerProfileDetails={customerProfileDetails.data}
          activeMtn="1234567890"
          selectedSku={mockProductDetails.childSkus[0]}
          setSelectedSku={jest.fn()}
          selectedColor="Black"
          setSelectedColor={jest.fn()}
          selectedSize="128GB"
          setSelectedSize={jest.fn()}
          selectedProtectionFeature={{}}
          setSelectedProtectionFeature={jest.fn()}
          ispuToggleOn={false}
          setIspuToggleOn={jest.fn()}
          isShipItToggleOn={false}
          setIsShipItToggleOn={jest.fn()}
          updateNumberShare={jest.fn()}
          setUpgradeReasonType={jest.fn()}
          updateDeviceData={updateDeviceData}
          updateDeviceId={updateDeviceId}
          updateSimId={updateSimId}
          setSelectedPaymentInfo={setSelectedPaymentInfo}
          setShowDeviceProtectionModal={setShowDeviceProtectionModal}
          setisInStock={setisInStock}
          getContractTerm={getContractTerm}
          setBuyOutAccepted={setBuyOutAccepted}
          setSkipRedirection={setSkipRedirection}
          removeLines={removeLines}
          groupByColors={jest.fn()}
          isBBYLocalOrder
          UpcCodeData="195949046070"
          bbyPricingDetailsResult={{
            data: mockBByPricingData,
            currentData: undefined,
            error: { messages: mockErrorResponse.messages },
            isError: true,
            isFetching: false,
            status: 'rejected',
            originalArgs: { body: { upcCode: '195949046070' } }
          }}
        />
      );
    });

    it('should render when BByPricing would be empty', () => {
      const emptyPricingData = {
        ...mockBByPricingData,
        priceInfo: []
      };

      render(
        <DeviceInfo
          details={mockProductDetails}
          productDetails={mockProductDetails}
          customerProfileDetails={customerProfileDetails.data}
          activeMtn="1234567890"
          selectedSku={mockProductDetails.childSkus[0]}
          setSelectedSku={jest.fn()}
          selectedColor="Black"
          setSelectedColor={jest.fn()}
          selectedSize="128GB"
          setSelectedSize={jest.fn()}
          selectedProtectionFeature={{}}
          setSelectedProtectionFeature={jest.fn()}
          ispuToggleOn={false}
          setIspuToggleOn={jest.fn()}
          isShipItToggleOn={false}
          setIsShipItToggleOn={jest.fn()}
          updateNumberShare={jest.fn()}
          setUpgradeReasonType={jest.fn()}
          updateDeviceData={updateDeviceData}
          updateDeviceId={updateDeviceId}
          updateSimId={updateSimId}
          setSelectedPaymentInfo={setSelectedPaymentInfo}
          setShowDeviceProtectionModal={setShowDeviceProtectionModal}
          setisInStock={setisInStock}
          getContractTerm={getContractTerm}
          setBuyOutAccepted={setBuyOutAccepted}
          setSkipRedirection={setSkipRedirection}
          removeLines={removeLines}
          groupByColors={jest.fn()}
          isBBYLocalOrder
          UpcCodeData="195949046070"
          bbyPricingDetailsResult={{
            data: emptyPricingData,
            currentData: emptyPricingData,
            isError: false,
            isFetching: false,
            status: 'fulfilled',
            originalArgs: { body: { upcCode: '195949046070' } }
          }}
        />
      );
    });
  });

  describe('Edge Cases', () => {
    it('should not throw error when bbyPricingDetailsResult is undefined', () => {
      expect(() => {
        render(
          <DeviceInfo
            details={mockProductDetails}
            productDetails={mockProductDetails}
            customerProfileDetails={customerProfileDetails.data}
            activeMtn="1234567890"
            selectedSku={mockProductDetails.childSkus[0]}
            setSelectedSku={jest.fn()}
            selectedColor="Black"
            setSelectedColor={jest.fn()}
            selectedSize="128GB"
            setSelectedSize={jest.fn()}
            selectedProtectionFeature={{}}
            setSelectedProtectionFeature={jest.fn()}
            ispuToggleOn={false}
            setIspuToggleOn={jest.fn()}
            isShipItToggleOn={false}
            setIsShipItToggleOn={jest.fn()}
            updateNumberShare={jest.fn()}
            setUpgradeReasonType={jest.fn()}
            updateDeviceData={updateDeviceData}
            updateDeviceId={updateDeviceId}
            updateSimId={updateSimId}
            setSelectedPaymentInfo={setSelectedPaymentInfo}
            setShowDeviceProtectionModal={setShowDeviceProtectionModal}
            setisInStock={setisInStock}
            getContractTerm={getContractTerm}
            setBuyOutAccepted={setBuyOutAccepted}
            setSkipRedirection={setSkipRedirection}
            removeLines={removeLines}
            groupByColors={jest.fn()}
            isBBYLocalOrder
            UpcCodeData="195949046070"
            bbyPricingDetailsResult={undefined}
          />
        );
      }).not.toThrow();
    });

    it('should render when originalArgs is null', () => {
      render(
        <DeviceInfo
          details={mockProductDetails}
          productDetails={mockProductDetails}
          customerProfileDetails={customerProfileDetails.data}
          activeMtn="1234567890"
          selectedSku={mockProductDetails.childSkus[0]}
          setSelectedSku={jest.fn()}
          selectedColor="Black"
          setSelectedColor={jest.fn()}
          selectedSize="128GB"
          setSelectedSize={jest.fn()}
          selectedProtectionFeature={{}}
          setSelectedProtectionFeature={jest.fn()}
          ispuToggleOn={false}
          setIspuToggleOn={jest.fn()}
          isShipItToggleOn={false}
          setIsShipItToggleOn={jest.fn()}
          updateNumberShare={jest.fn()}
          setUpgradeReasonType={jest.fn()}
          updateDeviceData={updateDeviceData}
          updateDeviceId={updateDeviceId}
          updateSimId={updateSimId}
          setSelectedPaymentInfo={setSelectedPaymentInfo}
          setShowDeviceProtectionModal={setShowDeviceProtectionModal}
          setisInStock={setisInStock}
          getContractTerm={getContractTerm}
          setBuyOutAccepted={setBuyOutAccepted}
          setSkipRedirection={setSkipRedirection}
          removeLines={removeLines}
          groupByColors={jest.fn()}
          isBBYLocalOrder
          UpcCodeData="195949046070"
          bbyPricingDetailsResult={{
            data: mockBByPricingData,
            currentData: undefined,
            isError: false,
            isFetching: false,
            status: 'fulfilled',
            originalArgs: null
          }}
        />
      );
    });
  });
});
