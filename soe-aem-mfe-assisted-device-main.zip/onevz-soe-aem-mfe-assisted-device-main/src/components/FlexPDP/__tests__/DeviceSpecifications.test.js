import React from 'react';
import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import DeviceSpecifications from '../DeviceSpecifications';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';

jest.mock('onevzsoemfecommon/Helpers', () => ({
  decodeHTMLEntities: jest.fn((text) => text),
}));

describe('DeviceSpecifications Component', () => {
  const defaultProps = {
    specsData: {
      Display: '6.1-inch display',
      Chip: 'A15 Bionic',
    },
    inbox: 'iPhone\rCable\rDocumentation',
    OverviewDetails: 'Great device with amazing features',
    openViewCall: jest.fn(),
    isVbg: false,
  };

  beforeEach(() => {
    jest.clearAllMocks();
    // Reset window.mfe
    delete window.mfe;
  });

  test('renders component with tabs', () => {
    render(<DeviceSpecifications {...defaultProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    expect(screen.getByRole('tab', { name: 'Overview' })).toBeInTheDocument();
    expect(screen.getByRole('tab', { name: 'Specs' })).toBeInTheDocument();
    expect(screen.getByRole('tab', { name: 'In the box' })).toBeInTheDocument();
  });

  test('displays overview content', () => {
    render(<DeviceSpecifications {...defaultProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    expect(screen.getByTestId('overview-content')).toBeInTheDocument();
  });

  test('calls openViewCall when Overview tab is clicked', () => {
    render(<DeviceSpecifications {...defaultProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    fireEvent.click(screen.getByRole('tab', { name: 'Overview' }));
    expect(defaultProps.openViewCall).toHaveBeenCalledWith('View device details | Overview');
  });

  test('shows specs when Specs tab is clicked', () => {
    render(<DeviceSpecifications {...defaultProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    fireEvent.click(screen.getByRole('tab', { name: 'Specs' }));
    expect(screen.getByTestId('left-container-1')).toBeInTheDocument();
  });

  test('shows inbox items when In the box tab is clicked', () => {
    render(<DeviceSpecifications {...defaultProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    fireEvent.click(screen.getByRole('tab', { name: 'In the box' }));
    expect(screen.getByText('iPhone')).toBeInTheDocument();
  });

  test('handles VBG mode correctly', () => {
    const vbgProps = {
      ...defaultProps,
      isVbg: true,
      OverviewDetails: null,
    };

    render(<DeviceSpecifications {...vbgProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    expect(screen.getByText('No information Available')).toBeInTheDocument();
  });

  test('handles empty props gracefully', () => {
    render(<DeviceSpecifications />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    expect(screen.getByRole('tab', { name: 'Overview' })).toBeInTheDocument();
  });

  // Test for line 73 coverage - isVbg true with empty specs
  test('displays "No information Available" for specs when isVbg is true and specs are empty', () => {
    const propsWithEmptySpecs = {
      ...defaultProps,
      isVbg: true,
      specsData: {}, // Empty specs data
    };

    render(<DeviceSpecifications {...propsWithEmptySpecs} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    fireEvent.click(screen.getByRole('tab', { name: 'Specs' }));
    expect(screen.getByText('No information Available')).toBeInTheDocument();
  });

  // Test for line 102 coverage - isVbg true with empty inbox
  test('displays "No information Available" for inbox when isVbg is true and inbox is empty', () => {
    const propsWithEmptyInbox = {
      ...defaultProps,
      isVbg: true,
      inbox: null, // No inbox data
    };

    render(<DeviceSpecifications {...propsWithEmptyInbox} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    fireEvent.click(screen.getByRole('tab', { name: 'In the box' }));
    expect(screen.getByText('No information Available')).toBeInTheDocument();
  });

  test('displays "No information Available" for inbox when isVbg is true and inbox is empty string', () => {
    const propsWithEmptyInbox = {
      ...defaultProps,
      isVbg: true,
      inbox: '', // Empty inbox string
    };

    render(<DeviceSpecifications {...propsWithEmptyInbox} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    fireEvent.click(screen.getByRole('tab', { name: 'In the box' }));
    expect(screen.getByText('No information Available')).toBeInTheDocument();
  });

  // Test for lines 18-19 coverage - window.mfe.isProspectNewCustomerTab = true
  test('renders with prospect new customer tab styling when window.mfe.isProspectNewCustomerTab is true', () => {
    // Mock window.mfe.isProspectNewCustomerTab = true
    window.mfe = { isProspectNewCustomerTab: true };

    render(<DeviceSpecifications {...defaultProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    expect(screen.getByRole('tab', { name: 'Overview' })).toBeInTheDocument();
  });

  // Test for lines 18-19 coverage - window.mfe.isProspectNewCustomerTab = false/undefined
  test('renders with normal styling when window.mfe.isProspectNewCustomerTab is false', () => {
    // Mock window.mfe.isProspectNewCustomerTab = false
    window.mfe = { isProspectNewCustomerTab: false };

    render(<DeviceSpecifications {...defaultProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    expect(screen.getByRole('tab', { name: 'Overview' })).toBeInTheDocument();
  });

  test('renders with normal styling when window.mfe is undefined', () => {
    // Ensure window.mfe is undefined
    delete window.mfe;

    render(<DeviceSpecifications {...defaultProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    expect(screen.getByRole('tab', { name: 'Overview' })).toBeInTheDocument();
  });
});
