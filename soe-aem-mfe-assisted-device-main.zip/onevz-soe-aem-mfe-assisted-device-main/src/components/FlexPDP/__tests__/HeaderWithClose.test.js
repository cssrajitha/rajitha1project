import { render, screen } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import HeaderWithClose from '../HeaderWithClose';

describe('<HeaderWithClose/>', () => {
  it('should test title and link should be #', () => {
    const mockAction = jest.fn();
    const title = 'title';
    render(<HeaderWithClose title={title} action={mockAction} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    expect(screen.getByText(/title/i)).toBeInTheDocument();
    expect(screen.getByRole('link')).toHaveAttribute('href', '#');
  });
  it('should test title and link should be /pdp', () => {
    const mockAction = jest.fn();
    const title = 'title';
    const href = '/pdp';
    render(<HeaderWithClose title={title} action={mockAction} href={href} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    expect(screen.getByRole('link')).toHaveAttribute('href', '/pdp');
  });
});
