import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import PDP from '../PDP';
import props from './PDPDeviceDaccProps.json';
import propsEdit from './PDPEditDeviceDaccProps.json';

jest.setTimeout(50000);
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradleProperty: () => [
      'TRUE',
      true,
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      '',
      '',
      'TRUE',
      'TRUE',
      '',
      '',
      '',
      'TRUE',
    ],
    getAssistedCradlePropertyV2: () => [
      'TRUE',
      true,
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      '',
      '',
      'TRUE',
      'TRUE',
      '',
      '',
      '',
      'TRUE',
    ],
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => false,
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

describe('PDP component render for Local Scan DACC Device', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });

  beforeAll(() => {
    sessionStorage.setItem('refundexchange', 'false');
    sessionStorage.setItem('isSecondNumLocal', true);
    sessionStorage.setItem('isSAExist', true);
    sessionStorage.setItem('isSANew', true);
    // sessionStorage.setItem('isSecondNumDfill', 'false');
    const location = {
      ...window.location,
      search: `?isScanDsDs=true&deviceId=5666666&imei1=777777&imei2&eDeviceSku=SAMSU&offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&isLocal=true&deviceId=350169643218109&simId=89148000009739425736&eSim=true&scanFromLanding=true`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?isScanDsDs=true&deviceId=5666666&imei1=777777&imei2&eDeviceSku=SAMSU&offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&isLocal=true&deviceId=350169643218109&simId=89148000009739425736&eSim=true&scanFromLanding=true`;
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    Object.defineProperty(window, 'mfe', {
      value: { scmDeviceMfeEnable: true },
      configurable: true,
    });
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...props}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test.skip('component should render', async () => {
    const addTocartBtn = await screen.getByRole('button', {
      name: /Add to Cart/i,
    });
    expect(addTocartBtn).toBeInTheDocument();
    fireEvent.click(addTocartBtn);
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Continue' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 5000);
    });
  });
});

describe('PDP component render for Local Scan DACC Device Edit Flow', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });

  beforeAll(() => {
    sessionStorage.setItem('refundexchange', 'false');
    sessionStorage.setItem('isSecondNumDfill', 'false');
    sessionStorage.setItem('isSecondNumLocal', true);
    sessionStorage.setItem('isSAExist', true);
    sessionStorage.setItem('isSANew', true);
    const location = {
      ...window.location,
      search: `?deviceFromCart=true&offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&isLocal=true&deviceId=350169643218109&simId=89148000009739425736&eSim=true&scanFromLanding=true`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?deviceFromCart=true&offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&isLocal=true&deviceId=350169643218109&simId=89148000009739425736&eSim=true&scanFromLanding=true`;
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    // window.mfe.scmDeviceMfeEnable = false;
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...propsEdit}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('component should render', async () => {
    const addTocartBtn = await screen.getByRole('button', {
      name: /Update/i,
    });
    expect(addTocartBtn).toBeInTheDocument();
    fireEvent.click(addTocartBtn);
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Continue' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 5000);
    });
  });
  test('component should render', async () => {
    const buyoutText = await screen.getByRole('heading', {
      name: 'Buyout Amount $777.7 Accepted',
    });
    expect(buyoutText).toBeInTheDocument();
  });
});

describe('PDP component render for Local Scan with PrefferedSoftSim in queryparams', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });

  beforeAll(() => {
    sessionStorage.setItem('channel', 'retail');
    const location = {
      ...window.location,
      search: `&preferredSoftSim=UNIVESIM5G-SA-A&isLocal=true&eSim=true&deviceId=5666666&imei1=777777&imei2&eDeviceSku=SAMSU&offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&deviceId=350169643218109`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?&preferredSoftSim=UNIVESIM5G-SA-A&isLocal=true&eSim=true&deviceId=5666666&imei1=777777&imei2&eDeviceSku=SAMSU&offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&deviceId=350169643218109`;
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...props}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('component should render', async () => {
    const addTocartBtn = await screen.getByRole('button', {
      name: /Update/i,
    });
    expect(addTocartBtn).toBeInTheDocument();
    fireEvent.click(addTocartBtn);
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Continue' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 5000);
    });
  });
});

describe('PDP component render for Local Scan with PrefferedSoftSim and simid', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });

  beforeAll(() => {
    sessionStorage.setItem('channel', 'retail');
    const location = {
      ...window.location,
      search: `&simId=8914800000973942573&preferredSoftSim=UNIVESIM5G-SA-A&isLocal=true&eSim=true&deviceId=5666666&imei1=777777&imei2&eDeviceSku=SAMSU&offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&deviceId=350169643218109`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?simId=8914800000973942573&preferredSoftSim=UNIVESIM5G-SA-A&isLocal=true&eSim=true&deviceId=5666666&imei1=777777&imei2&eDeviceSku=SAMSU&offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&deviceId=350169643218109`;
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...props}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('component should render', async () => {
    const addTocartBtn = await screen.getByRole('button', {
      name: /Update/i,
    });
    expect(addTocartBtn).toBeInTheDocument();
    fireEvent.click(addTocartBtn);
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Continue' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 5000);
    });
  });
});

describe('PDP component render for BYOD Edit with sim ID', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });

  beforeAll(() => {
    sessionStorage.setItem('channel', 'care');
    const location = {
      ...window.location,
      search: `&isEditAndView=true&isByodUpdate=true&eSim=true&simId=8914800000973942573&preferredSoftSim=UNIVESIM5G-SA-A&isLocal=true&eSim=true&deviceId=5666666&imei1=777777&imei2&eDeviceSku=SAMSU&offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&deviceId=350169643218109`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?isEditAndView=true&isByodUpdate=true&eSim=true&simId=8914800000973942573&preferredSoftSim=UNIVESIM5G-SA-A&isLocal=true&eSim=true&deviceId=5666666&imei1=777777&imei2&eDeviceSku=SAMSU&offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&deviceId=350169643218109`;
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...props}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('component should render', async () => {
    const addTocartBtn = await screen.getByRole('button', {
      name: /Update/i,
    });
    expect(addTocartBtn).toBeInTheDocument();
    fireEvent.click(addTocartBtn);
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Continue' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 5000);
    });
  });
});
describe('PDP component render for BYOD Edit with sim ID indirect with launchpackagesku', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });

  beforeAll(() => {
    sessionStorage.setItem('channel', 'inDirect');
    const location = {
      ...window.location,
      search: `&isEditAndView=true&isByodUpdate=truee&simId=8914800000973942573&preferredSoftSim=UNIVESIM5G-SA-A&isLocal=true&deviceId=5666666&imei1=777777&imei2&eDeviceSku=SAMSU&offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&deviceId=350169643218109&launchPackageSku=abc`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?isEditAndView=true&isByodUpdate=true&simId=8914800000973942573&preferredSoftSim=UNIVESIM5G-SA-A&isLocal=true&deviceId=5666666&imei1=777777&imei2&eDeviceSku=SAMSU&offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&deviceId=350169643218109&launchPackageSku=abc`;
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...props}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('component should render', async () => {
    const addTocartBtn = await screen.getByRole('button', {
      name: /Update/i,
    });
    expect(addTocartBtn).toBeInTheDocument();
    fireEvent.click(addTocartBtn);
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Continue' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 5000);
    });
  });
});

describe('PDP component render for BYOD Edit with sim sku not for retail channel', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });

  beforeAll(() => {
    sessionStorage.setItem('channel', 'care');
    const location = {
      ...window.location,
      search: `&isEditAndView=true&isByodUpdate=true&deviceId=5666666&imei1=777777&imei2&eDeviceSku=SAMSU&offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&deviceId=350169643218109`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?isEditAndView=true&isByodUpdate=true&deviceId=5666666&imei1=777777&imei2&eDeviceSku=SAMSU&offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&deviceId=350169643218109`;
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...props}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('component should render', async () => {
    const addTocartBtn = await screen.getByRole('button', {
      name: /Update/i,
    });
    expect(addTocartBtn).toBeInTheDocument();
    fireEvent.click(addTocartBtn);
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Continue' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 5000);
    });
  });
});
describe('PDP component render for Local Scan BBY flow', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });

  beforeAll(() => {
    const location = {
      ...window.location,
      search: `?deviceFromCart=true&offerEligible=Y&activeMtn=6165029774&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&isLocal=true&deviceId=350169643218109&simId=89148000009739425736&eSim=true&scanFromLanding=true`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?deviceFromCart=true&offerEligible=Y&activeMtn=6165029774&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&isLocal=true&deviceId=350169643218109&simId=89148000009739425736&eSim=true&scanFromLanding=true`;
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    // window.mfe.scmDeviceMfeEnable = false;
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...propsEdit}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('component should render', async () => {
    const addTocartBtn = await screen.getByRole('button', {
      name: /Update/i,
    });
    expect(addTocartBtn).toBeInTheDocument();
    fireEvent.click(addTocartBtn);
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Continue' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 5000);
    });
  });
});
