import { render, fireEvent } from '../../../modules/test-utils/renderHelper';
import SizeSelector from '../SizeSelector';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';

const renderComponent = (skus, selectedSku = {}) => {
  const mockChooseSize = jest.fn();
  const { container } = render(<SizeSelector skus={skus} selectedSku={selectedSku} chooseSize={mockChooseSize} />, {
    reducers: rootReducer,
    sagas: rootSaga,
  });
  return {
    skus,
    selectedSku,
    chooseSize: mockChooseSize,
    container,
  };
};

describe('<SizeSelctor/>', () => {
  it('should check nothing should be rendered when skus is empty array', () => {
    const { container } = renderComponent([]);
    expect(container.querySelector('.PriceSelector--Row').innerHTML).toBe('');
  });
  it('should check nothing should be rendered when skus is undefined', () => {
    const { container } = renderComponent(undefined, undefined);
    expect(container.querySelector('.PriceSelector--Row')).toBeNull();
  });
  it('should check nothing should be rendered when skus is undefined', () => {
    const { container } = renderComponent([{ capacity: 0, capacitySize: 0 }]);
    expect(container.querySelector('.PriceSelector--Row').innerHTML).toBe('');
  });
});

describe('<SizeSelector />', () => {
  const mockChooseSize = jest.fn();

  const renderComponent1 = (skus, selectedSku = {}) =>
    render(<SizeSelector skus={skus} selectedSku={selectedSku} chooseSize={mockChooseSize} />);

  it('should render nothing when skus is an empty array', () => {
    const { container } = renderComponent1([]);
    expect(container.querySelector('.PriceSelector--Row')).not.toBeNull();
  });

  it('should render nothing when skus is undefined', () => {
    const { container } = renderComponent1(undefined);
    expect(container.querySelector('.PriceSelector--Row')).toBeNull();
  });

  it('should render size options when skus are provided', () => {
    const skus = [
      {
        id: 1,
        size: 'S',
        capacity: '41',
        color: 'Black',
        skus: [
          { id: 1, size: 'S', capacity: '41' },
          { id: 2, size: 'M', capacity: '43' },
          { id: 3, size: 'L', capacity: '45' },
        ],
      },
      {
        id: 2,
        size: 'S',
        capacity: '43',
        color: 'red',
        skus: [
          { id: 1, size: 'S', capacity: '41' },
          { id: 2, size: 'M', capacity: '43' },
          { id: 3, size: 'L', capacity: '45' },
        ],
      },
    ];
    const selectedSku = {
      id: 2,
      size: 'M',
      capacity: '43',
      color: {
        displayName: 'Black',
      },
    };
    const { getByText } = renderComponent1(skus, selectedSku);
    expect(getByText('41')).toBeInTheDocument();
    expect(getByText('43')).toBeInTheDocument();
    expect(getByText('45')).toBeInTheDocument();
  });

  it('should call chooseSize when a size is selected', () => {
    const skus = [
      {
        id: 1,
        size: 'S',
        capacity: '41',
        color: 'Black',
        skus: [
          { id: 1, size: 'S', capacity: '41' },
          { id: 2, size: 'M', capacity: '43' },
          { id: 3, size: 'L', capacity: '45' },
        ],
      },
      {
        id: 2,
        size: 'S',
        capacity: '43',
        color: 'red',
        skus: [
          { id: 1, size: 'S', capacity: '41' },
          { id: 2, size: 'M', capacity: '43' },
          { id: 3, size: 'L', capacity: '45' },
        ],
      },
    ];
    const selectedSku = {
      id: 2,
      size: 'M',
      capacity: '43',
      color: {
        displayName: 'Black',
      },
    };
    const { getByText } = renderComponent1(skus, selectedSku);
    fireEvent.click(getByText('43'));
  });

  it('should call chooseSize when a size is selected', () => {
    const skus = [
      {
        id: 1,
        size: 'S',
        capacity: 'TB',
        color: 'Black',
        skus: [
          { id: 1, size: 'S', capacity: 'TB' },
          { id: 2, size: 'M', capacity: 'TB' },
          { id: 3, size: 'L', capacity: 'TB' },
        ],
      },
      {
        id: 2,
        size: 'S',
        capacity: 'TB',
        color: 'red',
        skus: [
          { id: 1, size: 'S', capacity: 'TB' },
          { id: 2, size: 'M', capacity: 'TB' },
          { id: 3, size: 'L', capacity: 'TB' },
        ],
      },
    ];
    const selectedSku = {
      id: 2,
      size: 'M',
      capacity: 'TB',
      color: {
        displayName: 'Black',
      },
    };
    const { getByText } = renderComponent1(skus, selectedSku);
    fireEvent.click(getByText('TB'));
  });
});
