import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import { CHANNELS, setupChannel } from '../../../modules/test-utils/utils';
import IneligibleDevicesModal from '../IncompatibleModal';

const INELIGIBLE_DEVICE_MODAL_PROPS = {
  setIinEligibleDevice: jest.fn(),
  onAddDeviceToCart: jest.fn(),
  onClose: jest.fn(),
  activeMtn: '7245678904',
  showModal: true,
};
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradleProperty: () => ['FALSE'],
  }),
  { virtual: true },
);
jest.mock('onevzsoemfecommon/Helpers', () => ({
  getQueryParamByName: jest.fn(() => ({
    isByodUpdate: true,
    offerEligible: true,
  })),
  getUIContextPath: jest.fn(() => {}),
  getUIContextPathBAU: jest.fn(() => {}),
}));

const Test = (channel) => {
  setupChannel(channel);
  beforeAll(() => {
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/pdp.html?activeMtn=5139074854&iSscan=true&deviceSKU=MQ8R3LL/A&isLocal=true&deviceId=350321532631401&isByodUpdate=true&offerEligible=true',
    );
    sessionStorage.setItem('newPostToPreIndicator', false);
    sessionStorage.setItem('isCostcoAgent', true);
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({ isLandingRedesignFlow: 'TRUE', vdsUpgradationFFlag: 'TRUE' }),
    );
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  describe(`<IneligibleDevicesModal component - ${channel}`, () => {
    test('it should mount and test selected device', async () => {
      render(<IneligibleDevicesModal {...INELIGIBLE_DEVICE_MODAL_PROPS} />);
      expect(screen.getByTestId('ineligibleDevicesModalupdate')).toBeInTheDocument();
      expect(screen.getByText('The selected device and offer are incompatible')).toBeInTheDocument();
      expect(screen.getByText('Continue with selected device')).toBeInTheDocument();
      expect(screen.getByText('Continue with selected offer')).toBeInTheDocument();
      expect(screen.getByText('Continue')).toBeInTheDocument();

      const radioBtn = screen.getByRole('radio', {
        name: 'selectedOffer',
      });
      fireEvent.click(radioBtn);
      const continueBtn = screen.getByRole('button', { name: 'Continue' });
      fireEvent.click(continueBtn);
    });
    test('test BYOD flow selected device', async () => {
      render(<IneligibleDevicesModal {...INELIGIBLE_DEVICE_MODAL_PROPS} />);
      const radioBtn = screen.getByRole('radio', {
        name: 'selectedOffer',
      });
      fireEvent.click(radioBtn);
      const continueBtn = screen.getByRole('button', { name: 'Continue' });
      expect(continueBtn).not.toBeDisabled();
      fireEvent.click(continueBtn);
    });
    test('it test selected Offer', async () => {
      render(<IneligibleDevicesModal {...INELIGIBLE_DEVICE_MODAL_PROPS} />);
      const radioBtn = screen.getByRole('radio', {
        name: 'selectedOffer',
      });
      fireEvent.click(radioBtn);
      const continueBtn = screen.getByRole('button', { name: 'Continue' });
      expect(continueBtn).not.toBeDisabled();
      fireEvent.click(continueBtn);
    });
    test('close the modal popup', async () => {
      render(<IneligibleDevicesModal {...INELIGIBLE_DEVICE_MODAL_PROPS} />);
      const closeBtn = screen.getByRole('button', { name: 'Testing Modal close' });
      fireEvent.click(closeBtn);
    });
  });
};

Test(CHANNELS.OMNI_TELESALES);
