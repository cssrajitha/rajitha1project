import React from 'react';
import { render } from '../../../modules/test-utils/renderHelper';
import PDP from '../PDP';
import productDetails from '../../../pages/PDP/mocks/api/getDetails.json';
import DeviceInfo from '../DeviceInfo';
import { isIndirect } from 'onevzsoemfeframework/DomService';
import { isVbg } from 'onevzsoemfeframework/VbgAemUtil';

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

jest.mock('onevzsoemfeframework/VbgAemUtil', () => ({
  __esModule: true,
  ...jest.requireActual('onevzsoemfeframework/VbgAemUtil'),
  isVbg: jest.fn(() => false),
}));

const details = productDetails.data.deviceProduct || {};
const defaultSkuStringValue = details?.defaultSKU || '';
const defaultSkuObjValue = details?.defaultSKUObj?.sorId || '';
const dispatchedActions = [];
const mockStore = {
  dispatch: (action) => {
    dispatchedActions.push(action);
  },
};

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradleProperty: () => [
      false,
      true,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      'TRUE',
      'TRUE',
    ],
    getAssistedCradlePropertyV2: () =>[
      false,
      true,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      'TRUE',
      'TRUE',
    ],
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => false,
    isIndirect: jest.fn().mockReturnValue(false),
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfecommon/APIService',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('onevzsoemfecommon/APIService'),
      useAddDeviceMutation: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                serviceBody: {
                  serviceResponse: {
                    context: {
                      contextInfo: {
                        processStep: '',
                      },
                      cartInfo: { lines: [{ downPaymentAmtApplied: '15', device: { upgradeReasonCode: 'UN' } }] },
                    },
                  },
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
      useAddFeaturesMutation: () => [() => {}, { data: {} }],
    };
  },
  { virtual: true },
);
jest.mock('../DeviceInfo', () => {
  return {
    __esModule: true,
    default: jest.fn(),
  };
});

// add test for getContractTerm method prop in DeviceInfo
describe('DeviceInfo getContractTerm prop', () => {
  const activeMtn = '1239724627';
  let deviceInfoProps = null;
  beforeEach(() => {
    isVbg.mockReturnValue(true);
    DeviceInfo.mockImplementation((props) => {
      deviceInfoProps = props;
      return <div data-testid="mock-device-info" />;
    });
    window.store = mockStore;
    window.mfe = {
      scmDeviceMfeEnable: true,
      scmQuoteEnable: true,
      isAcssProspectMfeEnabled: true,
      isProspectNewCustomerTab: true,
    };
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ byodSearchDeviceIdFFlag: 'TRUE' }));
    Object.defineProperty(window, 'location', {
      value: new URL(
        `http://localhost:3000/?activeMtn=${activeMtn}&offerEligible=Y&preferredSoftSim=Y&isByodUpdate=&ByodDeviceCompitable=true&isFromCPE=true&deviceId=353756110808409&simId=123`,
      ),
      configurable: true,
    });
    window.location.href = `http://localhost:3000/?activeMtn=${activeMtn}&offerEligible=Y&preferredSoftSim=Y&isByodUpdate=&deviceId=353756110808409&simId=123`;
    sessionStorage.setItem('isSecondNumLocal', true);
    sessionStorage.setItem('isSecondNumDfill', true);
    sessionStorage.setItem('isSAExist', true);
    sessionStorage.setItem('assistedFlags', JSON.stringify({ IS_VALID_USER: 'TRUE' }));
    sessionStorage.setItem('simFreezeInfo', JSON.stringify({ isBlocked: 'Y', simFreezeCode: 'N' }));
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ simProtectionTaggingFFlag: 'TRUE' }));
    sessionStorage.setItem('elvisFFlag', 'TRUE');
  });

  it('should return the correct contract term', async () => {
    isIndirect.mockReturnValue(false);
    const { getByTestId } = render(
      <PDP
        productDetails={{ deviceProduct: { productDisplayName: 'Test', techSpecs: {}, includedAccessories: '' } }}
        customerProfileDetails={{ customer: { billAccounts: [{ mtns: [{ mtn: '123', equipmentInfos: [{}] }] }] } }}
        activeMtn="123"
        cartDetails={{ cart: { lineDetails: { lineInfo: [{ mobileNumber: '123', lineActivityType: ['NSE'] }] }, orderDetails: {} } }}
        protectionFeatures={{}}
        setSelectedDeviceData={jest.fn()}
      />
    );
    expect(deviceInfoProps).toBeDefined();
    const getContractTermProp = deviceInfoProps?.getContractTerm;
    expect(typeof getContractTermProp).toBe('function');
    expect(getContractTermProp('DEVICE_PAYMENT')).toBe('VERIZON_EDGE');
    expect(getContractTermProp('MONTH_TO_MONTH')).toBe('MONTH_TO_MONTH');
    expect(getContractTermProp('1_YEAR')).toBe('ONE_YEAR');
    expect(getContractTermProp('ONE_YEAR')).toBe('ONE_YEAR');
    expect(getContractTermProp('2_YEAR')).toBe('TWO_YEAR');
    expect(getContractTermProp('TWO_YEAR')).toBe('TWO_YEAR');
    expect(getContractTermProp('3_YEAR')).toBe('THREE_YEAR');
    expect(getContractTermProp('THREE_YEAR')).toBe('THREE_YEAR');
    expect(getContractTermProp('30_MONTHS')).toBe('THIRTY_MONTHS');
    expect(getContractTermProp('THIRTY_MONTHS')).toBe('THIRTY_MONTHS');
    expect(getContractTermProp('UNKNOWN')).toBeUndefined();
  });
});
