import React from 'react';
import Emitter from 'onevzsoemfeframework/Emitter';
import { cloneDeep } from 'lodash';
import { render, screen } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import PDP from '../PDP';
import protectionFeatures from '../../../pages/PDP/mocks/api/getProtectionFeatures.json';
import getSkuDetails from '../../../pages/PDP/mocks/api/getSkuDetails.json';
import customerProfileDetails from '../../../pages/PDP/mocks/api/customerProfile.json';
import cartDetails from '../../../pages/PDP/mocks/api/retrieveCart.json';

const defaultSkuDetails = [{ color: { displayName: 'iPhone 15' } }];

const skuDetailsEmptyChildSku = cloneDeep(getSkuDetails);
skuDetailsEmptyChildSku.data.deviceSku.parentProducts[0].childSkus = [];

const skuDetailsEmptyDeviceSku = cloneDeep(getSkuDetails);
skuDetailsEmptyChildSku.data.deviceSku.parentProducts = [];

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradleProperty: () => [false, true, false],
    getAssistedCradlePropertyV2: () => [false, true, false],
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfecommon/APIService',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('onevzsoemfecommon/APIService'),
      useAddDeviceMutation: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                serviceBody: {
                  serviceResponse: {
                    context: {
                      contextInfo: {
                        processStep: 'ShoppingCart',
                      },
                      cartInfo: { lines: [{ downPaymentAmtApplied: '15', device: { upgradeReasonCode: 'UN' } }] },
                    },
                  },
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
    };
  },
  { virtual: true },
);

const RemoveLinesAPIResultWithAPIResponse = {
  data: {
    serviceBody: {
      serviceResponse: {
        context: {
          contextInfo: {
            processStep: 'MandatoryPlanSelectionPage',
          },
        },
      },
    },
  },
  status: 'fulfilled',
};

describe('PDP component render with no child sku', () => {
  const activeMtn = '5185673926';
  beforeEach(() => {
    window.location.href = `http://localhost/?activeMtn=${activeMtn}&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y`;
    Emitter.emit('TAGGING_COMPLETED', true);
    sessionStorage.setItem('isSAExist', true);

    render(
      <PDP
        productDetails={skuDetailsEmptyChildSku.data}
        protectionFeatures={protectionFeatures}
        cartDetails={cartDetails.data.data}
        customerProfileDetails={customerProfileDetails.data}
        activeMtn={activeMtn}
        selectedColor={defaultSkuDetails[0].color.displayName}
        setSelectedColor={jest.fn()}
        ispuToggleOn={false}
        setIspuToggleOn={jest.fn()}
        isShipItToggleOn={false}
        setIsShipItToggleOn={jest.fn()}
        selectedSku={defaultSkuDetails[0]}
        setSelectedSku={jest.fn()}
        selectedProtectionFeature={protectionFeatures.payload.features[1]}
        setSelectedProtectionFeature={jest.fn()}
        selectedSize={defaultSkuDetails[0].capacity}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        RemoveLinesAPIResult={RemoveLinesAPIResultWithAPIResponse}
        home5g
        setSelectedDeviceData={jest.fn()}
        setIsE911Opened={jest.fn()}
        setIsE911Visible={jest.fn()}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('component should render', async () => {
    const backButton = await screen.findByTestId('testBackGridwall');
    expect(backButton).toBeInTheDocument();
  });
});

describe('PDP component render with no devicesku', () => {
  const activeMtn = '5185673926';
  beforeEach(() => {
    window.location.href = `http://localhost/?activeMtn=${activeMtn}&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y`;
    Emitter.emit('TAGGING_COMPLETED', true);
    sessionStorage.setItem('isSAExist', true);

    render(
      <PDP
        productDetails={skuDetailsEmptyDeviceSku}
        protectionFeatures={protectionFeatures}
        cartDetails={cartDetails.data.data}
        customerProfileDetails={customerProfileDetails.data}
        activeMtn={activeMtn}
        selectedColor={defaultSkuDetails[0].color.displayName}
        setSelectedColor={jest.fn()}
        ispuToggleOn={false}
        setIspuToggleOn={jest.fn()}
        isShipItToggleOn={false}
        setIsShipItToggleOn={jest.fn()}
        selectedSku={defaultSkuDetails[0]}
        setSelectedSku={jest.fn()}
        selectedProtectionFeature={protectionFeatures.payload.features[1]}
        setSelectedProtectionFeature={jest.fn()}
        selectedSize={defaultSkuDetails[0].capacity}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        RemoveLinesAPIResult={RemoveLinesAPIResultWithAPIResponse}
        home5g
        setSelectedDeviceData={jest.fn()}
        setIsE911Opened={jest.fn()}
        setIsE911Visible={jest.fn()}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
    Emitter.emit('TAGGING_COMPLETED', true);
  });
  test('component should render', async () => {
    const backButton = await screen.findByTestId('testBackGridwall');
    expect(backButton).toBeInTheDocument();
  });
});
