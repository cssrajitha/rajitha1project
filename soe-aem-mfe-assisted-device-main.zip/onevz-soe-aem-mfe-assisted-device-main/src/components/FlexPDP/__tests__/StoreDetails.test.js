import React from 'react';
import * as params from 'onevzsoemfeframework/AssistedCradleService';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import StoreDetails from '../StoreDetails';

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: () => ['TRUE', 'TRUE'],
  }),
  { virtual: true }
);

jest.mock('../../../modules/services/APIService/APIServiceHooks', () => ({
  ...jest.requireActual('../../../modules/services/APIService/APIServiceHooks'),
  useLazyGetCheckZipcodeISPUEligibilityQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      endpointName: 'getCheckZipcodeISPUEligibility',
      requestId: 'Vsg5JONFY54mR2fbgMcZR',
      originalArgs: {
        body: {
          productId: 'dev19920011',
          intentType: 'AAL',
          defaultSku: 'MQ3R3LL/A',
          processingMTN: '2812530682',
          cartId: '78c36443-eb05-4eda-994c-97e913aef2ec',
          state: 'NJ',
          channel: 'OMNI-RETAIL',
          isApplyISPURestriction: false,
        },
      },
      startedTimeStamp: 1735632283247,
      data: {
        data: {
          deviceCatalogItems: [
            {
              productId: 'dev21412086',
              productDisplayName: 'iPhone 16',
              brandName: 'Apple',
              skus: [
                {
                  sorId: 'MQ3R3LL/A',
                  skuDisplayName: 'Apple iPhone 16 128GB in Ultramarine',
                  capacity: '128 GB',
                  isInstorePickupRestricted: true,
                },
                {
                  sorId: 'MYAT5LL/A',
                  skuDisplayName: 'Apple iPhone 16 256GB in Ultramarine',
                  capacity: '256 GB',
                  isInstorePickupRestricted: false,
                },
              ],
            },
          ],
        },
      },
      fulfilledTimeStamp: 1735632283518,
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      currentData: {
        data: {
          deviceCatalogItems: [
            {
              productId: 'dev21412086',
              productDisplayName: 'iPhone 16',
              brandName: 'Apple',
              skus: [
                {
                  sorId: 'MQ3R3LL/A',
                  skuDisplayName: 'Apple iPhone 16 128GB in Ultramarine',
                  capacity: '128 GB',
                  isInstorePickupRestricted: true,
                },
                {
                  sorId: 'MYAT5LL/A',
                  skuDisplayName: 'Apple iPhone 16 256GB in Ultramarine',
                  capacity: '256 GB',
                  isInstorePickupRestricted: false,
                },
              ],
            },
          ],
        },
      },
      isFetching: false,
    },
  ],
}));

describe('StoreDetails component render', () => {
  const props = {
    Telesales: 'TELESALES',
    stores: [
      {
        id: 'R00000004694',
        storeName: 'Watchung',
        isExpressStore: 'N',
        storeType: 'Store',
        retailId: 'R00000004694',
        storeStatus: 'Open',
        businessName: 'Verizon Wireless',
        zipPlus: '6511',
        fipsCode: '3403577600',
        area: 'Headquarters',
        region: 'Atlantic North',
        disasterImpacted: 'N',
        distance: 8.54,
        netaceLocationCode: 'D2280-01',
        zipCode: '07069',
        state: 'NJ',
        city: 'Watchung',
        phoneNumber: '9084901688',
        direct: 'Y',
        inStorePickupFlag: 'Y',
        items: {
          itemCount: 1,
          item: [
            {
              quantity: 0,
              itemCode: 'MTLW3LL/A',
              quantityAllocated: '0',
            },
          ],
        },
        hoursMon: '10:00 AM 08:00 PM',
        hoursTue: '10:00 AM 08:00 PM',
        hoursWed: '10:00 AM 08:00 PM',
        hoursThu: '10:00 AM 08:00 PM',
        hoursFri: '10:00 AM 08:00 PM',
        hoursSat: '09:00 AM 07:00 PM',
        hoursSun: '11:00 AM 06:00 PM',
        location: {
          longitude: -74.41187,
          latitude: 40.643234,
        },
        address1: '1620 Us Highway 22',
        currentGmtOffSet: '-5',
        ispuServices: 'LOCKER',
        eligbleForGoAndGrab: 'false',
        storeAvailableServices: 'LOCKER~INSTORE',
        lowInventory: false,
      },
      {
        id: 'R00000004169',
        storeName: 'Short Hills',
        isExpressStore: 'N',
        storeType: 'Store',
        retailId: 'R00000004169',
        storeStatus: 'Open',
        businessName: 'Verizon Wireless',
        zipPlus: '2746',
        fipsCode: '3401346410',
        area: 'Headquarters',
        region: 'Atlantic North',
        disasterImpacted: 'N',
        distance: 8.94,
        netaceLocationCode: 'D2230-01',
        zipCode: '07078',
        state: 'NJ',
        city: 'Short Hills',
        phoneNumber: '9733134900',
        direct: 'Y',
        inStorePickupFlag: 'Y',
        items: {
          itemCount: 1,
          item: [
            {
              quantity: 0,
              itemCode: 'MTLW3LL/A',
              quantityAllocated: '0',
            },
          ],
        },
        hoursMon: '10:00 AM 08:00 PM',
        hoursTue: '10:00 AM 08:00 PM',
        hoursWed: '10:00 AM 08:00 PM',
        hoursThu: '10:00 AM 08:00 PM',
        hoursFri: '10:00 AM 08:00 PM',
        hoursSat: '10:00 AM 08:00 PM',
        hoursSun: '11:00 AM 06:00 PM',
        location: {
          longitude: -74.3643,
          latitude: 40.740604,
        },
        address1: '1200 Morris Tpke',
        currentGmtOffSet: '-5',
        ispuServices: 'INSTORE',
        eligbleForGoAndGrab: 'false',
        storeAvailableServices: 'INSTORE',
        lowInventory: false,
      },
      {
        id: 'R00000250002',
        storeName: 'East Hanover',
        isExpressStore: 'N',
        storeType: 'Store',
        retailId: 'R00000250002',
        storeStatus: 'Open',
        businessName: 'Verizon Wireless',
        zipPlus: '3673',
        fipsCode: '3402700000',
        area: 'Headquarters',
        region: 'Atlantic North',
        disasterImpacted: 'N',
        distance: 10.4,
        netaceLocationCode: 'D2290-01',
        zipCode: '07936',
        state: 'NJ',
        city: 'East Hanover',
        phoneNumber: '9735039666',
        direct: 'Y',
        inStorePickupFlag: 'Y',
        items: {
          itemCount: 1,
          item: [
            {
              quantity: 0,
              itemCode: 'MTLW3LL/A',
              quantityAllocated: '0',
            },
          ],
        },
        hoursMon: '10:00 AM 08:00 PM',
        hoursTue: '10:00 AM 08:00 PM',
        hoursWed: '10:00 AM 08:00 PM',
        hoursThu: '10:00 AM 08:00 PM',
        hoursFri: '10:00 AM 08:00 PM',
        hoursSat: '09:00 AM 07:00 PM',
        hoursSun: '11:00 AM 06:00 PM',
        location: {
          longitude: -74.36422,
          latitude: 40.803596,
        },
        address1: '346 State Route 10',
        currentGmtOffSet: '-5',
        ispuServices: 'CURBSIDE',
        eligbleForGoAndGrab: 'false',
        storeAvailableServices: 'CURBSIDE~INSTORE',
        lowInventory: false,
      },
      {
        id: 'R00000002071',
        storeName: 'Bridgewater Commons',
        isExpressStore: 'N',
        storeType: 'Store',
        retailId: 'R00000002071',
        storeStatus: 'Open',
        businessName: 'Verizon Wireless',
        zipPlus: '2800',
        fipsCode: '3403500000',
        area: 'Headquarters',
        region: 'Atlantic North',
        disasterImpacted: 'N',
        distance: 10.64,
        netaceLocationCode: 'D2231-01',
        zipCode: '08807',
        state: 'NJ',
        city: 'Bridgewater',
        phoneNumber: '9082034000',
        direct: 'Y',
        inStorePickupFlag: 'Y',
        items: {
          itemCount: 1,
          item: [
            {
              quantity: 0,
              itemCode: 'MTLW3LL/A',
              quantityAllocated: '0',
            },
          ],
        },
        hoursMon: '10:00 AM 09:00 PM',
        hoursTue: '10:00 AM 09:00 PM',
        hoursWed: '10:00 AM 09:00 PM',
        hoursThu: '10:00 AM 09:00 PM',
        hoursFri: '10:00 AM 09:00 PM',
        hoursSat: '10:00 AM 09:00 PM',
        hoursSun: '11:00 AM 06:00 PM',
        location: {
          longitude: -74.61888,
          latitude: 40.585484,
        },
        address1: '400 Commons Way',
        address2: 'Space 2680',
        currentGmtOffSet: '-5',
        ispuServices: 'INSTORE',
        eligbleForGoAndGrab: 'false',
        storeAvailableServices: 'INSTORE',
        lowInventory: false,
      },
      {
        id: 'R00000165652',
        storeName: 'Westfield',
        isExpressStore: 'N',
        storeType: 'Store',
        retailId: 'R00000165652',
        storeStatus: 'Open',
        businessName: 'Verizon Wireless',
        zipPlus: '1421',
        fipsCode: '3403979040',
        area: 'Headquarters',
        region: 'Atlantic North',
        disasterImpacted: 'N',
        distance: 11.12,
        netaceLocationCode: 'D5425-01',
        zipCode: '07090',
        state: 'NJ',
        city: 'Westfield',
        phoneNumber: '9087891201',
        direct: 'Y',
        inStorePickupFlag: 'Y',
        items: {
          itemCount: 1,
          item: [
            {
              quantity: 0,
              itemCode: 'MTLW3LL/A',
              quantityAllocated: '0',
            },
          ],
        },
        hoursMon: '10:00 AM 08:00 PM',
        hoursTue: '10:00 AM 08:00 PM',
        hoursWed: '10:00 AM 08:00 PM',
        hoursThu: '10:00 AM 08:00 PM',
        hoursFri: '10:00 AM 08:00 PM',
        hoursSat: '09:00 AM 06:00 PM',
        hoursSun: '10:00 AM 05:00 PM',
        location: {
          longitude: -74.345955,
          latitude: 40.65034,
        },
        address1: '109 North Ave W',
        currentGmtOffSet: '-5',
        ispuServices: 'LOCKER',
        eligbleForGoAndGrab: 'false',
        storeAvailableServices: 'INSTORE~LOCKER',
        lowInventory: false,
      },
      {
        id: 'R00000246638',
        storeName: 'Succasunna',
        isExpressStore: 'N',
        storeType: 'Store',
        retailId: 'R00000246638',
        storeStatus: 'Open',
        businessName: 'Verizon Wireless',
        zipPlus: '1318',
        fipsCode: '3402771385',
        area: 'Headquarters',
        region: 'Atlantic North',
        disasterImpacted: 'N',
        distance: 11.55,
        netaceLocationCode: 'D2219-01',
        zipCode: '07876',
        state: 'NJ',
        city: 'Succasunna',
        phoneNumber: '9732524800',
        direct: 'Y',
        inStorePickupFlag: 'Y',
        items: {
          itemCount: 1,
          item: [
            {
              quantity: 0,
              itemCode: 'MTLW3LL/A',
              quantityAllocated: '0',
            },
          ],
        },
        hoursMon: '10:00 AM 08:00 PM',
        hoursTue: '10:00 AM 08:00 PM',
        hoursWed: '10:00 AM 08:00 PM',
        hoursThu: '10:00 AM 08:00 PM',
        hoursFri: '10:00 AM 08:00 PM',
        hoursSat: '10:00 AM 07:00 PM',
        hoursSun: '10:00 AM 05:00 PM',
        location: {
          longitude: -74.6436,
          latitude: 40.87009,
        },
        address1: '241 State Route 10 E',
        currentGmtOffSet: '-5',
        ispuServices: 'INSTORE',
        eligbleForGoAndGrab: 'false',
        storeAvailableServices: 'INSTORE',
        lowInventory: false,
      },
      {
        id: 'R00000001416',
        storeName: 'Union NJ',
        isExpressStore: 'N',
        storeType: 'Store',
        retailId: 'R00000001416',
        storeStatus: 'Open',
        businessName: 'Verizon Wireless',
        fipsCode: '3403974510',
        area: 'Headquarters',
        region: 'Atlantic North',
        disasterImpacted: 'N',
        distance: 12.32,
        netaceLocationCode: 'D2213-01',
        zipCode: '07083',
        state: 'NJ',
        city: 'Union',
        phoneNumber: '9086244100',
        direct: 'Y',
        inStorePickupFlag: 'Y',
        items: {
          itemCount: 1,
          item: [
            {
              quantity: 0,
              itemCode: 'MTLW3LL/A',
              quantityAllocated: '0',
            },
          ],
        },
        hoursMon: '10:00 AM 08:00 PM',
        hoursTue: '10:00 AM 08:00 PM',
        hoursWed: '10:00 AM 08:00 PM',
        hoursThu: '10:00 AM 08:00 PM',
        hoursFri: '10:00 AM 08:00 PM',
        hoursSat: '09:00 AM 07:00 PM',
        hoursSun: '11:00 AM 06:00 PM',
        location: {
          longitude: -74.303375,
          latitude: 40.689278,
        },
        address1: '2490 Us Highway 22 W',
        address2: 'Center Island',
        currentGmtOffSet: '-5',
        ispuServices: 'LOCKER',
        eligbleForGoAndGrab: 'false',
        storeAvailableServices: 'LOCKER~INSTORE',
        lowInventory: false,
      },
      {
        id: 'R00000007241',
        storeName: 'Bridgewater  RT 202',
        isExpressStore: 'N',
        storeType: 'Store',
        retailId: 'R00000007241',
        storeStatus: 'Open',
        businessName: 'Verizon Wireless',
        zipPlus: '2551',
        fipsCode: '3403500000',
        area: 'Headquarters',
        region: 'Atlantic North',
        disasterImpacted: 'N',
        distance: 12.5,
        netaceLocationCode: 'D2288-01',
        zipCode: '08807',
        state: 'NJ',
        city: 'Bridgewater',
        phoneNumber: '9082038484',
        direct: 'Y',
        inStorePickupFlag: 'Y',
        items: {
          itemCount: 1,
          item: [
            {
              quantity: 0,
              itemCode: 'MTLW3LL/A',
              quantityAllocated: '0',
            },
          ],
        },
        hoursMon: '09:00 AM 07:00 PM',
        hoursTue: '09:00 AM 07:00 PM',
        hoursWed: '09:00 AM 07:00 PM',
        hoursThu: '09:00 AM 07:00 PM',
        hoursFri: '09:00 AM 07:00 PM',
        hoursSat: '09:00 AM 06:00 PM',
        hoursSun: '10:00 AM 05:00 PM',
        location: {
          longitude: -74.66549,
          latitude: 40.574528,
        },
        address1: '756 Us Highway 202',
        currentGmtOffSet: '-5',
        ispuServices: 'CURBSIDE',
        eligbleForGoAndGrab: 'false',
        storeAvailableServices: 'CURBSIDE~INSTORE',
        lowInventory: false,
      },
      {
        id: 'R00000001783',
        storeName: 'Rockaway',
        isExpressStore: 'N',
        storeType: 'Store',
        retailId: 'R00000001783',
        storeStatus: 'Open',
        businessName: 'Verizon Wireless',
        zipPlus: '1663',
        fipsCode: '3402700000',
        area: 'Headquarters',
        region: 'Atlantic North',
        disasterImpacted: 'N',
        distance: 12.76,
        netaceLocationCode: 'D2272-01',
        zipCode: '07866',
        state: 'NJ',
        city: 'Rockaway',
        phoneNumber: '9739894360',
        direct: 'Y',
        inStorePickupFlag: 'Y',
        items: {
          itemCount: 1,
          item: [
            {
              quantity: 0,
              itemCode: 'MTLW3LL/A',
              quantityAllocated: '0',
            },
          ],
        },
        hoursMon: '10:00 AM 08:00 PM',
        hoursTue: '10:00 AM 08:00 PM',
        hoursWed: '10:00 AM 08:00 PM',
        hoursThu: '10:00 AM 08:00 PM',
        hoursFri: '10:00 AM 08:00 PM',
        hoursSat: '10:00 AM 07:00 PM',
        hoursSun: '11:00 AM 06:00 PM',
        location: {
          longitude: -74.548874,
          latitude: 40.909424,
        },
        address1: '321 Mount Hope Ave',
        currentGmtOffSet: '-5',
        ispuServices: 'INSTORE',
        eligbleForGoAndGrab: 'false',
        storeAvailableServices: 'INSTORE',
        lowInventory: false,
      },
      {
        id: 'R00000163265',
        storeName: 'South Plainfield',
        isExpressStore: 'N',
        storeType: 'Store',
        retailId: 'R00000163265',
        storeStatus: 'Open',
        businessName: 'Verizon Wireless',
        zipPlus: '1139',
        fipsCode: '3402369390',
        area: 'Headquarters',
        region: 'Atlantic North',
        disasterImpacted: 'N',
        distance: 12.94,
        netaceLocationCode: 'D5424-01',
        zipCode: '07080',
        state: 'NJ',
        city: 'South Plainfield',
        phoneNumber: '9087530801',
        direct: 'Y',
        inStorePickupFlag: 'Y',
        items: {
          itemCount: 1,
          item: [
            {
              quantity: 0,
              itemCode: 'MTLW3LL/A',
              quantityAllocated: '0',
            },
          ],
        },
        hoursMon: '10:00 AM 08:00 PM',
        hoursTue: '10:00 AM 08:00 PM',
        hoursWed: '10:00 AM 08:00 PM',
        hoursThu: '10:00 AM 08:00 PM',
        hoursFri: '10:00 AM 08:00 PM',
        hoursSat: '09:00 AM 07:00 PM',
        hoursSun: '10:00 AM 05:00 PM',
        location: {
          longitude: -74.43249,
          latitude: 40.554512,
        },
        address1: '7000 Hadley Rd',
        currentGmtOffSet: '-5',
        ispuServices: 'LOCKER',
        eligbleForGoAndGrab: 'false',
        storeAvailableServices: 'INSTORE~LOCKER',
        lowInventory: false,
      },
    ],
    setSelectedStore: jest.fn(),
    setIsIspuItemInCart: jest.fn(),
    setShowDeviceModal: jest.fn(),
    setIspuToggleOn: jest.fn(),
    setStoreList: jest.fn(),
    setIspufromCart: jest.fn(),
    setFindStoreBtnClicked: jest.fn(),
  };
  beforeEach(() => {
    jest.spyOn(params, 'getAssistedCradleProperty').mockReturnValue(['TRUE', 'TRUE']);
    render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('component should render', () => {
    const text = screen.getByText('Show only inventory available stores');
    expect(text).toBeInTheDocument();
  });
});
describe('StoreDetails component render', () => {
  const props = {
    Telesales: 'TELESALES',
    stores: [],
    setFindStoreBtnClicked: jest.fn(),
  };
  beforeEach(() => {
    jest.spyOn(params, 'getAssistedCradleProperty').mockReturnValue(['TRUE', 'TRUE']);
    render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('component should render', () => {
    const text = screen.getByText('Show only inventory available stores');
    expect(text).toBeInTheDocument();
  });
});
describe('StoreDetails component render', () => {
  const props = {
    Telesales: 'TELESALES',
    stores: [
      {
        id: 'R00000001745',
        storeName: 'Wilmington NC',
        isExpressStore: 'N',
        storeType: 'Store',
        retailId: 'R00000001745',
        storeStatus: 'Open',
        businessName: 'Verizon Wireless',
        zipPlus: '1632',
        fipsCode: '3712974440',
        area: 'Headquarters',
        region: 'Atlantic South',
        disasterImpacted: 'N',
        distance: 4.25,
        netaceLocationCode: 'P1619-01',
        zipCode: '28403',
        state: 'NC',
        city: 'Wilmington',
        phoneNumber: '9107992352',
        direct: 'N',
        inStorePickupFlag: 'Y',
        items: {
          itemCount: 1,
          item: [
            {
              quantity: 1,
              itemCode: 'MPUN3LL/A',
              quantityAllocated: '0',
            },
          ],
        },
        hoursMon: '10:00 AM 09:00 PM',
        hoursTue: '10:00 AM 09:00 PM',
        hoursWed: '10:00 AM 09:00 PM',
        hoursThu: '10:00 AM 09:00 PM',
        hoursFri: '10:00 AM 09:00 PM',
        hoursSat: '10:00 AM 09:00 PM',
        hoursSun: '10:00 AM 09:00 PM',
        location: {
          longitude: -77.87369,
          latitude: 34.2363,
        },
        address1: '318 S College Rd',
        currentGmtOffSet: '-5',
        ispuServices: 'INSTORE',
        eligbleForGoAndGrab: 'false',
        storeAvailableServices: 'INSTORE',
        lowInventory: true,
      },
      {
        id: 'R00000260458',
        storeName: 'Mayfaire ',
        isExpressStore: 'N',
        storeType: 'Store',
        retailId: 'R00000260458',
        storeStatus: 'Open',
        businessName: 'Verizon Wireless',
        zipPlus: '8361',
        fipsCode: '3712974440',
        area: 'Headquarters',
        region: 'Atlantic South',
        disasterImpacted: 'N',
        distance: 6.89,
        netaceLocationCode: 'P2598-01',
        zipCode: '28405',
        state: 'NC',
        city: 'Wilmington',
        phoneNumber: '9102565503',
        direct: 'Y',
        inStorePickupFlag: 'Y',
        items: {
          itemCount: 1,
          item: [
            {
              quantity: 1,
              itemCode: 'MPUN3LL/A',
              quantityAllocated: '0',
            },
          ],
        },
        hoursMon: '10:00 AM 09:00 PM',
        hoursTue: '10:00 AM 09:00 PM',
        hoursWed: '10:00 AM 09:00 PM',
        hoursThu: '10:00 AM 09:00 PM',
        hoursFri: '10:00 AM 09:00 PM',
        hoursSat: '10:00 AM 09:00 PM',
        hoursSun: '10:00 AM 09:00 PM',
        location: {
          longitude: -77.82743,
          latitude: 34.24288,
        },
        address1: '971 Military Cutoff Rd',
        address2: 'Unit 120',
        currentGmtOffSet: '-5',
        ispuServices: 'DS',
        eligbleForGoAndGrab: 'false',
        storeAvailableServices: 'INSTORE~DS',
        lowInventory: true,
      },
    ],
    statesList: {
      AL: 'Alabama',
      KY: 'Kentucky',
      OH: 'Ohio',
      AK: 'Alaska',
      LA: 'Louisiana',
      OK: 'Oklahoma',
      AZ: 'Arizona',
      ME: 'Maine',
      OR: 'Oregon',
      AR: 'Arkansas',
      MD: 'Maryland',
      PA: 'Pennsylvania',
      AS: 'American Samoa',
      MA: 'Massachusetts',
      PR: 'Puerto Rico',
      CA: 'California',
      MI: 'Michigan',
      RI: 'Rhode Island',
      CO: 'Colorado',
      MN: 'Minnesota',
      SC: 'South Carolina',
      CT: 'Connecticut',
      MS: 'Mississippi',
      SD: 'South Dakota',
      DE: 'Delaware',
      MO: 'Missouri',
      TN: 'Tennessee',
      DC: 'District of Columbia',
      MT: 'Montana',
      TX: 'Texas',
      FL: 'Florida',
      NE: 'Nebraska',
      TT: 'Trust Territories',
      GA: 'Georgia',
      NV: 'Nevada',
      UT: 'Utah',
      GU: 'Guam',
      NH: 'New Hampshire',
      VT: 'Vermont',
      HI: 'Hawaii',
      NJ: 'New Jersey',
      VA: 'Virginia',
      ID: 'Idaho',
      NM: 'New Mexico',
      VI: 'Virgin Islands',
      IL: 'Illinois',
      NY: 'New York',
      WA: 'Washington',
      IN: 'Indiana',
      NC: 'North Carolina',
      WV: 'West Virginia',
      IA: 'Iowa',
      ND: 'North Dakota',
      WI: 'Wisconsin',
      KS: 'Kansas',
      MP: 'Northern Mariana Islands',
      WY: 'Wyoming',
    },
    setSelectedStore: jest.fn(),
    setIsIspuItemInCart: jest.fn(),
    setShowDeviceModal: jest.fn(),
    setIspuToggleOn: jest.fn(),
    setStoreList: jest.fn(),
    setIspufromCart: jest.fn(),
    setFindStoreBtnClicked: jest.fn(),
  };
  beforeEach(() => {
    jest.spyOn(params, 'getAssistedCradleProperty').mockReturnValue(['TRUE', 'TRUE']);
    render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('component should render', () => {
    const text = screen.getByText('Show only inventory available stores');
    expect(text).toBeInTheDocument();
  });
  test('Pickup button onclick function', () => {
    const pickup = screen.getAllByText(/Pickup from this store/i);
    fireEvent.click(pickup[0]);
  });
});

describe('StoreDetails component render', () => {
  const props = {
    Telesales: 'TELESALES',
    stores: [
      {
        items: { itemCount: 1, item: [{ quantity: 2 }] },
        hoursSun: 'AM ',
        hoursMon: 'AM ',
        hoursTue: 'AM ',
        hoursWed: 'AM ',
        hoursThu: 'AM ',
        hoursFri: 'AM ',
        hoursSat: 'AM ',
        estimatedReadyByDate: '30 june',
        estMaxDate: '5 july',
        storeAvailableServices: 'CURBSIDE LOCKER',
        id: '0281',
      },
      {
        items: { itemCount: 1, item: [{ quantity: 2 }] },
        hoursSun: 'Closed ',
        hoursMon: 'Closed ',
        hoursTue: 'Closed ',
        hoursWed: 'Closed ',
        hoursThu: 'Closed ',
        hoursFri: 'Closed ',
        hoursSat: 'Closed ',
        storeAvailableServices: 'CURBSIDE LOCKER',
      },
      {
        items: { itemCount: 1, item: [{ quantity: 2 }] },
        hoursSun: 'PM ',
        hoursMon: 'PM ',
        hoursTue: 'PM ',
        hoursWed: 'PM ',
        hoursThu: 'PM ',
        hoursFri: 'PM ',
        hoursSat: 'PM ',
        storeAvailableServices: 'CURBSIDE LOCKER',
      },
      { storeAvailableServices: 'CURBSIDE LOCKER', items: { item: [] } },
    ],
    setSelectedStore: jest.fn(),
    setIsIspuItemInCart: jest.fn(),
    setShowDeviceModal: jest.fn(),
    setIspuToggleOn: jest.fn(),
    setStoreList: jest.fn(),
    setIspufromCart: jest.fn(),
    setFindStoreBtnClicked: jest.fn(),
    checkInStoreResult: {
      status: 'pending',
      endpointName: 'getCheckInStoreAvailability',
      requestId: 'hKNQHddmzAIaqYkTYbj5t',
      originalArgs: {
        body: {
          meta: {
            clientCorrrelationId:
              'ick-ClrSuZPeM-UmBI-2SFB6t1zB_dFDy3IfCcConCuwmPSIXyrD!1375284084!obsneocgzap08!5106!-1!1564408961747',
            timestamp: '2019-07-29T10:25:59.791-04:00',
          },
          data: {
            zipCode: '30329',
            sorIds: 'MQ3R3LL/A',
            customerType: 'N',
            excludeIndirect: false,
            range: 50,
            showOnlyAvailableStores: true,
          },
        },
      },
      startedTimeStamp: 1735630304551,
      isUninitialized: false,
      isLoading: true,
      isSuccess: false,
      isError: false,
      isFetching: true,
      data: {
        stores: [
          {
            id: 'R00000004694',
            storeName: 'Watchung',
            isExpressStore: 'N',
            storeType: 'Store',
            retailId: 'R00000004694',
            storeStatus: 'Open',
            businessName: 'Verizon Wireless',
            zipPlus: '6511',
            fipsCode: '3403577600',
            area: 'Headquarters',
            region: 'Atlantic North',
            disasterImpacted: 'N',
            distance: 8.54,
            netaceLocationCode: 'D2280-01',
            zipCode: '07069',
            state: 'NJ',
            city: 'Watchung',
            phoneNumber: '9084901688',
            direct: 'Y',
            inStorePickupFlag: 'Y',
            items: {
              itemCount: 1,
              item: [
                {
                  quantity: 0,
                  itemCode: 'MTLW3LL/A',
                  quantityAllocated: '0',
                },
              ],
            },
            hoursMon: '10:00 AM 08:00 PM',
            hoursTue: '10:00 AM 08:00 PM',
            hoursWed: '10:00 AM 08:00 PM',
            hoursThu: '10:00 AM 08:00 PM',
            hoursFri: '10:00 AM 08:00 PM',
            hoursSat: '09:00 AM 07:00 PM',
            hoursSun: '11:00 AM 06:00 PM',
            location: {
              longitude: -74.41187,
              latitude: 40.643234,
            },
            address1: '1620 Us Highway 22',
            currentGmtOffSet: '-5',
            ispuServices: 'LOCKER',
            eligbleForGoAndGrab: 'false',
            storeAvailableServices: 'LOCKER~INSTORE',
            lowInventory: false,
          },
          {
            id: 'R00000004169',
            storeName: 'Short Hills',
            isExpressStore: 'N',
            storeType: 'Store',
            retailId: 'R00000004169',
            storeStatus: 'Open',
            businessName: 'Verizon Wireless',
            zipPlus: '2746',
            fipsCode: '3401346410',
            area: 'Headquarters',
            region: 'Atlantic North',
            disasterImpacted: 'N',
            distance: 8.94,
            netaceLocationCode: 'D2230-01',
            zipCode: '07078',
            state: 'NJ',
            city: 'Short Hills',
            phoneNumber: '9733134900',
            direct: 'Y',
            inStorePickupFlag: 'Y',
            items: {
              itemCount: 1,
              item: [
                {
                  quantity: 0,
                  itemCode: 'MTLW3LL/A',
                  quantityAllocated: '0',
                },
              ],
            },
            hoursMon: '10:00 AM 08:00 PM',
            hoursTue: '10:00 AM 08:00 PM',
            hoursWed: '10:00 AM 08:00 PM',
            hoursThu: '10:00 AM 08:00 PM',
            hoursFri: '10:00 AM 08:00 PM',
            hoursSat: '10:00 AM 08:00 PM',
            hoursSun: '11:00 AM 06:00 PM',
            location: {
              longitude: -74.3643,
              latitude: 40.740604,
            },
            address1: '1200 Morris Tpke',
            currentGmtOffSet: '-5',
            ispuServices: 'INSTORE',
            eligbleForGoAndGrab: 'false',
            storeAvailableServices: 'INSTORE',
            lowInventory: false,
          },
        ],
      },
    },
    checkZipCodeIspuResult: {
      status: 'fulfilled',
      endpointName: 'getCheckZipcodeISPUEligibility',
      requestId: 'Vsg5JONFY54mR2fbgMcZR',
      originalArgs: {
        body: {
          productId: 'dev19920011',
          intentType: 'AAL',
          defaultSku: 'MQ3R3LL/A',
          processingMTN: '2812530682',
          cartId: '78c36443-eb05-4eda-994c-97e913aef2ec',
          state: 'NJ',
          channel: 'OMNI-RETAIL',
          isApplyISPURestriction: false,
        },
      },
      startedTimeStamp: 1735632283247,
      data: {
        data: {
          deviceCatalogItems: [
            {
              productId: 'dev21412086',
              productDisplayName: 'iPhone 16',
              brandName: 'Apple',
              skus: [
                {
                  sorId: 'MQ3R3LL/A',
                  skuDisplayName: 'Apple iPhone 16 128GB in Ultramarine',
                  capacity: '128 GB',
                  isInstorePickupRestricted: true,
                },
                {
                  sorId: 'MYAT5LL/A',
                  skuDisplayName: 'Apple iPhone 16 256GB in Ultramarine',
                  capacity: '256 GB',
                  isInstorePickupRestricted: false,
                },
              ],
            },
          ],
        },
      },
      fulfilledTimeStamp: 1735632283518,
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      currentData: {
        data: {
          deviceCatalogItems: [
            {
              productId: 'dev21412086',
              productDisplayName: 'iPhone 16',
              brandName: 'Apple',
              skus: [
                {
                  sorId: 'MQ3R3LL/A',
                  skuDisplayName: 'Apple iPhone 16 128GB in Ultramarine',
                  capacity: '128 GB',
                  isInstorePickupRestricted: true,
                },
                {
                  sorId: 'MYAT5LL/A',
                  skuDisplayName: 'Apple iPhone 16 256GB in Ultramarine',
                  capacity: '256 GB',
                  isInstorePickupRestricted: false,
                },
              ],
            },
          ],
        },
      },
      isFetching: false,
    },
    selectedSku: {
      sorId: 'MQ3R3LL/A',
    },
  };
  beforeEach(() => {
    jest.spyOn(params, 'getAssistedCradleProperty').mockReturnValue(['TRUE', 'TRUE']);
    render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('component should render', () => {
    const text = screen.getByText('Show only inventory available stores');
    expect(text).toBeInTheDocument();
  });
  test('Pickup button onclick function', () => {
    const pickup = screen.getAllByText(/Pickup from this store/i)[0];
    fireEvent.click(pickup);
  });
});

describe('StoreDetails component render', () => {
  const props = {
    Telesales: 'TELESALES',
    stores: [
      {
        id: 'R00000001745',
        storeName: 'Wilmington NC',
        isExpressStore: 'N',
        storeType: 'Store',
        retailId: 'R00000001745',
        storeStatus: 'Open',
        businessName: 'Verizon Wireless',
        zipPlus: '1632',
        fipsCode: '3712974440',
        area: 'Headquarters',
        region: 'Atlantic South',
        disasterImpacted: 'N',
        distance: 4.25,
        netaceLocationCode: 'P1619-01',
        zipCode: '28403',
        state: 'NC',
        city: 'Wilmington',
        phoneNumber: '9107992352',
        direct: 'N',
        inStorePickupFlag: 'Y',
        items: {
          itemCount: 1,
          item: [
            {
              quantity: 1,
              itemCode: 'MPUN3LL/A',
              quantityAllocated: '0',
            },
          ],
        },
        hoursMon: '10:00 AM 09:00 PM',
        hoursTue: '10:00 AM 09:00 PM',
        hoursWed: '10:00 AM 09:00 PM',
        hoursThu: '10:00 AM 09:00 PM',
        hoursFri: '10:00 AM 09:00 PM',
        hoursSat: '10:00 AM 09:00 PM',
        hoursSun: '10:00 AM 09:00 PM',
        location: {
          longitude: -77.87369,
          latitude: 34.2363,
        },
        address1: '318 S College Rd',
        currentGmtOffSet: '-5',
        ispuServices: 'CURBSIDE',
        eligbleForGoAndGrab: 'false',
        storeAvailableServices: 'CURBSIDE',
        lowInventory: true,
      },
      {
        id: 'R00000260458',
        storeName: 'Mayfaire ',
        isExpressStore: 'N',
        storeType: 'Store',
        retailId: 'R00000260458',
        storeStatus: 'Open',
        businessName: 'Verizon Wireless',
        zipPlus: '8361',
        fipsCode: '3712974440',
        area: 'Headquarters',
        region: 'Atlantic South',
        disasterImpacted: 'N',
        distance: 6.89,
        netaceLocationCode: 'P2598-01',
        zipCode: '28405',
        state: 'NC',
        city: 'Wilmington',
        phoneNumber: '9102565503',
        direct: 'Y',
        inStorePickupFlag: 'Y',
        items: {
          itemCount: 1,
          item: [
            {
              quantity: 1,
              itemCode: 'MPUN3LL/A',
              quantityAllocated: '0',
            },
          ],
        },
        hoursMon: '10:00 AM 09:00 PM',
        hoursTue: '10:00 AM 09:00 PM',
        hoursWed: '10:00 AM 09:00 PM',
        hoursThu: '10:00 AM 09:00 PM',
        hoursFri: '10:00 AM 09:00 PM',
        hoursSat: '10:00 AM 09:00 PM',
        hoursSun: '10:00 AM 09:00 PM',
        location: {
          longitude: -77.82743,
          latitude: 34.24288,
        },
        address1: '971 Military Cutoff Rd',
        address2: 'Unit 120',
        currentGmtOffSet: '-5',
        ispuServices: 'DS',
        eligbleForGoAndGrab: 'false',
        storeAvailableServices: 'CURBSIDE',
        lowInventory: true,
      },
    ],
    setSelectedStore: jest.fn(),
    setIsIspuItemInCart: jest.fn(),
    setShowDeviceModal: jest.fn(),
    setIspuToggleOn: jest.fn(),
    setStoreList: jest.fn(),
    setIspufromCart: jest.fn(),
    setFindStoreBtnClicked: jest.fn(),
    checkInStoreResult: {
      status: 'pending',
      endpointName: 'getCheckInStoreAvailability',
      requestId: 'hKNQHddmzAIaqYkTYbj5t',
      originalArgs: {
        body: {
          meta: {
            clientCorrrelationId:
              'ick-ClrSuZPeM-UmBI-2SFB6t1zB_dFDy3IfCcConCuwmPSIXyrD!1375284084!obsneocgzap08!5106!-1!1564408961747',
            timestamp: '2019-07-29T10:25:59.791-04:00',
          },
          data: {
            zipCode: '30329',
            sorIds: 'MQ3R3LL/A',
            customerType: 'N',
            excludeIndirect: false,
            range: 50,
            showOnlyAvailableStores: true,
          },
        },
      },
      startedTimeStamp: 1735630304551,
      isUninitialized: false,
      isLoading: true,
      isSuccess: false,
      isError: false,
      isFetching: true,
      data: {
        stores: [
          {
            id: 'R00000004694',
            storeName: 'Watchung',
            isExpressStore: 'N',
            storeType: 'Store',
            retailId: 'R00000004694',
            storeStatus: 'Open',
            businessName: 'Verizon Wireless',
            zipPlus: '6511',
            fipsCode: '3403577600',
            area: 'Headquarters',
            region: 'Atlantic North',
            disasterImpacted: 'N',
            distance: 8.54,
            netaceLocationCode: 'D2280-01',
            zipCode: '07069',
            state: 'NJ',
            city: 'Watchung',
            phoneNumber: '9084901688',
            direct: 'Y',
            inStorePickupFlag: 'Y',
            items: {
              itemCount: 1,
              item: [
                {
                  quantity: 0,
                  itemCode: 'MTLW3LL/A',
                  quantityAllocated: '0',
                },
              ],
            },
            hoursMon: '10:00 AM 08:00 PM',
            hoursTue: '10:00 AM 08:00 PM',
            hoursWed: '10:00 AM 08:00 PM',
            hoursThu: '10:00 AM 08:00 PM',
            hoursFri: '10:00 AM 08:00 PM',
            hoursSat: '09:00 AM 07:00 PM',
            hoursSun: '11:00 AM 06:00 PM',
            location: {
              longitude: -74.41187,
              latitude: 40.643234,
            },
            address1: '1620 Us Highway 22',
            currentGmtOffSet: '-5',
            ispuServices: 'LOCKER',
            eligbleForGoAndGrab: 'false',
            storeAvailableServices: 'LOCKER~INSTORE',
            lowInventory: false,
          },
          {
            id: 'R00000004169',
            storeName: 'Short Hills',
            isExpressStore: 'N',
            storeType: 'Store',
            retailId: 'R00000004169',
            storeStatus: 'Open',
            businessName: 'Verizon Wireless',
            zipPlus: '2746',
            fipsCode: '3401346410',
            area: 'Headquarters',
            region: 'Atlantic North',
            disasterImpacted: 'N',
            distance: 8.94,
            netaceLocationCode: 'D2230-01',
            zipCode: '07078',
            state: 'NJ',
            city: 'Short Hills',
            phoneNumber: '9733134900',
            direct: 'Y',
            inStorePickupFlag: 'Y',
            items: {
              itemCount: 1,
              item: [
                {
                  quantity: 0,
                  itemCode: 'MTLW3LL/A',
                  quantityAllocated: '0',
                },
              ],
            },
            hoursMon: '10:00 AM 08:00 PM',
            hoursTue: '10:00 AM 08:00 PM',
            hoursWed: '10:00 AM 08:00 PM',
            hoursThu: '10:00 AM 08:00 PM',
            hoursFri: '10:00 AM 08:00 PM',
            hoursSat: '10:00 AM 08:00 PM',
            hoursSun: '11:00 AM 06:00 PM',
            location: {
              longitude: -74.3643,
              latitude: 40.740604,
            },
            address1: '1200 Morris Tpke',
            currentGmtOffSet: '-5',
            ispuServices: 'INSTORE',
            eligbleForGoAndGrab: 'false',
            storeAvailableServices: 'INSTORE',
            lowInventory: false,
          },
        ],
      },
    },
    checkZipCodeIspuResult: {
      status: 'fulfilled',
      endpointName: 'getCheckZipcodeISPUEligibility',
      requestId: 'Vsg5JONFY54mR2fbgMcZR',
      originalArgs: {
        body: {
          productId: 'dev19920011',
          intentType: 'AAL',
          defaultSku: 'MQ3R3LL/A',
          processingMTN: '2812530682',
          cartId: '78c36443-eb05-4eda-994c-97e913aef2ec',
          state: 'NJ',
          channel: 'OMNI-RETAIL',
          isApplyISPURestriction: false,
        },
      },
      startedTimeStamp: 1735632283247,
      data: {
        data: {
          deviceCatalogItems: [
            {
              productId: 'dev21412086',
              productDisplayName: 'iPhone 16',
              brandName: 'Apple',
              skus: [
                {
                  sorId: 'MQ3R3LL/A',
                  skuDisplayName: 'Apple iPhone 16 128GB in Ultramarine',
                  capacity: '128 GB',
                  isInstorePickupRestricted: true,
                },
                {
                  sorId: 'MYAT5LL/A',
                  skuDisplayName: 'Apple iPhone 16 256GB in Ultramarine',
                  capacity: '256 GB',
                  isInstorePickupRestricted: false,
                },
              ],
            },
          ],
        },
      },
      fulfilledTimeStamp: 1735632283518,
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      currentData: {
        data: {
          deviceCatalogItems: [
            {
              productId: 'dev21412086',
              productDisplayName: 'iPhone 16',
              brandName: 'Apple',
              skus: [
                {
                  sorId: 'MQ3R3LL/A',
                  skuDisplayName: 'Apple iPhone 16 128GB in Ultramarine',
                  capacity: '128 GB',
                  isInstorePickupRestricted: true,
                },
                {
                  sorId: 'MYAT5LL/A',
                  skuDisplayName: 'Apple iPhone 16 256GB in Ultramarine',
                  capacity: '256 GB',
                  isInstorePickupRestricted: false,
                },
              ],
            },
          ],
        },
      },
      isFetching: false,
    },
    selectedSku: {
      sorId: 'MQ3R3LL/A',
    },
  };
  beforeEach(() => {
    jest.spyOn(params, 'getAssistedCradleProperty').mockReturnValue(['TRUE', 'TRUE']);
    render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('component should render', () => {
    const text = screen.getByText('Show only inventory available stores');
    expect(text).toBeInTheDocument();
  });
});

describe('StoreDetails component render', () => {
  const props = {
    Telesales: 'TELESALES',
    stores: [
      {
        id: 'R00000001745',
        storeName: 'Wilmington NC',
        isExpressStore: 'N',
        storeType: 'Store',
        retailId: 'R00000001745',
        storeStatus: 'Open',
        businessName: 'Verizon Wireless',
        zipPlus: '1632',
        fipsCode: '3712974440',
        area: 'Headquarters',
        region: 'Atlantic South',
        disasterImpacted: 'N',
        distance: 4.25,
        netaceLocationCode: 'P1619-01',
        zipCode: '28403',
        state: 'NC',
        city: 'Wilmington',
        phoneNumber: '9107992352',
        direct: 'N',
        inStorePickupFlag: 'Y',
        items: {
          itemCount: 1,
          item: [
            {
              quantity: 1,
              itemCode: 'MPUN3LL/A',
              quantityAllocated: '0',
            },
          ],
        },
        hoursMon: '10:00 AM 09:00 PM',
        hoursTue: '10:00 AM 09:00 PM',
        hoursWed: '10:00 AM 09:00 PM',
        hoursThu: '10:00 AM 09:00 PM',
        hoursFri: '10:00 AM 09:00 PM',
        hoursSat: '10:00 AM 09:00 PM',
        hoursSun: '10:00 AM 09:00 PM',
        location: {
          longitude: -77.87369,
          latitude: 34.2363,
        },
        address1: '318 S College Rd',
        currentGmtOffSet: '-5',
        ispuServices: 'CURBSIDE LOCKER',
        eligbleForGoAndGrab: 'false',
        storeAvailableServices: 'CURBSIDE LOCKER',
        lowInventory: true,
      },
      {
        id: 'R00000260458',
        storeName: 'Mayfaire ',
        isExpressStore: 'N',
        storeType: 'Store',
        retailId: 'R00000260458',
        storeStatus: 'Open',
        businessName: 'Verizon Wireless',
        zipPlus: '8361',
        fipsCode: '3712974440',
        area: 'Headquarters',
        region: 'Atlantic South',
        disasterImpacted: 'N',
        distance: 6.89,
        netaceLocationCode: 'P2598-01',
        zipCode: '28405',
        state: 'NC',
        city: 'Wilmington',
        phoneNumber: '9102565503',
        direct: 'Y',
        inStorePickupFlag: 'Y',
        items: {
          itemCount: 1,
          item: [
            {
              quantity: 1,
              itemCode: 'MPUN3LL/A',
              quantityAllocated: '0',
            },
          ],
        },
        hoursMon: '10:00 AM 09:00 PM',
        hoursTue: '10:00 AM 09:00 PM',
        hoursWed: '10:00 AM 09:00 PM',
        hoursThu: '10:00 AM 09:00 PM',
        hoursFri: '10:00 AM 09:00 PM',
        hoursSat: '10:00 AM 09:00 PM',
        hoursSun: '10:00 AM 09:00 PM',
        location: {
          longitude: -77.82743,
          latitude: 34.24288,
        },
        address1: '971 Military Cutoff Rd',
        address2: 'Unit 120',
        currentGmtOffSet: '-5',
        ispuServices: 'DS',
        eligbleForGoAndGrab: 'false',
        storeAvailableServices: 'CURBSIDE LOCKER',
        lowInventory: true,
      },
    ],
    statesList: {
      AL: 'Alabama',
      KY: 'Kentucky',
      OH: 'Ohio',
      AK: 'Alaska',
      LA: 'Louisiana',
      OK: 'Oklahoma',
      AZ: 'Arizona',
      ME: 'Maine',
      OR: 'Oregon',
      AR: 'Arkansas',
      MD: 'Maryland',
      PA: 'Pennsylvania',
      AS: 'American Samoa',
      MA: 'Massachusetts',
      PR: 'Puerto Rico',
      CA: 'California',
      MI: 'Michigan',
      RI: 'Rhode Island',
      CO: 'Colorado',
      MN: 'Minnesota',
      SC: 'South Carolina',
      CT: 'Connecticut',
      MS: 'Mississippi',
      SD: 'South Dakota',
      DE: 'Delaware',
      MO: 'Missouri',
      TN: 'Tennessee',
      DC: 'District of Columbia',
      MT: 'Montana',
      TX: 'Texas',
      FL: 'Florida',
      NE: 'Nebraska',
      TT: 'Trust Territories',
      GA: 'Georgia',
      NV: 'Nevada',
      UT: 'Utah',
      GU: 'Guam',
      NH: 'New Hampshire',
      VT: 'Vermont',
      HI: 'Hawaii',
      NJ: 'New Jersey',
      VA: 'Virginia',
      ID: 'Idaho',
      NM: 'New Mexico',
      VI: 'Virgin Islands',
      IL: 'Illinois',
      NY: 'New York',
      WA: 'Washington',
      IN: 'Indiana',
      NC: 'North Carolina',
      WV: 'West Virginia',
      IA: 'Iowa',
      ND: 'North Dakota',
      WI: 'Wisconsin',
      KS: 'Kansas',
      MP: 'Northern Mariana Islands',
      WY: 'Wyoming',
    },
    setSelectedStore: jest.fn(),
    setIsIspuItemInCart: jest.fn(),
    setShowDeviceModal: jest.fn(),
    setIspuToggleOn: jest.fn(),
    setStoreList: jest.fn(),
    setIspufromCart: jest.fn(),
    setFindStoreBtnClicked: jest.fn(),
  };
  beforeEach(() => {
    jest.spyOn(params, 'getAssistedCradleProperty').mockReturnValue(['TRUE', 'TRUE']);
    render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('component should render', () => {
    const text = screen.getByText('Show only inventory available stores');
    expect(text).toBeInTheDocument();
  });
  test('Pickup button onclick function', () => {
    const pickup = screen.getAllByText(/Pickup from this store/i)[0];
    fireEvent.click(pickup);
  });
});

describe('StoreDetails - BbyLocalOrderLocDetailsApiResponse handling', () => {
  const setShowDeviceModal = jest.fn();
  const setIspuToggleOn = jest.fn();
  const setStoreList = jest.fn();
  const setIspufromCart = jest.fn();
  const BbyLocalOrderLocDetailsRequest = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
    jest.spyOn(params, 'getAssistedCradleProperty').mockReturnValue(['TRUE', 'TRUE']);
  });

  test('should handle fulfilled BbyLocalOrderLocDetailsApiResponse', () => {
    const props = {
      Telesales: 'TELESALES',
      stores: [
        {
          id: 'R00000004694',
          storeName: 'Watchung',
          isExpressStore: 'N',
          storeType: 'Store',
          retailId: 'R00000004694',
          storeStatus: 'Open',
          businessName: 'Verizon Wireless',
          zipPlus: '6511',
          fipsCode: '3403577600',
          area: 'Headquarters',
          region: 'Atlantic North',
          disasterImpacted: 'N',
          distance: 8.54,
          netaceLocationCode: 'D2280-01',
          zipCode: '07069',
          state: 'NJ',
          city: 'Watchung',
          phoneNumber: '9084901688',
          direct: 'Y',
          inStorePickupFlag: 'Y',
          items: {
            itemCount: 1,
            item: [
              {
                quantity: 1,
                itemCode: 'MTLW3LL/A',
                quantityAllocated: '0',
              },
            ],
          },
          hoursMon: '10:00 AM 08:00 PM',
          hoursTue: '10:00 AM 08:00 PM',
          hoursWed: '10:00 AM 08:00 PM',
          hoursThu: '10:00 AM 08:00 PM',
          hoursFri: '10:00 AM 08:00 PM',
          hoursSat: '09:00 AM 07:00 PM',
          hoursSun: '11:00 AM 06:00 PM',
          location: {
            longitude: -74.41187,
            latitude: 40.643234,
          },
          address1: '1620 Us Highway 22',
          currentGmtOffSet: '-5',
          ispuServices: 'LOCKER',
          eligbleForGoAndGrab: 'false',
          storeAvailableServices: 'LOCKER~INSTORE',
          lowInventory: false,
        },
      ],
      setSelectedStore: jest.fn(),
      setIsIspuItemInCart: jest.fn(),
      setShowDeviceModal,
      setIspuToggleOn,
      setStoreList,
      setIspufromCart,
      setFindStoreBtnClicked: jest.fn(),
      isBBYLocalOrder: true,
      BbyLocalOrderLocDetailsRequest,
      BbyLocalOrderLocDetailsApiResponse: null,
      bestBuyISPUEnableLocalOrderFFlag: true,
    };

    const { rerender } = render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });

    // Click the pickup button to trigger the API call
    const pickup = screen.getAllByText(/Pickup from this store/i)[0];
    fireEvent.click(pickup);

    expect(BbyLocalOrderLocDetailsRequest).toHaveBeenCalled();

    // Simulate fulfilled API response
    const updatedProps = {
      ...props,
      BbyLocalOrderLocDetailsApiResponse: {
        status: 'fulfilled',
        data: { success: true },
      },
    };

    rerender(<StoreDetails {...updatedProps} />);

    // Verify state setters were called
    expect(setShowDeviceModal).toHaveBeenCalledWith(false);
    expect(setIspuToggleOn).toHaveBeenCalledWith(true);
    expect(setStoreList).toHaveBeenCalledWith(false);
    expect(setIspufromCart).toHaveBeenCalledWith(false);
  });

  test('should handle rejected BbyLocalOrderLocDetailsApiResponse', () => {
    const props = {
      Telesales: 'TELESALES',
      stores: [
        {
          id: 'R00000004694',
          storeName: 'Watchung',
          isExpressStore: 'N',
          storeType: 'Store',
          retailId: 'R00000004694',
          storeStatus: 'Open',
          businessName: 'Verizon Wireless',
          zipPlus: '6511',
          fipsCode: '3403577600',
          area: 'Headquarters',
          region: 'Atlantic North',
          disasterImpacted: 'N',
          distance: 8.54,
          netaceLocationCode: 'D2280-01',
          zipCode: '07069',
          state: 'NJ',
          city: 'Watchung',
          phoneNumber: '9084901688',
          direct: 'Y',
          inStorePickupFlag: 'Y',
          items: {
            itemCount: 1,
            item: [
              {
                quantity: 1,
                itemCode: 'MTLW3LL/A',
                quantityAllocated: '0',
              },
            ],
          },
          hoursMon: '10:00 AM 08:00 PM',
          hoursTue: '10:00 AM 08:00 PM',
          hoursWed: '10:00 AM 08:00 PM',
          hoursThu: '10:00 AM 08:00 PM',
          hoursFri: '10:00 AM 08:00 PM',
          hoursSat: '09:00 AM 07:00 PM',
          hoursSun: '11:00 AM 06:00 PM',
          location: {
            longitude: -74.41187,
            latitude: 40.643234,
          },
          address1: '1620 Us Highway 22',
          currentGmtOffSet: '-5',
          ispuServices: 'LOCKER',
          eligbleForGoAndGrab: 'false',
          storeAvailableServices: 'LOCKER~INSTORE',
          lowInventory: false,
        },
      ],
      setSelectedStore: jest.fn(),
      setIsIspuItemInCart: jest.fn(),
      setShowDeviceModal,
      setIspuToggleOn,
      setStoreList,
      setIspufromCart,
      setFindStoreBtnClicked: jest.fn(),
      isBBYLocalOrder: true,
      BbyLocalOrderLocDetailsRequest,
      BbyLocalOrderLocDetailsApiResponse: null,
      bestBuyISPUEnableLocalOrderFFlag: true,
    };

    const { rerender } = render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });

    // Click the pickup button to trigger the API call
    const pickup = screen.getAllByText(/Pickup from this store/i)[0];
    fireEvent.click(pickup);

    expect(BbyLocalOrderLocDetailsRequest).toHaveBeenCalled();

    // Simulate rejected API response
    const updatedProps = {
      ...props,
      BbyLocalOrderLocDetailsApiResponse: {
        status: 'rejected',
        error: { message: 'API Error' },
      },
    };

    rerender(<StoreDetails {...updatedProps} />);

    // Verify that only the waiting state is reset, other setters should not be called
    expect(setShowDeviceModal).not.toHaveBeenCalled();
    expect(setIspuToggleOn).not.toHaveBeenCalled();
    expect(setStoreList).not.toHaveBeenCalled();
    expect(setIspufromCart).not.toHaveBeenCalled();
  });

  test('should not trigger state updates when isWaitingForBbyResponse is false', () => {
    const props = {
      Telesales: 'TELESALES',
      stores: [
        {
          id: 'R00000004694',
          storeName: 'Watchung',
          isExpressStore: 'N',
          storeType: 'Store',
          retailId: 'R00000004694',
          storeStatus: 'Open',
          businessName: 'Verizon Wireless',
          zipPlus: '6511',
          fipsCode: '3403577600',
          area: 'Headquarters',
          region: 'Atlantic North',
          disasterImpacted: 'N',
          distance: 8.54,
          netaceLocationCode: 'D2280-01',
          zipCode: '07069',
          state: 'NJ',
          city: 'Watchung',
          phoneNumber: '9084901688',
          direct: 'Y',
          inStorePickupFlag: 'Y',
          items: {
            itemCount: 1,
            item: [
              {
                quantity: 1,
                itemCode: 'MTLW3LL/A',
                quantityAllocated: '0',
              },
            ],
          },
          hoursMon: '10:00 AM 08:00 PM',
          hoursTue: '10:00 AM 08:00 PM',
          hoursWed: '10:00 AM 08:00 PM',
          hoursThu: '10:00 AM 08:00 PM',
          hoursFri: '10:00 AM 08:00 PM',
          hoursSat: '09:00 AM 07:00 PM',
          hoursSun: '11:00 AM 06:00 PM',
          location: {
            longitude: -74.41187,
            latitude: 40.643234,
          },
          address1: '1620 Us Highway 22',
          currentGmtOffSet: '-5',
          ispuServices: 'LOCKER',
          eligbleForGoAndGrab: 'false',
          storeAvailableServices: 'LOCKER~INSTORE',
          lowInventory: false,
        },
      ],
      setSelectedStore: jest.fn(),
      setIsIspuItemInCart: jest.fn(),
      setShowDeviceModal,
      setIspuToggleOn,
      setStoreList,
      setIspufromCart,
      setFindStoreBtnClicked: jest.fn(),
      isBBYLocalOrder: false,
      BbyLocalOrderLocDetailsRequest,
      BbyLocalOrderLocDetailsApiResponse: {
        status: 'fulfilled',
        data: { success: true },
      },
      bestBuyISPUEnableLocalOrderFFlag: true,
    };

    render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });

    // Since isWaitingForBbyResponse is never set to true, the useEffect should not trigger
    expect(setShowDeviceModal).not.toHaveBeenCalled();
    expect(setIspuToggleOn).not.toHaveBeenCalled();
    expect(setStoreList).not.toHaveBeenCalled();
    expect(setIspufromCart).not.toHaveBeenCalled();
  });
});

describe('StoreDetails bestBuyEmpMasterAgentFFlag feature flag', () => {
  test('should use BBEMPLOC as masterAgentId when bestBuyEmpMasterAgentFFlag is TRUE', () => {
    jest.spyOn(params, 'getAssistedCradlePropertyV2').mockReturnValue(['TRUE', 'TRUE']);
    
    const BbyLocalOrderLocDetailsRequest = jest.fn();
    const props = {
      Telesales: 'TELESALES',
      stores: [
        {
          id: '123',
          storeName: 'Test Store',
          items: { itemCount: 1, item: [{ quantity: 1 }] },
          hoursSun: '10:00 AM 06:00 PM',
          hoursMon: '10:00 AM 08:00 PM',
          hoursTue: '10:00 AM 08:00 PM',
          hoursWed: '10:00 AM 08:00 PM',
          hoursThu: '10:00 AM 08:00 PM',
          hoursFri: '10:00 AM 08:00 PM',
          hoursSat: '09:00 AM 07:00 PM',
          storeAvailableServices: 'LOCKER~INSTORE',
          inStorePickupFlag: 'Y',
          direct: 'Y',
        },
      ],
      setSelectedStore: jest.fn(),
      setIsIspuItemInCart: jest.fn(),
      setShowDeviceModal: jest.fn(),
      setIspuToggleOn: jest.fn(),
      setStoreList: jest.fn(),
      setIspufromCart: jest.fn(),
      setFindStoreBtnClicked: jest.fn(),
      isBBYLocalOrder: true,
      BbyLocalOrderLocDetailsRequest,
      BbyLocalOrderLocDetailsApiResponse: null,
      bestBuyISPUEnableLocalOrderFFlag: true,
    };

    render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });

    const pickup = screen.getAllByText(/Pickup from this store/i)[0];
    fireEvent.click(pickup);

    // Verify the API was called with BBEMPLOC as masterAgentId
    expect(BbyLocalOrderLocDetailsRequest).toHaveBeenCalledWith({
      body: {
        realAgentCode: '0123',
        masterAgentId: 'BBEMPLOC',
      },
    });
  });

  test('should use BBYOMNI as masterAgentId when bestBuyEmpMasterAgentFFlag is FALSE', () => {
    jest.spyOn(params, 'getAssistedCradlePropertyV2').mockReturnValue(['TRUE', 'FALSE']);
    
    const BbyLocalOrderLocDetailsRequest = jest.fn();
    const props = {
      Telesales: 'TELESALES',
      stores: [
        {
          id: '456',
          storeName: 'Test Store',
          items: { itemCount: 1, item: [{ quantity: 1 }] },
          hoursSun: '10:00 AM 06:00 PM',
          hoursMon: '10:00 AM 08:00 PM',
          hoursTue: '10:00 AM 08:00 PM',
          hoursWed: '10:00 AM 08:00 PM',
          hoursThu: '10:00 AM 08:00 PM',
          hoursFri: '10:00 AM 08:00 PM',
          hoursSat: '09:00 AM 07:00 PM',
          storeAvailableServices: 'LOCKER~INSTORE',
          inStorePickupFlag: 'Y',
          direct: 'Y',
        },
      ],
      setSelectedStore: jest.fn(),
      setIsIspuItemInCart: jest.fn(),
      setShowDeviceModal: jest.fn(),
      setIspuToggleOn: jest.fn(),
      setStoreList: jest.fn(),
      setIspufromCart: jest.fn(),
      setFindStoreBtnClicked: jest.fn(),
      isBBYLocalOrder: true,
      BbyLocalOrderLocDetailsRequest,
      BbyLocalOrderLocDetailsApiResponse: null,
      bestBuyISPUEnableLocalOrderFFlag: true,
    };

    render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });

    const pickup = screen.getAllByText(/Pickup from this store/i)[0];
    fireEvent.click(pickup);

    // Verify the API was called with BBYOMNI as masterAgentId
    expect(BbyLocalOrderLocDetailsRequest).toHaveBeenCalledWith({
      body: {
        realAgentCode: '0456',
        masterAgentId: 'BBYOMNI',
      },
    });
  });

  test('should use BBYOMNI as masterAgentId when bestBuyEmpMasterAgentFFlag is undefined', () => {
    jest.spyOn(params, 'getAssistedCradlePropertyV2').mockReturnValue(['TRUE', undefined]);
    
    const BbyLocalOrderLocDetailsRequest = jest.fn();
    const props = {
      Telesales: 'TELESALES',
      stores: [
        {
          id: '789',
          storeName: 'Test Store',
          items: { itemCount: 1, item: [{ quantity: 1 }] },
          hoursSun: '10:00 AM 06:00 PM',
          hoursMon: '10:00 AM 08:00 PM',
          hoursTue: '10:00 AM 08:00 PM',
          hoursWed: '10:00 AM 08:00 PM',
          hoursThu: '10:00 AM 08:00 PM',
          hoursFri: '10:00 AM 08:00 PM',
          hoursSat: '09:00 AM 07:00 PM',
          storeAvailableServices: 'LOCKER~INSTORE',
          inStorePickupFlag: 'Y',
          direct: 'Y',
        },
      ],
      setSelectedStore: jest.fn(),
      setIsIspuItemInCart: jest.fn(),
      setShowDeviceModal: jest.fn(),
      setIspuToggleOn: jest.fn(),
      setStoreList: jest.fn(),
      setIspufromCart: jest.fn(),
      setFindStoreBtnClicked: jest.fn(),
      isBBYLocalOrder: true,
      BbyLocalOrderLocDetailsRequest,
      BbyLocalOrderLocDetailsApiResponse: null,
      bestBuyISPUEnableLocalOrderFFlag: true,
    };

    render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });

    const pickup = screen.getAllByText(/Pickup from this store/i)[0];
    fireEvent.click(pickup);

    // Verify the API was called with BBYOMNI as masterAgentId (default)
    expect(BbyLocalOrderLocDetailsRequest).toHaveBeenCalledWith({
      body: {
        realAgentCode: '0789',
        masterAgentId: 'BBYOMNI',
      },
    });
  });

  test('should pad realAgentCode with leading zeros to 4 digits', () => {
    jest.spyOn(params, 'getAssistedCradlePropertyV2').mockReturnValue(['TRUE', 'TRUE']);
    
    const BbyLocalOrderLocDetailsRequest = jest.fn();
    const props = {
      Telesales: 'TELESALES',
      stores: [
        {
          id: '5',
          storeName: 'Test Store',
          items: { itemCount: 1, item: [{ quantity: 1 }] },
          hoursSun: '10:00 AM 06:00 PM',
          hoursMon: '10:00 AM 08:00 PM',
          hoursTue: '10:00 AM 08:00 PM',
          hoursWed: '10:00 AM 08:00 PM',
          hoursThu: '10:00 AM 08:00 PM',
          hoursFri: '10:00 AM 08:00 PM',
          hoursSat: '09:00 AM 07:00 PM',
          storeAvailableServices: 'LOCKER~INSTORE',
          inStorePickupFlag: 'Y',
          direct: 'Y',
        },
      ],
      setSelectedStore: jest.fn(),
      setIsIspuItemInCart: jest.fn(),
      setShowDeviceModal: jest.fn(),
      setIspuToggleOn: jest.fn(),
      setStoreList: jest.fn(),
      setIspufromCart: jest.fn(),
      setFindStoreBtnClicked: jest.fn(),
      isBBYLocalOrder: true,
      BbyLocalOrderLocDetailsRequest,
      BbyLocalOrderLocDetailsApiResponse: null,
      bestBuyISPUEnableLocalOrderFFlag: true,
    };

    render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });

    const pickup = screen.getAllByText(/Pickup from this store/i)[0];
    fireEvent.click(pickup);

    // Verify realAgentCode is padded to 4 digits (5 -> 0005)
    expect(BbyLocalOrderLocDetailsRequest).toHaveBeenCalledWith({
      body: {
        realAgentCode: '0005',
        masterAgentId: 'BBEMPLOC',
      },
    });
  });
});

describe('StoreDetails date formatting without timezone conversion', () => {
  test('should display estMaxDate correctly without timezone shift', () => {
    const props = {
      Telesales: 'TELESALES',
      stores: [
        {
          items: { itemCount: 1, item: [{ quantity: 2 }] },
          hoursSun: '10:00 AM 06:00 PM',
          hoursMon: '10:00 AM 08:00 PM',
          hoursTue: '10:00 AM 08:00 PM',
          hoursWed: '10:00 AM 08:00 PM',
          hoursThu: '10:00 AM 08:00 PM',
          hoursFri: '10:00 AM 08:00 PM',
          hoursSat: '09:00 AM 07:00 PM',
          estMaxDate: '2025-12-19',
          storeAvailableServices: 'LOCKER~INSTORE',
          id: '0281',
        },
      ],
      setSelectedStore: jest.fn(),
      setIsIspuItemInCart: jest.fn(),
      setShowDeviceModal: jest.fn(),
      setIspuToggleOn: jest.fn(),
      setStoreList: jest.fn(),
      setIspufromCart: jest.fn(),
      setFindStoreBtnClicked: jest.fn(),
    };

    render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });

    // Verify the date is formatted correctly without timezone conversion
    // 2025-12-19 should display as "December 19th" not "December 18th"
    const dateText = screen.getByText(/December 19th/i);
    expect(dateText).toBeInTheDocument();
  });

  test('should display estimatedReadyByDate correctly without timezone shift', () => {
    const props = {
      Telesales: 'TELESALES',
      stores: [
        {
          items: { itemCount: 1, item: [{ quantity: 2 }] },
          hoursSun: '10:00 AM 06:00 PM',
          hoursMon: '10:00 AM 08:00 PM',
          hoursTue: '10:00 AM 08:00 PM',
          hoursWed: '10:00 AM 08:00 PM',
          hoursThu: '10:00 AM 08:00 PM',
          hoursFri: '10:00 AM 08:00 PM',
          hoursSat: '09:00 AM 07:00 PM',
          estimatedReadyByDate: '2025-01-15',
          storeAvailableServices: 'LOCKER~INSTORE',
          id: '0282',
        },
      ],
      setSelectedStore: jest.fn(),
      setIsIspuItemInCart: jest.fn(),
      setShowDeviceModal: jest.fn(),
      setIspuToggleOn: jest.fn(),
      setStoreList: jest.fn(),
      setIspufromCart: jest.fn(),
      setFindStoreBtnClicked: jest.fn(),
    };

    render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });

    // Verify the date is formatted correctly without timezone conversion
    // 2025-01-15 should display as "January 15th" not "January 14th"
    const dateText = screen.getByText(/January 15th/i);
    expect(dateText).toBeInTheDocument();
  });

  test('should handle both estimatedReadyByDate and estMaxDate together', () => {
    const props = {
      Telesales: 'TELESALES',
      stores: [
        {
          items: { itemCount: 1, item: [{ quantity: 2 }] },
          hoursSun: '10:00 AM 06:00 PM',
          hoursMon: '10:00 AM 08:00 PM',
          hoursTue: '10:00 AM 08:00 PM',
          hoursWed: '10:00 AM 08:00 PM',
          hoursThu: '10:00 AM 08:00 PM',
          hoursFri: '10:00 AM 08:00 PM',
          hoursSat: '09:00 AM 07:00 PM',
          estimatedReadyByDate: '2025-02-10',
          estMaxDate: '2025-02-12',
          storeAvailableServices: 'LOCKER~INSTORE',
          id: '0283',
        },
      ],
      setSelectedStore: jest.fn(),
      setIsIspuItemInCart: jest.fn(),
      setShowDeviceModal: jest.fn(),
      setIspuToggleOn: jest.fn(),
      setStoreList: jest.fn(),
      setIspufromCart: jest.fn(),
      setFindStoreBtnClicked: jest.fn(),
    };

    render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });

    // When both dates are present, estimatedReadyByDate is displayed
    // 2025-02-10 should display as "February 10th" not "February 9th"
    const dateText = screen.getByText(/February 10th/i);
    expect(dateText).toBeInTheDocument();
  });

  test('should display estMaxDate when only estMaxDate is provided', () => {
    const props = {
      Telesales: 'TELESALES',
      stores: [
        {
          items: { itemCount: 1, item: [{ quantity: 2 }] },
          hoursSun: '10:00 AM 06:00 PM',
          hoursMon: '10:00 AM 08:00 PM',
          hoursTue: '10:00 AM 08:00 PM',
          hoursWed: '10:00 AM 08:00 PM',
          hoursThu: '10:00 AM 08:00 PM',
          hoursFri: '10:00 AM 08:00 PM',
          hoursSat: '09:00 AM 07:00 PM',
          estMaxDate: '2025-03-25',
          storeAvailableServices: 'LOCKER~INSTORE',
          id: '0284',
        },
      ],
      setSelectedStore: jest.fn(),
      setIsIspuItemInCart: jest.fn(),
      setShowDeviceModal: jest.fn(),
      setIspuToggleOn: jest.fn(),
      setStoreList: jest.fn(),
      setIspufromCart: jest.fn(),
      setFindStoreBtnClicked: jest.fn(),
    };

    render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });

    // 2025-03-25 should display as "March 25th" not "March 24th"
    const dateText = screen.getByText(/March 25th/i);
    expect(dateText).toBeInTheDocument();
  });
});

describe('StoreDetails themeColor coverage tests', () => {
  test('should render with isDarkTheme=true and apply dark theme colors to all Body components', () => {
    const props = {
      stores: [
        {
          id: 'R00000004694',
          storeName: 'Watchung',
          direct: 'Y',
          inStorePickupFlag: 'Y',
          distance: 8.54,
          city: 'Watchung',
          state: 'NJ',
          phoneNumber: '9084901688',
          address1: '1620 Us Highway 22',
          items: {
            itemCount: 1,
            item: [
              {
                quantity: 2,
                itemCode: 'MTLW3LL/A',
                quantityAllocated: '2',
              },
            ],
          },
          hoursSun: '11:00 AM 06:00 PM',
          hoursMon: '10:00 AM 08:00 PM',
          hoursTue: '10:00 AM 08:00 PM',
          hoursWed: '10:00 AM 08:00 PM',
          hoursThu: '10:00 AM 08:00 PM',
          hoursFri: '10:00 AM 08:00 PM',
          hoursSat: '09:00 AM 07:00 PM',
          storeAvailableServices: 'LOCKER~INSTORE',
        },
      ],
      showOnlyAvailableStores: false,
      selectedSku: {
        sorId: 'MTLW3LL/A',
        color: { description: 'Blue' },
        capacity: '128GB',
      },
      isDarkTheme: true,
      setSelectedStore: jest.fn(),
      setIsIspuItemInCart: jest.fn(),
      setShowDeviceModal: jest.fn(),
      setIspuToggleOn: jest.fn(),
      setStoreList: jest.fn(),
      setIspufromCart: jest.fn(),
      setFindStoreBtnClicked: jest.fn(),
      handleToggleChange: jest.fn(),
    };

    render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });

    // Verify store name is rendered (line 366 Body component coverage)
    expect(screen.getByText('Watchung')).toBeInTheDocument();
    
    // Verify distance is rendered (line 402 Body component coverage)
    expect(screen.getByText(/8.54 Miles away/i)).toBeInTheDocument();
    
    // Verify item availability text is rendered (line 374 Body component coverage)
    expect(screen.getByText(/1 of 2 item\(s\) available/i)).toBeInTheDocument();
    
    // Verify toggle label is rendered (line 492 Body component coverage)
    expect(screen.getByText('Show only inventory available stores')).toBeInTheDocument();
    
    // Verify "Stores near you" is rendered (line 500 Body component coverage)
    expect(screen.getByText(/Stores near you/i)).toBeInTheDocument();
  });

  test('should render with isDarkTheme=false and apply light theme colors to all Body components', () => {
    const props = {
      stores: [
        {
          id: 'R00000004695',
          storeName: 'Short Hills',
          direct: 'N',
          inStorePickupFlag: 'Y',
          distance: 12.34,
          city: 'Short Hills',
          state: 'NJ',
          phoneNumber: '9731234567',
          address1: '100 Main Street',
          items: {
            itemCount: 2,
            item: [
              {
                quantity: 3,
                itemCode: 'MTLW3LL/A',
                quantityAllocated: '3',
              },
            ],
          },
          hoursSun: '11:00 AM 06:00 PM',
          hoursMon: '10:00 AM 08:00 PM',
          hoursTue: '10:00 AM 08:00 PM',
          hoursWed: '10:00 AM 08:00 PM',
          hoursThu: '10:00 AM 08:00 PM',
          hoursFri: '10:00 AM 08:00 PM',
          hoursSat: '09:00 AM 07:00 PM',
          storeAvailableServices: 'INSTORE',
        },
      ],
      showOnlyAvailableStores: false,
      selectedSku: {
        sorId: 'MTLW3LL/A',
        color: { description: 'Red' },
        capacity: '256GB',
      },
      isDarkTheme: false,
      setSelectedStore: jest.fn(),
      setIsIspuItemInCart: jest.fn(),
      setShowDeviceModal: jest.fn(),
      setIspuToggleOn: jest.fn(),
      setStoreList: jest.fn(),
      setIspufromCart: jest.fn(),
      setFindStoreBtnClicked: jest.fn(),
      handleToggleChange: jest.fn(),
    };

    render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });

    // Verify store name is rendered with light theme (line 366)
    expect(screen.getByText('Short Hills')).toBeInTheDocument();
    
    // Verify distance is rendered with light theme (line 402)
    expect(screen.getByText(/12.34 Miles away/i)).toBeInTheDocument();
    
    // Verify item availability with light theme (line 374)
    expect(screen.getByText(/2 of 3 item\(s\) available/i)).toBeInTheDocument();
    
    // Verify toggle label with light theme (line 492)
    expect(screen.getByText('Show only inventory available stores')).toBeInTheDocument();
    
    // Verify "Stores near you" with light theme (line 500)
    expect(screen.getByText(/Stores near you/i)).toBeInTheDocument();
  });

  test('should render Timings component with themeColor for each day of the week', () => {
    const props = {
      stores: [
        {
          id: 'R00000004696',
          storeName: 'Test Store',
          direct: 'Y',
          inStorePickupFlag: 'Y',
          distance: 5.0,
          city: 'Test City',
          state: 'NJ',
          phoneNumber: '1234567890',
          address1: '123 Test Street',
          items: {
            itemCount: 1,
            item: [
              {
                quantity: 1,
                itemCode: 'MTLW3LL/A',
                quantityAllocated: '1',
              },
            ],
          },
          hoursSun: '11:00 AM 06:00 PM',
          hoursMon: '10:00 AM 08:00 PM',
          hoursTue: '09:00 AM 09:00 PM',
          hoursWed: '10:00 AM 07:00 PM',
          hoursThu: '10:00 AM 08:00 PM',
          hoursFri: '10:00 AM 09:00 PM',
          hoursSat: '09:00 AM 07:00 PM',
          storeAvailableServices: 'INSTORE',
        },
      ],
      showOnlyAvailableStores: false,
      isDarkTheme: true,
      bestBuyISPUEnableLocalOrderFFlag: false,
      isBBYLocalOrder: false,
      setSelectedStore: jest.fn(),
      setIsIspuItemInCart: jest.fn(),
      setShowDeviceModal: jest.fn(),
      setIspuToggleOn: jest.fn(),
      setStoreList: jest.fn(),
      setIspufromCart: jest.fn(),
      setFindStoreBtnClicked: jest.fn(),
      handleToggleChange: jest.fn(),
    };

    render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });

    // Verify Timings component renders with themeColor (lines 94-95, 290)
    expect(screen.getByText(/Sun:/i)).toBeInTheDocument();
    expect(screen.getByText(/Mon:/i)).toBeInTheDocument();
    expect(screen.getByText(/Tue:/i)).toBeInTheDocument();
    expect(screen.getByText(/Wed:/i)).toBeInTheDocument();
    expect(screen.getByText(/Thu:/i)).toBeInTheDocument();
    expect(screen.getByText(/Fri:/i)).toBeInTheDocument();
    expect(screen.getByText(/Sat:/i)).toBeInTheDocument();
  });

  test('should render Timings with Closed status when hours are not available', () => {
    const props = {
      stores: [
        {
          id: 'R00000004697',
          storeName: 'Closed Store',
          direct: 'Y',
          inStorePickupFlag: 'Y',
          distance: 3.5,
          city: 'Closed City',
          state: 'NY',
          phoneNumber: '9876543210',
          address1: '456 Closed Avenue',
          items: {
            itemCount: 1,
            item: [
              {
                quantity: 1,
                itemCode: 'MTLW3LL/A',
                quantityAllocated: '1',
              },
            ],
          },
          hoursSun: 'Closed',
          hoursMon: 'Closed',
          storeAvailableServices: 'INSTORE',
        },
      ],
      showOnlyAvailableStores: false,
      isDarkTheme: false,
      bestBuyISPUEnableLocalOrderFFlag: false,
      isBBYLocalOrder: false,
      setSelectedStore: jest.fn(),
      setIsIspuItemInCart: jest.fn(),
      setShowDeviceModal: jest.fn(),
      setIspuToggleOn: jest.fn(),
      setStoreList: jest.fn(),
      setIspufromCart: jest.fn(),
      setFindStoreBtnClicked: jest.fn(),
      handleToggleChange: jest.fn(),
    };

    render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });

    // Verify Timings component renders Closed status (lines 94-95, 290)
    expect(screen.getByText(/Sun: Closed-/i)).toBeInTheDocument();
    expect(screen.getByText(/Mon: Closed-/i)).toBeInTheDocument();
  });

  test('should render with multiple stores and verify all Body components with themeColor', () => {
    const props = {
      stores: [
        {
          id: 'R00000001',
          storeName: 'Store One',
          direct: 'Y',
          inStorePickupFlag: 'Y',
          distance: 2.5,
          city: 'City One',
          state: 'NJ',
          phoneNumber: '1111111111',
          address1: '111 First Street',
          items: {
            itemCount: 1,
            item: [{ quantity: 5, itemCode: 'MTLW3LL/A' }],
          },
          hoursSun: '11:00 AM 05:00 PM',
          hoursMon: '10:00 AM 08:00 PM',
          hoursTue: '10:00 AM 08:00 PM',
          hoursWed: '10:00 AM 08:00 PM',
          hoursThu: '10:00 AM 08:00 PM',
          hoursFri: '10:00 AM 08:00 PM',
          hoursSat: '09:00 AM 06:00 PM',
          storeAvailableServices: 'CURBSIDE~INSTORE',
        },
        {
          id: 'R00000002',
          storeName: 'Store Two',
          direct: 'N',
          inStorePickupFlag: 'Y',
          distance: 7.8,
          city: 'City Two',
          state: 'NY',
          phoneNumber: '2222222222',
          address1: '222 Second Avenue',
          items: {
            itemCount: 2,
            item: [{ quantity: 3, itemCode: 'MTLW3LL/A' }],
          },
          hoursSun: '12:00 PM 06:00 PM',
          hoursMon: '09:00 AM 09:00 PM',
          hoursTue: '09:00 AM 09:00 PM',
          hoursWed: '09:00 AM 09:00 PM',
          hoursThu: '09:00 AM 09:00 PM',
          hoursFri: '09:00 AM 09:00 PM',
          hoursSat: '10:00 AM 08:00 PM',
          storeAvailableServices: 'LOCKER~INSTORE',
        },
      ],
      showOnlyAvailableStores: false,
      selectedSku: {
        sorId: 'MTLW3LL/A',
        color: { description: 'Green' },
        capacity: '512GB',
      },
      isDarkTheme: true,
      bestBuyISPUEnableLocalOrderFFlag: false,
      isBBYLocalOrder: false,
      setSelectedStore: jest.fn(),
      setIsIspuItemInCart: jest.fn(),
      setShowDeviceModal: jest.fn(),
      setIspuToggleOn: jest.fn(),
      setStoreList: jest.fn(),
      setIspufromCart: jest.fn(),
      setFindStoreBtnClicked: jest.fn(),
      handleToggleChange: jest.fn(),
    };

    render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });

    // Verify first store (all Body components with themeColor)
    expect(screen.getByText('Store One')).toBeInTheDocument();
    expect(screen.getByText(/2.50 Miles away/i)).toBeInTheDocument();
    expect(screen.getByText(/1 of 5 item\(s\) available/i)).toBeInTheDocument();

    // Verify second store
    expect(screen.getByText('Store Two')).toBeInTheDocument();
    expect(screen.getByText(/7.80 Miles away/i)).toBeInTheDocument();
    expect(screen.getByText(/2 of 3 item\(s\) available/i)).toBeInTheDocument();

    // Verify common elements with themeColor
    expect(screen.getByText('Show only inventory available stores')).toBeInTheDocument();
    expect(screen.getByText(/Stores near you/i)).toBeInTheDocument();
  });

  test('should render store index numbers with themeColor in Body component', () => {
    const props = {
      stores: [
        {
          id: 'R00000101',
          storeName: 'Indexed Store',
          direct: 'Y',
          inStorePickupFlag: 'Y',
          distance: 1.2,
          city: 'Index City',
          state: 'CA',
          phoneNumber: '5555555555',
          address1: '555 Index Road',
          items: {
            itemCount: 1,
            item: [{ quantity: 2, itemCode: 'MTLW3LL/A' }],
          },
          hoursSun: '10:00 AM 07:00 PM',
          hoursMon: '10:00 AM 08:00 PM',
          hoursTue: '10:00 AM 08:00 PM',
          hoursWed: '10:00 AM 08:00 PM',
          hoursThu: '10:00 AM 08:00 PM',
          hoursFri: '10:00 AM 08:00 PM',
          hoursSat: '10:00 AM 07:00 PM',
          storeAvailableServices: 'INSTORE',
        },
      ],
      showOnlyAvailableStores: false,
      isDarkTheme: false,
      setSelectedStore: jest.fn(),
      setIsIspuItemInCart: jest.fn(),
      setShowDeviceModal: jest.fn(),
      setIspuToggleOn: jest.fn(),
      setStoreList: jest.fn(),
      setIspufromCart: jest.fn(),
      setFindStoreBtnClicked: jest.fn(),
      handleToggleChange: jest.fn(),
    };

    const { container } = render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });

    // Verify the store index number is rendered with themeColor
    expect(screen.getByText('1')).toBeInTheDocument();
    expect(screen.getByText('Indexed Store')).toBeInTheDocument();
  });

  test('should apply themeColor when no stores are available', () => {
    const props = {
      stores: [],
      showOnlyAvailableStores: true,
      isDarkTheme: true,
      setSelectedStore: jest.fn(),
      setIsIspuItemInCart: jest.fn(),
      setShowDeviceModal: jest.fn(),
      setIspuToggleOn: jest.fn(),
      setStoreList: jest.fn(),
      setIspufromCart: jest.fn(),
      setFindStoreBtnClicked: jest.fn(),
      handleToggleChange: jest.fn(),
    };

    render(<StoreDetails {...props} />, { reducers: rootReducer, sagas: rootSaga });

    // Verify error message is rendered with themeColor (line 422)
    expect(screen.getByText(/Inventory is not available in stores nearby/i)).toBeInTheDocument();
    
    // Verify toggle label is still rendered with themeColor
    expect(screen.getByText('Show only inventory available stores')).toBeInTheDocument();
  });
});
