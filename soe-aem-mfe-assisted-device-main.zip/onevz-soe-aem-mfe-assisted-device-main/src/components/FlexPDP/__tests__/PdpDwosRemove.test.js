import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import { cloneDeep } from 'lodash';
import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import PDP from '../PDP';
import props from './pdpDfill.json';

const dFillBackOrderProps = cloneDeep(props);
dFillBackOrderProps.customerProfileDetails.commonInfo.isIndirect = true;

const dispatchedActions = [];
const mockStore = {
  dispatch: (action) => {
    dispatchedActions.push(action);
  },
};

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);
jest.mock('onevzsoemfecommon/Helpers', () => ({
  getQueryParamByName: (value) => {
    if (value === 'isDWOS') return 'true';
    if (value === 'deviceFromCart') return true;
  },
  isNumeric: jest.fn(),
  capitalizeFirstLetter: jest.fn(),
  formatMtnForNewLine: jest.fn(),
  getUIContextPath: jest.fn(),
}));
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradleProperty: () => [false, true, false, false, false, false, false, false, false, false, true],
     getAssistedCradlePropertyV2: () => [false, true, false, false, false, false, false, false, false, false, true],
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    getQueryParamByName: (value) => {
      if (value === 'isDWOS') return 'true';
      if (value === 'deviceFromCart') return true;
    },
    getClientAppName: () => 'ATG-RTL-NETACE',
    noOfDaysLeftInBillCycle: () => 12,
    isIpad: () => true,
    isRetail: () => false,
    isAsurion: () => false,
    executeShellFunction: jest.fn(),
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

describe('PDP component render for DFill Flow Back order', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  navigator.clipboard = jest.fn();
  navigator.clipboard.writeText = jest.fn('Pink');
  beforeEach(() => {
    sessionStorage.setItem('channel', 'indirect');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ dwosIndirectFFlag: 'TRUE' }));
    window.store = mockStore;
    window.vzdl = { page: {} };
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?offerEligible=Y&activeMtn=9102798662&productId=dev21410695&defaultSku=MTXW3LL/A&isDWOS=true`;
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        removeLinesAPI={jest.fn()}
        {...dFillBackOrderProps}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('component should render', async () => {
    const Remove = await screen.getByRole('button', {
      name: /Remove/i,
    });
    expect(Remove).toBeInTheDocument();
    fireEvent.click(Remove);
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });
});
