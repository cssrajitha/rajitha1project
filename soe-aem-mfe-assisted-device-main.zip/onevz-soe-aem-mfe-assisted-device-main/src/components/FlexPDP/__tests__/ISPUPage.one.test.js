import React from 'react';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import {  render, screen } from '../../../modules/test-utils/renderHelper';
import ISPUPage from '../ISPUPage';


describe('device model component render for prospect new customer in ACSS', () => {
    beforeEach(() => {
      window.mfe = {
        scmDeviceMfeEnable: true,
        isProspectNewCustomerTab: true,
      };
  
      const newProps = {
        selectedSku: { color: 'red' },
        devices: { devicename: 'samsung' },
        ProductDetails: { childSkus: [] },
        cartDetails: { cart: { lineDetails: { lineInfo: [] } } },
        customerProfileDetails: { customer: { qualificationDetails: { addressRequest: {} } } },
      };
      render(<ISPUPage {...newProps} />, { reducers: rootReducer, sagas: rootSaga });
    });
  
    afterEach(() => {
      delete window.mfe;
    });
  
    test('should apply prospect-specific classes and styles when conditions are met', () => {
      const mainContainer = screen.getByText('In-Store availability').closest('div.Ispu-Modal');
      expect(mainContainer).toHaveClass('prospect-acss-device-ispu-modal');
  
      const innerContainer = mainContainer.querySelector('.Prospect-BuyoutAmount-Modal-inner');
      expect(innerContainer).toBeInTheDocument();
  
      const headerContainer = screen.getByTestId('onBackTestId');
      expect(headerContainer).toHaveStyle('width: 42%');
    });
  });
describe('device model component render for prospect new customer in ACSS newcust -false', () => {
    beforeEach(() => {
      window.mfe = {
        scmDeviceMfeEnable: true,
        isProspectNewCustomerTab: false,
      };
  
      const newProps = {
        selectedSku: { color: 'red' },
        devices: { devicename: 'samsung' },
        ProductDetails: { childSkus: [] },
        cartDetails: { cart: { lineDetails: { lineInfo: [] } } },
        customerProfileDetails: { customer: { qualificationDetails: { addressRequest: {} } } },
      };
      render(<ISPUPage {...newProps} />, { reducers: rootReducer, sagas: rootSaga });
    });
  
    afterEach(() => {
      delete window.mfe;
    });
  
    test('should apply prospect-specific classes and styles when conditions are met', () => {
      const headerContainer = screen.getByTestId('onBackTestId');
      expect(headerContainer).toHaveStyle('width: 71%');
    });
  });