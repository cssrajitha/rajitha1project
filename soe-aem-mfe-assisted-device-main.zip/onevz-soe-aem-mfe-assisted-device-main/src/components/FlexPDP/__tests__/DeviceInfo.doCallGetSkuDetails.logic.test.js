/**
 * Unit Test for doCallGetSkuDetails IF Condition
 *
 * This file tests the IF condition logic (lines 1664-1694) of doCallGetSkuDetails function
 * in DeviceInfo.js by testing the conditional logic directly.
 *
 * The function is called from chooseColor and chooseSize handlers when user interacts
 * with color/size selectors.
 */

describe('DeviceInfo - doCallGetSkuDetails IF Condition Logic', () => {
  // Mock API functions
  const mockGetInventoryDetails = jest.fn().mockResolvedValue({ data: { success: true } });
  const mockComputeDPPriceBody = jest.fn().mockResolvedValue({ data: { success: true } });
  const mockSetUpcCode = jest.fn();
  const mockSetIsDevicePricingApiCallEnable = jest.fn();

  // Mock dependencies
  const activeMtn = '1234567890';
  const productId = 'dev19920005';
  const mtnList = { eup: [], aal: [] };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  /**
   * Simulates the doCallGetSkuDetails function logic
   * This is the EXACT logic from DeviceInfo.js lines 1664-1694
   */
  const doCallGetSkuDetails = async (filteredSku, type, downPayment = 0, filteredLineFromCart = null) => {
    const { deviceId = '' } = '';

    // THIS IS THE IF CONDITION WE'RE TESTING (Line 1664)
    if (filteredSku && filteredSku.sorId) {
      const params = {
        data: {
          sorId: filteredSku.sorId,
          productType: 'device',
          ...(type === 'PDPLocalScan' ? { deviceId } : {}),
          processingMTN: activeMtn,
          productId,
          mtnList,
          bogoEnabled: 'true',
          deviceDollarsAccountConvertedInd: '',
        },
      };

      const computeDPPriceReq = {
        sorId: filteredSku?.sorId,
        mtn: activeMtn,
        term: filteredSku?.price?.preferredTerm,
        downPayment: downPayment || filteredLineFromCart?.installmentInfo?.downPayment,
        isPercentage: false,
        agentOrFullRetailPrice: filteredSku?.price?.fullRetailPrice?.originalPrice,
        loanOfferId: filteredSku?.price?.devicePaymentPrice?.[0]?.dpTermPrices?.loanOfferDetails?.loanOfferId || '',
      };

      await mockGetInventoryDetails({ body: params }, false);

      // Nested IF condition (Line 1687)
      if (Number(downPayment || filteredLineFromCart?.installmentInfo?.downPayment) > 0) {
        mockComputeDPPriceBody({ body: computeDPPriceReq }, false);
      }

      mockSetUpcCode(filteredSku?.upcCodeFull);
      mockSetIsDevicePricingApiCallEnable(true);
    }
  };

  describe('TRUE Branch - filteredSku exists with sorId', () => {
    const validFilteredSku = {
      sorId: 'SKU123',
      price: {
        fullRetailPrice: { originalPrice: '999.99' },
        devicePaymentPrice: [
          {
            dpTermPrices: {
              preferredTerm: 36,
              loanOfferDetails: { loanOfferId: 'LOAN123' },
            },
          },
        ],
        preferredTerm: 36,
      },
      upcCodeFull: '123456789012',
    };

    test('should execute IF block and call getInventoryDetails', async () => {
      await doCallGetSkuDetails(validFilteredSku, 'size');

      expect(mockGetInventoryDetails).toHaveBeenCalledTimes(1);
      expect(mockGetInventoryDetails).toHaveBeenCalledWith(
        {
          body: {
            data: {
              sorId: 'SKU123',
              productType: 'device',
              processingMTN: activeMtn,
              productId,
              mtnList,
              bogoEnabled: 'true',
              deviceDollarsAccountConvertedInd: '',
            },
          },
        },
        false
      );
    });

    test('should call setUpcCode with upcCodeFull', async () => {
      await doCallGetSkuDetails(validFilteredSku, 'size');

      expect(mockSetUpcCode).toHaveBeenCalledTimes(1);
      expect(mockSetUpcCode).toHaveBeenCalledWith('123456789012');
    });

    test('should call setIsDevicePricingApiCallEnable with true', async () => {
      await doCallGetSkuDetails(validFilteredSku, 'size');

      expect(mockSetIsDevicePricingApiCallEnable).toHaveBeenCalledTimes(1);
      expect(mockSetIsDevicePricingApiCallEnable).toHaveBeenCalledWith(true);
    });

    test('should include deviceId when type is PDPLocalScan', async () => {
      await doCallGetSkuDetails(validFilteredSku, 'PDPLocalScan');

      expect(mockGetInventoryDetails).toHaveBeenCalledTimes(1);
      const callArgs = mockGetInventoryDetails.mock.calls[0][0];
      expect(callArgs.body.data).toHaveProperty('deviceId');
    });

    test('should NOT include deviceId when type is not PDPLocalScan', async () => {
      await doCallGetSkuDetails(validFilteredSku, 'size');

      expect(mockGetInventoryDetails).toHaveBeenCalledTimes(1);
      const callArgs = mockGetInventoryDetails.mock.calls[0][0];
      expect(callArgs.body.data).not.toHaveProperty('deviceId');
    });

    test('should call computeDPPriceBody when downPayment > 0', async () => {
      await doCallGetSkuDetails(validFilteredSku, 'size', 100);

      expect(mockComputeDPPriceBody).toHaveBeenCalledTimes(1);
      expect(mockComputeDPPriceBody).toHaveBeenCalledWith(
        {
          body: {
            sorId: 'SKU123',
            mtn: activeMtn,
            term: 36,
            downPayment: 100,
            isPercentage: false,
            agentOrFullRetailPrice: '999.99',
            loanOfferId: 'LOAN123',
          },
        },
        false
      );
    });

    test('should call computeDPPriceBody when filteredLineFromCart downPayment > 0', async () => {
      const filteredLineFromCart = {
        installmentInfo: {
          downPayment: 200,
        },
      };

      await doCallGetSkuDetails(validFilteredSku, 'size', 0, filteredLineFromCart);

      expect(mockComputeDPPriceBody).toHaveBeenCalledTimes(1);
      const callArgs = mockComputeDPPriceBody.mock.calls[0][0];
      expect(callArgs.body.downPayment).toBe(200);
    });

    test('should NOT call computeDPPriceBody when downPayment is 0', async () => {
      await doCallGetSkuDetails(validFilteredSku, 'size', 0);

      expect(mockComputeDPPriceBody).not.toHaveBeenCalled();
    });

    test('should handle missing preferredTerm gracefully', async () => {
      const skuWithoutTerm = {
        ...validFilteredSku,
        price: {
          ...validFilteredSku.price,
          preferredTerm: undefined,
        },
      };

      await doCallGetSkuDetails(skuWithoutTerm, 'size', 100);

      expect(mockComputeDPPriceBody).toHaveBeenCalled();
      const callArgs = mockComputeDPPriceBody.mock.calls[0][0];
      expect(callArgs.body.term).toBeUndefined();
    });

    test('should handle missing loanOfferId with empty string', async () => {
      const skuWithoutLoanId = {
        ...validFilteredSku,
        price: {
          ...validFilteredSku.price,
          devicePaymentPrice: [{}],
        },
      };

      await doCallGetSkuDetails(skuWithoutLoanId, 'size', 100);

      expect(mockComputeDPPriceBody).toHaveBeenCalled();
      const callArgs = mockComputeDPPriceBody.mock.calls[0][0];
      expect(callArgs.body.loanOfferId).toBe('');
    });
  });

  describe('FALSE Branch - Condition Not Met', () => {
    test('should NOT execute IF block when filteredSku is null', async () => {
      await doCallGetSkuDetails(null, 'size');

      expect(mockGetInventoryDetails).not.toHaveBeenCalled();
      expect(mockComputeDPPriceBody).not.toHaveBeenCalled();
      expect(mockSetUpcCode).not.toHaveBeenCalled();
      expect(mockSetIsDevicePricingApiCallEnable).not.toHaveBeenCalled();
    });

    test('should NOT execute IF block when filteredSku is undefined', async () => {
      await doCallGetSkuDetails(undefined, 'size');

      expect(mockGetInventoryDetails).not.toHaveBeenCalled();
      expect(mockComputeDPPriceBody).not.toHaveBeenCalled();
      expect(mockSetUpcCode).not.toHaveBeenCalled();
      expect(mockSetIsDevicePricingApiCallEnable).not.toHaveBeenCalled();
    });

    test('should NOT execute IF block when sorId is undefined', async () => {
      const skuWithoutSorId = {
        price: { fullRetailPrice: { originalPrice: '999.99' } },
        sorId: undefined,
      };

      await doCallGetSkuDetails(skuWithoutSorId, 'size');

      expect(mockGetInventoryDetails).not.toHaveBeenCalled();
      expect(mockComputeDPPriceBody).not.toHaveBeenCalled();
      expect(mockSetUpcCode).not.toHaveBeenCalled();
      expect(mockSetIsDevicePricingApiCallEnable).not.toHaveBeenCalled();
    });

    test('should NOT execute IF block when sorId is empty string', async () => {
      const skuWithEmptySorId = {
        price: { fullRetailPrice: { originalPrice: '999.99' } },
        sorId: '',
      };

      await doCallGetSkuDetails(skuWithEmptySorId, 'size');

      expect(mockGetInventoryDetails).not.toHaveBeenCalled();
      expect(mockComputeDPPriceBody).not.toHaveBeenCalled();
      expect(mockSetUpcCode).not.toHaveBeenCalled();
      expect(mockSetIsDevicePricingApiCallEnable).not.toHaveBeenCalled();
    });

    test('should NOT execute IF block when sorId is 0', async () => {
      const skuWithZeroSorId = {
        price: { fullRetailPrice: { originalPrice: '999.99' } },
        sorId: 0,
      };

      await doCallGetSkuDetails(skuWithZeroSorId, 'size');

      expect(mockGetInventoryDetails).not.toHaveBeenCalled();
      expect(mockComputeDPPriceBody).not.toHaveBeenCalled();
      expect(mockSetUpcCode).not.toHaveBeenCalled();
      expect(mockSetIsDevicePricingApiCallEnable).not.toHaveBeenCalled();
    });
  });

  describe('Edge Cases', () => {
    test('should handle missing upcCodeFull', async () => {
      const skuWithoutUpc = {
        sorId: 'SKU123',
        price: {
          fullRetailPrice: { originalPrice: '999.99' },
          devicePaymentPrice: [
            {
              dpTermPrices: {
                preferredTerm: 36,
                loanOfferDetails: { loanOfferId: 'LOAN123' },
              },
            },
          ],
          preferredTerm: 36,
        },
        upcCodeFull: undefined,
      };

      await doCallGetSkuDetails(skuWithoutUpc, 'size');

      expect(mockSetUpcCode).toHaveBeenCalledWith(undefined);
    });

    test('should handle complex downPayment fallback logic', async () => {
      const filteredLineFromCart = {
        installmentInfo: {
          downPayment: 150,
        },
      };

      // When downPayment prop is 0, should use cart's downPayment
      await doCallGetSkuDetails(
        {
          sorId: 'SKU123',
          price: { fullRetailPrice: { originalPrice: '999.99' } },
        },
        'size',
        0,
        filteredLineFromCart
      );

      expect(mockComputeDPPriceBody).toHaveBeenCalled();
    });
  });

  describe('Integration Scenarios', () => {
    test('should execute complete TRUE branch flow', async () => {
      const completeSku = {
        sorId: 'COMPLETE_SKU',
        price: {
          fullRetailPrice: { originalPrice: '1099.99' },
          devicePaymentPrice: [
            {
              dpTermPrices: {
                preferredTerm: 24,
                loanOfferDetails: { loanOfferId: 'LOAN456' },
              },
            },
          ],
          preferredTerm: 24,
        },
        upcCodeFull: '111222333444',
      };

      await doCallGetSkuDetails(completeSku, 'PDPLocalScan', 150);

      // All functions should be called
      expect(mockGetInventoryDetails).toHaveBeenCalled();
      expect(mockComputeDPPriceBody).toHaveBeenCalled();
      expect(mockSetUpcCode).toHaveBeenCalled();
      expect(mockSetIsDevicePricingApiCallEnable).toHaveBeenCalled();

      // Verify params include deviceId
      const inventoryCall = mockGetInventoryDetails.mock.calls[0][0];
      expect(inventoryCall.body.data).toHaveProperty('deviceId');

      // Verify all values are correct
      expect(mockSetUpcCode).toHaveBeenCalledWith('111222333444');
      expect(mockSetIsDevicePricingApiCallEnable).toHaveBeenCalledWith(true);
    });
  });
});
