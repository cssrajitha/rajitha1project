import React from 'react';
import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import PDP from '../PDP';
import preBackProductDetails from '../../../pages/PDP/mocks/api/preBackProductDetails.json';
import props from './pdpDfill.json';

const dispatchedActions = [];
const mockStore = {
  dispatch: (action) => {
    dispatchedActions.push(action);
  },
};

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: () => ['TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE'],
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => false,
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfecommon/APIService',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('onevzsoemfecommon/APIService'),
      useAddDeviceMutation: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: false,
              isError: true,
              isFetching: false,
              error: {
                data: {
                  errors: [
                    {
                      namespace: 'cxp-shopping-services',
                      id: '3247',
                      message:
                        ' Local and Pre/back devices on different lines not allowed in cart. You may add this device to cart only for creating a quote. To place an order you need to create a separate order.',
                      debug_id:
                        '2024-10-25T08:55:28.+0000:4928c0ec67e3c973:cxp-shopping-services-64b449568f-nq9fk:nssit3',
                      name: 'DEVICE_LOCAL_AND_PREBACK_CANNOT_BE_TOGETHER',
                    },
                  ],
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
    };
  },
  { virtual: true },
);

describe('PDP component render for DFill Flow Back order with local order in cart', () => {
  navigator.clipboard = jest.fn();
  navigator.clipboard.writeText = jest.fn('Pink');
  beforeEach(() => {
    window.store = mockStore;
    window.vzdl = { page: {} };
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?offerEligible=Y&activeMtn=9102798662&productId=dev21410695&defaultSku=MTXW3LL/A`;
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        productDetails={preBackProductDetails}
        {...props}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('component should render', async () => {
    const shipIt = screen.getByRole('button', {
      name: /Ship It/i,
    });
    expect(shipIt).toBeInTheDocument();
    fireEvent.click(shipIt);
    const localPreBackBanner = await screen.findByTestId('localPreBackErrMsg');
    expect(localPreBackBanner).toBeInTheDocument();
    const addToCartCTA = await screen.findByText('Add to cart');
    expect(addToCartCTA).toBeInTheDocument();
    fireEvent.click(addToCartCTA);
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });
  jest.setTimeout(10000);
});
