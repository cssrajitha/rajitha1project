import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import DeviceLockInfo from '../DeviceLockInfo/DeviceLockInfo';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';

describe('<DeviceLockInfo/>', () => {
  const mockHideModalHandler = jest.fn();
  const htmlContent = `<div><p><strong>Device Unlocking Policies</strong></p>
  <p>In order to mitigate theft and other fraudulent activity, newly purchased devices are
  "u201Clockedu201D" to work exclusively on the Verizon network. We have separate device
  unlocking policies that cover postpay and prepaid devices, as well as special rules for
  deployed military personnel.</p><p>"u201CUnlockingu201D" a device refers only to disabling software that would prevent a consumer
  from attempting to activate a device designed for one carrieru2019s network. Due to differing technologies, an unlocked Verizon Wireless device
  may not work u2013 or may experience limited functionality u2013 on another carrieru2019s network.</p>
  <p><strong>Postpay Device Unlocking Policy</strong></p>
  <p>Devices that you purchase from Verizon are locked for 60 days after purchase. Devices that you purchase from our retail partners are locked for 60 days after activation.After 60 days, we will automatically remove the lock. Following the 60 day lock period, we do not lock our phones at any time.</p>
  <p><strong>Prepaid Device Unlocking Policy</strong></p>
  <p>Devices that you purchase from Verizon and certain devices purchased from our retail partners are locked for 60 days after activation. After 60 days, we will automatically remove the lock. Following the 60 day lock period following device purchase, we do not lock our phones at any time.</p>
  <p>If you purchase a 4G Phone-in-a-Box from our retail partners, you should review the back of the box to determine the lock period applicable to that device.</p>
  <p><strong>Unlocking Policy for Deployed Military Personnel</strong></p>
  <p>If you are a Verizon Wireless customer in the military and receive relocation orders outside of the Verizon Coverage Area, we will unlock your device at your request, even during the 60-day-lock period following the purchase of your device.</p>
  <p>Effective Date: July 23, 2019</p></div>`;
  it('should test <DeviceLockInfo/>', () => {
    const { container } = render(<DeviceLockInfo hideModal={mockHideModalHandler} htmlContent={htmlContent} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    expect(screen.getByText(/important device lock information/i)).toBeInTheDocument();
    expect(
      screen.getByRole('img', {
        name: /left-caret icon/i,
      }),
    ).toBeInTheDocument();
    expect(container.querySelector('div > div > div > div:nth-child(2) > div').innerHTML).toBe(htmlContent);

    fireEvent.click(
      screen.getByRole('img', {
        name: /left-caret icon/i,
      }),
    );
    expect(mockHideModalHandler).toBeCalled();
  });
});
