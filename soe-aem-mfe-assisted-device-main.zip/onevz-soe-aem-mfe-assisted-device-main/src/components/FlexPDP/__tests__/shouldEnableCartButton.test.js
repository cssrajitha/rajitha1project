/**
 * Unit Tests for shouldEnableCartButton Function
 *
 * This file provides comprehensive coverage for all 12 early-return conditions
 * in the shouldEnableCartButton helper function (PDP.js lines 85-175).
 *
 * Testing Strategy: Pure unit tests importing the actual function from PDP.js
 * Each test targets a specific IF condition with precise scenario coverage.
 */

import { shouldEnableCartButton } from '../PDP';

describe('shouldEnableCartButton - Pure Unit Tests', () => {
  /**
   * Base context object with all properties set to falsy values
   * This ensures each test only enables the specific condition being tested
   */
  const createBaseContext = () => ({
    isIndirectChannel: false,
    fromCPE: false,
    numberShare: false,
    shareValue: '',
    rfexFlowBtn: false,
    contractChange: false,
    ispuToggle: false,
    sku: null,
    shipItToggle: false,
    prePay: false,
    preOrder: false,
    backorder: false,
    dFillQty: false,
    contract: false,
    pastbalPreBackOrder: false,
    cashOnlyCustomer: false,
    devId: '',
    simCardId: '',
    numberShareAndByod: false,
    orderDet: { customerType: 'E' },
    lineActivityType: 'UPGRADE',
    protectionFeat: null,
    selectedProtection: null,
    simLocalCardId: '',
    lineDeviceId: '',
    lineSimId: '',
    channelType: '',
  });

  describe('Condition 1: Indirect Channel Local Orders (Line 803)', () => {
    it('should return true when indirect channel with local order (no number share)', () => {
      const ctx = {
        ...createBaseContext(),
        isIndirectChannel: true,
        shipItToggle: false,
        numberShare: false,
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return true when indirect channel with number share and valid value', () => {
      const ctx = {
        ...createBaseContext(),
        isIndirectChannel: true,
        shipItToggle: false,
        numberShare: true,
        shareValue: 'MTN12345',
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return false when indirect channel but shipItToggle is on', () => {
      const ctx = {
        ...createBaseContext(),
        isIndirectChannel: true,
        shipItToggle: true,
        numberShare: false,
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });

    it('should return false when indirect channel with number share but empty value', () => {
      const ctx = {
        ...createBaseContext(),
        isIndirectChannel: true,
        shipItToggle: false,
        numberShare: true,
        shareValue: '',
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });

    it('should return true when indirect channel with number share and non-empty shareValue (different format)', () => {
      const ctx = {
        ...createBaseContext(),
        isIndirectChannel: true,
        shipItToggle: false,
        numberShare: true,
        shareValue: '1234567890', // Different shareValue format
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return true when indirect channel with number share but null shareValue (null !== "")', () => {
      const ctx = {
        ...createBaseContext(),
        isIndirectChannel: true,
        shipItToggle: false,
        numberShare: true,
        shareValue: null, // null !== '' is true, so condition passes!
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return true when indirect channel with number share but undefined shareValue (undefined !== "")', () => {
      const ctx = {
        ...createBaseContext(),
        isIndirectChannel: true,
        shipItToggle: false,
        numberShare: true,
        shareValue: undefined, // undefined !== '' is true, so condition passes!
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return true when indirect channel without number share (validates !numberShare branch)', () => {
      const ctx = {
        ...createBaseContext(),
        isIndirectChannel: true,
        shipItToggle: false,
        numberShare: false,
        shareValue: '', // shareValue doesn't matter when numberShare is false
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return true when indirect channel, no numberShare, with arbitrary shareValue', () => {
      const ctx = {
        ...createBaseContext(),
        isIndirectChannel: true,
        shipItToggle: false,
        numberShare: false,
        shareValue: 'MTN99999', // shareValue is ignored when !numberShare is true
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });
  });

  describe('Condition 2: CPE Flow - No Number Share (Line 808)', () => {
    it('should return true when fromCPE is true and numberShare is false', () => {
      const ctx = {
        ...createBaseContext(),
        fromCPE: true,
        numberShare: false,
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return false when fromCPE is false', () => {
      const ctx = {
        ...createBaseContext(),
        fromCPE: false,
        numberShare: false,
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });
  });

  describe('Condition 3: CPE Flow - Number Share with Value (Line 809)', () => {
    it('should return true when fromCPE, numberShare, and shareValue are all truthy', () => {
      const ctx = {
        ...createBaseContext(),
        fromCPE: true,
        numberShare: true,
        shareValue: 'MTN67890',
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return false when fromCPE and numberShare but shareValue is empty', () => {
      const ctx = {
        ...createBaseContext(),
        fromCPE: true,
        numberShare: true,
        shareValue: '',
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });

    it('should return false when numberShare and shareValue but fromCPE is false', () => {
      const ctx = {
        ...createBaseContext(),
        fromCPE: false,
        numberShare: true,
        shareValue: 'MTN67890',
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });
  });

  describe('Condition 4: Refund/Exchange Flow (Line 812)', () => {
    it('should return true when rfexFlowBtn and contractChange are both true', () => {
      const ctx = {
        ...createBaseContext(),
        rfexFlowBtn: true,
        contractChange: true,
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return false when rfexFlowBtn is true but contractChange is false', () => {
      const ctx = {
        ...createBaseContext(),
        rfexFlowBtn: true,
        contractChange: false,
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });

    it('should return false when contractChange is true but rfexFlowBtn is false', () => {
      const ctx = {
        ...createBaseContext(),
        rfexFlowBtn: false,
        contractChange: true,
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });
  });

  describe('Condition 5: ISPU - Instore Pickup SKU (Line 815)', () => {
    it('should return true when ispuToggle is on and SKU is instore pickup', () => {
      const ctx = {
        ...createBaseContext(),
        ispuToggle: true,
        sku: { isInstorePickup: true },
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return true when ispuToggle is on (caught by condition 6 even if not instore pickup)', () => {
      const ctx = {
        ...createBaseContext(),
        ispuToggle: true,
        sku: { isInstorePickup: false },
      };
      // This returns true because condition 6 (line 816) catches ispuToggle
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return false when SKU is instore pickup but ispuToggle is off', () => {
      const ctx = {
        ...createBaseContext(),
        ispuToggle: false,
        sku: { isInstorePickup: true },
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });

    it('should return true when ispuToggle is on even with null sku (caught by condition 6)', () => {
      const ctx = {
        ...createBaseContext(),
        ispuToggle: true,
        sku: null,
      };
      // Condition 5 returns false (sku?.isInstorePickup is undefined)
      // But condition 6 catches this: ispuToggle || ...
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });
  });

  describe('Condition 6: ISPU Toggle OR CPE (Line 816)', () => {
    it('should return true when ispuToggle is on (regardless of other conditions)', () => {
      const ctx = {
        ...createBaseContext(),
        ispuToggle: true,
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return true when fromCPE without number share', () => {
      const ctx = {
        ...createBaseContext(),
        ispuToggle: false,
        fromCPE: true,
        numberShare: false,
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return true when fromCPE with number share and valid value', () => {
      const ctx = {
        ...createBaseContext(),
        ispuToggle: false,
        fromCPE: true,
        numberShare: true,
        shareValue: 'MTN99999',
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return false when fromCPE with number share but empty value', () => {
      const ctx = {
        ...createBaseContext(),
        ispuToggle: false,
        fromCPE: true,
        numberShare: true,
        shareValue: '',
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });
  });

  describe('Condition 7: Pre-pay (Line 819)', () => {
    it('should return true when all pre-pay conditions are met', () => {
      const ctx = {
        ...createBaseContext(),
        prePay: true,
        preOrder: false,
        backorder: false,
        dFillQty: true,
        contract: true,
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return true when prePay with preOrder (caught by condition 8)', () => {
      const ctx = {
        ...createBaseContext(),
        prePay: true,
        preOrder: true, // This triggers condition 8 (lines 822-824)
        backorder: false,
        dFillQty: true,
        contract: true,
        pastbalPreBackOrder: false,
        cashOnlyCustomer: false,
        numberShare: false,
      };
      // Condition 7 fails (!preOrder is false)
      // But condition 8 catches this: !pastbalPreBackOrder && !cashOnlyCustomer && preOrder
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return true when prePay with backorder (caught by condition 8)', () => {
      const ctx = {
        ...createBaseContext(),
        prePay: true,
        preOrder: false,
        backorder: true, // This triggers condition 8 (lines 822-824)
        dFillQty: true,
        contract: true,
        pastbalPreBackOrder: false,
        cashOnlyCustomer: false,
        numberShare: false,
      };
      // Condition 7 fails (!backorder is false)
      // But condition 8 catches this: !pastbalPreBackOrder && !cashOnlyCustomer && backorder
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return false when prePay but dFillQty is false', () => {
      const ctx = {
        ...createBaseContext(),
        prePay: true,
        preOrder: false,
        backorder: false,
        dFillQty: false,
        contract: true,
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });

    it('should return false when prePay but contract is false', () => {
      const ctx = {
        ...createBaseContext(),
        prePay: true,
        preOrder: false,
        backorder: false,
        dFillQty: true,
        contract: false,
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });
  });

  describe('Condition 8: Pre-order and Backorder (Lines 822-824)', () => {
    it('should return true for preOrder without number share', () => {
      const ctx = {
        ...createBaseContext(),
        pastbalPreBackOrder: false,
        cashOnlyCustomer: false,
        preOrder: true,
        backorder: false,
        numberShare: false,
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return true for backorder without number share', () => {
      const ctx = {
        ...createBaseContext(),
        pastbalPreBackOrder: false,
        cashOnlyCustomer: false,
        preOrder: false,
        backorder: true,
        numberShare: false,
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return true for preOrder with number share and valid value', () => {
      const ctx = {
        ...createBaseContext(),
        pastbalPreBackOrder: false,
        cashOnlyCustomer: false,
        preOrder: true,
        numberShare: true,
        shareValue: 'MTN11111',
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return false when pastbalPreBackOrder is true', () => {
      const ctx = {
        ...createBaseContext(),
        pastbalPreBackOrder: true,
        cashOnlyCustomer: false,
        preOrder: true,
        numberShare: false,
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });

    it('should return false when cashOnlyCustomer is true', () => {
      const ctx = {
        ...createBaseContext(),
        pastbalPreBackOrder: false,
        cashOnlyCustomer: true,
        preOrder: true,
        numberShare: false,
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });

    it('should return false when number share but empty value', () => {
      const ctx = {
        ...createBaseContext(),
        pastbalPreBackOrder: false,
        cashOnlyCustomer: false,
        preOrder: true,
        numberShare: true,
        shareValue: '',
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });
  });

  describe('Condition 9: CPE with Device and SIM (Line 828)', () => {
    it('should return true when fromCPE with device and SIM, no number share', () => {
      const ctx = {
        ...createBaseContext(),
        fromCPE: true,
        devId: 'DEV123',
        simCardId: 'SIM456',
        numberShare: false,
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return true when fromCPE with device, SIM, and number share with value', () => {
      const ctx = {
        ...createBaseContext(),
        fromCPE: true,
        devId: 'DEV123',
        simCardId: 'SIM456',
        numberShare: true,
        shareValue: 'MTN22222',
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return true when fromCPE missing deviceId (caught by condition 2 or 6)', () => {
      const ctx = {
        ...createBaseContext(),
        fromCPE: true,
        devId: '',
        simCardId: 'SIM456',
        numberShare: false,
      };
      // Condition 9 fails (no devId)
      // But condition 2 or 6 catches: fromCPE && !numberShare
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return true when fromCPE missing simCardId (caught by condition 2 or 6)', () => {
      const ctx = {
        ...createBaseContext(),
        fromCPE: true,
        devId: 'DEV123',
        simCardId: '',
        numberShare: false,
      };
      // Condition 9 fails (no simCardId)
      // But condition 2 or 6 catches: fromCPE && !numberShare
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return false when number share but empty value', () => {
      const ctx = {
        ...createBaseContext(),
        fromCPE: true,
        devId: 'DEV123',
        simCardId: 'SIM456',
        numberShare: true,
        shareValue: '',
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });
  });

  describe('Condition 10: Number Share and BYOD (Line 831)', () => {
    it('should return true when numberShareAndByod is true', () => {
      const ctx = {
        ...createBaseContext(),
        numberShareAndByod: true,
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return false when numberShareAndByod is false', () => {
      const ctx = {
        ...createBaseContext(),
        numberShareAndByod: false,
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });
  });

  describe('Condition 11: Protection Feature Change (Lines 834-840)', () => {
    it('should return true for new customer (N) with different protection', () => {
      const ctx = {
        ...createBaseContext(),
        orderDet: { customerType: 'N' },
        protectionFeat: { currentProtection: { sorId: 'PROT_OLD' } },
        selectedProtection: { sorId: 'PROT_NEW' },
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return true for BYOD activity with different protection', () => {
      const ctx = {
        ...createBaseContext(),
        orderDet: { customerType: 'E' },
        lineActivityType: 'BYOD',
        protectionFeat: { currentProtection: { sorId: 'PROT_A' } },
        selectedProtection: { sorId: 'PROT_B' },
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return true for EUPBYOD activity with different protection', () => {
      const ctx = {
        ...createBaseContext(),
        orderDet: { customerType: 'E' },
        lineActivityType: 'EUPBYOD',
        protectionFeat: { currentProtection: { sorId: 'PROT_X' } },
        selectedProtection: { sorId: 'PROT_Y' },
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return false when protection sorIds are the same', () => {
      const ctx = {
        ...createBaseContext(),
        orderDet: { customerType: 'N' },
        protectionFeat: { currentProtection: { sorId: 'PROT_SAME' } },
        selectedProtection: { sorId: 'PROT_SAME' },
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });

    it('should return false when currentProtection is missing', () => {
      const ctx = {
        ...createBaseContext(),
        orderDet: { customerType: 'N' },
        protectionFeat: null,
        selectedProtection: { sorId: 'PROT_NEW' },
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });

    it('should return false when selectedProtection is missing', () => {
      const ctx = {
        ...createBaseContext(),
        orderDet: { customerType: 'N' },
        protectionFeat: { currentProtection: { sorId: 'PROT_OLD' } },
        selectedProtection: null,
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });

    it('should return false for existing customer (E) with UPGRADE activity', () => {
      const ctx = {
        ...createBaseContext(),
        orderDet: { customerType: 'E' },
        lineActivityType: 'UPGRADE',
        protectionFeat: { currentProtection: { sorId: 'PROT_OLD' } },
        selectedProtection: { sorId: 'PROT_NEW' },
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });
  });

  describe('Condition 12: Device/SIM ID Matching (Lines 844-848)', () => {
    it('should return true for RETAIL channel with matching device but different SIM', () => {
      const ctx = {
        ...createBaseContext(),
        devId: 'DEV_MATCH',
        lineDeviceId: 'DEV_MATCH',
        simLocalCardId: 'SIM_NEW',
        lineSimId: 'SIM_OLD',
        channelType: 'RETAIL',
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return true for TELESALES channel with matching device but different SIM', () => {
      const ctx = {
        ...createBaseContext(),
        devId: 'DEV_MATCH',
        lineDeviceId: 'DEV_MATCH',
        simLocalCardId: 'SIM_NEW',
        lineSimId: 'SIM_OLD',
        channelType: 'TELESALES',
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return true for mixed channel type containing RETAIL', () => {
      const ctx = {
        ...createBaseContext(),
        devId: 'DEV_MATCH',
        lineDeviceId: 'DEV_MATCH',
        simLocalCardId: 'SIM_NEW',
        lineSimId: 'SIM_OLD',
        channelType: 'OMNI-RETAIL',
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should return false when device IDs do not match', () => {
      const ctx = {
        ...createBaseContext(),
        devId: 'DEV_NEW',
        lineDeviceId: 'DEV_OLD',
        simLocalCardId: 'SIM_NEW',
        lineSimId: 'SIM_OLD',
        channelType: 'RETAIL',
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });

    it('should return false when SIM IDs are the same', () => {
      const ctx = {
        ...createBaseContext(),
        devId: 'DEV_MATCH',
        lineDeviceId: 'DEV_MATCH',
        simLocalCardId: 'SIM_SAME',
        lineSimId: 'SIM_SAME',
        channelType: 'RETAIL',
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });

    it('should return false for non-RETAIL/TELESALES channel', () => {
      const ctx = {
        ...createBaseContext(),
        devId: 'DEV_MATCH',
        lineDeviceId: 'DEV_MATCH',
        simLocalCardId: 'SIM_NEW',
        lineSimId: 'SIM_OLD',
        channelType: 'ONLINE',
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });
  });

  describe('Default Case: All Conditions False', () => {
    it('should return false when no conditions are met', () => {
      const ctx = createBaseContext();
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });

    it('should return false when conditions are partially met but incomplete', () => {
      const ctx = {
        ...createBaseContext(),
        fromCPE: true,
        numberShare: true,
        shareValue: '', // Missing required value
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });
  });

  describe('Edge Cases and Boundary Conditions', () => {
    it('should handle empty string as falsy for shareValue', () => {
      const ctx = {
        ...createBaseContext(),
        fromCPE: true,
        numberShare: true,
        shareValue: '',
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });

    it('should handle whitespace-only shareValue as truthy', () => {
      const ctx = {
        ...createBaseContext(),
        fromCPE: true,
        numberShare: true,
        shareValue: '   ',
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should handle null sku object gracefully (returns true via condition 6)', () => {
      const ctx = {
        ...createBaseContext(),
        ispuToggle: true,
        sku: null,
      };
      // Condition 5 fails (sku?.isInstorePickup with null sku)
      // But condition 6 catches: ispuToggle || ...
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should handle undefined sku object gracefully (returns true via condition 6)', () => {
      const ctx = {
        ...createBaseContext(),
        ispuToggle: true,
        sku: undefined,
      };
      // Condition 5 fails (sku?.isInstorePickup with undefined sku)
      // But condition 6 catches: ispuToggle || ...
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should handle missing currentProtection in protectionFeat', () => {
      const ctx = {
        ...createBaseContext(),
        orderDet: { customerType: 'N' },
        protectionFeat: {},
        selectedProtection: { sorId: 'PROT_NEW' },
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });

    it('should handle channelType.includes when channelType is empty string', () => {
      const ctx = {
        ...createBaseContext(),
        devId: 'DEV_MATCH',
        lineDeviceId: 'DEV_MATCH',
        simLocalCardId: 'SIM_NEW',
        lineSimId: 'SIM_OLD',
        channelType: '',
      };
      expect(shouldEnableCartButton(ctx)).toBe(false);
    });
  });

  describe('Priority and Condition Order', () => {
    it('should return true on first matching condition (indirect channel)', () => {
      const ctx = {
        ...createBaseContext(),
        isIndirectChannel: true,
        shipItToggle: false,
        numberShare: false,
        // Also set other conditions that would return true
        fromCPE: true,
        rfexFlowBtn: true,
        contractChange: true,
      };
      // First condition matches, should return immediately
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });

    it('should check conditions in order until first match', () => {
      const ctx = {
        ...createBaseContext(),
        // Skip condition 1
        isIndirectChannel: false,
        // Skip condition 2
        fromCPE: false,
        // Match condition 4 (rfex)
        rfexFlowBtn: true,
        contractChange: true,
      };
      expect(shouldEnableCartButton(ctx)).toBe(true);
    });
  });
});
