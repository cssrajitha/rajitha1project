import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import Emitter from 'onevzsoemfeframework/Emitter';
import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import PDP from '../PDP';
import protectionFeatures from '../../../pages/PDP/mocks/api/getProtectionFeatures.json';
import productDetails from '../../../pages/PDP/mocks/api/getDetails.json';
import productDetails2 from '../../../pages/PDP/mocks/api/getDetails2.json';
import customerProfileDetails from '../../../pages/PDP/mocks/api/customerProfile.json';
import cartDetails from '../../../pages/PDP/mocks/api/retrieveCart.json';

const details = productDetails.data.deviceProduct || {};
const defaultSkuStringValue = details?.defaultSKU || '';
const defaultSkuObjValue = details?.defaultSKUObj?.sorId || '';
const defaultSku = defaultSkuStringValue !== '' ? defaultSkuStringValue : defaultSkuObjValue;
const defaultSkuDetails = details.childSkus.filter((sku) => sku.sorId && sku.sorId === defaultSku);
const RemoveLinesAPIResultWithErrorCode = {
  data: {
    errors: [
      {
        id: '9656',
      },
    ],
  },
  status: 'fulfilled',
};
const RemoveLinesAPIResultWithAPIResponseWithDiffProcessStep = {
  data: {
    serviceBody: {
      serviceResponse: {
        context: {
          contextInfo: {
            processStep: 'CartResponse',
          },
        },
      },
    },
  },
  status: 'fulfilled',
};
const dispatchedActions = [];
const mockStore = {
  dispatch: (action) => {
    dispatchedActions.push(action);
  },
};

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: () => [false, true, 'TRUE'],
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => false,
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfecommon/APIService',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('onevzsoemfecommon/APIService'),
      useAddDeviceMutation: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                serviceBody: {
                  serviceResponse: {
                    context: {
                      contextInfo: {
                        processStep: 'PlanSelection',
                      },
                      cartInfo: { lines: [{ downPaymentAmtApplied: '15', device: { upgradeReasonCode: 'UN' } }] },
                    },
                  },
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
    };
  },
  { virtual: true },
);

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

describe('PDP component render', () => {
  const activeMtn = '5185673926';
  const props = {
    paymentObject: { contractDuration: 36 },
    buyoutUpgradeResult: { data: { totalBuyoutAmount: '56.7' }, status: 'fulfilled' },
    RemoveLinesAPIResult: {
      data: {
        errors: [
          {
            id: '9656',
          },
        ],
      },
      status: 'fulfilled',
    },
    setSelectedDeviceData: jest.fn(),
  };

  beforeAll(() => {
    sessionStorage.setItem('refundexchange', 'false');
    sessionStorage.setItem('isSAExist', true);
    sessionStorage.setItem('isSANew', true);
    sessionStorage.setItem('isSecondNumLocal', true);

    const location = {
      ...window.location,
      search: `?activeMtn=${activeMtn}&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y&eSim=true&eId=7845678908764652347673463764`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=${activeMtn}&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y&eSim=true&eId=7845678908764652347673463764`;
  });
  beforeEach(() => {
    render(
      <PDP
        productDetails={productDetails.data}
        protectionFeatures={protectionFeatures}
        cartDetails={cartDetails.data.data}
        customerProfileDetails={customerProfileDetails.data}
        activeMtn={activeMtn}
        selectedColor={defaultSkuDetails[0].color.displayName}
        setSelectedColor={jest.fn()}
        ispuToggleOn={false}
        setIspuToggleOn={jest.fn()}
        isShipItToggleOn={false}
        setIsShipItToggleOn={jest.fn()}
        selectedSku={defaultSkuDetails[0]}
        setSelectedSku={jest.fn()}
        selectedProtectionFeature={protectionFeatures.payload.features[1]}
        setSelectedProtectionFeature={jest.fn()}
        selectedSize={defaultSkuDetails[0].capacity}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        RemoveLinesAPIResult={RemoveLinesAPIResultWithErrorCode}
        {...props}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
    Emitter.emit('TAGGING_COMPLETED', true);
  });
  test.skip('component should render', async () => {
    fireEvent.click(
      screen.getByRole('button', {
        name: /add to cart/i,
      }),
    );
    const continueBtn = screen.getByRole('button', { name: 'Continue' });
    fireEvent.click(continueBtn);
  });
});

describe('PDP component render with Removelines Diff Processstep', () => {
  const activeMtn = '5185673926';
  beforeEach(() => {
    sessionStorage.setItem('isSAExist', true);
    sessionStorage.setItem('isSANew', true);
    sessionStorage.setItem('isSecondNumLocal', true);
    window.store = mockStore;
    window.location.href = `http://localhost/?activeMtn=${activeMtn}&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y&deviceFromCart=true`;
    render(
      <PDP
        productDetails={productDetails.data}
        protectionFeatures={protectionFeatures}
        cartDetails={cartDetails.data.data}
        customerProfileDetails={customerProfileDetails.data}
        activeMtn={activeMtn}
        selectedColor={defaultSkuDetails[0].color.displayName}
        setSelectedColor={jest.fn()}
        ispuToggleOn={false}
        setIspuToggleOn={jest.fn()}
        isShipItToggleOn={false}
        setIsShipItToggleOn={jest.fn()}
        selectedSku={defaultSkuDetails[0]}
        setSelectedSku={jest.fn()}
        selectedProtectionFeature={protectionFeatures.payload.features[1]}
        setSelectedProtectionFeature={jest.fn()}
        selectedSize={defaultSkuDetails[0].capacity}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        RemoveLinesAPIResult={RemoveLinesAPIResultWithAPIResponseWithDiffProcessStep}
        setSelectedDeviceData={jest.fn()}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
    Emitter.emit('TAGGING_COMPLETED', true);
  });
  test('component should render', async () => {
    const backButton = await screen.findByTestId('testBackGridwall');
    expect(backButton).toBeInTheDocument();
  });
});

describe('PDP component render for DFill Flow', () => {
  const activeMtn = '5185673926';
  const defaultSkuDetails1 = details.childSkus.filter((sku) => sku.sorId && sku.sorId === 'MPXT3LL/A');
  const props = {
    paymentObject: { contractDuration: 36 },
    buyoutUpgradeResult: { data: { totalBuyoutAmount: '56.7' }, status: 'fulfilled' },
    RemoveLinesAPIResult: {
      data: {
        errors: [
          {
            id: '9656',
          },
        ],
      },
      status: 'fulfilled',
    },
    setSelectedDeviceData: jest.fn(),
  };
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    window.store = mockStore;
    window.vzdl = { page: {} };
    window.location.href = `http://localhost/?activeMtn=${activeMtn}&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y`;
    sessionStorage.setItem('isSAExist', true);
    sessionStorage.setItem('isSANew', true);
    sessionStorage.setItem('isSecondNumLocal', true);
    render(
      <PDP
        productDetails={productDetails2}
        protectionFeatures={protectionFeatures}
        cartDetails={cartDetails.data.data}
        customerProfileDetails={customerProfileDetails.data}
        activeMtn={activeMtn}
        selectedColor={defaultSkuDetails1[0].color.displayName}
        setSelectedColor={jest.fn()}
        ispuToggleOn={false}
        setIspuToggleOn={jest.fn()}
        isShipItToggleOn={false}
        setIsShipItToggleOn={jest.fn()}
        selectedSku={defaultSkuDetails1[0]}
        setSelectedSku={jest.fn()}
        selectedProtectionFeature={protectionFeatures.payload.features[1]}
        setSelectedProtectionFeature={jest.fn()}
        selectedSize={defaultSkuDetails1[0].capacity}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        RemoveLinesAPIResult={RemoveLinesAPIResultWithErrorCode}
        {...props}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
    Emitter.emit('TAGGING_COMPLETED', true);
  });
  test.skip('component should render', async () => {
    const textSku = await screen.findByText('iPhone 14 Pro 128GB in Deep Purple');
    expect(textSku).toBeInTheDocument();
    const toggle = screen.getByRole('checkbox', { name: 'shipit toggle' });
    fireEvent.click(toggle);
    const shipIt = await screen.getByRole('button', {
      name: /Ship It/i,
    });
    expect(shipIt).toBeInTheDocument();
    fireEvent.click(shipIt);
    // const insurance = await screen.findByTestId('DeviceInsurance');
    // expect(insurance).toBeInTheDocument();
    // const continueBtn = screen.getByRole('button', { name: 'Continue' });
    // fireEvent.click(continueBtn);
    // await new Promise((res) => {
    //   setTimeout(res, 2000);
    // });
  });
});

describe('PDP component render no cart details', () => {
  const activeMtn = '5185673926';
  const props = {
    paymentObject: { contractDuration: 36 },
    buyoutUpgradeResult: { data: { totalBuyoutAmount: '56.7' }, status: 'fulfilled' },
    RemoveLinesAPIResult: {
      data: {
        errors: [
          {
            id: '9656',
          },
        ],
      },
      status: 'fulfilled',
    },
    setSelectedDeviceData: jest.fn(),
  };

  beforeAll(() => {
    sessionStorage.setItem('refundexchange', 'false');
    sessionStorage.setItem('isSAExist', true);
    sessionStorage.setItem('isSANew', true);
    sessionStorage.setItem('isSecondNumLocal', true);

    const location = {
      ...window.location,
      search: `?activeMtn=${activeMtn}&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y&eSim=true&eId=7845678908764652347673463764`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=${activeMtn}&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y&eSim=true&eId=7845678908764652347673463764`;
  });
  beforeEach(() => {
    render(
      <PDP
        productDetails={productDetails.data}
        protectionFeatures={protectionFeatures}
        cartDetails={{}}
        customerProfileDetails={customerProfileDetails.data}
        activeMtn={activeMtn}
        selectedColor={defaultSkuDetails[0].color.displayName}
        setSelectedColor={jest.fn()}
        ispuToggleOn={false}
        setIspuToggleOn={jest.fn()}
        isShipItToggleOn={false}
        setIsShipItToggleOn={jest.fn()}
        selectedSku={defaultSkuDetails[0]}
        setSelectedSku={jest.fn()}
        selectedProtectionFeature={protectionFeatures.payload.features[1]}
        setSelectedProtectionFeature={jest.fn()}
        selectedSize={defaultSkuDetails[0].capacity}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        RemoveLinesAPIResult={RemoveLinesAPIResultWithErrorCode}
        {...props}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
    Emitter.emit('TAGGING_COMPLETED', true);
  });
  test.skip('component should render', async () => {
    const textSku = await screen.findByText('iPhone 14 Pro 128GB in Deep Purple');
    expect(textSku).toBeInTheDocument();
    fireEvent.click(
      screen.getByRole('button', {
        name: /add to cart/i,
      }),
    );
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Continue' });
    fireEvent.click(continueBtn);
  });
});

describe('PDP component render 1', () => {
  const activeMtn = '5185673926';
  const props = {
    paymentObject: { contractDuration: 36 },
    buyoutUpgradeResult: { data: { totalBuyoutAmount: '56.7' }, status: 'fulfilled' },
    RemoveLinesAPIResult: {
      data: {
        errors: [
          {
            id: '9656',
          },
        ],
      },
      status: 'fulfilled',
    },
    setSelectedDeviceData: jest.fn(),
  };

  beforeAll(() => {
    sessionStorage.setItem('refundexchange', 'false');
    sessionStorage.setItem('isSAExist', true);
    sessionStorage.setItem('isSANew', true);
    sessionStorage.setItem('isSecondNumLocal', true);

    const location = {
      ...window.location,
      search: `?activeMtn=${activeMtn}&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y&eSim=true&eId=7845678908764652347673463764`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=${activeMtn}&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y&eSim=true&eId=7845678908764652347673463764&mtn=newLine1`;
  });
  beforeEach(() => {
    render(
      <PDP
        productDetails={productDetails.data}
        protectionFeatures={protectionFeatures}
        cartDetails={cartDetails.data.data}
        customerProfileDetails={customerProfileDetails.data}
        activeMtn={activeMtn}
        selectedColor={defaultSkuDetails[0].color.displayName}
        setSelectedColor={jest.fn()}
        ispuToggleOn={false}
        setIspuToggleOn={jest.fn()}
        isShipItToggleOn={false}
        setIsShipItToggleOn={jest.fn()}
        selectedSku={defaultSkuDetails[0]}
        setSelectedSku={jest.fn()}
        selectedProtectionFeature={protectionFeatures.payload.features[1]}
        setSelectedProtectionFeature={jest.fn()}
        selectedSize={defaultSkuDetails[0].capacity}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        RemoveLinesAPIResult={RemoveLinesAPIResultWithErrorCode}
        {...props}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
    Emitter.emit('TAGGING_COMPLETED', true);
  });
  test.skip('component should render', async () => {
    fireEvent.click(
      screen.getByRole('button', {
        name: /add to cart/i,
      }),
    );
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Continue' });
    fireEvent.click(continueBtn);
  });
});
describe('PDP component render 2', () => {
  const activeMtn = '5185673926';
  const props = {
    paymentObject: { contractDuration: 36 },
    buyoutUpgradeResult: {
      data: {
        totalBuyoutAmount: '56.7',
        serviceBody: {
          serviceResponse: {
            context: {
              contextInfo: {
                processStep: 'PlanSelection',
              },
            },
          },
        },
      },
      status: 'fulfilled',
    },
    RemoveLinesAPIResult: {
      data: {
        serviceBody: {
          serviceResponse: {
            context: {
              contextInfo: {
                processStep: 'PlanSelection',
              },
            },
          },
        },
      },
      serviceBody: {},
      status: 'fulfilled',
    },
    setSelectedDeviceData: jest.fn(),
  };
  const addDeviceData = {
    data: {
      serviceBody: {
        serviceResponse: {
          context: {
            contextInfo: {
              processStep: 'PlanSelection',
            },
          },
        },
      },
    },
    serviceBody: {},
    status: 'fulfilled',
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside/flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });

  beforeAll(() => {
    sessionStorage.setItem('refundexchange', 'false');
    sessionStorage.setItem('isSAExist', true);
    sessionStorage.setItem('isSANew', true);
    sessionStorage.setItem('isSecondNumLocal', true);

    const location = {
      ...window.location,
      search: `?activeMtn=${activeMtn}&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y&eSim=true&eId=7845678908764652347673463764`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=${activeMtn}&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y&eSim=true&eId=7845678908764652347673463764&mtn=newLine1`;
  });
  beforeEach(() => {
    render(
      <PDP
        productDetails={productDetails.data}
        protectionFeatures={protectionFeatures}
        cartDetails={cartDetails.data.data}
        customerProfileDetails={customerProfileDetails.data}
        activeMtn={activeMtn}
        selectedColor={defaultSkuDetails[0].color.displayName}
        setSelectedColor={jest.fn()}
        ispuToggleOn={false}
        setIspuToggleOn={jest.fn()}
        isShipItToggleOn={false}
        setIsShipItToggleOn={jest.fn()}
        selectedSku={defaultSkuDetails[0]}
        setSelectedSku={jest.fn()}
        selectedProtectionFeature={protectionFeatures.payload.features[1]}
        setSelectedProtectionFeature={jest.fn()}
        selectedSize={defaultSkuDetails[0].capacity}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        RemoveLinesAPIResult={RemoveLinesAPIResultWithErrorCode}
        {...props}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
    Emitter.emit('TAGGING_COMPLETED', true);
  });
  test.skip('component should render', async () => {
    fireEvent.click(
      screen.getByRole('button', {
        name: /add to cart/i,
      }),
    );
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Continue' });
    fireEvent.click(continueBtn);
  });
});
