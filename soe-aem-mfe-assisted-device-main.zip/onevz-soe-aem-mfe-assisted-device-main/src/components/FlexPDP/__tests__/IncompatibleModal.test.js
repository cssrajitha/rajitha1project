import { render, screen, fireEvent, waitFor } from '../../../modules/test-utils/renderHelper';
import { CHANNELS, setupChannel } from '../../../modules/test-utils/utils';
import IneligibleDevicesModal from '../IncompatibleModal';

const INELIGIBLE_DEVICE_MODAL_PROPS = {
  setIinEligibleDevice: jest.fn(),
  onAddDeviceToCart: jest.fn(),
  onClose: jest.fn(),
  activeMtn: '7245678904',
  showModal: true,
};
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradlePropertyV2: () => ['FALSE'],
  }),
  { virtual: true },
);
jest.mock('onevzsoemfecommon/Helpers', () => ({
  getQueryParamByName: jest.fn(() => ({
    isByodUpdate: true,
  })),
  getUIContextPath: jest.fn(() => {}),
  getUIContextPathBAU: jest.fn(() => {}),
}));

const Test = (channel) => {
  setupChannel(channel);
  beforeAll(() => {
    sessionStorage.setItem('newPostToPreIndicator', false);
    sessionStorage.setItem('isCostcoAgent', true);
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  describe(`<IneligibleDevicesModal component - ${channel}`, () => {
    beforeEach(() => {
      window.mfe = { scmDeviceMfeEnable: true, isDark: true };
    });
    test('it should mount and test selected device', async () => {
      window.mfe.isDark = false;
      window.history.pushState(
        {},
        'PDP',
        '/sales/assisted/new/device/pdp.html?activeMtn=5139074854&iSscan=true&deviceSKU=MQ8R3LL/A&isLocal=true&deviceId=350321532631401&isByodUpdate=true',
      );
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({ isLandingRedesignFlow: 'TRUE', vdsUpgradationFFlag: 'TRUE' }),
      );
      render(<IneligibleDevicesModal {...INELIGIBLE_DEVICE_MODAL_PROPS} />);
      expect(screen.getByTestId('ineligibleDevicesModalupdate')).toBeInTheDocument();
      expect(screen.getByText('The selected device and offer are incompatible')).toBeInTheDocument();
      expect(screen.getByText('Continue with selected device')).toBeInTheDocument();
      expect(screen.getByText('Continue with selected offer')).toBeInTheDocument();
      expect(screen.getByText('Continue')).toBeInTheDocument();
      const radioBtn = screen.getByRole('radio', {
        name: 'selectedDevice',
      });
      await waitFor(() => fireEvent.click(radioBtn));
      const continueBtn = screen.getByRole('button', { name: 'Continue' });
      fireEvent.click(continueBtn);
    });
    test('test BYOD flow selected device', async () => {
      window.history.pushState(
        {},
        'PDP',
        '/sales/assisted/new/device/pdp.html?activeMtn=5139074854&iSscan=true&deviceSKU=MQ8R3LL/A&isLocal=true&deviceId=350321532631401&isByodUpdate=true',
      );
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({ isLandingRedesignFlow: 'TRUE', vdsUpgradationFFlag: 'TRUE' }),
      );
      render(<IneligibleDevicesModal {...INELIGIBLE_DEVICE_MODAL_PROPS} />);
      const radioBtn = await waitFor(() =>
        screen.findByRole('radio', {
          name: 'selectedOffer',
        }),
      );
      await waitFor(() => fireEvent.click(radioBtn));
      const continueBtn = screen.getByRole('button', { name: 'Continue' });
      expect(continueBtn).not.toBeDisabled();
      fireEvent.click(continueBtn);
    });
    test('it test selected Offer', async () => {
      window.history.pushState(
        {},
        'PDP',
        '/sales/assisted/new/device/pdp.html?activeMtn=5139074854&iSscan=true&deviceSKU=MQ8R3LL/A&isLocal=true&deviceId=350321532631401&isByodUpdate=true',
      );
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({ isLandingRedesignFlow: 'TRUE', vdsUpgradationFFlag: 'TRUE' }),
      );
      render(<IneligibleDevicesModal {...INELIGIBLE_DEVICE_MODAL_PROPS} />);
      const radioBtn = screen.getByRole('radio', {
        name: 'selectedOffer',
      });
      fireEvent.click(radioBtn);
      const continueBtn = screen.getByRole('button', { name: 'Continue' });
      expect(continueBtn).not.toBeDisabled();
      fireEvent.click(continueBtn);
    });
    test('close the modal popup', async () => {
      window.history.pushState(
        {},
        'PDP',
        '/sales/assisted/new/device/pdp.html?activeMtn=5139074854&iSscan=true&deviceSKU=MQ8R3LL/A&isLocal=true&deviceId=350321532631401&isByodUpdate=true',
      );
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ isLandingRedesignFlow: 'TRUE' }));
      render(<IneligibleDevicesModal {...INELIGIBLE_DEVICE_MODAL_PROPS} />);
      const closeBtn = screen.getByRole('button', { name: 'Testing Modal close' });
      fireEvent.click(closeBtn);
    });
    test('test BYOD flow selected offer for BAU', async () => {
      window.history.pushState(
        {},
        'PDP',
        '/sales/assisted/new/device/pdp.html?activeMtn=5139074854&iSscan=true&deviceSKU=MQ8R3LL/A&isLocal=true&deviceId=350321532631401&isByodUpdate=true&offerEligible=Y',
      );
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({ isLandingRedesignFlow: 'FALSE', vdsUpgradationFFlag: 'TRUE' }),
      );
      render(<IneligibleDevicesModal {...INELIGIBLE_DEVICE_MODAL_PROPS} />);
      const radioBtn = screen.getByRole('radio', {
        name: 'selectedOffer',
      });
      fireEvent.click(radioBtn);
      const continueBtn = screen.getByRole('button', { name: 'Continue' });
      expect(continueBtn).not.toBeDisabled();
      fireEvent.click(continueBtn);
    });
    test('test BYOD flow selected offer for Flex 2.0 without offer eligible BYOD update', async () => {
      window.history.pushState(
        {},
        'PDP',
        '/sales/assisted/new/device/pdp.html?activeMtn=5139074854&iSscan=true&deviceSKU=MQ8R3LL/A&isLocal=true&deviceId=350321532631401&isByodUpdate=true',
      );
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({ isLandingRedesignFlow: 'TRUE', vdsUpgradationFFlag: 'TRUE' }),
      );
      sessionStorage.setItem('isCostcoAgent', false);
      render(<IneligibleDevicesModal {...INELIGIBLE_DEVICE_MODAL_PROPS} />);
      const radioBtn = screen.getByRole('radio', {
        name: 'selectedOffer',
      });
      fireEvent.click(radioBtn);
      const continueBtn = screen.getByRole('button', { name: 'Continue' });
      expect(continueBtn).not.toBeDisabled();
      fireEvent.click(continueBtn);
    });
    test('test BYOD flow selected offer for BAU without offerEligible', async () => {
      window.history.pushState(
        {},
        'PDP',
        '/sales/assisted/new/device/pdp.html?activeMtn=5139074854&iSscan=true&deviceSKU=MQ8R3LL/A&isLocal=true&deviceId=350321532631401&isByodUpdate=true',
      );
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({ isLandingRedesignFlow: 'FALSE', vdsUpgradationFFlag: 'TRUE' }),
      );
      sessionStorage.setItem('isCostcoAgent', false);
      render(<IneligibleDevicesModal {...INELIGIBLE_DEVICE_MODAL_PROPS} />);
      const radioBtn = screen.getByRole('radio', {
        name: 'selectedOffer',
      });
      fireEvent.click(radioBtn);
      const continueBtn = screen.getByRole('button', { name: 'Continue' });
      expect(continueBtn).not.toBeDisabled();
      fireEvent.click(continueBtn);
    });
    test('test update flow selected offer for BAU without offerEligible for non BYOD', async () => {
      window.history.pushState(
        {},
        'PDP',
        '/sales/assisted/new/device/pdp.html?activeMtn=5139074854&iSscan=true&deviceSKU=MQ8R3LL/A&isLocal=true&deviceId=350321532631401',
      );
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({ isLandingRedesignFlow: 'FALSE', vdsUpgradationFFlag: 'TRUE' }),
      );
      sessionStorage.setItem('isCostcoAgent', false);
      render(<IneligibleDevicesModal {...INELIGIBLE_DEVICE_MODAL_PROPS} />);
      const radioBtn = screen.getByRole('radio', {
        name: 'selectedOffer',
      });
      fireEvent.click(radioBtn);
      const continueBtn = screen.getByRole('button', { name: 'Continue' });
      expect(continueBtn).not.toBeDisabled();
      fireEvent.click(continueBtn);
    });
  });
};

Test(CHANNELS.OMNI_RETAIL);
