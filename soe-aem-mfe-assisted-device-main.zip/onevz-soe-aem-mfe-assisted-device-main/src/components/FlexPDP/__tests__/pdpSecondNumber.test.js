import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import PDP from '../PDP';
import props from './pdpSecondNumberprops.json';
import dsdsProps from '../__mocks__/pdpDSDS.json';
import iconicServiceSkuProps from './iconicServiceSku.json';

const dispatchedActions = [];
const mockStore = {
  dispatch: (action) => {
    dispatchedActions.push(action);
  },
};

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

jest.setTimeout(50000);
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: () => ['TRUE', true, 'TRUE', 'TRUE', 'TRUE', 'TRUE'],
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => false,
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

describe('PDP component render for DFill Flow', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.setItem('isSAExist', true);
    sessionStorage.setItem('isSANew', true);
    sessionStorage.setItem('isSecondNumLocal', true);
    window.store = mockStore;
    window.vzdl = { page: {} };
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&isLocal=true&deviceId=350169643218109&simId=89148000009739425736&eSim=true&scanFromLanding=true`;
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...props}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('component should render', async () => {
    const shipIt = await screen.getByRole('button', {
      name: /Add to Cart/i,
    });
    expect(shipIt).toBeInTheDocument();
    fireEvent.click(shipIt);
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Continue' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 5000);
    });
  });
});
describe('PDP component render for DFill Flow', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.setItem('isSAExist', true);
    sessionStorage.setItem('isSANew', true);
    sessionStorage.setItem('isSecondNumLocal', true);
    window.store = mockStore;
    window.vzdl = { page: {} };
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=MTLW3LL/A&isLocal=true&deviceId=350169643218109&simId=89148000009739425736&eSim=true&scanFromLanding=true`;
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...dsdsProps}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test.skip('component should render', async () => {
    const shipIt = await screen.getByRole('button', {
      name: /Add to Cart/i,
    });
    expect(shipIt).toBeInTheDocument();
    fireEvent.click(shipIt);
    const continueBtn = await screen.getByRole('button', { name: 'Shop' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });
  test.skip('component should render', async () => {
    const shipIt = await screen.getByRole('button', {
      name: /Add to Cart/i,
    });
    expect(shipIt).toBeInTheDocument();
    fireEvent.click(shipIt);
    const continueBtn = await screen.getByRole('button', { name: 'Testing Modal close' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });
});

describe('Should add ICONIC-SERVICE-SKU to cart', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    sessionStorage.setItem('isSAExist', true);
    sessionStorage.setItem('isSANew', true);
    sessionStorage.setItem('isSecondNumLocal', true);
    server.listen();
    const location = {
      ...window.location,
      search: `?offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=ICONIC-SERVICE-SKU&isLocal=true&deviceId=350169643218109&simId=89148000009739425736&eSim=true&scanFromLanding=true&prospectByodFlow=true`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?offerEligible=Y&activeMtn=6165029774&iSscan=true&imei2=353503753775606&eSimOnlyDevice=true&deviceSKU=ICONIC-SERVICE-SKU&isLocal=true&deviceId=350169643218109&simId=89148000009739425736&eSim=true&scanFromLanding=true&prospectByodFlow=true`;
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    window.store = mockStore;
    window.vzdl = { page: {} };
    render(
      <PDP
        setSelectedColor={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...iconicServiceSkuProps}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('component should render', async () => {
    const shipIt = await screen.getByRole('button', {
      name: /Add to Cart/i,
    });
    expect(shipIt).toBeInTheDocument();
    fireEvent.click(shipIt);
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Continue' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 5000);
    });
  });
});
