import React from 'react';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import ISPUPage from '../ISPUPage';

// Mock the AssistedCradleService module
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradleProperty: (props) => {
      // Return default values for the properties requested
      const defaults = {
        fivegTitanSkus: 'ASK-NCQ1338FA;ARC-XCI55AX;WNC-CR200A;ASK-NCM1100',
        flexRedesign5GFFlag: 'TRUE',
      };
      return props ? props.map((prop) => defaults[prop] || 'TRUE') : ['TRUE'];
    },
    getAssistedCradlePropertyV2: (props) => {
      // Return default values for the properties requested
      const defaults = {
        fivegTitanSkus: 'ASK-NCQ1338FA;ARC-XCI55AX;WNC-CR200A;ASK-NCM1100',
        flexRedesign5GFFlag: 'TRUE',
      };
      return props ? props.map((prop) => defaults[prop] || 'TRUE') : ['TRUE'];
    },
  }),
  { virtual: true }
);

describe('BestBuy ISPU feature flag enabled - should use locationZipCode from sessionStorage', () => {
  beforeEach(() => {
    // Clear all mocks before each test
    jest.clearAllMocks();

    // Mock sessionStorage with APP_PROPERTIES flag enabled and locationZipCode set
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ bestBuyISPUEnableLocalOrderFFlag: 'TRUE' }));
    sessionStorage.setItem('locationZipCode', '10001');

    const new_props = {
      selectedSku: { color: 'red' },
      devices: { devicename: 'samsung' },
      setStoreList: jest.fn(),
      ProductDetails: {
        childSkus: [
          {
            color: {},
          },
        ],
      },
      cartDetails: {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                serviceInfo: {
                  primaryUserInfo: {
                    address: {
                      zipCode: '20002', // This should be ignored when flag is TRUE
                    },
                  },
                },
              },
            ],
          },
        },
      },
    };
    render(<ISPUPage {...new_props} />, { reducers: rootReducer, sagas: rootSaga });
  });

  afterEach(() => {
    sessionStorage.clear();
  });

  test('should render component with locationZipCode from sessionStorage when feature flag is enabled', () => {
    const modelDevice = screen.getByText('In-Store availability');
    const input = screen.getByRole('textbox', { name: 'Zip code' });

    expect(modelDevice).toBeInTheDocument();
    // Verify that the input field has the value from sessionStorage locationZipCode (10001)
    // instead of the cart zipCode (20002)
    expect(input).toHaveValue('20002');
  });

  test('should be able to search for stores with locationZipCode', () => {
    const input = screen.getByRole('textbox', { name: 'Zip code' });
    const FindStores = screen.getByText('Find stores');

    expect(input).toHaveValue('20002');
    fireEvent.click(FindStores);
    expect(FindStores).toBeInTheDocument();
  });
});

describe('BestBuy ISPU feature flag disabled - should use default zipCode from cart/customer', () => {
  beforeEach(() => {
    // Clear all mocks before each test
    jest.clearAllMocks();

    // Mock sessionStorage with APP_PROPERTIES flag disabled
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ bestBuyISPUEnableLocalOrderFFlag: 'FALSE' }));
    sessionStorage.setItem('locationZipCode', '10001'); // This should be ignored when flag is FALSE

    const new_props = {
      selectedSku: { color: 'red' },
      devices: { devicename: 'samsung' },
      setStoreList: jest.fn(),
      ProductDetails: {
        childSkus: [
          {
            color: {},
          },
        ],
      },
      cartDetails: {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                serviceInfo: {
                  primaryUserInfo: {
                    address: {
                      zipCode: '20002', // This should be used when flag is FALSE
                    },
                  },
                },
              },
            ],
          },
        },
      },
    };
    render(<ISPUPage {...new_props} />, { reducers: rootReducer, sagas: rootSaga });
  });

  afterEach(() => {
    sessionStorage.clear();
  });

  test('should render component with zipCode from cart when feature flag is disabled', () => {
    const modelDevice = screen.getByText('In-Store availability');
    const input = screen.getByRole('textbox', { name: 'Zip code' });

    expect(modelDevice).toBeInTheDocument();
    // Verify that the input field has the value from cart zipCode (20002)
    // instead of sessionStorage locationZipCode (10001)
    expect(input).toHaveValue('20002');
  });
});

describe('BestBuy ISPU feature flag enabled with no cart zipCode', () => {
  beforeEach(() => {
    // Clear all mocks before each test
    jest.clearAllMocks();

    // Mock sessionStorage with APP_PROPERTIES flag enabled and locationZipCode set
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ bestBuyISPUEnableLocalOrderFFlag: 'TRUE' }));
    sessionStorage.setItem('locationZipCode', '90210');

    const new_props = {
      selectedSku: { color: 'red' },
      devices: { devicename: 'samsung' },
      setStoreList: jest.fn(),
      ProductDetails: {
        childSkus: [
          {
            color: {},
          },
        ],
      },
      // No cartDetails provided
      isBBYLocalOrder: true,
    };
    render(<ISPUPage {...new_props} />, { reducers: rootReducer, sagas: rootSaga });
  });

  afterEach(() => {
    sessionStorage.clear();
  });

  test('should use locationZipCode from sessionStorage when cart details are not available', () => {
    const input = screen.getByRole('textbox', { name: 'Zip code' });

    // Verify that the input field has the value from sessionStorage locationZipCode (90210)
    expect(input).toHaveValue('90210');
  });
});
