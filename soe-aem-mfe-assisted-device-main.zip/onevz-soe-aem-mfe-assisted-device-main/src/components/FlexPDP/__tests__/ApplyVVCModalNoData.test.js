// eslint-disable-next-line max-classes-per-file
import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import ApplyVVCModal from '../ApplyVVCModal';

const dispatchedActions = [];
const mockStore = {
  dispatch: (action) => {
    dispatchedActions.push(action);
  },
};
jest.mock(
  '../../../modules/services/APIService/APIServiceHooks',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('../../../modules/services/APIService/APIServiceHooks'),
      useCreateApplicationMutation: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
            },
          ];
        }
        return [() => {}, { data: { id: '1234' } }];
      },
    };
  },
  { virtual: true },
);

describe('ApplyVVCModal model component render Prequalify', () => {
  const props = {
    vvcEligibleType: 'preQualify',
    isaacPromo: {
      proposition: {
        hasApplyOffer: true,
        propositionId: 'GC_02',
        propositionAction: 'A',
        isDirectApply: true,
        message: 'Thank you for your interest! Sign up and receive: $100 sign up bonus and more',
        rank: '1',
        offerAmount: '100',
        spoName: 'SOBTRIGGER',
        syfOfferId: '',
        soiEngagementId: '501002527',
        rewardsEnrolled: false,
        verizonDollarsBalance: '',
        customerActions: [
          {
            id: '1',
            action: 'Apply Now',
            label: 'Apply Now',
          },
        ],
        isEmployeeEligible: false,
        mtnsWithCC: '',
        offerIdFromSYF: 'false',
      },
      sessionId: '-7960663412984780097',
      stateCd: 'IL',
      mtnActivatedForMoreThanADay: true,
      tagInformation: {
        acctHashCode: 'db5ec1466180b094bbb70382aa901b1deaf67eef7e03923f45b130711bb30c6a',
        lookupMtnHashCode: '55a816c101e7b7409ae62f95b7644748c3c22e508e971a822c3d7dd3ed62a2c9',
        area: 'Midwest|IL/WI',
        zipCode: '60491',
        state: 'IL',
      },
    },
    customerProfileDetails: {
      customer: { orderLocationCode: '679', billAccounts: [{ mtns: [{ mtn: '1234' }, { mtn: '2356' }] }] },
    },
    processAddToCartNextSteps: jest.fn(),
    opened: true,
  };
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/accountlandingservice/isaac/createapplication`, (req, res, ctx) => {
      console.log('inside /accountlandingservice/isaac/createapplication');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    window.store = mockStore;
    render(<ApplyVVCModal {...props} />);
  });
  test('ApplyVVC component shoudl render', () => {
    const ApplyVVCText = screen.getByText('Save on your Verizon Bill every month.');
    expect(ApplyVVCText).toBeInTheDocument();
  });
  test('close ApplyVVC Amount Model', () => {
    const ApplyVVCText = screen.getByText('Not now');
    expect(ApplyVVCText).toBeInTheDocument();
    fireEvent.click(ApplyVVCText);
  });
  test('Select MTN ', () => {
    const selectedMdn = screen.getByTestId('selectedMdn');
    expect(selectedMdn).toBeInTheDocument();
    fireEvent.click(selectedMdn);
  });
  test('it should mount dropdown selectMdn', () => {
    const selectMdn = screen.queryByTestId('selectedMdn');
    fireEvent.change(selectMdn, { target: { value: '5854696176' } });
    fireEvent.click(screen.getByTestId('vvcSendApplication'));
  });
});
