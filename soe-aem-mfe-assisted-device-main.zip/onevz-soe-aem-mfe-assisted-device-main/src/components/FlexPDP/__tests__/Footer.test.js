import { fireEvent, render, screen, waitFor } from '../../../modules/test-utils/renderHelper';
import Footer from '../Footer';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';

jest.mock('@vds/modals', () => ({
  Modal: ({ children, opened, onCloseButtonClick, onOpenedChange, ariaLabel, surface }) =>
    opened ? (
      <div data-testid="mock-modal" data-surface={surface}>
        {children}
        <button data-testid="modal-close-btn" onClick={onCloseButtonClick}>Close</button>
      </div>
    ) : null,
  ModalTitle: ({ children }) => <div data-testid="modal-title">{children}</div>,
  ModalBody: ({ children, ...rest }) => <div data-testid="modal-body" {...rest}>{children}</div>,
}));

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradleProperty: () => [''],
    getAssistedCradlePropertyV2: () => ['TRUE','TRUE'],
  }),
  { virtual: true },
);

const renderComponent = (
  buttonLabel,
  callDeviceAddToCart,
  isCartBtnEnable,
  deviceFromCart,
  isDWOS,
  disableUpdateBtn,
  removeLines,
  isPromoEligible,
  enableBYODbtn,
  devicePricingEnabled,
  carrierLockDisableButton
) => {
  render(
    <Footer
      btnLabel={buttonLabel}
      callDeviceAddToCart={callDeviceAddToCart}
      isCartBtnEnable={isCartBtnEnable}
      deviceFromCart={deviceFromCart}
      isDWOS={isDWOS}
      disableUpdateBtn={disableUpdateBtn}
      removeLines={removeLines}
      isPromoEligible={isPromoEligible}
      enableBYODbtn={enableBYODbtn}
      devicePricingEnabled={devicePricingEnabled}
      carrierLockDisableButton={carrierLockDisableButton}
    />,
    {
      reducers: rootReducer,
      sagas: rootSaga,
    },
  );
};

const renderRfexComponent = (
  buttonLabel,
  callDeviceAddToCart,
  isCartBtnEnable,
  deviceFromCart,
  isDWOS,
  disableUpdateBtn,
  removeLines,
  isPromoEligible,
  enableBYODbtn,
  devicePricingEnabled,
) => {
  render(
    <Footer
      btnLabel={buttonLabel}
      callDeviceAddToCart={callDeviceAddToCart}
      isCartBtnEnable={isCartBtnEnable}
      deviceFromCart={deviceFromCart}
      isDWOS={isDWOS}
      disableUpdateBtn={disableUpdateBtn}
      removeLines={removeLines}
      isPromoEligible={isPromoEligible}
      enableBYODbtn={enableBYODbtn}
      incompatibleSim
      rfexMfeFlow
      devicePricingEnabled={devicePricingEnabled}
    />,
    {
      reducers: rootReducer,
      sagas: rootSaga,
    },
  );
};

describe('Samsung carrier lock flow', () => {
  beforeEach(() => {
    window.mfe = { scmDeviceMfeEnable: false, isDark: true, themeProps: { background: '#00000' } };
  });
    it("disable 'BYOD' button", () => {
    const mockCallDeviceAddToCart = jest.fn();
    const mockCallRemoveLines = jest.fn();
    renderComponent('BYOD', mockCallDeviceAddToCart, true, false, true, false, true, mockCallRemoveLines,true,true,true);
  });
});

describe('<Footer/>', () => {
  describe('button should be disabled if isCartBtnEnable is false', () => {
    beforeEach(() => {
      window.mfe = { scmDeviceMfeEnable: false, isDark: true, themeProps: { background: '#00000' } };
    });
    const mockCallDeviceAddToCart = jest.fn();
    const mockCallRemoveLines = jest.fn();
    it("should test 'Add to Cart' button should be disabled", () => {
      window.mfe.scmDeviceMfeEnable = true;
      renderComponent('Add to Cart', mockCallDeviceAddToCart, false, false, true, false, mockCallRemoveLines, false);
      expect(
        screen.getByRole('button', {
          name: /add to cart/i,
        }),
      ).toBeDisabled();
    });

    it("should test 'Ship It' button should be disabled", () => {
      window.mfe.scmDeviceMfeEnable = true;
      renderComponent('Ship It', mockCallDeviceAddToCart, false, false, true, false, mockCallRemoveLines, false);
      expect(
        screen.getByRole('button', {
          name: /Ship It/i,
        }),
      ).toBeDisabled();
    });

    it("should test 'Find Stores' button should be disabled", () => {
      renderComponent('Find Stores', mockCallDeviceAddToCart, false, false, true, false, mockCallRemoveLines, false);
      expect(
        screen.getByRole('button', {
          name: /Find Stores/i,
        }),
      ).toBeDisabled();
    });
  });
  describe('button click should call the function', () => {
    beforeEach(() => {
      window.mfe = { scmDeviceMfeEnable: false, isDark: true, themeProps: { background: '#00000' } };
    });
    it("should test function should be called on clicking the 'Add to Cart' button", () => {
      const mockCallDeviceAddToCart = jest.fn();
      const mockCallRemoveLines = jest.fn();
      renderComponent('Add to Cart', mockCallDeviceAddToCart, true, false, true, false, mockCallRemoveLines, true);
      fireEvent.click(
        screen.getByRole('button', {
          name: /add to cart/i,
        }),
      );
      expect(mockCallDeviceAddToCart).toBeCalled();
    });

    it("should test function should be called on clicking the 'Ship It' button", () => {
      const mockCallDeviceAddToCart = jest.fn();
      const mockCallRemoveLines = jest.fn();
      renderComponent('Ship It', mockCallDeviceAddToCart, true, false, true, false, mockCallRemoveLines, false);
      fireEvent.click(
        screen.getByRole('button', {
          name: /Ship It/i,
        }),
      );
      expect(mockCallDeviceAddToCart).toBeCalledTimes(0);
    });

    it("should test 'Find Stores' button should be disabled in dark theme ", () => {
      const mockCallDeviceAddToCart = jest.fn();
      const mockCallRemoveLines = jest.fn();
      renderComponent('Find Stores', mockCallDeviceAddToCart, false, false, true, false, mockCallRemoveLines, false);
      expect(
        screen.getByRole('button', {
          name: /Find Stores/i,
        }),
      ).toBeDisabled();
    });

    it("should test function should be called on clicking the 'BYOD' button", () => {
      const mockCallDeviceAddToCart = jest.fn();
      const mockCallRemoveLines = jest.fn();
      renderComponent('BYOD', mockCallDeviceAddToCart, true, false, true, false, true, mockCallRemoveLines);
      fireEvent.click(
        screen.getByRole('button', {
          name: /BYOD/i,
        }),
      );
      expect(mockCallDeviceAddToCart).toBeCalledTimes(0);
    });

    describe('button click should call the function', () => {
      it("should test function should be called on clicking the 'Remove' button", () => {
        const mockCallDeviceAddToCart = jest.fn();
        const mockCallRemoveLines = jest.fn();
        renderComponent('Add to Cart', mockCallDeviceAddToCart, true, true, false, mockCallRemoveLines, false);
        fireEvent.click(
          screen.getByRole('button', {
            name: /Remove/i,
          }),
        );
      });
    });
  });
  describe('button click should call the function', () => {
    beforeEach(() => {
      window.mfe = { scmDeviceMfeEnable: false, isDark: false, themeProps: { background: '#00000' } };
    });

    it("should test function should be called on clicking the 'BYOD' button", () => {
      const mockCallDeviceAddToCart = jest.fn();
      const mockCallRemoveLines = jest.fn();
      renderComponent('BYOD', mockCallDeviceAddToCart, true, false, true, false, true, mockCallRemoveLines);
      fireEvent.click(
        screen.getByRole('button', {
          name: /BYOD/i,
        }),
      );
      expect(mockCallDeviceAddToCart).toBeCalledTimes(0);
    });

    describe('button click should call the function', () => {
      it("should test function should be called on clicking the 'Remove' button", () => {
        const mockCallDeviceAddToCart = jest.fn();
        const mockCallRemoveLines = jest.fn();
        renderComponent('Add to Cart', mockCallDeviceAddToCart, true, true, false, mockCallRemoveLines, false);
        fireEvent.click(
          screen.getByRole('button', {
            name: /Remove/i,
          }),
        );
      });
    });
  });
  describe('button click should call the function', () => {
    beforeEach(() => {
      window.mfe = { scmDeviceMfeEnable: false, isDark: true, themeProps: { background: '#00000' } };
    });

    it("should test function should be called on clicking the 'BYOD' button", () => {
      const mockCallDeviceAddToCart = jest.fn();
      const mockCallRemoveLines = jest.fn();
      renderComponent('BYOD', mockCallDeviceAddToCart, true, false, true, false, true, mockCallRemoveLines);
      fireEvent.click(
        screen.getByRole('button', {
          name: /BYOD/i,
        }),
      );
      expect(mockCallDeviceAddToCart).toBeCalledTimes(0);
    });
    it("should test function should 'BYOD' for byod rfex flow and BYOD should be disabled for incompatible sim", () => {
      const mockCallDeviceAddToCart = jest.fn();
      const mockCallRemoveLines = jest.fn();
      renderRfexComponent('BYOD', mockCallDeviceAddToCart, true, false, true, false, true, mockCallRemoveLines, true);
      // fireEvent.click(
      const byodRfexBtn = screen.getByRole('button', {
        name: /BYOD/i,
      });
      // );
      expect(byodRfexBtn).toBeDisabled();
    });
    describe('button click should call the function', () => {
      it("should test function should be called on clicking the 'Remove' button", () => {
        const mockCallDeviceAddToCart = jest.fn();
        const mockCallRemoveLines = jest.fn();
        renderComponent('Add to Cart', mockCallDeviceAddToCart, true, true, false, mockCallRemoveLines, false);
        fireEvent.click(
          screen.getByRole('button', {
            name: /Remove/i,
          }),
        );
      });
    });
  });
  describe('test second number dfill', () => {
    beforeEach(() => {
      sessionStorage.setItem('isSecondNumDfill', true);
    });
    const mockCallDeviceAddToCart = jest.fn();
    const mockCallRemoveLines = jest.fn();

    it("should test 'Find Stores' button should be disabled", () => {
      renderComponent('Find Stores', mockCallDeviceAddToCart, false, false, true, false, mockCallRemoveLines, false);
      expect(
        screen.getByRole('button', {
          name: /Find Stores/i,
        }),
      ).toBeDisabled();
    });
  });
  
  it("should disable 'Update' button when isPastBalAndBackOrder is true", () => {
    const mockCallDeviceAddToCart = jest.fn();
    const mockCallRemoveLines = jest.fn();
    // Mock getAssistedCradleProperty to return ['TRUE', true] for isBackOrderPastDueCheckFFlag
   // jest.spyOn(require('onevzsoemfeframework/AssistedCradleService'), 'getAssistedCradlePropertyV2').mockReturnValue(['TRUE', 'TRUE']);
    // Set up props to trigger isPastBalAndBackOrder
    render(
      <Footer
        btnLabel="Add to Cart"
        callDeviceAddToCart={mockCallDeviceAddToCart}
        isCartBtnEnable={true}
        deviceFromCart={true}
        isDWOS={false}
        disableUpdateBtn={false}
        removeLines={mockCallRemoveLines}
        isPromoEligible={true}
        enableBYODbtn={true}
        devicePricingEnabled={false}
        carrierLockDisableButton={false}
        isShipItToggleOn={true}
        isPastbalBackOrderWithDueAmount={true}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      }
    );
    expect(screen.getByRole('button', { name: /Update/i })).toBeDisabled();
  });

  it("should show confirmation modal when isSelectedDeviceByod is true, close on close button click, and call handleAddDeviceCall on OK click", async () => {
    sessionStorage.clear();
    window.mfe = { scmDeviceMfeEnable: false, isDark: false, themeProps: { background: '#00000' } };
    const mockCallDeviceAddToCart = jest.fn();
    const mockCallRemoveLines = jest.fn();
    render(
      <Footer
        btnLabel="Add to Cart"
        callDeviceAddToCart={mockCallDeviceAddToCart}
        isCartBtnEnable={true}
        deviceFromCart={false}
        isDWOS={true}
        disableUpdateBtn={false}
        removeLines={mockCallRemoveLines}
        isPromoEligible={true}
        enableBYODbtn={true}
        devicePricingEnabled={false}
        carrierLockDisableButton={false}
        isSelectedDeviceByod={true}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      }
    );
    // Click the Add to Cart button which should trigger handleDeviceCall and show the modal
    fireEvent.click(screen.getByRole('button', { name: /add to cart/i }));
    // Verify the confirmation modal is displayed with light surface (isDark is false)
    await waitFor(() => {
      expect(screen.getByText('Confirm phone upgrade')).toBeInTheDocument();
    });
    expect(screen.getByText(/By upgrading the device, the customers BYOD\+ discount will be removed and cannot be readded./i)).toBeInTheDocument();
    // Test close button functionality - click close button to dismiss modal (covers onCloseButtonClick)
    const closeButton = screen.getByRole('button', { name: /close/i });
    fireEvent.click(closeButton);
    // Verify modal is closed
    await waitFor(() => {
      expect(screen.queryByText('Confirm phone upgrade')).not.toBeInTheDocument();
    });
    // Re-open the modal by clicking Add to Cart again
    fireEvent.click(screen.getByRole('button', { name: /add to cart/i }));
    await waitFor(() => {
      expect(screen.getByText('Confirm phone upgrade')).toBeInTheDocument();
    });
    // Click the OK button to confirm and trigger handleModalOk
    fireEvent.click(screen.getByRole('button', { name: /OK/i }));
    // Verify that callDeviceAddToCart was called after clicking OK (covers handleModalOk -> handleAddDeviceCall)
    await waitFor(() => {
      expect(mockCallDeviceAddToCart).toHaveBeenCalled();
    });
  });

  it("should show confirmation modal with dark surface and cover onCloseButtonClick when isDark is true", async () => {
    sessionStorage.clear();
    window.mfe = { scmDeviceMfeEnable: true, isDark: true, themeProps: { background: '#00000' } };
    const mockCallDeviceAddToCart = jest.fn();
    const mockCallRemoveLines = jest.fn();
    render(
      <Footer
        btnLabel="Add to Cart"
        callDeviceAddToCart={mockCallDeviceAddToCart}
        isCartBtnEnable={true}
        deviceFromCart={false}
        isDWOS={true}
        disableUpdateBtn={false}
        removeLines={mockCallRemoveLines}
        isPromoEligible={true}
        enableBYODbtn={true}
        devicePricingEnabled={false}
        carrierLockDisableButton={false}
        isSelectedDeviceByod={true}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      }
    );
    // Click Add to Cart to trigger handleDeviceCall -> setShowConfirmationModal(true)
    fireEvent.click(screen.getByRole('button', { name: /add to cart/i }));
    // Verify modal is displayed with dark surface
    await waitFor(() => {
      expect(screen.getByText('Confirm phone upgrade')).toBeInTheDocument();
    });
    // Cover onCloseButtonClick={() => setShowConfirmationModal(false)}
    const closeButton = screen.getByRole('button', { name: /close/i });
    fireEvent.click(closeButton);
    // Verify modal is dismissed after close button click
    await waitFor(() => {
      expect(screen.queryByText('Confirm phone upgrade')).not.toBeInTheDocument();
    });
  });

  it("should call setSecondNumberWarningModal when checkSecondNumberFlag is true", () => {
    sessionStorage.clear();
    window.mfe = { scmDeviceMfeEnable: false, isDark: false, themeProps: { background: '#00000' } };
    const mockCallDeviceAddToCart = jest.fn();
    const mockCallRemoveLines = jest.fn();
    const mockSetSecondNumberWarningModal = jest.fn();
    render(
      <Footer
        btnLabel="Add to Cart"
        callDeviceAddToCart={mockCallDeviceAddToCart}
        isCartBtnEnable={true}
        deviceFromCart={false}
        isDWOS={true}
        disableUpdateBtn={false}
        removeLines={mockCallRemoveLines}
        isPromoEligible={true}
        enableBYODbtn={true}
        devicePricingEnabled={false}
        carrierLockDisableButton={false}
        isSelectedDeviceByod={true}
        checkSecondNumberFlag={true}
        setSecondNumberWarningModal={mockSetSecondNumberWarningModal}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      }
    );
    // Click button to trigger handleModal
    fireEvent.click(screen.getByRole('button', { name: /add to cart/i }));
    // Verify setSecondNumberWarningModal was called
    expect(mockSetSecondNumberWarningModal).toHaveBeenCalledWith(true);
  });
});