import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import Header from '../Header';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradleProperty: () => ['TRUE'],
  }),
  { virtual: true },
);
jest.mock('onevzsoemfeframework/DomService', () => ({
  getQueryParamByName: (value) => {
    if (value === 'isByodUpdate') return 'false';
    if (value === 'fromPage') return 'OtherPage';
    if (value === 'isDWOS') return true;
  },
  isIndirect: () => true,
  isIpad: () => false,
}));
jest.mock(
  'onevzsoemfecommon/Helpers',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getUIContextPath: jest.fn(() => {}),
    getUIContextPathBAU: jest.fn(() => {}),
    capitalizeFirstLetter: jest.fn(() => {}),
    formatMtnForNewLine: jest.fn(() => {}),
    isNumeric: jest.fn(() => {}),
    getQueryParamByName: jest.fn(() => ({
      isByodUpdate: true,
    })),
  }),
  { virtual: true },
);

describe('Header Component for BYOD flow', () => {
  const props = {
    data: {
      header: 'Header',
      line: 'Line',
      mdn: '1234567890',
      closeIcon: { popupModalclose: true },
      closeClickHandler: undefined,
      moreOptionClickHandler: jest.fn(),
    },
    computeDPPriceBody: jest.fn(),
    computeDPPriceResult: jest.fn(),
    isDownPaymentAlertNeedToEnable: false,
    setIsDownPaymentAlertNeedToEnable: jest.fn(),
  };

  beforeEach(() => {
    // Mock getQueryParamByName to return specific values
    window.mfe = {};
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/product-detail.html?activeMtn=5139074854&deviceSKU=MQ8R3LL/A&isByodUpdate=true&deviceId=350321532631401',
    );
  });
  test('should test navigate is called with -1 parameter on left caret click', () => {
    jest.mock('onevzsoemfeframework/DomService', () => ({
      getQueryParamByName: (value) => {
        if (value === 'isByodUpdate') return 'false';
        if (value === 'fromPage') return 'OtherPage';
      },
    }));
    jest.mock(
      'onevzsoemfecommon/Helpers',
      () => ({
        __esModule: true,
        default: jest.fn(() => ({})),
        getUIContextPath: jest.fn(() => {}),
        getUIContextPathBAU: jest.fn(() => {}),
        capitalizeFirstLetter: jest.fn(() => {}),
        formatMtnForNewLine: jest.fn(() => {}),
        isNumeric: jest.fn(() => {}),
        getQueryParamByName: jest.fn(() => ({
          isByodUpdate: true,
        })),
      }),
      { virtual: true },
    );
    window.mfe.scmDeviceMfeEnable = false;

    render(<Header {...props} />, { reducers: rootReducer, sagas: rootSaga });
    const mockNavigate = jest.fn();
    jest.mock('react-router-dom', () => ({ useNavigate: () => mockNavigate }));
    const testBackGridwall = screen.getByTestId('testBackGridwall');
    fireEvent.click(testBackGridwall);
  });
  test('should test navigate is called with -1 parameter on left caret click', () => {
    window.mfe.scmDeviceMfeEnable = false;

    render(<Header {...props} />, { reducers: rootReducer, sagas: rootSaga });
    const mockNavigate = jest.fn();
    jest.mock('react-router-dom', () => ({ useNavigate: () => mockNavigate }));
    const testBackGridwall = screen.getByTestId('testBackGridwall');
    fireEvent.click(testBackGridwall);
  });
});
