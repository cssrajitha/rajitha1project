import React from 'react';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import Footer from '../Footer';

describe('device model component render', () => {
  beforeEach(() => {
    render(
      <Footer
        btnLabel="Add to Cart"
        deviceFromCart={false}
        isCartBtnEnable
        checkSecondNumberFlag
        setSecondNumberWarningModal={jest.fn()}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('component should render', () => {
    fireEvent.click(
      screen.getByRole('button', {
        name: /add to cart/i,
      }),
    );
  });
});
