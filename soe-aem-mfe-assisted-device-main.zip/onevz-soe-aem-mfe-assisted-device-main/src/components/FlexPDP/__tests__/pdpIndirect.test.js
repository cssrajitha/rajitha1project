import React from 'react';
import { setupServer } from 'msw/node';
import Emitter from 'onevzsoemfeframework/Emitter';
import { rest } from 'msw';
import { cloneDeep } from 'lodash';
import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import PDP from '../PDP';
import propsIndirect from './pdpIndirectProps.json';
import IndirectPaymentOptions from '../indirectPaymentOptions';

const localOrderIndirectProps = cloneDeep(propsIndirect);
localOrderIndirectProps.cartDetails.cart.orderDetails.orderDepletionType = 'L';
const newLIneProps = cloneDeep(propsIndirect);
newLIneProps.cartDetails.cart.lineDetails.lineInfo = [{ lineActivityType: 'AAL', mobileNumber: '9102798662' }];

const dispatchedActions = [];
const mockStore = {
  dispatch: (action) => {
    dispatchedActions.push(action);
  },
};
jest.setTimeout(50000);
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: () => [
      'FALSE',
      'TRUE',
      'FALSE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
    ],
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    getClientAppName: () => 'ATG-RTL-NETACE',
    noOfDaysLeftInBillCycle: () => 12,
    isIpad: () => true,
    isRetail: () => false,
    isAsurion: () => false,
    isIndirect: () => true,
    executeShellFunction: jest.fn(),
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

describe('PDP component for indirect DFILL Flow', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.setItem('channel', 'indirect');
    window.store = mockStore;
    window.vzdl = { page: {} };
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?offerEligible=Y&activeMtn=9102798662&productId=dev21410695&defaultSku=MTXW3LL/A`;
    render(
      <PDP
        setSelectedColor={jest.fn()}
        selectedPaymentInfo={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...propsIndirect}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });

  test('Should render 3 payment options in UI ', async () => {
    expect(screen.getByText('Month To Month')).toBeInTheDocument();
    expect(screen.getByText('36 mo Device Payment')).toBeInTheDocument();
    expect(screen.getByText('Two Years Payment')).toBeInTheDocument();

    const monthToMonthPaymentOption = screen.getAllByRole('radio', {
      name: 'Month To Month',
    });
    expect(monthToMonthPaymentOption[0]).not.toBeChecked();
    fireEvent.click(monthToMonthPaymentOption[0]);
    expect(monthToMonthPaymentOption[0]).toBeChecked();

    const installmentMonth36 = screen.getAllByRole('radio', {
      name: '36 mo Device Payment',
    });
    expect(installmentMonth36[0]).not.toBeChecked();
    fireEvent.click(installmentMonth36[0]);
    expect(installmentMonth36[0]).toBeChecked();

    const twoYearsPaymentRadio = screen.getAllByRole('radio', {
      name: 'Two Years Payment',
    });
    expect(twoYearsPaymentRadio[0]).not.toBeChecked();
    fireEvent.click(twoYearsPaymentRadio[0]);
    expect(twoYearsPaymentRadio[0]).toBeChecked();
  });
});

describe('PDP component for indirect - indirectCashOnlyCustomer', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    window.store = mockStore;
    window.vzdl = { page: {} };
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?offerEligible=Y&activeMtn=9102798662&productId=dev21410695&defaultSku=MTXW3LL/A`;
    const cashOnlyFlowProps = cloneDeep(propsIndirect);
    cashOnlyFlowProps.customerProfileDetails.customer.billAccounts[0].accountAttributes.isCashOnly = true;
    cashOnlyFlowProps.customerProfileDetails.customer.billAccounts[0].accountAttributes.isCashOnlyExceptCO = true;
    cashOnlyFlowProps.productDetails.commonInfo.dpEligible = false;
    render(
      <PDP
        setSelectedColor={jest.fn()}
        selectedPaymentInfo={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...cashOnlyFlowProps}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('It should display Ship It button for Dfill order', async () => {
    const addToCartBtn = await screen.getByRole('button', {
      name: /Ship it/i,
    });
    expect(addToCartBtn).toBeInTheDocument();
  });

  test('Should render 2 payment options in UI ', async () => {
    expect(screen.getByText('Month To Month')).toBeInTheDocument();
    expect(screen.getByText('Two Years Payment')).toBeInTheDocument();

    const monthToMonthPaymentOption = screen.getAllByRole('radio', {
      name: 'Month To Month',
    });
    expect(monthToMonthPaymentOption[0]).not.toBeChecked();
    fireEvent.click(monthToMonthPaymentOption[0]);
    expect(monthToMonthPaymentOption[0]).toBeChecked();

    const twoYearsPaymentRadio = screen.getAllByRole('radio', {
      name: 'Two Years Payment',
    });
    expect(twoYearsPaymentRadio[0]).not.toBeChecked();
    fireEvent.click(twoYearsPaymentRadio[0]);
    expect(twoYearsPaymentRadio[0]).toBeChecked();
  });
});

describe('PDP component for indirect condition', () => {
  const directProps = {
    showDPOptions: true,
    isIndirect: true,
    isBYODUpg: false,
    isBYODAAL: false,
    deviceFromCart: false,
    customerProfileDetails: {},
    selectedPaymentInfo: {
      contractType: 'DEVICE_PAYMENT',
      price: 23.05,
      term: 36,
      paymentType: '',
    },
    productDetails: {
      deviceProduct: {
        brandName: 'Apple',
        defaultSKU: 'MYAT3LL/A',
        isSecondNumEligible: true,
        description:
          'iPhone 16. Built for Apple Intelligence.<sup>1</sup> Featuring Camera Control. 48MP Fusion camera. Five vibrant colors. And A18 chip.',
        isFreeOverNightShipping: false,
        isComingSoon: false,
        parentCategories: ['cat180001', 'cat10066', 'cat180004'],
        productId: 'dev21412086',
        productDisplayName: 'iPhone 16',
        rating: {
          numberOfReviews: null,
          averageRating: null,
          productId: null,
          batteryLife: null,
          callQuality: null,
          design: null,
          display: null,
          easeOfUse: null,
          features: null,
          percentRecommended: null,
          performance: null,
        },
        seo: {
          h1Tag: 'Apple iPhone 16',
          canonicalUrl: 'smartphones/apple-iphone-16/',
          metaDescription:
            'New Apple iPhone 16, available for preorder today at Verizon. Find information on pricing, colors, features and more.',
          metaTitle: 'Preorder New iPhone 16: Colors, Price, Specs | Verizon',
          metaRobotsIndex: '1001',
          metaRobotsFollow: '1',
          seoUrlName: 'apple-iphone-16',
        },
        customerAttributes: {
          establishedDate: '06/17/2006',
          customerType: 'PE',
          digitalCustomerType: 'B2C',
          firstName: 'RAVI',
          lastName: 'JACOBS',
          zipCode: '37824',
          zipCodePlus4: '0963',
          inWithVerizonInd: 'N',
          state: 'TN',
          hashedAccountNumber: 'de9f453b0f945716f09d3e2b6cc0cb22792bd8deb31007a0ddea51d1f000e3ca',
          mtnList: [Array],
          loggedInMtn: 'MASTRAL',
          lineDetails: [Array],
        },
        blockCTA: false,
        isDsdsCapable: true,
        additionalDisclosures:
          '<ol><li>Apple Intelligence will be available in beta on all iPhone 16 models, iPhone 15 Pro, and iPhone 15 Pro Max, with Siri and device language set to U.S. English, as an iOS 18 update in Fall 2024. Some features and additional languages will be coming over the course of the next year.</li>\n' +
          '<li>Battery life varies by use and configuration. See <a href="http://apple.com/batteries" target="_blank">apple.com/batteries</a> for more information.</li>\n' +
          '<li>Accessories sold separately.</li>\n' +
          '<li>The displays have rounded corners. When measured as a rectangle, the screen is 6.12 inches (iPhone 16), 6.69 inches (iPhone 16 Plus), 6.27 inches (iPhone 16 Pro) or 6.86 inches (iPhone Pro Max) diagonally. Actual viewable area is less.</li>\n' +
          '<li>Some features may not be available for all countries or all areas.</li>\n' +
          '<li>Service is included for free for two years with the activation of any iPhone 16 model. Connection and response times vary based on location, site conditions, and other factors. See <a href="https://support.apple.com/kb/HT213885 "target="_blank">https://support.apple.com/kb/HT213885</a> for more information.</li>\n' +
          '<li>iPhone 16 and iPhone 16 Pro can detect a severe car crash and call for help. Requires a cellular connection or Wi-Fi calling.</li>\n' +
          '</ol>',
        compatibleSimSorIds: [
          'UNIVESIM5G-SA-S',
          'UNIVESIM5G-SA-A',
          'UNIVESIM5G-SAB-A',
          'UNIVESIM5G-SAB-S',
          'UNIVESIM5G-SAB-D',
          'UNIVESIM5G-SA-D',
        ],
        deviceUnlockPolicy: {
          textId: '11500001',
          textName: 'DEVICE_UNLOCK_POLICY',
          description: null,
          text: '<p><strong>Device Unlocking Policies</strong></p>\r\r<p>In order to mitigate theft and other fraudulent activity, newly purchased devices are\r"u201Clockedu201D" to work exclusively on the Verizon network. We have separate device\runlocking policies that cover postpay and prepaid devices, as well as special rules for\rdeployed military personnel.</p>\r \r\r\r<p>"u201CUnlockingu201D" a device refers only to disabling software that would prevent a consumer\rfrom attempting to activate a device designed for one carrieru2019s network. Due to differing technologies, an unlocked Verizon Wireless device\rmay not work u2013 or may experience limited functionality u2013 on another carrieru2019s network.</p>\r\r \r\r<p><strong>Postpay Device Unlocking Policy</strong></p>\r\r\r\r<p>Devices that you purchase from Verizon are locked for 60 days after purchase. Devices that you purchase from our retail partners are locked for 60 days after activation.After 60 days, we will automatically remove the lock. Following the 60 day lock period, we do not lock our phones at any time.</p>\r\r\r\r\r<p><strong>Prepaid Device Unlocking Policy</strong></p>\r\r\r<p>Devices that you purchase from Verizon and certain devices purchased from our retail partners are locked for 60 days after activation. After 60 days, we will automatically remove the lock. Following the 60 day lock period following device purchase, we do not lock our phones at any time.</p>\r\r<p>If you purchase a 4G Phone&ndash;in&ndash;a&ndash;Box from our retail partners, you should review the back of the box to determine the lock period applicable to that device.</p>\r\r<p><strong>Unlocking Policy for Deployed Military Personnel</strong></p>\r\r<p>If you are a Verizon Wireless customer in the military and receive relocation orders outside of the Verizon Coverage Area, we will unlock your device at your request, even during the 60&ndash;day&ndash;lock period following the purchase of your device.</p>\r\r<p>Effective Date: July 23, 2019</p>',
          applicationFlag: true,
          url: null,
          urlAvailableFlag: false,
          newBrowserFlag: null,
          textType: 'GlobalText',
          displayB2cFlag: true,
          sequenceOrder: null,
          textVersion: null,
          wmsLabel: null,
          currentVersion: 1,
        },
        daccId: '02294',
        deviceType: 300202,
        hasDeviceUnlockPolicy: true,
        includedAccessories:
          '<ul class="details-list"><li>iPhone with iOS 18</li>\n' +
          '<li>USB-C Charge Cable (1 m)</li>\n' +
          '<li>Documentation</li>\n' +
          '</ul>',
        isAnySkuInStock: false,
        isAllSkusOutofStock: false,
        isCPO: false,
        isE911Address: false,
        isNumberShareCapable: false,
        isNumberShareMandatory: false,
        isSupportOnly: false,
        operatingSystem: 'Apple iOS',
        startDate: {
          date: '09-13-2024',
          dateTime: '09-13-2024 07:58:00 AM',
          dateLong: 1726228680000,
        },
        sorDeviceCategory: '5G Smartphone',
        specifications: {
          battery: null,
          depth: 0.31,
          height: 5.81,
          screenSize: '6.1"',
          size: '5.81,2.82,0.31',
          weight: 6,
          width: 2.82,
        },
        techSpecs: {
          'Video Playback':
            'Video playback : Up to 22 hours, Video playback (streamed) : Up to 18 hours, Audio playback : Up to 80 hours',
          Overall: 'Accessibility Shortcut, Siri, Guided Access, Per App Setting',
          'Wi-fi': 'Yes',
          Screen:
            'Super Retina XDR display | 6.1‑inch (diagonal) all‑screen OLED display | 2556‑by‑1179-pixel resolution at 460 ppi',
          Mobility: 'Voice Control, Switch Control, AssistiveTouch, Back Tap',
          'World Device': 'Works in over 200 countries depending on your plan',
          Depth: '0.31 inch',
          Auditory: 'Made for iPhone hearing devices, Sound Recognition, Headphone Accommodations, Live Captions',
          'Voice Assistant': 'Siri',
          '5G Nationwide':
            'FDD-5G NR (Bands n1, n2, n3, n5, n7, n8, n12, n14, n20, n25, n26, n28, n29, n30, n66, n70, n71, n75, n76) | TDD-5G NR (Bands n38, n40, n41, n48, n53, n77, n78, n79)',
          'Operating System': 'iOS 18',
          Height: '5.81 inches',
          Width: '2.82 inches',
          Visual: 'VoiceOver, Zoom, Color Filters, Spoken Content',
          'Camera Mode':
            'Photonic Engine;Portrait Lighting with six effects;Night mode;Panorama (up to 63MP);Spatial photos;Macro photography;Lens correction (Ultra Wide);Advanced red‑eye correction;Auto image stabilization;Burst mode;Photo geotagging;Image formats captured: HEIF and JPEG',
          Charging:
            'Up to 50% charge in around 30 minutes with 20W adapter or higher paired with USB-C charging cable, or  30W adapter or higher paired with MagSafe Charger (all available separately)',
          'Front Camera':
            '12MP camera;ƒ/1.9 aperture;Autofocus with Focus Pixels;Retina Flash;Deep Fusion;Smart HDR 5;Next-generation portraits with Focus and Depth Control;Portrait Lighting with six effects;Animoji and Memoji;Latest-generation Photographic Styles;Wide color capture for photos and Live Photos;Lens correction',
          '5G Ultra Wide-Band': '5G NR mmWave (Bands n258, n260, n261)',
          'Hearing Aid Compatibility': 'M3/T4',
          Weight: '6.00 ounces (170 grams)',
          Type: 'Built-in rechargeable lithium-ion battery',
          Storage: '128 GB, 256GB, 512GB (Subject to availability)',
          Colors: 'Black, White, Pink, Teal, Ultramarine',
          'Usage Time': 'Audio playback : Up to 80 hours',
          'Rear Camera':
            '48MP Fusion: 26 mm, ƒ/1.6 aperture, sensor‑shift optical image stabilization, 100% Focus Pixels, support for super-high-resolution photos (24MP and 48MP)',
          'Global & Roaming Network':
            'FDD-LTE (Bands 1, 2, 3, 4, 5, 7, 8, 12, 13, 14, 17, 18, 19, 20, 25, 26, 28, 29, 30, 32, 66, 71) | TDD-LTE (Bands 34, 38, 39, 40, 41, 42, 48, 53) | UMTS/HSPA+/DC-HSDPA (850, 900, 1700/2100, 1900, 2100 MHz) | GSM/EDGE (850, 900, 1800, 1900 MHz)',
          'Video Recording':
            '4K Dolby Vision video recording at 24 fps, 25 fps, 30 fps, or 60 fps | 1080p Dolby Vision video recording at 25 fps, 30 fps, or 60 fps | 720p Dolby Vision video recording at 30 fps',
        },
        categoryDisplayNames: ['GnG Devices', 'Smartphones', 'Postpaid Devices'],
        isIconicPhone: true,
        unlockDevicePDP: false,
        emergencyCLNR: true,
        cannotBeUpgraded: false,
        hostDeviceInCompatible: false,
        sorDeviceType: '5GE',
        ccod: null,
        favoriteId: null,
        inFavorite: false,
        wishListCount: 0,
        imageName: 'apple-iphone-16-ultramarine',
        imageUrlMap: {
          defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-16-ultramarine',
          largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-16-ultramarine?$device-lg$',
          mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-16-ultramarine?$device-med$',
          miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-16-ultramarine?$device-mini$',
          thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-16-ultramarine?$device-thumb$',
          imageSetUrl:
            'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/apple-iphone-16-ultramarine_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
        },
        deviceRestricted: false,
        skuRestrictions: { restrictionMessages: [], isAllSkusRestricted: false },
        productSpecification: null,
        notSellableSkus: ['3N390LL/A', '3N388LL/A', '3N386LL/A', '3N389LL/A', '3N387LL/A'],
        deviceLowestPrice: null,
        deviceHighestPrice: null,
        isDefaultPlanEligible: false,
        isInstorePickupRestricted: false,
        modPdp: false,
      },
      commonInfo: {
        showPrice: false,
        displayReasonCode: false,
        showShipitToggle: true,
        flexPDPTradeInLinkEnabled: true,
        containSoftSku: false,
        dpEligible: true,
        indirect: true,
      },
      accountInfo: {
        lastName: 'JACOBS',
        zipCode: '37824',
        myOfferAccepted: null,
        nickName: null,
        safeTechSessionId: '030a4501b24a480f93a9843a',
        processingMTN: null,
        accountEupDeviceType: null,
        zipCodePlus4: '0963',
        selectedOfferFlows: null,
        buyoutDisplay: 'False',
        estTradeInValue: null,
        firstName: 'RAVI',
        intentType: null,
        preOrderMTNEnable: 'false',
        custType: 'B2C',
        btaEligible: 'false',
        state: 'TN',
      },
      fiveGMobilityInfo: {
        fiveGToFourGOverlay: false,
        fiveGHomeRequired: false,
        fiveGUpSell: false,
      },
      catDL: null,
      getDeviceTradeStatus: { promoExists: false, bogoOffer: false },
      showReturnTab: false,
      enablePromoChoiceExp: false,
    },
    selectedPaymentType: {
      contractDuration: 36,
    },
    setSelectedPaymentInfo: jest.fn(),
    selectedSku: {
      price: {
        devicePaymentPrice: [
          {
            contractDuration: 36,
          },
        ],
      },
    },
  };
  beforeEach(() => {
    render(<IndirectPaymentOptions {...directProps} />);
  });

  test('conponent should render', () => {
    const radio = screen.getByRole('radio', { name: '36 mo Device Payment' });
    expect(radio).toBeInTheDocument();
  });
});

describe('PDP component for indirect condition for cash only flow', () => {
  const directProps = {
    isIndirect: true,
    isBYODUpg: false,
    isBYODAAL: false,
    deviceFromCart: true,
    customerProfileDetails: {
      customer: {
        billAccounts: [
          {
            accountAttributes: {
              isCashOnly: true,
              isCashOnlyExceptCO: true,
            },
          },
        ],
      },
    },
    selectedPaymentInfo: {
      contractType: 'MONTH_TO_MONTH',
      price: 23.05,
      term: 36,
      paymentType: '',
    },
    productDetails: {
      deviceProduct: {
        brandName: 'Apple',
        defaultSKU: 'MYAT3LL/A',
        isSecondNumEligible: true,
        description:
          'iPhone 16. Built for Apple Intelligence.<sup>1</sup> Featuring Camera Control. 48MP Fusion camera. Five vibrant colors. And A18 chip.',
        isFreeOverNightShipping: false,
        isComingSoon: false,
        parentCategories: ['cat180001', 'cat10066', 'cat180004'],
        productId: 'dev21412086',
        productDisplayName: 'iPhone 16',
        rating: {
          numberOfReviews: null,
          averageRating: null,
          productId: null,
          batteryLife: null,
          callQuality: null,
          design: null,
          display: null,
          easeOfUse: null,
          features: null,
          percentRecommended: null,
          performance: null,
        },
        seo: {
          h1Tag: 'Apple iPhone 16',
          canonicalUrl: 'smartphones/apple-iphone-16/',
          metaDescription:
            'New Apple iPhone 16, available for preorder today at Verizon. Find information on pricing, colors, features and more.',
          metaTitle: 'Preorder New iPhone 16: Colors, Price, Specs | Verizon',
          metaRobotsIndex: '1001',
          metaRobotsFollow: '1',
          seoUrlName: 'apple-iphone-16',
        },
        customerAttributes: {
          establishedDate: '06/17/2006',
          customerType: 'PE',
          digitalCustomerType: 'B2C',
          firstName: 'RAVI',
          lastName: 'JACOBS',
          zipCode: '37824',
          zipCodePlus4: '0963',
          inWithVerizonInd: 'N',
          state: 'TN',
          hashedAccountNumber: 'de9f453b0f945716f09d3e2b6cc0cb22792bd8deb31007a0ddea51d1f000e3ca',
          mtnList: [Array],
          loggedInMtn: 'MASTRAL',
          lineDetails: [Array],
        },
        blockCTA: false,
        isDsdsCapable: true,
        additionalDisclosures:
          '<ol><li>Apple Intelligence will be available in beta on all iPhone 16 models, iPhone 15 Pro, and iPhone 15 Pro Max, with Siri and device language set to U.S. English, as an iOS 18 update in Fall 2024. Some features and additional languages will be coming over the course of the next year.</li>\n' +
          '<li>Battery life varies by use and configuration. See <a href="http://apple.com/batteries" target="_blank">apple.com/batteries</a> for more information.</li>\n' +
          '<li>Accessories sold separately.</li>\n' +
          '<li>The displays have rounded corners. When measured as a rectangle, the screen is 6.12 inches (iPhone 16), 6.69 inches (iPhone 16 Plus), 6.27 inches (iPhone 16 Pro) or 6.86 inches (iPhone Pro Max) diagonally. Actual viewable area is less.</li>\n' +
          '<li>Some features may not be available for all countries or all areas.</li>\n' +
          '<li>Service is included for free for two years with the activation of any iPhone 16 model. Connection and response times vary based on location, site conditions, and other factors. See <a href="https://support.apple.com/kb/HT213885 "target="_blank">https://support.apple.com/kb/HT213885</a> for more information.</li>\n' +
          '<li>iPhone 16 and iPhone 16 Pro can detect a severe car crash and call for help. Requires a cellular connection or Wi-Fi calling.</li>\n' +
          '</ol>',
        compatibleSimSorIds: [
          'UNIVESIM5G-SA-S',
          'UNIVESIM5G-SA-A',
          'UNIVESIM5G-SAB-A',
          'UNIVESIM5G-SAB-S',
          'UNIVESIM5G-SAB-D',
          'UNIVESIM5G-SA-D',
        ],
        deviceUnlockPolicy: {
          textId: '11500001',
          textName: 'DEVICE_UNLOCK_POLICY',
          description: null,
          text: '<p><strong>Device Unlocking Policies</strong></p>\r\r<p>In order to mitigate theft and other fraudulent activity, newly purchased devices are\r"u201Clockedu201D" to work exclusively on the Verizon network. We have separate device\runlocking policies that cover postpay and prepaid devices, as well as special rules for\rdeployed military personnel.</p>\r \r\r\r<p>"u201CUnlockingu201D" a device refers only to disabling software that would prevent a consumer\rfrom attempting to activate a device designed for one carrieru2019s network. Due to differing technologies, an unlocked Verizon Wireless device\rmay not work u2013 or may experience limited functionality u2013 on another carrieru2019s network.</p>\r\r \r\r<p><strong>Postpay Device Unlocking Policy</strong></p>\r\r\r\r<p>Devices that you purchase from Verizon are locked for 60 days after purchase. Devices that you purchase from our retail partners are locked for 60 days after activation.After 60 days, we will automatically remove the lock. Following the 60 day lock period, we do not lock our phones at any time.</p>\r\r\r\r\r<p><strong>Prepaid Device Unlocking Policy</strong></p>\r\r\r<p>Devices that you purchase from Verizon and certain devices purchased from our retail partners are locked for 60 days after activation. After 60 days, we will automatically remove the lock. Following the 60 day lock period following device purchase, we do not lock our phones at any time.</p>\r\r<p>If you purchase a 4G Phone&ndash;in&ndash;a&ndash;Box from our retail partners, you should review the back of the box to determine the lock period applicable to that device.</p>\r\r<p><strong>Unlocking Policy for Deployed Military Personnel</strong></p>\r\r<p>If you are a Verizon Wireless customer in the military and receive relocation orders outside of the Verizon Coverage Area, we will unlock your device at your request, even during the 60&ndash;day&ndash;lock period following the purchase of your device.</p>\r\r<p>Effective Date: July 23, 2019</p>',
          applicationFlag: true,
          url: null,
          urlAvailableFlag: false,
          newBrowserFlag: null,
          textType: 'GlobalText',
          displayB2cFlag: true,
          sequenceOrder: null,
          textVersion: null,
          wmsLabel: null,
          currentVersion: 1,
        },
        daccId: '02294',
        deviceType: 300202,
        hasDeviceUnlockPolicy: true,
        includedAccessories:
          '<ul class="details-list"><li>iPhone with iOS 18</li>\n' +
          '<li>USB-C Charge Cable (1 m)</li>\n' +
          '<li>Documentation</li>\n' +
          '</ul>',
        isAnySkuInStock: false,
        isAllSkusOutofStock: false,
        isCPO: false,
        isE911Address: false,
        isNumberShareCapable: false,
        isNumberShareMandatory: false,
        isSupportOnly: false,
        operatingSystem: 'Apple iOS',
        startDate: {
          date: '09-13-2024',
          dateTime: '09-13-2024 07:58:00 AM',
          dateLong: 1726228680000,
        },
        sorDeviceCategory: '5G Smartphone',
        specifications: {
          battery: null,
          depth: 0.31,
          height: 5.81,
          screenSize: '6.1"',
          size: '5.81,2.82,0.31',
          weight: 6,
          width: 2.82,
        },
        techSpecs: {
          'Video Playback':
            'Video playback : Up to 22 hours, Video playback (streamed) : Up to 18 hours, Audio playback : Up to 80 hours',
          Overall: 'Accessibility Shortcut, Siri, Guided Access, Per App Setting',
          'Wi-fi': 'Yes',
          Screen:
            'Super Retina XDR display | 6.1‑inch (diagonal) all‑screen OLED display | 2556‑by‑1179-pixel resolution at 460 ppi',
          Mobility: 'Voice Control, Switch Control, AssistiveTouch, Back Tap',
          'World Device': 'Works in over 200 countries depending on your plan',
          Depth: '0.31 inch',
          Auditory: 'Made for iPhone hearing devices, Sound Recognition, Headphone Accommodations, Live Captions',
          'Voice Assistant': 'Siri',
          '5G Nationwide':
            'FDD-5G NR (Bands n1, n2, n3, n5, n7, n8, n12, n14, n20, n25, n26, n28, n29, n30, n66, n70, n71, n75, n76) | TDD-5G NR (Bands n38, n40, n41, n48, n53, n77, n78, n79)',
          'Operating System': 'iOS 18',
          Height: '5.81 inches',
          Width: '2.82 inches',
          Visual: 'VoiceOver, Zoom, Color Filters, Spoken Content',
          'Camera Mode':
            'Photonic Engine;Portrait Lighting with six effects;Night mode;Panorama (up to 63MP);Spatial photos;Macro photography;Lens correction (Ultra Wide);Advanced red‑eye correction;Auto image stabilization;Burst mode;Photo geotagging;Image formats captured: HEIF and JPEG',
          Charging:
            'Up to 50% charge in around 30 minutes with 20W adapter or higher paired with USB-C charging cable, or  30W adapter or higher paired with MagSafe Charger (all available separately)',
          'Front Camera':
            '12MP camera;ƒ/1.9 aperture;Autofocus with Focus Pixels;Retina Flash;Deep Fusion;Smart HDR 5;Next-generation portraits with Focus and Depth Control;Portrait Lighting with six effects;Animoji and Memoji;Latest-generation Photographic Styles;Wide color capture for photos and Live Photos;Lens correction',
          '5G Ultra Wide-Band': '5G NR mmWave (Bands n258, n260, n261)',
          'Hearing Aid Compatibility': 'M3/T4',
          Weight: '6.00 ounces (170 grams)',
          Type: 'Built-in rechargeable lithium-ion battery',
          Storage: '128 GB, 256GB, 512GB (Subject to availability)',
          Colors: 'Black, White, Pink, Teal, Ultramarine',
          'Usage Time': 'Audio playback : Up to 80 hours',
          'Rear Camera':
            '48MP Fusion: 26 mm, ƒ/1.6 aperture, sensor‑shift optical image stabilization, 100% Focus Pixels, support for super-high-resolution photos (24MP and 48MP)',
          'Global & Roaming Network':
            'FDD-LTE (Bands 1, 2, 3, 4, 5, 7, 8, 12, 13, 14, 17, 18, 19, 20, 25, 26, 28, 29, 30, 32, 66, 71) | TDD-LTE (Bands 34, 38, 39, 40, 41, 42, 48, 53) | UMTS/HSPA+/DC-HSDPA (850, 900, 1700/2100, 1900, 2100 MHz) | GSM/EDGE (850, 900, 1800, 1900 MHz)',
          'Video Recording':
            '4K Dolby Vision video recording at 24 fps, 25 fps, 30 fps, or 60 fps | 1080p Dolby Vision video recording at 25 fps, 30 fps, or 60 fps | 720p Dolby Vision video recording at 30 fps',
        },
        categoryDisplayNames: ['GnG Devices', 'Smartphones', 'Postpaid Devices'],
        isIconicPhone: true,
        unlockDevicePDP: false,
        emergencyCLNR: true,
        cannotBeUpgraded: false,
        hostDeviceInCompatible: false,
        sorDeviceType: '5GE',
        ccod: null,
        favoriteId: null,
        inFavorite: false,
        wishListCount: 0,
        imageName: 'apple-iphone-16-ultramarine',
        imageUrlMap: {
          defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-16-ultramarine',
          largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-16-ultramarine?$device-lg$',
          mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-16-ultramarine?$device-med$',
          miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-16-ultramarine?$device-mini$',
          thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-16-ultramarine?$device-thumb$',
          imageSetUrl:
            'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/apple-iphone-16-ultramarine_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
        },
        deviceRestricted: false,
        skuRestrictions: { restrictionMessages: [], isAllSkusRestricted: false },
        productSpecification: null,
        notSellableSkus: ['3N390LL/A', '3N388LL/A', '3N386LL/A', '3N389LL/A', '3N387LL/A'],
        deviceLowestPrice: null,
        deviceHighestPrice: null,
        isDefaultPlanEligible: false,
        isInstorePickupRestricted: false,
        modPdp: false,
      },
      commonInfo: {
        showPrice: false,
        displayReasonCode: false,
        showShipitToggle: true,
        flexPDPTradeInLinkEnabled: true,
        containSoftSku: false,
        dpEligible: true,
        indirect: true,
      },
      accountInfo: {
        lastName: 'JACOBS',
        zipCode: '37824',
        myOfferAccepted: null,
        nickName: null,
        safeTechSessionId: '030a4501b24a480f93a9843a',
        processingMTN: null,
        accountEupDeviceType: null,
        zipCodePlus4: '0963',
        selectedOfferFlows: null,
        buyoutDisplay: 'False',
        estTradeInValue: null,
        firstName: 'RAVI',
        intentType: null,
        preOrderMTNEnable: 'false',
        custType: 'B2C',
        btaEligible: 'false',
        state: 'TN',
      },
      fiveGMobilityInfo: {
        fiveGToFourGOverlay: false,
        fiveGHomeRequired: false,
        fiveGUpSell: false,
      },
      catDL: null,
      getDeviceTradeStatus: { promoExists: false, bogoOffer: false },
      showReturnTab: false,
      enablePromoChoiceExp: false,
    },
    setSelectedPaymentInfo: jest.fn(),
    selectedSku: {
      price: {
        fullRetailPrice: true,
      },
    },
    isAddEdgeUpSuccess: false,
  };
  beforeEach(() => {
    render(<IndirectPaymentOptions {...directProps} />);
  });

  test('conponent should render', () => {
    const radio = screen.getByRole('radio', { name: 'Month To Month' });
    expect(radio).toBeInTheDocument();
  });
});

describe('PDP component for indirect Local Order Flow', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.setItem('channel', 'indirect');
    window.store = mockStore;
    window.vzdl = { page: {} };
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?offerEligible=Y&activeMtn=9102798662&productId=dev21410695&defaultSku=MTXW3LL/A`;
    render(
      <PDP
        setSelectedColor={jest.fn()}
        selectedPaymentInfo={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...localOrderIndirectProps}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });

  test('It should display Add to Cart button for Local order', async () => {
    const addTocart = await screen.getByRole('button', {
      name: /Add to cart/i,
    });
    expect(addTocart).toBeInTheDocument();
    fireEvent.click(addTocart);
    Emitter.emit('TAGGING_COMPLETED', true);
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Decline protection_Decline Device Protection' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });

  test('It should display Add to Cart button for Local order with device only change', async () => {
    const m2m = screen.getAllByRole('radio', {
      name: 'Month To Month',
    });
    expect(m2m[0]).not.toBeChecked();
    fireEvent.click(m2m[0]);
    expect(m2m[0]).toBeChecked();

    const addTocart = await screen.getByRole('button', {
      name: /Add to cart/i,
    });
    expect(addTocart).toBeInTheDocument();
    fireEvent.click(addTocart);
    Emitter.emit('TAGGING_COMPLETED', true);
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Decline protection_Decline Device Protection' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });
});

describe('PDP component for indirect Local Order Flow For New Line', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
    const location = {
      ...window.location,
      search: `?offerEligible=Y&activeMtn=9102798662&productId=dev21410695&defaultSku=MTXW3LL/A&isByodUpdate=true`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?offerEligible=Y&activeMtn=9102798662&productId=dev21410695&defaultSku=MTXW3LL/A&isByodUpdate=true`;
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.setItem('channel', 'indirect');
    window.store = mockStore;
    window.vzdl = { page: {} };

    render(
      <PDP
        setSelectedColor={jest.fn()}
        selectedPaymentInfo={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...newLIneProps}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });

  test('It should display Add to Cart button for Local order', async () => {
    const submitButton = screen.queryByText('Device Only Change');
    expect(submitButton).toBeNull(); // it doesn't exist
  });
});

describe('PDP component should dispatch error message when deviceSimCompatible is N', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
    const location = {
      ...window.location,
      search: `?deviceSimCompatible=N&offerEligible=Y&activeMtn=9102798662&productId=dev21410695&defaultSku=MTXW3LL/A&isByodUpdate=true`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?deviceSimCompatible=N&offerEligible=Y&activeMtn=9102798662&productId=dev21410695&defaultSku=MTXW3LL/A&isByodUpdate=true`;
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.setItem('channel', 'indirect');
    window.store = mockStore;
    window.vzdl = { page: {} };

    render(
      <PDP
        setSelectedColor={jest.fn()}
        selectedPaymentInfo={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...newLIneProps}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });

  test('It should display Add to Cart button for Local order', async () => {
    const submitButton = screen.queryByText('Device Only Change');
    expect(submitButton).toBeNull(); // it doesn't exist
  });
});

describe('PDP component should show success message when deviceSimCompatible is Y', () => {
  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
    const location = {
      ...window.location,
      search: `?deviceSimCompatible=Y&offerEligible=Y&activeMtn=9102798662&productId=dev21410695&defaultSku=MTXW3LL/A&isByodUpdate=true`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?deviceSimCompatible=Y&offerEligible=Y&activeMtn=9102798662&productId=dev21410695&defaultSku=MTXW3LL/A&isByodUpdate=true`;
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.setItem('channel', 'indirect');
    window.store = mockStore;
    window.vzdl = { page: {} };

    render(
      <PDP
        setSelectedColor={jest.fn()}
        selectedPaymentInfo={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        {...newLIneProps}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });

  test('It should display Add to Cart button for Local order', async () => {
    const submitButton = screen.queryByText('Device Only Change');
    expect(submitButton).toBeNull(); // it doesn't exist
  });
});
describe('PDP component for indirect Local Order Flow imei2 scan issue', () => {
  sessionStorage.setItem('APP_PROPERTIES', '{"imeiIssueFielddt4360fixFFlag": "TRUE"}');

  const addDeviceData = {
    serviceBody: {},
  };
  const handlers = [
    rest.post(`*/flexV2/add-device`, (req, res, ctx) => {
      console.log('inside /flexV2/add-device');
      return res(ctx.status(200), ctx.json(addDeviceData));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
    const location = {
      ...window.location,
      search: `?offerEligible=Y&activeMtn=9102798662&productId=dev21410695&defaultSku=MTXW3LL/A&isByodUpdate=true&deviceId=1234567890`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?offerEligible=Y&activeMtn=9102798662&productId=dev21410695&defaultSku=MTXW3LL/A&isByodUpdate=true&deviceId=1234567890`;
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.setItem('channel', 'retail');

    window.store = mockStore;
    window.vzdl = { page: {} };
    window.location.href = `http://localhost:3010/content/vcg/assisted/product-detail.html?offerEligible=Y&activeMtn=9102798662&productId=dev21410695&defaultSku=MTXW3LL/A&deviceId=1234567890`;
    render(
      <PDP
        setSelectedColor={jest.fn()}
        selectedPaymentInfo={jest.fn()}
        setIspuToggleOn={jest.fn()}
        setIsShipItToggleOn={jest.fn()}
        setSelectedSku={jest.fn()}
        setSelectedProtectionFeature={jest.fn()}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        setSelectedDeviceData={jest.fn()}
        enteredDeviceID='1234567890'
        ValidateDeviceSimIdResult={{
          data: {
            serviceBody: { serviceResponse: { context: { deviceInfo: { imei1: '987654321', imei2: '1234567890' } } } },
          },
        }}
        {...localOrderIndirectProps}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });

  test('It should display Add to Cart button for Local order', async () => {
    const addTocart = await screen.getByRole('button', {
      name: /Add to cart/i,
    });
    expect(addTocart).toBeInTheDocument();
    fireEvent.click(addTocart);
    Emitter.emit('TAGGING_COMPLETED', true);
    const insurance = await screen.findByTestId('DeviceInsurance');
    expect(insurance).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: 'Decline protection_Decline Device Protection' });
    fireEvent.click(continueBtn);
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });
});
