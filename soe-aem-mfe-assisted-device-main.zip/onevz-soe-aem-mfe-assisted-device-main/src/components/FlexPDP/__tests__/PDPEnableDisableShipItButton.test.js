import React from 'react';
import { cloneDeep } from 'lodash';
import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import PDP from '../PDP';
import protectionFeatures from '../../../pages/PDP/mocks/api/getProtectionFeatures.json';
import productDetails from '../../../pages/PDP/mocks/api/getDetails.json';
import productDetails3 from '../../../pages/PDP/mocks/api/getDetails3.json';
import customerProfileDetails2 from '../../../pages/PDP/mocks/api/customerProfile2.json';
import cartDetails from '../../../pages/PDP/mocks/api/retrieveCart.json';

import deviceskuJson from './devicesku.json';

const details = productDetails.data.deviceProduct || {};
const defaultSkuStringValue = details?.defaultSKU || '';
const defaultSkuObjValue = details?.defaultSKUObj?.sorId || '';
const defaultSku = defaultSkuStringValue !== '' ? defaultSkuStringValue : defaultSkuObjValue;
const defaultSkuDetails = details.childSkus.filter((sku) => sku.sorId && sku.sorId === defaultSku);
const RemoveLinesAPIResultWithErrorCode = {
  data: {
    errors: [
      {
        id: '9656',
      },
    ],
  },
  status: 'fulfilled',
};

const details3 = productDetails3.data.deviceProduct || {};
const defaultSkuStringValue3 = details3?.defaultSKU || '';
const defaultSkuObjValue3 = details3?.defaultSKUObj?.sorId || '';
const defaultSku3 = defaultSkuStringValue3 !== '' ? defaultSkuStringValue3 : defaultSkuObjValue3;
const defaultSkuDetails3 = details3.childSkus.filter((sku) => sku.sorId && sku.sorId === defaultSku3);

const cloneProductDetails = cloneDeep(productDetails3);
delete cloneProductDetails.data.deviceProduct;
cloneProductDetails.data.deviceSku = deviceskuJson;

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradleProperty: () => [false, true, false],
    getAssistedCradlePropertyV2: () => [false, true, false],
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => false,
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);
jest.setTimeout(60000);
describe('PDP component render enable shipt it button', () => {
  const activeMtn = '5185673926';
  const props = {
    paymentObject: { contractDuration: 36 },
    buyoutUpgradeResult: { data: { totalBuyoutAmount: '56.7' }, status: 'fulfilled' },
    RemoveLinesAPIResult: {
      data: {
        errors: [
          {
            id: '9656',
          },
        ],
      },
      status: 'fulfilled',
    },
    setSelectedDeviceData: jest.fn(),
    removeLinesAPI: jest.fn(),
  };
  beforeAll(() => {
    sessionStorage.setItem('refundexchange', 'false');

    const location = {
      ...window.location,
      search: `?isByodUpdate=false&activeMtn=${activeMtn}&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y&mtn=newLine1&isContractChange=false`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?isByodUpdate=true&activeMtn=${activeMtn}&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y&mtn=newLine1&isContractChange=true`;

    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  beforeEach(() => {
    render(
      <PDP
        productDetails={productDetails.data}
        protectionFeatures={protectionFeatures}
        cartDetails={cartDetails.data.data}
        customerProfileDetails={customerProfileDetails2.data}
        activeMtn={activeMtn}
        selectedColor={defaultSkuDetails[0].color.displayName}
        setSelectedColor={jest.fn()}
        ispuToggleOn={false}
        setIspuToggleOn={jest.fn()}
        isShipItToggleOn={false}
        setIsShipItToggleOn={jest.fn()}
        selectedSku={defaultSkuDetails[0]}
        setSelectedSku={jest.fn()}
        selectedProtectionFeature={protectionFeatures.payload.features[1]}
        setSelectedProtectionFeature={jest.fn()}
        selectedSize={defaultSkuDetails[0].capacity}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        RemoveLinesAPIResult={RemoveLinesAPIResultWithErrorCode}
        {...props}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test.skip('component should render', async () => {
    const textSku = await screen.findByText('iPhone 14 Pro 128GB in Deep Purple');
    expect(textSku).toBeInTheDocument();
  });
  test.skip('component should render', async () => {
    const textSku = await screen.findByText('iPhone 14 Pro 128GB in Deep Purple');
    expect(textSku).toBeInTheDocument();
    const testShip = screen.queryAllByTestId('test-hitArea')[1];
    expect(testShip).toBeInTheDocument();
    fireEvent.click(testShip);
  });
  test('component should render', async () => {
    const textSku = await screen.getAllByRole('button', { name: 'Accept' });
    expect(textSku[0]).toBeInTheDocument();
    fireEvent.click(textSku[0]);
  });
  test('component should render', async () => {
    const textSku = await screen.getAllByRole('button', { name: 'Decline' });
    expect(textSku[0]).toBeInTheDocument();
    fireEvent.click(textSku[0]);
  });
  test('To cover removeLines function', () => {
    const removeModalId = screen.getByTestId('removeModalId');
    expect(removeModalId).toBeInTheDocument();
    fireEvent.click(removeModalId);
  });
});

describe('PDP component render enable ship it button refund exchange flow', () => {
  const activeMtn = '5185673926';
  const props = {
    paymentObject: { contractDuration: 36 },
    buyoutUpgradeResult: { data: { totalBuyoutAmount: '56.7' }, status: 'fulfilled' },
    RemoveLinesAPIResult: {
      data: {
        errors: [
          {
            id: '9656',
          },
        ],
      },
      status: 'fulfilled',
    },
    setSelectedDeviceData: jest.fn(),
  };

  beforeAll(() => {
    sessionStorage.setItem('refundexchange', 'true');

    const location = {
      ...window.location,
      search: `?isByodUpdate=true&activeMtn=${activeMtn}&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y&mtn=newLine1&isContractChange=true`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?isByodUpdate=true&activeMtn=${activeMtn}&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y&mtn=newLine1&isContractChange=true`;
  });

  beforeEach(() => {
    render(
      <PDP
        productDetails={cloneProductDetails.data}
        cartDetails={cartDetails.data.data}
        customerProfileDetails={customerProfileDetails2.data}
        activeMtn={activeMtn}
        selectedColor={defaultSkuDetails3[0].color.displayName}
        setSelectedColor={jest.fn()}
        ispuToggleOn={false}
        setIspuToggleOn={jest.fn()}
        isShipItToggleOn={false}
        setIsShipItToggleOn={jest.fn()}
        selectedSku={defaultSkuDetails3[0]}
        setSelectedSku={jest.fn()}
        selectedProtectionFeature={protectionFeatures.payload.features[1]}
        setSelectedProtectionFeature={jest.fn()}
        selectedSize={defaultSkuDetails3[0].capacity}
        setSelectedSize={jest.fn()}
        buyoutUpgradeReq={jest.fn()}
        RemoveLinesAPIResult={RemoveLinesAPIResultWithErrorCode}
        protectionFeatures={{ currentProtection: 'test', protectionFeatures: { sorId: 'sorID' } }}
        {...props}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });

  test('component should render', async () => {
    const textSku = await screen.getAllByRole('button', { name: 'Accept' });
    expect(textSku[0]).toBeInTheDocument();
    fireEvent.click(textSku[0]);
  });
  test('component should render', async () => {
    const textSku = await screen.getAllByRole('button', { name: 'Decline' });
    expect(textSku[0]).toBeInTheDocument();
    fireEvent.click(textSku[0]);
  });
});
