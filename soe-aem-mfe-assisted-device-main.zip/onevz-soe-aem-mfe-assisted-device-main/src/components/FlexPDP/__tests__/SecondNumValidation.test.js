import React from 'react';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { render, screen } from '../../../modules/test-utils/renderHelper';
import SecondLineDeviceId from '../SecondLineDeviceId';

const cartSetails = {
  cart: {
    lineDetails: {
      lineInfo: [
        {
          mtnDetails: {
            mobileNumber: '1234',
          },
          serviceInfo: {
            orderDevice: {
              lteVoraEquipInfo: {
                lteVoraDeviceInfo: {
                  deviceId: '987654321',
                },
                lteEqpt: {
                  iccid: '1234567',
                },
              },
            },
          },
        },
      ],
    },
  },
};
describe('device model component render', () => {
  beforeEach(() => {
    render(
      <SecondLineDeviceId isSecNumValidation validateDeviceSimIdRequest={jest.fn()} setSecondNumDeviceId={jest.fn()} />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('component should render', () => {
    expect(screen.getByTestId('SecondLineDeviceId')).toBeInTheDocument();
  });
});

describe('device model component render', () => {
  beforeEach(() => {
    render(
      <SecondLineDeviceId
        fromCpe
        isSecNumValidation
        validateDeviceSimIdRequest={jest.fn()}
        setSecondNumDeviceId={jest.fn()}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('component should render', () => {
    expect(screen.getByTestId('SecondLineDeviceId')).toBeInTheDocument();
  });
});
describe('device model component render', () => {
  beforeEach(() => {
    const location = {
      ...window.location,
      search: '?isFromCPE=true&deviceFromCart=true',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=newLine1&isFromCPE=${true}&deviceFromCart=${true}&productId=1234`;
    render(
      <SecondLineDeviceId
        cartDetails={cartSetails}
        pairedMtn="1234"
        fromCpe
        isSecNumValidation
        validateDeviceSimIdRequest={jest.fn()}
        setSecondNumDeviceId={jest.fn()}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('component should render', () => {
    expect(screen.getByTestId('SecondLineDeviceId')).toBeInTheDocument();
  });
});
