import { render, fireEvent, screen } from '../../modules/test-utils/renderHelper';
import DeviceInfo5G from './DeviceInfo5G';
import { Context } from '../../pages/PDP5G/PDP5gContext';
import { Deviceinfo5gMockWithoutInventoryWithBundle, Deviceinfo5gMockBundleProduct } from './mocks/Deviceinfo5gMock';

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradleProperty: () => ['TRUE'],
  }),
  { virtual: true },
);

describe(`<DeviceInfo5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMockWithoutInventoryWithBundle}>
        <DeviceInfo5G />
      </Context.Provider>,
    );
  });
  test.skip('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<DeviceInfo5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMockBundleProduct}>
        <DeviceInfo5G />
      </Context.Provider>,
    );
  });
  test.skip('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
