import { Modal, ModalTitle, ModalFooter } from '@vds/modals';
import { useNavigate } from 'react-router-dom';
import { getUIContextPathBAU } from 'onevzsoemfecommon/Helpers';
import Emitter from 'onevzsoemfeframework/Emitter';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { DEVICE_PLAN_INCOMPATIBLE_MESSAGE } from '../constants/DeviceConstants';
import { updateModalStateCommon } from './pdputils';

let navigate = '';

function useNavigateMFE() {
  navigate = useNavigate();
}

const DevicePlanCompatible = (props) => {
  const { showModal, removeLines } = props;
  const scmDeviceEnable = window?.mfe?.scmDeviceMfeEnable;
  const [ctaVisibleFFlag] = getAssistedCradlePropertyV2(['ctaVisibleFFlag']);

  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }

  const routeToPlanApp = () => {
    const nonPlanCompatibleroute = `${getUIContextPathBAU()}/combinedgridwall.html?fromLanding=TRUE&activeMtn=${
      props?.activeMtn
    }&isPlanTabSelect=true`;
    if (!scmDeviceEnable) {
      navigate(nonPlanCompatibleroute);
    } else {
      Emitter.emit('SCM_DEVICE_PLAN_COMPATIBLITY_FLOW');
    }
  };

  const routeToLanding = () => {
    removeLines();
    if (!scmDeviceEnable) {
      navigate(`${getUIContextPathBAU()}/landing.html`);
    }
  };

  const updateModalState = (opened) => {
    updateModalStateCommon(opened, props?.onClose);
  };

  return (
    <div data-testid='devicePlanCompatibleModal'>
      <Modal
        onOpenedChange={updateModalState}
        opened={showModal}
        surface='light'
        fullScreenDialog={false}
        disableAnimation={false}
        disableOutsideClick
        ariaLabel='Device Plan Compatible Modal'
        width={ctaVisibleFFlag === 'TRUE' ? '79vh' : '76vh'}
      >
        <ModalTitle>{DEVICE_PLAN_INCOMPATIBLE_MESSAGE}</ModalTitle>
        <ModalFooter
          buttonData={{
            primary: {
              children: 'Ok',
              onClick: () => routeToPlanApp(),
              'data-track': 'Ok',
            },
            close: {
              children: 'Cancel and Remove',
              onClick: () => routeToLanding(),
              'data-track': 'Cancel and Remove',
            },
          }}
        />
      </Modal>
    </div>
  );
};

export default DevicePlanCompatible;
