import React, { memo, useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';

const FccInfoWrapper = styled.div`
  color: #0077b4;
  margin: 20px 20px 0 0;
  font-size: 15px;
  font-weight: bold;
`;

function FccInfo(props) {
  const { productDetailsAemContent, details } = props;
  const [showFccInfo, setShowFccInfo] = useState(false);

  useEffect(() => {
    isInit();
  }, []);

  useEffect(() => {
    isInit();
  }, [productDetailsAemContent, details]);

  const isInit = () => {
    const isVissible =
      productDetailsAemContent?.fccInfo && productDetailsAemContent?.fccProductIds?.includes(details?.productId);
    setShowFccInfo(isVissible);
  };

  return showFccInfo && <FccInfoWrapper>{productDetailsAemContent?.fccInfo}</FccInfoWrapper>;
}

FccInfo.propTypes = {
  productDetailsAemContent: PropTypes.object,
  details: PropTypes.object,
};

FccInfo.defaultProps = {
  productDetailsAemContent: {},
  details: {},
};

export default memo(FccInfo);
