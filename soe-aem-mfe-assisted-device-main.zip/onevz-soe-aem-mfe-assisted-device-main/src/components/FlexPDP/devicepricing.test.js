import { executeShellFunction } from 'onevzsoemfeframework/DomService';
import { devicePricingDetails, getBestBuyPricingDetails } from './pdputils';

jest.mock('onevzsoemfeframework/DomService', () => ({
  executeShellFunction: jest.fn(),
}));

describe('pdputils', () => {
  describe('devicePricingDetails', () => {
    it('should parse data and call setBByPricing', () => {
      const mockSetBByPricing = jest.fn();
      const mockData = JSON.stringify({ test: 'data' });

      const result = devicePricingDetails(mockData, mockSetBByPricing);

      expect(mockSetBByPricing).toHaveBeenCalledWith({ test: 'data' });
      expect(result).toEqual({ test: 'data' });
    });

    it('should handle empty data', () => {
      const mockSetBByPricing = jest.fn();
      const mockData = JSON.stringify({});

      const result = devicePricingDetails(mockData, mockSetBByPricing);

      expect(mockSetBByPricing).toHaveBeenCalledWith({});
      expect(result).toEqual({});
    });

    it('should handle malformed JSON', () => {
      const mockSetBByPricing = jest.fn();
      expect(() => {
        devicePricingDetails('invalid json', mockSetBByPricing);
      }).toThrow();
      expect(mockSetBByPricing).not.toHaveBeenCalled();
    });
  });

  describe('getBestBuyPricingDetails', () => {
    let mockSetBByPricing;

    beforeEach(() => {
      jest.clearAllMocks();
      delete window.BbyDevicePricingDetails;
      mockSetBByPricing = jest.fn();
    });

    it('should handle undefined setBByPricing', () => {
      expect(() => getBestBuyPricingDetails()).not.toThrow();
    });

    it('should handle null setBByPricing', () => {
      expect(() => getBestBuyPricingDetails(null)).not.toThrow();
    });

    it('should handle non-function setBByPricing', () => {
      expect(() => getBestBuyPricingDetails('not a function')).not.toThrow();
    });

    it('should work with different UPC and storeId values', () => {
      const skuRealAgentCode = '0281';
      const UpcCodeData = '400055816159';

      getBestBuyPricingDetails(mockSetBByPricing, skuRealAgentCode, UpcCodeData);

      const firstCall = executeShellFunction.mock.calls[0][3];
      expect(JSON.parse(firstCall.requestPayloadJson)).toEqual({
        upc: UpcCodeData,
        storeId: skuRealAgentCode,
      });
    });
  });

  describe('Integration tests', () => {
    beforeEach(() => {
      jest.clearAllMocks();
      delete window.BbyDevicePricingDetails;
    });

    it('should properly integrate devicePricingDetails with getBestBuyPricingDetails', () => {
      const mockSetBByPricing = jest.fn();
      const pricingData = {
        storeId: '0281',
        upc: '400055816159',
        deviceSku: '5581615',
        priceInfo: [
          {
            priceId: 'cnt302',
            activationType: 'upgrade',
            purchaseType: 'FINANCED',
            contractTerm: 36,
            regularPrice: 8.33,
            currentPrice: 8.33,
            taxBasis: 299.99,
            downPaymentAmount: 0.0,
            bbyDownPayment: 0.0,
          },
          {
            priceId: 'cnt302',
            activationType: 'upgrade',
            purchaseType: 'FULL_SRP',
            contractTerm: 1,
            regularPrice: 299.99,
            currentPrice: 299.99,
            taxBasis: 299.99,
            downPaymentAmount: 0.0,
            bbyDownPayment: 0.0,
          },
          {
            priceId: 'cnt301',
            activationType: 'new',
            purchaseType: 'FINANCED',
            contractTerm: 36,
            regularPrice: 8.33,
            currentPrice: 8.33,
            taxBasis: 299.99,
            downPaymentAmount: 0.0,
            bbyDownPayment: 0.0,
          },
          {
            priceId: 'cnt301',
            activationType: 'new',
            purchaseType: 'FULL_SRP',
            contractTerm: 1,
            regularPrice: 299.99,
            currentPrice: 299.99,
            taxBasis: 299.99,
            downPaymentAmount: 0.0,
            bbyDownPayment: 0.0,
          },
        ],
      };

      getBestBuyPricingDetails(mockSetBByPricing);
      window.BbyDevicePricingDetails(JSON.stringify(pricingData));

      expect(mockSetBByPricing).toHaveBeenCalledWith(pricingData);
      expect(mockSetBByPricing).toHaveBeenCalledTimes(1);
    });

    it('should handle multiple sequential calls', () => {
      const mockSetBByPricing = jest.fn();
      const firstData = { priceInfo: [{ id: 1 }] };
      const secondData = { priceInfo: [{ id: 2 }] };

      getBestBuyPricingDetails(mockSetBByPricing);
      window.BbyDevicePricingDetails(JSON.stringify(firstData));

      getBestBuyPricingDetails(mockSetBByPricing);
      window.BbyDevicePricingDetails(JSON.stringify(secondData));

      expect(mockSetBByPricing).toHaveBeenCalledTimes(2);
      expect(mockSetBByPricing).toHaveBeenNthCalledWith(1, firstData);
      expect(mockSetBByPricing).toHaveBeenNthCalledWith(2, secondData);
    });
  });

  describe('Payment Options Generation', () => {
    beforeEach(() => {
      jest.clearAllMocks();
      delete window.BbyDevicePricingDetails;
    });

    it('should generate correct payment options for upgrade path', () => {
      const mockSetBByPricing = jest.fn();
      const pricingData = {
        priceInfo: [
          {
            activationType: 'upgrade',
            purchaseType: 'FINANCED',
            currentPrice: '10.99',
            contractTerm: '24',
          },
          {
            activationType: 'upgrade',
            purchaseType: 'FULL_SRP',
            currentPrice: '799.99',
            contractTerm: '24',
          },
        ],
      };

      getBestBuyPricingDetails(mockSetBByPricing);
      window.BbyDevicePricingDetails(JSON.stringify(pricingData));

      const receivedData = mockSetBByPricing.mock.calls[0][0];
      expect(receivedData.priceInfo).toHaveLength(2);
      expect(receivedData.priceInfo).toEqual(
        expect.arrayContaining([
          expect.objectContaining({
            activationType: 'upgrade',
            purchaseType: 'FINANCED',
          }),
          expect.objectContaining({
            activationType: 'upgrade',
            purchaseType: 'FULL_SRP',
          }),
        ]),
      );
    });

    it('should handle missing payment options', () => {
      const mockSetBByPricing = jest.fn();
      const incompletePricingData = {
        priceInfo: [
          {
            activationType: 'upgrade',
            purchaseType: 'FINANCED',
            currentPrice: '10.99',
            contractTerm: '24',
          },
        ],
      };

      getBestBuyPricingDetails(mockSetBByPricing);
      window.BbyDevicePricingDetails(JSON.stringify(incompletePricingData));

      const receivedData = mockSetBByPricing.mock.calls[0][0];
      expect(receivedData.priceInfo).toHaveLength(1);
      expect(receivedData.priceInfo[0]).toEqual(
        expect.objectContaining({
          activationType: 'upgrade',
          purchaseType: 'FINANCED',
        }),
      );
    });
  });
});
