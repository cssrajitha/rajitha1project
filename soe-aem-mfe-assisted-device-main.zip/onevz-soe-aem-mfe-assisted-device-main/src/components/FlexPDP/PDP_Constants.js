export const CARE_DROPDOWN_OPTIONS = [
  {
    label: 'Device change',
    value: 'Device change',
  },
  {
    label: 'SIM only change',
    value: 'SIM only change',
  },
];

export const DEVICE_CHANGE = CARE_DROPDOWN_OPTIONS[0].value;
export const SIM_ONLY_CHANGE = CARE_DROPDOWN_OPTIONS[1].value;
export const TELESALES_ISPU_SIM_SORID = 'BULKSIM5G-SA-A';
export const TELESALES_ISPU_SIM_SORID_CPE = 'BULKSIM5G-SA-S';
export const DROPSHIP_DEVICE_TOOLTIP = 'Order must be completed by 12 PM EST M-Th & 10 AM EST on F for next day delivery.';
export const DROPSHIP_PRODCODE5_ALLOWED_LIST = ['DAC', 'DCP', 'DCD', 'CCD', 'CAC', 'CCP'];
