import { fireEvent, waitFor } from '@testing-library/react';
import React from 'react';
import { isD2D } from 'onevzsoemfeframework/DomService';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { render, screen } from '../../modules/test-utils/renderHelper';
import MoreOptions from './MoreOptions';
import customerProfile from '../../pages/PDP/mocks/api/customerProfile.json';
import deviceProps from './__mocks__/mockMoreOptionsCart.json';
import { isVbg } from 'onevzsoemfeframework/VbgAemUtil';

jest.mock(
  '../../modules/utils/index',
  () => ({
    __esModule: true,
    ...jest.requireActual('../../modules/utils/index'),
    isFunctionalityEnabled: (flag, attribute) => {
      if (flag === 'scmCommonDefectFixFFlag' && attribute === 'scmBulkDFillSimFix') {
        return true;
      }
      return false;
    },
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradleProperty: () => ['TRUE'],
    getAssistedCradlePropertyV2: () => ['TRUE'],
  }),
  { virtual: true },
);

jest.mock('onevzsoemfeframework/VbgAemUtil', () => ({
  __esModule: true,
  ...jest.requireActual('onevzsoemfeframework/VbgAemUtil'),
  isVbg: jest.fn().mockReturnValue(false),
}));

describe('device model component render', () => {
  beforeAll(() => {
    window.vzdl = { page: {} };
  });

  beforeEach(() => {
   
    render(
      <MoreOptions
        CustomerData={customerProfile.data.customer}
        handleOk={jest.fn()}
        navigate={jest.fn()}
        productDetails={{
          deviceProduct: {
            commonInfo: {
              showPrice: true,
              displayReasonCode: true,
              showShipitToggle: true,
              flexPDPTradeInLinkEnabled: true,
              containSoftSku: false,
              dpEligible: true,
              indirect: false,
            },
          },
        }}
        isFromCPE={false}
        isRfexFlow
        isNewLine={false}
        channel='OMNI-RETAIL'
        downPayment={10}
        setDownPaymentObj={jest.fn()}
        CustomerProfileCommonInfo={{
          showTradeinTab: true,
        }}
        deviceContract='DPP'
        isInStock
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });
  test('MoreOptions component shoudl render', async () => {
    const MoreOptionsText = screen.getByText(/More options/i);
    fireEvent.click(MoreOptionsText);
    await waitFor(() => {
      const MoreOptionsId = screen.getAllByTestId('mpre-options')[2];
      fireEvent.click(MoreOptionsId);
    });
  });
  test.skip('MoreOptions component shoudl render', async () => {
    const MoreOptionsText = screen.getByText(/More options/i);
    fireEvent.click(MoreOptionsText);
    await waitFor(() => {
      const MoreOptionsId = screen.getAllByTestId('mpre-options')[3];
      fireEvent.click(MoreOptionsId);
    });
  });
  test('MoreOptions component shoudl render', async () => {
    const MoreOptionsText = screen.getByText(/More options/i);
    fireEvent.click(MoreOptionsText);
    fireEvent.mouseDown(MoreOptionsText);
  });
  test('MoreOptions component with option TradeIn selected', async () => {
    const MoreOptionsText = screen.getByText(/More options/i);
    fireEvent.click(MoreOptionsText);
    await waitFor(() => {
      const MoreOptionsId = screen.getAllByTestId('mpre-options')[1];
      fireEvent.click(MoreOptionsId);
    });
  });
  test('MoreOptions component with option DownPayment selected', () => {
    const MoreOptionsText = screen.getByText(/More options/i);
    fireEvent.click(MoreOptionsText);
    waitFor(() => {
      const MoreOptionsId = screen.getAllByTestId('mpre-options')[3];
      fireEvent.click(MoreOptionsId);
    });
    waitFor(() => {
      const okBtn = screen.getByText(/Done/i);
      expect(okBtn).toBeInTheDocument();
      fireEvent.click(okBtn);
    });
  });
  test('MoreOptions component with option DownPayment selected', () => {
    const MoreOptionsText = screen.getByText(/More options/i);
    fireEvent.click(MoreOptionsText);
    waitFor(() => {
      const MoreOptionsId = screen.getAllByTestId('mpre-options')[3];
      fireEvent.click(MoreOptionsId);
    });
    waitFor(()=> {
      const backArrow = screen.getByTestId('testBackGridwall');
      expect(backArrow).toBeInTheDocument();
      fireEvent.click(backArrow);
    })
  });
  test('MoreOptions component with option DownPayment selected', () => {
    const MoreOptionsText = screen.getByText(/More options/i);
    fireEvent.click(MoreOptionsText);
    waitFor(() => {
      const MoreOptionsId = screen.getAllByTestId('mpre-options')[3];
      fireEvent.click(MoreOptionsId);
    });
    waitFor(() => {
      const dpBtn = screen.getByTestId('DownPaymentBtn');
      expect(dpBtn).toBeInTheDocument();
      fireEvent.click(dpBtn);
    });
  });
  test('MoreOptions component for with option compatible sims selected', async () => {
    const MoreOptionsText = screen.getByText(/More options/i);
    fireEvent.click(MoreOptionsText);
    await waitFor(() => {
      const MoreOptionsId = screen.getAllByTestId('mpre-options')[4];
      fireEvent.click(MoreOptionsId);
    });
  });
  test('MoreOptions component for with option compatible sims selected', async () => {
    const MoreOptionsText = screen.getByText(/More options/i);
    fireEvent.click(MoreOptionsText);
    await waitFor(() => {
      const MoreOptionsId = screen.getAllByTestId('mpre-options')[0];
      fireEvent.click(MoreOptionsId);
    });
  });
});

describe('device model component render', () => {
  beforeAll(() => {
    window.vzdl = { page: {} };
  });
  beforeEach(() => {

    render(
      <MoreOptions
        CustomerData={customerProfile.data.customer}
        cartDetails={deviceProps.cartDetails}
        activeMtn='5185673926'
        mtn='5185673926'
        handleOk={jest.fn()}
        navigate={jest.fn()}
        productDetails={{
          deviceProduct: {
            commonInfo: {
              showPrice: true,
              displayReasonCode: true,
              showShipitToggle: true,
              flexPDPTradeInLinkEnabled: true,
              containSoftSku: false,
              dpEligible: true,
              indirect: false,
            },
          },
        }}
        isFromCPE={false}
        isRfexFlow={false}
        isNewLine={false}
        channel='OMNI-RETAIL'
        downPayment={10}
        setDownPaymentObj={jest.fn()}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });
  test('MoreOptions component shoudl render', async () => {
    const MoreOptionsText = screen.getByText(/More options/i);
    expect(isD2D()).toBe(false);
    fireEvent.click(MoreOptionsText);
    await waitFor(() => {
      const MoreOptionsId = screen.getAllByTestId('mpre-options')[0];
      fireEvent.click(MoreOptionsId);
    });
  });
});
describe('device model component render', () => {
  beforeAll(() => {
    window.vzdl = { page: {} };
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
  });
  beforeEach(() => {
    
    render(
      <MoreOptions
        CustomerData={customerProfile.data.customer}
        cartDetails={deviceProps.deviceCartDetails}
        activeMtn='5185673926'
        mtn='5185673926'
        handleOk={jest.fn()}
        navigate={jest.fn()}
        productDetails={{
          deviceProduct: {
            commonInfo: {
              showPrice: true,
              displayReasonCode: true,
              showShipitToggle: true,
              flexPDPTradeInLinkEnabled: true,
              containSoftSku: false,
              dpEligible: true,
              indirect: false,
              isD2D: false,
            },
          },
        }}
        isFromCPE={false}
        isRfexFlow={false}
        isNewLine={false}
        channel='OMNI-RETAIL'
        downPayment={10}
        setDownPaymentObj={jest.fn()}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });
  test('MoreOptions component shoudl render', async () => {
    const MoreOptionsText = screen.getByText(/More options/i);
    expect(isD2D()).toBe(false);
    fireEvent.click(MoreOptionsText);
    await waitFor(() => {
      const MoreOptionsId = screen.getAllByTestId('mpre-options')[0];
      fireEvent.click(MoreOptionsId);
    });
  });
});
describe('device model component render 1', () => {
  beforeAll(() => {
    window.vzdl = { page: {} };
  });
  beforeEach(() => {
    
    render(
      <MoreOptions
        CustomerData={customerProfile.data.customer}
        handleOk={jest.fn()}
        navigate={jest.fn()}
        productDetails={{
          deviceProduct: {
            commonInfo: {
              showPrice: true,
              displayReasonCode: true,
              showShipitToggle: true,
              flexPDPTradeInLinkEnabled: true,
              containSoftSku: false,
              dpEligible: true,
              indirect: false,
            },
          },
        }}
        isFromCPE={false}
        isRfexFlow
        isNewLine={false}
        channel='OMNI-RETAIL'
        downPayment={10}
        setDownPaymentObj={jest.fn()}
        isInStock
        
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });
  test('MoreOptions component shoudl render', async () => {
    const MoreOptionsText = screen.getByText(/More options/i);
    fireEvent.click(MoreOptionsText);
    await waitFor(() => {
      const MoreOptionsId = screen.getAllByTestId('mpre-options')[3];
      fireEvent.click(MoreOptionsId);
    });
  });
  test('MoreOptions component shoudl render', async () => {
    const MoreOptionsText = screen.getByText(/More options/i);
    fireEvent.click(MoreOptionsText);
    await waitFor(() => {
      const MoreOptionsId = screen.getAllByTestId('mpre-options')[0];
      fireEvent.click(MoreOptionsId);
    });
  });
  test('MoreOptions component shoudl render', async () => {
    const MoreOptionsText = screen.getByText(/More options/i);
    fireEvent.click(MoreOptionsText);
    await waitFor(() => {
      const MoreOptionsId = screen.getAllByTestId('mpre-options')[1];
      fireEvent.click(MoreOptionsId);
    });
  });
  test('MoreOptions component shoudl render', async () => {
    const MoreOptionsText = screen.getByText(/More options/i);
    fireEvent.click(MoreOptionsText);
    await waitFor(() => {
      const MoreOptionsId = screen.getAllByTestId('mpre-options')[3];
      fireEvent.click(MoreOptionsId);
    });
  });
});

describe('device model component render 1', () => {
  beforeAll(() => {
    window.vzdl = { page: {} };
    window.mfe={scmDeviceMfeEnable: true, isDark: true};
  });
 
  test('MoreOptions component shoudl render', async () => {
    window.mfe={scmDeviceMfeEnable: true, isDark: true};
    render(
      <MoreOptions
        CustomerData={customerProfile.data.customer}
        handleOk={jest.fn()}
        navigate={jest.fn()}
        productDetails={{
          deviceProduct: {
            commonInfo: {
              showPrice: true,
              displayReasonCode: true,
              showShipitToggle: true,
              flexPDPTradeInLinkEnabled: true,
              containSoftSku: false,
              dpEligible: true,
              indirect: false,
            },
          },
        }}
        isFromCPE={false}
        isRfexFlow
        isNewLine={false}
        channel='OMNI-RETAIL'
        downPayment={10}
        setDownPaymentObj={jest.fn()}
        isInStock
        scmDeviceEnable
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });

  test('MoreOptions component shoudl render when scmBulkDFillSimFix is enabled', async () => {
    window.mfe={scmDeviceMfeEnable: true, isDark: true};
    render(
      <MoreOptions
        CustomerData={customerProfile.data.customer}
        handleOk={jest.fn()}
        navigate={jest.fn()}
        productDetails={{
          deviceProduct: {
            compatibleSimSorIds : ['sim1'],
            commonInfo: {
              showPrice: true,
              displayReasonCode: true,
              showShipitToggle: true,
              flexPDPTradeInLinkEnabled: true,
              containSoftSku: false,
              dpEligible: true,
              indirect: false,
            },
          },
        }}
        isFromCPE={false}
        isRfexFlow
        isNewLine={false}
        channel='OMNI-RETAIL'
        downPayment={10}
        setDownPaymentObj={jest.fn()}
        isInStock
        scmDeviceEnable
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });
});

describe('device model component render with Device MFE enabled', () => {
  beforeAll(() => {
    window.vzdl = { page: {} };
    window.mfe={scmDeviceMfeEnable: true, isDark: true};
  });

  beforeEach(() => {
    
    window.mfe={scmDeviceMfeEnable: true, isDark: true};
    render(
      <MoreOptions
        CustomerData={customerProfile.data.customer}
        handleOk={jest.fn()}
        navigate={jest.fn()}
        productDetails={{
          deviceProduct: {
            commonInfo: {
              showPrice: true,
              displayReasonCode: true,
              showShipitToggle: true,
              flexPDPTradeInLinkEnabled: true,
              containSoftSku: false,
              dpEligible: true,
              indirect: false,
            },
          },
        }}
        isFromCPE={false}
        isRfexFlow
        isNewLine={false}
        channel='OMNI-RETAIL'
        downPayment={10}
        setDownPaymentObj={jest.fn()}
        CustomerProfileCommonInfo={{
          showTradeinTab: true,
        }}
        deviceContract='DPP'
        isInStock
        scmDeviceEnable
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });
  test('MoreOptions component shoudl render', async () => {
    const MoreOptionsText = screen.getByText(/More options/i);
    fireEvent.click(MoreOptionsText);
    await waitFor(() => {
      const MoreOptionsId = screen.getAllByTestId('mpre-options')[2];
      fireEvent.click(MoreOptionsId);
    });
  });
  test.skip('MoreOptions component shoudl render', async () => {
    const MoreOptionsText = screen.getByText(/More options/i);
    fireEvent.click(MoreOptionsText);
    await waitFor(() => {
      const MoreOptionsId = screen.getAllByTestId('mpre-options')[3];
      fireEvent.click(MoreOptionsId);
    });
  });
  test('MoreOptions component shoudl render', async () => {
    const MoreOptionsText = screen.getByText(/More options/i);
    fireEvent.click(MoreOptionsText);
    fireEvent.mouseDown(MoreOptionsText);
  });
  test('MoreOptions component with option TradeIn selected', async () => {
    const MoreOptionsText = screen.getByText(/More options/i);
    fireEvent.click(MoreOptionsText);
    await waitFor(() => {
      const MoreOptionsId = screen.getAllByTestId('mpre-options')[1];
      fireEvent.click(MoreOptionsId);
    });
  });
  test('MoreOptions component with option DownPayment selected',  () => {
    const MoreOptionsText = screen.getByText(/More options/i);
    fireEvent.click(MoreOptionsText);
     waitFor(() => {
      const MoreOptionsId = screen.getAllByTestId('mpre-options')[0];
      fireEvent.click(MoreOptionsId);
    });
     waitFor(() => {
      const okBtn = screen.getByText(/Ok/i);
      expect(okBtn).toBeInTheDocument();
      fireEvent.click(okBtn);
    });
  });
  test('MoreOptions component for with option compatible sims selected', async () => {
    const MoreOptionsText = screen.getByText(/More options/i);
    fireEvent.click(MoreOptionsText);
    await waitFor(() => {
      const MoreOptionsId = screen.getAllByTestId('mpre-options')[4];
      fireEvent.click(MoreOptionsId);
    });
  });
  test('MoreOptions component for with option compatible sims selected', async () => {
    const MoreOptionsText = screen.getByText(/More options/i);
    fireEvent.click(MoreOptionsText);
    await waitFor(() => {
      const MoreOptionsId = screen.getAllByTestId('mpre-options')[0];
      fireEvent.click(MoreOptionsId);
    });
  });
});

describe('MoreOptions options array', () => {
  const defaultProps = {
  productDetails: { commonInfo: {}, deviceProduct: {}, deviceSku: {} },
  CustomerData: { billAccounts: [{ mtns: [{ mtn: '123', equipmentInfos: [{}] }] }] },
  mtn: '123',
  selectedSku: 'sku1',
  setUpgradeReasonType: jest.fn(),
  deviceContract: 'MONTH_TO_MONTH',
  isRfexFlow: false,
  isNewLine: false,
  isFromCPE: false,
  orderDetails: {},
  selectedPaymentInfo: {},
  isInStock: true,
  CustomerProfileCommonInfo: {},
  cartDetails: {},
  activeMtn: '123',
  computeDPPriceBody: {},
  computeDPPriceResult: {},
  isDownPaymentAlertNeedToEnable: false,
  setIsDownPaymentAlertNeedToEnable: jest.fn(),
  setDownPaymentObj: jest.fn(),
  downPaymentObj: {},
  retailPrice: 100,
  bbyContractTerm: '',
  bbPaymentOptionsSelected: false,
};
  it('should NOT show Down Payment for deviceContract in exclusion list when isVbgAemNsaEnabled', () => {
    // deviceContract is 'ONE_YEAR', which is in the exclusion list
    isVbg.mockReturnValue(true);
    render(
      <MoreOptions
        {...defaultProps}
        deviceContract="ONE_YEAR"
      />
    );
    fireEvent.click(screen.getByText('More options'));
    // Down Payment should NOT be in the options
    expect(screen.queryByText('Down Payment')).not.toBeInTheDocument();
  });

  it('should not show Down Payment for deviceContract is MONTH_TO_MONTH when isVbgAemNsaEnabled', () => {
    // deviceContract is 'MONTH_TO_MONTH', which is NOT in the exclusion list
    isVbg.mockReturnValue(true);
    render(
      <MoreOptions
        {...defaultProps}
        deviceContract="MONTH_TO_MONTH"
      />
    );
    fireEvent.click(screen.getByText('More options'));
    // Down Payment should NOT be in the options
    expect(screen.queryByText('Down Payment')).not.toBeInTheDocument();
  });

  it('should not show Down Payment for deviceContract MONTH_TO_MONTH when isVbgAemNsaEnabled is false', () => {
    isVbg.mockReturnValue(false);
    render(
      <MoreOptions
        {...defaultProps}
        deviceContract="MONTH_TO_MONTH"
      />
    );
    fireEvent.click(screen.getByText('More options'));
    // Down Payment should NOT be in the options
    expect(screen.queryByText('Down Payment')).not.toBeInTheDocument();
  });

  it('should show Down Payment for any contract when isVbgAemNsaEnabled is false', () => {
    isVbg.mockReturnValue(false);
    const MoreOptionsReloaded = require('./MoreOptions').default;
    render(
      <MoreOptionsReloaded
        {...defaultProps}
        deviceContract="ONE_YEAR"
      />
    );
    fireEvent.click(screen.getByText('More options'));
    // Down Payment should be in the options
    expect(screen.getByText('Down Payment')).toBeInTheDocument();
  });
});
