import React from 'react';
import SmartWatchBandOptions from './SmartWatchBandOptions';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { render, screen } from '../../modules/test-utils/renderHelper';

describe('smartWatch size component render', () => {
  const props = {
    selectedSku: {},
    skus: undefined,
  };
  beforeEach(() => {
    render(<SmartWatchBandOptions {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('it should mount', () => {
    render(<SmartWatchBandOptions {...props} />);
  });
});

describe('smartWatch size component render', () => {
  const props = {
    skus: [{ color: 'red', skusGroupedBySWBand: [{ band: 'apple' }] }],
    selectedSku: { color: { displayName: 'red' }, skuFilters: { band: 'apple' } },
  };
  beforeEach(() => {
    render(<SmartWatchBandOptions {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('it should mount', () => {
    const smartWatchSizeId = screen.getByTestId('smartWatchBandOptions');
    expect(smartWatchSizeId).toBeInTheDocument();
  });
});
