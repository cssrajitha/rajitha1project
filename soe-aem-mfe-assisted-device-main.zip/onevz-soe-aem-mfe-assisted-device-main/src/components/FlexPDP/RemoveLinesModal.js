import React from 'react';
import { Button } from '@vds/buttons';
import { RemoveLineModalDiv } from '../CombinedGridwall/FlexGlobalStyledConstants';

const RemoveLinesModal = ({ setRemoveLineModal, removeLines }) => {
  const handleClick = (option) => {
    if (option === 'decline') {
      setRemoveLineModal(false);
    } else if (option === 'accept') {
      removeLines('', 'REMOVE_LINE', '', true);
    }
  };
  const overlayTitle =
    'This transaction cannot be processed due to conflicts with other items in the cart. Do you want to remove the lines instead?';

  return (
    <RemoveLineModalDiv data-testid='RemoveLinesModal'>
      <div className='removeLine-modal-inner u-borderTopGray'>
        <div className='bodyPart u-marginBottomExtraLarge'>
          <div className='bodyPartInner'>
            <div>
              <div className='removeLineMessage line-height-35 bold u-paddingTopExtraLarge'>{overlayTitle}</div>
            </div>
          </div>
        </div>
        <div className='buttonPart'>
          <Button
            data-track='Decline'
            data-testid='declineModalId'
            className='button-secondary u-marginAllSmall u-marginLeftNone'
            label='Decline'
            onClick={() => handleClick('decline')}
          />
          <Button
            data-track='Remove'
            data-testid='removeModalId'
            className='button-primary u-marginAllSmall'
            label='Remove'
            onClick={() => handleClick('accept')}
          />
        </div>
        ;
      </div>
    </RemoveLineModalDiv>
  );
};

export default RemoveLinesModal;
