import styled from 'styled-components';
import PropTypes from 'prop-types';
import { getQueryParamByName } from 'onevzsoemfeframework/DomService';
import { Title, Body } from '@vds/typography';
import { Line } from '@vds/lines';
import { RadioButtonGroup } from '@vds/radio-buttons';
import { PaddingTop16, Padding16 } from '../CombinedGridwall/FlexGlobalStyledConstants';

const PreOwnedRadioButtonStyle = styled.div`
  div[class^='RadioButtonGroupWrapper'] {
    padding-top: 7px !important;
    margin-top: 5px;
  }
`;

function PreOwnedDevice(props) {
  const {
    details,
    handlePreOwnedDeviceRadioChangeParent,
    getInventoryStatus,
    setSelectedSize,
    setSelectedColor,
    setSelectedSku,
    doCallGetSkuDetails,
    groupPreOwnedConditionSkus,
  } = props;
  const renderPreConditionOptions = (preConditionDetails) => {
    const { defaultSKU = '', childSkus = [] } = details;
    const defaultSkuDetails = childSkus.filter((sku) => {
      return sku.sorId === defaultSKU;
    });
    const defaultSkuDeviceCondition = defaultSkuDetails?.[0]?.deviceConditionDisplayName
      ? defaultSkuDetails?.[0]?.deviceConditionDisplayName
      : '';
    const otherSkuDeviceCondition = preConditionDetails?.[0]?.condition ?? '';
    const finalSelectedCondition =
      defaultSkuDeviceCondition !== '' ? defaultSkuDeviceCondition : otherSkuDeviceCondition;

    if (preConditionDetails && preConditionDetails.length > 0) {
      return (
        <PreOwnedRadioButtonStyle>
          <RadioButtonGroup
            onChange={(e) => {
              handlePreOwnedDeviceRadioChangeParent(e.target.value);
              handlePreOwnedDeviceRadioChange(e.target.value, preConditionDetails);
            }}
            defaultValue={finalSelectedCondition}
            key='preOwnedDevice_radio'
            data={preConditionDetails.map((item) => {
              const children = (
                <>
                  {item.condition && (
                    <Body size='large' bold key={`${item?.condition}-preOwned`}>
                      {item?.condition}
                    </Body>
                  )}
                  <Body>
                    <Body key={`${item?.condition}-preOwned_description`}>{item.description}</Body>
                  </Body>
                </>
              );
              return {
                name: 'condition',
                children: children,
                value: item?.condition,
                className: 'preOwned-radio-label',
              };
            })}
          />
        </PreOwnedRadioButtonStyle>
      );
    }
  };
  const handlePreOwnedDeviceRadioChange = (deviceConditionSelected, details, defaultSkuDetails) => {
    const searchFromLanding = getQueryParamByName('fromLanding') || false;
    const filteredPreOwnedCondition = details?.filter((deviceCondition) => {
      return deviceCondition?.condition === deviceConditionSelected;
    });
    const filterInStockSkus = filteredPreOwnedCondition?.[0]?.skus?.filter((sku) => {
      return searchFromLanding ? sku?.sorId === defaultSkuDetails : getInventoryStatus(sku);
    });
    const defaultSKU =
      filterInStockSkus?.length > 0 ? filterInStockSkus?.[0] : filteredPreOwnedCondition?.[0]?.skus?.[0];
    setSelectedSku(defaultSKU);
    setSelectedSize(defaultSKU?.capacity);
    setSelectedColor(defaultSKU?.color?.displayName);
    doCallGetSkuDetails(defaultSKU, 'color');
  };

  return (
    <>
      <PaddingTop16>
        <Line type='secondary' surface='light' />
      </PaddingTop16>

      <Padding16>
        <Title size='small'>Device condition</Title>
        {renderPreConditionOptions(groupPreOwnedConditionSkus)}
      </Padding16>
    </>
  );
}
export default PreOwnedDevice;

PreOwnedDevice.propTypes = {
  details: PropTypes.object,
  handlePreOwnedDeviceRadioChangeParent: PropTypes.func,
  getInventoryStatus: PropTypes.func,
  setSelectedSize: PropTypes.func,
  setSelectedColor: PropTypes.func,
  setSelectedSku: PropTypes.func,
  doCallGetSkuDetails: PropTypes.func,
  groupPreOwnedConditionSkus: PropTypes.object,
};
