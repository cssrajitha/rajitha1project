import React from 'react';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { render, screen } from '../../modules/test-utils/renderHelper';
import FccInfo from './FccInfo';

const componentProps = {
  productDetailsAemContent: { fccInfo: 'Fcc Info', fccProductIds: 'dev009' },
  details: { productId: 'dev009' },
};

describe('device model component render', () => {
  beforeAll(() => {
    window.vzdl = { page: {} };
  });

  beforeEach(() => {
    render(<FccInfo {...componentProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('Should show Fcc Info to Rep', async () => {
    const fccInfo = screen.getByText(/Fcc Info/i);
    expect(fccInfo).toBeInTheDocument();
  });
});
