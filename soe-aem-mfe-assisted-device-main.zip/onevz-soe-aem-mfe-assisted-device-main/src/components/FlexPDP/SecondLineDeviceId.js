import React, { useEffect, useRef, useState } from 'react';
import styled from 'styled-components';
import { Input } from '@vds/inputs';
import { Icon } from '@vds/icons';
import { getQueryParamByName, isIpad } from 'onevzsoemfeframework/DomService';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';

const InputWrapper = styled.div`
  display: flex;
  justify-content: space-between;
`;
const IconWrapper = styled.div`
  margin-top: 18px;
  margin-left: 15px;
`;

const SecondLineDeviceId = (props) => {
  const deviceIdFromUrl = getQueryParamByName('deviceId');
  let imei2 = props?.deviceInfo?.imei2 || getQueryParamByName('imei2') || '';
  const [skipIccidCall] = getAssistedCradlePropertyV2(['skipIccidCall']);
  const snDeviceIdErrorFixFFlag =
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.snDeviceIdErrorFixFFlag === 'TRUE';
  const editLineInfo = props?.cartDetails?.cart?.lineDetails?.lineInfo?.filter(
    (line) => line?.mtnDetails?.mobileNumber === props?.pairedMtn,
  );
  const editScenario = getQueryParamByName('isEditAndView') || getQueryParamByName('deviceFromCart');
  let dualSimId = '';
  const [isSecondNumValidation, setIsSecondNumValidation] = useState(false);
  if (editScenario && imei2 === '') {
    const dualDeviceInfo = editLineInfo?.[0]?.serviceInfo?.orderDevice?.lteVoraEquipInfo || {};
    imei2 = dualDeviceInfo?.lteVoraDeviceInfo?.deviceId;
    dualSimId = dualDeviceInfo?.lteEqpt?.iccid;
  }
  props?.setSecondNumDeviceId(imei2);
  const validationAttemptedRef = useRef(false);
  useEffect(() => {
    if (validationAttemptedRef.current) {
      return;
    }
    if ((snDeviceIdErrorFixFFlag && deviceIdFromUrl) || (!snDeviceIdErrorFixFFlag)) {
      validationAttemptedRef.current = true;
      setIsSecondNumValidation(true);
      props?.validateDeviceSimIdRequest({
        mtn: props?.pairedMtn || '',
        isCustomerProvidedEquipment: false,
        deviceId: snDeviceIdErrorFixFFlag ? deviceIdFromUrl : imei2,
        simId: '',
        cpSimCard: false,
        fromCpe: props?.fromCpe || false,
        sku: props?.deviceData?.skuId || getQueryParamByName('deviceSKU'),
        offerEligible: getQueryParamByName('offerEligible'),
        activeMtn: props?.pairedMtn,
        deviceFlow: true,
        isSecondNumLine: true,
        isSecondNumValidation,
      });
    }
  }, [deviceIdFromUrl, imei2, props?.pairedMtn, props?.deviceData, props?.validateDeviceSimIdRequest, props?.fromCpe]);

  return (
    <InputWrapper data-testid='SecondLineDeviceId'>
      <div style={{ display: 'flex', width: '330px' }}>
        <div style={{ width: '100%' }}>
          <Input
            type='text'
            iconName=''
            name='deviceId'
            id='deviceId'
            containsPii
            data-testid='InputDeviceId'
            placeholder='Enter Device ID'
            value={imei2}
            label='Enter Second number Device ID'
          />
        </div>
        <IconWrapper>
          <Icon name='barcode' size='64' disabled />
        </IconWrapper>
      </div>
      {!skipIccidCall && (
        <div style={{ width: '300px', marginRight: '35px' }}>
          <Input
            name='simId'
            id='simId'
            placeholder='Enter Sim ID'
            value={props?.secondNumSimId ? props?.secondNumSimId : dualSimId || ''}
            data-testid='InputSimId'
            required
            disabled={!isIpad()}
            label='Enter Sim ID'
          />
        </div>
      )}
    </InputWrapper>
  );
};

export default SecondLineDeviceId;
