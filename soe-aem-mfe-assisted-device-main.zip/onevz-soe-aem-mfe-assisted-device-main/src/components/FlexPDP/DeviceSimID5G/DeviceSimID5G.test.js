import { cloneDeep } from 'lodash';
import { render, screen, waitFor, fireEvent } from '../../../modules/test-utils/renderHelper';
import DeviceSimID5G from './DeviceSimID5G';
import { Context } from '../../../pages/PDP5G/PDP5gContext';

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isProd: jest.fn(),
    isIndirect: jest.fn(),
    isIpad: jest.fn(),
    isRetail: () => false,
  }),
  { virtual: true },
);
const contextValue = {
  devicePayload: {},
  setDevicePayload: jest.fn(),
  validateDeviceSimRequest: {},
  setValidateDeviceSimRequest: jest.fn(),
  deviceFromCart: {},
  customerProfile: {
    customer: {
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          billAccountNo: '1',
          mtns: [
            {
              mtn: '1234567890',
              primaryUser: {
                firstName: 'RAVI',
                lastName: 'REYES',
              },
              mobileInfoAttributes: {
                accessRoles: {
                  manager: false,
                  member: false,
                  owner: true, // intentionally set for branch test
                },
              },
              equipmentInfos: [
                {
                  deviceInfo: {
                    deviceId: '356295371550522',
                    deviceSku: 'MQ403LL/A',
                    deviceUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a',
                    productDisplayName: null,
                    category: {
                      smartphone: true,
                      tablet: false,
                      basicphone: false,
                      connectedDevice: false,
                      internetDevice: false,
                      homePC: false,
                      telematics: false,
                      virtualDevice: false,
                      WSOnly: false,
                    },
                    tradeInValue: '',
                    displayName: 'Apple iPhone 14 Plus 256GB in Purple',
                    capacity: null,
                    deviceType: {
                      backupRouter4G: null,
                      device4G: null,
                      device3G: null,
                      device5GA: null,
                      device5GE: null,
                      antenna5G: null,
                      home5G: null,
                      deviceType: null,
                      home4GLte: null,
                    },
                    numberShareCapability: '',
                    cdmaRestrictedDevice: false,
                    fixedWirelessInfos: null,
                    pairedDeviceDetails: [
                      {
                        pairedImei: '356295370120319',
                        pairedImeiMtn: '',
                        isPairedImeiActive: false,
                        isPairedMTNSameAccount: false,
                      },
                    ],
                  },
                  simInfo: {
                    simId: '89148000009189155874',
                    simSku: null,
                    skuType: 'S',
                  },
                },
              ],
              mtnDetails: {
                mtnType: '123',
              },
            },
          ],
        },
      ],
    },
  },
  cartDetails: {},
  isByodUpdate: false,
  simSwapNotificationHighRiskMsg: '',
  simSwapNotify: '',
  enableEnforceApi: false,
  ValidateDeviceSimIdResult: { status: 'fulfilled', data: {} },
  validateDeviceSimIdRequestBody: jest.fn(),
  activeMtn: '1234567890',
  isNewLine: false,
  isLocal: false,
  isDWOS: false,
  deviceIdSelected: '',
  selectedSku: { sorId: 'sku123' },
  is5GDevice: true,
  customerType: 'N',
  setdevicedata: jest.fn(),
  devicedata: {},
  LTEorCBandQualified: true,
  getSimSku: jest.fn(),
  SimSkuResult: { status: 'fulfilled', data: {} },
};

const cartDetails = {
  cart: {
    lineDetails: {
      lineInfo: [
        {
          mobileNumber: '123456789',
          itemsInfo: [
            {
              cartItems: {
                cartItem: [
                  {
                    cartItemType: 'DEVICE',
                    deviceId: 'device123',
                  },
                  {
                    cartItemType: 'SIM',
                    simId: 'sim123',
                  },
                ],
              },
            },
          ],
          lineNumber: '1234567890',
        },
      ],
    },
  },
};
const activeMtn = '1234567890';

describe(`<DeviceSimID5G/> component mount`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={contextValue}>
        <DeviceSimID5G />
      </Context.Provider>,
    );
  });
  test('should mount', () => {
    const deviceSimID5GWrapper = screen.getByTestId('DeviceSimID5G');
    expect(deviceSimID5GWrapper).toBeInTheDocument();
  });

  it('should handle ValidateDeviceSimIdResult status fulfilled', async () => {
    contextValue.ValidateDeviceSimIdResult = {
      status: 'fulfilled',
      data: { serviceBody: { serviceResponse: { context: { deviceInfo: {} } } } },
    };
    await waitFor(() => {
      expect(contextValue.setdevicedata).toHaveBeenCalled();
    });
  });

  it('should handle ValidateDeviceSimIdResult status rejected', async () => {
    contextValue.ValidateDeviceSimIdResult = {
      status: 'rejected',
      error: { data: { errors: [{ message: 'Sim is not compatible with the selected Device' }] } },
    };
    // await waitFor(() => {
    //   expect(contextValue.setdevicedata).not.toHaveBeenCalled();
    // });
  });

  it('should handle ValidateDeviceSimIdResult status rejected', async () => {
    contextValue.ValidateDeviceSimIdResult = {
      status: 'pending',
      error: { data: { errors: [{ message: 'Sim is not compatible with the selected Device' }] } },
    };
    // await waitFor(() => {
    //   expect(contextValue.setdevicedata).not.toHaveBeenCalled();
    // });
  });
  it('should handle ValidateDeviceSimIdResult status rejected', async () => {
    contextValue.ValidateDeviceSimIdResult = {
      status: 'rejected',
      isError: true,
      error: { data: { errors: [{ message: 'Sim is not compatible with the selected Device' }] } },
    };
    // await waitFor(() => {
    //   expect(contextValue.setdevicedata).not.toHaveBeenCalled();
    // });
  });

  it('should handle change in SIM ID', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: 'newSimId' } });
    expect(input.value).toBe('newSimId');
  });

  it('should handle change in Device ID', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: 'newDeviceId' } });
    expect(input.value).toBe('newDeviceId');
  });

  it.skip('should handle SIM processing message display', () => {
    expect(screen.queryByText('SIM processing only available on iPad')).not.toBeInTheDocument();
  });

  it.skip('should handle Video Assist Flow message display', () => {
    contextValue.isVideoAssistFlow = true;
    expect(
      screen.getByText('SIM processing and device changes are not available during Video Assists or Outbound Leads'),
    ).toBeInTheDocument();
  });

  it('should handle getSimSkuHandler call', async () => {
    contextValue.SimSkuResult = {
      status: 'fulfilled',
      data: { data: { simSku: { inventoryDetails: { localInventory: { isInStock: true, qtyAvailable: 1 } } } } },
    };
    await waitFor(() => {
      expect(contextValue.setdevicedata).toHaveBeenCalled();
    });
  });

  it('should handle getSimSkuHandler error', async () => {
    contextValue.SimSkuResult = { isError: true, errors: [{ message: 'Error fetching sim inventory' }] };
    // await waitFor(() => {
    //   expect(AppMessageActions.addAppMessage).toHaveBeenCalledWith('Error fetching sim inventory', 'error', true, false);
    // });
  });

  it.skip('should handle showSimProcessingMsg function', () => {
    const showSimProcessingMsg = screen.queryByText('SIM processing only available on iPad');
    expect(showSimProcessingMsg).not.toBeInTheDocument();
  });

  it('should handle validateDeviceSimIdRequestHandler function', () => {
    const payload = {
      deviceId: 'device123',
      mtn: '1234567890',
      simId: 'sim123',
      cpSimCard: false,
      fromCpe: false,
      isCustomerProvidedEquipment: false,
      deviceFlow: true,
      flowType: 'SIM',
      isDWOS: false,
      isEmbeddedSimCall: true,
    };
    contextValue.validateDeviceSimIdRequestBody(payload);
    expect(contextValue.validateDeviceSimIdRequestBody).toHaveBeenCalledWith(payload);
  });

  it('should handle handleChangeSimID function', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: 'newSimId' } });
    expect(input.value).toBe('newSimId');
  });

  it('should handle handleChangeDeviceIDs function', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: 'newDeviceId' } });
    expect(input.value).toBe('newDeviceId');
  });

  it('should handle updateDfillSimId function', () => {
    contextValue.setdevicedata({ simId: 'sim123' });
    expect(contextValue.setdevicedata).toHaveBeenCalledWith({ simId: 'sim123' });
  });

  it('should handle allowOnlyNumbers function', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: '123456' } });
    expect(input.value).toBe('123456');
  });

  it('should handle allowOnlyNumbers function', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: '' } });
    expect(input.value).toBe('');
  });

  test('Device Scan testing by entering device Id', async () => {
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
    fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    expect(deviceTextBox).toHaveValue('350669643749367');
  });
  test('Device Scan testing by entering device Id that are not allowed', async () => {
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: 'abc' } });
    fireEvent.blur(deviceTextBox, { target: { value: 'abc' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    expect(deviceTextBox).toHaveValue('abc');
  });
  test('Device Scan testing by entering device Id that are not allowed', async () => {
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: '1' } });
    fireEvent.change(deviceTextBox, { target: { value: '' } });
    fireEvent.blur(deviceTextBox, { target: { value: '' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    expect(deviceTextBox).toHaveValue('');
  });
});
describe(`<DeviceSimID5G/> component mount`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={contextValue}>
        <DeviceSimID5G />
      </Context.Provider>,
    );
  });
  test('should mount', () => {
    const deviceSimID5GWrapper = screen.getByTestId('DeviceSimID5G');
    expect(deviceSimID5GWrapper).toBeInTheDocument();
  });

  it('should handle ValidateDeviceSimIdResult status fulfilled', async () => {
    contextValue.ValidateDeviceSimIdResult = {
      status: 'fulfilled',
      data: { serviceBody: { serviceResponse: { context: { deviceInfo: {} } } } },
    };
    await waitFor(() => {
      expect(contextValue.setdevicedata).toHaveBeenCalled();
    });
  });

  it('should handle ValidateDeviceSimIdResult status rejected', async () => {
    contextValue.ValidateDeviceSimIdResult = {
      status: 'rejected',
      error: { data: { errors: [{ message: 'Sim is not compatible with the selected Device' }] } },
    };
    // await waitFor(() => {
    //   expect(contextValue.setdevicedata).not.toHaveBeenCalled();
    // });
  });

  it('should handle ValidateDeviceSimIdResult status rejected', async () => {
    contextValue.ValidateDeviceSimIdResult = {
      status: 'pending',
      error: { data: { errors: [{ message: 'Sim is not compatible with the selected Device' }] } },
    };
    // await waitFor(() => {
    //   expect(contextValue.setdevicedata).not.toHaveBeenCalled();
    // });
  });
  it('should handle ValidateDeviceSimIdResult status rejected', async () => {
    contextValue.ValidateDeviceSimIdResult = {
      status: 'rejected',
      isError: true,
      error: { data: { errors: [{ message: 'Sim is not compatible with the selected Device' }] } },
    };
    // await waitFor(() => {
    //   expect(contextValue.setdevicedata).not.toHaveBeenCalled();
    // });
  });

  it('should handle change in SIM ID', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: 'newSimId' } });
    expect(input.value).toBe('newSimId');
  });

  it('should handle change in Device ID', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: 'newDeviceId' } });
    expect(input.value).toBe('newDeviceId');
  });

  it.skip('should handle SIM processing message display', () => {
    expect(screen.queryByText('SIM processing only available on iPad')).not.toBeInTheDocument();
  });

  it('should handle Video Assist Flow message display', () => {
    contextValue.isVideoAssistFlow = true;
  });

  it('should handle getSimSkuHandler call', async () => {
    contextValue.SimSkuResult = {
      status: 'fulfilled',
      data: { data: { simSku: { inventoryDetails: { localInventory: { isInStock: true, qtyAvailable: 1 } } } } },
    };
    await waitFor(() => {
      expect(contextValue.setdevicedata).toHaveBeenCalled();
    });
  });

  it('should handle getSimSkuHandler error', async () => {
    contextValue.SimSkuResult = { isError: true, errors: [{ message: 'Error fetching sim inventory' }] };
    // await waitFor(() => {
    //   expect(AppMessageActions.addAppMessage).toHaveBeenCalledWith('Error fetching sim inventory', 'error', true, false);
    // });
  });

  it.skip('should handle showSimProcessingMsg function', () => {
    const showSimProcessingMsg = screen.queryByText('SIM processing only available on iPad');
    expect(showSimProcessingMsg).not.toBeInTheDocument();
  });

  it('should handle validateDeviceSimIdRequestHandler function', () => {
    const payload = {
      deviceId: 'device123',
      mtn: '1234567890',
      simId: 'sim123',
      cpSimCard: false,
      fromCpe: false,
      isCustomerProvidedEquipment: false,
      deviceFlow: true,
      flowType: 'SIM',
      isDWOS: false,
      isEmbeddedSimCall: true,
    };
    contextValue.validateDeviceSimIdRequestBody(payload);
    expect(contextValue.validateDeviceSimIdRequestBody).toHaveBeenCalledWith(payload);
  });

  it('should handle handleChangeSimID function', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: 'newSimId' } });
    expect(input.value).toBe('newSimId');
  });

  it('should handle handleChangeDeviceIDs function', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: 'newDeviceId' } });
    expect(input.value).toBe('newDeviceId');
  });

  it('should handle updateDfillSimId function', () => {
    contextValue.setdevicedata({ simId: 'sim123' });
    expect(contextValue.setdevicedata).toHaveBeenCalledWith({ simId: 'sim123' });
  });

  it('should handle allowOnlyNumbers function', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: '123456' } });
    expect(input.value).toBe('123456');
  });

  it('should handle allowOnlyNumbers function', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: '' } });
    expect(input.value).toBe('');
  });

  test('Device Scan testing by entering device Id', async () => {
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
    fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    expect(deviceTextBox).toHaveValue('350669643749367');
  });
  test('Device Scan testing by entering device Id that are not allowed', async () => {
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: 'abc' } });
    fireEvent.blur(deviceTextBox, { target: { value: 'abc' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    expect(deviceTextBox).toHaveValue('abc');
  });
  test('Device Scan testing by entering device Id that are not allowed', async () => {
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: '1' } });
    fireEvent.change(deviceTextBox, { target: { value: '' } });
    fireEvent.blur(deviceTextBox, { target: { value: '' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    expect(deviceTextBox).toHaveValue('');
  });
});

describe(`<DeviceSimID5G/> component mount for edti scenario`, () => {
  const editContextValues = cloneDeep(contextValue);
  editContextValues.deviceFromCart = true;
  editContextValues.cartDetails = cartDetails;
  editContextValues.activeMtn = activeMtn;
  editContextValues.SimSkuResult = {
    status: 'fulfilled',
    data: { data: { simSku: { inventoryDetails: { localInventory: { isInStock: true, qtyAvailable: 1 } } } } },
  };
  jest.mock(
    'onevzsoemfecommon/Helpers',
    () => ({
      __esModule: true,
      ...jest.requireActual('onevzsoemfecommon/Helpers'),
      getQueryParamByName: jest.fn((value) => {
        if (value === 'deviceId') return '123456789';
        if (value === 'simId') return '123456789777777777';
        return false;
      }),
      getPDPEnable: jest.fn(true),
    }),
    { virtual: true },
  );
  beforeEach(() => {
    render(
      <Context.Provider value={editContextValues}>
        <DeviceSimID5G />
      </Context.Provider>,
    );
  });
  test('should set validated device and sim IDs from cart', async () => {
    contextValue.cartDetails = cartDetails;
    contextValue.activeMtn = activeMtn;
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();
  });
});
