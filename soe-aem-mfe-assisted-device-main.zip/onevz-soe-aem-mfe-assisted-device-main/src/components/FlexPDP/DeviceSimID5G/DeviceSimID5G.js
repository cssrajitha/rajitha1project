/* eslint-disable no-else-return */
import React, { useState, useEffect, useContext } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { allowOnlyNumbers } from 'onevzsoemfecommon/Helpers/validation';
// eslint-disable-next-line you-dont-need-lodash-underscore/get
import { isEmpty } from 'lodash';
import styled from 'styled-components';
import { getQueryParamByName, isIpad, isRetail } from 'onevzsoemfeframework/DomService';
import { getUIContextPathBAU } from 'onevzsoemfecommon/Helpers';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import * as appLoaderActions from 'onevzsoemfecommon/AppLoaderActions';
import DeviceScan from '../../CombinedGridwall/DeviceScan';
import SimScan from '../DeviceSimID/SimScan';
import { Context } from '../../../pages/PDP5G/PDP5gContext';
import { getBundleNames } from '../../../pages/PDP5G/pdp5gutils';
import { inDirectValidateDeviceSimIdPayload } from '../pdputils';

const DivWrapper = styled.div`
  display: block;
`;
const DeviceWrapper = styled.div`
  display: flex;
  align-items: flex-start;
  width: 100%;
  justify-content: space-between;
`;
const IpadSimContent = styled.div`
  width: max-content;
`;
const InputWrapper = styled.div`
  display: flex;
  align-items: center;
  flex-direction: column;
  align-items: flex-start;
`;
const SIMIDWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  width: '21rem';
  padding-left: '2%';
`;

let navigate = '';

function useNavigateMFE() {
  navigate = useNavigate();
}

const DeviceSimID5G = () => {
  const {
    deviceFromCart,
    customerProfile,
    cartDetails,
    enableEnforceApi,
    ValidateDeviceSimIdResult,
    validateDeviceSimIdRequestBody,
    activeMtn,
    isNewLine = false,
    isLocal = false,
    deviceIdSelected = '',
    selectedSku,
    is5GDevice,
    customerType,
    setdevicedata,
    devicedata,
    LTEorCBandQualified,
    getSimSku,
    SimSkuResult,
    isVideoAssistFlow = false,
    devicePayload,
    setDevicePayload,
    validateDeviceSimRequest,
    setValidateDeviceSimRequest,
    isByodUpdate,
    isIndirect,
  } = useContext(Context);

  const [deviceActiveCheck, deviceActiveLoanCheck, devicePreorderCheck, iccidStatusCheck, disableEsimAtLocalInventory] =
    getAssistedCradlePropertyV2([
      'deviceActiveCheck',
      'deviceActiveLoanCheck',
      'devicePreorderCheck',
      'iccidStatusCheck',
      'disableEsimAtLocalInventory',
    ]);

  const dispatch = useDispatch();
  const [fivegTitanSkus] = getAssistedCradlePropertyV2(['fivegTitanSkus']);
  const sku = selectedSku?.sorId;
  const CustomerData = customerProfile?.customer || {};
  const channel = CustomerData?.channel || sessionStorage.getItem('channel');
  const bundles = getBundleNames(customerProfile);
  const is5GHomeSelfInstall = is5GDevice && bundles?.bundleName?.includes('5GHomeSelfInstall');
  const scanFromLanding = Boolean(getQueryParamByName('scanFromLanding'));
  const ValidateDeviceSimIdResultStatus = ValidateDeviceSimIdResult?.status;

  const deviceInfo = ValidateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo;
  const correlationId = ValidateDeviceSimIdResult?.data?.serviceHeader?.correlationId;

  const [validatedDeviceId, setValidatedDeviceId] = useState('');
  const [validatedSimId, setValidatedSimId] = useState('');
  const [deviceInput, setDeviceInput] = useState('');

  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }

  // function assignNumberRedirect() {
  //   navigate(`${getUIContextPathBAU()}/numberselection.html`);
  // }

  const simProcessOnlyIpad = !!(!isIpad() && !isNewLine);

  useEffect(() => {
    const deviceIdVal = getQueryParamByName('deviceId');
    const simIdVal = getQueryParamByName('simId');
    if (deviceIdVal) setValidatedDeviceId(deviceIdVal);
    if (simIdVal) setValidatedSimId(simIdVal);
    if (deviceFromCart) setDeviceAndSimIdHandler();
    return () => {};
  }, []);

  useEffect(() => {
    if (!isEmpty(devicedata)) {
      setValidatedDeviceId(devicedata?.deviceId);
      setValidatedSimId(devicedata?.simId);
    }
  }, [devicedata]);

  useEffect(() => {
    if (ValidateDeviceSimIdResultStatus === 'fulfilled') {
      isSingleLookUpModel();
      dispatch(appLoaderActions.hide());
    } else if (
      ValidateDeviceSimIdResultStatus === 'rejected' &&
      ValidateDeviceSimIdResult?.error?.data?.errors?.[0]?.message === 'Sim is not compatible with the selected Device'
    ) {
      setValidatedSimId('');
      dispatch(appLoaderActions.hide());
    }
  }, [ValidateDeviceSimIdResult?.data, ValidateDeviceSimIdResultStatus]);

  const setDeviceAndSimIdHandler = () => {
    const cartLineInfo = cartDetails?.cart?.lineDetails?.lineInfo || [];
    const filteredLineFromCart =
      cartLineInfo?.find((line) => line?.mobileNumber === activeMtn || line?.lineNumber === activeMtn) || {};
    const deviceFromFilteredCartLine = filteredLineFromCart?.itemsInfo?.[0]?.cartItems?.cartItem?.find(
      (item) => item?.cartItemType === 'DEVICE',
    );
    const simFromFilteredCartLine = filteredLineFromCart?.itemsInfo?.[0]?.cartItems?.cartItem?.find(
      (item) => item?.cartItemType === 'SIM',
    );

    if (deviceFromFilteredCartLine) {
      setValidatedDeviceId(deviceFromFilteredCartLine?.deviceId);
    }
    if (simFromFilteredCartLine) {
      setValidatedSimId(simFromFilteredCartLine?.simId);
    }
  };

  /* Details for Iconic Sku Start */
  const isIconicServiceSku = !!(sku && sku === 'ICONIC-SERVICE-SKU');

  const lineInfo = CustomerData?.billAccounts?.[0]?.mtns?.filter((line) => line.mtn === activeMtn);
  const isNewlyAddedLine = lineInfo?.[0]?.isNewLine === true;
  const activeMtnEqpInfo = lineInfo?.[0]?.equipmentInfos?.[0] || {};

  const { simInfo = {} } = activeMtnEqpInfo;
  const simInfoFromLanding = simInfo?.simId ? simInfo.simId : '';

  let displaySimForIconicSku = true;
  if (isIconicServiceSku === true && isNewlyAddedLine === false) {
    /* istanbul ignore else */
    if (simInfoFromLanding === '') {
      displaySimForIconicSku = false;
    }
  }

  let upgradeIneligibleFlag = false;
  if (lineInfo && lineInfo.length > 0 && lineInfo[0] && !lineInfo[0]?.isNewLine) {
    upgradeIneligibleFlag = lineInfo[0]?.lineLevelChangeEligibility?.pendingOrderDetail !== null;
  }

  const deviceSimIdFunc = () => {};

  const expandSimID = () => true;

  const showSimInfo = () => expandSimID();

  const getSimSkuHandler = (simSkupayload) => {
    getSimSku({ body: simSkupayload });
  };

  useEffect(() => {
    if (SimSkuResult?.status === 'fulfilled') {
      const requestFlowType = validateDeviceSimRequest?.data?.lines?.[0]?.device?.Flowtype;
      const inventoryDetails = SimSkuResult?.data?.data?.simSku?.inventoryDetails || {};
      if (SimSkuResult?.data?.data?.simSku && !isEmpty(inventoryDetails)) {
        const { localInventory } = inventoryDetails;
        const { isInStock = true, qtyAvailable = 0 } = localInventory;
        if (qtyAvailable > 0 && isInStock === true) {
          const simIdNotRetail = !isRetail() ? deviceInfo?.simInfo?.preferredSoftSim : '';
          const simIdSimSku = deviceInfo?.simInfo?.iccid || simIdNotRetail;

          const updateDevicedata = {
            eSimOnlyDevice:
              deviceInfo?.makeEtniPersApi && deviceInfo?.simInfo && !deviceInfo.simInfo.dfillCompatibleSim,
            skuId: deviceInfo?.deviceSku,
            mtn: deviceInfo?.mtn,
            deviceId: deviceInfo?.deviceId,
            imei1: deviceInfo?.imei1,
            skuDisplayName: deviceInfo?.skuDisplayName || '',
            simId: simIdSimSku, // Entered SIM IDx
            simLocalId: deviceInfo?.simInfo?.iccid,
            fmipLocked: deviceInfo?.fmipLocked,
            manualEntrySimId: devicePayload?.simId || '',
            cpSimCard: devicePayload?.cpSimCard,
            eid: deviceInfo?.simInfo?.eID,
            launchPackageSku: requestFlowType === 'SIM' ? deviceInfo?.simInfo?.launchPackageSku : '',
            preferredSoftSim: deviceInfo?.simInfo?.preferredSoftSim,
            etniApi: deviceInfo?.makeEtniPersApi,
            currentSimIdInRequest: devicePayload?.data?.lines?.[0]?.device?.sim?.CurrentSimid,
            invokeIdScan: deviceInfo?.invokeIdScan || '',
            correlationId,
            flowType: requestFlowType,
            simswapSessionId: deviceInfo?.simswapSessionId || '',
          };
          setdevicedata(updateDevicedata);
        } else {
          // yield put(actions.updateSimInventoryOutOfStock());
        }
      } else {
        dispatch(appMessageActions.addAppMessage('Unable to fetch sim inventory details', 'error', true, false));
      }
    } else if (SimSkuResult?.isError) {
      const errormessage = SimSkuResult?.errors?.[0]?.message;
      dispatch(appMessageActions.addAppMessage(errormessage, 'error', true, false));
    }
  }, [SimSkuResult]);

  const isSingleLookUpModel = () => {
    const { sendSimFromLanding = false } = devicePayload;
    const requestFlowType = validateDeviceSimRequest?.data?.lines?.[0]?.device?.Flowtype;
    const formattedDeviceId = devicePayload?.deviceId;
    const intentType = validateDeviceSimRequest?.cartInfo?.intent;
    const mtnNotGenerated = activeMtn?.includes('newLine');
    console.log('mtnNotGenerated', mtnNotGenerated);
    let simId;
    if (deviceInfo?.simInfo2?.iccid) simId = deviceInfo?.simInfo2?.iccid;
    else if (channel?.indexOf('OMNI-RETAIL') === -1 && !isIndirect) simId = deviceInfo?.simInfo2?.preferredSoftSim;
    else simId = '';
    // if (mtnNotGenerated) {
    //   dispatch(
    //     appMessageActions.addAppMessage(
    //       `Please generate MDN for the line ${activeMtn} to proceed`,
    //       'error',
    //       true,
    //       true,
    //       false,
    //       false,
    //       true,
    //       'Assign Number',
    //       () => {
    //         assignNumberRedirect();
    //       },
    //     ),
    //   );
    // }

    if (
      is5GDevice &&
      LTEorCBandQualified &&
      deviceInfo?.deviceSku !== undefined &&
      !fivegTitanSkus?.includes(deviceInfo?.deviceSku)
    ) {
      dispatch(appMessageActions.addAppMessage('Device does not match with the selected device', 'error', true, false));
      return;
    } else if (is5GHomeSelfInstall) {
      // 5G gift box scenario
      const skuId = deviceInfo?.giftBoxInfo?.oduSku;
      const deviceId = deviceInfo?.giftBoxInfo?.id;
      const redirectionURL = `${getUIContextPathBAU()}/pdp.html?activeMtn=${activeMtn}&deviceSKU=${skuId}&deviceId=${deviceId}&isFiveGScan=true`;
      setdevicedata(deviceInfo?.giftBoxInfo);
      navigate(redirectionURL);
      return;
    } else if (
      deviceInfo?.simInfo?.iccid !== '' &&
      requestFlowType === 'DEVICE' &&
      !devicePayload?.isEmbeddedSimCall &&
      !devicePayload?.sendSimFromLanding
    ) {
      const payloadSecondCall = {
        mtn: devicePayload.mtn,
        deviceId: deviceInfo?.deviceId,
        simId: deviceInfo?.simInfo?.iccid,
        cpSimCard: devicePayload?.cpSimCard,
        fromCpe: devicePayload?.fromCpe,
        isCustomerProvidedEquipment: false,
        deviceFlow: true,
        flowType: 'SIM',
        isDWOS: false,
        isEmbeddedSimCall: true,
      };
      validateDeviceSimIdRequestHandler(payloadSecondCall);
      return;
    } else if (
      isRetail &&
      devicePayload.flowType === 'SIM' &&
      (intentType === 'AAL' || intentType === 'BYOD') &&
      !devicePayload.isEmbeddedSimCall &&
      !devicePayload.cpSimCard
    ) {
      const launchPackageSku = deviceInfo?.simInfo?.launchPackageSku || '';

      const simInventoryRequest = {
        data: {
          sorId: launchPackageSku,
          productType: 'SIM',
          channel: 'assisted',
          mtn: devicePayload.mtn, // lookupMtn,
          // accountNumber: customerId,
          locationCode: CustomerData?.orderLocationCode, // locationCode ? locationCode : landing?.cartDetails?.cartHeader?.cartCreatorOrderLocationCode,
          intentType,
          salesFlow: true,
        },
      };
      getSimSkuHandler(simInventoryRequest);
      return;
    }
    /* istanbul ignore else */
    if (ValidateDeviceSimIdResult?.data) {
      if (sendSimFromLanding === false) {
        const etniApi = deviceInfo?.simInfo2 ? false : deviceInfo?.makeEtniPersApi;
        const eSimOnlyDevice = !!(deviceInfo?.makeEtniPersApi && !deviceInfo?.simInfo?.dfillCompatibleSim);
        const cpSimCard = (requestFlowType === 'DEVICE' && deviceInfo?.simInfo2?.iccid) || devicePayload?.cpSimCard;
        if (
          deviceInfo?.simClass4G === 'NP' &&
          (channel?.includes('OMNI-RETAIL') || channel?.includes('OMNI-INDIRECT')) &&
          deviceInfo?.simInfo2
        ) {
          setdevicedata({
            eSimOnlyDevice,
            skuId:
              deviceInfo?.simInfo2?.launchPackageSku ||
              deviceInfo?.simInfo2?.launchPackageSkuType ||
              deviceInfo?.deviceSku,
            imei1: deviceInfo?.imei1,
            skuDisplayName: deviceInfo?.simInfo2?.skuDisplayName || '',
            deviceId: deviceInfo?.simInfo2?.deviceId,
            simId,
            simLocalId: deviceInfo?.simInfo2?.iccid,
            fmipLocked: deviceInfo?.simInfo2?.fmipLocked,
            manualEntrySimId: devicePayload?.simId || '',
            cpSimCard, // If the device has inbuilt sim, set customerProvidedSim as true
            cpSimCheckboxSelected: devicePayload?.cpSimCard,
            eid: deviceInfo?.simInfo2?.eID,
            eid2: deviceInfo?.pairedImeiData?.eid || '',
            launchPackageSku: requestFlowType === 'SIM' ? deviceInfo?.simInfo2?.launchPackageSku || '' : '',
            preferredSoftSim: deviceInfo?.simInfo2?.preferredSoftSim ? deviceInfo?.simInfo2?.preferredSoftSim : '',
            ispuCompatibleSIM: deviceInfo?.simInfo2?.ispuCompatibleSIM ? deviceInfo?.simInfo2?.ispuCompatibleSIM : '',
            etniApi,
            currentSimIdInRequest: formattedDeviceId ? devicePayload?.data?.lines?.[0]?.device?.sim?.CurrentSimid : '',
            scanFromPDPLocalFlow: !!(
              isLocal &&
              scanFromLanding === false &&
              !devicePayload?.fromCpe &&
              !devicePayload?.isCustomerProvidedEquipment
            ),
            pDeviceId: deviceInfo?.simInfo?.deviceId || '',
            simClass4G: deviceInfo?.simClass4G,
            intentType,
            physicalSku: deviceInfo?.deviceSku,
            physicalSimSku: deviceInfo?.simInfo?.dfillCompatibleSim || '',
            eDeviceId: deviceInfo?.simInfo2?.deviceId || '',
          });
        } else {
          // eSim data
          setdevicedata({
            eSimOnlyDevice,
            skuId: deviceInfo?.deviceSku,
            skuDisplayName: deviceInfo?.skuDisplayName,
            imei1: deviceInfo?.imei1,
            deviceId: deviceInfo?.deviceId,
            simId: deviceInfo?.simInfo?.iccid || deviceInfo?.simInfo?.preferredSoftSim,
            simLocalId: deviceInfo?.simInfo?.iccid,
            fmipLocked: deviceInfo?.fmipLocked,
            manualEntrySimId: devicePayload?.simId,
            cpSimCard, // If the device has inbuilt sim, set customerProvidedSim as true
            cpSimCheckboxSelected: devicePayload?.cpSimCard,
            eid: deviceInfo?.simInfo?.eID,
            eid2: deviceInfo?.pairedImeiData?.eid || '',
            launchPackageSku: requestFlowType === 'SIM' ? deviceInfo?.simInfo?.launchPackageSku : '',
            preferredSoftSim: deviceInfo?.simInfo?.preferredSoftSim || '',
            ispuCompatibleSIM: deviceInfo?.simInfo?.ispuCompatibleSIM || '',
            etniApi,
            currentSimIdInRequest: formattedDeviceId ? devicePayload?.data?.lines?.[0]?.device?.sim?.CurrentSimid : '',
            scanFromPDPLocalFlow: !!(
              isLocal &&
              scanFromLanding === false &&
              !devicePayload?.fromCpe &&
              !devicePayload?.isCustomerProvidedEquipment
            ),
          });
        }
      }

      if (intentType === 'EUP' || ((intentType === 'AAL' || intentType === 'NSE') && !devicePayload?.fromCpe)) {
        const skuId = deviceInfo?.deviceSku;
        if (is5GDevice === true && !bundles?.bundleName?.includes('5GHomeSelfInstall')) {
          if (channel?.indexOf('INDIRECT') > -1 && !devicePayload?.simId) {
            return;
          }
          const redirectionURL = `${getUIContextPathBAU()}/pdp.html?activeMtn=${activeMtn}&deviceSKU=${skuId}&deviceId=${devicePayload?.deviceId}&is5GGemini=true&scanFromLanding=${scanFromLanding}`;
          navigate(redirectionURL);
        }
      }
    }
  };

  const validateDeviceSimIdRequestHandler = (payload) => {
    const isFiveG = is5GDevice;
    const payloadDeviceId = payload?.deviceId?.deviceId || payload?.deviceId;
    const mtnValue = payload?.activeMtn || payload?.mtn;
    const { sendSimFromLanding } = payload;
    const processAction = is5GHomeSelfInstall ? 'validateGiftBoxId' : 'validateDeviceSim';
    let action = 'AAL_5G';
    if (customerType === 'N') {
      action = 'NSE_5G';
    }
    let intendType = 'AAL';
    if (is5GHomeSelfInstall) {
      intendType = '5GHome';
    }
    const lineSimDetailsFromLanding = activeMtnEqpInfo?.simInfo?.simId;
    const lineDeviceDetailsFromLanding = activeMtnEqpInfo?.deviceInfo?.deviceId;
    console.log('lineDeviceDetailsFromLanding', lineDeviceDetailsFromLanding);
    const mtnType = !isEmpty(lineInfo) && lineInfo?.[0]?.mtnDetails?.mtnType ? lineInfo?.[0]?.mtnDetails?.mtnType : '';
    let flowType = 'DEVICE';
    if (payload?.simId) {
      flowType = 'SIM';
    }

    const formattedDeviceId = payloadDeviceId;
    const formattedSimId = payload.simId?.simId || payload.simId || '';
    const deviceSku = payload.sku ? payload.sku : '';
    console.log(deviceSku);
    const smartIMEI = payload.smartIMEI || false;
    const simSku = payload?.simSku;
    const cpeWthoutDevIdFlag = payload?.cpeWthoutDevIdFlag || false;

    let intent;
    /* istanbul ignore else */
    if (customerType === 'N') {
      intent = 'NSE';
    } else if (is5GHomeSelfInstall) {
      intent = '5GHome';
    } else if (isNewLine) {
      intent = 'AAL';
    }
    let CurrentSimid = '';
    /* istanbul ignore if */
    if (sendSimFromLanding) {
      CurrentSimid = lineSimDetailsFromLanding;
    }

    // For new customer flow we are setting currentSimid as empty CXTDT-595283
    if (customerType === 'N') CurrentSimid = '';
    let device;
    /* istanbul ignore else */
    if (isFiveG === true && bundles?.bundleName?.includes('5GHomeSelfInstall')) {
      device = {
        Flowtype: 'GIFTBOX',
        giftbox: {
          id: formattedDeviceId,
        },
      };
    } else if (!cpeWthoutDevIdFlag) {
      device = {
        id: formattedDeviceId,
        Flowtype: flowType,
        CurrentId: '',
        isCustomerProvidedEquipment: false,
        sku: '', // deviceSku,
        smartIMEI,
        sim: {
          id: formattedSimId,
          sku: simSku,
          isCustomerProvidedSIM: false,
          CurrentSimid,
        },
      };
    }
    const validateDeviceRequestBody = {
      cartInfo: {
        creditAppNum: null, // Todo for PDP page
        processingMTN: mtnValue,
        intent,
        processStep: 'GridWallPDP',
        processAction,
        action,
        intendType,
        locationCode: CustomerData?.orderLocationCode,
      },
      data: {
        lines: [
          {
            mtn: mtnValue,
            mtnType,
            eskuId: payload.eskuId || '',
            device,
          },
        ],
      },
      disableEsimAtLocalInventory: false,
      ...inDirectValidateDeviceSimIdPayload(
        deviceActiveCheck,
        deviceActiveLoanCheck,
        devicePreorderCheck,
        iccidStatusCheck,
        disableEsimAtLocalInventory,
      ),
    };
    // for indirect channel we are sending existing device id from landing page (AAL flow it will be empty)
    // if (isIndirect) {
    //   validateDeviceRequestBody.data.lines[0].device.existingDeviceId = lineDeviceDetailsFromLanding;
    // }
    validateDeviceSimIdRequestBody({ body: validateDeviceRequestBody, spinner: false });
    setValidateDeviceSimRequest(validateDeviceRequestBody);
    setDevicePayload(payload);
  };

  if (ValidateDeviceSimIdResult?.status === 'pending') {
    dispatch(appLoaderActions.show());
  } else if (ValidateDeviceSimIdResult?.isError) {
    dispatch(appLoaderActions.hide());
  }

  const handleChangeSimID = (e, ivrSimID) => {
    const simIdValue = ivrSimID || e?.target?.value;
    setValidatedSimId(simIdValue);
  };

  /* istanbul ignore next */
  const updateDfillSimId = (simId) => {
    setValidatedSimId(simId);
  };

  const handleChangeDeviceIDs = (e) => {
    let txtfieldVal;
    /* istanbul ignore else */
    if (e?.target?.value) {
      const input = e.target.value;
      setValidatedDeviceId(input);
      if (allowOnlyNumbers(e.target.value) && e.target.value.length <= 15) {
        if (e.target.value.length === 15) {
          setValidatedDeviceId(input);
        }
      } else {
        e.target.value = txtfieldVal || '';
      }
    } else if (e?.target?.value === '') {
      setValidatedDeviceId(e.target.value);
      // will override eSimDevice id if user clears the device id
    }
  };

  // if sim input field is disabled and desktop then show label message
  // const showSimProcessingMsg = () => !showSimInfo() && !isIpad();
  const showSimProcessingMsg = () => !isIpad();

  return (
    <div data-testid='DeviceSimID5G'>
      <DeviceWrapper>
        <SIMIDWrapper>
          <DeviceScan
            setRepSelectedSimType={deviceSimIdFunc}
            setEnableBYODbtn={deviceSimIdFunc}
            deviceIdEsimCheck={false}
            shouldDisplayESIMMessage={false}
            isPdpPage
            isProvisionalId={false}
            ScanFromLanding={false}
            upgradeIneligibleFlag={upgradeIneligibleFlag}
            sku={sku}
            isCancel={deviceSimIdFunc}
            addressValidation={{}}
            homeSalesBundles={{}}
            isCustomerProvidedEquipment={false}
            validateDeviceSimIdRequest={validateDeviceSimIdRequestHandler}
            handleChangeDeviceIDs={(e) => handleChangeDeviceIDs(e)}
            deviceId={validatedDeviceId || ''}
            fromCpe={false}
            showScanner
            isWSAPCpeError={false}
            cpeDeviceId=''
            cpeCheckboxFlag={false}
            isIndirect
            LineDeviceId=''
            appPropertiesFromSessionStorage={{}}
            customerType={customerType}
            is5GDevice={is5GDevice}
            isPaymentOptionVisible={false}
            updateEsimDialogBoxButtons={deviceSimIdFunc}
            isByodUpdate={isByodUpdate}
            CustomerData={CustomerData}
            activeMtn={activeMtn}
            isFromPDPPage
            isNewlyAddedLine={isNewlyAddedLine}
            setDisableUpdateButton={deviceSimIdFunc}
            isDisabled={isByodUpdate}
            simSkuInput=''
            deviceInput={deviceInput}
            setDeviceInput={setDeviceInput}
            simSwapNotificationHighRiskMsg=''
            simSwapNotify=''
            enableEnforceApi={enableEnforceApi}
          />
        </SIMIDWrapper>
        <InputWrapper>
          <SIMIDWrapper>
            <>
              <IpadSimContent>
                {/* {!showSimInfo() ? (
                  <InputWrapper>
                    <Input
                      name='simId'
                      id='simId'
                      placeholder='Enter Sim ID'
                      surface='light'
                      value={validatedSimId}
                      onChange={deviceSimIdFunc}
                      onBlur={deviceSimIdFunc}
                      data-testid='handleChangeSimID'
                      required
                      disabled={false}
                      label='Enter Sim ID'
                      data-track='Productdetail_simId'
                      error=''
                      errorText=''
                    />
                  </InputWrapper>
                ) : (
                  ''
                )} */}
                {(simProcessOnlyIpad || showSimProcessingMsg()) &&
                  channel !== 'OMNI-CARE' &&
                  isVideoAssistFlow === false &&
                  channel !== 'OMNI-TELESALES' && (
                    <DivWrapper>
                      <span className='u-textBold'>SIM processing only available on iPad {deviceIdSelected}</span>
                    </DivWrapper>
                  )}
                {isVideoAssistFlow === true && !(isRetail && isIpad()) && (
                  <DivWrapper>
                    <span className='u-textBold'>
                      SIM processing and device changes are not available during Video Assists or Outbound Leads
                    </span>
                  </DivWrapper>
                )}
              </IpadSimContent>
              {showSimInfo() && (
                // eslint-disable-next-line react/jsx-no-useless-fragment
                <>
                  {displaySimForIconicSku === true && (
                    <InputWrapper>
                      <SIMIDWrapper>
                        <SimScan
                          hideCPSim
                          isCustomerProvidedEquipment={false}
                          validateDeviceSimIdRequest={validateDeviceSimIdRequestHandler}
                          deviceId={validatedDeviceId || ''}
                          handleChangeSimID={(e, ivrSimId) => handleChangeSimID(e, ivrSimId)}
                          fromCpe={false}
                          isLocal={isLocal}
                          simId={validatedSimId || ''}
                          showScanner={!isByodUpdate}
                          updateDfillSimId={updateDfillSimId}
                          isDeviceBuyout={false}
                          updateShowISPUForVA={deviceSimIdFunc}
                          isVideoAssistFlow={isVideoAssistFlow}
                          getDeviceData={deviceSimIdFunc}
                          simDisabled={isByodUpdate}
                          channel={channel}
                          deviceInfo={deviceInfo}
                          validateDeviceSimRequest={validateDeviceSimRequest}
                          is5GDevice={is5GDevice}
                          isPaymentOptionVisible={false}
                          cartDetails
                          customerProfileDetails={customerProfile}
                          correlationId={correlationId}
                          handleGetUpdateOldSimId={deviceSimIdFunc}
                          simSwapFlowUpdateButtonDisabled={deviceSimIdFunc}
                          setMitekIdVerifyStatus={deviceSimIdFunc}
                          activeMtn={activeMtn}
                          isNewlyAddedLine={isNewlyAddedLine}
                          isByodUpdate={isByodUpdate}
                          isDisabled={false}
                        />
                      </SIMIDWrapper>
                    </InputWrapper>
                  )}
                </>
              )}
            </>
          </SIMIDWrapper>
        </InputWrapper>
      </DeviceWrapper>
    </div>
  );
};

export default DeviceSimID5G;
