import { cloneDeep } from 'lodash';
import { render, screen, waitFor, fireEvent } from '../../../modules/test-utils/renderHelper';
import DeviceSimID5G from './DeviceSimID5G';
import { Context } from '../../../pages/PDP5G/PDP5gContext';

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    getQueryParamByName: (value) => {
      if (value === 'deviceId') {
        return '123';
      }
      if (value === 'simId') {
        return '123';
      }
      return null;
    },
    isProd: jest.fn(),
    isIndirect: jest.fn(),
    isIpad: jest.fn(),
    isRetail: () => true,
  }),
  { virtual: true },
);
const contextValue = {
  devicePayload: {},
  setDevicePayload: jest.fn(),
  validateDeviceSimRequest: {},
  setValidateDeviceSimRequest: jest.fn(),
  deviceFromCart: {},
  customerProfile: { customer: { channel: 'OMNI-INDIRECT' } },
  cartDetails: {},
  isByodUpdate: false,
  simSwapNotificationHighRiskMsg: '',
  simSwapNotify: '',
  enableEnforceApi: false,
  ValidateDeviceSimIdResult: {
    status: 'fulfilled',
    data: {
      serviceHeader: {
        clientId: 'OMNI-RETAIL',
        statusMsg: 'SUCCESS',
        serviceName: 'SalesOrderPurchase',
        userId: '',
        statusCode: '00',
        sessionId: '',
        correlationId: 'soe-cart-2024.01.12.07.11.22-970.9509891901429',
      },
      serviceBody: {
        serviceResponse: {
          context: {
            caseId: 'SOP-13890891-C01',
            deviceInfo: {
              simInfo: {
                mfgCode: '',

                prodName: '',
                preferredSoftSim: 'DFILLUNIV5G-SA-A',

                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: 'BULKSIM5G-SA-A',
                makeEtniPersApi: false,
                deviceId: '350669643749367',
                dfillCompatibleSim: 'DFILLUNIV5G-SA-A',
                esimid: '',
                eID: '',
                iccid: '97797897987987',
                simInfo2: {
                  iccid: '',
                  launchPackageSku: '',
                },
              },
              simInfo2: {
                mfgCode: '',
                launchPackageSku: 'SMS911UZEV',
                prodName: '',
                preferredSoftSim: 'DFILLUNIV5G-SA-A',
                launchPackageSkuType: 'SMS911UZEV',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: 'BULKSIM5G-SA-A',
                makeEtniPersApi: false,
                deviceId: '350669643749367',
                dfillCompatibleSim: 'DFILLUNIV5G-SA-A',
                esimid: '',
                eID: '',
                iccid: '97797897987987',
                simInfo2: {
                  iccid: '',
                  launchPackageSku: '',
                },
              },
              invokeIdScan: '',
              deviceSimCompatible: 'N',
              deviceSimM2MPair: 'N',
              deviceESimCompatible: 'N',
              deviceESimM2MPair: 'N',
              deviceId: '350669643749367',
              color: {
                colorId: 'clr10280008',
                displayName: 'Cream',
                description: 'White',
                colorCssStyle: '#E3DECA',
              },
              imageName: 'samsung-diamond1-cream',
              imageUrlMap: {
                defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/samsung-diamond1-cream',
                largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/samsung-diamond1-cream?$device-lg$',
                mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/samsung-diamond1-cream?$device-med$',
                miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/samsung-diamond1-cream?$device-mini$',
                thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/samsung-diamond1-cream?$device-thumb$',
              },
              skuDisplayName: 'Samsung Galaxy S23 128GB in Cream',
              deviceSku: 'SMS911UZEV',
              isRestrictedDevice: 'N',
              deviceAttributes: {
                mfgCode: 'SAM',
                mfgName: 'Samsung',
                prodName: 'GALAXY S23 128 CRM',
                prodType: '5GSmartphone',
                equipModeCode: '5GE',
                equipMode: '5GDevice',
                gpsIndicator: 'Y',
                daccCode: '01975',
                deviceType: '5GE',
                deviceCategory: '5G Smartphone',
                productId: 'dev20760267',
                postpaidRestrictStartDate: '',
                prepayRestrictStartDate: '',
                wholesaleRestrictStartDate: '',
              },
              lostAndStolen: {
                lostStolen: 'N',
                nonPay: 'N',
              },
              numbershareCapability: '',
              price: {
                fullRetailPrice: {
                  originalPrice: '799.99',
                  discountedPrice: '0.0',
                  contractDuration: '0.0',
                  contractText: 'Full Retail Price',
                },
                oneYearPrice: {
                  originalPrice: '799.99',
                  discountedPrice: '0.0',
                  contractDuration: '0.0',
                  contractText: 'One Year Price',
                },
                devicePaymentPrice: [],
              },
              skipSimIdFlag: false,
              appleWatchFlag: false,
              fmipLocked: false,
              appleCarrieLock: false,
              e911AddrInd: '',
              simClass4G: 'NP',
              makeEtniPersApi: true,
              softMessages: [],
              standalonePairingEligible: true,
              deviceFamilyType: 'Phone',
              osType: 'Android',
              euiccCapable: '',
              imei1: '350669643749367',
              imei2: '352524653749369',
              productFamily: 'GALAXY S23',
              productDisplayName: 'Galaxy S23',
              pairedImeiData: {
                pairedImei: '352524653749369',
                eid: '89043051202200836223005596129497',
                sku: 'SMS911UZEV-E',
                preferredSim: '',
                devicePreferredSoftSim: 'UNIVESIM5G-SA-S',
                simClass4G: 'NR',
                euiccCapable: true,
              },
              simswapSessionId: '',
              eSIMOnly: false,
            },
          },
        },
      },
    },
  },
  validateDeviceSimIdRequestBody: jest.fn(),
  activeMtn: 'newLine',
  selectedSku: { sorId: 'sku123' },
  is5GDevice: true,
  customerType: 'N',
  setdevicedata: jest.fn(),
  devicedata: {
    deviceId: '000352066101955677',
    mtn: '2035369933',
    channel: 'OMNI-INDIRECT',
    intentType: 'EUP',
    simClass4G: 'NP',
    eDeviceId: '123',
    physicalSku: 'ABCD-E',
  },
  LTEorCBandQualified: true,
  getSimSku: jest.fn(),
  SimSkuResult: { status: 'fulfilled', data: {} },
};
const contextValueBundle = {
  devicePayload: {},
  setDevicePayload: jest.fn(),
  validateDeviceSimRequest: {},
  setValidateDeviceSimRequest: jest.fn(),
  scmDeviceEnable: true,
  deviceFromCart: {},
  customerProfile: {
    customer: {
      channel: 'OMNI-INDIRECT',
      billAccounts: [
        {
          billAccountNo: '1',
          mtns: [
            {
              mtn: 'newLine',
              primaryUser: {
                firstName: 'RAVI',
                lastName: 'REYES',
              },
              mobileInfoAttributes: {
                accessRoles: {
                  manager: false,
                  member: false,
                  owner: true, // intentionally set for branch test
                },
              },
              equipmentInfos: [
                {
                  deviceInfo: {
                    deviceId: '356295371550522',
                    deviceSku: 'MQ403LL/A',
                    deviceUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a',
                    productDisplayName: null,
                    category: {
                      smartphone: true,
                      tablet: false,
                      basicphone: false,
                      connectedDevice: false,
                      internetDevice: false,
                      homePC: false,
                      telematics: false,
                      virtualDevice: false,
                      WSOnly: false,
                    },
                    tradeInValue: '',
                    displayName: 'Apple iPhone 14 Plus 256GB in Purple',
                    capacity: null,
                    deviceType: {
                      backupRouter4G: null,
                      device4G: null,
                      device3G: null,
                      device5GA: null,
                      device5GE: null,
                      antenna5G: null,
                      home5G: null,
                      deviceType: null,
                      home4GLte: null,
                    },
                    numberShareCapability: '',
                    cdmaRestrictedDevice: false,
                    fixedWirelessInfos: null,
                    pairedDeviceDetails: [
                      {
                        pairedImei: '356295370120319',
                        pairedImeiMtn: '',
                        isPairedImeiActive: false,
                        isPairedMTNSameAccount: false,
                      },
                    ],
                  },
                  simInfo: {
                    simId: '89148000009189155874',
                    simSku: null,
                    skuType: 'S',
                  },
                },
              ],
            },
          ],
        },
      ],
    },
  },
  cartDetails: {},
  isByodUpdate: false,
  simSwapNotificationHighRiskMsg: '',
  simSwapNotify: '',
  enableEnforceApi: false,
  ValidateDeviceSimIdResult: {
    status: 'fulfilled',
    data: {
      serviceHeader: {
        clientId: 'OMNI-RETAIL',
        statusMsg: 'SUCCESS',
        serviceName: 'SalesOrderPurchase',
        userId: '',
        statusCode: '00',
        sessionId: '',
        correlationId: 'soe-cart-2024.01.12.07.11.22-970.9509891901429',
      },
      serviceBody: {
        serviceResponse: {
          context: {
            caseId: 'SOP-13890891-C01',
            deviceInfo: {
              simInfo: {
                mfgCode: '',
                launchPackageSku: 'SMS911UZEV',
                prodName: '',
                preferredSoftSim: 'DFILLUNIV5G-SA-A',
                launchPackageSkuType: 'SMS911UZEV',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: 'BULKSIM5G-SA-A',
                makeEtniPersApi: false,
                deviceId: '350669643749367',
                dfillCompatibleSim: 'DFILLUNIV5G-SA-A',
                esimid: '',
                eID: '',
                iccid: '97797897987987',
                simInfo2: {
                  iccid: '',
                  launchPackageSku: '',
                },
              },
              simInfo2: {
                mfgCode: '',

                prodName: '',
                preferredSoftSim: 'DFILLUNIV5G-SA-A',

                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: 'BULKSIM5G-SA-A',
                makeEtniPersApi: false,
                deviceId: '350669643749367',
                dfillCompatibleSim: 'DFILLUNIV5G-SA-A',
                esimid: '',
                eID: '',
                iccid: '97797897987987',
                simInfo2: {
                  iccid: '',
                  launchPackageSku: '',
                },
              },
              invokeIdScan: '',
              deviceSimCompatible: 'N',
              deviceSimM2MPair: 'N',
              deviceESimCompatible: 'N',
              deviceESimM2MPair: 'N',
              deviceId: '350669643749367',
              color: {
                colorId: 'clr10280008',
                displayName: 'Cream',
                description: 'White',
                colorCssStyle: '#E3DECA',
              },
              imageName: 'samsung-diamond1-cream',
              imageUrlMap: {
                defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/samsung-diamond1-cream',
                largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/samsung-diamond1-cream?$device-lg$',
                mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/samsung-diamond1-cream?$device-med$',
                miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/samsung-diamond1-cream?$device-mini$',
                thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/samsung-diamond1-cream?$device-thumb$',
              },
              skuDisplayName: 'Samsung Galaxy S23 128GB in Cream',
              isRestrictedDevice: 'N',
              deviceAttributes: {
                mfgCode: 'SAM',
                mfgName: 'Samsung',
                prodName: 'GALAXY S23 128 CRM',
                prodType: '5GSmartphone',
                equipModeCode: '5GE',
                equipMode: '5GDevice',
                gpsIndicator: 'Y',
                daccCode: '01975',
                deviceType: '5GE',
                deviceCategory: '5G Smartphone',
                productId: 'dev20760267',
                postpaidRestrictStartDate: '',
                prepayRestrictStartDate: '',
                wholesaleRestrictStartDate: '',
              },
              lostAndStolen: {
                lostStolen: 'N',
                nonPay: 'N',
              },
              numbershareCapability: '',
              price: {
                fullRetailPrice: {
                  originalPrice: '799.99',
                  discountedPrice: '0.0',
                  contractDuration: '0.0',
                  contractText: 'Full Retail Price',
                },
                oneYearPrice: {
                  originalPrice: '799.99',
                  discountedPrice: '0.0',
                  contractDuration: '0.0',
                  contractText: 'One Year Price',
                },
                devicePaymentPrice: [],
              },
              skipSimIdFlag: false,
              appleWatchFlag: false,
              fmipLocked: false,
              appleCarrieLock: false,
              e911AddrInd: '',
              simClass4G: 'NP',
              makeEtniPersApi: true,
              softMessages: [],
              standalonePairingEligible: true,
              deviceFamilyType: 'Phone',
              osType: 'Android',
              euiccCapable: '',
              imei1: '350669643749367',
              imei2: '352524653749369',
              productFamily: 'GALAXY S23',
              productDisplayName: 'Galaxy S23',
              pairedImeiData: {
                pairedImei: '352524653749369',
                eid: '89043051202200836223005596129497',
                sku: 'SMS911UZEV-E',
                preferredSim: '',
                devicePreferredSoftSim: 'UNIVESIM5G-SA-S',
                simClass4G: 'NR',
                euiccCapable: true,
              },
              simswapSessionId: '',
              eSIMOnly: false,
            },
          },
        },
      },
    },
  },
  validateDeviceSimIdRequestBody: jest.fn(),
  activeMtn: 'newLine',
  isNewLine: false,
  isLocal: true,
  isDWOS: false,
  deviceIdSelected: '',
  selectedSku: { sorId: 'sku123' },
  is5GDevice: true,
  customerType: 'N',
  setdevicedata: jest.fn(),
  devicedata: {
    deviceId: '000352066101955677',
    mtn: '2035369933',
    channel: 'OMNI-INDIRECT',
    intentType: 'EUP',
    simClass4G: 'NP',
    eDeviceId: '123',
    physicalSku: 'ABCD-E',
  },
  LTEorCBandQualified: true,
  getSimSku: jest.fn(),
  SimSkuResult: { status: 'fulfilled', data: {} },
};
const contextValueSelfBundle = {
  devicePayload: {},
  setDevicePayload: jest.fn(),
  validateDeviceSimRequest: {},
  setValidateDeviceSimRequest: jest.fn(),
  scmDeviceEnable: true,
  deviceFromCart: {},
  customerProfile: {
    customer: {
      channel: 'OMNI-INDIRECT',
      billAccounts: [
        {
          billAccountNo: '1',
          mtns: [
            {
              mtn: 'newLine',
              primaryUser: {
                firstName: 'RAVI',
                lastName: 'REYES',
              },
              mobileInfoAttributes: {
                accessRoles: {
                  manager: false,
                  member: false,
                  owner: true, // intentionally set for branch test
                },
              },
              equipmentInfos: [
                {
                  deviceInfo: {
                    deviceId: '356295371550522',
                    deviceSku: 'MQ403LL/A',
                    deviceUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a',
                    productDisplayName: null,
                    category: {
                      smartphone: true,
                      tablet: false,
                      basicphone: false,
                      connectedDevice: false,
                      internetDevice: false,
                      homePC: false,
                      telematics: false,
                      virtualDevice: false,
                      WSOnly: false,
                    },
                    tradeInValue: '',
                    displayName: 'Apple iPhone 14 Plus 256GB in Purple',
                    capacity: null,
                    deviceType: {
                      backupRouter4G: null,
                      device4G: null,
                      device3G: null,
                      device5GA: null,
                      device5GE: null,
                      antenna5G: null,
                      home5G: null,
                      deviceType: null,
                      home4GLte: null,
                    },
                    numberShareCapability: '',
                    cdmaRestrictedDevice: false,
                    fixedWirelessInfos: null,
                    pairedDeviceDetails: [
                      {
                        pairedImei: '356295370120319',
                        pairedImeiMtn: '',
                        isPairedImeiActive: false,
                        isPairedMTNSameAccount: false,
                      },
                    ],
                  },
                  simInfo: {
                    simId: '89148000009189155874',
                    simSku: null,
                    skuType: 'S',
                  },
                },
              ],
            },
          ],
        },
      ],
      qualificationDetails: {
        addressRequest: {
          eligibilities: {
            fiveGHomebundle: [],
            CBandSku: 'ARC-XCI55AX',
            cbandBundle: [
              {
                bundleName: '5GHomeCBandSelfSetup',
                id: '26730007',
                type: 's',
                skuId: 'ARC-XCI55AX',
              },
              {
                bundleName: '5GHomeSelfInstall',
                id: '26730003',
                type: 'p',
                skuId: 'ARC-XCI55AX',
              },
            ],
          },
        },
      },
    },
  },
  cartDetails: {},
  isByodUpdate: false,
  simSwapNotificationHighRiskMsg: '',
  simSwapNotify: '',
  enableEnforceApi: false,
  ValidateDeviceSimIdResult: {
    status: 'fulfilled',
    data: {
      serviceHeader: {
        clientId: 'OMNI-RETAIL',
        statusMsg: 'SUCCESS',
        serviceName: 'SalesOrderPurchase',
        userId: '',
        statusCode: '00',
        sessionId: '',
        correlationId: 'soe-cart-2024.01.12.07.11.22-970.9509891901429',
      },
      serviceBody: {
        serviceResponse: {
          context: {
            caseId: 'SOP-13890891-C01',
            deviceInfo: {
              simInfo: {
                mfgCode: '',
                launchPackageSku: 'SMS911UZEV',
                prodName: '',
                preferredSoftSim: 'DFILLUNIV5G-SA-A',
                launchPackageSkuType: 'SMS911UZEV',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: 'BULKSIM5G-SA-A',
                makeEtniPersApi: false,
                deviceId: '350669643749367',
                dfillCompatibleSim: 'DFILLUNIV5G-SA-A',
                esimid: '',
                eID: '',
                iccid: '97797897987987',
                simInfo2: {
                  iccid: '',
                  launchPackageSku: '',
                },
              },
              simInfo2: {
                mfgCode: '',

                prodName: '',
                preferredSoftSim: 'DFILLUNIV5G-SA-A',

                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: 'BULKSIM5G-SA-A',
                makeEtniPersApi: false,
                deviceId: '350669643749367',
                dfillCompatibleSim: 'DFILLUNIV5G-SA-A',
                esimid: '',
                eID: '',
                iccid: '97797897987987',
                simInfo2: {
                  iccid: '',
                  launchPackageSku: '',
                },
              },
              invokeIdScan: '',
              deviceSimCompatible: 'N',
              deviceSimM2MPair: 'N',
              deviceESimCompatible: 'N',
              deviceESimM2MPair: 'N',
              deviceId: '350669643749367',
              color: {
                colorId: 'clr10280008',
                displayName: 'Cream',
                description: 'White',
                colorCssStyle: '#E3DECA',
              },
              imageName: 'samsung-diamond1-cream',
              imageUrlMap: {
                defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/samsung-diamond1-cream',
                largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/samsung-diamond1-cream?$device-lg$',
                mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/samsung-diamond1-cream?$device-med$',
                miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/samsung-diamond1-cream?$device-mini$',
                thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/samsung-diamond1-cream?$device-thumb$',
              },
              skuDisplayName: 'Samsung Galaxy S23 128GB in Cream',
              isRestrictedDevice: 'N',
              deviceAttributes: {
                mfgCode: 'SAM',
                mfgName: 'Samsung',
                prodName: 'GALAXY S23 128 CRM',
                prodType: '5GSmartphone',
                equipModeCode: '5GE',
                equipMode: '5GDevice',
                gpsIndicator: 'Y',
                daccCode: '01975',
                deviceType: '5GE',
                deviceCategory: '5G Smartphone',
                productId: 'dev20760267',
                postpaidRestrictStartDate: '',
                prepayRestrictStartDate: '',
                wholesaleRestrictStartDate: '',
              },
              lostAndStolen: {
                lostStolen: 'N',
                nonPay: 'N',
              },
              numbershareCapability: '',
              price: {
                fullRetailPrice: {
                  originalPrice: '799.99',
                  discountedPrice: '0.0',
                  contractDuration: '0.0',
                  contractText: 'Full Retail Price',
                },
                oneYearPrice: {
                  originalPrice: '799.99',
                  discountedPrice: '0.0',
                  contractDuration: '0.0',
                  contractText: 'One Year Price',
                },
                devicePaymentPrice: [],
              },
              skipSimIdFlag: false,
              appleWatchFlag: false,
              fmipLocked: false,
              appleCarrieLock: false,
              e911AddrInd: '',
              simClass4G: 'NP',
              makeEtniPersApi: true,
              softMessages: [],
              standalonePairingEligible: true,
              deviceFamilyType: 'Phone',
              osType: 'Android',
              euiccCapable: '',
              imei1: '350669643749367',
              imei2: '352524653749369',
              productFamily: 'GALAXY S23',
              productDisplayName: 'Galaxy S23',
              pairedImeiData: {
                pairedImei: '352524653749369',
                eid: '89043051202200836223005596129497',
                sku: 'SMS911UZEV-E',
                preferredSim: '',
                devicePreferredSoftSim: 'UNIVESIM5G-SA-S',
                simClass4G: 'NR',
                euiccCapable: true,
              },
              simswapSessionId: '',
              eSIMOnly: false,
            },
          },
        },
      },
    },
  },
  validateDeviceSimIdRequestBody: jest.fn(),
  activeMtn: 'newLine',
  isNewLine: false,
  isLocal: true,
  isDWOS: false,
  deviceIdSelected: '',
  selectedSku: { sorId: 'sku123' },
  is5GDevice: true,
  customerType: 'N',
  setdevicedata: jest.fn(),
  devicedata: {
    deviceId: '000352066101955677',
    mtn: '2035369933',
    channel: 'OMNI-INDIRECT',
    intentType: 'EUP',
    simClass4G: 'NP',
    eDeviceId: '123',
    physicalSku: 'ABCD-E',
  },
  LTEorCBandQualified: true,
  getSimSku: jest.fn(),
  SimSkuResult: { status: 'fulfilled', data: {} },
};
const cartDetails = {
  cart: {
    lineDetails: {
      lineInfo: [
        {
          mobileNumber: '1234567890',
          itemsInfo: [
            {
              cartItems: {
                cartItem: [
                  {
                    cartItemType: 'DEVICE',
                    deviceId: 'device123',
                  },
                  {
                    cartItemType: 'SIM',
                    simId: 'sim123',
                  },
                ],
              },
            },
          ],
        },
      ],
    },
  },
};
const activeMtn = '1234567890';

describe(`<DeviceSimID5G/> component mount`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={contextValue}>
        <DeviceSimID5G />
      </Context.Provider>,
    );
  });
  test('should mount', () => {
    const deviceSimID5GWrapper = screen.getByTestId('DeviceSimID5G');
    expect(deviceSimID5GWrapper).toBeInTheDocument();
  });

  it('should handle ValidateDeviceSimIdResult status fulfilled', async () => {
    contextValue.ValidateDeviceSimIdResult = {
      status: 'fulfilled',
      data: { serviceBody: { serviceResponse: { context: { deviceInfo: {} } } } },
    };
    await waitFor(() => {
      expect(contextValue.setdevicedata).toHaveBeenCalled();
    });
  });

  it('should handle ValidateDeviceSimIdResult status fulfilled', async () => {
    contextValue.ValidateDeviceSimIdResult = {
      status: 'fulfilled',
      data: { serviceBody: { serviceResponse: { context: { deviceInfo: {} } } } },
    };
    await waitFor(() => {
      expect(contextValue.setdevicedata).toHaveBeenCalled();
    });
  });
  it('should handle ValidateDeviceSimIdResult status rejected', async () => {
    contextValue.ValidateDeviceSimIdResult = {
      status: 'rejected',
      error: { data: { errors: [{ message: 'Sim is not compatible with the selected Device' }] } },
    };
    // await waitFor(() => {
    //   expect(contextValue.setdevicedata).not.toHaveBeenCalled();
    // });
  });

  it('should handle ValidateDeviceSimIdResult status rejected', async () => {
    contextValue.ValidateDeviceSimIdResult = {
      status: 'pending',
      error: { data: { errors: [{ message: 'Sim is not compatible with the selected Device' }] } },
    };
    // await waitFor(() => {
    //   expect(contextValue.setdevicedata).not.toHaveBeenCalled();
    // });
  });
  it('should handle ValidateDeviceSimIdResult status rejected', async () => {
    contextValue.ValidateDeviceSimIdResult = {
      status: 'rejected',
      isError: true,
      error: { data: { errors: [{ message: 'Sim is not compatible with the selected Device' }] } },
    };
    // await waitFor(() => {
    //   expect(contextValue.setdevicedata).not.toHaveBeenCalled();
    // });
  });

  it('should handle change in SIM ID', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: 'newSimId' } });
    expect(input.value).toBe('newSimId');
  });

  it('should handle change in Device ID', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: 'newDeviceId' } });
    expect(input.value).toBe('newDeviceId');
  });

  it.skip('should handle SIM processing message display', () => {
    expect(screen.queryByText('SIM processing only available on iPad')).not.toBeInTheDocument();
  });

  it.skip('should handle Video Assist Flow message display', () => {
    contextValue.isVideoAssistFlow = true;
    expect(
      screen.getByText('SIM processing and device changes are not available during Video Assists or Outbound Leads'),
    ).toBeInTheDocument();
  });

  it('should handle getSimSkuHandler call', async () => {
    contextValue.SimSkuResult = {
      status: 'fulfilled',
      data: { data: { simSku: { inventoryDetails: { localInventory: { isInStock: true, qtyAvailable: 1 } } } } },
    };
    await waitFor(() => {
      expect(contextValue.setdevicedata).toHaveBeenCalled();
    });
  });

  it('should handle getSimSkuHandler error', async () => {
    contextValue.SimSkuResult = { isError: true, errors: [{ message: 'Error fetching sim inventory' }] };
    // await waitFor(() => {
    //   expect(AppMessageActions.addAppMessage).toHaveBeenCalledWith('Error fetching sim inventory', 'error', true, false);
    // });
  });

  it.skip('should handle showSimProcessingMsg function', () => {
    const showSimProcessingMsg = screen.queryByText('SIM processing only available on iPad');
    expect(showSimProcessingMsg).not.toBeInTheDocument();
  });

  it('should handle validateDeviceSimIdRequestHandler function', () => {
    const payload = {
      deviceId: 'device123',
      mtn: '1234567890',
      simId: 'sim123',
      cpSimCard: false,
      fromCpe: false,
      isCustomerProvidedEquipment: false,
      deviceFlow: true,
      flowType: 'SIM',
      isDWOS: false,
      isEmbeddedSimCall: true,
    };
    contextValue.validateDeviceSimIdRequestBody(payload);
    contextValue.customerType = 'U';
    contextValue.customerProfile.customer = {
      homeSalesAddress: {
        bundles: {
          bundleName: '5GHomeSelfInstall',
        },
      },
    };

    expect(contextValue.validateDeviceSimIdRequestBody).toHaveBeenCalledWith(payload);
  });

  it('should handle handleChangeSimID function', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: 'newSimId' } });
    expect(input.value).toBe('newSimId');
  });

  it('should handle handleChangeDeviceIDs function', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: 'newDeviceId' } });
    expect(input.value).toBe('newDeviceId');
  });

  it('should handle updateDfillSimId function', () => {
    contextValue.setdevicedata({ simId: 'sim123' });
    expect(contextValue.setdevicedata).toHaveBeenCalledWith({ simId: 'sim123' });
  });

  it('should handle allowOnlyNumbers function', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: '123456' } });
    expect(input.value).toBe('123456');
  });

  it('should handle allowOnlyNumbers function', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: '' } });
    expect(input.value).toBe('');
  });

  test('Device Scan testing by entering device Id', async () => {
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
    fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    expect(deviceTextBox).toHaveValue('350669643749367');
  });
  test('Device Scan testing by entering device Id that are not allowed', async () => {
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: 'abc' } });
    fireEvent.blur(deviceTextBox, { target: { value: 'abc' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    expect(deviceTextBox).toHaveValue('abc');
  });
  test('Device Scan testing by entering device Id that are not allowed', async () => {
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: '1' } });
    fireEvent.change(deviceTextBox, { target: { value: '' } });
    fireEvent.blur(deviceTextBox, { target: { value: '' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    expect(deviceTextBox).toHaveValue('');
  });
});
describe(`<DeviceSimID5G/> component mount`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={contextValueBundle}>
        <DeviceSimID5G />
      </Context.Provider>,
    );
  });
  test('should mount', () => {
    const deviceSimID5GWrapper = screen.getByTestId('DeviceSimID5G');
    expect(deviceSimID5GWrapper).toBeInTheDocument();
  });

  it('should handle ValidateDeviceSimIdResult status fulfilled', async () => {
    contextValueBundle.ValidateDeviceSimIdResult = {
      status: 'fulfilled',
      data: { serviceBody: { serviceResponse: { context: { deviceInfo: {} } } } },
    };
    await waitFor(() => {
      expect(contextValueBundle.setdevicedata).toHaveBeenCalled();
    });
  });

  it('should handle ValidateDeviceSimIdResult status rejected', async () => {
    contextValueBundle.ValidateDeviceSimIdResult = {
      status: 'rejected',
      error: { data: { errors: [{ message: 'Sim is not compatible with the selected Device' }] } },
    };
    // await waitFor(() => {
    //   expect(contextValueBundle.setdevicedata).not.toHaveBeenCalled();
    // });
  });

  it('should handle ValidateDeviceSimIdResult status rejected', async () => {
    contextValueBundle.ValidateDeviceSimIdResult = {
      status: 'pending',
      error: { data: { errors: [{ message: 'Sim is not compatible with the selected Device' }] } },
    };
    // await waitFor(() => {
    //   expect(contextValueBundle.setdevicedata).not.toHaveBeenCalled();
    // });
  });
  it('should handle ValidateDeviceSimIdResult status rejected', async () => {
    contextValueBundle.ValidateDeviceSimIdResult = {
      status: 'rejected',
      isError: true,
      error: { data: { errors: [{ message: 'Sim is not compatible with the selected Device' }] } },
    };
    // await waitFor(() => {
    //   expect(contextValueBundle.setdevicedata).not.toHaveBeenCalled();
    // });
  });

  it('should handle change in SIM ID', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: 'newSimId' } });
    expect(input.value).toBe('newSimId');
  });

  it('should handle change in Device ID', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: 'newDeviceId' } });
    expect(input.value).toBe('newDeviceId');
  });

  it.skip('should handle SIM processing message display', () => {
    expect(screen.queryByText('SIM processing only available on iPad')).not.toBeInTheDocument();
  });

  it.skip('should handle Video Assist Flow message display', () => {
    contextValueBundle.isVideoAssistFlow = true;
    expect(
      screen.getByText('SIM processing and device changes are not available during Video Assists or Outbound Leads'),
    ).toBeInTheDocument();
  });

  it('should handle getSimSkuHandler call', async () => {
    contextValueBundle.SimSkuResult = {
      status: 'fulfilled',
      data: { data: { simSku: { inventoryDetails: { localInventory: { isInStock: true, qtyAvailable: 1 } } } } },
    };
    await waitFor(() => {
      expect(contextValueBundle.setdevicedata).toHaveBeenCalled();
    });
  });

  it('should handle getSimSkuHandler error', async () => {
    contextValueBundle.SimSkuResult = { isError: true, errors: [{ message: 'Error fetching sim inventory' }] };
    // await waitFor(() => {
    //   expect(AppMessageActions.addAppMessage).toHaveBeenCalledWith('Error fetching sim inventory', 'error', true, false);
    // });
  });

  it.skip('should handle showSimProcessingMsg function', () => {
    const showSimProcessingMsg = screen.queryByText('SIM processing only available on iPad');
    expect(showSimProcessingMsg).not.toBeInTheDocument();
  });

  it('should handle validateDeviceSimIdRequestHandler function', () => {
    const payload = {
      deviceId: 'device123',
      mtn: '1234567890',
      simId: 'sim123',
      cpSimCard: false,
      fromCpe: false,
      isCustomerProvidedEquipment: false,
      deviceFlow: true,
      flowType: 'SIM',
      isDWOS: false,
      isEmbeddedSimCall: true,
    };
    contextValueBundle.validateDeviceSimIdRequestBody(payload);
    contextValueBundle.customerType = 'U';
    contextValueBundle.customerProfile.customer = {
      homeSalesAddress: {
        bundles: {
          bundleName: '5GHomeSelfInstall',
        },
      },
    };

    expect(contextValueBundle.validateDeviceSimIdRequestBody).toHaveBeenCalledWith(payload);
  });

  it('should handle handleChangeSimID function', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: 'newSimId' } });
    expect(input.value).toBe('newSimId');
  });

  it('should handle handleChangeDeviceIDs function', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: 'newDeviceId' } });
    expect(input.value).toBe('newDeviceId');
  });

  it('should handle updateDfillSimId function', () => {
    contextValueBundle.setdevicedata({ simId: 'sim123' });
    expect(contextValueBundle.setdevicedata).toHaveBeenCalledWith({ simId: 'sim123' });
  });

  it('should handle allowOnlyNumbers function', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: '123456' } });
    expect(input.value).toBe('123456');
  });

  it('should handle allowOnlyNumbers function', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: '' } });
    expect(input.value).toBe('');
  });

  test('Device Scan testing by entering device Id', async () => {
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
    fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    expect(deviceTextBox).toHaveValue('350669643749367');
  });
  test('Device Scan testing by entering device Id that are not allowed', async () => {
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: 'abc' } });
    fireEvent.blur(deviceTextBox, { target: { value: 'abc' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    expect(deviceTextBox).toHaveValue('abc');
  });
  test('Device Scan testing by entering device Id that are not allowed', async () => {
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: '1' } });
    fireEvent.change(deviceTextBox, { target: { value: '' } });
    fireEvent.blur(deviceTextBox, { target: { value: '' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    expect(deviceTextBox).toHaveValue('');
  });
});
describe(`<DeviceSimID5G/> component mount`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={contextValueSelfBundle}>
        <DeviceSimID5G />
      </Context.Provider>,
    );
  });
  test('should mount', () => {
    const deviceSimID5GWrapper = screen.getByTestId('DeviceSimID5G');
    expect(deviceSimID5GWrapper).toBeInTheDocument();
  });
});
describe(`<DeviceSimID5G/> component mount`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={contextValue}>
        <DeviceSimID5G />
      </Context.Provider>,
    );
  });
  test('should mount', () => {
    const deviceSimID5GWrapper = screen.getByTestId('DeviceSimID5G');
    expect(deviceSimID5GWrapper).toBeInTheDocument();
  });

  it('should handle ValidateDeviceSimIdResult status fulfilled', async () => {
    contextValue.ValidateDeviceSimIdResult = {
      status: 'fulfilled',
      data: { serviceBody: { serviceResponse: { context: { deviceInfo: {} } } } },
    };
    await waitFor(() => {
      expect(contextValue.setdevicedata).not.toHaveBeenCalled();
    });
  });

  it('should handle ValidateDeviceSimIdResult status rejected', async () => {
    contextValue.ValidateDeviceSimIdResult = {
      status: 'rejected',
      error: { data: { errors: [{ message: 'Sim is not compatible with the selected Device' }] } },
    };
    // await waitFor(() => {
    //   expect(contextValue.setdevicedata).not.toHaveBeenCalled();
    // });
  });

  it('should handle ValidateDeviceSimIdResult status rejected', async () => {
    contextValue.ValidateDeviceSimIdResult = {
      status: 'pending',
      error: { data: { errors: [{ message: 'Sim is not compatible with the selected Device' }] } },
    };
    // await waitFor(() => {
    //   expect(contextValue.setdevicedata).not.toHaveBeenCalled();
    // });
  });
  it('should handle ValidateDeviceSimIdResult status rejected', async () => {
    contextValue.ValidateDeviceSimIdResult = {
      status: 'rejected',
      isError: true,
      error: { data: { errors: [{ message: 'Sim is not compatible with the selected Device' }] } },
    };
    // await waitFor(() => {
    //   expect(contextValue.setdevicedata).not.toHaveBeenCalled();
    // });
  });

  it('should handle change in SIM ID', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: 'newSimId' } });
    expect(input.value).toBe('newSimId');
  });

  it('should handle change in Device ID', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: 'newDeviceId' } });
    expect(input.value).toBe('newDeviceId');
  });

  it.skip('should handle SIM processing message display', () => {
    expect(screen.queryByText('SIM processing only available on iPad')).not.toBeInTheDocument();
  });

  it.skip('should handle Video Assist Flow message display', () => {
    contextValue.isVideoAssistFlow = true;
    expect(
      screen.getByText('SIM processing and device changes are not available during Video Assists or Outbound Leads'),
    ).toBeInTheDocument();
  });

  it('should handle getSimSkuHandler call', async () => {
    contextValue.SimSkuResult = {
      status: 'fulfilled',
      data: { data: { simSku: { inventoryDetails: { localInventory: { isInStock: true, qtyAvailable: 1 } } } } },
    };
    await waitFor(() => {
      expect(contextValue.setdevicedata).toHaveBeenCalled();
    });
  });

  it('should handle getSimSkuHandler error', async () => {
    contextValue.SimSkuResult = { isError: true, errors: [{ message: 'Error fetching sim inventory' }] };
    // await waitFor(() => {
    //   expect(AppMessageActions.addAppMessage).toHaveBeenCalledWith('Error fetching sim inventory', 'error', true, false);
    // });
  });

  it.skip('should handle showSimProcessingMsg function', () => {
    const showSimProcessingMsg = screen.queryByText('SIM processing only available on iPad');
    expect(showSimProcessingMsg).not.toBeInTheDocument();
  });

  it('should handle validateDeviceSimIdRequestHandler function', () => {
    const payload = {
      deviceId: 'device123',
      mtn: '1234567890',
      simId: 'sim123',
      cpSimCard: false,
      fromCpe: false,
      isCustomerProvidedEquipment: false,
      deviceFlow: true,
      flowType: 'SIM',
      isDWOS: false,
      isEmbeddedSimCall: true,
    };
    contextValue.validateDeviceSimIdRequestBody(payload);
    contextValue.customerType = 'U';
    contextValue.customerProfile.customer = {
      homeSalesAddress: {
        bundles: {
          bundleName: '5GHomeSelfInstall',
        },
      },
    };

    expect(contextValue.validateDeviceSimIdRequestBody).toHaveBeenCalledWith(payload);
  });

  it('should handle handleChangeSimID function', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: 'newSimId' } });
    expect(input.value).toBe('newSimId');
  });

  it('should handle handleChangeDeviceIDs function', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: 'newDeviceId' } });
    expect(input.value).toBe('newDeviceId');
  });

  it('should handle updateDfillSimId function', () => {
    contextValue.setdevicedata({ simId: 'sim123' });
    expect(contextValue.setdevicedata).toHaveBeenCalledWith({ simId: 'sim123' });
  });

  it('should handle allowOnlyNumbers function', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: '123456' } });
    expect(input.value).toBe('123456');
  });

  it('should handle allowOnlyNumbers function', async () => {
    const input = await screen.findByRole('textbox', {
      name: 'Enter Sim ID',
    });
    fireEvent.change(input, { target: { value: '' } });
    expect(input.value).toBe('');
  });

  test('Device Scan testing by entering device Id', async () => {
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
    fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    expect(deviceTextBox).toHaveValue('350669643749367');
  });
  test('Device Scan testing by entering device Id that are not allowed', async () => {
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: 'abc' } });
    fireEvent.blur(deviceTextBox, { target: { value: 'abc' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    expect(deviceTextBox).toHaveValue('abc');
  });
  test('Device Scan testing by entering device Id that are not allowed', async () => {
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: '1' } });
    fireEvent.change(deviceTextBox, { target: { value: '' } });
    fireEvent.blur(deviceTextBox, { target: { value: '' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    expect(deviceTextBox).toHaveValue('');
  });
});
describe(`<DeviceSimID5G/> component mount for edti scenario iconic service sku`, () => {
  const editContextValues = cloneDeep(contextValue);
  editContextValues.deviceFromCart = true;
  editContextValues.cartDetails = cartDetails;
  editContextValues.activeMtn = activeMtn;
  editContextValues.selectedSku.sorId = 'ICONIC-SERVICE-SKU';
  jest.mock(
    'onevzsoemfecommon/Helpers',
    () => ({
      __esModule: true,
      ...jest.requireActual('onevzsoemfecommon/Helpers'),
      getQueryParamByName: jest.fn((value) => {
        if (value === 'deviceId') return '123456789';
        if (value === 'simId') return '123456789777777777';
        return false;
      }),
      getPDPEnable: jest.fn(true),
    }),
    { virtual: true },
  );
  beforeEach(() => {
    render(
      <Context.Provider value={editContextValues}>
        <DeviceSimID5G />
      </Context.Provider>,
    );
  });
  test('should set validated device and sim IDs from cart', async () => {
    contextValue.cartDetails = cartDetails;
    contextValue.activeMtn = activeMtn;
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();
  });
});
describe(`<DeviceSimID5G/> component mount for device flow type`, () => {
  const editContextValues = cloneDeep(contextValue);
  editContextValues.cartDetails = cartDetails;
  editContextValues.activeMtn = activeMtn;
  editContextValues.is5GDevice = false;
  editContextValues.validateDeviceSimRequest = { data: { lines: [{ device: { Flowtype: 'DEVICE' } }] } };
  jest.mock(
    'onevzsoemfecommon/Helpers',
    () => ({
      __esModule: true,
      ...jest.requireActual('onevzsoemfecommon/Helpers'),
      getQueryParamByName: jest.fn((value) => {
        if (value === 'deviceId') return '123456789';
        if (value === 'simId') return '123456789777777777';
        return false;
      }),
      getPDPEnable: jest.fn(true),
    }),
    { virtual: true },
  );
  beforeEach(() => {
    render(
      <Context.Provider value={editContextValues}>
        <DeviceSimID5G />
      </Context.Provider>,
    );
  });
  test('should set validated device and sim IDs from cart', async () => {
    contextValue.cartDetails = cartDetails;
    contextValue.activeMtn = activeMtn;
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();
  });
});
describe(`<DeviceSimID5G/> component mount for sim flow type`, () => {
  const editContextValues = cloneDeep(contextValue);
  editContextValues.cartDetails = cartDetails;
  editContextValues.activeMtn = activeMtn;
  editContextValues.is5GDevice = false;
  editContextValues.validateDeviceSimRequest = {
    data: { lines: [{ device: { Flowtype: 'SIM' } }] },
    cartInfo: { intent: 'BYOD' },
  };
  editContextValues.devicePayload = { flowType: 'SIM' };
  editContextValues.SimSkuResult = {
    status: 'fulfilled',
    data: { data: { simSku: { inventoryDetails: { localInventory: {} } } } },
  };
  jest.mock(
    'onevzsoemfecommon/Helpers',
    () => ({
      __esModule: true,
      ...jest.requireActual('onevzsoemfecommon/Helpers'),
      getQueryParamByName: jest.fn((value) => {
        if (value === 'deviceId') return '123456789';
        if (value === 'simId') return '123456789777777777';
        return false;
      }),
      getPDPEnable: jest.fn(true),
    }),
    { virtual: true },
  );
  beforeEach(() => {
    render(
      <Context.Provider value={editContextValues}>
        <DeviceSimID5G />
      </Context.Provider>,
    );
  });
  test('should set validated device and sim IDs from cart', async () => {
    contextValue.cartDetails = cartDetails;
    contextValue.activeMtn = activeMtn;
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();
  });
});
describe(`<DeviceSimID5G/> component mount for sim flow type`, () => {
  const editContextValues = cloneDeep(contextValue);
  editContextValues.cartDetails = cartDetails;
  editContextValues.activeMtn = activeMtn;
  editContextValues.is5GDevice = false;
  editContextValues.validateDeviceSimRequest = {
    data: { lines: [{ device: { Flowtype: 'SIM' } }] },
    cartInfo: { intent: 'BYOD' },
  };
  editContextValues.devicePayload = { flowType: 'SIM' };
  editContextValues.SimSkuResult = {
    status: 'fulfilled',
    data: { data: { simSku: { inventoryDetails: { localInventory: { isInStock: true, qtyAvailable: 1 } } } } },
  };
  jest.mock(
    'onevzsoemfecommon/Helpers',
    () => ({
      __esModule: true,
      ...jest.requireActual('onevzsoemfecommon/Helpers'),
      getQueryParamByName: jest.fn((value) => {
        if (value === 'deviceId') return '123456789';
        if (value === 'simId') return '123456789777777777';
        return false;
      }),
      getPDPEnable: jest.fn(true),
    }),
    { virtual: true },
  );
  beforeEach(() => {
    render(
      <Context.Provider value={editContextValues}>
        <DeviceSimID5G />
      </Context.Provider>,
    );
  });
  test('should set validated device and sim IDs from cart', async () => {
    contextValue.cartDetails = cartDetails;
    contextValue.activeMtn = activeMtn;
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();
  });
});
describe(`<DeviceSimID5G/> component mount for sim flow type`, () => {
  const editContextValues = cloneDeep(contextValue);
  editContextValues.cartDetails = cartDetails;
  editContextValues.activeMtn = activeMtn;
  editContextValues.is5GDevice = false;
  editContextValues.validateDeviceSimRequest = {
    data: { lines: [{ device: { Flowtype: 'DEVICE' } }] },
    cartInfo: { intent: 'BYOD' },
  };
  editContextValues.scmDeviceEnable = false;
  editContextValues.devicePayload = { isEmbeddedSimCall: true };
  editContextValues.SimSkuResult = {
    status: 'fulfilled',
    data: { data: { simSku: { inventoryDetails: { localInventory: { isInStock: true, qtyAvailable: 1 } } } } },
  };
  jest.mock(
    'onevzsoemfecommon/Helpers',
    () => ({
      __esModule: true,
      ...jest.requireActual('onevzsoemfecommon/Helpers'),
      getQueryParamByName: jest.fn((value) => {
        if (value === 'deviceId') return '123456789';
        if (value === 'simId') return '123456789777777777';
        return false;
      }),
      getPDPEnable: jest.fn(true),
    }),
    { virtual: true },
  );
  beforeEach(() => {
    render(
      <Context.Provider value={editContextValues}>
        <DeviceSimID5G />
      </Context.Provider>,
    );
  });
  test('should set validated device and sim IDs from cart', async () => {
    contextValue.cartDetails = cartDetails;
    contextValue.activeMtn = activeMtn;
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();
  });
});
describe(`<DeviceSimID5G/> component mount for sim flow type`, () => {
  const editContextValues = cloneDeep(contextValue);
  editContextValues.cartDetails = cartDetails;
  editContextValues.activeMtn = activeMtn;
  editContextValues.is5GDevice = false;
  editContextValues.ValidateDeviceSimIdResult = {
    status: 'fulfilled',
    data: { serviceBody: { serviceResponse: { context: { deviceInfo: { simClass4G: 'NP', simInfo2: {} } } } } },
  };
  editContextValues.validateDeviceSimRequest = { data: { lines: [{ device: { Flowtype: 'SIM' } }] } };
  editContextValues.scmDeviceEnable = false;
  editContextValues.devicePayload = { isEmbeddedSimCall: true, deviceId: '123' };
  editContextValues.SimSkuResult = {
    status: 'fulfilled',
    data: { data: { simSku: { inventoryDetails: { localInventory: { isInStock: true, qtyAvailable: 1 } } } } },
  };
  jest.mock(
    'onevzsoemfecommon/Helpers',
    () => ({
      __esModule: true,
      ...jest.requireActual('onevzsoemfecommon/Helpers'),
      getQueryParamByName: jest.fn((value) => {
        if (value === 'deviceId') return '123456789';
        if (value === 'simId') return '123456789777777777';
        return false;
      }),
      getPDPEnable: jest.fn(true),
    }),
    { virtual: true },
  );
  beforeEach(() => {
    render(
      <Context.Provider value={editContextValues}>
        <DeviceSimID5G />
      </Context.Provider>,
    );
  });
  test('should set validated device and sim IDs from cart', async () => {
    contextValue.cartDetails = cartDetails;
    contextValue.activeMtn = activeMtn;
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();
  });
});
describe(`<DeviceSimID5G/> component mount for sim flow type`, () => {
  const editContextValues = cloneDeep(contextValue);
  editContextValues.cartDetails = cartDetails;
  editContextValues.activeMtn = activeMtn;
  editContextValues.is5GDevice = false;
  editContextValues.ValidateDeviceSimIdResult = {
    status: 'fulfilled',
    data: { serviceBody: { serviceResponse: { context: { deviceInfo: {} } } } },
  };
  editContextValues.validateDeviceSimRequest = { data: { lines: [{ device: { Flowtype: 'SIM' } }] } };
  editContextValues.scmDeviceEnable = false;
  editContextValues.devicePayload = { isEmbeddedSimCall: true, deviceId: '123' };
  editContextValues.SimSkuResult = {
    status: 'fulfilled',
    data: { data: { simSku: { inventoryDetails: { localInventory: { isInStock: true, qtyAvailable: 1 } } } } },
  };
  jest.mock(
    'onevzsoemfecommon/Helpers',
    () => ({
      __esModule: true,
      ...jest.requireActual('onevzsoemfecommon/Helpers'),
      getQueryParamByName: jest.fn((value) => {
        if (value === 'deviceId') return '123456789';
        if (value === 'simId') return '123456789777777777';
        return false;
      }),
      getPDPEnable: jest.fn(true),
    }),
    { virtual: true },
  );
  beforeEach(() => {
    render(
      <Context.Provider value={editContextValues}>
        <DeviceSimID5G />
      </Context.Provider>,
    );
  });
  test('should set validated device and sim IDs from cart', async () => {
    contextValue.cartDetails = cartDetails;
    contextValue.activeMtn = activeMtn;
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();
  });
});
describe(`<DeviceSimID5G/> component mount for sim flow type`, () => {
  const editContextValues = cloneDeep(contextValue);
  editContextValues.cartDetails = cartDetails;
  editContextValues.activeMtn = activeMtn;
  editContextValues.is5GDevice = false;
  editContextValues.ValidateDeviceSimIdResult = {
    status: 'fulfilled',
    data: { serviceBody: { serviceResponse: { context: { deviceInfo: {} } } } },
  };
  editContextValues.validateDeviceSimRequest = {
    data: { lines: [{ device: { Flowtype: 'SIM' } }] },
    cartInfo: { intent: 'NSE' },
  };
  editContextValues.scmDeviceEnable = false;
  editContextValues.devicePayload = { isEmbeddedSimCall: true, deviceId: '123', sendSimFromLanding: true };
  editContextValues.SimSkuResult = {
    status: 'fulfilled',
    data: { data: { simSku: { inventoryDetails: { localInventory: { isInStock: true, qtyAvailable: 1 } } } } },
  };
  jest.mock(
    'onevzsoemfecommon/Helpers',
    () => ({
      __esModule: true,
      ...jest.requireActual('onevzsoemfecommon/Helpers'),
      getQueryParamByName: jest.fn((value) => {
        if (value === 'deviceId') return '123456789';
        if (value === 'simId') return '123456789777777777';
        return false;
      }),
      getPDPEnable: jest.fn(true),
    }),
    { virtual: true },
  );
  beforeEach(() => {
    render(
      <Context.Provider value={editContextValues}>
        <DeviceSimID5G />
      </Context.Provider>,
    );
  });
  test('should set validated device and sim IDs from cart', async () => {
    contextValue.cartDetails = cartDetails;
    contextValue.activeMtn = activeMtn;
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();
  });
});
describe(`<DeviceSimID5G/> component mount for sim flow type`, () => {
  const editContextValues = cloneDeep(contextValue);
  editContextValues.cartDetails = cartDetails;
  editContextValues.activeMtn = activeMtn;
  editContextValues.is5GDevice = true;
  editContextValues.LTEorCBandQualified = false;
  editContextValues.ValidateDeviceSimIdResult = {
    status: 'fulfilled',
    data: { serviceBody: { serviceResponse: { context: { deviceInfo: {} } } } },
  };
  editContextValues.validateDeviceSimRequest = {
    data: { lines: [{ device: { Flowtype: 'SIM' } }] },
    cartInfo: { intent: 'NSE' },
  };
  editContextValues.scmDeviceEnable = false;
  editContextValues.devicePayload = { isEmbeddedSimCall: true, deviceId: '123', sendSimFromLanding: true };
  editContextValues.SimSkuResult = {
    status: 'fulfilled',
    data: { data: { simSku: { inventoryDetails: { localInventory: { isInStock: true, qtyAvailable: 1 } } } } },
  };
  jest.mock(
    'onevzsoemfecommon/Helpers',
    () => ({
      __esModule: true,
      ...jest.requireActual('onevzsoemfecommon/Helpers'),
      getQueryParamByName: jest.fn((value) => {
        if (value === 'deviceId') return '123456789';
        if (value === 'simId') return '123456789777777777';
        return false;
      }),
      getPDPEnable: jest.fn(true),
    }),
    { virtual: true },
  );
  beforeEach(() => {
    render(
      <Context.Provider value={editContextValues}>
        <DeviceSimID5G />
      </Context.Provider>,
    );
  });
  test('should set validated device and sim IDs from cart', async () => {
    contextValue.cartDetails = cartDetails;
    contextValue.activeMtn = activeMtn;
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();
  });
});
describe(`<DeviceSimID5G/> component mount for sim flow type`, () => {
  const editContextValues = cloneDeep(contextValue);
  editContextValues.cartDetails = cartDetails;
  editContextValues.activeMtn = activeMtn;
  editContextValues.is5GDevice = true;
  editContextValues.LTEorCBandQualified = false;
  editContextValues.ValidateDeviceSimIdResult = {
    status: 'fulfilled',
    data: { serviceBody: { serviceResponse: { context: { deviceInfo: {} } } } },
  };
  editContextValues.validateDeviceSimRequest = {
    data: { lines: [{ device: { Flowtype: 'SIM' } }] },
    cartInfo: { intent: 'NSE' },
  };
  editContextValues.scmDeviceEnable = false;
  editContextValues.devicePayload = {
    isEmbeddedSimCall: true,
    deviceId: '123',
    sendSimFromLanding: true,
    simId: '123',
  };
  editContextValues.SimSkuResult = {
    status: 'fulfilled',
    data: { data: { simSku: { inventoryDetails: { localInventory: { isInStock: true, qtyAvailable: 1 } } } } },
  };
  jest.mock(
    'onevzsoemfecommon/Helpers',
    () => ({
      __esModule: true,
      ...jest.requireActual('onevzsoemfecommon/Helpers'),
      getQueryParamByName: jest.fn((value) => {
        if (value === 'deviceId') return '123456789';
        if (value === 'simId') return '123456789777777777';
        return false;
      }),
      getPDPEnable: jest.fn(true),
    }),
    { virtual: true },
  );
  beforeEach(() => {
    render(
      <Context.Provider value={editContextValues}>
        <DeviceSimID5G />
      </Context.Provider>,
    );
  });
  test('should set validated device and sim IDs from cart', async () => {
    contextValue.cartDetails = cartDetails;
    contextValue.activeMtn = activeMtn;
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();
  });
});
