import React from 'react';
import RemoveLinesModal from './RemoveLinesModal';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { render, screen, fireEvent } from '../../modules/test-utils/renderHelper';

describe('smartWatch size component render', () => {
  const props = {
    setRemoveLineModal: jest.fn(),
    removeLines: jest.fn(),
  };
  beforeEach(() => {
    render(<RemoveLinesModal {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('it should mount', () => {
    render(<RemoveLinesModal {...props} />);
  });
});

describe('RemoveLinesModal component render', () => {
  const props = {
    setRemoveLineModal: jest.fn(),
    removeLines: jest.fn(),
  };
  beforeEach(() => {
    render(<RemoveLinesModal {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('it should mount', () => {
    const RemoveLinesModalId = screen.getByTestId('RemoveLinesModal');
    expect(RemoveLinesModalId).toBeInTheDocument();
  });
  test('it should mount', () => {
    const declineModalId = screen.getByTestId('declineModalId');
    expect(declineModalId).toBeInTheDocument();
    fireEvent.click(declineModalId);
  });
  test('it should mount', () => {
    const removeModalId = screen.getByTestId('removeModalId');
    expect(removeModalId).toBeInTheDocument();
    fireEvent.click(removeModalId);
  });
});
