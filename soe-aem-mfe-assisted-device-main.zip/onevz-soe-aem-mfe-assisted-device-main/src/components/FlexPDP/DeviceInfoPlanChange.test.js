/* eslint-disable no-import-assign */
/* eslint-disable no-promise-executor-return */
// eslint-disable-next-line you-dont-need-lodash-underscore/get
import { get as getProp } from 'lodash';
import { executeShellFunction } from 'onevzsoemfeframework/DomService';
import { render, screen, fireEvent } from '../../modules/test-utils/renderHelper';
import DeviceInfo from './DeviceInfo';
import { CHANNELS, setupChannel } from '../../modules/test-utils/utils';
import protectionFeatures from '../../pages/PDP/mocks/api/getProtectionFeatures.json';
import cartDetails from '../../pages/PDP/mocks/api/retrieveCart.json';
import customerProfileDetails from '../../pages/PDP/mocks/api/customerProfile.json';
import getSkuDetails from '../../pages/PDP/mocks/api/getSkuDetails.json';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { setupServer } from '../../pages/PDP/mocks/setupServer';
import mockDeviceInfoCredit from './mocks/mockDeviceInfoCredit.json';
import dropshipSkuDetailsResponse from '../../pages/PDP/mocks/api/dropshipSkuDetailsResponse.json';

mockDeviceInfoCredit.fullRetailPrice = {
  allPromotions: [{ discountMonthlyPrice: '234' }],
  originalPrice: 1199.99,
  contractText: 'Full Retail Price',
};
jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => true,
  }),
  { virtual: true },
);
const mockBByData = {
  storeId: '0281',
  upc: '400055816159',
  deviceSku: '5581615',
  priceInfo: [
    {
      priceId: 'cnt302',
      activationType: 'upgrade',
      purchaseType: 'FINANCED',
      contractTerm: 36,
      regularPrice: 8.33,
      currentPrice: 8.33,
      taxBasis: 299.99,
      downPaymentAmount: 0.0,
      bbyDownPayment: 0.0,
    },
    {
      priceId: 'cnt302',
      activationType: 'upgrade',
      purchaseType: 'FULL_SRP',
      contractTerm: 1,
      regularPrice: 299.99,
      currentPrice: 299.99,
      taxBasis: 299.99,
      downPaymentAmount: 0.0,
      bbyDownPayment: 0.0,
    },
    {
      priceId: 'cnt301',
      activationType: 'new',
      purchaseType: 'FINANCED',
      contractTerm: 36,
      regularPrice: 8.33,
      currentPrice: 8.33,
      taxBasis: 299.99,
      downPaymentAmount: 0.0,
      bbyDownPayment: 0.0,
    },
    {
      priceId: 'cnt301',
      activationType: 'new',
      purchaseType: 'FULL_SRP',
      contractTerm: 1,
      regularPrice: 299.99,
      currentPrice: 299.99,
      taxBasis: 299.99,
      downPaymentAmount: 0.0,
      bbyDownPayment: 0.0,
    },
  ],
};
jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => false,
    isIpad: () => true,
    executeShellFunction: jest
      .fn()
      .mockImplementation(() => global.window.BbyDevicePricingDetails(JSON.stringify(mockBByData))),
  }),
  { virtual: true },
);

jest.mock('onevzsoemfecommon/CommonService', () => ({
  ...jest.requireActual('onevzsoemfecommon/CommonService'),
  useLazyUpdateConsentQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: false,
      isError: true,
      isFetching: false,
      error: { name: 'System Error', code: '400', Message: 'Could not get device details' },
    },
  ],
}));
jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => true,
  }),
  { virtual: true },
);
// jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
//   ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
//   useLazyGetDevicePricingEligibilityQuery: () => [
//     () => {},
//     {
//       status: 'fulfilled',
//       isUninitialized: false,
//       isLoading: false,
//       isSuccess: true,
//       isError: false,
//       isFetching: true,
//       data: { dpMessage: { message: '' } },
//     },
//   ],
// }));
jest.mock(
  '../../modules/services/APIService/APIServiceHooks',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
      useLazyEligibleNumberShareListQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                status: 'Success',
                payload: {
                  deviceDetailsAndOffers: {
                    displayName:
                      'Apple Watch Series 9 GPS + Cellular 41mm Pink Aluminum Case with Light Pink Sport Band - S/M',
                    sorId: 'MRHY3LL/A',
                    color: 'Pink (Aluminum)',
                    imageURL:
                      'https://ss7.vzw.com/is/image/VerizonWireless/apple-watch-series-9-gps-cellular-41mm-pink-aluminum-case-light-pink-sport-band-mrhy3ll-a-a',
                    supportsAllVZProtectFeatures: false,
                    eligibleNumberShareOS: ['Apple iOS'],
                    smartLocator: false,
                  },
                  mandatoryPairingNeeded: false,
                  numberShareEligibleDevices: [
                    {
                      customerName: 'RAVI JETER',
                      nickName: 'RAVI-7979',
                      mtn: '5155547979',
                      deviceDisplayName: 'IPHONE 13 MINI 128 MIDNIGHT',
                      deviceImageUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-mini-midnight',
                      currentConnectedDevices: 0,
                      maxConnectedDevicesAllowed: 5,
                      preSelect: true,
                      trunkMtn: '5155547979',
                    },
                  ],
                  mtn: '5154529414',
                  lineActivityType: 'AAL',
                  watchToWatchUpgrade: false,
                  currentPaired: false,
                  accountPairedDevice: {
                    mtn: '12345678',
                  },
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
      useLazyGetRetrieveURCodeQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                meta: {
                  timestamp: 1714739048101,
                  cxpCorrelationId:
                    '2024-05-03T12:24:08.+0000:6d760cb7d9fbe0b1:cxp-shopping-services-684fb47569-9nqsc:nssit2',
                },
                data: {
                  retrieveURCforCartMtnList: {
                    mtnUpgradeReasonCodes: [
                      {
                        mtn: '2697161703',
                        upgradeReasonCodes: [
                          {
                            code: 'MA',
                            description: 'Manager Exception with non-working equipment',
                            contractTermDetails: {
                              contractTerm: 'VERIZON_EDGE',
                            },
                            defaultReasonCode: false,
                          },
                          {
                            code: 'WA',
                            description: 'WFG RETURN - DEVICE PAYMENT PRICE',
                            contractTermDetails: {
                              contractTerm: 'VERIZON_EDGE',
                            },
                            defaultReasonCode: true,
                          },
                        ],
                      },
                    ],
                  },
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
      useLazyGetDevicePricingEligibilityQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                deviceFinanceLimit: 2000.0,
                totalFinanceLimit: 4864.59,
                isDevicePaymentEligible: true,
                isDevicePaymentPending: false,
                custTypeCode: 'PE',
                downPaymentPercentage: 0,
                inEligibleMessage: 'CUSTOMER HAS A PAST DUE BALANCE GREATER THAN  $ 24.99',
                isConditionalEligibility: true,
                dpMessage: {
                  message:
                    'You are prequalified for Device payment with $2000.00 Device finance limit and $4864.59 Total finance limit remaining',
                  type: 'WARNING',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      dpTermPrices: {
                        firstMonthPrice: 16.85,
                        remainingMonthPrice: 16.66,
                        dpTerm: 30,
                        downPayment: 0.0,
                      },
                    },
                    {
                      dpTermPrices: {
                        firstMonthPrice: 20.9,
                        remainingMonthPrice: 20.83,
                        dpTerm: 24,
                        downPayment: 0.0,
                      },
                    },
                    {
                      dpTermPrices: {
                        firstMonthPrice: 14.19,
                        remainingMonthPrice: 13.88,
                        dpTerm: 36,
                        downPayment: 0.0,
                      },
                    },
                  ],
                  vvcDeviceFinancingOfferPrice: {
                    originalMonthlyPrice: 33.33,
                    monthlyDiscountPrice: 15.0,
                    contractText: 'Monthly Payment with Verizon Visa Card',
                    installmentTerm: 36,
                  },
                  fullRetailPrice: { allPromotions: [{ discountMonthlyPrice: '234' }] },
                },
                totalFinanceLimitRemaining: 4864.59,
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
      useLazyRetrievedppQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                data: {
                  dppIndicator: false,
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
    };
  },
  { virtual: true },
);
jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
  useLazyGetDevicePricingEligibilityQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: {
        isDevicePaymentEligible: false,
        dpMessage: {
          message:
            'You are prequalified for Device payment with $2000.00 Device finance limit and $4864.59 Total finance limit remaining',
          type: 'WARNING',
          inEligibleMessage: 'CUSTOMER HAS A PAST DUE BALANCE GREATER THAN  $ 24.99',
        },
      },
    },
  ],
  useLazyGetBestBuyInventoryQuery: () => [
    () => {},
    {
      status: 'Success',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: {
        availability: [
          {
            storeLocation: 'Minneapolis',
            quantity: 997,
            deviceSku: '5581615',
            storeId: '281',
            upc: '400055816159',
          },
          {
            storeLocation: 'Minneapolis',
            quantity: 997,
            deviceSku: '5581615',
            storeId: '281',
            upc: '400055816159',
          },
        ],
        devicePricingDetails: {
          storeId: '0281',
          upc: '887276053875',
          priceInfo: [
            {
              priceId: 'cnt302',
              activationType: 'upgrade',
              purchaseType: 'FINANCED',
              contractTerm: 36,
              regularPrice: 16.66,
              currentPrice: 16.66,
              taxBasis: 599.99,
              downPaymentAmount: 0,
              bbyDownPaymentAmount: 0,
            },
            {
              regularPrice: 1299.99,
              currentPrice: 1166.99,
              contractTerm: 1,
              activationType: 'upgrade',
              downPaymentAmount: 0,
              priceId: 'cnt302',
              purchaseType: 'FULL_SRP',
              taxBasis: 1299.99,
              bbyDownPayment: 50,
            },
            {
              priceId: 'cnt301',
              activationType: 'new',
              purchaseType: 'FINANCED',
              contractTerm: 36,
              regularPrice: 16.66,
              currentPrice: 16.66,
              taxBasis: 599.99,
              downPaymentAmount: 0,
              bbyDownPaymentAmount: 0,
            },
            {
              regularPrice: 299.99,
              currentPrice: 299.99,
              contractTerm: 1,
              activationType: 'new',
              downPaymentAmount: 0,
              priceId: 'cnt301',
              purchaseType: 'FULL_SRP',
              taxBasis: 299.99,
              bbyDownPayment: 0,
            },
          ],
          deviceSku: '4811019',
        },
      },
    },
  ],
}));

jest.mock(
  'onevzsoemfecommon/DeviceAPIService',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('onevzsoemfecommon/DeviceAPIService'),
      useLazyRetrievedppQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                data: {
                  dppIndicator: true,
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
    };
  },
  { virtual: true },
);
jest.mock('./SmartWatchBandOptions', () => ({ chooseSWBand }) => (
  <div
    role='button'
    data-testid='chooseSWBand'
    style={{ height: '150px', width: '300px' }}
    onClick={() => chooseSWBand({ target: { value: 'band' } })}
    onKeyDown={() => chooseSWBand({ target: { value: 'band' } })}
    tabIndex={0}
  >
    Click me
  </div>
));
jest.mock('./SmartWatchSizeOptions', () => ({ chooseSWBandSize }) => (
  <div
    role='button'
    data-testid='chooseSWBandSize'
    style={{ height: '150px', width: '300px' }}
    onClick={() => chooseSWBandSize({ target: { value: 'band' } })}
    onKeyDown={() => chooseSWBandSize({ target: { value: 'band' } })}
    tabIndex={0}
  >
    Click me
  </div>
));
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: () => ['TRUE'],
  }),
  { virtual: true },
);

const Test = (channel) => {
  setupChannel(channel);
  describe(`render <DeviceInfo> Plan Change`, () => {
    setupServer();
    jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
      ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
      useLazyGetDeviceDetailsQuery: () => [
        () => {},
        {
          status: 'fulfilled',
          isUninitialized: false,
          isLoading: false,
          isSuccess: true,
          isError: false,
          isFetching: false,
          data: { data: {} },
        },
      ],
      useLazyGetSkuDetailsQuery: () => [
        () => {},
        {
          status: 'fulfilled',
          isUninitialized: false,
          isLoading: false,
          isSuccess: true,
          isError: false,
          isFetching: false,
          data: { data: {} },
        },
      ],
    }));
    const modProductDetails = dropshipSkuDetailsResponse;
    const details = modProductDetails.data.deviceSku?.parentProducts[0] || {};
    const defaultSkuStringValue = getProp(details, 'defaultSKU') || '';
    const defaultSkuObjValue = getProp(details.defaultSKUObj, 'sorId') || '';
    const defaultSku = defaultSkuStringValue !== '' ? defaultSkuStringValue : defaultSkuObjValue;
    const defaultSkuDetails = details.childSkus.filter((sku) => sku.sorId && sku.sorId === defaultSku);
    const getdeatils_mockdata = {
      meta: {
        timestamp: '1690200378755',
        cxpCorrelationId: '2023-07-24T12:06:18.+0000:6ca5957e3448fc6b:cxp-browsing-services-5ffb77b8d5-bw8j5:nssit1',
      },
      data: {
        deviceProduct: {
          brandName: 'Apple',
          defaultSKU: 'MQ0E3LL/A',
          description:
            'iPhone 14 Pro. Capture incredible detail with a 48MP Main camera. Experience iPhone in a whole new way with Dynamic Island and Always-On display. And get peace of mind with groundbreaking safety features. Pair iPhone 14 Pro with Verizon, the network America relies on. 5G Ultra Wideband is now in more and more places, so more and more people can do amazing things with Verizon and iPhone 14 Pro. ',
          isFreeOverNightShipping: false,
          isComingSoon: false,
          parentCategories: ['cat10066', 'cat180001', 'cat180004'],
          productId: 'dev19920005',
          productDisplayName: 'iPhone 14 Pro',
          rating: {
            numberOfReviews: '6576',
            averageRating: '4.3648',
            productId: null,
            batteryLife: null,
            callQuality: null,
            design: null,
            display: null,
            easeOfUse: null,
            features: null,
            percentRecommended: null,
            performance: null,
          },
          seo: {
            h1Tag: 'iPhone 14 Pro',
            canonicalUrl: 'smartphones/apple-iphone-14-pro/',
            metaDescription:
              'Order the new Apple iPhone 14 Pro at Verizon, the network America relies on. See reviews, features, colors and more.',
            metaTitle: 'Buy the New iPhone 14 Pro - Price, Colors | Verizon',
            metaRobotsIndex: '1001',
            metaRobotsFollow: '1',
            seoUrlName: 'apple-iphone-14-pro',
          },
          customerAttributes: {
            establishedDate: '09/27/2010',
            customerType: 'PE',
            digitalCustomerType: 'B2E',
            ecpdId: '536984',
            firstName: 'JAKE',
            lastName: 'WRIGHT',
            zipCode: '12534',
            zipCodePlus4: '4737',
            inWithVerizonInd: 'N',
            state: 'NY',
            hashedAccountNumber: '6ddbc05e17d83728e1e64fabe6c6b40414689e1366d96237f528b2d389487d84',
            mtnList: ['5185673926', '8457062228'],
            loggedInMtn: 'PALACH9',
            lineDetails: [
              {
                mtn: '5185673926',
                hashedMtn: '87c29fdbdb62783f5348abd0ba8f840c5281fe24d99b1ed94406e5c48b499887',
                existingFWA: false,
              },
              {
                mtn: '8457062228',
                hashedMtn: '552fa45493a7c7a84d3b0116aba2e9785bbefa63ad217f01192801d2cbaf3b58',
                existingFWA: false,
              },
            ],
          },
          blockCTA: false,
          additionalDisclosures:
            "<ol><li>Splash, Water, and Dust Resistance: iPhone 14 Pro and iPhone 14 Pro Max are splash, water, and dust resistant and were tested under controlled laboratory conditions with a rating of IP68 under IEC standard 60529 (maximum depth of 6 meters up to 30 minutes). Splash, water, and dust resistance are not permanent conditions. Resistance might decrease as a result of normal wear. Do not attempt to charge a wet iPhone; refer to the user guide for cleaning and drying instructions. Liquid damage not covered under warranty.</li><li>FaceTime: FaceTime calling requires a FaceTime-enabled device for the caller and recipient and a Wi-Fi connection. Availability over a cellular network depends on carrier policies; data charges may apply.</li><li>Emergency SOS via Satellite: Available in November 2022. Service is included for free for two years with the activation of any iPhone 14 model. Connection and response times vary based on location, site conditions, and other factors. See <a href='https://www.apple.com/iphone-14/' target='_blank'>apple.com/iphone-14</a> or <a href='https://www.apple.com/iphone-14-pro/' target='_blank'>apple.com/iphone-14-pro</a> for more information.</li><li>Crash Detection: Emergency SOS uses a cellular connection or Wi-Fi calling.</li><li>Camera Resolution: Compared with the previous generation.</li><li>CPU Speed: Compared with the previous generation.</li><li>Power and Battery: All battery claims depend on network configuration and many other factors; actual results will vary. Battery has limited recharge cycles and may eventually need to be replaced. Battery life and charge cycles vary by use and settings. See <a href='https://www.apple.com/batteries/' target='_blank'>apple.com/batteries</a> and <a href='https://www.apple.com/iphone/battery.html' target='_blank'>apple.com/iphone/battery.html</a> for more information.</li></ol>\r",
          childSkus: [
            {
              color: {
                colorCssStyle: '#1E1D1B',
                colorId: 'clr12240018',
                description: 'Black',
                displayName: 'Space Black',
              },
              price: {
                devicePaymentPrice: [
                  {
                    originalPrice: 27.77,
                    contractDuration: 36,
                    contractText:
                      'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
                    dpTermPrices: {
                      downPayment: 0,
                      downPaymentRequired: false,
                      upgradeOptionPercentage: 50,
                      upgradeOptionCode: 'UO',
                      dpTerm: 36,
                      ugradeEligibilityCategory: [
                        {
                          categoryCode: '4',
                          categories: ['5G Smartphone~4G Smartphone'],
                        },
                      ],
                      firstMonthPrice: 28.04,
                      remainingMonthPrice: 27.77,
                    },
                  },
                ],
                fullRetailPrice: {
                  originalPrice: 999.99,
                  contractText: 'Full Retail Price',
                },
                vvcDeviceFinancingOfferPrice: {
                  originalMonthlyPrice: 33.33,
                  monthlyDiscountPrice: 15.0,
                  contractText: 'Monthly Payment with Verizon Visa Card',
                  installmentTerm: 36,
                },
                preferredTerm: 36,
              },
              comingSoonFlag: false,
              imageUrlMap: {
                defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
                largeImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
                mediumImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
                miniImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
                thumbImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
                imageSetUrl:
                  'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
              },
              inventoryDetails: {
                dFillInventory: {
                  isAvailable: false,
                  isBackorder: false,
                  isDeliverBy: false,
                  isPreOrder: false,
                  isShipBy: false,
                  isInStock: true,
                  locationCode: '9999999',
                  qtyAvailable: 69865,
                },
              },
              isBillToAccount: false,
              isRestrictionEnabled: true,
              prodCode1: '5GD',
              prodCode2: 'SMT',
              prodCode3: 'DIG',
              prodCode4: 'VDS',
              prodCode5: 'ISL',
              skuDisplayName: 'iPhone 14 Pro 128GB in Space Black',
              skuId: 'sku5600273',
              sorId: 'MPXT3LL/A',
              customerAttributes: {
                establishedDate: '09/27/2010',
                customerType: 'PE',
                digitalCustomerType: 'B2E',
                ecpdId: '536984',
                firstName: 'JAKE',
                lastName: 'WRIGHT',
                zipCode: '12534',
                zipCodePlus4: '4737',
                inWithVerizonInd: 'N',
                state: 'NY',
                hashedAccountNumber: '6ddbc05e17d83728e1e64fabe6c6b40414689e1366d96237f528b2d389487d84',
                mtnList: ['5185673926', '8457062228'],
                lineDetails: [
                  {
                    mtn: '5185673926',
                    hashedMtn: '87c29fdbdb62783f5348abd0ba8f840c5281fe24d99b1ed94406e5c48b499887',
                    existingFWA: false,
                  },
                  {
                    mtn: '8457062228',
                    hashedMtn: '552fa45493a7c7a84d3b0116aba2e9785bbefa63ad217f01192801d2cbaf3b58',
                    existingFWA: false,
                  },
                ],
              },
              capacity: '128 GB',
              capacitySize: 128,
              capacityUnit: '128 GB',
              isDevicePaymentEligible: true,
              isInstorePickup: true,
              isSameDayDelivery: true,
              isHumDevice: true,
              isSmartLocator: false,
              simSku: 'UNIVESIM5G-SA-D',
              edgeDeviceCap: '1010',
              productIdMap: {
                prepayProduct: 'dev20000221',
                postPayProduct: 'dev19920005',
              },
              skuRestricted: false,
              skuFilters: {
                deviceFilterType: 'smartphones',
                restrictedAccySku: 'false',
              },
              isPreconfigureEnabled: false,
              itemSaleFlag: true,
            },
          ],
          childSkusByColor: [
            {
              skus: [
                {
                  sorId: 1,
                },
              ],
            },
          ],
          compatibleSimSorIds: ['UNIVESIM5G-SA-A', 'UNIVESIM5G-SA-S', 'UNIVESIM5G-SA-D'],
          deviceUnlockPolicy: {
            textId: '11500001',
            textName: 'DEVICE_UNLOCK_POLICY',
            description: null,
            text: '<p><strong>Device Unlocking Policies</strong></p>\r\r<p>In order to mitigate theft and other fraudulent activity, newly purchased devices are\r"u201Clockedu201D" to work exclusively on the Verizon network. We have separate device\runlocking policies that cover postpay and prepaid devices, as well as special rules for\rdeployed military personnel.</p>\r \r\r\r<p>"u201CUnlockingu201D" a device refers only to disabling software that would prevent a consumer\rfrom attempting to activate a device designed for one carrieru2019s network. Due to differing technologies, an unlocked Verizon Wireless device\rmay not work u2013 or may experience limited functionality u2013 on another carrieru2019s network.</p>\r\r \r\r<p><strong>Postpay Device Unlocking Policy</strong></p>\r\r\r\r<p>Devices that you purchase from Verizon are locked for 60 days after purchase. Devices that you purchase from our retail partners are locked for 60 days after activation.After 60 days, we will automatically remove the lock. Following the 60 day lock period, we do not lock our phones at any time.</p>\r\r\r\r\r<p><strong>Prepaid Device Unlocking Policy</strong></p>\r\r\r<p>Devices that you purchase from Verizon and certain devices purchased from our retail partners are locked for 60 days after activation. After 60 days, we will automatically remove the lock. Following the 60 day lock period following device purchase, we do not lock our phones at any time.</p>\r\r<p>If you purchase a 4G Phone&ndash;in&ndash;a&ndash;Box from our retail partners, you should review the back of the box to determine the lock period applicable to that device.</p>\r\r<p><strong>Unlocking Policy for Deployed Military Personnel</strong></p>\r\r<p>If you are a Verizon Wireless customer in the military and receive relocation orders outside of the Verizon Coverage Area, we will unlock your device at your request, even during the 60&ndash;day&ndash;lock period following the purchase of your device.</p>\r\r<p>Effective Date: July 23, 2019</p>',
            applicationFlag: true,
            url: null,
            urlAvailableFlag: false,
            newBrowserFlag: null,
            textType: 'GlobalText',
            displayB2cFlag: true,
            sequenceOrder: null,
            textVersion: null,
            wmsLabel: null,
            currentVersion: 1,
          },
          daccId: '01794',
          deviceType: 300202,
          hasDeviceUnlockPolicy: true,
          includedAccessories:
            '<ul class="features">\r<li>iPhone with iOS 16</li>\r<li>USB-C to Lightning Cable</li>\r<li>Documentation</li>\r</ul>',
          isAnySkuInStock: false,
          isAllSkusOutofStock: false,
          isCPO: false,
          isE911Address: false,
          isNumberShareCapable: true,
          isNumberShareMandatory: true,
          isSupportOnly: false,
          operatingSystem: 'Apple iOS',
          startDate: {
            date: '01/25/2024',
            dateTime: '01-25-2024 05:00:00 AM',
            dateLong: 1706158800000,
          },
          sorDeviceCategory: '5G Smartphone',
          specifications: {
            battery: null,
            depth: 0.31,
            height: 5.81,
            screenSize: '6.1"',
            size: '5.81,2.81,0.31',
            weight: 7.27,
            width: 2.81,
          },
          techSpecs: {
            'Video Playback': 'Up to 23 hrs.',
            Overall: 'Accessibility Shortcut, Siri, Guided Access, Per App Setting',
            'Wi-Fi': 'Yes',
            Screen:
              'Super Retina XDR display; 6.1-inch (diagonal) all-screen OLED display; 2556-by-1179-pixel resolution at 460 ppi',
            '5G Ultra Wideband': 'n260/ n261 (high-band / mmWave) | n77 (mid-band / C-band)',
            'Hearing Aid Compatibility': 'M3/T4',
            Depth: '0.31 in.',
            Weight: '7.27 oz.',
            Type: 'Built-in rechargeable lithium-ion battery',
            '4G': '13, 4, 2, 5, 66, 46, 48',
            Colors: 'Space Black, Silver, Gold, Deep Purple',
            Storage: '128GB, 256GB, 512GB, 1TB (Subject to availability)',
            Auditory: 'Made for iPhone hearing devices, Sound Recognition, Headphone Accommodations, Live Captions',
            'Usage Time': 'Streamed: Up to 20 hrs; Audio playback: Up to 75 hrs.',
            'Rear Camera':
              'Main: 24 mm, ƒ/1.78 aperture, second-generation sensor-shift optical image stabilization, seven-element lens, 100% Focus Pixels',
            'Mobility/Cognitive': 'Voice Control, Switch Control, AssistiveTouch, Back Tap',
            'FCC ID': 'BCG-E4000A',
            'Global & Roaming Network':
              'LTE Roaming 1, 3, 7, 20, 28, 12, 26 | GSM/UMTS 850, 900, 1700/2100, 1900, 2100 MHz) | GSM/EDGE (850, 900, 1800, 1900 Mhz)',
            '5G Nationwide': 'n2/n5/n48/n66',
            Height: '5.81 in.',
            'Operating System': 'Apple iOS',
            camera: '48MP ',
            Width: '2.81 in.',
            Visual: 'VoiceOver, Zoom, Color Filters, Spoken Content',
          },
          categoryDisplayNames: ['GnG Devices', 'Postpaid Devices', 'Smartphones'],
          isIconicPhone: true,
          unlockDevicePDP: false,
          emergencyCLNR: true,
          cannotBeUpgraded: false,
          hostDeviceInCompatible: false,
          sorDeviceType: '5GE',
          ccod: null,
          favoriteId: null,
          inFavorite: false,
          wishListCount: 0,
          imageName: 'iphone-14-pro-deep-purple-fall22-a',
          imageUrlMap: {
            defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a',
            largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-lg$',
            mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-med$',
            miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-mini$',
            thumbImage:
              'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-thumb$',
            imageSetUrl:
              'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
          },
          deviceRestricted: false,
          skuRestrictions: {
            restrictionMessages: [],
            isAllSkusRestricted: false,
          },
          productSpecification: null,
          notSellableSkus: ['3L242LL/A'],
          modPdp: false,
          defaultSKUObj: {
            color: {
              colorCssStyle: '#655D6C',
              colorId: 'clr12200029',
              description: 'Purple',
              displayName: 'Deep Purple',
            },
            price: {
              devicePaymentPrice: [
                {
                  originalPrice: 27.77,
                  contractDuration: 36,
                  contractText:
                    'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
                  dpTermPrices: {
                    downPayment: 0,
                    downPaymentRequired: false,
                    upgradeOptionPercentage: 50,
                    upgradeOptionCode: 'UO',
                    dpTerm: 36,
                    ugradeEligibilityCategory: [
                      {
                        categoryCode: '4',
                        categories: ['5G Smartphone~4G Smartphone'],
                      },
                    ],
                    firstMonthPrice: 28.04,
                    remainingMonthPrice: 27.77,
                  },
                },
              ],
              fullRetailPrice: {
                originalPrice: 999.99,
                contractText: 'Full Retail Price',
              },
              vvcDeviceFinancingOfferPrice: {
                originalMonthlyPrice: 33.33,
                monthlyDiscountPrice: 15.0,
                contractText: 'Monthly Payment with Verizon Visa Card',
                installmentTerm: 36,
              },
              preferredTerm: 36,
            },
            comingSoonFlag: false,
            imageUrlMap: {
              defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a',
              largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-lg$',
              mediumImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-med$',
              miniImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-mini$',
              thumbImage:
                'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-thumb$',
              imageSetUrl:
                'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
            },
            inventoryDetails: {
              dFillInventory: {
                isAvailable: false,
                isBackorder: false,
                isDeliverBy: false,
                isPreOrder: false,
                isShipBy: false,
                isInStock: true,
                locationCode: '9999999',
                qtyAvailable: 121020,
              },
              localInventory: {
                isAvailable: false,
                isBackorder: false,
                isDeliverBy: false,
                isPreOrder: false,
                isShipBy: false,
                isInStock: true,
                locationCode: '2777301',
                qtyAvailable: 20,
              },
            },
            isBillToAccount: false,
            isRestrictionEnabled: true,
            prodCode1: '5GD',
            prodCode2: 'SMT',
            prodCode3: 'DIG',
            prodCode4: 'VDS',
            prodCode5: 'ISL',
            skuDisplayName: 'iPhone 14 Pro 128GB in Deep Purple',
            skuId: 'sku5600276',
            sorId: 'MQ0E3LL/A',
            customerAttributes: {
              establishedDate: '09/27/2010',
              customerType: 'PE',
              digitalCustomerType: 'B2E',
              ecpdId: '536984',
              firstName: 'JAKE',
              lastName: 'WRIGHT',
              zipCode: '12534',
              zipCodePlus4: '4737',
              inWithVerizonInd: 'N',
              state: 'NY',
              hashedAccountNumber: '6ddbc05e17d83728e1e64fabe6c6b40414689e1366d96237f528b2d389487d84',
              mtnList: ['5185673926', '8457062228'],
              lineDetails: [
                {
                  mtn: '5185673926',
                  hashedMtn: '87c29fdbdb62783f5348abd0ba8f840c5281fe24d99b1ed94406e5c48b499887',
                  existingFWA: false,
                },
                {
                  mtn: '8457062228',
                  hashedMtn: '552fa45493a7c7a84d3b0116aba2e9785bbefa63ad217f01192801d2cbaf3b58',
                  existingFWA: false,
                },
              ],
            },
            capacity: '128 GB',
            capacitySize: 128,
            capacityUnit: '128 GB',
            isDevicePaymentEligible: true,
            isInstorePickup: true,
            isSameDayDelivery: true,
            isHumDevice: false,
            isSmartLocator: false,
            simSku: 'UNIVESIM5G-SA-D',
            edgeDeviceCap: '1010',
            productIdMap: {
              prepayProduct: 'dev20000221',
              postPayProduct: 'dev19920005',
            },
            skuRestricted: false,
            skuFilters: {
              deviceFilterType: 'Smartphones',
              restrictedAccySku: 'false',
            },
            isPreconfigureEnabled: false,
            itemSaleFlag: true,
          },
        },
        deviceSku: {
          color: {
            colorCssStyle: '#655D6C',
            colorId: 'clr12200029',
            description: 'Purple',
            displayName: 'Deep Purple',
          },
          price: {
            devicePaymentPrice: [
              {
                originalPrice: 27.77,
                contractDuration: 36,
                contractText:
                  'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
                dpTermPrices: {
                  downPayment: 0,
                  downPaymentRequired: false,
                  upgradeOptionPercentage: 50,
                  upgradeOptionCode: 'UO',
                  dpTerm: 36,
                  ugradeEligibilityCategory: [
                    {
                      categoryCode: '4',
                      categories: ['5G Smartphone~4G Smartphone'],
                    },
                  ],
                  firstMonthPrice: 28.04,
                  remainingMonthPrice: 27.77,
                },
              },
            ],
            fullRetailPrice: {
              originalPrice: 999.99,
              contractText: 'Full Retail Price',
            },
            vvcDeviceFinancingOfferPrice: {
              originalMonthlyPrice: 33.33,
              monthlyDiscountPrice: 15.0,
              contractText: 'Monthly Payment with Verizon Visa Card',
              installmentTerm: 36,
            },
            preferredTerm: 36,
          },
          comingSoonFlag: false,
          imageUrlMap: {
            defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a',
            largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-lg$',
            mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-med$',
            miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-mini$',
            thumbImage:
              'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-thumb$',
            imageSetUrl:
              'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
          },
          inventoryDetails: {
            dFillInventory: {
              isAvailable: false,
              isBackorder: false,
              isDeliverBy: false,
              isPreOrder: false,
              isShipBy: false,
              isInStock: true,
              locationCode: '9999999',
              qtyAvailable: 121020,
            },
            localInventory: {
              isAvailable: false,
              isBackorder: false,
              isDeliverBy: false,
              isPreOrder: false,
              isShipBy: false,
              isInStock: true,
              locationCode: '2777301',
              qtyAvailable: 20,
            },
          },
          isBillToAccount: false,
          isRestrictionEnabled: true,
          prodCode1: '5GD',
          prodCode2: 'SMT',
          prodCode3: 'DIG',
          prodCode4: 'VDS',
          prodCode5: 'ISL',
          skuDisplayName: 'iPhone 14 Pro 128GB in Deep Purple',
          skuId: 'sku5600276',
          sorId: 'MQ0E3LL/A',
          customerAttributes: {
            establishedDate: '09/27/2010',
            customerType: 'PE',
            digitalCustomerType: 'B2E',
            ecpdId: '536984',
            firstName: 'JAKE',
            lastName: 'WRIGHT',
            zipCode: '12534',
            zipCodePlus4: '4737',
            inWithVerizonInd: 'N',
            state: 'NY',
            hashedAccountNumber: '6ddbc05e17d83728e1e64fabe6c6b40414689e1366d96237f528b2d389487d84',
            mtnList: ['5185673926', '8457062228'],
            lineDetails: [
              {
                mtn: '5185673926',
                hashedMtn: '87c29fdbdb62783f5348abd0ba8f840c5281fe24d99b1ed94406e5c48b499887',
                existingFWA: false,
              },
              {
                mtn: '8457062228',
                hashedMtn: '552fa45493a7c7a84d3b0116aba2e9785bbefa63ad217f01192801d2cbaf3b58',
                existingFWA: false,
              },
            ],
          },
          capacity: '128 GB',
          capacitySize: 128,
          capacityUnit: '128 GB',
          isDevicePaymentEligible: true,
          isInstorePickup: true,
          isSameDayDelivery: true,
          isHumDevice: false,
          isSmartLocator: false,
          simSku: 'UNIVESIM5G-SA-D',
          edgeDeviceCap: '1010',
          productIdMap: {
            prepayProduct: 'dev20000221',
            postPayProduct: 'dev19920005',
          },
          skuRestricted: false,
          skuFilters: {
            deviceFilterType: 'Smartphones',
            restrictedAccySku: 'false',
          },
          isPreconfigureEnabled: false,
          itemSaleFlag: true,
        },
        commonInfo: {
          showPrice: true,
          displayReasonCode: true,
          showShipitToggle: true,
          flexPDPTradeInLinkEnabled: true,
          containSoftSku: false,
          dpEligible: true,
          indirect: false,
        },
        accountInfo: {
          lastName: 'WRIGHT',
          zipCode: '12534',
          myOfferAccepted: null,
          nickName: null,
          safeTechSessionId: '5600a69800d74348a0d12092',
          processingMTN: null,
          accountEupDeviceType: null,
          zipCodePlus4: '4737',
          selectedOfferFlows: null,
          estTradeInValue: null,
          firstName: 'JAKE',
          intentType: null,
          preOrderMTNEnable: 'false',
          custType: 'B2E',
          btaEligible: 'false',
          buyoutDisplay: 'True',
          state: 'NY',
        },
        fiveGMobilityInfo: {
          fiveGToFourGOverlay: false,
          fiveGHomeRequired: false,
          fiveGUpSell: false,
        },
        catDL: null,
        getDeviceTradeStatus: {
          promoExists: false,
          bogoOffer: false,
        },
        showReturnTab: false,
      },
      featureFlags: { earlyUpgradeOrderVVCFFlag: true },
      fromCache: false,
    };
    const bbyPricingDetails = {
      availability: [
        {
          storeLocation: 'Minneapolis',
          quantity: 997,
          deviceSku: '5581615',
          storeId: '281',
          upc: '400055816159',
        },
        {
          storeLocation: 'Minneapolis',
          quantity: 997,
          deviceSku: '5581615',
          storeId: '281',
          upc: '400055816159',
        },
      ],
      devicePricingDetails: {
        storeId: '0281',
        upc: '887276053875',
        priceInfo: [
          {
            priceId: 'cnt302',
            activationType: 'upgrade',
            purchaseType: 'FINANCED',
            contractTerm: 36,
            regularPrice: 16.66,
            currentPrice: 16.66,
            taxBasis: 599.99,
            downPaymentAmount: 0,
            bbyDownPaymentAmount: 0,
          },
          {
            regularPrice: 1299.99,
            currentPrice: 1166.99,
            contractTerm: 1,
            activationType: 'upgrade',
            downPaymentAmount: 0,
            priceId: 'cnt302',
            purchaseType: 'FULL_SRP',
            taxBasis: 1299.99,
            bbyDownPayment: 50,
          },
          {
            priceId: 'cnt301',
            activationType: 'new',
            purchaseType: 'FINANCED',
            contractTerm: 36,
            regularPrice: 16.66,
            currentPrice: 16.66,
            taxBasis: 599.99,
            downPaymentAmount: 0,
            bbyDownPaymentAmount: 0,
          },
          {
            regularPrice: 299.99,
            currentPrice: 299.99,
            contractTerm: 1,
            activationType: 'new',
            downPaymentAmount: 0,
            priceId: 'cnt301',
            purchaseType: 'FULL_SRP',
            taxBasis: 299.99,
            bbyDownPayment: 0,
          },
        ],
        deviceSku: '4811019',
      },
    };
    beforeAll(() => {
      if (!global.window) {
        global.window = {};
      }
    });

    beforeEach(() => {
      sessionStorage.setItem('elvisFFlag', 'TRUE');
      global.window.BbyDevicePricingDetails = jest.fn((data) => data);
      executeShellFunction.mockImplementation(() => global.window.BbyDevicePricingDetails(JSON.stringify(mockBByData)));
      render(
        <DeviceInfo
          btnLabel='BYOD'
          showPlanChange
          details={details}
          getContractTerm={jest.fn()}
          productDetails={modProductDetails.data}
          protectionFeatures={protectionFeatures}
          cartDetails={{
            ...cartDetails.data.data,
            cart: {
              ...cartDetails.data.data.cart,
              orderDetails: {
                ...cartDetails.data.data.cart.orderDetails,
                customerType: 'N',
              },
            },
          }}
          GetDetailsResult={{ data: getdeatils_mockdata }}
          SkuDetailsResult={{ data: getSkuDetails }}
          bbyPricingDetailsResult={{ data: bbyPricingDetails }}
          customerProfileDetails={customerProfileDetails.data}
          activeMtn='5185673926'
          selectedColor={defaultSkuDetails[0].color.displayName}
          setSelectedColor={jest.fn()}
          ispuToggleOn={false}
          setIspuToggleOn={jest.fn()}
          isShipItToggleOn
          setIsShipItToggleOn={jest.fn()}
          selectedSku={{ skuFilters: { deviceFilterType: 'tablets' } }}
          setSelectedSku={jest.fn()}
          selectedProtectionFeature={protectionFeatures.payload.features[1]}
          setSelectedProtectionFeature={jest.fn()}
          selectedSize={defaultSkuDetails[0].capacity}
          setSelectedSize={jest.fn()}
          setBuyoutToggleChange={jest.fn()}
          updateNumberShare={jest.fn()}
          isNumberShare={false}
          numberShareValue='9732022897'
          sharedMtnValue=''
          updateNumberShareValue={jest.fn()}
          updateSharedMtnValue={jest.fn()}
          setSelectedPaymentInfo={jest.fn()}
          updateDeviceId={jest.fn()}
          updateSimId={jest.fn()}
          updateDeviceData={jest.fn()}
          setTmpLinkClicked={jest.fn()}
          setUpgradeReasonType={jest.fn()}
          groupByColors={jest.fn()}
          groupBySmartWatchBand={jest.fn()}
          setisInStock={jest.fn()}
          setIncompatibleSim={jest.fn()}
          sendFullRetailPrice={jest.fn()}
          setBbyPaymetOptionPriceId={jest.fn()}
          bbyPaymetOptionPriceId='cnt302'
          setBbyContractTerm={jest.fn()}
          bbyContractTerm='36'
          setBbPaymentOptionsSelected={jest.fn()}
          isBBYLocalOrder
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });
    test(`it should disable 'Ship It' button and show 'This item is unavailable.' text`, async () => {
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      const PlanChange = screen.getByLabelText('Plan Change');
      expect(PlanChange).toBeInTheDocument();
      PlanChange.removeAttribute('disabled');
      expect(PlanChange).not.toBeDisabled();
      fireEvent.click(PlanChange);
    });
  });
};

Test(CHANNELS.OMNI_INDIRECT);
