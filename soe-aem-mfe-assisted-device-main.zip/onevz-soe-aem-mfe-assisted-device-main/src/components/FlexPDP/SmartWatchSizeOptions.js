import React from 'react';
import { RadioBoxGroup } from '@vds/radio-boxes';
import sortBy from 'lodash/sortBy';
import styled from 'styled-components';

const RadioBoxWrap = styled.div`
  label {
    padding: 0.5rem;
    color: #000000 !important;
  }
  & label::before {
    content: '';
    display: none;
  }
`;
const SmartWatchSizeOptions = (props) => {
  const { skus, selectedSku } = props;
  const { color = {}, skuFilters = {}, sorId = '' } = selectedSku;
  const { band = '' } = skuFilters;
  if (!skus || !color) {
    return '';
  }
  const colorObj = skus && skus.length > 0 && skus.filter((sku) => sku.color === color.displayName);
  const bandSkus = colorObj?.[0]?.skusGroupedBySWBand;
  const bandSkusFiltered = bandSkus?.[0] && bandSkus.filter((sku) => sku?.band === band);
  const bandSizeSkus = bandSkusFiltered?.[0]?.bandSkus ?? [];
  const bandSizeSkusSorted = sortBy(bandSizeSkus, ['sizeInInteger']);
  const defaultValue = bandSizeSkusSorted?.[0] && bandSizeSkusSorted?.find((sku) => sorId === sku?.sorId);
  return (
    <RadioBoxWrap data-testid='smartWatchSizeOptions'>
      {Array.isArray(bandSizeSkusSorted) && bandSizeSkusSorted?.[0] && (
        <RadioBoxGroup
          key={defaultValue?.sorId}
          defaultValue={defaultValue?.sorId}
          onChange={props.chooseSWBandSize}
          orientation='horizontal'
          surface='light'
          data={bandSizeSkusSorted.map((sku) => {
            const bandSizeSku = sku?.sorId;
            const bandSizeText = sku?.skuFilters?.size;
            return {
              name: 'bands',
              children: bandSizeText,
              text: bandSizeText,
              value: bandSizeSku,
              width: '100px',
              'data-track': `Productdetail_smartwatchbandsize_${bandSizeSku}`,
            };
          })}
        />
      )}
    </RadioBoxWrap>
  );
};
export default SmartWatchSizeOptions;
