import { Button } from '@vds/buttons';
import styled from 'styled-components';

const DivFooter = styled.div`
  padding-left: 15px;
  padding-bottom: 15px;
`;

const BuyOutWrapper = styled.div`
  background-color: rgba(0, 0, 10, 0.5);
`;

const ModalBody = styled.div`
  background-color: #fefefe;
`;

function ShowPastbalPreBackOrder(props) {
  /**
   * executes on click of Ok CTA
   */
  const okOnclickHandler = () => {
    props.setShowModalPastbalPreBackOrder(false);
  };
  return (
    <BuyOutWrapper
      className='BuyoutAmount-Modal'
      style={{ 'background-color': 'rgba(0, 0, 10, 0.5)' }}
      data-testid='pastDueModalInPDP'
    >
      <div className='BuyoutAmount-Modal-inner preBackOrder'>
        <ModalBody>
          <div className='u-marginBottomExtraLarge'>
            <div className='bodyPartInner'>
              <div className='buyOutContent u-paddingLeftLarge u-paddingTopLarge u-marginBottomMedium'>
                <p>Devices that are on preOrder/backorder are not allowed Past Due transaction.</p>
                <p className='u-marginTopMedium'>
                  Past Due amount must be paid before sales order, or select in-stock device to proceed.
                </p>
                <p className='u-marginTopMedium'>
                  <b>Note:</b> Back orders with ISPU can still proceed with past due.
                </p>
              </div>
            </div>
          </div>
          <DivFooter>
            <Button width='154px' size='small' inverted secondary onClick={okOnclickHandler} data-track='OK'>
              OK
            </Button>
          </DivFooter>
        </ModalBody>
      </div>
    </BuyOutWrapper>
  );
}

export default ShowPastbalPreBackOrder;
