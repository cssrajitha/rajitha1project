import React, { useEffect, useContext } from 'react';
import styled from 'styled-components';
// eslint-disable-next-line you-dont-need-lodash-underscore/get
import { isEmpty, get, cloneDeep } from 'lodash';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import { useDispatch } from 'react-redux';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { Padding32 } from '../CombinedGridwall/FlexGlobalStyledConstants';
import { LIGHT_BG_COLOR } from '../../constants/constants';
import DeviceInfo5G from './DeviceInfo5G';
import { Context } from '../../pages/PDP5G/PDP5gContext';
import Header from '../../pages/PDP5G/Header';

const HeaderWraper = styled.div`
  position: absolute;
  background: ${LIGHT_BG_COLOR};
  width: 100%;
  top: 0;
  max-width: 1133px;
  z-index: inherit;
`;

function PDP5G() {
  const dispatch = useDispatch();
  const {
    getDetailsResponse = {},
    customerProfile = {},
    cartDetails = {},
    activeMtn = '',
    details,
    setDetails,
    isShipItToggleOn,
    bundleProduct,
    isfiveGGemini,
    isfiveGScan,
    setDisableShipIttoogle,
    ispuToggleOn = false,
    isFromCPE = false,
    isByodUpdate = false,
    isIspuItemInCart = false,
    isRfexFlow = false,
  } = useContext(Context);
  const productDetails = getDetailsResponse;
  // const [details, setDetails] = useState(
  //   getDetailsResponse?.deviceProduct || getDetailsResponse?.deviceSku?.parentProducts[0]
  // );

  //  const scmDeviceMfeEnable = window?.mfe?.scmDeviceMfeEnable;
  // const isDark = (scmDeviceMfeEnable && window?.mfe?.isDark) || false;
  // const bgColor = scmDeviceMfeEnable && window?.mfe?.themeProps?.background;
  const { lineDetails = {} } = cartDetails?.cart || {};

  const landingMtn = customerProfile?.customer?.billAccounts[0]?.mtns?.filter((mtnList) => mtnList?.mtn === activeMtn);
  const totalLines = lineDetails?.lineInfo || [];
  const lineInfo = totalLines?.filter((line) => line?.mobileNumber === activeMtn);
  const isNewlyAddedLine = landingMtn?.[0] ? landingMtn[0].isNewlyAddedLine : '';
  const AALFirstName = lineInfo?.[0]?.serviceInfo?.primaryUserInfo?.firstName || '';
  const preferFirstName = isNewlyAddedLine ? AALFirstName : landingMtn?.[0]?.primaryUser?.preferFirstName;
  const primaryfirstname = preferFirstName || landingMtn?.[0]?.primaryUser?.firstName;
  const primaryUserName = primaryfirstname ? `${primaryfirstname}` : '';
  const FirstName = primaryUserName || AALFirstName;
  const { productDisplayName = '' } = bundleProduct || {};
  const headerData = {
    header: details?.productDisplayName || productDisplayName,
    line: FirstName,
    mdn: activeMtn,
    closeIcon: { popupModalclose: true },
  };
  const { LTEQualified = false, cBandQualified = false } =
    customerProfile?.customer?.qualificationDetails?.addressRequest || {};

  useEffect(() => {
    let updateDeviceDetails = productDetails?.deviceProduct || productDetails?.deviceSku?.parentProducts?.[0];
    // when childSkus is empty array then set childskus from deviceSku as per BAU
    if (!updateDeviceDetails?.childSkus?.[0]) {
      const deviceSku = cloneDeep(productDetails?.deviceSku) || {};
      const deviceProduct = deviceSku?.parentProducts?.[0] || {};
      deviceProduct.childSkus = [deviceSku];
      updateDeviceDetails = deviceProduct;
    }
    setDetails(updateDeviceDetails);
  }, [productDetails]);

  useEffect(() => {
    if (LTEQualified && !cBandQualified) {
      displayLTEHomeRouterBanner();
    }
  }, [LTEQualified, cBandQualified]);

  const getButtonLabel = () => {
    const ADDTOCART = 'Add to Cart';
    const SHIPIT = 'Ship It';
    const FINDSTORES = 'Find Stores';
    const UPDATE = 'Update';
    const PICKUP = 'Pick Up';
    const BYOD = 'BYOD';
    let label = ADDTOCART;
    const isWSAPCpeError = Boolean(getQueryParamByName('isWSAPCpeError')) || false;
    const isContractChange = !!getQueryParamByName('isContractChange');
    const etniApi = false;
    if (!isEmpty(bundleProduct)) {
      if (isfiveGGemini || isfiveGScan) {
        label = 'Add to Cart';
      } else if (ispuToggleOn && isIspuItemInCart) {
        label = PICKUP;
      } else {
        // const { productDisplayName } = bundleProduct;
        const is5GHomeProfInstall =
          productDisplayName.includes('Professional') ||
          get(bundleProduct?.childSkus?.[0], 'is5gHomeProfessionalInstall');
        //  const is5gHomeSelfInstall = get(bundleProduct?.childSkus?.[0], 'is5gHomeSelfInstall');
        label = isfiveGScan || is5GHomeProfInstall ? 'Add to Cart' : 'Ship It';
        if (is5GHomeProfInstall) {
          setDisableShipIttoogle(true);
        }
      }
    } else if (isShipItToggleOn && !isFromCPE && !isByodUpdate) {
      label = SHIPIT;
    } else if (ispuToggleOn && isIspuItemInCart) {
      label = PICKUP;
    } else if (!isShipItToggleOn && !ispuToggleOn && !isFromCPE && !isByodUpdate) {
      label = ADDTOCART;
    } else if (isFromCPE && !isWSAPCpeError) {
      label = ispuToggleOn && !etniApi && !isFromCPE ? FINDSTORES : UPDATE;
    } else if (isByodUpdate) {
      label = BYOD;
    } else if ((isRfexFlow && isContractChange) || isFromCPE) {
      label = UPDATE;
    }
    return label;
  };

  const displayLTEHomeRouterBanner = () => {
    dispatch(
      appMessageActions.addAppMessage(
        'The availability of LTE Home Internet Service and the use of the LTE Home Router/antenna is limited to certain areas. The LTE Home Router can only be used at the service address registered at the time of order placement, and the device will not work if moved to another location.',
        'warning',
      ),
    );
  };

  return (
    <>
      <HeaderWraper>
        <Header data={headerData} closeClickHandler={() => {}} />
      </HeaderWraper>
      <Padding32>
        <DeviceInfo5G btnLabel={getButtonLabel()} />
      </Padding32>
    </>
  );
}
export default PDP5G;
