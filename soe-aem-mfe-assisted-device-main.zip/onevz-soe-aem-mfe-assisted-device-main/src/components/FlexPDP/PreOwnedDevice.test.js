import React from 'react';
import PreOwnedDevice from './PreOwnedDevice';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { render, screen, fireEvent } from '../../modules/test-utils/renderHelper';
import PreOwnedMock from './mocks/PreOwnedMock.json';

describe('smartWatch size component render', () => {
  beforeEach(() => {
    render(
      <PreOwnedDevice
        {...PreOwnedMock}
        handlePreOwnedDeviceRadioChangeParent={jest.fn()}
        setSelectedSize={jest.fn()}
        getInventoryStatus={jest.fn()}
        setSelectedColor={jest.fn()}
        setSelectedSku={jest.fn()}
        doCallGetSkuDetails={jest.fn()}
        setSelectedPreownedDevice={jest.fn()}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('it should mount', () => {
    screen.getByText(/Device condition/i);
    const radiobtn = screen.getByRole('radio', {
      name: 'Very Good These devices are in very good condition. They have slightly more scratches and scuffs.',
    });
    expect(radiobtn).toBeInTheDocument();
    fireEvent.click(radiobtn);
  });
});
describe('smartWatch size component render 1', () => {
  jest.mock(
    'onevzsoemfeframework/DomService',
    () => ({
      __esModule: true,
      default: jest.fn(() => ({})),
      ...jest.requireActual('onevzsoemfeframework/DomService'),
      getQueryParamByName: (value) => {
        if (value === 'fromLanding') return true;
      },
    }),
    { virtual: true },
  );
  beforeEach(() => {
    render(
      <PreOwnedDevice
        {...PreOwnedMock}
        handlePreOwnedDeviceRadioChangeParent={jest.fn()}
        setSelectedSize={jest.fn()}
        getInventoryStatus={jest.fn()}
        setSelectedColor={jest.fn()}
        setSelectedSku={jest.fn()}
        doCallGetSkuDetails={jest.fn()}
        setSelectedPreownedDevice={jest.fn()}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('it should mount', () => {
    screen.getByText(/Device condition/i);
    const radiobtn = screen.getByRole('radio', {
      name: 'Very Good These devices are in very good condition. They have slightly more scratches and scuffs.',
    });
    expect(radiobtn).toBeInTheDocument();
    fireEvent.click(radiobtn);
  });
});
describe('smartWatch size component render 2', () => {
  beforeEach(() => {
    render(
      <PreOwnedDevice
        {...PreOwnedMock}
        handlePreOwnedDeviceRadioChangeParent={jest.fn()}
        setSelectedSize={jest.fn()}
        getInventoryStatus={jest.fn()}
        setSelectedColor={jest.fn()}
        setSelectedSku={jest.fn()}
        doCallGetSkuDetails={jest.fn()}
        setSelectedPreownedDevice={jest.fn()}
        details=''
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('it should mount', () => {
    screen.getByText(/Device condition/i);
    const radiobtn = screen.getByRole('radio', {
      name: 'Very Good These devices are in very good condition. They have slightly more scratches and scuffs.',
    });
    expect(radiobtn).toBeInTheDocument();
    fireEvent.click(radiobtn);
  });
});
