import { Tabs, Tab } from '@vds/tabs';
import { UnorderedList, ListItem } from '@vds/lists';
import styled from 'styled-components';
import { React } from 'react';
import { Body } from '@vds/typography';
import PropTypes from 'prop-types';
import { decodeHTMLEntities } from 'onevzsoemfecommon/Helpers';
import SpecsContainer from './SpecsContainer';

const MarginSides = styled.div`
  margin: 0 3rem;
`;
const SpecCont = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  margin-bottom: 7rem;
  height: ${window?.mfe?.isProspectNewCustomerTab ? '30vh' : 'auto'};
  overflow-y: ${window?.mfe?.isProspectNewCustomerTab ? 'auto' : ''};
`;
const LeftContainer = styled.div`
  float: left;
  width: 49%;
`;
const RightContainer = styled.div`
  float: right;
  width: 49%;
`;
const OverviewContainer = styled.div`
  padding-top: 2rem;
  width: 29rem;
`;

const ButtonWrapper = styled.span`
  padding-left: 0.5rem;
`;

function DeviceSpecifications(props) {
  const { specsData, inbox, OverviewDetails, isVbg } = props;
  const specsEntries = Object.entries(specsData || {});
  const inboxItems =
    inbox &&
    inbox
      .replace(/<([^<>]+)>/gi, '')
      .split('\r')
      .filter((x) => !!x);
  const leftI = specsEntries.slice(0, Math.ceil(specsEntries.length / 2));
  const RightC = specsEntries.slice(Math.ceil(specsEntries.length / 2));

  return (
    <MarginSides>
      <Tabs orientation='horizontal' indicatorPosition='bottom' size='medium'>
        <Tab label='Overview' onClick={() => props.openViewCall('View device details | Overview')}>
          <SpecCont>
            <OverviewContainer>
              <Body size='large' color='#000000' bold={false}>
                {isVbg && !OverviewDetails ? (
                  'No information Available'
                ) : (
                  <span
                    data-testid='overview-content'
                    dangerouslySetInnerHTML={{ __html: decodeHTMLEntities(`${OverviewDetails}`) }}
                  />
                )}
                <ButtonWrapper />
              </Body>
            </OverviewContainer>
          </SpecCont>
        </Tab>
        <Tab label='Specs' onClick={() => props.openViewCall('View device details | Specs')}>
          <SpecCont>
            {isVbg && specsEntries.length === 0 ? (
              <OverviewContainer>
                <Body size='large' color='#000000' bold={false}>
                  No information Available
                </Body>
              </OverviewContainer>
            ) : (
              <>
                <LeftContainer>
                  {leftI.map((item, index) => (
                    <span key={item[0]} data-testid={`left-container-${index + 1}`}>
                      <SpecsContainer key={item[0]} title={item[0]} subtitle={item[1]} />
                    </span>
                  ))}
                </LeftContainer>
                <RightContainer>
                  {RightC.map((item, index) => (
                    <span key={item[0]} data-testid={`right-container-${index + 1}`}>
                      <SpecsContainer key={item[0]} title={item[0]} subtitle={item[1]} />
                    </span>
                  ))}
                </RightContainer>
              </>
            )}
          </SpecCont>
        </Tab>
        <Tab label='In the box' onClick={() => props.openViewCall('View device details | In the box')}>
          <SpecCont>
            <OverviewContainer>
              {isVbg && (!inboxItems || inboxItems.length === 0) ? (
                <Body size='large' color='#000000' bold={false}>
                  No information Available
                </Body>
              ) : (
                <UnorderedList>
                  {inboxItems &&
                    inboxItems?.map((value) => (
                      <ListItem size='bodyLarge' key={`Item ${value}`}>
                        {value}
                      </ListItem>
                    ))}
                </UnorderedList>
              )}
            </OverviewContainer>
          </SpecCont>
        </Tab>
      </Tabs>
    </MarginSides>
  );
}

DeviceSpecifications.propTypes = {
  specsData: PropTypes.object,
  inbox: PropTypes.string,
  OverviewDetails: PropTypes.string,
  openViewCall: PropTypes.func,
  isVbg: PropTypes.bool,
};

export default DeviceSpecifications;
