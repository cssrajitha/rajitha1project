// eslint-disable-next-line you-dont-need-lodash-underscore/get

import { render } from '../../modules/test-utils/renderHelper';
import CountdownTimer from './CountdownTimer';
import { CHANNELS, setupChannel } from '../../modules/test-utils/utils';
import productDetails from '../../pages/PDP/mocks/api/getDetails.json';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { setupServer } from '../../pages/PDP/mocks/setupServer';

jest.setTimeout(30000)

const Test = (channel) => {
  setupChannel(channel);
  describe(`<CountdownTimer component - ${channel}`, () => {
    setupServer();
    beforeEach(() => {
      render(
        <CountdownTimer
          product={productDetails?.data}
          isPreOrder
          defaultSkuPreOrderFlag
          // updateAddToCartDisableStatus={(status) => props.updateAddToCartDisableStatus(status)}
          // updateAddToCartDisableStatus={jest.fn()}
          disableAddToCart={jest.fn()}
          fromGW={false}
          isPreorderTestingEnabled='true'
          isPrePay={false}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('CountdownTimer Component to be rendered on screen', async () => {
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ iconicTimerIssueFFlag: 'TRUE' }));
      const temp = await new Promise((r)=>setTimeout(r,2000))
      console.log(temp)
    });
    test('CountdownTimer Component to be rendered on screen', async () => {
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ iconicTimerIssueFFlag: 'FALSE' }));
      const temp = await new Promise((r)=>setTimeout(r,2000))
      console.log(temp)
    });
  });
};

Test(CHANNELS.OMNI_RETAIL);
