import { cloneDeep } from 'lodash';
import { render, fireEvent, screen, act } from '../../modules/test-utils/renderHelper';
import DeviceInfo5G from './DeviceInfo5G';
import { Context } from '../../pages/PDP5G/PDP5gContext';
import {
  Deviceinfo5gMock,
  Deviceinfo5gMockProductDetails,
  Deviceinfo5gMockBundleProduct,
  Deviceinfo5gMockWithoutInventory,
  Deviceinfo5gMockWithoutInventoryDfill,
  Deviceinfo5gMockWithoutInventoryInstock,
  Deviceinfo5gMockWithoutInventoryWithBundle,
  Deviceinfo5gMockWithoutInventoryInstockWithBundle,
  Deviceinfo5gMockWithoutInventoryInstockWithOutBundle,
  Deviceinfo5gMockWithoutInventoryInstockWithOutBundleBillAccount,
  Deviceinfo5gMockWithoutLocal,
  Deviceinfo5gMockISPU,
} from './mocks/Deviceinfo5gMock';

const BYODContext = cloneDeep(Deviceinfo5gMock);
BYODContext.isByodUpdate = true;

describe(`<DeviceInfo5G/> component mount for EUP BYOD`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={BYODContext}>
        <DeviceInfo5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const cpsArea = screen.queryByText('Enter Customer Provided Device ID');
    expect(cpsArea).toBeInTheDocument();
  });
});

describe(`<DeviceInfo5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMock}>
        <DeviceInfo5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<DeviceInfo5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMockWithoutLocal}>
        <DeviceInfo5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<DeviceInfo5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMockWithoutInventoryInstockWithOutBundleBillAccount}>
        <DeviceInfo5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<DeviceInfo5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMockWithoutInventoryInstockWithOutBundle}>
        <DeviceInfo5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<DeviceInfo5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMockProductDetails}>
        <DeviceInfo5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<DeviceInfo5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMockBundleProduct}>
        <DeviceInfo5G />
      </Context.Provider>,
    );
  });
  test.skip('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<DeviceInfo5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMockWithoutInventory}>
        <DeviceInfo5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<DeviceInfo5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMockWithoutInventoryInstock}>
        <DeviceInfo5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<DeviceInfo5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMockWithoutInventoryDfill}>
        <DeviceInfo5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
});
describe(`<DeviceInfo5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMockWithoutInventoryWithBundle}>
        <DeviceInfo5G />
      </Context.Provider>,
    );
  });
  test.skip('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
  test.skip('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: /Instore pickup Toggle/,
    });
    fireEvent.click(shipit);
  });
});
describe(`<DeviceInfo5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMockWithoutInventoryInstockWithBundle}>
        <DeviceInfo5G />
      </Context.Provider>,
    );
  });
  test.skip('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
  test('should mount', async () => {
    expect(screen.getAllByRole('radio')[0]).toBeInTheDocument();
    fireEvent.change(screen.getAllByRole('radio')[0]);
  });
  test.skip('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: /Instore pickup Toggle/,
    });
    fireEvent.click(shipit);
  });
});
describe(`<DeviceInfo5G/> component mount1`, () => {
  beforeEach(() => {
    render(
      <Context.Provider value={Deviceinfo5gMockISPU}>
        <DeviceInfo5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
  test('should mount', async () => {
    sessionStorage.setItem('isSecondNumDfill', JSON.stringify('true'));
    sessionStorage.setItem('isSplitShipment', JSON.stringify('true'));
    const shipit = await screen.getByRole('checkbox', {
      name: /Instore pickup Toggle/,
    });
    fireEvent.click(shipit);
  });
});
describe(`<DeviceInfo5G/> component mount1`, () => {
  beforeEach(() => {
    sessionStorage.setItem('isSecondNumDfill', JSON.stringify('true'));
    sessionStorage.setItem('isSplitShipment', JSON.stringify('true'));
    render(
      <Context.Provider value={Deviceinfo5gMockISPU}>
        <DeviceInfo5G />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: 'shipit toggle',
    });
    fireEvent.click(shipit);
  });
  test('ISPU toggle change event', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: /Instore pickup Toggle/,
    });
    fireEvent.click(shipit);
    fireEvent.click(screen.getByText(/Check availability/));
  });
});
describe(`<DeviceInfo5G/> component mount1`, () => {
  beforeEach(() => {
    sessionStorage.setItem('isSecondNumDfill', JSON.stringify('true'));
    sessionStorage.setItem('isSplitShipment', JSON.stringify('true'));
    render(
      <Context.Provider value={Deviceinfo5gMockISPU}>
        <DeviceInfo5G />
      </Context.Provider>,
    );
  });
  test('ISPU toggle change event', async () => {
    const shipit = await screen.getByRole('checkbox', {
      name: /Instore pickup Toggle/,
    });
    fireEvent.click(shipit);
    fireEvent.click(screen.getByText(/Check availability/));
  });
  test('renders when scrolled is equal to true', () => {
    fireEvent.click(screen.getByText(/Check availability/));
    const dataTest = screen.getAllByTestId('onBackTestId')[0];
    act(() => {
      fireEvent.click(dataTest);
    });
  });
});
