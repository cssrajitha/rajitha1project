import { contractTermLabels } from "../../constants/ContractTerms";
import { contractTermList, dpTermList } from "../../constants/constants";
/**
 * Determines whether to show the down payment options.
 *
 * @param {boolean} isDpInVisible - Indicates if the down payment is visible.
 * @param {boolean} dppIndicatorValue - The value of the DPP indicator.
 * @param {boolean} declineBuyout - Indicates if the buyout is declined.
 * @param {boolean} buyOutToggleOn - Indicates if the buyout toggle is on.
 * @returns {boolean} - Returns true if the down payment options should be shown, otherwise false.
 */
export function showDownPaymentOptions(isDpInVisible, dppIndicatorValue, declineBuyout, buyOutToggleOn) {
  return !isDpInVisible && !dppIndicatorValue && (!declineBuyout || buyOutToggleOn);
}

const  sortByContractTerm = (arr) => {
    return arr.slice().sort((a, b) => {
    const indexA = contractTermList.indexOf(a);
    const indexB = contractTermList.indexOf(b);
    return indexA - indexB;
  });
}

export function addDynamicContractPrices({ selectedSku, paymentOptions }) {
  const allPriceKeys = Object.keys(selectedSku?.price || {});
  const selectedKeys = allPriceKeys?.filter((key) => key.includes('YearPrice') || key.includes('MonthPrice'));
  const dynamicContractPrices = sortByContractTerm(selectedKeys);
  dynamicContractPrices.forEach((key) => {
    const priceObj = selectedSku?.price?.[key];
    if (priceObj && priceObj?.originalPrice && priceObj?.contractText) {
      paymentOptions.push({
        id: `DEVICE_CONTRACT_${key}`,
        text: `$${priceObj.originalPrice}`,
        value: `$${priceObj.originalPrice}:${contractTermLabels?.[key]}:`,
        subtext: priceObj.contractText,
        name: priceObj.contractText,
        'data-track': `Productdetail_${key.replace(/\s+/g, '')}`,
      });
    }
  });
}

export function sortPaymentOptions({ paymentOptions, isVbgFlag }) {
  if(isVbgFlag) {
    const sortedData = paymentOptions
      .filter(item => dpTermList.includes(parseInt(item.name)))
      .sort((a, b) => dpTermList.indexOf(parseInt(a.name)) - dpTermList.indexOf(parseInt(b.name)));
    paymentOptions = sortedData;
  }
  return paymentOptions;
}