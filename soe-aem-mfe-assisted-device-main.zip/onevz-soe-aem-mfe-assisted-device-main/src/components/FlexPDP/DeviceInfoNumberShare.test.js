// eslint-disable-next-line you-dont-need-lodash-underscore/get
import { get as getProp } from 'lodash';
import { render, screen, fireEvent } from '../../modules/test-utils/renderHelper';
import DeviceInfo from './DeviceInfo';
import { CHANNELS, setupChannel } from '../../modules/test-utils/utils';
import protectionFeatures from '../../pages/PDP/mocks/api/getProtectionFeatures.json';
import productDetails from '../../pages/PDP/mocks/api/getDetails.json';
import cartDetails from '../../pages/PDP/mocks/api/retrieveCart.json';
import customerProfileDetails from '../../pages/PDP/mocks/api/customerProfile.json';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { setupServer } from '../../pages/PDP/mocks/setupServer';
import mockDeviceInfoCredit from './mocks/mockDeviceInfoCredit.json';

mockDeviceInfoCredit.fullRetailPrice = {
  allPromotions: [{ discountMonthlyPrice: '234' }],
  originalPrice: 1199.99,
  contractText: 'Full Retail Price',
};
jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => true,
  }),
  { virtual: true },
);
const mockBByData = {
  storeId: '0281',
  upc: '400055816159',
  deviceSku: '5581615',
  priceInfo: [
    {
      priceId: 'cnt302',
      activationType: 'upgrade',
      purchaseType: 'FINANCED',
      contractTerm: 36,
      regularPrice: 8.33,
      currentPrice: 8.33,
      taxBasis: 299.99,
      downPaymentAmount: 0.0,
      bbyDownPayment: 0.0,
    },
    {
      priceId: 'cnt302',
      activationType: 'upgrade',
      purchaseType: 'FULL_SRP',
      contractTerm: 1,
      regularPrice: 299.99,
      currentPrice: 299.99,
      taxBasis: 299.99,
      downPaymentAmount: 0.0,
      bbyDownPayment: 0.0,
    },
    {
      priceId: 'cnt301',
      activationType: 'new',
      purchaseType: 'FINANCED',
      contractTerm: 36,
      regularPrice: 8.33,
      currentPrice: 8.33,
      taxBasis: 299.99,
      downPaymentAmount: 0.0,
      bbyDownPayment: 0.0,
    },
    {
      priceId: 'cnt301',
      activationType: 'new',
      purchaseType: 'FULL_SRP',
      contractTerm: 1,
      regularPrice: 299.99,
      currentPrice: 299.99,
      taxBasis: 299.99,
      downPaymentAmount: 0.0,
      bbyDownPayment: 0.0,
    },
  ],
};
jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => false,
    isIpad: () => true,
    executeShellFunction: jest
      .fn()
      .mockImplementation(() => global.window.BbyDevicePricingDetails(JSON.stringify(mockBByData))),
  }),
  { virtual: true },
);

jest.mock('onevzsoemfecommon/CommonService', () => ({
  ...jest.requireActual('onevzsoemfecommon/CommonService'),
  useLazyUpdateConsentQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: false,
      isError: true,
      isFetching: false,
      error: { name: 'System Error', code: '400', Message: 'Could not get device details' },
    },
  ],
}));
jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => true,
  }),
  { virtual: true },
);
jest.mock(
  '../../modules/services/APIService/APIServiceHooks',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
      useLazyGetRetrieveURCodeQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                meta: {
                  timestamp: 1714739048101,
                  cxpCorrelationId:
                    '2024-05-03T12:24:08.+0000:6d760cb7d9fbe0b1:cxp-shopping-services-684fb47569-9nqsc:nssit2',
                },
                data: {
                  retrieveURCforCartMtnList: {
                    mtnUpgradeReasonCodes: [
                      {
                        mtn: '2697161703',
                        upgradeReasonCodes: [
                          {
                            code: 'MA',
                            description: 'Manager Exception with non-working equipment',
                            contractTermDetails: {
                              contractTerm: 'VERIZON_EDGE',
                            },
                            defaultReasonCode: false,
                          },
                          {
                            code: 'WA',
                            description: 'WFG RETURN - DEVICE PAYMENT PRICE',
                            contractTermDetails: {
                              contractTerm: 'VERIZON_EDGE',
                            },
                            defaultReasonCode: true,
                          },
                        ],
                      },
                    ],
                  },
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
      useLazyGetDevicePricingEligibilityQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                deviceFinanceLimit: 2000.0,
                totalFinanceLimit: 4864.59,
                isDevicePaymentEligible: true,
                isDevicePaymentPending: false,
                custTypeCode: 'PE',
                downPaymentPercentage: 0,
                inEligibleMessage: 'CUSTOMER HAS A PAST DUE BALANCE GREATER THAN  $ 24.99',
                isConditionalEligibility: true,
                dpMessage: {
                  message:
                    'You are prequalified for Device payment with $2000.00 Device finance limit and $4864.59 Total finance limit remaining',
                  type: 'WARNING',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      dpTermPrices: {
                        firstMonthPrice: 16.85,
                        remainingMonthPrice: 16.66,
                        dpTerm: 30,
                        downPayment: 0.0,
                      },
                    },
                    {
                      dpTermPrices: {
                        firstMonthPrice: 20.9,
                        remainingMonthPrice: 20.83,
                        dpTerm: 24,
                        downPayment: 0.0,
                      },
                    },
                    {
                      dpTermPrices: {
                        firstMonthPrice: 14.19,
                        remainingMonthPrice: 13.88,
                        dpTerm: 36,
                        downPayment: 0.0,
                      },
                    },
                  ],
                  vvcDeviceFinancingOfferPrice: {
                    originalMonthlyPrice: 33.33,
                    monthlyDiscountPrice: 15.0,
                    contractText: 'Monthly Payment with Verizon Visa Card',
                    installmentTerm: 36,
                  },
                  fullRetailPrice: { allPromotions: [{ discountMonthlyPrice: '234' }] },
                },
                totalFinanceLimitRemaining: 4864.59,
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
      useLazyRetrievedppQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                data: {
                  dppIndicator: false,
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
      useLazyGetBestBuyInventoryQuery: () => [
        () => {},
        {
          status: 'Success',
          isUninitialized: false,
          isLoading: false,
          isSuccess: true,
          isError: false,
          isFetching: false,
          data: {
            errors: [
              {
                namespace: 'cxp-bestbuy_adapter',
                name: 'VALIDATION_ERROR',
                id: '6666',
                debug_id: '2025-07-10T19:58:33.470774703Z|36a38010-2f48-459a-8ef9-c3e48896f335-131309|null',
                message: '',
              },
            ],
          },
        },
      ],
    };
  },
  { virtual: true },
);
jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
  useLazyGetDevicePricingEligibilityQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: {
        dpMessage: {
          message:
            'You are prequalified for Device payment with $2000.00 Device finance limit and $4864.59 Total finance limit remaining',
          type: 'WARNING',
        },
      },
    },
  ],
  useLazyGetBestBuyInventoryQuery: () => [
    () => {},
    {
      status: 'Success',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: {
        errors: [
          {
            namespace: 'cxp-bestbuy_adapter',
            name: 'VALIDATION_ERROR',
            id: '6666',
            debug_id: '2025-07-10T19:58:33.470774703Z|36a38010-2f48-459a-8ef9-c3e48896f335-131309|null',
            message: '',
          },
        ],
      },
    },
  ],
}));

jest.mock(
  'onevzsoemfecommon/DeviceAPIService',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('onevzsoemfecommon/DeviceAPIService'),
      useLazyRetrievedppQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                data: {
                  dppIndicator: true,
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
    };
  },
  { virtual: true },
);
jest.mock('./SmartWatchBandOptions', () => ({ chooseSWBand }) => (
  <div
    role='button'
    data-testid='chooseSWBand'
    style={{ height: '150px', width: '300px' }}
    onClick={() => chooseSWBand({ target: { value: 'band' } })}
    onKeyDown={() => chooseSWBand({ target: { value: 'band' } })}
    tabIndex={0}
  >
    Click me
  </div>
));
jest.mock('./SmartWatchSizeOptions', () => ({ chooseSWBandSize }) => (
  <div
    role='button'
    data-testid='chooseSWBandSize'
    style={{ height: '150px', width: '300px' }}
    onClick={() => chooseSWBandSize({ target: { value: 'band' } })}
    onKeyDown={() => chooseSWBandSize({ target: { value: 'band' } })}
    tabIndex={0}
  >
    Click me
  </div>
));
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradleProperty: () => ['', 'UNL', 'FALSE', true, 'TRUE', 'TRUE', '', '', '', 'TRUE', 'TRUE'],
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfecommon/DeviceAPIService',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('onevzsoemfecommon/DeviceAPIService'),
      useLazyEligibleNumberShareListQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                status: 'Success',
                payload: {
                  deviceDetailsAndOffers: {
                    displayName:
                      'Apple Watch Series 9 GPS + Cellular 41mm Pink Aluminum Case with Light Pink Sport Band - S/M',
                    sorId: 'MRHY3LL/A',
                    color: 'Pink (Aluminum)',
                    imageURL:
                      'https://ss7.vzw.com/is/image/VerizonWireless/apple-watch-series-9-gps-cellular-41mm-pink-aluminum-case-light-pink-sport-band-mrhy3ll-a-a',
                    supportsAllVZProtectFeatures: false,
                    eligibleNumberShareOS: ['Apple iOS'],
                    smartLocator: false,
                  },
                  mandatoryPairingNeeded: false,
                  numberShareEligibleDevices: [
                    {
                      customerName: 'RAVI JETER',
                      nickName: 'RAVI-7979',
                      mtn: '5155547979',
                      deviceDisplayName: 'IPHONE 13 MINI 128 MIDNIGHT',
                      deviceImageUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-mini-midnight',
                      currentConnectedDevices: 0,
                      maxConnectedDevicesAllowed: 5,
                      preSelect: true,
                      trunkMtn: '5155547979',
                    },
                  ],
                  mtn: '5154529414',
                  lineActivityType: 'AAL',
                  watchToWatchUpgrade: false,
                  currentPaired: false,
                  accountPairedDevice: {
                    mtn: '12345678',
                    accountPairingCanBeChanged: false,
                  },
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
    };
  },
  { virtual: true },
);

const Test = (channel) => {
  setupChannel(channel);
  describe(`<DeviceInfo component - ${channel}`, () => {
    setupServer();
    const modProductDetails = productDetails;

    modProductDetails.data.deviceProduct = {
      ...modProductDetails.data.deviceProduct,
      childSkusByPreOwnedCondition: [
        {
          test: 'test',
        },
      ],
    };
    const details = modProductDetails.data.deviceProduct || {};
    details.isNumberShareMandatory = false;
    details.isNumberShareCapable = true;
    const defaultSkuStringValue = getProp(details, 'defaultSKU') || '';
    const defaultSkuObjValue = getProp(details.defaultSKUObj, 'sorId') || '';
    const defaultSku = defaultSkuStringValue !== '' ? defaultSkuStringValue : defaultSkuObjValue;
    const defaultSkuDetails = details.childSkus.filter((sku) => sku.sorId && sku.sorId === defaultSku);
    beforeEach(() => {
      sessionStorage.setItem('elvisFFlag', 'TRUE');
      window.mfe = {};

      window.vzdl = {
        page: {},
        target: { message: '' },
        event: { value: '' },
      };
      render(
        <DeviceInfo
          details={details}
          getContractTerm={jest.fn()}
          productDetails={modProductDetails.data}
          protectionFeatures={protectionFeatures}
          cartDetails={cartDetails.data}
          customerProfileDetails={customerProfileDetails.data}
          activeMtn='5185673926'
          selectedColor={defaultSkuDetails[0].color.displayName}
          setSelectedColor={jest.fn()}
          ispuToggleOn={false}
          setIspuToggleOn={jest.fn()}
          isShipItToggleOn={false}
          setIsShipItToggleOn={jest.fn()}
          selectedSku={defaultSkuDetails[0]}
          setSelectedSku={jest.fn()}
          selectedProtectionFeature={protectionFeatures.payload.features[1]}
          setSelectedProtectionFeature={jest.fn()}
          selectedSize={defaultSkuDetails[0].capacity}
          setSelectedSize={jest.fn()}
          setBuyoutToggleChange={jest.fn()}
          updateNumberShare={jest.fn()}
          isNumberShare
          numberShareValue='9732022897'
          sharedMtnValue=''
          updateNumberShareValue={jest.fn()}
          updateSharedMtnValue={jest.fn()}
          setSelectedPaymentInfo={jest.fn()}
          isContractChange
          isRfexFlow
          setShowDeviceProtectionModal={jest.fn()}
          updateDeviceId={jest.fn()}
          updateSimId={jest.fn()}
          updateDeviceData={jest.fn()}
          showDeviceProtectionModal='true'
          isPreorderCountDownEnabled='true'
          setTmpLinkClicked={jest.fn()}
          setProtectionShownStatusInDevice={jest.fn()}
          tmpScreenOpened={jest.fn()}
          setUpgradeReasonType={jest.fn()}
          groupByColors={jest.fn()}
          groupBySmartWatchBand={jest.fn()}
          setisInStock={jest.fn()}
          setIncompatibleSim={jest.fn()}
          sendFullRetailPrice={jest.fn()}
          isPreOrder={false}
          setBbyPaymetOptionPriceId={jest.fn()}
          bbyPaymetOptionPriceId='cnt302'
          setBbyContractTerm={jest.fn()}
          bbyContractTerm='36'
          upcCodeFromPdpScan='987654321012'
          isBBYLocalOrder
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('should click device numberShareToggle', async () => {
      const numbersharetoggle = await screen.findByRole('checkbox', { name: /numbershare toggle/i });
      expect(numbersharetoggle).not.toBeDisabled();
      fireEvent.change(numbersharetoggle, { target: { value: 'checked' } });
      fireEvent.click(numbersharetoggle);
      const numberShareIcon = screen.getByTestId('sharedNumSharIcon');
      expect(numberShareIcon).toBeInTheDocument();
      fireEvent.click(numberShareIcon);
    });
  });
};
Test(CHANNELS.OMNI_RETAIL);
