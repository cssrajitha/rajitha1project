import React from 'react';

const BackorderText = ({ shippingDate }) => (
    <div className=' u-floatLeft u-textBold' id='devicePdpBackOrderText' name='back_Order' style={{ color: '#0077B4' }}>
      {' '}
      Back order device ships by {shippingDate}{' '}
    </div>
  );

export default BackorderText;
