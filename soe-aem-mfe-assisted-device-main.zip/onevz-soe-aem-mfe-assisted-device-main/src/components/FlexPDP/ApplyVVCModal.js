import React, { useEffect, useState } from 'react';
import { ModalTitle, ModalBody, Modal } from '@vds/modals';
import { Button } from '@vds/buttons';
import styled from 'styled-components';
import {
  useCreateApplicationMutation,
  useAddVzccFeedbackStatusMutation,
  useAddSubmitFeedbackMutation,
} from '../../modules/services/APIService/APIServiceHooks';

const TextStyle = styled.div`
  padding-bottom: 20px;
`;
const NotNow = styled.div`
  display: inline-block;
  cursor: pointer;
`;
const StyledButton = styled(Button)`
  display: inline-block;
  margin-right: 30px;
`;
const FormContainer = styled.div`
  max-width: 600px;
  padding: 20px;
`;
const FormGroup = styled.div`
  display: flex;
  align-items: flex-start;
  gap: var(--space-1X, 4px);
  font-size: 15px !important;
`;
const MDNSelect = styled.select`
  display: flex;
  width: 328px;
  height: 44px;
  justify-content: flex-end;
  align-items: center;
  margin-right: 40px;
  border-radius: var(--border-radius, 4px);
  border: 1px solid var(--formcontrols-border, #6f7171);
`;
const InputSelect = styled.input`
  display: flex;
  width: 328px;
  height: 44px;
  justify-content: flex-end;
  align-items: center;
  margin-right: 40px;
  border-radius: var(--border-radius, 4px);
  border: 1px solid var(--formcontrols-border, #6f7171);
`;
const FormStyle = styled.form`
  display: flex;
`;

function ApplyVVCModal({
  vvcEligibleType,
  isaacPromo,
  customerProfileDetails,
  processAddToCartNextSteps,
  setShowApplyVVCModal,
  selectedSku,
}) {
  const [createApplication, createApplicationResults] = useCreateApplicationMutation();
  const [addSubmitFeedback] = useAddSubmitFeedbackMutation();
  const [addVzccFeedbackStatus] = useAddVzccFeedbackStatusMutation();
  const [selectedMTN, setSelectedMTN] = useState('');
  const activeMtns = customerProfileDetails?.customer?.billAccounts[0]?.mtns;
  const dfoNachoVVCFFlag = /true/i.test(JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.dfoNachoVVCFFlag);
  const aprNCHOFFlag = /true/i.test(JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.aprNCHOFFlag);
  const vvcFeedbackDispositionFFlag = JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.vvcFeedbackDispositionFFlag;

  const handleAddVzccFeedbackStatus = (status) => {
    const payload = {
      cartId: sessionStorage.getItem('cartId') || '',
      soiEngagementId: isaacPromo?.proposition?.soiEngagementId,
      rank: isaacPromo?.proposition?.rank,
      vzccStatus: {
        feedbackStatus: status,
      },
    };
    addVzccFeedbackStatus({ body: payload });
  };

  const sendApplication = () => {
    const payload = {
      customerInfo: {
        locationCode: customerProfileDetails?.customer?.orderLocationCode,
        messageMtn: selectedMTN,
        originalMtn: selectedMTN,
      },
      syfOfferId: isaacPromo?.proposition?.syfOfferId,
      propositionId: isaacPromo?.proposition?.propositionId,
      market: '',
      outletType: '',
      promotionalSPOCategoryCode: isaacPromo?.proposition?.spoName,
      sessionId: isaacPromo?.sessionId,
      soiEngagementId: isaacPromo?.proposition?.soiEngagementId,
      rank: isaacPromo?.proposition?.rank,
      offerIdFromSYF: 'false',
      isDfoCustomer: 'Y',
      pageContext: `DFO-${selectedSku?.price?.fullRetailPrice?.originalPrice}`,
    };
    createApplication({ body: payload });
  };

  const handleAddSubmitFeedback = () => {
    const payload = {
      customerInfo: {
        locationCode: customerProfileDetails?.customer?.orderLocationCode,
        isNewCustomer: false,
        creditAppNum: '',
      },
      syfOfferId: isaacPromo?.proposition?.syfOfferId,
      sessionId: isaacPromo?.sessionId,
      customerSelection: 'Decline',
      rank: isaacPromo?.proposition?.rank,
      propositionId: isaacPromo?.proposition?.propositionId,
      soiEngagementId: isaacPromo?.proposition?.soiEngagementId,
      promotionalSPOCategoryCode: isaacPromo?.proposition?.spoName,
      offerIdFromSYF: false,
    };
    addSubmitFeedback({ body: payload });
  };

  useEffect(() => {
    if (createApplicationResults.data) {
      sessionStorage.setItem('isVVCAplicationCreated', true);
      processAddToCartNextSteps();
    }
  }, [createApplicationResults]);

  const onSelectMtn = (e) => {
    setSelectedMTN(e.target.value);
  };
  const closeModal = (opened) => {
    if (!opened) {
      setShowApplyVVCModal(false);
      if (vvcFeedbackDispositionFFlag) {
        handleAddVzccFeedbackStatus('Declined');
        handleAddSubmitFeedback();
      }
    }
  };

  return (
    <Modal
      data-testid='applyVVCModal'
      fullScreenDialog
      hideCloseButton={false}
      opened
      onOpenedChange={closeModal}
      ariaLabel='applyVVCModal'
    >
      <ModalTitle data-testid='modal-header'>
        <div>
          {vvcEligibleType === 'preQualify' ? (
            <b>See if you prequalify for The Verizon Visa® Card</b>
          ) : (
            <b>Nice. You’re pre-approved for Verizon Visa® Card!</b>
          )}
        </div>
      </ModalTitle>
      <ModalBody data-testid='modal-body'>
        {vvcEligibleType === 'preQualify' && (
          <TextStyle>Get a decision in seconds with no impact to your credit score.</TextStyle>
        )}

        <TextStyle>
          Get 0% APR financing with 36 equal monthly payments on device purchases when you apply and are approved for
          the Verizon Visa Card. Plus, you’ll earn 4% in Verizon Dollar rewards you can use toward your bill, and much
          more.
        </TextStyle>

        <TextStyle>
          To apply for the Verizon Visa card, may I have your consent to send an SMS with a link to the application?
        </TextStyle>
        <FormContainer>
          <FormStyle>
            <div>
              <FormGroup>Select MDN</FormGroup>
              <MDNSelect data-testid='selectedMdn' onChange={(e) => onSelectMtn(e)}>
                <option value='' selected hidden>
                  {selectedMTN}
                </option>
                {activeMtns?.map((activeLine) => (
                  <option key={activeLine.mtn} value={activeLine.mtn}>
                    {activeLine.mtn}
                  </option>
                ))}
              </MDNSelect>
            </div>
            <div>
              <FormGroup>MDN to be linked to Verizon Visa Card</FormGroup>
              <InputSelect type='text' className='mdn-select' data-testid='selectedMdnLink' value={selectedMTN} />
            </div>
          </FormStyle>
        </FormContainer>
        <br />
        <div>
          {dfoNachoVVCFFlag && !aprNCHOFFlag ? (
            <b>Get up to $200 cash back with Verizon Visa® Card.</b>
          ) : (
            <b>Get up to $150 cash back with Verizon Visa® Card.</b>
          )}
        </div>
        {dfoNachoVVCFFlag && !aprNCHOFFlag ? (
          <TextStyle>
            Get a $50 statement credit when you open an account and make a purchase in the first 90 days. Get an
            additional $150 statement credit when you spend $1500 using your card in the first 90 days. Offer available
            10/15/25 to 1/6/26.
          </TextStyle>
        ) : (
          <TextStyle>
            Get a $50 statement credit when you open an account and make a purchase in the first 90 days. Get an
            additional $100 statement credit when you spend $1500 using your card in the first 90 days. Limited time
            offer.
          </TextStyle>
        )}
        <div>
          <b>Earn rewards. Redeem. Repeat.</b>
        </div>
        <TextStyle>
          Use the Verizon Visa Card everywhere Visa credit cards are accepted to earn Verizon Dollars. Earn 4% on
          grocery store purchases and gas purchases, 4% on dining purchases, including take-out, 4% on Verizon
          purchases, and 1% on all other purchases.
        </TextStyle>
        <div>
          <b>Save on your Verizon Bill every month.</b>
        </div>
        <TextStyle>
          New enrollees to Verizon’s Auto Pay can get up to $10/mo off each eligible account or phone line, up to 12
          lines max (depending on plan). Enroll with the card to earn 1% in rewards on your bill.
        </TextStyle>
        <TextStyle>
          To learn more about the Verizon Visa Card please visit{' '}
          <a href='https://www.verizon.com/verizonvisacard' target='_blank'>
            verizon.com/verizonvisacard
          </a>
          . Further details can be found on the Verizon Visa Card FAQs at{' '}
          <a href='https://www.verizon.com/support/verizon-visa-card-faqs' target='_blank'>
            https://www.verizon.com/support/verizon-visa-card-faqs
          </a>
          .
        </TextStyle>

        <StyledButton
          data-testid='vvcSendApplication'
          data-track='Send'
          onClick={() => {
            sendApplication();
            if (vvcFeedbackDispositionFFlag) {
              handleAddVzccFeedbackStatus('Applied');
            }
          }}
          disabled={!selectedMTN}
        >
          Send
        </StyledButton>

        <NotNow
          data-testid='primary_btn_2'
          onClick={() => {
            processAddToCartNextSteps();
            if (vvcFeedbackDispositionFFlag) {
              handleAddVzccFeedbackStatus('Declined');
              handleAddSubmitFeedback();
            }
          }}
          aria-hidden='true'
        >
          <u>Not now</u>
        </NotNow>
      </ModalBody>
    </Modal>
  );
}

export default ApplyVVCModal;
