export const EquipOffers = ['Simple', 'Trade', 'Virtual Reward', 'Multi Line BOGO', 'Multi Line BMSM', 'BYOD'];
export const fiveGProfInstallCharges = {
  profInstallCharge: '$99.00',
  profInstallStrikedAmt: '$99.00 ',
  zeroDollarAmount: '$0.00',
  limitedTimeOffer: 'Limited time offer',
  orderReviewDisclaimer: null,
  installDescription: 'Non-refundable. Billed after installation.',
  additionalDescription: null,
  taxesAndCharges: 'taxes & surcharges',
  oneTimeCharges: 'One Time Charges.',
  taxesAndFees: 'Plus taxes & Surcharges.',
  tgwPrice: '$0.00',
  freeofCharge: 'Included free of charge',
};
export const DEVICE_PLAN_INCOMPATIBLE_MESSAGE =
  'Plan is not compatible with the chosen device. Click OK to choose compatible plans';
export const DEFAULT_SIM_SWAP_ERROR_MSG =
  'SIM or SIM and Device change has been restricted. Direct the customer to self-serve online or to contact VZ Cust Protection at 888-483-7200';

// mtnType constants
export const MTN_TYPE_PRE_TO_POST = 'PRETOPOSTPAY';
export const MTN_TYPE_YAHOO = 'YAHOO';
export const MTN_TYPE_VISIBLE = 'VISIBLE';
export const MTN_TYPE_HARMONY = 'HARMONY';

export const carrierModalText =
  'The device provided may be locked by the carrier where originally purchased. Moving forward without connecting with the previous carrier may cause delays with your activation.';
export const carrierModalSubText = 'Would you like to pause to contact the previous carrier?';
export const carrierModalAcknowledgementext =
  'I understand the device I am activating may be carrier locked and will not send or receive calls, texts or data on the Verizon Network until it has been unlocked by previous carrier. If porting to Verizon in this order, service with your previous provider may be lost while the unlock process is completed.';
export const carrierLockResponseText =
  'If this is not a Verizon device, it may be carrier locked. Please contact the previous carrier for assistance.';

export const secondNumberActivationHeaderText = 'Second Number Activation';
export const secondNumberActivationSubText =
  'This device is tied to a Second Number. Advise customer to download and install the eSIM profile in the new device to complete IMEI activation for the second number.';
export const WIFI_BACKUP_DETAILS = {
  title: 'Wi-Fi Backup',
  subtitle: 'Please advise the customer that this is not a primary internet solution and speed is not guaranteed.',
  advisory: 'Reliable backup when your primary internet goes down.',
  monthlyPrice: '$30',
  data1: {
    heading: 'Unlimited data for 7 days a month',
    content:
      'Stay connected in case your primary internet service provider goes down with unlimited backup data for up to 7 days a month.' +
      "Download speeds up to 32 Mbps; upload speeds up to 5 Mbps. For backup use in the event of primary internet provider network outage. Backup power source required for use during power outage. When network is experiencing heavy traffic, your data may be temporarily slowed. Data usage is subject to Verizon's Customer Agreement.",
  },
  data2: {
    heading: 'Router included',
    content:
      'The included state-of-the-art router provides coverage for multiple devices so you get optimal performance in case your primary internet service provider goes down.' +
      "Verizon owns the equipment provided with your plan, including the router. If you choose to disconnect service, you must return equipment within 30 days or you'll incur an unreturned equipment fee(s).",
  },
  data3: {
    heading: 'Easy to setup & use',
    content:
      'Keep your router plugged in and if your primary internet connection goes out, connect your devices to Wi-Fi Backup to start a 24-hour session. You can check your usage at anytime.',
  },
};
export const WIFI_BACKUP_SWITCH_VHI_LITE = {
  header: 'Switch to Verizon Home Internet Lite',
  body: 'Switching from Wi-Fi Backup to Verizon Home Internet Lite would need a corresponding router and plan selection to be done again.',
};

export const VHI_LITE_SWITCH_WIFI_BACKUP = {
  header: 'Switch to Wi-Fi Backup',
  body: 'Switching from Verizon Home Internet Lite to Wi-Fi Backup would need a corresponding router and plan selection to be done again.',
};

export const WIFI_BACKUP_SWITCH_LTE = {
  header: 'Switch to Wi-Fi Backup',
  body: 'Switching from LTE Home Internet to Wi-Fi Backup would need a corresponding router and plan selection to be done again.',
};

export const WIFI_BACKUP_SWITCH_5G = {
  header: 'Switch to Wi-Fi Backup',
  body: 'Switching from 5G Home Internet to Wi-Fi Backup would need a corresponding router and plan selection to be done again.',
};

export const SWITCH_MODAL_5G = {
  header: 'Switch to 5G Home Internet',
  body: 'Switching from Wi-Fi Backup to 5G Home Internet would need a corresponding router and plan selection to be done again.',
};

export const SWITCH_MODAL_LTE = {
  header: 'Switch to LTE Home Internet',
  body: 'Switching from Wi-Fi Backup to LTE Home Internet would need a corresponding router and plan selection to be done again.',
};
