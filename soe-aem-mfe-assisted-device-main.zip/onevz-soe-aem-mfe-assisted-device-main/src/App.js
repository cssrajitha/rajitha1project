import React, { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Gridwall from './pages/Gridwall';
import StoreProvider from './modules/store';

// Lazy load components (PDP, PDP5G, DpBuyout)
const PDP = lazy(() => import(/* webpackChunkName: "device-mfe-pdp" */ './pages/PDP/index'));
const PDP5G = lazy(() => import(/* webpackChunkName: "device-mfe-pdp5g" */ './pages/PDP5G/index'));

function App() {
  return (
    <StoreProvider>
      <Router>
        <Suspense fallback={<div>Loading...</div>}>
          <Routes>
            <Route exact path='/sales/assisted/new/device/gridwall.html' element={<Gridwall />} />
            <Route exact path='/sales/assisted/new/device/pdp.html' element={<PDP />} />
            <Route exact path='/sales/assisted/new/device/pdp5g.html' element={<PDP5G />} />
          </Routes>
        </Suspense>
      </Router>
    </StoreProvider>
  );
}

export default App;
