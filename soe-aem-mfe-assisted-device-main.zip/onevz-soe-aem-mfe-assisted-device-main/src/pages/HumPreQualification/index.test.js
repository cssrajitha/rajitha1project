import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import { render, screen } from '../../modules/test-utils/renderHelper';
// import HumPreQualificationContainer from './HumPreQualificationContainer';
import HumPreQualification from './index';

const fiveGEmptyListTesting = (text, customerData, searchtxt) => {
  describe(`Gridwall component - 5G Home - ${text}`, () => {
    const handlers1 = [
      rest.post(`*/accountlandingservice/flexV2/customerProfile`, (req, res, ctx) => {
        console.log('inside /accountlandingservice/flexV2/customerProfile');
        return res(ctx.status(200), ctx.json(customerData));
      }),
    ];
    const server1 = setupServer(...handlers1);
    const activeMTN = 'newLine1';
    jest.setTimeout(20000);
    beforeAll(() => {
      server1.listen();
      sessionStorage.setItem('channel', 'OMNI-RETAIL');
    });
    beforeEach(() => {
      window.history.pushState({}, 'Gridwall', `/sales/assisted/new/gridwall.html?activeMtn=${activeMTN}`);
      render(<HumPreQualification resetToggleOptions={jest.fn()} />, {});
    });
    test(`should render with 5G Home - ${text}`, async () => {
      const category = await screen.findAllByText(searchtxt);
      expect(category[0]).toBeInTheDocument();
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
    });
  });
};

fiveGEmptyListTesting(
  'Hum PreQualification',
  {
    data: {
      customer: {
        email: 'basineni.naidu@verizon.com',
        billAccounts: [
          {
            mtns: [
              {
                mtn: '2762063006',
              },
            ],
          },
        ],
      },
    },
  },
  'Validate Email',
);

fiveGEmptyListTesting(
  'Hum PreQualification2',
  {
    data: {
      customer: {
        billAccounts: [
          {
            mtns: [
              {
                mtn: '2762063006',
              },
            ],
          },
        ],
      },
    },
  },
  'Validate Email',
);

fiveGEmptyListTesting(
  'Hum PreQualification2',
  {
    data: {
      customer: {
        billAccounts: [
          {
            mtns: [],
          },
        ],
      },
    },
  },
  'Validate Email',
);
