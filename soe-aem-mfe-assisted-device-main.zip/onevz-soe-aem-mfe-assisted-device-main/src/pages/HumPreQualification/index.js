import React from 'react';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import HumPreQualificationContainer from './HumPreQualificationContainer';
import HumPreQualificationApiCallHook from './HumPreQualificationApiCallHook';

function HumPreQualification() {
  const {
    CustomerProfileResult,
    CartDetailsResult,
    emailValidateRequestBody,
    EmailValidateResponse,
    getYearsRequestBody,
    GetYearsResponse,
    getModelsRequestBody,
    GetModelsResponse,
    getMakesRequestBody,
    GetMakesResponse,
    getHumCompatibilityBody,
    HumCompatibilityResponse,
  } = HumPreQualificationApiCallHook();
  const activeMtn = getQueryParamByName('activeMtn');
  const productId = getQueryParamByName('productId');
  const defaultSku = getQueryParamByName('defaultSku') || getQueryParamByName('deviceSKU');

  return (
    <div data-testid='HumPreQualificationID'>
      {CustomerProfileResult?.data && (
        <HumPreQualificationContainer
          activeMtn={activeMtn}
          productId={productId}
          defaultSku={defaultSku}
          CustomerProfileResult={CustomerProfileResult?.data?.data}
          CartDetailsResult={CartDetailsResult?.data?.data}
          emailValidateRequestBody={emailValidateRequestBody}
          EmailValidateResponse={EmailValidateResponse}
          getYearsRequestBody={getYearsRequestBody}
          GetYearsResponse={GetYearsResponse}
          getModelsRequestBody={getModelsRequestBody}
          GetModelsResponse={GetModelsResponse}
          getMakesRequestBody={getMakesRequestBody}
          GetMakesResponse={GetMakesResponse}
          getHumCompatibilityBody={getHumCompatibilityBody}
          HumCompatibilityResponse={HumCompatibilityResponse}
        />
      )}
    </div>
  );
}

export default HumPreQualification;
