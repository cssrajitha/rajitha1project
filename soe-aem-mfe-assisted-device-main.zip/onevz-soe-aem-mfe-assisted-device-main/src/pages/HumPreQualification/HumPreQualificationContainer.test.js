import React from 'react';
import { setupServer } from 'msw/node';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { render, screen } from '../../modules/test-utils/renderHelper';
import HumPreQualificationContainer from './HumPreQualificationContainer';
import HumPreQualification from './index';

describe(`<HumPreQualification /> component`, () => {
  const props = {
    DeviceDetailsResult: { data: { data: {} } },
    CustomerProfileResult: { customer: { billAccounts: [{ mtns: ['123456789'] }] } },
    CartDetailsResult: { data: { data: {} } },
    ProtectionFeaturesResult: { data: { data: {} } },
  };
  setupServer();
  beforeEach(() => {
    window.history.pushState(
      {},
      'HumPreQualification',
      '/sales/assisted/new/HumPreQualification.html?offerEligible=Y&activeMtn=2812530682&productId=dev9880019&defaultSku=VZ-0410-001-US'
    );
    render(<HumPreQualificationContainer {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should mount', async () => {
    expect(screen.getByTestId('HumPreQualification-section')).toBeInTheDocument();
  });
});

describe(`<HumPreQualification /> component`, () => {
  const props = {
    DeviceDetailsResult: { data: { data: {} } },
    CustomerProfileResult: { customer: { email: 'abc@verizon.com' } },
    CartDetailsResult: { data: { data: {} } },
    ProtectionFeaturesResult: { data: { data: {} } },
  };
  setupServer();
  beforeEach(() => {
    window.history.pushState(
      {},
      'HumPreQualification',
      '/sales/assisted/new/HumPreQualification.html?offerEligible=Y&activeMtn=2812530682&productId=dev9880019&defaultSku=VZ-0410-001-US'
    );
    render(<HumPreQualificationContainer {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should mount', async () => {
    expect(screen.getByTestId('HumPreQualification-section')).toBeInTheDocument();
  });
});

describe(`<HumPreQualification /> component`, () => {
  const props = {
    DeviceDetailsResult: { data: { data: {} } },
    CustomerProfileResult: { data: { billAccounts: [{ mtns: [] }] }, email: 'abc@verizon.com' },
    CartDetailsResult: { data: { data: {} } },
    ProtectionFeaturesResult: { data: { data: {} } },
  };
  setupServer();
  beforeEach(() => {
    window.history.pushState(
      {},
      'HumPreQualification',
      '/sales/assisted/new/HumPreQualification.html?offerEligible=Y&activeMtn=2812530682&productId=dev9880019&defaultSku=VZ-0410-001-US'
    );
    render(<HumPreQualification {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should mount', async () => {
    await new Promise((res) => {
      setTimeout(res, 3000);
    });
    expect(screen.getByTestId('HumPreQualificationID')).toBeInTheDocument();
  });
});

describe(`<HumPreQualification /> component`, () => {
  const props = {
    DeviceDetailsResult: { data: { data: {} } },
    CustomerProfileResult: { data: { billAccounts: [{ mtns: [] }] }, email: 'abc@verizon.com' },
    CartDetailsResult: { data: { customer: { user: ['test user'] } } },
    ProtectionFeaturesResult: { data: { data: {} } },
  };
  setupServer();
  beforeEach(() => {
    window.history.pushState(
      {},
      'HumPreQualification',
      '/sales/assisted/new/HumPreQualification.html?offerEligible=Y&activeMtn=2812530682&productId=dev9880019&deviceSKU=VZ-0410-001-US'
    );
    render(<HumPreQualification {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should mount', async () => {
    await new Promise((res) => {
      setTimeout(res, 3000);
    });
    expect(screen.getByTestId('HumPreQualificationID')).toBeInTheDocument();
  });
});
