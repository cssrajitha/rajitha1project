import React from 'react';
import HumPreQualification from '../../components/HumPreQualification/HumPreQualification';

const HumPreQualificationContainer = (props) => {
  const {
    CustomerProfileResult,
    CartDetailsResult,
    emailValidateRequestBody,
    EmailValidateResponse,
    getYearsRequestBody,
    GetYearsResponse,
    getModelsRequestBody,
    GetModelsResponse,
    getMakesRequestBody,
    GetMakesResponse,
    getHumCompatibilityBody,
    HumCompatibilityResponse,
  } = props;

  const getRegisteredMdns = () => {
    let mtnArr;
    if (CustomerProfileResult) {
      const mdns = CustomerProfileResult?.customer?.billAccounts?.[0]?.mtns;
      mtnArr = mdns?.length > 0 ? mdns.concat({ mtn: 'Other' }) : [];
    }
    return mtnArr.map((item) => item.mtn);
  };
  return (
    <div data-testid='HumPreQualification-section'>
      <HumPreQualification
        {...props}
        CartDetailsResult={CartDetailsResult}
        registeredMdns={getRegisteredMdns()}
        customerEmail={CustomerProfileResult?.customer?.email ? CustomerProfileResult?.customer?.email : ''}
        channel={CustomerProfileResult?.customer?.channel}
        emailValidateRequestBody={emailValidateRequestBody}
        EmailValidateResponse={EmailValidateResponse}
        getYearsRequestBody={getYearsRequestBody}
        GetYearsResponse={GetYearsResponse}
        getModelsRequestBody={getModelsRequestBody}
        GetModelsResponse={GetModelsResponse}
        getMakesRequestBody={getMakesRequestBody}
        GetMakesResponse={GetMakesResponse}
        getHumCompatibilityBody={getHumCompatibilityBody}
        HumCompatibilityResponse={HumCompatibilityResponse}
        customerType={sessionStorage.getItem('customerType')}
      />
    </div>
  );
};

export default HumPreQualificationContainer;
