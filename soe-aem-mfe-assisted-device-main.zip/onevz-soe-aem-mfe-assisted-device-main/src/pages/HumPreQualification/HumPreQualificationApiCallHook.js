import { useGetCustomerProfileQuery, useGetCartDetailsQuery } from 'onevzsoemfecommon/APIService';
import {
  useLazyValidateEmailAddressQuery,
  useLazyGetYearsQuery,
  useLazyGetMakesQuery,
  useLazyGetModelsQuery,
  useLazyValidateHumCompatibilityQuery,
} from 'onevzsoemfecommon/DeviceAPIService';
import { requestBodyCustomerProfile, requestBodyRetriveCart } from '../../modules/services/APIService/APIRequestBody';
// import {
// useLazyValidateEmailAddressQuery,
// useLazyGetYearsQuery,
// useLazyGetMakesQuery,
// useLazyGetModelsQuery,
// useLazyValidateHumCompatibilityQuery,
// } from '../../modules/services/APIService/APIServiceHooks';

const HumPreQualificationApiCallHook = () => {
  const CustomerProfileResult = useGetCustomerProfileQuery(
    { body: requestBodyCustomerProfile },
    { refetchOnMountOrArgChange: true },
  );
  const CartDetailsResult = useGetCartDetailsQuery(
    { body: requestBodyRetriveCart },
    { refetchOnMountOrArgChange: true, skip: !CustomerProfileResult.isSuccess },
  );
  const [emailValidateRequestBody, EmailValidateResponse] = useLazyValidateEmailAddressQuery();
  const [getYearsRequestBody, GetYearsResponse] = useLazyGetYearsQuery();
  const [getModelsRequestBody, GetModelsResponse] = useLazyGetModelsQuery();
  const [getMakesRequestBody, GetMakesResponse] = useLazyGetMakesQuery();
  const [getHumCompatibilityBody, HumCompatibilityResponse] = useLazyValidateHumCompatibilityQuery();

  return {
    CustomerProfileResult,
    CartDetailsResult,
    emailValidateRequestBody,
    EmailValidateResponse,
    getYearsRequestBody,
    GetYearsResponse,
    getModelsRequestBody,
    GetModelsResponse,
    getMakesRequestBody,
    GetMakesResponse,
    getHumCompatibilityBody,
    HumCompatibilityResponse,
  };
};

export default HumPreQualificationApiCallHook;
