import { isEmpty } from 'lodash';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import { getAddressInfo, isFunctionalityEnabled} from '../../modules/utils';

import {
  getQualificationDetails,
  getVhiLiteQualifiedForIntentType,
  isBundleFlow,
  isEditFlowLocalOrder,
  getLteCbdIntendType,
} from './pdp5gutils';

export default function generateAddDevicePayload(payloadData = {}) {// NOSONAR
  const {
    activeMtn = '',
    isfiveGGemini = false,
    isfiveGScan = false,
    is5GDevice = false,
    cartDetails = {},
    customerProfile = {},
    bundleProduct = {},
    selectedSku = {},
    LTEorCBandQualified = false,
    LandingCband = false,
    isFWAcheckAltAddress = false,
    selectedStore = {},
    isIspuItemInCart = false,
    customerType = '',
    cbandBundleFlow = false,
    ispuToggleOn = false,
    date = '',
    isCsscRepFromOptix = false,
    devicedata = {},
    isShipItToggleOn = false,
    trade3POChoiceOfferFFlag = false,
    vhiLiteQualifiedFFlag = false,
  } = payloadData;

  const { isNewLine } = payloadData;

  const { caseId = '', cartId = '', lookupMtn = '', accountNo = '' } = customerProfile?.data?.customer || {};
  const { cartCreator = '' } = cartDetails?.cart?.cartHeader?.cartCreator || {};
  const simFourG = {
    id: 'DFILLSIM-TRI-A',
    iccid: '',
    isCustomerProvidedSIM: false,
  };
  const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable;
  const isHomeSales = /true/i.test(customerProfile?.customer?.isHomeSales);
  const getHomeSalesAddressDetails = customerProfile?.customer?.homeSalesAddress || {};
  const isFWASimplificationEnabledEC = customerProfile?.customer?.isFWASimplificationEnabled;
  const is5gHomeSelfInstall = bundleProduct?.childSkus?.[0]?.is5gHomeSelfInstall;
  const is5gHomeProfInstall = bundleProduct?.childSkus?.[0]?.is5gHomeProfessionalInstall;
  const addressRequest = customerProfile?.customer?.qualificationDetails?.addressRequest;

  const lineDetails = cartDetails?.cart?.lineDetails;
  const isfourGAddress = LTEorCBandQualified && !is5gHomeProfInstall && !isBundleFlow(customerProfile);
  const activeLineItem = lineDetails?.lineInfo?.find((line) => line?.mobileNumber === activeMtn);
  const lineNumberCart = activeLineItem?.lineNumber;

  const qualificationDetails = getQualificationDetails(customerProfile, activeLineItem);

  let isSimplifiedCband = '';
  let isSimplifiedLTE = '';
  if (isFWASimplificationEnabledEC && isFWAcheckAltAddress) {
    const { cbandQualified, ltequalified } = getHomeSalesAddressDetails;
    isSimplifiedCband = cbandQualified === true;
    isSimplifiedLTE = ltequalified === true;
  }
  console.log(isSimplifiedLTE);

  // const isOptixFlexRedesignCheck = domService?.isOptixwithMasterFlag(JSON.parse(sessionStorage?.getItem("assistedFlags")));
  // Boolean(domService.getQueryParamByName("is5GGemini"))
  // let isfiveGScan = Boolean(domService.getQueryParamByName("isFiveGScan"));
  // domService.isCsscRepFromOptix()
  const deviceFromCart = /true/i.test(getQueryParamByName('deviceFromCart'));
  const addWifiTransactionType = sessionStorage.getItem('fiveGHomeInternetSelectedFlow') === 'WiFi-Backup';
  const wifiBackupCbandQualified = /true/i.test(sessionStorage.getItem('wifiBackupCbandQualified'));
  const wifiBackupLteQualified = /true/i.test(sessionStorage.getItem('wifiBackupLteQualified'));
  const qualificationType = sessionStorage.getItem('Qualification_type');
  const hs_qualification = JSON.parse(sessionStorage.getItem('homesalesQualification_type'));
  const editFlowParams = {
    isEditFlow: false,
    deviceFromCart,
    skuId: getQueryParamByName('skuId'),
    deviceId: getQueryParamByName('deviceId'),
    simId: getQueryParamByName('simId'),
    preferredSoftSim: getQueryParamByName('preferredSoftSim'),
    deviceSKU: getQueryParamByName('deviceSKU'),
  };
  const dataFromQueryParams = isEditFlowLocalOrder(editFlowParams);

  let onlyWifiFlowType = '';
  let wifibackupAddressDetails = '';
  let wifiNetworkBandwidthType = '';
  if (addWifiTransactionType) {
    if (wifiBackupCbandQualified) {
      onlyWifiFlowType = 'WIFIBACKUP_CBD';
      wifiNetworkBandwidthType = 'CBD';
    } else if (wifiBackupLteQualified) {
      onlyWifiFlowType = 'WIFIBACKUP_LTE';
      wifiNetworkBandwidthType = 'LTE';
    }
  }

  let { id = '', giftBoxSku = '', oDUSku = '', iDUSku = '', oDUimei = '', oDUiccid = '', iDUmacid = '' } = devicedata;

  if (isEmpty(devicedata) && isfiveGScan) {
    oDUimei = getQueryParamByName('oDUimei');
    oDUiccid = getQueryParamByName('oDUiccid');
    id = getQueryParamByName('deviceId');
    giftBoxSku = getQueryParamByName('giftBoxSku');
    oDUSku = getQueryParamByName('deviceSKU');
    iDUSku = getQueryParamByName('iDUSku');
    iDUmacid = getQueryParamByName('iDUmacid');
  }

  const { productId } = bundleProduct;
  let simSku;
  const {
    fiveGHomeQualified = false,
    cBandQualified = false,
    LTEQualified = false,
    tanglewoodQualified = false,
    VHILiteQualified = false,
  } = qualificationDetails;
  let childSkuSimSku = bundleProduct?.childSkus?.[0]?.simSku;
  const isVHILiteQualified = getVhiLiteQualifiedForIntentType(vhiLiteQualifiedFFlag, VHILiteQualified);
  /* istanbul ignore next */
  if ((scmUpgradeMfeEnable && isFunctionalityEnabled('scmCommonFixFFlag', 'enableFWAISPUFixFFlag')) && !childSkuSimSku) {
    childSkuSimSku = selectedSku?.simSku; 
  }
  if ((isfiveGGemini && isfiveGGemini === true) || tanglewoodQualified === true) {
    simSku = childSkuSimSku;
  } else {
    simSku = bundleProduct?.childSkus?.[0]?.bundleLinks?.deviceLinks?.[0]?.deviceSku?.simSku || childSkuSimSku;
  }
  let sorID = '';
  if (
    is5gHomeSelfInstall &&
    cbandBundleFlow &&
    bundleProduct?.childSkus?.[0]?.bundleLinks?.deviceLinks?.[0]?.deviceSku?.sorId
  ) {
    sorID = bundleProduct.childSkus[0].bundleLinks.deviceLinks[0].deviceSku.sorId;
  }
  const getSelectedStoreDetails = ispuToggleOn && isIspuItemInCart && selectedStore ? selectedStore : '';
  const depletionLocationCode = getSelectedStoreDetails.netaceLocationCode || '';
  const localDepletionType =
    isfiveGScan ||
    isfiveGGemini ||
    depletionLocationCode ||
    (!is5gHomeProfInstall && !isShipItToggleOn && !tanglewoodQualified);
  const dfillDepletionType = is5gHomeSelfInstall || (isShipItToggleOn && !tanglewoodQualified);
  // eslint-disable-next-line no-nested-ternary
  const depletionTypeVal = localDepletionType ? 'L' : dfillDepletionType ? 'F' : 'O';
  const isIspuFlow = !!(ispuToggleOn === true && depletionLocationCode !== '');

  // Below changes are for C-band
  const FWACBandbundle = !!customerProfile?.customer?.homeSalesAddress?.bundles;
  const FWACBandQual = customerProfile?.customer?.homeSalesAddress?.cbandQualified;
  let sorType = '';
  if (is5gHomeSelfInstall || /true/i.test(fiveGHomeQualified)) {
    sorType = '';
  } else if (is5gHomeProfInstall && (cBandQualified || FWACBandbundle)) {
    sorType = 'BUNDLE';
  }

  let deviceSku = '';
  if (LTEorCBandQualified && !is5gHomeProfInstall) {
    deviceSku = selectedSku?.sorId;
  } else {
    deviceSku = is5gHomeSelfInstall && cbandBundleFlow && cBandQualified ? sorID : oDUSku || productId;
  }

  const multiLineSeqNumber = lineDetails?.lineInfo
    ?.find((line) => line?.mobileNumber === activeMtn)
    ?.multiLineSeqNumber?.toString();

  let fourGAddressRequest = {};
  if (LTEorCBandQualified) {
    if (cBandQualified || LTEQualified || qualificationType === 'LTE' || qualificationType === 'CBD') {
      fourGAddressRequest = getAddressInfo(addressRequest, date);
    }
  }
  let LTECBDIntendType = getLteCbdIntendType(LTEQualified, isVHILiteQualified, qualificationType, customerType);

  if (onlyWifiFlowType && addWifiTransactionType && wifiBackupCbandQualified) {
    LTECBDIntendType = customerType === 'N' ? 'NSE_5G' : 'AAL_5G';
  } else if (onlyWifiFlowType && addWifiTransactionType && wifiBackupLteQualified) {
    LTECBDIntendType = customerType === 'N' ? 'NSE_LTE' : 'AAL_LTE';
  }

  if (onlyWifiFlowType) {
    wifibackupAddressDetails = getAddressInfo(addressRequest, date);
  }

  let fiveGDeliverAddress = {};
  if (isfourGAddress && !isHomeSales) {
    fiveGDeliverAddress = fourGAddressRequest;
  } else if (isHomeSales) {
    const launchType = isBundleFlow(customerProfile) ? '' : { launchType: '4GH' };
    fiveGDeliverAddress = getAddressInfo(getHomeSalesAddressDetails, date);
    fiveGDeliverAddress = { ...fiveGDeliverAddress, ...launchType };
  } else if (onlyWifiFlowType) {
    fiveGDeliverAddress = wifibackupAddressDetails;
  }

  const cartInfo = {
    ...(scmUpgradeMfeEnable &&
      (is5gHomeSelfInstall || /true/i.test(fiveGHomeQualified)) && 
      {
        clientAppName: 'VZW-ACSS',
        cartId: cartId || sessionStorage.getItem('acssMfeCartId') || '',
        caseId: caseId || sessionStorage.getItem('acssMfeCaseId') || '',
        accountNumber: accountNo,
        cartCreator: customerType === 'N' ? cartCreator : lookupMtn,
      }),
    processStep: 'GridWallPDP',
    processingMTN: activeMtn,
    processAction: 'addDevice',
    intendType: LTECBDIntendType,
  };
  const request = {
    cartInfo,
    data: {
      lines: [
        {
          depletionType: depletionTypeVal,
          multiLineSeqNumber,
          depletionLocationCode,
          ispuFlow: isIspuFlow,
          isNewLine,
          mtn: activeMtn,
          device: {
            id: deviceSku,
            contractTerm: 'MONTH_TO_MONTH',
            ...(is5GDevice && !tanglewoodQualified
              ? { networkBandwidthType: cBandQualified || FWACBandQual || qualificationType === 'CBD' ? 'CBD' : 'MMW' }
              : {}),
            ...(tanglewoodQualified || qualificationType === 'TGW' ? { networkBandwidthType: 'TGW' } : {}),
            ...((cbandBundleFlow || FWACBandbundle) && depletionTypeVal !== 'L' ? { sorType } : {}),

            ...(isfourGAddress
              ? {
                  networkBandwidthType:
                    cBandQualified || qualificationType === 'CBD' || hs_qualification?.cbandQualified || LandingCband
                      ? 'CBD'
                      : 'LTE',
                }
              : {}),
            /* istanbul ignore else */
            ...(is5GDevice && isFWASimplificationEnabledEC && !isFWAcheckAltAddress
              ? /* istanbul ignore next */{
                  networkBandwidthType:
                    cBandQualified ||
                    qualificationType === 'CBD' ||
                    hs_qualification?.cbandQualified ||
                    isSimplifiedCband
                      ? 'CBD'
                      : 'LTE',
                }
              : {}),
            ...(onlyWifiFlowType ? { networkBandwidthType: wifiNetworkBandwidthType } : {}),
            ...(is5GDevice && scmUpgradeMfeEnable
              ? 
              {
                  networkBandwidthType: 'CBD',
                  sorType: is5gHomeProfInstall ? 'BUNDLE' : '',
                }
              : {}),
          },
          sim: isfourGAddress
            ? simFourG
            : {
                ...(tanglewoodQualified ? {} : { id: simSku }),
              },
          ...(isfiveGScan ? { giftBox: {} } : {}),
          ...(isfiveGScan ? { idu: {} } : {}),
          ...{ fiveG: fiveGDeliverAddress },
          ...(isfourGAddress && { triggerPricingValidation: true }),
        },
      ],
    },
  };

  // if it's tanglewoodQualified then remove sim node from request
  if (tanglewoodQualified) {
    delete request.data.lines[0].sim;
  }

  if (isfiveGScan) {
    request.data.lines[0].device.deviceId = oDUimei;
    request.data.lines[0].sim.iccid = oDUiccid;
    request.data.lines[0].giftBox.id = giftBoxSku;
    request.data.lines[0].giftBox.deviceId = id;
    request.data.lines[0].idu.id = iDUSku;
    request.data.lines[0].idu.deviceId = iDUmacid;
  }

  if (isfiveGGemini || dataFromQueryParams?.isEditFlow) {
    // when we have devicedata empty means it means not scanned any device yet from pdp page
    const { skuId, deviceId, simId, preferredSoftSim } = isEmpty(devicedata) ? dataFromQueryParams : devicedata;
    request.data.lines[0].device.id = skuId;
    request.data.lines[0].device.deviceId = deviceId;
    request.data.lines[0].sim.iccid = simId;
    request.data.lines[0].sim.id = preferredSoftSim;
    request.cartInfo.isGemini = true;
  }

  if (selectedSku?.skuFilters?.deviceFilterType) {
    request.data.lines[0].device.category = selectedSku.skuFilters.deviceFilterType;
  }

  if (trade3POChoiceOfferFFlag && lineNumberCart && request.data?.lines?.length > 0) {
    request.data.lines[0].lineNumber = lineNumberCart;
  }

  if (addWifiTransactionType) {
    request.data.lines[0].transactionType = 'WIFIBACKUP';
  }
  const intendTypes = ['NSE', 'AAL'];
  if (isCsscRepFromOptix && intendTypes.some((type) => request?.cartInfo?.intendType?.includes(type))) {
    request.data.lines[0].isNewLine = true;
  }
  return request;
}
