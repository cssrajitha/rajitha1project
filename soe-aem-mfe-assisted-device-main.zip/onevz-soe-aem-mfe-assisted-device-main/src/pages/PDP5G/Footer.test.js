import { render, fireEvent, screen, act } from '../../modules/test-utils/renderHelper';
import Footer from './Footer';
import { Context } from './PDP5gContext';

describe(`<Footer 5G/> component mount1`, () => {
  const PDP5GContexData = {
    ddDeviceToCartHandler: jest.fn(),
    deviceFromCart: true,
    removeLinesHandler: jest.fn(),
  };
  beforeEach(() => {
    render(
      <Context.Provider value={PDP5GContexData}>
        <Footer ispuItemInCart='true' />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const dataTest = screen.getAllByText(/Find Stores/i)[0];
    act(() => {
      fireEvent.click(dataTest);
    });
  });
});
describe(`<Footer 5G/> component mount1`, () => {
  const PDP5GContexData = {
    ddDeviceToCartHandler: jest.fn(),
    deviceFromCart: false,
    removeLinesHandler: jest.fn(),
  };
  beforeEach(() => {
    render(
      <Context.Provider value={PDP5GContexData}>
        <Footer btnLabel='Find Stores' />
      </Context.Provider>,
    );
  });
  test('should mount', async () => {
    const dataTest = screen.getAllByText(/Find Stores/i)[0];
    act(() => {
      fireEvent.click(dataTest);
    });
  });
});

describe(`<Footer 5G/> component mount for BYOD`, () => {
  const PDP5GContexData = {
    ddDeviceToCartHandler: jest.fn(),
    deviceFromCart: false,
    isByodUpdate: true,
    removeLinesHandler: jest.fn(),
  };
  beforeEach(() => {
    render(
      <Context.Provider value={PDP5GContexData}>
        <Footer btnLabel='BYOD' />
      </Context.Provider>,
    );
  });
  test('FOR EUP BYOD Footer Label Should BE BYOD', async () => {
    const dataTest = screen.getAllByText(/BYOD/i)[0];
    expect(dataTest).toBeInTheDocument();
  });
});
