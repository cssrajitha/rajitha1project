import { fireEvent, render, screen, waitFor } from '../../modules/test-utils/renderHelper';
import Header from './Header';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import * as DomService from 'onevzsoemfeframework/DomService'; // 1. Import the actual module

const mockNavigate = jest.fn();
const mockHistoryGoBack = jest.fn();
const mockHistoryPush = jest.fn();
const mockGetQueryParamByName = jest.fn();

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockNavigate,
}));
jest.mock('onevzsoemfeframework/DomService', () => ({
  ...jest.requireActual('onevzsoemfeframework/DomService'), // Keep all other original exports
  getQueryParamByName: (param) => mockGetQueryParamByName(param), // Override getQueryParamByName to use our mock
}));

// jest.mock('onevzsoemfeframework/DomService', () => ({
//   getQueryParamByName: (param) => {
//     // This mock will be used by default, returning 'OtherPage'
//     if (param === 'fromPage') {
//       return 'OtherPage'; // Ensures 'fromPage' is NOT 'Landing'
//     }
//     return null;
//   },
// }));
const getQueryParamMock = jest.spyOn(DomService, 'getQueryParamByName');
jest.mock('onevzsoemfecommon/Helpers', () => ({
  ...jest.requireActual('onevzsoemfecommon/Helpers'),
  getUIContextPathBAU: () => '/mocked-context-path',
  acssMfeBasePath: '/mocked-acss-path',
  // Add any other helpers your component needs
  isNumeric: jest.requireActual('onevzsoemfecommon/Helpers').isNumeric,
  capitalizeFirstLetter: jest.requireActual('onevzsoemfecommon/Helpers').capitalizeFirstLetter,
  formatMtnForNewLine: jest.requireActual('onevzsoemfecommon/Helpers').formatMtnForNewLine,
}));

const renderComponent = (mdn = '8145772880', closeIcon = { popupModalclose: true }) => {
  const closeClickHandler = jest.fn();
  const moreOptionClickHandler = jest.fn();
  const navigatePdp = jest.fn();
  const setDownPaymentObj = jest.fn();

  const header = 'iPhone 14 Pro';
  const line = 'JOSEPH';
  const downPayment = 10;
  // const mdn = '8145772880';
  render(
    <Header
      data={{
        header,
        line,
        mdn,
        closeIcon,
        closeClickHandler,
        moreOptionClickHandler,
        navigatePdp,
      }}
      productDetails={{
        deviceProduct: {
          commonInfo: {
            showPrice: true,
            displayReasonCode: true,
            showShipitToggle: true,
            flexPDPTradeInLinkEnabled: true,
            containSoftSku: false,
            dpEligible: true,
            indirect: false,
          },
        },
      }}
      isFromCPE={false}
      isRfexFlow={false}
      isNewLine={false}
      channel='OMNI-RETAIL'
      downPayment={downPayment}
      setDownPaymentObj={setDownPaymentObj}
    />,
    {
      reducers: rootReducer,
      sagas: rootSaga,
    },
  );
  return {
    header,
    line,
    mdn,
    closeIcon,
    closeClickHandler,
    moreOptionClickHandler,
  };
};

const renderComponentWithoutClosehandler = (mdn = '8145772880', closeIcon = { popupModalclose: true }) => {
  const closeClickHandler = jest.fn();
  const moreOptionClickHandler = jest.fn();
  const navigatePdp = jest.fn();
  const setDownPaymentObj = jest.fn();

  const header = 'iPhone 14 Pro';
  const line = 'JOSEPH';
  const downPayment = 10;
  // const mdn = '8145772880';
  render(
    <Header
      data={{
        header,
        line,
        mdn,
        closeIcon,
        closeClickHandler: undefined,
        moreOptionClickHandler,
        navigatePdp,
      }}
      productDetails={{
        deviceProduct: {
          commonInfo: {
            showPrice: true,
            displayReasonCode: true,
            showShipitToggle: true,
            flexPDPTradeInLinkEnabled: true,
            containSoftSku: false,
            dpEligible: true,
            indirect: false,
          },
        },
      }}
      isFromCPE={false}
      isRfexFlow={false}
      isNewLine={false}
      channel='OMNI-RETAIL'
      downPayment={downPayment}
      setDownPaymentObj={setDownPaymentObj}
    />,
    {
      reducers: rootReducer,
      sagas: rootSaga,
    },
  );
  return {
    header,
    line,
    mdn,
    closeIcon,
    closeClickHandler,
    moreOptionClickHandler,
  };
};
jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);
describe('<Header/>', () => {
  beforeEach(() => {
    window.mfe = {};
    sessionStorage.setItem('isSAExist', true);
  });
  it('should test header component everything is visible except for more options', () => {
    const { header, closeClickHandler } = renderComponent('8145772880');
    const closeButton = screen.getByRole('img', {
      name: /close icon/i,
    });
    expect(closeButton).toBeInTheDocument();
    expect(screen.queryByText(/more options/i)).toBeNull();
    expect(
      screen.getByRole('heading', {
        name: new RegExp(header, 'i'),
      }),
    ).toBeInTheDocument();
    screen.getByRole('heading', {
      name: /joseph 814-577-2880/i,
    });
    fireEvent.click(closeButton);
    expect(closeClickHandler).toBeCalled();
  });

  it('should test header component everything is visible except for more options when theme is dark', () => {
    window.mfe.scmDeviceMfeEnable = true;
    window.mfe.isDark = true;
    const { header, closeClickHandler } = renderComponent('8145772880');
    const closeButton = screen.getByRole('img', {
      name: /close icon/i,
    });
    expect(closeButton).toBeInTheDocument();
    expect(screen.queryByText(/more options/i)).toBeNull();
    expect(
      screen.getByRole('heading', {
        name: new RegExp(header, 'i'),
      }),
    ).toBeInTheDocument();
    screen.getByRole('heading', {
      name: /joseph 814-577-2880/i,
    });
    fireEvent.click(closeButton);
    expect(closeClickHandler).toBeCalled();
  });

  it('should test scmDeviceMfeEnable navigatereturn (-1)', () => {
    window.mfe.scmDeviceMfeEnable = false;
    const { header, closeClickHandler } = renderComponentWithoutClosehandler('8145772880');
    const closeButton = screen.getByRole('img', {
      name: /close icon/i,
    });
    expect(closeButton).toBeInTheDocument();
    expect(screen.queryByText(/more options/i)).toBeNull();
    expect(
      screen.getByRole('heading', {
        name: new RegExp(header, 'i'),
      }),
    ).toBeInTheDocument();
    screen.getByRole('heading', {
      name: /joseph 814-577-2880/i,
    });
    fireEvent.click(closeButton);
    expect(closeClickHandler).not.toBeCalled();
  });
  it('should test navigate is called with -1 parameter on left caret click', () => {
    renderComponent('linemdn123', false);
    const mockNavigate = jest.fn();
    jest.mock('react-router-dom', () => ({ useNavigate: () => mockNavigate }));

    screen.getByRole('heading', {
      name: /joseph Lin emdn 123/i,
    });
    fireEvent.click(screen.getByTestId('testBackGridwall'));

    waitFor(() => expect(mockNavigate).toBeCalledWith(-1));
  });

  it('should test navigate is called with -1 parameter on left caret click returning empty', () => {
    window.mfe.scmDeviceMfeEnable = true;
    renderComponent('linemdn123', false);
    const mockNavigate = jest.fn();
    jest.mock('react-router-dom', () => ({ useNavigate: () => mockNavigate }));

    screen.getByRole('heading', {
      name: /joseph Lin emdn 123/i,
    });
    fireEvent.click(screen.getByTestId('testBackGridwall'));
  });
});

describe('Header Component with large display text', () => {
  beforeEach(() => {
    render(
      <Header
        data={{
          header: 'Iphone 15 Pro Max Iphone 15 Pro Max Iphone 15 Pro Max Iphone 15 Pro Max',
          line: '5g',
          mdn: '8145772880',
        }}
        productDetails={{
          deviceProduct: {
            commonInfo: {
              showPrice: true,
              displayReasonCode: true,
              showShipitToggle: true,
              flexPDPTradeInLinkEnabled: true,
              containSoftSku: false,
              dpEligible: true,
              indirect: false,
            },
          },
        }}
        isFromCPE={false}
        isRfexFlow={false}
        isNewLine={false}
        channel='OMNI-RETAIL'
        downPayment={10}
        setDownPaymentObj={jest.fn()}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('IDLInfo component shoudl render', () => {
    const testBackGridwall = screen.getByTestId('testBackGridwall');
    expect(testBackGridwall).toBeInTheDocument();
  });
});

describe('Header Component for Back and Forth Flow', () => {
  beforeEach(() => {
    const navigatePdp = jest.fn();
    window.mfe = {};
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/product-detail.html?fromPage=Landing&activeMtn=5139074854&deviceSKU=MQ8R3LL/A&isByodUpdate=true&deviceId=350321532631401',
    );
    render(
      <Header
        data={{
          header: 'Iphone 15 Pro Max',
          mdn: 'linemdn123',
          line: 'JOSEPH',
          navigatePdp,
          closeClickHandler: undefined,
        }}
        productDetails={{
          deviceProduct: {
            commonInfo: {
              showPrice: true,
              displayReasonCode: true,
              showShipitToggle: true,
              flexPDPTradeInLinkEnabled: true,
              containSoftSku: false,
              dpEligible: true,
              indirect: false,
            },
          },
        }}
        isFromCPE={false}
        isRfexFlow={false}
        isNewLine={false}
        channel='OMNI-RETAIL'
        downPayment={10}
        setDownPaymentObj={jest.fn()}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });
  test('should test navigate is called with -1 parameter on left caret click', () => {
    window.mfe = { scmDeviceMfeEnable: false, scmUpgradeMfeEnable: true };
    const mockNavigate = jest.fn();
    jest.mock('react-router-dom', () => ({ useNavigate: () => mockNavigate }));
    screen.getByRole('heading', {
      name: /joseph Lin emdn 123/i,
    });
    fireEvent.click(screen.getByTestId('testBackGridwall'));

    waitFor(() => expect(mockNavigate).toBeCalledWith(-1));
  });
});

describe('Header Component for BYOD flow', () => {
  const props = {
    data: {
      header: 'Header',
      line: 'Line',
      mdn: '1234567890',
      closeIcon: { popupModalclose: true },
      closeClickHandler: undefined,
      moreOptionClickHandler: jest.fn(),
    },
    computeDPPriceBody: jest.fn(),
    computeDPPriceResult: jest.fn(),
    isDownPaymentAlertNeedToEnable: false,
    setIsDownPaymentAlertNeedToEnable: jest.fn(),
  };

  beforeEach(() => {
    // Mock getQueryParamByName to return specific values
    window.mfe = {};
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/product-detail.html?activeMtn=5139074854&deviceSKU=MQ8R3LL/A&isByodUpdate=true&deviceId=350321532631401',
    );
  });
  test('should test navigate is called with -1 parameter on left caret click', () => {
    jest.mock('onevzsoemfeframework/DomService', () => ({
      getQueryParamByName: (value) => {
        if (value === 'isByodUpdate') return 'false';
        if (value === 'fromPage') return 'OtherPage';
      },
    }));
    jest.mock(
      'onevzsoemfecommon/Helpers',
      () => ({
        __esModule: true,
        default: jest.fn(() => ({})),
        getUIContextPath: jest.fn(() => { }),
        getUIContextPathBAU: jest.fn(() => { }),
        capitalizeFirstLetter: jest.fn(() => { }),
        formatMtnForNewLine: jest.fn(() => { }),
        isNumeric: jest.fn(() => { }),
        getQueryParamByName: jest.fn(() => ({
          isByodUpdate: true,
        })),
      }),
      { virtual: true },
    );
    window.mfe.scmDeviceMfeEnable = false;
    window.mfe.scmUpgradeMfeEnable = true;
    // This is the FIX
    const mockHistoryPush = jest.fn();
    window.mfe.historyRef = {
      goBack: jest.fn(),
      push: mockHistoryPush // Add the missing mock function
    }; window.mfe.scmCombinedGridwallFlow = true;

    render(<Header {...props} />, { reducers: rootReducer, sagas: rootSaga });
    const mockNavigate = jest.fn();
    jest.mock('react-router-dom', () => ({ useNavigate: () => mockNavigate }));
    const testBackGridwall = screen.getByTestId('testBackGridwall');
    fireEvent.click(testBackGridwall);
  });

  test('should test navigate is called with -1 parameter on left caret click', () => {
    jest.mock('onevzsoemfeframework/DomService', () => ({
      getQueryParamByName: (value) => {
        if (value === 'isByodUpdate') return 'false';
        if (value === 'fromPage') return 'OtherPage';
      },
    }));
    jest.mock(
      'onevzsoemfecommon/Helpers',
      () => ({
        __esModule: true,
        default: jest.fn(() => ({})),
        getUIContextPath: jest.fn(() => { }),
        getUIContextPathBAU: jest.fn(() => { }),
        capitalizeFirstLetter: jest.fn(() => { }),
        formatMtnForNewLine: jest.fn(() => { }),
        isNumeric: jest.fn(() => { }),
        getQueryParamByName: jest.fn(() => ({
          isByodUpdate: true,
        })),
      }),
      { virtual: true },
    );
    window.mfe.scmDeviceMfeEnable = false;
    window.mfe.scmUpgradeMfeEnable = true;
    const mockHistoryPush = jest.fn();
    window.mfe.historyRef = {
      goBack: jest.fn(),
      push: mockHistoryPush // Add the missing mock function
    };
    window.mfe.scmCombinedGridwallFlow = false;

    render(<Header {...props} />, { reducers: rootReducer, sagas: rootSaga });
    const mockNavigate = jest.fn();
    jest.mock('react-router-dom', () => ({ useNavigate: () => mockNavigate }));
    const testBackGridwall = screen.getByTestId('testBackGridwall');
    fireEvent.click(testBackGridwall);
  });

});
describe('Header navigation fallback', () => {
  beforeEach(() => {
    // Clear mock calls and reset global/session states before each test
    mockNavigate.mockClear();
    jest.clearAllMocks(); // Clears all mock function call histories

    // 3. Set scmUpgradeMfeEnable to false
    window.mfe = {
      scmUpgradeMfeEnable: false,
    };

    // Mock sessionStorage methods to verify calls
    Storage.prototype.setItem = jest.fn();
    Storage.prototype.getItem = jest.fn(() => 'true'); // Mock 'isSAExist' to be true
    Storage.prototype.removeItem = jest.fn();

    // Setup the condition for the 'isSAExist' check
    sessionStorage.setItem('isSAExist', 'true');
  });

  it('should navigate to combinedgridwall as a fallback', () => {
    const testMdn = '9876543210';

    // 1. Render using the helper that sets closeClickHandler to undefined
    renderComponentWithoutClosehandler(testMdn);

    // Find and click the back button to trigger navigatePdp
    fireEvent.click(screen.getByTestId('testBackGridwall'));

    // --- Assertions ---

    // Check that navigate was called with the correct URL from the 'else' block
    const expectedUrl = `/mocked-context-path/combinedgridwall.html?fromPDP=true&activeMtn=${testMdn}&backfrompdp=true`;
    expect(mockNavigate).toHaveBeenCalledWith(expectedUrl);
    expect(mockNavigate).toHaveBeenCalledTimes(1);

    // Verify all sessionStorage calls from lines 87-91 are made
    expect(sessionStorage.setItem).toHaveBeenCalledWith('isFromBack', true);
    expect(sessionStorage.setItem).toHaveBeenCalledWith('isSecondNumLocal', false);
    expect(sessionStorage.getItem).toHaveBeenCalledWith('isSAExist');
    expect(sessionStorage.removeItem).toHaveBeenCalledWith('isSAExist');
  });
});
// Add this new describe block to your file

describe('Header navigation for Landing Page', () => {
  beforeEach(() => {
  mockGetQueryParamByName.mockImplementation((param) => {
    if (param === 'fromPage') {
        return 'Landing';
      }
      return null;
    });

    // Ensure the other conditions are met
    window.mfe = { scmUpgradeMfeEnable: false };
    mockNavigate.mockClear();
  });

  afterEach(() => {
    mockGetQueryParamByName.mockRestore();
  });

  it("should navigate to landing.html when fromPage is 'Landing' and no closeClickHandler is provided", () => {
    const testMdn = '1112223333';

    // Renders the component, closeClickHandler is undefined
    renderComponentWithoutClosehandler(testMdn);

    // ACT: Click the back button to trigger navigatePdp
    fireEvent.click(screen.getByTestId('testBackGridwall'));

    
    const expectedUrl = `/mocked-context-path/landing.html?activeMtn=${testMdn}&backfrompdp=true`;

    expect(mockNavigate).toHaveBeenCalledWith(expectedUrl);
    expect(mockNavigate).toHaveBeenCalledTimes(1);
  });
});

describe('Header useNavigate error handling', () => {
  it('should hit the catch block when useNavigate throws an error', () => {
    // Spy on console.log to confirm the log is called
    const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation(() => {});

    jest.spyOn(require('react-router-dom'), 'useNavigate').mockImplementationOnce(() => {
      throw new Error('Forcing error for catch block coverage');
    });

    // Render the component. The error will happen during rendering.
    // We use the minimal render helper to avoid side effects.
    renderComponent('1234567890');

    // Assert: The catch block's console.log should have been called
    expect(consoleLogSpy).toHaveBeenCalledWith('');

    // Clean up the spy
    consoleLogSpy.mockRestore();
  });
});
