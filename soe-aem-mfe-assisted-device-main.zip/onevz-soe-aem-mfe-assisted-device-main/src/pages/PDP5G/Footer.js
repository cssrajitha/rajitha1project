import React, { useContext } from 'react';
import styled from 'styled-components';
import { Button } from '@vds/buttons';
import PropTypes from 'prop-types';
import { Context } from './PDP5gContext';
import { LIGHT_BG_COLOR } from '../../constants/constants';

const FooterArea = styled.div`
  background-color: ${LIGHT_BG_COLOR};
  bottom: 0px;
  display: flex;
  flex-wrap: wrap;
  width: 252px;
  button:enabled:focus {
    color: white;
  }
`;

function Footer(props) {
  const { addDeviceToCartHandler, deviceFromCart, removeLinesHandler, isByodUpdate } = useContext(Context);
  const { btnLabel, ispuItemInCart, navigateToIspu } = props;
  // isCartBtnEnable = false,
  // const bgColor = window?.mfe?.scmDeviceMfeEnable && window?.mfe?.themeProps?.background;
  // const isDark = (window?.mfe?.scmDeviceMfeEnable && window?.mfe?.isDark) || false;

  return (
    <FooterArea>
      {!deviceFromCart || btnLabel === 'Pick Up' ? (
        <>
          {(btnLabel === 'Add to Cart' || btnLabel === 'Pick Up' || btnLabel === 'BYOD') && (
            <Button
              width='154px'
              size='large'
              inverted
              secondary
              surface='light'
              data-track={btnLabel}
              onClick={addDeviceToCartHandler}
              disabled={isByodUpdate}
            >
              {btnLabel}
            </Button>
          )}
          {btnLabel === 'Ship It' && (
            <Button
              onClick={addDeviceToCartHandler}
              width='154px'
              size='large'
              inverted
              secondary
              data-track={btnLabel}
              surface='light'
            >
              {btnLabel}
            </Button>
          )}
          {btnLabel === 'Find Stores' && !deviceFromCart && (
            <Button size='large' onClick={navigateToIspu} data-track={btnLabel}>
              {btnLabel}
            </Button>
          )}
        </>
      ) : (
        <>
          <Button
            onClick={removeLinesHandler}
            style={{ marginRight: '10px', marginBottom: '10px', width: '154px' }}
            width='154px'
            size='large'
            inverted
            secondary
            surface='light'
            data-track='Remove'
          >
            Remove
          </Button>
          {!ispuItemInCart && (
            <Button
              onClick={addDeviceToCartHandler}
              width='154px'
              size='large'
              inverted
              secondary
              surface='light'
              data-track='Update'
            >
              Update
            </Button>
          )}
          {ispuItemInCart && (
            <Button
              inverted
              secondary
              size='large'
              style={{ marginBottom: '10px', width: '154px' }}
              data-track='Find Stores'
              surface='light'
              onClick={navigateToIspu}
            >
              Find Stores
            </Button>
          )}
        </>
      )}
    </FooterArea>
  );
}
export default Footer;

Footer.propTypes = {
  btnLabel: PropTypes.string,
  ispuItemInCart: PropTypes.bool,
  navigateToIspu: PropTypes.func,
};
