/**
 * Determines if the customer is eligible for the home sales Cband bundle flow.
 *
 * @param {Object} customerProfile - The customer profile object.
 * @param {Object} customerProfile.priorQualification - The prior qualification object.
 * @param {boolean} customerProfile.priorQualification.cbandQualified - Indicates if the customer is Cband qualified.
 * @param {Array} customerProfile.bundles - The array of bundles.
 * @param {Object} customerProfile.customer.homeSalesAddress - The home sales address object.
 *
 * @returns {boolean} - Returns true if the customer is eligible for the home sales Cband bundle flow, otherwise false.
 */
export function isHomeSalesCbandBundleFlow(customerProfile = {}) {
  const { priorQualification = {}, bundles = [] } = customerProfile?.customer?.homeSalesAddress ?? {};

  if (priorQualification?.cbandQualified && bundles?.length > 0) return true;
}

/**
 * Retrieves the qualification details for a customer profile.
 *
 * @param {Object} customerProfile - The customer profile object.
 * @returns {Object} - The qualification details and cBandQualified value.
 */

export function getQualificationDetails(customerProfile = {}, cartLineItem = {}) {
  const homeSalesFlow = isHomeSales(customerProfile);
  const qualificationDetails = homeSalesFlow
    ? customerProfile?.customer?.homeSalesAddress?.priorQualification
    : customerProfile?.customer?.qualificationDetails?.addressRequest;
  const cBandQualified = homeSalesFlow
    ? customerProfile?.customer?.homeSalesAddress?.priorQualification?.cbandQualified
    : customerProfile?.customer?.qualificationDetails?.addressRequest?.cBandQualified;
  // for tanglewood refereing to the cartLineItem
  const tanglewoodQualified = qualificationDetails?.tanglewoodQualified || cartLineItem?.tanglewoodSelected === 'Y';
  return { ...qualificationDetails, cBandQualified, tanglewoodQualified };
}

/**
 * Checks if the customer profile indicates a bundle flow.
 *
 * @param {Object} customerProfile - The customer profile object.
 * @returns {boolean} - Returns true if the customer profile indicates a bundle flow, otherwise false.
 */
export function isBundleFlow(customerProfile = {}) {
  if (isHomeSales(customerProfile)) {
    const { bundles = [] } = customerProfile?.customer?.homeSalesAddress ?? {};
    if (bundles?.length > 0) return true;
  } else {
    const {
      fiveGHomebundle = [],
      cbandBundle = [],
      tanglewoodBundle = [],
    } = customerProfile?.customer?.qualificationDetails?.addressRequest?.eligibilities ?? {};
    if (cbandBundle?.length || fiveGHomebundle?.length || tanglewoodBundle?.length) return true;
  }
}

/**
 * Checks if the customer profile indicates home sales.
 * @param customerProfile - The customer profile object.
 * @returns A boolean value indicating if the customer profile indicates home sales.
 */
export function isHomeSales(customerProfile) {
  return /true/i.test(customerProfile?.customer?.isHomeSales);
}

/**
 * Retrieves the bundles based on the customer profile.
 *
 * @param {Object} customerProfile - The customer profile object.
 * @returns {Array} - The array of bundles.
 */
export function getBundles(customerProfile = {}) {
  let bundles = [];
  if (isHomeSales(customerProfile)) {
    bundles = customerProfile?.customer?.homeSalesAddress?.bundles ?? [];
  } else {
    const {
      fiveGHomebundle = [],
      cbandBundle = [],
      tanglewoodBundle = [],
    } = customerProfile?.customer?.qualificationDetails?.addressRequest?.eligibilities ?? {};
    bundles = [...fiveGHomebundle, ...cbandBundle, ...tanglewoodBundle];
  }
  return [...new Set(bundles)];
}

export function getBundleNames(customerProfile = {}) {
  const fivegBundles = getBundles(customerProfile);
  let bundle = '';
  if (fivegBundles?.length > 1) {
    const combinedBundles = fivegBundles.map((b) => b?.bundleName).join(', ');
    bundle = {
      bundleName: combinedBundles,
      power: 'HIGH', // bundles[0].power
    };
  } else if (fivegBundles?.length === 1) {
    [bundle] = fivegBundles;
  }
  return bundle;
}

export function indirectDetailsAndSkuDetailsPayload(obj = {}) {
  let payload = {};
  if (obj?.isIndirect) {
    const pendingLoanCheckByMTNValue = /true/i.test(obj?.pendingLoanCheckByMTN);
    const installmentLoanStatusCheckValue = /true/i.test(obj?.installmentLoanStatusCheck);
    payload = {
      pendingLoanCheckByMTN: pendingLoanCheckByMTNValue,
      installmentLoanStatusCheck: installmentLoanStatusCheckValue,
    };
  }
  return payload;
}

/**
 * Checks if the current flow is an edit flow for a local order.
 * @param {Object} objParams - The parameters object.
 * @returns {Object} - The modified parameters object with the 'isEditFlow' property set to true and the 'skuId' property updated.
 */
export function isEditFlowLocalOrder(objParams = {}) {
  const obj = { ...objParams };
  const skuId = obj?.skuId || obj?.deviceSKU;
  if (obj?.deviceFromCart && obj.deviceId && obj?.simId && obj?.preferredSoftSim && skuId) {
    obj.isEditFlow = true;
    obj.skuId = skuId;
  }
  return obj;
}

export const getVhiLiteQualifiedForIntentType = (vhiLiteQualifiedFFlag, isVHILiteQualified) => {
  const addVhiLiteTransactionType = sessionStorage.getItem('fiveGHomeInternetSelectedFlow') === 'VHILite';
  const vhiLiteSessionValue = sessionStorage.getItem('vhiLiteQualified') === 'true';
  return vhiLiteQualifiedFFlag && addVhiLiteTransactionType && (isVHILiteQualified || vhiLiteSessionValue);
};

export const getLteCbdIntendType = (LTEQualified, isVHILiteQualified, qualificationType, customerType) => {
  if (LTEQualified || isVHILiteQualified || qualificationType === 'LTE') {
    return customerType === 'N' ? 'NSE_LTE' : 'AAL_LTE';
  }
  return customerType === 'N' ? 'NSE_5G' : 'AAL_5G';
};
