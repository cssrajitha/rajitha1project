import {
  isHomeSalesCbandBundleFlow,
  getQualificationDetails,
  isBundleFlow,
  isHomeSales,
  getBundles,
  getBundleNames,
  indirectDetailsAndSkuDetailsPayload,
  isEditFlowLocalOrder,
  getVhiLiteQualifiedForIntentType,
} from './pdp5gutils';

describe('pdp5gutils.js', () => {
  describe('isHomeSalesCbandBundleFlow', () => {
    it('should return true if the customer is Cband qualified and has bundles', () => {
      const customerProfile = {
        customer: {
          homeSalesAddress: {
            priorQualification: {
              cbandQualified: true,
            },
            bundles: [1, 2, 3],
          },
        },
      };

      const result = isHomeSalesCbandBundleFlow(customerProfile);

      expect(result).toBe(true);
    });

    it('should return undefined if the customer is not Cband qualified', () => {
      const result = isHomeSalesCbandBundleFlow();
      expect(result).toBeUndefined();
    });

    it('should return undefined if the customer has no bundles', () => {
      const customerProfile = {
        customer: {
          homeSalesAddress: {
            priorQualification: {
              cbandQualified: true,
            },
            bundles: [],
          },
        },
      };

      const result = isHomeSalesCbandBundleFlow(customerProfile);

      expect(result).toBeUndefined();
    });
  });

  describe('getQualificationDetails', () => {
    it('should return the qualification details and cBandQualified value for home sales', () => {
      const customerProfile = {
        customer: {
          homeSalesAddress: {
            priorQualification: {
              cbandQualified: true,
            },
          },
          isHomeSales: true,
        },
      };
      getQualificationDetails(customerProfile);
    });

    it('should return the qualification details and cBandQualified value for non-home sales', () => {
      const customerProfile = {
        customer: {
          qualificationDetails: {
            addressRequest: {
              cBandQualified: true,
            },
          },
          isHomeSales: false,
        },
      };

      const result = getQualificationDetails(customerProfile);

      expect(result).toEqual({
        cBandQualified: true,
        tanglewoodQualified: false,
      });
    });

    it('should return the qualification details and cBandQualified value for non-home sales', () => {
      getQualificationDetails();
    });
  });

  describe('isBundleFlow', () => {
    it('should return true for bundle flow in home sales', () => {
      isBundleFlow();
    });

    it('should return true for bundle flow in home sales', () => {
      const customerProfile = {
        customer: {
          homeSalesAddress: {
            bundles: [1, 2, 3],
          },
          isHomeSales: true,
        },
      };
      const result = isBundleFlow(customerProfile);
      expect(result).toBe(true);
    });

    it('should return true for bundle flow in home sales', () => {
      const customerProfile = {
        customer: {
          isHomeSales: true,
        },
      };
      isBundleFlow(customerProfile);
    });

    it('should return true for bundle flow in non-home sales', () => {
      const customerProfile = {
        customer: {
          qualificationDetails: {
            addressRequest: {
              eligibilities: {
                cbandBundle: [1, 2, 3],
              },
            },
          },
        },
      };

      const result = isBundleFlow(customerProfile);

      expect(result).toBe(true);
    });
  });

  describe('isHomeSales', () => {
    it('should return true for home sales', () => {
      const customerProfile = {
        customer: {
          isHomeSales: 'true',
        },
      };

      const result = isHomeSales(customerProfile);

      expect(result).toBe(true);
    });

    it('should return false for non-home sales', () => {
      const customerProfile = {
        customer: {
          isHomeSales: 'false',
        },
      };

      const result = isHomeSales(customerProfile);

      expect(result).toBe(false);
    });

    it('should return false for undefined isHomeSales value', () => {
      const customerProfile = {
        customer: {},
      };

      const result = isHomeSales(customerProfile);

      expect(result).toBe(false);
    });
  });

  describe('getBundles', () => {
    it('should return an empty array when customerProfile is empty', () => {
      const result = getBundles();
      expect(result).toEqual([]);
    });

    it('should return an empty array when customerProfile is empty', () => {
      const customerProfile = {
        customer: {
          isHomeSales: true,
          homeSalesAddress: {},
        },
      };
      const result = getBundles(customerProfile);
      expect(result).toEqual([]);
    });

    it('should return an empty array when customerProfile is empty', () => {
      const customerProfile = {};
      const result = getBundles(customerProfile);
      expect(result).toEqual([]);
    });

    it('should return an empty array when customerProfile is not a home sales customer', () => {
      const customerProfile = {
        customer: {
          qualificationDetails: {
            addressRequest: {
              eligibilities: {
                fiveGHomebundle: [],
                cbandBundle: [],
                tanglewoodBundle: [],
              },
            },
          },
        },
      };
      const result = getBundles(customerProfile);
      expect(result).toEqual([]);
    });

    it('should return home sales address bundles when customerProfile is a home sales customer', () => {
      const customerProfile = {
        customer: {
          homeSalesAddress: ['Bundle A', 'Bundle B'],
        },
      };
      getBundles(customerProfile);
    });

    it('should return combined bundles when customerProfile is not a home sales customer', () => {
      const customerProfile = {
        customer: {
          qualificationDetails: {
            addressRequest: {
              eligibilities: {
                fiveGHomebundle: ['Bundle A'],
                cbandBundle: ['Bundle B'],
                tanglewoodBundle: ['Bundle C'],
              },
            },
          },
        },
      };
      const result = getBundles(customerProfile);
      expect(result).toEqual(['Bundle A', 'Bundle B', 'Bundle C']);
    });

    it('should remove duplicate bundles', () => {
      const customerProfile = {
        customer: {
          qualificationDetails: {
            addressRequest: {
              eligibilities: {
                fiveGHomebundle: ['Bundle A', 'Bundle B'],
                cbandBundle: ['Bundle B', 'Bundle C'],
                tanglewoodBundle: ['Bundle C', 'Bundle D'],
              },
            },
          },
        },
      };
      const result = getBundles(customerProfile);
      expect(result).toEqual(['Bundle A', 'Bundle B', 'Bundle C', 'Bundle D']);
    });
  });

  it('should return an empty string when no bundles are provided', () => {
    const result = getBundleNames();
    expect(result).toEqual('');
  });

  it('should return the single bundle when only one bundle is provided', () => {
    const customerProfile = {
      customer: {
        isHomeSales: true,
        homeSalesAddress: {
          bundles: [{ bundleName: 'Bundle A', power: 'HIGH' }],
        },
      },
    };
    const result = getBundleNames(customerProfile);
    expect(result).toEqual({ bundleName: 'Bundle A', power: 'HIGH' });
  });

  it('should return the Muntiple bundle names ', () => {
    const customerProfile = {
      customer: {
        qualificationDetails: {
          addressRequest: {
            eligibilities: {
              fiveGHomebundle: [
                { bundleName: 'Bundle A', power: 'HIGH' },
                { bundleName: 'Bundle B', power: 'LOW' },
              ],
            },
          },
        },
      },
    };
    const result = getBundleNames(customerProfile);
    expect(result).toEqual({ bundleName: 'Bundle A, Bundle B', power: 'HIGH' });
  });
});

describe('indirectDetailsAndSkuDetailsPayload', () => {
  it('should return an empty object when obj.isIndirect is falsy', () => {
    const obj = {
      isIndirect: false,
      pendingLoanCheckByMTN: 'false',
      installmentLoanStatusCheck: 'false',
    };

    const result = indirectDetailsAndSkuDetailsPayload(obj);

    expect(result).toEqual({});
  });

  it('should return an empty object when obj is falsy', () => {
    const result = indirectDetailsAndSkuDetailsPayload();

    expect(result).toEqual({});
  });

  it('should return the correct payload object when obj.isIndirect is truthy', () => {
    const obj = {
      isIndirect: true,
      pendingLoanCheckByMTN: 'true',
      installmentLoanStatusCheck: 'true',
    };

    const result = indirectDetailsAndSkuDetailsPayload(obj);

    expect(result).toEqual({
      pendingLoanCheckByMTN: true,
      installmentLoanStatusCheck: true,
    });
  });

  it('should convert "true" strings to boolean true values', () => {
    const obj = {
      isIndirect: true,
      pendingLoanCheckByMTN: 'true',
      installmentLoanStatusCheck: 'true',
    };

    const result = indirectDetailsAndSkuDetailsPayload(obj);

    expect(result.pendingLoanCheckByMTN).toBe(true);
    expect(result.installmentLoanStatusCheck).toBe(true);
  });
});

describe('isEditFlowLocalOrder', () => {
  it('should return the original object when all conditions are not met', () => {
    const obj = {};
    const result = isEditFlowLocalOrder(obj);
    expect(result).toEqual(obj);
  });

  it('should return the empty object when its not edit flow ', () => {
    const obj = {};
    const result = isEditFlowLocalOrder();
    expect(result).toEqual(obj);
  });

  it('should set isEditFlow and skuId when all conditions are met', () => {
    const obj = {
      deviceFromCart: true,
      deviceId: '123',
      simId: '456',
      preferredSoftSim: true,
      skuId: '789',
    };
    const expected = {
      ...obj,
      isEditFlow: true,
    };
    const result = isEditFlowLocalOrder(obj);
    expect(result).toEqual(expected);
  });

  it('should set isEditFlow and skuId when skuId is present in objParams', () => {
    const obj = {
      deviceFromCart: true,
      deviceId: '123',
      simId: '456',
      preferredSoftSim: true,
      deviceSKU: '789',
    };
    const expected = {
      ...obj,
      isEditFlow: true,
      skuId: '789',
    };
    const result = isEditFlowLocalOrder(obj);
    expect(result).toEqual(expected);
  });
});

describe('getVhiLiteQualifiedForIntentType', () => {
  beforeEach(() => {
    // Clear sessionStorage before each test
    sessionStorage.clear();
  });

  it('should return true when all conditions are met with isVHILiteQualified true', () => {
    sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'VHILite');
    sessionStorage.setItem('vhiLiteQualified', 'true');

    const result = getVhiLiteQualifiedForIntentType(true, true);

    expect(result).toBe(true);
  });

  it('should return true when vhiLiteSessionValue is true but isVHILiteQualified is false', () => {
    sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'VHILite');
    sessionStorage.setItem('vhiLiteQualified', 'true');

    const result = getVhiLiteQualifiedForIntentType(true, false);

    expect(result).toBe(true);
  });

  it('should return false when vhiLiteQualifiedFFlag is false', () => {
    sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'VHILite');
    sessionStorage.setItem('vhiLiteQualified', 'true');

    const result = getVhiLiteQualifiedForIntentType(false, true);

    expect(result).toBe(false);
  });

  it('should return false when fiveGHomeInternetSelectedFlow is not VHILite', () => {
    sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'Other');
    sessionStorage.setItem('vhiLiteQualified', 'true');

    const result = getVhiLiteQualifiedForIntentType(true, true);

    expect(result).toBe(false);
  });

  it('should return false when neither isVHILiteQualified nor vhiLiteSessionValue is true', () => {
    sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'VHILite');
    sessionStorage.setItem('vhiLiteQualified', 'false');

    const result = getVhiLiteQualifiedForIntentType(true, false);

    expect(result).toBe(false);
  });

  it('should return false when vhiLiteQualified session value is not set', () => {
    sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'VHILite');

    const result = getVhiLiteQualifiedForIntentType(true, false);

    expect(result).toBe(false);
  });

  it('should return false when fiveGHomeInternetSelectedFlow session value is not set', () => {
    sessionStorage.setItem('vhiLiteQualified', 'true');

    const result = getVhiLiteQualifiedForIntentType(true, true);

    expect(result).toBe(false);
  });
});
