import * as fns from 'onevzsoemfecommon/Helpers';
import { render, screen, waitFor, fireEvent } from '../../modules/test-utils/renderHelper';
import PDP5G from './index';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import React from 'react';
import * as APIService from 'onevzsoemfecommon/APIService';
import { setupServer, setupServer2, setupServer3, setupServer4, setupServer5 } from './mocks/setupServer';

jest.setTimeout(50000);
jest.mock(
  'onevzsoemfecommon/Helpers',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfecommon/Helpers'),
    getQueryParamByName: jest.fn(),
    isNumeric: jest.fn(),
    capitalizeFirstLetter: jest.fn(),
    formatMtnForNewLine: jest.fn(),
    getUIContextPathBAU: jest.fn(() => '/mocked-bau-path'),
    acssMfeBasePath: '/acss/care/content/vcg/assisted',
  }),
  { virtual: true }
);
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradleProperty: () => ['TRUE', 'TRUE', 'WNC-CR200A,ASK-NCQ1338FA,ARC-XCI55AX'],
  }),
  { virtual: true }
);
const mockNavigate = jest.fn();
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockNavigate,
}));
jest.mock(
  'onevzsoemfeframework/Emitter',
  () => {
    const mockEmit = jest.fn();
    const mockOn = jest.fn();
    const mockOff = jest.fn();
    return {
      __esModule: true,
      default: {
        emit: mockEmit,
        on: mockOn,
        off: mockOff,
      },
      __mockEmit: mockEmit,
      __mockOn: mockOn,
      __mockOff: mockOff,
    };
  },
  { virtual: true }
);
jest.mock('onevzsoemfecommon/APIService', () => {
  const originalModule = jest.requireActual('onevzsoemfecommon/APIService');
  return {
    __esModule: true,
    ...originalModule,
    useLazyRemoveLinesQuery: jest.fn(() => [
      jest.fn(), // Default trigger function
      { status: 'uninitialized', data: null }, // Default result
    ]),
  };
});

describe(`PDP5g component`, () => {
  setupServer();
  beforeEach(() => {
    if (!APIService.useLazyRemoveLinesQuery.mock.results[0]) {
      APIService.useLazyRemoveLinesQuery.mockReturnValue([jest.fn(), { status: 'uninitialized', data: null }]);
    }
  });
  afterEach(() => {
    APIService.useLazyRemoveLinesQuery.mockImplementation(
      jest.requireActual('onevzsoemfecommon/APIService').useLazyRemoveLinesQuery
    );
    jest.clearAllMocks();
  });
  test('check pdp 5g page loaded or nont', async () => {
    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await expect(async () => {
      await waitFor(() => expect(screen.getByText(/price call sucess/i)).toBeInTheDocument());
    }).rejects.toEqual(expect.anything());
  });

  test('should load 5G PDP page for 5G device scan', async () => {
    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'isFiveGScan') return true;
      if (value === 'deviceFromCart') return null;
      return null;
    });
    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await expect(async () => {
      await waitFor(() => expect(screen.getByText(/price call sucess/i)).toBeInTheDocument());
    }).rejects.toEqual(expect.anything());
  });

  test('should load 5G PDP with deviceSKU and deviceId', async () => {
    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'deviceSKU') return 'deviceSKU';
      if (value === 'deviceId') return '1234567890';
      if (value === 'iSscan') return true;
      return null;
    });
    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await expect(async () => {
      await waitFor(() => expect(screen.getByText(/price call sucess/i)).toBeInTheDocument());
    }).rejects.toEqual(expect.anything());
  });

  test('should load 5G PDP with deviceSKU and deviceId', async () => {
    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'activeMtn') return '5185673926';
      if (value === 'is5GGemini') return true;
      if (value === 'scanFromLanding') return true;
      return null;
    });
    sessionStorage.setItem('Qualification_type', 'LTE');
    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await expect(async () => {
      await waitFor(() => expect(screen.getByText(/price call sucess/i)).toBeInTheDocument());
    }).rejects.toEqual(expect.anything());
  });

  test('should load 5G PDP with deviceSKU and deviceId', async () => {
    sessionStorage.setItem('Qualification_type', '');
    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'activeMtn') return '5185673926';
      if (value === 'isEditAndView') return true;
      return null;
    });
    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await expect(async () => {
      await waitFor(() => expect(screen.getByText(/price call sucess/i)).toBeInTheDocument());
    }).rejects.toEqual(expect.anything());
  });

  test('Should click on CTA for DFILL Order for acss flow', async () => {
    window.mfe = { scmUpgradeMfeEnable: true };
    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    const shipItCta = screen.getByText(/Ship It/i);
    expect(shipItCta).toBeInTheDocument();
    fireEvent.click(shipItCta);
    await expect(async () => {
      await waitFor(() => expect(screen.getByText(/device added successfully/i)).toBeInTheDocument());
    }).rejects.toEqual(expect.anything());
  });
  test('Should click on CTA for DFILL Order', async () => {
    window.mfe = { scmUpgradeMfeEnable: false };
    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    const shipItCta = screen.getByText(/Ship It/i);
    expect(shipItCta).toBeInTheDocument();
    fireEvent.click(shipItCta);
    await expect(async () => {
      await waitFor(() => expect(screen.getByText(/device added successfully/i)).toBeInTheDocument());
    }).rejects.toEqual(expect.anything());
  });

  test('should remove added device', async () => {
    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'deviceFromCart') return true;
      return null;
    });
    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    const removeCta = screen.getByText(/Remove/i);
    expect(removeCta).toBeInTheDocument();
    fireEvent.click(removeCta);
    await expect(async () => {
      await waitFor(() => expect(screen.getByText(/Device remove successfully/i)).toBeInTheDocument());
    }).rejects.toEqual(expect.anything());
  });

  test('Should remove added Wifi Back Updevice', async () => {
    sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'WiFi-Backup');
    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'deviceFromCart') return true;
      return null;
    });
    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    const removeCta = screen.getByText(/Remove/i);
    expect(removeCta).toBeInTheDocument();
    fireEvent.click(removeCta);
  });
  test('should load 5G PDP with deviceSKU and deviceId', async () => {
    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'deviceSKU') return 'deviceSKU';
      if (value === 'deviceId') return '1234567890';
      if (value === 'iSscan') return true;
      if (value === 'scanFromLanding') return true;
      if (value === 'isLocal') return true;
      if (value === 'is5GGemini') return true;
      return null;
    });
    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await expect(async () => {
      await waitFor(() => expect(screen.getByText(/price call sucess/i)).toBeInTheDocument());
    }).rejects.toEqual(expect.anything());
  });
});

describe(`PDP5g component`, () => {
  setupServer2();
  beforeEach(() => {
    if (!APIService.useLazyRemoveLinesQuery.mock.results[0]) {
      APIService.useLazyRemoveLinesQuery.mockReturnValue([jest.fn(), { status: 'uninitialized', data: null }]);
    }
  });
  afterEach(() => {
    APIService.useLazyRemoveLinesQuery.mockImplementation(
      jest.requireActual('onevzsoemfecommon/APIService').useLazyRemoveLinesQuery
    );
    jest.clearAllMocks();
  });
  test('check pdp 5g page loaded or nont', async () => {
    sessionStorage.setItem('cbandBundleFlowSession', true);
    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'isBundledGW') return true;
      if (value === 'is5GGemini') return true;
      return null;
    });
    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await expect(async () => {
      await waitFor(() => expect(screen.getByText(/price call sucess/i)).toBeInTheDocument());
    }).rejects.toEqual(expect.anything());
  });
  test('Device Scan testing by entering device Id', async () => {
    sessionStorage.setItem('Qualification_type', 'CBD');
    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'activeMtn') return '5185673926';
      return null;
    });
    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await new Promise((res) => {
      setTimeout(res, 30000);
    });
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
    fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
    await new Promise((res) => {
      setTimeout(res, 10000);
    });
    expect(deviceTextBox).toHaveValue('350669643749367');
  });
  test('should load 5G PDP with deviceSKU and deviceId', async () => {
    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'deviceSKU') return 'deviceSKU';
      if (value === 'deviceId') return '1234567890';
      if (value === 'iSscan') return true;
      if (value === 'scanFromLanding') return true;
      if (value === 'isLocal') return true;
      if (value === 'is5GGemini') return true;
      return null;
    });
    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await expect(async () => {
      await waitFor(() => expect(screen.getByText(/price call sucess/i)).toBeInTheDocument());
    }).rejects.toEqual(expect.anything());
  });
});

describe(`PDP5g component`, () => {
  setupServer2();
  beforeEach(() => {
    if (!APIService.useLazyRemoveLinesQuery.mock.results[0]) {
      APIService.useLazyRemoveLinesQuery.mockReturnValue([jest.fn(), { status: 'uninitialized', data: null }]);
    }
  });
  afterEach(() => {
    APIService.useLazyRemoveLinesQuery.mockImplementation(
      jest.requireActual('onevzsoemfecommon/APIService').useLazyRemoveLinesQuery
    );
    jest.clearAllMocks();
  });
  test('check pdp 5g page for isBundledGW: false and nonscan', async () => {
    sessionStorage.setItem('cbandBundleFlowSession', true);
    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'isBundledGW') return false;
      if (value === 'is5GGemini') return false;
      return null;
    });
    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await expect(async () => {
      await waitFor(() => expect(screen.getByText(/price call sucess/i)).toBeInTheDocument());
    }).rejects.toEqual(expect.anything());
  });
});

describe(`PDP5g component`, () => {
  setupServer3();
  beforeEach(() => {
    if (!APIService.useLazyRemoveLinesQuery.mock.results[0]) {
      APIService.useLazyRemoveLinesQuery.mockReturnValue([jest.fn(), { status: 'uninitialized', data: null }]);
    }
  });
  afterEach(() => {
    APIService.useLazyRemoveLinesQuery.mockImplementation(
      jest.requireActual('onevzsoemfecommon/APIService').useLazyRemoveLinesQuery
    );
    jest.clearAllMocks();
  });
  test('Device Scan testing by entering device Id', async () => {
    sessionStorage.setItem('Qualification_type', 'CBD');
    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'activeMtn') return '5185673926';
      return null;
    });
    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await new Promise((res) => {
      setTimeout(res, 30000);
    });
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
    fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
    await new Promise((res) => {
      setTimeout(res, 10000);
    });
    expect(deviceTextBox).toHaveValue('350669643749367');
  });
  test('should load 5G PDP with deviceSKU and deviceId', async () => {
    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'deviceSKU') return 'deviceSKU';
      if (value === 'deviceId') return '1234567890';
      if (value === 'iSscan') return true;
      if (value === 'scanFromLanding') return true;
      if (value === 'isLocal') return true;
      if (value === 'is5GGemini') return true;
      return null;
    });
    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await expect(async () => {
      await waitFor(() => expect(screen.getByText(/price call sucess/i)).toBeInTheDocument());
    }).rejects.toEqual(expect.anything());
  });
});
describe(`PDP5g component`, () => {
  setupServer4();
  beforeEach(() => {
    if (!APIService.useLazyRemoveLinesQuery.mock.results[0]) {
      APIService.useLazyRemoveLinesQuery.mockReturnValue([jest.fn(), { status: 'uninitialized', data: null }]);
    }
  });
  afterEach(() => {
    APIService.useLazyRemoveLinesQuery.mockImplementation(
      jest.requireActual('onevzsoemfecommon/APIService').useLazyRemoveLinesQuery
    );
    jest.clearAllMocks();
  });
  test('Device Scan testing by entering device Id', async () => {
    sessionStorage.setItem('Qualification_type', 'CBD');
    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'activeMtn') return '5185673926';
      return null;
    });
    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await new Promise((res) => {
      setTimeout(res, 30000);
    });
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
    fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
    await new Promise((res) => {
      setTimeout(res, 10000);
    });
    expect(deviceTextBox).toHaveValue('350669643749367');
  });
});
describe(`PDP5g component`, () => {
  setupServer5();
  beforeEach(() => {
    if (!APIService.useLazyRemoveLinesQuery.mock.results[0]) {
      APIService.useLazyRemoveLinesQuery.mockReturnValue([jest.fn(), { status: 'uninitialized', data: null }]);
    }
  });
  afterEach(() => {
    APIService.useLazyRemoveLinesQuery.mockImplementation(
      jest.requireActual('onevzsoemfecommon/APIService').useLazyRemoveLinesQuery
    );
    jest.clearAllMocks();
  });
  test('Device Scan testing by entering device Id', async () => {
    sessionStorage.setItem('Qualification_type', 'CBD');
    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'activeMtn') return '5185673926';
      return null;
    });
    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await new Promise((res) => {
      setTimeout(res, 30000);
    });
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
    fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
    await new Promise((res) => {
      setTimeout(res, 10000);
    });
    expect(deviceTextBox).toHaveValue('350669643749367');
  });
});
describe('PDP5G isVhiLite variable coverage', () => {
  setupServer();
  beforeEach(() => {
    if (!APIService.useLazyRemoveLinesQuery.mock.results[0]) {
      APIService.useLazyRemoveLinesQuery.mockReturnValue([jest.fn(), { status: 'uninitialized', data: null }]);
    }
  });
  afterEach(() => {
    APIService.useLazyRemoveLinesQuery.mockImplementation(
      jest.requireActual('onevzsoemfecommon/APIService').useLazyRemoveLinesQuery
    );
    jest.clearAllMocks();
    sessionStorage.clear();
  });

  test('should set isVhiLite to true when vhiLiteQualifiedFFlag is true and sessionStorage has VHILite', async () => {
    // Mock getAssistedCradlePropertyV2 to return true for edgePhase1FFlag
    jest.mock(
      'onevzsoemfeframework/AssistedCradleService',
      () => ({
        __esModule: true,
        ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
        getAssistedCradleProperty: () => ['TRUE', 'TRUE', 'WNC-CR200A,ASK-NCQ1338FA,ARC-XCI55AX'],
      }),
      { virtual: true }
    );

    sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'VHILite');

    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'activeMtn') return '5185673926';
      if (value === 'productId') return 'dev11000011';
      return null;
    });

    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    await waitFor(() => {
      // Test should execute the line 120 with both conditions true
      expect(sessionStorage.getItem('fiveGHomeInternetSelectedFlow')).toBe('VHILite');
    });
  });

  test('should set isVhiLite to false when vhiLiteQualifiedFFlag is false', async () => {
    // Mock getAssistedCradlePropertyV2 to return false for edgePhase1FFlag
    jest.mock(
      'onevzsoemfeframework/AssistedCradleService',
      () => ({
        __esModule: true,
        ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
        getAssistedCradleProperty: () => ['TRUE', 'TRUE', 'WNC-CR200A,ASK-NCQ1338FA,ARC-XCI55AX'],
      }),
      { virtual: true }
    );

    sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'VHILite');

    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'activeMtn') return '5185673926';
      if (value === 'productId') return 'dev11000011';
      return null;
    });

    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    await waitFor(() => {
      // Test should execute the line 120 with first condition false
      expect(sessionStorage.getItem('fiveGHomeInternetSelectedFlow')).toBe('VHILite');
    });
  });

  test('should set isVhiLite to false when sessionStorage does not have VHILite', async () => {
    // Mock getAssistedCradlePropertyV2 to return true for edgePhase1FFlag
    jest.mock(
      'onevzsoemfeframework/AssistedCradleService',
      () => ({
        __esModule: true,
        ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
        getAssistedCradleProperty: () => ['TRUE', 'TRUE', 'WNC-CR200A,ASK-NCQ1338FA,ARC-XCI55AX'],
      }),
      { virtual: true }
    );

    sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'WiFi-Backup'); // Not VHILite

    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'activeMtn') return '5185673926';
      if (value === 'productId') return 'dev11000011';
      return null;
    });

    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    await waitFor(() => {
      // Test should execute the line 120 with second condition false
      expect(sessionStorage.getItem('fiveGHomeInternetSelectedFlow')).not.toBe('VHILite');
    });
  });

  test('should set isVhiLite to false when sessionStorage is empty', async () => {
    // Mock getAssistedCradlePropertyV2 to return true for edgePhase1FFlag
    jest.mock(
      'onevzsoemfeframework/AssistedCradleService',
      () => ({
        __esModule: true,
        ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
        getAssistedCradleProperty: () => ['TRUE', 'TRUE', 'WNC-CR200A,ASK-NCQ1338FA,ARC-XCI55AX'],
      }),
      { virtual: true }
    );

    // Don't set any sessionStorage value

    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'activeMtn') return '5185673926';
      if (value === 'productId') return 'dev11000011';
      return null;
    });

    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    await waitFor(() => {
      // Test should execute the line 120 with second condition false (null !== 'VHILite')
      expect(sessionStorage.getItem('fiveGHomeInternetSelectedFlow')).toBeNull();
    });
  });
});
describe('PDP5G MFE navigation coverage', () => {
  setupServer();
  beforeEach(() => {
    if (!APIService.useLazyRemoveLinesQuery.mock.results[0]) {
      APIService.useLazyRemoveLinesQuery.mockReturnValue([jest.fn(), { status: 'uninitialized', data: null }]);
    }
  });
  let mockHistoryPush;
  let mockEmit;
  let mockOn;

  beforeEach(() => {
    jest.clearAllMocks();
    sessionStorage.clear();
    mockHistoryPush = jest.fn();
    const EmitterModule = require('onevzsoemfeframework/Emitter');
    mockEmit = EmitterModule.__mockEmit;
    mockOn = EmitterModule.__mockOn;
    window.Emitter = { emit: mockEmit };
  });
  afterEach(() => {
    APIService.useLazyRemoveLinesQuery.mockImplementation(
      jest.requireActual('onevzsoemfecommon/APIService').useLazyRemoveLinesQuery
    );
    jest.clearAllMocks();
    sessionStorage.clear();
    delete window.mfe;
  });

  test('should emit event and navigate via MFE historyRef when scmUpgradeMfeEnable is true and RemoveLinesAPIResult is fulfilled', async () => {
    window.mfe = {
      scmUpgradeMfeEnable: true,
      historyRef: {
        push: mockHistoryPush,
      },
    };

    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'activeMtn') return '5185673926';
      if (value === 'deviceFromCart') return true;
      return null;
    });

    const mockTrigger = jest.fn();

    APIService.useLazyRemoveLinesQuery.mockImplementation(() => {
      const [result, setResult] = React.useState({
        status: 'uninitialized',
        data: null,
      });

      const trigger = (args) => {
        mockTrigger(args);
        setResult({ status: 'fulfilled', data: { success: true } });
      };

      return [trigger, result];
    });

    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    await waitFor(
      () => {
        expect(screen.queryByText(/Remove/i)).toBeInTheDocument();
      },
      { timeout: 5000 }
    );
    const removeButton = screen.getByText(/Remove/i);
    fireEvent.click(removeButton);

    await waitFor(
      () => {
        expect(mockEmit).toHaveBeenCalledWith('ADD_SELECTED_DEVICE_TO_CART', {});
        expect(mockEmit).toHaveBeenCalledWith('ACSS_SCM_CLEAR_LEFT_RAIL', true);
        expect(mockHistoryPush).toHaveBeenCalledWith(
          expect.stringContaining('/acss/care/content/vcg/assisted/product-detail.html')
        );
      },
      { timeout: 10000 }
    );
  });

  test('should not navigate via MFE when scmUpgradeMfeEnable is false', async () => {
    window.mfe = {
      scmUpgradeMfeEnable: false,
      historyRef: {
        push: mockHistoryPush,
      },
    };

    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'activeMtn') return '5185673926';
      if (value === 'deviceFromCart') return true;
      return null;
    });

    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    await waitFor(
      () => {
        expect(screen.getByText(/Remove/i)).toBeInTheDocument();
      },
      { timeout: 5000 }
    );

    const removeButton = screen.getByText(/Remove/i);
    fireEvent.click(removeButton);

    // Wait a bit to ensure no navigation happens
    await new Promise((resolve) => setTimeout(resolve, 1000));

    expect(mockHistoryPush).not.toHaveBeenCalled();
  });

  test('should handle MFE navigation when historyRef is undefined', async () => {
    window.mfe = {
      scmUpgradeMfeEnable: true,
      historyRef: undefined,
    };

    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'activeMtn') return '5185673926';
      if (value === 'deviceFromCart') return true;
      return null;
    });
    const mockTrigger = jest.fn();
    APIService.useLazyRemoveLinesQuery.mockImplementation(() => {
      const [result, setResult] = React.useState({
        status: 'uninitialized',
        data: null,
      });
      const trigger = (args) => {
        mockTrigger(args);
        setResult({ status: 'fulfilled', data: { success: true } });
      };
      return [trigger, result];
    });
    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await waitFor(
      () => {
        expect(screen.getByText(/Remove/i)).toBeInTheDocument();
      },
      { timeout: 5000 }
    );

    const removeButton = screen.getByText(/Remove/i);
    fireEvent.click(removeButton);

    await waitFor(
      () => {
        expect(mockEmit).toHaveBeenCalledWith('ADD_SELECTED_DEVICE_TO_CART', {});
        expect(mockEmit).toHaveBeenCalledWith('ACSS_SCM_CLEAR_LEFT_RAIL', true);
      },
      { timeout: 5000 }
    );
  });
  test('should call react-router navigate when scmUpgradeMfeEnable is false', async () => {
    jest.spyOn(fns, 'getUIContextPathBAU').mockReturnValue('/mocked-bau-path');
    window.mfe = {
      scmUpgradeMfeEnable: false,
    };
    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'activeMtn') return '5185673926';
      if (value === 'deviceFromCart') return true;
      return null;
    });
    const mockTrigger = jest.fn();
    APIService.useLazyRemoveLinesQuery.mockImplementation(() => {
      const [result, setResult] = React.useState({
        status: 'uninitialized',
        data: null,
      });
      const trigger = (args) => {
        mockTrigger(args);
        setTimeout(() => {
          setResult({ status: 'fulfilled', data: { success: true } });
        }, 0);
      };

      return [trigger, result];
    });

    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await waitFor(
      () => {
        expect(screen.getByText(/Remove/i)).toBeInTheDocument();
      },
      { timeout: 5000 }
    );

    const removeButton = screen.getByText(/Remove/i);
    fireEvent.click(removeButton);
    await waitFor(
      () => {
        expect(mockNavigate).toHaveBeenCalledWith('/mocked-bau-path/landing.html');
      },
      { timeout: 5000 }
    );
  });
});
