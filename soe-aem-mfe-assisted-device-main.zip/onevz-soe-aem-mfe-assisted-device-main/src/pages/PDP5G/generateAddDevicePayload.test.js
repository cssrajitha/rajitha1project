import { cloneDeep } from 'lodash';
import * as fns from 'onevzsoemfecommon/Helpers';
import generateAddDevicePayload from './generateAddDevicePayload';

const address = {
  addressLine2: '6 7',
  streetNumber: 899,
  streetName: 'test',
  streetType: 'test',
  streetDirection: 'test',
  addressLine1: '',
  city: 'test',
  state: '  test',
  zipCode: '6666666',
  zipCode4: '777777',
  firstName: 'test',
  lastName: 'test',
  eventCorrelationId: '6666666666666',
};

const addressNoStrictDirection = cloneDeep(address);
addressNoStrictDirection.streetDirection = '';

const payloadData = {
  is5GDevice: true,
  customerProfile: {
    customer: {
      homeSalesAddress: { cbandQualified: true, ltequalified: true, bundles: { childSkus: [{}] } },
      qualificationDetails: {
        addressRequest: address,
      },
    },
  },
  activeMtn: '1234567890',
  devicedata: {
    id: 'device123',
    giftBoxSku: 'giftBox123',
    oDUSku: 'oDUSku123',
    iDUSku: 'iDUSku123',
    oDUimei: 'oDUimei123',
    oDUiccid: 'oDUiccid123',
    iDUmacid: 'iDUmacid123',
  },
  qualificationDetails: {
    fiveGHomeQualified: false,
  },
  cartDetails: {
    cart: {
      lineDetails: {
        lineInfo: [
          {
            mobileNumber: '1234567890',
            isNewlyAddedLine: true,
            multiLineSeqNumber: 123,
            lineNumber: 'newLine1',
          },
        ],
      },
    },
  },
  bundleProduct: {
    productId: 'bundle123',
    childSkus: [
      {
        simSku: 'sim123',
        bundleLinks: {
          deviceLinks: [
            {
              deviceSku: {
                simSku: 'sim456',
                sorId: 'sor123',
              },
            },
          ],
        },
        is5gHomeSelfInstall: true,
        is5gHomeProfessionalInstall: false,
      },
    ],
  },
  getSelectedStoreDetails: {
    netaceLocationCode: 'location123',
  },
  customerType: 'N',
  cbandBundleFlow: true,
  deviceData: {
    skuId: 'device456',
    deviceId: 'device789',
    simId: 'sim789',
    preferredSoftSim: 'sim789',
  },
  ispuToggleOn: true,
  lineDetails: [
    {
      mtn: '1234567890',
      isNewlyAddedLine: true,
    },
  ],
  date: '2022-01-01',
  isOptixFlexRedesignCheck: true,
  is5GGemini: true,
  isfiveGScan: true,
  isCsscRepFromOptix: true,
  LTEorCBandQualified: false,
  isIspuItemInCart: true,
  selectedStore: { data: {} },
};

jest.setTimeout(50000);
jest.mock(
  'onevzsoemfecommon/Helpers',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfecommon/Helpers'),
    getQueryParamByName: jest.fn(),
  }),
  { virtual: true },
);

describe('generateAddDevicePayload', () => {
  it('should return the correct request object', () => {
    generateAddDevicePayload(payloadData);
  });
  it('should return the empty', () => {
    generateAddDevicePayload();
  });

  it('should return the empty', () => {
    sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'WiFi-Backup');
    generateAddDevicePayload(payloadData);
  });
  it('should return the homeSales', () => {
    const homeSalesFlow = cloneDeep(payloadData);
    homeSalesFlow.customerProfile.customer.isHomeSales = 'true';
    generateAddDevicePayload(homeSalesFlow);
  });

  it('should return the homeSales', () => {
    const homeSalesFlow = cloneDeep(payloadData);
    homeSalesFlow.customerProfile.customer.isHomeSales = 'true';
    homeSalesFlow.customerProfile.customer.homeSalesAddress.bundles = [{ bundleName: 'Gen4' }];
    generateAddDevicePayload(homeSalesFlow);
  });

  it('isFWASimplificationEnabledEC flow', () => {
    const isFWASimplificationEnabledECData = cloneDeep(payloadData);
    isFWASimplificationEnabledECData.customerProfile.customer.isFWASimplificationEnabled = true;
    isFWASimplificationEnabledECData.isFWAcheckAltAddress = true;
    generateAddDevicePayload(isFWASimplificationEnabledECData);
  });

  it('cBand flow', () => {
    const cBandQualifiedData = cloneDeep(payloadData);
    cBandQualifiedData.isfiveGScan = false;
    cBandQualifiedData.is5GGemini = false;
    cBandQualifiedData.getSelectedStoreDetails = {};
    cBandQualifiedData.customerProfile.customer.qualificationDetails.addressRequest.cBandQualified = true;
    cBandQualifiedData.bundleProduct.childSkus[0].is5gHomeSelfInstall = false;
    cBandQualifiedData.bundleProduct.childSkus[0].is5gHomeProfessionalInstall = true;
    generateAddDevicePayload(cBandQualifiedData);
  });

  it('FWACBandbundle flow', () => {
    const FWACBandbundleData = cloneDeep(payloadData);
    FWACBandbundleData.isfiveGScan = false;
    FWACBandbundleData.is5GGemini = false;
    FWACBandbundleData.customerProfile.customer.qualificationDetails.addressRequest.fiveGHomeQualified = true;
    FWACBandbundleData.qualificationDetails.cBandQualified = false;
    FWACBandbundleData.bundleProduct.childSkus[0].is5gHomeSelfInstall = false;
    FWACBandbundleData.bundleProduct.childSkus[0].is5gHomeProfessionalInstall = true;
    FWACBandbundleData.customerProfile.customer.homeSalesAddress.bundles = {};
    generateAddDevicePayload(FWACBandbundleData);
  });

  it('tanglewoodQualified flow', () => {
    sessionStorage.setItem('Qualification_type', 'TGW');
    const tanglewoodQualifiedData = cloneDeep(payloadData);
    tanglewoodQualifiedData.isfiveGScan = false;
    tanglewoodQualifiedData.is5GGemini = false;
    tanglewoodQualifiedData.customerProfile.customer.qualificationDetails.addressRequest.tanglewoodQualified = true;
    tanglewoodQualifiedData.bundleProduct.childSkus[0].is5gHomeSelfInstall = false;
    tanglewoodQualifiedData.bundleProduct.childSkus[0].is5gHomeProfessionalInstall = false;
    tanglewoodQualifiedData.customerProfile.customer.homeSalesAddress.bundles = {};
    tanglewoodQualifiedData.LTEorCBandQualified = false;
    generateAddDevicePayload(tanglewoodQualifiedData);
  });

  it('tanglewoodQualified flow', () => {
    sessionStorage.setItem('Qualification_type', 'TGW');
    const tanglewoodQualifiedData = cloneDeep(payloadData);
    tanglewoodQualifiedData.isfiveGScan = false;
    tanglewoodQualifiedData.is5GGemini = false;
    tanglewoodQualifiedData.customerProfile.customer.qualificationDetails.addressRequest.tanglewoodQualified = false;
    tanglewoodQualifiedData.bundleProduct.childSkus[0].is5gHomeSelfInstall = false;
    tanglewoodQualifiedData.bundleProduct.childSkus[0].is5gHomeProfessionalInstall = false;
    tanglewoodQualifiedData.customerProfile.customer.homeSalesAddress.bundles = {};
    tanglewoodQualifiedData.LTEorCBandQualified = false;
    tanglewoodQualifiedData.is5GDevice = true;
    generateAddDevicePayload(tanglewoodQualifiedData);
  });

  it('isFWASimplificationEnabledEC flow', () => {
    const isFWASimplificationEnabledECData = cloneDeep(payloadData);
    isFWASimplificationEnabledECData.isFWASimplificationEnabledEC = true;
    isFWASimplificationEnabledECData.isFWAcheckAltAddress = true;
    generateAddDevicePayload(isFWASimplificationEnabledECData);
  });

  it('LTEorCBandQualified flow', () => {
    sessionStorage.setItem('Qualification_type', 'LTE');
    const LTEorCBandQualifiedData = cloneDeep(payloadData);
    LTEorCBandQualifiedData.LTEorCBandQualified = true;
    generateAddDevicePayload(LTEorCBandQualifiedData);
  });

  it('LTEorCBandQualified flow', () => {
    sessionStorage.setItem('Qualification_type', 'LTE');
    const LTEorCBandQualifiedData = cloneDeep(payloadData);
    LTEorCBandQualifiedData.LTEorCBandQualified = true;
    LTEorCBandQualifiedData.customerType = '';
    generateAddDevicePayload(LTEorCBandQualifiedData);
  });

  it('LTEorCBandQualified flow read qualification data from sessin storage', () => {
    sessionStorage.setItem('Qualification_type', 'CBD');
    sessionStorage.setItem('address_Details', JSON.stringify(address));
    const LTEorCBandQualifiedData = cloneDeep(payloadData);
    LTEorCBandQualifiedData.LTEorCBandQualified = true;
    LTEorCBandQualifiedData.isHomeSales = true;
    LTEorCBandQualifiedData.customerProfile.customer.qualificationDetails.addressRequest = '';
    generateAddDevicePayload(LTEorCBandQualifiedData);
  });
  it('cBand flow', () => {
    const cBandQualifiedData = cloneDeep(payloadData);
    cBandQualifiedData.isfiveGScan = false;
    cBandQualifiedData.is5GGemini = false;
    cBandQualifiedData.getSelectedStoreDetails = {};
    cBandQualifiedData.customerProfile.customer.qualificationDetails.addressRequest.cBandQualified = true;
    cBandQualifiedData.bundleProduct.childSkus[0].is5gHomeSelfInstall = true;
    cBandQualifiedData.bundleProduct.childSkus[0].is5gHomeProfessionalInstall = true;
    generateAddDevicePayload(cBandQualifiedData);
  });
  it('local scan flow', () => {
    const scanDevice = cloneDeep(payloadData);
    scanDevice.isfiveGGemini = true;
    scanDevice.devicedata = { skuId: 'SKU123', deviceId: 'device123', simId: 'sim123', preferredSoftSim: 'sim123' };
    generateAddDevicePayload(scanDevice);
  });
  it('Wifi BAckup flow CBAND flow new customer', () => {
    sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'WiFi-Backup');
    sessionStorage.setItem('wifiBackupCbandQualified', 'true');
    const wifiBackUp = cloneDeep(payloadData);
    generateAddDevicePayload(wifiBackUp);
  });

  it('Wifi BAckup flow CBAND flow Existing customer', () => {
    sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'WiFi-Backup');
    sessionStorage.setItem('wifiBackupCbandQualified', 'true');
    const wifiBackUp = cloneDeep(payloadData);
    wifiBackUp.customerProfile.customer.qualificationDetails.addressRequest = addressNoStrictDirection;
    wifiBackUp.customerType = '';
    generateAddDevicePayload(wifiBackUp);
  });

  it('Wifi BAckup flow CBAND flow New customer', () => {
    sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'WiFi-Backup');
    sessionStorage.setItem('wifiBackupCbandQualified', 'false');
    sessionStorage.setItem('wifiBackupLteQualified', 'true');
    sessionStorage.setItem('address_Details', '{}');
    const wifiBackUp = cloneDeep(payloadData);
    wifiBackUp.customerType = 'N';
    wifiBackUp.customerProfile.customer.qualificationDetails.addressRequest = '';
    generateAddDevicePayload(wifiBackUp);
  });

  it('Wifi BAckup flow CBAND flow Existing customer', () => {
    sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'WiFi-Backup');
    sessionStorage.setItem('wifiBackupCbandQualified', 'false');
    sessionStorage.setItem('wifiBackupLteQualified', 'true');
    const wifiBackUp = cloneDeep(payloadData);
    wifiBackUp.customerType = '';
    generateAddDevicePayload(wifiBackUp);
  });

  it('Home Sales Order Flow', () => {
    const homeSalesFlow = cloneDeep(payloadData);
    homeSalesFlow.isHomeSales = true;
    generateAddDevicePayload(homeSalesFlow);
  });

  it('Local Scan From Landing', () => {
    const scanDevice = cloneDeep(payloadData);
    scanDevice.isfiveGGemini = true;
    scanDevice.devicedata = {};
    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'skuId') return 'deviceSKU';
      if (value === 'deviceId') return '1234567890';
      if (value === 'simId') return '891234576886996969';
      if (value === 'preferredSoftSim') return 'DFILL-SIM';
      return null;
    });
    generateAddDevicePayload(scanDevice);
  });

  it('Local Scan From Landing Self Setup', () => {
    const scanDevice = cloneDeep(payloadData);
    scanDevice.isfiveGScan = true;
    scanDevice.devicedata = {};
    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'deviceId') return '1234567890';
      if (value === 'simId') return '1234567890';
      if (value === 'id') return '891234576886996969';
      if (value === 'giftBoxSku') return 'deviceSKU';
      if (value === 'oDUSku') return 'oDUSku';
      if (value === 'iDUSku') return 'iDUSku';
      if (value === 'iDUmacid') return 'iDUmacid';
      return null;
    });
    generateAddDevicePayload(scanDevice);
  });

  it('When trade3POChoiceOfferFFlag is true', () => {
    const trade3POChoiceOfferFFlag = cloneDeep(payloadData);
    trade3POChoiceOfferFFlag.trade3POChoiceOfferFFlag = true;
    trade3POChoiceOfferFFlag.selectedSku = { skuFilters: { deviceFilterType: 'Wifi BackUP' } };
    generateAddDevicePayload(trade3POChoiceOfferFFlag);
  });

  it('scmUpgradeMfeEnable with is5gHomeSelfInstall and cartInfo properties', () => {
    // Mock window.mfe.scmUpgradeMfeEnable
    const originalWindow = global.window;
    global.window = {
      ...originalWindow,
      mfe: {
        scmUpgradeMfeEnable: true,
      },
    };

    // Mock sessionStorage for cartId and caseId
    const setItemSpy = jest.spyOn(Storage.prototype, 'setItem');
    const getItemSpy = jest.spyOn(Storage.prototype, 'getItem');
    getItemSpy.mockImplementation((key) => {
      if (key === 'acssMfeCartId') return 'mockCartId123';
      if (key === 'acssMfeCaseId') return 'mockCaseId456';
      return null;
    });

    const scmUpgradeData = cloneDeep(payloadData);
    scmUpgradeData.bundleProduct.childSkus[0].is5gHomeSelfInstall = true;
    scmUpgradeData.customerProfile.data = {
      customer: {
        caseId: 'testCaseId',
        cartId: 'testCartId', 
        lookupMtn: 'testLookupMtn',
        accountNo: 'testAccountNo',
      },
    };
    scmUpgradeData.cartDetails.cart.cartHeader = {
      cartCreator: {
        cartCreator: 'testCartCreator',
      },
    };
    scmUpgradeData.customerType = 'N'; // New customer type

    const result = generateAddDevicePayload(scmUpgradeData);

    // Cleanup
    global.window = originalWindow;
    setItemSpy.mockRestore();
    getItemSpy.mockRestore();
  });

  it('scmUpgradeMfeEnable with fiveGHomeQualified regex match for existing customer', () => {
    // Mock window.mfe.scmUpgradeMfeEnable
    const originalWindow = global.window;
    global.window = {
      ...originalWindow,
      mfe: {
        scmUpgradeMfeEnable: true,
      },
    };

    const scmUpgradeExistingData = cloneDeep(payloadData);
    scmUpgradeExistingData.bundleProduct.childSkus[0].is5gHomeSelfInstall = false;
    scmUpgradeExistingData.customerProfile.customer.qualificationDetails.addressRequest.fiveGHomeQualified = 'TRUE'; // Should match /true/i regex
    scmUpgradeExistingData.customerProfile.data = {
      customer: {
        lookupMtn: 'existingLookupMtn',
        accountNo: 'existingAccountNo',
      },
    };
    scmUpgradeExistingData.cartDetails.cart.cartHeader = {
      cartCreator: {
        cartCreator: 'existingCartCreator',
      },
    };
    scmUpgradeExistingData.customerType = 'E'; // Existing customer type

    const result = generateAddDevicePayload(scmUpgradeExistingData);

    // Cleanup
    global.window = originalWindow;
  });

  it('scmUpgradeMfeEnable with fiveGHomeQualified true string to cover line 208', () => {
    // Mock window.mfe.scmUpgradeMfeEnable
    const originalWindow = global.window;
    global.window = {
      ...originalWindow,
      mfe: {
        scmUpgradeMfeEnable: true,
      },
    };

    const scmUpgradeTestData = cloneDeep(payloadData);
    
    // Ensure is5gHomeSelfInstall is false so we test the fiveGHomeQualified condition
    scmUpgradeTestData.bundleProduct.childSkus[0].is5gHomeSelfInstall = false;
    
    // Set up qualificationDetails to have fiveGHomeQualified = 'true' in the correct location
    // The getQualificationDetails function looks at customer.qualificationDetails.addressRequest
    scmUpgradeTestData.customerProfile.customer.qualificationDetails = {
      addressRequest: {
        ...address,
        fiveGHomeQualified: 'true', // This should match /true/i regex in line 208
      },
    };
    
    // Also ensure we have the activeLineItem that matches activeMtn for getQualificationDetails
    scmUpgradeTestData.cartDetails.cart.lineDetails = {
      lineInfo: [
        {
          mobileNumber: '1234567890', // This matches activeMtn
          isNewlyAddedLine: true,
          multiLineSeqNumber: 123,
          lineNumber: 'newLine1',
        },
      ],
    };
    
    // Set up required customer data for cartInfo
    scmUpgradeTestData.customerProfile.data = {
      customer: {
        caseId: 'testCaseId208',
        cartId: 'testCartId208',
        lookupMtn: 'testLookupMtn208',
        accountNo: 'testAccountNo208',
      },
    };
    
    scmUpgradeTestData.cartDetails.cart.cartHeader = {
      cartCreator: {
        cartCreator: 'testCartCreator208',
      },
    };
    
    scmUpgradeTestData.customerType = 'N';

    const result = generateAddDevicePayload(scmUpgradeTestData);

    // Cleanup
    global.window = originalWindow;
  });

  it('scmUpgradeMfeEnable with is5gHomeSelfInstall true to cover first part of OR condition', () => {
    // Mock window.mfe.scmUpgradeMfeEnable
    const originalWindow = global.window;
    global.window = {
      ...originalWindow,
      mfe: {
        scmUpgradeMfeEnable: true,
      },
    };

    const scmUpgradeTestData = cloneDeep(payloadData);
    
    // Ensure is5gHomeSelfInstall is true to test first part of OR condition
    scmUpgradeTestData.bundleProduct.childSkus[0].is5gHomeSelfInstall = true;
    
    // Set fiveGHomeQualified to false to ensure we're only testing the first part
    scmUpgradeTestData.customerProfile.customer.qualificationDetails = {
      addressRequest: {
        ...address,
        fiveGHomeQualified: false,
      },
    };
    
    // Set up required customer data for cartInfo
    scmUpgradeTestData.customerProfile.data = {
      customer: {
        caseId: 'testCaseIdSelfInstall',
        cartId: 'testCartIdSelfInstall',
        lookupMtn: 'testLookupMtnSelfInstall',
        accountNo: 'testAccountNoSelfInstall',
      },
    };
    
    scmUpgradeTestData.cartDetails.cart.cartHeader = {
      cartCreator: {
        cartCreator: 'testCartCreatorSelfInstall',
      },
    };
    
    scmUpgradeTestData.customerType = 'E'; // Existing customer to test lookupMtn path

    const result = generateAddDevicePayload(scmUpgradeTestData);

    // Cleanup
    global.window = originalWindow;
  });

  it('is5GDevice and scmUpgradeMfeEnable for device networkBandwidthType coverage line 262', () => {
    // Mock window.mfe.scmUpgradeMfeEnable
    const originalWindow = global.window;
    global.window = {
      ...originalWindow,
      mfe: {
        scmUpgradeMfeEnable: true,
      },
    };

    const deviceNetworkTestData = cloneDeep(payloadData);
    
    // Ensure is5GDevice is true to test the device network bandwidth condition
    deviceNetworkTestData.is5GDevice = true;
    
    // Set up professional install to test 'BUNDLE' sorType
    deviceNetworkTestData.bundleProduct.childSkus[0].is5gHomeProfessionalInstall = true;
    
    const result = generateAddDevicePayload(deviceNetworkTestData);

    // Cleanup
    global.window = originalWindow;
  });

  it('is5GDevice and scmUpgradeMfeEnable with self install for empty sorType coverage', () => {
    // Mock window.mfe.scmUpgradeMfeEnable
    const originalWindow = global.window;
    global.window = {
      ...originalWindow,
      mfe: {
        scmUpgradeMfeEnable: true,
      },
    };

    const deviceNetworkSelfInstallData = cloneDeep(payloadData);
    
    // Ensure is5GDevice is true to test the device network bandwidth condition
    deviceNetworkSelfInstallData.is5GDevice = true;
    
    // Set up self install to test empty sorType
    deviceNetworkSelfInstallData.bundleProduct.childSkus[0].is5gHomeProfessionalInstall = false;
    deviceNetworkSelfInstallData.bundleProduct.childSkus[0].is5gHomeSelfInstall = true;
    
    const result = generateAddDevicePayload(deviceNetworkSelfInstallData);

    // Cleanup
    global.window = originalWindow;
  });

  it('scmUpgradeMfeEnable false to cover line 207 negative path', () => {
    // Mock window.mfe.scmUpgradeMfeEnable as false
    const originalWindow = global.window;
    global.window = {
      ...originalWindow,
      mfe: {
        scmUpgradeMfeEnable: false, // This should make the condition false
      },
    };

    const scmUpgradeDisabledData = cloneDeep(payloadData);
    
    // Even though other conditions are true, scmUpgradeMfeEnable is false
    scmUpgradeDisabledData.bundleProduct.childSkus[0].is5gHomeSelfInstall = true;
    scmUpgradeDisabledData.is5GDevice = true;
    
    const result = generateAddDevicePayload(scmUpgradeDisabledData);

    // Cleanup
    global.window = originalWindow;
  });

  it('cartId and caseId fallback to sessionStorage coverage for lines 210-211', () => {
    // Mock window.mfe.scmUpgradeMfeEnable
    const originalWindow = global.window;
    global.window = {
      ...originalWindow,
      mfe: {
        scmUpgradeMfeEnable: true,
      },
    };

    // Mock sessionStorage for cartId and caseId fallback
    const getItemSpy = jest.spyOn(Storage.prototype, 'getItem');
    getItemSpy.mockImplementation((key) => {
      if (key === 'acssMfeCartId') return 'sessionCartId123';
      if (key === 'acssMfeCaseId') return 'sessionCaseId456';
      return null;
    });

    const sessionStorageTestData = cloneDeep(payloadData);
    
    // Enable the conditions for cartInfo spread
    sessionStorageTestData.bundleProduct.childSkus[0].is5gHomeSelfInstall = true;
    
    // Set up customer data WITHOUT cartId and caseId to test sessionStorage fallback
    sessionStorageTestData.customerProfile.data = {
      customer: {
        // No cartId or caseId here to test fallback
        lookupMtn: 'testLookupMtn',
        accountNo: 'testAccountNo',
      },
    };
    
    sessionStorageTestData.cartDetails.cart.cartHeader = {
      cartCreator: {
        cartCreator: 'testCartCreator',
      },
    };
    
    sessionStorageTestData.customerType = 'N';

    const result = generateAddDevicePayload(sessionStorageTestData);

    // Cleanup
    global.window = originalWindow;
    getItemSpy.mockRestore();
  });

  it('cartId and caseId empty fallback to empty string coverage for lines 210-211', () => {
    // Mock window.mfe.scmUpgradeMfeEnable
    const originalWindow = global.window;
    global.window = {
      ...originalWindow,
      mfe: {
        scmUpgradeMfeEnable: true,
      },
    };

    // Mock sessionStorage to return null for complete fallback test
    const getItemSpy = jest.spyOn(Storage.prototype, 'getItem');
    getItemSpy.mockImplementation((key) => {
      return null; // This will test the final fallback to empty string
    });

    const emptyFallbackTestData = cloneDeep(payloadData);
    
    // Enable the conditions for cartInfo spread
    emptyFallbackTestData.bundleProduct.childSkus[0].is5gHomeSelfInstall = true;
    
    // Set up customer data WITHOUT cartId and caseId
    emptyFallbackTestData.customerProfile.data = {
      customer: {
        lookupMtn: 'testLookupMtn',
        accountNo: 'testAccountNo',
      },
    };
    
    emptyFallbackTestData.cartDetails.cart.cartHeader = {
      cartCreator: {
        cartCreator: 'testCartCreator',
      },
    };
    
    emptyFallbackTestData.customerType = 'E'; // Test existing customer path for line 213

    const result = generateAddDevicePayload(emptyFallbackTestData);

    // Cleanup
    global.window = originalWindow;
    getItemSpy.mockRestore();
  });
  it('scmUpgradeMfeEnable with is5gHomeSelfInstall and cartInfo properties', () => {
    // Mock window.mfe.scmUpgradeMfeEnable
    const originalWindow = global.window;
    global.window = {
      ...originalWindow,
      mfe: {
        scmUpgradeMfeEnable: true,
      },
    };

    // Mock sessionStorage for cartId and caseId
    const setItemSpy = jest.spyOn(Storage.prototype, 'setItem');
    const getItemSpy = jest.spyOn(Storage.prototype, 'getItem');
    getItemSpy.mockImplementation((key) => {
      if (key === 'acssMfeCartId') return 'mockCartId123';
      if (key === 'acssMfeCaseId') return 'mockCaseId456';
      return null;
    });

    const scmUpgradeData = cloneDeep(payloadData);
    scmUpgradeData.bundleProduct.childSkus[0].is5gHomeSelfInstall = true;
    scmUpgradeData.customerProfile.data = {
      customer: {
        caseId: 'testCaseId',
        cartId: 'testCartId', 
        lookupMtn: 'testLookupMtn',
        accountNo: 'testAccountNo',
      },
    };
    scmUpgradeData.cartDetails.cart.cartHeader = {
      cartCreator: {
        cartCreator: 'testCartCreator',
      },
    };
    scmUpgradeData.customerType = 'N'; // New customer type

    const result = generateAddDevicePayload(scmUpgradeData);

    // Cleanup
    global.window = originalWindow;
    setItemSpy.mockRestore();
    getItemSpy.mockRestore();
  });

  it('scmUpgradeMfeEnable with fiveGHomeQualified regex match for existing customer', () => {
    // Mock window.mfe.scmUpgradeMfeEnable
    const originalWindow = global.window;
    global.window = {
      ...originalWindow,
      mfe: {
        scmUpgradeMfeEnable: true,
      },
    };

    const scmUpgradeExistingData = cloneDeep(payloadData);
    scmUpgradeExistingData.bundleProduct.childSkus[0].is5gHomeSelfInstall = false;
    scmUpgradeExistingData.customerProfile.customer.qualificationDetails.addressRequest.fiveGHomeQualified = 'TRUE'; // Should match /true/i regex
    scmUpgradeExistingData.customerProfile.data = {
      customer: {
        lookupMtn: 'existingLookupMtn',
        accountNo: 'existingAccountNo',
      },
    };
    scmUpgradeExistingData.cartDetails.cart.cartHeader = {
      cartCreator: {
        cartCreator: 'existingCartCreator',
      },
    };
    scmUpgradeExistingData.customerType = 'E'; // Existing customer type

    const result = generateAddDevicePayload(scmUpgradeExistingData);

    // Cleanup
    global.window = originalWindow;
  });

  it('scmUpgradeMfeEnable with fiveGHomeQualified true string to cover line 208', () => {
    // Mock window.mfe.scmUpgradeMfeEnable
    const originalWindow = global.window;
    global.window = {
      ...originalWindow,
      mfe: {
        scmUpgradeMfeEnable: true,
      },
    };

    const scmUpgradeTestData = cloneDeep(payloadData);
    
    // Ensure is5gHomeSelfInstall is false so we test the fiveGHomeQualified condition
    scmUpgradeTestData.bundleProduct.childSkus[0].is5gHomeSelfInstall = false;
    
    // Set up qualificationDetails to have fiveGHomeQualified = 'true' in the correct location
    // The getQualificationDetails function looks at customer.qualificationDetails.addressRequest
    scmUpgradeTestData.customerProfile.customer.qualificationDetails = {
      addressRequest: {
        ...address,
        fiveGHomeQualified: 'true', // This should match /true/i regex in line 208
      },
    };
    
    // Also ensure we have the activeLineItem that matches activeMtn for getQualificationDetails
    scmUpgradeTestData.cartDetails.cart.lineDetails = {
      lineInfo: [
        {
          mobileNumber: '1234567890', // This matches activeMtn
          isNewlyAddedLine: true,
          multiLineSeqNumber: 123,
          lineNumber: 'newLine1',
        },
      ],
    };
    
    // Set up required customer data for cartInfo
    scmUpgradeTestData.customerProfile.data = {
      customer: {
        caseId: 'testCaseId208',
        cartId: 'testCartId208',
        lookupMtn: 'testLookupMtn208',
        accountNo: 'testAccountNo208',
      },
    };
    
    scmUpgradeTestData.cartDetails.cart.cartHeader = {
      cartCreator: {
        cartCreator: 'testCartCreator208',
      },
    };
    
    scmUpgradeTestData.customerType = 'N';

    const result = generateAddDevicePayload(scmUpgradeTestData);

    // Cleanup
    global.window = originalWindow;
  });

  it('scmUpgradeMfeEnable with is5gHomeSelfInstall true to cover first part of OR condition', () => {
    // Mock window.mfe.scmUpgradeMfeEnable
    const originalWindow = global.window;
    global.window = {
      ...originalWindow,
      mfe: {
        scmUpgradeMfeEnable: true,
      },
    };

    const scmUpgradeTestData = cloneDeep(payloadData);
    
    // Ensure is5gHomeSelfInstall is true to test first part of OR condition
    scmUpgradeTestData.bundleProduct.childSkus[0].is5gHomeSelfInstall = true;
    
    // Set fiveGHomeQualified to false to ensure we're only testing the first part
    scmUpgradeTestData.customerProfile.customer.qualificationDetails = {
      addressRequest: {
        ...address,
        fiveGHomeQualified: false,
      },
    };
    
    // Set up required customer data for cartInfo
    scmUpgradeTestData.customerProfile.data = {
      customer: {
        caseId: 'testCaseIdSelfInstall',
        cartId: 'testCartIdSelfInstall',
        lookupMtn: 'testLookupMtnSelfInstall',
        accountNo: 'testAccountNoSelfInstall',
      },
    };
    
    scmUpgradeTestData.cartDetails.cart.cartHeader = {
      cartCreator: {
        cartCreator: 'testCartCreatorSelfInstall',
      },
    };
    
    scmUpgradeTestData.customerType = 'E'; // Existing customer to test lookupMtn path

    const result = generateAddDevicePayload(scmUpgradeTestData);

    // Cleanup
    global.window = originalWindow;
  });

  it('is5GDevice and scmUpgradeMfeEnable for device networkBandwidthType coverage line 262', () => {
    // Mock window.mfe.scmUpgradeMfeEnable
    const originalWindow = global.window;
    global.window = {
      ...originalWindow,
      mfe: {
        scmUpgradeMfeEnable: true,
      },
    };

    const deviceNetworkTestData = cloneDeep(payloadData);
    
    // Ensure is5GDevice is true to test the device network bandwidth condition
    deviceNetworkTestData.is5GDevice = true;
    
    // Set up professional install to test 'BUNDLE' sorType
    deviceNetworkTestData.bundleProduct.childSkus[0].is5gHomeProfessionalInstall = true;
    
    const result = generateAddDevicePayload(deviceNetworkTestData);

    // Cleanup
    global.window = originalWindow;
  });

  it('is5GDevice and scmUpgradeMfeEnable with self install for empty sorType coverage', () => {
    // Mock window.mfe.scmUpgradeMfeEnable
    const originalWindow = global.window;
    global.window = {
      ...originalWindow,
      mfe: {
        scmUpgradeMfeEnable: true,
      },
    };

    const deviceNetworkSelfInstallData = cloneDeep(payloadData);
    
    // Ensure is5GDevice is true to test the device network bandwidth condition
    deviceNetworkSelfInstallData.is5GDevice = true;
    
    // Set up self install to test empty sorType
    deviceNetworkSelfInstallData.bundleProduct.childSkus[0].is5gHomeProfessionalInstall = false;
    deviceNetworkSelfInstallData.bundleProduct.childSkus[0].is5gHomeSelfInstall = true;
    
    const result = generateAddDevicePayload(deviceNetworkSelfInstallData);

    // Cleanup
    global.window = originalWindow;
  });

  it('scmUpgradeMfeEnable false to cover line 207 negative path', () => {
    const originalWindow = global.window;
    global.window = {
      ...originalWindow,
      mfe: {
        scmUpgradeMfeEnable: false, 
      },
    };

    const scmUpgradeDisabledData = cloneDeep(payloadData);
    
    scmUpgradeDisabledData.bundleProduct.childSkus[0].is5gHomeSelfInstall = true;
    scmUpgradeDisabledData.is5GDevice = true;
    
    const result = generateAddDevicePayload(scmUpgradeDisabledData);

    global.window = originalWindow;
  });

  it('cartId and caseId fallback to sessionStorage coverage for lines 210-211', () => {
    const originalWindow = global.window;
    global.window = {
      ...originalWindow,
      mfe: {
        scmUpgradeMfeEnable: true,
      },
    };

    const getItemSpy = jest.spyOn(Storage.prototype, 'getItem');
    getItemSpy.mockImplementation((key) => {
      if (key === 'acssMfeCartId') return 'sessionCartId123';
      if (key === 'acssMfeCaseId') return 'sessionCaseId456';
      return null;
    });

    const sessionStorageTestData = cloneDeep(payloadData);
    
    sessionStorageTestData.bundleProduct.childSkus[0].is5gHomeSelfInstall = true;
    
    sessionStorageTestData.customerProfile.data = {
      customer: {
        lookupMtn: 'testLookupMtn',
        accountNo: 'testAccountNo',
      },
    };
    
    sessionStorageTestData.cartDetails.cart.cartHeader = {
      cartCreator: {
        cartCreator: 'testCartCreator',
      },
    };
    
    sessionStorageTestData.customerType = 'N';

    const result = generateAddDevicePayload(sessionStorageTestData);

    global.window = originalWindow;
    getItemSpy.mockRestore();
  });

  it('cartId and caseId empty fallback to empty string coverage for lines 210-211', () => {
    const originalWindow = global.window;
    global.window = {
      ...originalWindow,
      mfe: {
        scmUpgradeMfeEnable: true,
      },
    };

    const getItemSpy = jest.spyOn(Storage.prototype, 'getItem');
    getItemSpy.mockImplementation((key) => {
      return null; 
    });

    const emptyFallbackTestData = cloneDeep(payloadData);
    
    emptyFallbackTestData.bundleProduct.childSkus[0].is5gHomeSelfInstall = true;
    
    emptyFallbackTestData.customerProfile.data = {
      customer: {
        lookupMtn: 'testLookupMtn',
        accountNo: 'testAccountNo',
      },
    };
    
    emptyFallbackTestData.cartDetails.cart.cartHeader = {
      cartCreator: {
        cartCreator: 'testCartCreator',
      },
    };
    
    emptyFallbackTestData.customerType = 'E';

    const result = generateAddDevicePayload(emptyFallbackTestData);

    global.window = originalWindow;
    getItemSpy.mockRestore();
  });
  it('should add scmUpgrade cartInfo when scmUpgradeMfeEnable and is5gHomeSelfInstall are true', () => {
    const originalMfe = global.window.mfe;

    global.window.mfe = {
      scmUpgradeMfeEnable: true,
    };

    const setItemSpy = jest.spyOn(Storage.prototype, 'setItem');
    const getItemSpy = jest.spyOn(Storage.prototype, 'getItem');
    getItemSpy.mockImplementation((key) => {
      if (key === 'acssMfeCartId') return 'mockCartId123';
      if (key === 'acssMfeCaseId') return 'mockCaseId456';
      return null;
    });

    const scmUpgradeData = cloneDeep(payloadData);
    scmUpgradeData.bundleProduct.childSkus[0].is5gHomeSelfInstall = true;
    scmUpgradeData.customerProfile.data = {
      customer: {
        caseId: 'testCaseId',
        cartId: 'testCartId',
        lookupMtn: 'testLookupMtn',
        accountNo: 'testAccountNo',
      },
    };
    scmUpgradeData.cartDetails.cart.cartHeader = {
      cartCreator: {
        cartCreator: 'testCartCreator',
      },
    };
    scmUpgradeData.customerType = 'N';

    const result = generateAddDevicePayload(scmUpgradeData);

    expect(result.cartInfo.clientAppName).toBe('VZW-ACSS'); 
    expect(result.cartInfo.cartId).toBe('testCartId');
    expect(result.cartInfo.caseId).toBe('testCaseId');
    expect(result.cartInfo.accountNumber).toBe('testAccountNo');
    expect(result.cartInfo.cartCreator).toBe('testCartCreator');

    global.window.mfe = originalMfe;
    setItemSpy.mockRestore();
    getItemSpy.mockRestore();
  });
  it('should use sessionStorage fallback and lookupMtn for existing customers', () => {
    const originalMfe = global.window.mfe;
    global.window.mfe = { scmUpgradeMfeEnable: true };

    const getItemSpy = jest.spyOn(Storage.prototype, 'getItem');
    getItemSpy.mockImplementation((key) => {
      if (key === 'acssMfeCartId') return 'sessionCartId123';
      if (key === 'acssMfeCaseId') return 'sessionCaseId456';
      return null;
    });

    const scmUpgradeData = cloneDeep(payloadData);
    scmUpgradeData.bundleProduct.childSkus[0].is5gHomeSelfInstall = true;
    
    scmUpgradeData.customerType = 'E'; 

    scmUpgradeData.customerProfile.data = {
      customer: {
        
        lookupMtn: 'existingMtn123', 
        accountNo: 'testAccountNo',
      },
    };
    scmUpgradeData.cartDetails.cart.cartHeader = {
      cartCreator: { cartCreator: 'testCartCreator' },
    };

    const result = generateAddDevicePayload(scmUpgradeData);

    expect(result.cartInfo.clientAppName).toBe('VZW-ACSS');
    expect(result.cartInfo.cartId).toBe('sessionCartId123'); // <-- Checks sessionStorage
    expect(result.cartInfo.caseId).toBe('sessionCaseId456'); // <-- Checks sessionStorage
    expect(result.cartInfo.cartCreator).toBe('existingMtn123'); // <-- Checks 'else' path

    // Cleanup
    global.window.mfe = originalMfe;
    getItemSpy.mockRestore();
  });
  it('should use empty string fallback when all values are null', () => {
    const originalMfe = global.window.mfe;
    global.window.mfe = { scmUpgradeMfeEnable: true };

    const getItemSpy = jest.spyOn(Storage.prototype, 'getItem');
    getItemSpy.mockImplementation((key) => {
      return null; 
    });

    const scmUpgradeData = cloneDeep(payloadData);
    scmUpgradeData.bundleProduct.childSkus[0].is5gHomeSelfInstall = true;
    scmUpgradeData.customerType = 'N';

    scmUpgradeData.customerProfile.data = {
      customer: {
       
        accountNo: 'testAccountNo',
      },
    };
    scmUpgradeData.cartDetails.cart.cartHeader = {
      cartCreator: { cartCreator: 'testCartCreator' },
    };

    const result = generateAddDevicePayload(scmUpgradeData);

    expect(result.cartInfo.clientAppName).toBe('VZW-ACSS');
    expect(result.cartInfo.cartId).toBe(''); 
    expect(result.cartInfo.caseId).toBe('');

    global.window.mfe = originalMfe;
    getItemSpy.mockRestore();
  });
  it('should cover fiveGHomeQualified path when scmUpgradeMfeEnable is true', () => {
    const originalMfe = global.window.mfe;
    global.window.mfe = {
      scmUpgradeMfeEnable: true, 
    };

    const scmUpgradeData = cloneDeep(payloadData);
    
    scmUpgradeData.bundleProduct.childSkus[0].is5gHomeSelfInstall = false; 
    
    scmUpgradeData.customerProfile.customer.qualificationDetails.addressRequest.fiveGHomeQualified = 'TRUE'; 

    scmUpgradeData.customerProfile.data = {
      customer: { caseId: 'case123', cartId: 'cart123', accountNo: 'acct123' },
    };
    scmUpgradeData.cartDetails.cart.cartHeader = {
      cartCreator: { cartCreator: 'creator123' },
    };
    scmUpgradeData.customerType = 'N';

    const result = generateAddDevicePayload(scmUpgradeData);

    expect(result.cartInfo.clientAppName).toBe('VZW-ACSS');
    expect(result.cartInfo.cartId).toBe('cart123');
    expect(result.cartInfo.caseId).toBe('case123');

    global.window.mfe = originalMfe;
  });
  it('should set sorType to BUNDLE when scmUpgrade is on, is5GDevice, and is ProfInstall', () => {
    const originalMfe = global.window.mfe;
    global.window.mfe = {
      scmUpgradeMfeEnable: true, 
    };

    const scmUpgradeData = cloneDeep(payloadData);
    
    scmUpgradeData.is5GDevice = true; 
    
    scmUpgradeData.bundleProduct.childSkus[0].is5gHomeProfessionalInstall = true; 
    scmUpgradeData.bundleProduct.childSkus[0].is5gHomeSelfInstall = false; 

    const result = generateAddDevicePayload(scmUpgradeData);

    const device = result.data.lines[0].device;
    expect(device.networkBandwidthType).toBe('CBD');
    expect(device.sorType).toBe('BUNDLE'); 
    global.window.mfe = originalMfe;
  });
});
