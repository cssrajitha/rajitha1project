import * as fns from 'onevzsoemfecommon/Helpers';
import { render, screen, waitFor, fireEvent } from '../../modules/test-utils/renderHelper';
import PDP5G from './index';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { setupServer, setupServer2, setupServer3, setupServer4, setupServer5 } from './mocks/setupServer';

jest.setTimeout(50000);
jest.mock(
  'onevzsoemfecommon/Helpers',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfecommon/Helpers'),
    getQueryParamByName: jest.fn(),
    isNumeric: jest.fn(),
    capitalizeFirstLetter: jest.fn(),
    formatMtnForNewLine: jest.fn(),
    getUIContextPathBAU: jest.fn(),
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradleProperty: () => ['TRUE', 'TRUE', 'WNC-CR200A,ASK-NCQ1338FA,ARC-XCI55AX','FALSE','TRUE'],
  }),
  { virtual: true },
);

describe(`PDP5g component`, () => {
  setupServer5();
  afterEach(() => {
    jest.restoreAllMocks();
  });
  test('Device Scan testing by entering device Id', async () => {
    sessionStorage.setItem('Qualification_type', 'CBD');
    jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
      if (value === 'activeMtn') return '5185673926';
      return null;
    });
    render(<PDP5G />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await new Promise((res) => {
      setTimeout(res, 30000);
    });
    const deviceTextBox = await screen.findByRole('textbox', {
      name: 'Enter Device ID',
    });
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
    fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
    await new Promise((res) => {
      setTimeout(res, 10000);
    });
    expect(deviceTextBox).toHaveValue('350669643749367');
  });
});
