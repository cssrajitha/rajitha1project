import { setupServer } from 'msw/node';
import { handlers, handlers2, handlers3, handlers4, handlers5 } from './handlers';

export const server = () => setupServer(...handlers());
export const server2 = () => setupServer(...handlers2());
export const server3 = () => setupServer(...handlers3());
export const server4 = () => setupServer(...handlers4());
export const server5 = () => setupServer(...handlers5());
