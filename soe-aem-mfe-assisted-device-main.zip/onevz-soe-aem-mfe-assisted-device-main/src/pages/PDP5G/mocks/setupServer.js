import {
  server as APIServer,
  server2 as APIServer2,
  server3 as APIServer3,
  server4 as APIServer4,
  server5 as APIServer5,
} from './server';

export const setupServer = () => {
  const server = APIServer();

  beforeAll(() => server.listen());
  // Reset any runtime request handlers we may add during the tests.

  afterEach(() => server.resetHandlers());
  // Disable API mocking after the tests are done.

  afterAll(() => server.close());
};

export const setupServer2 = () => {
  const server = APIServer2();

  beforeAll(() => server.listen());
  // Reset any runtime request handlers we may add during the tests.

  afterEach(() => server.resetHandlers());
  // Disable API mocking after the tests are done.

  afterAll(() => server.close());
};

export const setupServer3 = () => {
  const server = APIServer3();

  beforeAll(() => server.listen());
  // Reset any runtime request handlers we may add during the tests.

  afterEach(() => server.resetHandlers());
  // Disable API mocking after the tests are done.

  afterAll(() => server.close());
};

export const setupServer4 = () => {
  const server = APIServer4();

  beforeAll(() => server.listen());
  // Reset any runtime request handlers we may add during the tests.

  afterEach(() => server.resetHandlers());
  // Disable API mocking after the tests are done.

  afterAll(() => server.close());
};

export const setupServer5 = () => {
  const server = APIServer5();

  beforeAll(() => server.listen());
  // Reset any runtime request handlers we may add during the tests.

  afterEach(() => server.resetHandlers());
  // Disable API mocking after the tests are done.

  afterAll(() => server.close());
};
