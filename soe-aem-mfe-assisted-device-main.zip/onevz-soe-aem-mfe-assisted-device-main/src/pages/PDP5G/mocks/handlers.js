import { rest } from 'msw';
import { cloneDeep } from 'lodash';

// api mocking response
import customerProfile from './api/customerProfile.json';
import getDetails from './api/getDetails.json';
import getSkuDetails from './api/getSkuDetails.json';
import retrieveCart from './api/retrieveCart.json';
import productList from './api/productList.json';
import addDevice from './api/addDevice.json';
import removeLines from './api/removeLines.json';

const ValidateDeviceSimIdData = {
  serviceBody: {
    serviceResponse: {
      context: {
        deviceInfo: {
          deviceSku: 'WNC-CR200A',
          deviceId: '350669643749367',
          simInfo: {
            iccid: '',
          },
        },
      },
    },
  },
};
const newValidateDeviceSimIdData = cloneDeep(ValidateDeviceSimIdData);
newValidateDeviceSimIdData.serviceBody.serviceResponse.context.deviceInfo.deviceSku = 'ASK-NCQ1338FA';
const newValidateDeviceSimIdDataSku = cloneDeep(ValidateDeviceSimIdData);
newValidateDeviceSimIdDataSku.serviceBody.serviceResponse.context.deviceInfo.deviceSku = 'ARC-XCI55AX';

const newGetSkuDetails = cloneDeep(getSkuDetails);
newGetSkuDetails.data.deviceSku.inventoryDetails.localInventory.isInStock = false;

const emptyGetSkuDetails = cloneDeep(getSkuDetails);
emptyGetSkuDetails.data.deviceSku = {};

export const handlers = () => [
  rest.post(`*/flexV2/customerProfile`, (req, res, ctx) => res(ctx.status(200), ctx.json(customerProfile))),
  rest.post(`*/flexV2/getDetails`, (req, res, ctx) => res(ctx.status(200), ctx.json(getDetails))),
  rest.post(`*/flexV2/getSkuDetails`, (req, res, ctx) => res(ctx.status(200), ctx.json(getSkuDetails))),
  rest.post(`*/flexV2/retrieve-cart`, (req, res, ctx) => res(ctx.status(200), ctx.json(retrieveCart))),
  rest.post(`*/flexV2/productList`, (req, res, ctx) => res(ctx.status(200), ctx.json(productList))),
  rest.post(`*/flexV2/add-device`, (req, res, ctx) => res(ctx.status(200), ctx.json(addDevice))),
  rest.post(`*/cart/remove-lines`, (req, res, ctx) => res(ctx.status(200), ctx.json(removeLines))),
  rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) =>
    res(ctx.status(200), ctx.json(ValidateDeviceSimIdData)),
  ),
];

const fwaSimplificationEnabledMock = cloneDeep(customerProfile);
const customerProfileCband = cloneDeep(customerProfile);
const newGetDetailsMock = cloneDeep(getDetails);
fwaSimplificationEnabledMock.data.customer = {
  ...fwaSimplificationEnabledMock.data.customer,
  isFWASimplificationEnabled: true,
  qualificationDetails: {
    addressRequest: { fiveGHomeQualified: true, eligibilities: { fiveGHomebundle: ['abc'] } },
  },
};
customerProfileCband.data.customer = {
  ...customerProfileCband.data.customer,
  qualificationDetails: {
    addressRequest: { cBandQualified: true },
    eligibilities: { cbandBundle: [{ bunDleName: 'sdf' }] },
  },
};
newGetDetailsMock.data = {
  ...newGetDetailsMock.data,
  bundleProduct: {
    childSkus: [
      {
        price: {
          fullRetailPrice: {
            contractDuration: null,
            contractText: 'Full Retail Price',
            discountedPrice: '0.0',
            originalPrice: '0',
          },
        },
        is5gHomeProfessionalInstall: false,
        is5gHomeSelfInstall: true,
        bundleLinks: {
          deviceLinks: [
            {
              deviceSku: {
                isInstorePickup: true,
                inventoryDetails: {
                  dFillInventory: {
                    isBackorder: true,
                    shippingDate: {
                      date: '12/12/2023',
                      dateTime: '12-12-2023 08:00:00 AM',
                      dateLong: 1702368000000,
                    },
                  },
                },
              },
            },
          ],
        },
      },
    ],
    isActive: true,
    isShowcase: true,
    productDisplayName: '5G Home Self setup',
    productId: '16900001',
    seo: '{metaRobotsFollow: "1", metaRobotsIndex: "1001", se…}',
    deviceUnlockPolicy: '{applicationFlag: true, currentVersion: 1, descript…}',
    compatibleSimSorIds: ['BULK2FF-LRA-CT-A', 'BULK4FF-LRA-CC-A'],
    blockCTA: false,
  },
};
export const handlers2 = () => [
  rest.post(`*/flexV2/customerProfile`, (req, res, ctx) =>
    res(ctx.status(200), ctx.json(fwaSimplificationEnabledMock)),
  ),
  rest.post(`*/flexV2/getDetails`, (req, res, ctx) => res(ctx.status(200), ctx.json(newGetDetailsMock))),
  rest.post(`*/flexV2/getSkuDetails`, (req, res, ctx) => res(ctx.status(200), ctx.json(newGetSkuDetails))),
  rest.post(`*/flexV2/retrieve-cart`, (req, res, ctx) => res(ctx.status(200), ctx.json(retrieveCart))),
  rest.post(`*/flexV2/productList`, (req, res, ctx) => res(ctx.status(200), ctx.json(productList))),
  rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
    console.log('inside /flexV2/validate-deviceSimId');
    return res(ctx.status(200), ctx.json(ValidateDeviceSimIdData));
  }),
];

export const handlers3 = () => [
  rest.post(`*/flexV2/customerProfile`, (req, res, ctx) =>
    res(ctx.status(200), ctx.json(fwaSimplificationEnabledMock)),
  ),
  rest.post(`*/flexV2/getDetails`, (req, res, ctx) => res(ctx.status(200), ctx.json(newGetDetailsMock))),
  rest.post(`*/flexV2/getSkuDetails`, (req, res, ctx) => res(ctx.status(200), ctx.json(emptyGetSkuDetails))),
  rest.post(`*/flexV2/retrieve-cart`, (req, res, ctx) => res(ctx.status(200), ctx.json(retrieveCart))),
  rest.post(`*/flexV2/productList`, (req, res, ctx) => res(ctx.status(200), ctx.json(productList))),
  rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
    console.log('inside /flexV2/validate-deviceSimId');
    return res(ctx.status(200), ctx.json(newValidateDeviceSimIdDataSku));
  }),
];
export const handlers4 = () => [
  rest.post(`*/flexV2/customerProfile`, (req, res, ctx) =>
    res(ctx.status(200), ctx.json(fwaSimplificationEnabledMock)),
  ),
  rest.post(`*/flexV2/getDetails`, (req, res, ctx) => res(ctx.status(200), ctx.json(newGetDetailsMock))),
  rest.post(`*/flexV2/retrieve-cart`, (req, res, ctx) => res(ctx.status(200), ctx.json(retrieveCart))),
  rest.post(`*/flexV2/productList`, (req, res, ctx) => res(ctx.status(200), ctx.json(productList))),
  rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
    console.log('inside /flexV2/validate-deviceSimId');
    return res(ctx.status(200), ctx.json(newValidateDeviceSimIdData));
  }),
];
export const handlers5 = () => [
  rest.post(`*/flexV2/customerProfile`, (req, res, ctx) => res(ctx.status(200), ctx.json(customerProfileCband))),
  rest.post(`*/flexV2/getDetails`, (req, res, ctx) => res(ctx.status(200), ctx.json(newGetDetailsMock))),
  rest.post(`*/flexV2/retrieve-cart`, (req, res, ctx) => res(ctx.status(200), ctx.json(retrieveCart))),
  rest.post(`*/flexV2/productList`, (req, res, ctx) => res(ctx.status(200), ctx.json(productList))),
  rest.post(`*/flexV2/validate-deviceSimId`, (req, res, ctx) => {
    console.log('inside /flexV2/validate-deviceSimId');
    return res(ctx.status(200), ctx.json(newValidateDeviceSimIdData));
  }),
];
