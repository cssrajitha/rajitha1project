/* eslint-disable no-param-reassign */
/* eslint-disable no-nested-ternary */
/* eslint-disable no-unsafe-optional-chaining */
/* eslint-disable no-shadow */
import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  useLazyGetDeviceDetailsQuery,
  useLazyGetSkuDetailsQuery,
  useLazyGetProductListQuery,
} from 'onevzsoemfecommon/BrowseAPIService';
import Emitter from 'onevzsoemfeframework/Emitter';
import { isIndirect } from 'onevzsoemfeframework/DomService';
import {
  useGetCustomerProfileQuery,
  useGetCartDetailsQuery,
  useLazyRemoveLinesQuery,
  useLazyValidateDeviceSimIdQuery,
  useAddDeviceMutation,
} from 'onevzsoemfecommon/APIService';
import { getAssistedCradleProperty, getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { getQueryParamByName, getUIContextPathBAU, acssMfeBasePath } from 'onevzsoemfecommon/Helpers';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { useDispatch } from 'react-redux';
import { isEmpty } from 'lodash';
import {
  requestBodyCustomerProfile,
  requestBodyRetriveCart,
  initialRequestBodyDeviceDetails,
} from '../../modules/services/APIService/APIRequestBody';
import { useLazyGetSimSkuQuery } from '../../modules/services/APIService/APIServiceHooks';
import { Context } from './PDP5gContext';
import PDP5GDevice from '../../components/FlexPDP/PDP5G';
import generateAddDevicePayload from './generateAddDevicePayload';
import getProductDetailsJSON from './mocks/getProductDetails.json';
import { getQualificationDetails, indirectDetailsAndSkuDetailsPayload, isHomeSalesCbandBundleFlow } from './pdp5gutils';

const PDP5G = () => {
  const dispatch = useDispatch();
  const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable;
  const [
    installmentLoanStatusCheckCradle,
    pendingLoanCheckByMTNCradle,
    installmentLoanStatusCheckFFlag,
    pendingLoanCheckByMTNFFlag,
    cradleToFFlagControllerFFlag,
  ] = getAssistedCradleProperty([
    'installmentLoanStatusCheck',
    'pendingLoanCheckByMTN',
    'installmentLoanStatusCheckFFlag',
    'pendingLoanCheckByMTNFFlag',
    'cradleToFFlagControllerFFlag',
  ]);
  const installmentLoanStatusCheck = /true/i.test(cradleToFFlagControllerFFlag)
    ? installmentLoanStatusCheckFFlag
    : installmentLoanStatusCheckCradle;
  const pendingLoanCheckByMTN = /true/i.test(cradleToFFlagControllerFFlag)
    ? pendingLoanCheckByMTNFFlag
    : pendingLoanCheckByMTNCradle;
  const trade3POChoiceOfferFFlag = /true/i.test(getAssistedCradleProperty(['trade3POChoiceOfferFFlag'])?.[0]);
  const [getProducts, ProductListResult] = useLazyGetProductListQuery();
  const [getSimSku, SimSkuResult] = useLazyGetSimSkuQuery();
  const [devicedata, setdevicedata] = useState({});
  const [devicePayload, setDevicePayload] = useState({});
  const [validateDeviceSimRequest, setValidateDeviceSimRequest] = useState({});
  const [details, setDetails] = useState(null);
  const [isShipItToggleOn, setIsShipItToggleOn] = useState(true);
  const [tangleWoodQualified, setTangleWoodQualified] = useState(false);
  const [customerType, setCustomerType] = useState(null);
  const [LTEorCBandQualified, setLTEorCBandQualified] = useState(false);
  const [cBandQualication, setCBandQualication] = useState(false);
  const [bundleProduct, setBundleProduct] = useState({});
  const [getDetailsResponse, setGetDetailsResponse] = useState(null);
  const [skuDetails, setSkuDetails] = useState(null);
  const [validateDeviceSimIdRequestBody, ValidateDeviceSimIdResult] = useLazyValidateDeviceSimIdQuery();
  const [customerProfile, setCustomerProfile] = useState(null);
  const [InStockLabel, setInStockLabel] = useState('');
  const [disableShipIttoogle, setDisableShipIttoogle] = useState(false);
  const [ispuToggleOn, setIspuToggleOn] = useState(false);
  const [cartDetails, setCartDetails] = useState(null);
  const isBundledGW = Boolean(getQueryParamByName('isBundledGW')) || false;
  const [is5GDevice, setIs5GDevice] = useState(true);
  const [selectedSku, setSelectedSku] = useState({});
  const [isNewLine, setIsNewLine] = useState(false);
  const [is5gLine, setIs5gLine] = useState(false);
  const [cbandBundleFlow, setCbandBundleFlow] = useState(false);
  // const [getQualificationDetails, setGetQualificationDetails] = useState({});
  const [isIspuItemInCart, setIsIspuItemInCart] = useState(false);
  const [selectedStore, setSelectedStore] = useState('');

  const [getDetailsRequestBody, GetDetailsResult] = useLazyGetDeviceDetailsQuery();
  const [getSkuDetailsRequestBody, SkuDetailsResult] = useLazyGetSkuDetailsQuery();
  const [addDevices, AddDevicesResult] = useAddDeviceMutation();
  const [removeLinesAPI, RemoveLinesAPIResult] = useLazyRemoveLinesQuery();
  // const [validateDeviceSimIdRequestBody, ValidateDeviceSimIdResult] = useLazyValidateDeviceSimIdQuery();
  const defaultSKUPresent = !!getQueryParamByName('defaultSku');
  const deviceSkuPresent = !!getQueryParamByName('deviceSKU');
  const isfiveGScan = /true/i.test(getQueryParamByName('isFiveGScan'));
  const isByodUpdate = /true/i.test(getQueryParamByName('isByodUpdate'));
  const isfiveGGemini = /true/i.test(getQueryParamByName('is5GGemini'));
  const isESim = Boolean(getQueryParamByName('eSim')); // AAL BYOD
  const scanFromLanding = Boolean(getQueryParamByName('scanFromLanding'));
  const isEditAndView = Boolean(getQueryParamByName('isEditAndView'));
  // const isScanDsDs = Boolean(getQueryParamByName('isScanDsDs'));
  // const intentType = getQueryParamByName('intentType');
  const activeMtn = getQueryParamByName('activeMtn');
  const productIdVal = getQueryParamByName('productId') || sessionStorage.getItem('productId');
  const [productId, setProductId] = useState(productIdVal);
  const defaultSku = getQueryParamByName('defaultSku') || getQueryParamByName('deviceSKU');
  const deviceSKU = getQueryParamByName('deviceSKU');
  const deviceFromCart = Boolean(getQueryParamByName('deviceFromCart'));
  // const isScanDsDs = Boolean(getQueryParamByName('isScanDsDs'));
  // const intentType = getQueryParamByName('intentType');
  const iSscan = getQueryParamByName('iSscan');
  // const activeMtn = getQueryParamByName('activeMtn');
  const deviceIdFromParam = getQueryParamByName('deviceId');
  const isRfexFlow = sessionStorage.getItem('refundexchange') === 'true' || false;
  const isWifiBackUp = sessionStorage.getItem('fiveGHomeInternetSelectedFlow') === 'WiFi-Backup';
  const isVhiLite =
    sessionStorage.getItem('vhiLiteQualified')?.toLowerCase() === 'true' ||
    sessionStorage.getItem('fiveGHomeInternetSelectedFlow') === 'VHILite';
  const skuSearch = Boolean(getQueryParamByName('skuSearch'));
  const isBYODAAL = false;
  const isBYODUpg = Boolean(getQueryParamByName('isByodUpdate'));
  let navigate = '';
  function useNavigateMFE() {
    navigate = useNavigate();
  }
  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }
  const funcParams = { isIndirect: isIndirect(), installmentLoanStatusCheck, pendingLoanCheckByMTN };
  const CustomerProfileResult = useGetCustomerProfileQuery(
    { body: requestBodyCustomerProfile },
    { refetchOnMountOrArgChange: true }
  );
  const CartDetailsResult = useGetCartDetailsQuery(
    { body: requestBodyRetriveCart },
    { refetchOnMountOrArgChange: true },
    { skip: !CustomerProfileResult.isSuccess }
  );

  useEffect(() => {
    if ((devicedata.skuId || devicedata?.deviceId) && is5GDevice) {
      getDetails(productId, isBundledGW, devicedata?.skuId);
    }
  }, [devicedata]);

  useEffect(() => {
    if (CartDetailsResult?.status === 'fulfilled') {
      setCartDetails(CartDetailsResult?.data?.data);
      setCustomerType(CartDetailsResult.data?.data?.cart?.orderDetails?.customerType);
    }
  }, [CartDetailsResult]);

  useEffect(() => {
    if (CustomerProfileResult.status === 'fulfilled') {
      setCustomerProfile(CustomerProfileResult.data.data);
    }
  }, [CustomerProfileResult]);

  useEffect(() => {
    if (ProductListResult?.status === 'fulfilled') {
      const { gridWall = {} } = ProductListResult?.data?.data || {};
      const { productList = [] } = gridWall;
      const filteredProduct =
        productList && productList.length > 0
          ? productList.filter((product) => product.productDisplayName === '5G Home Self Install')
          : [];
      const selfInstallId = filteredProduct && filteredProduct.length > 0 ? filteredProduct[0].productId : '';
      if (selfInstallId && selfInstallId !== '') {
        getDetails(selfInstallId, isBundledGW);
      }
    }
  }, [ProductListResult]);

  useEffect(() => {
    if (CartDetailsResult?.isSuccess) {
      initPDP5G();
    }
  }, [CartDetailsResult]);

  // cartDetails.cartHeader.visionCustomerType
  const initPDP5G = () => {
    const lineInfo = CartDetailsResult?.data?.data?.cart?.lineDetails?.lineInfo;
    const lineDetails = lineInfo?.filter((item) => item.mobileNumber === activeMtn);
    const is5GDeviceVal = !!(
      lineDetails &&
      lineDetails.length > 0 &&
      lineDetails[0] &&
      lineDetails[0].deviceTypeSelected === '5G Internet'
    );
    setIs5GDevice(is5GDeviceVal);

    const { cBandQualified = false, LTEQualified = false } =
      CustomerProfileResult?.data?.data?.customer?.qualificationDetails?.addressRequest || {};
    const qualificationType = sessionStorage.getItem('Qualification_type');
    const homesalesQualification_type = sessionStorage.getItem('homesalesQualification_type');
    const hs_qualificationType =
      typeof homesalesQualification_type === 'object' &&
      JSON.parse(sessionStorage.getItem('homesalesQualification_type'));
    const isFWASimplificationEnabled = CustomerProfileResult?.data?.data?.customer?.isFWASimplificationEnabled;
    const isFWASimplificationEnabledEC = CustomerProfileResult?.data?.data?.customer?.isFWASimplificationEnabled;
    const homeSalesAddress = CustomerProfileResult?.data?.data?.customer?.homeSalesAddress || {};
    const LandingCBAND = homeSalesAddress?.priorQualification?.cbandQualified;
    const Landingltequalified = homeSalesAddress?.priorQualification?.LTEQualified;
    if (isFWASimplificationEnabled || isFWASimplificationEnabledEC) {
      const cBandQual = homeSalesAddress?.cbandQualified || cBandQualified;
      const lteQual = homeSalesAddress?.ltequalified || LTEQualified;
      const LTEorCBandQualifiedVal = is5GDevice && (cBandQual || lteQual);
      setLTEorCBandQualified(LTEorCBandQualifiedVal);
    } else {
      const LTEorCBandQualifiedVal =
        is5GDevice &&
        (cBandQualified ||
          LTEQualified ||
          LandingCBAND ||
          Landingltequalified ||
          qualificationType === 'CBD' ||
          qualificationType === 'LTE' ||
          hs_qualificationType?.cbandQualified ||
          hs_qualificationType?.ltequalified);
      setLTEorCBandQualified(LTEorCBandQualifiedVal);
    }
    if (isfiveGScan && isfiveGScan === true) {
      get5GProducts();
    }
    //  else if (deviceFromCart && is5GDevice && this.props.fiveGProducts) {
    //   this.getDetails(this.props.fiveGProducts, locationCode, isBundledGW);
    // }
    else if (deviceFromCart && productId) {
      getDetails(productId, isBundledGW);
    } else if (deviceSKU) {
      getSkuDetails(deviceIdFromParam, deviceSKU, isBYODUpg || isBYODAAL);
    } else if (!isESim) {
      getDetails(productId, isBundledGW);
    }
  };
  const get5GProducts = () => {
    const data = {
      data: {
        productType: 'bundle',
        processingMTN: activeMtn,
        customerLoggedInOrNot: false,
        compatibleProductId: '',
        filterSortData: {
          sortOption: '',
          paymentOption: '',
          filters: [
            {
              type: 'Category',
              values: ['5g-Internet'],
            },
            {
              type: 'Brand',
              values: [''],
            },
            {
              type: 'OS',
              values: [''],
            },
          ],
        },
        paginationData: {
          offset: 0,
          recPerPage: 24,
        },
      },
    };
    getProducts({ body: data, spinner: true }, false);
  };

  const getDetails = (productId, isBundledGW, sku = '') => {
    const skuValueToBeSentInRequest =
      defaultSKUPresent === true ? defaultSku : deviceSkuPresent === true ? deviceSKU : '';
    const lines = CartDetailsResult?.data?.data?.cart?.lineDetails?.lineInfo;
    const currentLine = lines && lines.length > 0 && lines.find((item) => item?.mobileNumber === activeMtn);
    const is5gLineType = currentLine && currentLine?.deviceTypeSelected === '5G Internet';
    const {
      cBandQualified = false,
      LTEQualified = false,
      fiveGHomeQualified = false,
    } = CustomerProfileResult?.data?.data?.customer?.qualificationDetails?.addressRequest || {};
    const fivegCheckVal = is5gLineType && (cBandQualified || LTEQualified);
    console.log(fivegCheckVal);
    // const { fiveGHomebundle = [], CBandSku = "", LTEHomeSku = "", cbandBundle = [], tanglewoodBundle=[]} = eligibilities;
    const { cbandBundle = [] } =
      CustomerProfileResult?.data?.data?.customer?.qualificationDetails?.addressRequest?.eligibilities || {};
    setCbandBundleFlow(cbandBundle.length > 0 && cBandQualified);
    // setFivegCheck(fivegCheckVal)
    setIs5gLine(is5gLineType);
    /* istanbul ignore else */
    if (!(cbandBundle.length > 0 && cBandQualified)) {
      if (sku === 'WNC-CR200A') {
        productId = 'dev19360183';
      }
      if (sku === 'ASK-NCQ1338FA') {
        productId = 'dev18800001';
      }
      if (sku === 'ARC-XCI55AX') {
        productId = 'dev18800002';
      }
    }
    const requestBodyDeviceDetails = {
      ...initialRequestBodyDeviceDetails,
      data: {
        ...initialRequestBodyDeviceDetails.data,
        productId: !productId || productId === '' ? sessionStorage.getItem('productId') : productId,
        ...(defaultSKUPresent === true || deviceSkuPresent === true
          ? { defaultSku: skuValueToBeSentInRequest || '' }
          : {}),
        skuSearch,
        processingMTN: activeMtn,
        enableBPM: !(customerType === 'N' || isRfexFlow),
        ...indirectDetailsAndSkuDetailsPayload(funcParams),
        ...((cBandQualified && !isBundledGW) || /true/i.test(fiveGHomeQualified)
          ? { networkBandWidthType: cBandQualified === true ? 'CBD' : 'MMW' }
          : {}),
      },
    };
    setProductId(requestBodyDeviceDetails?.data?.productId);
    // if (customerType !== "N" && isPrepayCart && deviceSkuPresent) {
    //   requestBodyDeviceDetails.data.prepayCart = true
    // }
    // if (!is5gLineType && fivegTitanSkusFormatted && fivegTitanSkusFormatted.includes(defaultSku)) {
    //   const errorMessage = "Adding Titan device for this flow is not allowed";
    //   dispatch(
    //     appMessageActions.addAppMessage(
    //       errorMessage,
    //       'error',
    //       true,
    //       60000,
    //     ),)
    //   // this.setState({ errorMessage }, () => this.props.addAppMessage(this.state.errorMessage, "error"));
    //   // this.props.hideAppLoader(); // check
    // }
    // else {
    getDetailsRequestBody({ body: requestBodyDeviceDetails });
    // }
  };

  const getSkuDetails = (deviceId, deviceSKUfromParam, isCPE = false) => {
    const deviceIdParams = deviceId;
    const deviceSkuId =
      ValidateDeviceSimIdResult?.data?.data?.serviceResponse?.context?.deviceSku || deviceSKUfromParam;

    const requestBodyDeviceDetails = {
      data: {
        sorId: deviceSkuId,
        deviceId: deviceIdParams,
        productType: 'device',
        processingMTN: activeMtn,
        isCPE,
        enableAssistedTagging: true,
        ...indirectDetailsAndSkuDetailsPayload(funcParams),
      },
    };
    /* istanbul ignore else */
    if (iSscan) {
      requestBodyDeviceDetails.data.isScan = 'True';
    }
    getSkuDetailsRequestBody({ body: requestBodyDeviceDetails });
  };

  useEffect(() => {
    /* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */
    if (GetDetailsResult.status === 'fulfilled') {
      const cbandBundleFlowSession = sessionStorage.getItem('cbandBundleFlowSession');
      const isFWASimplificationEnabled = CustomerProfileResult?.data?.data?.customer?.isFWASimplificationEnabled;
      const homeSalesCbandBundleFlow = isHomeSalesCbandBundleFlow(CustomerProfileResult?.data?.data);
      const isFWASimplificationEnabledEC = CustomerProfileResult?.data?.data?.customer?.isFWASimplificationEnabled; // this.props.isFWASimplificationEnabledEC; // check
      const fiveGHomebundle =
        CustomerProfileResult?.data?.data?.customer?.qualificationDetails?.addressRequest?.eligibilities; // this.props?.getQualificationDetails?.fiveGHomebundle; // check inside eligibilities
      const FWAcheckAltAddress = false; // this.props?.isFWAcheckAltAddress; // check getting from addlines
      /* istanbul ignore next */
      if (GetDetailsResult?.data?.data) {
        setGetDetailsResponse(GetDetailsResult?.data?.data);
        const lineInfo = CartDetailsResult?.data?.data?.cart?.lineDetails?.lineInfo?.filter(
          (item) => item.mobileNumber === activeMtn
        );
        const activeMtnEqpInfo =
          lineInfo && lineInfo.length > 0 && lineInfo[0] && lineInfo[0].equipmentInfos && lineInfo[0].equipmentInfos[0]
            ? lineInfo[0].equipmentInfos[0]
            : {};
        const isNewLineCreated = !!(
          lineInfo &&
          lineInfo.length > 0 &&
          lineInfo[0] &&
          (lineInfo[0].lineActivityType?.includes('AAL') || lineInfo[0].lineActivityType?.includes('NSE'))
        );
        setIsNewLine(isNewLineCreated);
        const { deviceInfo = {} } = activeMtnEqpInfo;
        const { deviceType = '' } = deviceInfo;
        const home4GLte = deviceType?.home4GLte || false;
        if (isBundledGW || is5GDevice) {
          const LandingCBAND =
            CustomerProfileResult?.data?.data?.customer?.homeSalesAddress?.priorQualification?.cbandQualified;
          const Landingltequalified =
            CustomerProfileResult?.data?.data?.customer?.homeSalesAddress?.priorQualification?.LTEQualified;
          const isCbandBundleISPU = getQueryParamByName('isCbandBundleISPU');
          const qualificationType = sessionStorage.getItem('Qualification_type');
          const hs_qualificationType = JSON.parse(sessionStorage.getItem('homesalesQualification_type'));
          // eslint-disable-next-line no-unsafe-optional-chaining
          const {
            cBandQualified = false,
            LTEQualified = false,
            fiveGHomeQualified = false,
            tanglewoodQualified = false,
          } = getQualificationDetails(CustomerProfileResult?.data?.data, lineInfo?.[0]);
          setTangleWoodQualified(tanglewoodQualified);
          const cBandQualicationVal = !!(
            cBandQualified ||
            qualificationType === 'CBD' ||
            hs_qualificationType?.cbandQualified
          );
          // eslint-disable-next-line max-len
          if (isfiveGGemini && isfiveGGemini === true) {
            const { deviceProduct } = GetDetailsResult?.data?.data;
            /* istanbul ignore next */
            if (
              scanFromLanding &&
              ((!fiveGHomeQualified && ((cBandQualified && (cbandBundleFlow || isCbandBundleISPU)) || LTEQualified)) ||
                (!fiveGHomeQualified && (LandingCBAND || Landingltequalified)) ||
                qualificationType === 'LTE' ||
                (qualificationType === 'CBD' && (!/true/i.test(cbandBundleFlowSession) || isCbandBundleISPU)) ||
                hs_qualificationType?.ltequalified ||
                hs_qualificationType?.cbandQualified)
            ) {
              setDetails(GetDetailsResult?.data?.data?.deviceProduct);
              setCBandQualication(cBandQualicationVal);
            } else if (deviceProduct === undefined && GetDetailsResult?.data?.data?.bundleProduct) {
              const { bundleProduct = {} } = GetDetailsResult.data.data;
              // this.setState({ bundleProduct: bundleProduct, isBundledGW });
              setBundleProduct(bundleProduct);
            } else {
              // this.setState({ bundleProduct: deviceProduct, isBundledGW });
              setBundleProduct(deviceProduct);
            }
          } else if (
            isFWASimplificationEnabled &&
            GetDetailsResult?.data?.data?.bundleProduct &&
            (cbandBundleFlow ||
              cBandQualified ||
              /true/i.test(cbandBundleFlowSession) ||
              (fiveGHomeQualified && fiveGHomebundle))
          ) {
            // eslint-disable-next-line no-shadow
            const { bundleProduct = {} } = GetDetailsResult.data.data || {};
            setBundleProduct(bundleProduct);
          } else if (
            GetDetailsResult?.data?.data?.deviceProduct &&
            !tanglewoodQualified &&
            (qualificationType === 'LTE' ||
              isCbandBundleISPU ||
              hs_qualificationType?.ltequalified ||
              (!fiveGHomeQualified && ((cBandQualified && !cbandBundleFlow) || isCbandBundleISPU || LTEQualified)) ||
              (!fiveGHomeQualified && (LandingCBAND || Landingltequalified) && !homeSalesCbandBundleFlow) ||
              (qualificationType === 'CBD' && !/true/i.test(cbandBundleFlowSession)) ||
              (hs_qualificationType?.cbandQualified && !homeSalesCbandBundleFlow))
          ) {
            //! fiveGHomeQualified && cBandQualified) {
            setDetails(GetDetailsResult?.data?.data?.deviceProduct);
            setCBandQualication(cBandQualicationVal);
          } else if (isEditAndView && isEditAndView === true && is5gLine && fiveGHomeQualified) {
            if (GetDetailsResult?.data?.data?.bundleProduct) {
              const { bundleProduct } = GetDetailsResult.data.data;
              setBundleProduct(bundleProduct);
            } else {
              const { deviceProduct } = GetDetailsResult?.data?.data;
              setBundleProduct(deviceProduct);
            }
          } else if (
            isFWASimplificationEnabledEC === true &&
            !FWAcheckAltAddress &&
            GetDetailsResult?.data?.data?.deviceProduct &&
            !GetDetailsResult?.data?.data?.bundleProduct
          ) {
            const { deviceProduct } = GetDetailsResult?.data?.data;
            setDetails(deviceProduct);
          } else if (
            isFWASimplificationEnabledEC === true &&
            FWAcheckAltAddress &&
            GetDetailsResult?.data?.data?.bundleProduct
          ) {
            const { bundleProduct = {} } = GetDetailsResult?.data?.data;
            setBundleProduct(bundleProduct);
          } else {
            const { bundleProduct } = GetDetailsResult?.data?.data;
            setBundleProduct(bundleProduct);
          }
        } else {
          // eslint-disable-next-line no-shadow
          const details =
            sessionStorage.getItem('isProd') === 'false' && productId === 'dev11000011'
              ? getProductDetailsJSON.data.deviceProduct
              : GetDetailsResult.data.data.deviceProduct;
          const sorDeviceCategory = details && details.sorDeviceCategory;
          const sorDeviceType = details && details.sorDeviceType;
          if (!isNewLineCreated && LTEorCBandQualified && !home4GLte) {
            const errorMessage = 'Device is restricted to be sold in this flow.';
            dispatch(appMessageActions.addAppMessage(errorMessage, 'error', true, 60000));
            return true;
          }
          if (!isNewLineCreated && !LTEorCBandQualified && home4GLte) {
            const errorMessage = 'Device is restricted to be sold in this flow.';
            dispatch(appMessageActions.addAppMessage(errorMessage, 'error', true, 60000));
            return true;
          }
          if (sorDeviceCategory === '5G Internet' && sorDeviceType === '5GF' && !is5GDevice) {
            const errorMessage = 'Device is not allowed to be sold in this flow';
            dispatch(appMessageActions.addAppMessage(errorMessage, 'error', true, 60000));
            return true;
          }
        }
      }
    }
  }, [GetDetailsResult]);

  useEffect(() => {
    if (SkuDetailsResult.isSuccess && SkuDetailsResult?.data?.data?.deviceSku) {
      const isLocal = getQueryParamByName('isLocal');
      const { deviceSku } = SkuDetailsResult.data.data;
      let deviceProduct = deviceSku?.parentProducts?.[0] || {};
      const localInventory = deviceSku?.inventoryDetails?.localInventory;
      // Check local inventory availability
      const isLocalInventoryAvailable = localInventory?.qtyAvailable > 0 && localInventory?.isInStock;
      if (!isIndirect() && scanFromLanding && isLocal && !isLocalInventoryAvailable) {
        const errorMessage =
          'There is no inventory for the device, please fix the inventory and try again or continue with Shop devices for Ship it.';
        dispatch(appMessageActions.addAppMessage(errorMessage, 'error', true, 60000));
        return;
      }
      // Handle 5G Gemini logic
      /* istanbul ignore else */
      if (isfiveGGemini && deviceProduct?.productId) {
        getDetails(deviceProduct.productId, isBundledGW);
      } else if (!isEmpty(deviceProduct)) {
        deviceProduct = { ...deviceProduct };
        deviceProduct.childSkus = [deviceSku];
        setDetails(deviceProduct);
      }
    }
  }, [SkuDetailsResult]);

  useEffect(() => {
    if (AddDevicesResult?.status === 'fulfilled') {
      if (!scmUpgradeMfeEnable) {
        navigate(`${getUIContextPathBAU()}/combinedgridwall.html?fromPDP=true&activeMtn=${activeMtn}&backfrompdp=true`);
      } else {
        const activenewLineMTN = getQueryParamByName('activeMtn');
        sessionStorage.setItem('activeMTN', activenewLineMTN);
        Emitter.emit('ADD_SELECTED_DEVICE_TO_CART', { newLine: true, navToPlanTab: false });
        Emitter.emit('ACSS_SCM_DEVICE_SUBTAB', { subTab: 'CombinedGridwall', activeMtn });

      }
    }
  }, [AddDevicesResult]);

  const addDeviceToCartHandler = () => {
    const addDevicePayload = generateAddDevicePayload(getAddDevicePayloadData());
    addDevices({ body: addDevicePayload });
  };

  useEffect(() => {
    if (RemoveLinesAPIResult?.data && RemoveLinesAPIResult?.status === 'fulfilled') {
      if (scmUpgradeMfeEnable) {
        Emitter.emit('ADD_SELECTED_DEVICE_TO_CART', {});
        Emitter.emit('ACSS_SCM_CLEAR_LEFT_RAIL', true);
        window?.mfe?.historyRef?.push(
          `${acssMfeBasePath}/product-detail.html?deviceSKU=undefined&isByodUpdate=true&deviceId=undefined&simId=undefined&isEditAndView=true&activeMtn=newLine1&defaultTab=GR`
        );
      } else {
        navigate(`${getUIContextPathBAU()}/landing.html`);
      }
    }
  }, [RemoveLinesAPIResult, RemoveLinesAPIResult?.status]);

  const removeLinesHandler = () => {
    const request = {
      cartInfo: {
        processingMTN: activeMtn,
        processAction: isNewLine ? 'removeDevice' : '',
      },
      data: {
        lines: [
          {
            mtn: activeMtn,
          },
        ],
        enableAssistedTagging: true,
      },
    };
    if (isWifiBackUp || isVhiLite) {
      request.cartInfo.transactionType = 'WIFIBACKUP';
      request.data.lines[0].transactionType = 'WIFIBACKUP';
    }
    removeLinesAPI({ body: request });
  };

  const getAddDevicePayloadData = () => ({
    activeMtn,
    isfiveGScan,
    isfiveGGemini,
    is5GDevice,
    cartDetails,
    customerProfile,
    bundleProduct,
    LTEorCBandQualified,
    selectedSku,
    isNewLine,
    cbandBundleFlow,
    customerType,
    selectedStore,
    ispuToggleOn,
    isIspuItemInCart,
    isShipItToggleOn,
    devicedata,
    trade3POChoiceOfferFFlag,
  });

  const allContextValues = () => ({
    getDetailsResponse,
    skuDetails,
    customerProfile,
    cartDetails,
    activeMtn,
    details,
    setDetails,
    addDeviceToCartHandler,
    removeLinesHandler,
    selectedSku,
    setSelectedSku,
    bundleProduct,
    LTEorCBandQualified,
    isNewLine,
    isShipItToggleOn,
    setIsShipItToggleOn,
    isfiveGGemini,
    isfiveGScan,
    cbandBundleFlow,
    deviceFromCart,
    setInStockLabel,
    InStockLabel,
    setIspuToggleOn,
    ispuToggleOn,
    isEditAndView,
    disableShipIttoogle,
    setDisableShipIttoogle,
    setSkuDetails,
    cBandQualication,
    selectedStore,
    setSelectedStore,
    isIspuItemInCart,
    setIsIspuItemInCart,
    tangleWoodQualified,
    validateDeviceSimIdRequestBody,
    ValidateDeviceSimIdResult,
    is5GDevice,
    customerType,
    setdevicedata,
    devicedata,
    getSimSku,
    SimSkuResult,
    devicePayload,
    setDevicePayload,
    validateDeviceSimRequest,
    setValidateDeviceSimRequest,
    isByodUpdate,
    isIndirect: isIndirect(),
  });

  const contextData = useMemo(
    () => allContextValues(),
    [
      getDetailsResponse,
      skuDetails,
      customerProfile,
      cartDetails,
      activeMtn,
      details,
      selectedSku,
      bundleProduct,
      isShipItToggleOn,
      InStockLabel,
      ispuToggleOn,
      selectedStore,
      isIspuItemInCart,
      ValidateDeviceSimIdResult,
      devicedata,
      SimSkuResult,
    ]
  );

  return (
    <Context.Provider value={contextData}>
      {(((isBundledGW || is5GDevice) && bundleProduct) || details) && <PDP5GDevice />}
    </Context.Provider>
  );
};

export default PDP5G;
