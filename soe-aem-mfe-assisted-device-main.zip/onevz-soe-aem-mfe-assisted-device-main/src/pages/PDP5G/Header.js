import styled from 'styled-components';
import { Title } from '@vds/typography';
import { Icon } from '@vds/icons';
import { Line } from '@vds/lines';
import PropTypes from 'prop-types';
import { isNumeric, capitalizeFirstLetter, formatMtnForNewLine, getUIContextPathBAU, acssMfeBasePath } from 'onevzsoemfecommon/Helpers';
import { useNavigate } from 'react-router-dom';
import { getQueryParamByName } from 'onevzsoemfeframework/DomService';
import { BackClickable, FlexBox } from '../../components/CombinedGridwall/FlexGlobalStyledConstants';
// import MoreOptions from './MoreOptions';
import { LIGHT_THEME_COLOR } from '../../constants/constants';
const FlexBoxGrowOne = styled.div`
  display: flex;
  flex-grow: 1;
`;
const ShopWrapper = styled.div`
  padding: 1.5rem 0.5rem;
`;
const LineWrapper = styled.div`
  padding: 0 2rem;
`;
const FlexAlignContainerItemsCenter = styled.div`
  display: flex;
  align-items: center;
  padding: 0 2rem;
  justify-content: space-between;
`;
const LineSeperator = styled.div`
  width: 1px;
  height: 27px;
  background: ${LIGHT_THEME_COLOR};
  top: 1.5rem;
  position: relative;
`;
const MinimizeDisplayName = styled.div`
  width: 500px;
  white-space: nowrap;
  overflow: hidden;
  float: left;
  text-overflow: ellipsis;
`;

let navigate = '';

function useNavigateMFE() {
  navigate = useNavigate();
}
function Header5G(props) {
  // const scmDeviceEnable = window?.mfe?.scmDeviceMfeEnable || false;
  const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable;
  const scmCombinedGridwallFlow = window?.mfe?.scmCombinedGridwallFlow || false;

  try {
    useNavigateMFE();
  } catch (e) {
    console.log('');
  }

  const { header, line, mdn, closeIcon, closeClickHandler } = props.data;
  // const isDark = (window?.mfe?.scmDeviceMfeEnable && window?.mfe?.isDark) || false;
  const phoneRegex = /^\(?(\d{3})\)?[-. ]?(\d{3})[-. ]?(\d{4})$/;
  const MDN = isNumeric(mdn) ? mdn.replace(phoneRegex, '$1-$2-$3') : capitalizeFirstLetter(formatMtnForNewLine(mdn));
  const fromPage = getQueryParamByName('fromPage');
  const isFWA5G = getQueryParamByName('fwa5G');

  const navigatePdp = () => {
    if (closeClickHandler) {
      closeClickHandler();
    } else if (fromPage === 'Landing') {
      navigate(`${getUIContextPathBAU()}/landing.html?activeMtn=${mdn}&backfrompdp=true`);
    }
    else if (scmUpgradeMfeEnable) {

      if (scmCombinedGridwallFlow && window?.mfe?.historyRef && !isFWA5G) {
        window?.mfe?.historyRef?.goBack();
      } else {
        window?.mfe?.historyRef?.push(
          `${acssMfeBasePath}/product-detail.html?deviceSKU=undefined&isByodUpdate=true&deviceId=undefined&simId=undefined&isEditAndView=true&activeMtn=${mdn}&fromPage=CombinedGridwall&defaultTab=GR`
        );
      }

    }
    else {
      navigate(`${getUIContextPathBAU()}/combinedgridwall.html?fromPDP=true&activeMtn=${mdn}&backfrompdp=true`);
    }
    sessionStorage.setItem('isFromBack', true);
    sessionStorage.setItem('isSecondNumLocal', false);
    if (sessionStorage.getItem('isSAExist')) {
      sessionStorage.removeItem('isSAExist');
    }
  };
  return (
    <>
      <FlexAlignContainerItemsCenter>
        <FlexBoxGrowOne>
          <BackClickable
            data-testid='testBackGridwall'
            onClick={navigatePdp}
            tabIndex={0}
            role='button'
            data-track={`ProductDetail_${header}_back`}
          >
            <Icon surface='light' name='left-caret' size='XLarge' medium='true' />
          </BackClickable>
          <ShopWrapper>
            <Title color={LIGHT_THEME_COLOR} size='small' bold primitive='h1'>
              {header?.length > 60 ? <MinimizeDisplayName>{header}</MinimizeDisplayName> : header}
            </Title>
          </ShopWrapper>
          {line && (
            <>
              <LineSeperator />
              <ShopWrapper>
                <Title color={LIGHT_THEME_COLOR} size='small' bold primitive='h1'>
                  {line} {MDN}{' '}
                </Title>
              </ShopWrapper>
            </>
          )}
        </FlexBoxGrowOne>
        <FlexBox>
          <div>
            
            { !(scmUpgradeMfeEnable && isFWA5G ==='true') && closeIcon?.popupModalclose && (
              <span
                onClick={closeClickHandler || (() => navigate(-1))}
                onKeyDown={{}}
                tabIndex={0}
                role='button'
                data-track={`ProductDetail_${header}_close`}
              >
                <Icon surface='light' name='close' size='large'/>
              </span>
            )}
          </div>
        </FlexBox>
      </FlexAlignContainerItemsCenter>
      <LineWrapper>
        <Line type='secondary' />
      </LineWrapper>
    </>
  );
}
Header5G.propTypes = {
  data: PropTypes.shape({
    mdn: PropTypes.string,
    header: PropTypes.string,
    line: PropTypes.string,
    closeIcon: PropTypes.bool,
    FirstName: PropTypes.string,
  }),
};
export default Header5G;
