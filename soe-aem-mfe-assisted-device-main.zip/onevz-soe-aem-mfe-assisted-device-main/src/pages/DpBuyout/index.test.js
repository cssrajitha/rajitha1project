import React from 'react';
import { fireEvent, render, screen } from '../../modules/test-utils/renderHelper';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import DpBuyout from './index';

// Mock the API Service Hook
jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
  useLazyPosInitiateBuyOutQuery: () => [
    jest.fn(), // mock function for posInitiateBuyout
    {
      status: 'uninitialized',
      isUninitialized: true,
      isLoading: false,
      isSuccess: false,
      isError: false,
      data: {
        body: {
          serviceBody: {
            serviceResponse: {
              context: {
                devicePayOffInfo: [
                  {
                    mdn: '1111111111',
                    nickName: 'Test Phone 1',
                    productName: 'iPhone 13',
                    active: 'TRUE',
                    pendingNumberOfInstallments: 5,
                    totalBuyoutAmount: 500.0,
                  },
                  {
                    mdn: '2222222222',
                    nickName: 'Test Phone 2',
                    productName: 'Galaxy S21',
                    active: 'TRUE',
                    pendingNumberOfInstallments: 8,
                    totalBuyoutAmount: 800.0,
                  },
                  {
                    mdn: '3333333333',
                    nickName: 'Inactive Phone',
                    productName: 'Old Phone',
                    active: 'FALSE',
                    pendingNumberOfInstallments: 2,
                    totalBuyoutAmount: 200.0,
                  },
                ],
              },
            },
          },
        },
      },
    },
  ],
}));

// Mock the child components to focus on the main component
jest.mock('../../components/DPBuyout/SelectedDevice/LeftPanel/LeftPanel', () => () => (
  <div data-testid='left-panel'>LeftPanel Mock</div>
));

jest.mock('../../components/DPBuyout/SelectedDevice/Header', () => () => <div data-testid='header'>Header Mock</div>);

jest.mock('../../components/DPBuyout/SelectedDevice/RightPanel/RightPanel', () => () => (
  <div data-testid='right-panel'>RightPanel Mock</div>
));

// Mock RemoteLoader to capture and call the callback
let mockRemoteLoaderCallback = null;
/* eslint-disable react/prop-types */
jest.mock('onevzsoemfeframework/RemoteLoader', () => (props) => {
  // Capture the callback function passed as onCloseDpBuyoutPayment
  mockRemoteLoaderCallback = props.moduleProps?.onCloseDpBuyoutPayment;
  return (
    <div data-testid='remote-loader-mock'>
      <button
        type='button'
        data-testid='close-payment-true'
        onClick={() => mockRemoteLoaderCallback?.(true)}
      >
        Close with True
      </button>
      <button
        type='button'
        data-testid='close-payment-false'
        onClick={() => mockRemoteLoaderCallback?.(false)}
      >
        Close with False
      </button>
      <button
        type='button'
        data-testid='close-payment-default'
        onClick={() => mockRemoteLoaderCallback?.()}
      >
        Close with Default
      </button>
    </div>
  );
});
/* eslint-enable react/prop-types */

describe('DpBuyout', () => {
  test('renders the correct welcome message', () => {
    const props = {
      accountNumber: '123456789',
      selectedMtn: '5139074854',
      closeDpBuyoutModal: jest.fn(),
    };

    render(<DpBuyout {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    const expectedText = screen.getByText(/Select a device/i);

    expect(expectedText).toBeInTheDocument();
  });
  test('renders the correct welcome message', async () => {
    const props = {
      accountNumber: '123456789',
      selectedMtn: '5139074854',
      closeDpBuyoutModal: jest.fn(),
    };

    render(<DpBuyout {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    const buyoutButton = screen.getByRole('button', { name: /Buyout/i });
    await fireEvent.click(buyoutButton);
  });

  describe('closePaymentModal', () => {
    test('should close payment modal with default argument (false)', async () => {
      const props = {
        accountNumber: '123456789',
        selectedMtn: '5139074854',
        closeDpBuyoutModal: jest.fn(),
      };

      render(<DpBuyout {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      // Open the buyout payment modal first
      const buyoutButton = screen.getByRole('button', { name: /Buyout/i });
      fireEvent.click(buyoutButton);

      // Verify RemoteLoader is rendered (payment modal is open)
      expect(screen.getByTestId('remote-loader-mock')).toBeInTheDocument();

      // Click the button to close with default argument
      const closeDefaultButton = screen.getByTestId('close-payment-default');
      fireEvent.click(closeDefaultButton);

      // After closing, SelectedDevice should be rendered again
      expect(screen.getByText(/Select a device/i)).toBeInTheDocument();
    });

    test('should close payment modal and set paymentDone to true when argument is true', async () => {
      const props = {
        accountNumber: '123456789',
        selectedMtn: '5139074854',
        closeDpBuyoutModal: jest.fn(),
      };

      render(<DpBuyout {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      // Open the buyout payment modal first
      const buyoutButton = screen.getByRole('button', { name: /Buyout/i });
      fireEvent.click(buyoutButton);

      // Verify RemoteLoader is rendered
      expect(screen.getByTestId('remote-loader-mock')).toBeInTheDocument();

      // Click the button to close with true argument
      const closeTrueButton = screen.getByTestId('close-payment-true');
      fireEvent.click(closeTrueButton);

      // After closing with true, paymentDone should be set to true
      // and SelectedDevice should receive paymentDone=true prop
      expect(screen.getByText(/Select a device/i)).toBeInTheDocument();
    });

    test('should close payment modal and set paymentDone to false when argument is false', async () => {
      const props = {
        accountNumber: '123456789',
        selectedMtn: '5139074854',
        closeDpBuyoutModal: jest.fn(),
      };

      render(<DpBuyout {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      // Open the buyout payment modal first
      const buyoutButton = screen.getByRole('button', { name: /Buyout/i });
      fireEvent.click(buyoutButton);

      // Verify RemoteLoader is rendered
      expect(screen.getByTestId('remote-loader-mock')).toBeInTheDocument();

      // Click the button to close with false argument
      const closeFalseButton = screen.getByTestId('close-payment-false');
      fireEvent.click(closeFalseButton);

      // After closing with false, paymentDone should be set to false
      // and SelectedDevice should be rendered
      expect(screen.getByText(/Select a device/i)).toBeInTheDocument();
    });

    test('should set paymentDone state correctly and close modal', async () => {
      const props = {
        accountNumber: '123456789',
        selectedMtn: '5139074854',
        closeDpBuyoutModal: jest.fn(),
      };

      render(<DpBuyout {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      // Initial state - SelectedDevice should be rendered
      expect(screen.getByText(/Select a device/i)).toBeInTheDocument();

      // Click buyout button to open payment modal
      const buyoutButton = screen.getByRole('button', { name: /Buyout/i });
      fireEvent.click(buyoutButton);

      // RemoteLoader should be rendered (payment modal is open)
      expect(screen.getByTestId('remote-loader-mock')).toBeInTheDocument();
      
      // SelectedDevice should not be visible when payment modal is open
      expect(screen.queryByTestId('left-panel')).not.toBeInTheDocument();

      // Close the modal with true
      const closeTrueButton = screen.getByTestId('close-payment-true');
      fireEvent.click(closeTrueButton);

      // After closing, SelectedDevice should be rendered again
      expect(screen.getByText(/Select a device/i)).toBeInTheDocument();
      expect(screen.getByTestId('left-panel')).toBeInTheDocument();
    });

    test('should handle closePaymentModal without arguments (default to false)', async () => {
      const props = {
        accountNumber: '123456789',
        selectedMtn: '5139074854',
        closeDpBuyoutModal: jest.fn(),
      };

      render(<DpBuyout {...props} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      // Open payment modal
      const buyoutButton = screen.getByRole('button', { name: /Buyout/i });
      fireEvent.click(buyoutButton);

      // Verify RemoteLoader is rendered
      expect(screen.getByTestId('remote-loader-mock')).toBeInTheDocument();

      // Close without any argument - should default to false
      const closeDefaultButton = screen.getByTestId('close-payment-default');
      fireEvent.click(closeDefaultButton);

      // SelectedDevice should be rendered with paymentDone defaulting to false
      expect(screen.getByText(/Select a device/i)).toBeInTheDocument();
    });
  });
});