import React, { useState } from 'react';
import RemoteLoader from 'onevzsoemfeframework/RemoteLoader';
import styled from 'styled-components';
import { Modal } from '@vds/modals';
import SelectDevice from '../../components/DPBuyout/SelectedDevice/SelectedDevice';
import { useLazyPosInitiateBuyOutQuery } from '../../modules/services/APIService/APIServiceHooks';
import '../../assests/CSS/globalStyle.css';

const ModalContainer = styled.div``;

function DpBuyout(props) {
  const [showBuyoutPayModal, setBuyoutPayModal] = useState(false);
  const [ paymentDone,setPaymentDone] = useState(false)
  const [activeMDN, setActiveMDN] = useState('');
  const [posInitiateBuyout, posInitiateBuyOutResult] = useLazyPosInitiateBuyOutQuery();

  const { accountNumber } = props;

  const closePaymentModal =(arg = false) =>{
    setPaymentDone(arg)
    setBuyoutPayModal( false)
  }
  /* istanbul ignore next */
  const DpBuyoutPaymentRoute = {
    scope: 'onevzsoemfeassistedpayment',
    app: 'onevzsoemfeassistedhost',
    module: './BuyoutPayment',
    moduleProps: {
      pageContext: '',
      activeMtn: activeMDN,
      accountNumber,
      onCloseDpBuyoutPayment: (arg) => closePaymentModal(arg),
    },
  };

  const moduleRenderDecider = () => {
    if (showBuyoutPayModal) {
      return <RemoteLoader {...DpBuyoutPaymentRoute} />;
    }
    return (
      <SelectDevice
        {...props}
        activeMDN={activeMDN}
        setActiveMDN={(arg) => setActiveMDN(arg)}
        setBuyoutPayModal={(arg) => setBuyoutPayModal(arg)}
        posInitiateBuyout={posInitiateBuyout}
        posInitiateBuyOutResult={posInitiateBuyOutResult}
        paymentDone = {paymentDone}
      />
    );
  };

  return (
    <ModalContainer>
      <Modal
        id='BuyoutModal'
        className='buyout-pay-modal'
        opened
        fullScreenDialog
        closeButton={<span />}
        modalHeight='100%'
      >
        {moduleRenderDecider()}
      </Modal>
    </ModalContainer>
  );
}
export default DpBuyout;
