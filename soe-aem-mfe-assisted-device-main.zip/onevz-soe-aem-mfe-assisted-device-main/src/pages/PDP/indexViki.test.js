import React from 'react';
import { render } from '../../modules/test-utils/renderHelper';
import PDP from './index.js';
import PDPApiCallHook from './PDPApiCallHook.js';

jest.mock('./PDPApiCallHook');
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradleProperty: () => [true, true, 'TRUE', '', '', 'TRUE', '', '', '', '', '', '', 'TRUE'],
  }),
  { virtual: true },
);

describe('PDPContainer', () => {
  const props = {
    CustomerProfileResult: { data: { data: {} } },
    CartDetailsResult: { data: { data: {} } },
    ProtectionFeaturesResult: { data: { data: {} } },
    setSimIdResult: {
      data: { data: { serviceBody: { serviceResponse: { context: { deviceInfo: { deviceSku: {} } } } } } },
      status: 'fulfilled',
    },
  };
  beforeEach(() => {
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/pdp.html?isByodUpdate=true&mtn=978f74302da56d445230199a1f578e3743299bc2cca7f7756cbeb0151427915d&iSscan=true&deviceSKU=SMS911UZEV&deviceId=350321532631401&productId=1234&flowType=VIKI_AddToOrder',
    );
    PDPApiCallHook.mockReturnValue({
      __esModule: true,
      ...jest.requireActual('./PDPApiCallHook'),

      CustomerProfileResult: {
        data: {
          data: {
            customer: {
              billAccounts: [
                {
                  billAccountNo: '1',
                  mtns: [
                    {
                      mtn: '7038983931',
                      lineLevelServiceOffers: [],
                      numberShare: null,
                      mtnHashCode: '978f74302da56d445230199a1f578e3743299bc2cca7f7756cbeb0151427915d',
                      nickName: 'KENNY L SWARTZ-3931',
                      addOnDueMonthly: null,
                      tradeInPromo: null,
                      inServiceDate: null,
                      lineSharingIndicator: '',
                      lineAccessCharge: null,
                      installmentLoans: [],
                      earlyTermination: null,
                      availableMTNsForLoanTransfer: {},
                      offers: null,
                      recentPurchaseOrder: null,
                      marketingOption: {
                        vzCCHolder: false,
                      },
                      totalDueMonthly: null,
                      planChangeHoldOrdersFound: null,
                      mtnEffectiveDate: null,
                      isEqpOrAccOfferAccepted: null,
                      lineLevelCurrentCostData: {},
                      networkBandwidthType: '',
                      deviceMtnIndicator: '',
                      showSUGToggle: true,
                      balanceAmount: null,
                      isNewLine: false,
                      sharePlan: null,
                      fiosEligibilityCategory: null,
                      accountAddress: null,
                      fwaRedeemDetails: null,
                      showAddSecondNumTile: false,
                      secondNumberInfo: null,
                      newLine: false,
                      primaryNumber: false,
                      secondaryNumber: false,
                    },
                  ],
                  authorizedUsers: [
                    {
                      label: 'Mock Auth User',
                      value: 'Mock Auth User',
                      firstName: 'Mock',
                      lastName: 'User',
                      designation: 'user',
                    },
                  ],
                },
              ],
            },
          },
        },
      },
      activeMtn: '',
      SkuDetailsResult: {
        status: 'fulfilled',
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: true,
        isFetching: false,
      },
      getSkuDetailsRequestBody: jest.fn(),
      CartDetailsResult: { data: {} },
    });
    render(<PDP {...props} />);
  });
  test('it should mount', () => {});
});

describe('PDPContainer', () => {
  const props = {
    CustomerProfileResult: { data: { data: {} } },
    CartDetailsResult: { data: { data: {} } },
    ProtectionFeaturesResult: { data: { data: {} } },
    setSimIdResult: {
      data: { data: { serviceBody: { serviceResponse: { context: { deviceInfo: { deviceSku: {} } } } } } },
      status: 'fulfilled',
    },
  };
  beforeEach(() => {
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/pdp.html?isByodUpdate=true&mtn=978f74302da56d445230199a1f578e3743299bc2cca7f7756cbeb0151427915d&iSscan=true&deviceSKU=SMS911UZEV&deviceId=350321532631401&productId=1234&flowType=VIKI_AddToOrder',
    );
    PDPApiCallHook.mockReturnValue({
      __esModule: true,
      ...jest.requireActual('./PDPApiCallHook'),

      CustomerProfileResult: { data: {} },
      activeMtn: '',
      SkuDetailsResult: {
        status: 'fulfilled',
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: true,
        isFetching: false,
      },
      getSkuDetailsRequestBody: jest.fn(),
      CartDetailsResult: {
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [
                  {
                    lineNumber: '978f74302da56d445230199a1f578e3743299bc2cca7f7756cbeb0151427915d',
                    mobileNumber: '978f74302da56d445230199a1f578e3743299bc2cca7f7756cbeb0151427915d',
                    itemsInfo: [
                      {
                        cartItems: {
                          cartItem: [
                            {
                              cartItemType: 'DEVICE',
                              depletionType: 'L',
                            },
                          ],
                        },
                      },
                    ],
                  },
                ],
              },
            },
          },
        },
      },
    });
    render(<PDP {...props} />);
  });
  test('it should mount', () => {});
});
describe('PDPContainer', () => {
  const props = {
    CustomerProfileResult: { data: { data: {} } },
    CartDetailsResult: { data: { data: {} } },
    ProtectionFeaturesResult: { data: { data: {} } },
    setSimIdResult: {
      data: { data: { serviceBody: { serviceResponse: { context: { deviceInfo: { deviceSku: {} } } } } } },
      status: 'fulfilled',
    },
  };
  beforeEach(() => {
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/pdp.html?isByodUpdate=true&mtn=978f74302da56d445230199a1f578e3743299bc2cca7f7756cbeb0151427915d&iSscan=true&deviceSKU=SMS911UZEV&deviceId=350321532631401&productId=1234&flowType=VIKI_AddToOrder',
    );
    PDPApiCallHook.mockReturnValue({
      __esModule: true,
      ...jest.requireActual('./PDPApiCallHook'),

      CustomerProfileResult: { data: {} },
      activeMtn: '',
      SkuDetailsResult: {
        status: 'fulfilled',
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: true,
        isFetching: false,
      },
      getSkuDetailsRequestBody: jest.fn(),
      CartDetailsResult: { data: {} },
    });
    render(<PDP {...props} />);
  });
  test('it should mount', () => {});
});
describe('PDPContainer 1', () => {
  const props = {
    CustomerProfileResult: { data: { data: {} } },
    ProtectionFeaturesResult: { data: { data: {} } },
    setSimIdResult: {
      data: { data: { serviceBody: { serviceResponse: { context: { deviceInfo: { deviceSku: {} } } } } } },
      status: 'fulfilled',
    },
  };
  beforeEach(() => {
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/pdp.html?activeMtn=5139074854&iSscan=true&deviceSKU=MQ8R3LL/A&isLocal=true&deviceId=350321532631401',
    );
    PDPApiCallHook.mockReturnValue({
      __esModule: true,
      ...jest.requireActual('./PDPApiCallHook'),

      CustomerProfileResult: { data: {} },
      activeMtn: '',
      SkuDetailsResult: {
        status: 'fulfilled',
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: true,
        isFetching: false,
      },
      getSkuDetailsRequestBody: jest.fn(),
      BbyLocalOrderLocDetailsRequest: jest.fn(),
      CartDetailsResult: {
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [
                  {
                    mobileNumber: '5139074854',
                    deviceTypeSelected: '5G Internet',
                    itemsInfo: [{ depletionType: 'L' }],
                  },
                ],
              },
              cartHeader: {
                locationSubType: 'GN',
                maid: 'BBX',
              },
            },
          },
        },
      },
      BbyLocalOrderLocDetailsApiResponse: {
        status: 'fulfilled',
        data: {
          status: 'SUCCESS',
          bbyLocalOrderLocDetails: {
            lcLocationCode: 'Q724201',
            lcLocationType: 'S',
            lcLocSubtype: 'GN',
            agRetailCode: 'BBX',
            masterAgentId: 'BBYOMNI',
            agVisionOutletId: '000140165',
            lcFipsCode: '4812126232',
          },
        },
      },
    });
    render(<PDP {...props} />);
  });
  test('it should mount', () => {});
});
describe('PDPContainer', () => {
  const props = {
    CustomerProfileResult: { data: { data: {} } },
    CartDetailsResult: { data: { data: {} } },
    ProtectionFeaturesResult: { data: { data: {} } },
    setSimIdResult: {
      data: { data: { serviceBody: { serviceResponse: { context: { deviceInfo: { deviceSku: {} } } } } } },
      status: 'fulfilled',
    },
  };
  beforeEach(() => {
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/pdp.html?isByodUpdate=true&mtn=7038983931&iSscan=true&deviceSKU=SMS911UZEV&deviceId=350321532631401&productId=1234&flowType=VIKI_AddToOrder',
    );
    PDPApiCallHook.mockReturnValue({
      __esModule: true,
      ...jest.requireActual('./PDPApiCallHook'),

      CustomerProfileResult: {
        data: {
          data: {
            customer: {
              billAccounts: [
                {
                  billAccountNo: '1',
                  mtns: [
                    {
                      mtn: '7038983931',
                      lineLevelServiceOffers: [],
                      numberShare: null,
                      mtnHashCode: '978f74302da56d445230199a1f578e3743299bc2cca7f7756cbe',
                      nickName: 'KENNY L SWARTZ-3931',
                      addOnDueMonthly: null,
                      tradeInPromo: null,
                      inServiceDate: null,
                      lineSharingIndicator: '',
                      lineAccessCharge: null,
                      installmentLoans: [],
                      earlyTermination: null,
                      availableMTNsForLoanTransfer: {},
                      offers: null,
                      recentPurchaseOrder: null,
                      marketingOption: {
                        vzCCHolder: false,
                      },
                      totalDueMonthly: null,
                      planChangeHoldOrdersFound: null,
                      mtnEffectiveDate: null,
                      isEqpOrAccOfferAccepted: null,
                      lineLevelCurrentCostData: {},
                      networkBandwidthType: '',
                      deviceMtnIndicator: '',
                      showSUGToggle: true,
                      balanceAmount: null,
                      isNewLine: false,
                      sharePlan: null,
                      fiosEligibilityCategory: null,
                      accountAddress: null,
                      fwaRedeemDetails: null,
                      showAddSecondNumTile: false,
                      secondNumberInfo: null,
                      newLine: false,
                      primaryNumber: false,
                      secondaryNumber: false,
                    },
                  ],
                  authorizedUsers: [
                    {
                      label: 'Mock Auth User',
                      value: 'Mock Auth User',
                      firstName: 'Mock',
                      lastName: 'User',
                      designation: 'user',
                    },
                  ],
                },
              ],
            },
          },
        },
      },
      activeMtn: '',
      SkuDetailsResult: {
        status: 'fulfilled',
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: true,
        isFetching: false,
      },
      getSkuDetailsRequestBody: jest.fn(),
      CartDetailsResult: {
        data: {
          data: {
            cart: {
              customerProfile: {
                billAccounts: [
                  {
                    billAccountNo: '1',
                    mtns: [
                      {
                        mtn: '7038983931',
                        lineLevelServiceOffers: [],
                        numberShare: null,
                        mtnHashCode: '978f74302da56d445230199a1f578e3743299b5d',
                        nickName: 'KENNY L SWARTZ-3931',
                        addOnDueMonthly: null,
                        tradeInPromo: null,
                        inServiceDate: null,
                        lineSharingIndicator: '',
                        lineAccessCharge: null,
                        installmentLoans: [],
                        earlyTermination: null,
                        availableMTNsForLoanTransfer: {},
                        offers: null,
                        recentPurchaseOrder: null,
                        marketingOption: {
                          vzCCHolder: false,
                        },
                        totalDueMonthly: null,
                        planChangeHoldOrdersFound: null,
                        mtnEffectiveDate: null,
                        isEqpOrAccOfferAccepted: null,
                        lineLevelCurrentCostData: {},
                        networkBandwidthType: '',
                        deviceMtnIndicator: '',
                        showSUGToggle: true,
                        balanceAmount: null,
                        isNewLine: false,
                        sharePlan: null,
                        fiosEligibilityCategory: null,
                        accountAddress: null,
                        fwaRedeemDetails: null,
                        showAddSecondNumTile: false,
                        secondNumberInfo: null,
                        newLine: false,
                        primaryNumber: false,
                        secondaryNumber: false,
                      },
                    ],
                    authorizedUsers: [
                      {
                        label: 'Mock Auth User',
                        value: 'Mock Auth User',
                        firstName: 'Mock',
                        lastName: 'User',
                        designation: 'user',
                      },
                    ],
                  },
                ],
              },
            },
          },
        },
      },
    });
    render(<PDP {...props} />);
  });
  test('it should mount', () => {});
});
