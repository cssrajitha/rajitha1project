import PDPContainer from './PDPContainer';
import { render, screen } from '../../modules/test-utils/renderHelper';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';

jest.mock('../../components/FlexPDP/PDP', () => () => <h2>PDP Component</h2>);

jest.mock(
  '../../modules/utils',
  () => ({
    __esModule: true,
    ...jest.requireActual('../../modules/utils'),
    isFunctionalityEnabled: () => true,
  }),
  { virtual: true },
);

describe('PDPContainer', () => {
  it('should test PDP Container', () => {
    const props = {
      DeviceDetailsResult: { data: {} },
      CustomerProfileResult: { data: {} },
      activeMtn: '',
      CartDetailsResult: { data: {} },
      ProtectionFeaturesResult: { data: {} },
    };
    window.mfe = {scmDeviceMfeEnable: true};
    render(<PDPContainer {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    expect(screen.getByRole('heading', { name: 'PDP Component' })).toBeInTheDocument();
    window.mfe = {scmDeviceMfeEnable: false};
  });
});
describe('PDPContainer', () => {
  it('should test PDP Container', () => {
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/pdp.html?isByodUpdate=true&activeMtn=5185673926&iSscan=true&deviceSKU=SMS911UZEV&deviceId=350321532631401&productId=1234&flowType=VIKI_AddToOrder',
    );
    const props = {
      DeviceDetailsResult: { data: {} },
      CustomerProfileResult: { data: {} },
      activeMtn: '',
      CartDetailsResult: { data: {} },
    };
    render(<PDPContainer {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    expect(screen.getByRole('heading', { name: 'PDP Component' })).toBeInTheDocument();
  });
});
describe('PDPContainer', () => {
  it('should test PDP Container', () => {
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/pdp.html?isByodUpdate=true&mtn=978f74302da56d445230199a1f578e3743299bc2cca7f7756cbeb0151427915d&iSscan=true&deviceSKU=SMS911UZEV&deviceId=350321532631401&productId=1234&flowType=VIKI_AddToOrder',
    );
    const props = {
      DeviceDetailsResult: { data: {} },
      CustomerProfileResult: {
        data: {
          data: {
            customer: {
              billAccounts: [
                {
                  billAccountNo: '1',
                  mtns: [
                    {
                      mtn: '7038983931',
                      lineLevelServiceOffers: [],
                      numberShare: null,
                      mtnHashCode: '978f74302da56d445230199a1f578e3743299bc2cca7f7756cbeb0151427915d',
                      nickName: 'KENNY L SWARTZ-3931',
                      addOnDueMonthly: null,
                      tradeInPromo: null,
                      inServiceDate: null,
                      lineSharingIndicator: '',
                      lineAccessCharge: null,
                      installmentLoans: [],
                      earlyTermination: null,
                      availableMTNsForLoanTransfer: {},
                      offers: null,
                      recentPurchaseOrder: null,
                      marketingOption: {
                        vzCCHolder: false,
                      },
                      totalDueMonthly: null,
                      planChangeHoldOrdersFound: null,
                      mtnEffectiveDate: null,
                      isEqpOrAccOfferAccepted: null,
                      lineLevelCurrentCostData: {},
                      networkBandwidthType: '',
                      deviceMtnIndicator: '',
                      showSUGToggle: true,
                      balanceAmount: null,
                      isNewLine: false,
                      sharePlan: null,
                      fiosEligibilityCategory: null,
                      accountAddress: null,
                      fwaRedeemDetails: null,
                      showAddSecondNumTile: false,
                      secondNumberInfo: null,
                      newLine: false,
                      primaryNumber: false,
                      secondaryNumber: false,
                    },
                  ],
                  authorizedUsers: [
                    {
                      label: 'Mock Auth User',
                      value: 'Mock Auth User',
                      firstName: 'Mock',
                      lastName: 'User',
                      designation: 'user',
                    },
                  ],
                },
              ],
            },
          },
        },
      },
      activeMtn: '',
      CartDetailsResult: { data: {} },
    };
    render(<PDPContainer {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    expect(screen.getByRole('heading', { name: 'PDP Component' })).toBeInTheDocument();
  });
});
describe('PDPContainer', () => {
  it('should test PDP Container', () => {
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/pdp.html?isByodUpdate=true&mtn=978f74302da56d445230199a1f578e3743299bc2cca7f7756cbeb0151427915d&iSscan=true&deviceSKU=SMS911UZEV&deviceId=350321532631401&productId=1234&flowType=VIKI_AddToOrder',
    );
    const props = {
      DeviceDetailsResult: { data: {} },
      CustomerProfileResult: { data: {} },
      activeMtn: '123',
      CartDetailsResult: {
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [
                  {
                    lineNumber: '978f74302da56d445230199a1f578e3743299bc2cca7f7756cbeb0151427915d',
                  },
                ],
              },
            },
          },
        },
      },
    };
    render(<PDPContainer {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    expect(screen.getByRole('heading', { name: 'PDP Component' })).toBeInTheDocument();
  });
});
