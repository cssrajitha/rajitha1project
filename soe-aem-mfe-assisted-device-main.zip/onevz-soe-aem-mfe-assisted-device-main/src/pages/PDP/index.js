import React, { useCallback, useEffect, useState } from 'react';
import { getQueryParamByName, getUIContextPathBAU, getUrlName } from 'onevzsoemfecommon/Helpers';
import Emitter from 'onevzsoemfeframework/Emitter';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { isRetail, isIndirect as isInDirect } from 'onevzsoemfeframework/DomService';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { isEmpty } from 'lodash';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import PDPContainer from './PDPContainer';
import PDPApiCallHook from './PDPApiCallHook';
import RegisterPDPEventEmitter from './RegisterPDPEventEmitter';
import { initialRequestBodyDeviceDetails } from '../../modules/services/APIService/APIRequestBody';
import PDPError from './PDPError';
import hashMtnConversion from '../../modules/utils/hashMtnConversion';
import { determineBBOrderType, isDWOSAllowed, getAdobeSubKeyContract } from '../../components/FlexPDP/pdputils';
import FFLAGS from '../../constants/fFlag.constant';
import { isFunctionalityEnabled } from '../../modules/utils/index';

let navigate = '';
function useNavigateMFE() {
  navigate = useNavigate();
}

function PDP(props) {
  const scmDeviceMfeEnable = window?.mfe?.scmDeviceMfeEnable;
  const dispatch = useDispatch();
  const { moduleProps } = props;
  const { simSwapNotificationHighRiskMsg } = moduleProps || {};

  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }

  const productId = getQueryParamByName('productId');
  const defaultSku = getQueryParamByName('defaultSku') || getQueryParamByName('deviceSKU');
  const deviceSKU = getQueryParamByName('deviceSKU');
  const deviceFromCart = Boolean(getQueryParamByName('deviceFromCart'));
  const isScanDsDs = Boolean(getQueryParamByName('isScanDsDs'));
  const intentType = getQueryParamByName('intentType');
  const iSscan = !!getQueryParamByName('iSscan');
  const [ValidateDeviceSimIdResult, setSimIdResult] = useState();
  const [activeMtn, setActiveMtn] = useState(getQueryParamByName('activeMtn'));
  const acssUpdatedDeviceSku =
    scmDeviceMfeEnable &&
    ValidateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo?.simInfo?.launchPackageSku;
  const {
    CustomerProfileResult,
    getDetailsRequestBody,
    GetDetailsResult,
    CartDetailsResult,
    ProtectionFeaturesResult,
    getSkuDetailsRequestBody,
    SkuDetailsResult,
    buyoutUpgradeResult,
    buyoutUpgradeReq,
    removeLinesAPI,
    RemoveLinesAPIResult,
    BbyLocalOrderLocDetailsRequest,
    BbyLocalOrderLocDetailsApiResponse,
  } = PDPApiCallHook(acssUpdatedDeviceSku);
  const [selectedDeviceData, setSelectedDeviceData] = useState({});
  const lineInfo = CartDetailsResult?.data?.data?.cart?.lineDetails?.lineInfo;
  const lineDetails = lineInfo?.find((item) => item.mobileNumber === activeMtn);
  const cartDeviceInfo = lineDetails?.itemsInfo?.[0]?.cartItems?.cartItem || [];
  const cartDevice = cartDeviceInfo?.find((cartItem) => cartItem.cartItemType === 'DEVICE');
  const localOrder = cartDevice && cartDevice?.depletionType && cartDevice?.depletionType === 'L';
  const editDeviceIndirectFFlag = /true/i.test(getAssistedCradlePropertyV2(['editDeviceIndirectFFlag'])?.[0]);

  let displayIndirectSku = (((deviceFromCart && localOrder) || iSscan) && isInDirect()) || false;
  if(editDeviceIndirectFFlag) {
    displayIndirectSku = false;
  }
  
  const [BbyLocalOrderLocDetailsResponse, setBbyLocalOrderLocDetailsResponse] = useState({});
  const DeviceDetailsResult =
    (deviceSKU && !deviceFromCart) || displayIndirectSku ? SkuDetailsResult : GetDetailsResult;
  const [
    isPreorderCountDownEnabled,
    isPreorderTestingEnabled,
    isApplyISPURestrictionFFlag,
    installmentLoanStatusCheckCradle,
    pendingLoanCheckByMTNCradle,
    bestBuyIntegrationFFlag,
    isVVCFlowEnabled,
    elvisProspectFlag,
    dwosIndirectFFlag,
    pendingLoanCheckByMTNFFlag,
    installmentLoanStatusCheckFFlag,
    cradleToFFlagControllerFFlag,
    bestBuyEmpMasterAgentFFlag,
    bestBuyISPUEnableLocalOrderFFlag,
  ] = getAssistedCradlePropertyV2([
    'preorderCountDownFFlag',
    'preorderTestingFFlag',
    'isApplyISPURestrictionFFlag',
    'installmentLoanStatusCheck',
    'pendingLoanCheckByMTN',
    'bestBuyIntegrationFFlag',
    'isVVCFlowEnabled',
    'elvisProspectFlag',
    'dwosIndirectFFlag',
    'pendingLoanCheckByMTNFFlag',
    'installmentLoanStatusCheckFFlag',
    'cradleToFFlagControllerFFlag',
    'bestBuyEmpMasterAgentFFlag',
    'bestBuyISPUEnableLocalOrderFFlag',
  ]);
  const installmentLoanStatusCheck = /true/i.test(cradleToFFlagControllerFFlag)
    ? installmentLoanStatusCheckFFlag
    : installmentLoanStatusCheckCradle;
  const pendingLoanCheckByMTN = /true/i.test(cradleToFFlagControllerFFlag)
    ? pendingLoanCheckByMTNFFlag
    : pendingLoanCheckByMTNCradle;
  const isBYODUpg = Boolean(getQueryParamByName('isByodUpdate')); //  Upgrade DEVICE_ONLY change
  const isBYODAAL = Boolean(getQueryParamByName('isFromCPE')); // AAL BYOD
  const elvisFromSession = sessionStorage.getItem('elvisFFlag');
  const elvisFFlag = /true/i.test(elvisFromSession);
  const storeLocationCode = CustomerProfileResult?.data?.data?.customer?.orderLocationCode ?? '';
  const elvis2512FFlag = /true/i.test(JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.elvis2512FFlag);
  const channelSessionTaggingFFlag = /true/i.test(getAssistedCradlePropertyV2(['channelSessionTaggingFFlag'])?.[0]);
  const flexFlowServiceChangeFFlag =
    /true/i.test(getAssistedCradlePropertyV2(['flexFlowServiceChangeFFlag'])?.[0]) &&
    getQueryParamByName('etrServiceChanges');
  const cleanProvisionalIdIndFFlag = /true/i.test(getAssistedCradlePropertyV2(['cleanProvisionalIdIndFFlag'])?.[0])
  const isETRserviceOnly = /true/i.test(sessionStorage.getItem('isEtrServiceChangesFlow'));
  const isEtrServiceOnlyFlow =
    isETRserviceOnly && /true/i.test(getAssistedCradlePropertyV2(['flexFlowServiceChangeFFlag'])?.[0]);

  RegisterPDPEventEmitter(DeviceDetailsResult);
  const handleLineDetailsInput = (newValue) => {
    const gridWallActiveMTN = sessionStorage.getItem('activeGridwallMTN');
    if (gridWallActiveMTN === newValue?.activeMtn) {
      return;
    }
    if (newValue?.activeMtn) {
      setActiveMtn(newValue.activeMtn);
      setSelectedDeviceData({ deviceId: getQueryParamByName('deviceId') });
      sessionStorage.setItem('flexServiceFlowLineChange', true);
    }
    sessionStorage.setItem('activeGridwallMTN', newValue?.activeMtn);
  };
  useEffect(() => {
    const urlName = getUrlName(window.location.href);
    if (!flexFlowServiceChangeFFlag && urlName === 'product-detail' && isEtrServiceOnlyFlow) {
      const dID = getQueryParamByName('deviceId');
      const sID = getQueryParamByName('simId');
      const skuID = getQueryParamByName('deviceSKU');
      const aMtn = getQueryParamByName('activeMtn');
      const refreshParam = `?etrServiceChanges=true&isByodUpdate=true&isEditAndView=true&activeMtn=${aMtn}&deviceId=${dID}&deviceSKU=${skuID}&simId=${sID}`;
      navigate(`${getUIContextPathBAU()}/combinedgridwall.html${refreshParam}`);
    }
  }, []);
  useEffect(() => {
    if (flexFlowServiceChangeFFlag) {
      Emitter.on('Input_From_Line_Details', handleLineDetailsInput);

      return () => {
        Emitter.off('Input_From_Line_Details', handleLineDetailsInput);
        dispatch(appMessageActions.clearAppMessages());
      };
    }
  }, []);
  useEffect(() => {
    const incompatiblePlan = sessionStorage.getItem('incompatiblePlan');
    const deviceIdFromParam = getQueryParamByName('deviceId');
    if (incompatiblePlan && flexFlowServiceChangeFFlag) {
      sessionStorage.removeItem('incompatiblePlan');
      return;
    }
    if (flexFlowServiceChangeFFlag) {
      /*istanbul ignore else*/
      if(cleanProvisionalIdIndFFlag){
      sessionStorage.removeItem('provisionalId')}
      getSkuDetails(deviceIdFromParam, deviceSKU, isBYODUpg || isBYODAAL);
    }
  }, [activeMtn]);

  useEffect(() => {
    const incompatiblePlan = sessionStorage.getItem('incompatiblePlan');
    const deviceIdFromParam = getQueryParamByName('deviceId');
    if (incompatiblePlan && flexFlowServiceChangeFFlag) {
      sessionStorage.removeItem('incompatiblePlan');
      return;
    }
    const selectedLine = CartDetailsResult?.data?.data?.cart?.lineDetails?.lineInfo?.find(
        (line) => line?.mobileNumber === activeMtn,
    );

    const isSkuUpdateEnabled = isFunctionalityEnabled(FFLAGS?.scmCommonDefectFixFFlag?.name, FFLAGS?.scmCommonDefectFixFFlag?.attribute?.simOnlyChangeFix);

    /* istanbul ignore next */
    if (deviceFromCart && productId && (!isInDirect() || (isInDirect() && !localOrder))) {
      getDetails();
    } else if (isSkuUpdateEnabled && scmDeviceMfeEnable && selectedLine) {
      const latestDeviceInCart = selectedLine?.itemsInfo?.[0]?.cartItems?.cartItem?.find(
        (item) => item?.cartItemType === 'DEVICE'
      );
      getSkuDetails(latestDeviceInCart?.deviceId, latestDeviceInCart?.sorId, isBYODUpg || isBYODAAL);
    } else if (deviceSKU || displayIndirectSku) {
      getSkuDetails(deviceIdFromParam, deviceSKU, isBYODUpg || isBYODAAL);
    } else {
      getDetails();
    }
  }, [CartDetailsResult?.data?.data]);
  useEffect(() => {
    if (/true/i.test(bestBuyIntegrationFFlag)) {
      const skuRealAgentCode = SkuDetailsResult?.data?.data?.accountInfo?.realAgentCode;
      const selectedLine = CartDetailsResult.data?.data?.cart?.lineDetails?.lineInfo?.find(
        (line) => line?.mobileNumber === activeMtn,
      );
      const { locationSubType = '', maid = '' } = CartDetailsResult?.data?.data?.cart?.cartHeader || {};
      const depletionType = selectedLine?.itemsInfo?.[0]?.depletionType;
      const iSscanLocal = getQueryParamByName('iSscan');
      const cartDetails = CartDetailsResult?.data?.data;
      const { isBBYLocalOrder } = determineBBOrderType(iSscanLocal, cartDetails);
      if ((depletionType === 'L' && locationSubType === 'GN' && maid === 'BBX') || isBBYLocalOrder) {
        const requestBody = {
          realAgentCode: skuRealAgentCode,
          masterAgentId: 'BBYOMNI',
        };
        if (/true/i.test(bestBuyEmpMasterAgentFFlag)) {
          requestBody.masterAgentId = 'BBEMPLOC';
        }
          BbyLocalOrderLocDetailsRequest({ body: requestBody });
      }
    }
  }, [SkuDetailsResult]);

  Emitter.on('PROVISIONAL_ID_UNCHECK', (request) => {
    if (flexFlowServiceChangeFFlag) {
      getSkuDetailsRequestBody({ body: request });
    }
    Emitter.off('PROVISIONAL_ID_UNCHECK');
  });

  useEffect(() => {
    if (BbyLocalOrderLocDetailsApiResponse?.status === 'fulfilled') {
      /*istanbul ignore else*/
      if (BbyLocalOrderLocDetailsApiResponse?.data?.bbyLocalOrderLocDetails)
        setBbyLocalOrderLocDetailsResponse(BbyLocalOrderLocDetailsApiResponse?.data?.bbyLocalOrderLocDetails);
    }
  }, [BbyLocalOrderLocDetailsApiResponse]);
  useEffect(() => {
    updateGlassBoxSession(GetDetailsResult?.data?.data);
  }, [GetDetailsResult]);
  let convertedMtn = '';
  useEffect(() => {
    const hashedMtn = getQueryParamByName('mtn');
    const isViKi = /true/i.test(getQueryParamByName('flowType') === 'VIKI_AddToOrder');
    if (isViKi && CustomerProfileResult?.data && CartDetailsResult?.data && hashedMtn) {
      convertedMtn = hashMtnConversion(
        CustomerProfileResult?.data?.data?.customer?.billAccounts?.[0]?.mtns,
        CartDetailsResult?.data?.data?.cart?.lineDetails,
        hashedMtn,
      );
      if (isEmpty(convertedMtn)) {
        const selectedLineInfo = CartDetailsResult?.data?.data?.cart?.customerProfile?.billAccounts?.[0]?.mtns?.filter(
          (line) => line.mtn === hashedMtn.replaceAll('-', ''),
        );
        convertedMtn = selectedLineInfo?.[0]?.mtn;
      }
      setActiveMtn(convertedMtn);
    }
  }, [CustomerProfileResult?.data, CartDetailsResult?.data]);
  useEffect(() => {
    /* istanbul ignore next */
    if (ValidateDeviceSimIdResult?.data && ValidateDeviceSimIdResult?.status === 'fulfilled') {
      const { deviceInfo } = ValidateDeviceSimIdResult?.data.serviceBody?.serviceResponse?.context || {};
      let deviceSku = deviceInfo?.deviceSku;
      if (scmDeviceMfeEnable && deviceInfo?.deviceAttributes?.mfgCode === 'PDI') {
        const billAccounts = CustomerProfileResult?.data?.data?.customer?.billAccounts[0] || {};
        const mtns = billAccounts?.mtns || [];
        const mtn = mtns.find((mtnData) => mtnData.mtn === activeMtn);
        const device_info = mtn?.equipmentInfos.length > 0 ? mtn?.equipmentInfos?.[0]?.deviceInfo : {};
        if (device_info) {
          deviceSku = device_info.deviceSku;
        }
      }
      getSkuDetails(selectedDeviceData?.deviceId, deviceSku, isBYODUpg || isBYODAAL);
    }
  }, [ValidateDeviceSimIdResult, ValidateDeviceSimIdResult?.status]);
  /**
   * for indirect we are passing pendingLoanCheckByMTN and installmentLoanStatusCheck as per cradle property
   * @returns {object} {pendingLoanCheckByMTN: true,installmentLoanStatusCheck: true }
   */
  // used useCallback to avoid unnecessary rerender of this piece of code
  const indirectPayloadData = useCallback(() => {
    let payload = {};
    if (isInDirect()) {
      const pendingLoanCheckByMTNValue = /true/i.test(pendingLoanCheckByMTN);
      const installmentLoanStatusCheckValue = /true/i.test(installmentLoanStatusCheck);
      payload = {
        pendingLoanCheckByMTN: pendingLoanCheckByMTNValue,
        installmentLoanStatusCheck: installmentLoanStatusCheckValue,
      };
    }
    return payload;
  }, [pendingLoanCheckByMTN, installmentLoanStatusCheck]);
  /**
   * will execute it after getdetails api success
   * @param {Object} data object of getdetails api
   */
  const updateGlassBoxSession = (data) => {
    const isPreOrder = data?.deviceProduct?.childSkus?.[0]?.inventoryDetails?.dFillInventory?.isPreOrder || '';
    const isBackorder = data?.deviceProduct?.childSkus?.[0]?.inventoryDetails?.dFillInventory?.isBackorder || '';
    const daccId = data?.deviceProduct?.daccId || '';
    sessionStorage.setItem('gb_isPreorder', isPreOrder);
    sessionStorage.setItem('gb_isBackorder', isBackorder);
    sessionStorage.setItem('gb_daccCode', daccId);
  };
  const getSkuDetails = (deviceId, deviceSKUfromParam, isCPE) => {
    // const isLocal = Boolean(getQueryParamByName('isLocal'));
    // const scanFromLanding = Boolean(getQueryParamByName('scanFromLanding'));
    let deviceIdParams = deviceId;
    let deviceSkuId = setSimIdResult?.data?.data?.serviceResponse?.context?.deviceSku || deviceSKUfromParam;
    const devicedata = props?.transformedValidateDeviceSimIdData;
    console.log('getSkuDetails ~ devicedata:', devicedata);
    const allowedIntentTypes = ['AAL', 'EUP', 'NSE'];
    if (isScanDsDs && allowedIntentTypes.includes(intentType) && (isRetail() || isInDirect())) {
      deviceSkuId = getQueryParamByName('physicalSku');
      deviceIdParams = getQueryParamByName('pDeviceId');
    }
    if (/true/i.test(sessionStorage.getItem('provisionalId'))) {
      deviceSkuId = getQueryParamByName('deviceSKU');
    }
    const requestBodyDeviceDetails = {
      data: {
        sorId: deviceSkuId,
        deviceId: deviceIdParams,
        productType: 'device',
        ...(elvisFFlag
          ? {
              pageId: 'PDP',
              ...(elvis2512FFlag && { storeLocationCode }),
            }
          : {}),
        ...(elvisProspectFlag && customerType === 'N'
          ? {
              isElvisProspect: true,
            }
          : {}),
        processingMTN: activeMtn,
        isCPE,
        enableAssistedTagging: true,
        ...getAdobeSubKeyContract(channelSessionTaggingFFlag),
      },
    };
    if (iSscan) {
      requestBodyDeviceDetails.data.isScan = 'True';
    }
    getSkuDetailsRequestBody({ body: requestBodyDeviceDetails });
  };
  const customerType = CartDetailsResult.data?.data?.cart?.orderDetails?.customerType;
  const isRfexFlow = sessionStorage.getItem('refundexchange') === 'true' || false;
  const getDetails = () => {
    const requestBodyDeviceDetails = {
      ...initialRequestBodyDeviceDetails,
      data: {
        ...initialRequestBodyDeviceDetails.data,
        productId,
        defaultSku,
        processingMTN: activeMtn,
        ...(isDWOSAllowed(dwosIndirectFFlag, getQueryParamByName('isDWOS')) ? { calledFrom: 'DWOS' } : {}),
        ...(elvisFFlag
          ? {
              pageId: 'PDP',
              ...(elvis2512FFlag && { storeLocationCode }),
              accountNumber: CustomerProfileResult?.data?.data?.customer?.accountNo,
            }
          : {}),
        ...(elvisProspectFlag && customerType === 'N'
          ? {
              isElvisProspect: true,
              pageId: 'PDP',
            }
          : {}),
        enableBPM: !(customerType === 'N' || isRfexFlow),
        isApplyISPURestriction: !!(isApplyISPURestrictionFFlag || isApplyISPURestrictionFFlag === 'TRUE'),
        ...indirectPayloadData(),
        ...getAdobeSubKeyContract(channelSessionTaggingFFlag),
      },
    };
    if (isVVCFlowEnabled) {
      requestBodyDeviceDetails.data.businessFlow = [
        { key: 'PDP_Version', value: '2.0' },
        { key: 'isCommonPDP', value: 'true' },
      ];
    }
    getDetailsRequestBody({ body: requestBodyDeviceDetails });
  };
  if (DeviceDetailsResult.error) {
    dispatch(
      appMessageActions.addAppMessage(
        'Could not get the device details, please go back and select a different device.',
        'error',
        true,
        true,
      ),
    );
    return <PDPError activeMtn={activeMtn} />;
  }
  return (
    <PDPContainer
      GetDetailsResult={GetDetailsResult}
      DeviceDetailsResult={DeviceDetailsResult}
      SkuDetailsResult={SkuDetailsResult}
      CustomerProfileResult={CustomerProfileResult}
      ValidateDeviceSimIdResult={ValidateDeviceSimIdResult}
      CartDetailsResult={CartDetailsResult}
      ProtectionFeaturesResult={ProtectionFeaturesResult}
      activeMtn={activeMtn}
      isPreorderCountDownEnabled={isPreorderCountDownEnabled}
      isPreorderTestingEnabled={isPreorderTestingEnabled}
      buyoutUpgradeReq={buyoutUpgradeReq}
      buyoutUpgradeResult={buyoutUpgradeResult}
      removeLinesAPI={removeLinesAPI}
      RemoveLinesAPIResult={RemoveLinesAPIResult}
      setSimIdResult={setSimIdResult}
      setSelectedDeviceData={setSelectedDeviceData}
      transformedValidateDeviceSimIdData={props?.transformedValidateDeviceSimIdData}
      productDetailsAemContent={props?.productDetailsAemContent}
      BbyLocalOrderLocDetailsApiResponse={BbyLocalOrderLocDetailsApiResponse}
      BbyLocalOrderLocDetailsResponse={BbyLocalOrderLocDetailsResponse}
      BbyLocalOrderLocDetailsRequest={BbyLocalOrderLocDetailsRequest}
      simSwapNotificationHighRiskMsg={simSwapNotificationHighRiskMsg}
    />
  );
}
export default PDP;
