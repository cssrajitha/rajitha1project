import React from 'react';
import { setupServer } from 'msw/node';
import Emitter from 'onevzsoemfeframework/Emitter';
import rootReducer from '../../modules/store/reducer.js';
import { rootSaga } from '../../modules/store/saga.js';
import { render, screen } from '../../modules/test-utils/renderHelper.js';
import PDP from './index.js';

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => true,
    isIpad: () => true,
    isIndirect: () => true,
    getQueryParamByName: jest.fn(() => ({
      deviceFromCart: false,
    })),
  }),
  { virtual: true },
);

jest.mock('onevzsoemfecommon/BrowseAPIService', () => ({
  ...jest.requireActual('onevzsoemfecommon/BrowseAPIService'),
  useLazyGetSkuDetailsQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: false,
      isError: true,
      isFetching: false,
      error: { name: 'System Error', code: '400', Message: 'Could not get device details' },
    },
  ],
}));

describe(`<Pdp /> component`, () => {
  const props = {
    DeviceDetailsResult: { data: { data: {} } },
    CustomerProfileResult: { data: { data: {} } },
    CartDetailsResult: { data: { data: {} } },
    ProtectionFeaturesResult: { data: { data: {} } },
    setSimIdResult: {
      data: { data: { serviceBody: { serviceResponse: { context: { deviceInfo: { deviceSku: {} } } } } } },
      status: 'fulfilled',
    },
  };
  setupServer();
  beforeEach(() => {
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/pdp.html?activeMtn=8145772880&productId=dev19920006&defaultSku=MQ8R3LL/A&deviceFromCart=true',
    );
    render(<PDP {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test.skip('should mount', async () => {
    expect(screen.getByTestId('pdp-device-section')).toBeInTheDocument();
  });
  test('test emitter PROVISIONAL_ID_UNCHECK', () => {
    const handler = jest.fn();
    Emitter.on('PROVISIONAL_ID_UNCHECK', handler);
    Emitter.emit('PROVISIONAL_ID_UNCHECK', { id: 'test-id' });
    expect(handler).toHaveBeenCalledWith({ id: 'test-id' });
    Emitter.off('PROVISIONAL_ID_UNCHECK', handler);
  });
});

describe(`<Pdp /> component Load with PDP error`, () => {
  const props = {
    DeviceDetailsResult: { data: { data: {} } },
    CustomerProfileResult: { data: { data: {} } },
    CartDetailsResult: { data: { data: {} } },
    ProtectionFeaturesResult: { data: { data: {} } },
  };
  setupServer();
  beforeEach(() => {
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/pdp.html?activeMtn=5139074854&iSscan=true&deviceSKU=MQ8R3LL/A&isLocal=true&deviceId=350321532631401&productId=350321532631401',
    );
    render(<PDP {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should mount', async () => {
    expect(screen.getByTestId('error-container')).toBeInTheDocument();
  });
});
