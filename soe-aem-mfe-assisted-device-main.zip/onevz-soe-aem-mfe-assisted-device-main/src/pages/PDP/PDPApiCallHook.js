import {
  useGetCustomerProfileQuery,
  useGetCartDetailsQuery,
  useLazyRemoveLinesQuery,
  useLazyValidateDeviceSimIdQuery,
} from 'onevzsoemfecommon/APIService';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { isVbg, isVbgAem } from 'onevzsoemfeframework/VbgAemUtil';
// import { useLazyDeviceInventoryStatusCheckQuery } from 'onevzsoemfecommon/CartAPIService';
import { useLazyGetDeviceDetailsQuery, useLazyGetSkuDetailsQuery } from 'onevzsoemfecommon/BrowseAPIService';
import { useGetProtectionFeaturesQuery, useLazyGetBuyoutUpgradeQuery } from 'onevzsoemfecommon/DeviceAPIService';
import {
  // useLazyGetDeviceDetailsQuery,
  // useGetProtectionFeaturesQuery,
  // useLazyGetSkuDetailsQuery,
  // useLazyValidateDeviceSimIdQuery,
  useLazyDeviceInventoryStatusCheckQuery,
  // useLazyGetBuyoutUpgradeQuery,
  useLazyBbyLocalOrderLocDetailsQuery,
} from '../../modules/services/APIService/APIServiceHooks';
import {
  initialRequestBodyProtectionFeatures,
  requestBodyCustomerProfile,
  requestBodyRetriveCart,
} from '../../modules/services/APIService/APIRequestBody';
import { determineBBOrderType } from '../../components/FlexPDP/pdputils';

const PDPApiCallHook = (acssUpdatedDeviceSku = false) => {
  const activeMtnFFlag = /true/i.test(getAssistedCradlePropertyV2(['protectionFeatureSkipFFlag'])?.[0]);
  let activeMtn = getQueryParamByName('activeMtn');
  if (activeMtnFFlag && (activeMtn === 'null' || activeMtn === 'undefined')) {
    activeMtn = '';
  }
  const defaultSku = getQueryParamByName('defaultSku');
  const deviceSKU = getQueryParamByName('deviceSKU');
  const iSscanLocal = getQueryParamByName('iSscan');
  const vbgFwaMLOrderingFFlag = isVbgAem() && JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.vbgFwaMLOrderingFFlag === 'TRUE';
  const fiveGLinesCount = getQueryParamByName('fiveGLinesCount') || 0;
  const CustomerProfileResult = useGetCustomerProfileQuery(
    { body: { ...requestBodyCustomerProfile, mtn: (vbgFwaMLOrderingFFlag && fiveGLinesCount > 1) ? activeMtn : '' } },
    { refetchOnMountOrArgChange: true },
  );

  const CartDetailsResult = useGetCartDetailsQuery(
    { body: requestBodyRetriveCart },
    { refetchOnMountOrArgChange: true },
    { skip: !CustomerProfileResult.isSuccess },
  );
  const { isBBYLocalOrder, isBBYDfillOrder } = determineBBOrderType(iSscanLocal, CartDetailsResult?.data?.data);
  const requestBodyProtectionFeatures = {
    ...initialRequestBodyProtectionFeatures,
    mtn: activeMtn,
    deviceSorId: defaultSku || deviceSKU,
    isBBYLocalOrder,
    isBBYDfillOrder,
  };
  if (acssUpdatedDeviceSku) {
    requestBodyProtectionFeatures.deviceSorId = acssUpdatedDeviceSku;
  }

  const [getDetailsRequestBody, GetDetailsResult] = useLazyGetDeviceDetailsQuery();

  const [getSkuDetailsRequestBody, SkuDetailsResult] = useLazyGetSkuDetailsQuery();

  const fiveGDetails = CartDetailsResult?.data?.data?.cart?.lineDetails?.lineInfo?.filter(
    (line) => line?.deviceTypeSelected === '5G Internet',
  );
  const isFiveG = fiveGDetails?.length > 0;

  const ProtectionFeaturesResult = useGetProtectionFeaturesQuery(
    { body: requestBodyProtectionFeatures },
    {
      refetchOnMountOrArgChange: true,
      skip:
        !CustomerProfileResult.isSuccess || !activeMtn || (isVbg() ? !CartDetailsResult.isSuccess || isFiveG : false),
    },
  );

  const [validateDeviceSimIdRequestBody, ValidateDeviceSimIdResult] = useLazyValidateDeviceSimIdQuery();
  const [DeviceInventoryStatusCheckRequestBody, DeviceInventoryStatusCheckResult] =
    useLazyDeviceInventoryStatusCheckQuery();

  const [buyoutUpgradeReq, buyoutUpgradeResult] = useLazyGetBuyoutUpgradeQuery();

  const [removeLinesAPI, RemoveLinesAPIResult] = useLazyRemoveLinesQuery();

  const [BbyLocalOrderLocDetailsRequest, BbyLocalOrderLocDetailsApiResponse] = useLazyBbyLocalOrderLocDetailsQuery();

  return {
    CustomerProfileResult,
    getDetailsRequestBody,
    GetDetailsResult,
    CartDetailsResult,
    ProtectionFeaturesResult,
    getSkuDetailsRequestBody,
    SkuDetailsResult,
    validateDeviceSimIdRequestBody,
    ValidateDeviceSimIdResult,
    DeviceInventoryStatusCheckRequestBody,
    DeviceInventoryStatusCheckResult,
    buyoutUpgradeReq,
    buyoutUpgradeResult,
    removeLinesAPI,
    RemoveLinesAPIResult,
    BbyLocalOrderLocDetailsRequest,
    BbyLocalOrderLocDetailsApiResponse,
  };
};

export default PDPApiCallHook;
