import { setupServer } from 'msw/node';
import Emitter from 'onevzsoemfeframework/Emitter';
import { render, screen, waitFor } from '../../modules/test-utils/renderHelper';
import RegisterPDPEventEmitter from './RegisterPDPEventEmitter';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradlePropertyV2: () => ['TRUE'],
  }),
  { virtual: true }
);

describe(`<RegisterPDPEventEmitter /> when product details is success`, () => {
  const props = {
    isSuccess: true,
  };
  window.vzdl = {
    page: {
      name: 'product-detail',
    },
  };
  setupServer();
  beforeEach(() => {
    render(<RegisterPDPEventEmitter {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('Should wait to component render', async () => {
    await expect(async () => {
      await waitFor(() => expect(screen.getByText(/product details true/i)).toBeInTheDocument());
    }).rejects.toEqual(expect.anything());
  });
});

describe(`<RegisterPDPEventEmitter /> when product details is false`, () => {
  const props = {
    isSuccess: false,
  };
  setupServer();
  beforeEach(() => {
    render(<RegisterPDPEventEmitter {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('check plan price call', async () => {
    window.vzdl = {
      page: {
        name: 'product-detail',
      },
    };
    await expect(async () => {
      await waitFor(() => expect(screen.getByText(/product details false/i)).toBeInTheDocument());
    }).rejects.toEqual(expect.anything());
    Emitter.emit('WRITE_VZDL_DATA', 'false');
  });
});
