import React from 'react';
import { setupServer } from 'msw/node';
import { isRetail, isIndirect as isInDirect } from 'onevzsoemfeframework/DomService';
import { rest } from 'msw';
import Emitter from 'onevzsoemfeframework/Emitter';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { render, screen } from '../../modules/test-utils/renderHelper';
import PDP from './index.js';

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    // getAssistedCradlePropertyV2 :()=> ['TRUE'],
    getAssistedCradleProperty: () => [
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'FALSE',
      'FALSE',
      'FALSE',
      'TRUE',
      'TRUE',
    ],
    getAssistedCradlePropertyV2: () => [
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'FALSE',
      'FALSE',
      'FALSE',
      'TRUE',
      'TRUE',
    ],
  }),
  { virtual: true },
);

// jest.mock('onevzsoemfeframework/AssistedCradleService', () => ({
//   getAssistedCradleProperty: jest.fn(() => ['', '', true]),
// }));

// featureFlag.getAssistedCradleProperty = jest.fn().mockReturnValue([true, true, true]);

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => true,
    isIpad: () => true,
    isRetail: () => true,
    getQueryParamByName: jest.fn(() => ({
      deviceFromCart: true,
    })),
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfecommon/Helpers',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfecommon/Helpers'),
    isAsurion: () => true,
    isIpad: () => true,
    getQueryParamByName: (val) => {
      if (val === 'etrServiceChanges') return true;
      if (val === 'isScanDsDs') return true;
      if (val === 'intentType') return 'AAL';
    },
  }),
  { virtual: true },
);

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
  useLazyGetDeviceDetailsQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: { data: {} },
    },
  ],
  useLazyGetSkuDetailsQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: { data: {} },
    },
  ],
}));

describe(`<Pdp /> component`, () => {
  const props = {
    DeviceDetailsResult: { data: { data: {} } },
    CustomerProfileResult: { data: { data: {} } },
    CartDetailsResult: { data: { data: {} } },
    ProtectionFeaturesResult: { data: { data: {} } },
    setSimIdResult: {
      data: { data: { serviceBody: { serviceResponse: { context: { deviceInfo: { deviceSku: {} } } } } } },
      status: 'fulfilled',
    },
  };
  setupServer();
  beforeEach(() => {
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/pdp.html?activeMtn=8145772880&productId=dev19920006&defaultSku=MQ8R3LL/A',
    );
    render(<PDP {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('should mount', async () => {
    expect(screen.getByTestId('pdp-device-section')).toBeInTheDocument();
  });

  test('test emitter PROVISIONAL_ID_UNCHECK', () => {
    const handler = jest.fn();
    Emitter.on('PROVISIONAL_ID_UNCHECK', handler);
    Emitter.emit('PROVISIONAL_ID_UNCHECK', { id: 'test-id' });
    expect(handler).toHaveBeenCalledWith({ id: 'test-id' });

    // Remove the handler and verify it's removed
    Emitter.off('PROVISIONAL_ID_UNCHECK', handler);

    // Spy on the internal listeners map if possible
    if (Emitter.listeners) {
      const listeners = Emitter.listeners('PROVISIONAL_ID_UNCHECK');
      expect(listeners).not.toContain(handler);
    }

    Emitter.emit('PROVISIONAL_ID_UNCHECK', { id: 'test-id-2' });
    expect(handler).toHaveBeenCalledTimes(1);
  });

  // test('should display device details header', async () => {
  //   const { productDisplayName } = getDetailsMock.data.deviceProduct;
  //   expect(await screen.findByText(productDisplayName)).toBeInTheDocument();
  // });

  // test('should display device info', async () => {
  //   const { skuDisplayName } = getDetailsMock.data.deviceProduct.defaultSKUObj;
  //   // const { description } = getDetailsMock.data.deviceProduct;
  //   expect(await screen.findByText(skuDisplayName)).toBeInTheDocument();
  //   const storageSelector = await screen.findByLabelText(/256 GB/i, { selector: 'input' });
  //   fireEvent.click(storageSelector);
  //   expect(storageSelector.value).toBe('256 GB');
  // });

  // test('should test header component everything is visible except for more options', async () => {
  //   const overviewTab = await screen.findByRole('tab', {
  //     name: /overview/i,
  //   });
  //   const specsTab = await screen.findByRole('tab', {
  //     name: /specs/i,
  //   });
  //   const inTheBoxTab = await screen.findByRole('tab', {
  //     name: /in the box/i,
  //   });
  //   expect(overviewTab).toBeInTheDocument();
  //   expect(specsTab).toBeInTheDocument();
  //   expect(inTheBoxTab).toBeInTheDocument();

  //   fireEvent.click(overviewTab);
  //   expect(await screen.findByTestId('overview-content')).toBeInTheDocument();
  //   const showMore = await screen.findByText(/show more/i);
  //   fireEvent.click(showMore);
  //   expect(await screen.findByText(/show less/i)).toBeInTheDocument();
  //   const showLess = await screen.findByText(/show less/i);
  //   fireEvent.click(showLess);
  //   expect(await screen.findByText(/show more/i)).toBeInTheDocument();
  // });
});

describe(`<Pdp /> component Local`, () => {
  const props = {
    DeviceDetailsResult: { data: { data: {} } },
    CustomerProfileResult: { data: { data: {} } },
    CartDetailsResult: { data: { data: {} } },
    ProtectionFeaturesResult: { data: { data: {} } },
  };
  setupServer();
  beforeEach(() => {
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/pdp.html?activeMtn=5139074854&iSscan=true&deviceSKU=MQ8R3LL/A&isLocal=true&deviceId=350321532631401',
    );
    render(<PDP {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should mount', async () => {
    expect(screen.getByTestId('pdp-device-section')).toBeInTheDocument();
  });
});

describe(`<Pdp /> component Local with Product Id`, () => {
  const props = {
    DeviceDetailsResult: { data: { data: {} } },
    CustomerProfileResult: { data: { data: {} } },
    CartDetailsResult: { data: { data: {} } },
    ProtectionFeaturesResult: { data: { data: {} } },
  };
  setupServer();
  beforeEach(() => {
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/pdp.html?activeMtn=5139074854&iSscan=true&deviceSKU=MQ8R3LL/A&isLocal=true&deviceId=350321532631401&productId=350321532631401&deviceFromCart=true',
    );
    render(<PDP {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should mount', async () => {
    expect(screen.getByTestId('pdp-device-section')).toBeInTheDocument();
  });
});

describe(`<Pdp /> component Local with Product Id`, () => {
  const props = {
    DeviceDetailsResult: { data: { data: {} } },
    CustomerProfileResult: { data: { data: {} } },
    CartDetailsResult: { data: { data: {} } },
    ProtectionFeaturesResult: { data: { data: {} } },
    activeMtn: '5139074854',
  };
  setupServer();
  beforeEach(() => {
    sessionStorage.setItem('elvisFFlag', 'TRUE');
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({ elvis2512FFlag: 'TRUE', editDeviceIndirectFFlag: 'TRUE' }),
    );
    sessionStorage.setItem('channel', 'indirect');
    sessionStorage.setItem('assistedFlags', JSON.stringify({ isVVCFlowEnabled: 'TRUE' }));
    sessionStorage.setItem('provisionalId', 'true');
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/pdp.html?activeMtn=5139074854&iSscan=true&deviceSKU=MQ8R3LL/A&isLocal=true&deviceId=350321532631401&productId=350321532631401&deviceFromCart=true',
    );
    render(<PDP {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should mount', async () => {
    expect(screen.getByTestId('pdp-device-section')).toBeInTheDocument();
  });
});

describe(`<Pdp /> component Local physical sim and isScanDSDS`, () => {
  const props = {
    DeviceDetailsResult: { data: { data: {} } },
    CustomerProfileResult: { data: { data: {} } },
    CartDetailsResult: { data: { data: {} } },
    ProtectionFeaturesResult: { data: { data: {} } },
  };
  setupServer();
  beforeEach(() => {
    sessionStorage.setItem('elvisFFlag', 'TRUE');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ elvis2512FFlag: 'TRUE' }));
    sessionStorage.setItem('channel', 'retail');
    sessionStorage.setItem('assistedFlags', JSON.stringify({ isVVCFlowEnabled: 'TRUE' }));
    sessionStorage.setItem('provisionalId', 'true');
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/pdp.html?activeMtn=5139074854&iSscan=true&deviceSKU=MQ8R3LL/A&isLocal=true&deviceId=350321532631401&productId=350321532631401&isScanDsDs=true&intentType=AAL&physicalSku=MQ8R3LL/A&pDeviceId=350321532631401',
    );
    render(<PDP {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should mount', async () => {
    expect(isRetail()).toBeTruthy();
    expect(screen.getByTestId('pdp-device-section')).toBeInTheDocument();
  });
});
describe(`<Pdp /> component Local physical sim and isScanDSDS and indirect location`, () => {
  const props = {
    DeviceDetailsResult: { data: { data: {} } },
    CustomerProfileResult: { data: { data: {} } },
    CartDetailsResult: { data: { data: {} } },
    ProtectionFeaturesResult: { data: { data: {} } },
  };
  setupServer();
  beforeEach(() => {
    sessionStorage.setItem('elvisFFlag', 'TRUE');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ elvis2512FFlag: 'TRUE' }));
    sessionStorage.setItem('channel', 'indirect');
    sessionStorage.setItem('assistedFlags', JSON.stringify({ isVVCFlowEnabled: 'TRUE' }));
    sessionStorage.setItem('provisionalId', 'true');
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/pdp.html?activeMtn=5139074854&iSscan=true&deviceSKU=MQ8R3LL/A&isLocal=true&deviceId=350321532631401&productId=350321532631401&isScanDsDs=true&intentType=AAL&physicalSku=MQ8R3LL/A&pDeviceId=350321532631401',
    );
    render(<PDP {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should mount', async () => {
    expect(isInDirect()).toBeTruthy();
    expect(screen.getByTestId('pdp-device-section')).toBeInTheDocument();
  });
});

describe(`<Pdp /> component Error scenario`, () => {
  const props = {
    DeviceDetailsResult: { data: { data: {} } },
    CustomerProfileResult: { data: { data: {} } },
    CartDetailsResult: { data: { data: {} } },
    ProtectionFeaturesResult: { data: { data: {} } },
  };
  const DeviceDetails = { errors: { name: 'System Error', code: '400', Message: 'Could not get device details' } };
  const handlers = [
    rest.post(`*/flexV2/getDetails`, (req, res, ctx) => {
      console.log('inside */flexV2/getDetails');
      return res(ctx.status(400), ctx.json(DeviceDetails));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
    window.sessionStorage.setItem('elvisFFlag', 'TRUE');
    sessionStorage.setItem('provisionalId', 'true');
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {});
  test.skip('should get Blank page', async () => {
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/pdp.html?activeMtn=5139074854&iSscan=true&deviceSKU=MQ8R3LL/A&isLocal=true&deviceId=350321532631401',
    );
    const { container } = render(<PDP {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    expect(container).toBeEmptyDOMElement();
  });
});
describe(`<Pdp /> component Flag Validation`, () => {
  const props = {
    DeviceDetailsResult: { data: { data: {} } },
    CustomerProfileResult: { data: { data: {} } },
    CartDetailsResult: { data: { data: {} } },
    ProtectionFeaturesResult: { data: { data: {} } },
    activeMtn: '5139074854',
  };
  setupServer();
  beforeEach(() => {
    sessionStorage.setItem('elvisFFlag', 'TRUE');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ elvis2512FFlag: 'TRUE' }));
    sessionStorage.setItem('channel', 'retail');
    sessionStorage.setItem('assistedFlags', JSON.stringify({ isVVCFlowEnabled: 'TRUE' }));
    sessionStorage.setItem('provisionalId', true);
    // window.history.pushState(
    //   {},
    //   'PDP',
    //   '/sales/assisted/new/device/pdp.html?activeMtn=5139074854&iSscan=true&deviceSKU=MQ8R3LL/A&isLocal=true&deviceId=350321532631401&productId=350321532631401&isScanDsDs=true&intentType=AAL&physicalSku=MQ8R3LL/A&pDeviceId=350321532631401'
    // );
    render(<PDP {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should enable elvisProspectFlag when elvisFlag is TRUE and customerType is N', () => {
    sessionStorage.setItem('elvisFlag', 'TRUE');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ elvis2512FFlag: 'TRUE' }));
    sessionStorage.setItem('customerType', 'N');
    sessionStorage.setItem('provisionalId', true);
    const requestBodyDeviceDetails = {
      data: {
        isElvisProspect:
          sessionStorage.getItem('elvisFlag') === 'TRUE' && sessionStorage.getItem('customerType') === 'N',
      },
    };
    expect(requestBodyDeviceDetails.data.isElvisProspect).toBeTruthy();
  });
  test('should set isApplyISPURestriction to true when isApplyISPURestrictionFFlag is "TRUE"', () => {
    sessionStorage.setItem('isApplyISPURestrictionFFlag', 'TRUE');
    const isApplyISPURestrictionFFlag = sessionStorage.getItem('isApplyISPURestrictionFFlag');
    const requestBodyDeviceDetails = {
      data: {
        isApplyISPURestriction: isApplyISPURestrictionFFlag === 'TRUE',
      },
    };
    expect(requestBodyDeviceDetails.data.isApplyISPURestriction).toBeTruthy();
  });
  test('should set isApplyISPURestriction to false when isApplyISPURestrictionFFlag is False', () => {
    sessionStorage.setItem('isApplyISPURestrictionFFlag', 'FALSE');
    const requestBodyDeviceDetails = {
      data: {
        isApplyISPURestriction: false,
      },
    };
    expect(requestBodyDeviceDetails.data.isApplyISPURestriction).toBeFalsy();
  });
});
describe(`<Pdp /> component Local with Product Id`, () => {
  const props = {
    DeviceDetailsResult: { data: { data: {} } },
    CustomerProfileResult: { data: { data: {} } },
    CartDetailsResult: { data: { data: {} } },
    ProtectionFeaturesResult: { data: { data: {} } },
    activeMtn: '5139074854',
  };
  setupServer();
  beforeEach(() => {
    sessionStorage.setItem('incompatiblePlan', true);
    sessionStorage.setItem('provisionalId', true);
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/pdp.html?activeMtn=5139074854&iSscan=true&deviceSKU=MQ8R3LL/A&isLocal=true&deviceId=350321532631401&productId=350321532631401&deviceFromCart=true',
    );
    render(<PDP {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should mount', async () => {
    expect(screen.getByTestId('pdp-device-section')).toBeInTheDocument();
  });
  test('should mount', async () => {
    expect(screen.getByTestId('pdp-device-section')).toBeInTheDocument();
    Emitter.emit('Input_From_Line_Details', {
      activeMtn: '4782303946',
    });
    Emitter.emit('Input_From_Line_Details', {});
    Emitter.emit('Input_From_Line_Details', {
      activeMtn: '4782303946',
    });
    window.sessionStorage.setItem('activeGridwallMTN', '4782303946');
    Emitter.emit('Input_From_Line_Details', {
      activeMtn: '4782303946',
    });
  });
});