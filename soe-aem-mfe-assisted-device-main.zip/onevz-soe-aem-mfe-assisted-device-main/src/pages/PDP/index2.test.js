import React from 'react';
import { setupServer } from 'msw/node';
import rootReducer from '../../modules/store/reducer.js';
import { rootSaga } from '../../modules/store/saga.js';
import { render, screen } from '../../modules/test-utils/renderHelper.js';
import PDP from './index.js';

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    // getAssistedCradlePropertyV2 :()=> ['TRUE'],
    getAssistedCradleProperty: () => ['TRUE'],
    getAssistedCradlePropertyV2: () => ['TRUE'],
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => true,
    isIpad: () => true,
    getQueryParamByName: jest.fn(() => ({
      deviceFromCart: true,
    })),
    getUrlName: () => 'product-detail',
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfecommon/Helpers',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfecommon/Helpers'),
    isAsurion: () => true,
    isIpad: () => true,
    getQueryParamByName: (val) => {
      if (val === 'etrServiceChanges') return false;
    },
  }),
  { virtual: true },
);

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
  useLazyGetDeviceDetailsQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: { data: {} },
    },
  ],
  useLazyGetSkuDetailsQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: { data: {} },
    },
  ],
}));

describe(`<Pdp /> component`, () => {
  const props = {
    DeviceDetailsResult: { data: { data: {} } },
    CustomerProfileResult: { data: { data: {} } },
    CartDetailsResult: { data: { data: {} } },
    ProtectionFeaturesResult: { data: { data: {} } },
    setSimIdResult: {
      data: { data: { serviceBody: { serviceResponse: { context: { deviceInfo: { deviceSku: {} } } } } } },
      status: 'fulfilled',
    },
  };
  setupServer();
  beforeEach(() => {
    sessionStorage.setItem('isEtrServiceChangesFlow', true);
    window.history.pushState(
      {},
      'product-detail',
      '/sales/assisted/new/device/product-detail.html?activeMtn=5139074854&iSscan=true&deviceSKU=MQ8R3LL/A&isLocal=true&deviceId=350321532631401&productId=350321532631401&deviceFromCart=true',
    );
    render(<PDP {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('should mount', async () => {
    expect(screen.getByTestId('pdp-device-section')).toBeInTheDocument();
  });
});
describe(`<Pdp /> component`, () => {
  const props = {
    DeviceDetailsResult: { data: { data: {} } },
    CustomerProfileResult: { data: { data: {} } },
    CartDetailsResult: { data: { data: {} } },
    ProtectionFeaturesResult: { data: { data: {} } },
    setSimIdResult: {
      data: { data: { serviceBody: { serviceResponse: { context: { deviceInfo: { deviceSku: {} } } } } } },
      status: 'fulfilled',
    },
  };
  setupServer();
  beforeEach(() => {
    sessionStorage.setItem('isEtrServiceChangesFlow', true);
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/pdp.html?activeMtn=5139074854&iSscan=true&deviceSKU=MQ8R3LL/A&isLocal=true&deviceId=350321532631401&productId=350321532631401&deviceFromCart=true',
    );
    render(<PDP {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('should mount', async () => {
    expect(screen.getByTestId('pdp-device-section')).toBeInTheDocument();
  });
});
