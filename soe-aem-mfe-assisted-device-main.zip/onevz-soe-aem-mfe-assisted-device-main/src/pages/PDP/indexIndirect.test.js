import React from 'react';
import { setupServer } from 'msw/node';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { render, screen } from '../../modules/test-utils/renderHelper';
import PDP from './index.js';

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradleProperty: () => [true, true, 'TRUE'],
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isIndirect: () => true,
    isIpad: () => true,
    getQueryParamByName: jest.fn(() => ({
      deviceFromCart: true,
    })),
  }),
  { virtual: true },
);

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
  useLazyGetDeviceDetailsQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: { data: {} },
    },
  ],
  useLazyGetSkuDetailsQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: { data: {} },
    },
  ],
}));

describe(`<Pdp /> component for indirect channel `, () => {
  const props = {
    DeviceDetailsResult: { data: { data: {} } },
    CustomerProfileResult: { data: { data: {} } },
    CartDetailsResult: { data: { data: {} } },
    ProtectionFeaturesResult: { data: { data: {} } },
    setSimIdResult: {
      data: { data: { serviceBody: { serviceResponse: { context: { deviceInfo: { deviceSku: {} } } } } } },
      status: 'fulfilled',
    },
  };
  setupServer();
  beforeEach(() => {
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/pdp.html?activeMtn=8145772880&productId=dev19920006&defaultSku=MQ8R3LL/A',
    );
    render(<PDP {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('should load device details for indirect', async () => {
    expect(async () => {
      expect(screen.getByTestId('pdp-device-section')).toBeInTheDocument();
    });
  });
});
