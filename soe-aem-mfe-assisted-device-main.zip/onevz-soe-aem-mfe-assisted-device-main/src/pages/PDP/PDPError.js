import styled from 'styled-components';
import { Title } from '@vds/typography';
import { Icon } from '@vds/icons';
import { getUIContextPathBAU, getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import * as DOMPurify from 'dompurify';
import { useNavigate } from 'react-router-dom';
import { Line } from '@vds/lines';

const BackClickable = styled.a`
  cursor: pointer;
  color: #000000 !important;
  align-items: center;
  padding: 1.5rem 1.5rem 1.5rem 0;
`;
const RightTextAlign = styled.div`
  padding: 0 100px 20px;
`;

const FlexBoxGrowOne = styled.div`
  display: flex;
  flex-grow: 1;
`;

const LineWrapper = styled.div`
  padding: 0 2rem;
`;
export const FlexAlignContainerItemsCenter = styled.div`
  display: flex;
  align-items: center;
  padding: 0 2rem;
  justify-content: space-between;
`;

const ShopWrapper = styled.div`
  padding: 1.5rem 0.5rem;
`;

const ShopWrapperTop = styled.div`
  padding: 2.5rem 0 0 0;
`;

const PDPWrapper = styled.div`
  margin-top: 2rem;
  max-width: 1133px;
  width: ${(props) => (props.scmDeviceEnable ? '85%' : '100%')};
  position: fixed;
  display: flex;
  top: ${(props) => (props.scmDeviceEnable ? '10rem' : '3rem')};
`;

const LeftWrapper = styled.div`
  width: 260px;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  margin-top: 2rem;
  z-index: 100;
`;

const RightWrapper = styled.div`
  display: flex;
  flex: 1;
  flex-direction: column;
  width: 100%;
  height: calc(100vh - 86px);
  overflow-y: auto;
  padding-left: 0.5rem;
`;

const LeftAlign = styled.div`
  text-align: left !important;
`;

let navigate = '';

function useNavigateMFE() {
  navigate = useNavigate();
}

function PDPError() {
  const scmDeviceEnable = window?.mfe?.scmDeviceMfeEnable;

  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }

  const handleBackNav = (props) => {
    const fromPage = getQueryParamByName('fromPage');
    const activeMtn = getQueryParamByName('activeMtn') || sessionStorage.getItem('activeMTN') || props?.activeMtn;
    const gridwallUrl = DOMPurify.sanitize(
      `/combinedgridwall.html?fromPDP=true&activeMtn=${activeMtn}&backfrompdp=true`,
    );
    if (!scmDeviceEnable) {
      /* istanbul ignore else */
      if (fromPage === 'Landing') {
        navigate(`${getUIContextPathBAU()}/landing.html?fromPDP=true`);
      } else {
        navigate(`${getUIContextPathBAU()}${gridwallUrl}`);
      }
    } else if (window?.mfe?.scmUpgradeMfeEnable) {
      window?.mfe?.historyRef.goBack();
    }
  };
  return (
    <>
      <FlexAlignContainerItemsCenter data-testid='error-container'>
        <FlexBoxGrowOne>
          <BackClickable data-testid='testBackGridwall' onClick={handleBackNav} data-track='PDPpage-BackIcon'>
            <Icon name='left-caret' size='XLarge' medium='true' />
          </BackClickable>
          <ShopWrapper>
            <Title size='small' bold primitive='h1'>
              Device PDP
            </Title>
          </ShopWrapper>
        </FlexBoxGrowOne>
      </FlexAlignContainerItemsCenter>
      <LineWrapper>
        <Line type='secondary' />
      </LineWrapper>
      <PDPWrapper scmDeviceEnable={scmDeviceEnable}>
        <LeftWrapper>
          <RightTextAlign>
            <img src='https://ss7.vzw.com/is/image/VerizonWireless/generic_phone?$device-med$' alt='DeviceIcon' />
          </RightTextAlign>
        </LeftWrapper>
        <RightWrapper>
          <RightTextAlign>
            <ShopWrapperTop>
              <Title size='small' bold primitive='h1'>
                <LeftAlign>Could not load the device details, please go back and select a different device.</LeftAlign>
              </Title>{' '}
            </ShopWrapperTop>
          </RightTextAlign>
        </RightWrapper>
      </PDPWrapper>
    </>
  );
}
export default PDPError;
