// import { setupServer } from 'msw/node';
import { render, screen, fireEvent } from '../../modules/test-utils/renderHelper';
import PDPError from './PDPError';
// import PDP from './index.js';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
  useLazyGetDeviceDetailsQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: { data: {} },
      error: true,
    },
  ],
  useLazyGetSkuDetailsQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: { data: {} },
      error: true,
    },
  ],
}));

describe(`PDPError component`, () => {
  beforeEach(() => {
    window.history.pushState({}, 'PDP', '/sales/assisted/new/device/pdp.html');
    window.mfe = {};
    render(<PDPError />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should mount', async () => {
    expect(screen.getByTestId('error-container')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('error-container'));
  });
  test('should mount', async () => {
    expect(screen.getByTestId('error-container')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('error-container'));
  });
});
describe(`PDPError component without fromPromotions`, () => {
  beforeEach(() => {
    window.mfe = {};
    window.history.pushState({}, 'PDP', '/sales/assisted/new/device/pdp.html?activeMtn=5185673926&fromPage=Landing');
    render(<PDPError />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should mount', async () => {
    window.mfe.scmDeviceMfeEnable = false;
    expect(screen.getByTestId('testBackGridwall')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('testBackGridwall'));
  });
  test('should mount with scmDeviceEnable enabled', async () => {
    window.mfe.scmDeviceMfeEnable = true;
    expect(screen.getByTestId('testBackGridwall')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('testBackGridwall'));
  });
  test('should mount with scmDeviceEnable enabled', async () => {
    window.mfe.scmDeviceMfeEnable = true;
    window.mfe.scmUpgradeMfeEnable = true;
    window.mfe.historyRef = { goBack: jest.fn() };
    expect(screen.getByTestId('testBackGridwall')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('testBackGridwall'));
  });
});
describe(`PDPError component without fromPromotions`, () => {
  beforeEach(() => {
    window.history.pushState({}, 'PDP', '/sales/assisted/new/device/pdp.html');
    render(<PDPError />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should mount', async () => {
    expect(screen.getByTestId('testBackGridwall')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('testBackGridwall'));
  });
});
