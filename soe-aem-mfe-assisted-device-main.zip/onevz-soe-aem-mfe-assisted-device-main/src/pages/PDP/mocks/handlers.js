import { rest } from 'msw';

// api mocking response
import customerProfile from './api/customerProfile.json';
import getDetails from './api/getDetails.json';
import getProtectionFeatures from './api/getProtectionFeatures.json';
import retrieveCart from './api/retrieveCart.json';

export const handlers = () => [
  rest.post(`*/flexV2/customerProfile`, (req, res, ctx) => res(ctx.status(200), ctx.json(customerProfile))),
  rest.post(`*/flexV2/getDetails`, (req, res, ctx) => res(ctx.status(200), ctx.json(getDetails))),
  rest.post(`*/flexV2/getProtectionFeatures`, (req, res, ctx) => res(ctx.status(200), ctx.json(getProtectionFeatures))),
  rest.post(`*/flexV2/retrieve-cart`, (req, res, ctx) => res(ctx.status(200), ctx.json(retrieveCart))),
];
