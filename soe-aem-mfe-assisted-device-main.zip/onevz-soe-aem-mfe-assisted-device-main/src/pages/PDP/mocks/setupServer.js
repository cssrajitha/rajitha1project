import { server as APIServer } from './server';

export const setupServer = () => {
  const server = APIServer();

  beforeAll(() => server.listen());
  // Reset any runtime request handlers we may add during the tests.

  afterEach(() => server.resetHandlers());
  // Disable API mocking after the tests are done.

  afterAll(() => server.close());
};
