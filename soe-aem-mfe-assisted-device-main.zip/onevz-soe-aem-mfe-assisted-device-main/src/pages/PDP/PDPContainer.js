import React from 'react';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import { useGetProtectionFeaturesQuery } from 'onevzsoemfecommon/DeviceAPIService';
import { initialRequestBodyProtectionFeatures } from '../../modules/services/APIService/APIRequestBody';
import PDP from '../../components/FlexPDP/PDP';
import { isFunctionalityEnabled } from '../../modules/utils';

const PDPContainer = (props) => {
  const {
    DeviceDetailsResult,
    CustomerProfileResult,
    activeMtn,
    CartDetailsResult,
    ProtectionFeaturesResult,
    isPreorderCountDownEnabled,
    isPreorderTestingEnabled,
    buyoutUpgradeReq,
    buyoutUpgradeResult,
    removeLinesAPI,
    RemoveLinesAPIResult,
    setSimIdResult,
    setSelectedDeviceData,
    ValidateDeviceSimIdResult,
    SkuDetailsResult,
    GetDetailsResult,
    simSwapNotificationHighRiskMsg,
  } = props;

  const defaultSku = getQueryParamByName('defaultSku');
  const deviceSKU = getQueryParamByName('deviceSKU');
  const isScmfullScreenFix = isFunctionalityEnabled('scmPactCommonFixFFlag', 'scmfullScreenFix');
  let protectionFeaturesResultOFViki = {};
  const isViKi = /true/i.test(getQueryParamByName('flowType') === 'VIKI_AddToOrder');
    const isPrePay = CartDetailsResult?.data?.data?.cart?.orderDetails?.isPrePayCart === 'Y';
  const requestBodyProtectionFeatures = {
    ...initialRequestBodyProtectionFeatures,
    mtn: activeMtn,
    deviceSorId: defaultSku || deviceSKU,
  };
  protectionFeaturesResultOFViki = useGetProtectionFeaturesQuery(
    { body: requestBodyProtectionFeatures },
    { skip: !(isViKi && CustomerProfileResult?.data && CartDetailsResult?.data && !isPrePay && activeMtn) },
  );

  return (
    <div data-testid='pdp-device-section' style={(window?.mfe?.scmDeviceMfeEnable && isScmfullScreenFix) ? { height: '65vh', overflowY: 'scroll' } : {}} >
      {DeviceDetailsResult.data && CustomerProfileResult.data && CartDetailsResult.data ? (
        <PDP
          GetDetailsResult={GetDetailsResult}
          productDetails={DeviceDetailsResult.data?.data}
          SkuDetailsResult={SkuDetailsResult}
          customerProfileDetails={CustomerProfileResult.data?.data}
          ValidateDeviceSimIdResult={ValidateDeviceSimIdResult}
          activeMtn={activeMtn}
          cartDetails={CartDetailsResult.data?.data}
          protectionFeatures={ProtectionFeaturesResult?.data || protectionFeaturesResultOFViki?.data}
          isPreorderCountDownEnabled={isPreorderCountDownEnabled}
          isPreorderTestingEnabled={isPreorderTestingEnabled}
          buyoutUpgradeReq={buyoutUpgradeReq}
          buyoutUpgradeResult={buyoutUpgradeResult}
          removeLinesAPI={removeLinesAPI}
          RemoveLinesAPIResult={RemoveLinesAPIResult}
          setSimIdResult={setSimIdResult}
          setSelectedDeviceData={setSelectedDeviceData}
          transformedValidateDeviceSimIdData={props?.transformedValidateDeviceSimIdData}
          productDetailsAemContent={props?.productDetailsAemContent}
          BbyLocalOrderLocDetailsApiResponse={props?.BbyLocalOrderLocDetailsApiResponse}
          BbyLocalOrderLocDetailsResponse={props?.BbyLocalOrderLocDetailsResponse}
          BbyLocalOrderLocDetailsRequest={props.BbyLocalOrderLocDetailsRequest}
          simSwapNotificationHighRiskMsg={simSwapNotificationHighRiskMsg}
        />
      ) : null}
    </div>
  );
};

export default PDPContainer;
