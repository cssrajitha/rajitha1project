import { renderHook } from '@testing-library/react';
import { Provider } from 'react-redux';
import configureAppStore from 'onevzsoemfeframework/Store';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';

// Import the mocked modules
import {
  useGetCustomerProfileQuery,
  useGetCartDetailsQuery,
  useLazyRemoveLinesQuery,
  useLazyValidateDeviceSimIdQuery,
} from 'onevzsoemfecommon/APIService';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import { isVbg, isVbgAem } from 'onevzsoemfeframework/VbgAemUtil';
import { useLazyGetDeviceDetailsQuery, useLazyGetSkuDetailsQuery } from 'onevzsoemfecommon/BrowseAPIService';
import { useGetProtectionFeaturesQuery, useLazyGetBuyoutUpgradeQuery } from 'onevzsoemfecommon/DeviceAPIService';
import PDPApiCallHook from './PDPApiCallHook';
import {
  useLazyDeviceInventoryStatusCheckQuery,
  useLazyBbyLocalOrderLocDetailsQuery,
} from '../../modules/services/APIService/APIServiceHooks';
import { determineBBOrderType } from '../../components/FlexPDP/pdputils';

// Mock all the API service hooks
jest.mock('onevzsoemfecommon/APIService', () => ({
  useGetCustomerProfileQuery: jest.fn(),
  useGetCartDetailsQuery: jest.fn(),
  useLazyRemoveLinesQuery: jest.fn(),
  useLazyValidateDeviceSimIdQuery: jest.fn(),
}));

jest.mock('onevzsoemfecommon/Helpers', () => ({
  getQueryParamByName: jest.fn(),
}));

jest.mock('onevzsoemfeframework/VbgAemUtil', () => ({
  isVbg: jest.fn(),
  isVbgAem: jest.fn(),
}));

jest.mock('onevzsoemfecommon/BrowseAPIService', () => ({
  useLazyGetDeviceDetailsQuery: jest.fn(),
  useLazyGetSkuDetailsQuery: jest.fn(),
}));

jest.mock('onevzsoemfecommon/DeviceAPIService', () => ({
  useGetProtectionFeaturesQuery: jest.fn(),
  useLazyGetBuyoutUpgradeQuery: jest.fn(),
}));

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  useLazyDeviceInventoryStatusCheckQuery: jest.fn(),
  useLazyBbyLocalOrderLocDetailsQuery: jest.fn(),
}));

jest.mock('../../modules/services/APIService/APIRequestBody', () => ({
  initialRequestBodyProtectionFeatures: {
    deviceSorId: '',
    mtn: '',
    isBBYLocalOrder: false,
    isBBYDfillOrder: false,
  },
  requestBodyCustomerProfile: { mockCustomerProfile: true },
  requestBodyRetriveCart: { mockRetrieveCart: true },
}));

jest.mock('../../components/FlexPDP/pdputils', () => ({
  determineBBOrderType: jest.fn(),
}));

jest.mock('onevzsoemfeframework/AssistedCradleService', () => ({
  getAssistedCradlePropertyV2: jest.fn(),
}));

describe('PDPApiCallHook', () => {
  let store;

  // Create a wrapper component for the hook
  const createWrapper =
    () =>
    ({ children }) => <Provider store={store}>{children}</Provider>;

  beforeEach(() => {
    // Reset all mocks before each test
    jest.clearAllMocks();

    // Create a fresh store for each test
    function* defaultSaga() {
      yield 'default saga';
    }
    store = configureAppStore({}, defaultSaga);

    // Setup default mock implementations
    getQueryParamByName.mockImplementation((param) => {
      const params = {
        activeMtn: '1234567890',
        defaultSku: 'SKU123',
        deviceSKU: 'DEVICE123',
        iSscan: 'true',
      };
      return params[param];
    });

    isVbg.mockReturnValue(false);

    determineBBOrderType.mockReturnValue({
      isBBYLocalOrder: false,
      isBBYDfillOrder: false,
    });

    // Mock API hook return values
    useGetCustomerProfileQuery.mockReturnValue({
      data: { mockCustomerData: true },
      isSuccess: true,
      isLoading: false,
      error: null,
    });

    useGetCartDetailsQuery.mockReturnValue({
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [{ deviceTypeSelected: '4G' }],
            },
          },
        },
      },
      isSuccess: true,
      isLoading: false,
      error: null,
    });

    useGetProtectionFeaturesQuery.mockReturnValue({
      data: { mockProtectionFeatures: true },
      isSuccess: true,
      isLoading: false,
      error: null,
    });

    // Mock lazy query hooks
    useLazyGetDeviceDetailsQuery.mockReturnValue([
      jest.fn(), // trigger function
      { data: null, isLoading: false, error: null },
    ]);

    useLazyGetSkuDetailsQuery.mockReturnValue([
      jest.fn(), // trigger function
      { data: null, isLoading: false, error: null },
    ]);

    useLazyValidateDeviceSimIdQuery.mockReturnValue([
      jest.fn(), // trigger function
      { data: null, isLoading: false, error: null },
    ]);

    useLazyDeviceInventoryStatusCheckQuery.mockReturnValue([
      jest.fn(), // trigger function
      { data: null, isLoading: false, error: null },
    ]);

    useLazyGetBuyoutUpgradeQuery.mockReturnValue([
      jest.fn(), // trigger function
      { data: null, isLoading: false, error: null },
    ]);

    useLazyRemoveLinesQuery.mockReturnValue([
      jest.fn(), // trigger function
      { data: null, isLoading: false, error: null },
    ]);

    useLazyBbyLocalOrderLocDetailsQuery.mockReturnValue([
      jest.fn(), // trigger function
      { data: null, isLoading: false, error: null },
    ]);
  });

  describe('Basic hook functionality', () => {
    it('should initialize and return all expected API hooks and results', () => {
      const wrapper = createWrapper();
      const { result } = renderHook(() => PDPApiCallHook(), { wrapper });

      expect(result.current).toHaveProperty('CustomerProfileResult');
      expect(result.current).toHaveProperty('getDetailsRequestBody');
      expect(result.current).toHaveProperty('GetDetailsResult');
      expect(result.current).toHaveProperty('CartDetailsResult');
      expect(result.current).toHaveProperty('ProtectionFeaturesResult');
      expect(result.current).toHaveProperty('getSkuDetailsRequestBody');
      expect(result.current).toHaveProperty('SkuDetailsResult');
      expect(result.current).toHaveProperty('validateDeviceSimIdRequestBody');
      expect(result.current).toHaveProperty('ValidateDeviceSimIdResult');
      expect(result.current).toHaveProperty('DeviceInventoryStatusCheckRequestBody');
      expect(result.current).toHaveProperty('DeviceInventoryStatusCheckResult');
      expect(result.current).toHaveProperty('buyoutUpgradeReq');
      expect(result.current).toHaveProperty('buyoutUpgradeResult');
      expect(result.current).toHaveProperty('removeLinesAPI');
      expect(result.current).toHaveProperty('RemoveLinesAPIResult');
      expect(result.current).toHaveProperty('BbyLocalOrderLocDetailsRequest');
      expect(result.current).toHaveProperty('BbyLocalOrderLocDetailsApiResponse');
    });

    it('should call useGetCustomerProfileQuery with correct parameters', () => {
      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      expect(useGetCustomerProfileQuery).toHaveBeenCalledWith(
        { body: { mockCustomerProfile: true, mtn: '' } },
        { refetchOnMountOrArgChange: true },
      );
    });

    it('should call useGetCartDetailsQuery with correct parameters and skip condition', () => {
      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      expect(useGetCartDetailsQuery).toHaveBeenCalledWith(
        { body: { mockRetrieveCart: true } },
        { refetchOnMountOrArgChange: true },
        { skip: false }, // CustomerProfileResult.isSuccess is true
      );
    });
  });

  describe('Query parameter handling', () => {
    it('should retrieve query parameters correctly', () => {
      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      expect(getQueryParamByName).toHaveBeenCalledWith('activeMtn');
      expect(getQueryParamByName).toHaveBeenCalledWith('defaultSku');
      expect(getQueryParamByName).toHaveBeenCalledWith('deviceSKU');
      expect(getQueryParamByName).toHaveBeenCalledWith('iSscan');
    });

    it('should handle missing query parameters', () => {
      getQueryParamByName.mockReturnValue(null);
      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      expect(useGetProtectionFeaturesQuery).toHaveBeenCalledWith(
        expect.objectContaining({
          body: expect.objectContaining({
            mtn: null,
            deviceSorId: null,
          }),
        }),
        expect.objectContaining({
          skip: true, // Should skip when activeMtn is null
        }),
      );
    });
  });

  describe('Protection Features request body construction', () => {
    it('should construct protection features request body with defaultSku when available', () => {
      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      expect(useGetProtectionFeaturesQuery).toHaveBeenCalledWith(
        expect.objectContaining({
          body: expect.objectContaining({
            mtn: '1234567890',
            deviceSorId: 'SKU123', // Uses defaultSku over deviceSKU
            isBBYLocalOrder: false,
            isBBYDfillOrder: false,
          }),
        }),
        expect.any(Object),
      );
    });

    it('should use deviceSKU when defaultSku is not available', () => {
      getQueryParamByName.mockImplementation((param) => {
        const params = {
          activeMtn: '1234567890',
          defaultSku: null,
          deviceSKU: 'DEVICE123',
          iSscan: 'true',
        };
        return params[param];
      });

      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      expect(useGetProtectionFeaturesQuery).toHaveBeenCalledWith(
        expect.objectContaining({
          body: expect.objectContaining({
            deviceSorId: 'DEVICE123', // Uses deviceSKU when defaultSku is null
          }),
        }),
        expect.any(Object),
      );
    });

    it('should update deviceSorId when acssUpdatedDeviceSku is provided', () => {
      const acssUpdatedDeviceSku = 'UPDATED_SKU123';
      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(acssUpdatedDeviceSku), { wrapper });

      expect(useGetProtectionFeaturesQuery).toHaveBeenCalledWith(
        expect.objectContaining({
          body: expect.objectContaining({
            deviceSorId: acssUpdatedDeviceSku,
          }),
        }),
        expect.any(Object),
      );
    });

    it('should include BBY order type information in request body', () => {
      determineBBOrderType.mockReturnValue({
        isBBYLocalOrder: true,
        isBBYDfillOrder: true,
      });

      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      expect(useGetProtectionFeaturesQuery).toHaveBeenCalledWith(
        expect.objectContaining({
          body: expect.objectContaining({
            isBBYLocalOrder: true,
            isBBYDfillOrder: true,
          }),
        }),
        expect.any(Object),
      );
    });
  });

  describe('5G device handling', () => {
    it('should detect 5G devices and skip protection features query when VBG and 5G', () => {
      isVbg.mockReturnValue(true);
      useGetCartDetailsQuery.mockReturnValue({
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [{ deviceTypeSelected: '5G Internet' }],
              },
            },
          },
        },
        isSuccess: true,
      });

      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      expect(useGetProtectionFeaturesQuery).toHaveBeenCalledWith(
        expect.any(Object),
        expect.objectContaining({
          skip: true, // Should skip for 5G devices when VBG
        }),
      );
    });

    it('should not skip protection features query for non-5G devices', () => {
      isVbg.mockReturnValue(true);
      // Cart data with non-5G device (already set in beforeEach)

      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      expect(useGetProtectionFeaturesQuery).toHaveBeenCalledWith(
        expect.any(Object),
        expect.objectContaining({
          skip: false, // Should not skip for non-5G devices
        }),
      );
    });

    it('should not skip protection features query when not VBG environment', () => {
      isVbg.mockReturnValue(false);
      useGetCartDetailsQuery.mockReturnValue({
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [{ deviceTypeSelected: '5G Internet' }],
              },
            },
          },
        },
        isSuccess: true,
      });

      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      expect(useGetProtectionFeaturesQuery).toHaveBeenCalledWith(
        expect.any(Object),
        expect.objectContaining({
          skip: false, // Should not skip for 5G when not VBG
        }),
      );
    });
  });

  describe('Skip conditions for protection features query', () => {
    it('should skip protection features query when customer profile is not successful', () => {
      useGetCustomerProfileQuery.mockReturnValue({
        data: null,
        isSuccess: false,
        isLoading: true,
        error: null,
      });

      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      expect(useGetProtectionFeaturesQuery).toHaveBeenCalledWith(
        expect.any(Object),
        expect.objectContaining({
          skip: true,
        }),
      );
    });

    it('should skip protection features query when activeMtn is not available', () => {
      getQueryParamByName.mockImplementation((param) => {
        const params = {
          activeMtn: null, // No activeMtn
          defaultSku: 'SKU123',
          deviceSKU: 'DEVICE123',
          iSscan: 'true',
        };
        return params[param];
      });

      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      expect(useGetProtectionFeaturesQuery).toHaveBeenCalledWith(
        expect.any(Object),
        expect.objectContaining({
          skip: true,
        }),
      );
    });

    it('should skip protection features query when cart details is not successful in VBG environment', () => {
      isVbg.mockReturnValue(true);
      useGetCartDetailsQuery.mockReturnValue({
        data: null,
        isSuccess: false,
        isLoading: true,
        error: null,
      });

      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      expect(useGetProtectionFeaturesQuery).toHaveBeenCalledWith(
        expect.any(Object),
        expect.objectContaining({
          skip: true,
        }),
      );
    });
  });

  describe('Cart details query skip condition', () => {
    it('should skip cart details query when customer profile is not successful', () => {
      useGetCustomerProfileQuery.mockReturnValue({
        data: null,
        isSuccess: false,
        isLoading: true,
        error: null,
      });

      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      expect(useGetCartDetailsQuery).toHaveBeenCalledWith(expect.any(Object), expect.any(Object), { skip: true });
    });
  });

  describe('API hook initialization', () => {
    it('should initialize all lazy query hooks', () => {
      const wrapper = createWrapper();
      const { result } = renderHook(() => PDPApiCallHook(), { wrapper });

      // Verify that all lazy hooks are initialized
      expect(useLazyGetDeviceDetailsQuery).toHaveBeenCalled();
      expect(useLazyGetSkuDetailsQuery).toHaveBeenCalled();
      expect(useLazyValidateDeviceSimIdQuery).toHaveBeenCalled();
      expect(useLazyDeviceInventoryStatusCheckQuery).toHaveBeenCalled();
      expect(useLazyGetBuyoutUpgradeQuery).toHaveBeenCalled();
      expect(useLazyRemoveLinesQuery).toHaveBeenCalled();
      expect(useLazyBbyLocalOrderLocDetailsQuery).toHaveBeenCalled();

      // Verify that the hook returns the trigger functions and results
      expect(typeof result.current.getDetailsRequestBody).toBe('function');
      expect(typeof result.current.getSkuDetailsRequestBody).toBe('function');
      expect(typeof result.current.validateDeviceSimIdRequestBody).toBe('function');
      expect(typeof result.current.DeviceInventoryStatusCheckRequestBody).toBe('function');
      expect(typeof result.current.buyoutUpgradeReq).toBe('function');
      expect(typeof result.current.removeLinesAPI).toBe('function');
      expect(typeof result.current.BbyLocalOrderLocDetailsRequest).toBe('function');
    });
  });

  describe('Edge cases', () => {
    it('should handle empty cart line details', () => {
      useGetCartDetailsQuery.mockReturnValue({
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [], // Empty array
              },
            },
          },
        },
        isSuccess: true,
      });

      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      // Should not affect the protection features query negatively
      expect(useGetProtectionFeaturesQuery).toHaveBeenCalledWith(
        expect.any(Object),
        expect.objectContaining({
          skip: false,
        }),
      );
    });

    it('should handle missing cart structure gracefully', () => {
      useGetCartDetailsQuery.mockReturnValue({
        data: {
          data: {
            cart: null, // Missing cart
          },
        },
        isSuccess: true,
      });

      const wrapper = createWrapper();
      const { result } = renderHook(() => PDPApiCallHook(), { wrapper });

      // Should not throw errors and should return valid hook structure
      expect(result.current).toBeDefined();
      expect(result.current.CartDetailsResult).toBeDefined();
    });

    it('should handle completely missing cart data', () => {
      useGetCartDetailsQuery.mockReturnValue({
        data: null,
        isSuccess: true,
      });

      const wrapper = createWrapper();
      const { result } = renderHook(() => PDPApiCallHook(), { wrapper });

      // Should not throw errors
      expect(result.current).toBeDefined();
      expect(result.current.CartDetailsResult).toBeDefined();
    });
  });

  describe('determineBBOrderType integration', () => {
    it('should call determineBBOrderType with correct parameters', () => {
      const mockCartData = {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [{ deviceTypeSelected: '4G' }],
            },
          },
        },
      };

      useGetCartDetailsQuery.mockReturnValue({
        data: mockCartData,
        isSuccess: true,
      });

      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      expect(determineBBOrderType).toHaveBeenCalledWith('true', mockCartData.data);
    });
  });

  describe('activeMtnFFlag feature flag and string handling', () => {
    it('should set activeMtn to empty string when activeMtnFFlag is true and activeMtn is "null"', () => {
      getQueryParamByName.mockImplementation((param) => {
        if (param === 'activeMtn') return 'null';
        if (param === 'defaultSku') return 'SKU123';
        if (param === 'deviceSKU') return 'DEVICE123';
        if (param === 'iSscan') return 'true';
        return undefined;
      });
      getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']);

      const wrapper = createWrapper();
      const { result } = renderHook(() => PDPApiCallHook(), { wrapper });

      expect(result.current.ProtectionFeaturesResult).toBeDefined();
      expect(useGetProtectionFeaturesQuery).toHaveBeenCalledWith(
        expect.objectContaining({
          body: expect.objectContaining({
            mtn: '',
          }),
        }),
        expect.any(Object),
      );
    });

    it('should set activeMtn to empty string when activeMtnFFlag is true and activeMtn is "undefined"', () => {
      getQueryParamByName.mockImplementation((param) => {
        if (param === 'activeMtn') return 'undefined';
        if (param === 'defaultSku') return 'SKU123';
        if (param === 'deviceSKU') return 'DEVICE123';
        if (param === 'iSscan') return 'true';
        return undefined;
      });
      getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']);

      const wrapper = createWrapper();
      const { result } = renderHook(() => PDPApiCallHook(), { wrapper });

      expect(result.current.ProtectionFeaturesResult).toBeDefined();
      expect(useGetProtectionFeaturesQuery).toHaveBeenCalledWith(
        expect.objectContaining({
          body: expect.objectContaining({
            mtn: '',
          }),
        }),
        expect.any(Object),
      );
    });

    it('should keep original activeMtn when activeMtnFFlag is false', () => {
      getQueryParamByName.mockImplementation((param) => {
        if (param === 'activeMtn') return 'null';
        if (param === 'defaultSku') return 'SKU123';
        if (param === 'deviceSKU') return 'DEVICE123';
        if (param === 'iSscan') return 'true';
        return undefined;
      });
      getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

      const wrapper = createWrapper();
      const { result } = renderHook(() => PDPApiCallHook(), { wrapper });

      expect(result.current.ProtectionFeaturesResult).toBeDefined();
      expect(useGetProtectionFeaturesQuery).toHaveBeenCalledWith(
        expect.objectContaining({
          body: expect.objectContaining({
            mtn: 'null', // Should keep original value when flag is false
          }),
        }),
        expect.any(Object),
      );
    });
  });

  describe('VBG FWA ML ordering feature flag', () => {
    beforeEach(() => {
      // Mock sessionStorage for these tests
      Object.defineProperty(window, 'sessionStorage', {
        value: {
          getItem: jest.fn(),
          setItem: jest.fn(),
          removeItem: jest.fn(),
          clear: jest.fn(),
        },
        writable: true,
      });
    });

    it('should include activeMtn in customer profile request when VBG AEM and feature flag is enabled with multiple 5G lines', () => {
      isVbgAem.mockReturnValue(true);
      getQueryParamByName.mockImplementation((param) => {
        const params = {
          activeMtn: '1234567890',
          defaultSku: 'SKU123',
          deviceSKU: 'DEVICE123',
          iSscan: 'true',
          fiveGLinesCount: '2',
        };
        return params[param];
      });
      
      window.sessionStorage.getItem.mockReturnValue(
        JSON.stringify({ vbgFwaMLOrderingFFlag: 'TRUE' })
      );

      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      expect(useGetCustomerProfileQuery).toHaveBeenCalledWith(
        { body: { mockCustomerProfile: true, mtn: '1234567890' } },
        { refetchOnMountOrArgChange: true },
      );
    });

    it('should not include activeMtn in customer profile request when fiveGLinesCount is 1 or less', () => {
      isVbgAem.mockReturnValue(true);
      getQueryParamByName.mockImplementation((param) => {
        const params = {
          activeMtn: '1234567890',
          defaultSku: 'SKU123',
          deviceSKU: 'DEVICE123',
          iSscan: 'true',
          fiveGLinesCount: '1',
        };
        return params[param];
      });
      
      window.sessionStorage.getItem.mockReturnValue(
        JSON.stringify({ vbgFwaMLOrderingFFlag: 'TRUE' })
      );

      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      expect(useGetCustomerProfileQuery).toHaveBeenCalledWith(
        { body: { mockCustomerProfile: true, mtn: '' } },
        { refetchOnMountOrArgChange: true },
      );
    });

    it('should not include activeMtn in customer profile request when feature flag is disabled', () => {
      isVbgAem.mockReturnValue(true);
      getQueryParamByName.mockImplementation((param) => {
        const params = {
          activeMtn: '1234567890',
          defaultSku: 'SKU123',
          deviceSKU: 'DEVICE123',
          iSscan: 'true',
          fiveGLinesCount: '2',
        };
        return params[param];
      });
      
      window.sessionStorage.getItem.mockReturnValue(
        JSON.stringify({ vbgFwaMLOrderingFFlag: 'FALSE' })
      );

      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      expect(useGetCustomerProfileQuery).toHaveBeenCalledWith(
        { body: { mockCustomerProfile: true, mtn: '' } },
        { refetchOnMountOrArgChange: true },
      );
    });

    it('should not include activeMtn in customer profile request when not VBG AEM', () => {
      isVbgAem.mockReturnValue(false);
      getQueryParamByName.mockImplementation((param) => {
        const params = {
          activeMtn: '1234567890',
          defaultSku: 'SKU123',
          deviceSKU: 'DEVICE123',
          iSscan: 'true',
          fiveGLinesCount: '2',
        };
        return params[param];
      });
      
      window.sessionStorage.getItem.mockReturnValue(
        JSON.stringify({ vbgFwaMLOrderingFFlag: 'TRUE' })
      );

      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      expect(useGetCustomerProfileQuery).toHaveBeenCalledWith(
        { body: { mockCustomerProfile: true, mtn: '' } },
        { refetchOnMountOrArgChange: true },
      );
    });

    it('should handle missing APP_PROPERTIES in session storage', () => {
      isVbgAem.mockReturnValue(true);
      getQueryParamByName.mockImplementation((param) => {
        const params = {
          activeMtn: '1234567890',
          fiveGLinesCount: '2',
        };
        return params[param];
      });
      
      window.sessionStorage.getItem.mockReturnValue(null);

      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      expect(useGetCustomerProfileQuery).toHaveBeenCalledWith(
        { body: { mockCustomerProfile: true, mtn: '' } },
        { refetchOnMountOrArgChange: true },
      );
    });

    it('should handle malformed JSON in session storage', () => {
      isVbgAem.mockReturnValue(true);
      getQueryParamByName.mockImplementation((param) => {
        const params = {
          activeMtn: '1234567890',
          fiveGLinesCount: '2',
        };
        return params[param];
      });
      
      window.sessionStorage.getItem.mockReturnValue('invalid json');

      const wrapper = createWrapper();
      
      // Should not throw an error and should handle gracefully
      expect(() => renderHook(() => PDPApiCallHook(), { wrapper })).not.toThrow();
    });
  });

  describe('fiveGLinesCount parameter handling', () => {
    it('should retrieve fiveGLinesCount query parameter', () => {
      getQueryParamByName.mockImplementation((param) => {
        const params = {
          activeMtn: '1234567890',
          defaultSku: 'SKU123',
          deviceSKU: 'DEVICE123',
          iSscan: 'true',
          fiveGLinesCount: '3',
        };
        return params[param];
      });

      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      expect(getQueryParamByName).toHaveBeenCalledWith('fiveGLinesCount');
    });

    it('should default fiveGLinesCount to 0 when not provided', () => {
      getQueryParamByName.mockImplementation((param) => {
        const params = {
          activeMtn: '1234567890',
          defaultSku: 'SKU123',
          deviceSKU: 'DEVICE123',
          iSscan: 'true',
          fiveGLinesCount: null,
        };
        return params[param];
      });

      const wrapper = createWrapper();
      const { result } = renderHook(() => PDPApiCallHook(), { wrapper });

      // The hook should not fail and should handle the null case
      expect(result.current).toBeDefined();
    });
  });

  describe('Multiple 5G devices in cart', () => {
    it('should correctly identify multiple 5G devices in cart', () => {
      isVbg.mockReturnValue(true);
      useGetCartDetailsQuery.mockReturnValue({
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [
                  { deviceTypeSelected: '5G Internet' },
                  { deviceTypeSelected: '5G Internet' },
                  { deviceTypeSelected: '4G' },
                ],
              },
            },
          },
        },
        isSuccess: true,
      });

      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      expect(useGetProtectionFeaturesQuery).toHaveBeenCalledWith(
        expect.any(Object),
        expect.objectContaining({
          skip: true, // Should skip for multiple 5G devices when VBG
        }),
      );
    });

    it('should handle mixed device types correctly', () => {
      isVbg.mockReturnValue(true);
      useGetCartDetailsQuery.mockReturnValue({
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [
                  { deviceTypeSelected: '5G Internet' },
                  { deviceTypeSelected: '4G LTE' },
                  { deviceTypeSelected: 'Smartphone' },
                ],
              },
            },
          },
        },
        isSuccess: true,
      });

      const wrapper = createWrapper();
      renderHook(() => PDPApiCallHook(), { wrapper });

      expect(useGetProtectionFeaturesQuery).toHaveBeenCalledWith(
        expect.any(Object),
        expect.objectContaining({
          skip: true, // Should skip because there's at least one 5G device when VBG
        }),
      );
    });
  });

  describe('Error handling and resilience', () => {
    it('should handle API errors gracefully', () => {
      useGetCustomerProfileQuery.mockReturnValue({
        data: null,
        isSuccess: false,
        isLoading: false,
        error: { message: 'API Error' },
      });

      const wrapper = createWrapper();
      const { result } = renderHook(() => PDPApiCallHook(), { wrapper });

      // Should not throw and should return the error state
      expect(result.current.CustomerProfileResult.error).toEqual({ message: 'API Error' });
    });

    it('should handle undefined cart line info gracefully', () => {
      useGetCartDetailsQuery.mockReturnValue({
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: undefined, // Undefined lineInfo
              },
            },
          },
        },
        isSuccess: true,
      });

      const wrapper = createWrapper();
      const { result } = renderHook(() => PDPApiCallHook(), { wrapper });

      // Should not throw errors
      expect(result.current).toBeDefined();
      expect(result.current.CartDetailsResult).toBeDefined();
    });

    it('should handle missing deviceTypeSelected property', () => {
      useGetCartDetailsQuery.mockReturnValue({
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [
                  { someOtherProperty: 'value' }, // Missing deviceTypeSelected
                  { deviceTypeSelected: '4G' },
                ],
              },
            },
          },
        },
        isSuccess: true,
      });

      const wrapper = createWrapper();
      const { result } = renderHook(() => PDPApiCallHook(), { wrapper });

      // Should not throw errors and should handle gracefully
      expect(result.current).toBeDefined();
    });
  });
});
