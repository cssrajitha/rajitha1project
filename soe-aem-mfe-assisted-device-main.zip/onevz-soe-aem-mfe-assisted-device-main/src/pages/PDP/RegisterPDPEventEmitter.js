import { useEffect } from 'react';
import Emitter from 'onevzsoemfeframework/Emitter';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';

const RegisterPDPEventEmitter = (DeviceDetailsResult) => {
  const cleanUpEmitterFFlag = /true/i.test(getAssistedCradlePropertyV2(['cleanUpEmitterFFlag'])?.[0]);

  useEffect(() => {
    const handleVzdlData = (vzdlData) => {
      if (vzdlData === 'true') {
        const details = {
          PAGE_LOADED: 'true',
          CUSTOM_EVENT: 'prodView',
        };

        Emitter.emit('PAGE_LOADED', details);

        Emitter.removeAllListeners('WRITE_VZDL_DATA');
      }
    };
    Emitter.on('WRITE_VZDL_DATA', handleVzdlData);
    return () => {
      cleanUpEmitterFFlag && Emitter.off('WRITE_VZDL_DATA', handleVzdlData);
    };
  }, []);
  useEffect(() => {
    if (DeviceDetailsResult.isSuccess) {
      Emitter.emit('WRITE_VZDL_DATA', 'true');
    }
  }, [DeviceDetailsResult.isSuccess]);

  return null;
};

export default RegisterPDPEventEmitter;
