/* eslint-disable no-nested-ternary */
import React, { useState, useEffect, useRef, useCallback, memo } from 'react';
import { getQueryParamByName, getUIContextPathBAU, isProd } from 'onevzsoemfecommon/Helpers';
import { isMobile } from 'onevzsoemfecommon/Helpers/useragent';
import Emitter from 'onevzsoemfeframework/Emitter';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import * as appLoaderActions from 'onevzsoemfecommon/AppLoaderActions';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { sendCustomEvent } from 'onevzsoemfeframework/Tagging';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Title } from '@vds/typography';
import { rfexMfeFlowFlag } from 'onevzsoemfecommon/Helpers/common_functions';
import { isVbg } from 'onevzsoemfeframework/VbgAemUtil';
import {
  EquipOffers,
  MTN_TYPE_PRE_TO_POST,
  MTN_TYPE_YAHOO,
  MTN_TYPE_VISIBLE,
  MTN_TYPE_HARMONY,
  carrierLockResponseText,
} from '../../components/constants/DeviceConstants';
import { getFilteredCategory } from '../../modules/utils';
import GridwallContainer from './GridwallContainer';
import GridwallApiCallHook from './GridwallApiCallHook';
import { PaddingTop8 } from '../../components/CombinedGridwall/FlexGlobalStyledConstants';
import getPDPEnable from '../../modules/utils/getPDPEnable';
import {
  inDirectValidateDeviceSimIdPayload,
  checkDeviceSimCompatibility,
  initiateDeviceSimCompatibilityCheck,
  isDWOSAllowed,
  refundExchangeFlowIntent,
} from '../../components/FlexPDP/pdputils';
import { isVbgFwaMLOrderingFFlag } from '../../modules/utils/vbgUtils';

let navigate = '';

function useNavigateMFE() {
  navigate = useNavigate();
}

const Gridwall = memo(() => {
  const [productList, setProductList] = useState(null);
  const [trialDeviceDetail, setTrialDeviceDetail] = useState();
  const [deviceCategory, setDeviceCategory] = useState('');
  const [toggleOptions, setToggleOptions] = useState({});
  const [activeMtn, setActiveMtn] = useState(
    sessionStorage.getItem('activeMTN') || getQueryParamByName('activeMtn') || sessionStorage.getItem('tagActiveMtn')
  );
  const [devicesToCompare, setDevicesToCompare] = useState([]);
  const [showCompareDevicesModalFlag, setShowCompareDevicesModalFlag] = useState(false);
  const [showCompareData, setShowCompareData] = useState();
  const {
    CustomerProfileResult,
    CartDetailsResult,
    MyOffers,
    getCompareList,
    CompareListResult,
    validateDeviceSimIdRequestBody,
    ValidateDeviceSimIdResult,
    eSimDetailsRequestBody,
    eSimDetailsResult,
    getProducts,
    ProductListResult,
    getTrialDeviceDetail,
    TrialDeviceDetailsResult,
    removeSecondNumberDetails,
  } = GridwallApiCallHook();
  const [validateDeviceSimIdPayload, setValidateDeviceSimIdPayload] = useState({});
  const [ByodCheck, setByodCheck] = useState(false);
  const [prospectByodFlow, setProspectByodFlow] = useState(false);
  const [showProspectTile, setShowProspectTile] = useState(true);
  const [showSUGConsent, setShowSUGConsent] = useState(false);
  const [isEntiModalVisible, setIsEntiModalVisible] = useState(false);
  const [devicePayload, setDevicePayload] = useState({});
  const [scanCheck, setScanCheck] = useState('');
  const [popUp, setPopUp] = useState(false);
  const [immediateCall, setImmediateCall] = useState(false);
  const dispatch = useDispatch();
  const [scrolled, setScrolled] = useState(0);
  const [isLoadMore, setLoadMore] = useState('');
  const compareModalWrapperRef = useRef(null);
  const landingLines = CustomerProfileResult.data?.data?.customer?.billAccounts?.[0]?.mtns;
  const orderDetails = CartDetailsResult?.data?.data?.cart?.orderDetails;
  const [isCloseByod, setIsCloseByod] = useState(false);
  const [fiveGExistingActiveLine, setFiveGExistingActiveLine] = useState(false);
  const [showCarrierLockPopup, setShowCarrierLockPopup] = useState(false);
  const offers = MyOffers?.data;
  const [
    enableGridwallPersonalization,
    enableGridwallPersonalizationNSE,
    isGridwallCacheEnabled,
    isGWByodEUPEnabled,
    skipIccidCall,
    disableEsimAtLocalInventory,
    pearlBYODFlow,
    deviceActiveCheck,
    deviceActiveLoanCheck,
    devicePreorderCheck,
    iccidStatusCheck,
    bestBuyIntegrationFFlag,
    dwosIndirectFFlag,
  ] = getAssistedCradlePropertyV2([
    'gridwallPersonalizationFFlag',
    'gridwallPersonalizationNseFFlag',
    'isGridwallCacheEnabled',
    'isGWByodEUPEnabled',
    'skipIccidCall',
    'disableEsimAtLocalInventory',
    'pearlBYODFlow',
    'deviceActiveCheck',
    'deviceActiveLoanCheck',
    'devicePreorderCheck',
    'iccidStatusCheck',
    'bestBuyIntegrationFFlag',
    'dwosIndirectFFlag',
  ]);
  const skipICCIDFFlag = /true/i.test(getAssistedCradlePropertyV2(['skipICCIDFFlag'])?.[0]);
  const cleanUpEmitterFFlag = /true/i.test(getAssistedCradlePropertyV2(['cleanUpEmitterFFlag'])?.[0]);
  const isDwosIndirect = /true/i.test(dwosIndirectFFlag);
  const [isDWOS, setIsDWOS] = useState(isDWOSAllowed(dwosIndirectFFlag, getQueryParamByName('isDWOS')));
  const ispdpenable = getPDPEnable();
  console.log(isGWByodEUPEnabled);
  const totalLines = CartDetailsResult?.data?.data?.cart?.lineDetails?.lineInfo || [];
  const selectedLine =
    totalLines?.length > 0 &&
    totalLines?.filter(
      (item) =>
        (item.mobileNumber === activeMtn && item?.lineActivityType !== 'DEO') ||
        (isDWOS && item?.lineActivityType === 'DEO'),
    );
  const lineActivityType = selectedLine?.[0]?.lineActivityType;
  const installmentTerm = selectedLine?.[0]?.installmentInfo?.installmentTerm;
  const cartItemsForLine = selectedLine?.[0]?.itemsInfo?.[0]?.cartItems?.cartItem || [];
  const mtnData = CustomerProfileResult?.customer?.billAccounts?.[0]?.mtns;
   /* istanbul ignore next */
  const landingMtn = mtnData?.filter((mtnList) => mtnList.mtn === activeMtn);  
  useEffect(() => {
      /* istanbul ignore next */
    const handleUpdateDwos = (value) => {
    if (isDwosIndirect) {
      setIsDWOS(value);
    }
  }
    Emitter.on('Update_dwos', handleUpdateDwos);
    return () => {
      cleanUpEmitterFFlag && Emitter.off('Update_dwos', handleUpdateDwos);
    };
  }, []);
  // const isGWByodEUPEnabledFlag = /true/i.test(isGWByodEUPEnabled);
  const isGWByodEUPEnabledFlag = true;
  const [upcCode, setUpcCode] = useState('');
  const upcCodeQueryParam = /true/i.test(bestBuyIntegrationFFlag) && upcCode !== '' ? `&upcCodeValue=${upcCode}` : '';

  const getUpdatedFilteredCategory = (categoryFilterValue, is5gLine) => {
  if (isVbg()) {
    let activeLineInCart = totalLines?.filter((line) => line?.mobileNumber === activeMtn);
    const isFiveGDevice = activeLineInCart?.length > 0 && activeLineInCart?.some((line) => line?.deviceTypeSelected === '5G Internet');
    if (isFiveGDevice) {
        return '5g-Internet';
    } else {
        return getFilteredCategory(categoryFilterValue, is5gLine);
      }
    } else {
      return getFilteredCategory(categoryFilterValue, is5gLine);
    }
  };

  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }

  const getTotal5GLinesCount = (totalLines) => {
    const FIVE_G_INTERNET_TYPE = '5G Internet';
    const fiveGLines = totalLines?.filter(line => line?.deviceTypeSelected === FIVE_G_INTERNET_TYPE);
    return fiveGLines?.length || 0;
  }

  const get5gFlow = (vbgFwaMLOrderingFFlag, fiveGLinesCount, isFiveGDevice) => {
    if(vbgFwaMLOrderingFFlag) {
      if (fiveGLinesCount > 1 && isFiveGDevice) {
        return "multiline";
      }
      if (isFiveGDevice) {
        return "singleline";
      }
      return "";
    }
    return "";
  }

  const isFiveGDeviceSelected = (activeLineInCart) => {
    if(activeLineInCart?.length > 0) {
      return activeLineInCart?.some((line) => line?.deviceTypeSelected === '5G Internet');
    }
    return false;
  }

  useEffect(() => {
    let isFiveGExistingLine = false;
    if (CustomerProfileResult.isSuccess) {
      const landingLinesData = CustomerProfileResult.data?.data?.customer?.billAccounts?.[0]?.mtns;
      /* istanbul ignore next */
      if (Array.isArray(landingLinesData)) {
        isFiveGExistingLine = landingLinesData.find((existingLine) => {
          const deviceName =
            Array.isArray(existingLine?.equipmentInfos) &&
            existingLine?.equipmentInfos[0]?.deviceInfo?.productDisplayName;
          if (existingLine?.mtn === activeMtn && deviceName === 'Verizon Internet Gateway') {
            return true;
          }
          return false;
        });
        setFiveGExistingActiveLine(isFiveGExistingLine);
      }
    }
    if (!isFiveGExistingLine) {
      const deviceFilterType =
        totalLines?.length > 0
          ? totalLines?.find((line) => line?.mobileNumber === activeMtn)?.deviceCategoryName ||
            totalLines?.find((line) => line?.mobileNumber === activeMtn)?.deviceTypeSelected ||
            ''
          : '';

      const offerDeviceCategory =
        lineHasOffer && !is5gLine
          ? lineOffer?.[0]?.deviceCategory
            ? `${lineOffer?.[0]?.deviceCategory}s`
            : ''
          : deviceFilterType || '';
      const isWifiFlow = sessionStorage.getItem('fiveGHomeInternetSelectedFlow') === 'WiFi-Backup';
      
      const vbgFwaMLOrderingFFlag = isVbgFwaMLOrderingFFlag();
      const fiveGLinesCount = getTotal5GLinesCount(totalLines);
      let activeLineInCart = totalLines?.filter((line) => line?.mobileNumber === activeMtn);
      const isFiveGDevice = isFiveGDeviceSelected(activeLineInCart);
      const vbg5gLineCount = get5gFlow(vbgFwaMLOrderingFFlag, fiveGLinesCount, isFiveGDevice);
      
      const initialRequestBody = {
        data: {
          isPromoFilterDisabled: false,
          isWifibackupFlow: isWifiFlow,
          enableGridwallPersonalization: /true/i.test(enableGridwallPersonalization),
          enableGridwallPersonalizationNSE: /true/i.test(enableGridwallPersonalizationNSE),
          isGridwallCacheEnabled: /true/i.test(isGridwallCacheEnabled),
          enableAssistedTagging: true,
          productType: 'device',
          processingMTN: activeMtn || '',
          vbg5gLineCount: vbg5gLineCount,
          customerLoggedInOrNot: false,
          prepayCart: false,
          ...(isDWOS === true ? { calledFrom: 'DWOS' } : {}),
          filterSortData: {
            filters: [
              {
                type: 'Category',
                values: [getUpdatedFilteredCategory(deviceCategory || offerDeviceCategory, is5gLine)],
              },
              {
                type: 'Brand',
                values: [''],
              },
              {
                type: 'OS',
                values: [''],
              },
            ],
          },
          paginationData: {
            offset: 0,
            recPerPage: 24,
          },
        },
      };
      const isTanglewoodBundle = sessionStorage.getItem('tanglewoodBundleFlowSession');
      if (isTanglewoodBundle && selectedLine[0]?.tanglewoodSelected === 'Y') {
        const bundleName = sessionStorage.getItem('bundles');
        const tanglewoodBundle = {
          type: 'eligibleBundles',
          values: [bundleName],
        };
        initialRequestBody.data.filterSortData.filters.push(tanglewoodBundle);
      }
      getProducts({ body: initialRequestBody, spinner: true }, false);
      setrequestBody(initialRequestBody);
      if (
        CartDetailsResult &&
        CartDetailsResult?.data?.data?.cart?.orderDetails?.flowType === 'DVM_CONVERSION' &&
        pearlBYODFlow
      ) {
        getTrialDeviceDetail({ body: {}, spinner: true }, false);
      }
    }
  }, [CustomerProfileResult.isSuccess, activeMtn, deviceCategory, CartDetailsResult?.isFetching]);

  useEffect(() => {
    if (TrialDeviceDetailsResult && TrialDeviceDetailsResult?.data) {
      const data = TrialDeviceDetailsResult?.data?.customer?.billAccounts?.[0]?.mtns?.[0];
      const newData = TrialDeviceDetailsResult?.data?.data?.customer?.billAccounts?.[0]?.mtns?.[0];
      const trialData = newData || data;
      setTrialDeviceDetail({ tdd: trialData });
    }
  }, [TrialDeviceDetailsResult, TrialDeviceDetailsResult?.data]);

  useEffect(() => {
    if (ProductListResult?.isSuccess && ProductListResult?.data) {
      const gridWall = ProductListResult?.data?.data?.gridWall;
      const newProductList = gridWall?.productList ? gridWall?.productList : gridWall?.deviceSku?.parentProducts || [];
      if (isLoadMore && ProductListResult?.data?.data?.gridWall?.pagination?.totalNumberRecords > 23) {
        setProductList((prevState) => {
          const existingProductList = prevState?.gridWall?.productList || [];
          return {
            ...ProductListResult?.data?.data,
            gridWall: { ...gridWall, productList: [...existingProductList, ...newProductList] },
          };
        });
      } else if (gridWall?.productList || gridWall?.deviceSku) {
        setProductList({
          ...ProductListResult?.data?.data,
          gridWall: { ...gridWall, productList: newProductList },
        });
      } else {
        setProductList(null);
      }

      dispatch(appLoaderActions.hide());
    }
  }, [ProductListResult?.isSuccess, ProductListResult?.data]);

  useEffect(() => {
    if (ProductListResult?.status === 'fulfilled' && ProductListResult?.data) {
      Emitter.emit('GRIDWALL_MFE', 'true');
    }
  }, [ProductListResult]);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(compareModalWrapperRef.current?.scrollTop > 10);
    };
    if (showCompareDevicesModalFlag === true && compareModalWrapperRef.current != null) {
      compareModalWrapperRef.current?.addEventListener('scroll', handleScroll);
      return () => {
        compareModalWrapperRef.current?.removeEventListener('scroll', handleScroll);
      };
    }
  }, [showCompareDevicesModalFlag]);

  useEffect(() => {
    let category = '';
    Emitter.on('Input_From_Line_Details', (newValue) => {
      console.log('EVENT_EMITTER', 'Consume', 'Input_From_Line_Details', newValue);
      const gridWallActiveMTN = sessionStorage.getItem('activeGridwallMTN');
      setLoadMore('');
      resetToggleOptions();
      if (gridWallActiveMTN === null && newValue?.activeMtn === activeMtn) {
        return;
      }
      if (gridWallActiveMTN === newValue?.activeMtn) {
        return;
      }
      if (newValue?.activeMtn) {
        setActiveMtn(newValue.activeMtn);
      }

      sessionStorage.setItem('activeGridwallMTN', newValue?.activeMtn);
      if (newValue?.deviceCategory?.smartphone) {
        category = 'Smartphones';
      } else if (newValue?.deviceCategory?.tablet) {
        category = 'Tablets';
      } else if (newValue?.deviceCategory?.basicphone) {
        category = 'Basic Phones';
      } else if (newValue?.deviceCategory?.connectedDevice) {
        category = 'Connected Devices';
      } else if (newValue?.deviceCategory?.internetDevice) {
        category = 'Internet Devices';
      } else if (newValue?.deviceCategory?.homePC) {
        category = 'Home/Office Solutions';
      }
      setDeviceCategory(newValue?.deviceTypeSelected || category);
    });
    return () => {
      Emitter.off('Input_From_Line_Details');
      dispatch(appMessageActions.clearAppMessages());
    };
  }, []);

  useEffect(() => {
    Emitter.emit('ProspectBYODTile', prospectByodFlow);
  }, [prospectByodFlow]);

  useEffect(() => {
    setShowCompareData(CompareListResult?.data?.data);
    if (CompareListResult?.data?.data?.compareList?.length > 0 && CompareListResult?.data?.data?.compareList[1]) {
      compareDevicesModalFlag(true);
    } else {
      compareDevicesModalFlag(false);
    }
  }, [CompareListResult]);

  useEffect(() => {
    if (isByod) {
      setByodCheck(false);
      setProspectByodFlow(true);
      setShowProspectTile(true);
      closeCompareDevicesoptions();
    } else {
      setByodCheck(false);
      setProspectByodFlow(false);
      setShowProspectTile(true);
      closeCompareDevicesoptions();
    }
  }, [activeMtn]);

  useEffect(() => {
    console.log('lineActivityType=> ', lineActivityType);
    if (lineActivityType === 'AAL' || lineActivityType === 'NSE') {
      if (isByod) {
        setProspectByodFlow(true);
      } else {
        setProspectByodFlow(false);
        setShowProspectTile(true);
      }
    } else if (lineActivityType?.includes('BYOD') && hasIteminCart) {
      setShowProspectTile(false);
      setProspectByodFlow(false);
    } else if (lineActivityType?.includes('BYOD') && !hasIteminCart) {
      setShowProspectTile(true);
      if (isByod) {
        setProspectByodFlow(true);
      } else {
        setProspectByodFlow(false);
      }
    }
  }, [lineActivityType]);

  useEffect(() => {
    UpdateBYODCheck();
  }, [isCloseByod]);

  useEffect(() => {
    if (/true/i.test(sessionStorage.getItem('isFromBack'))) {
      removeSecondNumberDetails({ body: { isDualNumberFlow: true } });
      sessionStorage.setItem('isFromBack', false);
    }
  }, []);

  const cartItem = cartItemsForLine?.length > 0 && cartItemsForLine.find((item) => item?.cartItemType === 'DEVICE');
  const deviceItemInfo =
    cartItemsForLine &&
    cartItemsForLine.length > 0 &&
    cartItemsForLine.filter((item) => item && item.cartItemType === 'DEVICE');
  const deviceDetailsIncart = deviceItemInfo?.[0] ?? {};
  // const { deviceId = '' } = deviceDetailsIncart;
  const { deviceIdInCart = '' } = deviceDetailsIncart;

  const simItemInfo =
    cartItemsForLine &&
    cartItemsForLine.length > 0 &&
    cartItemsForLine.filter((item) => item && item.cartItemType === 'SIM');
  const simDetailsIncart = simItemInfo?.[0] ?? {};

  const hasIteminCart = !!cartItem;
  const compareDevicesModalFlag = (data) => {
    setShowCompareDevicesModalFlag(data);
  };
  const simIdInCart = () => {
    const { simId = '', activeCartandCase = {}, cartDetails = {} } = simDetailsIncart;
    if (activeCartandCase?.cartId === cartDetails?.lineDetails?.cartId) {
      return simId;
    }
    return '';
  };
  let activeLine = totalLines?.filter((line) => line?.mobileNumber === activeMtn);

  if (activeLine?.length < 1) {
    activeLine = landingLines?.filter((line) => line?.mtn === activeMtn);
  }
  const is5gLine = activeLine?.length > 0 && activeLine[0].deviceTypeSelected === '5G Internet';
  // const isDWOS = !!getQueryParamByName('isDWOS');
  const isStackbleOffer = () => {
    const filteredOffer = offers?.lines?.filter(
      (line) =>
        line?.mtn?.toLowerCase()?.replace(/\s/g, '') === activeLine?.[0]?.mobileNumber?.toLowerCase() ||
        line?.mtn?.toLowerCase()?.replace(/\s/g, '') === activeLine?.[0]?.lineNumber?.toLowerCase() ||
        line?.mtn?.toLowerCase()?.replace(/\s/g, '') === activeLine?.[0]?.mtn?.toLowerCase() ||
        line?.mtn?.toLowerCase()?.replace(/\s/g, '') === activeMtn,
    );
    const lineHasOffers = !!(filteredOffer?.length && filteredOffer?.length > 0);
    let stackedOffers = [];
    if (lineHasOffers && filteredOffer?.[0]?.offers?.length > 1) {
      stackedOffers = filteredOffer?.[0]?.offers?.filter((item) => EquipOffers?.includes(item?.offerSubType));
    }
    const isOffersStacked = stackedOffers?.length > 1;
    return isOffersStacked;
  };

  const lineOffer = offers?.lines?.filter(
    (line) =>
      line?.mtn?.toLowerCase()?.replace(/\s/g, '') === activeLine?.[0]?.mobileNumber?.toLowerCase() ||
      line?.mtn?.toLowerCase()?.replace(/\s/g, '') === activeLine?.[0]?.lineNumber?.toLowerCase() ||
      line?.mtn?.toLowerCase()?.replace(/\s/g, '') === activeLine?.[0]?.mtn?.toLowerCase() ||
      line?.mtn?.toLowerCase()?.replace(/\s/g, '') === activeMtn?.toLowerCase(),
  );

  const isExistingCustomer = CustomerProfileResult?.data?.data?.customer?.billAccounts?.[0]?.mtns?.length > 0;
  const isExistingCustomerNewLine = !!activeLine?.[0]?.lineNumber?.toLowerCase()?.includes('newline');
  const isOCToGridwallEnabled = true; // props?.appPropertiesFromSessionStorage?.isOCToGridwallEnabled === 'TRUE';
  const intentCheck = isExistingCustomer && isExistingCustomerNewLine ? !!isOCToGridwallEnabled : true;

  // if line is AAL, isOCToGridwallEnabled needs to be considered
  const lineHasOffer = !!(lineOffer?.length && lineOffer?.length > 0);
  const isByod = !!(lineHasOffer && lineOffer?.[0]?.offers?.[0]?.offerSubType === 'BYOD');

  const rebeatOfferId =
    lineHasOffer && lineOffer?.[0]?.offers?.[0]?.offerSubType === 'Virtual Reward'
      ? lineOffer?.[0]?.offers?.[0]?.sku
      : null;
  let rebeatElligible = false;
  offers?.proposition?.forEach((item) => {
    if (item?.soiEngagementId && rebeatOfferId) {
      if (item?.soiEngagementId === rebeatOfferId) {
        item?.dynamicAttrList?.forEach((data) => {
          if (data?.attrId === 'isPortIn') {
            if (!data?.value || data?.value === 'false') {
              rebeatElligible = true;
            }
          }
        });
      }
    } else {
      return false;
    }
  });

  const byodCheck = !!(lineHasOffer && lineOffer?.[0]?.offers?.[0]?.offerSubType !== 'BYOD');
  const nationalCheck = !!(
    lineHasOffer &&
    (offers?.offerSourceSystem?.toLowerCase()?.includes('national') ||
      offers?.offerSourceSystem?.toLowerCase()?.includes('prospect'))
  );

  const toggleValue =
    toggleOptions?.[activeMtn] !== undefined && activeMtn
      ? toggleOptions?.[activeMtn]
      : !!(lineOffer?.length && lineOffer?.length > 0);

  // Need to handle 5g device condition

  const updateToggleOptions = (data, mtn) => {
    const tempToggleObject = { ...toggleOptions };
    tempToggleObject[mtn] = data;
    setToggleOptions(tempToggleObject);
  };

  const resetToggleOptions = () => {
    setToggleOptions({});
  };

  const [requestBody, setrequestBody] = useState(null);

  const getProductList = (
    isToggleOff = false,
    start = 0,
    end = 24,
    categoryValue = '',
    brandValue = '',
    osValue = '',
    sortValue = 'Feature',
    loadingMore = false,
    sortOptions = {},
  ) => {
    if (!loadingMore) sessionStorage.setItem('scrollY', 0);
    let prepareRequestBody = {};
    const deviceFilterType =
      totalLines?.length > 0
        ? totalLines?.find((line) => line?.mobileNumber === activeMtn)?.deviceCategoryName ||
          totalLines?.find((line) => line?.mobileNumber === activeMtn)?.deviceTypeSelected ||
          ''
        : '';

    const offerDeviceCategory =
      lineHasOffer && !is5gLine
        ? lineOffer?.[0]?.deviceCategory
          ? `${lineOffer[0]?.deviceCategory}s`
          : ''
        : deviceFilterType || '';
    const categoryFilterValue = categoryValue || offerDeviceCategory || '';
    const isWifiFlow = sessionStorage.getItem('fiveGHomeInternetSelectedFlow') === 'WiFi-Backup';
    prepareRequestBody = {
      data: {
        isPromoFilterDisabled: !(
          lineHasOffer &&
          isToggleOff &&
          byodCheck &&
          nationalCheck &&
          !isDWOS &&
          !rebeatElligible &&
          intentCheck &&
          !is5gLine &&
          !isStackbleOffer()
        ),
        isWifibackupFlow: isWifiFlow,
        correlationId: '',
        isGridwallCacheEnabled: /true/i.test(isGridwallCacheEnabled),
        enableGridwallPersonalization: /true/i.test(enableGridwallPersonalization),
        enableGridwallPersonalizationNSE: /true/i.test(enableGridwallPersonalizationNSE),
        enableAssistedTagging: true,
        productType: 'device',
        processingMTN: activeMtn || '',
        customerLoggedInOrNot: false,
        compatibleProductId: '',
        prepayCart: false,
        filterSortData: {
          sortOption:
            sortValue === 'Reset'
              ? ''
              : sortValue === 'Feature'
                ? sortOptions[activeMtn]
                  ? sortOptions[activeMtn]
                  : ''
                : sortValue,
          filters: [
            {
              type: 'Category',
              values: [getUpdatedFilteredCategory(categoryFilterValue, is5gLine)],
            },
            {
              type: 'Brand',
              values: [brandValue],
            },
            {
              type: 'OS',
              values: [osValue],
            },
          ],
        },
        paginationData: {
          offset: start,
          recPerPage: end,
        },
      },
    };
    if (categoryValue && categoryValue === 'Certified Pre-owned') {
      const preOwnedobj = {
        type: 'Special_Offers',
        values: ['Certified Pre-owned'],
      };
      prepareRequestBody.data.filterSortData.filters.push(preOwnedobj);
    }
    getProducts({ body: prepareRequestBody }, true);
    setrequestBody(prepareRequestBody);
  };
  const handleScroll = (event) => {
    const griddiv = event.target;
    const scrollHeight = Math.floor(griddiv.scrollHeight);
    const scrollTop = Math.floor(griddiv.scrollTop);
    const clientHeight = Math.floor(griddiv.clientHeight);
    const scrollPercentage = (scrollTop / (scrollHeight - clientHeight)) * 100;

    if (!isProd()) {
      sessionStorage.setItem('griddiv.scrollHeight', scrollHeight);
      sessionStorage.setItem('griddiv.scrollTop', scrollTop);
      sessionStorage.setItem('griddiv.clientHeight', clientHeight);
    }
    if (scrollPercentage >= 85) {
      const bottom = JSON.parse(sessionStorage.getItem('scrollY')) || 0;
      const scrollY = bottom + griddiv.clientHeight;
      setLoadMore(griddiv.scrollHeight);
      sessionStorage.setItem('scrollY', scrollY);
    }
  };
  const gridRef = useCallback((node) => {
    if (node != null) {
      if (isMobile()) {
        node.addEventListener('touchmove', handleScroll);
        node.addEventListener('scroll', handleScroll);
      } else {
        node.addEventListener('scroll', handleScroll);
      }
    }
  }, []);

  const hideCompareDevicesModal = () => {
    setShowCompareDevicesModalFlag(false);
  };

  const handleCompareCheckboxChange = (productId) => {
    setDevicesToCompare((prevState) => [...prevState, productId]);
  };
  const handleRemoveProductFromCompareInGW = (productId) => {
    const newDeviceCompareOptions = devicesToCompare.filter((product) => product.productId !== productId);
    setDevicesToCompare(newDeviceCompareOptions);
  };

  const handleRemoveProductFromFooter = (productId) => {
    const newDeviceCompareOption = devicesToCompare?.filter((product) => product?.productId !== productId);
    setDevicesToCompare(newDeviceCompareOption);
  };

  const handleRemoveProductFromCompare = (productId) => {
    const newDeviceCompareOptions = devicesToCompare?.filter((product) => product?.productId !== productId);
    setDevicesToCompare(newDeviceCompareOptions);
    if (newDeviceCompareOptions?.length < 2) {
      setShowCompareDevicesModalFlag(false);
    }
    compareDevices(newDeviceCompareOptions);
  };

  const closeCompareDevicesoptions = () => {
    setDevicesToCompare([]);
  };

  const compareDevices = (newDeviceCompareOptions) => {
    const deviceToCompareData = newDeviceCompareOptions?.length > 0 ? newDeviceCompareOptions : devicesToCompare;
    const compDevicesArray = [];
    deviceToCompareData.forEach((product) => compDevicesArray.push(product.productId));

    const requestData = {
      data: {
        productType: 'device',
        compatibleProductId: '',
        compDevices: compDevicesArray,
      },
    };
    getCompareList({ body: requestData }, false);
  };

  const UpdateBYODCheck = () => {
    if (isByod && !cartItem && !isCloseByod) {
      setProspectByodFlow(true);
    } else {
      setProspectByodFlow(false);
      setShowProspectTile(true);
    }
  };

  const toggleSUGConsent = (status) => {
    setShowSUGConsent(typeof status !== 'undefined' ? status : !showSUGConsent);
  };

  const handleByodflag = (isexsistingline, categoryValue) => {
    setByodCheck(!ByodCheck);
    setProspectByodFlow(!ByodCheck);
    setShowProspectTile(ByodCheck);
    setDeviceCategory(categoryValue);
    if (SecNumFlow) {
      navigate(`${getUIContextPathBAU()}/landing.html`);
    } else if (!isexsistingline) {
      const vzdl = window?.vzdl || {};
      if (vzdl?.page) {
        vzdl.page.detail = !ByodCheck ? `CombinedGridwall | Customer Equipment Modal` : `CombinedGridwall_device`;
        if (!ByodCheck) {
          vzdl.page.flow = vzdl.page.flow === 'AAL' ? 'AALBYOD' : 'NSO';
        } else {
          vzdl.page.flow = vzdl.page.flow === 'AALBYOD' ? 'AAL' : 'NSE';
        }
      }
      window.vzdl = vzdl;
      sendCustomEvent('openView', window?.vzdl);
    } else if (!hasIteminCart) {
      const billAccounts = CustomerProfileResult?.data?.data?.customer?.billAccounts?.[0]?.mtns;
      /* istanbul ignore next */
      const mtnInfo = billAccounts?.length > 0 && billAccounts.find((ele) => ele.mtn === activeMtn);
      const { deviceInfo = {}, simInfo = {} } = mtnInfo && mtnInfo.equipmentInfos && mtnInfo.equipmentInfos[0];
      navigate(
        `${getUIContextPathBAU()}/product-detail.html?fromPage=combinedgridwall&offerEligible=Y&deviceId=${
          deviceInfo?.deviceId
        }&deviceSKU=${deviceInfo?.deviceSku}&isByodUpdate=true&isEditAndView=true&selectedInsuranceSorId=&simId=${
          simInfo?.simId
        }&activeMtn=${activeMtn}&prospectByodFlow=true&productId=`,
      );
    } else {
      const simInfoFind = cartItemsForLine?.find((rec) => rec.cartItemType === 'SIM');
      const deviceInfoFind = cartItemsForLine?.find((rec) => rec.cartItemType === 'DEVICE');
      const deviceIdParams = deviceInfoFind?.deviceId ? `&deviceId=${deviceInfoFind?.deviceId}` : '';
      const simIdParams = simInfoFind?.simId ? `&simId=${simInfoFind?.simId}` : '';
      const deviceskuparam = deviceInfoFind?.sorId || deviceInfoFind?.skuId || '';
      const productIdparam = deviceInfoFind?.productId;
      navigate(
        `${getUIContextPathBAU()}/product-detail.html?fromPage=combinedgridwall&offerEligible=Y${deviceIdParams}&deviceSKU=${deviceskuparam}&isByodUpdate=true&isEditAndView=true&selectedInsuranceSorId=${simIdParams}&activeMtn=${activeMtn}&prospectByodFlow=true&productId=${productIdparam}`,
      );
    }
  };

  const SecNumFlow = Boolean(getQueryParamByName('SecondNumber')) || false;
  const primaryMtnofSecondNumber = getQueryParamByName('primaryMtn') || '';
  const customerType = getQueryParamByName('customerType') || sessionStorage.getItem('customerType');
  const isByodUpdate = !!getQueryParamByName('isByodUpdate');
  const isFromCPE = getQueryParamByName('isFromCPE');
  const isLocal = getQueryParamByName('isLocal');
  const scanFromLanding = Boolean(getQueryParamByName('scanFromLanding'));
  const deviceIdFromQuery = isByodUpdate && getQueryParamByName('deviceId') ? getQueryParamByName('deviceId') : '';
  const simIdFromQuery = isByodUpdate && getQueryParamByName('simId') ? getQueryParamByName('simId') : '';
  const cartLines = totalLines;
  const lineInformation = cartLines?.filter((line) => line.mobileNumber === activeMtn);
  const fiveGDetails =
    activeLine?.length > 0 &&
    activeLine?.filter((line) => line?.deviceTypeSelected && line?.deviceTypeSelected === '5G Internet');
  const isFiveG = fiveGDetails?.length > 0;
  const intendType =
    lineInformation?.length > 0 && lineInformation?.[0]?.lineActivityType
      ? lineInformation?.[0]?.lineActivityType
      : 'EUP';
  const isFromCart = !!getQueryParamByName('deviceFromCart');
  const isFrom = getQueryParamByName('isByodUpdate') ? 'isByodUpdate' : isFromCart ? 'deviceFromCart' : 'isLocal';

  const customerDetails = CustomerProfileResult?.data?.data;
  const channel = customerDetails?.customer?.channel;
  const isIndirect = channel?.includes('OMNI-INDIRECT');
  const existingLineInfo = CustomerProfileResult?.data?.data?.customer?.billAccounts?.[0]?.mtns?.find(
    (line) => line?.mtn === activeMtn,
  );
  const existingActiveMtnEqpInfo = existingLineInfo?.equipmentInfos?.[0] || {};
  const isBYODCarrierLockFFlagEnabled =
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.isBYODCarrierLockFFlag === 'TRUE';

  useEffect(() => {
    if (isIndirect && ValidateDeviceSimIdResult.status === 'fulfilled' && immediateCall) {
      validateDeviceSimId();
      setImmediateCall(false);
    }
    if (ValidateDeviceSimIdResult?.status === 'fulfilled' && !showCarrierLockPopup) {
      const deviceInfo = ValidateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo;
      if (
        isBYODCarrierLockFFlagEnabled &&
        deviceInfo?.softMessages?.length > 0 &&
        deviceInfo?.softMessages?.indexOf(`${carrierLockResponseText}`) > -1
      ) {
        setShowCarrierLockPopup(true);
      }
    }
  }, [immediateCall, ValidateDeviceSimIdResult]);

  const validateDeviceSimIdRequest = (payload) => {
    // const isRfexFlow = sessionStorage.getItem('refundexchange') === 'true' || false;
    const isPrepayCart = orderDetails?.isPrePayCart || 'N';
    const isCustomerProvidedEquipment = !(
      payload.isCustomerProvidedEquipment === null || payload.isCustomerProvidedEquipment === false
    );
    let lineSimDetailsFromLanding =
      lineInformation?.length > 0 &&
      lineInformation[0].equipmentInfos &&
      lineInformation[0].equipmentInfos.length > 0 &&
      lineInformation[0].equipmentInfos[0].simInfo &&
      lineInformation[0].equipmentInfos[0].simInfo.simId &&
      lineInformation[0].equipmentInfos[0].simInfo.simId !== '' &&
      lineInformation[0].equipmentInfos[0].simInfo.simId !== null &&
      lineInformation[0].equipmentInfos[0].simInfo.simId !== undefined
        ? lineInformation[0].equipmentInfos[0].simInfo.simId
        : '';

    if (isIndirect) {
      lineSimDetailsFromLanding = existingActiveMtnEqpInfo?.simInfo?.simId;
    }

    const lineDeviceDetailsFromLanding =
      lineInformation &&
      lineInformation.length > 0 &&
      lineInformation[0].equipmentInfos &&
      lineInformation[0].equipmentInfos.length > 0 &&
      lineInformation[0].equipmentInfos[0].deviceInfo &&
      lineInformation[0].equipmentInfos[0].deviceInfo.deviceId &&
      lineInformation[0].equipmentInfos[0].deviceInfo.deviceId !== '' &&
      lineInformation[0].equipmentInfos[0].deviceInfo.deviceId !== null &&
      lineInformation[0].equipmentInfos[0].deviceInfo.deviceId !== undefined
        ? lineInformation[0].equipmentInfos[0].deviceInfo.deviceId
        : '';

    const isNewLine = !!(intendType && intendType === 'AAL');
    const mtnType =
      activeLine?.length > 0 && activeLine?.[0]?.mtnDetails?.mtnType ? activeLine?.[0]?.mtnDetails?.mtnType : '';
    const flowType = payload.deviceFlow ? 'DEVICE' : payload.simId && payload.simId !== ' ' ? 'SIM' : 'DEVICE';
    const intentType = isCustomerProvidedEquipment ? 'BYOD' : isNewLine ? 'AAL' : 'EUP';
    const formattedDeviceId = payload.deviceId ? payload.deviceId : '';
    const formattedSimId = payload.simId ? payload.simId : '';
    const { cpSimCard } = payload;
    const { sendSimFromLanding } = payload;
    const { homeSalesAddress = {} } = CustomerProfileResult?.data?.data?.customer || {};
    const { bundles = [] } = homeSalesAddress;
    const carrierFromQuery = payload.carrier ? payload.carrier : '';
    const sku = payload.sku ? payload.sku : '';
    const smartIMEI = payload.smartIMEI || false;
    const simSku = payload.simSku ? payload.simSku : '';
    const cpeWthoutDevIdFlag = payload.cpeWthoutDevIdFlag ? payload.cpeWthoutDevIdFlag : false;
    const deviceNameFromQuery = payload.deviceName ? payload.deviceName : '';
    const validateDeviceRequestBody = {
      cartInfo: {
        creditAppNum: null, // Todo for PDP page
        processingMTN: payload?.mtn,
        ...(rfexMfeFlowFlag()
          ? {}
          : {
              intent:
                customerType === 'N' && isCustomerProvidedEquipment
                  ? 'NSEBYOD'
                  : customerType === 'N'
                    ? 'NSE'
                    : isPrepayCart === 'Y' && customerType !== 'N' && isCustomerProvidedEquipment
                      ? 'BYOD'
                      : isFiveG === true
                        ? '5GHome'
                        : isCustomerProvidedEquipment
                          ? 'BYOD'
                          : isNewLine
                            ? 'AAL'
                            : 'EUP',
            }),
        processStep: isCustomerProvidedEquipment ? 'BYODDeviceIDPage' : 'GridWallPDP',
        processAction: isFiveG === true ? 'validateGiftBoxId' : 'validateDeviceSim',
        action: '',
        locationCode: customerDetails?.customer?.orderLocationCode,
      },
      data: {
        lines: [
          {
            mtn: payload?.mtn,
            mtnType,
            eskuId: payload.eskuId || '',
            device:
              isFiveG === true && bundles && bundles?.bundleName?.includes('5GHomeSelfInstall')
                ? {
                    Flowtype: 'GIFTBOX',
                    giftbox: {
                      id: formattedDeviceId,
                    },
                  }
                : !cpeWthoutDevIdFlag
                  ? {
                      id: formattedDeviceId,
                      Flowtype: 'DEVICE',

                      CurrentId:
                        isByodUpdate === true &&
                        lineDeviceDetailsFromLanding &&
                        lineDeviceDetailsFromLanding !== '' &&
                        lineDeviceDetailsFromLanding !== formattedDeviceId
                          ? lineDeviceDetailsFromLanding
                          : deviceIdFromQuery,
                      isCustomerProvidedEquipment,
                      sku,
                      smartIMEI,
                      sim: {
                        id: formattedSimId,
                        sku: simSku,
                        isCustomerProvidedSIM: cpSimCard,
                        CurrentSimid:
                          sendSimFromLanding && sendSimFromLanding === true
                            ? lineSimDetailsFromLanding
                            : isByodUpdate === true
                              ? ''
                              : simIdFromQuery,
                      },
                    }
                  : cpeWthoutDevIdFlag &&
                      deviceNameFromQuery &&
                      carrierFromQuery &&
                      deviceNameFromQuery !== '' &&
                      carrierFromQuery !== ''
                    ? {
                        id: formattedDeviceId,
                        Flowtype: flowType,
                        CurrentId:
                          isByodUpdate === true &&
                          lineDeviceDetailsFromLanding &&
                          lineDeviceDetailsFromLanding !== '' &&
                          lineDeviceDetailsFromLanding !== formattedDeviceId
                            ? lineDeviceDetailsFromLanding
                            : deviceIdFromQuery,
                        isCustomerProvidedEquipment,

                        sku,
                        smartIMEI: true,
                        sorDisplayName: deviceNameFromQuery,
                        skuCarrier: carrierFromQuery,
                      }
                    : {
                        id: formattedDeviceId,
                        Flowtype: flowType,
                        CurrentId:
                          isByodUpdate === true &&
                          lineDeviceDetailsFromLanding &&
                          lineDeviceDetailsFromLanding !== '' &&
                          lineDeviceDetailsFromLanding !== formattedDeviceId
                            ? lineDeviceDetailsFromLanding
                            : deviceIdFromQuery,
                        isCustomerProvidedEquipment,
                        sku,
                        smartIMEI: smartIMEI || false,
                        sim: {
                          id: formattedSimId,
                          sku: simSku,
                          isCustomerProvidedSIM: cpSimCard,
                          CurrentSimid:
                            sendSimFromLanding && sendSimFromLanding === true
                              ? lineSimDetailsFromLanding
                              : isByodUpdate === true
                                ? ''
                                : simIdFromQuery,
                        },
                      },
          },
        ],
      },
      disableEsimAtLocalInventory: false,
      ...inDirectValidateDeviceSimIdPayload(
        deviceActiveCheck,
        deviceActiveLoanCheck,
        devicePreorderCheck,
        iccidStatusCheck,
        disableEsimAtLocalInventory,
      ),
    };
    validateDeviceRequestBody.cartInfo.intent = refundExchangeFlowIntent(validateDeviceRequestBody.cartInfo.intent);
    setDevicePayload(payload);
    setScanCheck(intentType);
    setValidateDeviceSimIdPayload(validateDeviceRequestBody);
    validateDeviceSimIdRequestBody({ body: validateDeviceRequestBody });
    setPopUp(!popUp);
  };

  const validateDeviceSimId = () => {
    const { data = {}, errors } = ValidateDeviceSimIdResult;
    const deviceInfo = !data.errors ? data?.serviceBody?.serviceResponse?.context?.deviceInfo : {};
    const payload = devicePayload;
    // const flowType = payload.deviceFlow ? 'DEVICE' : payload.simId && payload.simId !== ' ' ? 'SIM' : 'DEVICE';
    const mtnNotGenerated = activeMtn?.includes('newLine');
    // const queryParams = '?';
    // const redirectParams = queryParams.slice(0, -1);
    const compatibilityCheckParams = {
      isIndirect,
      intendType,
      isByodUpdate,
      deviceInfo,
      payload,
      previousPayload: validateDeviceSimIdPayload,
      validateDeviceSimIdRequest,
    };

    if (errors && errors.length > 0) {
      // 500 error scenario handling
      dispatch(appLoaderActions.hide());
      dispatch(appMessageActions.addAppMessage(errors[0].message, 'error'));
    } else if (data && data?.errors) {
      // Error scenario
      console.log('data - validateSimandDeviceId', data);
      const errormessage = data.errors[0].message;
      dispatch(appMessageActions.addAppMessage(errormessage, 'error'));
    } else if (
      deviceInfo &&
      deviceInfo.deviceId &&
      deviceInfo.deviceId.length < 15 &&
      deviceInfo.deviceSku &&
      deviceInfo.deviceId !== deviceInfo.deviceSku &&
      (deviceInfo.deviceAttributes.deviceCategory.includes('4G') ||
        deviceInfo.deviceAttributes.deviceType === '4GE' ||
        deviceInfo.deviceAttributes.deviceType === '4GC' ||
        deviceInfo.deviceAttributes.deviceType === '4GO' ||
        deviceInfo.deviceAttributes.deviceType === 'IML' ||
        deviceInfo.deviceAttributes.deviceType === '5GF' ||
        deviceInfo.deviceAttributes.deviceType === '5GL' ||
        deviceInfo.deviceAttributes.deviceType === '4GR' ||
        deviceInfo.deviceAttributes.deviceType === '5GA' ||
        deviceInfo.deviceAttributes.deviceType === '5GE' ||
        deviceInfo.deviceAttributes.deviceType === '5GF')
    ) {
      // device id length validation for 4G and 5G
      dispatch(
        appMessageActions.addAppMessage(
          `${deviceInfo.deviceId} is not a valid 15 digit 4G Device ID. Please re-enter`,
          'error',
        ),
      );
    } else if (deviceInfo && deviceInfo.deviceSku && deviceInfo.deviceSku === '') {
      // error scenario for missing sku
      dispatch(appMessageActions.addAppMessage('Device is not compatible with the selected device', 'error'));
    } else if (mtnNotGenerated) {
      dispatch(
        appMessageActions.addAppMessage(
          `Please generate MDN for the line ${activeMtn} to proceed`,
          'error',
          true,
          true,
          false,
          false,
          true,
          'Assign Number',
          () => {
            navigate(`${getUIContextPathBAU()}/numberselection.html?fromPage=CombinedGridwall`);
          },
        ),
      );
    } else if (isIndirect && checkDeviceSimCompatibility(compatibilityCheckParams)) {
      setImmediateCall(true);
      initiateDeviceSimCompatibilityCheck(compatibilityCheckParams);
    } else if (intendType === 'EUP' || (intendType === 'AAL' && !payload?.fromCpe) || intendType === 'NSE') {
      // NON BYOD or LOCAL FLOW
      // || block is only for pdpmfe enable location
      if (
        (deviceInfo && deviceInfo.makeEtniPersApi) ||
        (ispdpenable &&
          !(disableEsimAtLocalInventory === 'TRUE') &&
          (deviceInfo?.simInfo2?.makeEtniPersApi || deviceInfo?.simInfo?.makeEtniPersApi))
      ) {
        setIsEntiModalVisible(!isEntiModalVisible);
      } else {
        // NON BYOD or LOCAL FLOW  NON ESIM

        console.log('landing1 - validateSimandDeviceId', payload);
        // const contextUrl = getUIContextPath();
        const skuId = deviceInfo?.deviceSku;
        const formattedDeviceId = payload?.deviceId;
        // NON 5G FLOW
        if (!(channel?.includes('OMNI-INDIRECT') && payload?.simId === '') || (isIndirect && payload?.simId === '')) {
          console.log('search Name false PDP route 3');
          let redirectionPath = '';
          if (isFrom === 'isLocal' && deviceInfo?.simClass4G === 'NP' && deviceInfo?.simInfo2) {
            // LOCAL FLOW Samsung DSDS ESIM
            redirectionPath = `${getUIContextPathBAU()}/product-detail.html?iSscan=true&offerEligible=Y&deviceSKU=${skuId}&${isFrom}=true&deviceId=${formattedDeviceId}&activeMtn=${activeMtn}&imei1=${
              deviceInfo?.imei1
            }&imei2=${deviceInfo?.imei2}${
              payload.simId !== ''
                ? `&simId=${payload.simId}`
                : `&eId=${deviceInfo?.simInfo2?.eID}&preferredSoftSim=${deviceInfo?.simInfo2?.preferredSoftSim}`
            }&eDeviceSku=${deviceInfo?.simInfo2?.launchPackageSku}&preferredSoftSim=${
              deviceInfo?.simInfo2?.preferredSoftSim
            }&eSim=true&isLocalScanFromGridwallDSDS=true${upcCodeQueryParam}`;
          } else {
            redirectionPath = `${getUIContextPathBAU()}/product-detail.html?iSscan=true&offerEligible=Y&deviceSKU=${skuId}&&${isFrom}=true&deviceId=${formattedDeviceId}&activeMtn=${activeMtn}&imei2=${
              deviceInfo?.imei2
            }${payload.simId !== '' ? `&simId=${payload.simId}` : ''}${upcCodeQueryParam}`;
          }
          if (isIndirect) {
            const deviceSimCompatible = deviceInfo?.deviceSimCompatible;
            if (
              deviceSimCompatible === 'Y' &&
              !payload.simId &&
              validateDeviceSimIdPayload?.data?.lines?.[0]?.device?.sim?.CurrentSimid
            ) {
              redirectionPath += `&simId=${existingActiveMtnEqpInfo?.simInfo?.simId}&deviceSimCompatible=${deviceSimCompatible}`;
            } else if (deviceSimCompatible === 'N') {
              redirectionPath += `&deviceSimCompatible=${deviceSimCompatible}`;
            }
            navigate(`${redirectionPath}&isLocal=${isFrom === 'isLocal'}`);
          } else {
            navigate(`${redirectionPath}`);
          }
        }
      }
    }
  };

  const initSimDetailsCall = ({ payload = {} }) => {
    const mdn = activeMtn || '';
    const billingSystemFromCart = CartDetailsResult?.data?.data?.orderDetails?.billingSystem || '';
    const ByodProspectFlow = false;
    const isMtnTypePortIn = selectedLine[0]?.portinMtnAssignment || false;
    const isActiveLineMtnType = selectedLine[0]?.mtnDetails?.mtnType
      ? selectedLine[0]?.mtnDetails?.mtnType.toUpperCase()
      : '';
    const isMtnTypePreToPost = isActiveLineMtnType === MTN_TYPE_PRE_TO_POST;
    const isMtnTypeVisible = isActiveLineMtnType === MTN_TYPE_VISIBLE;
    const isMtnTypeYahoo = isActiveLineMtnType === MTN_TYPE_YAHOO;
    const isMtnTypeHarmony = isActiveLineMtnType === MTN_TYPE_HARMONY;
    const isPrepayCart = orderDetails?.isPrePayCart || 'N';
    const deviceData = ValidateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo;
    let billerId = '';
    if (CustomerProfileResult?.customer?.billingSystem) {
      billerId = CustomerProfileResult.customer.billingSystem;
    } else if (billingSystemFromCart) {
      billerId = billingSystemFromCart;
    } else if (ByodProspectFlow && CartDetailsResult?.data?.data?.orderDetails?.billingSystem) {
      billerId = CartDetailsResult?.data?.data?.orderDetails?.billingSystem;
    }

    let eid = deviceData?.simInfo?.eID || '';
    let sku = deviceData?.simInfo?.preferredSoftSim || '';

    if (ispdpenable && deviceData?.simClass4G === 'NP' && deviceData?.simInfo2) {
      eid = deviceData?.simInfo2?.eID;
      sku = deviceData?.simInfo2?.preferredSoftSim;
    }

    // const isFromCart = !!getQueryParamByName('deviceFromCart');
    // const isFrom = isFromCart ? 'deviceFromCart' : 'isLocal';
    // const scanFromLanding = false;
    // const scanFromPDPLocalFlow = !!(
    //   isFrom === 'isLocal' &&
    //   scanFromLanding === false &&
    //   !payload?.fromCpe &&
    //   !payload?.isCustomerProvidedEquipment &&
    //   !isByodUpdate
    // );
    // need to check isnewline
    const intentType = payload?.isCustomerProvidedEquipment ? 'BYOD' : 'EUP';
    const assistedFlags = sessionStorage.getItem('APP_PROPERTIES');
    const odaIndicatorRequired =
      (!(assistedFlags?.disableEsimAtLocalInventory === 'TRUE') &&
        (channel === 'OMNI-RETAIL' ||
          channel === 'OMNI-RETAIL-TAB' ||
          channel === 'OMNI-INDIRECT' ||
          channel === 'OMNI-INDIRECT-TAB') &&
        deviceData?.simClass4G === 'NP' &&
        intentType === 'EUP') ||
      deviceData?.setOdaIndicatorforEsimCall;

    const params = {
      billerId,
      mdn,
      sku,
      eid,
      ...(odaIndicatorRequired ? { odaInd: 'Y' } : {}),
      processInd:
        payload && payload.isCustomerProvidedEquipment
          ? 'N'
          : ByodProspectFlow
            ? 'N'
            : intendType === 'AAL' || intendType === 'NSE' || customerType === 'N'
              ? 'N'
              : 'D',
    };
    /* istanbul ignore else */
    // No else statement to cover
    if (
      isMtnTypePreToPost ||
      isMtnTypeVisible ||
      isMtnTypeYahoo ||
      isMtnTypeHarmony ||
      isMtnTypePortIn ||
      isPrepayCart === 'Y'
    ) {
      params.processInd = 'M';
    }
    eSimDetailsRequestBody({ body: params });
  };

  const initSimDetailsResp = (res) => {
    const { data = {} } = res;

    if (data && data.errors) {
      // const errormessage = data.errors[0].message;
      // yield put(appMessageActions.addAppMessage(errormessage, "error"));
      navigate(`/combinedgridwall.html?fromAssignMtn=true&activeMtn=${activeMtn}`);
    } else {
      const mdn = activeMtn;
      // const isInterim = window.location.href.indexOf('deviceSimId') > -1;
      const searchByName = getQueryParamByName('searchByName') === 'false' ? 'searchByName=false&' : '';
      const deviceInfo = ValidateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo;
      let skuId = deviceInfo?.deviceSku || '';
      let preferredSoftSim = deviceInfo?.simInfo?.preferredSoftSim || '';
      if (ispdpenable) {
        skuId = deviceInfo?.simInfo?.launchPackageSku || '';
      }
      const formattedDeviceId = deviceInfo?.deviceId || '';
      const ByodProspectFlow = false;
      const scanFromPDPLocalFlow = false;
      const eSimOnlyDevice = !!(deviceInfo?.makeEtniPersApi && !deviceInfo?.simInfo?.dfillCompatibleSim);
      const simId = res && res.data && res.data.iccid ? res.data.iccid : '';
      let queryParamsPdpMfe = '';
      // for samsung motorola devices we need to send (pDeviceId, eDeviceId,eDeviceSku) in add-device payoad so passing data in queryparams
      if (ispdpenable && deviceInfo?.simClass4G === 'NP' && deviceInfo?.simInfo2) {
        preferredSoftSim = deviceInfo?.simInfo2?.preferredSoftSim;
        const eId = deviceInfo?.simInfo2?.eID;
        skuId =
          deviceInfo?.simInfo2?.launchPackageSku || deviceInfo?.simInfo2?.launchPackageSkuType || deviceInfo?.deviceSku;
        queryParamsPdpMfe = `&isScanDsDs=true&eId=${eId}&skuId=${skuId}&eDeviceId=${deviceInfo?.simInfo2?.deviceId}&pDeviceId=${deviceInfo?.simInfo?.deviceId}&physicalSku=${deviceInfo?.deviceSku}&intentType=${intendType}`;
      }

      let refferedUrl = '';
      refferedUrl = `${getUIContextPathBAU()}/product-detail.html?offerEligible=Y&activeMtn=${mdn}&iSscan=true&imei2=${
        deviceInfo?.imei2
      }&eSimOnlyDevice=${eSimOnlyDevice}&${searchByName}deviceSKU=${skuId}&${isFrom}=true&deviceId=${formattedDeviceId}&simId=${simId}&eSim=true${
        isFrom === 'isLocal' ? (scanFromPDPLocalFlow === true ? '&scanFromLanding=false' : '&scanFromLanding=true') : ''
      }${ByodProspectFlow ? '&prospectByodFlow=true&ByodDeviceCompitable=true' : ''}${upcCodeQueryParam}`;

      let refferedUrl2 = '';
      refferedUrl2 = `${getUIContextPathBAU()}/product-detail.html?offerEligible=Y&activeMtn=${mdn}&iSscan=true&imei2=${
        deviceInfo?.imei2
      }&eSimOnlyDevice=${eSimOnlyDevice}&${searchByName}deviceSKU=${skuId}&preferredSoftSim=${preferredSoftSim}&${isFrom}=true&deviceId=${formattedDeviceId}&simId=${simId}&eSim=true${
        isFrom === 'isLocal' ? (scanFromPDPLocalFlow === true ? '&scanFromLanding=false' : '&scanFromLanding=true') : ''
      }${ByodProspectFlow ? '&prospectByodFlow=true&ByodDeviceCompitable=true' : ''}&cpSimCard=${
        devicePayload?.cpSimCard
      }${queryParamsPdpMfe}${upcCodeQueryParam}`;

      if (ispdpenable) {
        navigate(refferedUrl2);
      } else {
        navigate(refferedUrl);
      }
    }
  };

  const onClickEntiLookupOption = (option) => {
    if (option === 'yes') {
      const isNewlyAddedLine = (landingMtn && landingMtn[0] && landingMtn[0].isNewlyAddedLine) || false;
      const val = isNewlyAddedLine;
      const deviceInfo = ValidateDeviceSimIdResult?.data?.serviceBody?.serviceResponse?.context?.deviceInfo;
      let skuId = deviceInfo?.deviceSku || '';
      if (ispdpenable) {
        skuId = deviceInfo?.simInfo?.launchPackageSku || '';
      }
      const formattedDeviceId = deviceInfo?.deviceId || '';
      let eId = deviceInfo?.simInfo?.eID ? deviceInfo?.simInfo?.eID : '';
      const scanFromPDPLocalFlow = !!(
        isFrom === 'isLocal' &&
        !getQueryParamByName('scanFromLanding') &&
        !getQueryParamByName('isFromCPE') &&
        !val &&
        !isByodUpdate
      );
      let preferredSoftSim = deviceInfo?.simInfo?.preferredSoftSim;

      setIsEntiModalVisible(!isEntiModalVisible);
      setPopUp(!popUp);
      setScanCheck('');
      let queryParamsPdpMfe = '';
      // for samsung motorola devices we need to send (pDeviceId, eDeviceId,eDeviceSku) in add-device payoad so passing data in queryparams
      if (ispdpenable) {
        queryParamsPdpMfe = `&cpSimCard=${devicePayload?.cpSimCard}&imei2=${deviceInfo?.imei2}`;
        if (deviceInfo?.simClass4G === 'NP' && deviceInfo?.simInfo2) {
          preferredSoftSim = deviceInfo?.simInfo2?.preferredSoftSim;
          eId = deviceInfo?.simInfo2?.eID;
          skuId =
            deviceInfo?.simInfo2?.launchPackageSku ||
            deviceInfo?.simInfo2?.launchPackageSkuType ||
            deviceInfo?.deviceSku;
          queryParamsPdpMfe = `${queryParamsPdpMfe}&isScanDsDs=true&skuId=${skuId}&eDeviceId=${deviceInfo?.simInfo2?.deviceId}&pDeviceId=${deviceInfo?.simInfo?.deviceId}&physicalSku=${deviceInfo?.deviceSku}&intentType=${intendType}&cpSimCard=${devicePayload?.cpSimCard}`;
        }
      }
      if (skipIccidCall === 'TRUE' || skipICCIDFFlag) {
        navigate(
          `${getUIContextPathBAU()}/product-detail.html?offerEligible=Y&activeMtn=${activeMtn}&iSscan=true&deviceSKU=${skuId}&preferredSoftSim=${preferredSoftSim}&isLocal=true&deviceId=${formattedDeviceId}&eId=${eId}&eSim=true${
            isFrom === 'isLocal'
              ? scanFromPDPLocalFlow === true
                ? '&scanFromLanding=false'
                : '&scanFromLanding=true'
              : ''
          }${queryParamsPdpMfe}${upcCodeQueryParam}`,
        );
      } else {
        initSimDetailsCall({
          isCustomerProvidedEquipment: val,
          isLocal: true,
        });
      }
    } else {
      setIsEntiModalVisible(!isEntiModalVisible);
      setPopUp(!popUp);
      setScanCheck('');
    }
  };
  const updateDevicePayload = (payload) => {
    setDevicePayload((previouspayload) => ({ ...previouspayload, ...payload }));
  };
  const updateSetUpPopUp = () => {
    setPopUp(!popUp);
  };
  return (
    <div>
      {fiveGExistingActiveLine ? (
        <PaddingTop8>
          <Title size='small' color='#6F7171'>
            Device Upgrade Ineligible.
          </Title>
        </PaddingTop8>
      ) : (
        <GridwallContainer
          handleByodflag={handleByodflag}
          isFromCPE={isFromCPE}
          isLocal={isLocal}
          ScanFromLanding={scanFromLanding}
          onClose={() => toggleSUGConsent && toggleSUGConsent(false)}
          lineActivityType={lineActivityType}
          installmentTerm={installmentTerm}
          selectedLine={selectedLine}
          totalLines={totalLines}
          commonInfo={CustomerProfileResult?.data?.data?.commonInfo}
          cartDetails={CartDetailsResult?.data?.data}
          isProspectflow
          deviceIdInCart={deviceIdInCart}
          simIdInCart={simIdInCart}
          CustomerDataCustomer={CustomerProfileResult?.data?.data?.customer}
          prospectByodFlow={prospectByodFlow}
          ValidateDeviceSimIdResult={ValidateDeviceSimIdResult?.data}
          ValidateDeviceSimIdResultStatus={ValidateDeviceSimIdResult?.status}
          validateDeviceSimIdRequest={validateDeviceSimIdRequest}
          updateDevicePayload={updateDevicePayload}
          devicePayload={devicePayload}
          popUp={popUp}
          updateSetUpPopUp={updateSetUpPopUp}
          lineHasOffer={lineHasOffer}
          nationalCheck={nationalCheck}
          offers={MyOffers?.data}
          activeMtn={activeMtn}
          setIsCloseByod={setIsCloseByod}
          showProspectTile={showProspectTile}
          toggleValue={toggleValue}
          selectedSkuId={cartItem?.skuId}
          products={{ [activeMtn]: productList }}
          getDevices={getProductList}
          getRefetchProductList={getProductList}
          requestBody={requestBody}
          toggleOptions={toggleOptions}
          resetToggleOptions={resetToggleOptions}
          handleCompareCheckboxChange={handleCompareCheckboxChange}
          handleRemoveProductFromCompareInGW={handleRemoveProductFromCompareInGW}
          devicestocompare={devicesToCompare}
          CustomerData={CustomerProfileResult?.data?.data?.customer}
          hasIteminCart={hasIteminCart}
          landingData={CustomerProfileResult?.data?.data}
          byodCheck={byodCheck}
          intentCheck={intentCheck}
          rebeatElligible={rebeatElligible}
          is5gLine={is5gLine}
          isStackbleOffer={isStackbleOffer}
          updateToggleOptions={updateToggleOptions}
          eSimDetailsResult={eSimDetailsResult?.data}
          eSimDetailsResultStatus={eSimDetailsResult?.status}
          validateDeviceSimId={validateDeviceSimId}
          initSimDetailsResp={initSimDetailsResp}
          setShowProspectTile={setShowProspectTile}
          landingLinesInfo={landingLines}
          cartItem={cartItem}
          UpdateBYODCheck={UpdateBYODCheck}
          scanCheck={scanCheck}
          isLoadMore={isLoadMore}
          setLoadMore={setLoadMore}
          isProductListLoading={
            ProductListResult?.isFetching ||
            CartDetailsResult?.isFetching ||
            MyOffers?.isFetching ||
            CustomerProfileResult?.isFetching
          }
          compareDevices={compareDevices}
          hideCompareDevicesModal={hideCompareDevicesModal}
          handleRemoveProductFromFooter={handleRemoveProductFromFooter}
          closeCompareDevicesoptions={closeCompareDevicesoptions}
          showCompareData={showCompareData}
          handleRemoveProductFromCompare={handleRemoveProductFromCompare}
          scrolled={scrolled}
          handleConfirmationDialogBoxClick={(option) => onClickEntiLookupOption(option)}
          compareModalWrapperRef={compareModalWrapperRef}
          showCompareDevicesModalFlag={showCompareDevicesModalFlag}
          devicesToCompareLength={devicesToCompare.length}
          isEntiModalVisible={isEntiModalVisible}
          gridRef={gridRef}
          isGWByodEUPEnabledFlag={isGWByodEUPEnabledFlag}
          ProductListResult={ProductListResult}
          deviceCategory={deviceCategory}
          SecNumFlow={SecNumFlow}
          primaryMtnofSecondNumber={primaryMtnofSecondNumber}
          trialDeviceDetail={trialDeviceDetail}
          setUpcCode={setUpcCode}
          isDWOS={isDWOS}
          setShowCarrierLockPopup={setShowCarrierLockPopup}
          showCarrierLockPopup={showCarrierLockPopup}
        />
      )}
    </div>
  );
});

export default Gridwall;
