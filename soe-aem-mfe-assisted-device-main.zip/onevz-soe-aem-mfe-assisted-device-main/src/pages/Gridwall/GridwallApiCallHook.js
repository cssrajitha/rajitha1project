import {
  useGetCartDetailsQuery,
  useGetCustomerProfileQuery,
  useLazyValidateDeviceSimIdQuery,
} from 'onevzsoemfecommon/APIService';
import {
  useLazyGetProductListQuery,
  useLazyCompareListQuery,
  useLazyGetSkuDetailsQuery,
} from 'onevzsoemfecommon/BrowseAPIService';
import { useLazyRemoveSecondNumberDetailsQuery, useLazyESimDetailsQuery } from 'onevzsoemfecommon/CartAPIService';
import { useGetMyOffersQuery } from 'onevzsoemfecommon/AccountAPIService';
import {
  // useLazyGetProductListQuery,
  useLazyGetTrialDeviceDetailQuery,
  // useLazyCompareListQuery,
  // useGetMyOffersQuery,
  // useLazyValidateDeviceSimIdQuery,
  // useLazyESimDetailsQuery,
  // useLazyGetSkuDetailsQuery,
  // useLazyRemoveSecondNumberDetailsQuery,
} from '../../modules/services/APIService/APIServiceHooks';
import { requestBodyRetriveCart, requestBodyCustomerProfile } from '../../modules/services/APIService/APIRequestBody';

const GridwallApiCallHook = () => {
  const CustomerProfileResult = useGetCustomerProfileQuery({ body: requestBodyCustomerProfile });
  const CartDetailsResult = useGetCartDetailsQuery({ body: requestBodyRetriveCart }, { refetchOnMountOrArgChange: true });
  const MyOffers = useGetMyOffersQuery({ body: {}, spinner: false }, { refetchOnMountOrArgChange: true });
  const [getCompareList, CompareListResult] = useLazyCompareListQuery();
  const [validateDeviceSimIdRequestBody, ValidateDeviceSimIdResult] = useLazyValidateDeviceSimIdQuery();

  const [eSimDetailsRequestBody, eSimDetailsResult] = useLazyESimDetailsQuery();
  const [getProducts, ProductListResult] = useLazyGetProductListQuery();
  const [getTrialDeviceDetail, TrialDeviceDetailsResult] = useLazyGetTrialDeviceDetailQuery();
  const [getSkuDetails, SkuDetailsResult] = useLazyGetSkuDetailsQuery();
  const [removeSecondNumberDetails, RemoveSecondNumberResult] = useLazyRemoveSecondNumberDetailsQuery();

  return {
    CustomerProfileResult,
    CartDetailsResult,
    MyOffers,
    getCompareList,
    CompareListResult,
    validateDeviceSimIdRequestBody,
    ValidateDeviceSimIdResult,
    eSimDetailsRequestBody,
    eSimDetailsResult,
    getProducts,
    ProductListResult,
    getTrialDeviceDetail,
    TrialDeviceDetailsResult,
    getSkuDetails,
    SkuDetailsResult,
    removeSecondNumberDetails,
    RemoveSecondNumberResult,
  };
};

export default GridwallApiCallHook;
