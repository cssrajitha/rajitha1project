import React from 'react';
import styled from 'styled-components';
import { ConfirmationDialogBox } from 'onevzsoemfecommon/ConfirmationDialogBox';
import GridwallDevices from '../../components/CombinedGridwall/GridwallDevices';
import CompareFooter from '../../components/CombinedGridwall/CompareFooter';
import CompareGridwallDevices from '../../components/CombinedGridwall/CompareGridwallDevices';
import Cpe from '../../components/CombinedGridwall/Cpe/Cpe';

const PageWrapper = styled.div`
  height: 100vh;
  position: fixed;
  top: 0;
  z-index: 9999;
  left: 0px;
  background-color: white;
  width: 100%;
  overflow: auto;
`;
const GridwallWrapper = styled.div`
  flex: 1;
  height: ${({ scmDeviceMfeEnable }) => (scmDeviceMfeEnable ? '100%' : 'calc(100vh - 150px)')};
  overflow: auto;
`;

const GridwallContainer = (props) => {
  const {
    handleByodflag,
    isFromCPE,
    isLocal,
    scanFromLanding,
    onClose,
    lineActivityType,
    selectedLine,
    totalLines,
    commonInfo,
    cartDetails,
    isProspectflow,
    deviceIdInCart,
    simIdInCart,
    CustomerDataCustomer,
    prospectByodFlow,
    ValidateDeviceSimIdResult,
    ValidateDeviceSimIdResultStatus,
    validateDeviceSimIdRequest,
    updateDevicePayload,
    devicePayload,
    popUp,
    updateSetUpPopUp,
    lineHasOffer,
    nationalCheck,
    offers,
    activeMtn,
    setIsCloseByod,
    showProspectTile,
    toggleValue,
    selectedSkuId,
    products,
    getDevices,
    getRefetchProductList,
    requestBody,
    toggleOptions,
    resetToggleOptions,
    handleCompareCheckboxChange,
    handleRemoveProductFromCompareInGW,
    devicestocompare,
    CustomerData,
    hasIteminCart,
    landingData,
    byodCheck,
    intentCheck,
    rebeatElligible,
    is5gLine,
    isStackbleOffer,
    updateToggleOptions,
    eSimDetailsResult,
    eSimDetailsResultStatus,
    validateDeviceSimId,
    initSimDetailsResp,
    setShowProspectTile,
    landingLinesInfo,
    cartItem,
    UpdateBYODCheck,
    scanCheck,
    isLoadMore,
    setLoadMore,
    isProductListLoading,
    compareDevices,
    hideCompareDevicesModal,
    handleRemoveProductFromFooter,
    closeCompareDevicesoptions,
    showCompareData,
    handleRemoveProductFromCompare,
    scrolled,
    handleConfirmationDialogBoxClick,
    compareModalWrapperRef,
    showCompareDevicesModalFlag,
    devicesToCompareLength,
    isEntiModalVisible,
    gridRef,
    isGWByodEUPEnabledFlag,
    ProductListResult,
    deviceCategory,
    SecNumFlow,
    primaryMtnofSecondNumber,
    installmentTerm,
    trialDeviceDetail,
    isDWOS,
    setShowCarrierLockPopup,
    showCarrierLockPopup,
  } = props;

  const getCompareGridwallDevices = showCompareDevicesModalFlag ? (
    <PageWrapper data-testid='scroll-container' ref={compareModalWrapperRef}>
      <CompareGridwallDevices
        cartDetails={cartDetails}
        showCompareData={showCompareData}
        handleRemoveProductFromCompare={handleRemoveProductFromCompare}
        devicesToCompare={devicestocompare}
        hideCompareDevicesModal={hideCompareDevicesModal}
        scrolled={scrolled}
      />
    </PageWrapper>
  ) : (
    ''
  );

  return (
    <GridwallWrapper ref={gridRef} data-testid='GridWallWrapper' scmDeviceMfeEnable={window?.mfe?.scmDeviceMfeEnable}>
      {!showCompareDevicesModalFlag ? (
        <>
          {prospectByodFlow || SecNumFlow ? (
            <Cpe
              handleByodflag={handleByodflag}
              isFromCPE={isFromCPE}
              isLocal={isLocal}
              ScanFromLanding={scanFromLanding}
              onClose={onClose}
              lineActivityType={lineActivityType}
              selectedLine={selectedLine}
              totalLines={totalLines}
              commonInfo={commonInfo}
              cartDetails={cartDetails}
              isProspectflow={isProspectflow}
              deviceIdInCart={deviceIdInCart}
              simIdInCart={simIdInCart()}
              CustomerData={CustomerDataCustomer}
              prospectByodFlow={prospectByodFlow}
              ValidateDeviceSimIdResult={ValidateDeviceSimIdResult}
              ValidateDeviceSimIdResultStatus={ValidateDeviceSimIdResultStatus}
              validateDeviceSimIdRequest={validateDeviceSimIdRequest}
              updateDevicePayload={updateDevicePayload}
              devicePayload={devicePayload}
              popUp={popUp}
              updateSetUpPopUp={updateSetUpPopUp}
              lineHasOffer={lineHasOffer}
              nationalCheck={nationalCheck}
              offers={offers}
              activeMtn={activeMtn}
              setIsCloseByod={setIsCloseByod}
              scanCheck={scanCheck}
              deviceCategory={deviceCategory}
              landingLinesInfo={landingLinesInfo}
              primaryMtnofSecondNumber={primaryMtnofSecondNumber}
              SecNumFlow={SecNumFlow}
              setShowCarrierLockPopup={setShowCarrierLockPopup}
              showCarrierLockPopup={showCarrierLockPopup}
            />
          ) : (
            <GridwallDevices
              trialDeviceDetail={trialDeviceDetail}
              ProductListResult={ProductListResult}
              showProspectTile={showProspectTile}
              toggleValue={toggleValue}
              selectedSkuId={selectedSkuId}
              cartDetails={cartDetails}
              products={products}
              totalLines={totalLines}
              activeMtn={activeMtn}
              getDevices={getDevices}
              getRefetchProductList={getRefetchProductList}
              requestBody={requestBody}
              toggleOptions={toggleOptions}
              resetToggleOptions={resetToggleOptions}
              handleCompareCheckboxChange={handleCompareCheckboxChange}
              handleRemoveProductFromCompareInGW={handleRemoveProductFromCompareInGW}
              devicestocompare={devicestocompare}
              CustomerData={CustomerData}
              lineActivityType={lineActivityType}
              hasIteminCart={hasIteminCart}
              handleByodflag={handleByodflag}
              offers={offers}
              devicePayload={devicePayload}
              landingData={landingData}
              byodCheck={byodCheck}
              intentCheck={intentCheck}
              lineHasOffer={lineHasOffer}
              nationalCheck={nationalCheck}
              rebeatElligible={rebeatElligible}
              is5gLine={is5gLine}
              isStackbleOffer={isStackbleOffer}
              updateToggleOptions={updateToggleOptions}
              validateDeviceSimIdRequest={validateDeviceSimIdRequest}
              prospectByodFlow={prospectByodFlow}
              ValidateDeviceSimIdResult={ValidateDeviceSimIdResult}
              ValidateDeviceSimIdResultStatus={ValidateDeviceSimIdResultStatus}
              eSimDetailsResult={eSimDetailsResult}
              eSimDetailsResultStatus={eSimDetailsResultStatus}
              validateDeviceSimId={validateDeviceSimId}
              initSimDetailsResp={initSimDetailsResp}
              setShowProspectTile={setShowProspectTile}
              landingLinesInfo={landingLinesInfo}
              cartItem={cartItem}
              selectedLine={selectedLine}
              UpdateBYODCheck={UpdateBYODCheck}
              scanCheck={scanCheck}
              popUp={popUp}
              isLoadMore={isLoadMore}
              setLoadMore={setLoadMore}
              setIsCloseByod={setIsCloseByod}
              isProductListLoading={isProductListLoading}
              isGWByodEUPEnabledFlag={isGWByodEUPEnabledFlag}
              installmentTerm={installmentTerm}
              updateDevicePayload={updateDevicePayload}
              setUpcCode={props?.setUpcCode}
              isDWOS={isDWOS}
            />
          )}
          {devicesToCompareLength > 0 && (
            <CompareFooter
              devicestocompare={devicestocompare}
              compareDevices={compareDevices}
              hideCompareDevicesModal={hideCompareDevicesModal}
              handleRemoveProductFromFooter={handleRemoveProductFromFooter}
              closeCompareDevicesoptions={closeCompareDevicesoptions}
            />
          )}
          {isEntiModalVisible && (
            <ConfirmationDialogBox
              message='This device requires an eSim for activation, do you wish to continue?'
              isNoBtnDisabled={false}
              handleConfirmationDialogBoxClick={handleConfirmationDialogBoxClick}
            />
          )}
        </>
      ) : (
        getCompareGridwallDevices
      )}
    </GridwallWrapper>
  );
};

export default GridwallContainer;
