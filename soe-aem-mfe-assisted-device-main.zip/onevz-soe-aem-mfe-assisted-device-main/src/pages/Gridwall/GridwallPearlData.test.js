import React from 'react';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { render } from '../../modules/test-utils/renderHelper';
import Gridwall from './index';
import data from '../../components/CombinedGridwall/__mocks__/mockCombinedGridwallData.json';
import myOffers from '../../components/CombinedGridwall/__mocks__/getMyOffers.json';

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);

const result = {
  data: {
    cart: {
      orderDetails: { flowType: 'DVM_CONVERSION' },
    },
    data: {
      customer: {
        billAccounts: [
          {
            billAccountNo: '1',
            recommendation: {
              recommendedPlan: {
                usageInfo: {
                  accountUsageInfo: {
                    dataUsageInfos: [],
                  },
                },
                unbilledAccountUsageInfo: {
                  totalData: null,
                  unitOfMeasure: null,
                  usageType: null,
                  dataAllowance: null,
                },
              },
            },

            accountOffers: {
              productOffers: [],
            },
            accountLevelChangeEligibility: {
              isAddNewLineAllowed: true,
              isBundleChangeAllowed: true,
              isSharePlanChangeAllowed: true,
              pendingOrderDetail: null,
            },
            mtns: [
              {
                mtn: '4782303946',
                lineLevelServiceOffers: [],
                numberShare: null,
                mtnHashCode: 'fd9c6f8eae5f78d79e5d2e468c0e61bbc69eaebb21cc9fd10cb3fd6932782b73',
                nickName: 'DAN M JETER-3946',
                benefitPair: {
                  pairedPhoneMtn: null,
                  eligibleToPair: false,
                  existingPair: false,
                  grantee: false,
                  grantor: false,
                },
                primaryUser: {
                  firstName: 'DAN',
                  lastName: 'JETER',
                  preferFirstName: null,
                  preferLastName: null,
                  preferPronoun: null,
                },
              },
            ],
          },
        ],
      },
      cart: {
        orderDetails: { flowType: 'DVM_CONVERSION' },
      },
    },
  },
};

const productList = {
  data: {
    data: {
      gridWall: {
        pagination: {
          totalNumberRecords: 24,
        },
      },
    },
  },
};

const myOffersData = {
  data: {
    lines: [
      {
        mtn: 'newLine1',
      },
    ],
  },
};
jest.mock('./GridwallApiCallHook', () => ({
  __esModule: true,
  default: jest.fn(() => ({
    CustomerProfileResult: { ...result },
    CartDetailsResult: { data: { ...result } },
    MyOffers: { ...myOffersData },
    getCompareList: {},
    CompareListResult: {},
    validateDeviceSimIdRequestBody: {},
    ValidateDeviceSimIdResult: {},
    eSimDetailsRequestBody: {},
    eSimDetailsResult: jest.fn(),
    getProducts: jest.fn(),
    ProductListResult: { ...productList },
    getTrialDeviceDetail: jest.fn(),
    TrialDeviceDetailsResult: result,
    removeSecondNumberDetails: jest.fn(),
  })),
}));

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradleProperty: () => ['TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE'],
    getAssistedCradlePropertyV2: () => ['TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE'],
  }),
  { virtual: true },
);

const TestEmmiter = () => {
  describe(`Emmiter testing section`, () => {
    const activeMtn = 'newLine1';
    render(<Gridwall resetToggleOptions={jest.fn()} data={data} activeMtn={activeMtn} offers={myOffers} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    test(`Pearl Trial Device detail`, async () => {
      expect(true).toBe(true);
    });
  });
};

TestEmmiter();
