import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { fireEvent, render, screen, waitFor } from '../../modules/test-utils/renderHelper';
import Gridwall from './index';
import data1 from '../../components/CombinedGridwall/__mocks__/mockCombinedGridwallData.json';
import myOffers from '../../components/CombinedGridwall/newCustomerMocks/myOffers.json';
import data from '../../components/CombinedGridwall/newCustomerMocks/retrieveCart.json';
import mislGridData from '../../components/CombinedGridwall/__mocks__/mislGridwallMock.json';

jest.mock(
  'onevzsoemfecommon/Helpers/common_functions',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
    rfexMfeFlowFlag: () => false,
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: () => [
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'FALSE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
      'TRUE',
    ],
  }),
  { virtual: true },
);

jest.setTimeout(30000);
describe('Load cpe', () => {
  const handlers = [
    rest.post(`*/flexV2/productList`, (req, res, ctx) => {
      console.log('inside /flexV2/productList');
      return res(ctx.status(200), ctx.json(data1.data));
    }),
    rest.post(`*/flexV2/productList`, (req, res, ctx) => {
      console.log('2nd time inside /flexV2/productList');
      return res(ctx.status(200), ctx.json(data1.secondTimeProductListCallResponse));
    }),
    rest.post(`*/cartservice/cart/flexV2/retrieve-cart`, (req, res, ctx) => {
      console.log('2nd time inside /cartservice/cart/flexV2/retrieve-cart');
      return res(ctx.status(200), ctx.json({ data }));
    }),

    rest.post(`*/accountlandingservice/getMyOffers`, (req, res, ctx) => {
      console.log('inside /accountlandingservice/getMyOffers');
      return res(ctx.status(200), ctx.json(myOffers));
    }),
    rest.post(`*/accountlandingservice/flexV2/customerProfile`, (req, res, ctx) => {
      console.log('inside /accountlandingservice/flexV2/customerProfile');
      return res(
        ctx.status(200),
        ctx.json({
          data: {
            commonInfo: {
              showAccessoryTab: false,
              showTradeinTab: true,
              showLocalDfillRadioButton: false,
              showEnterDeviceToggle: true,
              showScanner: true,
              showSearchAccessory: false,
              showViewPriceBreakdown: false,
              showPriceBreakdownTooltip: true,
              showDevicePrices: true,
              showShipitToggle: true,
              showSellersPrice: false,
              isIndirect: false,
              showSalesRep: true,
              isISPUEnabled: true,
              showShopMoreDevices: true,
              showSecurityDeposit: false,
              showViewUpgradeReasonCode: true,
              showIneligibleUpgradeLines: true,
              showPastDueYesNobutton: false,
              maxNewLines: 5,
              showAccessoryShipItToggle: true,
              isTrialUnlimitedAccount: false,
              showCompassOffers: true,
              serviceOfferAccepted: false,
              isVZHPCustomer: true,
              isGridwallRedesignFlow: true,
              disableDfillRadioButton: false,
              showCreditStatus: true,
              showEcpdProfile: true,
              showHomeServicesReferral: true,
              showClickToCall: true,
              showIdCheck: true,
              showFPFCHeck: true,
              showManageDownPayments: true,
              showIntegrateWFM: false,
              showOrderEffectiveDate: true,
              showCartAnalyzer: true,
              showNeedHelp: false,
            },
            customer: {
              caseId: 'SOP-14471063-C01',
              cartId: '1ae317b9-4479-44ca-a828-03677b89a7d5',
              availablePaths: [],
              contactAddress: {
                state: null,
              },
              customerName: {
                firstName: null,
                lastName: null,
                businessName: null,
                preferFirstName: null,
                preferLastName: null,
                preferPronoun: null,
              },
              customerAttributes: {
                hasEcpd: null,
                autoPayDiscountEligibleCustomerType: null,
                customerType: null,
                associationIdNo: null,
              },
              billAccounts: [
                {
                  "mtns": [
                    {
                      "mtn": "5185673926",
                      "numberShare": null,
                      "mtnHashCode": "87c29fdbdb62783f5348abd0ba8f840c5281fe24d99b1ed94406e5c48b499887",
                      "nickName": "JAKE A WRIGHT-3926",
                      "benefitPair": {
                        "pairedPhoneMtn": null,
                        "eligibleToPair": false,
                        "existingPair": false,
                        "grantee": false,
                        "grantor": false
                      },
                      "primaryUser": {
                        "firstName": "RYAN",
                        "lastName": "WRIGHT",
                        "preferFirstName": "",
                        "preferLastName": "",
                        "preferPronoun": ""
                      },
                      "mtnStatus": {
                        "isActive": true,
                        "isDisconnected": false,
                        "isReassignedAndInActive": false,
                        "isSuspendedWithBilling": false,
                        "isSuspendedWithoutBilling": false,
                        "mtnSuspendAllowed": false,
                        "isMtnSuspended": false,
                        "mtnStatusReasonCode": "",
                        "isMtnChanged": null,
                        "isReassigned": null,
                        "isTransfered": false,
                        "status": "AR"
                      },
                      "equipmentInfos": [
                        {
                          "deviceInfo": {
                            "pairedDeviceDetails": [
                              {
                                "pairedImei": "353756110808409"
                              }
                            ],
                            "deviceId": "353756110808409",
                            "deviceSku": "SMA102UZKVZ",
                            "deviceUrl": "https://ss7.vzw.com/is/image/VerizonWireless/Samsung-Galaxy-A10e-Device-07312019",
                            "productDisplayName": "Galaxy A10e",
                            "category": {
                              "smartphone": true,
                              "tablet": false,
                              "basicphone": false,
                              "connectedDevice": false,
                              "internetDevice": false,
                              "homePC": false,
                              "telematics": false,
                              "virtualDevice": false,
                              "WSOnly": false
                            },
                            "tradeInValue": "0.00",
                            "displayName": "Samsung Galaxy A10e in Charcoal Black",
                            "capacity": null,
                            "deviceType": {
                              "backupRouter4G": null,
                              "device4G": null,
                              "device3G": null,
                              "device5GA": false,
                              "device5GE": false,
                              "antenna5G": false,
                              "home5G": false,
                              "deviceType": "4GE",
                              "home4GLte": false
                            },
                            "numberShareCapability": null,
                            "cdmaRestrictedDevice": false
                          },
                          "simInfo": {
                            "simId": "89148000005700881964",
                            "simSku": "EMBDSIMTRI",
                            "skuType": null
                          }
                        }
                      ],
                      "pricePlanInfo": {
                        "planId": "70995",
                        "description": "SECOND NUMBER",
                        "planDisplayName": null,
                        "planImageUrl": "https://ss7.vzw.com/is/image/VerizonWireless/6gb_0518",
                        "planCategoryName": "MORE EVERYTHING TALK TEXT DATA",
                        "effectiveDate": null,
                        "planAttributes": {
                          "sharePlan": true,
                          "isJax": false,
                          "isFelix": false,
                          "hasSecondNumPlan": true
                        },
                        "accessCharge": null,
                        "imageUrlMap": null,
                        "planPromotions": null
                      },
                      "currentSPOs": null,
                      "currentFeatures": [
                        {
                          "sfoId": "48526",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "48553",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "68869",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "68870",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "68871",
                          "price": "0.00",
                          "isActive": true,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/3way_Calling_012918",
                          "existing": false
                        },
                        {
                          "sfoId": "68872",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "68873",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "68874",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "68876",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "73324",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "74774",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "75632",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "75706",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "75802",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "75836",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "75837",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "76152",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918",
                          "existing": false
                        },
                        {
                          "sfoId": "76404",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "76600",
                          "price": "0.00",
                          "isActive": true,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/Caller_ID_012918",
                          "existing": false
                        },
                        {
                          "sfoId": "77249",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "77256",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "77524",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "77556",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "77568",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "77573",
                          "price": "15.0",
                          "isActive": true,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/Line_Access_Charge_012918",
                          "existing": false
                        },
                        {
                          "sfoId": "77581",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "77583",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "77885",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "78706",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "78707",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "78732",
                          "price": "0.00",
                          "isActive": true,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/Voicemail_012918",
                          "existing": false
                        },
                        {
                          "sfoId": "80148",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "81158",
                          "price": "0.00",
                          "isActive": true,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/HD_Voice_012918",
                          "existing": false
                        },
                        {
                          "sfoId": "83856",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        }
                      ],
                      "addOnDueMonthly": null,
                      "equipmentUpgradeEligibility": {
                        "upgradeEligible": true,
                        "annualUpgradeEligible": false,
                        "buyoutEligible": false,
                        "earlyUpgradeEligible": false,
                        "edgeUpEligible": false,
                        "upgradeEligibilityDate": "03/15/2022",
                        "upgradeEligibilityLabel": "Upgrade Now",
                        "buyoutAmountLabel": null,
                        "pendingOrderDetail": null,
                        "isWithInWFGperiod": true,
                        "discountEligibility": {
                          "discountEligible": true,
                          "eligibilityLabel": "DISCOUNT ELIGIBLE"
                        },
                        "hadTwoBuyoutInCurrentMonth": false,
                        "transferUpgradeEligibility": {
                          "giverEligible": true,
                          "takerEligible": false,
                          "takerMtns": []
                        }
                      },
                      "lineLevelChangeEligibility": {
                        "isDeviceOnlyChangeAllowed": true,
                        "isFeatureChangeAllowed": true,
                        "isLLBChangeAllowed": true,
                        "isMtnChangeAllowed": true,
                        "isMtnSuspendAllowed": true,
                        "isPricePlanChangeAllowed": true,
                        "pendingOrderDetail": null
                      },
                      "mobileInfoAttributes": {
                        "paidInsuranceExist": false,
                        "numberShareParent": "",
                        "accountOwner": false,
                        "accessRoles": null,
                        "hasReferAFriend": false
                      },
                      "tradeInPromo": null,
                      "inServiceDate": null,
                      "lineSharingIndicator": "",
                      "lineAccessCharge": null,
                      "installmentLoans": [],
                      "earlyTermination": null,
                      "mobileInfoInsurance": {},
                      "availableMTNsForLoanTransfer": {},
                      "offers": null,
                      "recentPurchaseOrder": null,
                      "marketingOption": {
                        "vzCCHolder": false
                      },
                      "totalDueMonthly": null,
                      "planChangeHoldOrdersFound": null,
                      "mtnEffectiveDate": null,
                      "isEqpOrAccOfferAccepted": null,
                      "lineLevelCurrentCostData": {},
                      "networkBandwidthType": "",
                      "deviceMtnIndicator": "",
                      "showSUGToggle": true,
                      "balanceAmount": null,
                      "isNewLine": false,
                      "sharePlan": null,
                      "fiosEligibilityCategory": null,
                      "primaryNumber": true,
                      "secondNumberInfo": [
                        {
                          "type": "Second Number",
                          "value": "8382918623"
                        }
                      ],
                      "accountAddress": null,
                      "newLine": false
                    },
                    {
                      "mtn": "8457062228",
                      "numberShare": null,
                      "mtnHashCode": "552fa45493a7c7a84d3b0116aba2e9785bbefa63ad217f01192801d2cbaf3b58",
                      "nickName": "JAKE A WRIGHT-2228",
                      "benefitPair": {
                        "pairedPhoneMtn": null,
                        "eligibleToPair": false,
                        "existingPair": false,
                        "grantee": false,
                        "grantor": false
                      },
                      "primaryUser": {
                        "firstName": "RYAN",
                        "lastName": "WRIGHT",
                        "preferFirstName": "",
                        "preferLastName": "",
                        "preferPronoun": ""
                      },
                      "mtnStatus": {
                        "isActive": true,
                        "isDisconnected": false,
                        "isReassignedAndInActive": false,
                        "isSuspendedWithBilling": false,
                        "isSuspendedWithoutBilling": false,
                        "mtnSuspendAllowed": false,
                        "isMtnSuspended": false,
                        "mtnStatusReasonCode": "",
                        "isMtnChanged": null,
                        "isReassigned": null,
                        "isTransfered": false,
                        "status": "AR"
                      },
                      "equipmentInfos": [
                        {
                          "deviceInfo": {
                            "deviceId": "354227112319299",
                            "deviceSku": "SMA115UZKVZ",
                            "deviceUrl": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-galaxy-a11-postpaid-4g-smartphone-black-sma115uzkvz",
                            "productDisplayName": "Galaxy A11",
                            "category": {
                              "smartphone": true,
                              "tablet": false,
                              "basicphone": false,
                              "connectedDevice": false,
                              "internetDevice": false,
                              "homePC": false,
                              "telematics": false,
                              "virtualDevice": false,
                              "WSOnly": false
                            },
                            "tradeInValue": "10.00",
                            "displayName": "Samsung Galaxy A11 in Black",
                            "capacity": null,
                            "deviceType": {
                              "backupRouter4G": null,
                              "device4G": null,
                              "device3G": null,
                              "device5GA": false,
                              "device5GE": false,
                              "antenna5G": false,
                              "home5G": false,
                              "deviceType": "4GE",
                              "home4GLte": false
                            },
                            "numberShareCapability": null,
                            "cdmaRestrictedDevice": false
                          },
                          "simInfo": {
                            "simId": "89148000006199133255",
                            "simSku": "EMBDSIMTRI",
                            "skuType": null
                          }
                        }
                      ],
                      "pricePlanInfo": {
                        "planId": "92775",
                        "description": "MORE EVERY UNL TLK&TXT 6GB",
                        "planDisplayName": null,
                        "planImageUrl": "https://ss7.vzw.com/is/image/VerizonWireless/6gb_0518",
                        "planCategoryName": "MORE EVERYTHING TALK TEXT DATA",
                        "effectiveDate": null,
                        "planAttributes": {
                          "sharePlan": true,
                          "isJax": false,
                          "isFelix": false
                        },
                        "accessCharge": null,
                        "imageUrlMap": null,
                        "planPromotions": null
                      },
                      "currentSPOs": null,
                      "currentFeatures": [
                        {
                          "sfoId": "48526",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "48553",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "68869",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "68870",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "68871",
                          "price": "0.00",
                          "isActive": true,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/3way_Calling_012918",
                          "existing": false
                        },
                        {
                          "sfoId": "68872",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "68873",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "68874",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "68876",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "73324",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "74774",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "75632",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "75706",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "75802",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "75836",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "75837",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "76152",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918",
                          "existing": false
                        },
                        {
                          "sfoId": "76404",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "76600",
                          "price": "0.00",
                          "isActive": true,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/Caller_ID_012918",
                          "existing": false
                        },
                        {
                          "sfoId": "77249",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "77256",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "77524",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "77556",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "77568",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "77573",
                          "price": "15.0",
                          "isActive": true,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/Line_Access_Charge_012918",
                          "existing": false
                        },
                        {
                          "sfoId": "77581",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "77583",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "77885",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "78706",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "78707",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "78732",
                          "price": "0.00",
                          "isActive": true,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/Voicemail_012918",
                          "existing": false
                        },
                        {
                          "sfoId": "80148",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "81158",
                          "price": "0.00",
                          "isActive": true,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/HD_Voice_012918",
                          "existing": false
                        },
                        {
                          "sfoId": "83856",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "86225",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "86226",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "86227",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "88145",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        }
                      ],
                      "addOnDueMonthly": null,
                      "equipmentUpgradeEligibility": {
                        "upgradeEligible": true,
                        "annualUpgradeEligible": false,
                        "buyoutEligible": false,
                        "earlyUpgradeEligible": false,
                        "edgeUpEligible": false,
                        "upgradeEligibilityDate": "12/19/2022",
                        "upgradeEligibilityLabel": "Upgrade Now",
                        "buyoutAmountLabel": null,
                        "pendingOrderDetail": null,
                        "isWithInWFGperiod": true,
                        "discountEligibility": {
                          "discountEligible": true,
                          "eligibilityLabel": "DISCOUNT ELIGIBLE"
                        },
                        "hadTwoBuyoutInCurrentMonth": false,
                        "transferUpgradeEligibility": {
                          "giverEligible": true,
                          "takerEligible": false,
                          "takerMtns": []
                        }
                      },
                      "lineLevelChangeEligibility": {
                        "isDeviceOnlyChangeAllowed": true,
                        "isFeatureChangeAllowed": true,
                        "isLLBChangeAllowed": true,
                        "isMtnChangeAllowed": true,
                        "isMtnSuspendAllowed": true,
                        "isPricePlanChangeAllowed": true,
                        "pendingOrderDetail": null
                      },
                      "mobileInfoAttributes": {
                        "paidInsuranceExist": false,
                        "numberShareParent": "",
                        "accountOwner": false,
                        "accessRoles": null,
                        "hasReferAFriend": false
                      },
                      "tradeInPromo": null,
                      "inServiceDate": null,
                      "lineSharingIndicator": "",
                      "lineAccessCharge": null,
                      "installmentLoans": [],
                      "earlyTermination": null,
                      "mobileInfoInsurance": {},
                      "availableMTNsForLoanTransfer": {},
                      "offers": null,
                      "recentPurchaseOrder": {
                        "purchasePrice": "160.00",
                        "retailPrice": "179.99"
                      },
                      "marketingOption": {
                        "vzCCHolder": false
                      },
                      "totalDueMonthly": null,
                      "planChangeHoldOrdersFound": null,
                      "mtnEffectiveDate": null,
                      "isEqpOrAccOfferAccepted": null,
                      "lineLevelCurrentCostData": {},
                      "networkBandwidthType": "",
                      "deviceMtnIndicator": "",
                      "showSUGToggle": true,
                      "balanceAmount": null,
                      "isNewLine": false,
                      "sharePlan": null,
                      "fiosEligibilityCategory": null,
                      "accountAddress": null,
                      "newLine": false
                    },
                    {
                      "mtn": "5185673928",
                      "deviceTypeSelected": "5G Internet",
                      "numberShare": null,
                      "mtnHashCode": "87c29fdbdb62783f5348abd0ba8f840c5281fe24d99b1ed94406e5c48b499887",
                      "nickName": "JAKE A WRIGHT-3926",
                      "benefitPair": {
                        "pairedPhoneMtn": null,
                        "eligibleToPair": false,
                        "existingPair": false,
                        "grantee": false,
                        "grantor": false
                      },
                      "primaryUser": {
                        "firstName": "RYAN",
                        "lastName": "WRIGHT",
                        "preferFirstName": "",
                        "preferLastName": "",
                        "preferPronoun": ""
                      },
                      "mtnStatus": {
                        "isActive": true,
                        "isDisconnected": false,
                        "isReassignedAndInActive": false,
                        "isSuspendedWithBilling": false,
                        "isSuspendedWithoutBilling": false,
                        "mtnSuspendAllowed": false,
                        "isMtnSuspended": false,
                        "mtnStatusReasonCode": "",
                        "isMtnChanged": null,
                        "isReassigned": null,
                        "isTransfered": false,
                        "status": "AR"
                      },
                      "equipmentInfos": [
                        {
                          "deviceInfo": {
                            "deviceId": "353756110808409",
                            "deviceSku": "SMA102UZKVZ",
                            "deviceUrl": "https://ss7.vzw.com/is/image/VerizonWireless/Samsung-Galaxy-A10e-Device-07312019",
                            "productDisplayName": "Galaxy A10e",
                            "category": {
                              "smartphone": true,
                              "tablet": false,
                              "basicphone": false,
                              "connectedDevice": false,
                              "internetDevice": false,
                              "homePC": false,
                              "telematics": false,
                              "virtualDevice": false,
                              "WSOnly": false
                            },
                            "tradeInValue": "0.00",
                            "displayName": "Samsung Galaxy A10e in Charcoal Black",
                            "capacity": null,
                            "deviceType": {
                              "backupRouter4G": null,
                              "device4G": null,
                              "device3G": null,
                              "device5GA": false,
                              "device5GE": false,
                              "antenna5G": false,
                              "home5G": false,
                              "deviceType": "4GE",
                              "home4GLte": false
                            },
                            "numberShareCapability": null,
                            "cdmaRestrictedDevice": false
                          },
                          "simInfo": {
                            "simId": "89148000005700881964",
                            "simSku": "EMBDSIMTRI",
                            "skuType": null
                          }
                        }
                      ],
                      "pricePlanInfo": {
                        "planId": "92775",
                        "description": "MORE EVERY UNL TLK&TXT 6GB",
                        "planDisplayName": null,
                        "planImageUrl": "https://ss7.vzw.com/is/image/VerizonWireless/6gb_0518",
                        "planCategoryName": "MORE EVERYTHING TALK TEXT DATA",
                        "effectiveDate": null,
                        "planAttributes": {
                          "sharePlan": true,
                          "isJax": false,
                          "isFelix": false
                        },
                        "accessCharge": null,
                        "imageUrlMap": null,
                        "planPromotions": null
                      },
                      "currentSPOs": null,
                      "currentFeatures": [
                        {
                          "sfoId": "48526",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        },
                        {
                          "sfoId": "48553",
                          "price": "0.00",
                          "isActive": false,
                          "imageUrlMap": "https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216",
                          "existing": false
                        }
                      ],
                      "addOnDueMonthly": null,
                      "equipmentUpgradeEligibility": {
                        "upgradeEligible": true,
                        "annualUpgradeEligible": false,
                        "buyoutEligible": false,
                        "earlyUpgradeEligible": false,
                        "edgeUpEligible": true,
                        "upgradeEligibilityDate": "03/15/2022",
                        "upgradeEligibilityLabel": "Upgrade Now",
                        "buyoutAmountLabel": null,
                        "pendingOrderDetail": null,
                        "isWithInWFGperiod": true,
                        "discountEligibility": {
                          "discountEligible": true,
                          "eligibilityLabel": "DISCOUNT ELIGIBLE"
                        },
                        "hadTwoBuyoutInCurrentMonth": false,
                        "transferUpgradeEligibility": {
                          "giverEligible": true,
                          "takerEligible": false,
                          "takerMtns": []
                        }
                      },
                      "lineLevelChangeEligibility": {
                        "isDeviceOnlyChangeAllowed": true,
                        "isFeatureChangeAllowed": true,
                        "isLLBChangeAllowed": true,
                        "isMtnChangeAllowed": true,
                        "isMtnSuspendAllowed": true,
                        "isPricePlanChangeAllowed": true,
                        "pendingOrderDetail": null
                      },
                      "mobileInfoAttributes": {
                        "paidInsuranceExist": false,
                        "numberShareParent": "",
                        "accountOwner": false,
                        "accessRoles": null,
                        "hasReferAFriend": false
                      },
                      "tradeInPromo": null,
                      "inServiceDate": null,
                      "lineSharingIndicator": "",
                      "lineAccessCharge": null,
                      "installmentLoans": [],
                      "earlyTermination": null,
                      "mobileInfoInsurance": {},
                      "availableMTNsForLoanTransfer": {},
                      "offers": null,
                      "recentPurchaseOrder": null,
                      "marketingOption": {
                        "vzCCHolder": false
                      },
                      "totalDueMonthly": null,
                      "planChangeHoldOrdersFound": null,
                      "mtnEffectiveDate": null,
                      "isEqpOrAccOfferAccepted": null,
                      "lineLevelCurrentCostData": {},
                      "networkBandwidthType": "",
                      "deviceMtnIndicator": "",
                      "showSUGToggle": true,
                      "balanceAmount": null,
                      "isNewLine": false,
                      "sharePlan": null,
                      "fiosEligibilityCategory": null,
                      "accountAddress": null,
                      "newLine": false
                    }
                  ],
                }
              ],
              isSalesRepIdMismatch: false,
              repId: 'ENC13',
              loggedInUser: 'tabmgr',
              channel: 'OMNI-RETAIL',
              isComboOrderAllowed: false,
              isFWASimplificationEnabled: false,
              homeSalesAddressList: [],
              secondNumPlanExists: false,
              qualificationDetails: {
                cartId: '',
              },
            },
          },
        }),
      );
    }),
  ];
  const server = setupServer(...handlers);
  const activeMtn = 'newLine2';
  jest.setTimeout(20000);
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify(mislGridData.cradleData));
    sessionStorage.setItem('activeMTN', 'newLine2');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
    sessionStorage.setItem('APP_PROPERTIES', '');
    sessionStorage.setItem('activeMTN', '');
  });
  beforeEach(() => {
    jest.spyOn(console, 'error');
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);
    window.vzdl = {
      ...window.vzdl,
      event: {
        value: '',
      },
      page: {
        detail: '',
        flow: 'NSE',
      },
    };
    const location = {
      ...window.location,
      search: `?activeMtn=${activeMtn}`,
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=${activeMtn}`;
    render(<Gridwall resetToggleOptions={jest.fn()} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('compare modal testing', async () => {
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    const byodTile = await screen.findByRole('button', { name: 'Bring Your Own Device' });
    fireEvent.click(byodTile);
    const gridPage = await screen.findByText('Add customer-provided equipment');
    waitFor(() => expect(gridPage).toBeInTheDocument());
    const closebtn = await screen.findByText('Close');
    fireEvent.click(closebtn);
    waitFor(() => expect(byodTile).toBeInTheDocument());
  });
});
