export const SetStorageSession = (key, value) => {
  window.sessionStorage.setItem(key, value);
};
export const setSession = (sessionName, value) => {
  window.sessionStorage.setItem(sessionName, value);
};

export const getSession = (name) => {
  const value = window.sessionStorage.getItem(name);
  return value;
};

export const ClearStorageSession = () => {
  window.sessionStorage.clear();
};

