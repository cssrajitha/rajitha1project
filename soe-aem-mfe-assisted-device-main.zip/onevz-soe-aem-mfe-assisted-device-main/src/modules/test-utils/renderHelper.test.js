import { render, screen } from './renderHelper';
import { wait } from './utils';

const Comp = () => 'Hello World!';
describe(`App component`, () => {
  test('App should mount', async () => {
    render(<Comp />);
    await wait();
    expect(screen.getByText('Hello World!')).toBeInTheDocument();
  });
});
