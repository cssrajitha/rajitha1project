// channel setup utils
export const CHANNELS = {
  OMNI_TELESALES: 'OMNI-TELESALES',
  OMNI_RETAIL: 'OMNI-RETAIL',
  OMNI_RETAIL_TAB: 'OMNI-RETAIL-TAB',
  OMNI_D2D: 'OMNI-D2D',
  OMNI_INDIRECT: 'OMNI-INDIRECT',
  OMNI_CARE: 'OMNI-CARE',
  CHAT_STORE: 'CHAT-STORE',
};

export const setupChannel = (channel) => {
  beforeAll(() => {
    sessionStorage.setItem('channel', channel);
    sessionStorage.setItem('APIContext', getApiContext(channel));
  });

  afterAll(() => {
    sessionStorage.setItem('channel', '');
    sessionStorage.setItem('APIContext', '');
  });
};

export const getApiContext = (channel) => {
  if (channel === CHANNELS.OMNI_TELESALES) {
    return 'https://telestore-soe.vzwcorp.com';
  }
  if (channel === CHANNELS.OMNI_RETAIL || channel === CHANNELS.OMNI_RETAIL_TAB) {
    return 'https://sposstore-soe.vzwcorp.com';
  }
};

export const setUserAgentIPad = () => {
  const { userAgent } = global.navigator;
  beforeAll(() => {
    Object.defineProperty(global.navigator, 'userAgent', {
      get() {
        return 'iPad';
      },
      configurable: true,
    });
  });
  afterAll(() => {
    Object.defineProperty(global.navigator, 'userAgent', {
      get() {
        return userAgent;
      },
      configurable: true,
    });
  });
};

export async function wait(ms = 1000) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

export const onKeyPressEvent = (e) => {
  if (e?.charCode === 13 || e?.charCode === 32) {
    return true;
  }

  return false;
};
