import moment from 'moment';
import { sendCustomEvent } from 'onevzsoemfeframework/Tagging';
import UserProfile from 'onevzsoemfeframework/AcssUserProfile';

import { cloneDeep, isEmpty, isNull } from 'lodash';
/* eslint-disable no-nested-ternary */
export const getFilteredCategory = (categoryFilterValue, is5gLine) =>
  categoryFilterValue === 'All devices'
    ? 'postpaid-devices'
    : categoryFilterValue === 'Certified Pre-owned' || categoryFilterValue?.toLowerCase()?.includes('smartphone')
      ? 'Smartphones'
      : is5gLine && categoryFilterValue?.toLowerCase()?.includes('5g internet')
        ? '5g-Internet'
        : categoryFilterValue?.toLowerCase()?.includes('internet')
          ? 'Internet Devices'
          : categoryFilterValue?.toLowerCase()?.includes('connected device')
            ? 'Connected Devices'
            : categoryFilterValue?.toLowerCase()?.includes('smartwatch')
              ? 'Connected Smartwatches'
              : categoryFilterValue?.toLowerCase()?.includes('tablet')
                ? 'Tablets'
                : categoryFilterValue?.toLowerCase()?.includes('home/office')
                  ? 'Home/Office Solutions'
                  : categoryFilterValue?.toLowerCase()?.includes('business solution')
                    ? 'Business Solutions'
                    : categoryFilterValue?.toLowerCase()?.includes('basic phone')
                      ? 'Basic Phones'
                      : categoryFilterValue?.toLowerCase()?.includes('unlocked phones')
                        ? 'unlocked-smartphones'
                        : categoryFilterValue?.toLowerCase()?.includes('netbooks')
                          ? ''
                          : categoryFilterValue?.toLowerCase()?.includes('machine') ||
                              categoryFilterValue === 'undefineds' ||
                              categoryFilterValue?.toLowerCase()?.includes('jet')
                            ? ''
                            : categoryFilterValue;

export function mPosFormatDate(value, actualFormat, formatPattern = 'MM/DD/YYYY') {
  return moment(value, actualFormat).format(formatPattern);
}

export function makeOpenViewCall(pageDetail = '') {
  if (!window?.vzdl?.page?.detail || window?.vzdl?.page?.detail !== pageDetail) {
    const vzdl = window?.vzdl || {};
    /* istanbul ignore if */
    if (pageDetail && vzdl?.page) {
      vzdl.page = { ...vzdl.page, detail: pageDetail === 'deleteLostStolenDevice' ? 'deleteLostStolenDevice' : `Product Detail | ${pageDetail}` };
      if (vzdl?.event) vzdl.event = { ...vzdl.event, value: '' };
    }
    window.vzdl = vzdl;
    sendCustomEvent('openView', window?.vzdl);
  }
}

export const getFFlag = (flag) => {
  const featureEnablement =
    localStorage.getItem('featureEnablement') && JSON.parse(localStorage.getItem('featureEnablement'));
  if (featureEnablement) {
    return featureEnablement[flag];
  }
  return null;
};

const initializeUserProfile = () => {
  const getUserProfile = UserProfile.getProfile();

  if (isEmpty(getUserProfile)) {
    const userProfileString = localStorage.getItem('userprofile');
    if (userProfileString) {
      UserProfile.setProfile(JSON.parse(userProfileString));
    }
  }
};

export const isDBFlagEnabled = (flag) => {
  initializeUserProfile();
  const enableForSR = UserProfile.getSRDeptPermission(flag);
  const enabledForSession = UserProfile.getSessionPermission(flag);
  const enableForPilot = UserProfile.getPilotProperty(flag);

  return enableForSR === 'Y' || enabledForSession === 'Y' || enableForPilot === 'Y';
};

export const isFunctionalityEnabled = (fFlag, attribute, dbFlag) => {
  const fFlagData = getFFlag(fFlag);
  const dbFlagEnabled = dbFlag ? isDBFlagEnabled(dbFlag) : true;

  if (attribute && fFlagData?.[attribute]?.find((attr) => attr === 'Y')) {
    return dbFlagEnabled;
  } else if (!attribute) {
    return fFlagData === 'Y' && dbFlagEnabled;
  }
  return false;
};

export const getAddressInfo = (qualificationDetails, date) => {
  let addressInfo = qualificationDetails;
  const address_details = JSON.parse(sessionStorage.getItem('address_Details')) ;
  if (Object.keys(addressInfo).length === 0 && address_details) {
    addressInfo = address_details;
  }
  const { addressLine2 = '' } = addressInfo;
  const address2Apt = /\s/.test(addressLine2);
  /* istanbul ignore next */
  const addressLine2Split = address2Apt ? addressLine2.split(' ') : '';
  /* istanbul ignore next */
  const apartmentNo = address2Apt ? addressLine2Split[1] : addressLine2;
  const deliverAddress = {
    selfInstallDate: date,
    address: {
      streetNumber: addressInfo.streetNumber,
      streetName: addressInfo.streetName,
      streetType: addressInfo.streetType,
      streetDirection: addressInfo?.streetDirection || '',
      addressLine1: addressInfo.addressLine1,
      addressLine2,
      apartmentNo,
      city: addressInfo.city,
      state: addressInfo.state,
      zipCode: addressInfo.zipCode,
      zipCode4: addressInfo.zipCodePlus4,
      firstName: addressInfo.firstName,
      lastName: addressInfo.lastName,
      eventCorrelationId: addressInfo.eventCorrelationId,
    },
  };
  return deliverAddress;
};

export const getSCMFilteredDfillAndBulkSims = (compatibleSimSorIds) => {
  let filteredCompatibleSims = compatibleSimSorIds?.filter((sim) => sim?.includes('DFILL') || sim?.includes('BULK'));
  if (filteredCompatibleSims?.length === 0) {
    filteredCompatibleSims = ['BULKSIM5G-SA-S', 'DFILLUNIV5G-SA-A', 'DFILLSIM-TRI-A'];
  }
  return filteredCompatibleSims;
};
