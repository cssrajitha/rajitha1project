import { isVbgAem } from 'onevzsoemfeframework/VbgAemUtil';
import { getVbgFwaProfInstallOrderingFlag, isVbgFwaMLOrderingFFlag } from './vbgUtils';
const { isVbgnsaDropshipFFlag } = require('./vbgUtils');

// Mock the VbgAemUtil module
jest.mock('onevzsoemfeframework/VbgAemUtil', () => ({
  isVbgAem: jest.fn(),
}));

describe('vbgUtils', () => {
  const mockIsVbgAem = isVbgAem;

  beforeEach(() => {
    // Clear all mocks before each test
    jest.clearAllMocks();
    // Clear sessionStorage
    sessionStorage.clear();
  });

  describe('getVbgFwaProfInstallOrderingFlag', () => {
    it('should return true when isVbgAem is true and flag is TRUE', () => {
      mockIsVbgAem.mockReturnValue(true);
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({
        vbgFwaProfInstallOrderingFFlag: 'TRUE'
      }));

      const result = getVbgFwaProfInstallOrderingFlag();
      expect(result).toBe(true);
    });

    it('should return false when isVbgAem is false', () => {
      mockIsVbgAem.mockReturnValue(false);
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({
        vbgFwaProfInstallOrderingFFlag: 'TRUE'
      }));

      const result = getVbgFwaProfInstallOrderingFlag();
      expect(result).toBe(false);
    });

    it('should return false when flag is not TRUE', () => {
      mockIsVbgAem.mockReturnValue(true);
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({
        vbgFwaProfInstallOrderingFFlag: 'FALSE'
      }));

      const result = getVbgFwaProfInstallOrderingFlag();
      expect(result).toBe(false);
    });

    it('should return false when APP_PROPERTIES is not in sessionStorage', () => {
      mockIsVbgAem.mockReturnValue(true);

      const result = getVbgFwaProfInstallOrderingFlag();
      expect(result).toBe(false);
    });
  });

  describe('isVbgFwaMLOrderingFFlag', () => {
    it('should return true when isVbgAem is true and flag is TRUE', () => {
      mockIsVbgAem.mockReturnValue(true);
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({
        vbgFwaMLOrderingFFlag: 'TRUE'
      }));

      const result = isVbgFwaMLOrderingFFlag();
      expect(result).toBe(true);
    });

    it('should return false when isVbgAem is false', () => {
      mockIsVbgAem.mockReturnValue(false);
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({
        vbgFwaMLOrderingFFlag: 'TRUE'
      }));

      const result = isVbgFwaMLOrderingFFlag();
      expect(result).toBe(false);
    });
  });
describe('isVbgnsaDropshipFFlag', () => {

  it('should return true when isVbgAem is true and flag is TRUE', () => {
    mockIsVbgAem.mockReturnValue(true);
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({
      vbgnsaDropshipFFlag: 'TRUE'
    }));

    const result = isVbgnsaDropshipFFlag();
    expect(result).toBe(true);
  });

  it('should return false when isVbgAem is false', () => {
    mockIsVbgAem.mockReturnValue(false);
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({
      vbgnsaDropshipFFlag: 'TRUE'
    }));

    const result = isVbgnsaDropshipFFlag();
    expect(result).toBe(false);
  });

  it('should return false when flag is not TRUE', () => {
    mockIsVbgAem.mockReturnValue(true);
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({
      vbgnsaDropshipFFlag: 'FALSE'
    }));

    const result = isVbgnsaDropshipFFlag();
    expect(result).toBe(false);
  });

  it('should return false when APP_PROPERTIES is not in sessionStorage', () => {
    mockIsVbgAem.mockReturnValue(true);
    sessionStorage.clear();

    const result = isVbgnsaDropshipFFlag();
    expect(result).toBe(false);
  });
});
});
