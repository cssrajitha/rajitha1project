import { getPricingPriority, getDpTermIndex } from './devicePricingUtils';

describe('devicePricingUtils', () => {
  describe('getPricingPriority', () => {
    it('returns the first available option from otherPriceList if devicePaymentPrice is missing', () => {
      const price = {
        threeYearPrice: { originalPrice: 1000 },
        twoYearPrice: { originalPrice: 900 },
        oneYearPrice: { originalPrice: 800 },
      };
      expect(getPricingPriority(price)).toBe('threeYearPrice');
    });

    it('returns the first available option from otherPriceList if devicePaymentPrice is empty', () => {
      const price = {
        devicePaymentPrice: [],
        twoYearPrice: { originalPrice: 900 },
        oneYearPrice: { originalPrice: 800 },
      };
      expect(getPricingPriority(price)).toBe('twoYearPrice');
    });

    it('returns null if no matching options are found', () => {
      const price = {
        devicePaymentPrice: [],
      };
      expect(getPricingPriority(price)).toBeNull();
    });

    it('returns "fullRetailPrice" if only fullRetailPrice is present', () => {
      const price = {
        fullRetailPrice: { originalPrice: 1200 },
      };
      expect(getPricingPriority(price)).toBe('fullRetailPrice');
    });

    it('returns null if price is undefined or not an object', () => {
      expect(getPricingPriority(undefined)).toBeNull();
      expect(getPricingPriority(null)).toBeNull();
      expect(getPricingPriority(42)).toBeNull();
      expect(getPricingPriority('string')).toBeNull();
    });
  });
  describe('getDpTermIndex', () => {
    it('returns the index of the matching dpTerm in devicePaymentPrice', () => {
      const price = {
        devicePaymentPrice: [{ dpTermPrices: { dpTerm: 24 } }, { dpTermPrices: { dpTerm: 30 } }],
      };
      expect(getDpTermIndex(price)).toBe(1);
    });

    it('returns -1 if no matching dpTerm is found', () => {
      const price = {
        devicePaymentPrice: [],
      };
      expect(getDpTermIndex(price)).toBe(-1);
    });

    it('returns -1 if devicePaymentPrice is not present', () => {
      const price = {};
      expect(getDpTermIndex(price)).toBe(-1);
    });
  });
});
