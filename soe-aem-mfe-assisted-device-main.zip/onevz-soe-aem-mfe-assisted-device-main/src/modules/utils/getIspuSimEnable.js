import { getQueryParamByName, isTelesales, isChatStore, isOmniCare } from 'onevzsoemfeframework/DomService';

export default function getIspuSimEnable(omnicaredropdownValue = 'Device change') {
  const isFromCpe = getQueryParamByName('isFromCPE');
  const eSim = getQueryParamByName('eSim');
  const isByodUpdate = getQueryParamByName('isByodUpdate');
  const enable = isFromCpe && (isTelesales() || isChatStore() || isOmniCare()) && !eSim;
  // for sim only change in care it will be false
  const careEnable = isByodUpdate && isOmniCare() && !eSim && omnicaredropdownValue === 'Device change';

  return enable || careEnable;
}
