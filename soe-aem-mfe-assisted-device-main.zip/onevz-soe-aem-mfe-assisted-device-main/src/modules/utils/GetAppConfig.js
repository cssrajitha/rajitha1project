import appConfig from '../../appconfig.json';

export const GetAppConfig = () => appConfig;
