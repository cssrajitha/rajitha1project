import { isVbgAem } from 'onevzsoemfeframework/VbgAemUtil';


/**
 * Checks if the VBG FWA Professional Installation Ordering feature flag is enabled
 * @returns {boolean} True if the flag is enabled, false otherwise
 */
export const getVbgFwaProfInstallOrderingFlag = () => {
  const isVbgFwaProfInstallFlagEnabled = isVbgAem() && JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.vbgFwaProfInstallOrderingFFlag === 'TRUE';
  return isVbgFwaProfInstallFlagEnabled;
};

/**
 * Checks if the VBG FWA ML Ordering feature flag is enabled
 * @returns {boolean} True if the flag is enabled, false otherwise
 */
export const isVbgFwaMLOrderingFFlag = () => {
  const vbgFwaMLOrderingFFlag = isVbgAem() && JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.vbgFwaMLOrderingFFlag === 'TRUE';
  return vbgFwaMLOrderingFFlag;
};

/**
 * Checks if the VBG NSA Dropship feature flag is enabled
 * @returns {boolean} True if the flag is enabled, false otherwise
 */
export const isVbgnsaDropshipFFlag = () => {
  const vbgnsaDropshipFFlag = isVbgAem() && JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.vbgnsaDropshipFFlag === 'TRUE';
  return vbgnsaDropshipFFlag;
};



