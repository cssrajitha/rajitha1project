import UserProfile from 'onevzsoemfeframework/AcssUserProfile';
import FFLAGS from '../../constants/fFlag.constant';
import { getFilteredCategory, isFunctionalityEnabled, makeOpenViewCall } from './index';

const mockUserProfile = {
  userId: 'mohma1c',
  serviceRegionId: '113',
  serviceRegionName: 'Basking Ridge NJ',
  departmentId: '109',
  departmentName: 'ACSS Support',
  firstName: 'Mohan, Madan',
  lastName: 'Madan Mohan',
  userType: 'ACSS',
  redisUpdatedDate: 'Date: 18-SEPTEMBER-2025- Time: 6:41:41',
  themeId: 'theme_white',
  prepayRoleId: '160',
  pilotProperties: {
    ACSS_SC_GENERATE_ESIM_ENABLE: 'Y',
  },
};

describe(`getFilteredCategory and check openviewcalls`, () => {
  test('getFilteredCategory', async () => {
    expect(getFilteredCategory('All devices')).toBe('postpaid-devices');
    expect(getFilteredCategory('smartphone')).toBe('Smartphones');
    expect(getFilteredCategory('5g internet', true)).toBe('5g-Internet');
    expect(getFilteredCategory('internet')).toBe('Internet Devices');
    expect(getFilteredCategory('connected device')).toBe('Connected Devices');
    expect(getFilteredCategory('smartwatch')).toBe('Connected Smartwatches');
    expect(getFilteredCategory('tablet')).toBe('Tablets');
    expect(getFilteredCategory('home/office')).toBe('Home/Office Solutions');
    expect(getFilteredCategory('business solution')).toBe('Business Solutions');
    expect(getFilteredCategory('basic phone')).toBe('Basic Phones');
    expect(getFilteredCategory('unlocked phones')).toBe('unlocked-smartphones');
    expect(getFilteredCategory('netbooks')).toBe('');
    expect(getFilteredCategory('machine')).toBe('');
    expect(getFilteredCategory('jet')).toBe('');
    expect(getFilteredCategory('')).toBe('');
  });
  test('makeOpenViewCall', () => {
    makeOpenViewCall();
  });

  test('makeOpenViewCall with param', () => {
    makeOpenViewCall('Device Protection');
  });
});

describe(`Test utility function isFunctionalityEnabled`, () => {
  test('It should return false when functionality enabled', async () => {
    expect(
      isFunctionalityEnabled(FFLAGS.scmMiscFixFFlag.name, FFLAGS.scmMiscFixFFlag.attribute.generateESimProfile),
    ).toBe(false);
  });

  test('It should return true when functionality enabled', async () => {
    localStorage.setItem('featureEnablement', JSON.stringify({ scmMiscFixFFlag: { generateESimProfile: ['Y'] } }));
    expect(
      isFunctionalityEnabled(FFLAGS.scmMiscFixFFlag.name, FFLAGS.scmMiscFixFFlag.attribute.generateESimProfile),
    ).toBe(true);
  });

  test('It should return true when pass valid fFlag', async () => {
    localStorage.setItem('featureEnablement', JSON.stringify({ scmMiscFixFFlag: 'Y' }));
    expect(isFunctionalityEnabled(FFLAGS.scmMiscFixFFlag.name)).toBe(true);
  });

  test('It should return false when pass valid dbFlag and not profile not exist', async () => {
    localStorage.setItem('featureEnablement', JSON.stringify({ scmMiscFixFFlag: { generateESimProfile: ['Y'] } }));
    expect(
      isFunctionalityEnabled(
        FFLAGS.scmMiscFixFFlag.name,
        FFLAGS.scmMiscFixFFlag.attribute.generateESimProfile,
        FFLAGS.scmMiscFixFFlag.attribute.eSimDbFlag,
      ),
    ).toBe(false);
  });

  test('It should return true when pass valid dbFlag and profile also set', async () => {
    localStorage.setItem('userprofile', JSON.stringify(mockUserProfile));
    localStorage.setItem('featureEnablement', JSON.stringify({ scmMiscFixFFlag: { generateESimProfile: ['Y'] } }));
    expect(
      isFunctionalityEnabled(
        FFLAGS.scmMiscFixFFlag.name,
        FFLAGS.scmMiscFixFFlag.attribute.generateESimProfile,
        FFLAGS.scmMiscFixFFlag.attribute.eSimDbFlag,
      ),
    ).toBe(true);
    localStorage.removeItem('userprofile');
    UserProfile.setProfile({});
  });

  test('It should return true when pass profile already set with Db flag', async () => {
    UserProfile.setProfile(mockUserProfile);
    localStorage.setItem('featureEnablement', JSON.stringify({ scmMiscFixFFlag: { generateESimProfile: ['Y'] } }));
    expect(
      isFunctionalityEnabled(
        FFLAGS.scmMiscFixFFlag.name,
        FFLAGS.scmMiscFixFFlag.attribute.generateESimProfile,
        FFLAGS.scmMiscFixFFlag.attribute.eSimDbFlag,
      ),
    ).toBe(true);
    UserProfile.setProfile({});
  });
});
