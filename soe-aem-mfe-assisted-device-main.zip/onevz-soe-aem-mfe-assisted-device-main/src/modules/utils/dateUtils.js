/**
 * Convert a date string from MM/DD/YY to MM/DD/YYYY with basic input validation.
 *
 * Contract:
 * - Input: string in the format MM/DD/YY (two-digit year)
 * - Output: string in the format MM/DD/YYYY; returns the original input on validation failure
 * - Error handling: Non-string inputs, malformed strings, or invalid numeric ranges return the input unchanged
 *
 * Sliding window assumption:
 * - A 20-year forward threshold is applied when inferring the century for two-digit years.
 *   If the inferred full year would be more than 20 years ahead of the current year,
 *   the year is wrapped to the previous century.
 *   Example (currentYear = 2026): '01/01/50' -> 1950 (since 2050 > 2026 + 20), '01/01/45' -> 2045.
 *
 * @param {string} dStr
 * @returns {string}
 */
export const toFullYear = (dStr) => {
  if (!dStr || typeof dStr !== 'string') return dStr;
  const parts = dStr.split('/');
  if (parts.length !== 3) return dStr;

  const [mm, dd, yy] = parts;
  // Validate presence
  if (!mm || !dd || !yy) return dStr;

  // Year must be either 2 or 4 digits; reject other formats explicitly
  if (yy.length !== 2 && yy.length !== 4) return dStr;
  // Already in YYYY format – return unchanged
  if (yy.length === 4) return dStr;

  // Validate numeric month/day
  const mmNum = Number.parseInt(mm, 10);
  const ddNum = Number.parseInt(dd, 10);
  if (Number.isNaN(mmNum) || Number.isNaN(ddNum)) return dStr;
  if (mmNum < 1 || mmNum > 12 || ddNum < 1 || ddNum > 31) return dStr;

  // Compute full year using sliding window logic
  const currentYear = new Date().getFullYear();
  const currentCentury = Math.floor(currentYear / 100);
  const twoDigitYear = Number.parseInt(yy, 10);
  if (Number.isNaN(twoDigitYear)) return dStr;

  // Sliding window: infer century so that dates more than ~20 years ahead
  // wrap to the previous century (e.g., '99' -> 1999 when currentYear is 2026)
  let fullYear = (currentCentury * 100) + twoDigitYear;
  if (fullYear > currentYear + 20) {
    fullYear -= 100;
  }

  return `${mm}/${dd}/${fullYear}`;
};
