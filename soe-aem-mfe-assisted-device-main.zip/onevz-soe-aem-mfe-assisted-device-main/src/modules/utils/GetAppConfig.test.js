import { GetAppConfig } from './GetAppConfig';

describe('Test Get AppConfig', () => {
  test('Test Appconfig', () => {
    const result = GetAppConfig();
    expect(result.urls.addDevice).toBe('/cartservice/cart/flexV2/add-device');
  });
});
