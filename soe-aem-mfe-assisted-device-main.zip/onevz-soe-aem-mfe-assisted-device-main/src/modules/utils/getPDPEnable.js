import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';

export default function getPDPEnable() {
  const [flexRedesignMasterFFlag, flexRedesignFFlag] = getAssistedCradlePropertyV2([
    'flexRedesignMasterFFlag',
    'flexRedesignFFlag',
  ]);
  const isPDPMFECareEnabled = /true/i.test(sessionStorage?.getItem('isACSSFlexRedesign'));

  const isPDPenable = !!(flexRedesignMasterFFlag === 'TRUE' || flexRedesignFFlag === 'TRUE' || isPDPMFECareEnabled);

  return isPDPenable;
}
