import { toFullYear } from './dateUtils';

// Freeze time so year inference is deterministic
// Current date fixed to Jan 25, 2026
beforeAll(() => {
  jest.useFakeTimers('modern');
  jest.setSystemTime(new Date('2026-01-25T00:00:00Z'));
});

afterAll(() => {
  jest.useRealTimers();
});

describe('dateUtils.toFullYear', () => {
  it('returns input unchanged for non-string values', () => {
    expect(toFullYear(null)).toBeNull();
    // Numbers and objects pass through unchanged
    // @ts-ignore - testing runtime behavior
    expect(toFullYear(42)).toBe(42);
    // @ts-ignore
    const obj = { a: 1 };
    // @ts-ignore
    expect(toFullYear(obj)).toBe(obj);
  });

  it('returns input unchanged for malformed strings (no slashes or wrong parts)', () => {
    expect(toFullYear('010126')).toBe('010126');
    expect(toFullYear('01-01-26')).toBe('01-01-26');
  });

  it('returns input unchanged when year is already 4 digits', () => {
    expect(toFullYear('01/15/2026')).toBe('01/15/2026');
  });

  it('returns input unchanged when year length is not 2 or 4 digits (1 or 3 digits)', () => {
    expect(toFullYear('01/01/2')).toBe('01/01/2');
    expect(toFullYear('01/01/123')).toBe('01/01/123');
  });

  it('returns input unchanged for non-numeric 2-digit year', () => {
    expect(toFullYear('01/15/AB')).toBe('01/15/AB');
  });

  it('converts a 2-digit year within sliding window to current century (<= +20 years)', () => {
    // Current year is 2026; 27 -> 2027 should stay in current century
    expect(toFullYear('01/15/27')).toBe('01/15/2027');
    // Boundary: 46 -> 2046 (equal to currentYear + 20) stays in current century
    expect(toFullYear('06/30/46')).toBe('06/30/2046');
  });

  it('wraps to previous century when inferred year exceeds currentYear + 20', () => {
    // 47 -> 2047 would exceed threshold -> 1947
    expect(toFullYear('07/04/47')).toBe('07/04/1947');
    // 99 -> 2099 would exceed threshold -> 1999
    expect(toFullYear('12/31/99')).toBe('12/31/1999');
  });

  it('handles turn of century lower bound correctly (00 -> 2000)', () => {
    expect(toFullYear('01/01/00')).toBe('01/01/2000');
  });

  it('validates numeric month/day and ranges; returns input unchanged when invalid', () => {
    expect(toFullYear('13/01/26')).toBe('13/01/26'); // invalid month > 12
    expect(toFullYear('12/32/26')).toBe('12/32/26'); // invalid day > 31
    expect(toFullYear('01/XX/26')).toBe('01/XX/26'); // non-numeric day
    expect(toFullYear('MM/DD/26')).toBe('MM/DD/26'); // non-numeric month/day
    expect(toFullYear('/01/26')).toBe('/01/26'); // empty month
    expect(toFullYear('01//26')).toBe('01//26'); // empty day
  });

  it('supports single-digit month/day and converts correctly', () => {
    expect(toFullYear('1/5/26')).toBe('1/5/2026');
  });
});
