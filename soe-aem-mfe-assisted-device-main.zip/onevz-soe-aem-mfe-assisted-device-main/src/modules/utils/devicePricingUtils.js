import { dppKey, dpTermList, contractTermList } from "../../constants/constants";

export const getDpTermIndex = (price) => {
  if (price && Array.isArray(price?.[dppKey]) && price?.[dppKey]?.length > 0) {
    for (const option of dpTermList) {
      const foundIndex = price[dppKey].findIndex(item => item?.dpTermPrices?.dpTerm === option);
      if (foundIndex > -1) {
        return foundIndex;
      }
    }
  }
  return -1;
}

export const getPricingPriority = (price) => {
  if (price) {
    for (const option of contractTermList) {
      if (price?.[option]) {
        return option;
      }
    }
  }
  return null;
};
