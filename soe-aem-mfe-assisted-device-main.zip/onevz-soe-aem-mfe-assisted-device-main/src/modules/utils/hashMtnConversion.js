export default function hashMtnConversion(mtns, lineDetails, hashedMtn) {
  let convertedMTN = '';
  const lineSentFromETR = mtns?.filter((line) => line?.mtnHashCode === hashedMtn);
  const mtnDetailsFromCart = lineDetails?.lineInfo?.filter((line) => line?.lineNumber === hashedMtn);
  if (lineSentFromETR?.[0]?.mtn) {
    convertedMTN = lineSentFromETR?.[0]?.mtn;
  } else {
    convertedMTN = mtnDetailsFromCart?.[0]?.lineNumber ? mtnDetailsFromCart?.[0]?.lineNumber : convertedMTN;
  }
  return convertedMTN;
}
