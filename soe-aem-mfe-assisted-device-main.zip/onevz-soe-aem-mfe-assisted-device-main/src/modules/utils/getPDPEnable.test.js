import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import getPDPEnable from './getPDPEnable';

jest.mock('onevzsoemfeframework/AssistedCradleService');

describe('getPDPEnable', () => {
  beforeEach(() => {
    getAssistedCradlePropertyV2.mockReset();
  });

  test('should return true when flexRedesignMasterFFlag is "TRUE"', () => {
    getAssistedCradlePropertyV2.mockReturnValueOnce(['TRUE', 'FALSE']);
    const result = getPDPEnable();
    expect(result).toBe(true);
  });

  test('should return true when flexRedesignFFlag is "TRUE"', () => {
    getAssistedCradlePropertyV2.mockReturnValueOnce(['FALSE', 'TRUE']);
    const result = getPDPEnable();
    expect(result).toBe(true);
  });

  test('should return false when flexRedesignMasterFFlag, flexRedesignFFlag and isACSSFlexRedesign is "false"', () => {
    getAssistedCradlePropertyV2.mockReturnValueOnce(['FALSE', 'FALSE']);
    sessionStorage.setItem('isACSSFlexRedesign', false);
    const result = getPDPEnable();
    expect(result).toBe(false);
  });

  test('should return true when isACSSFlexRedesign is "true"', () => {
    getAssistedCradlePropertyV2.mockReturnValueOnce(['FALSE', 'FALSE']);
    sessionStorage.setItem('isACSSFlexRedesign', true);
    const result = getPDPEnable();
    expect(result).toBe(true);
  });
});
