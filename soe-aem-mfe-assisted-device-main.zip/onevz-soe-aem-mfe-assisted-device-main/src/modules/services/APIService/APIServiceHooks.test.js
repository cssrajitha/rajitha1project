import { TAG_PRODUCT_LIST } from './APIServiceHooks';

describe(`App component`, () => {
  test('App should mount', async () => {
    expect(TAG_PRODUCT_LIST).toBe('tag_product_list');
  });
});
