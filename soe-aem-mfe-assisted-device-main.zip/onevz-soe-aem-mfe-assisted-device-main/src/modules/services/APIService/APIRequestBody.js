import { isVbgAem } from 'onevzsoemfeframework/VbgAemUtil';
import { getQueryParamByName } from 'onevzsoemfeframework/DomService';

export const requestBodyRetriveCart = {
  meta: {
    client: 'CXP',
  },
  data: {
    cartId: '',
    retrieveCurrentFeatures: true,
    adobeSubkey: sessionStorage.getItem('adobe-sessionId') || '', // adobeSubkey is added solely for Tagging, pls do not remove it.
  },
};

const vbgFwaMLOrderingFFlag =
  isVbgAem() && JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.vbgFwaMLOrderingFFlag === 'TRUE';
const activeMTN = sessionStorage.getItem('activeMTN') || '';
const fiveGLinesCount = getQueryParamByName('fiveGLinesCount') || 0;

export const requestBodyCustomerProfile = {
  enableAssistedTagging: true,
  mtn: vbgFwaMLOrderingFFlag && fiveGLinesCount > 1 ? activeMTN : '',
};

export const requestBodyProductList = {
  data: {
    isPromoFilterDisabled: true,
    correlationId: '',
    enableGridwallPersonalization: true,
    enableGridwallPersonalizationNSE: false,
    market: '',
    custType: '',
    siteId: '',
    masterAgentCode: '',
    locationCode: '',
    productType: 'device',
    pageId: '',
    intentType: '',
    processingMTN: '',
    zipCode: '',
    customerLoggedInOrNot: false,
    compatibleProductId: '',
    prepayCart: false,
    orderType: '',
    filterSortData: {
      sortOption: '',
      paymentOption: '',
      filters: [
        {
          type: 'Category',
          values: ['Smartphones'],
        },
        {
          type: 'Brand',
          values: [''],
        },
        {
          type: 'OS',
          values: [''],
        },
      ],
    },
    paginationData: {
      offset: 0,
      recPerPage: 24,
    },
  },
};

export const initialRequestBodyDeviceDetails = {
  data: {
    productId: '',
    seoUrlName: '',
    correlationId: '',
    market: '',
    siteId: '',
    masterAgentCode: '',
    productType: 'device',
    mtnList: {
      eup: [],
      aal: [],
    },
    bogoEnabled: 'False',
    defaultSku: '',
    skuSearch: false,
    processingMTN: '',
    zipCode: '',
    enableAssistedTagging: true,
  },
};

export const initialRequestBodyProtectionFeatures = {
  mtn: '',
  deviceSorId: '',
  getHomeProtectionEligibility: false,
};

export const initialRequestBodyBundleRecommendations = {
  deviceId: '',
  cartId: '',
  skuId: '',
  promoFlow: null,
};

export const initialRequestBodyDpEligibility = {
  deviceId: '',
  cartId: '',
  skuId: '',
  promoFlow: null,
};

export const initialRequestBodyDownPaymnet = {
  header: {},
  cartId: '',
  accountNo: '',
  term: 36,
  sorId: 'MQ0E3LL/A',
  downPayment: 0,
  isPercentage: false,
  agentOrFullRetailPrice: 999.99,
};

export const initialRequestBodyUpgradeReasonCodes = {
  cartId: '',
  cartMtnList: [
    {
      mtn: '',
      deviceSku: '',
      contractType: '',
      reasonCodeType: '',
    },
  ],
};

export const initialRequestAddDevice = {
  cartInfo: {
    correlationId: '',
    processStep: '',
    processingMTN: '',
    processAction: '',
    intendType: '',
    number_share_capable: '',
    creditAppNum: null,
    isQuoteCart: false,
    enableDefaultedShipToHome: true,
    bogoEnabled: 'True',
  },
  data: {
    lines: [
      {
        mtn: '',
        lineDeviceDollar: 0,
        upgradeReasonCode: '',
        device: {
          category: '',
          deviceId: '',
          id: '',
          sorType: '',
          contractTerm: '',
          dppMonths: 0,
          isCustomerProvidedEquipment: false,
        },
        sim: {
          id: '',
          iccid: '',
          isCustomerProvidedSIM: false,
        },
        addFeatures: [
          {
            id: '',
            quantity: 0,
            actionIndicator: '',
            type: '',
          },
        ],
        downPayment: {
          amount: 0,
        },
        isKeepingExistingEqProtection: false,
        ispuFlow: false,
        newLineOrAAL: false,
        isNewLine: false,
        depletionLocationCode: '',
        depletionType: '',
        sddZipCode: '',
        preBackOrderDate: '',
        triggerPricingValidation: false,
      },
    ],
    selectedMtn: '',
    totalDeviceDollar: null,
    enableAssistedTagging: true,
  },
};

export const requestBodyFetchPricingShapshort = {
  cartId: '',
  caseId: '',
  quoteNSAEnabled: true,
  requestSource: 'LANDING',
};

export const initialRequestFiveGetDetails = {
  data: {
    productId: '',
    seoUrlName: '',
    correlationId: '',
    market: '',
    custType: '',
    siteId: '',
    masterAgentCode: '',
    locationCode: '',
    orderType: 'PS',
    productType: 'device',
    mtnList: {
      eup: [],
      aal: [],
    },
    isPortIn: false,
    bogoEnabled: 'True',
    intentType: '',
    defaultSku: '',
    skuSearch: false,
    cartCreator: '',
    processingMTN: '',
    zipCode: '',
    channel: 'assisted',
    customerLoggedInOrNot: false,
    enableBPM: true,
    networkBandWidthType: 'CBD',
  },
};

export const initialAddAccessoryRequest = {
  cartInfo: {
    correlationId: '69a66ef4d7e344dfb2db299209ea8333',
    processingMTN: '',
    processStep: 'ShoppingCart',
    processAction: 'addAccessory',
    intendType: 'EUP',
    creditAppNum: null,
  },
  data: {
    depletionType: '',
    lines: [
      {
        mtn: '',
        mdnFilterValue: '',
        removeAccessories: [],
        addAccessories: [],
        ispuFlow: false,
        depletionLocationCode: '',
      },
    ],
  },
};
