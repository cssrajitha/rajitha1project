const localStorageMock = (() => {
    let store = {};
    return {
        getItem(key) {
        return store[key] || null;
        },
        setItem(key, value) {
        store[key] = value?.toString();
        },
        removeItem(key) {
        delete store[key];
        },
        clear() {
        store = {};
        },
    };
})();

Object.defineProperty(window, 'sessionStorage', {
    value: localStorageMock,
});

describe('vbgFwaMLOrderingFFlag', () => {
  let mockIsVbgAem;
  let mockSessionStorage;

  beforeEach(() => {
    mockIsVbgAem = jest.fn();
    mockSessionStorage = {
      getItem: jest.fn(),
    };
    
    jest.doMock('onevzsoemfeframework/VbgAemUtil', () => ({
      isVbgAem: mockIsVbgAem,
    }));

    jest.mock(
      'onevzsoemfeframework/DomService',
      () => ({
        __esModule: true,
        default: jest.fn(() => ({})),
        ...jest.requireActual('onevzsoemfeframework/DomService'),
        getQueryParamByName: (value) => {
          if (value === 'fiveGLinesCount') return 2;
        },
      }),
      { virtual: true },
    );
    
    // Object.defineProperty(window, 'sessionStorage', {
    //   value: mockSessionStorage,
    //   writable: true,
    // });
  });

  afterEach(() => {
    jest.resetAllMocks();
    jest.resetModules();
  });

  describe('requestBodyCustomerProfile', () => {
    
    beforeEach(() => {
      sessionStorage.clear();
      window.mfe = {};
      sessionStorage.setItem('APP_PROPERTIES', '{"vbgFwaMLOrderingFFlag":"TRUE"}');
      sessionStorage.setItem('activeMTN', 'newLine1');
    });
  
    test('should set mtn to "newLine1" if window.mfe.scmPlanMfeEnable is true', () => {
      window.mfe.scmPlanMfeEnable = true;
      // Re-import to re-evaluate the value
      jest.resetModules();
      // eslint-disable-next-line global-require
      const { requestBodyCustomerProfile: reloadedProfile } = require('./APIRequestBody');
      expect(reloadedProfile.mtn).toBe('');
    });
  });

  describe('when isVbgAem returns true but flag is FALSE', () => {
    it('should set mtn to empty string in requestBodyCustomerProfile', async () => {
      mockIsVbgAem.mockReturnValue(true);
      
      const { requestBodyCustomerProfile } = await import('./APIRequestBody.js');

      expect(requestBodyCustomerProfile.mtn).toBe('newLine1');
      expect(requestBodyCustomerProfile.enableAssistedTagging).toBe(true);
    });
  });

  describe('when isVbgAem returns false', () => {
    it('should set mtn to empty string in requestBodyCustomerProfile', async () => {
      
      const { requestBodyCustomerProfile } = await import('./APIRequestBody.js');

      expect(requestBodyCustomerProfile.mtn).toBe('');
      expect(requestBodyCustomerProfile.enableAssistedTagging).toBe(true);
    });
  });

  describe('when APP_PROPERTIES is null or invalid JSON', () => {
    it('should set mtn to empty string when APP_PROPERTIES is null', async () => {
      mockIsVbgAem.mockReturnValue(true);
      
      const { requestBodyCustomerProfile } = await import('./APIRequestBody.js');

      expect(requestBodyCustomerProfile.mtn).toBe('newLine1');
    });

    it('should set mtn to empty string when APP_PROPERTIES is invalid JSON', async () => {
      mockIsVbgAem.mockReturnValue(true);
      
      const { requestBodyCustomerProfile } = await import('./APIRequestBody.js');

      expect(requestBodyCustomerProfile.mtn).toBe('newLine1');
    });
  });

  describe('when activeMTN is not available', () => {
    it('should set mtn to empty string when activeMTN is null', async () => {
      mockIsVbgAem.mockReturnValue(true);
      
      const { requestBodyCustomerProfile } = await import('./APIRequestBody.js');

      expect(requestBodyCustomerProfile.mtn).toBe('newLine1');
    });
  });
});

describe('vbgFwaMLOrderingFFlag', () => {
    let mockIsVbgAem;
    let mockSessionStorage;

    
  
    beforeEach(() => {
      mockIsVbgAem = jest.fn();
      mockSessionStorage = {
        getItem: jest.fn(),
      };
      
      jest.doMock('onevzsoemfeframework/VbgAemUtil', () => ({
        isVbgAem: mockIsVbgAem,
      }));

      jest.mock(
        'onevzsoemfeframework/DomService',
        () => ({
          __esModule: true,
          default: jest.fn(() => ({})),
          ...jest.requireActual('onevzsoemfeframework/DomService'),
          getQueryParamByName: (value) => {
            if (value === 'abc') return 'ac';
          },
        }),
        { virtual: true },
      );
    });
  
    afterEach(() => {
      jest.resetAllMocks();
      jest.resetModules();
    });
  
    describe('requestBodyCustomerProfile', () => {
      
      beforeEach(() => {
        sessionStorage.clear();
        window.mfe = {};
        sessionStorage.setItem('APP_PROPERTIES', '{"vbgFwaMLOrderingFFlag":"TRUE"}');
      });
    
      test('should set mtn to "newLine1" if window.mfe.scmPlanMfeEnable is true', () => {
        window.mfe.scmPlanMfeEnable = true;
        // Re-import to re-evaluate the value
        // jest.resetModules();
        // eslint-disable-next-line global-require
        const { requestBodyCustomerProfile: reloadedProfile } = require('./APIRequestBody');
        expect(reloadedProfile.mtn).toBe('');
      });
    });
});