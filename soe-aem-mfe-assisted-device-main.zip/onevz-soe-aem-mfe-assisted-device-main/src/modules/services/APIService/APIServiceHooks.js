import { injectAPI } from 'onevzsoemfeframework/APIService';
import { GetAppConfig } from '../../utils/GetAppConfig';

// URLS
const appConfig = GetAppConfig();
const { urls } = appConfig;
const {
  getTrialDeviceDetail,
  productList,
  getDetails,
  getProtectionFeatures,
  // bundleRecommendations,
  dpEligibility,
  fetchDownPayment,
  retrieveURC,
  getInventoryDetails,
  checkInStoreAvailability,
  checkZipcodeISPUEligibility,
  getSkuList,
  eSimDetails,
  compareList,
  getMyOffers,
  smartimeitypeahead,
  validateDeviceSimId,
  deviceInventoryStatusCheck,
  splitEqually,
  validateBYODTool,
  addDownPayment,
  eligibleNumberShareList,
  updateConsent,
  getBuyoutUpgrade,
  add_buyout,
  allowDeviceIdToReuse,
  // fetchPricingSnapshot,
  validateEmailAddress = 'deviceconfigservice/telematics/validateEmailAddress',
  getYears = '/deviceconfigservice/telematics/getYears',
  getMakes = '/deviceconfigservice/telematics/getMakes',
  getModels = '/deviceconfigservice/telematics/getModels',
  validateHumCompatibility = '/deviceconfigservice/telematics/validateHumCompatibility',
  removeSecondNumberDetails = '/cartservice/cart/removeSecondNumberDetails',
  getOffers = '/accountlandingservice/isaac/getoffers ',
  createApplication = '/accountlandingservice/isaac/createapplication',
  bbyLocalOrderLocDetails = '/peripheralsservice/bbyLocalOrderLocDetails ',
  getCartExceedsLimiturl = '/cartservice/cart/getCartExceedsLimit',
  getBrowserServiceSimSku = '/browseservice/flexV2/getSimSku',
  getBestBuyInventory = '/browseservice/getBestBuyInventory',
  addSubmitfeedback = '/accountlandingservice/isaac/submitfeedback',
  addVzccFeedbackStatus = '/cartservice/cart/vzccFeedbackStatus',
  posInitiateBuyOut = '/paymentservice/posInitiateBuyOut',
  agreementPDF = '/paymentservice/agreementPDF',
  retrievePosDevices = '/billingservice/retrievePosDevices',
  printerConfig = '/quoteservice/printerConfig',
  readUserParamDetails = '/peripheralsservice/readUserParamDetails',
  generateJwt = '/fraudservice/generateJWT'
} = urls;

// Tags
export const TAG_READ_USER_PARAM_DETAILS = 'tag_read_user_param_details';
export const TAG_GENERATE_JWT = 'tag_generateJwt';
export const TAG_PRODUCT_LIST = 'tag_product_list';
export const TAG_SKU_LIST = 'tag_sku_list';
export const TAG_SKU_DETAILS = 'tag_sku_details';
export const TAG_BROWSESERVICE_DEVICE_DETAILS = 'tag_browseservice_device_details';
export const TAG_PROTECTION_FEATURES = 'tag_protection_features';
export const TAG_BUNDLE_RECOMMENDATIONS = 'tag_bundle_recommendations';
export const TAG_DEVICE_PRICING_ELIGIBILITY = 'tag_device_pricing_eligibility';
export const TAG_FETCH_DOWNPAYMENT = 'tag_fetch_downpayment';
export const TAG_UPGRADEREASONCODE = 'tag_fetch_retrieveURC';
export const TAG_INVENTORY_DETAILS = 'tag_inventory_details';
export const TAG_ADD_DEVICE = 'tag_add_device';
export const TAG_CHECKINSTOREAVAILABILITY = 'tag_checkInStoreAvailability';
export const TAG_CHECKZIPCODEISPUELIGIBILITY = 'tag_checkZipcodeISPUEligibility';
// const TAG_FETCH_PRICING_SNAPSHOT = 'tag_fetch_pricing_snapshot';
export const TAG_ESIM_DETAILS = 'tag_esim_details';
export const TAG_COMPARE_LIST = 'tag_compare_list';
export const TAG_MY_OFFERS = 'tag_my_offers';
export const TAG_TRIAL_DEVICE_DETAIL = 'tag_trial_device_detail';
export const TAG_SMARTIMEI_TYPEAHEAD = 'smartimei_typeahead';
export const TAG_VALIDATE_DEVICESIMID = 'tag_validate_deviceSimId';
export const TAG_VALIDATE_DEVICE_SIMID = 'tag_validate_device_simid';
export const TAG_ALLOW_DEVICE_ID_TO_REUSE = 'tag_allow_device_id_to_reuse';
export const TAG_DEVICE_INVENTORY_STATUS_CHECK = 'tag_device_inventory_status_check';
export const TAG_SPLITEQUALLY = 'tag_splitEqually';
export const TAG_VALIDATE_BYOD_TOOL = 'tag_validate_BYOD_Tool';
export const TAG_COMPUTEDPPRICES = 'tag_computeDPPrices';
export const TAG_ELIGIBLE_NUMBERSHARE_LIST = 'tag_eligibleNumberShareList';
export const TAG_UPDATECONSENT = 'tag_updateConsent';
export const TAG_GETBUYOUTUPGRADE = 'tag_getBuyoutUpgrade';
export const TAG_ADD_BUYOUT = 'tag_add_buyout';
export const TAG_REMOVE_LINES = 'tag_remove_lines';
export const TAG_VALIDATE_EMAIL = 'tag_validate_email';
export const TAG_GET_YEARS = 'TAG_GET_YEARS';
export const TAG_GET_MAKES = 'TAG_GET_MAKES';
export const TAG_GET_MODELS = 'TAG_GET_MODELS';
export const TAG_GET_VALIDATEHUMCOMPATIBILITY = 'TAG_GET_VALIDATEHUMCOMPATIBILITY';
export const TAG_REMOVE_SECOND_NUMBER_DETAILS = 'TAG_REMOVE_SECOND_NUMBER_DETAILS';
export const TAG_GET_OFFERS = 'TAG_GET_OFFERS_PDP';
export const TAG_CREATE_APPLICATION = 'TAG_CREATE_APPLICATION';
export const TAB_GET_PROVISIONAL_ID = 'TAG_GET_PROVISIONAL_ID';
export const TAG_GET_PROVISIONAL_ID_SOE = 'TAG_GET_PROVISIONAL_ID_SOE';
export const TAG_POS_INITIATE_BUYOUT = 'TAG_POS_INITIATE_BUYOUT';
export const TAB_GET_FRAUDRISK_SCORE = 'TAB_GET_FRAUDRISK_SCORE';
export const TAG_BBY_LOCAL_LOC_ORDER_DETAILS = 'tag_bbyLocalOrderLocDetails';
export const TAG_CREDIT_LIMIT_CHECK = 'TAG_CREDIT_LIMIT_CHECK';
export const TAG_SIM_SKU = 'tag_browseservice_sim_sku';
export const TAG_ADD_SUBMIT_FEEDBACK = 'TAG_ADD_SUBMIT_FEEDBACK';
export const TAG_ADD_VZCCFEEDBACKSTATUS = 'TAG_ADD_VZCCFEEDBACKSTATUS';
export const TAG_AGREEMENT_PDF = 'TAG_AGREEMENT_PDF';
export const TAG_RETRIEVE_POS_DEVICES = 'TAG_RETRIEVE_POS_DEVICES';
export const TAG_PRINTER_CONFIG = 'TAG_PRINTER_CONFIG'

// Names
export const API_READ_USER_PARAM_DETAILS = 'readUserParamDetails'
export const API_GENERATE_JWT = 'generateJwt';
export const API_PRODUCT_LIST = 'getProductList';
export const API_SKU_LIST = 'getSkuList';
export const API_SKU_DETAILS_LIST = 'getSkuDetails';
export const API_BROWSESERVICE_DEVICE_DETAILS = 'getDeviceDetails';
export const API_ESIM_DETAILS = 'eSimDetails';
export const API_PROTECTION_FEATURES = 'getProtectionFeatures';
export const API_BUNDLE_RECOMMENDATIONS = 'getBundleRecommendations';
export const API_DEVICE_PRICING_ELIGIBILITY = 'getDevicePricingEligibility';
export const API_GET_PROVISIONAL_ID = 'retrieveProvisionalDeviceId';
export const API_GET_PROVISIONAL_ID_SOE = 'retrieveProvisionalDeviceIdSoe';
export const API_POS_INITIATE_BUYOUT = 'posInitiateBuyOut';
export const API_GET_FRAUDRISK_SCORE = 'fraudRiskScore';
export const API_UPGRADEREASONCODE = 'getRetrieveURCode';
export const API_FETCH_DOWNPAYMENT = 'getFetchDownpayment';
export const API_INVENTORY_DETAILS = 'getInventoryDetails';
export const API_ADD_DEVICE = 'addDevice';
export const API_CHECKINSTOREAVAILABILITY = 'getCheckInStoreAvailability';
export const API_CHECKZIPCODEISPUELIGIBILITY = 'getCheckZipcodeISPUEligibility';
export const API_COMPARE_LIST = 'compareList';
export const API_MY_OFFERS = 'getMyOffers';
export const API_TRIAL_DEVICE_DETAIL = 'getTrialDeviceDetail';
export const API_SMARTIMEI_TYPEAHEAD = 'smartimeiTypeahead';
export const API_VALIDATE_DEVICESIMID = 'getvalidateDeviceSimId';
export const API_VALIDATE_DEVICE_SIMID = 'validateDeviceSimId';
export const API_ALLOW_DEVICE_ID_TO_REUSE = 'allowDeviceIdToReuse';
export const API_DEVICE_INVENTORY_STATUS_CHECK = 'deviceInventoryStatusCheck';
export const API_SPLITEQUALLY = 'splitEqually';
export const API_VALIDATE_BYOD_TOOL = 'validateBYODTool';
export const API_COMPUTEDPPRICES = 'computeDPPrices';
export const API_ELIGIBLE_NUMBERSHARE_LIST = 'eligibleNumberShareList';
export const API_UPDATECONSENT = 'updateConsent';
export const API_GETBUYOUTUPGRADE = 'getBuyoutUpgrade';
export const API_ADD_BUYOUT = 'add_buyout';
export const API_REMOVE_LINES = 'removeLines';
export const API_FETCH_PRICING_SNAPSHOT = 'fetchPricingSnapshot';
export const API_VALIDATE_EMAIL = 'validateEmailAddress';
export const API_GET_YEARS = 'getYears';
export const API_GET_MAKES = 'getMakes';
export const API_GET_MODELS = 'getModels';
export const API_GET_VALIDATEHUMCOMPATIBILITY = 'validateHumCompatibility';
export const API_REMOVE_SECOND_NUMBER_DETAILS = 'removeSecondNumberDetails';
export const API_GET_OFFERS = 'getOffersPdp';
export const API_CREATE_APPLICATION = 'createApplication';
export const API_BBY_LOCAL_LOC_ORDER_DETAILS = 'bbyLocalOrderLocDetails';
export const API_CARD_LIMIT = 'getCartExceedsLimit';
export const API_SIM_SKU = 'getSimSku';
export const API_ADD_VZCCFEEDBACKSTATUS = 'addVzccFeedbackStatus';
export const API_ADD_SUBMIT_FEEDBACK = 'addSubmitFeedback';

export const TAG_BBY_LOCAL_LOC_ORDER_DETAILS_PRICING = 'tag_getBestBuyInventory';
export const API_BBY_LOCAL_LOC_ORDER_DETAILS_PRICING = 'getBestBuyInventory';
export const API_AGREEEMENT_PDF ='agreementPDF'
export const API_RETRIEVE_POS_DEVICES = 'retrievePosDevices'
export const API_PRINTER_CONFIG = 'printerConfig'

// Query builder Types
export const MUTATION = 'mutation';

// HTTP Method
export const POST = 'POST';

// Hooks
// api migrated from common
export const { useLazyGetProductListQuery } = injectAPI(API_PRODUCT_LIST, TAG_PRODUCT_LIST, productList);
export const { useLazyGetTrialDeviceDetailQuery } = injectAPI(
  API_TRIAL_DEVICE_DETAIL,
  TAG_TRIAL_DEVICE_DETAIL,
  getTrialDeviceDetail,
);
// api migrated from common
export const { useLazyGetSkuListQuery } = injectAPI(API_SKU_LIST, TAG_SKU_LIST, getSkuList);

// api migrated from common - (device&acount)
export const { useLazyGetSkuDetailsQuery } = injectAPI(
  API_SKU_DETAILS_LIST,
  TAG_SKU_DETAILS,
  '/browseservice/flexV2/getSkuDetails',
);
// export const { useESimDetailsQuery } = injectAPI(API_ESIM_DETAILS, TAG_ESIM_DETAILS, eSimDetails);
// api migrated from common
export const { useLazyCompareListQuery } = injectAPI(API_COMPARE_LIST, TAG_COMPARE_LIST, compareList);

// api migrated from common (device&account)
export const { useGetMyOffersQuery } = injectAPI(API_MY_OFFERS, TAG_MY_OFFERS, getMyOffers);
// api migrated from common
export const { useLazySmartimeiTypeaheadQuery } = injectAPI(
  API_SMARTIMEI_TYPEAHEAD,
  TAG_SMARTIMEI_TYPEAHEAD,
  smartimeitypeahead,
);

// api migrated from common (device&account)
export const { useLazyESimDetailsQuery } = injectAPI(API_ESIM_DETAILS, TAG_ESIM_DETAILS, eSimDetails);

// api migrated from common (device&account&mtn)
export const { useLazyValidateDeviceSimIdQuery } = injectAPI(
  API_VALIDATE_DEVICE_SIMID,
  TAG_VALIDATE_DEVICE_SIMID,
  validateDeviceSimId,
);
// api for allowing device ID to be reused (remove from Lost/Stolen list)
export const { useLazyAllowDeviceIdToReuseQuery } = injectAPI(
  API_ALLOW_DEVICE_ID_TO_REUSE,
  TAG_ALLOW_DEVICE_ID_TO_REUSE,
  allowDeviceIdToReuse,
);
// api migrated from common - reverted
export const { useLazyDeviceInventoryStatusCheckQuery } = injectAPI(
  API_DEVICE_INVENTORY_STATUS_CHECK,
  TAG_DEVICE_INVENTORY_STATUS_CHECK,
  deviceInventoryStatusCheck,
);
// api migrated from common
export const { useLazyRemoveSecondNumberDetailsQuery } = injectAPI(
  API_REMOVE_SECOND_NUMBER_DETAILS,
  TAG_REMOVE_SECOND_NUMBER_DETAILS,
  removeSecondNumberDetails,
);
// api migrated from common
export const { useLazyGetDeviceDetailsQuery } = injectAPI(
  API_BROWSESERVICE_DEVICE_DETAILS,
  TAG_BROWSESERVICE_DEVICE_DETAILS,
  getDetails,
);

// api migrated from common
export const { useGetProtectionFeaturesQuery } = injectAPI(
  API_PROTECTION_FEATURES,
  TAG_PROTECTION_FEATURES,
  getProtectionFeatures,
);
// api migrated from common
export const { useGetRetrieveURCodeQuery } = injectAPI(API_UPGRADEREASONCODE, TAG_UPGRADEREASONCODE, retrieveURC);

// api migrated from common
export const { useLazyGetFetchDownpaymentQuery } = injectAPI(
  API_FETCH_DOWNPAYMENT,
  TAG_FETCH_DOWNPAYMENT,
  fetchDownPayment,
);

// api migrated from common (device&account)
export const { useLazyGetInventoryDetailsQuery } = injectAPI(
  API_INVENTORY_DETAILS,
  TAG_INVENTORY_DETAILS,
  getInventoryDetails,
);
// api migrated from common (device&account)
export const { useLazyGetCheckInStoreAvailabilityQuery } = injectAPI(
  API_CHECKINSTOREAVAILABILITY,
  TAG_CHECKINSTOREAVAILABILITY,
  checkInStoreAvailability,
);
// api migrated from common (device check in store)
export const { useLazyGetCheckZipcodeISPUEligibilityQuery } = injectAPI(
  API_CHECKZIPCODEISPUELIGIBILITY,
  TAG_CHECKZIPCODEISPUELIGIBILITY,
  checkZipcodeISPUEligibility,
);

// api migrated from common
export const { useLazySplitEquallyQuery } = injectAPI(API_SPLITEQUALLY, TAG_SPLITEQUALLY, splitEqually);
// api migrated from common
export const { useLazyValidateBYODToolQuery } = injectAPI(
  API_VALIDATE_BYOD_TOOL,
  TAG_VALIDATE_BYOD_TOOL,
  validateBYODTool,
);
// api migrated from common
export const { useLazyEligibleNumberShareListQuery } = injectAPI(
  API_ELIGIBLE_NUMBERSHARE_LIST,
  TAG_ELIGIBLE_NUMBERSHARE_LIST,
  eligibleNumberShareList,
);

// api migrated from common
export const { useLazyComputeDPPricesQuery } = injectAPI(API_COMPUTEDPPRICES, TAG_COMPUTEDPPRICES, addDownPayment);

// api migrated from common
export const { useLazyUpdateConsentQuery } = injectAPI(API_UPDATECONSENT, TAG_UPDATECONSENT, updateConsent);

// api migrated from common
export const { useLazyGetBuyoutUpgradeQuery } = injectAPI(API_GETBUYOUTUPGRADE, TAG_GETBUYOUTUPGRADE, getBuyoutUpgrade);

// api migrated from common
export const { useLazyAdd_buyoutQuery } = injectAPI(API_ADD_BUYOUT, TAG_ADD_BUYOUT, add_buyout);

// export const { useLazyFetchPricingSnapShotQuery } = injectAPI(
//   API_FETCH_PRICING_SNAPSHOT,
//   TAG_FETCH_PRICING_SNAPSHOT,
//   fetchPricingSnapshot
// );

// api migrated from common
export const { useLazyValidateEmailAddressQuery } = injectAPI(
  API_VALIDATE_EMAIL,
  TAG_VALIDATE_EMAIL,
  validateEmailAddress,
);

// api migrated from common
export const { useLazyGetYearsQuery } = injectAPI(API_GET_YEARS, TAG_GET_YEARS, getYears);

// api migrated from common
export const { useLazyGetMakesQuery } = injectAPI(API_GET_MAKES, TAG_GET_MAKES, getMakes);

// api migrated from common
export const { useLazyGetModelsQuery } = injectAPI(API_GET_MODELS, TAG_GET_MODELS, getModels);

// api migrated from common
export const { useLazyValidateHumCompatibilityQuery } = injectAPI(
  API_GET_VALIDATEHUMCOMPATIBILITY,
  TAG_GET_VALIDATEHUMCOMPATIBILITY,
  validateHumCompatibility,
);

// api migrated from common - reverted
export const { useLazyGetRetrieveURCodeQuery } = injectAPI(API_UPGRADEREASONCODE, TAG_UPGRADEREASONCODE, retrieveURC);
// api migrated from common - reverted
export const { useLazyGetDevicePricingEligibilityQuery } = injectAPI(
  API_DEVICE_PRICING_ELIGIBILITY,
  TAG_DEVICE_PRICING_ELIGIBILITY,
  dpEligibility,
);

export const { useLazyRetrieveProvisionalDeviceIdQuery } = injectAPI(
  API_GET_PROVISIONAL_ID,
  TAB_GET_PROVISIONAL_ID,
  '/cpc/retrieveProvisionalDeviceId',
  POST,
  'query',
  [],
  60,
  false,
  { isAcssService: true },
);

export const { useLazyRetrieveProvisionalDeviceIdSoeQuery } = injectAPI(
  API_GET_PROVISIONAL_ID_SOE,
  TAG_GET_PROVISIONAL_ID_SOE,
  '/browseservice/retrieveProvisionalDeviceId',
  POST,
  'query',
  [],
  60,
  false,
);

export const { useLazyPosInitiateBuyOutQuery } = injectAPI(
  API_POS_INITIATE_BUYOUT,
  TAG_POS_INITIATE_BUYOUT,
  posInitiateBuyOut
);

export const { useLazyFraudRiskScoreQuery } = injectAPI(
  API_GET_FRAUDRISK_SCORE,
  TAB_GET_FRAUDRISK_SCORE,
  '/cpc/fraudRiskScore',
  POST,
  'query',
  [],
  60,
  false,
  { isAcssService: true },
);

export const { useGetOffersPdpMutation } = injectAPI(API_GET_OFFERS, TAG_GET_OFFERS, getOffers, POST, MUTATION);

export const { useCreateApplicationMutation } = injectAPI(
  API_CREATE_APPLICATION,
  TAG_CREATE_APPLICATION,
  createApplication,
  POST,
  MUTATION,
);

export const { useGetCartExceedsLimitMutation } = injectAPI(
  API_CARD_LIMIT,
  TAG_CREDIT_LIMIT_CHECK,
  getCartExceedsLimiturl,
  POST,
  MUTATION,
);

export const { useLazyBbyLocalOrderLocDetailsQuery } = injectAPI(
  API_BBY_LOCAL_LOC_ORDER_DETAILS,
  TAG_BBY_LOCAL_LOC_ORDER_DETAILS,
  bbyLocalOrderLocDetails,
);

export const { useLazyGetBestBuyInventoryQuery } = injectAPI(
  API_BBY_LOCAL_LOC_ORDER_DETAILS_PRICING,
  TAG_BBY_LOCAL_LOC_ORDER_DETAILS_PRICING,
  getBestBuyInventory,
);

export const { useAddVzccFeedbackStatusMutation } = injectAPI(
  API_ADD_VZCCFEEDBACKSTATUS,
  TAG_ADD_VZCCFEEDBACKSTATUS,
  addVzccFeedbackStatus,
  POST,
  MUTATION,
);

export const { useAddSubmitFeedbackMutation } = injectAPI(
  API_ADD_SUBMIT_FEEDBACK,
  TAG_ADD_SUBMIT_FEEDBACK,
  addSubmitfeedback,
  POST,
  MUTATION,
);
export const {useLazyReadUserParamDetailsQuery} = injectAPI(
  API_READ_USER_PARAM_DETAILS,
  TAG_READ_USER_PARAM_DETAILS,
  readUserParamDetails,
  POST
)
export const {useLazyGenerateJwtQuery} = injectAPI(API_GENERATE_JWT,TAG_GENERATE_JWT,generateJwt);

export const { useLazyGetSimSkuQuery } = injectAPI(API_SIM_SKU, TAG_SIM_SKU, getBrowserServiceSimSku);
export const {useLazyAgreementPDFQuery} = injectAPI(API_AGREEEMENT_PDF,TAG_AGREEMENT_PDF,agreementPDF);
export const {useLazyRetrievePosDevicesQuery} = injectAPI(API_RETRIEVE_POS_DEVICES,TAG_RETRIEVE_POS_DEVICES,retrievePosDevices);
export const {useLazyPrinterConfigQuery} = injectAPI(API_PRINTER_CONFIG,TAG_PRINTER_CONFIG,printerConfig)

