import { Provider } from 'react-redux';
import configureAppStore from 'onevzsoemfeframework/Store';
import rootReducer from './reducer';
import { rootSaga } from './saga';

const store = configureAppStore(rootReducer, rootSaga);

export default function StoreProvider({ children, context }) {
  return (
    <Provider store={store} context={context}>
      {' '}
      {children}{' '}
    </Provider>
  );
}
