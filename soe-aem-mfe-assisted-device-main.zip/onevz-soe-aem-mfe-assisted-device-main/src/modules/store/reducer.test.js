import createRootReducer from './reducer';

describe(`Reducer `, () => {
  test('createRootReducer should be function', async () => {
    const reducer = jest.fn();
    const temp = createRootReducer(reducer);
    expect(temp).not.toBe(null);
  });
});
