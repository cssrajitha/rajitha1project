import { render, screen } from '@testing-library/react';
import StoreProvider from './index';

const Comp = () => 'New Comp';
describe(`Reducer `, () => {
  test('dummyComp should mount', async () => {
    render(
      <StoreProvider>
        <Comp />
      </StoreProvider>,
    );
    expect(screen.getByText('New Comp')).toBeInTheDocument();
  });
});
