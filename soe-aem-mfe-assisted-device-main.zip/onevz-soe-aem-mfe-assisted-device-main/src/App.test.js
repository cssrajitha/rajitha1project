import React from 'react';
import { render } from '@testing-library/react';
import App from './App';

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradleProperty: () => ['TRUE', 'TRUE'],
  }),
  { virtual: true },
);

describe(`App component`, () => {
  test('App should mount', async () => {
    render(<App />);
  });
});
