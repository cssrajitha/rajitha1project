import { transformProductListRequest, transformAddAccessoryRequest } from './commonFunctions';

// Mock the dependencies
jest.mock('../modules/services/APIService/APIRequestBody', () => ({
  requestBodyProductList: {
    meta: 'original-meta',
    data: {
      someOtherKey: 'preserve-me',
      productType: 'original-productType',
      filterSortData: {
        originalSort: 'orig',
        paymentOption: 'orig-payment',
        sortOption: 'orig-sort',
        filters: [{ type: 'Original' }],
      },
      paginationData: {
        offset: 999,
        recPerPage: 12,
      },
    },
  },
  initialAddAccessoryRequest: {
    cartInfo: {
      correlationId: '69a66ef4d7e344dfb2db299209ea8333',
      processingMTN: '',
      processStep: 'ShoppingCart',
      processAction: 'addAccessory',
      intendType: 'EUP',
      creditAppNum: null,
    },
    data: {
      depletionType: '',
      lines: [
        {
          mtn: '',
          mdnFilterValue: '',
          removeAccessories: [],
          addAccessories: [],
          ispuFlow: false,
          depletionLocationCode: '',
        },
      ],
    },
  },
}));

describe('commonFunctions', () => {
  describe('transformProductListRequest', () => {
    it('returns expected structure with all defaults when called with no arguments', () => {
      const result = transformProductListRequest();

      // Preserves top-level spread keys from mocked requestBodyProductList
      expect(result.meta).toBe('original-meta');
      expect(result.data.someOtherKey).toBe('preserve-me');

      // Default productType
      expect(result.data.productType).toBe('device');

      // Default pagination
      expect(result.data.paginationData).toEqual({ offset: 0, recPerPage: 24 });

      // Default sortOption and paymentOption
      expect(result.data.filterSortData.sortOption).toBe('');
      expect(result.data.filterSortData.paymentOption).toBe('');

      // Filters structure with default empty values
      const { filters } = result.data.filterSortData;
      expect(filters).toHaveLength(3);
      expect(filters[0]).toEqual({ type: 'Category', values: [''] });
      expect(filters[1]).toEqual({ type: 'Brand', values: [''] }); // brand falsy -> ['']
      expect(filters[2]).toEqual({ type: 'OS', values: [''] }); // os falsy -> ['']
    });

    it('returns expected structure with empty object argument', () => {
      const result = transformProductListRequest({});

      expect(result.data.productType).toBe('device');
      expect(result.data.paginationData).toEqual({ offset: 0, recPerPage: 24 });
      expect(result.data.filterSortData.filters[1]).toEqual({ type: 'Brand', values: [''] });
      expect(result.data.filterSortData.filters[2]).toEqual({ type: 'OS', values: [''] });
    });

    it('uses provided brand value in filters when brand is truthy', () => {
      const result = transformProductListRequest({ brand: 'Samsung' });

      expect(result.data.filterSortData.filters[1]).toEqual({
        type: 'Brand',
        values: ['Samsung'],
      });
    });

    it('uses empty string fallback when brand is empty string', () => {
      const result = transformProductListRequest({ brand: '' });

      expect(result.data.filterSortData.filters[1]).toEqual({
        type: 'Brand',
        values: [''],
      });
    });

    it('uses provided os value in filters when os is truthy', () => {
      const result = transformProductListRequest({ os: 'Android' });

      expect(result.data.filterSortData.filters[2]).toEqual({
        type: 'OS',
        values: ['Android'],
      });
    });

    it('uses empty string fallback when os is empty string', () => {
      const result = transformProductListRequest({ os: '' });

      expect(result.data.filterSortData.filters[2]).toEqual({
        type: 'OS',
        values: [''],
      });
    });

    it('applies all provided parameters correctly', () => {
      const payload = {
        brand: 'Apple',
        category: 'Smartphones',
        os: 'iOS',
        offset: 10,
        recPerPage: 50,
        productType: 'accessory',
        sortOption: 'price_asc',
        paymentOption: 'monthly',
      };

      const result = transformProductListRequest(payload);

      expect(result.data.productType).toBe('accessory');
      expect(result.data.paginationData).toEqual({ offset: 10, recPerPage: 50 });
      expect(result.data.filterSortData.sortOption).toBe('price_asc');
      expect(result.data.filterSortData.paymentOption).toBe('monthly');

      const { filters } = result.data.filterSortData;
      expect(filters[0]).toEqual({ type: 'Category', values: ['Smartphones'] });
      expect(filters[1]).toEqual({ type: 'Brand', values: ['Apple'] });
      expect(filters[2]).toEqual({ type: 'OS', values: ['iOS'] });
    });

    it('handles partial parameters with defaults for missing ones', () => {
      const result = transformProductListRequest({
        brand: 'Google',
        offset: 5,
      });

      expect(result.data.productType).toBe('device'); // default
      expect(result.data.paginationData.offset).toBe(5);
      expect(result.data.paginationData.recPerPage).toBe(24); // default
      expect(result.data.filterSortData.filters[1]).toEqual({
        type: 'Brand',
        values: ['Google'],
      });
      expect(result.data.filterSortData.filters[2]).toEqual({
        type: 'OS',
        values: [''], // default fallback
      });
    });

    it('preserves originalSort from requestBodyProductList filterSortData', () => {
      const result = transformProductListRequest();

      // The spread should preserve keys from the mocked filterSortData
      expect(result.data.filterSortData.originalSort).toBe('orig');
    });
  });

  describe('transformAddAccessoryRequest', () => {
    it('should return expected structure with all defaults when called with empty parameters', () => {
      const result = transformAddAccessoryRequest({});

      // Verify cartInfo is preserved and processingMTN is set
      expect(result.cartInfo.correlationId).toBe('69a66ef4d7e344dfb2db299209ea8333');
      expect(result.cartInfo.processingMTN).toBeUndefined();
      expect(result.cartInfo.processStep).toBe('ShoppingCart');
      expect(result.cartInfo.processAction).toBe('addAccessory');
      expect(result.cartInfo.intendType).toBe('EUP');
      expect(result.cartInfo.creditAppNum).toBeNull();

      // Verify data structure with defaults
      expect(result.data.depletionType).toBe('');
      expect(result.data.lines).toHaveLength(1);
      expect(result.data.lines[0].mtn).toBeUndefined();
      expect(result.data.lines[0].mdnFilterValue).toBeUndefined();
      expect(result.data.lines[0].addAccessories).toEqual([]);
      expect(result.data.lines[0].removeAccessories).toEqual([]);
      expect(result.data.lines[0].ispuFlow).toBe(false);
      expect(result.data.lines[0].depletionLocationCode).toBe('');
    });

    it('should set processingMTN and mtn correctly', () => {
      const result = transformAddAccessoryRequest({ mtn: '1234567890' });

      expect(result.cartInfo.processingMTN).toBe('1234567890');
      expect(result.data.lines[0].mtn).toBe('1234567890');
      expect(result.data.lines[0].mdnFilterValue).toBe('1234567890');
    });

    it('should transform addAccessoriesList correctly', () => {
      const addAccessoriesList = [
        { id: 'ACC001', qty: 2 },
        { id: 'ACC002', qty: 1 },
        { id: 'ACC003', qty: 5 },
      ];

      const result = transformAddAccessoryRequest({ addAccessoriesList });

      expect(result.data.lines[0].addAccessories).toEqual([
        { id: 'ACC001', qty: 2, isSoftSku: false, accessoryBundle: false },
        { id: 'ACC002', qty: 1, isSoftSku: false, accessoryBundle: false },
        { id: 'ACC003', qty: 5, isSoftSku: false, accessoryBundle: false },
      ]);
    });

    it('should transform removeAccessoriesList correctly', () => {
      const removeAccessoriesList = [
        { id: 'REM001', qty: 1 },
        { id: 'REM002', qty: 3 },
      ];

      const result = transformAddAccessoryRequest({ removeAccessoriesList });

      expect(result.data.lines[0].removeAccessories).toEqual([
        { id: 'REM001', qty: 1, isSoftSku: false, accessoryBundle: false },
        { id: 'REM002', qty: 3, isSoftSku: false, accessoryBundle: false },
      ]);
    });

    it('should handle both addAccessoriesList and removeAccessoriesList', () => {
      const addAccessoriesList = [{ id: 'ADD001', qty: 2 }];
      const removeAccessoriesList = [{ id: 'REM001', qty: 1 }];

      const result = transformAddAccessoryRequest({ addAccessoriesList, removeAccessoriesList });

      expect(result.data.lines[0].addAccessories).toEqual([
        { id: 'ADD001', qty: 2, isSoftSku: false, accessoryBundle: false },
      ]);
      expect(result.data.lines[0].removeAccessories).toEqual([
        { id: 'REM001', qty: 1, isSoftSku: false, accessoryBundle: false },
      ]);
    });

    it('should set isIspuCheck to true when provided', () => {
      const result = transformAddAccessoryRequest({ isIspuCheck: true });

      expect(result.data.lines[0].ispuFlow).toBe(true);
    });

    it('should set isIspuCheck to false by default', () => {
      const result = transformAddAccessoryRequest({});

      expect(result.data.lines[0].ispuFlow).toBe(false);
    });

    it('should set activeLineDepletionType correctly', () => {
      const result = transformAddAccessoryRequest({ activeLineDepletionType: 'WAREHOUSE' });

      expect(result.data.depletionType).toBe('WAREHOUSE');
    });

    it('should use empty string for activeLineDepletionType by default', () => {
      const result = transformAddAccessoryRequest({});

      expect(result.data.depletionType).toBe('');
    });

    it('should handle all parameters together', () => {
      const params = {
        mtn: '9876543210',
        addAccessoriesList: [
          { id: 'CASE001', qty: 1 },
          { id: 'PROT001', qty: 2 },
        ],
        removeAccessoriesList: [{ id: 'OLD001', qty: 1 }],
        isIspuCheck: true,
        activeLineDepletionType: 'STORE',
      };

      const result = transformAddAccessoryRequest(params);

      // Verify cartInfo
      expect(result.cartInfo.processingMTN).toBe('9876543210');

      // Verify data
      expect(result.data.depletionType).toBe('STORE');
      expect(result.data.lines[0].mtn).toBe('9876543210');
      expect(result.data.lines[0].mdnFilterValue).toBe('9876543210');
      expect(result.data.lines[0].ispuFlow).toBe(true);
      expect(result.data.lines[0].depletionLocationCode).toBe('');

      // Verify accessories
      expect(result.data.lines[0].addAccessories).toHaveLength(2);
      expect(result.data.lines[0].addAccessories[0]).toEqual({
        id: 'CASE001',
        qty: 1,
        isSoftSku: false,
        accessoryBundle: false,
      });
      expect(result.data.lines[0].removeAccessories).toHaveLength(1);
      expect(result.data.lines[0].removeAccessories[0]).toEqual({
        id: 'OLD001',
        qty: 1,
        isSoftSku: false,
        accessoryBundle: false,
      });
    });

    it('should handle empty addAccessoriesList array', () => {
      const result = transformAddAccessoryRequest({ addAccessoriesList: [] });

      expect(result.data.lines[0].addAccessories).toEqual([]);
    });

    it('should handle empty removeAccessoriesList array', () => {
      const result = transformAddAccessoryRequest({ removeAccessoriesList: [] });

      expect(result.data.lines[0].removeAccessories).toEqual([]);
    });

    it('should set isSoftSku to false for all accessories', () => {
      const addAccessoriesList = [{ id: 'ACC001', qty: 1 }];
      const result = transformAddAccessoryRequest({ addAccessoriesList });

      expect(result.data.lines[0].addAccessories[0].isSoftSku).toBe(false);
    });

    it('should set accessoryBundle to false for all accessories', () => {
      const addAccessoriesList = [{ id: 'ACC001', qty: 1 }];
      const result = transformAddAccessoryRequest({ addAccessoriesList });

      expect(result.data.lines[0].addAccessories[0].accessoryBundle).toBe(false);
    });

    it('should preserve all original cartInfo properties', () => {
      const result = transformAddAccessoryRequest({ mtn: '1111111111' });

      expect(result.cartInfo).toEqual({
        correlationId: '69a66ef4d7e344dfb2db299209ea8333',
        processingMTN: '1111111111',
        processStep: 'ShoppingCart',
        processAction: 'addAccessory',
        intendType: 'EUP',
        creditAppNum: null,
      });
    });

    it('should handle accessories with optional properties', () => {
      const addAccessoriesList = [{ id: 'ACC001', qty: 1, extraProp: 'should-not-appear' }];

      const result = transformAddAccessoryRequest({ addAccessoriesList });

      expect(result.data.lines[0].addAccessories[0]).toEqual({
        id: 'ACC001',
        qty: 1,
        isSoftSku: false,
        accessoryBundle: false,
      });
      expect(result.data.lines[0].addAccessories[0].extraProp).toBeUndefined();
    });

    it('should handle accessories without id property', () => {
      const addAccessoriesList = [{ qty: 1 }];

      const result = transformAddAccessoryRequest({ addAccessoriesList });

      expect(result.data.lines[0].addAccessories[0]).toEqual({
        id: undefined,
        qty: 1,
        isSoftSku: false,
        accessoryBundle: false,
      });
    });

    it('should handle accessories without qty property', () => {
      const addAccessoriesList = [{ id: 'ACC001' }];

      const result = transformAddAccessoryRequest({ addAccessoriesList });

      expect(result.data.lines[0].addAccessories[0]).toEqual({
        id: 'ACC001',
        qty: undefined,
        isSoftSku: false,
        accessoryBundle: false,
      });
    });

    it('should handle large addAccessoriesList arrays', () => {
      const addAccessoriesList = Array.from({ length: 10 }, (_, i) => ({
        id: `ACC${i.toString().padStart(3, '0')}`,
        qty: i + 1,
      }));

      const result = transformAddAccessoryRequest({ addAccessoriesList });

      expect(result.data.lines[0].addAccessories).toHaveLength(10);
      expect(result.data.lines[0].addAccessories[0].id).toBe('ACC000');
      expect(result.data.lines[0].addAccessories[9].id).toBe('ACC009');
      expect(result.data.lines[0].addAccessories[9].qty).toBe(10);
    });

    it('should always set depletionLocationCode to empty string', () => {
      const result = transformAddAccessoryRequest({
        mtn: '1234567890',
        activeLineDepletionType: 'WAREHOUSE',
      });

      expect(result.data.lines[0].depletionLocationCode).toBe('');
    });

    it('should handle false value for isIspuCheck explicitly', () => {
      const result = transformAddAccessoryRequest({ isIspuCheck: false });

      expect(result.data.lines[0].ispuFlow).toBe(false);
    });

    it('should handle empty string for mtn', () => {
      const result = transformAddAccessoryRequest({ mtn: '' });

      expect(result.cartInfo.processingMTN).toBe('');
      expect(result.data.lines[0].mtn).toBe('');
      expect(result.data.lines[0].mdnFilterValue).toBe('');
    });

    it('should handle empty string for activeLineDepletionType', () => {
      const result = transformAddAccessoryRequest({ activeLineDepletionType: '' });

      expect(result.data.depletionType).toBe('');
    });
  });
});
