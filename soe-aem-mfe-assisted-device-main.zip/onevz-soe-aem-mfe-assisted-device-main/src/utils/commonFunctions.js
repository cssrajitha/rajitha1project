import { initialAddAccessoryRequest, requestBodyProductList } from '../modules/services/APIService/APIRequestBody';

export const transformProductListRequest = (data = {}) => {
  const {
    brand = '',
    category = '',
    os = '',
    offset = 0,
    recPerPage = 24,
    productType = 'device',
    sortOption = '',
    paymentOption = '',
  } = data;

  return {
    ...requestBodyProductList,
    data: {
      ...requestBodyProductList.data,
      productType,
      filterSortData: {
        ...requestBodyProductList.data.filterSortData,
        sortOption,
        paymentOption,
        filters: [
          {
            type: 'Category',
            values: [category],
          },
          {
            type: 'Brand',
            values: brand ? [brand] : [''],
          },
          {
            type: 'OS',
            values: os ? [os] : [''],
          },
        ],
      },
      paginationData: {
        offset,
        recPerPage,
      },
    },
  };
};

export const transformAddAccessoryRequest = ({
  mtn,
  addAccessoriesList = [],
  removeAccessoriesList = [],
  isIspuCheck = false,
  activeLineDepletionType = '',
}) => {
  const addAccessories = [
    ...addAccessoriesList.map((acc) => ({
      id: acc?.id,
      qty: acc?.qty,
      isSoftSku: false,
      accessoryBundle: false,
    })),
  ];

  const removeAccessories = [
    ...removeAccessoriesList.map((acc) => ({
      id: acc?.id,
      qty: acc?.qty,
      isSoftSku: false,
      accessoryBundle: false,
    })),
  ];

  return {
    ...initialAddAccessoryRequest,
    cartInfo: {
      ...initialAddAccessoryRequest.cartInfo,
      processingMTN: mtn,
    },
    data: {
      ...initialAddAccessoryRequest.data,
      depletionType: activeLineDepletionType,
      lines: [
        {
          ...initialAddAccessoryRequest.data.lines[0],
          mtn,
          mdnFilterValue: mtn,
          addAccessories,
          removeAccessories,
          ispuFlow: isIspuCheck,
          depletionLocationCode: '',
        },
      ],
    },
  };
};
