export const contractTerms = {
  ONE_YEAR: 'ONE_YEAR',
  TWO_YEAR: 'TWO_YEAR',
  THREE_YEAR: 'THREE_YEAR',
  THIRTY_MONTHS: 'THIRTY_MONTHS',
};

export const contractTermLabels = {
  oneYearPrice: '1_YEAR',
  twoYearPrice: '2_YEAR',
  threeYearPrice: '3_YEAR',
  thirtyMonthPrice: '30_MONTHS',
};

export const contractTextLabels = {
  ONE_YEAR_PRICE: 'One Year Price',
  TWO_YEAR_PRICE: 'Two Year Price',
  THREE_YEAR_PRICE: 'Three Year Price',
  THIRTY_MONTH_PRICE: 'Thirty Month Price',
};