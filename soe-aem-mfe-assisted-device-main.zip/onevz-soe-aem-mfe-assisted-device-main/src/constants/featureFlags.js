export const FEATURE_FLAGS = {
  VBG_NSA_YEAR_FORMAT_ACT_LATER: 'vbgNsaYearFormatActLaterFFlag',
  VBG_NSA_AAL_ACTIVATE_LATER: 'vbgNSAAALActivateLaterFFlag',
};
