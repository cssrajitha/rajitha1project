export const UI_SELECTORS = {
  ACTIVATE_LATER_TOGGLE_NAME: 'activateLater toggle',
};
