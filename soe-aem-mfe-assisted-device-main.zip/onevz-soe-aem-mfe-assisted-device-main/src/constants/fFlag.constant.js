const FFLAGS = {
  // Features flag
  scmMiscFixFFlag: {
    name: 'scmMiscFixFFlag',
    attribute: {
      generateESimProfile: 'generateESimProfile',
      eSimDbFlag: 'ACSS_SC_GENERATE_ESIM_ENABLE',
    },
  },
  scmCommonFixFFlag: {
    name: 'scmCommonFixFFlag',
    attribute: {
      fixSCMDeviceChangeIccid: 'fixSCMDeviceChangeIccid',
    },
  },
  scmCommonDefectFixFFlag: {
    name: 'scmCommonDefectFixFFlag',
    attribute: {
      scmBulkDFillSimFix: 'scmBulkDFillSimFix',
      scmBulkDFillSimDbFlag: 'ACSS_SC_BULK_DFILL_SIM_ENABLE',
      EsimActivationEnabled: 'eSimActivationEnabled',
      eSimDbFlag: 'ACSS_SC_GENERATE_ESIM_ENABLE',
      simOnlyChangeFix: 'simOnlyChangeFix',
    },
  },
};

export default FFLAGS;
