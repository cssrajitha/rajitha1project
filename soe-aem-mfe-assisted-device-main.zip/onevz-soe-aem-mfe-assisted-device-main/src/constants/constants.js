export const DARK_THEME_COLOR = '#ffffff';
export const LIGHT_THEME_COLOR = '#000000';
export const LIGHT_BG_COLOR = '#ffffff';
export const DARK_THEME_BGCOLOR = '#202229';
export const statesList = {
  AL: 'Alabama',
  KY: 'Kentucky',
  OH: 'Ohio',
  AK: 'Alaska',
  LA: 'Louisiana',
  OK: 'Oklahoma',
  AZ: 'Arizona',
  ME: 'Maine',
  OR: 'Oregon',
  AR: 'Arkansas',
  MD: 'Maryland',
  PA: 'Pennsylvania',
  AS: 'American Samoa',
  MA: 'Massachusetts',
  PR: 'Puerto Rico',
  CA: 'California',
  MI: 'Michigan',
  RI: 'Rhode Island',
  CO: 'Colorado',
  MN: 'Minnesota',
  SC: 'South Carolina',
  CT: 'Connecticut',
  MS: 'Mississippi',
  SD: 'South Dakota',
  DE: 'Delaware',
  MO: 'Missouri',
  TN: 'Tennessee',
  DC: 'District of Columbia',
  MT: 'Montana',
  TX: 'Texas',
  FL: 'Florida',
  NE: 'Nebraska',
  TT: 'Trust Territories',
  GA: 'Georgia',
  NV: 'Nevada',
  UT: 'Utah',
  GU: 'Guam',
  NH: 'New Hampshire',
  VT: 'Vermont',
  HI: 'Hawaii',
  NJ: 'New Jersey',
  VA: 'Virginia',
  ID: 'Idaho',
  NM: 'New Mexico',
  VI: 'Virgin Islands',
  IL: 'Illinois',
  NY: 'New York',
  WA: 'Washington',
  IN: 'Indiana',
  NC: 'North Carolina',
  WV: 'West Virginia',
  IA: 'Iowa',
  ND: 'North Dakota',
  WI: 'Wisconsin',
  KS: 'Kansas',
  MP: 'Northern Mariana Islands',
  WY: 'Wyoming',
};
export const dppKey = 'devicePaymentPrice';
export const dpTermList = [36, 30, 24];
export const contractTermList = [
  'threeYearPrice',
  'thirtyMonthPrice',
  'twoYearPrice',
  'oneYearPrice',
  'fullRetailPrice',
];
export const UI_MESSAGES = {
  MULTI_ESIM_PROFILE_ERROR:
    'There is already an eSIM profile reserved for this MDN. Troubleshooting for activation is recommended.',
};

export const THE_DEVICE_ID = 'The device ID';
export const HAS_BEEN_SUCCESSFULLY_REMOVED_FROM_THE_LOST_STOLEN_LIST = 'has been successfully removed from the Lost/Stolen list.';