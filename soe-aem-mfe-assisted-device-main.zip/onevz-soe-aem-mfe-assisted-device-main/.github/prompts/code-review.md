# Code Review Checklist for React.js - OneVZ SOE AEM MFE

## Overview

This code review checklist ensures that all React.js code in the OneVZ SOE AEM MFE Assisted Device repository adheres to coding standards, design standards, SAST (Static Application Security Testing), and DAST (Dynamic Application Security Testing) rules.

---

## 📋 General Code Review Guidelines

### Pre-Review Checklist

- [ ] Code builds successfully (`npm run build`)
- [ ] All tests pass (`npm test`)
- [ ] No console errors or warnings
- [ ] Code is formatted with Prettier (`npm run format`)
- [ ] ESLint passes with no errors (`npm run lint`)
- [ ] Commit messages follow Conventional Commits specification

---

## 🎨 Coding Standards

### JavaScript/React Standards

#### Code Style

- [ ] Follows **Airbnb JavaScript Style Guide**
- [ ] Uses **ESLint** configuration from `@onevz-soe-mfe-base/eslint-config`
- [ ] Uses **Prettier** configuration from `@onevz-soe-mfe-base/prettier-config`
- [ ] No ESLint warnings or errors
- [ ] Code is properly formatted before commit
- [ ] Pre-commit hooks (Husky) are working

#### Component Structure

- [ ] **Named components** use arrow functions or function declarations
- [ ] **Unnamed components** use arrow functions
- [ ] Component follows standard structure:

  ```javascript
  import React from 'react';
  import PropTypes from 'prop-types';

  const ComponentName = ({ prop1, prop2 }) => {
    // Component logic
    return (
      // JSX
    );
  };

  ComponentName.propTypes = {
    prop1: PropTypes.string,
    prop2: PropTypes.func,
  };

  export default ComponentName;
  ```

- [ ] Components are placed in appropriate directories (`src/components/` or `src/pages/`)
- [ ] Component-specific styles, tests, and utilities are co-located

#### Naming Conventions

- [ ] **Files**: PascalCase for component files (e.g., `CombinedGridwall.js`)
- [ ] **Functions**: camelCase (e.g., `isHomeSalesCbandBundleFlow`)
- [ ] **Constants**: UPPER_SNAKE_CASE for true constants
- [ ] **Components**: PascalCase (e.g., `Header5G`, `Footer`)
- [ ] **Props**: camelCase
- [ ] **CSS/Styled Components**: kebab-case for class names
- [ ] No single-letter variable names (except in loops)
- [ ] Meaningful and descriptive names

#### Import/Export Standards

- [ ] Uses ES6 import/export syntax
- [ ] Imports are grouped in correct order:
  1. React and React-related libraries
  2. Third-party libraries
  3. VDS components
  4. Local components
  5. Utilities and helpers
  6. Constants
  7. Styles
- [ ] Named exports for utilities and constants
- [ ] Default exports for components
- [ ] No unused imports
- [ ] No circular dependencies

#### PropTypes & Type Safety

- [ ] All component props have PropTypes defined
- [ ] PropTypes include `isRequired` where appropriate
- [ ] Default props are defined where needed
- [ ] PropTypes are properly documented

---

## 🏗️ Design Standards

### Component Architecture

- [ ] Follows **Container/Presentational** pattern where appropriate
- [ ] Uses **React Hooks** appropriately (useState, useEffect, useCallback, useMemo)
- [ ] Implements **code splitting** for performance optimization
- [ ] Uses **lazy loading** for routes and heavy components
- [ ] Components are modular and reusable
- [ ] Single Responsibility Principle is followed
- [ ] Components are not overly complex (max ~200 lines)

### State Management

- [ ] Uses **Redux Toolkit** (`@reduxjs/toolkit`) for global state
- [ ] Uses **redux-saga** for side effects and async operations
- [ ] Uses **redux-injectors** for code splitting and dynamic reducer/saga injection
- [ ] Store structure follows conventions in `src/modules/store/`
- [ ] Services are located in `src/modules/services/`
- [ ] No unnecessary global state (use local state when appropriate)
- [ ] Actions and reducers are properly named
- [ ] Sagas handle errors appropriately

### Styling

- [ ] Uses **styled-components** (v5.3.9) for component styling
- [ ] Uses **Verizon Design System (VDS)** components where possible
- [ ] Maintains consistent spacing and layout patterns
- [ ] Follows mobile-first responsive design principles
- [ ] No inline styles (except for dynamic values)
- [ ] CSS-in-JS follows naming conventions
- [ ] Responsive breakpoints are consistent
- [ ] Theme variables are used appropriately

### Performance Optimization

- [ ] Implements proper memoization (React.memo, useMemo, useCallback)
- [ ] Lazy loads routes and components
- [ ] Optimizes bundle size
- [ ] Monitors Web Vitals metrics (using `web-vitals` library)
- [ ] No unnecessary re-renders
- [ ] Large lists use virtualization if needed
- [ ] Images are optimized
- [ ] Code splitting is implemented where beneficial

---

## ♿ Accessibility Standards (WCAG 2.1 AA)

- [ ] Uses semantic HTML elements
- [ ] Provides proper ARIA labels and roles
- [ ] Ensures keyboard navigation support
- [ ] Color contrast meets WCAG 2.1 AA standards
- [ ] All interactive elements are keyboard accessible
- [ ] Form inputs have associated labels
- [ ] Images have alt text
- [ ] Focus indicators are visible
- [ ] Skip navigation links are provided where needed
- [ ] Screen reader tested (if applicable)
- [ ] No reliance on color alone for information

---

## 🔒 Security Standards

### Input Sanitization

- [ ] Uses **DOMPurify** (v3.0.1) for sanitizing HTML content
- [ ] Uses **XSS** library (v1.0.14) for preventing cross-site scripting attacks
- [ ] Validates all user inputs before processing
- [ ] Never trusts data from external sources
- [ ] Implements proper input validation
- [ ] Escapes user-generated content
- [ ] Sanitizes data before rendering

### Dependency Security

- [ ] Uses **AJV** (v8.12.0) for JSON schema validation
- [ ] Dependencies are up to date
- [ ] No known security vulnerabilities (`npm audit`)
- [ ] Security advisories have been reviewed
- [ ] No deprecated dependencies
- [ ] Lock file is committed (`package-lock.json`)

### Authentication & Authorization

- [ ] No hardcoded credentials or API keys
- [ ] Uses environment variables for sensitive configuration
- [ ] Implements proper session management
- [ ] Validates user permissions on both client and server
- [ ] Secure token storage
- [ ] Proper logout functionality
- [ ] Session timeout is implemented

### Sensitive Data Protection

- [ ] No sensitive data in console logs
- [ ] No sensitive data in error messages exposed to users
- [ ] API responses don't expose sensitive information
- [ ] No PII (Personally Identifiable Information) in URLs
- [ ] Secure data transmission (HTTPS)

---

## 🛡️ SAST (Static Application Security Testing)

### SonarQube Integration

- [ ] SonarQube analysis has been run
- [ ] No critical or major SonarQube issues
- [ ] Code quality gates pass
- [ ] Code coverage meets minimum thresholds
- [ ] Code smells are addressed
- [ ] Technical debt is minimal
- [ ] Duplicate code is minimized

### Code Quality Metrics

- [ ] Follows SOLID principles
- [ ] Follows clean code practices
- [ ] No code smells (long methods, large classes, etc.)
- [ ] Cyclomatic complexity is within acceptable range
- [ ] Cognitive complexity is within acceptable range
- [ ] No commented-out code
- [ ] No dead code or unused variables

### SonarQube Exclusions (Configured)

The following are excluded from SonarQube analysis:

- Test files: `**/*.test.js`
- Mock files: `**/__mocks__/**`, `**/mock/**`, `**/mocks/**`
- Setup files: `src/setupTests.js`, `src/index.js`, `src/reportWebVitals.js`, `src/bootstrap.js`
- Assets: `**/assets/json/**/*`, `**/assets/css/*`, `**/assets/fonts/**/*`
- Build artifacts: `**/node_modules/**`, `**/package/**`
- Snapshots: `**/_snapshots_/**`

---

## 🔍 DAST (Dynamic Application Security Testing)

### Runtime Security

- [ ] Security scans on deployed applications pass
- [ ] No common vulnerabilities (OWASP Top 10):
  - [ ] A01: Broken Access Control
  - [ ] A02: Cryptographic Failures
  - [ ] A03: Injection
  - [ ] A04: Insecure Design
  - [ ] A05: Security Misconfiguration
  - [ ] A06: Vulnerable and Outdated Components
  - [ ] A07: Identification and Authentication Failures
  - [ ] A08: Software and Data Integrity Failures
  - [ ] A09: Security Logging and Monitoring Failures
  - [ ] A10: Server-Side Request Forgery (SSRF)

### API Security

- [ ] API security is validated
- [ ] Authentication flows are secure
- [ ] API endpoints are properly secured
- [ ] Rate limiting is implemented where needed
- [ ] API responses are validated
- [ ] CORS is properly configured
- [ ] API keys are not exposed

### Production Security

- [ ] Runtime security is monitored
- [ ] Error handling doesn't expose sensitive information
- [ ] Logging is implemented appropriately
- [ ] Security headers are configured
- [ ] Content Security Policy (CSP) is implemented

---

## 🧪 Testing Standards

### Unit Testing

- [ ] Uses **Jest** and **React Testing Library**
- [ ] Test file naming: `ComponentName.test.js`
- [ ] All tests pass (`npm test`)
- [ ] Tests follow AAA pattern (Arrange, Act, Assert)
- [ ] Tests are meaningful and not just for coverage
- [ ] Edge cases are tested
- [ ] Error scenarios are tested
- [ ] Test structure follows conventions:
  ```javascript
  describe('ComponentName', () => {
    describe('functionName', () => {
      it('should do something specific', () => {
        // Arrange
        // Act
        // Assert
        expect(result).toBe(expected);
      });
    });
  });
  ```

### Coverage Requirements

- [ ] Code coverage meets minimum thresholds
- [ ] Coverage reports generated (`npm run test-coverage`)
- [ ] All source files are covered except exclusions
- [ ] Critical paths have 100% coverage
- [ ] Uses `src/modules/test-utils/renderHelper.js` for common setups
- [ ] External dependencies are properly mocked

### Test Quality

- [ ] Tests are isolated and independent
- [ ] No flaky tests
- [ ] Tests run quickly
- [ ] Mocks are used appropriately
- [ ] Tests are maintainable
- [ ] Test descriptions are clear

---

## 📦 Build & Deployment

### Build Configuration

- [ ] Production build succeeds (`npm run build`)
- [ ] VBG build succeeds (`npm run build:vbg`)
- [ ] Bundle size is optimized
- [ ] No build warnings
- [ ] Source maps are configured properly
- [ ] Environment variables are properly configured

### Module Federation

- [ ] Built as a proper Micro Frontend (MFE)
- [ ] Integration with AEM works correctly
- [ ] Supports multiple build targets (VBG, VCG)
- [ ] Module federation configuration is correct

### Browser Support

- [ ] **Production**: >0.2%, not dead, not op_mini all
- [ ] **Development**: Last 1 version of Chrome, Firefox, Safari
- [ ] Cross-browser testing completed
- [ ] No browser-specific issues

---

## 📝 Documentation

### Code Documentation

- [ ] JSDoc comments for complex functions
- [ ] Component props are documented using PropTypes
- [ ] README.md is up to date
- [ ] API integrations are documented
- [ ] Data flows are documented
- [ ] Inline comments for complex business logic
- [ ] Comments are meaningful and add value

### Maintainability

- [ ] Code is self-documenting
- [ ] Complex algorithms are explained
- [ ] TODOs are tracked properly
- [ ] No outdated comments
- [ ] Architecture decisions are documented

---

## 🔄 Version Control

### Git Practices

- [ ] Uses **Conventional Commits** specification
- [ ] Commit messages are meaningful
- [ ] Commits are atomic and logical
- [ ] No merge conflicts
- [ ] Branch naming follows conventions
- [ ] No sensitive data in commit history
- [ ] `.gitignore` is properly configured

### Code Changes

- [ ] Changes are focused and minimal
- [ ] No unrelated changes in the same PR
- [ ] Backward compatibility is maintained
- [ ] Breaking changes are documented

---

## 🚀 Performance Checklist

- [ ] No memory leaks
- [ ] Event listeners are cleaned up
- [ ] Subscriptions are unsubscribed
- [ ] API calls are optimized
- [ ] No N+1 queries
- [ ] Caching is implemented where appropriate
- [ ] Debouncing/throttling is used for expensive operations
- [ ] Bundle size is within acceptable limits
- [ ] Lazy loading is implemented
- [ ] Code splitting is effective

---

## 🎯 Best Practices Checklist

- [ ] No console.logs or debugger statements
- [ ] Proper error handling implemented
- [ ] Loading states are handled
- [ ] Error states are handled
- [ ] Empty states are handled
- [ ] User feedback is provided for actions
- [ ] Forms have proper validation
- [ ] API errors are handled gracefully
- [ ] Network errors are handled
- [ ] Retry logic is implemented where needed

---

## 📊 Code Review Severity Levels

### 🔴 Critical (Must Fix)

- Security vulnerabilities
- Breaking changes
- Data loss issues
- Performance blockers
- Accessibility violations (WCAG AA)

### 🟡 Major (Should Fix)

- Code quality issues
- Design pattern violations
- Test coverage gaps
- Documentation missing
- Minor security concerns

### 🟢 Minor (Nice to Have)

- Code style improvements
- Refactoring suggestions
- Performance optimizations
- Enhanced readability

---

## ✅ Final Review Checklist

Before approving the code review:

- [ ] All critical issues are resolved
- [ ] All major issues are addressed or have a plan
- [ ] Code follows all coding standards
- [ ] Design standards are met
- [ ] SAST rules pass (SonarQube)
- [ ] DAST considerations are addressed
- [ ] Security best practices are followed
- [ ] Tests are comprehensive and passing
- [ ] Documentation is complete
- [ ] Performance is acceptable
- [ ] Accessibility standards are met
- [ ] Code is maintainable and scalable

---

## 📚 References

- [Airbnb JavaScript Style Guide](https://github.com/airbnb/javascript)
- [React Documentation](https://react.dev/)
- [Redux Toolkit Documentation](https://redux-toolkit.js.org/)
- [Testing Library Documentation](https://testing-library.com/react)
- [Verizon Design System](https://vds.verizon.com/)
- [WCAG 2.1 Guidelines](https://www.w3.org/WAI/WCAG21/quickref/)
- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [SonarQube Documentation](https://docs.sonarqube.org/)

---

**Version**: 1.0  
**Last Updated**: January 30, 2026  
**Maintained By**: OneVZ SOE AEM MFE Team
