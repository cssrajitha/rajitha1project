React Performance # React/Next.js Performance Optimization

## Prompt

**Role**: Act as a senior performance engineer specializing in React and Next.js.  
**Context**: I have a React component or page in a Next.js app router app that I need to optimize for performance. Please analyze the code provided below and identify all potential bottlenecks and areas for improvement.  
**Goal**: Provide a comprehensive list of actionable recommendations to improve the performance, reduce re-renders, and optimize the Core Web Vitals (LCP, FID, CLS) for this code.

---

## Optimization Areas to Focus On

### Rendering & Memoization:

- Are there any unnecessary re-renders?
- Can `React.memo` be applied to any components?
- Are `useMemo` and `useCallback` being used correctly to memoize expensive calculations or functions?
- Is state being lifted too high, causing excessive re-renders in children?

### Next.js App Router Specifics (if applicable):

- Can this component be a Server Component (`"use server"`)?
- If it must be a Client Component (`"use client"`), are there parts that can be extracted into Server Components and passed as children?

### Code Splitting & Lazy Loading:

- Are there any components that can be dynamically imported using `next/dynamic` to reduce the initial bundle size?
- Is code-splitting being used effectively?

### Data Fetching & State:

- How is data being fetched? Can caching (e.g., React Query, SWR, or Next.js fetch caching) be improved?
- Is the state structure efficient? Are large state updates causing issues?

### DOM & Assets:

- Are there any large, unoptimized images? Should `next/image` be used?
- Is the component causing layout shifts (CLS)?
- Are there any expensive DOM manipulations or large lists that could benefit from virtualization (windowing)?

---

## Output Format

### High-Level Summary:

A brief overview of the component's current performance state and the most critical areas for improvement.

### Actionable Recommendations (List):

1. **[Issue #1 Title]**:
   - **Problem**: (Briefly explain the performance issue.)
   - **Recommendation**: (Explain how to fix it.)
   - **Refactored Code**:
     - **Before**:
       ```tsx
       // Original code snippet
       ```
     - **After**:
       ```tsx
       // Optimized code snippet
       ```

2. **[Issue #2 Title]**:
   - **Problem**: ...
   - **Recommendation**: ...
   - **Refactored Code**:
     - **Before**:
       ```tsx
       // Original code snippet
       ```
     - **After**:
       ```tsx
       // Optimized code snippet
       ```

(Continue for all identified issues.)
