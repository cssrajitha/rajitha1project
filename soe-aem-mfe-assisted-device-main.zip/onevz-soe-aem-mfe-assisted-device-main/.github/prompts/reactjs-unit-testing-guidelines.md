# ReactJS Unit Testing Guidelines

## Overview

This document provides comprehensive guidelines for writing unit tests in this ReactJS MFE (Micro Frontend) application. All tests should use Jest as the testing framework and React Testing Library for component testing.

---

## Table of Contents

1. [Testing Framework & Tools](#testing-framework--tools)
2. [File Structure & Naming](#file-structure--naming)
3. [Test Organization](#test-organization)
4. [Component Testing Patterns](#component-testing-patterns)
5. [Mocking Strategies](#mocking-strategies)
6. [Redux & State Testing](#redux--state-testing)
7. [API & Service Testing](#api--service-testing)
8. [Best Practices](#best-practices)
9. [Code Coverage](#code-coverage)
10. [Common Patterns & Examples](#common-patterns--examples)

---

## Testing Framework & Tools

### Core Dependencies

- **Jest**: v29.x (via react-scripts)
- **React Testing Library**: `@testing-library/react@13.4.0`
- **Jest DOM**: `@testing-library/jest-dom@5.16.5`
- **User Event**: `@testing-library/user-event@13.5.0`
- **MSW (Mock Service Worker)**: `msw@1.2.3` for API mocking

### Setup Files

- **Global Setup**: `src/setupTests.js`
- **Test Utilities**: `src/modules/test-utils/renderHelper.js`
- **Custom Render Helper**: Wraps components with Redux Provider and Router

```javascript
// src/setupTests.js
import '@testing-library/jest-dom';
import '@testing-library/jest-dom/extend-expect';

window.matchMedia =
  window.matchMedia ||
  function matchMedia() {
    return {
      matches: false,
      addListener() {},
      removeListener() {},
    };
  };
```

---

## File Structure & Naming

### Naming Convention

- Test files: `ComponentName.test.js`
- Place test files alongside the component they test
- Use the same directory structure as source files

### Example Structure

```
src/
├── components/
│   ├── Header/
│   │   ├── Header.js
│   │   ├── Header.test.js
│   │   └── _mocks_/
│   │       └── HeaderMockData.json
├── pages/
│   ├── PDP5G/
│   │   ├── index.js
│   │   ├── index.test.js
│   │   ├── Header.js
│   │   ├── Header.test.js
│   │   └── mocks/
│   │       └── setupServer.js
└── modules/
    ├── utils/
    │   ├── devicePricingUtils.js
    │   └── devicePricingUtils.test.js
```

---

## Test Organization

### Test Structure Pattern

Follow the **Arrange-Act-Assert (AAA)** pattern:

```javascript
describe('ComponentName', () => {
  describe('functionName', () => {
    it('should do something specific', () => {
      // Arrange - Set up test data and environment
      const mockData = { id: 1, name: 'Test' };

      // Act - Perform the action being tested
      const result = functionName(mockData);

      // Assert - Verify the outcome
      expect(result).toBe(expected);
    });
  });
});
```

### Describe Blocks

- **Outer describe**: Component or module name
- **Inner describe**: Function, method, or feature being tested
- **it/test**: Specific test case with clear description

### Example from Repository

```javascript
describe('pdp5gutils.js', () => {
  describe('isHomeSalesCbandBundleFlow', () => {
    it('should return true if the customer is Cband qualified and has bundles', () => {
      const customerProfile = {
        customer: {
          homeSalesAddress: {
            priorQualification: { cbandQualified: true },
            bundles: [1, 2, 3],
          },
        },
      };
      const result = isHomeSalesCbandBundleFlow(customerProfile);
      expect(result).toBe(true);
    });

    it('should return undefined if the customer is not Cband qualified', () => {
      const result = isHomeSalesCbandBundleFlow();
      expect(result).toBeUndefined();
    });
  });
});
```

---

## Component Testing Patterns

### Using Custom Render Helper

Always use the custom `renderHelper` which provides Redux store and Router context:

```javascript
import { render, screen, fireEvent, waitFor } from '../../modules/test-utils/renderHelper';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import ComponentName from './ComponentName';

const renderComponent = (props = {}) => {
  render(<ComponentName {...props} />, {
    reducers: rootReducer,
    sagas: rootSaga,
  });
};
```

### Query Methods Priority

Follow React Testing Library's query priority:

1. **Accessible Queries** (Preferred)
   - `getByRole`
   - `getByLabelText`
   - `getByPlaceholderText`
   - `getByText`

2. **Semantic Queries**
   - `getByAltText`
   - `getByTitle`

3. **Test IDs** (Last Resort)
   - `getByTestId`

### Example Component Test

```javascript
describe('<Header/>', () => {
  beforeEach(() => {
    window.mfe = {};
    sessionStorage.setItem('isSAExist', true);
  });

  it('should render header with close button', () => {
    const closeClickHandler = jest.fn();

    render(
      <Header
        data={{
          header: 'iPhone 14 Pro',
          line: 'JOSEPH',
          mdn: '8145772880',
          closeIcon: { popupModalclose: true },
          closeClickHandler,
        }}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );

    const closeButton = screen.getByRole('img', { name: /close icon/i });
    expect(closeButton).toBeInTheDocument();

    fireEvent.click(closeButton);
    expect(closeClickHandler).toHaveBeenCalled();
  });
});
```

### Testing User Interactions

```javascript
import { act } from '../../modules/test-utils/renderHelper';

test('should handle button click', async () => {
  const handleClick = jest.fn();
  render(<Button onClick={handleClick} label='Click Me' />);

  const button = screen.getByText(/click me/i);

  act(() => {
    fireEvent.click(button);
  });

  expect(handleClick).toHaveBeenCalledTimes(1);
});
```

### Testing Async Operations

```javascript
test('should load data asynchronously', async () => {
  render(<DataComponent />, {
    reducers: rootReducer,
    sagas: rootSaga,
  });

  await waitFor(() => {
    expect(screen.getByText(/data loaded/i)).toBeInTheDocument();
  });
});
```

---

## Mocking Strategies

### Mocking External Modules

#### Mock onevzsoemfecommon Helpers

```javascript
jest.mock(
  'onevzsoemfecommon/Helpers',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfecommon/Helpers'),
    getQueryParamByName: jest.fn(),
    getUIContextPath: jest.fn(() => {}),
    getUIContextPathBAU: jest.fn(() => {}),
  }),
  { virtual: true },
);
```

#### Mock with Dynamic Return Values

```javascript
jest.spyOn(fns, 'getQueryParamByName').mockImplementation((value) => {
  if (value === 'deviceSKU') return 'SKU123';
  if (value === 'deviceId') return '1234567890';
  return null;
});
```

#### Mock Framework Services

```javascript
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradleProperty: () => ['TRUE', 'TRUE', 'WNC-CR200A'],
  }),
  { virtual: true },
);
```

### Mocking API Calls with MSW

#### Setup MSW Server

```javascript
import { setupServer } from 'msw/node';
import { rest } from 'msw';

const handlers = [
  rest.post('*/deviceconfigservice/telematics/getYears', (req, res, ctx) => {
    return res(ctx.status(200), ctx.json({ years: [2020, 2021, 2022] }));
  }),

  rest.get('*/api/device/:id', (req, res, ctx) => {
    const { id } = req.params;
    return res(ctx.status(200), ctx.json({ id, name: 'Device' }));
  }),
];

const server = setupServer(...handlers);

describe('Component with API calls', () => {
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });

  afterEach(() => server.resetHandlers());
  afterAll(() => server.close());

  test('should fetch data successfully', async () => {
    render(<ComponentWithAPI />);
    await waitFor(() => {
      expect(screen.getByText(/device/i)).toBeInTheDocument();
    });
  });
});
```

### Mocking React Hooks

#### Mock Custom Hooks

```javascript
jest.mock(
  '../../modules/services/APIService/APIServiceHooks',
  () => ({
    __esModule: true,
    ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
    useLazyValidateEmailAddressQuery: () => [
      () => {},
      {
        status: 'Success',
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: false,
        data: { validEmail: true },
      },
    ],
  }),
  { virtual: true },
);
```

### Mocking Functions and Callbacks

```javascript
const mockCallback = jest.fn();

test('should call callback with correct arguments', () => {
  render(<Component onSubmit={mockCallback} />);

  fireEvent.click(screen.getByText(/submit/i));

  expect(mockCallback).toHaveBeenCalledWith({ value: 'test' });
  expect(mockCallback).toHaveBeenCalledTimes(1);
});
```

---

## Redux & State Testing

### Testing Components with Redux

```javascript
import { render, screen } from '../../modules/test-utils/renderHelper';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';

test('should render with Redux state', () => {
  const { store } = render(<ConnectedComponent />, {
    reducers: rootReducer,
    sagas: rootSaga,
    preloadedState: {
      user: { name: 'John Doe' },
    },
  });

  expect(screen.getByText(/john doe/i)).toBeInTheDocument();
});
```

### Testing Redux Actions & Reducers

```javascript
describe('userReducer', () => {
  it('should handle SET_USER action', () => {
    const initialState = { user: null };
    const action = { type: 'SET_USER', payload: { name: 'Jane' } };

    const newState = userReducer(initialState, action);

    expect(newState.user).toEqual({ name: 'Jane' });
  });
});
```

---

## API & Service Testing

### Testing Utility Functions

```javascript
describe('devicePricingUtils', () => {
  describe('getPricingPriority', () => {
    it('returns the first available option from otherPriceList', () => {
      const price = {
        threeYearPrice: { originalPrice: 1000 },
        twoYearPrice: { originalPrice: 900 },
      };

      expect(getPricingPriority(price)).toBe('threeYearPrice');
    });

    it('returns null if no matching options are found', () => {
      const price = { devicePaymentPrice: [] };
      expect(getPricingPriority(price)).toBeNull();
    });

    it('handles edge cases correctly', () => {
      expect(getPricingPriority(undefined)).toBeNull();
      expect(getPricingPriority(null)).toBeNull();
      expect(getPricingPriority(42)).toBeNull();
    });
  });
});
```

### Testing Error Handling

```javascript
test('should handle API errors gracefully', async () => {
  server.use(
    rest.get('*/api/data', (req, res, ctx) => {
      return res(ctx.status(500), ctx.json({ error: 'Server Error' }));
    }),
  );

  render(<DataComponent />);

  await waitFor(() => {
    expect(screen.getByText(/error loading data/i)).toBeInTheDocument();
  });
});
```

---

## Best Practices

### DO's ✅

1. **Use Descriptive Test Names**

   ```javascript
   // Good
   it('should display error message when email is invalid', () => {});

   // Bad
   it('test email', () => {});
   ```

2. **Test User Behavior, Not Implementation**

   ```javascript
   // Good - Tests what user sees
   expect(screen.getByText(/welcome/i)).toBeInTheDocument();

   // Bad - Tests implementation details
   expect(component.state.isLoggedIn).toBe(true);
   ```

3. **Clean Up After Tests**

   ```javascript
   beforeEach(() => {
     window.mfe = {};
     sessionStorage.clear();
   });

   afterEach(() => {
     jest.restoreAllMocks();
     jest.clearAllMocks();
   });
   ```

4. **Use waitFor for Async Operations**

   ```javascript
   await waitFor(() => {
     expect(screen.getByText(/loaded/i)).toBeInTheDocument();
   });
   ```

5. **Test Edge Cases and Error States**

   ```javascript
   it('handles undefined input gracefully', () => {
     expect(processData(undefined)).toBeNull();
   });
   ```

6. **Isolate Tests**
   - Each test should be independent
   - Avoid test interdependencies
   - Use beforeEach/afterEach for setup/cleanup

### DON'Ts ❌

1. **Don't Test Implementation Details**

   ```javascript
   // Bad
   expect(component.instance().someInternalMethod()).toBe(true);
   ```

2. **Don't Use Random Data**

   ```javascript
   // Bad - Non-deterministic
   const randomId = Math.random();

   // Good - Deterministic
   const testId = '12345';
   ```

3. **Don't Leave console.log Statements**
   - Remove debug statements before committing
   - Use proper debugging tools instead

4. **Don't Skip Important Tests**
   - Avoid `it.skip` or `describe.skip` in committed code
   - Fix failing tests instead of skipping them

5. **Don't Test External Libraries**
   - Focus on your code, not third-party code
   - Trust that libraries are tested by their maintainers

---

## Code Coverage

### Coverage Configuration

```json
{
  "collectCoverageFrom": [
    "src/**/*.{js,jsx,ts,tsx}",
    "!src/**/*.d.ts",
    "!src/**/__tests__/**/*.[jt]s?(x)",
    "!src/**/?(*.)+(spec|test).[jt]s?(x)",
    "!src/**/__mocks__/**/*.[jt]s?(x)",
    "!src/**/mocks/**/*.[jt]s?(x)",
    "!src/bootstrap.js",
    "!src/index.js",
    "!src/reportWebVitals.js"
  ]
}
```

### Running Coverage

```bash
# Run tests with coverage
npm run test-coverage

# View coverage report
# Open ./coverage/lcov-report/index.html
```

### Coverage Goals

- Aim for **80%+ code coverage**
- Focus on critical business logic
- Don't sacrifice quality for coverage numbers
- 100% coverage doesn't mean bug-free code

### SonarQube Integration

- Coverage reports sent to SonarQube via `jest-sonar-reporter`
- Report location: `./coverage/sonar-report.xml`
- Integrate with CI/CD pipeline

---

## Common Patterns & Examples

### Testing Context Providers

```javascript
import { Context } from './PDP5gContext';

describe('<Footer/> with Context', () => {
  const contextData = {
    addDeviceToCartHandler: jest.fn(),
    deviceFromCart: true,
    removeLinesHandler: jest.fn(),
  };

  test('should use context values', () => {
    render(
      <Context.Provider value={contextData}>
        <Footer btnLabel='Add to Cart' />
      </Context.Provider>,
    );

    fireEvent.click(screen.getByText(/add to cart/i));
    expect(contextData.addDeviceToCartHandler).toHaveBeenCalled();
  });
});
```

### Testing Conditional Rendering

```javascript
test('should show loading state', () => {
  render(<Component isLoading={true} />);
  expect(screen.getByText(/loading/i)).toBeInTheDocument();
});

test('should show content when loaded', () => {
  render(<Component isLoading={false} data={mockData} />);
  expect(screen.queryByText(/loading/i)).not.toBeInTheDocument();
  expect(screen.getByText(/content/i)).toBeInTheDocument();
});
```

### Testing Forms

```javascript
test('should submit form with valid data', async () => {
  const onSubmit = jest.fn();
  render(<Form onSubmit={onSubmit} />);

  const emailInput = screen.getByLabelText(/email/i);
  const submitButton = screen.getByRole('button', { name: /submit/i });

  fireEvent.change(emailInput, { target: { value: 'test@example.com' } });
  fireEvent.click(submitButton);

  await waitFor(() => {
    expect(onSubmit).toHaveBeenCalledWith({ email: 'test@example.com' });
  });
});
```

### Testing with Multiple Test Cases

```javascript
describe.each([
  ['devicePaymentPrice', { devicePaymentPrice: [{ dpTerm: 24 }] }],
  ['threeYearPrice', { threeYearPrice: { originalPrice: 1000 } }],
  ['fullRetailPrice', { fullRetailPrice: { originalPrice: 1200 } }],
])('getPricingPriority with %s', (expectedKey, price) => {
  it(`should return ${expectedKey}`, () => {
    expect(getPricingPriority(price)).toBe(expectedKey);
  });
});
```

### Testing Router Navigation

```javascript
import { render, screen } from '../../modules/test-utils/renderHelper';

test('should navigate to PDP page', () => {
  const navigatePdp = jest.fn();

  render(<Component navigatePdp={navigatePdp} />);

  fireEvent.click(screen.getByText(/view details/i));
  expect(navigatePdp).toHaveBeenCalledWith({ deviceId: '123' });
});
```

### Snapshot Testing (Use Sparingly)

```javascript
test('matches snapshot', () => {
  const { container } = render(<StaticComponent />);
  expect(container).toMatchSnapshot();
});
```

---

## Testing Commands

### Available Commands

```bash
# Run all tests (CI mode - no watch)
npm test

# Run tests in watch mode
npm run test:watch

# Run tests with debugging enabled
npm run test:debug

# Run tests with coverage report
npm run test-coverage

# Run specific test file
npm test -- Header.test.js

# Run tests matching pattern
npm test -- --testNamePattern="Header"

# Update snapshots
npm test -- -u
```

### Jest Configuration

```javascript
// Custom timeout for long-running tests
jest.setTimeout(50000);

// Module name mapping (already configured in package.json)
"moduleNameMapper": {
  "onevzsoemfecommon/(.*)$": "<rootDir>/__mocks__/onevzsoemfecommon/$1.mjs",
  "onevzsoemfeframework/(.*)$": "<rootDir>/__mocks__/onevzsoemfeframework/$1.mjs"
}
```

---

## Troubleshooting

### Common Issues

1. **Tests Timeout**
   - Increase timeout: `jest.setTimeout(50000)`
   - Check for unresolved promises
   - Ensure async operations complete

2. **Cannot Find Module**
   - Check module name mapping in package.json
   - Verify mock files exist in `__mocks__` directory
   - Use correct file extensions (.mjs for mocks)

3. **State Not Updating**
   - Wrap state changes in `act()`
   - Use `waitFor()` for async state updates
   - Check if component is connected to Redux properly

4. **Mock Not Working**
   - Ensure mock is defined before import
   - Use `{ virtual: true }` for external modules
   - Clear mocks between tests with `jest.clearAllMocks()`

---

## Additional Resources

- [Jest Documentation](https://jestjs.io/docs/getting-started)
- [React Testing Library](https://testing-library.com/docs/react-testing-library/intro/)
- [Testing Library Queries](https://testing-library.com/docs/queries/about)
- [MSW Documentation](https://mswjs.io/docs/)
- [Common Mistakes with React Testing Library](https://kentcdodds.com/blog/common-mistakes-with-react-testing-library)

---

## Checklist Before Committing Tests

- [ ] All tests pass locally (`npm test`)
- [ ] Code coverage meets minimum threshold
- [ ] No `console.log` or debug statements
- [ ] No skipped tests (`it.skip`, `describe.skip`)
- [ ] Tests are deterministic (no random data)
- [ ] Async operations use `waitFor` or `act`
- [ ] Mocks are cleaned up in `afterEach`
- [ ] Test descriptions are clear and meaningful
- [ ] Edge cases and error scenarios are covered
- [ ] Tests follow AAA (Arrange-Act-Assert) pattern

---

**Remember**: Good tests are an investment in code quality and maintainability. Write tests that give you confidence in your code!
