# GitHub Copilot Instructions

## Project Overview

This is a React-based Micro Frontend (MFE) application for Verizon's OneVZ SOE AEM platform, specifically handling assisted device sales flows. The application uses React 18.2.0, Redux Toolkit, React Router, and the Verizon Design System (VDS) component library.

## Coding Standards & Conventions

### JavaScript/React Standards

#### Code Style

- Follow **Airbnb JavaScript Style Guide** as the base standard
- Use **ESLint** with `@onevz-soe-mfe-base/eslint-config` for linting
- Use **Prettier** with `@onevz-soe-mfe-base/prettier-config` for formatting
- Always run `npm run format` before committing code
- ESLint and Prettier rules are enforced via pre-commit hooks (Husky)

#### Component Conventions

- **Named components**: Use arrow functions or function declarations
- **Unnamed components**: Use arrow functions
- **Component structure**:

  ```javascript
  import React from 'react';
  import PropTypes from 'prop-types';

  const ComponentName = ({ prop1, prop2 }) => {
    // Component logic
    return (
      // JSX
    );
  };

  ComponentName.propTypes = {
    prop1: PropTypes.string,
    prop2: PropTypes.func,
  };

  export default ComponentName;
  ```

- Place components in appropriate directories under `src/components/` or `src/pages/`
- Co-locate component-specific styles, tests, and utilities

#### Naming Conventions

- **Files**: Use PascalCase for component files (e.g., `CombinedGridwall.js`)
- **Functions**: Use camelCase (e.g., `isHomeSalesCbandBundleFlow`)
- **Constants**: Use UPPER_SNAKE_CASE for true constants
- **Components**: Use PascalCase (e.g., `Header5G`, `Footer`)
- **Props**: Use camelCase
- **CSS/Styled Components**: Use kebab-case for class names

#### Import/Export Standards

- Use ES6 import/export syntax
- Group imports in order:
  1. React and React-related libraries
  2. Third-party libraries
  3. VDS components
  4. Local components
  5. Utilities and helpers
  6. Constants
  7. Styles
- Use named exports for utilities, constants
- Use default exports for components
- Enable `devDependencies` in import rules for flexibility

### State Management

- Use **Redux Toolkit** (`@reduxjs/toolkit`) for global state
- Use **redux-saga** for side effects and async operations
- Use **redux-injectors** for code splitting and dynamic reducer/saga injection
- Store structure located in `src/modules/store/`
- Services located in `src/modules/services/`

### Styling

- Use **styled-components** (v5.3.9) for component styling
- Use **Verizon Design System (VDS)** components whenever possible
- Maintain consistent spacing and layout patterns
- Follow mobile-first responsive design principles

### Security Standards

#### Input Sanitization

- Use **DOMPurify** (v3.0.1) for sanitizing HTML content
- Use **XSS** library (v1.0.14) for preventing cross-site scripting attacks
- Validate all user inputs before processing
- Never trust data from external sources

#### Dependency Security

- Use **AJV** (v8.12.0) for JSON schema validation
- Keep dependencies updated regularly
- Review security advisories for all dependencies
- Use `npm audit` to identify and fix vulnerabilities

#### Authentication & Authorization

- Never hardcode credentials or API keys
- Use environment variables for sensitive configuration
- Implement proper session management
- Validate user permissions on both client and server

### SAST (Static Application Security Testing)

#### SonarQube Integration

- **SonarQube** is configured for code quality and security analysis
- Configuration file: `sonar-project.properties`
- Exclusions:
  - Test files: `**/*.test.js`
  - Mock files: `**/__mocks__/**`, `**/mock/**`, `**/mocks/**`
  - Setup files: `src/setupTests.js`, `src/index.js`, `src/reportWebVitals.js`, `src/bootstrap.js`
  - Assets: `**/assets/json/**/*`, `**/assets/css/*`, `**/assets/fonts/**/*`
  - Build artifacts: `**/node_modules/**`, `**/package/**`
  - Snapshots: `**/_snapshots_/**`

#### Code Quality Metrics

- Maintain code coverage above project thresholds
- Address all critical and major SonarQube issues before merging
- Monitor code smells and technical debt
- Follow SOLID principles and clean code practices

### DAST (Dynamic Application Security Testing)

- Run security scans on deployed applications
- Test for common vulnerabilities (OWASP Top 10)
- Validate API security and authentication flows
- Monitor runtime security in production environments

### Testing Standards

#### Unit Testing

- Use **Jest** and **React Testing Library** (`@testing-library/react`, `@testing-library/jest-dom`)
- Minimum code coverage requirements (as per project configuration)
- Test file naming: `ComponentName.test.js`
- Test structure:
  ```javascript
  describe('ComponentName', () => {
    describe('functionName', () => {
      it('should do something specific', () => {
        // Arrange
        // Act
        // Assert
        expect(result).toBe(expected);
      });
    });
  });
  ```

#### Coverage Configuration

- **collectCoverageFrom**: All source files except tests, mocks, and setup files
- Run coverage: `npm run test-coverage`
- Coverage reports generated in `./coverage` directory
- SonarQube integration via `jest-sonar-reporter`

#### Test Utilities

- Use `src/modules/test-utils/renderHelper.js` for common test setups
- Mock external dependencies using `__mocks__/` directory
- Mock `onevzsoemfecommon` and `onevzsoemfeframework` libraries

#### Testing Commands

- `npm test`: Run tests in CI mode (no watch)
- `npm run test:debug`: Run tests with debugging enabled
- `npm run test:watch`: Run tests in watch mode
- `npm run test-coverage`: Generate coverage reports

### Design Standards

#### Component Architecture

- Follow **Container/Presentational** pattern where appropriate
- Use **React Hooks** for state and side effects
- Implement **code splitting** for performance optimization
- Leverage **lazy loading** for routes and heavy components

#### Accessibility

- Follow WCAG 2.1 AA standards
- Use semantic HTML elements
- Provide proper ARIA labels and roles
- Ensure keyboard navigation support
- Test with screen readers

#### Performance

- Optimize bundle size (use webpack-dedupe-plugin)
- Implement proper memoization (React.memo, useMemo, useCallback)
- Lazy load routes and components
- Monitor Web Vitals metrics (using `web-vitals` library)

### Maintainability Standards

#### Code Organization

```
src/
├── components/          # Reusable UI components
├── pages/              # Page-level components
├── modules/
│   ├── services/       # API services
│   ├── store/          # Redux store configuration
│   ├── utils/          # Utility functions
│   └── test-utils/     # Test helpers
├── constants/          # Application constants
├── assets/             # Static assets
└── App.js              # Root application component
```

#### Documentation

- Add JSDoc comments for complex functions and utilities
- Document component props using PropTypes
- Maintain up-to-date README.md
- Document API integrations and data flows
- Include inline comments for complex business logic

#### Version Control

- Use **Conventional Commits** specification
- Commit message format enforced by `@commitlint/config-conventional`
- Husky pre-commit hooks for linting and formatting
- Meaningful commit messages describing the "why"

### Scalability Standards

#### Module Federation

- Built as a Micro Frontend (MFE) for modular deployment
- Integration with AEM (Adobe Experience Manager)
- Supports multiple build targets (VBG, VCG)

#### Performance Optimization

- Use **Craco** for custom webpack configuration
- Implement code splitting at route level
- Optimize dependencies (deduplication, tree shaking)
- Monitor bundle size and load performance

#### API Design

- Centralize API calls in `src/modules/services/APIService/`
- Implement proper error handling and retry logic
- Use Redux Saga for complex async flows
- Handle loading and error states consistently

### Build & Deployment

#### Build Commands

- `npm run build`: Production build (VCG)
- `npm run build:vbg`: Production build for VBG
- `npm run local:deploy`: Local deployment
- `npm run npm-package`: Create deployment packages for both VCG and VBG

#### CI/CD Pipeline

- **Jenkins** pipeline defined in `Jenkinsfile` and `Unified_Jenkinsfile`
- Automated testing in pipeline
- SonarQube integration for quality gates
- Automated packaging and deployment

#### Environment Configuration

- Use environment-specific configurations
- Store sensitive data in environment variables
- Support for multiple deployment targets
- Context path: `onevzsoemfeassisteddevice`

### Browser Support

- **Production**: >0.2%, not dead, not op_mini all
- **Development**: Last 1 version of Chrome, Firefox, Safari

### Dependencies Management

- Use **npm** with `--legacy-peer-deps` flag for installations
- Lock versions for critical dependencies
- Regular security audits
- Document reasons for version pinning

## Best Practices Checklist

Before submitting code, ensure:

- [ ] Code follows ESLint and Prettier rules
- [ ] All tests pass (`npm test`)
- [ ] Code coverage meets minimum thresholds
- [ ] PropTypes are defined for all component props
- [ ] No console.logs or debugger statements
- [ ] Proper error handling implemented
- [ ] Accessibility standards met
- [ ] Security best practices followed
- [ ] Documentation updated
- [ ] Commit messages follow conventional format
- [ ] No hardcoded credentials or sensitive data
- [ ] SonarQube quality gates pass

## Common Patterns

### API Service Usage

```javascript
import APIService from 'onevzsoemfecommon/APIService';

const fetchData = async () => {
  try {
    const response = await APIService.get('/endpoint');
    return response.data;
  } catch (error) {
    // Handle error
    console.error('API Error:', error);
    throw error;
  }
};
```

### Redux Saga Pattern

```javascript
import { call, put, takeLatest } from 'redux-saga/effects';

function* fetchDataSaga(action) {
  try {
    const data = yield call(apiCall, action.payload);
    yield put({ type: 'FETCH_SUCCESS', payload: data });
  } catch (error) {
    yield put({ type: 'FETCH_FAILURE', payload: error });
  }
}

export default function* rootSaga() {
  yield takeLatest('FETCH_REQUEST', fetchDataSaga);
}
```

### Styled Component Pattern

```javascript
import styled from 'styled-components';

const StyledContainer = styled.div`
  padding: 16px;
  background-color: #ffffff;

  @media (max-width: 768px) {
    padding: 8px;
  }
`;
```

## Additional Resources

- [Airbnb JavaScript Style Guide](https://github.com/airbnb/javascript)
- [React Documentation](https://react.dev/)
- [Redux Toolkit Documentation](https://redux-toolkit.js.org/)
- [Testing Library Documentation](https://testing-library.com/react)
- [Verizon Design System](https://vds.verizon.com/)
