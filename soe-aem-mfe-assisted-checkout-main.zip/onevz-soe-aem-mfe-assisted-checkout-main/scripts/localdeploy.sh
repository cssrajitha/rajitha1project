#!/bin/sh

# Update your local exact path of http server local to drop the built files
DEPLOY_LOCATION=/Users/<profilename>/Documents/httpserver/etc/clientlibs/vcg/common/onevzsoemfeassistedcheckout/100/
rm -rfv "$DEPLOY_LOCATION"*
cp -r ./build/* $DEPLOY_LOCATION
