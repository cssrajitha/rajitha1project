#!/bin/sh
REL_VERSION=$(echo ${GIT_BRANCH} | cut -d '/' -f2 | tr -d ' ')
REPO="onevz-soe-aem-mfe-assisted-checkout"
PROP_NAME="com.verizon.vcg.soe.mfe-assisted.aem.ui.apps.checkout"
CONTEXT_PATH="onevzsoemfeassistedcheckout"
MOCKS_ZIP_NAME='@mf-tests.zip'
DEPLOY_VERSION=100
ZIP_FOLDER=${PROP_NAME}-${REL_VERSION}.${BUILD_NUMBER}
VERSION_NUMBER=${REL_VERSION}.${BUILD_NUMBER}
ART_PATH="https://oneartifactoryci.verizon.com/artifactory/HIVV_SOE/vzw/hivv/${GIT_BRANCH}"
CUR_DIR=$(pwd) && echo "Current working dir = ${CUR_DIR}"
if [ ${REPO} = "onevz-soe-aem-mfe-framework" ] || [ ${REPO} = "onevz-soe-aem-mfe-common" ] || [ ${REPO} = "onevz-soe-aem-mfe-assisted-plans" ];then
    TEMPLATE_NAME=onevz-soe-aem-mfe-common-manifest
    ROOT_PATH="${CUR_DIR}/${ZIP_FOLDER}/jcr_root/etc/clientlibs/vcg/common/${CONTEXT_PATH}/${DEPLOY_VERSION}"
else
    TEMPLATE_NAME=onevz-soe-aem-mfe-assisted-manifest
    ROOT_PATH="${CUR_DIR}/${ZIP_FOLDER}/jcr_root/etc/clientlibs/vcg/assisted/soe-assisted-mfe/${CONTEXT_PATH}/${DEPLOY_VERSION}"
fi
TEMPLATE_ART_PATH="https://oneartifactoryci.verizon.com/artifactory/HIVV_SOE/vzw/hivv/MFE_BUILD_TEMPLATE/${TEMPLATE_NAME}"
mkdir -p ${CUR_DIR}/${ZIP_FOLDER}
mkdir -p ${CUR_DIR}/build_template
curl -ks --config configCL.txt ${TEMPLATE_ART_PATH}/${TEMPLATE_NAME}.zip -o ${TEMPLATE_NAME}.zip
unzip -q ${TEMPLATE_NAME}.zip -d ${CUR_DIR}/build_template
if [ $? -ne 0 ]; then
    echo "Error: Template zip file not available"
    exit 1
fi
if [ -d "${CUR_DIR}/build_template/jcr_root/apps" ]; then 
    rm -Rf ${CUR_DIR}/build_template/jcr_root/apps
fi
ls -altrh
echo "updating filter.xml file"
sed -i 's#/etc/clientlibs/vcg/assisted/soe-assisted-mfe#/etc/clientlibs/vcg/assisted/soe-assisted-mfe/'${CONTEXT_PATH}'/'${DEPLOY_VERSION}'#g' ${CUR_DIR}/build_template/META-INF/vault/filter.xml
grep -v "/apps/vcg/components/soe-assisted/page/react-page-mfe" ${CUR_DIR}/build_template/META-INF/vault/filter.xml > temp.txt
mv temp.txt ${CUR_DIR}/build_template/META-INF/vault/filter.xml
sed -i 's#/version.config.js##g' ${CUR_DIR}/build_template/META-INF/vault/filter.xml
echo "Printing filter.xml file"
cat ${CUR_DIR}/build_template/META-INF/vault/filter.xml
echo "update properties.xml file"
sed -i "s/VERSION_NUMBER/${VERSION_NUMBER}/g" ${CUR_DIR}/build_template/META-INF/vault/properties.xml
sed -i "s/PROP_NAME/${PROP_NAME}/g" ${CUR_DIR}/build_template/META-INF/vault/properties.xml
echo "Printing properties.xml file"
cat ${CUR_DIR}/build_template/META-INF/vault/properties.xml
echo "Copying build-template files into atifact folder"
cp -R ${CUR_DIR}/build_template/** ${CUR_DIR}/${ZIP_FOLDER}
echo "Copying build results into artifact zip folder"
mkdir -p ${ROOT_PATH}
cp -R ${CUR_DIR}/build/** ${ROOT_PATH}
echo "data under workspace ${CUR_DIR}"
ls -altrh ${CUR_DIR}
echo "data under ${CUR_DIR}/build directory"
ls -altrh ${CUR_DIR}/build
echo "data under artifact folder ${CUR_DIR}/${ZIP_FOLDER}"
ls -altrh ${CUR_DIR}/${ZIP_FOLDER}
echo "Archiving the artifact => ${ZIP_FOLDER}.zip"
cd ${CUR_DIR}/${ZIP_FOLDER}
zip -r -qq ${CUR_DIR}/${ZIP_FOLDER}.zip jcr_root META-INF 
echo "Artifact created successfully => ${ZIP_FOLDER}.zip"
echo "uploading test.zip file for dependecy services unit test"
ls -l ${CUR_DIR}/dist
curl -ks --config ${CUR_DIR}/configCL.txt -X PUT "https://oneartifactoryci.verizon.com/artifactory/HIVV_SOE/${CONTEXT_PATH}/ICON/${GIT_BRANCH}/${MOCKS_ZIP_NAME}" -T ${CUR_DIR}/dist/@mf-tests.zip
echo "uploading success"
