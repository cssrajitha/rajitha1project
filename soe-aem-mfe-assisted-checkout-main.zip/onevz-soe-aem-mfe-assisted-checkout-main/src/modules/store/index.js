import { Provider } from 'react-redux';
import configureAppStore from 'onevzsoemfeframework/Store';
import rootReducer from './reducer';
import { rootSaga } from './saga';

// eslint-disable-next-line react/prop-types
export default function StoreProvider({ children, initialReducers }) {
  const store = configureAppStore(initialReducers || rootReducer, rootSaga);
  return <Provider store={store}> {children} </Provider>;
}
