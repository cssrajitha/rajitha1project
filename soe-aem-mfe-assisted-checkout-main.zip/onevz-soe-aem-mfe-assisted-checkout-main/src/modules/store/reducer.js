import { combineReducers } from '@reduxjs/toolkit';
import { baseAPIService } from 'onevzsoemfeframework/APIService';

const createRootReducer = (injectReducer) => {
  const rootReducer = combineReducers({
    ...injectReducer,
    [baseAPIService.reducerPath]: baseAPIService.reducer,
  });

  return rootReducer;
};

export default createRootReducer;
