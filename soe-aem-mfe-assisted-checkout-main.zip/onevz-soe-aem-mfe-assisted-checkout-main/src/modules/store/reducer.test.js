import createRootReducer from './reducer';

describe('Reducer', () => {
  test('Test Root Reducer', () => {
    expect(createRootReducer({})).toBeTruthy();
  });
});
