import { injectAPI } from 'onevzsoemfeframework/APIService';
import * as APIConst from 'onevzsoemfecommon/APIServiceConstants';

export const urls = {
  cartUserInfo: '/cartservice/cart/userInfo',
  retrieveCart: '/cartservice/cart/flexV2/retrieve-cart',
  fetchPricingSnapshot: '/addonsservice/fetchPricingSnapshot',
  getAllActiveMTN: '/orderprocessservice/customerprofileapi/getAllActiveMTNs',
  orderReview: '/orderprocessservice/orderReviewApi/orderReview',
  readOrder: '/orderprocessservice/readorderapi/readOrder',
  getDetails: '/browseservice/flexV2/getDetails',
  addAccessories: '/cartservice/cart/add-accessories',
  getNextBillSummary: '/orderprocessservice/nbsapi/nextbillsummary',
  orderWrite: '/orderprocessservice/orderwriteapi/orderWrite',
  retrieveInstallmentAgreement: '/devicepricingservice/retrieveInstallmentAgreement',
  retrieveAEMInfoManagerData: '/inspicioservice/inspicio/retrieveAEMInfoManagerData',
  paperlessBilling: '/cartservice/cart/enroll-paperlessBilling',
  updateAFOInfo: '/cartservice/cart/updateAFOInfo',
  getCustomerMtns: '/orderprocessservice/customerprofileapi/flexV2/getCustomerMtns',
  getUpdateSplitFullfillmentOder: '/orderprocessservice/orderwriteapi/updateSplitFulfillmentOrder',
  readOrderDocumentsInfo: '/activationprovisionservice/readOrderDocumentsInfo',
  getDevices: '/peripheralsservice/getDevices',
  getViewreceipt: '/activationprovisionservice/viewReceipt',
  updateVisionRemark: '/acctmgmtservice/updateVisionRemark',
  readOrderRetrieveInstallmentAgreement: '/activationprovisionservice/readOrderRetrieveInstallmentAgreement',
  viewOrPrintEdgeUpReturnLabel: '/activationprovisionservice/viewOrPrintEdgeUpReturnLabel',
  emailReceipt: '/activationprovisionservice/emailReceipt',
  trackShipment: '/shippinghandlingservice/shipping/trackShipment',
  retrievePaymentOptions: '/paymentservice/retrievePaymentOptions',
  regenerateReceipts: '/receiptservice/regenerateReceipts',
  lpRetrieveCompleteOrderDetails: '/ordersearchservice/lpRetrieveCompleteOrderDetails',
  sendSecurePaymentEmail: 'paymentservice/sendSecurePaymentEmail',
  getAccountAddressValidation: '/shippinghandlingservice/shipping/getAccountAddressValidation',
  deleteCart: '/cartservice/cart/deleteCart',
  customerByMtn: '/orderprocessservice/customerprofileapi/customerByMtn',
};

const {
  cartUserInfo,
  retrieveCart,
  fetchPricingSnapshot,
  getAllActiveMTN,
  orderReview,
  getDetails,
  addAccessories,
  customerByMtn,
  getNextBillSummary,
  orderWrite,
  retrieveInstallmentAgreement,
  retrieveAEMInfoManagerData,
  paperlessBilling,
  updateAFOInfo,
  getCustomerMtns,
  getUpdateSplitFullfillmentOder,
  readOrderDocumentsInfo,
  getDevices,
  getViewreceipt,
  updateVisionRemark,
  readOrderRetrieveInstallmentAgreement,
  viewOrPrintEdgeUpReturnLabel,
  emailReceipt,
  trackShipment,
  retrievePaymentOptions,
  regenerateReceipts,
  lpRetrieveCompleteOrderDetails,
  sendSecurePaymentEmail,
  getAccountAddressValidation,
  deleteCart,
} = urls;

// Query builder Types
export const MUTATION = 'mutation';
export const QUERY = 'query';

// HTTP Method
export const POST = 'POST';
export const GET = 'GET';

// Tags

export const TAG_USER_INFO = 'tag_user_info';
export const TAG_CART_DETAILS = 'tag_cart_details';
export const TAG_PRICING_SNAP = 'tag_pricing_snap';
export const TAG_ACTIVE_MTN = 'tag_active_mtn';
export const TAG_ORDER_REVIEW = 'tag_order_review';
export const TAG_READ_ORDER = 'tag_read_order';
export const TAG_GET_DETAILS = 'tag_get_details';
export const TAG_ADD_ACCESSORIES = 'tag_add_accessories';
export const TAG_CUSTOMER_MTN = 'tag_customer_mtn';
export const TAG_GET_NEXT_BILL_SUMMARY = 'tag_get_next_bill_summary';
export const TAG_ORDER_WRITE = 'tag_order_write';
export const TAG_RETRIEVE_INSTALLMENT_AGREEMENT = 'tag_retrieve_installment_agreement';
export const TAG_RETRIEVE_AEM_INFO_MANAGER_DATA = 'tag_retrieve_aem_info_manager_data';
export const TAG_PAPER_LESS_BILLING = 'tag_paper_less_billing';
export const TAG_UPDATE_AFO_INFO = 'tag_update_AFO_Info';
export const TAG_GET_CUSTOMER_BY_MTNS = 'tag_get_customer_by_mtns';
export const TAG_GET_UPDATE_SPLIT_FULFILLMENT_ORDER = 'tag_get_update_split_fulfillment_order';
export const TAG_READ_ORDER_DOCUMENTS_INFO = 'tag_read_order_documents_info';
export const TAG_GET_DEVICES = 'tag_get_devices';
export const TAG_VIEW_RECEIPT = 'tag_view_receipt';
export const TAG_UPDATE_VISION_REMARK = 'tag_update_vision_remark';
export const TAG_READ_ORDER_RETRIEVE_INSTALLMENT_AGREEMENT = 'tag_read_order_retrieve_installment_agreement';
export const TAG_VIEW_OR_PRINT_EDGE_UP_RETURN_LABEL = 'tag_view_or_print_edge_up_return_label';
export const TAG_EMAIL_RECEIPT = 'tag_email_receipt';
export const TAG_REGENERATE_RECEIPTS = 'tag_regenerate_receipts';
export const TAG_RETRIEVE_COMPLETE_ORDER_DETAILS = 'tag_lpRetrieveCompleteOrderDetails';
export const TAG_GET_ACCOUNT_ADDRESS_VALIDATION = 'tag_getAccountAddressValidation';
export const TAG_DELETE_CART = 'tag_deletecart';

export const TAG_TRACK_SHIPMENT = 'tag_track_shipment';
export const TAG_RETRIEVE_PAYMENT_OPTIONS = 'tag_retrieve_payment_options';
export const TAG_SEND_SECURE_PAYMENT_EMAIL = 'tag_send_secure_payment_email';

// Names

export const API_USER_INFO = 'saveUserInfo';
export const API_CART_DETAILS = 'getCartDetails';
export const API_PRICING_SNAP = 'fetchPricingSnap';
export const API_ACTIVE_MTN = 'getAllActiveMtn';
export const API_ORDER_REVIEW = 'getOrderReview';
export const API_READ_ORDER = 'getReadOrder';
export const API_GET_DETAILS = 'getDetails';
export const API_ADD_ACCESSORIES = 'addAccessories';
export const API_CUSTOMER_MTN = 'getCustomerByMtn';
export const API_GET_NEXT_BILL_SUMMARY = 'getNextBillSummary';
export const API_ORDER_WRITE = 'getOrderWrite';
export const API_RETRIEVE_INSTALLMENT_AGREEMENT = 'getRetrieveInstallmentAgreement';
export const API_RETRIEVE_AEM_INFO_MANAGER_DATA = 'postRetrieveAemInfoManagerData';
export const API_PAPER_LESS_BILLING = 'getPaperLessBilling';
export const API_UPDATE_AFO_INFO = 'updateAFOInfo';
export const API_GET_CUSTOMER_BY_MTNS = 'getCustomerByMtns';
export const API_GET_UPDATE_SPLIT_FULFILLMENT_ORDER = 'getSplitFulfillmentOrder';
export const API_READ_ORDER_DOCUMENTS_INFO = 'readOrderDocumentsInfo';
export const API_GET_DEVICES = 'getDevices';
export const API_VIEW_RECEIPT = 'getViewReceipt';
export const API_UPDATE_VISION_REMARK = 'updateVisionRemark';
export const API_READ_ORDER_RETRIEVE_INSTALLMENT_AGREEMENT = 'readOrderRetrieveInstallmentAgreement';
export const API_VIEW_OR_PRINT_EDGE_UP_RETURN_LABEL = 'viewOrPrintEdgeUpReturnLabel';
export const API_EMAIL_RECEIPT = 'emailReceipt';
export const API_TRACK_SHIPMENT = 'getTrackShipment';
export const API_RETRIEVE_PAYMENT_OPTIONS = 'getRetrievePaymentOptions';
export const API_REGENERATE_RECEIPTS = 'regenerateReceipts';
export const API_RETRIEVE_COMPLETE_ORDER_DETAILS = 'lpRetrieveCompleteOrderDetails';
export const API_SEND_SECURE_PAYMENT_EMAIL = 'sendSecurePaymentEmail';

export const API_GET_ACCOUNT_ADDRESS_VALIDATION = 'getAccountAddressValidation';
export const API_DELETE_CART = 'deleteCart';
// Hooks

export const { useLazySaveUserInfoQuery } = injectAPI(API_USER_INFO, TAG_USER_INFO, cartUserInfo);
export const { useLazyGetCartDetailsQuery } = injectAPI(API_CART_DETAILS, TAG_CART_DETAILS, retrieveCart);
export const { useLazyGetSplitFulfillmentOrderQuery } = injectAPI(
  API_GET_UPDATE_SPLIT_FULFILLMENT_ORDER,
  TAG_GET_UPDATE_SPLIT_FULFILLMENT_ORDER,
  getUpdateSplitFullfillmentOder,
);
export const { useLazyFetchPricingSnapQuery } = injectAPI(API_PRICING_SNAP, TAG_PRICING_SNAP, fetchPricingSnapshot);
export const { useLazyGetAllActiveMtnQuery } = injectAPI(API_ACTIVE_MTN, TAG_ACTIVE_MTN, getAllActiveMTN);
export const { useLazyGetRetrievePaymentOptionsQuery } = injectAPI(
  API_RETRIEVE_PAYMENT_OPTIONS,
  TAG_RETRIEVE_PAYMENT_OPTIONS,
  retrievePaymentOptions,
);
export const { useGetOrderReviewQuery } = injectAPI(API_ORDER_REVIEW, TAG_ORDER_REVIEW, orderReview);
export const { useLazyGetReadOrderQuery } = injectAPI(API_READ_ORDER, TAG_READ_ORDER, urls.readOrder);
export const { useLazyGetDetailsQuery } = injectAPI(API_GET_DETAILS, TAG_GET_DETAILS, getDetails);
export const { useLazyAddAccessoriesQuery } = injectAPI(API_ADD_ACCESSORIES, TAG_ADD_ACCESSORIES, addAccessories);
export const { useLazyGetCustomerByMtnQuery } = injectAPI(API_CUSTOMER_MTN, TAG_CUSTOMER_MTN, customerByMtn);
export const { useLazyGetDevicesQuery } = injectAPI(API_GET_DEVICES, TAG_GET_DEVICES, getDevices);
export const { useLazyGetViewReceiptQuery } = injectAPI(API_VIEW_RECEIPT, TAG_VIEW_RECEIPT, getViewreceipt);
export const { useLazyUpdateVisionRemarkQuery } = injectAPI(
  API_UPDATE_VISION_REMARK,
  TAG_UPDATE_VISION_REMARK,
  updateVisionRemark,
);

export const { useLazyReadOrderRetrieveInstallmentAgreementQuery } = injectAPI(
  API_READ_ORDER_RETRIEVE_INSTALLMENT_AGREEMENT,
  TAG_READ_ORDER_RETRIEVE_INSTALLMENT_AGREEMENT,
  readOrderRetrieveInstallmentAgreement,
);

export const { useLazyViewOrPrintEdgeUpReturnLabelQuery } = injectAPI(
  API_VIEW_OR_PRINT_EDGE_UP_RETURN_LABEL,
  TAG_VIEW_OR_PRINT_EDGE_UP_RETURN_LABEL,
  viewOrPrintEdgeUpReturnLabel,
);

export const { useLazyGetNextBillSummaryQuery } = injectAPI(
  API_GET_NEXT_BILL_SUMMARY,
  TAG_GET_NEXT_BILL_SUMMARY,
  getNextBillSummary,
);
export const { useLazyGetOrderWriteQuery } = injectAPI(API_ORDER_WRITE, TAG_ORDER_WRITE, orderWrite);
export const { useLazyGetRetrieveInstallmentAgreementQuery } = injectAPI(
  API_RETRIEVE_INSTALLMENT_AGREEMENT,
  TAG_RETRIEVE_INSTALLMENT_AGREEMENT,
  retrieveInstallmentAgreement,
);
export const { useLazyPostRetrieveAemInfoManagerDataQuery } = injectAPI(
  API_RETRIEVE_AEM_INFO_MANAGER_DATA,
  TAG_RETRIEVE_AEM_INFO_MANAGER_DATA,
  retrieveAEMInfoManagerData,
);

export const { useUpdateAFOInfoMutation } = injectAPI(
  API_UPDATE_AFO_INFO,
  TAG_UPDATE_AFO_INFO,
  updateAFOInfo,
  POST,
  MUTATION,
  [APIConst.TAG_RETRIVE_CART],
);

export const { useLazyGetCustomerByMtnsQuery } = injectAPI(
  API_GET_CUSTOMER_BY_MTNS,
  TAG_GET_CUSTOMER_BY_MTNS,
  getCustomerMtns,
);
export const { useLazyGetPaperLessBillingQuery } = injectAPI(
  API_PAPER_LESS_BILLING,
  TAG_PAPER_LESS_BILLING,
  paperlessBilling,
);

console.log(
  'APIConst',
  injectAPI(API_READ_ORDER_DOCUMENTS_INFO, TAG_READ_ORDER_DOCUMENTS_INFO, readOrderDocumentsInfo),
);
export const { useLazyReadOrderDocumentsInfoQuery } = injectAPI(
  API_READ_ORDER_DOCUMENTS_INFO,
  TAG_READ_ORDER_DOCUMENTS_INFO,
  readOrderDocumentsInfo,
);
export const { useLazyEmailReceiptQuery } = injectAPI(API_EMAIL_RECEIPT, TAG_EMAIL_RECEIPT, emailReceipt);
export const { useLazyGetTrackShipmentQuery } = injectAPI(API_TRACK_SHIPMENT, TAG_TRACK_SHIPMENT, trackShipment);
export const { useLazyRegenerateReceiptsQuery } = injectAPI(
  API_REGENERATE_RECEIPTS,
  TAG_REGENERATE_RECEIPTS,
  regenerateReceipts,
);

export const { useLazyLpRetrieveCompleteOrderDetailsQuery } = injectAPI(
  API_RETRIEVE_COMPLETE_ORDER_DETAILS,
  TAG_RETRIEVE_COMPLETE_ORDER_DETAILS,
  lpRetrieveCompleteOrderDetails,
);

export const { useLazySendSecurePaymentEmailQuery } = injectAPI(
  API_SEND_SECURE_PAYMENT_EMAIL,
  TAG_SEND_SECURE_PAYMENT_EMAIL,
  sendSecurePaymentEmail,
);

export const { useLazyGetAccountAddressValidationQuery } = injectAPI(
  API_GET_ACCOUNT_ADDRESS_VALIDATION,
  TAG_GET_ACCOUNT_ADDRESS_VALIDATION,
  getAccountAddressValidation,
);

export const { useLazyDeleteCartQuery } = injectAPI(API_DELETE_CART,TAG_DELETE_CART, deleteCart)
