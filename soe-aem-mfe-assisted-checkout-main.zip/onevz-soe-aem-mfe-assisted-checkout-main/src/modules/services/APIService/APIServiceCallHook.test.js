import { TAG_USER_INFO, urls } from './APIServiceCallHook';

jest.mock(
  'onevzsoemfeframework/GetAppConfig',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    GetAppConfig: jest.fn(() => ''),
  }),
  { virtual: true }
);
describe(`App component`, () => {
  test('App should mount', async () => {
    expect(TAG_USER_INFO).toBe('tag_user_info');
  });
});

describe('URLs Assignment Test', () => {
  test('Assign URLs from urls object', () => {
    const {
      cartUserInfo,
      retrieveCart,
      fetchPricingSnapshot,
      getAllActiveMTN,
      orderReview,
      getDetails,
      retrieveAEMInfoManagerData,
      getUpdateSplitFullfillmentOder,
    } = urls;
    expect(cartUserInfo).toBe('/cartservice/cart/userInfo');
    expect(retrieveCart).toBe('/cartservice/cart/flexV2/retrieve-cart');
    expect(fetchPricingSnapshot).toBe('/addonsservice/fetchPricingSnapshot');
    expect(getAllActiveMTN).toBe('/orderprocessservice/customerprofileapi/getAllActiveMTNs');
    expect(orderReview).toBe('/orderprocessservice/orderReviewApi/orderReview');
    expect(getDetails).toBe('/browseservice/flexV2/getDetails');
    expect(retrieveAEMInfoManagerData).toBe('/inspicioservice/inspicio/retrieveAEMInfoManagerData');
    expect(getUpdateSplitFullfillmentOder).toBe('/orderprocessservice/orderwriteapi/updateSplitFulfillmentOrder');
    expect(urls?.readOrder).toBe('/orderprocessservice/readorderapi/readOrder');
  });
});
