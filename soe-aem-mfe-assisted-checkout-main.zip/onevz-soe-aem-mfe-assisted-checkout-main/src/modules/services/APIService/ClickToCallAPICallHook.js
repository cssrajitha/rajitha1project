import { useLazyGetClickToCallDetailsQuery, useLazyInitiateClickToCallQuery } from './APIServiceHooks';

const ClickToCallAPICallHook = () => {
  const [getClickToCallDetailsRequest, getClickToCallDetailsResult] = useLazyGetClickToCallDetailsQuery();
  const [getClickToCallRequest, getClickToCallResult] = useLazyInitiateClickToCallQuery();

  return {
    getClickToCallDetailsRequest,
    getClickToCallDetailsResult,
    getClickToCallRequest,
    getClickToCallResult,
  };
};

export default ClickToCallAPICallHook;
