import { useLazyGetReferencesQuery } from './APIServiceHooks';

const AccountSectionAPICallHook = () => {
  const [getReferences, getReferencesResult] = useLazyGetReferencesQuery();
  return {
    getReferences,
    getReferencesResult,
  };
};

export default AccountSectionAPICallHook;
