import { renderHook } from '@testing-library/react';
import AgreementsAPICallHook from './AgreementsAPICallHook';
import StoreProvider from '../../store/index';

describe('AgreementsAPICallHook Test', () => {
  test('Should call the hook ', () => {
    const response = renderHook(() => AgreementsAPICallHook(), { wrapper: StoreProvider });
    expect(response).toBeDefined();
  });
});
