import { useLazyGetOrderWriteQuery } from './APIServiceCallHook';
import { useLazyMultiLineFMIPQuery } from './APIServiceHooks';

const GetStandAlonetradein = () => {
  const [getOrderWrite, getOrderWriteResult] = useLazyGetOrderWriteQuery();
  const [getMFIPrequest, getMFIPResult] = useLazyMultiLineFMIPQuery();

  return {
    getOrderWrite,
    getOrderWriteResult,
    getMFIPrequest,
    getMFIPResult,
  };
};

export default GetStandAlonetradein;
