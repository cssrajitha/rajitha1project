import { useLazyGetVerifyEmailQuery } from 'onevzsoemfecommon/APIService';
import {
  useLazyEmailReceiptQuery,
  useLazyGetDevicesQuery,
  useLazyGetViewReceiptQuery,
  useLazyRegenerateReceiptsQuery,
} from './APIServiceCallHook';
import { useLazyEmailValidateQuery } from './APIServiceHooks';

const EmailApiCallHook = () => {
  const [emailValidate, emailValidateResult] = useLazyEmailValidateQuery();
  const [verifyEmail, verifyEmailResult] = useLazyGetVerifyEmailQuery();
  const [getViewreceipt, getViewreceiptResult] = useLazyGetViewReceiptQuery();
  const [getDevices, getDevicesResult] = useLazyGetDevicesQuery();
  const [emailReceipt, emailReceiptResult] = useLazyEmailReceiptQuery();
  const [regenerateReceipts, getRegereateReceipts] = useLazyRegenerateReceiptsQuery();

  return {
    emailValidate,
    emailValidateResult,
    verifyEmail,
    verifyEmailResult,
    getViewreceipt,
    getViewreceiptResult,
    getDevices,
    getDevicesResult,
    emailReceipt,
    emailReceiptResult,
    regenerateReceipts,
    getRegereateReceipts,
  };
};
export default EmailApiCallHook;
