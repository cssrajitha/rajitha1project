import { renderHook } from '@testing-library/react';
import StoreProvider from '../../store/index';
import EmailApiCallHook from './EmailApiCallHook';

describe('EmailApiCallHook Test', () => {
  test('Should call the hook ', () => {
    const response = renderHook(() => EmailApiCallHook(), { wrapper: StoreProvider });
    expect(response).toBeDefined();
  });
});
