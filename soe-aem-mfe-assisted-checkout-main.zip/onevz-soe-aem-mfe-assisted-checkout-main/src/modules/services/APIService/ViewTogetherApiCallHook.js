import {
  useLazyGenerateInspicioIdQuery,
  useLazySendEmailQuery,
  useLazySendLovLinkQuery,
  useLazySendMessageQuery,
  useLazyGeneratePaxQRCodeQuery,
  useLazyReceiveMessageQuery,
  useLazyUpdateAffirmPaymentQuery,
} from './APIServiceHooks';

const ViewTogetherApiCallHook = () => {
  const [requestBodyGenerateInspicioId, getResultGenerateInspicioId] = useLazyGenerateInspicioIdQuery();
  const [requestBodySendMessage, getResultSendMessage] = useLazySendMessageQuery();
  const [requestBodySendLovLink, getResultSendLovLink] = useLazySendLovLinkQuery();
  const [requestBodySendEmail, getResultSendEmail] = useLazySendEmailQuery();
  const [requestBodyGeneratePaxQRCode, getResultGeneratePaxQRCode] = useLazyGeneratePaxQRCodeQuery();
  const [receiveMessage, receiveMessageResult] = useLazyReceiveMessageQuery();
  const [updateAffirm, updateAffirmResult] = useLazyUpdateAffirmPaymentQuery();

  return {
    requestBodyGenerateInspicioId,
    getResultGenerateInspicioId,
    requestBodySendMessage,
    getResultSendMessage,
    requestBodySendLovLink,
    getResultSendLovLink,
    requestBodySendEmail,
    getResultSendEmail,
    requestBodyGeneratePaxQRCode,
    getResultGeneratePaxQRCode,
    receiveMessage,
    receiveMessageResult,
    updateAffirm,
    updateAffirmResult,
  };
};

export default ViewTogetherApiCallHook;
