import {
  TAG_FETCH_PRICING_SNAPSHOT,
  API_PRICINGSNAPSHOT_PROFILE,
  appConfig,
  API_BROWSESERVICE_DEVICE_DETAILS,
  TAG_BROWSESERVICE_DEVICE_DETAILS,
} from './APIServiceHooks';

const { urls } = appConfig;

const { fetchPricingSnapshot, getDetails } = urls;

describe(`App component`, () => {
  test('App should mount', async () => {
    expect(TAG_FETCH_PRICING_SNAPSHOT).toBe('tag_pricing_snapshot');
    expect(API_PRICINGSNAPSHOT_PROFILE).toBe('getPricingSnapshot');
    expect(API_BROWSESERVICE_DEVICE_DETAILS).toBe('getDeviceDetails');
    expect(TAG_BROWSESERVICE_DEVICE_DETAILS).toBe('tag_browseservice_device_details');
  });
});

describe('URLs Assignment Test', () => {
  test('Assign URLs from urls object', () => {
    expect(fetchPricingSnapshot).toBeTruthy();
    expect(getDetails).toBeTruthy();
  });
});
