import { renderHook } from '@testing-library/react';
import StoreProvider from '../../store/index';
import PickupDetailsAPICallHook from './PickupDetailsAPICallHook';

describe('PickupApiCallHook Test', () => {
  test('Should call the hook ', () => {
    const response = renderHook(() => PickupDetailsAPICallHook(), { wrapper: StoreProvider });
    expect(response).toBeDefined();
  });
});
