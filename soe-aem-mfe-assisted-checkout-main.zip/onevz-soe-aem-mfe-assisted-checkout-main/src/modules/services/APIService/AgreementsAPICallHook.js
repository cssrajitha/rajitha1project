import {
  useLazyGetCustomerByMtnsQuery,
  useLazyGetOrderWriteQuery,
  useLazyGetRetrieveInstallmentAgreementQuery,
  useLazyPostRetrieveAemInfoManagerDataQuery,
  useUpdateAFOInfoMutation,
} from './APIServiceCallHook';
import {
  useLazyGetAccountAddressesQuery,
  useLazyUpdateShippingAddressAndOptionsQuery,
  useLazyValidateAddressQuery,
} from './APIServiceHooks';

const AgreementsAPICallHook = () => {
  const [getOrderWrite, getOrderWriteResult] = useLazyGetOrderWriteQuery();
  const [getRetrieveInstallmentAgreement, getRetrieveInstallmentAgreementResult] =
    useLazyGetRetrieveInstallmentAgreementQuery();
  const [retrieveAEMInfoManagerDataRequest, retrieveAEMInfoManagerDataResponse] =
    useLazyPostRetrieveAemInfoManagerDataQuery();
  const [updateAFOInfo, UpdateAFOInfoResponse] = useUpdateAFOInfoMutation();
  const [getCustomerByMtns, getCustomerByMtnsResult] = useLazyGetCustomerByMtnsQuery();
  const [getUniqueAddresses, getUniqueAddressesResult] = useLazyGetAccountAddressesQuery();
  const [validateAddressBody, validateAddressResult] = useLazyValidateAddressQuery();
  const [updateShippingOptionBody, updateShippingOptionResult] = useLazyUpdateShippingAddressAndOptionsQuery();

  return {
    getOrderWrite,
    getOrderWriteResult,
    getRetrieveInstallmentAgreement,
    getRetrieveInstallmentAgreementResult,
    retrieveAEMInfoManagerDataRequest,
    retrieveAEMInfoManagerDataResponse,
    updateAFOInfo,
    UpdateAFOInfoResponse,
    getCustomerByMtns,
    getCustomerByMtnsResult,
    getUniqueAddresses,
    getUniqueAddressesResult,
    validateAddressBody,
    validateAddressResult,
    updateShippingOptionBody,
    updateShippingOptionResult,
  };
};

export default AgreementsAPICallHook;
