import { useLazyGetDetailsQuery } from './APIServiceCallHook';

const GetDetailsApiCallHook = () => {
  const [getDetailsReq, getDetailsRes] = useLazyGetDetailsQuery();
  return {
    getDetailsReq,
    getDetailsRes,
  };
};

export default GetDetailsApiCallHook;
