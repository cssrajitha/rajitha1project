import { useLazyGet5GAppointmentsQuery, useLazySave5GAppointmentQuery } from './APIServiceHooks';

const AppointmentAPICallHook = () => {
  const [get5GAppointments, get5GAppointmentsResult] = useLazyGet5GAppointmentsQuery();
  const [save5GAppointment, save5GAppointmentResult] = useLazySave5GAppointmentQuery();
  return {
    get5GAppointments,
    get5GAppointmentsResult,
    save5GAppointment,
    save5GAppointmentResult,
  };
};
export default AppointmentAPICallHook;
