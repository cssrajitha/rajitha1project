import { useAddRemoveAccessoriesMutation } from 'onevzsoemfecommon/APIService';
import { useLazyGetCustomerByMtnQuery } from './APIServiceCallHook';

const GetAccessApiCallHook = () => {
  const [addAccessories, addAccessoriesSuccess] = useAddRemoveAccessoriesMutation();
  const [getCustomerByMtn, getCustomerByMtnSuccess] = useLazyGetCustomerByMtnQuery();

  return {
    addAccessories,
    addAccessoriesSuccess,
    getCustomerByMtn,
    getCustomerByMtnSuccess,
  };
};

export default GetAccessApiCallHook;
