import { useLazyGetPaperLessBillingQuery } from './APIServiceCallHook';

const PaperLessBillingApiCallHook = () => {
  const [paperLessBilling, paperLessBillingResult] = useLazyGetPaperLessBillingQuery();

  return {
    paperLessBilling,
    paperLessBillingResult,
  };
};

export default PaperLessBillingApiCallHook;
