import { useLazyGetNextBillSummaryQuery } from './APIServiceCallHook';

const GetNextBillSummaryHook = () => {
  const [getNextBillSummaryReq, getNextBillSummaryRes] = useLazyGetNextBillSummaryQuery();
  return {
    getNextBillSummaryReq,
    getNextBillSummaryRes,
  };
};

export default GetNextBillSummaryHook;
