import { useLazyGetStoreInfoQuery } from './APIServiceHooks';

const PickupDetailsAPICallHook = () => {
  const [getStoreInfo, storeInfoResult] = useLazyGetStoreInfoQuery();
  return {
    getStoreInfo,
    storeInfoResult,
  };
};

export default PickupDetailsAPICallHook;
