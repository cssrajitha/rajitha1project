import { injectAPI } from 'onevzsoemfeframework/APIService';
import { GetAppConfig } from 'onevzsoemfeframework/GetAppConfig';

export const appConfig = GetAppConfig();
const { urls } = appConfig;

const url_local = {
  retrieveRemarks: 'activationprovisionservice/remark/retrieveremark',
  resubmitActivationApi: '/orderprocessservice/resubmit/resubmitActivation',
  ocActivation: '/orderprocessservice/activationStatus/retrieveActivationStatus',
  getReferences: '/addonsservice/getReferences',
  lineCharges: '/orderprocessservice/nbsapi/otherlinescharges',
  computeDPPrices: '/devicepricingservice/computeDPPrices',
  sendEmail: '/inspicioservice/inspicio/sendEmail',
  generatePaxQRCode: '/peripheralsservice/generatePaxQRCode',
  generateInspicioId: '/inspicioservice/inspicio/generateInspicioID',
  sendMessage: '/inspicioservice/inspicio/sendMessage',
  sendLovLink: '/orderprocessservice/lovapi/sendLovLink',
  validateAddress: '/qualificationservice/vfw/validateAddress',
  updateShippingAddressAndOptions: '/shippinghandlingservice/shipping/updateShippingAddressAndOptions',
  updateShippingAddressQA: '/shippinghandlingservice/shipping/updateShippingAddressQA',
  shippingOptions: '/shippinghandlingservice/shipping/getShippingOptions',
  checkInStoreAvailability: '/shippinghandlingservice/ispu/checkInStoreAvailability',
  updateShippingOptions: '/shippinghandlingservice/shipping/updateShippingOptions',
  getClickToCallDetails: '/accountlandingservice/landing/getClickToCallDetails',
  initiateClickToCall: '/accountlandingservice/landing/initiateClickToCall',
  manualDiscount: '/interimservice/manual-discount',
  validateCartAndCheckout: '/cartservice/cart/validateCartAndCheckout',
  updateManualDiscount: '/cartservice/cart/updateManualDiscount',
  updateBarcode: '/cartservice/cart/updateBarcode',
  updateTradein: '/tradeinservice/tradein/updateTradein',
  updateAccountDevices: '/tradeinservice/tradein/accountDevices',
  emailValidate: '/accountlandingservice/validate/emailValidate',
  verifyEmail: '/fraudservice/validate/verifyEmail',
  addDownPayment: '/cartservice/cart/add-downpayment',
  multiLineFMIP: '/devicepricingservice/multiLineFMIP',
  getLovDetails: '/orderprocessservice/lovDetailsApi/getLovDetails',
  getAccAddressValidation: '/shippinghandlingservice/shipping/getAccountAddressValidation',
  get5GAppointments: '/appointmentservice/appointment/get5GAppointments',
  save5GAppointment: '/appointmentservice/appointment/save5GAppointment',
  receiveMessage: '/inspicioservice/inspicio/receiveMessage',
  updateAffirmPayment: '/paymentservice/updateAffirmPayment',
  giftPurchase: '/cartservice/cart/enroll-giftPurchase',
  getStoreInformation: '/shippinghandlingservice/ispu/getStoreInformation',
  getAccountAddresses: '/shippinghandlingservice/shipping/getAccountAddresses',
  getTypeAhead: '/shippinghandlingservice/shipping/typeahead',
  getSMSConsent: '/consentservice/consent/getSMSConsent',
  lpRetrieveCompleteOrderDetails: '/ordersearchservice/lpRetrieveCompleteOrderDetails',
  readOrder: '/orderprocessservice/readorderapi/readOrder',
  fetchUnifiedNbsData: '/orderprocessservice/nbsapi/fetchUnifiedNbsData',
  nextbillestimate: '/assisted/nsa/secure/gw/unifiednbs/pos/ordering/nextbillestimate',
  getStoreTradeInformation: '/tradeinservice/tradein/getStoreInformation',
  getStoreInfo: '/shippinghandlingservice/ispu/getStoreInformation',
};

// Trade-in specific URLs
const UPDATE_TRADEIN_URL = '/tradeinservice/tradein/updateTradein';

export const API_BROWSESERVICE_DEVICE_DETAILS = 'getDeviceDetails';
export const TAG_BROWSESERVICE_DEVICE_DETAILS = 'tag_browseservice_device_details';

export const API_ADDDPPRICES = 'updateDownpayment';
export const TAG_ADDDPPRICES = 'tag_updateDownpayment';

const { fetchPricingSnapshot, getDetails } = urls;
const {
  retrieveRemarks,
  resubmitActivationApi,
  ocActivation,
  getReferences,
  validateAddress,
  updateShippingAddressAndOptions,
  updateShippingAddressQA,
  shippingOptions,
  checkInStoreAvailability,
  updateShippingOptions,
  lineCharges,
  addDownPayment,
  manualDiscount,
  updateManualDiscount,
  updateBarcode,
  updateTradein,
  updateAccountDevices,
  emailValidate,
  verifyEmail,
  computeDPPrices,
  multiLineFMIP,
  getLovDetails,
  getAccAddressValidation,
  get5GAppointments,
  save5GAppointment,
  receiveMessage,
  updateAffirmPayment,
  giftPurchase,
  getStoreInformation,
  getAccountAddresses,
  validateCartAndCheckout,
  getTypeAhead,
  getSMSConsent,
  lpRetrieveCompleteOrderDetails,
  readOrder,
  fetchUnifiedNbsData,
  nextbillestimate,
  getStoreTradeInformation,
  getStoreInfo
} = url_local;

// HTTP Method
export const POST = 'POST';

// Operation types
export const MUTATION = 'mutation';

// Tags
export const TAG_GET_REFERENCES = 'tag_get_references';
export const TAG_SHIPPING_OPTIONS = 'tag_get_shipping_options';
export const TAG_CHECK_IN_STORE_AVAILABLITY = 'tag_checkin_store_availability';
export const TAG_UPDATE_SHIPPING_OPTIONS = 'tag_update_shipping_options';
export const TAG_COMPUTEDPPRICES = 'tag_computeDPPrices';
export const TAG_MY_LINE_CHARGES = 'tag_lines_charges';
export const TAG_GENERATE_INSPICIO_ID = 'tag_generate_inspicio_id';
export const TAG_GENERATE_PAX_QR_CODE = 'tag_generate_inspicio_id';
export const TAG_SEND_MESSAGE = 'tag_send_message';
export const TAG_SEND_LOV_LINK = 'tag_send_lov_link';
export const TAG_SEND_EMAIL = 'tag_send_email';
export const TAG_FETCH_PRICING_SNAPSHOT = 'tag_pricing_snapshot';
export const TAG_UPDATE_SHIPPINGADDRESS = 'tag_updateShippingAddressAndOptions';
export const TAG_UPDATE_SHIPPINGADDRESS_QA = 'tag_updateShippingAddressQA';
export const TAG_VALIDATE_ADDRESS = 'tag_validateAddress';
export const TAG_CLICKTOCALL_DETAILS = 'tag_getClickToCallDetails';
export const TAG_INITIATE_CLICKTOCALL = 'tag_initiateClickToCall';
export const TAG_MANUAL_DISCOUNT = 'tag_getManualDiscount';
export const TAG_UPDATE_MANUAL_DISCOUNT = 'tag_updateManualDiscount';
export const TAG_UPDATE_BARCODE = 'tag_updateBarcode';
export const TAG_UPDATE_TRADEIN = 'tag_updateTradein';
export const TAG_UPDATE_AccountDevices = 'tag_accountDevices';
export const TAG_EMAIL_VALIDATE = 'tag_emailValidate';
export const TAG_VERIFY_EMAIL = 'tag_verifyEmail';
export const TAG_MULTILINEFMIP = 'tag_multiLineFMIP';
export const TAG_GET_LOV_DETAILS = 'tag_get_lov_details';
export const TAG_GET_ACC_ADDRESS_VALIDATION = 'tag_get_acc_address_validation';
export const TAG_GET_5GAppointments = 'tag_get5GAppointments';
export const TAG_SAVE_5GAppointment = 'tag_save5GAppointment';
export const TAG_ISNPICIO_RECEIVE_MESSAGE = 'tag_inspicio_receive_message';
export const TAG_UPDATE_AFFIRM_PAYMENT = 'tag_update_affirm_payment';
export const TAG_GIFT_PURCHASE = 'tag_giftPurchase';
export const TAG_GET_STORE_INFORMATION = 'tag_get_store_information';
export const TAG_GET_STORE_INFO = 'tag_get_store_info'
export const TAG_GET_ACCOUNT_ADDRESSES = 'tag_get_account_addresses';
export const TAG_VALIDATE_CART_AND_CHECKOUT = 'tag_getValidateCartAndCheckout';
export const TAG_TYPE_AHEAD = 'tag_typeahead';
export const TAG_GET_SMS_CONSENT = 'tag_getSMSConsent';
export const TAG_LP_RETRIEVE_COMPLETE_ORDER_DETAILS = 'tag_lpRetrieveCompleteOrderDetails';
export const TAG_READ_ORDER = 'tag_readOrder';
export const TAG_FETCH_UNIFIED_NBS_DATA = 'tag_fetch_unified_nbs_data';
export const TAG_FETCH_NBE_DATA = 'tag_nextbillestimate';
export const TAG_GET_STORE_TRADE_INFORMATION = 'tag_get_store_trade_information';

// Cache invalidation tags
export const TAG_RETRIVE_CART = 'tag_retrive_cart';

// Names
export const API_COMPUTEDPPRICES = 'computeDPPrices';
const API_LINE_CHARGES = 'postLineCharges';
export const API_GENERATE_INSPICIO_ID = 'generateInspicioId';
export const API_GENERATE_PAX_QR_CODE = 'generatePaxQRCode';
export const API_SEND_MESSAGE = 'sendMessage';
export const API_SEND_LOV_LINK = 'sendLovLink';
export const API_SEND_EMAIL = 'sendEmail';
export const API_PLAN_REFERENCES = 'getReferences';
export const API_PRICINGSNAPSHOT_PROFILE = 'getPricingSnapshot';
export const API_SHIPPING_OPTIONS = 'shippingOptions';
export const API_CHECK_IN_STORE_AVAILABLITY = 'checkInStoreAvailability';
export const API_UPDATE_SHIPPING_OPTIONS = 'updateShippingOptions';
export const API_UPDATE_SHIPPINGADDRESS = 'updateShippingAddressAndOptions';
export const API_UPDATE_SHIPPINGADDRESS_QA = 'updateShippingAddressQA';
export const API_VALIDATE_ADDRESS = 'validateAddress';
export const API_CLICKTOCALL_DETAILS = 'getClickToCallDetails';
export const API_INITIATE_CLICKTOCALL = 'initiateClickToCall';
export const API_MANUAL_DISCOUNT = 'getManualDiscount';
export const API_UPDATE_MANUAL_DISCOUNT = 'updateManualDiscount';
export const API_UPDATE_BARCODE = 'updateBarcode';
export const API_UPDATE_TRADEIN = 'updateTradein';
export const API_UPDATE_TRADEIN_MUTATION = 'updateTradeIn';
export const API_UPDATE_AccountDevices = 'updateAccountDevices';
export const API_EMAIL_VALIDATE = 'emailValidate';
export const API_VERIFY_EMAIL = 'verifyEmail';
export const API_MULTILINEFMIP = 'multiLineFMIP';
export const API_GET_LOV_DETAILS = 'getLovDetails';
export const API_GET_ACC_ADDRESS_VALIDATION = 'getAccAddressValidation';
export const API_GET_5GAPPOINTMENTS = 'get5GAppointments';
export const API_SAVE_5GAPPOINTMENT = 'save5GAppointment';
export const API_INSPICIO_RECEIVE_MESSAGE = 'receiveMessage';
export const API_UPDATE_AFFIRM_PAYMENT = 'updateAffirmPayment';
export const API_GIFT_PURCHASE = 'enrollGiftPurchase';
export const API_GET_STORE_INFORMATION = 'getStoreInformation';
export const API_GET_STORE_INFO = 'getStoreInfo';
export const API_GET_ACCOUNT_ADDRESSES = 'getAccountAddresses';
export const API_VALIDATE_CART_AND_CHECKOUT = 'getValidateCartAndCheckout';
export const API_TYPE_AHEAD = 'typeahead';
export const API_GET_SMS_CONSENT = 'getSMSConsent';
export const API_EMAIL_RECEIPT = 'emailReceipt';
export const API_LP_RETRIEVE_COMPLETE_ORDER_DETAILS = 'lpRetrieveCompleteOrderDetails';
export const API_READ_ORDER = 'readOrder';
export const API_GET_STORE_TRADE_INFORMATION = 'getStoreTradeInformation';

export const TAG_RETRIEVE_REMARKS = 'tag_retrieveRemarks';
export const API_RETRIEVE_REMARKS = 'retrieveRemarks';
export const { useLazyRetrieveRemarksQuery } = injectAPI(API_RETRIEVE_REMARKS, TAG_RETRIEVE_REMARKS, retrieveRemarks);

export const TAG_RESUBMIT_ACTIVATIONS = 'tag_resubmitActivationApi';
export const API_RESUBMIT_ACTIVATIONS = 'resubmitActivationApi';

export const { useLazyResubmitActivationApiQuery } = injectAPI(
  API_RESUBMIT_ACTIVATIONS,
  TAG_RESUBMIT_ACTIVATIONS,
  resubmitActivationApi,
);

export const TAG_OC_ACTIVATIONS = 'tag_ocActivation';
export const API_OC_ACTIVATIONS = 'ocActivation';
export const { useLazyOcActivationQuery } = injectAPI(API_OC_ACTIVATIONS, TAG_OC_ACTIVATIONS, ocActivation);
export const API_FETCH_UNIFIED_NBS_DATA = 'fetchUnifiedNbsData';
export const API_FETCH_NBE_DATA = 'nextbillestimate';

export const { useLazyGetAccountAddressesQuery } = injectAPI(
  API_GET_ACCOUNT_ADDRESSES,
  TAG_GET_ACCOUNT_ADDRESSES,
  getAccountAddresses,
);

export const { useLazyReceiveMessageQuery } = injectAPI(
  API_INSPICIO_RECEIVE_MESSAGE,
  TAG_ISNPICIO_RECEIVE_MESSAGE,
  receiveMessage,
);

export const { useLazyUpdateAffirmPaymentQuery } = injectAPI(
  API_UPDATE_AFFIRM_PAYMENT,
  TAG_UPDATE_AFFIRM_PAYMENT,
  updateAffirmPayment,
);

// Hooks
export const { useLazyComputeDPPricesQuery } = injectAPI(API_COMPUTEDPPRICES, TAG_COMPUTEDPPRICES, computeDPPrices);

export const { useLazyUpdateDownpaymentQuery } = injectAPI(API_ADDDPPRICES, TAG_ADDDPPRICES, addDownPayment);

export const { useLazyPostLineChargesQuery } = injectAPI(API_LINE_CHARGES, TAG_MY_LINE_CHARGES, lineCharges);
export const { useLazyEnrollGiftPurchaseQuery } = injectAPI(API_GIFT_PURCHASE, TAG_GIFT_PURCHASE, giftPurchase);
export const { useLazyGenerateInspicioIdQuery } = injectAPI(
  API_GENERATE_INSPICIO_ID,
  TAG_GENERATE_INSPICIO_ID,
  url_local.generateInspicioId,
);

export const { useLazySendMessageQuery } = injectAPI(API_SEND_MESSAGE, TAG_SEND_MESSAGE, url_local.sendMessage);

export const { useLazySendLovLinkQuery } = injectAPI(API_SEND_LOV_LINK, TAG_SEND_LOV_LINK, url_local.sendLovLink);

export const { useLazySendEmailQuery } = injectAPI(API_SEND_EMAIL, TAG_SEND_EMAIL, url_local.sendEmail);

export const { useLazyGeneratePaxQRCodeQuery } = injectAPI(
  API_GENERATE_PAX_QR_CODE,
  TAG_GENERATE_PAX_QR_CODE,
  url_local.generatePaxQRCode,
);
export const { useGetPricingSnapshotQuery } = injectAPI(
  API_PRICINGSNAPSHOT_PROFILE,
  TAG_FETCH_PRICING_SNAPSHOT,
  fetchPricingSnapshot,
);
export const { useLazyGetReferencesQuery } = injectAPI(API_PLAN_REFERENCES, TAG_GET_REFERENCES, getReferences);
export const { useLazyGetDeviceDetailsQuery } = injectAPI(
  API_BROWSESERVICE_DEVICE_DETAILS,
  TAG_BROWSESERVICE_DEVICE_DETAILS,
  getDetails,
);
export const { useLazyValidateAddressQuery } = injectAPI(API_VALIDATE_ADDRESS, TAG_VALIDATE_ADDRESS, validateAddress);
export const { useLazyUpdateShippingAddressAndOptionsQuery } = injectAPI(
  API_UPDATE_SHIPPINGADDRESS,
  TAG_UPDATE_SHIPPINGADDRESS,
  updateShippingAddressAndOptions
);
export const { useLazyUpdateShippingAddressQAQuery } = injectAPI(
  API_UPDATE_SHIPPINGADDRESS_QA,
  TAG_UPDATE_SHIPPINGADDRESS_QA,
  updateShippingAddressQA
);
export const { useShippingOptionsQuery } = injectAPI(API_SHIPPING_OPTIONS, TAG_SHIPPING_OPTIONS, shippingOptions);

export const { useLazyCheckInStoreAvailabilityQuery } = injectAPI(
  API_CHECK_IN_STORE_AVAILABLITY,
  TAG_CHECK_IN_STORE_AVAILABLITY,
  checkInStoreAvailability,
);

export const { useLazyUpdateShippingOptionsQuery } = injectAPI(
  API_UPDATE_SHIPPING_OPTIONS,
  TAG_UPDATE_SHIPPING_OPTIONS,
  updateShippingOptions,
);

export const { useLazyGetClickToCallDetailsQuery } = injectAPI(
  API_CLICKTOCALL_DETAILS,
  TAG_CLICKTOCALL_DETAILS,
  url_local.getClickToCallDetails,
);
export const { useLazyInitiateClickToCallQuery } = injectAPI(
  API_INITIATE_CLICKTOCALL,
  TAG_INITIATE_CLICKTOCALL,
  url_local.initiateClickToCall,
);
export const { useLazyGetManualDiscountQuery } = injectAPI(API_MANUAL_DISCOUNT, TAG_MANUAL_DISCOUNT, manualDiscount);

export const { useLazyUpdateManualDiscountQuery } = injectAPI(
  API_UPDATE_MANUAL_DISCOUNT,
  TAG_UPDATE_MANUAL_DISCOUNT,
  updateManualDiscount,
);
export const { useLazyUpdateBarcodeQuery } = injectAPI(API_UPDATE_BARCODE, TAG_UPDATE_BARCODE, updateBarcode);
export const { useLazyUpdateTradeinQuery } = injectAPI(API_UPDATE_TRADEIN, TAG_UPDATE_TRADEIN, updateTradein);

export const { useUpdateTradeInMutation } = injectAPI(
  API_UPDATE_TRADEIN_MUTATION,
  TAG_UPDATE_TRADEIN,
  UPDATE_TRADEIN_URL,
  POST,
  MUTATION,
  [TAG_RETRIVE_CART, TAG_FETCH_PRICING_SNAPSHOT],
);

export const { useLazyUpdateAccountDevicesQuery } = injectAPI(
  API_UPDATE_AccountDevices,
  TAG_UPDATE_AccountDevices,
  updateAccountDevices,
);
export const { useLazyEmailValidateQuery } = injectAPI(API_EMAIL_VALIDATE, TAG_EMAIL_VALIDATE, emailValidate);
export const { useLazyVerifyEmailQuery } = injectAPI(API_VERIFY_EMAIL, TAG_VERIFY_EMAIL, verifyEmail);
export const { useLazyMultiLineFMIPQuery } = injectAPI(API_MULTILINEFMIP, TAG_MULTILINEFMIP, multiLineFMIP);
export const { useLazyGetLovDetailsQuery } = injectAPI(API_GET_LOV_DETAILS, TAG_GET_LOV_DETAILS, getLovDetails);
export const { useLazyGetAccAddressValidationQuery } = injectAPI(
  API_GET_ACC_ADDRESS_VALIDATION,
  TAG_GET_ACC_ADDRESS_VALIDATION,
  getAccAddressValidation,
);
export const { useLazyGet5GAppointmentsQuery } = injectAPI(
  API_GET_5GAPPOINTMENTS,
  TAG_GET_5GAppointments,
  get5GAppointments,
);
export const { useLazySave5GAppointmentQuery } = injectAPI(
  API_SAVE_5GAPPOINTMENT,
  TAG_SAVE_5GAppointment,
  save5GAppointment,
);
export const { useLazyGetStoreInformationQuery } = injectAPI(
  API_GET_STORE_INFORMATION,
  TAG_GET_STORE_INFORMATION,
  getStoreInformation,
);

export const { useLazyGetStoreInfoQuery } = injectAPI(
  API_GET_STORE_INFO,
  TAG_GET_STORE_INFO,
  getStoreInfo,
);

export const { useLazyGetValidateCartAndCheckoutQuery } = injectAPI(
  API_VALIDATE_CART_AND_CHECKOUT,
  TAG_VALIDATE_CART_AND_CHECKOUT,
  validateCartAndCheckout,
);

export const { useLazyTypeaheadQuery } = injectAPI(API_TYPE_AHEAD, TAG_TYPE_AHEAD, getTypeAhead);
export const { useLazyGetSMSConsentQuery } = injectAPI(API_GET_SMS_CONSENT, TAG_GET_SMS_CONSENT, getSMSConsent);

export const { useLazyLpRetrieveCompleteOrderDetailsQuery } = injectAPI(
  API_LP_RETRIEVE_COMPLETE_ORDER_DETAILS,
  TAG_LP_RETRIEVE_COMPLETE_ORDER_DETAILS,
  lpRetrieveCompleteOrderDetails,
);

export const { useLazyReadOrderQuery } = injectAPI(API_READ_ORDER, TAG_READ_ORDER, readOrder);
export const { useFetchUnifiedNbsDataQuery } = injectAPI(
  API_FETCH_UNIFIED_NBS_DATA,
  TAG_FETCH_UNIFIED_NBS_DATA,
  fetchUnifiedNbsData,
);

export const { useLazyNextbillestimateQuery } = injectAPI(
  API_FETCH_NBE_DATA,
  TAG_FETCH_NBE_DATA,
  nextbillestimate,
  POST,
  'query',
  [],
  60,
  false,
  { isUnfiedNBS: true },
);

export const { useLazyGetStoreTradeInformationQuery } = injectAPI(
  API_GET_STORE_TRADE_INFORMATION,
  TAG_GET_STORE_TRADE_INFORMATION,
  getStoreTradeInformation,
);
