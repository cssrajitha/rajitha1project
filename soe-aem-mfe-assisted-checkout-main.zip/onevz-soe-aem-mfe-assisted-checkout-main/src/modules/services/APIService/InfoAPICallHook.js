import {
  useLazySaveUserInfoQuery,
  useLazyGetCartDetailsQuery,
  useLazyFetchPricingSnapQuery,
  useLazyGetAllActiveMtnQuery,
  useLazyUpdateVisionRemarkQuery,
  useLazyReadOrderRetrieveInstallmentAgreementQuery,
  useLazyViewOrPrintEdgeUpReturnLabelQuery,
  useLazyReadOrderDocumentsInfoQuery,
} from './APIServiceCallHook';

const InfoApiCallHook = () => {
  const [submitUserInfo, submitUserInforSuccess] = useLazySaveUserInfoQuery();
  const [getCartRequest, getCartResponse] = useLazyGetCartDetailsQuery();
  const [fetchPricingSnapRequest, fetchPricingSnapResponse] = useLazyFetchPricingSnapQuery();
  const [getActiveMTNRequest, getActiveMTNResponse] = useLazyGetAllActiveMtnQuery();
  const [updateVisionRemark, getUpdateVisionRemarkResponse] = useLazyUpdateVisionRemarkQuery();
  const [readOrderDPReceiptApi, getreadOrderDPReceiptApiResponse] = useLazyReadOrderRetrieveInstallmentAgreementQuery();
  const [viewOrPrintEdgeUpReturnLabel, getViewOrPrintEdgeUpReturnLabelRes] = useLazyViewOrPrintEdgeUpReturnLabelQuery();
  const [readOrderDocInfo, readOrderDocInfoRes] = useLazyReadOrderDocumentsInfoQuery();
  return {
    submitUserInfo,
    submitUserInforSuccess,
    getCartRequest,
    getCartResponse,
    fetchPricingSnapRequest,
    fetchPricingSnapResponse,
    getActiveMTNRequest,
    getActiveMTNResponse,
    updateVisionRemark,
    getUpdateVisionRemarkResponse,
    readOrderDPReceiptApi,
    getreadOrderDPReceiptApiResponse,
    viewOrPrintEdgeUpReturnLabel,
    getViewOrPrintEdgeUpReturnLabelRes,
    readOrderDocInfo,
    readOrderDocInfoRes,
  };
};

export default InfoApiCallHook;
