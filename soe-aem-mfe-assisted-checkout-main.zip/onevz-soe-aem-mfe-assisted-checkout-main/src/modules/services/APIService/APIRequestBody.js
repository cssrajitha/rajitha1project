const scmCheckoutMfeEnabled = window?.mfe?.scmCheckoutMfeEnabled || '';

export const initialRequestAddDevice = {
  cartInfo: {
    correlationId: '',
    processStep: '',
    processingMTN: '',
    processAction: '',
    intendType: '',
    number_share_capable: '',
    creditAppNum: null,
    isQuoteCart: false,
    enableDefaultedShipToHome: true,
    bogoEnabled: 'True',
  },
  data: {
    lines: [
      {
        mtn: '',
        lineDeviceDollar: 0,
        upgradeReasonCode: '',
        device: {
          category: '',
          deviceId: '',
          id: '',
          sorType: '',
          contractTerm: '',
          dppMonths: 0,
          isCustomerProvidedEquipment: false,
        },
        sim: {
          id: '',
          iccid: '',
          isCustomerProvidedSIM: false,
        },
        addFeatures: [
          {
            id: '',
            quantity: 0,
            actionIndicator: '',
            type: '',
          },
        ],
        downPayment: {
          amount: 0,
        },
        isKeepingExistingEqProtection: false,
        ispuFlow: false,
        newLineOrAAL: false,
        isNewLine: false,
        depletionLocationCode: '',
        depletionType: '',
        sddZipCode: '',
        preBackOrderDate: '',
        triggerPricingValidation: false,
      },
    ],
    selectedMtn: '',
    totalDeviceDollar: null,
    enableAssistedTagging: true,
  },
};

export const requestBodyProductList = {
  data: {
    correlationId: '',
    market: '',
    custType: '',
    siteId: '',
    masterAgentCode: '',
    locationCode: '',
    productType: 'device',
    intentType: 'NSE',
    zipCode: '',
    customerLoggedInOrNot: false,
    compatibleProductId: '',
    prepayCart: false,
    orderType: 'PS',
    filterSortData: {
      sortOption: '',
      paymentOption: '',
      filters: [
        {
          type: '',
          values: [''],
        },
        {
          type: '',
          values: [''],
        },
        {
          type: '',
          values: [''],
        },
        {},
      ],
    },
    paginationData: {
      offset: 0,
      recPerPage: 24,
    },
    enableGridwallPersonalization: false,
    enableAssistedTagging: true,
  },
};

export const requestBodyRetriveCart = {
  meta: {
    client: 'CXP',
  },
  data: {
    cartId: scmCheckoutMfeEnabled ? sessionStorage.getItem('acssMfeCartId') : '',
    retrieveCurrentFeatures: true,
  },
};

export const requestBodyCustomerProfile = {
  enableAssistedTagging: true,
};

export const requestBodyFetchPricingSnapshot = {
  cartId: scmCheckoutMfeEnabled ? sessionStorage.getItem('acssMfeCartId') : '',
  requestSource: 'ORDER_REVIEW',
};

export const requestBodyUserInfo = {
  cartId: '',
  intendType: 'EUP',
  lines: [
    {
      mtn: '',
      email: '',
    },
  ],
};

export const requestBodyRetrieveCart = {
  meta: {},
  data: {
    cartId: scmCheckoutMfeEnabled ? sessionStorage.getItem('acssMfeCartId') : '',
    retrieveCurrentFeatures: true,
  },
};

export const requestBodyPricingSnap = {
  cartId: scmCheckoutMfeEnabled ? sessionStorage.getItem('acssMfeCartId') : '',
  requestSource: 'ORDER_REVIEW',
};

export const requestBodyAllActiveMTN = {
  accountNumber: '',
};

export const requestBodyOrderReview = {
  depletionType: '',
  customerId: '',
  ispuItem: '',
  purchaseWithTradeIn: false,
};

export const requestBodyGetDetails = {
  data: {
    productId: '',
    productType: 'Device',
  },
};

export const requestGetNextBillSummaryBody = {
  cartId: '',
  locationCode: '',
  count: 0,
  zeroChargeFeatureOnly: false,
  isStandaloneUpgradeDevice: false,
};

export const initialRequestBodyDeviceDetails = {
  data: {
    productId: '',
    seoUrlName: '',
    correlationId: '',
    market: '',
    siteId: '',
    masterAgentCode: '',
    productType: 'device',
    mtnList: {
      eup: [],
      aal: [],
    },
    bogoEnabled: 'False',
    defaultSku: '',
    skuSearch: false,
    processingMTN: '',
    zipCode: '',
    enableAssistedTagging: true,
  },
};

export const requestGetManualDiscountBody = {
  data: {
    cartId: 'c2294f0f-51e1-4e07-8a8a-d4fe0f008fb6',
    locationCode: '0026301',
  },
};

export const requestBodyConfirmationPageAssisted = (cartid) => ({
  meta: {
    function: 'orderconfirmpageflags',
    cartid,
    managerApprovalRequired: false,
  },
});
