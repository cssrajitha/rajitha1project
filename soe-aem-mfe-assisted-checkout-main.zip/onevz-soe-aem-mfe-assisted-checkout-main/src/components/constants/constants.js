export const DARK_THEME_BGCOLOR = '#000000';
export const DARK_THEME_COLOR = '#ffffff';
export const ADDINFO_LIGHT_COLOR = '#747676';
export const bgColor = () => window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.themeProps?.background;
export const isDark = () => window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;
export const DARK_SURFACE = 'dark';
export const themeSurface = () => (isDark() ? 'dark' : 'light');
export const themeTextColor = () => (isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR);
export const themeBgColor = () => (isDark() ? DARK_THEME_BGCOLOR : DARK_THEME_COLOR);
export const themeTableHeaderBgColor = () => (isDark() ? DARK_THEME_BGCOLOR : 'rgb(246, 246, 246)');
export const themeIconColor = () => (isDark() ? '#fff' : '#000');
export const activationStyleYellow = {
  color: 'orange',
  'font-size': '15px',
  'vertical-align': 'text-bottom',
  'border-bottom-style': 'none',
  'border-bottom-color': 'none',
};
export const activationStyleGreen = {
  color: '#959595',
  'white-space': 'break-spaces',
  'font-size': '15px',
  'padding-left': '0.4375rem',
  'padding-top': '0.21875rem',
  'border-bottom-style': 'none',
  'border-bottom-color': 'none',
  'vertical-align': 'text-bottom',
};
