import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../modules/store';
import TypeAheadBox from './TypeAheadBox';

const mockedAddData = [
  {
    zip: '96266',
    locusID: '400001104568',
    baseAddID: 'B',
    disprawstr: '3 PSC 3 BOX 3, APO, AP, 96266, USA',
    dispstr: '3 PSC 3 BOX 3',
    muni: 'APO',
    houseNumber: '3',
    state: 'AP',
    locusLocation: '37.7749,-122.4194',
  },
  {
    zip: '54762',
    locusID: '400343642669',
    baseAddID: 'B',
    disprawstr: '3 3 2 3/4 AVE, PRAIRIE FARM, WI, 54762, USA',
    dispstr: '3 3 2 3/4 AVE',
    muni: 'PRAIRIE FARM',
    houseNumber: '3',
    state: 'WI',
    locusLocation: '45.2521,-91.9972',
  },
];

describe('TypeAheadBox component', () => {
  beforeEach(() => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <TypeAheadBox collapseAddress AddressData={mockedAddData} handleAddressSelction={jest.fn} />
        </StoreProvider>
      </BrowserRouter>
    );
  });

  test('TypeAheadBox', async () => {
    await waitFor(() => {
      const titleElement = screen.getByTestId('dropdown');
      expect(titleElement).toBeInTheDocument();

      const addElement = screen.getByText('3 PSC 3 BOX 3, APO, AP, 96266, USA');
      fireEvent.click(addElement);
    });
  });
});
