import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../modules/store';
import TaxChanges from './TaxChanges';

describe('Shippingdetails page Header - scmUpgradeMfeEnable flow', () => {
  beforeAll(() => {
    window.mfe = { scmUpgradeMfeEnable: true };
  });
  beforeEach(() => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <TaxChanges totalTaxAmount={12.34} />
        </StoreProvider>
      </BrowserRouter>
    );
  });

  test('renders tax changes', async () => {
    await waitFor(() => {
      const titleElement = screen.getByTestId('tax-changes');
      expect(titleElement).toBeInTheDocument();
    });
  });

  test('close click tax changes', async () => {
    await waitFor(() => {
      const close = screen.getByTestId('close-link');
      fireEvent.click(close);
    });
  });

  test('tax changes continue click', async () => {
    await waitFor(() => {
      const continueBtn = screen.getByText('Continue');
      fireEvent.click(continueBtn);
    });
  });
});

describe('Shippingdetails page Header - isQAFlow', () => {
  beforeAll(() => {
    window.mfe = { scmUpgradeMfeEnable: false };
  });
  beforeEach(() => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ quickAccessoryCheckoutTaggingFFlag: 'TRUE' }));
    render(
      <BrowserRouter>
        <StoreProvider>
          <TaxChanges totalTaxAmount={12.34} isQAFlow />
        </StoreProvider>
      </BrowserRouter>
    );
  });

  test('close click tax changes', async () => {
    await waitFor(() => {
      const close = screen.getByTestId('close-link');
      fireEvent.click(close);
    });
  });
});

describe('Shippingdetails page Header - regular flow', () => {
  beforeAll(() => {
    window.mfe = { scmUpgradeMfeEnable: false };
  });
  beforeEach(() => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <TaxChanges totalTaxAmount={12.34} />
        </StoreProvider>
      </BrowserRouter>
    );
  });

  test('close click tax changes', async () => {
    await waitFor(() => {
      const close = screen.getByTestId('close-link');
      fireEvent.click(close);
    });
  });
});
