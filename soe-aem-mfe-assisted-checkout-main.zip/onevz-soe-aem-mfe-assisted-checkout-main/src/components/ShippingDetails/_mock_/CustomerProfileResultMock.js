export const customerTypeisNotNData = {
  data: {
    meta: {
      timestamp: '1691504419623',
      cxpCorrelationId:
        '2023-08-08T14:20:19.+0000:c315e0f6ac105644:cxp-customerprofile-services-84447687bc-8h799:nssit1',
    },
    data: {
      customer: {
        caseId: 'SOP-16631496-E01',
        cartId: 'cce6a277-b5b2-4ce0-bc89-8b0e2ae95cf2',
        lookupMtn: '4782303946',
        customerAttributes: {
          hasEcpd: false,
          autoPayDiscountEligibleCustomerType: true,
          customerType: 'PE',
          associationIdNo: null,
        },
      },
    },
  },
};

export const customerTypeisNData = {
  data: {
    meta: {
      timestamp: '1691504419623',
      cxpCorrelationId:
        '2023-08-08T14:20:19.+0000:c315e0f6ac105644:cxp-customerprofile-services-84447687bc-8h799:nssit1',
    },
    data: {
      customer: {
        caseId: 'SOP-16631496-E01',
        cartId: 'cce6a277-b5b2-4ce0-bc89-8b0e2ae95cf2',
        lookupMtn: '4782303946',
        customerAttributes: {
          hasEcpd: false,
          autoPayDiscountEligibleCustomerType: true,
          customerType: 'N',
          associationIdNo: null,
        },
      },
    },
  },
};
