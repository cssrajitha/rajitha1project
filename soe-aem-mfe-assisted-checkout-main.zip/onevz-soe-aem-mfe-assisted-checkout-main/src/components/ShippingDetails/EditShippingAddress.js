import { Button } from '@vds/buttons';
import { Checkbox } from '@vds/checkboxes';
import { Notification } from '@vds/notifications';
import { RadioButtonGroup } from '@vds/radio-buttons';
import { DropdownSelect as Dropdown } from '@vds/selects';
import { Body } from '@vds/typography';
import PropTypes from 'prop-types';
import { isEmpty } from 'lodash';
import { useEffect, useState } from 'react';
import Emitter from 'onevzsoemfeframework/Emitter';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR } from '../constants/constants';
import { requestBodyRetriveCart } from '../../modules/services/APIService/APIRequestBody';
import { useLazyGetCartDetailsQuery } from '../../modules/services/APIService/APIServiceCallHook';
import {
  useLazyGetAccountAddressesQuery,
  useLazyGetValidateCartAndCheckoutQuery,
  useLazyTypeaheadQuery,
  useLazyUpdateShippingAddressAndOptionsQuery,
  useLazyUpdateShippingAddressQAQuery,
  useLazyUpdateShippingOptionsQuery,
  useLazyValidateAddressQuery,
} from '../../modules/services/APIService/APIServiceHooks';
import FormContainerComponent from './FormContainerComponent';
import {
  addressChangeWarningText,
  checkError,
  handleTypeAhead,
  isNSEQAFlow,
  shippingAddressOptions,
  validateInputChanges,
} from './FormUtils';
import MultipleShippingModal from './MultipleShippingModal';
import TaxChanges from './TaxChanges';
import { isSplitFulfillmentEnabled, dFillItemPresent } from '../../utils/orderreviewUtil';

const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable;
const CenterSpan = styled.span`
  text-align: center;
`;

const Container = styled.div`
  display: flex;
  gap: 20px;
  flex-direction: column;
`;

const AddressTypeContainer = styled.div`
  & > div {
    display: flex !important;
    flex-direction: row !important;
    align-items: baseline !important;
    justify-content: flex-start !important;
    gap: 50px;
  }
`;

const MarginAuto = styled.div`
  margin: auto;
`;

const AppMessageContainer = styled.div`
  position: fixed;
  top: 0px;
  height: 50px;
  z-index: 1;
  color: white;
  display: flex;
  width: 80%;
`;

const DialogContainer = styled.div`
  position: fixed;
  top: 50%;
  left: 50%;
  width: 30%;
  height: 15%;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: ${(props) => (props.isDark ? DARK_THEME_BGCOLOR : 'white')};
  transform: translate(-50%, -50%);
  padding: 15px;
  z-index: 99;
  box-shadow: 0px 0px 1px 0px;
`;

const DialogBody = styled.div`
  display: grid;
  grid-template-rows: 1fr 1fr;
  gap: 10px;
`;

const FooterContainer = styled.div`
  border-top: 1px solid rgb(216, 218, 218);
  text-align: center;
  bottom: 0px;
  width: 64rem;
  z-index: 999;
  background-color: ${(props) => (props.isDark ? DARK_THEME_BGCOLOR : 'rgb(255, 255, 255)')};
  position: fixed;
  display: flex;
  padding: 10px;
`;

const ShipMultipleText = styled.div`
  font-weight: bold !important;
  font-family: BrandFontBold, Sans-serif !important;
  text-decoration: underline;
  cursor: pointer;
  color: #007aff;
`;

const DropdownContainer = styled.div`
  [class^='StyledTypography-VDS'] {
    font-weight: bold;
  }
`;

const CheckoutContainer = styled.div`
  [class^='ChildWrapper-VDS'] {
    font-size: 12px;
  }
`;

const addressTypes = [
  {
    name: 'Residential Address',
    children: 'Residential Address',
    value: 'residentialAddress',
    ariaLabel: 'Residential',
  },
  {
    name: 'Business Address',
    children: 'Business Address',
    value: 'businessAddress',
    ariaLabel: 'Business',
  },
];

const messageText = 'Send text messages for order confirmation and shipping notifications';

const unSelectMDNText = 'Unselecting the MDN will disable Inspicio mode for SMS';

const fiveGAddressChangeWarningText =
  'Change in shipping address will need additional validation before order can be processed. VZW may contact the number provided in the credit application if additional information is required. If ship to address differs from service address, remind the customer that Home Internet equipment is authorized for use at the qualified service address only.';

const activityTypes = [
  'EUP',
  'AAL',
  'AAL_LTE',
  'BYOD',
  'ACC',
  'EUPBYOD',
  'NSE',
  'NSE_LTE',
  'NSE_5G',
  'AAL_5G',
  'NSEBYOD',
  'AALBYOD',
  'FEA',
  'DEO',
  'NSEACC',
];

const EditShippinAddress = ({
  customerProfile,
  orderDetails,
  lineDetails,
  cartHeader,
  selectedShippingOption,
  mtnList,
  CustomerProfileResult,
  getShippingOptionsOfAllLines,
  CartDetailsResult,
  isFromRefundOrderView = false,
  isQAFlow = false,
  setShippingOptionsForQA,
  isDark = false,
}) => {
  const [getUniqueAddresses, getUniqueAddressesResult] = useLazyGetAccountAddressesQuery();
  const splitFulfillmentFlag = isSplitFulfillmentEnabled(CartDetailsResult?.orderDetails?.itemLevelShipment) || false;
  const [newCustAddr, setNewCustAddr] = useState({});
  const cartId = cartHeader?.cartId || sessionStorage.getItem('cartId') || '';
  const isNSEQA = isNSEQAFlow(isQAFlow, CartDetailsResult);
  const defaultMtn = '9999999999';

  useEffect(() => {
    if (CustomerProfileResult?.data && CartDetailsResult?.orderDetails?.customerType === 'N') {
      getUniqueAddresses({
        body: { cartId: CustomerProfileResult?.data?.data?.customer?.cartId },
        spinner: true,
        mock: false,
      });
    }
  }, [CustomerProfileResult?.data, CartDetailsResult]);

  useEffect(() => {
    if (getUniqueAddressesResult?.data) {
      setNewCustAddr(getUniqueAddressesResult?.data);
    }
  }, [getUniqueAddressesResult.status]);

  const billAccountInfo = customerProfile?.billAccounts?.[0];
  const existingAddress =
    CartDetailsResult?.orderDetails?.customerType === 'N' ||
    (scmUpgradeMfeEnable && CartDetailsResult?.orderDetails?.customerType === 'U')
      ? newCustAddr?.addressDetails?.[0]
      : billAccountInfo?.accountAddress;
  const addressInfo =
    isQAFlow || scmUpgradeMfeEnable
      ? CartDetailsResult?.lineDetails?.lineInfo?.[0]?.itemsInfo?.[0]?.shipping?.address
      : existingAddress;
  const skipAddressValidation = 'N'; // Can be updated in Invalid address scenario implementation.
  const notifyChannl = orderDetails?.spocs?.notificationOptions;
  const itemsData = lineDetails?.lineInfo?.[0]?.itemsInfo?.[0];
  const shippInfo = itemsData?.shipping;
  const prevTotalShippingCost = sessionStorage.getItem('prevTotalShippingCost');
  const [taxAmount, setTaxAmount] = useState('');
  const accountData = billAccountInfo?.accountAddress;

  const [selectedMtn, setSelectedMtn] = useState('');
  const [sendTextMessageCheck, setSendTextMessageCheck] = useState(true);
  const [unSelectClick, setUnSelectClick] = useState(true);

  const [validateAddressBody] = useLazyValidateAddressQuery();
  const [updateShippingOptionBody, updateShippingOptionResult] = useLazyUpdateShippingAddressAndOptionsQuery();
  const [updateShippingAddressQABody] = useLazyUpdateShippingAddressQAQuery();
  const [updateShippingOptionsBody, updateShippingOptionsResult] = useLazyUpdateShippingOptionsQuery();
  const [getValidateCartAndCheckoutBody, getValidateCartAndCheckoutResult] = useLazyGetValidateCartAndCheckoutQuery();
  const [getCartDetailsDataBody, getCartDetailsResults] = useLazyGetCartDetailsQuery();

  const [showAddressChangeWarning, setShowAddressChangeWarning] = useState(false);
  const [addressChangeText, setAddressChangeText] = useState('');

  const [shippingOptionsFormData, setShippingOptionsFormData] = useState({});

  const [isIndirectChannel, setIsIndirectChannel] = useState(false);
  const [isSDDSelected, setIsSDDSelected] = useState(false);
  const [hasMultipleDfillOrders, setHasMultipleDfillOrders] = useState(false);
  const [showShipToMultipleModal, setShowShipToMultipleModal] = useState(false);

  const [getAddressTypehead, GetAddressTypeheadResult] = useLazyTypeaheadQuery();
  const [cityStateList, setCityStateList] = useState([]);
  const [collapseAddress, setCollapseAddress] = useState(false);
  const [timer, setTimer] = useState();
  const [keepCurrAdd, setKeepCurrAdd] = useState(false);

  useEffect(() => {
    const nameVal =
      isQAFlow && addressInfo?.firstName
        ? `${addressInfo?.firstName} ${addressInfo?.lastName || ''}`
        : itemsData?.attention;
    setShippingOptionsFormData({
      name: nameVal,
      attn: '',
      streetName:
        CartDetailsResult?.orderDetails?.customerType === 'N'
          ? `${addressInfo?.streetNumber ?? ''} ${addressInfo?.streetName ?? ''} ${addressInfo?.addrType ?? ''}`
          : addressInfo?.addressLine1,
      apartmentNo: addressInfo?.apartmentNo || addressInfo?.addressLine2,
      phone:
        CartDetailsResult?.orderDetails?.customerType === 'N'
          ? newCustAddr?.addressDetails?.[0].phoneNumber
          : notifyChannl?.contactPhoneNumber,
      cityState: addressInfo?.city,
      zipCode: addressInfo?.zipCode,
      emailId: notifyChannl?.primaryEmailId,
      state: addressInfo?.state,
    });
    setCityStateList([
      {
        label: addressInfo?.city,
        value: addressInfo?.state,
      },
    ]);
  }, [itemsData, addressInfo, notifyChannl]);

  const [formDataError, setFormDataError] = useState({
    nameError: false,
    attnError: false,
    streetNameError: false,
    apartmentNoError: false,
    phoneError: false,
    cityStateError: false,
    zipCodeError: false,
    emailIdError: false,
  });

  const [selectedCityState, setSelectedCityState] = useState('');
  const [selectedAddressType, setSelectedAddressType] = useState(null);

  useEffect(() => {
    validateAddressBody({
      body: {
        addressLine1: '',
        addressLine2: '',
        city: '',
        state: '',
        zipCode: shippingOptionsFormData?.zipCode,
        type: 'validateAddress',
      },
      mock: false,
    });
  }, [selectedAddressType]);

  useEffect(() => {
    Emitter.emit('PAGE_LOADED', {
      PAGE_LOADED: 'true',
      CUSTOM_EVENT: 'Pageview',
    });
  }, []);

  const onChange = (e, element) => {
    if (!showAddressChangeWarning) setShowAddressChangeWarning(true);
    if (element === 'streetName') {
      handleTypeAhead(e, timer, setTimer, getAddressTypehead, setCollapseAddress);
    }
    validateInputChanges(
      element,
      e,
      formDataError,
      shippingOptionsFormData,
      setShippingOptionsFormData,
      setFormDataError,
      validateAddressBody,
      selectedAddressType,
      isQAFlow,
    );
  };

  const AddressData = GetAddressTypeheadResult?.data?.addresses;

  const handleAddressSelction = (e) => {
    setShippingOptionsFormData({
      ...shippingOptionsFormData,
      streetName: e?.dispstr,
      zipCode: e?.zip,
      cityState: e?.muni,
      state: e?.state,
    });
    setCityStateList([
      {
        label: e?.muni,
        value: e?.state,
      },
    ]);
    setCollapseAddress(false);
  };

  const onCityStateChange = (value) => {
    if (value) setSelectedCityState(value);
  };
  const generatePayload = (fullAccNum, serviceName, intent, intendType, multiLineOptions, multiLineAddress) => ({
    serviceHeader: {
      clientId: 'VZW-NETACE',
      statusMsg: 'PEGA generated message',
      correlationId: '69a66ef4d7e344dfb2db299209ea8333',
      sessionId: '',
      serviceName,
      userId: CustomerProfileResult?.data?.data?.customer?.loggedInUser,
      statusCode: '0',
    },
    serviceOptionBody: {
      serviceRequest: {
        context: {
          caseId: CustomerProfileResult?.data?.data?.customer?.caseId,
          customerInfo: {
            accountNumber: fullAccNum,
            cartCreator: CartDetailsResult?.orderDetails.orderList?.[0]?.creditApplication?.creditApplicationNum,
            processingMTN: selectedMtn || cartHeader?.cartCreator,
            originalCreditApprovalNumber:
              CartDetailsResult?.orderDetails.orderList?.[0]?.creditApplication?.creditApplicationNum,
            customerType: CartDetailsResult?.orderDetails.customerType === 'N' ? 'N' : '',
          },
          cartInfo: {
            cartId,
            action: 'UPDATE',
            itemType: 'SHIPPINGOPTION',
            intendType,
            shipmentInfo: multiLineOptions,
          },
          contextInfo: {
            callReason: 'SalesOrderPurchase',
            intent,
            processStep: 'OrderReview-Shipping',
            processAction: 'updateShippingOptions',
          },
        },
      },
    },
    serviceAddressBody: {
      serviceRequest: {
        context: {
          cartInfo: {
            action: 'UPDATE',
            cartId,
            intendType,
            itemType: 'SHIPPINGADDRESS',
            shipmentAddress: {
              notificationMDN: shippingOptionsFormData.notificationChecked
                ? shippingOptionsFormData.notificationMDN
                : '',
              lines: multiLineAddress,
            },
          },
          caseId: CustomerProfileResult?.data?.data?.customer?.caseId,
          contextInfo: {
            callReason: 'SalesOrderPurchase',
            intent:
              CartDetailsResult?.orderDetails.customerType === 'N' || sessionStorage.getItem('customerType') === 'N'
                ? 'NSE'
                : 'Upgrade',
            processAction: 'updateShippingAddress',
            processStep: 'OrderReview-Shipping',
          },
          customerInfo: {
            accountNumber: fullAccNum || '',
            cartCreator: CartDetailsResult?.orderDetails.orderList?.[0]?.creditApplication?.creditApplicationNum,
            processingMTN: selectedMtn || cartHeader?.cartCreator,
            originalCreditApprovalNumber:
              CartDetailsResult?.orderDetails.orderList?.[0]?.creditApplication?.creditApplicationNum,
            customerType: CartDetailsResult?.orderDetails.customerType === 'N' ? 'N' : '',
          },
        },
      },
    },
  });

  const onSave = async (e) => {
    const msfToNsaQAFFlag =
      /true/i.test(JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.msfToNsaQuickAccessoriesFFlag) || false;
    if (
      msfToNsaQAFFlag &&
      isQAFlow &&
      selectedAddressType === 'businessAddress' &&
      shippingOptionsFormData.attn === ''
    ) {
      return setFormDataError({ ...formDataError, attnError: true });
    }

    const isPrepayCart = sessionStorage.getItem('newPostToPreIndicator')
      ? sessionStorage.getItem('newPostToPreIndicator')
      : false;
    const customerType = sessionStorage.getItem('customerType');
    const isNewCustomer = !!(customerType && customerType === 'N');
    const lineInfo = lineDetails?.lineInfo;
    const is5Gdevice = !!(
      lineInfo &&
      lineInfo.length > 0 &&
      lineInfo.some((item) => item?.deviceTypeSelected === '5G Internet')
    );

    if (showAddressChangeWarning) {
      setAddressChangeText(is5Gdevice ? fiveGAddressChangeWarningText : addressChangeWarningText);
      setShowAddressChangeWarning(false);
    } else {
      e.preventDefault();
      setAddressChangeText('');
      const names = shippingOptionsFormData?.name?.split(' ');

      const zipCode =
        (shippingOptionsFormData.zipCode &&
          shippingOptionsFormData.zipCode.indexOf('-') > -1 &&
          shippingOptionsFormData?.zipCode?.split('-')?.[0]) ||
        shippingOptionsFormData?.zipCode;
      const fullAccNum = cartHeader?.fullAccountNumber?.replace(/(\d{1,5})$/, (_, num) => num.padStart(5, '0'));

      let intendType = '';
      let checkDFillItem = true;
      const multiLineOptions = lineInfo
        ?.map((item) => {
          const renderOptions =
            item?.itemsInfo?.[0]?.cartItems &&
            !isEmpty(item.itemsInfo[0]?.cartItems?.cartItem) &&
            activityTypes.includes(item.lineActivityType);
          intendType = item?.lineActivityType;

          if (splitFulfillmentFlag) {
            checkDFillItem = dFillItemPresent([item]);
          }

          if (renderOptions && checkDFillItem) {
            const itemLevelShipping = splitFulfillmentFlag ? item?.itemsInfo?.[0]?.shipping : {};
            const optionsObj = {
              multiLineSeqNumber: item.multiLineSeqNumber,
              shipping: {
                shippingCode:
                  selectedShippingOption?.shippingOptionId ||
                  shippInfo?.shippingCode ||
                  itemLevelShipping?.shippingCode,
                shippingCost:
                  selectedShippingOption?.shippingCost || shippInfo?.shippingCost || itemLevelShipping?.shippingCost,
                shippingDescription:
                  selectedShippingOption?.shippingDescription ||
                  shippInfo?.shippingDescription ||
                  itemLevelShipping?.shippingDescription,
                depletionLocation: '',
                fipsCode: accountData?.fipsCode,
                deliveryDate: selectedShippingOption?.estimatedDeliveryDate || '',
              },
            };
            if ((isQAFlow || scmUpgradeMfeEnable) && optionsObj?.shipping?.shippingCost === '0.00') {
              optionsObj.shipping.shippingCost = '0.0';
            }
            return optionsObj;
          }
          return null;
        })
        .filter(Boolean)
        .sort((a, b) => a.multiLineSeqNumber - b.multiLineSeqNumber);
      const serviceName = isPrepayCart ? 'SalesOrderFlex' : 'SalesOrderPurchase';
      let intent = 'Upgrade';
      if (isNewCustomer) {
        intent = 'NSE';
      }

      const multiLineAddress = lineInfo
        ?.map((item) => {
          const renderAddress =
            item?.itemsInfo?.[0]?.cartItems &&
            !isEmpty(item.itemsInfo[0]?.cartItems?.cartItem) &&
            activityTypes.includes(item.lineActivityType);

          if (splitFulfillmentFlag) {
            checkDFillItem = dFillItemPresent([item]);
          }

          if (renderAddress && checkDFillItem) {
            const addObj = {
              address: {
                addressLine2: '',
                streetName: shippingOptionsFormData.streetName,
                addressLine1: shippingOptionsFormData.streetName,
                apartmentNo: shippingOptionsFormData.apartmentNo,
                attention: shippingOptionsFormData.attn,
                city: shippingOptionsFormData.cityState,
                countryCode: '',
                emailId: shippingOptionsFormData.emailId,
                fipsCode: accountData?.fipsCode,
                firmName: '',
                name: shippingOptionsFormData.name,
                firstName: names?.[0],
                lastName: names?.[1],
                phoneNumber: shippingOptionsFormData.phone,
                poBoxNo: '',
                ruralDelNo: '',
                ruralRouteNo: '',
                state: shippingOptionsFormData?.state,
                addressType: selectedAddressType === addressTypes?.[1]?.value ? 'B' : 'R',
                zipCode,
                zipCode4: '',
              },
              multiLineSeqNumber: item.multiLineSeqNumber,
              skipAddressValidation,
            };
            return addObj;
          }
          return null;
        })
        .filter(Boolean)
        .sort((a, b) => a.multiLineSeqNumber - b.multiLineSeqNumber);

      const payload = generatePayload(fullAccNum, serviceName, intent, intendType, multiLineOptions, multiLineAddress);

      if (isNSEQA) {
        const qaShippingPayload = payload.serviceAddressBody;
        qaShippingPayload.serviceRequest.context.cartInfo.intendType = 'NSEACC';
        qaShippingPayload.serviceRequest.context.contextInfo.intent = 'NSEACC';
        qaShippingPayload.serviceRequest.context.customerInfo.customerType = 'N';
        qaShippingPayload.serviceRequest.context.customerInfo.cartCreator = defaultMtn;
        qaShippingPayload.serviceRequest.context.customerInfo.originalCreditApprovalNumber = defaultMtn;
        qaShippingPayload.serviceRequest.context.skipCheckoutCall = false;
        qaShippingPayload.serviceRequest.context.cartInfo.cartId =
          cartId || CustomerProfileResult?.data?.data?.customer?.cartId;
        const shippingAddrUpdateRes = await updateShippingAddressQABody({
          body: qaShippingPayload,
          spinner: true,
          mock: false,
        });
        const respShippingOptions = shippingAddrUpdateRes?.data?.data?.lines?.[0]?.shippingOptions;
        const selectedShippingOptionValid = respShippingOptions?.some(
          (item) =>
            item.shippingOptionId ===
            payload.serviceOptionBody.serviceRequest.context.cartInfo.shipmentInfo?.[0]?.shipping.shippingCode,
        );
        if (selectedShippingOptionValid) {
          const shipOptionQAPayload = {
            serviceBody: payload.serviceOptionBody,
            serviceHeader: payload.serviceHeader,
          };
          shipOptionQAPayload.serviceBody.serviceRequest.context.cartInfo.cartId =
            qaShippingPayload.serviceRequest.context.cartInfo.cartId;
          shipOptionQAPayload.serviceBody.serviceRequest.context.cartInfo.intendType = 'NSE';
          shipOptionQAPayload.serviceBody.serviceRequest.context.contextInfo.intent = 'NSE';
          shipOptionQAPayload.serviceBody.serviceRequest.context.customerInfo =
            qaShippingPayload.serviceRequest.context.customerInfo;
          updateShippingOptionsBody({ body: shipOptionQAPayload, spinner: true, mock: false });
        } else {
          setShippingOptionsForQA(respShippingOptions);
        }
      } else {
        updateShippingOptionBody({ body: payload, spinner: true, mock: false });
      }
    }
  };

  useEffect(() => {
    if (updateShippingOptionResult?.isSuccess || getValidateCartAndCheckoutResult?.isSuccess) {
      getCartDetailsDataBody({ body: requestBodyRetriveCart, mock: false });
    }
  }, [updateShippingOptionResult, getValidateCartAndCheckoutResult]);

  useEffect(() => {
    if (updateShippingOptionsResult?.isSuccess && isNSEQA) {
      const vcacRequest = {
        cartInfo: {
          cartId: cartId || CustomerProfileResult?.data?.data?.customer?.cartId,
          cartCreator: '9999999999',
          locationCode: orderDetails?.locationCode,
          intendType: 'NSEACC',
          processStep: 'ShoppingCart',
        },
      };
      getValidateCartAndCheckoutBody({ body: vcacRequest, spinner: true, mock: false });
    }
  }, [updateShippingOptionsResult]);

  let navigate = '';
  function useNavigateMFE() {
    navigate = useNavigate();
  }
  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }

  useEffect(() => {
    if (getCartDetailsResults?.status === 'fulfilled') {
      const currentShippingCost = getCartDetailsResults?.data?.data?.cart?.orderDetails?.totalShippingCost;
      if (scmUpgradeMfeEnable) {
        console.log('UPDATE_SHIPPING_ADDRESS', getCartDetailsResults);
        Emitter?.emit('UPDATE_SHIPPING_ADDRESS', getCartDetailsResults?.data?.data?.cart);
      }

      if (prevTotalShippingCost < currentShippingCost && !showShipToMultipleModal) {
        setTaxAmount(getCartDetailsResults?.data?.data?.cart?.orderDetails?.totalTaxAmount);
        return;
      }
      if (showShipToMultipleModal) setShowShipToMultipleModal(false);
      /* istanbul ignore else */
      if (isQAFlow) {
        navigate(`/sales/assisted/new/qa-order-review.html`);
      } else if (isFromRefundOrderView) {
        const locationCode = orderDetails?.locationCode || '';
        const orderNumber = orderDetails?.orderList?.[0]?.orderNumber || '';
        navigate(
          `/sales/assisted/new/refundexchange/order-review.html?isReadOrder=Y&orderNumber=${orderNumber}&locationCode=${locationCode}`,
        );
      } else if (!scmUpgradeMfeEnable) {
        navigate(`/sales/assisted/new/order-review.html`);
      } else {
        Emitter.emit('CLOSE_SHIPPING_DETAILS_MODAL');
      }
    }
  }, [getCartDetailsResults]);

  useEffect(() => {
    if (CustomerProfileResult?.data) {
      setIsIndirectChannel(CustomerProfileResult?.data?.data?.commonInfo?.isIndirect);
      sessionStorage.setItem('isIndirectChannel', CustomerProfileResult?.data?.data?.commonInfo?.isIndirect);
    }
  }, [CustomerProfileResult]);
  useEffect(() => {
    if (
      selectedShippingOption?.shippingOptionId === 'SDD_SAMEDAY' ||
      selectedShippingOption?.shippingOptionId === 'SDD_SAMEDAY_NVMP'
    ) {
      setIsSDDSelected(true);
    } else {
      setIsSDDSelected(false);
    }
  }, [selectedShippingOption]);
  useEffect(() => {
    const depletionTypes = lineDetails?.lineInfo?.filter((item) => item.itemsInfo[0].depletionType === 'F');
    if (depletionTypes?.length > 1) {
      setHasMultipleDfillOrders(true);
    } else if (splitFulfillmentFlag && sessionStorage.getItem('intentType') === 'AAL') {
      let dFillItems = [];
      let sameLineDFillItems = [];
      lineDetails?.lineInfo?.map((item) => {
        if (dFillItemPresent([item])) {
          sameLineDFillItems = item.itemsInfo?.[0]?.cartItems?.cartItem.filter(
            (dFillItem) =>
              dFillItem.depletionType === 'F' &&
              (dFillItem.cartItemType === 'DEVICE' || dFillItem.cartItemType === 'ACCESSORY'),
          );
          dFillItems = [...dFillItems, ...sameLineDFillItems];
        }
        return dFillItems;
      });
      if (dFillItems?.length > 1) {
        setHasMultipleDfillOrders(true);
      } else {
        setHasMultipleDfillOrders(false);
      }
    } else {
      setHasMultipleDfillOrders(false);
    }
  }, [lineDetails]);

  const handleShowMultipleModal = () => {
    setShowShipToMultipleModal(true);
  };
  const keepCurrentAdd = () => {
    setKeepCurrAdd(!keepCurrAdd)
  };
  const handleSelectedAddressType = (value) => {
    const msfToNsaQAFFlag = /true/i.test(
      JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.msfToNsaQuickAccessoriesFFlag,
    );

    if (msfToNsaQAFFlag && isQAFlow) {
      setSelectedAddressType(value);
      setFormDataError({ ...formDataError, attnError: false });
    } else {
      setSelectedAddressType(value);
    }
  };

  return (
    <>
      <TaxChanges totalTaxAmount={Number(taxAmount).toFixed(2)} isQAFlow={isQAFlow} />
      {addressChangeText && (
        <AppMessageContainer>
          <Notification
            type='warning'
            title={addressChangeText}
            fullBleed={false}
            inline={false}
            disableFocus
            layout='horizontal'
            onCloseButtonClick={() => setAddressChangeText('')}
          />
        </AppMessageContainer>
      )}
      <Container data-testid='editDetails'>
        <AddressTypeContainer>
          <RadioButtonGroup
            data-testid='addressType'
            onChange={(e) => handleSelectedAddressType(e.target.value)}
            error={false}
            data={addressTypes}
            defaultValue={addressTypes?.[0]?.value}
            surface={isDark ? 'dark' : 'light'}
          />
        </AddressTypeContainer>
        <FormContainerComponent
          onCityStateChange={onCityStateChange}
          cityStateList={cityStateList}
          selectedCityState={selectedCityState}
          handleAddressSelction={handleAddressSelction}
          AddressData={AddressData}
          collapseAddress={collapseAddress}
          shippingAddressOptions={shippingAddressOptions}
          formDataError={formDataError}
          shippingOptionsFormData={shippingOptionsFormData}
          onChange={onChange}
          selectedAddressType={selectedAddressType}
          isDark={isDark}
        />
        {CartDetailsResult?.orderDetails?.customerType !== 'N' && !isQAFlow && (
          <Checkbox
            name='term and conditions'
            width='auto'
            label=''
            disabled={false}
            error={false}
            errorText='Please agree to the terms and conditions.'
            selected={sendTextMessageCheck}
            surface={isDark ? 'dark' : 'light'}
            onChange={() => {
              setSendTextMessageCheck((prev) => !prev);
              setUnSelectClick(true);
            }}
          >
            <MarginAuto>
              <Body bold color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>{messageText} </Body>
            </MarginAuto>
          </Checkbox>
        )}
        {sendTextMessageCheck && CartDetailsResult?.orderDetails?.customerType !== 'N' && !isQAFlow && (
          <DropdownContainer>
            <Dropdown
              id='mdnSelect'
              data-testid='mdn-selection'
              value={selectedMtn}
              error={false}
              disabled={false}
              readOnly={false}
              surface={isDark ? 'dark' : 'light'}
              onChange={(e) => setSelectedMtn(e.target.value)}
              label='Select MDN to send text message *'
            >
              {mtnList &&
                mtnList.length > 0 &&
                mtnList.map((mtn) => (
                  <option key={mtn} value={mtn}>
                    {mtn}
                  </option>
                ))}
            </Dropdown>
          </DropdownContainer>
        )}

        <CheckoutContainer>
          <Checkbox
          // keepCurrAdd
            data-track={keepCurrAdd ? "keepCurrentAddress_Selected" : "keepCurrentAddress_notSelected"}
            name='default'
            width='auto'
            disabled={false}
            error={false}
            errorText='Please agree to the terms and conditions.'
            surface={isDark ? 'dark' : 'light'}
            onChange={keepCurrentAdd}
          >
            Keep Current Address
          </Checkbox>
        </CheckoutContainer>
        {!isIndirectChannel && !isSDDSelected && hasMultipleDfillOrders && !splitFulfillmentFlag && (
          <ShipMultipleText onClick={handleShowMultipleModal}>Ship to multiple locations</ShipMultipleText>
        )}
      </Container>
      {!sendTextMessageCheck && unSelectClick && (
        <DialogContainer isDark={isDark}>
          <DialogBody>
            <Body bold color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
              <CenterSpan>{unSelectMDNText}</CenterSpan>
            </Body>
            <MarginAuto>
              <Button data-testid='ok-btn' width={30} surface={isDark ? 'dark' : 'light'} onClick={() => setUnSelectClick(false)}>
                ok
              </Button>
            </MarginAuto>
          </DialogBody>
        </DialogContainer>
      )}
      <FooterContainer isDark={isDark}>
        <MarginAuto>
          <Button disabled={checkError(formDataError) || !shippingOptionsFormData?.zipCode} surface={isDark ? 'dark' : 'light'} onClick={onSave}>
            Save
          </Button>
        </MarginAuto>
      </FooterContainer>
      {lineDetails?.lineInfo && (
        <MultipleShippingModal
          CartDetailsResult={CartDetailsResult}
          showShipToMultipleModal={showShipToMultipleModal}
          setShowShipToMultipleModal={setShowShipToMultipleModal}
          lineItems={lineDetails?.lineInfo}
          getShippingOptionsOfAllLines={getShippingOptionsOfAllLines}
          updateShippingOptionBody={updateShippingOptionBody}
          CustomerProfileResult={CustomerProfileResult}
          isQAFlow={isQAFlow}
        />
      )}
    </>
  );
};
EditShippinAddress.propTypes = {
  mtnList: PropTypes.arrayOf(String),
  selectedShippingOption: PropTypes.string,
  customerProfile: PropTypes.shape({
    billAccounts: PropTypes.arrayOf(
      PropTypes.shape({
        accountAddress: PropTypes.shape({
          addressLine1: PropTypes.string,
          addressLine2: PropTypes.string,
          city: PropTypes.string,
          fipsCode: PropTypes.string,
          state: PropTypes.string,
          zipCode: PropTypes.string,
          zipCodePlus4: PropTypes.string,
        }),
        mtns: PropTypes.arrayOf(
          PropTypes.shape({
            equipmentUpgradeEligibility: PropTypes.shape({
              upgradeEligibilityDate: PropTypes.string,
              upgradeEligible: PropTypes.bool,
            }),
            lineSharingIndicator: PropTypes.string,
            mobileInfoAttributes: PropTypes.shape({
              smartFamilyParent: PropTypes.bool,
            }),
            mtn: PropTypes.string,
            pricePlanInfo: PropTypes.shape({
              planAttributes: PropTypes.shape({
                sharePlan: PropTypes.bool,
              }),
              planId: PropTypes.string,
            }),
          }),
        ),
      }),
    ),
    customerAttributes: PropTypes.shape({
      digitalCustomerType: PropTypes.string,
      taxExemptCode: PropTypes.string,
    }),
  }),
  orderDetails: PropTypes.shape({
    spocs: PropTypes.shape({
      notificationOptions: PropTypes.shape({
        contactPhoneNumber: PropTypes.string,
        primaryEmailId: PropTypes.string,
      }),
    }),
    totalShippingCost: PropTypes.number,
    locationCode: PropTypes.string,
    orderList: PropTypes.arrayOf(
      PropTypes.shape({
        orderNumber: PropTypes.string,
      }),
    ),
  }),
  lineDetails: PropTypes.shape({
    lineInfo: PropTypes.arrayOf(
      PropTypes.shape({
        itemsInfo: PropTypes.arrayOf(
          PropTypes.shape({
            attention: PropTypes.string,
          }),
        ),
      }),
    ),
  }),
  cartHeader: PropTypes.shape({
    cartCreator: PropTypes.string,
    cartCreatorChannelId: PropTypes.string,
    cartCreatorOrderLocationCode: PropTypes.string,
    cartCreatorSalesRepId: PropTypes.string,
    cartId: PropTypes.string,
    caseId: PropTypes.string,
    createTimestamp: PropTypes.string,
    fullAccountNumber: PropTypes.string,
  }),
  CustomerProfileResult: PropTypes.object,
  getShippingOptionsOfAllLines: PropTypes.any,
  CartDetailsResult: PropTypes.object,
  isFromRefundOrderView: PropTypes.bool,
  isQAFlow: PropTypes.bool,
  setShippingOptionsForQA: PropTypes.func,
  isDark: PropTypes.bool,
};
export default EditShippinAddress;
