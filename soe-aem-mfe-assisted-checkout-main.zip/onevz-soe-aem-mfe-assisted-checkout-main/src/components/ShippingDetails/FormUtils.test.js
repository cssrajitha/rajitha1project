import { handleTypeAhead, validateInputChanges } from './FormUtils';

describe('Check utils', () => {
  jest.useFakeTimers();
  const mockSetTimer = jest.fn();
  const mockGetAddressTypehead = jest.fn();
  const mockSetCollapseAddress = jest.fn();
  test('run handleTypeAhead with value', () => {
    handleTypeAhead({ target: { value: 'A' } }, 1000, mockSetTimer, mockGetAddressTypehead, mockSetCollapseAddress);
    jest.advanceTimersByTime(1000);
    expect(mockSetTimer).toHaveBeenCalled();
    expect(mockGetAddressTypehead).toHaveBeenCalled();
    expect(mockSetCollapseAddress).toHaveBeenCalled();
  });

  test('run handleTypeAhead without value', () => {
    handleTypeAhead({ target: { value: '' } }, 1000, mockSetTimer, mockGetAddressTypehead, mockSetCollapseAddress);
    jest.advanceTimersByTime(1000);
    expect(mockSetTimer).not.toHaveBeenCalled();
    expect(mockGetAddressTypehead).not.toHaveBeenCalled();
    expect(mockSetCollapseAddress).toHaveBeenCalled();
  });

  test('run validateInputChanges without value', () => {
    validateInputChanges('', { target: { value: 'A' } }, '', '', jest.fn(), jest.fn(), jest.fn());
  });
});
