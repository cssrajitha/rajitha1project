import { Button } from '@vds/buttons';
import { Checkbox } from '@vds/checkboxes';
import { Notification } from '@vds/notifications';
import { RadioButtonGroup } from '@vds/radio-buttons';
import PropTypes from 'prop-types';
import { useEffect, useState } from 'react';
import styled from 'styled-components';
import AgreementsAPICallHook from '../../modules/services/APIService/AgreementsAPICallHook';
import { useLazyTypeaheadQuery } from '../../modules/services/APIService/APIServiceHooks';
import FormContainerComponent from './FormContainerComponent';
import {
  addressChangeWarningText,
  checkError,
  handleTypeAhead,
  shippingAddressOptions,
  validateInputChanges,
} from './FormUtils';
import { generatePayload } from './MultipleShippingRequest';

const Container = styled.div`
  display: flex;
  gap: 20px;
  flex-direction: column;
`;

const AddressTypeContainer = styled.div`
  & > div {
    display: flex !important;
    flex-direction: row !important;
    align-items: baseline !important;
    justify-content: flex-start !important;
    gap: 50px;
  }
`;

const MarginAuto = styled.div`
  display: flex;
  gap: 10px;
  [class^='StyledChildWrapper-VDS'] {
    margin: 0 10px;
  }
`;

const AppMessageContainer = styled.div`
  position: relative;
  color: white;
  display: flex;
  width: 100%;
`;

const addressTypes = [
  {
    name: 'Change to Residential Address',
    children: 'Change to Residential Address',
    value: 'residentialAddress',
    ariaLabel: 'Residential',
  },
  {
    name: 'Change to Business Address',
    children: 'Change to Business Address',
    value: 'businessAddress',
    ariaLabel: 'Business',
  },
];

const MultipleEditShippinAddress = ({ shippingMethod, cartHeader, setShowChangeAddress, getUniqueAddresses }) => {
  const skipAddressValidation = 'N'; // Can be updated in Invalid address scenario implementation.
  const { validateAddressBody, validateAddressResult, updateShippingOptionBody, updateShippingOptionResult } =
    AgreementsAPICallHook();
  const [showAddressChangeWarning, setShowAddressChangeWarning] = useState(false);
  const [addressChangeText, setAddressChangeText] = useState('');
  const [shippingOptionsFormData, setShippingOptionsFormData] = useState({});
  const [selectedCityState, setSelectedCityState] = useState('');
  const [selectedAddressType, setSelectedAddressType] = useState(null);
  const [cityStateList, setCityStateList] = useState([]);
  const [formDataError, setFormDataError] = useState({
    nameError: false,
    attnError: false,
    streetNameError: false,
    apartmentNoError: false,
    phoneError: false,
    cityStateError: false,
    zipCodeError: false,
    emailIdError: false,
  });

  const [getMultiAddressTypehead, GetMultiAddressTypeheadResult] = useLazyTypeaheadQuery();

  const [collapseTypeAheadAddress, setCollapseTypeAheadAddress] = useState(false);
  const [timer, setTimer] = useState();

  useEffect(() => {
    setSelectedAddressType(addressTypes?.[0]?.value);
    setShippingOptionsFormData({
      name: '',
      attn: '',
      streetName: '',
      apartmentNo: '',
      phone: '',
      cityState: '',
      zipCode: '',
      emailId: '',
      state: '',
    });
    validateAddressBody({
      body: {
        addressLine1: '',
        addressLine2: '',
        city: '',
        state: '',
        zipCode: shippingOptionsFormData?.zipCode,
        type: 'validateAddress',
      },
      spinner: false,
      mock: false,
    });
  }, []);

  useEffect(() => {
    if (validateAddressResult?.data) {
      const cityArray = validateAddressResult?.data?.data?.validateAddress?.cityStatesFound;
      const options = cityArray?.map((item) => ({
        value: item,
        label: item,
      }));
      setCityStateList(options);
      setSelectedCityState(options?.[0]?.value);
      setShippingOptionsFormData({ ...shippingOptionsFormData, cityState: options?.[0]?.value });
    }
  }, [validateAddressResult]);

  const onChange = (e, element) => {
    if (element === 'streetName') {
      handleTypeAhead(e, timer, setTimer, getMultiAddressTypehead, setCollapseTypeAheadAddress);
    }
    if (!showAddressChangeWarning) setShowAddressChangeWarning(true);
    validateInputChanges(
      element,
      e,
      formDataError,
      shippingOptionsFormData,
      setShippingOptionsFormData,
      setFormDataError,
      validateAddressBody
    );
  };

  const MultiAddressData = GetMultiAddressTypeheadResult?.data?.addresses;

  const handleMultiAddressSelction = (e) => {
    setShippingOptionsFormData({
      ...shippingOptionsFormData,
      streetName: e?.dispstr,
      zipCode: e?.zip,
      cityState: e?.muni,
      state: e?.state,
    });
    setCityStateList([
      {
        label: e?.muni,
        value: e?.state,
      },
    ]);
    setCollapseTypeAheadAddress(false);
  };

  const onCityStateChange = (value) => {
    if (value) {
      setSelectedCityState(value);
      setShippingOptionsFormData({ ...shippingOptionsFormData, cityState: value });
    }
  };

  const onAddressTypeChange = (value) => {
    if (value) {
      setSelectedAddressType(value);
      validateAddressBody({
        body: {
          addressLine1: '',
          addressLine2: '',
          city: '',
          state: '',
          zipCode: shippingOptionsFormData?.zipCode,
          type: 'validateAddress',
        },
        spinner: false,
        mock: false,
      });
    }
  };

  const onSave = (e) => {
    if (showAddressChangeWarning) {
      setAddressChangeText(addressChangeWarningText);
      setShowAddressChangeWarning(false);
    } else {
      e.preventDefault();
      setAddressChangeText('');
      const names = shippingOptionsFormData?.name?.split(' ');

      const zipCode =
        (shippingOptionsFormData.zipCode &&
          shippingOptionsFormData.zipCode.indexOf('-') > -1 &&
          shippingOptionsFormData?.zipCode?.split('-')?.[0]) ||
        shippingOptionsFormData?.zipCode;
      const fullAccNum = cartHeader?.fullAccountNumber?.replace(/(\d{1,5})$/, (_, num) => num.padStart(5, '0'));

      const payload = generatePayload(
        names,
        zipCode,
        fullAccNum,
        cartHeader,
        shippingMethod,
        shippingOptionsFormData,
        selectedAddressType,
        addressTypes,
        skipAddressValidation
      );

      updateShippingOptionBody({ body: payload, mock: false });
    }
  };

  const handleCancel = () => {
    setShowChangeAddress(false);
  };

  useEffect(() => {
    if (updateShippingOptionResult?.data) {
      setShowChangeAddress(false);
      getUniqueAddresses({
        body: { cartId: '' },
        spinner: true,
        mock: false,
      });
    }
  }, [updateShippingOptionResult]);

  return (
    <>
      {addressChangeText && (
        <AppMessageContainer>
          <Notification
            type='warning'
            title={addressChangeText}
            fullBleed={false}
            inline={false}
            disableFocus
            layout='horizontal'
            onCloseButtonClick={() => setAddressChangeText('')}
          />
        </AppMessageContainer>
      )}
      <Container data-testid='editDetails'>
        <AddressTypeContainer>
          <RadioButtonGroup
            data-testid='addressType'
            onChange={(e) => onAddressTypeChange(e.target.value)}
            error={false}
            data={addressTypes}
            defaultValue={addressTypes?.[0]?.value}
          />
        </AddressTypeContainer>
        <FormContainerComponent
          onCityStateChange={onCityStateChange}
          cityStateList={cityStateList}
          selectedCityState={selectedCityState}
          handleAddressSelction={handleMultiAddressSelction}
          AddressData={MultiAddressData}
          collapseAddress={collapseTypeAheadAddress}
          shippingAddressOptions={shippingAddressOptions}
          formDataError={formDataError}
          onChange={onChange}
          shippingOptionsFormData={shippingOptionsFormData}
        />
        <Checkbox
          name='default'
          width='auto'
          disabled={false}
          error={false}
          errorText='Please agree to the terms and conditions.'
        >
          Keep Current Address
        </Checkbox>
        <MarginAuto>
          <Button onClick={onSave}>Save</Button>
          <Button
            use='secondary'
            disabled={checkError(formDataError) || !shippingOptionsFormData?.zipCode}
            onClick={handleCancel}
          >
            Cancel
          </Button>
        </MarginAuto>
      </Container>
    </>
  );
};
MultipleEditShippinAddress.propTypes = {
  shippingMethod: PropTypes.string,
  cartHeader: PropTypes.shape({
    cartCreator: PropTypes.string,
    cartCreatorChannelId: PropTypes.string,
    cartCreatorOrderLocationCode: PropTypes.string,
    cartCreatorSalesRepId: PropTypes.string,
    cartId: PropTypes.string,
    caseId: PropTypes.string,
    createTimestamp: PropTypes.string,
    fullAccountNumber: PropTypes.string,
  }),
  setShowChangeAddress: PropTypes.any,
  getUniqueAddresses: PropTypes.func,
};
export default MultipleEditShippinAddress;
