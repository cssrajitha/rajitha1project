import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import MultipleShippingContent from './MultipleShippingContent';
import StoreProvider from '../../modules/store';
import {
  alternateDropDownShippingOptionsData,
  alternateDropDownaddressOptionsData,
  dropDownShippingOptionsData,
  dropDownaddressOptionsData,
  streeNumAddressOptionsData,
  updatedAddressOptionsData,
  updatedShippingOptionsData,
} from './_mock_/MultipleShippingContentMock';

jest.mock('./MultipleEditShippingAddress', () => ({
  __esModule: true,
  default: () => <div data-testid='editmultiple'>Edit multiple shipping</div>,
}));

const props = {
  miniImage:
    'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-128gb-blue-prepaid-mtpm3ll-a-a?$device-mini$',
  deviceDescription: 'IP15 128 BL',
  numberOfItems: 3,
  shippingMethod: {
    multiLineSeqNumber: 1,
    depletionLocation: '',
    fipsCode: '2951065000',
    description: 'Estimated to arrive on Thu, Jul 25. 3 to 5 Day Ground. Signature required.',
    estimatedDeliveryDate: '2024-07-25 00:00:00',
    estimatedDeliveryDateText: 'Thu, Jul 25',
    shippingCost: '0.0',
    shippingDescription: '3 to 5 Day Ground',
    shippingOptionId: 'SHP018',
    shortDescription: '3 to 5 Day Ground',
    signatureRequired: 'true',
    active: true,
    addedShippingOptionId: 'false',
    estDeliveryDate: '2024-07-25T00:00:00Z',
    freeOvernightShipping: 'false',
    name: '3 to 5 Day Ground',
    discounted: false,
    discountedPrice: 0,
    twoDayShipping: false,
    discountExist: false,
  },
  cartHeader: {
    winBackAccountNumber: '',
    vendorId: 'NETACE',
    ani: 3147049522,
    repRole: 'POSITSUPERUSER',
    locationType: 'T',
    sourceSystem: 'OMNI-RETAIL',
    fullAccountNumber: '0280084163-1',
    status: 'A',
    createTimestamp: '2024-07-18T03:18:16.14-04:00[US/Eastern]',
    lastUpdateTimestamp: '2024-07-18T03:30:17.31-04:00[US/Eastern]',
    cartCreator: '3147049522',
    cartCreatorChannelId: 'OMNI-RETAIL',
    cartCreatorOrderLocationCode: 'D031501',
    cartCreatorSalesRepId: 'EE818',
    visionCustomerType: 'PE',
    maverickLocation: false,
    preConfiguredCartType: 'BAU',
    preConfiguredCartTypeDuringAddDevice: 'BAU',
    isCoreRep: false,
    isERTRep: false,
  },
  radioButtonData: [
    {
      name: 'addressOption',
      children: '3915 CHIPPEWA ST APT 1E',
      value: '3915 CHIPPEWA ST APT 1E',
    },
    {
      name: 'addressOption',
      value: 'New Shipping address',
      children: 'New Shipping address',
    },
  ],
  streetAddress: '3915 CHIPPEWA ST APT 1E',
  mtn: '3147049522',
  itemCount: 1,
  multiLineSeqNumber: 1,
  fipsCode: '2951065000',
  attention: 'KYLE JACOBS',
  updatedShippingOptions: updatedShippingOptionsData,
  updatedAddressOptions: updatedAddressOptionsData,
  setUpdatedShippingOptions: jest.fn(),
  setUpdatedAddressOptions: jest.fn(),
};

const shippingDescription = {
  dropDownShippingOptions: dropDownShippingOptionsData,
};

const shortDescription = {
  dropDownShippingOptions: alternateDropDownShippingOptionsData,
};

const alternateDropdownoptions = {
  dropDownaddressOptions: alternateDropDownaddressOptionsData,
};

const streetNumAddressOptions = {
  dropDownaddressOptions: streeNumAddressOptionsData,
};

const dropdownOptions = {
  dropDownaddressOptions: dropDownaddressOptionsData,
};

describe('multipleShippingcontent', () => {
  test('initial render', () => {
    render(
      <StoreProvider>
        <MultipleShippingContent {...props} {...shippingDescription} {...dropdownOptions} />
      </StoreProvider>,
    );
    const addressdropdown = screen.getByTestId('streetAddress');
    expect(addressdropdown).toBeInTheDocument();
    fireEvent.change(addressdropdown, { target: { value: '3912 WIPLOS ST APT 1C' } });
    const shippingdropdown = screen.getByTestId('handleShippingOptionChange');
    expect(shippingdropdown).toBeInTheDocument();
    fireEvent.change(shippingdropdown, { target: { value: 'Next Day by 12pm' } });
  });
  test('address change clicked', () => {
    const alternateShippingMethod = {
      shippingMethod: {
        multiLineSeqNumber: 1,
        depletionLocation: '',
        fipsCode: '2951065000',
        description: 'Estimated to arrive on Thu, Jul 25. 3 to 5 Day Ground. Signature required.',
        estimatedDeliveryDate: '2024-07-25 00:00:00',
        estimatedDeliveryDateText: 'Thu, Jul 25',
        shippingCost: '0.0',
        shippingOptionId: 'SHP018',
        shortDescription: '3 to 5 Day Ground',
        signatureRequired: 'true',
        active: true,
        addedShippingOptionId: 'false',
        estDeliveryDate: '2024-07-25T00:00:00Z',
        freeOvernightShipping: 'false',
        name: '3 to 5 Day Ground',
        discounted: false,
        discountedPrice: 0,
        twoDayShipping: false,
        discountExist: false,
      },
    };
    render(
      <StoreProvider>
        <MultipleShippingContent
          {...props}
          {...alternateShippingMethod}
          {...shippingDescription}
          {...dropdownOptions}
        />
      </StoreProvider>,
    );
    const changeAddress = screen.getByText('Change address');
    expect(changeAddress).toBeInTheDocument();
    fireEvent.click(changeAddress);
    const radioBtns = screen.getAllByRole('radio');
    expect(radioBtns.length).toBe(2);
    // const radioBtnText = screen.getByText('3915 CHIPPEWA ST APT 1E');
    // fireEvent.change(radioBtnText);
    const remoteRadioButton = screen.getByRole('radio', { name: '3915 CHIPPEWA ST APT 1E' });
    fireEvent.click(remoteRadioButton);

    // const editShipping = screen.getByText('Edit multiple shipping');
    // expect(editShipping).toBeInTheDocument();
  });
  test('only street name render', () => {
    const newProps = {
      itemCount: 0,
      numberOfItems: 2,
    };
    render(
      <StoreProvider>
        <MultipleShippingContent {...props} {...shortDescription} {...newProps} {...alternateDropdownoptions} />
      </StoreProvider>,
    );
    const addressdropdown = screen.getByTestId('streetAddress');
    expect(addressdropdown).toBeInTheDocument();
    fireEvent.change(addressdropdown, { target: { value: '3912 WIPLOS ST APT 1C' } });
    const shippingdropdown = screen.getByTestId('handleShippingOptionChange');
    expect(shippingdropdown).toBeInTheDocument();
    fireEvent.change(shippingdropdown, { target: { value: 'Next Day by 12pm' } });
  });
  test('only street num render', () => {
    const newProps = {
      itemCount: 0,
      numberOfItems: 2,
    };
    render(
      <StoreProvider>
        <MultipleShippingContent {...props} {...shortDescription} {...newProps} {...streetNumAddressOptions} />
      </StoreProvider>,
    );
    const addressdropdown = screen.getByTestId('streetAddress');
    expect(addressdropdown).toBeInTheDocument();
    fireEvent.change(addressdropdown, { target: { value: '3912 WIPLOS ST APT 1C' } });
    const shippingdropdown = screen.getByTestId('handleShippingOptionChange');
    expect(shippingdropdown).toBeInTheDocument();
    fireEvent.change(shippingdropdown, { target: { value: 'Next Day by 12pm' } });
  });
});
