import { fireEvent, render, screen } from '@testing-library/react';
import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import userEvent from '@testing-library/user-event';
import StoreProvider from '../../modules/store';
import MultipleEditShippingAddress from './MultipleEditShippingAddress';
import * as AgreementsAPICallHook from '../../modules/services/APIService/AgreementsAPICallHook';
import shippingAddressOptions from './FormUtils';

const mockData = {
  validateAddressBody: jest.fn(),
  validateAddressResult: {
    data: {
      data: {
        validateAddress: {
          validAddress: false,
          cityStatesFound: ['BARRINGTON-RI', 'BARRINGTON-NY', 'WASHINGTON-WI'],
          fipsCode: '4400100000',
          overlaySwitch: '0',
          zipRestricted: false,
          scrubbedAddress: {},
          numberOfCitiesFound: '1',
        },
      },
    },
  },
  updateShippingOptionBody: jest.fn(),
  updateShippingOptionResult: { data: true },
};

const props = {
  shippingMethod: {
    multiLineSeqNumber: 1,
    depletionLocation: '',
    fipsCode: '2951065000',
    description: 'Estimated to arrive on Thu, Jul 25. 3 to 5 Day Ground. Signature required.',
    estimatedDeliveryDate: '2024-07-25 00:00:00',
    estimatedDeliveryDateText: 'Thu, Jul 25',
    shippingCost: '0.0',
    shippingDescription: '3 to 5 Day Ground',
    shippingOptionId: 'SHP018',
    shortDescription: '3 to 5 Day Ground',
    signatureRequired: 'true',
    active: true,
    addedShippingOptionId: 'false',
    estDeliveryDate: '2024-07-25T00:00:00Z',
    freeOvernightShipping: 'false',
    name: '3 to 5 Day Ground',
    discounted: false,
    discountedPrice: 0,
    twoDayShipping: false,
    discountExist: false,
  },
  cartHeader: {
    winBackAccountNumber: '',
    vendorId: 'NETACE',
    ani: 3147049522,
    repRole: 'POSITSUPERUSER',
    locationType: 'T',
    sourceSystem: 'OMNI-RETAIL',
    fullAccountNumber: '0280084163-1',
    status: 'A',
    createTimestamp: '2024-07-18T03:18:16.14-04:00[US/Eastern]',
    lastUpdateTimestamp: '2024-07-18T03:30:17.31-04:00[US/Eastern]',
    cartCreator: '3147049522',
    cartCreatorChannelId: 'OMNI-RETAIL',
    cartCreatorOrderLocationCode: 'D031501',
    cartCreatorSalesRepId: 'EE818',
    visionCustomerType: 'PE',
    maverickLocation: false,
    preConfiguredCartType: 'BAU',
    preConfiguredCartTypeDuringAddDevice: 'BAU',
    isCoreRep: false,
    isERTRep: false,
  },
  setShowChangeAddress: jest.fn(),
  getUniqueAddresses: jest.fn(),
  handleMultiAddressSelction: jest.fn(),
  onChange: jest.fn(),
  onCityStateChange: jest.fn(),
};

jest.mock('./TypeAheadBox', () => ({
  __esModule: true,
  default: ({ handleAddressSelction }) => (
    <div>
      <button type='button' data-testid='mocked-nbs' onClick={() => handleAddressSelction()}>
        AddressSelection
      </button>
    </div>
  ),
}));

describe('multiple edit shipping address', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  beforeEach(() => {
    jest.spyOn(AgreementsAPICallHook, 'default').mockImplementation(() => mockData);
    jest.useFakeTimers();
    render(
      <BrowserRouter>
        <StoreProvider>
          <MultipleEditShippingAddress {...props} shippingAddressOptions={shippingAddressOptions} />
        </StoreProvider>
      </BrowserRouter>,
    );
  });
  test('Basic render with cancel click', () => {
    const zipcodeInput = screen.getByLabelText('Zip Code*', { selector: 'input' });
    fireEvent.change(zipcodeInput, { target: { value: '74528' } });
    const cancelBtn = screen.getByText('Cancel');
    fireEvent.click(cancelBtn);
  });
  test('change the input forms', () => {
    const nameInput = screen.getByLabelText('Name*', { selector: 'input' });
    fireEvent.change(nameInput, { target: { value: 'Ethan Bond 1' } });

    const streetInput = screen.getByLabelText('Street Address*', { selector: 'input' });
    fireEvent.change(streetInput, { target: { value: 'East bound st' } });

    setTimeout(() => {
      const attnInput = screen.getByLabelText('ATTN', { selector: 'input' });
      fireEvent.change(attnInput, { target: { value: 'sample' } });

      const aptInput = screen.getByLabelText('Apt/Suite', { selector: 'input' });
      fireEvent.change(aptInput, { target: { value: '101' } });
    }, 2000);
    const phoneInput = screen.getByLabelText('Can be Reached*', { selector: 'input' });
    fireEvent.change(phoneInput, { target: { value: '7418529633' } });

    fireEvent.change(screen.getByRole('combobox'), { target: { value: 'New York' } });

    userEvent.selectOptions(
      screen.getByRole('combobox'),
      screen.getByRole('option', { name: 'BARRINGTON-RI,-,BARRINGTON-RI item 1 of 3' }),
    );
    expect(screen.getByRole('option', { name: 'BARRINGTON-RI,-,BARRINGTON-RI item 1 of 3' }).selected).toBe(true);

    const zipcodeInput = screen.getByLabelText('Zip Code*', { selector: 'input' });
    fireEvent.change(zipcodeInput, { target: { value: '74528' } });

    const emailInput = screen.getByLabelText('Email Address*', { selector: 'input' });
    fireEvent.change(emailInput, { target: { value: 'abc@gmail.com' } });

    const saveBtn = screen.getByText('Save');
    fireEvent.click(saveBtn);

    const closeBtn = screen.getByTestId('Notification-close-button');
    fireEvent.click(closeBtn);

    fireEvent.click(saveBtn);
  });
  test('else part to cover', () => {
    const zipcodeInput = screen.getByLabelText('Zip Code*', { selector: 'input' });
    fireEvent.change(zipcodeInput, { target: { value: '74528-0001' } });
    const phoneInput = screen.getByLabelText('Can be Reached*', { selector: 'input' });
    fireEvent.change(phoneInput, { target: { value: '7418529633141' } });

    setTimeout(() => {
      const attnInput = screen.getByLabelText('ATTN', { selector: 'input' });
      fireEvent.change(attnInput, { target: { value: 'attn' } });
      fireEvent.change(attnInput, { target: { value: '' } });

      const aptInput = screen.getByLabelText('Apt/Suite', { selector: 'input' });
      fireEvent.change(aptInput, { target: { value: '102' } });
      fireEvent.change(aptInput, { target: { value: '' } });
    }, 3000);
  });
  test('click business address', () => {
    const addressRadio = screen.getByText('Change to Business Address');
    fireEvent.click(addressRadio);
  });
  test('Keep Current Address', async () => {
    const keppAddCheckbox = screen.getByText('Keep Current Address');
    fireEvent.click(keppAddCheckbox);
  });

  test('onSave', async () => {
    const saveBtn = await screen.findByRole('button', { name: 'Save' });
    expect(saveBtn).toBeInTheDocument();
    fireEvent.click(saveBtn);
  });

  test('typeAhead', async () => {
    const streetAddInput = screen.getByLabelText(/Street Address/i, { selector: 'input' });
    fireEvent.change(streetAddInput, { target: { value: '3' } });
    jest.advanceTimersByTime(1000);

    const addSelection = screen.getByText('AddressSelection');
    fireEvent.click(addSelection);
  });
});
