import { Button } from '@vds/buttons';
import { Icon } from '@vds/icons';
import { Line } from '@vds/lines';
import { Title } from '@vds/typography';
import PropTypes from 'prop-types';
import React from 'react';
import { useNavigate } from 'react-router';
import styled from 'styled-components';
import Emitter from 'onevzsoemfeframework/Emitter';
import { invokeTagging } from '../../utils/test-utils/utils';

const TaxChangesContainer = styled.div`
  z-index: 1000;
  position: fixed;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  margin: auto;
  background-color: black;
`;

const TaxChangesInnerContainer = styled.div`
  position: absolute;
  width: 64rem !important;
  top: 0%;
  min-height: 100%;
  bottom: auto;
  margin: auto;
  right: 1%;
  background: white;
  left: 1%;
`;

const TaxChangesBodyContainer = styled.div`
  height: 76vh;
  overflow: auto;
  display: flex;
  justify-content: center;
  margin-top: 100px;
`;

const FlexBoxGrowOne = styled.div`
  display: flex;
  flex-grow: 1;
  height: 4rem;
`;
const ShopWrapper = styled.div`
  width: 50%;
  padding: 1.5rem 0.5rem;
`;

const FlexAlignContainerItemsCenter = styled.div`
  display: flex;
  align-items: center !important;
  justify-content: space-between;
`;

const FixedHeader = styled.div`
  max-width: 64rem;
  background-color: rgb(255, 255, 255);
  top: 0;
  z-index: 1;
  width: 100%;
  position: fixed;
`;

const CloseIconWrapper = styled.div`
  display: flex;
  margin-right: 30px;
`;

const BlackClickable = styled.a`
  cursor: pointer;
  color: #000000 !important;
`;

const ItemContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
`;

const FooterContainer = styled.div`
  border-top: 1px solid rgb(216, 218, 218);
  text-align: center;
  bottom: 0px;
  width: 62rem;
  z-index: 999;
  background-color: rgb(255, 255, 255);
  position: fixed;
  display: flex;
  padding: 10px;
`;

const MarginAuto = styled.div`
  margin: auto;
`;

const redirectionUrl = '/sales/assisted/new/order-review.html';
const changeText = 'Changing your shipping address will affect the sales tax on your purchase';
const taxChangesHeading = 'Tax Changes';
const newTaxesText = 'New Taxes for Device';

function TaxChanges({ totalTaxAmount, isQAFlow = false }) {
  const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable;
  const quickAccessoryCheckoutTaggingFFlag = /true/i.test(
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.quickAccessoryCheckoutTaggingFFlag,
  );
  if(isQAFlow && quickAccessoryCheckoutTaggingFFlag && totalTaxAmount > 0 ){
    invokeTagging("openView", "Tax Changes")
  }
  const handleRedirect = () => {
    if (isQAFlow) {
      navigate('/sales/assisted/new/qa-order-review.html');
    } else if (!scmUpgradeMfeEnable) {
      navigate(redirectionUrl);
    } else {
      Emitter.emit('CLOSE_SHIPPING_DETAILS_MODAL');
    }
  };
  let navigate = '';
  function useNavigateMFE() {
    navigate = useNavigate();
  }
  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }
  return (
    totalTaxAmount > 0 && (
      <TaxChangesContainer data-testid='tax-changes'>
        <TaxChangesInnerContainer>
          <FixedHeader data-testid='header'>
            <FlexAlignContainerItemsCenter>
              <FlexBoxGrowOne>
                <ShopWrapper>
                  <Title size='small' bold primitive='h1'>
                    Tax Changes
                  </Title>
                </ShopWrapper>
              </FlexBoxGrowOne>
              <CloseIconWrapper>
                <BlackClickable data-testid='close-link' onClick={() => handleRedirect()}>
                  <Icon name='close' size='large' />
                </BlackClickable>
              </CloseIconWrapper>
            </FlexAlignContainerItemsCenter>
            <Line type='secondary' />
          </FixedHeader>
          <TaxChangesBodyContainer>
            <ItemContainer>
              <Icon name='warning' size={200} />
              <Title>{taxChangesHeading}</Title>
              <Title>{changeText}</Title>
              <Title bold>{newTaxesText}</Title>
              <Title>{`$${totalTaxAmount}`}</Title>
            </ItemContainer>
          </TaxChangesBodyContainer>

          <FooterContainer>
            <MarginAuto>
              <Button onClick={() => handleRedirect()}>Continue</Button>
            </MarginAuto>
          </FooterContainer>
        </TaxChangesInnerContainer>
      </TaxChangesContainer>
    )
  );
}

TaxChanges.propTypes = {
  totalTaxAmount: PropTypes.string,
  isQAFlow: PropTypes.bool,
};

export default TaxChanges;
