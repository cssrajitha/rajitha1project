import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import StoreProvider from '../../modules/store';
import Emitter from 'onevzsoemfeframework/Emitter';
import shippingOptionsJson from '../../__mock__/shipping-options.json';

import ShippingOptionsForm from './ShippingOptionsForm';

const timeout = 30000;
jest.setTimeout(timeout);

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => jest.fn(),
  useState: jest.fn(),
}));

describe('Shipping Options Form Component', () => {
  const handlers = [
    rest.post(`*/shippinghandlingservice/shipping/getShippingOptions`, (req, res, ctx) =>
      res(ctx.status(200), ctx.json(shippingOptionsJson))
    ),
  ];
  const server = setupServer(...handlers);

  beforeAll(() => {
    server.listen();
  });

  beforeEach(() => {
    const defaultSelectedShippingOption = 'SHP002';
    const setSelectedShippingOptionMock = jest.fn();

    render(
      <BrowserRouter>
        <StoreProvider>
          <ShippingOptionsForm
            defaultSelectedShippingOption={defaultSelectedShippingOption}
            setSelectedShippingOption={setSelectedShippingOptionMock}
            setGetShippingOptionsOfAllLines={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );
  });

  test('renders shipping options form', async () => {
    await waitFor(() => {
      const titleElement = screen.getByTestId('shippingOptions');
      expect(titleElement).toBeInTheDocument();

      const shippinOption = screen.getByRole('radio', { name: /Next Day by 8pm/i });
      fireEvent.click(shippinOption);
    });
  });

  test('renders shipping options form - ispu', async () => {
    await waitFor(() => {
      const titleElement = screen.getByTestId('shippingOptions');
      expect(titleElement).toBeInTheDocument();

      const ispuOption = screen.getByLabelText('In Store Pick Up');
      fireEvent.click(ispuOption);
    });
  });
  test('renders shipping options form - ispu and scmUpgradeMfeEnable is true', async () => {
    await waitFor(() => {
      window.mfe = { scmUpgradeMfeEnable: true };
      const titleElement = screen.getByTestId('shippingOptions');
      expect(titleElement).toBeInTheDocument();
      const ispuOption = screen.getByLabelText('In Store Pick Up');
      fireEvent.click(ispuOption);
      Emitter.emit('ACSS_SCM_SWITCH_TAB', { type: 'SWITCH_TAB', targetTab: 'DEVICE_TAB', isIspu: true });
    });
  });
});

describe('Shipping Options Form Component - isQAFlow - with no options loaded initially', () => {
  beforeEach(() => {
    const defaultSelectedShippingOption = 'SHP002';
    const setSelectedShippingOptionMock = jest.fn();

    render(
      <BrowserRouter>
        <StoreProvider>
          <ShippingOptionsForm
            defaultSelectedShippingOption={defaultSelectedShippingOption}
            setSelectedShippingOption={setSelectedShippingOptionMock}
            setGetShippingOptionsOfAllLines={jest.fn()}
            isQAFlow
          />
        </StoreProvider>
      </BrowserRouter>
    );
  });

  test('renders shipping options form as empty', () => {
    window.mfe = { scmUpgradeMfeEnable: false };
    expect(screen.queryByText(/Please select one of the shipping options below/i)).not.toBeInTheDocument();
  });
});

describe('Shipping Options Form Component - isQAFlow - with options loaded', () => {
  beforeEach(() => {
    const defaultSelectedShippingOption = 'SHP002';
    const setSelectedShippingOptionMock = jest.fn();

    render(
      <BrowserRouter>
        <StoreProvider>
          <ShippingOptionsForm
            defaultSelectedShippingOption={defaultSelectedShippingOption}
            setSelectedShippingOption={setSelectedShippingOptionMock}
            setGetShippingOptionsOfAllLines={jest.fn()}
            isQAFlow
            shippingOptionsQA={shippingOptionsJson.lines[0].shippingOptions}
          />
        </StoreProvider>
      </BrowserRouter>
    );
  });

  test('renders shipping options form with data', () => {
    const titleElement = screen.getByText('Please select one of the shipping options below');
    expect(titleElement).toBeInTheDocument();
  });
});

describe('Shipping Options Form Component - isQAFlow on selection of nextday by8pm- with options loaded', () => {
  beforeEach(() => {
    const defaultSelectedShippingOption = 'NEXT DAY BY 8PM';
    const setSelectedShippingOptionMock = jest.fn();

    render(
      <BrowserRouter>
        <StoreProvider>
          <ShippingOptionsForm
            defaultSelectedShippingOption={defaultSelectedShippingOption}
            setSelectedShippingOption={setSelectedShippingOptionMock}
            setGetShippingOptionsOfAllLines={jest.fn()}
            isQAFlow
            shippingOptionsQA={shippingOptionsJson.lines[0].shippingOptions}
            selectedShippingOption={{ shippingDescription: 'NEXT DAY BY 8PM' }}
          />
        </StoreProvider>
      </BrowserRouter>
    );
  });

  test('renders shipping options form with data', () => {
    const titleElement = screen.getByText('Please select one of the shipping options below');
    expect(titleElement).toBeInTheDocument();
  });
});
describe('Shipping Options Form Component - isQAFlow on selection of nextday by8pm- with options loaded', () => {
  beforeEach(() => {
    const defaultSelectedShippingOption = 'NEXT DAY BY 8PM';
    const setSelectedShippingOptionMock = jest.fn();

    render(
      <BrowserRouter>
        <StoreProvider>
          <ShippingOptionsForm
            defaultSelectedShippingOption={defaultSelectedShippingOption}
            setSelectedShippingOption={setSelectedShippingOptionMock}
            setGetShippingOptionsOfAllLines={jest.fn()}
            isQAFlow={false}
            shippingOptionsQA={shippingOptionsJson.lines[0].shippingOptions}
            selectedShippingOption={{ shippingDescription: 'NEXT DAY BY 8PM' }}
          />
        </StoreProvider>
      </BrowserRouter>
    );
  });

  test('renders shipping options form with data', () => {
    const titleElement = screen.getByText('Please select one of the shipping options below');
    expect(titleElement).toBeInTheDocument();
  });
});

describe('Shipping Options Form Component - isDark prop set to true', () => {
  test('renders shipping options form with dark theme - line 147, 153, 167, 193, 196', async () => {
    const defaultSelectedShippingOption = 'SHP002';
    const setSelectedShippingOptionMock = jest.fn();

    render(
      <BrowserRouter>
        <StoreProvider>
          <ShippingOptionsForm
            defaultSelectedShippingOption={defaultSelectedShippingOption}
            setSelectedShippingOption={setSelectedShippingOptionMock}
            setGetShippingOptionsOfAllLines={jest.fn()}
            isDark={true}
            shippingAddress={{
              streetNumber: '123',
              streetName: 'Main St',
              type: 'residential',
              city: 'New York',
              state: 'NY',
              zipCode: '10001',
              zipCode4: '1234',
            }}
            cartId="test-cart-id"
          />
        </StoreProvider>
      </BrowserRouter>
    );

    await waitFor(() => {
      const titleElement = screen.getByTestId('shippingOptions');
      expect(titleElement).toBeInTheDocument();
    });
  });

  test('renders shipping options form with dark theme and ISPU option', async () => {
    const defaultSelectedShippingOption = 'SHP002';
    const setSelectedShippingOptionMock = jest.fn();

    render(
      <BrowserRouter>
        <StoreProvider>
          <ShippingOptionsForm
            defaultSelectedShippingOption={defaultSelectedShippingOption}
            setSelectedShippingOption={setSelectedShippingOptionMock}
            setGetShippingOptionsOfAllLines={jest.fn()}
            isDark={true}
            shippingAddress={{
              streetNumber: '123',
              streetName: 'Main St',
              type: 'residential',
              city: 'New York',
              state: 'NY',
              zipCode: '10001',
              zipCode4: '1234',
            }}
            cartId="test-cart-id"
          />
        </StoreProvider>
      </BrowserRouter>
    );

    await waitFor(() => {
      const ispuOption = screen.getByLabelText('In Store Pick Up');
      expect(ispuOption).toBeInTheDocument();
      fireEvent.click(ispuOption);
    });
  });
});

describe('Shipping Options Form Component - isDark prop set to false (light theme)', () => {
  test('renders shipping options form with light theme - line 147, 153, 167, 193, 196', async () => {
    const defaultSelectedShippingOption = 'SHP002';
    const setSelectedShippingOptionMock = jest.fn();

    render(
      <BrowserRouter>
        <StoreProvider>
          <ShippingOptionsForm
            defaultSelectedShippingOption={defaultSelectedShippingOption}
            setSelectedShippingOption={setSelectedShippingOptionMock}
            setGetShippingOptionsOfAllLines={jest.fn()}
            isDark={false}
            shippingAddress={{
              streetNumber: '123',
              streetName: 'Main St',
              type: 'residential',
              city: 'New York',
              state: 'NY',
              zipCode: '10001',
              zipCode4: '1234',
            }}
            cartId="test-cart-id"
          />
        </StoreProvider>
      </BrowserRouter>
    );

    await waitFor(() => {
      const titleElement = screen.getByTestId('shippingOptions');
      expect(titleElement).toBeInTheDocument();
    });
  });
});

describe('Shipping Options Form Component - QA Flow with isDark prop', () => {
  test('renders QA flow with dark theme and selected shipping option note - line 196', () => {
    const defaultSelectedShippingOption = 'SHP002';
    const setSelectedShippingOptionMock = jest.fn();

    render(
      <BrowserRouter>
        <StoreProvider>
          <ShippingOptionsForm
            defaultSelectedShippingOption={defaultSelectedShippingOption}
            setSelectedShippingOption={setSelectedShippingOptionMock}
            setGetShippingOptionsOfAllLines={jest.fn()}
            isQAFlow={true}
            isDark={true}
            shippingOptionsQA={shippingOptionsJson.lines[0].shippingOptions}
            selectedShippingOption={{ shippingDescription: 'Standard Shipping' }}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const titleElement = screen.getByText('Please select one of the shipping options below');
    expect(titleElement).toBeInTheDocument();
  });

  test('renders QA flow with light theme and selected shipping option note - line 196', () => {
    const defaultSelectedShippingOption = 'SHP002';
    const setSelectedShippingOptionMock = jest.fn();

    render(
      <BrowserRouter>
        <StoreProvider>
          <ShippingOptionsForm
            defaultSelectedShippingOption={defaultSelectedShippingOption}
            setSelectedShippingOption={setSelectedShippingOptionMock}
            setGetShippingOptionsOfAllLines={jest.fn()}
            isQAFlow={false}
            isDark={false}
            shippingOptionsQA={shippingOptionsJson.lines[0].shippingOptions}
            selectedShippingOption={{ shippingDescription: 'Standard Shipping' }}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const titleElement = screen.getByText('Please select one of the shipping options below');
    expect(titleElement).toBeInTheDocument();
  });
});

describe('Shipping Options Form Component - shipping cost display coverage', () => {
  test('renders shipping options with cost displayed - line 153', () => {
    const defaultSelectedShippingOption = 'SHP002';
    const setSelectedShippingOptionMock = jest.fn();
    const shippingOptionsWithCost = [
      {
        shippingOptionId: 'SHP001',
        shippingDescription: 'Express Shipping',
        shippingCost: '15.99',
        estimatedDeliveryDate: '2026-02-20',
      },
    ];

    render(
      <BrowserRouter>
        <StoreProvider>
          <ShippingOptionsForm
            defaultSelectedShippingOption={defaultSelectedShippingOption}
            setSelectedShippingOption={setSelectedShippingOptionMock}
            setGetShippingOptionsOfAllLines={jest.fn()}
            isDark={true}
            shippingOptionsQA={shippingOptionsWithCost}
            isQAFlow={true}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const titleElement = screen.getByTestId('shippingOptions');
    expect(titleElement).toBeInTheDocument();
  });

  test('renders shipping options without cost - line 153', () => {
    const defaultSelectedShippingOption = 'SHP002';
    const setSelectedShippingOptionMock = jest.fn();
    const shippingOptionsWithoutCost = [
      {
        shippingOptionId: 'SHP001',
        shippingDescription: 'Free Shipping',
        shippingCost: null,
        estimatedDeliveryDate: '2026-02-20',
      },
    ];

    render(
      <BrowserRouter>
        <StoreProvider>
          <ShippingOptionsForm
            defaultSelectedShippingOption={defaultSelectedShippingOption}
            setSelectedShippingOption={setSelectedShippingOptionMock}
            setGetShippingOptionsOfAllLines={jest.fn()}
            isDark={false}
            shippingOptionsQA={shippingOptionsWithoutCost}
            isQAFlow={true}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const titleElement = screen.getByTestId('shippingOptions');
    expect(titleElement).toBeInTheDocument();
  });
});