import { DropdownSelect } from '@vds/selects';
import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { RadioButtonGroup } from '@vds/radio-buttons';
import MultipleEditShippinAddress from './MultipleEditShippingAddress';

const Tiles = styled.div`
  display: flex;
  flex-direction: row;
  gap: 15px;
  margin: 20px 0;
`;
const HorizontalLine = styled.div`
  border: none;
  border-top: 1px solid rgba(0, 0, 0, 0.3);
  margin: 10px 0;
  width: 100%;
`;

const Col35 = styled.div`
  width: 33%;
`;

const DropDowmWrapper = styled.div`
  [class^='StyledTypography-VDS'] {
    font-size: 16px;
    font-family: BrandFontRegular, Arial, sans-serif;
  }
  [class^='SelectEl-VDS'] {
    font-size: 14px;
    font-family: BrandFontRegular, sans-serif;
  }
`;

const MtnValue = styled.div`
  font-family: BrandFontBold, Sans-serif !important;
  font-size: 18px;
  font-weight: bold;
`;

const ItemCountText = styled.div`
  font-family: BrandFontRegular, Sans-serif !important;
  font-size: 18px;
`;

const ChangeAddressText = styled.div`
  margin: 5px 0;
  cursor: pointer;
  span {
    font-family: BrandFontBold, Sans-serif !important;
    font-weight: bold;
    font-size: 15px;
  }
`;
const Container = styled.div`
  display: flex;
  width: auto;
  margin-top: 10px;
  gap: 30px;
`;

const FlexContainer = styled.div`
  display: block;
  css-float: left;
  width: 43%;
  margin-left: 0%;
  clear: none;
`;

const Group = styled.div`
  div[class^='RadioButtonGroupWrapper'] {
    padding-top: 1rem !important;
  }
  div[class^='ChildWrapper'] {
    font-family: BrandFontRegular;
  }
`;

const LineSeperator = styled.div`
  border-right: 1px solid #d8dada;
  position: relative;
`;

const MultipleShippingContent = ({
  miniImage,
  deviceDescription,
  numberOfItems,
  shippingMethod,
  streetAddress,
  dropDownShippingOptions,
  dropDownaddressOptions,
  mtn,
  itemCount,
  multiLineSeqNumber,
  fipsCode,
  updatedShippingOptions,
  updatedAddressOptions,
  setUpdatedAddressOptions,
  setUpdatedShippingOptions,
  attention,
  radioButtonData,
  cartHeader,
  getUniqueAddresses,
}) => {
  const [selectedShippingMethod, setSelectedShippingMethod] = useState('');
  const [selectedStreetAddress, setSelectedStreetAddress] = useState('');
  const [showChangeAddress, setShowChangeAddress] = useState(false);

  const newAddressText = 'New Shipping address';

  useEffect(() => {
    setSelectedStreetAddress(streetAddress);
    setSelectedShippingMethod(shippingMethod?.shippingDescription || shippingMethod?.shortDescriptioningMethod);
  }, [streetAddress, shippingMethod]);

  const getCamelCaseName = (title) =>
    title
      ?.toLowerCase()
      .split(' ')
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');

  const handleAddressChange = (addressValue, dropdownOptions) => {
    const addrValue = addressValue && dropdownOptions?.find((option) => option.label === addressValue);
    const value = addrValue?.value;
    if (value) {
      setSelectedStreetAddress(value?.addressLine1 || value?.streetName || value?.streetNumber);
      const addressData = {
        multiLineSeqNumber,
        attention,
        fipsCode,
        ruralRouteNo: '',
        ...value,
      };
      const filterData = updatedAddressOptions.filter((item) => item.multiLineSeqNumber !== multiLineSeqNumber);
      setUpdatedAddressOptions([...filterData, addressData]);
    }
  };

  const handleShippingOptionChange = (optionShipping, dropdownOptions) => {
    const optionShip = optionShipping && dropdownOptions?.find((option) => option?.label === optionShipping);
    const shippingOption = optionShip?.value;
    const shippingData = {
      multiLineSeqNumber,
      depletionLocation: '',
      fipsCode,
      ...shippingOption,
    };
    const filterData = updatedShippingOptions.filter((item) => item.multiLineSeqNumber !== multiLineSeqNumber);
    setUpdatedShippingOptions([...filterData, shippingData]);

    if (shippingOption) {
      setSelectedShippingMethod(shippingOption?.shippingDescription || shippingOption?.shortDescription);
    }
  };

  const onChangeFunc = (e) => {
    if (e.target.value !== newAddressText) {
      handleAddressChange(e.target.value, dropDownaddressOptions);
      setShowChangeAddress(false);
    }
  };

  return (
    <>
      <Tiles>
        <Col35>
          <div key={mtn}>
            <MtnValue>{mtn}</MtnValue>
            <ItemCountText>{itemCount || 0} Item(s)</ItemCountText>
            <div className='u-paddingTopSmall'>
              <center>
                <img
                  style={{ width: '31x', height: '44px' }}
                  src={miniImage}
                  alt={deviceDescription}
                  title={getCamelCaseName(deviceDescription)}
                />
              </center>
              {numberOfItems > 1 && (
                <span className='font-14 u-paddingTopExtraSmall'>
                  + {numberOfItems - 1} more item
                  {numberOfItems > 2 ? 's' : ''}
                </span>
              )}
            </div>
          </div>
        </Col35>
        <Col35>
          <DropDowmWrapper>
            <DropdownSelect
              width='100%'
              id='streetAddress'
              data-testid='streetAddress'
              error={false}
              value={selectedStreetAddress}
              onChange={(e) => handleAddressChange(e.target.value, dropDownaddressOptions)}
            >
              {dropDownaddressOptions?.map((option) => (
                <option key={option.key} value={option.label}>
                  {option.label}
                </option>
              ))}
            </DropdownSelect>
          </DropDowmWrapper>
          <ChangeAddressText onClick={() => setShowChangeAddress(!showChangeAddress)}>
            <span>Change address</span>
          </ChangeAddressText>
        </Col35>
        <Col35>
          <DropDowmWrapper>
            <DropdownSelect
              width='100%'
              id={`shippingDropdownOptions${multiLineSeqNumber}`}
              data-testid='handleShippingOptionChange'
              error={false}
              value={selectedShippingMethod}
              onChange={(e) => handleShippingOptionChange(e.target.value, dropDownShippingOptions)}
            >
              {dropDownShippingOptions?.map(
                (option) =>
                  option?.value?.shippingOptionId !== 'SDD_SAMEDAY' &&
                  option?.value?.shippingOptionId !== 'SDD_SAMEDAY_NVMP' && (
                    <option key={option.key} value={option.label}>
                      {option.label}
                    </option>
                  ),
              )}
            </DropdownSelect>
          </DropDowmWrapper>
        </Col35>
      </Tiles>
      {showChangeAddress && (
        <Container>
          <FlexContainer>
            <div>Shipping address choices</div>
            <Group data-testid='newAddressText'>
              <RadioButtonGroup
                id='radio-btn'
                data-testId='radio-btn'
                className='u-paddingTopMedium u-text16'
                defaultValue={newAddressText}
                onChange={(e) => onChangeFunc(e)}
                data={radioButtonData}
              />
            </Group>
          </FlexContainer>
          <LineSeperator />
          <FlexContainer>
            <MultipleEditShippinAddress
              shippingMethod={shippingMethod}
              cartHeader={cartHeader}
              selectedShippingOption={selectedShippingMethod}
              setShowChangeAddress={setShowChangeAddress}
              getUniqueAddresses={getUniqueAddresses}
            />
          </FlexContainer>
        </Container>
      )}
      <HorizontalLine />
    </>
  );
};

MultipleShippingContent.propTypes = {
  miniImage: PropTypes.any,
  deviceDescription: PropTypes.any,
  numberOfItems: PropTypes.any,
  shippingMethod: PropTypes.any,
  streetAddress: PropTypes.any,
  dropDownShippingOptions: PropTypes.any,
  dropDownaddressOptions: PropTypes.any,
  mtn: PropTypes.any,
  itemCount: PropTypes.any,
  multiLineSeqNumber: PropTypes.any,
  fipsCode: PropTypes.string,
  updatedShippingOptions: PropTypes.object,
  updatedAddressOptions: PropTypes.object,
  setUpdatedAddressOptions: PropTypes.func,
  setUpdatedShippingOptions: PropTypes.func,
  attention: PropTypes.any,
  radioButtonData: PropTypes.array,
  cartHeader: PropTypes.any,
  getUniqueAddresses: PropTypes.func,
};

export default MultipleShippingContent;
