import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../modules/store';

import ShippingDetailsHeader from './ShippingDetailsHeader';

describe('Shippingdetails page Header', () => {
  beforeEach(() => {
    window.mfe = { scmUpgradeMfeEnable: true };
    render(
      <BrowserRouter>
        <StoreProvider>
          <ShippingDetailsHeader />
        </StoreProvider>
      </BrowserRouter>
    );
  });

  test('renders shipping details header', async () => {
    await waitFor(() => {
      const titleElement = screen.getByTestId('header');
      expect(titleElement).toBeInTheDocument();

      const close = screen.getByTestId('close-link');
      fireEvent.click(close);
    });
  });

  test('renders shipping details header 1', async () => {
    await waitFor(() => {
      const titleElement = screen.getByTestId('header');
      expect(titleElement).toBeInTheDocument();

      const close = screen.getByTestId('close-link');
      fireEvent.click(close);
    });
  });
});

describe('Shippingdetails page Header - isQAFlow', () => {
  beforeEach(() => {
    window.mfe = { scmUpgradeMfeEnable: false };
    render(
      <BrowserRouter>
        <StoreProvider>
          <ShippingDetailsHeader isQAFlow />
        </StoreProvider>
      </BrowserRouter>
    );
  });

  test('renders shipping details header', async () => {
    await waitFor(() => {
      const titleElement = screen.getByTestId('header');
      expect(titleElement).toBeInTheDocument();

      const close = screen.getByTestId('close-link');
      fireEvent.click(close);
    });
  });

  test('renders shipping details header 1', async () => {
    await waitFor(() => {
      const titleElement = screen.getByTestId('header');
      expect(titleElement).toBeInTheDocument();

      const close = screen.getByTestId('close-link');
      fireEvent.click(close);
    });
  });
});

describe('Shippingdetails page Header', () => {
  beforeEach(() => {
    window.mfe = { scmUpgradeMfeEnable: false };
    render(
      <BrowserRouter>
        <StoreProvider>
          <ShippingDetailsHeader />
        </StoreProvider>
      </BrowserRouter>
    );
  });

  test('renders shipping details header', async () => {
    await waitFor(() => {
      const titleElement = screen.getByTestId('header');
      expect(titleElement).toBeInTheDocument();

      const close = screen.getByTestId('close-link');
      fireEvent.click(close);
    });
  });
});

describe('Shippingdetails page Header', () => {
  beforeEach(() => {
    window.mfe = { scmUpgradeMfeEnable: false };
    render(
      <BrowserRouter>
        <StoreProvider>
          <ShippingDetailsHeader isFromRefundOrderView />
        </StoreProvider>
      </BrowserRouter>
    );
  });

  test('renders shipping details header', async () => {
    await waitFor(() => {
      const titleElement = screen.getByTestId('header');
      expect(titleElement).toBeInTheDocument();

      const close = screen.getByTestId('close-link');
      fireEvent.click(close);
    });
  });
});
