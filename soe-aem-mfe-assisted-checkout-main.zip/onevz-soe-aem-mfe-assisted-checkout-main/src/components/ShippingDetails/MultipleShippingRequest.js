export const getUpdateShippingAndAddressPayload = (
  CustomerProfileResult,
  CartDetailsResult,
  multiLineAddress,
  multiLineOptions,
  creditAppNum,
) => ({
  serviceHeader: {
    statusMsg: 'PEGA generated message',
    correlationId: CustomerProfileResult?.meta?.cxpCorrelationId,
    sessionId: '',
    serviceName: 'SalesOrderPurchase',
    statusCode: '0',
  },
  serviceOptionBody: {
    serviceRequest: {
      context: {
        skipCheckoutCall: true,
        caseId: CustomerProfileResult?.data?.customer?.caseId,
        customerInfo: {
          accountNumber: CartDetailsResult?.cartHeader?.fullAccountNumber,
          cartCreator:
            CustomerProfileResult?.data?.customer?.customerAttributes?.customerType === 'N'
              ? creditAppNum
              : CustomerProfileResult?.data?.customer?.lookupMtn,
          processingMTN: CustomerProfileResult?.data?.customer?.lookupMtn,
          originalCreditApprovalNumber:
            CustomerProfileResult?.data?.customer?.customerAttributes?.customerType === 'N' ? creditAppNum : '',
          customerType: CustomerProfileResult?.data?.customer?.customerAttributes?.customerType === 'N' || '',
        },
        cartInfo: {
          cartId: CustomerProfileResult?.data?.customer?.cartId,
          action: 'UPDATE',
          itemType: 'SHIPPINGOPTION',
          intendType: CustomerProfileResult?.data?.customer?.customerAttributes?.customerType === 'N' ? 'NSE' : 'EUP',
          shipmentInfo: multiLineOptions,
        },
        contextInfo: {
          callReason: 'SalesOrderPurchase',
          intent: CustomerProfileResult?.data?.customer?.customerAttributes?.customerType === 'N' ? 'NSE' : 'Upgrade',
          processStep: 'OrderReview-Shipping',
          processAction: 'updateShippingOptions',
        },
      },
    },
  },
  serviceAddressBody: {
    serviceRequest: {
      context: {
        cartInfo: {
          action: 'UPDATE',
          cartId: CustomerProfileResult?.data?.customer?.cartId,
          intendType: CustomerProfileResult?.data?.customer?.customerAttributes?.customerType === 'N' ? 'NSE' : 'EUP',
          itemType: 'SHIPPINGADDRESS',
          shipmentAddress: {
            lines: multiLineAddress,
          },
        },
        caseId: CustomerProfileResult?.data?.customer?.caseId,
        contextInfo: {
          callReason: 'SalesOrderPurchase',
          intent: CustomerProfileResult?.data?.customer?.customerAttributes?.customerType === 'N' ? 'NSE' : 'Upgrade',
          processAction: 'updateShippingAddress',
          processStep: 'OrderReview-Shipping',
        },
        customerInfo: {
          accountNumber: CartDetailsResult?.cartHeader?.fullAccountNumber,
          cartCreator:
            CustomerProfileResult?.data?.customer?.customerAttributes?.customerType === 'N'
              ? creditAppNum
              : CustomerProfileResult?.data?.customer?.lookupMtn,
          processingMTN: CustomerProfileResult?.data?.customer?.lookupMtn,
          originalCreditApprovalNumber:
            CustomerProfileResult?.data?.customer?.customerAttributes?.customerType === 'N' ? creditAppNum : '',
          customerType: CustomerProfileResult?.data?.customer?.customerAttributes?.customerType === 'N' || '',
        },
      },
    },
  },
});

export const generatePayload = (
  names,
  zipCode,
  fullAccNum,
  cartHeader,
  shippingMethod,
  shippingOptionsFormData,
  selectedAddressType,
  addressTypes,
  skipAddressValidation,
) => ({
  serviceHeader: {
    clientId: 'VZW-NETACE',
    statusMsg: 'PEGA generated message',
    correlationId: '69a66ef4d7e344dfb2db299209ea8333',
    sessionId: '',
    serviceName: 'SalesOrderPurchase',
    userId: '',
    statusCode: '0',
  },
  serviceOptionBody: {
    serviceRequest: {
      context: {
        caseId: cartHeader?.caseId,
        customerInfo: {
          accountNumber: fullAccNum,
          cartCreator: cartHeader?.cartCreator,
          processingMTN: cartHeader?.cartCreator,
          originalCreditApprovalNumber: '',
          customerType: '',
        },
        cartInfo: {
          cartId: cartHeader?.cartId,
          action: 'UPDATE',
          itemType: 'SHIPPINGOPTION',
          intendType: 'EUP',
          shipmentInfo: [
            {
              multiLineSeqNumber: 1,
              shipping: {
                shippingCode: shippingMethod?.shippingOptionId,
                shippingCost: shippingMethod?.shippingCost,
                shippingDescription: shippingMethod?.shippingDescription,
                depletionLocation: '',
                fipsCode: shippingMethod?.fipsCode,
                deliveryDate: shippingMethod?.estimatedDeliveryDate,
              },
            },
          ],
        },
        contextInfo: {
          callReason: 'SalesOrderPurchase',
          intent: 'Upgrade',
          processStep: 'OrderReview-Shipping',
          processAction: 'updateShippingOptions',
        },
      },
    },
  },
  serviceAddressBody: {
    serviceRequest: {
      context: {
        cartInfo: {
          action: 'UPDATE',
          cartId: cartHeader?.cartId,
          intendType: 'EUP',
          itemType: 'SHIPPINGADDRESS',
          shipmentAddress: {
            notificationMDN: '',
            lines: [
              {
                address: {
                  addressLine2: '',
                  streetName: shippingOptionsFormData.streetName,
                  addressLine1: shippingOptionsFormData.streetName,
                  apartmentNo: shippingOptionsFormData.apartmentNo,
                  attention: shippingOptionsFormData.attn,
                  city: shippingOptionsFormData.cityState,
                  countryCode: '',
                  emailId: shippingOptionsFormData.emailId,
                  fipsCode: shippingMethod?.fipsCode,
                  firmName: '',
                  name: shippingOptionsFormData.name,
                  firstName: names?.[0],
                  lastName: names?.[1],
                  phoneNumber: shippingOptionsFormData.phone,
                  poBoxNo: '',
                  ruralDelNo: '',
                  ruralRouteNo: '',
                  state: shippingOptionsFormData?.state,
                  addressType: selectedAddressType === addressTypes?.[1]?.value ? 'B' : 'R',
                  zipCode,
                  zipCode4: '',
                },
                multiLineSeqNumber: shippingMethod?.multiLineSeqNumber,
                skipAddressValidation,
              },
            ],
          },
        },
        caseId: cartHeader?.caseId,
        contextInfo: {
          callReason: 'SalesOrderPurchase',
          intent: 'Upgrade',
          processAction: 'updateShippingAddress',
          processStep: 'OrderReview-Shipping',
        },
        customerInfo: {
          accountNumber: fullAccNum,
          cartCreator: cartHeader?.cartCreator,
          processingMTN: cartHeader?.cartCreator,
          originalCreditApprovalNumber: '',
          customerType: '',
        },
      },
    },
  },
});
