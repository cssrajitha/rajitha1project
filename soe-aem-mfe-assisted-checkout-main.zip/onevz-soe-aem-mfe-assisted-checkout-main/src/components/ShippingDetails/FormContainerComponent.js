import { Input } from '@vds/inputs';
import { DropdownSelect as Dropdown } from '@vds/selects';
import PropTypes from 'prop-types';
import React from 'react';
import styled from 'styled-components';
import TypeAheadBox from './TypeAheadBox';

const InputContainer = styled.div`
  grid-area: ${(props) => props?.optionId};
  input {
    font-weight: bold;
  }
  [class^='OptionalLabel-VDS'] {
    display: none;
  }
`;

const FormContainer = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;

  grid-column-gap: 20px;
  grid-row-gap: 20px;
  position: relative;
  grid-template-areas:
    'name name'
    'attn attn'
    'streetName streetName'
    'apartmentNo phone'
    'cityState zipCode'
    'emailId emailId';
`;

export default function FormContainerComponent({
  onCityStateChange,
  cityStateList,
  selectedCityState,
  handleAddressSelction,
  AddressData,
  collapseAddress,
  shippingAddressOptions,
  formDataError,
  shippingOptionsFormData,
  onChange,
  selectedAddressType,
  isDark = false,
}) {
  const errorTextLabel = (option) => {
    let errorText = '';
    if (option.id === 'name') {
      errorText = `Please enter both first name and last name.`;
    } else if (option.title === 'Can be Reached') {
      errorText = `Enter a valid Phone Number.`;
    } else {
      errorText = `Enter a valid ${option.title?.replace('*', '')}.`;
    }
    return errorText;
  };

  return (
    <FormContainer>
      {shippingAddressOptions?.map((option) => (
        <InputContainer key={option.id} optionId={option.id}>
          {option.id !== 'cityState' ? (
            <div style={{ display: 'flex' }}>
              <Input
                type='text'
                label={
                  <>
                    {/* { selectedAddressType !== "businessAddress" ? option.title?.replace('*','') :"Business" + option.title?.replace('*','')} */}
                    {`${selectedAddressType === 'businessAddress' && option.id === 'name' ? 'Business' : ''}${option.title?.replace('*', '')}`}
                    {option.required && <span style={{ color: 'red' }}>*</span>}
                  </>
                }
                readOnly={false}
                required={option.required}
                disabled={false}
                error={formDataError?.[`${option.id}Error`]}
                errorText={errorTextLabel(option)}
                value={shippingOptionsFormData?.[option.id]}
                onChange={(e) => onChange(e, option.id)}
                width='100%'
                name={option.id}
                surface={isDark ? 'dark' : 'light'}
              />
              {option.id === 'streetName' && (
                <TypeAheadBox
                  collapseAddress={collapseAddress}
                  AddressData={AddressData}
                  handleAddressSelction={handleAddressSelction}
                />
              )}
            </div>
          ) : (
            <Dropdown
              id='cityState'
              data-testid='cityState'
              value={selectedCityState}
              error={false}
              disabled={false}
              readOnly={false}
              surface={isDark ? 'dark' : 'light'}
              onChange={(e) => onCityStateChange(e.target.value)}
              label='City/State*'
            >
              {cityStateList && cityStateList.length > 0 ? (
                cityStateList.map((city) => (
                  <option key={city.label} value={city.label}>
                    {city.label}-{city.value}
                  </option>
                ))
              ) : (
                <option>City,State not available</option>
              )}
            </Dropdown>
          )}
        </InputContainer>
      ))}
    </FormContainer>
  );
}

FormContainerComponent.propTypes = {
  onCityStateChange: PropTypes.func,
  cityStateList: PropTypes.array,
  selectedCityState: PropTypes.any,
  handleAddressSelction: PropTypes.func,
  AddressData: PropTypes.array,
  collapseAddress: PropTypes.bool,
  shippingAddressOptions: PropTypes.bool,
  formDataError: PropTypes.bool,
  shippingOptionsFormData: PropTypes.any,
  onChange: PropTypes.func,
  selectedAddressType: PropTypes.any,
  isDark: PropTypes.bool,
};
