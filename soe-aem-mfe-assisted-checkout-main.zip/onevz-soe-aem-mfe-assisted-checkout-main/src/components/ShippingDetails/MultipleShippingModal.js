import PropTypes from 'prop-types';
import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import { Button } from '@vds/buttons';
import { Title } from '@vds/typography';
import { Icon } from '@vds/icons';
import { Line } from '@vds/lines';
import MultipleShippingContent from './MultipleShippingContent';
import AgreementsAPICallHook from '../../modules/services/APIService/AgreementsAPICallHook';
import { getUpdateShippingAndAddressPayload } from './MultipleShippingRequest';
import { isSplitFulfillmentEnabled, dFillItemPresent } from '../../utils/orderreviewUtil';

const Tiles = styled.div`
  display: flex;
  flex-direction: row;
  gap: 15px;
  margin: 20px 0;
`;

const HorizontalLine = styled.div`
  border: none;
  border-top: 2px solid black;
  margin: 10px 0;
  width: 100%;
`;
const Col35 = styled.div`
  width: 33%;
`;
const ColHeader = styled.div`
  width: 33%;
  font-size: 18px;
  font-weight: bold;
  font-family: BrandFontBold, Sans-serif !important;
`;
const ShippingInfoContainer = styled.div`
  padding-top: 1.75rem;
  font-weight: 700;
  @media (max-width: 1024px) {
    margin-left: 12.5rem;
    margin-right: 4.5rem;
  }
  @media (min-width: 1025px) {
    margin-left: 18.5rem;
    margin-right: 6.5rem;
  }

  span {
    font-size: 16px;
    font-weight: bold;
    font-family: BrandFontBold, Sans-serif !important;
  }
`;
const MarginAuto = styled.div`
  margin: auto;
`;

const FooterContainer = styled.div`
  text-align: center;
  bottom: 0px;
  width: 64rem !important;
  z-index: 999;
  background-color: rgb(255, 255, 255);
  position: fixed;
  display: flex;
  padding: 10px 0;
  @media (max-width: 1024px) {
    width: 52rem !important;
  }
`;

const MultipleShippingModalContainer = styled.div`
  z-index: 1000;
  position: fixed;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  margin: auto;
  background-color: black;
`;

const MultipleShippingInnerContainer = styled.div`
  position: absolute;
  width: 64rem !important;
  top: 0%;
  height: 100%;
  bottom: auto;
  margin: auto;
  right: 1%;
  overflow-y: scroll;
  background: white;
  left: 1%;
  @media (max-width: 1024px) {
    width: 52rem !important;
  }
`;

const MultipleShippingHeaderContainer = styled.div`
  max-width: 64rem !important;
  background-color: rgb(255, 255, 255);
  top: 0;
  z-index: 1;
  width: 100%;
  position: fixed;
  @media (max-width: 1024px) {
    width: 52rem !important;
  }
`;
const FlexAlignContainerItemsCenter = styled.div`
  display: flex;
  align-items: center !important;
  justify-content: space-between;
`;
const FlexBoxGrowOne = styled.div`
  display: flex;
  flex-grow: 1;
  height: 4rem;
`;
const ShopWrapper = styled.div`
  width: 50%;
  padding: 1.5rem 1.25rem;
`;
const CloseIconWrapper = styled.div`
  display: flex;
  margin-right: 30px;
`;
const BlackClickable = styled.a`
  cursor: pointer;
  color: #000000 !important;
`;
const MultipleShippingBodyContainer = styled.div`
  margin: 100px 20px 0 20px;
`;

const orderNote = `Two day orders placed by 8 PM EST M-F and Saturday by 2 PM EST will ship same day. Overnight orders completed by 11 PM EST will generally ship same day depending on inventory availability`;

const QAOrderNote = `__ Free 3 to 5 Day Ground Shipping is available for accessory orders purchased online Monday - Friday by 4:00 PM Local. Available for purchases placed on VerizonWireless.com for delivery within the U.S. only, excluding Alaska and Hawaii. Orders placed by 4:00 PM Local Monday - Friday excluding holidays will deliver in three (3) to five (5) business days. Overnight orders placed on Friday will not arrive until the following Monday.  All orders subject to credit authorization, verification and inventory availability. All orders under $49 must be placed by 4pm local time.`;

const MultipleShippingModal = ({
  showShipToMultipleModal,
  setShowShipToMultipleModal,
  lineItems,
  getShippingOptionsOfAllLines,
  updateShippingOptionBody,
  CartDetailsResult,
  CustomerProfileResult,
  isQAFlow = false,
}) => {
  const { getUniqueAddresses, getUniqueAddressesResult } = AgreementsAPICallHook();
  const splitFulfillmentFlag = isSplitFulfillmentEnabled(CartDetailsResult?.orderDetails?.itemLevelShipment) || false;
  const [uniqueAddressLists, setUniqueAddressLists] = useState([]);
  const [updatedShippingOptions, setUpdatedShippingOptions] = useState([]);
  const [updatedAddressOptions, setUpdatedAddressOptions] = useState([]);
  const [multipleShippingArray, setMultipleShippingArray] = useState([]);

  useEffect(() => {
    getUniqueAddresses({
      body: { cartId: CustomerProfileResult?.data?.data?.customer?.cartId },
      spinner: true,
      mock: false,
    });
  }, []);

  useEffect(() => {
    if (getUniqueAddressesResult?.data) {
      setUniqueAddressLists(getUniqueAddressesResult?.data);
    }
  }, [getUniqueAddressesResult]);

  const getCartItemDeviceDetails = (info) => {
    const itemInfo = info?.itemsInfo?.[0];
    const deviceCartItem = itemInfo?.cartItems?.cartItem?.filter(
      (currentCartItem) => currentCartItem.cartItemType === 'DEVICE' || currentCartItem.cartItemType === 'ACCESSORY',
    );
    const miniImages = {
      miniImage: deviceCartItem?.[0]?.imageUrlMap?.miniImage,
      deviceDescription: deviceCartItem?.[0]?.deviceDisplayName || deviceCartItem?.[0]?.description,
      numberOfItems: deviceCartItem?.length,
    };

    return miniImages;
  };

  const loadShippingData = (info) => {
    const line =
      getShippingOptionsOfAllLines && getShippingOptionsOfAllLines?.lines
        ? getShippingOptionsOfAllLines?.lines?.filter(
            (data) => parseInt(data.multiLineSeqNumber, 10) === info.multiLineSeqNumber,
          )
        : [];
    const shippingOptions = line?.[0]?.shippingOptions;
    const selectedOptionCode = line?.[0]?.selectedOptionCode;
    const selectedShippingOption = shippingOptions?.filter((item) => item?.shippingOptionId === selectedOptionCode);

    const address = info?.itemsInfo?.[0]?.shipping?.address;
    if (address) {
      const addressSelected = [];
      addressSelected.push(address);
      let selecteAddress = addressSelected;
      const uniqueAddressList = uniqueAddressLists?.addressDetails;
      if (uniqueAddressList?.length > 0) {
        selecteAddress = uniqueAddressList.filter(
          (uniqueAddress) =>
            uniqueAddress?.addressLine1 === address?.addressLine1 && uniqueAddress?.zipCode === address?.zipCode,
        );
      }
      const shippingData = {
        shippingDataShippingOption: selectedShippingOption?.[0],
        shippingDataAddress: selecteAddress?.length > 0 && selecteAddress?.[0],
      };
      return shippingData;
    }
  };

  const getShippingOptions = (multiLineSeqNumber) => {
    const line = getShippingOptionsOfAllLines?.lines?.filter(
      (data) => parseInt(data.multiLineSeqNumber, 10) === multiLineSeqNumber,
    );
    const shippingOptions = line?.[0]?.shippingOptions;
    return shippingOptions;
  };

  const getAddressOptions = () => {
    const addressOptions = [];
    const uniqueAddress = uniqueAddressLists;

    uniqueAddress?.addressDetails?.forEach((address) => {
      if (address?.addressLine1 && address?.zipCode && address?.lineNo)
        addressOptions.push({
          address,
          key: address.lineNo,
          uniqueAddressString: address.addressLine1 + address.zipCode + address.lineNo,
        });
    });

    return addressOptions;
  };

  const handleSave = () => {
    const multiLineAddress = updatedAddressOptions
      .map((item) => {
        const addressObj = {
          address: {
            addressLine2: '',
            addressLine1: item?.addressLine1,
            apartmentNo: item?.apartmentNo,
            attention: item?.attention,
            city: item?.city,
            countryCode: item?.country,
            emailId: item?.emailId,
            fipsCode: item?.fipsCode,
            firmName: item?.firmName,
            firstName: item?.firstName,
            lastName: item?.lastName,
            phoneNumber: item?.phoneNumber,
            poBoxNo: item?.pobox,
            ruralDelNo: item?.ruralDel,
            ruralRouteNo: item?.ruralRte,
            state: item?.state,
            streetName: item?.streetName,
            streetNumber: item?.streetNumber,
            addressType: item?.type,
            zipCode: item?.zipCode,
            zipCode4: item?.zipCode4,
          },
          multiLineSeqNumber: item?.multiLineSeqNumber,
          skipAddressValidation: 'Y',
        };
        return addressObj;
      })
      .sort((a, b) => a.multiLineSeqNumber - b.multiLineSeqNumber);
    const multiLineOptions = updatedShippingOptions
      .map((item) => {
        const optionsObj = {
          multiLineSeqNumber: item?.multiLineSeqNumber,
          shipping: {
            shippingCode: item?.shippingOptionId,
            shippingCost: item?.shippingCost,
            shippingDescription: item?.shortDescription || item?.shippingDescription,
            deliveryDate: item?.estimatedDeliveryDate,
            depletionLocation: '',
            fipsCode: item?.fipsCode,
          },
        };
        return optionsObj;
      })
      .sort((a, b) => a.multiLineSeqNumber - b.multiLineSeqNumber);
    const creditAppNum = sessionStorage.getItem('creditAppNum');
    const updateShippingAndAddressPayload = getUpdateShippingAndAddressPayload(
      CustomerProfileResult?.data,
      CartDetailsResult,
      multiLineAddress,
      multiLineOptions,
      creditAppNum,
    );
    updateShippingOptionBody({ body: updateShippingAndAddressPayload, mock: false });
  };

  useEffect(() => {
    let AddressOptionsArray = [];
    let ShippingOptionsArray = [];
    let DFillLines = [];
    const lineInfoDetails = lineItems.filter(
      (lineInfo) => lineInfo.lineActivityType !== 'CPC' && lineInfo.lineActivityType !== 'FEA',
    );

    if (splitFulfillmentFlag) {
      const dFillLineInfo = lineInfoDetails.filter((lineInfo) => dFillItemPresent([lineInfo]));
      DFillLines = dFillLineInfo;
    } else {
      DFillLines = lineInfoDetails;
    }

    const shippingArray = DFillLines?.map((lineInfo) => {
      const { miniImage, deviceDescription, numberOfItems } = getCartItemDeviceDetails(lineInfo);
      const { shippingDataShippingOption, shippingDataAddress } = loadShippingData(lineInfo);
      const shippingOptions = getShippingOptions(lineInfo.multiLineSeqNumber);
      const addresses = getAddressOptions();
      const uniqueAddresses = Array.from(new Set(addresses?.map((address) => address.uniqueAddressString)))?.map(
        (uniqueAddressString) => addresses.find((s) => s.uniqueAddressString === uniqueAddressString),
      );
      const radioButtonData = [];
      const dropDownaddressOptions = uniqueAddresses?.map((item) => {
        const streetAddressInfo = item?.address?.addressLine1;
        radioButtonData.push({
          name: 'addressOption',
          value: streetAddressInfo,
          children: <React.Fragment> {streetAddressInfo}</React.Fragment>,
        });
        return {
          label: streetAddressInfo,
          value: item?.address,
          key: item?.address.lineNo,
        };
      });
      const newAddressText = 'New Shipping address';
      radioButtonData.push({
        name: 'addressOption',
        value: newAddressText,
        children: <React.Fragment> {newAddressText}</React.Fragment>,
      });
      const dropDownShippingOptions = shippingOptions?.map((item, ind) => ({
        label: item?.shippingDescription || item?.shortDescription,
        value: item,
        key: ind,
      }));

      let selectedAddress = null;
      const selectedShippingDetails = shippingDataAddress;
      if (selectedShippingDetails) {
        selectedAddress = selectedShippingDetails;
      } else if (!selectedAddress && dropDownaddressOptions?.length > 0) {
        selectedAddress = dropDownaddressOptions?.[0]?.value;
        dropDownaddressOptions.forEach((address) => {
          if (parseInt(address.value.lineNo, 10) === lineInfo.multiLineSeqNumber) {
            selectedAddress = address.value;
          }
        });
      }
      const attention = lineInfo?.itemsInfo?.[0]?.attention;
      const addressData = {
        multiLineSeqNumber: lineInfo.multiLineSeqNumber,
        attention,
        fipsCode: lineInfo?.itemsInfo?.[0]?.fipsCode,
        ruralRouteNo: '',
        ...selectedAddress,
      };
      const streetAddress =
        selectedAddress?.addressLine1 || selectedAddress?.streetName || selectedAddress?.streetNumber;

      AddressOptionsArray = [...AddressOptionsArray, addressData];
      const selectedOption = shippingDataShippingOption;
      const shippingData = {
        multiLineSeqNumber: lineInfo?.multiLineSeqNumber,
        depletionLocation: '',
        fipsCode: lineInfo?.itemsInfo?.[0]?.fipsCode,
        ...selectedOption,
      };
      ShippingOptionsArray = [...ShippingOptionsArray, shippingData];
      const mtn = lineInfo?.serviceInfo?.mtn;
      const itemCount = lineInfo?.itemsInfo?.[0]?.itemCount;
      const { multiLineSeqNumber } = lineInfo;
      const fipsCode = lineInfo?.itemsInfo?.[0]?.fipsCode;
      const data = {
        miniImage,
        deviceDescription,
        numberOfItems,
        shippingData,
        streetAddress,
        dropDownShippingOptions,
        dropDownaddressOptions,
        mtn,
        itemCount,
        multiLineSeqNumber,
        attention,
        fipsCode,
        lineInfo,
        radioButtonData,
      };
      return data;
    });
    setUpdatedAddressOptions(AddressOptionsArray);
    setUpdatedShippingOptions(ShippingOptionsArray);
    setMultipleShippingArray(shippingArray);
  }, [uniqueAddressLists]);

  return (
    showShipToMultipleModal && (
      <MultipleShippingModalContainer>
        <MultipleShippingInnerContainer>
          <MultipleShippingHeaderContainer data-testid='header'>
            <FlexAlignContainerItemsCenter>
              <FlexBoxGrowOne>
                <ShopWrapper>
                  <Title size='small' bold primitive='h1'>
                    Change Shipping Details
                  </Title>
                </ShopWrapper>
              </FlexBoxGrowOne>
              <CloseIconWrapper>
                <BlackClickable
                  data-testid='close-link'
                  onClick={() => setShowShipToMultipleModal(!showShipToMultipleModal)}
                >
                  <Icon name='close' size='large' />
                </BlackClickable>
              </CloseIconWrapper>
            </FlexAlignContainerItemsCenter>
            <Line type='primary' />
          </MultipleShippingHeaderContainer>
          <MultipleShippingBodyContainer>
            <Tiles>
              <Col35> </Col35>
              <ColHeader>Shipping Address</ColHeader>
              <ColHeader>Shipping Options</ColHeader>
            </Tiles>
            <HorizontalLine />
            {multipleShippingArray?.map((item) => (
              <MultipleShippingContent
                miniImage={item?.miniImage}
                deviceDescription={item?.deviceDescription}
                numberOfItems={item?.numberOfItems}
                shippingMethod={item?.shippingData}
                streetAddress={item?.streetAddress}
                dropDownShippingOptions={item?.dropDownShippingOptions}
                dropDownaddressOptions={item?.dropDownaddressOptions}
                mtn={item?.mtn}
                itemCount={item?.itemCount}
                multiLineSeqNumber={item?.multiLineSeqNumber}
                fipsCode={item?.fipsCode}
                updatedShippingOptions={updatedShippingOptions}
                updatedAddressOptions={updatedAddressOptions}
                setUpdatedAddressOptions={setUpdatedAddressOptions}
                setUpdatedShippingOptions={setUpdatedShippingOptions}
                key={item}
                attention={item?.attention}
                radioButtonData={item?.radioButtonData}
                cartHeader={CartDetailsResult?.cartHeader}
                getUniqueAddresses={getUniqueAddresses}
              />
            ))}
            <ShippingInfoContainer>
              <span>{isQAFlow ? QAOrderNote : orderNote}</span>
            </ShippingInfoContainer>
          </MultipleShippingBodyContainer>
          <FooterContainer>
            <MarginAuto>
              <Button width={140} onClick={handleSave}>
                Save
              </Button>
            </MarginAuto>
          </FooterContainer>
        </MultipleShippingInnerContainer>
      </MultipleShippingModalContainer>
    )
  );
};

MultipleShippingModal.propTypes = {
  showShipToMultipleModal: PropTypes.bool,
  setShowShipToMultipleModal: PropTypes.func,
  lineItems: PropTypes.array,
  getShippingOptionsOfAllLines: PropTypes.array,
  updateShippingOptionBody: PropTypes.func,
  CartDetailsResult: PropTypes.array,
  CustomerProfileResult: PropTypes.object,
  isQAFlow: PropTypes.bool,
};

export default MultipleShippingModal;
