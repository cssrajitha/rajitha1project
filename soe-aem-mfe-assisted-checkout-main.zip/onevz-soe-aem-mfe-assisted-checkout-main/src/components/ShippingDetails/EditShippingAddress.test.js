import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../modules/store';
import EditShippinAddress from './EditShippingAddress';
import cartJson from '../../__mock__/shipping-retrive-cart.json';
import lineDetailsJson from '../../__mock__/AlternateLineDetails.json';
import splitLineDetailsJson from './_mock_/SplitLineDetails.json';

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => jest.fn(),
}));

jest.mock('./MultipleShippingModal', () => ({
  __esModule: true,
  default: () => <div>Multiple shipping modal</div>,
}));

jest.mock('../../modules/services/APIService/APIServiceCallHook', () => ({
  ...jest.requireActual('../../modules/services/APIService/APIServiceCallHook'),
  useLazyGetCartDetailsQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: {
        data: {
          cart: {
            orderDetails: { totalShippingCost: 10 },
          },
        },
      },
    },
  ],
}));

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),

  useLazyTypeaheadQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: {
        addresses: [
          {
            zip: '96266',
            locusID: '400001104568',
            baseAddID: 'B',
            disprawstr: '3 PSC 3 BOX 3, APO, AP, 96266, USA',
            dispstr: '3 PSC 3 BOX 3',
            muni: 'APO',
            houseNumber: '3',
            state: 'AP',
            locusLocation: '37.7749,-122.4194',
          },
          {
            zip: '54762',
            locusID: '400343642669',
            baseAddID: 'B',
            disprawstr: '3 3 2 3/4 AVE, PRAIRIE FARM, WI, 54762, USA',
            dispstr: '3 3 2 3/4 AVE',
            muni: 'PRAIRIE FARM',
            houseNumber: '3',
            state: 'WI',
            locusLocation: '45.2521,-91.9972',
          },
        ],
      },
    },
  ],
}));

jest.mock('./TypeAheadBox', () => ({
  __esModule: true,
  default: ({ handleAddressSelction }) => (
    <div>
      <button type='button' data-testid='mocked-nbs' onClick={() => handleAddressSelction()}>
        AddressSelection
      </button>
    </div>
  ),
}));

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
  useLazyGetAccountAddressesQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: {
        addressDetails: [
          {
            addrType: 'RD',
            addressLine1: '1900 KNIGHTSBRIDGE RD APT 1102 ',
            apartmentNo: '1102',
            city: 'DALLAS',
            countryCode: '',
            emailId: 'sivaram.java9@gmail.com',
            firstName: 'SIVA',
            lastName: 'MFE',
            lineNo: '1',
            phoneNumber: '4074449999',
            state: 'TX',
            streetName: 'KNIGHTSBRIDGE',
            streetNumber: '1900',
            zipCode: '75234',
            zipCode4: '1356',
          },
        ],
      },
    },
  ],
}));

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
  useLazyUpdateShippingAddressAndOptionsQuery: () => [
    jest.fn().mockImplementation(() =>
      Promise.resolve({
        data: {},
      }),
    ),
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
    },
  ],
}));

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
  useLazyUpdateShippingAddressQAQuery: () => [
    jest.fn().mockImplementation(() =>
      Promise.resolve({
        data: {
          data: {
            cartId: '07dcb2ba-a48c-420f-bd68-3bee6be6265f',
            lines: [
              {
                ispuEligible: false,
                selectedOptionCode: 'ECONOMYSHP',
                shipContactInfoMissing: false,
                shippingOptions: [
                  {
                    active: false,
                    addedShippingOptionId: false,
                    description: 'Estimated to arrive on Mon, Apr 21. ECONOMY 3-5 DAYS - FREE.',
                    discounted: false,
                    estDeliveryDate: '2025-04-21T00:00:00Z',
                    estimatedDeliveryDate: '2025-04-21 00:00:00',
                    estimatedDeliveryDateText: 'Mon, Apr 21',
                    freeOvernightShipping: false,
                    shippingCost: 0,
                    shippingDescription: 'ECONOMY 3-5 DAYS - FREE',
                    shippingOptionId: 'ECONOMYSHP',
                    shortDescription: 'ECONOMY 3-5 DAYS - FREE',
                    signatureRequired: 'false',
                    twoDayShipping: false,
                  },
                  {
                    active: false,
                    addedShippingOptionId: true,
                    description: 'Estimated to arrive on Fri, Apr 18. 2 DAY BY 8PM. Signature required.',
                    discounted: false,
                    estDeliveryDate: '2025-04-18T00:00:00Z',
                    estimatedDeliveryDate: '2025-04-18 00:00:00',
                    estimatedDeliveryDateText: 'Fri, Apr 18',
                    freeOvernightShipping: false,
                    shippingCost: 7,
                    shippingDescription: '2 DAY BY 8PM',
                    shippingOptionId: 'SHP003',
                    shortDescription: '2 DAY BY 8PM',
                    signatureRequired: 'true',
                    twoDayShipping: false,
                  },
                  {
                    active: false,
                    addedShippingOptionId: false,
                    description: 'Estimated to arrive on Thu, Apr 17. NEXT DAY BY 8PM. Signature required.',
                    discounted: false,
                    estDeliveryDate: '2025-04-17T00:00:00Z',
                    estimatedDeliveryDate: '2025-04-17 00:00:00',
                    estimatedDeliveryDateText: 'Thu, Apr 17',
                    freeOvernightShipping: false,
                    shippingCost: 12.99,
                    shippingDescription: 'NEXT DAY BY 8PM',
                    shippingOptionId: 'SHP004',
                    shortDescription: 'NEXT DAY BY 8PM',
                    signatureRequired: 'true',
                    twoDayShipping: false,
                  },
                ],
                shipTogetherPref: true,
                showISPUErrorMessage: false,
                showSDDErrorMessage: false,
                youngTenureCustomer: false,
              },
            ],
          },
        },
      }),
    ),
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: {
        data: {
          cartId: '07dcb2ba-a48c-420f-bd68-3bee6be6265f',
          lines: [
            {
              ispuEligible: false,
              selectedOptionCode: 'ECONOMYSHP',
              shipContactInfoMissing: false,
              shippingOptions: [
                {
                  active: false,
                  addedShippingOptionId: false,
                  description: 'Estimated to arrive on Mon, Apr 21. ECONOMY 3-5 DAYS - FREE.',
                  discounted: false,
                  estDeliveryDate: '2025-04-21T00:00:00Z',
                  estimatedDeliveryDate: '2025-04-21 00:00:00',
                  estimatedDeliveryDateText: 'Mon, Apr 21',
                  freeOvernightShipping: false,
                  shippingCost: 0,
                  shippingDescription: 'ECONOMY 3-5 DAYS - FREE',
                  shippingOptionId: 'ECONOMYSHP',
                  shortDescription: 'ECONOMY 3-5 DAYS - FREE',
                  signatureRequired: 'false',
                  twoDayShipping: false,
                },
                {
                  active: false,
                  addedShippingOptionId: true,
                  description: 'Estimated to arrive on Fri, Apr 18. 2 DAY BY 8PM. Signature required.',
                  discounted: false,
                  estDeliveryDate: '2025-04-18T00:00:00Z',
                  estimatedDeliveryDate: '2025-04-18 00:00:00',
                  estimatedDeliveryDateText: 'Fri, Apr 18',
                  freeOvernightShipping: false,
                  shippingCost: 7,
                  shippingDescription: '2 DAY BY 8PM',
                  shippingOptionId: 'SHP003',
                  shortDescription: '2 DAY BY 8PM',
                  signatureRequired: 'true',
                  twoDayShipping: false,
                },
                {
                  active: false,
                  addedShippingOptionId: false,
                  description: 'Estimated to arrive on Thu, Apr 17. NEXT DAY BY 8PM. Signature required.',
                  discounted: false,
                  estDeliveryDate: '2025-04-17T00:00:00Z',
                  estimatedDeliveryDate: '2025-04-17 00:00:00',
                  estimatedDeliveryDateText: 'Thu, Apr 17',
                  freeOvernightShipping: false,
                  shippingCost: 12.99,
                  shippingDescription: 'NEXT DAY BY 8PM',
                  shippingOptionId: 'SHP004',
                  shortDescription: 'NEXT DAY BY 8PM',
                  signatureRequired: 'true',
                  twoDayShipping: false,
                },
              ],
              shipTogetherPref: true,
              showISPUErrorMessage: false,
              showSDDErrorMessage: false,
              youngTenureCustomer: false,
            },
          ],
        },
      },
    },
  ],
  useLazyGetValidateCartAndCheckoutQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
    },
  ],
  useLazyUpdateShippingOptionsQuery: () => [
    jest.fn().mockImplementation(() =>
      Promise.resolve({
        data: {},
      }),
    ),
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
    },
  ],
}));

const performFormFill = () => {
  const titleElement = screen.getByTestId('editDetails');
  expect(titleElement).toBeInTheDocument();

  const nameInput = screen.getByLabelText(/Name*/i, { selector: 'input' });

  fireEvent.change(nameInput, { target: { value: 'Ethan James' } });
  expect(nameInput.value).toBe('Ethan James');

  const streetAddInput = screen.getByLabelText(/Street Address/i, { selector: 'input' });

  fireEvent.change(streetAddInput, { target: { value: '1037 BARKEY' } });
  expect(streetAddInput.value).toBe('1037 BARKEY');

  const attnInput = screen.getByLabelText(/ATTN/i, { selector: 'input' });

  fireEvent.change(attnInput, { target: { value: '103' } });
  expect(attnInput.value).toBe('103');

  fireEvent.change(attnInput, { target: { value: '' } });

  const aptSuiteInput = screen.getByLabelText(/Apt\/Suite/i, { selector: 'input' });

  fireEvent.change(aptSuiteInput, { target: { value: '103' } });
  expect(aptSuiteInput.value).toBe('103');
  fireEvent.change(aptSuiteInput, { target: { value: '' } });

  const phInput = screen.getByLabelText(/Can be Reached/i, { selector: 'input' });

  fireEvent.change(phInput, { target: { value: '4819241446' } });
  expect(phInput.value).toBe('4819241446');

  const emailInput = screen.getByLabelText(/Email Address/i, { selector: 'input' });

  fireEvent.change(emailInput, { target: { value: 'ABC@VERIZON.COM' } });
  expect(emailInput.value).toBe('ABC@VERIZON.COM');

  const zipInput = screen.getByLabelText(/Zip Code/i, { selector: 'input' });

  fireEvent.change(zipInput, { target: { value: '16127' } });
  expect(zipInput.value).toBe('16127');
};

describe('Edit Shipping Address Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
    window.mfe = { scmUpgradeMfeEnable: true };
  });
  beforeEach(() => {
    const customerProfile = cartJson?.data?.cart?.customerProfile;
    const orderDetails = cartJson?.data?.cart?.orderDetails;
    const lineDetails = cartJson?.data?.cart?.lineDetails;
    const listmtns = ['7243728622', '7249675773'];
    const selectedShippingOption = {
      shippingOptionId: 'SDD_SAMEDAY',
    };
    sessionStorage.setItem('prevTotalShippingCost', 0);
    sessionStorage.setItem('newPostToPreIndicator', 'Y');
    sessionStorage.setItem('customerType', 'N');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'FALSE' }));
    jest.useFakeTimers();
    render(
      <BrowserRouter>
        <StoreProvider>
          <EditShippinAddress
            customerProfile={customerProfile}
            orderDetails={orderDetails}
            lineDetails={lineDetails}
            mtnList={listmtns}
            selectedShippingOption={selectedShippingOption}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('renders Edit form', async () => {
    await waitFor(() => {
      performFormFill();
    });
  });

  test('Save button click', async () => {
    await waitFor(() => {
      const saveBtn = screen.getByText('Save');

      const nameInput = screen.getByLabelText('Name*', { selector: 'input' });

      fireEvent.change(nameInput, { target: { value: 'Ethan Bond 1' } });
      expect(nameInput.value).toBe('Ethan Bond 1');
      fireEvent.click(saveBtn);
    });
  });

  test('Change dropdown', async () => {
    await waitFor(() => {
      const cistyStateDropDown = screen.getByTestId('cityState');
      fireEvent.change(cistyStateDropDown);
    });
  });

  test('Change address type', async () => {
    await waitFor(() => {
      const addressRadio = screen.getByText('Business Address');
      fireEvent.click(addressRadio);
    });
  });

  test('terms and address checkbox check', async () => {
    await waitFor(() => {
      const termsCheckBox = screen.getByText('Send text messages for order confirmation and shipping notifications');
      fireEvent.click(termsCheckBox);

      const okBtn = screen.getByTestId('ok-btn');
      expect(okBtn).toBeInTheDocument();
      fireEvent.click(okBtn);

      const keppAddCheckbox = screen.getByText('Keep Current Address');
      fireEvent.click(keppAddCheckbox);
    });
  });

  test('typeAhead', async () => {
    const streetAddInput = screen.getByLabelText(/Street Address/i, { selector: 'input' });
    fireEvent.change(streetAddInput, { target: { value: '3' } });
    jest.advanceTimersByTime(1000);

    const addSelection = screen.getByText('AddressSelection');
    fireEvent.click(addSelection);
  });

  test('mdn-selection check', async () => {
    const dropdown = screen.getByTestId('mdn-selection');
    expect(dropdown).toBeInTheDocument();
    fireEvent.change(dropdown);
  });
});

describe('alternateLineDetails info', () => {
  beforeEach(() => {
    const customerProfile = cartJson?.data?.cart?.customerProfile;
    const orderDetails = cartJson?.data?.cart?.orderDetails;
    const lineDetails = lineDetailsJson;
    const listmtns = ['7243728622', '7249675773'];
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'FALSE' }));
    const selectedShippingOption = {
      shippingOptionId: 'SDD_SAMEDAY',
    };
    const CustomerProfileResult = {
      data: {
        data: {
          commonInfo: {
            isIndirect: true,
          },
        },
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditShippinAddress
            customerProfile={customerProfile}
            orderDetails={orderDetails}
            lineDetails={lineDetails}
            mtnList={listmtns}
            selectedShippingOption={selectedShippingOption}
            CustomerProfileResult={CustomerProfileResult}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('renders Edit form', async () => {
    await waitFor(() => {
      performFormFill();
    });
  });
});
describe('alternateLineDetails ahippingOption', () => {
  beforeEach(() => {
    const customerProfile = cartJson?.data?.cart?.customerProfile;
    const orderDetails = cartJson?.data?.cart?.orderDetails;
    const lineDetails = splitLineDetailsJson;
    const cartDetailsResult = {
      orderDetails: {
        itemLevelShipment: true,
        orderList: [
          {
            creditApplication: {
              creditApplicationNum: 1234,
            },
          },
        ],
      },
    };
    const listmtns = ['7243728622', '7249675773'];
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'TRUE' }));
    sessionStorage.setItem('intentType', 'AAL');

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditShippinAddress
            customerProfile={customerProfile}
            orderDetails={orderDetails}
            lineDetails={lineDetails}
            mtnList={listmtns}
            CartDetailsResult={cartDetailsResult}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('renders Edit form', async () => {
    await waitFor(() => {
      performFormFill();
      const addressRadio = screen.getByText('Business Address');
      fireEvent.click(addressRadio);
      const saveBtn = screen.getByText('Save');
      const zipInput = screen.getByLabelText(/Zip Code/i, { selector: 'input' });
      fireEvent.change(zipInput, { target: { value: '16127-0001' } });
      fireEvent.click(saveBtn);
      fireEvent.click(saveBtn);
    });
  });
  test('renders Edit form', async () => {
    await waitFor(() => {
      const addressRadio = screen.getByText('Business Address');
      fireEvent.click(addressRadio);
      performFormFill();
      const saveBtn = screen.getByText('Save');
      fireEvent.click(saveBtn);
      fireEvent.click(saveBtn);
    });
  });
});
describe('alternateLineDetails shippingOption attn', () => {
  beforeEach(() => {
    const customerProfile = cartJson?.data?.cart?.customerProfile;
    const orderDetails = cartJson?.data?.cart?.orderDetails;
    const lineDetails = splitLineDetailsJson;
    const cartDetailsResult = {
      orderDetails: {
        itemLevelShipment: true,
        orderList: [
          {
            creditApplication: {
              creditApplicationNum: 1234,
            },
          },
        ],
      },
      lineDetails: {
        lineInfo: [
          {
            itemsInfo: [
              {
                shipping: {
                  address: {
                    firstName: 'TEST',
                  },
                },
              },
            ],
          },
        ],
      },
    };
    const listmtns = ['7243728622', '7249675773'];
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'TRUE', msfToNsaQuickAccessoriesFFlag: 'TRUE' }),
    );
    sessionStorage.setItem('intentType', 'AAL');

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditShippinAddress
            customerProfile={customerProfile}
            orderDetails={orderDetails}
            lineDetails={lineDetails}
            mtnList={listmtns}
            CartDetailsResult={cartDetailsResult}
            isQAFlow
            setShippingOptionsForQA={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('renders Edit form', async () => {
    await waitFor(() => {
      performFormFill();
      const addressRadio = screen.getByText('Business Address');
      fireEvent.click(addressRadio);
      const saveBtn = screen.getByText('Save');
      const zipInput = screen.getByLabelText(/Zip Code/i, { selector: 'input' });
      fireEvent.change(zipInput, { target: { value: '16127-0001' } });
      fireEvent.click(saveBtn);
      fireEvent.click(saveBtn);
    });
  });
  test('renders Edit form', async () => {
    await waitFor(() => {
      const addressRadio = screen.getByText('Business Address');
      fireEvent.click(addressRadio);
      performFormFill();
      const saveBtn = screen.getByText('Save');
      fireEvent.click(saveBtn);
      fireEvent.click(saveBtn);
    });
  });
});
describe('alternateLineDetails shippingOption attn QA', () => {
  beforeEach(() => {
    const customerProfile = cartJson?.data?.cart?.customerProfile;
    const orderDetails = cartJson?.data?.cart?.orderDetails;
    const lineDetails = splitLineDetailsJson;
    const cartDetailsResult = {
      orderDetails: {
        itemLevelShipment: true,
        orderList: [
          {
            creditApplication: {
              creditApplicationNum: 1234,
            },
          },
        ],
      },
    };
    const listmtns = ['7243728622', '7249675773'];
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'TRUE', msfToNsaQuickAccessoriesFFlag: 'FALSE' }),
    );
    sessionStorage.setItem('intentType', 'AAL');

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditShippinAddress
            customerProfile={customerProfile}
            orderDetails={orderDetails}
            lineDetails={lineDetails}
            mtnList={listmtns}
            CartDetailsResult={cartDetailsResult}
            isQAFlow
            setShippingOptionsForQA={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('renders Edit form', async () => {
    await waitFor(() => {
      performFormFill();
      const addressRadio = screen.getByText('Business Address');
      fireEvent.click(addressRadio);
      const saveBtn = screen.getByText('Save');
      const zipInput = screen.getByLabelText(/Zip Code/i, { selector: 'input' });
      fireEvent.change(zipInput, { target: { value: '16127-0001' } });
      fireEvent.click(saveBtn);
      fireEvent.click(saveBtn);
    });
  });
  test('renders Edit form', async () => {
    await waitFor(() => {
      const addressRadio = screen.getByText('Business Address');
      fireEvent.click(addressRadio);
      performFormFill();
      const saveBtn = screen.getByText('Save');
      fireEvent.click(saveBtn);
      fireEvent.click(saveBtn);
    });
  });
});
describe('Edit Shipping Address Component', () => {
  beforeEach(() => {
    const customerProfile = cartJson?.data?.cart?.customerProfile;
    const orderDetails = cartJson?.data?.cart?.orderDetails;
    const lineDetails = cartJson?.data?.cart?.lineDetails;
    const listmtns = ['7243728622', '7249675773'];
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'FALSE' }));
    sessionStorage.setItem('intentType', 'AAL');
    const CustomerProfileResult = {
      data: {
        data: {
          commonInfo: {
            isIndirect: false,
          },
        },
      },
    };
    const selectedShippingOption = {
      shippingOptionId: 'SHP018',
    };
    const cartDetailsResult = {
      orderDetails: {
        itemLevelShipment: true,
        orderList: [
          {
            creditApplication: {
              creditApplicationNum: 1234,
            },
          },
        ],
      },
    };
    window.mfe = { scmUpgradeMfeEnable: false };

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditShippinAddress
            customerProfile={customerProfile}
            orderDetails={orderDetails}
            lineDetails={lineDetails}
            mtnList={listmtns}
            CustomerProfileResult={CustomerProfileResult}
            selectedShippingOption={selectedShippingOption}
            CartDetailsResult={cartDetailsResult}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });
  // test('renders Edit form', async () => {
  //   await waitFor(() => {
  //     performFormFill();
  //     const multipleShippingText = screen.getByText('Ship to multiple locations');
  //     fireEvent.click(multipleShippingText);
  //     const modal = screen.getByText('Multiple shipping modal');
  //     expect(modal).toBeInTheDocument();
  //   });
  // });
  test('renders Edit form', async () => {
    await waitFor(() => {
      performFormFill();
      const saveBtn = screen.getByText('Save');

      fireEvent.click(saveBtn);
    });
  });
  test('renders Edit form with nofitification', async () => {
    await waitFor(() => {
      performFormFill();
      const saveBtn = screen.getByText('Save');
      fireEvent.click(saveBtn);
      const closeNotification = screen.getByTestId('Notification-close-button');
      fireEvent.click(closeNotification);

      fireEvent.click(saveBtn);
    });
  });
});

describe('Edit Shipping Address Component', () => {
  beforeEach(() => {
    const customerProfile = cartJson?.data?.cart?.customerProfile;
    const orderDetails = cartJson?.data?.cart?.orderDetails;
    const lineDetails = cartJson?.data?.cart?.lineDetails;
    const listmtns = ['7243728622', '7249675773'];
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'FALSE' }));
    const CustomerProfileResult = {
      data: {
        data: {
          commonInfo: {
            isIndirect: false,
          },
        },
      },
    };
    const selectedShippingOption = {
      shippingOptionId: 'SHP018',
    };
    const cartDetailsResult = {
      orderDetails: {
        itemLevelShipment: true,
        orderList: [
          {
            creditApplication: {
              creditApplicationNum: 1234,
            },
          },
        ],
      },
    };
    window.mfe = { scmUpgradeMfeEnable: false };

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditShippinAddress
            customerProfile={customerProfile}
            orderDetails={orderDetails}
            lineDetails={lineDetails}
            mtnList={listmtns}
            CustomerProfileResult={CustomerProfileResult}
            selectedShippingOption={selectedShippingOption}
            CartDetailsResult={cartDetailsResult}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });
  test('renders Edit form with nofitification', async () => {
    await waitFor(() => {
      performFormFill();
      const saveBtn = screen.getByText('Save');
      fireEvent.click(saveBtn);
      const closeNotification = screen.getByTestId('Notification-close-button');
      fireEvent.click(closeNotification);

      fireEvent.click(saveBtn);
    });
  });
});

describe('Edit Shipping Address Component', () => {
  beforeEach(() => {
    const customerProfile = cartJson?.data?.cart?.customerProfile;
    const orderDetails = cartJson?.data?.cart?.orderDetails;
    const lineDetails = cartJson?.data?.cart?.lineDetails;
    const listmtns = ['7243728622', '7249675773'];
    const CustomerProfileResult = {
      data: {
        data: {
          commonInfo: {
            isIndirect: false,
          },
        },
      },
    };

    const CartDetailsResult = {
      orderDetails: {
        customerType: 'N',
      },
    };
    const selectedShippingOption = {
      shippingOptionId: 'SHP018',
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditShippinAddress
            customerProfile={customerProfile}
            orderDetails={orderDetails}
            lineDetails={lineDetails}
            mtnList={listmtns}
            CustomerProfileResult={CustomerProfileResult}
            selectedShippingOption={selectedShippingOption}
            CartDetailsResult={CartDetailsResult}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });
  test('renders new customer', () => {
    const keppAddCheckbox = screen.getByText('Keep Current Address');
    expect(keppAddCheckbox).toBeInTheDocument();
  });
});

describe('Edit Shipping Address Component', () => {
  beforeEach(() => {
    sessionStorage.setItem('prevTotalShippingCost', 100);
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'FALSE' }));
    sessionStorage.setItem('intentType', 'AAL');

    window.mfe = { scmUpgradeMfeEnable: false };
  });
  test('renders Edit form', async () => {
    const customerProfile = cartJson?.data?.cart?.customerProfile;
    const orderDetails = cartJson?.data?.cart?.orderDetails;
    const lineDetails = cartJson?.data?.cart?.lineDetails;
    const listmtns = ['7243728622', '7249675773'];
    const CustomerProfileResult = {
      data: {
        data: {
          commonInfo: {
            isIndirect: false,
          },
        },
      },
    };
    const selectedShippingOption = {
      shippingOptionId: 'SHP018',
    };
    const cartDetailsResult = {
      orderDetails: {
        itemLevelShipment: true,
        orderList: [
          {
            creditApplication: {
              creditApplicationNum: 1234,
            },
          },
        ],
      },
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <EditShippinAddress
            customerProfile={customerProfile}
            orderDetails={orderDetails}
            lineDetails={lineDetails}
            mtnList={listmtns}
            CustomerProfileResult={CustomerProfileResult}
            selectedShippingOption={selectedShippingOption}
            CartDetailsResult={cartDetailsResult}
            isFromRefundOrderView
            closeModal={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });
});

describe('Edit Shipping Address Component - isQAFlow', () => {
  beforeEach(() => {
    sessionStorage.setItem('prevTotalShippingCost', 100);
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'FALSE' }));
    sessionStorage.setItem('intentType', 'AAL');

    window.mfe = { scmUpgradeMfeEnable: false };
  });
  test('renders Edit form', async () => {
    const customerProfile = cartJson?.data?.cart?.customerProfile;
    const orderDetails = cartJson?.data?.cart?.orderDetails;
    const lineDetails = cartJson?.data?.cart?.lineDetails;
    const listmtns = ['7243728622', '7249675773'];
    const CustomerProfileResult = {
      data: {
        data: {
          commonInfo: {
            isIndirect: false,
          },
        },
      },
    };
    const selectedShippingOption = {
      shippingOptionId: 'SHP018',
    };
    const cartDetailsResult = {
      orderDetails: {
        itemLevelShipment: true,
        orderList: [
          {
            creditApplication: {
              creditApplicationNum: 1234,
            },
          },
        ],
      },
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <EditShippinAddress
            customerProfile={customerProfile}
            orderDetails={orderDetails}
            lineDetails={lineDetails}
            mtnList={listmtns}
            CustomerProfileResult={CustomerProfileResult}
            selectedShippingOption={selectedShippingOption}
            CartDetailsResult={cartDetailsResult}
            isFromRefundOrderView
            closeModal={jest.fn()}
            isQAFlow
            setShippingOptionsForQA={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    await waitFor(() => {
      performFormFill();
      const saveBtn = screen.getByText('Save');
      fireEvent.click(saveBtn);
      const closeNotification = screen.getByTestId('Notification-close-button');
      fireEvent.click(closeNotification);

      fireEvent.click(saveBtn);
    });
  });

  test('renders Edit form - with selected shipping option', async () => {
    const customerProfile = cartJson?.data?.cart?.customerProfile;
    const orderDetails = cartJson?.data?.cart?.orderDetails;
    const lineDetails = cartJson?.data?.cart?.lineDetails;
    const listmtns = ['7243728622', '7249675773'];
    const CustomerProfileResult = {
      data: {
        data: {
          commonInfo: {
            isIndirect: false,
          },
        },
      },
    };
    const cartDetailsResult = {
      orderDetails: {
        itemLevelShipment: true,
        orderList: [
          {
            creditApplication: {
              creditApplicationNum: 1234,
            },
          },
        ],
      },
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <EditShippinAddress
            customerProfile={customerProfile}
            orderDetails={orderDetails}
            lineDetails={lineDetails}
            mtnList={listmtns}
            CustomerProfileResult={CustomerProfileResult}
            selectedShippingOption={{
              shippingOptionId: 'SHP003',
            }}
            CartDetailsResult={cartDetailsResult}
            isFromRefundOrderView
            closeModal={jest.fn()}
            isQAFlow
            setShippingOptionsForQA={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    await waitFor(() => {
      performFormFill();
      const saveBtn = screen.getByText('Save');
      fireEvent.click(saveBtn);
      const closeNotification = screen.getByTestId('Notification-close-button');
      fireEvent.click(closeNotification);

      fireEvent.click(saveBtn);
    });
  });
});
describe('Edit Shipping Address Component - isQAFlow', () => {
  beforeEach(() => {
    sessionStorage.setItem('leadsUserRole', 'REP');
    sessionStorage.setItem('prevTotalShippingCost', 100);
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({ quickAccessoryCheckoutTaggingFFlag: 'TRUE', splitFulfilmentUIOrderReviewFFlag: 'FALSE' }),
    );
    sessionStorage.setItem('intentType', 'AAL');

    window.mfe = { scmUpgradeMfeEnable: false };
  });
  test('renders Edit form', async () => {
    const customerProfile = cartJson?.data?.cart?.customerProfile;
    const orderDetails = cartJson?.data?.cart?.orderDetails;
    const lineDetails = cartJson?.data?.cart?.lineDetails;
    const listmtns = ['7243728622', '7249675773'];
    const CustomerProfileResult = {
      data: {
        data: {
          commonInfo: {
            isIndirect: false,
          },
        },
      },
    };
    const selectedShippingOption = {
      shippingOptionId: 'SHP018',
    };
    const cartDetailsResult = {
      orderDetails: {
        itemLevelShipment: true,
        orderList: [
          {
            creditApplication: {
              creditApplicationNum: 1234,
            },
          },
        ],
      },
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <EditShippinAddress
            customerProfile={customerProfile}
            orderDetails={orderDetails}
            lineDetails={lineDetails}
            mtnList={listmtns}
            CustomerProfileResult={CustomerProfileResult}
            selectedShippingOption={selectedShippingOption}
            CartDetailsResult={cartDetailsResult}
            isFromRefundOrderView
            closeModal={jest.fn()}
            isQAFlow
            setShippingOptionsForQA={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    await waitFor(() => {
      performFormFill();
      const saveBtn = screen.getByText('Save');
      fireEvent.click(saveBtn);
      const closeNotification = screen.getByTestId('Notification-close-button');
      fireEvent.click(closeNotification);

      fireEvent.click(saveBtn);
    });
  });

  test('renders Edit form - with selected shipping option', async () => {
    const customerProfile = cartJson?.data?.cart?.customerProfile;
    const orderDetails = cartJson?.data?.cart?.orderDetails;
    const lineDetails = cartJson?.data?.cart?.lineDetails;
    const listmtns = ['7243728622', '7249675773'];
    const CustomerProfileResult = {
      data: {
        data: {
          commonInfo: {
            isIndirect: false,
          },
        },
      },
    };
    const cartDetailsResult = {
      orderDetails: {
        itemLevelShipment: true,
        orderList: [
          {
            creditApplication: {
              creditApplicationNum: 1234,
            },
          },
        ],
      },
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <EditShippinAddress
            customerProfile={customerProfile}
            orderDetails={orderDetails}
            lineDetails={lineDetails}
            mtnList={listmtns}
            CustomerProfileResult={CustomerProfileResult}
            selectedShippingOption={{
              shippingOptionId: 'SHP003',
            }}
            CartDetailsResult={cartDetailsResult}
            isFromRefundOrderView
            closeModal={jest.fn()}
            isQAFlow
            setShippingOptionsForQA={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    await waitFor(() => {
      performFormFill();
      const saveBtn = screen.getByText('Save');
      fireEvent.click(saveBtn);
      const closeNotification = screen.getByTestId('Notification-close-button');
      fireEvent.click(closeNotification);

      fireEvent.click(saveBtn);
    });
  });
});
describe('Edit Shipping Address Component - isQAFlow lead', () => {
  beforeEach(() => {
    sessionStorage.removeItem('leadsUserRole');
    sessionStorage.setItem('prevTotalShippingCost', 100);
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({ quickAccessoryCheckoutTaggingFFlag: 'TRUE', splitFulfilmentUIOrderReviewFFlag: 'FALSE' }),
    );
    sessionStorage.setItem('intentType', 'AAL');

    window.mfe = { scmUpgradeMfeEnable: false };
  });
  test('renders Edit form', async () => {
    const customerProfile = cartJson?.data?.cart?.customerProfile;
    const orderDetails = cartJson?.data?.cart?.orderDetails;
    const lineDetails = cartJson?.data?.cart?.lineDetails;
    const listmtns = ['7243728622', '7249675773'];
    const CustomerProfileResult = {
      data: {
        data: {
          commonInfo: {
            isIndirect: false,
          },
        },
      },
    };
    const selectedShippingOption = {
      shippingOptionId: 'SHP018',
    };
    const cartDetailsResult = {
      orderDetails: {
        itemLevelShipment: true,
        orderList: [
          {
            creditApplication: {
              creditApplicationNum: 1234,
            },
          },
        ],
      },
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <EditShippinAddress
            customerProfile={customerProfile}
            orderDetails={orderDetails}
            lineDetails={lineDetails}
            mtnList={listmtns}
            CustomerProfileResult={CustomerProfileResult}
            selectedShippingOption={selectedShippingOption}
            CartDetailsResult={cartDetailsResult}
            isFromRefundOrderView
            closeModal={jest.fn()}
            isQAFlow
            setShippingOptionsForQA={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    await waitFor(() => {
      performFormFill();
      const saveBtn = screen.getByText('Save');
      fireEvent.click(saveBtn);
      const closeNotification = screen.getByTestId('Notification-close-button');
      fireEvent.click(closeNotification);

      fireEvent.click(saveBtn);
    });
  });

  test('renders Edit form - with selected shipping option', async () => {
    const customerProfile = cartJson?.data?.cart?.customerProfile;
    const orderDetails = cartJson?.data?.cart?.orderDetails;
    const lineDetails = cartJson?.data?.cart?.lineDetails;
    const listmtns = ['7243728622', '7249675773'];
    const CustomerProfileResult = {
      data: {
        data: {
          commonInfo: {
            isIndirect: false,
          },
        },
      },
    };
    const cartDetailsResult = {
      orderDetails: {
        itemLevelShipment: true,
        orderList: [
          {
            creditApplication: {
              creditApplicationNum: 1234,
            },
          },
        ],
      },
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <EditShippinAddress
            customerProfile={customerProfile}
            orderDetails={orderDetails}
            lineDetails={lineDetails}
            mtnList={listmtns}
            CustomerProfileResult={CustomerProfileResult}
            selectedShippingOption={{
              shippingOptionId: 'SHP003',
            }}
            CartDetailsResult={cartDetailsResult}
            isFromRefundOrderView
            closeModal={jest.fn()}
            isQAFlow
            setShippingOptionsForQA={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    await waitFor(() => {
      performFormFill();
      const saveBtn = screen.getByText('Save');
      fireEvent.click(saveBtn);
      const closeNotification = screen.getByTestId('Notification-close-button');
      fireEvent.click(closeNotification);

      fireEvent.click(saveBtn);
    });
  });
});
describe('Edit Shipping Address Component - isDark prop tests', () => {
  beforeEach(() => {
    sessionStorage.removeItem('leadsUserRole');
    sessionStorage.setItem('prevTotalShippingCost', 100);
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({ quickAccessoryCheckoutTaggingFFlag: 'TRUE', splitFulfilmentUIOrderReviewFFlag: 'FALSE' }),
    );
    sessionStorage.setItem('intentType', 'AAL');
    window.mfe = { scmUpgradeMfeEnable: false };
  });

  test('renders Edit form with isDark=true - covers lines 82, 841, 845', async () => {
    const customerProfile = cartJson?.data?.cart?.customerProfile;
    const orderDetails = cartJson?.data?.cart?.orderDetails;
    const lineDetails = cartJson?.data?.cart?.lineDetails;
    const listmtns = ['7243728622', '7249675773'];
    const CustomerProfileResult = {
      data: {
        data: {
          commonInfo: {
            isIndirect: false,
          },
          customer: {
            cartId: 'test-cart-123',
            caseId: 'case-123',
            loggedInUser: 'testuser',
          },
        },
      },
    };
    const selectedShippingOption = {
      shippingOptionId: 'SHP018',
    };
    const cartDetailsResult = {
      orderDetails: {
        itemLevelShipment: true,
        customerType: 'E',
        orderList: [
          {
            creditApplication: {
              creditApplicationNum: 1234,
            },
          },
        ],
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditShippinAddress
            customerProfile={customerProfile}
            orderDetails={orderDetails}
            lineDetails={lineDetails}
            mtnList={listmtns}
            CustomerProfileResult={CustomerProfileResult}
            selectedShippingOption={selectedShippingOption}
            CartDetailsResult={cartDetailsResult}
            isDark={true}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    await waitFor(() => {
      const editDetails = screen.getByTestId('editDetails');
      expect(editDetails).toBeInTheDocument();
    });
  });

  test('renders Edit form with isDark=false - covers lines 82, 841, 845', async () => {
    const customerProfile = cartJson?.data?.cart?.customerProfile;
    const orderDetails = cartJson?.data?.cart?.orderDetails;
    const lineDetails = cartJson?.data?.cart?.lineDetails;
    const listmtns = ['7243728622', '7249675773'];
    const CustomerProfileResult = {
      data: {
        data: {
          commonInfo: {
            isIndirect: false,
          },
          customer: {
            cartId: 'test-cart-123',
            caseId: 'case-123',
            loggedInUser: 'testuser',
          },
        },
      },
    };
    const selectedShippingOption = {
      shippingOptionId: 'SHP018',
    };
    const cartDetailsResult = {
      orderDetails: {
        itemLevelShipment: true,
        customerType: 'E',
        orderList: [
          {
            creditApplication: {
              creditApplicationNum: 1234,
            },
          },
        ],
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditShippinAddress
            customerProfile={customerProfile}
            orderDetails={orderDetails}
            lineDetails={lineDetails}
            mtnList={listmtns}
            CustomerProfileResult={CustomerProfileResult}
            selectedShippingOption={selectedShippingOption}
            CartDetailsResult={cartDetailsResult}
            isDark={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    await waitFor(() => {
      const editDetails = screen.getByTestId('editDetails');
      expect(editDetails).toBeInTheDocument();
    });
  });

  test('renders unselect MDN dialog with isDark=true and clicks ok button - covers lines 841, 845', async () => {
    const customerProfile = cartJson?.data?.cart?.customerProfile;
    const orderDetails = cartJson?.data?.cart?.orderDetails;
    const lineDetails = cartJson?.data?.cart?.lineDetails;
    const listmtns = ['7243728622', '7249675773'];
    const CustomerProfileResult = {
      data: {
        data: {
          commonInfo: {
            isIndirect: false,
          },
          customer: {
            cartId: 'test-cart-123',
            caseId: 'case-123',
            loggedInUser: 'testuser',
          },
        },
      },
    };
    const selectedShippingOption = {
      shippingOptionId: 'SHP018',
    };
    const cartDetailsResult = {
      orderDetails: {
        itemLevelShipment: true,
        customerType: 'E',
        orderList: [
          {
            creditApplication: {
              creditApplicationNum: 1234,
            },
          },
        ],
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditShippinAddress
            customerProfile={customerProfile}
            orderDetails={orderDetails}
            lineDetails={lineDetails}
            mtnList={listmtns}
            CustomerProfileResult={CustomerProfileResult}
            selectedShippingOption={selectedShippingOption}
            CartDetailsResult={cartDetailsResult}
            isDark={true}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    await waitFor(() => {
      const checkbox = screen.getByText(/Send text messages for order confirmation and shipping notifications/i);
      expect(checkbox).toBeInTheDocument();
      
      // Uncheck the checkbox to trigger the dialog
      fireEvent.click(checkbox);
    });

    await waitFor(() => {
      const okButton = screen.getByTestId('ok-btn');
      expect(okButton).toBeInTheDocument();
      fireEvent.click(okButton);
    });
  });

  test('renders unselect MDN dialog with isDark=false and clicks ok button - covers lines 841, 845', async () => {
    const customerProfile = cartJson?.data?.cart?.customerProfile;
    const orderDetails = cartJson?.data?.cart?.orderDetails;
    const lineDetails = cartJson?.data?.cart?.lineDetails;
    const listmtns = ['7243728622', '7249675773'];
    const CustomerProfileResult = {
      data: {
        data: {
          commonInfo: {
            isIndirect: false,
          },
          customer: {
            cartId: 'test-cart-123',
            caseId: 'case-123',
            loggedInUser: 'testuser',
          },
        },
      },
    };
    const selectedShippingOption = {
      shippingOptionId: 'SHP018',
    };
    const cartDetailsResult = {
      orderDetails: {
        itemLevelShipment: true,
        customerType: 'E',
        orderList: [
          {
            creditApplication: {
              creditApplicationNum: 1234,
            },
          },
        ],
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditShippinAddress
            customerProfile={customerProfile}
            orderDetails={orderDetails}
            lineDetails={lineDetails}
            mtnList={listmtns}
            CustomerProfileResult={CustomerProfileResult}
            selectedShippingOption={selectedShippingOption}
            CartDetailsResult={cartDetailsResult}
            isDark={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    await waitFor(() => {
      const checkbox = screen.getByText(/Send text messages for order confirmation and shipping notifications/i);
      expect(checkbox).toBeInTheDocument();
      
      // Uncheck the checkbox to trigger the dialog
      fireEvent.click(checkbox);
    });

    await waitFor(() => {
      const okButton = screen.getByTestId('ok-btn');
      expect(okButton).toBeInTheDocument();
      fireEvent.click(okButton);
    });
  });

  test('renders Footer with isDark=true - covers line 82 background color', async () => {
    const customerProfile = cartJson?.data?.cart?.customerProfile;
    const orderDetails = cartJson?.data?.cart?.orderDetails;
    const lineDetails = cartJson?.data?.cart?.lineDetails;
    const listmtns = ['7243728622', '7249675773'];
    const CustomerProfileResult = {
      data: {
        data: {
          commonInfo: {
            isIndirect: false,
          },
          customer: {
            cartId: 'test-cart-123',
            caseId: 'case-123',
            loggedInUser: 'testuser',
          },
        },
      },
    };
    const selectedShippingOption = {
      shippingOptionId: 'SHP018',
    };
    const cartDetailsResult = {
      orderDetails: {
        itemLevelShipment: true,
        customerType: 'E',
        orderList: [
          {
            creditApplication: {
              creditApplicationNum: 1234,
            },
          },
        ],
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditShippinAddress
            customerProfile={customerProfile}
            orderDetails={orderDetails}
            lineDetails={lineDetails}
            mtnList={listmtns}
            CustomerProfileResult={CustomerProfileResult}
            selectedShippingOption={selectedShippingOption}
            CartDetailsResult={cartDetailsResult}
            isDark={true}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    await waitFor(() => {
      const saveButton = screen.getByText('Save');
      expect(saveButton).toBeInTheDocument();
    });
  });
});
