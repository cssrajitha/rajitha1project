import { RadioButtonGroup } from '@vds/radio-buttons';
import { Body } from '@vds/typography';
import PropTypes from 'prop-types';
import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import moment from 'moment';
import { useNavigate } from 'react-router-dom';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR } from '../constants/constants';
import { useShippingOptionsQuery } from '../../modules/services/APIService/APIServiceHooks';
import { isNSEQAFlow } from './FormUtils';

const Seperator = styled.div`
  position: relative;
  display: block;
  border-top: 0.07143rem solid rgb(216, 218, 218);
  padding-top: 0px;
  padding-bottom: 0px;
  margin: 0px;
  margin-top: 10px;
`;

const RadioButtonContainer = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr auto;
`;

const RadioTitleContainer = styled.div`
  grid-column: 1;
  width: 400px;
`;

const RadioAmountContainer = styled.div`
  grid-column: 3;
`;
const ShippingInfoContainer = styled.div`
  width: 100%;
  padding-top: 1.75rem;
  margin-left: 8%;
`;

const Container = styled.div`
  margin-top: 10px;
`;

const QAOrderNote = `__ Free 3 to 5 Day Ground Shipping is available for accessory orders purchased online Monday - Friday by 4:00 PM Local. Available for purchases placed on VerizonWireless.com for delivery within the U.S. only, excluding Alaska and Hawaii. Orders placed by 4:00 PM Local Monday - Friday excluding holidays will deliver in three (3) to five (5) business days. Overnight orders placed on Friday will not arrive until the following Monday.  All orders subject to credit authorization, verification and inventory availability. All orders under $49 must be placed by 4pm local time.`;

const orderNote = `Two day orders placed by 8 PM EST M-F and Saturday by 2 PM EST will ship same day. Overnight orders
completed by 11 PM EST will generally ship same day depending on inventory availability`;

const qaSelectShippingOption = `Please select one of the shipping options below`;

const nextDayQAORderNote = `__ Next Day Shipping with delivery by 8pm is available for purchases placed on VerizonWireless.com within the U.S. only, excluding Alaska and Hawaii. Orders will be delivered in one (1) business day from the date of your shipping notification email. Orders placed by 10:00pm ET Monday - Friday, 2:00pm Saturday excluding holidays will deliver in one (1) business day. Orders placed after 2:00pm local time on Saturday and before 10:00pm ET on Monday will deliver on Tuesday. All orders subject to credit authorization, verification and inventory availability. All orders under $49 must be placed by 4pm local time.`

function ShippingOptionsForm({
  setSelectedShippingOption,
  shippingAddress,
  cartId,
  setGetShippingOptionsOfAllLines,
  cartDetails,
  isQAFlow = false,
  shippingOptionsQA,
  selectedShippingOption = '',
  isDark = false,
}) {
  const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable;
  let navigate = '';
  function useNavigateMFE() {
    navigate = useNavigate();
  }
  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }

  const handleIspuSelected = () => {
    if (scmUpgradeMfeEnable) {
      window.Emitter?.emit('ACSS_SCM_SWITCH_TAB', { type: 'SWITCH_TAB', targetTab: 'DEVICE_TAB', isIspu: true });
    } else {
      navigate(`/sales/assisted/new/ispustorefinder.html`);
    }
  };

  const payload = {
    cartId,
    optimizeSDD: 'Y',
    shippingAddress: {
      apartmentNo: '',
      streetNumber: shippingAddress?.streetNumber,
      streetName: shippingAddress?.streetName,
      type: shippingAddress?.type,
      addressLine2: '',
      poBoxNo: '',
      ruralDelNo: '',
      city: shippingAddress?.city,
      state: shippingAddress?.state,
      zipCode: shippingAddress?.zipCode,
      zipCode4: shippingAddress?.zipCode4,
      countryCode: '',
    },
  };
  const defaultOption = 'SHP002';
  const skipShippingOptionsCall = !shippingAddress?.zipCode && isNSEQAFlow(isQAFlow, cartDetails);
  const ShippingOptionsResult = useShippingOptionsQuery(
    { body: payload, mock: false },
    { skip: skipShippingOptionsCall },
  );
  const [radioGroupData, setRadioGroupData] = useState([]);
  const shipLineData = ShippingOptionsResult?.data?.lines?.[0];
  const shippingOptionsData = shippingOptionsQA || shipLineData?.shippingOptions;
  const defaultSelectedShippingOption =
    shipLineData?.selectedOptionCode || shippingOptionsQA?.[0]?.shippingOptionId || defaultOption;
  const ispuEligible = shipLineData?.ispuEligible;
  const [isIspuSelected, setIsIspuSelected] = useState(false);

  const isIspuOption = shippingOptionsData?.find((opt) => opt.shippingOptionId === 'ISPU') || '';

  useEffect(() => {
    if (ShippingOptionsResult?.data) setGetShippingOptionsOfAllLines(ShippingOptionsResult?.data);
  }, [ShippingOptionsResult]);

  useEffect(() => {
    if (shippingOptionsQA?.[0]) {
      setSelectedShippingOption(shippingOptionsQA[0]);
    }
  }, [shippingOptionsQA]);

  const onShippingOptionChange = (e) => {
    if (e.target.value === 'ISPU') {
      setIsIspuSelected(true);
      setSelectedShippingOption({ shippingOptionId: 'ISPU' });
    } else {
      const selecetdShiptionOptionObj = shippingOptionsData?.find((opt) => opt.shippingOptionId === e.target.value);
      setSelectedShippingOption(selecetdShiptionOptionObj);
    }
  };

  useEffect(() => {
    const updatedOptions = shippingOptionsData?.map((item) => ({
      name: item.shippingOptionId,
      value: item.shippingOptionId,
      children: (
        <React.Fragment>
          <RadioButtonContainer>
            <RadioTitleContainer>
              <Body color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                {item.shippingDescription || item.shortDescription}{' '}
                {`(Expected delivery by ${moment(item?.estimatedDeliveryDate).format('MM/DD/YYYY')})`}
              </Body>
            </RadioTitleContainer>
            <RadioAmountContainer>
              <Body color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>{item.shippingCost ? `$${item.shippingCost}` : ''}</Body>
            </RadioAmountContainer>
          </RadioButtonContainer>

          <Seperator />
        </React.Fragment>
      ),
    }));
    if (updatedOptions && !isQAFlow && ispuEligible && isIspuOption === '') {
      updatedOptions.unshift({
        name: 'ISPU',
        value: 'ISPU',
        children: (
          <React.Fragment>
            <Body size='large' bold color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
              In Store Pick Up
            </Body>

            <Seperator />
          </React.Fragment>
        ),
      });
    }
    setRadioGroupData(updatedOptions);
  }, [shippingOptionsData]);

  return (
    <Container data-testid='shippingOptions'>
      {shippingOptionsQA && (
        <ShippingInfoContainer>
          <Body bold>{qaSelectShippingOption}</Body>
        </ShippingInfoContainer>
      )}
      {radioGroupData && radioGroupData.length > 0 && defaultSelectedShippingOption && (
        <>
          <RadioButtonGroup
            onChange={(e) => onShippingOptionChange(e)}
            error={false}
            data={radioGroupData}
            defaultValue={defaultSelectedShippingOption}
            surface={isDark ? 'dark' : 'light'}
          />
          {selectedShippingOption?.shippingDescription !== "NEXT DAY BY 8PM" &&<ShippingInfoContainer>
            <Body bold color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>{isQAFlow ? QAOrderNote : orderNote}</Body>
          </ShippingInfoContainer>}
          {selectedShippingOption?.shippingDescription === "NEXT DAY BY 8PM" &&<ShippingInfoContainer>
            <Body bold>{isQAFlow ? nextDayQAORderNote : orderNote}</Body>
          </ShippingInfoContainer>}
        </>
      )}
      {isIspuSelected && handleIspuSelected()}
    </Container>
  );
}

ShippingOptionsForm.propTypes = {
  setSelectedShippingOption: PropTypes.func,
  cartId: PropTypes.string,
  shippingAddress: PropTypes.shape({
    addressLine1: PropTypes.string,
    addressLine2: PropTypes.string,
    apartmentNo: PropTypes.string,
    city: PropTypes.string,
    countryCode: PropTypes.string,
    county: PropTypes.string,
    emailId: PropTypes.string,
    fipsCode: PropTypes.string,
    firmName: PropTypes.string,
    firstName: PropTypes.string,
    lastName: PropTypes.string,
    phoneNumber: PropTypes.string,
    poBoxNo: PropTypes.string,
    ruralDelNo: PropTypes.string,
    state: PropTypes.string,
    streetDirection: PropTypes.string,
    streetName: PropTypes.string,
    streetNumber: PropTypes.string,
    streetType: PropTypes.string,
    type: PropTypes.string,
    zipCode: PropTypes.string,
    zipCode4: PropTypes.string,
  }),
  setGetShippingOptionsOfAllLines: PropTypes.func,
  cartDetails: PropTypes.object,
  isQAFlow: PropTypes.bool,
  shippingOptionsQA: PropTypes.array,
  selectedShippingOption: PropTypes.string,
  isDark: PropTypes.bool,
};
export default ShippingOptionsForm;
