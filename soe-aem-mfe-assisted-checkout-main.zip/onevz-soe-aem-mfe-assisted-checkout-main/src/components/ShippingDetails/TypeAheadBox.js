import { Body } from '@vds/typography';
import PropTypes from 'prop-types';
import React from 'react';
import styled from 'styled-components';

const CustomBox = styled.div`
  box-sizing: border-box;
  background-color: rgb(255, 255, 255);
  border: 0.0625rem solid rgb(217, 217, 217);
  border-radius: 2px;
  min-height: auto;
  height: fit-content;
  text-align: left;
  visibility: visible;
  margin-top: 3.4rem;
  position: absolute;
  z-index: 99;
  width: 100%;
  height: 200px;
  overflow: auto;
`;

const BottomBorder = styled.div`
  padding: 0.5rem;
  border-bottom: 1px solid lightgray;
  cursor: pointer;
`;

export default function TypeAheadBox({ collapseAddress, AddressData, handleAddressSelction }) {
  return (
    collapseAddress &&
    AddressData?.length > 0 && (
      <CustomBox data-testid='dropdown'>
        {AddressData?.map((address) => (
          <BottomBorder key={address?.disprawstr} onClick={() => handleAddressSelction(address)}>
            <Body data-testid='address_fields' size='small' key={address?.disprawstr}>
              {address?.disprawstr}
            </Body>
          </BottomBorder>
        ))}
      </CustomBox>
    )
  );
}

TypeAheadBox.propTypes = {
  collapseAddress: PropTypes.bool,
  AddressData: PropTypes.array,
  handleAddressSelction: PropTypes.func,
};
