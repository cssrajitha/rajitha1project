import { Icon } from '@vds/icons';
import { Line } from '@vds/lines';
import { Title } from '@vds/typography';
import React from 'react';
import { useNavigate } from 'react-router';
import Emitter from 'onevzsoemfeframework/Emitter';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR } from '../constants/constants';

const FlexBoxGrowOne = styled.div`
  display: flex;
  flex-grow: 1;
  height: 4rem;
`;
const ShopWrapper = styled.div`
  width: 50%;
  padding: 1.5rem 0.5rem;
`;

export const FlexAlignContainerItemsCenter = styled.div`
  display: flex;
  align-items: center !important;
  justify-content: space-between;
`;

const FixedHeader = styled.div`
  max-width: 64rem;
  background-color: ${(props) => (props.isDark ? DARK_THEME_BGCOLOR : 'rgb(255, 255, 255)')};
  top: 0;
  z-index: 1;
  width: 100%;
  position: fixed;
`;

const CloseIconWrapper = styled.div`
  display: flex;
  margin-right: 30px;
`;

const BlackClickable = styled.a`
  cursor: pointer;
  color: ${(props) => (props.isDark ? DARK_THEME_COLOR : '#000000')} !important;
`;

function ShippingDetailsHeader({ orderDetails, isFromRefundOrderView = false, isQAFlow = false, isDark = false }) {
  const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable || false;
  let navigate = '';
  function useNavigateMFE() {
    navigate = useNavigate();
  }
  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }

  const handleBackClick = () => {
    if (isQAFlow) {
      navigate(`/sales/assisted/new/qa-order-review.html`);
    } else if (isFromRefundOrderView) {
      const locationCode = orderDetails?.locationCode || '';
      const orderNumber = orderDetails?.orderList?.[0]?.orderNumber || '';
      navigate(
        `/sales/assisted/new/refundexchange/order-review.html?isReadOrder=Y&orderNumber=${orderNumber}&locationCode=${locationCode}`,
      );
    } else if (!scmUpgradeMfeEnable) {
      navigate(`/sales/assisted/new/order-review.html`);
    } else {
      Emitter.emit('CLOSE_SHIPPING_DETAILS_MODAL');
    }
  };
  return (
    <FixedHeader data-testid='header' isDark={isDark}>
      <FlexAlignContainerItemsCenter>
        <FlexBoxGrowOne>
          <ShopWrapper>
            <Title size='small' bold primitive='h1' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
              Change Shipping Address
            </Title>
          </ShopWrapper>
        </FlexBoxGrowOne>
        <CloseIconWrapper>
          <BlackClickable
            data-testid='close-link'
            isDark={isDark}
            onClick={() => {
              handleBackClick();
            }}
          >
            <Icon name='close' size='large' color={isDark ? DARK_THEME_COLOR : '#000000'} />
          </BlackClickable>
        </CloseIconWrapper>
      </FlexAlignContainerItemsCenter>
      <Line type='secondary' />
    </FixedHeader>
  );
}

ShippingDetailsHeader.propTypes = {
  orderDetails: PropTypes.object,
  isFromRefundOrderView: PropTypes.bool,
  isQAFlow: PropTypes.bool,
  isDark: PropTypes.bool,
};

export default ShippingDetailsHeader;
