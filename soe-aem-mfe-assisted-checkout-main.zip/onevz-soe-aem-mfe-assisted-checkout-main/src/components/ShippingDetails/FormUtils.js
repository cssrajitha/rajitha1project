export const onEmailChange = (
  e,
  formDataError,
  shippingOptionsFormData,
  setShippingOptionsFormData,
  setFormDataError,
) => {
  const { name, value } = e.target;
  const updatedValue = value.replace(/\s/g, '');
  const rE = /^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i;
  const valid = updatedValue !== '' && rE.test(updatedValue);

  setShippingOptionsFormData({
    ...shippingOptionsFormData,
    [name]: value,
  });
  setFormDataError({ ...formDataError, emailIdError: !valid });
};

export const onPhoneChange = (
  e,
  formDataError,
  shippingOptionsFormData,
  setShippingOptionsFormData,
  setFormDataError,
) => {
  const { name, value } = e.target;
  const rE = /^\d+$/;
  const valid = value !== '' && rE.test(value);

  setShippingOptionsFormData({ ...shippingOptionsFormData, [name]: value });
  setFormDataError({ ...formDataError, phoneError: !(valid && value.length <= 10) });
};

export const onStreetChange = (
  e,
  formDataError,
  shippingOptionsFormData,
  setShippingOptionsFormData,
  setFormDataError,
) => {
  const { name, value } = e.target;
  const rE = /^[0-9a-zA-Z-.,#'() \b]+$/;
  const valid = value !== '' && rE.test(value);
  setShippingOptionsFormData({ ...shippingOptionsFormData, [name]: value });
  setFormDataError({ ...formDataError, streetNameError: !valid });
};

export const onZipChange = (
  e,
  formDataError,
  shippingOptionsFormData,
  setShippingOptionsFormData,
  setFormDataError,
  validateAddressBody,
) => {
  const { name, value } = e.target;
  const rE = /^\d{5}$|^\d{5}-\d{4}$/;
  const valid = value !== '' && rE.test(value);
  setShippingOptionsFormData({ ...shippingOptionsFormData, [name]: value.trim() });
  setFormDataError({ ...formDataError, zipCodeError: !valid });
  if (value.length === 5) {
    validateAddressBody({
      body: {
        addressLine1: '',
        addressLine2: '',
        city: '',
        state: '',
        zipCode: value,
        type: 'validateAddress',
      },
      spinner: false,
      mock: false,
    });
  }
};

export const onNameChange = (
  e,
  formDataError,
  shippingOptionsFormData,
  setShippingOptionsFormData,
  setFormDataError,
) => {
  const { name, value } = e.target;
  const rE = /^[a-zA-Z]+(?:\s+[a-zA-Z]+)+$/;
  const valid = value !== '' && rE.test(value);
  setShippingOptionsFormData({ ...shippingOptionsFormData, [name]: value });
  setFormDataError({ ...formDataError, nameError: !valid });
};

export const onAttnChange = (
  e,
  formDataError,
  shippingOptionsFormData,
  setShippingOptionsFormData,
  setFormDataError,
  validateAddressBody,
  selectedAddressType,
  isQAFlow

) => {
  const { name, value } = e.target;
  const trimmedValue = value.trim();
  console.log("-------validate", validateAddressBody);
  const msfToNsaQAFFlag = /true/i.test(
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.msfToNsaQuickAccessoriesFFlag,
  );
    
  if(msfToNsaQAFFlag && isQAFlow){
    const rE = /^[0-9a-zA-Z-._, \b]+$/;
    const valid = rE.test(trimmedValue);
    const selectedRadio = selectedAddressType === "businessAddress" ? !valid : false
    setShippingOptionsFormData({ ...shippingOptionsFormData, [name]: trimmedValue });
    setFormDataError({ ...formDataError, attnError: selectedRadio });
  } else if (trimmedValue) {
    const rE = /^[0-9a-zA-Z-._, \b]+$/;
    const valid = rE.test(trimmedValue);
    setShippingOptionsFormData({ ...shippingOptionsFormData, [name]: trimmedValue });
    setFormDataError({ ...formDataError, attnError: !valid });
  } else {
    setFormDataError({ ...formDataError, attnError: false });
    setShippingOptionsFormData({ ...shippingOptionsFormData, [name]: '' });
  }
 
};

export const onSuiteChange = (
  e,
  formDataError,
  shippingOptionsFormData,
  setShippingOptionsFormData,
  setFormDataError,
) => {
  const { name, value } = e.target;
  const trimmedValue = value.trim();
  if (trimmedValue) {
    const rE = /^[0-9a-zA-Z]+$/;
    const valid = rE.test(trimmedValue) && trimmedValue.length <= 5;
    setShippingOptionsFormData({ ...shippingOptionsFormData, [name]: trimmedValue.trim() });
    setFormDataError({ ...formDataError, apartmentNoError: !valid });
  } else {
    setFormDataError({ ...formDataError, apartmentNoError: false });
    setShippingOptionsFormData({ ...shippingOptionsFormData, [name]: '' });
  }
};

export const handleTypeAhead = (e, timer, setTimer, getAddressTypehead, setCollapseAddress) => {
  const input = e?.target?.value;

  if (input?.length > 0) {
    const requestBody = {
      countrycode: 'USA',
      streetterm: input,
    };
    clearTimeout(timer);
    setTimer(
      setTimeout(() => {
        getAddressTypehead({ body: requestBody, spinner: false });
        setCollapseAddress(true);
      }, 1000),
    );
  } else {
    setCollapseAddress(false);
  }
};

export const validateInputChanges = (
  element,
  e,
  formDataError,
  shippingOptionsFormData,
  setShippingOptionsFormData,
  setFormDataError,
  validateAddressBody,
  selectedAddressType,
  isQAFlow
) => {
  const switchFun = {
    emailId: onEmailChange,
    phone: onPhoneChange,
    streetName: onStreetChange,
    apartmentNo: onSuiteChange,
    zipCode: onZipChange,
    name: onNameChange,
    attn: onAttnChange,
  };
  if (switchFun[element]) {
    switchFun[element](
      e,
      formDataError,
      shippingOptionsFormData,
      setShippingOptionsFormData,
      setFormDataError,
      validateAddressBody,
      selectedAddressType,
      isQAFlow
    );
  }
};

export const shippingAddressOptions = [
  {
    title: 'Name*',
    id: 'name',
    required: true,
    maxlength: null,
    dataType: 'String',
  },

  {
    title: 'ATTN',
    id: 'attn',
    required: null,
    maxlength: null,
    dataType: 'String',
  },
  {
    title: 'Street Address*',
    id: 'streetName',
    required: true,
    maxlength: null,
    dataType: 'AlphaNumeric',
  },
  {
    title: 'Apt/Suite',
    id: 'apartmentNo',
    required: null,
    maxlength: 50,
    dataType: 'AlphaNumeric',
  },
  {
    title: 'Can be Reached*',
    id: 'phone',
    required: true,
    maxlength: null,
    dataType: 'Numeric',
  },
  {
    title: 'City, State',
    id: 'cityState',
    required: true,
    maxlength: null,
    dataType: 'String',
  },
  {
    title: 'Zip Code*',
    id: 'zipCode',
    required: true,
    maxlength: null,
    dataType: 'Numeric',
  },
  {
    title: 'Email Address*',
    id: 'emailId',
    required: true,
    maxlength: null,
    dataType: 'AlphaNumeric',
  },
];

export const addressChangeWarningText =
  'Change in shipping address will need additional validation before order can be processed. VZW may contact the number provided in the credit application if additional information is required. Customer can check order status by calling 888-483-7200.';

export const checkError = (formDataError) => Object.values(formDataError).some((value) => value === true);

export const isNSEQAFlow = (isQAFlow, cart) => isQAFlow && !cart?.cartHeader?.cartCreator;
