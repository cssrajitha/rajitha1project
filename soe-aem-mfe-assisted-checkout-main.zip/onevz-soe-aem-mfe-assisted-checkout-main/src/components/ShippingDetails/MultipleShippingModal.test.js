import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import MultipleShippingModal from './MultipleShippingModal';
import StoreProvider from '../../modules/store';
import { lineItemsData } from './_mock_/lineItemsMock';
import { alternateShippingOptions } from './_mock_/alternateMock';
import { getShippingOptionsOfAllLinesData } from './_mock_/getShippingOptionsOfAllLinesMock';
import { customerTypeisNotNData, customerTypeisNData } from './_mock_/CustomerProfileResultMock';
import * as orderWriteAPICallHook from '../../modules/services/APIService/AgreementsAPICallHook';
import { alternateLineItemsMock } from './_mock_/alternateLineItemsMock';

jest.mock('./MultipleShippingContent', () => ({
  __esModule: true,
  default: () => <div>Shipping content</div>,
}));

const props = {
  showShipToMultipleModal: true,
  setShowShipToMultipleModal: jest.fn,
  lineItems: lineItemsData,
  getShippingOptionsOfAllLines: getShippingOptionsOfAllLinesData,
  updateShippingOptionBody: jest.fn(),
  CartDetailsResult: {
    cartHeader: {
      fullAccountNumber: '0280084163-1',
    },
    orderDetails: {
      itemLevelShipment: true,
    },
  },
};

const customerTypeisNotN = {
  CustomerProfileResult: customerTypeisNotNData,
};

const customerTypeisN = {
  CustomerProfileResult: customerTypeisNData,
};

const mockData = {
  getUniqueAddresses: jest.fn(),
  getUniqueAddressesResult: {
    data: {
      addressDetails: [
        {
          apartmentNo: '1E',
          streetNumber: '3915',
          streetName: 'CHIPPEWA',
          addrType: 'ST',
          city: 'SAINT LOUIS',
          state: 'MO',
          zipCode: '63116',
          zipCode4: '3663',
          countryCode: '',
          firmName: '',
          firstName: 'RYAN',
          lastName: 'MANUEL',
          phoneNumber: '4843035305',
          emailId: 'KZHVPHQ@VZW.COM',
          addressLine1: '3915 CHIPPEWA ST APT 1E',
          lineNo: '1',
        },
        {
          apartmentNo: '1B',
          streetNumber: '5148',
          streetName: 'RENOW',
          addrType: 'ST',
          city: 'SAINT SATAN',
          state: 'NY',
          zipCode: '50004',
          zipCode4: '3663',
          countryCode: '',
          firmName: '',
          firstName: 'WEST',
          lastName: 'SUITES',
          phoneNumber: '7485961237',
          emailId: 'CASDQWFC@VZW.COM',
          lineNo: '2',
        },
        {
          apartmentNo: '1C',
          streetNumber: '3912',
          addrType: 'ST',
          city: 'SAINT LOUIS',
          state: 'MO',
          zipCode: '63116',
          zipCode4: '3663',
          countryCode: '',
          firmName: '',
          firstName: 'RYAN',
          lastName: 'MANUEL',
          phoneNumber: '4843035305',
          emailId: 'KZHVPHQ@VZW.COM',
          addressLine1: '3912 SAINT LOUIS ST APT 1C',
          lineNo: '3',
        },
      ],
    },
  },
};
const alternateMockData = {
  getUniqueAddresses: jest.fn(),
  getUniqueAddressesResult: {
    data: {
      addressDetails: [
        {
          apartmentNo: '1E',
          streetNumber: '3915',
          streetName: 'CHIPPEWA',
          addrType: 'ST',
          city: 'SAINT LOUIS',
          state: 'MO',
          zipCode: '63116',
          zipCode4: '3663',
          countryCode: '',
          firmName: '',
          firstName: 'RYAN',
          lastName: 'MANUEL',
          phoneNumber: '4843035305',
          emailId: 'KZHVPHQ@VZW.COM',
          addressLine1: '3915 CHIPPEWA ST APT 1E',
          lineNo: '3',
        },
      ],
    },
  },
};

describe('MultipleShippingModal', () => {
  test('initial render', () => {
    sessionStorage.setItem('creditAppNum', '741258963');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'TRUE' }));
    sessionStorage.setItem('intentType', 'AAL');
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);
    render(
      <StoreProvider>
        <MultipleShippingModal {...props} {...customerTypeisNotN} />
      </StoreProvider>,
    );
    sessionStorage.getItem('creditAppNum');
    const button = screen.getByText('Save');
    fireEvent.click(button);
  });
  test('alternateshipping render', () => {
    sessionStorage.setItem('creditAppNum', '741258963');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'TRUE' }));
    sessionStorage.setItem('intentType', 'AAL');
    const alternateProps = {
      getShippingOptionsOfAllLines: alternateShippingOptions,
    };
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);
    render(
      <StoreProvider>
        <MultipleShippingModal {...props} {...alternateProps} />
      </StoreProvider>,
    );
    sessionStorage.getItem('creditAppNum');
    const button = screen.getByText('Save');
    fireEvent.click(button);
  });
  test('click close btn', () => {
    sessionStorage.setItem('creditAppNum', '741258963');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'TRUE' }));
    sessionStorage.setItem('intentType', 'AAL');
    const alternateProps = {
      getShippingOptionsOfAllLines: alternateShippingOptions,
    };
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);
    render(
      <StoreProvider>
        <MultipleShippingModal {...props} {...alternateProps} />
      </StoreProvider>,
    );
    const closeBtn = screen.getByTestId('close-link');
    fireEvent.click(closeBtn);
  });
  test('alternateLine details render', () => {
    sessionStorage.setItem('creditAppNum', '741258963');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'TRUE' }));
    sessionStorage.setItem('intentType', 'AAL');
    const alternateProps = {
      lineItems: alternateLineItemsMock,
    };
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);
    render(
      <StoreProvider>
        <MultipleShippingModal {...props} {...alternateProps} />
      </StoreProvider>,
    );
    sessionStorage.getItem('creditAppNum');
    const button = screen.getByText('Save');
    fireEvent.click(button);
  });
  test('alternateLine details render null', () => {
    sessionStorage.setItem('creditAppNum', '741258963');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'FALSE' }));
    const alternateProps = {
      lineItems: alternateLineItemsMock,
    };
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => alternateMockData);
    render(
      <StoreProvider>
        <MultipleShippingModal {...props} {...alternateProps} />
      </StoreProvider>,
    );
    sessionStorage.getItem('creditAppNum');
    const button = screen.getByText('Save');
    fireEvent.click(button);
  });
  test('initial render', () => {
    sessionStorage.setItem('creditAppNum', '741258963');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'FALSE' }));
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);
    render(
      <StoreProvider>
        <MultipleShippingModal {...props} {...customerTypeisN} />
      </StoreProvider>,
    );
    sessionStorage.getItem('creditAppNum');
    const button = screen.getByText('Save');
    fireEvent.click(button);
  });
});
