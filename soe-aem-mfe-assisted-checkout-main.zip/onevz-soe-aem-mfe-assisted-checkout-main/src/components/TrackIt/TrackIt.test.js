import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import { useDispatch } from 'react-redux';
import { addAppMessage } from 'onevzsoemfecommon/AppMessageActions';
import { useLazyGetTrackShipmentQuery } from '../../modules/services/APIService/APIServiceCallHook';
import TrackIt from './TrackIt';

jest.mock('react-redux', () => ({
  useDispatch: jest.fn(),
}));

jest.mock('../../modules/services/APIService/APIServiceCallHook', () => ({
  useLazyGetTrackShipmentQuery: jest.fn(),
}));

jest.mock('onevzsoemfecommon/AppMessageActions', () => ({
  addAppMessage: jest.fn(),
}));

const mockReadOrderResponse = {
  cart: {
    lineDetails: {
      lineInfo: [
        {
          itemsInfo: [{ depletionType: 'F' }, { depletionType: 'N' }],
        },
      ],
    },
    orderDetails: {
      orderList: [{ orderNumber: 12345 }],
    },
  },
};

describe('TrackIt Component', () => {
  const props = {
    handleToggle: jest.fn(),
    locationCode: '123',
    readOrderResponse: mockReadOrderResponse,
    orderStatus: 'OM',
  };

  const mockDispatch = jest.fn();
  const mockGetTrackShipmentQuery = jest.fn();
  beforeEach(() => {
    jest.clearAllMocks();
    useDispatch.mockReturnValue(mockDispatch);
    useLazyGetTrackShipmentQuery.mockReturnValue([mockGetTrackShipmentQuery]);
  });

  test('renders TrackIt component with tracking details', async () => {
    const props1 = {
      handleToggle: jest.fn(),
      locationCode: '123',
      readOrderResponse: mockReadOrderResponse,
      orderStatus: 'CO',
    };
    const mockResponse = {
      data: [
        {
          shippmentDetails: [
            {
              deliveredDate: '02/07/2025',
              shippingTrackerCarrier: 'FEDEX_642600383312',
              expectedShipDate: '01/31/2025',
              shipmentStatus: 'Shipped',
              trackingURL: 'https://fedex.com/fedextrack/?trknbr=642600383312',
              mtn: '8132945943',
            },
          ],
        },
        {
          errors: [
            {
              errorMessage: 'No cases exist that match search criteria',
              errorCode: '99',
            },
          ],
        },
      ],
    };
    useLazyGetTrackShipmentQuery.mockReturnValue([jest.fn().mockResolvedValue({ data: mockResponse })]);

    render(<TrackIt {...props1} />);

    screen.debug();
  });

  test('renders TrackIt component with no tracking details', () => {
    render(<TrackIt {...props} />);
    expect(screen.getByText('Track It')).toBeInTheDocument();
    expect(screen.getByText('No order available to track shipment')).toBeInTheDocument();
  });

  test('renders TrackIt component with no tracking details to pase else condition', () => {
    const updatedProps = { ...props, readOrderResponse: {} };
    render(<TrackIt {...updatedProps} />);
    expect(screen.getByText('Track It')).toBeInTheDocument();
    expect(screen.getByText('No order available to track shipment')).toBeInTheDocument();
  });

  test('renders TrackIt component with no tracking details to pase else condition', () => {
    const updatedProps = {
      ...props,
      readOrderResponse: {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                itemsInfo: [{ depletionType: 'F' }, { depletionType: 'N' }],
              },
            ],
          },
          orderDetails: {
            orderList: [{ orderNumber: 12345 }, { orderNumber: 0 }],
          },
        },
      },
    };
    render(<TrackIt {...updatedProps} />);
    expect(screen.getByText('Track It')).toBeInTheDocument();
    expect(screen.getByText('No order available to track shipment')).toBeInTheDocument();
  });
  test('renders TrackIt component with tracking details', async () => {
    const mockResponse = [
      {
        shippmentDetails: [
          {
            deliveredDate: '02/07/2025',
            shippingTrackerCarrier: 'FEDEX_642600383312',
            expectedShipDate: '01/31/2025',
            shipmentStatus: 'Shipped Item',
            trackingURL: 'https://fedex.com/fedextrack/?trknbr=642600383312',
            mtn: '8132945943',
          },
          {
            deliveredDate: '02/09/2025',
            shippingTrackerCarrier: 'FEDEX_64260038312',
            expectedShipDate: '01/09/2025',
            shipmentStatus: 'Shipped',
            trackingURL: 'https://fedex.com/fedextrack/?trknbr=642600384312',
            mtn: '8132945923',
          },
        ],
      },
      {
        errors: [
          {
            errorMessage: 'No cases exist that match search criteria',
            errorCode: '99',
          },
        ],
      },
    ];

    mockGetTrackShipmentQuery.mockResolvedValueOnce(mockResponse);

    const updatedProps = {
      ...props,
      orderStatus: 'CO',
    };

    render(<TrackIt {...updatedProps} />);
    await waitFor(() => {
      expect(screen.getByText('8132945943')).toBeInTheDocument();
      expect(screen.getByText('01/31/2025')).toBeInTheDocument();
      expect(screen.getByText('02/07/2025')).toBeInTheDocument();
      expect(screen.getByText('FEDEX_642600383312')).toBeInTheDocument();
      expect(screen.getByText('Shipped')).toBeInTheDocument();
    });
  });

  test('renders TrackIt component with tracking details->falsy part', async () => {
    const mockResponse = [
      {
        shippmentDetails: [
          {
            deliveredDate: '02/07/2025',
            shippingTrackerCarrier: 'FEDEX_642600383312',
            expectedShipDate: '01/31/2025',
            shipmentStatus: 'Shipped Item',
            trackingURL: 'https://fedex.com/fedextrack/?trknbr=642600383312',
            mtn: '8132945943',
          },
          {
            deliveredDate: '02/09/2025',
            shippingTrackerCarrier: 'FEDEX_64260038312',
            expectedShipDate: '01/09/2025',
            shipmentStatus: 'Shipped',
            trackingURL: 'https://fedex.com/fedextrack/?trknbr=642600384312',
          },
        ],
      },
      {
        errors: [
          {
            errorMessage: 'No cases exist that match search criteria',
            errorCode: '99',
          },
        ],
      },
    ];

    mockGetTrackShipmentQuery.mockResolvedValueOnce(mockResponse);

    const updatedProps = {
      ...props,
      orderStatus: 'CO',
    };

    render(<TrackIt {...updatedProps} />);
    await waitFor(() => {
      expect(screen.getByText('8132945943')).toBeInTheDocument();
      expect(screen.getByText('01/31/2025')).toBeInTheDocument();
      expect(screen.getByText('02/07/2025')).toBeInTheDocument();
      expect(screen.getByText('FEDEX_642600383312')).toBeInTheDocument();
      expect(screen.getByText('Shipped')).toBeInTheDocument();
    });
  });

  test('renders TrackIt component with tracking details with no table data', async () => {
    const newProps = {
      ...props,
      orderStatus: 'CO',
    };

    const mockResponse = {
      data: {
        data: [
          {
            shippmentDetails: [],
          },
        ],
      },
    };
    mockGetTrackShipmentQuery.mockResolvedValueOnce(mockResponse);

    render(<TrackIt {...newProps} />);
  });

  test('handles error while getting tracking details', async () => {
    const mockError = {
      response: {
        data: {
          errors: [{ message: 'Error message' }],
        },
      },
    };

    mockGetTrackShipmentQuery.mockRejectedValueOnce(mockError);

    render(<TrackIt {...props} />);
    await waitFor(() => {
      expect(mockDispatch).toHaveBeenCalledWith(addAppMessage('Error message', 'error', true, true));
    });
  });

  test('handles error while getting tracking details-> else path', async () => {
    const mockError = {
      response: {
        data: {
          errors1: [{ message: 'Error message' }],
        },
      },
    };

    mockGetTrackShipmentQuery.mockRejectedValueOnce(mockError);

    render(<TrackIt {...props} />);
    await waitFor(() => {
      expect(mockDispatch).toHaveBeenCalledWith(addAppMessage('Error message', 'error', true, true));
    });
  });

  test('handles toggle click', () => {
    render(<TrackIt {...props} />);
    fireEvent.click(screen.getByRole('img', { name: /left-caret icon/i }));
    expect(props.handleToggle).toHaveBeenCalled();
  });

  test('checks depletion type and sets showMessage', () => {
    render(<TrackIt {...props} />);
    expect(screen.getByText('No order available to track shipment')).toBeInTheDocument();
  });

  test('checks depletion type and does not set showMessage', () => {
    const newProps = {
      ...props,
      orderStatus: 'CO',
    };
    render(<TrackIt {...newProps} />);
    expect(screen.queryByText('No order available to track shipment')).not.toBeInTheDocument();
  });
});
