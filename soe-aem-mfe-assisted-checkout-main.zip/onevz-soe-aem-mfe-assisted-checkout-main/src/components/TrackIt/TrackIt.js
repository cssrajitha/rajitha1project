import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Table, TableHead, TableHeader, TableBody, TableRow, Cell } from '@vds/tables';
import { useDispatch } from 'react-redux';
import { Icon } from '@vds/icons';
import { Title } from '@vds/typography';
import { addAppMessage } from 'onevzsoemfecommon/AppMessageActions';
import styled from 'styled-components';
import { useLazyGetTrackShipmentQuery } from '../../modules/services/APIService/APIServiceCallHook';

const TrackItHeaderWrapper = styled.div`
  display: flex;
  align-items: center;
  font-weight: 900;
  border-bottom: 1px solid #d8dada;
  clear: both;
  padding-top: 16px;
  padding-bottom: 16px;
  padding-left: 0.5rem;
`;

const TrackItIconWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: 'verizon-icons', sans-serif !important;
  font-size: 1.5rem;
  font-style: normal;
  font-weight: normal;
  font-feature-settings: normal;
  font-variant: normal;
  text-transform: none;
  height: 24px !important;
  width: 24px !important;
  -webkit-font-smoothing: antialiased;
  border-right: 1px solid #000000;
  padding-right: 0.875rem !important;
  margin-right: 0.875rem;

  &:hover {
    cursor: pointer;
  }
`;

const TrackItModal = styled.div`
  font-size: 18px;
  z-index: 1000;
  position: fixed;
  width: 100%;
  height: 100%;
  padding: 0;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  margin: auto;
  overflow-y: hidden;
  overflow-x: hidden;
  background-color: white;
  max-width: 100%;
`;

const TrackItModalInner = styled.div`
  position: absolute;
  width: 64rem;
  max-width: 64rem;
  overflow-x: hidden;
  overflow-y: hidden;
  height: calc(100% - 148px);
  top: 58px;
  bottom: auto;
  margin: auto;
  left: 0;
  right: 0;
  background: white;
  padding-bottom: 7rem;

  @media (pointer: none), (pointer: coarse) {
    width: 64rem;
    max-width: 100%;
    overflow-x: hidden;
    overflow-y: hidden;
    height: calc(100% - 148px);
    top: 58px;
    bottom: auto;
    margin: auto;
    left: 0;
    right: 0;
    background: white;
    padding-bottom: 7rem;
  }

  @media (pointer: fine) {
    width: 100%;
    max-width: 64rem;
    overflow-x: hidden;
    overflow-y: auto;
    height: calc(100% - 148px);
    top: 58px;
    bottom: auto;
    margin: auto;
    left: 0;
    right: 0;
    background: white;
    background-clip: content-box, padding-box;
  }
`;

const BlueAnchor = styled.a`
  color: blue !important;
  font-size: 18px;
  text-decoration: none;
`;

const StyleText = styled.p`
  margin-top: 10px;
  text-align: center;
  font-size: 30px;
  font-weight: bolder;
  font-family: BrandFontRegular, Sans-serif;
  letter-spacing: -1.5px;
`;

const CenteredTable = styled(Table)`
  text-align: center;
  border-color: lightgray;
`;

const CenteredTableHeader = styled(TableHeader)`
  color: #4a4a4a;
  text-align: center;
  font-size: 18px;
  font-weight: normal;
  margin-top: 0 !important;
  border-color: lightgray;
  border-top: 1px solid lightgray;
  border-bottom: 1px solid lightgray;
  padding-left:
  &:hover {
    cursor: pointer;
  }

  &:first-child {
    padding-left: 25px; 
  }
`;

const CenteredTableCell = styled(Cell)`
  color: #4a4a4a;
  text-align: center;
  font-size: 18px;
  &:hover {
    cursor: pointer;
  }

  &:first-child {
    padding-left: 25px;
  }
`;

const TrackIt = (props) => {
  const dispatch = useDispatch();
  const [trackingDetails, setTrackingDetails] = useState([]);
  const [showMessage, setShowMessage] = useState(false);
  const [getShipmentDetails] = useLazyGetTrackShipmentQuery();
  const [depletionType, setDepletionType] = useState(false);
  const { handleToggle, locationCode, readOrderResponse, orderStatus } = props;

  useEffect(() => {
    const depletionTypeExists = checkDepletionType();
    getDepletionTypeAndOrderStatus(orderStatus, depletionTypeExists);
    getTrackItDetails();
  }, []);

  const checkDepletionType = () => {
    const depletionTypeExists = readOrderResponse?.cart?.lineDetails?.lineInfo?.some((line) =>
      line?.itemsInfo?.some((item) => item.depletionType === 'F'),
    );
    setDepletionType(depletionTypeExists);
    return depletionTypeExists;
  };

  const getDepletionTypeAndOrderStatus = (orderstatus, depletiontype) => {
    if (!depletiontype || (depletiontype && orderstatus === 'OM')) {
      console.log('depletiontype inside func', depletionType, orderstatus);
      setShowMessage(true);
    } else {
      setShowMessage(false);
    }
  };

  const getTrackItDetails = async () => {
    const orderList = getOrderList(readOrderResponse);
    const reqordlist = [];
    if (orderList.length > 0) {
      orderList.forEach((order) => {
        if (order.orderNumber !== 0) {
          const req = {
            orderNumber: order.orderNumber,
            locationCode,
          };
          reqordlist.push(req);
        }
      });
    }
    const payload = { data: reqordlist };
    try {
      const res = await getShipmentDetails({ body: payload, mock: false });
      const response = res?.data?.data || res?.data || res;

      mapResponse(response);
    } catch (error) {
      const errMsg = error?.response?.data?.errors?.[0]
        ? error.response.data.errors[0].message
        : 'Error while getting Trackit orderDetails';
      dispatch(addAppMessage(errMsg, 'error', true, true));
    }
  };

  const getOrderList = (data) => {
    if (data && data.cart && data.cart.orderDetails && data.cart.orderDetails.orderList) {
      return data.cart.orderDetails.orderList;
    }
    return [];
  };

  const mapResponse = (trackingResponse) => {
    let TrackingDetails = [];

    if (trackingResponse && trackingResponse.length > 0) {
      trackingResponse.forEach((item) => {
        if (item?.shippmentDetails && item?.shippmentDetails?.length > 0) {
          TrackingDetails = [...TrackingDetails, ...item.shippmentDetails];
        }
      });

      setTrackingDetails(TrackingDetails);
    }
  };

  const TrackItHeader = (
    <TrackItHeaderWrapper>
      <TrackItIconWrapper
        onClick={() => {
          handleToggle();
        }}
      >
        <Icon name='left-caret' size='XLarge' medium='true' />
      </TrackItIconWrapper>
      {/* <VerticalLine /> */}
      <Title size='small' color='#4a4a4a' bold>
        Track It
      </Title>
    </TrackItHeaderWrapper>
  );

  const TrackItBody = (
    <TrackItModalInner className='trackit-Modal-inner'>
      {TrackItHeader}
      <CenteredTable className='small-table' striped={false} surface='light' padding='standard'>
        <TableHead>
          <CenteredTableHeader>Line</CenteredTableHeader>
          <CenteredTableHeader>MTN</CenteredTableHeader>
          <CenteredTableHeader>Shipment Date</CenteredTableHeader>
          <CenteredTableHeader>Delivered Date</CenteredTableHeader>
          <CenteredTableHeader>Carrier_Tracking_Number</CenteredTableHeader>
          <CenteredTableHeader>Status</CenteredTableHeader>
        </TableHead>
        <TableBody>
          {trackingDetails &&
            trackingDetails.length > 0 &&
            trackingDetails.map((item, i) => (
              <TableRow key={item?.mtn || i}>
                <CenteredTableCell>
                  <span style={{ fontSize: '18px' }}>{i + 1}</span>
                </CenteredTableCell>
                <CenteredTableCell>
                  <span style={{ fontSize: '18px' }}>{item?.mtn}</span>
                </CenteredTableCell>
                <CenteredTableCell>
                  <span style={{ fontSize: '18px' }}>{item?.expectedShipDate}</span>
                </CenteredTableCell>
                <CenteredTableCell>
                  <span style={{ fontSize: '18px' }}>{item?.deliveredDate}</span>
                </CenteredTableCell>
                <CenteredTableCell>
                  <BlueAnchor tabIndex='0' href={item?.trackingURL} target='_blank'>
                    {item?.shippingTrackerCarrier}
                  </BlueAnchor>
                </CenteredTableCell>
                <CenteredTableCell>
                  <span style={{ fontSize: '18px' }}>{item?.shipmentStatus}</span>
                </CenteredTableCell>
              </TableRow>
            ))}
        </TableBody>
      </CenteredTable>
    </TrackItModalInner>
  );

  return (
    <TrackItModal data-testid='trackit' showMessage={showMessage} noTableData={trackingDetails.length === 0}>
      <div>
        {(!showMessage && TrackItBody) || (
          <div data-testid='showMessage'>
            {TrackItHeader}
            <StyleText>No order available to track shipment</StyleText>
          </div>
        )}
      </div>
    </TrackItModal>
  );
};

TrackIt.propTypes = {
  handleToggle: PropTypes.func.isRequired,
  locationCode: PropTypes.string.isRequired,
  readOrderResponse: PropTypes.object.isRequired,
  orderStatus: PropTypes.string.isRequired,
};

export default TrackIt;
