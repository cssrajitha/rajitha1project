import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../../modules/store';
import ItemsAtGlance from '../ItemsAtGlance';

// Mock styled-components theme functions
jest.mock('../../constants/constants', () => ({
  themeIconColor: jest.fn(() => '#000'),
  themeSurface: jest.fn(() => 'light'),
  themeTableHeaderBgColor: jest.fn(() => '#f5f5f5'),
  themeTextColor: jest.fn(() => '#333'),
}));

// Mock sessionStorage
const mockSessionStorage = {
  getItem: jest.fn(),
  setItem: jest.fn(),
  clear: jest.fn(),
};
Object.defineProperty(window, 'sessionStorage', {
  value: mockSessionStorage,
});

// Mock window.mfe
Object.defineProperty(window, 'mfe', {
  value: { scmDeviceMfeEnable: true },
  writable: true,
});

// Mock ResizeObserver
class ResizeObserver {
  constructor() {
    this.observe = jest.fn();
    this.unobserve = jest.fn();
    this.disconnect = jest.fn();
  }
}
window.ResizeObserver = ResizeObserver;

// Test data factories
const createCartItem = (overrides = {}) => ({
  id: '1',
  description: 'Test Item',
  itemCode: 'TEST123',
  itemPrice: 100,
  qty: 1,
  taxAmount: 10,
  discountedPrice: 90,
  depletionType: 'S',
  depletionLocation: 'STORE001',
  manualDiscount: { discountAmount: 5 },
  sedOfferList: {
    sedOffer: [
      {
        offerId: 'OFFER123',
        discAmt: 10,
      },
    ],
  },
  itemsInfo: { status: 'Active' },
  ...overrides,
});

const createLineInfo = (overrides = {}) => ({
  serviceInfo: {
    primaryUserInfo: {
      firstName: 'John',
      lastName: 'Doe',
    },
    mtn: '1234567890',
  },
  itemsInfo: [
    {
      cartItems: {
        cartItem: [createCartItem()],
      },
    },
  ],
  ...overrides,
});

const createCartDetails = (overrides = {}) => ({
  cart: {
    lineDetails: {
      lineInfo: [createLineInfo()],
    },
  },
  ...overrides,
});

// Helper to render component with providers
const renderWithProviders = (component) => render(
    <BrowserRouter>
      <StoreProvider>{component}</StoreProvider>
    </BrowserRouter>,
  );

describe('ItemsAtGlance Component', () => {
  let mockHandleToggle;

  beforeEach(() => {
    mockHandleToggle = jest.fn();
    mockSessionStorage.getItem.mockReturnValue('1000001');
    jest.clearAllMocks();
  });

  describe('Component Rendering', () => {
    it('should render component with default props', () => {
      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={createCartDetails()} />,
      );

      expect(screen.getByTestId('items-at-glance')).toBeInTheDocument();
      expect(screen.getByText('Items At Glance')).toBeInTheDocument();
    });

    it('should render without cart details', () => {
      renderWithProviders(<ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={null} />);

      expect(screen.getByTestId('items-at-glance')).toBeInTheDocument();
    });

    it('should apply correct styling when scmDeviceMfeEnable is true', () => {
      window.mfe.scmDeviceMfeEnable = true;
      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={createCartDetails()} />,
      );

      const modalWrapper = screen.getByTestId('items-at-glance');
      expect(modalWrapper).toBeInTheDocument();
    });

    it('should apply correct styling when scmDeviceMfeEnable is false', () => {
      window.mfe.scmDeviceMfeEnable = false;
      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={createCartDetails()} />,
      );

      const modalWrapper = screen.getByTestId('items-at-glance');
      expect(modalWrapper).toBeInTheDocument();
    });
  });

  describe('User Interactions', () => {
    it('should close modal when close button is clicked', () => {
      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={createCartDetails()} />,
      );

      const closeButton = screen.getByTestId('close-button');
      fireEvent.click(closeButton);

      expect(mockHandleToggle).toHaveBeenCalledWith('');
    });

    it('should render dropdown with line options', () => {
      const cartDetails = createCartDetails({
        cart: {
          lineDetails: {
            lineInfo: [
              createLineInfo({
                serviceInfo: {
                  primaryUserInfo: { firstName: 'John', lastName: 'Doe' },
                  mtn: '1111111111',
                },
              }),
              createLineInfo({
                serviceInfo: {
                  primaryUserInfo: { firstName: 'Jane', lastName: 'Smith' },
                  mtn: '2222222222',
                },
              }),
            ],
          },
        },
      });

      renderWithProviders(<ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetails} />);

      expect(screen.getByTestId('select')).toBeInTheDocument();
      expect(screen.getByText('All Lines')).toBeInTheDocument();
    });
  });

  describe('Data Display', () => {
    it('should display primary user information', () => {
      const cartDetails = createCartDetails();
      renderWithProviders(<ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetails} />);

      expect(screen.getByText('John Doe')).toBeInTheDocument();
      const phoneElements = screen.getAllByText('1234567890');
      expect(phoneElements.length).toBeGreaterThan(0);
      expect(phoneElements[0]).toBeInTheDocument();
    });

    it('should render table with cart items', () => {
      const cartDetails = createCartDetails();
      renderWithProviders(<ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetails} />);

      expect(screen.getByTestId('table')).toBeInTheDocument();
      expect(screen.getByText('Test Item')).toBeInTheDocument();
      expect(screen.getByText('item #:TEST123')).toBeInTheDocument();
    });

    it('should display cart item details correctly', () => {
      const cartDetails = createCartDetails();
      renderWithProviders(<ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetails} />);

      // Check for item details
      expect(screen.getByText('Test Item')).toBeInTheDocument();
      expect(screen.getByText('item #:TEST123')).toBeInTheDocument();
      expect(screen.getByText('Status:Active')).toBeInTheDocument();

      // Check for pricing information
      expect(screen.getByText('100')).toBeInTheDocument(); // itemPrice
      expect(screen.getByText('1')).toBeInTheDocument(); // qty
      expect(screen.getByText('$10')).toBeInTheDocument(); // taxAmount
      expect(screen.getByText('$90')).toBeInTheDocument(); // discountedPrice
    });

    it('should handle offer information correctly', () => {
      const cartDetails = createCartDetails();
      renderWithProviders(<ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetails} />);

      expect(screen.getByText('OFFER123')).toBeInTheDocument();
      expect(screen.getByText('10')).toBeInTheDocument(); // discount amount
    });

    it('should display manual discount when present', () => {
      const cartDetails = createCartDetails();
      renderWithProviders(<ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetails} />);

      expect(screen.getByText('$5')).toBeInTheDocument(); // manual discount
    });
  });

  describe('Edge Cases and Error Handling', () => {
    it('should handle empty cart details gracefully', () => {
      renderWithProviders(<ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={{}} />);

      expect(screen.getByTestId('items-at-glance')).toBeInTheDocument();
    });

    it('should handle missing line info', () => {
      const cartDetails = {
        cart: {
          lineDetails: {
            lineInfo: null,
          },
        },
      };

      renderWithProviders(<ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetails} />);

      expect(screen.getByTestId('items-at-glance')).toBeInTheDocument();
    });

    it('should handle missing cart items', () => {
      const cartDetails = createCartDetails({
        cart: {
          lineDetails: {
            lineInfo: [
              {
                serviceInfo: {
                  primaryUserInfo: { firstName: 'John', lastName: 'Doe' },
                  mtn: '1234567890',
                },
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: null,
                    },
                  },
                ],
              },
            ],
          },
        },
      });

      renderWithProviders(<ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetails} />);

      expect(screen.getByTestId('items-at-glance')).toBeInTheDocument();
    });

    it('should handle items without sed offer list', () => {
      const cartItem = createCartItem({ sedOfferList: null });
      const cartDetails = createCartDetails({
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ...createLineInfo(),
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: [cartItem],
                    },
                  },
                ],
              },
            ],
          },
        },
      });

      renderWithProviders(<ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetails} />);

      const zeroElements = screen.getAllByText('0');
      expect(zeroElements).toHaveLength(2); // Should have exactly 2 elements with "0" text
      expect(zeroElements[0]).toBeInTheDocument(); // Default offer ID
      expect(zeroElements[1]).toBeInTheDocument(); // Default discount amount
    });

    it('should handle items without manual discount', () => {
      const cartItem = createCartItem({ manualDiscount: null });
      const cartDetails = createCartDetails({
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ...createLineInfo(),
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: [cartItem],
                    },
                  },
                ],
              },
            ],
          },
        },
      });

      renderWithProviders(<ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetails} />);

      expect(screen.getByText('$0')).toBeInTheDocument(); // Default manual discount
    });
  });

  describe('Location Code Logic', () => {
    it('should return depletionLocation when depletionType is L', () => {
      const cartItem = createCartItem({
        depletionType: 'L',
        depletionLocation: 'LOCAL123',
      });
      const cartDetails = createCartDetails({
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ...createLineInfo(),
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: [cartItem],
                    },
                  },
                ],
              },
            ],
          },
        },
      });

      renderWithProviders(<ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetails} />);

      expect(screen.getByText('LOCAL123')).toBeInTheDocument();
    });

    it('should return session storage value when depletionType is not L', () => {
      mockSessionStorage.getItem.mockReturnValue('SESSION123');
      const cartItem = createCartItem({
        depletionType: 'S',
        depletionLocation: 'STORE001',
      });
      const cartDetails = createCartDetails({
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ...createLineInfo(),
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: [cartItem],
                    },
                  },
                ],
              },
            ],
          },
        },
      });

      renderWithProviders(<ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetails} />);

      expect(screen.getByText('SESSION123')).toBeInTheDocument();
      expect(mockSessionStorage.getItem).toHaveBeenCalledWith('ROorderLocationCode');
    });

    it('should return default location when session storage is empty', () => {
      mockSessionStorage.getItem.mockReturnValue(null);
      const cartItem = createCartItem({
        depletionType: 'S',
        depletionLocation: 'STORE001',
      });
      const cartDetails = createCartDetails({
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ...createLineInfo(),
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: [cartItem],
                    },
                  },
                ],
              },
            ],
          },
        },
      });

      renderWithProviders(<ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetails} />);

      expect(screen.getByText('1000001')).toBeInTheDocument();
    });
  });

  describe('Multiple Lines Handling', () => {
    it('should render multiple lines with different items', () => {
      const cartDetails = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                serviceInfo: {
                  primaryUserInfo: { firstName: 'John', lastName: 'Doe' },
                  mtn: '1111111111',
                },
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: [createCartItem({ description: 'Item 1', itemCode: 'ITEM001' })],
                    },
                  },
                ],
              },
              {
                serviceInfo: {
                  primaryUserInfo: { firstName: 'Jane', lastName: 'Smith' },
                  mtn: '2222222222',
                },
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: [createCartItem({ description: 'Item 2', itemCode: 'ITEM002' })],
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      renderWithProviders(<ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetails} />);

      expect(screen.getByText('Item 1')).toBeInTheDocument();
      expect(screen.getByText('item #:ITEM001')).toBeInTheDocument();
      expect(screen.getByText('Item 2')).toBeInTheDocument();
      expect(screen.getByText('item #:ITEM002')).toBeInTheDocument();
    });
  });

  describe('Component State Management', () => {
    it('should initialize with correct open state', () => {
      renderWithProviders(
        <ItemsAtGlance value={false} handleToggle={mockHandleToggle} cartDetails={createCartDetails()} />,
      );

      // Modal should be closed initially
      const modal = screen.queryByText('Items At Glance');
      expect(modal).not.toBeInTheDocument();
    });

    it('should update open state when value prop changes', () => {
      const { rerender } = renderWithProviders(
        <ItemsAtGlance value={false} handleToggle={mockHandleToggle} cartDetails={createCartDetails()} />,
      );

      // Modal should be closed
      expect(screen.queryByText('Items At Glance')).not.toBeInTheDocument();

      // Re-render with value=true
      rerender(
        <BrowserRouter>
          <StoreProvider>
            <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={createCartDetails()} />
          </StoreProvider>
        </BrowserRouter>,
      );

      // Modal should now be open
      expect(screen.getByText('Items At Glance')).toBeInTheDocument();
    });
  });

  describe('Performance and Memoization', () => {
    it('should handle large datasets efficiently', () => {
      const largeCartDetails = {
        cart: {
          lineDetails: {
            lineInfo: Array.from({ length: 10 }, (unused, lineIndex) => ({
              serviceInfo: {
                primaryUserInfo: { firstName: `User${lineIndex}`, lastName: 'Test' },
                mtn: `111111111${lineIndex}`,
              },
              itemsInfo: Array.from({ length: 5 }, (unused2, itemIndex) => ({
                cartItems: {
                  cartItem: Array.from({ length: 3 }, (unused3, cartIndex) =>
                    createCartItem({
                      id: `${lineIndex}-${itemIndex}-${cartIndex}`,
                      description: `Item ${lineIndex}-${itemIndex}-${cartIndex}`,
                      itemCode: `ITEM${lineIndex}${itemIndex}${cartIndex}`,
                    }),
                  ),
                },
              })),
            })),
          },
        },
      };

      // const startTime = performance.now();
      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={largeCartDetails} />,
      );
      // const endTime = performance.now();

      // Should render without significant performance issues
      // expect(endTime - startTime).toBeLessThan(2000); // 2 second threshold for large dataset
      // expect(screen.getByTestId('items-at-glance')).toBeInTheDocument();
    });
  });

  describe('Accessibility', () => {
    it('should have proper ARIA labels', () => {
      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={createCartDetails()} />,
      );

      const modal = screen.getByRole('dialog');
      // Check for aria-labelledby which VDS Modal uses instead of aria-label
      expect(modal).toHaveAttribute('aria-labelledby');
      expect(modal).toHaveAttribute('aria-describedby');
      expect(modal).toHaveAttribute('aria-modal', 'true');
    });

    it('should be keyboard accessible', async () => {
      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={createCartDetails()} />,
      );

      const closeButton = screen.getByTestId('close-button');

      // Focus the close button
      closeButton.focus();
      expect(closeButton).toHaveFocus();

      // Press Enter to trigger click
      fireEvent.keyDown(closeButton, { key: 'Enter', code: 'Enter' });
      fireEvent.click(closeButton);

      expect(mockHandleToggle).toHaveBeenCalledWith('');
    });
  });

  describe('Specific Line Coverage Tests', () => {
    it('should cover handleSelectChange function line 124', () => {
      // Test line 124 - setSelectedLineNumber(event.target.value)
      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={createCartDetails()} />,
      );

      const select = screen.getByTestId('select');
      
      // Trigger the change event to cover line 124
      fireEvent.change(select, { target: { value: '1234567890' } });

      // Verify the select value changed (this covers setSelectedLineNumber call)
      expect(select.value).toBe('1234567890');
    });

    it('should cover styled component conditional rendering line 38', () => {
      // Test styled component with scmDeviceMfeEnable true
      window.mfe.scmDeviceMfeEnable = true;
      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={createCartDetails()} />,
      );

      let modalWrapper = screen.getAllByTestId('items-at-glance')[0];
      expect(modalWrapper).toBeInTheDocument();

      // Test styled component with scmDeviceMfeEnable false
      window.mfe.scmDeviceMfeEnable = false;
      const { rerender } = renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={createCartDetails()} />,
      );

      rerender(
        <BrowserRouter>
          <StoreProvider>
            <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={createCartDetails()} />
          </StoreProvider>
        </BrowserRouter>,
      );

      modalWrapper = screen.getAllByTestId('items-at-glance');
      expect(modalWrapper[0]).toBeInTheDocument();
    });
  });

  describe('Advanced Component Functionality', () => {
    it('should handle complex cart structures with multiple item types', () => {
      const complexCartDetails = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                serviceInfo: {
                  primaryUserInfo: { firstName: 'John', lastName: 'Doe' },
                  mtn: '1234567890',
                },
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: [
                        createCartItem({
                          description: 'Device Item',
                          itemCode: 'DEVICE001',
                          itemPrice: 599.99,
                          sedOfferList: {
                            sedOffer: [
                              { offerId: 'DEVICE_OFFER', discAmt: 50 },
                            ],
                          },
                          manualDiscount: { discountAmount: 25 },
                          depletionType: 'L',
                          depletionLocation: 'WAREHOUSE001',
                        }),
                        createCartItem({
                          description: 'Accessory Item',
                          itemCode: 'ACC001',
                          itemPrice: 29.99,
                          sedOfferList: null,
                          manualDiscount: null,
                          depletionType: 'S',
                          depletionLocation: 'STORE001',
                        }),
                      ],
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={complexCartDetails} />,
      );

      // Verify device item details
      expect(screen.getByText('Device Item')).toBeInTheDocument();
      expect(screen.getByText('item #:DEVICE001')).toBeInTheDocument();
      expect(screen.getByText('599.99')).toBeInTheDocument();
      expect(screen.getByText('DEVICE_OFFER')).toBeInTheDocument();
      expect(screen.getByText('50')).toBeInTheDocument();
      expect(screen.getByText('$25')).toBeInTheDocument();
      expect(screen.getByText('WAREHOUSE001')).toBeInTheDocument();

      // Verify accessory item details
      expect(screen.getByText('Accessory Item')).toBeInTheDocument();
      expect(screen.getByText('item #:ACC001')).toBeInTheDocument();
      expect(screen.getByText('29.99')).toBeInTheDocument();
      
      // Verify default values for null fields
      const zeroElements = screen.getAllByText('0');
      expect(zeroElements.length).toBeGreaterThanOrEqual(2);
      
      const dollarZeroElements = screen.getAllByText('$0');
      expect(dollarZeroElements.length).toBeGreaterThanOrEqual(1);
    });

    it('should render table headers correctly', () => {
      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={createCartDetails()} />,
      );

      // Check all table headers
      expect(screen.getByText('Items Info')).toBeInTheDocument();
      expect(screen.getByText('Price/Unit')).toBeInTheDocument();
      expect(screen.getByText('Qty')).toBeInTheDocument();
      expect(screen.getByText('Taxes, Surcharges & Gov Fees')).toBeInTheDocument();
      expect(screen.getByText('Total')).toBeInTheDocument();
      expect(screen.getByText('Offer Id')).toBeInTheDocument();
      expect(screen.getByText('Offer Amt')).toBeInTheDocument();
      expect(screen.getByText('Manual Discount')).toBeInTheDocument();
      expect(screen.getByText('Reb Ind')).toBeInTheDocument();
      expect(screen.getByText('Qty Ret')).toBeInTheDocument();
      expect(screen.getByText('Ware House')).toBeInTheDocument();
    });

    it('should handle dropdown option rendering with multiple lines', () => {
      const multiLineCartDetails = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                serviceInfo: {
                  primaryUserInfo: { firstName: 'John', lastName: 'Doe' },
                  mtn: '1111111111',
                },
                itemsInfo: [{ cartItems: { cartItem: [createCartItem()] } }],
              },
              {
                serviceInfo: {
                  primaryUserInfo: { firstName: 'Jane', lastName: 'Smith' },
                  mtn: '2222222222',
                },
                itemsInfo: [{ cartItems: { cartItem: [createCartItem()] } }],
              },
              {
                serviceInfo: {
                  primaryUserInfo: { firstName: 'Bob', lastName: 'Johnson' },
                  mtn: '3333333333',
                },
                itemsInfo: [{ cartItems: { cartItem: [createCartItem()] } }],
              },
            ],
          },
        },
      };

      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={multiLineCartDetails} />,
      );

      // Verify line information is displayed
      expect(screen.getByText('John Doe')).toBeInTheDocument();
      expect(screen.getByText('Jane Smith')).toBeInTheDocument();
      expect(screen.getByText('Bob Johnson')).toBeInTheDocument();
      
      const phoneElements1111 = screen.getAllByText('1111111111');
      expect(phoneElements1111.length).toBeGreaterThan(0);
      const phoneElements2222 = screen.getAllByText('2222222222');
      expect(phoneElements2222.length).toBeGreaterThan(0);
      const phoneElements3333 = screen.getAllByText('3333333333');
      expect(phoneElements3333.length).toBeGreaterThan(0);
    });

    it('should handle different manual discount scenarios', () => {
      const cartDetails = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                serviceInfo: {
                  primaryUserInfo: { firstName: 'John', lastName: 'Doe' },
                  mtn: '1234567890',
                },
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: [
                        createCartItem({
                          description: 'Item with positive discount',
                          manualDiscount: { discountAmount: 15.50 },
                        }),
                        createCartItem({
                          description: 'Item with zero discount',
                          manualDiscount: { discountAmount: 0 },
                        }),
                        createCartItem({
                          description: 'Item with negative discount',
                          manualDiscount: { discountAmount: -5 },
                        }),
                      ],
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetails} />,
      );

      expect(screen.getByText('$15.5')).toBeInTheDocument();
      
      // Should display $0 for zero and negative discounts
      const dollarZeroElements = screen.getAllByText('$0');
      expect(dollarZeroElements.length).toBeGreaterThanOrEqual(2);
    });

    it('should handle items with different depletion types', () => {
      const cartDetails = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                serviceInfo: {
                  primaryUserInfo: { firstName: 'John', lastName: 'Doe' },
                  mtn: '1234567890',
                },
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: [
                        createCartItem({
                          description: 'Local Item',
                          depletionType: 'L',
                          depletionLocation: 'LOCAL_WAREHOUSE',
                        }),
                        createCartItem({
                          description: 'Store Item',
                          depletionType: 'S',
                          depletionLocation: 'STORE_LOCATION',
                        }),
                        createCartItem({
                          description: 'Other Item',
                          depletionType: 'O',
                          depletionLocation: 'OTHER_LOCATION',
                        }),
                      ],
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetails} />,
      );

      expect(screen.getByText('LOCAL_WAREHOUSE')).toBeInTheDocument();
      
      // For non-'L' types, should use session storage value
      const sessionValues = screen.getAllByText('1000001');
      expect(sessionValues.length).toBeGreaterThanOrEqual(2);
    });
  });

  describe('Modal Interaction and State Management', () => {
    it('should handle modal opening and closing via keyboard', async () => {
      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={createCartDetails()} />,
      );

      const closeButton = screen.getByTestId('close-button');

      // Test Space key
      fireEvent.keyDown(closeButton, { key: ' ', code: 'Space' });
      expect(mockHandleToggle).toHaveBeenCalledWith('');

      jest.clearAllMocks();

      // Test Enter key
      fireEvent.keyDown(closeButton, { key: 'Enter', code: 'Enter' });
      expect(mockHandleToggle).toHaveBeenCalledWith('');
    });

    it('should handle modal state changes properly', async () => {
      const { rerender } = renderWithProviders(
        <ItemsAtGlance value={false} handleToggle={mockHandleToggle} cartDetails={createCartDetails()} />,
      );

      // Should not show modal content when closed
      expect(screen.queryByText('Items At Glance')).not.toBeInTheDocument();

      // Open modal
      rerender(
        <BrowserRouter>
          <StoreProvider>
            <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={createCartDetails()} />
          </StoreProvider>
        </BrowserRouter>,
      );

      await waitFor(() => {
        expect(screen.getByText('Items At Glance')).toBeInTheDocument();
      });

      // Close modal
      rerender(
        <BrowserRouter>
          <StoreProvider>
            <ItemsAtGlance value={false} handleToggle={mockHandleToggle} cartDetails={createCartDetails()} />
          </StoreProvider>
        </BrowserRouter>,
      );

      await waitFor(() => {
        expect(screen.queryByText('Items At Glance')).not.toBeInTheDocument();
      });
    });

    it('should handle dropdown selection changes', async () => {
      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={createCartDetails()} />,
      );

      const select = screen.getByTestId('select');
      
      // Initial value should be 'all'
      expect(select.value).toBe('all');

      // Change selection using fireEvent
      fireEvent.change(select, { target: { value: '1234567890' } });
      expect(select.value).toBe('1234567890');

      // Change back to 'all'
      fireEvent.change(select, { target: { value: 'all' } });
      expect(select.value).toBe('all');
    });
  });

  describe('Data Transformation and Utility Functions', () => {
    it('should properly transform cart item data', () => {
      const testItem = {
        id: 'test-123',
        description: 'Test Product',
        itemCode: 'PROD123',
        itemPrice: 199.99,
        qty: 2,
        taxAmount: 20,
        discountedPrice: 180,
        sedOfferList: {
          sedOffer: [{ offerId: 'TEST_OFFER', discAmt: 19.99 }],
        },
        manualDiscount: { discountAmount: 10 },
        depletionType: 'L',
        depletionLocation: 'TEST_WAREHOUSE',
        itemsInfo: { status: 'Active' },
      };

      const cartDetails = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                serviceInfo: {
                  primaryUserInfo: { firstName: 'John', lastName: 'Doe' },
                  mtn: '1234567890',
                },
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: [testItem],
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetails} />,
      );

      // Verify all transformed data is displayed correctly
      expect(screen.getByText('Test Product')).toBeInTheDocument();
      expect(screen.getByText('item #:PROD123')).toBeInTheDocument();
      expect(screen.getByText('Status:Active')).toBeInTheDocument();
      expect(screen.getByText('199.99')).toBeInTheDocument();
      expect(screen.getByText('2')).toBeInTheDocument();
      expect(screen.getByText('$20')).toBeInTheDocument();
      expect(screen.getByText('$180')).toBeInTheDocument();
      expect(screen.getByText('TEST_OFFER')).toBeInTheDocument();
      expect(screen.getByText('19.99')).toBeInTheDocument();
      expect(screen.getByText('$10')).toBeInTheDocument();
      expect(screen.getByText('TEST_WAREHOUSE')).toBeInTheDocument();
    });

    it('should handle missing item properties gracefully', () => {
      const incompleteItem = {
        description: 'Incomplete Item',
        // Missing most properties
      };

      const cartDetails = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                serviceInfo: {
                  primaryUserInfo: { firstName: 'John', lastName: 'Doe' },
                  mtn: '1234567890',
                },
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: [incompleteItem],
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetails} />,
      );

      expect(screen.getByText('Incomplete Item')).toBeInTheDocument();
      
      // Should handle undefined values gracefully
      expect(screen.getByText('item #:')).toBeInTheDocument(); // empty itemCode
      expect(screen.getByText('Status:')).toBeInTheDocument(); // empty status
    });
  });

  describe('Session Storage Integration', () => {
    it('should handle various session storage scenarios', () => {
      // Test with custom session storage value
      mockSessionStorage.getItem.mockReturnValue('CUSTOM_LOCATION');
      
      const cartDetails = createCartDetails({
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ...createLineInfo(),
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: [createCartItem({ depletionType: 'S' })],
                    },
                  },
                ],
              },
            ],
          },
        },
      });

      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetails} />,
      );

      expect(screen.getByText('CUSTOM_LOCATION')).toBeInTheDocument();
      expect(mockSessionStorage.getItem).toHaveBeenCalledWith('ROorderLocationCode');
    });

    it('should handle empty string in session storage', () => {
      mockSessionStorage.getItem.mockReturnValue('');
      
      const cartDetails = createCartDetails({
        cart: {
          lineDetails: {
            lineInfo: [
              {
                ...createLineInfo(),
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: [createCartItem({ depletionType: 'S' })],
                    },
                  },
                ],
              },
            ],
          },
        },
      });

      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetails} />,
      );

      expect(screen.getByText('1000001')).toBeInTheDocument(); // Default fallback
    });
  });

  describe('Component Props and PropTypes', () => {
    it('should handle all prop combinations', () => {
      // Test with minimal props
      renderWithProviders(<ItemsAtGlance />);
      expect(screen.getByTestId('items-at-glance')).toBeInTheDocument();

      // Test with all props
      renderWithProviders(
        <ItemsAtGlance
          value
          handleToggle={mockHandleToggle}
          cartDetails={createCartDetails()}
        />,
      );
      expect(screen.getByText('Items At Glance')).toBeInTheDocument();
    });

    it('should handle undefined cartDetails', () => {
      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={undefined} />,
      );
      expect(screen.getByTestId('items-at-glance')).toBeInTheDocument();
    });
  });

  describe('Responsive and Visual Elements', () => {
    it('should render all visual elements correctly', () => {
      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={createCartDetails()} />,
      );

      // Check for title
      expect(screen.getByText('Items At Glance')).toBeInTheDocument();
      
      // Check for close icon (by testing the close button)
      expect(screen.getByTestId('close-button')).toBeInTheDocument();
      
      // Check for dropdown
      expect(screen.getByTestId('select')).toBeInTheDocument();
      
      // Check for table
      expect(screen.getByTestId('table')).toBeInTheDocument();
      
      // Check for "All Lines" option
      expect(screen.getByText('All Lines')).toBeInTheDocument();
    });

    it('should apply correct styling classes', () => {
      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={createCartDetails()} />,
      );

      const modalWrapper = screen.getByTestId('items-at-glance');
      expect(modalWrapper).toBeInTheDocument();
      expect(modalWrapper).toHaveAttribute('data-testid', 'items-at-glance');
    });
  });

  describe('Comprehensive Function Coverage Tests', () => {
    it('should cover transformCartItem function with all edge cases', () => {
      const testCases = [
        // Case 1: Complete item with all properties
        {
          item: {
            id: 'test-1',
            description: 'Complete Item',
            itemCode: 'COMP001',
            itemPrice: 100,
            qty: 2,
            taxAmount: 15,
            discountedPrice: 85,
            sedOfferList: { sedOffer: [{ offerId: 'OFFER1', discAmt: 10 }] },
            manualDiscount: { discountAmount: 5 },
            depletionType: 'L',
            depletionLocation: 'WAREHOUSE1',
            itemsInfo: { status: 'Active' },
          },
          expectedId: 'test-1',
        },
        // Case 2: Item without ID (should use index)
        {
          item: {
            description: 'No ID Item',
            itemCode: 'NOID001',
            itemPrice: 50,
            qty: 1,
          },
          expectedId: 2, // index will be used
        },
        // Case 3: Item with undefined/null properties
        {
          item: {
            description: 'Minimal Item',
            itemCode: null,
            itemPrice: undefined,
            sedOfferList: null,
            manualDiscount: null,
            itemsInfo: null,
          },
          expectedId: 3,
        },
      ];

      const cartDetails = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                serviceInfo: {
                  primaryUserInfo: { firstName: 'Test', lastName: 'User' },
                  mtn: '1234567890',
                },
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: testCases.map(tc => tc.item),
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetails} />,
      );

      // Verify all items are rendered
      expect(screen.getByText('Complete Item')).toBeInTheDocument();
      expect(screen.getByText('No ID Item')).toBeInTheDocument();
      expect(screen.getByText('Minimal Item')).toBeInTheDocument();
    });

    it('should cover renderCartItemRows with null and invalid inputs', () => {
      const cartDetailsWithNullItems = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                serviceInfo: {
                  primaryUserInfo: { firstName: 'Test', lastName: 'User' },
                  mtn: '1234567890',
                },
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: null, // This should return null
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetailsWithNullItems} />,
      );

      // Component should render without errors
      const modalWrappers = screen.getAllByTestId('items-at-glance');
      expect(modalWrappers[0]).toBeInTheDocument();

      // Test with non-array cartItems
      const cartDetailsWithInvalidItems = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                serviceInfo: {
                  primaryUserInfo: { firstName: 'Test', lastName: 'User' },
                  mtn: '1234567890',
                },
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: 'invalid-string', // This should return null
                    },
                  },
                ],
              },
            ],
          },
        },
      };

       renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetailsWithInvalidItems} />,
      );

      // Component should still render without errors
      const modalWrappers2 = screen.getAllByTestId('items-at-glance');
      expect(modalWrappers2[0]).toBeInTheDocument();
    });

    it('should cover renderLineOptions with null and invalid inputs', () => {
      // Test with null lineInfo
      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={{ cart: { lineDetails: { lineInfo: null } } }} />,
      );

      let modalWrappers3 = screen.getAllByTestId('items-at-glance');
      expect(modalWrappers3[0]).toBeInTheDocument();

      // Test with non-array lineInfo
      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={{ cart: { lineDetails: { lineInfo: 'invalid' } } }} />,
      );

      modalWrappers3 = screen.getAllByTestId('items-at-glance');
      expect(modalWrappers3[0]).toBeInTheDocument();
    });

    it('should cover renderLineTables with various edge cases', () => {
      const edgeCaseCartDetails = {
        cart: {
          lineDetails: {
            lineInfo: [
              // Case 1: lineItem without itemsInfo
              {
                serviceInfo: {
                  primaryUserInfo: { firstName: 'User1', lastName: 'Test' },
                  mtn: '1111111111',
                },
                itemsInfo: null,
              },
              // Case 2: lineItem with non-array itemsInfo
              {
                serviceInfo: {
                  primaryUserInfo: { firstName: 'User2', lastName: 'Test' },
                  mtn: '2222222222',
                },
                itemsInfo: 'invalid',
              },
              // Case 3: lineItem with itemsInfo containing null cartItems
              {
                serviceInfo: {
                  primaryUserInfo: { firstName: 'User3', lastName: 'Test' },
                  mtn: '3333333333',
                },
                itemsInfo: [
                  {
                    cartItems: null,
                  },
                ],
              },
              // Case 4: lineItem with itemsInfo containing invalid cartItems structure
              {
                serviceInfo: {
                  primaryUserInfo: { firstName: 'User4', lastName: 'Test' },
                  mtn: '4444444444',
                },
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: null,
                    },
                  },
                ],
              },
              // Case 5: Valid lineItem for comparison
              {
                serviceInfo: {
                  primaryUserInfo: { firstName: 'User5', lastName: 'Test' },
                  mtn: '5555555555',
                },
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: [createCartItem({ description: 'Valid Item' })],
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={edgeCaseCartDetails} />,
      );

      // Should render without errors and show the valid item
      expect(screen.getByText('Valid Item')).toBeInTheDocument();
      expect(screen.getByText('User5 Test')).toBeInTheDocument();
    });

    it('should cover all conditional branches in manual discount rendering', () => {
      const discountTestCases = [
        // Case 1: manualDiscount with positive amount
        createCartItem({
          description: 'Positive Discount Item',
          manualDiscount: { discountAmount: 25.50 },
        }),
        // Case 2: manualDiscount with zero amount
        createCartItem({
          description: 'Zero Discount Item',
          manualDiscount: { discountAmount: 0 },
        }),
        // Case 3: manualDiscount with negative amount
        createCartItem({
          description: 'Negative Discount Item',
          manualDiscount: { discountAmount: -10 },
        }),
        // Case 4: null manualDiscount
        createCartItem({
          description: 'Null Discount Item',
          manualDiscount: null,
        }),
        // Case 5: undefined manualDiscount
        createCartItem({
          description: 'Undefined Discount Item',
          manualDiscount: undefined,
        }),
      ];

      const cartDetails = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                serviceInfo: {
                  primaryUserInfo: { firstName: 'Test', lastName: 'User' },
                  mtn: '1234567890',
                },
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: discountTestCases,
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetails} />,
      );

      // Verify all items are rendered
      expect(screen.getByText('Positive Discount Item')).toBeInTheDocument();
      expect(screen.getByText('Zero Discount Item')).toBeInTheDocument();
      expect(screen.getByText('Negative Discount Item')).toBeInTheDocument();
      expect(screen.getByText('Null Discount Item')).toBeInTheDocument();
      expect(screen.getByText('Undefined Discount Item')).toBeInTheDocument();

      // Check discount amounts
      expect(screen.getByText('$25.5')).toBeInTheDocument(); // Positive discount
      const zeroDiscounts = screen.getAllByText('$0');
      expect(zeroDiscounts.length).toBeGreaterThanOrEqual(4); // Zero, negative, null, undefined should all show $0
    });

    it('should cover keyboard navigation for close button', () => {
      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={createCartDetails()} />,
      );

      const closeButton = screen.getByTestId('close-button');

      // Test Enter key
      fireEvent.keyDown(closeButton, { key: 'Enter', code: 'Enter' });
      expect(mockHandleToggle).toHaveBeenCalledWith('');

      jest.clearAllMocks();

      // Test Space key
      fireEvent.keyDown(closeButton, { key: ' ', code: 'Space' });
      expect(mockHandleToggle).toHaveBeenCalledWith('');

      jest.clearAllMocks();

      // Test other keys (should not trigger)
      fireEvent.keyDown(closeButton, { key: 'Escape', code: 'Escape' });
      expect(mockHandleToggle).not.toHaveBeenCalled();

      fireEvent.keyDown(closeButton, { key: 'Tab', code: 'Tab' });
      expect(mockHandleToggle).not.toHaveBeenCalled();
    });

    it('should cover all branches of getLocationCode function', () => {
      const locationTestCases = [
        // Case 1: depletionType 'L' should return depletionLocation
        {
          item: createCartItem({
            description: 'Local Depletion Item',
            depletionType: 'L',
            depletionLocation: 'LOCAL_WAREHOUSE_123',
          }),
          expectedLocation: 'LOCAL_WAREHOUSE_123',
        },
        // Case 2: depletionType 'S' with session storage value
        {
          item: createCartItem({
            description: 'Store Depletion Item',
            depletionType: 'S',
            depletionLocation: 'STORE_LOCATION',
          }),
          expectedLocation: '1000001', // Default from mock
        },
        // Case 3: Other depletionType
        {
          item: createCartItem({
            description: 'Other Depletion Item',
            depletionType: 'O',
            depletionLocation: 'OTHER_LOCATION',
          }),
          expectedLocation: '1000001', // Default from mock
        },
      ];

      // Test with custom session storage value
      mockSessionStorage.getItem.mockReturnValue('CUSTOM_SESSION_LOCATION');

      const cartDetails = {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                serviceInfo: {
                  primaryUserInfo: { firstName: 'Test', lastName: 'User' },
                  mtn: '1234567890',
                },
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: locationTestCases.map(tc => tc.item),
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      renderWithProviders(
        <ItemsAtGlance value handleToggle={mockHandleToggle} cartDetails={cartDetails} />,
      );

      // Verify all items are rendered
      expect(screen.getByText('Local Depletion Item')).toBeInTheDocument();
      expect(screen.getByText('Store Depletion Item')).toBeInTheDocument();
      expect(screen.getByText('Other Depletion Item')).toBeInTheDocument();

      // Verify location codes
      expect(screen.getByText('LOCAL_WAREHOUSE_123')).toBeInTheDocument(); // L type returns depletionLocation
      const customSessionElements = screen.getAllByText('CUSTOM_SESSION_LOCATION');
      expect(customSessionElements.length).toBeGreaterThanOrEqual(2); // S and O types use session storage
    });
  });
});
