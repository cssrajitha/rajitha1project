import React, { useState, useMemo, useEffect } from 'react';
import PropTypes from 'prop-types';
import styled, { createGlobalStyle } from 'styled-components';
import { Icon } from '@vds/icons';
import { Modal } from '@vds/modals';
import { Title, Body } from '@vds/typography';
import { DropdownSelect } from '@vds/selects';
import { Table, TableHead, TableHeader, TableBody, TableRow, Cell } from '@vds/tables';
import { themeIconColor, themeSurface, themeTableHeaderBgColor, themeTextColor } from '../constants/constants';

const headerData = [
  { id: 1, heading: 'Items Info' },
  { id: 2, heading: 'Price/Unit' },
  { id: 3, heading: 'Qty' },
  { id: 4, heading: 'Taxes, Surcharges & Gov Fees' },
  { id: 5, heading: 'Total' },
  { id: 6, heading: 'Offer Id' },
  { id: 7, heading: 'Offer Amt' },
  { id: 8, heading: 'Manual Discount' },
  { id: 9, heading: 'Reb Ind' },
  { id: 10, heading: 'Qty Ret' },
  { id: 11, heading: 'Ware House' },
];

export const ModalWrapper = styled.div`
  background-color: ${({ scmDeviceMfeEnable }) => (!scmDeviceMfeEnable ? '#fff' : 'rgb(0 0 0 / 70%)')};
`;

const ComponentStyle = createGlobalStyle`

    [class^='ModalDialog-VDS'] {
      padding-top: 0;
      width: 100%;
      max-width: 1133px !important;
    }

    [class^='Overlay-VDS']{
    background: ${({ scmDeviceMfeEnable }) => (!scmDeviceMfeEnable ? '#fff' : 'rgb(0 0 0 / 70%)')};
    }

    [id="close-button"]{
    opacity: 0;
    }

`;

export const Header = styled.div`
  box-sizing: border-box;
  margin: 0 -8px;
  padding: 0;
`;

export const TitleWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  margin: 10px;
`;

const SelectWrapper = styled.div`
  [class^='SelectContainer-VDS'] {
    border-bottom: 1px solid black;
    border-top: none;
    border-left: none;
    border-right: none;
    border-radius: 0px;
    width: 21%;
    margin-top: 10px;
    margin-left: 5px;
  }
`;

export const IconWrapper = styled.div`
  cursor: pointer;
  color: #000000 !important;
`;

export const TableWrapper = styled.div`
  border: none !important;
  border-collapse: collapse;
  border-spacing: 0px;
  text-align: left;
  width: 100%;
  font-family: BrandFont-Text, Helvetica, Arial, sans-serif;
  font-size: 0.875rem;
  margin-bottom: 2rem;
  padding-top: 2rem;

  [class^='TableTR-VDS'] {
    background: #e4e5e3;
    border-bottom: 0.07143rem solid #d8dada !important;
    border: 0.0625rem solid #d8dada !important;
  }
  [class^=' StyledTableRow-VDS '] {
    border: 0.0625rem solid #d8dada !important;
  }
  [class^='StyledCell-VDS'] {
    border: 0.0625rem solid #d8dada;
    line-height: 1.2 !important;
    padding: 0.875rem 1.3125rem 1.25rem 0.3125rem !important;
  }
`;

export const Divider = styled.div`
  border-bottom: 1px solid #d8dada;
`;

const DetailsWrapper = styled.div`
  margin-top: 50px;
  margin-left: 2px;
`;

const ItemsAtGlance = ({ value, handleToggle, cartDetails }) => {
  const scmDeviceMfeEnable = window?.mfe?.scmDeviceMfeEnable;
  const [selectedLineNumber, setSelectedLineNumber] = useState('all');
  const [open, setOpen] = useState(value);

  // Update open state when value prop changes
  useEffect(() => {
    setOpen(value);
  }, [value]);

  // Handle select change
  const handleSelectChange = (event) => {
    setSelectedLineNumber(event.target.value);
  };
  const getLocationCode = (depletionType, depletionLocation) => {
    if (depletionType === 'L') {
      return depletionLocation;
    }
    const OrderLocation = sessionStorage.getItem('ROorderLocationCode');
    return OrderLocation || '1000001';
  };

  // Helper function to transform cart item data
  const transformCartItem = (item, index) => ({
    id: item.id || index,
    description: item.description,
    itemCode: item.itemCode,
    itemPrice: item.itemPrice,
    qty: item.qty,
    taxAmount: item.taxAmount,
    discountedPrice: item.discountedPrice,
    sedOfferList: item?.sedOfferList,
    manualDiscount: item.manualDiscount,
    depletionType: item.depletionType,
    depletionLocation: item.depletionLocation,
    status: item?.itemsInfo?.status,
  });

  // Helper function to render table rows for cart items
  const renderCartItemRows = (cartItems) => {
    if (!cartItems || !Array.isArray(cartItems)) return null;

    return cartItems.map((item, index) => {
      const transformedItem = transformCartItem(item, index);

      return (
        <TableRow key={transformedItem.id}>
          <Cell style={{ color: themeTextColor() }}>
            <p style={{ fontWeight: 800 }}>{transformedItem.description}</p>
            <p>item #:{transformedItem.itemCode}</p>
            <p>Status:{transformedItem.status}</p>
          </Cell>
          <Cell style={{ color: themeTextColor() }}>{transformedItem.itemPrice}</Cell>
          <Cell style={{ color: themeTextColor() }}>{transformedItem.qty}</Cell>
          <Cell>${transformedItem.taxAmount}</Cell>
          <Cell style={{ color: themeTextColor() }}>${transformedItem.discountedPrice}</Cell>
          <Cell style={{ color: themeTextColor() }}>{transformedItem.sedOfferList?.sedOffer?.[0]?.offerId || 0}</Cell>
          <Cell style={{ color: themeTextColor() }}>{transformedItem.sedOfferList?.sedOffer?.[0]?.discAmt || 0.0}</Cell>
          <Cell style={{ fontWeight: 800 }}>
            ${transformedItem.manualDiscount?.discountAmount > 0 ? transformedItem.manualDiscount.discountAmount : 0.0}
          </Cell>
          <Cell style={{ color: themeTextColor() }}>-</Cell>
          <Cell style={{ color: themeTextColor() }}>-</Cell>
          <Cell style={{ color: themeTextColor() }}>
            {getLocationCode(transformedItem.depletionType, transformedItem.depletionLocation)}
          </Cell>
        </TableRow>
      );
    });
  };

  // Helper function to render dropdown options for line info
  const renderLineOptions = (lineInfo) => {
    if (!lineInfo || !Array.isArray(lineInfo)) return null;

    return lineInfo.map((item) => (
      <optgroup>
        <option>
          <Body size='medium' bold={false}>
            {item?.serviceInfo?.primaryUserInfo?.firstName}
          </Body>
        </option>
        <option>
          <Body size='medium' bold={false}>
            {item?.serviceInfo?.mtn}
          </Body>
        </option>
      </optgroup>
    ));
  };

  // Helper function to render tables for each line
  const renderLineTables = (lineInfo) => {
    if (!lineInfo || !Array.isArray(lineInfo)) return null;

    return lineInfo.map((lineItem) => {
      if (!lineItem?.itemsInfo || !Array.isArray(lineItem.itemsInfo)) return null;

      return lineItem.itemsInfo.map((itemInfo) => {
        if (!itemInfo?.cartItems?.cartItem) return null;

        return (
          <DetailsWrapper>
            <Title size='small' color={themeTextColor()} bold={false}>
              {`${lineItem?.serviceInfo?.primaryUserInfo?.firstName} ${lineItem?.serviceInfo?.primaryUserInfo?.lastName}`}
            </Title>
            <Title size='small' color={themeTextColor()} bold>
              {lineItem?.serviceInfo?.mtn}
            </Title>
            <Table striped={false}>
              <TableHead bottomLine='primary'>
                {headerData.map((data) => (
                  <TableHeader
                    key={data.id}
                    style={{ color: themeTextColor(), backgroundColor: themeTableHeaderBgColor() }}
                  >
                    {data.heading}
                  </TableHeader>
                ))}
              </TableHead>
              <TableBody>{renderCartItemRows(itemInfo.cartItems.cartItem)}</TableBody>
            </Table>
          </DetailsWrapper>
        );
      });
    });
  };

  // Memoized calculations for performance
  const lineInfo = useMemo(() => cartDetails?.cart?.lineDetails?.lineInfo || [], [cartDetails]);

  const content = (
    <>
      <Header>
        <TitleWrapper>
          <Title size='small' color={themeTextColor()} bold>
            Items At Glance
          </Title>
          <IconWrapper
            onClick={() => {
              setOpen(false);
              handleToggle('');
            }}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                setOpen(false);
                handleToggle('');
              }
            }}
            data-testid='close-button'
            name='close-glance'
            tabIndex={0}
            role="button"
            aria-label="Close Items At Glance modal"
          >
            <Icon name='close' size='medium' color={themeIconColor()} />
          </IconWrapper>
        </TitleWrapper>
        <Divider />
      </Header>
      <DetailsWrapper style={{ color: themeTextColor() }}>
        <SelectWrapper>
          <DropdownSelect
            surface={themeSurface()}
            error={false}
            disabled={false}
            readOnly={false}
            inlineLabel
            value={selectedLineNumber}
            onChange={handleSelectChange}
            data-testid='select'
          >
            <option data-testid='select-option' value='all'>
              All Lines
            </option>
            <Divider />
            {renderLineOptions(lineInfo)}
          </DropdownSelect>
        </SelectWrapper>
      </DetailsWrapper>

      <TableWrapper data-testid='table'>{renderLineTables(lineInfo)}</TableWrapper>
    </>
  );

  return (
    <>
      <ComponentStyle scmDeviceMfeEnable={scmDeviceMfeEnable} />
      <ModalWrapper data-testid='items-at-glance' scmDeviceMfeEnable={scmDeviceMfeEnable}>
        <Modal
          surface={themeSurface()}
          disableAnimation={false}
          disableOutsideClick={false}
          fullScreenDialog={!window?.mfe?.isProspectNewCustomerTab}
          width='100%'
          aria-label='Items At Glance'
          opened={open}
          onOpenedChange={(opened) => !opened && setOpen(false)}
          closeButton={null}
          className={!scmDeviceMfeEnable ? 'my-custom-modal' : ''}
        > 
          {content}
        </Modal>
      </ModalWrapper>
    </>
  );
};

ItemsAtGlance.propTypes = {
  value: PropTypes.bool,
  handleToggle: PropTypes.func,
  cartDetails: PropTypes.object,
};

export default ItemsAtGlance;
