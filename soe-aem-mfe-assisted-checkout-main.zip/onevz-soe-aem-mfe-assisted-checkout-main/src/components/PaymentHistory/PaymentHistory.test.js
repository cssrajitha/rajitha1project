import React from 'react';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import Emitter from 'onevzsoemfeframework/Emitter';
import '@testing-library/jest-dom/extend-expect';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { getPaymentMode, getCardTypeFourDigits } from 'onevzsoemfecommon/Helpers/validation';
import PaymentHistoryModal from './PaymentHistory';
import { useLazyGetRetrievePaymentOptionsQuery } from '../../modules/services/APIService/APIServiceCallHook';

jest.mock('onevzsoemfecommon/Helpers/validation', () => ({
  getPaymentMode: jest.fn(),
  getCardTypeFourDigits: jest.fn(),
}));
jest.mock('onevzsoemfeframework/AssistedCradleService', () => ({
  getAssistedCradlePropertyV2: jest.fn(),
}));
jest.mock('../../utils/tagging');

jest.mock('../../modules/services/APIService/APIServiceCallHook');

const mockReadOrderResponse = {
  cart: {
    orderDetails: {
      orderList: [{ orderNumber: 12345 }, { orderNumber: 67890 }],
    },
    cartHeader: {
      cartCreatorChannelId: 'OMNI-TELESALES',
      cartId: '',
    },
  },
};

const mockResponse = {
  data: {
    orders: [
      {
        orderTotal: 100.0,
        totalPaidAmount: 50.0,
        orderBalanceAmount: 50.0,
        paymentDetail: [
          {
            paymentSeqNum: 1,
            modeOfPay: 'CR',
            cardNumber: 'X234567812345678',
            paymentDate: '2023-01-01T12:00:00Z', // Valid date and time
            paymentAmount: 50.0,
          },
          {
            paymentSeqNum: 2,
            modeOfPay: 'CR',
            cardNumber: '',
            paymentDate: '', // Empty paymentDate to trigger fallback to ''
            paymentAmount: 50.0,
          },
          {
            paymentSeqNum: 3,
            modeOfPay: 'IE',
            paymentDate: '2023-01-01', // Only date part to trigger fallback to date
            cardNumber: '123',
            paymentAmount: 50.0,
          },
          {
            paymentSeqNum: 4,
            modeOfPay: 'OTHER',
            cardNumber: '12345678',
            paymentDate: 'T12:00:00Z', // Only time part to trigger fallback to time
            paymentAmount: 50.0,
          },
          {
            paymentSeqNum: 5,
            modeOfPay: 'CR',
            cardNumber: '1234567890123456', // cardNumber length matches cardLength
            paymentDate: undefined, // Undefined paymentDate to trigger fallback to ''
            paymentAmount: 50.0,
          },
        ],
      },
    ],
  },
};

describe('PaymentHistory Component', () => {
  beforeAll(() => {
    Emitter.emit('vtRefreshPayment_event', 'test');
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  beforeEach(() => {
    getAssistedCradlePropertyV2.mockReturnValue(['true']); // Mock it to return a valid array
    useLazyGetRetrievePaymentOptionsQuery.mockReturnValue([jest.fn(), { data: mockResponse.data }]);
    getPaymentMode.mockReturnValue('Other Payment Mode');
    getCardTypeFourDigits.mockReturnValue('****5678');
  });

  test('renders PaymentHistory component', () => {
    render(<PaymentHistoryModal value handleToggle={jest.fn()} readOrderResponse={mockReadOrderResponse} />);
  });

  test('closes modal on button click', () => {
    const handleToggle = jest.fn();
    render(<PaymentHistoryModal value handleToggle={handleToggle} readOrderResponse={mockReadOrderResponse} />);
  });

  test('fetches payment options on mount', async () => {
    const mockGetRetrievePaymentOptionsBody = jest.fn();
    useLazyGetRetrievePaymentOptionsQuery.mockReturnValue([
      mockGetRetrievePaymentOptionsBody,
      { data: mockResponse.data },
    ]);
    render(<PaymentHistoryModal value handleToggle={jest.fn()} readOrderResponse={mockReadOrderResponse} />);
    await waitFor(() => expect(mockGetRetrievePaymentOptionsBody).toHaveBeenCalled());
  });

  test('displays payment details', async () => {
    render(<PaymentHistoryModal value handleToggle={jest.fn()} readOrderResponse={mockReadOrderResponse} />);
  });

  test('closes modal on Done button click', () => {
    const handleToggle = jest.fn();
    render(<PaymentHistoryModal value handleToggle={handleToggle} readOrderResponse={mockReadOrderResponse} />);
  });

  test('displays payment details for different modes of payment', async () => {
    render(<PaymentHistoryModal value handleToggle={jest.fn()} readOrderResponse={mockReadOrderResponse} />);
  });

  test('displays payment details for empty payment details', async () => {
    const emptyPaymentDetailsResponse = {
      data: {
        orders: [
          {
            orderTotal: 100.0,
            totalPaidAmount: 50.0,
            orderBalanceAmount: 50.0,
            paymentDetail: [],
          },
        ],
      },
    };
    useLazyGetRetrievePaymentOptionsQuery.mockReturnValue([jest.fn(), { data: emptyPaymentDetailsResponse.data }]);
    render(<PaymentHistoryModal value handleToggle={jest.fn()} readOrderResponse={mockReadOrderResponse} />);
  });

  test('handles error when fetching payment options fails', async () => {
    useLazyGetRetrievePaymentOptionsQuery.mockReturnValue([jest.fn(), { error: 'Error fetching data' }]);
    render(<PaymentHistoryModal value handleToggle={jest.fn()} readOrderResponse={mockReadOrderResponse} />);
  });

  test('displays payment details for different order statuses', async () => {
    const differentOrderStatusResponse = {
      data: {
        orders: [
          {
            orderTotal: 100.0,
            totalPaidAmount: 50.0,
            orderBalanceAmount: 50.0,
            paymentDetail: [
              {
                paymentSeqNum: 1,
                modeOfPay: 'CR',
                cardNumber: '1234567812345678',
                paymentDate: '2023-01-01T12:00:00Z',
                paymentAmount: 50.0,
              },
            ],
            orderStatus: 'Completed',
          },
        ],
      },
    };
    useLazyGetRetrievePaymentOptionsQuery.mockReturnValue([jest.fn(), { data: differentOrderStatusResponse.data }]);
    render(<PaymentHistoryModal value handleToggle={jest.fn()} readOrderResponse={mockReadOrderResponse} />);
  });
  test('displays card number when channel is not OMNI-TELESALES', async () => {
    // Modify the existing mockReadOrderResponse to set cartCreatorChannelId to 'OTHER-CHANNEL'
    mockReadOrderResponse.cart.cartHeader.cartCreatorChannelId = 'OTHER-CHANNEL';

    // Mock the response for the payment options query
    useLazyGetRetrievePaymentOptionsQuery.mockReturnValue([jest.fn(), { data: mockResponse.data }]);
    getPaymentMode.mockReturnValue('Other Payment Mode');
    getCardTypeFourDigits.mockReturnValue('****5678');

    render(<PaymentHistoryModal value handleToggle={jest.fn()} readOrderResponse={mockReadOrderResponse} />);
  });
  test('covers handleClose function within PaymentHistoryModal', async () => {
    const handleToggleMock = jest.fn();

    // Mock sessionStorage.getItem to return a specific value
    const mockGetItem = jest.fn().mockReturnValue('some-channel');
    Object.defineProperty(window, 'sessionStorage', {
      value: {
        getItem: mockGetItem,
      },
      writable: true,
    });

    // Mock the response for the payment options query
    useLazyGetRetrievePaymentOptionsQuery.mockReturnValue([jest.fn(), { data: mockResponse.data }]);
    getPaymentMode.mockReturnValue('Other Payment Mode');
    getCardTypeFourDigits.mockReturnValue('****5678');

    const { getByTestId } = render(
      <PaymentHistoryModal value handleToggle={handleToggleMock} readOrderResponse={mockReadOrderResponse} />
    );

    // Simulate closing the modal by clicking the close button
    fireEvent.click(getByTestId('View PaymentHistoy Modal is Closed'));
    expect(handleToggleMock).toHaveBeenCalledWith(false);
  });

  // Add this test case to cover the empty cartHeader scenario
  test('handles empty cartHeader gracefully', () => {
    const mockReadOrderResponseWithEmptyCartHeader = {
      cart: {
        orderDetails: {
          orderList: [{ orderNumber: 12345 }, { orderNumber: 67890 }],
        },
        cartHeader: {}, // Empty cartHeader
      },
    };

    render(
      <PaymentHistoryModal
        value
        handleToggle={jest.fn()}
        readOrderResponse={mockReadOrderResponseWithEmptyCartHeader}
      />
    );

    // Add assertions to verify the behavior when cartHeader is empty
    expect(screen.getByTestId('payment-history-modal')).toBeInTheDocument();
    // Add more assertions as needed
  });
  test('excludes rows with modeOfPay === "IE" or "ZD" when paymentHistoryRefundFlag is true', () => {
    const mockResponseWithModes = {
      data: {
        orders: [
          {
            paymentDetail: [
              { paymentSeqNum: 1, modeOfPay: 'IE', paymentAmount: 50.0 },
              { paymentSeqNum: 2, modeOfPay: 'ZD', paymentAmount: 50.0 },
              { paymentSeqNum: 3, modeOfPay: 'CR', paymentAmount: 100.0 },
            ],
          },
        ],
      },
    };

    useLazyGetRetrievePaymentOptionsQuery.mockReturnValue([jest.fn(), { data: mockResponseWithModes.data }]);

    render(
      <PaymentHistoryModal
        value
        handleToggle={jest.fn()}
        readOrderResponse={mockReadOrderResponse}
        paymentHistoryRefundFlag
      />
    );
  });

  test('includes all rows when paymentHistoryRefundFlag is false', () => {
    const mockResponseWithModes = {
      data: {
        orders: [
          {
            paymentDetail: [
              { paymentSeqNum: 1, modeOfPay: 'IE', paymentAmount: 50.0 },
              { paymentSeqNum: 2, modeOfPay: 'ZD', paymentAmount: 50.0 },
              { paymentSeqNum: 3, modeOfPay: 'CR', paymentAmount: 100.0 },
            ],
          },
        ],
      },
    };

    useLazyGetRetrievePaymentOptionsQuery.mockReturnValue([jest.fn(), { data: mockResponseWithModes.data }]);

    render(
      <PaymentHistoryModal
        value
        handleToggle={jest.fn()}
        readOrderResponse={mockReadOrderResponse}
        paymentHistoryRefundFlag={false}
      />
    );
  });
});
