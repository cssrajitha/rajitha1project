import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import Emitter from 'onevzsoemfeframework/Emitter';
import styled, { createGlobalStyle } from 'styled-components';
import { Modal } from '@vds/modals';
import { Icon } from '@vds/icons';
import { Title } from '@vds/typography';
import { Button as VdsButton } from '@vds/buttons';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { Table, TableBody, TableHead, TableHeader, TableRow, Cell } from '@vds/tables';
import moment from 'moment';
import { Line } from '@vds/lines';
import { getPaymentMode, getCardTypeFourDigits } from 'onevzsoemfecommon/Helpers/validation';
import { TableWrapper } from '../ItemsAtGlance/ItemsAtGlance';
import { useLazyGetRetrievePaymentOptionsQuery } from '../../modules/services/APIService/APIServiceCallHook';

const ModalWrapper = styled.div`
  background-color: #ffffff;
`;

const Button = styled(VdsButton)`
  padding: 0 1.5rem 0 1.5rem;
`;

const ComponentStyle = createGlobalStyle`
  [class^='ModalDialog-VDS'] {
    padding-top: 0;
    width: 100%;
    max-width: 1133px !important;
    border-radius: 0 !important; /* Add this line to remove rounded corners */
  }

  [class^='Overlay-VDS'] {
    background: rgb(0 0 0 / 70%);
  }

  [id="close-button"] {
    opacity: 0;
  }
`;

const BackClickable = styled.a`
  cursor: pointer;
  color: #000000 !important;
  align-items: center;
  padding: 1.5rem 1.5rem 1.5rem 0;
`;

const VerticalLine = styled.div`
  border-left: 1px solid #000;
  height: 1.5rem;
  margin: 0 1rem;
`;

const Padding36 = styled.div`
  padding: 1.5rem 2rem;
`;

const TotalContainer = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 2rem 0;
`;

const RemainingContainer = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: 0.5rem;
`;

const FlexAlignContainerItemsCenter = styled.div`
  display: flex;
  align-items: center !important;
  justify-content: space-between;
`;

const FooterArea = styled.div`
  background-color: rgb(255, 255, 255);
  z-index: 1;
  bottom: 0px;
  position: fixed;
  width: 100%;
  display: flex;
  border-top: 1px solid rgb(204, 204, 204);
  justify-content: center;
`;

const FlexBoxGrowOne = styled.div`
  display: flex;
  flex-grow: 1;
  height: 4rem;
  align-items: center;
  gap: 0.3rem;
`;

const CloseIconWrapper = styled.div`
  display: flex;

  a {
    padding: 1rem !important;
  }
`;

const Marginleft = styled.div`
  margin-left: 20px;
`;

const StyledTable = styled(Table)`
  border-collapse: collapse;
  width: 100%;
`;

const StyledTableHeader = styled(TableHeader)`
  background-color: rgb(246, 246, 246);
  text-align: center;
  padding: 0.75rem;
  font-size: 0.875rem;
  border: 1px solid #ddd;
`;

const StyledCell = styled(Cell)`
  text-align: center;
  padding: 0.75rem;
  font-size: 0.875rem;
  color: #000;
  border: 1px solid #ddd;
`;

const PaymentHistoryModal = ({ value, handleToggle, readOrderResponse, readOrder }) => {
  const [open, setOpen] = useState(value);
  const orderList = [readOrderResponse?.cart?.orderDetails?.orderList];
  const [isReadOrderFlag] = getAssistedCradlePropertyV2(['readOrderMfeFFlag']);
  const isReadOrderFlagEnabled = /true/i.test(isReadOrderFlag);
  const isFromReadOrder = readOrder || false;
  const orderNumbers = orderList.flatMap((orderArray) =>
    orderArray?.map((order) => order.orderNumber).filter((orderNumber) => orderNumber !== 0),
  );

  const orderNumbersString = orderNumbers.join('/');

  const cartCreatorChannelId = readOrderResponse?.cart?.cartHeader?.cartCreatorChannelId;

  const [getRetrievePaymentOptionsBody, response] = useLazyGetRetrievePaymentOptionsQuery();
  const vtRefPymtEmitterFFlag = /true/i.test(getAssistedCradlePropertyV2(['vtRefPymtEmitterFFlag'])?.[0]);

  const handleClose = () => {
    setOpen(false);
    handleToggle(false);
  };

  useEffect(() => {
    Emitter.on('vtRefreshPayment_event', (val) => {
      /* istanbul ignore next */
      if (val) {
        callRetreivePaymentOptionsAPI();
      }
    });
    callRetreivePaymentOptionsAPI();

    return () => {
      if( vtRefPymtEmitterFFlag ){
        Emitter.off('vtRefreshPayment_event');
      }
    }
  }, []);

  const callRetreivePaymentOptionsAPI = () => {
    const bodyRetreivePaymentRefund = {
      jobCode: '',
      securityClassCode: '',
      getPaymentHistory: true,
    };
    const bodyRetreivePayment = {
      jobCode: 'SNWP94',
      vzCardApprovalStatusRequired: 'Y',
      getPaymentHistory: true,
      skipPaymentOptions: false,
    };
    getRetrievePaymentOptionsBody({
      body: isReadOrderFlagEnabled && isFromReadOrder ? bodyRetreivePayment : bodyRetreivePaymentRefund,
    });
  };

  const [orderTotal, setOrderTotal] = useState(0);
  const [totalPaid, setTotalPaid] = useState(0);
  const [remainingAmount, setRemainingAmount] = useState(0);
  const [paymentDetail, setPaymentDetail] = useState([]);

  useEffect(() => {
    if (response?.data) {
      if (isFromReadOrder && isReadOrderFlagEnabled) {
        setOrderTotal(response.data?.orderTotalInDB);
      } else {
        setOrderTotal(response.data?.orderTotal);
      }
      setTotalPaid(response.data?.orders[0]?.totalPaidAmount);
      setRemainingAmount(response.data?.orderBalance);
      setPaymentDetail(response.data?.orders[0]?.paymentDetail);
    }
  }, [response]);

  const getModeOfPay = (item) => {
    let mode = '';
    switch (item.modeOfPay) {
      case 'CR':
        mode = item.cardNumber
          ? `${getCardTypeFourDigits(item.cardNumber.substr(0, 4))} ${item.cardNumber.substr(
              item.cardNumber.length - 4,
            )}`
          : '';
        break;
      case 'IE':
        mode = `IE ($${item.paymentAmount})`;
        break;
      default:
        mode = getPaymentMode(item.modeOfPay);
    }
    return mode;
  };

  const getAuthorization = (item, channelId) => {
    let authorization = '';
    const channel = sessionStorage.getItem('channel') || channelId;
    const maskedCardNumber = maskCC(item.cardNumber);
    switch (item.modeOfPay) {
      case 'CR':
        if (item.cardNumber) {
          if (channel === 'OMNI-TELESALES') {
            authorization = maskedCardNumber;
          } else {
            authorization = item.cardNumber;
          }
        } else {
          authorization = '';
        }
        break;
      case 'IE':
        authorization = 'DEVICE PAYMENT';
        break;
      default:
        authorization = '';
    }
    return authorization;
  };

  const maskCC = (ccNumber) => {
    let maskedNumber = '';
    if (ccNumber) {
      const cardNum = ccNumber;

      if (cardNum[0] === 'X') {
        return;
      }
      if (cardNum.length < 4) {
        return;
      }

      const last4 = cardNum.substring(cardNum.length - 4, cardNum.length);
      const firstNums = cardNum.substring(0, cardNum.length - 4);
      maskedNumber = firstNums.replace(/[a-zA-Z0-9]/g, '*');
      maskedNumber += last4;
    }
    return maskedNumber;
  };

  const formatDateTime = (item) => {
    if (!item || !item.paymentDate) {
      return '';
    }

    const rawDate = item.paymentDate.split('T');
    const date = rawDate[0] ? moment(rawDate[0]).format('MM/DD/YYYY') : '';
    const time = rawDate[1] ? rawDate[1].replace(/Z/g, '') : '';
    return date && time ? `${date}  ${time}` : date || time;
  };

  return (
    <>
      <ComponentStyle />
      <ModalWrapper data-testid='payment-history-modal'>
        <Modal
          surface='light'
          disableAnimation={false}
          disableOutsideClick={false}
          fullScreenDialog
          width='100%'
          ariaLabel='Payment History'
          opened={open}
          onOpenedChange={(opened) => !opened && handleClose()}
          closeButton={null}
        >
          <div>
            <FlexAlignContainerItemsCenter>
              <FlexBoxGrowOne>
                <Title size='small' color='#4A4A4A' bold data-testid='payment-history-title'>
                  Payment history
                </Title>
                <VerticalLine />
                <Title size='small' bold data-testid='order-number-title'>
                  Order Number:
                </Title>
                <Title size='small' data-testid='order-number'>
                  {orderNumbersString}
                </Title>
              </FlexBoxGrowOne>
              <CloseIconWrapper>
                <Marginleft>
                  <BackClickable data-testid='View PaymentHistoy Modal is Closed' onClick={handleClose}>
                    <Icon name='close' size='large' />
                  </BackClickable>
                </Marginleft>
              </CloseIconWrapper>
            </FlexAlignContainerItemsCenter>
            <Line type='secondary' />
            <TotalContainer>
              <Title size='small' color='#4A4A4A' bold data-testid='order-total-title'>
                Order total
              </Title>
              <Title size='small' bold data-testid='order-total'>
                ${orderTotal}
              </Title>
            </TotalContainer>
            {response?.error || !response?.data ? (
              <Title size='small' data-testid='no-data'>
                No Data
              </Title>
            ) : (
              <TableWrapper>
                <StyledTable striped={false} bottomLine='secondary' padding='compact'>
                  <TableHead bottomLine='primary' padding='standard'>
                    <StyledTableHeader data-testid='table-header-type'>Type</StyledTableHeader>
                    <StyledTableHeader data-testid='table-header-authorization'>Authorization</StyledTableHeader>
                    <StyledTableHeader data-testid='table-header-date'>Date</StyledTableHeader>
                    <StyledTableHeader data-testid='table-header-amount'>Amount</StyledTableHeader>
                  </TableHead>
                  <TableBody>
                    {paymentDetail
                      ?.filter((detail) => {
                        if (!isFromReadOrder) {
                          return detail.modeOfPay !== 'IE' && detail.modeOfPay !== 'ZD';
                        }
                        return true;
                      })
                      .map((detail) => (
                        <TableRow key={detail.paymentSeqNum} data-testid='payment-detail-row'>
                          <StyledCell data-testid='payment-detail-type'>{getModeOfPay(detail)}</StyledCell>
                          <StyledCell data-testid='payment-detail-authorization'>
                            {getAuthorization(detail, cartCreatorChannelId)}
                          </StyledCell>
                          <StyledCell data-testid='payment-detail-date'>{formatDateTime(detail)}</StyledCell>
                          <StyledCell data-testid='payment-detail-amount'>
                            {detail.modeOfPay === 'IE' ? '' : `$${detail.paymentAmount}`}
                          </StyledCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </StyledTable>
              </TableWrapper>
            )}
            <TotalContainer>
              <Title size='small' color='#4A4A4A' bold data-testid='total-paid-title'>
                Total paid
              </Title>
              <Title size='small' bold data-testid='total-paid'>
                ${isFromReadOrder && isReadOrderFlagEnabled ? totalPaid : totalPaid * -1}
              </Title>
            </TotalContainer>
            {isFromReadOrder && isReadOrderFlagEnabled && (
              <RemainingContainer>
                <Title size='small' data-testid='remaining-amount'>
                  ${remainingAmount}
                </Title>
                <Title size='small' data-testid='remaining-text'>
                  remaining
                </Title>
              </RemainingContainer>
            )}
            <FooterArea>
              <Padding36>
                <Button size='large' onClick={handleClose} data-testid='done-button'>
                  Done
                </Button>
              </Padding36>
            </FooterArea>
          </div>
        </Modal>
      </ModalWrapper>
    </>
  );
};

PaymentHistoryModal.propTypes = {
  handleToggle: PropTypes.func.isRequired,
  value: PropTypes.bool.isRequired,
  readOrderResponse: PropTypes.any,
  readOrder: PropTypes.bool,
};

export default PaymentHistoryModal;
