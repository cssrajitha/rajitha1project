import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { Input } from '@vds/inputs';
import styled from 'styled-components';
import { useLazyGetSMSConsentQuery } from '../../modules/services/APIService/APIServiceHooks';

const InputContainer = styled.div`
  [class^='InputContainer-VDS'] {
    border-color: rgb(216, 218, 218) rgb(216, 218, 218) rgb(0, 0, 0);
    border-radius: 0px;
  }
`;

const SmsInput = ({ selectedSmsMDN, setselectedSmsMDN, setEnableSendBtn }) => {
  const [getSMSConsentReq, getSMSConsentResult] = useLazyGetSMSConsentQuery();
  const errorEnable =
    (selectedSmsMDN && selectedSmsMDN.length > 0 && selectedSmsMDN && selectedSmsMDN.length < 10) ||
    (getSMSConsentResult?.data?.data && !getSMSConsentResult?.data?.data?.wireless);

  const validateMdnOnBlur = () => {
    const payload = {
      data: {
        mtn: selectedSmsMDN,
        purposeName: 'Transactional',
        lineOfBusiness: 'Wireless',
        flowName: 'View Together',
      },
    };
    getSMSConsentReq({ body: payload, spinner: false });
  };

  const handleChange = (e) => {
    const inputMTN = e.target.value.replace(/\D/g, '');
    setselectedSmsMDN(inputMTN);
  };

  useEffect(() => {
    if (getSMSConsentResult?.data) {
      setEnableSendBtn(getSMSConsentResult?.data?.data?.wireless);
    }
  }, [getSMSConsentResult]);

  return (
    <InputContainer>
      <Input
        data-testid='newcustomer-mdn'
        type='tel'
        label='MDN'
        error={errorEnable || false}
        errorText='Please enter a valid mobile number'
        width='250px'
        onChange={handleChange}
        onBlur={validateMdnOnBlur}
        defaultValue=''
      />
    </InputContainer>
  );
};

SmsInput.propTypes = {
  selectedSmsMDN: PropTypes.string,
  setselectedSmsMDN: PropTypes.func,
  setEnableSendBtn: PropTypes.func,
};

export default SmsInput;
