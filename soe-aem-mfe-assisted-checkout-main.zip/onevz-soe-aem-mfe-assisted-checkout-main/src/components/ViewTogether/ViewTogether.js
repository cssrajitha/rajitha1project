import { Accordion, AccordionDetail, AccordionHeader, AccordionItem, AccordionTitle } from '@vds/accordions';
import { useDispatch } from 'react-redux';
import Emitter from 'onevzsoemfeframework/Emitter';
import ReceivePoll from 'onevzsoemfecommon/Components/ReceivePoll';
import { Button, ButtonGroup } from '@vds/buttons';
import { RadioButtonGroup } from '@vds/radio-buttons';
import { DropdownSelect } from '@vds/selects';
import { Input } from '@vds/inputs';
import { Toggle } from '@vds/toggles';
import { Icon } from '@vds/icons';
import { Modal, ModalBody } from '@vds/modals';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import { useEffect, useRef, useState } from 'react';
import { isIpad, executeShellFunction } from 'onevzsoemfeframework/DomService';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import moment from 'moment';
import { getQueryParamByName, isFunctionalityEnabled } from 'onevzsoemfecommon/Helpers';
import { useLazyLovupdatecaseQuery } from 'onevzsoemfecommon/APIService';
import { formatAccountNumber, getMTNList } from '../../utils/common';
import ViewTogetherApiCallHook from '../../modules/services/APIService/ViewTogetherApiCallHook';
import {
  reqGenerateInspicioId,
  reqGeneratePaxQRCode,
  reqSendEmail,
  reqSendLovLink,
  reqSendMessage,
} from './ViewTogetherRequest';
import handleReceivePoll, { handleContinue, handleLogCustomerUrl } from './handleReceivePoll';
import AgreementsAPICallHook from '../../modules/services/APIService/AgreementsAPICallHook';
import InfoApiCallHook from '../../modules/services/APIService/InfoAPICallHook';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR, isDark } from '../constants/constants';
import SmsInput from './SmsInput';
import { viewTogetherOptionsHelper } from '../../utils/orderreviewUtil';
import { handleLongPolling } from './cobrowse';
import { useLazyGetCustomerByMtnQuery } from '../../modules/services/APIService/APIServiceCallHook';
const ViewTogetherText = styled.div`
  font-weight: bold;
  font-size: 700;
  margin-top: 20px;
  margin-left: 25px;
  margin-bottom: 30px;
`;

const TitleText = styled.div`
  margin-left: 10px;
  display: flex;
`;

const AddMargin = styled.div`
  margin-top: 20px;
  margin-left: 15px;
  margin-bottom: 80px;
`;

const DropdownWrapper = styled.div`
  margin-top: 20px;
  margin-left: 20px;
  display: flex;
`;

const ButtonStyle = styled.div`
  margin-top: 25px;
  margin-left: 20px;
`;

const RadioButtonStyle = styled.div`
      & > div {
            display:flex;
            flex-direction: row !important;
      },
      & .radioWrapper:first-child {
        margin-top: 1.5rem;
      },
      & label {
            margin-right: 30px !important;
      },
      padding-top: 60px;
      margin-left: 20px;
       [class^="ComponentWrapper-VDS"] {
        padding: 0px 0px 0px 5px;
  }
`;

const HorizontalLine = styled.div`
  border: none;
  margin-top: 16px;
`;

const ButtonWrapper = styled.div`
  float: left;
  margin-bottom: 80px;
  margin-top: 20px;
  [class^='ButtonGroupRow-VDS'] {
    padding-bottom: 0.3rem;
  }
`;

const QRCodeText = styled.div`
  margin-top: 25px;
  font-weight: bold;
  width: 350px;
  margin-left: 40px;
  font-size: 20px;
`;

const SpanishToggle = styled.div`
  float: right;
  margin-top: -30px;
`;

const AlternateCheckMark = styled.div`
  margin-left: 10px;
  display: flex;
`;
const QRCodeGenerate = styled.div`
  font-size: medium;
  margin-left: 10px;
`;

const ViewTogetherAccordianWrapper = styled.div`
  padding-top: 15px;
  [class^='TriggerIconWrapper-VDS'] {
    margin-top: 0px;
  }
`;

const QRCodeGenerateText = styled.div`
  text-align: center;
  font-size: 20px;
`;

const QRCodeGenerateWidth = styled.div`
  text-align: center;
  overflow: hidden;
`;

const AccordianContentWrapper = styled.div`
  margin-top: 60px;
`;

const ViewTogether = ({
  showAccordion,
  customerProfile,
  getCartResponse,
  getNextBillSummaryRes,
  handleToggleChange,
  handleShowViewTogether,
  handleHideContinueShowViewTogether,
  landing,
  paperLessBilling,
  updatedEmail,
  spanishSelected,
  setShowSendMessageError,
  onAccordianToggle,
  openAccordian,
  setSelectedReviewMode,
  onChangeSubReason,
  subReasonSelected,
  onChangeRadio,
  selectedRadio,
  autoSelectRC,
  orderReviewResponse,
  fetchPriceSnapshot,
  unifiedNbsData,
  setReceivedLovPollResponse,
  exitLovData,
}) => {
  const { getActiveMTNRequest, getActiveMTNResponse, updateVisionRemark } = InfoApiCallHook();
  const [getCustomerByMtn, getCustomerByMtnSuccess] = useLazyGetCustomerByMtnQuery();
  const [qrGenerateClicked, setQRGenerateClick] = useState(false);
  const [ptaGenerateClicked, setPTAGenerateClick] = useState(false);
  const [showQRAltCheckmark, setQRAltCheckmark] = useState(false);
  const [showPTAAltCheckmark, setPTAAltCheckmark] = useState(false);
  const [displaySendEmailActionClick, setDisplaySendEmailActionClick] = useState(true);
  const [displaySendSmsActionClick, setDisplaySendSmsActionClick] = useState(true);
  const [isViewTogetherFlow, setIsViewTogetherFlow] = useState(false);
  const [radioSelected, setRadioSelected] = useState(selectedRadio);
  const [selectedSmsMDN, setselectedSmsMDN] = useState('');
  const [enableSendBtn, setEnableSendBtn] = useState(false);
  const emulatorlaunchedDefault = window.sessionStorage.getItem('emulatorlaunched') === 'true';
  const [emulatorLaunced, setEmulatorlaunch] = useState(emulatorlaunchedDefault);

  const [
    isMultiLineRisaFFlagEnabled,
    storeVTDocumentFFlag,
    retailCompanionForVTFFlag,
    retailCompanionForVTCheckoutMfeFFlag,
  ] = getAssistedCradlePropertyV2([
    'multiLineRisaMfeFFlag',
    'storeVTDocumentFFlag',
    'storeVTVideoFFlag',
    'retailCompanionTaggingFFlag',
    'retailCompanionForVTFFlag',
    'retailCompanionForVTCheckoutMfeFFlag',
  ]);

  const [mtnList, setMtnList] = useState([]);
  const dispatch = useDispatch();
  const orderWriteStatus = useRef(false);

  // useEffect(() => {
  //   if (scmCheckoutMfeEnabled && mtnList?.length > 0) {
  //     setselectedSmsMDN(mtnList?.[0]?.value)
  //   }
  // }, [mtnList]);

  const {
    requestBodyGenerateInspicioId,
    requestBodySendMessage,
    requestBodySendLovLink,
    requestBodySendEmail,
    getResultSendEmail,
    getResultSendLovLink,
    requestBodyGeneratePaxQRCode,
    getResultGenerateInspicioId,
    getResultSendMessage,
  } = ViewTogetherApiCallHook();
  const { getOrderWrite } = AgreementsAPICallHook();
  const [showModal, setShowModal] = useState(false);
  const [inspicioURLValue, setInspicioURLValue] = useState(false);
  /* istanbul ignore next */
  const useLazyLovupdatecaseQueryResult = useLazyLovupdatecaseQuery();
  const [lovupdatecaseAPI] = useLazyLovupdatecaseQueryResult || [() => {}, {}];
  const [sendInspicioData, setSendInspicioData] = useState(null);
  const enableRetailCompanionOption =
    retailCompanionForVTFFlag === 'TRUE' && retailCompanionForVTCheckoutMfeFFlag === 'TRUE';
  const { viewTogetherOptions, viewTogetherOptionsSCM } = viewTogetherOptionsHelper(
    getCartResponse?.orderDetails?.itemLevelShipment,
    getCartResponse?.lineDetails,
    enableRetailCompanionOption,
  );
  const [filteredViewTogetherOptionsSCM, setFilteredViewTogetherOptionsSCM] = useState(viewTogetherOptionsSCM);
  const scmCheckoutMfeEnabled = window?.mfe?.scmCheckoutMfeEnable;
  const [vzwACSSReasons, setVzwACSSReasons] = useState([]);
  const isAcssVtPerksEnabled = window?.mfe?.acssVtPerksEnabled || false;
  const [vtSubChannelIndicatorFFlag] = getAssistedCradlePropertyV2(['vtSubChannelIndicatorFFlag']);

  /* istanbul ignore next */
  const openModal = () => {
    setShowModal(!showModal);
  };

  const onSelectedRadio = (selectedRadioValue) => {
    if (selectedRadioValue !== 'Customer QR Code' && selectedRadioValue !== 'View Together using PTA') {
      setQRAltCheckmark(false);
      setPTAAltCheckmark(false);
    }

    if (
      (selectedRadioValue === 'Customer QR Code' || selectedRadioValue === 'View Together using PTA') &&
      qrGenerateClicked &&
      !ptaGenerateClicked
    ) {
      setQRAltCheckmark(true);
    }

    if (
      (selectedRadioValue === 'Customer QR Code' || selectedRadioValue === 'View Together using PTA') &&
      ptaGenerateClicked &&
      !qrGenerateClicked
    ) {
      setPTAAltCheckmark(true);
    }
  };

  const selectedRadioButton = (event) => {
    setRadioSelected(event.target.value);
    onChangeRadio(event.target.value);
    onSelectedRadio(event.target.value);
    setSelectedReviewMode(event.target.value);
    setSendInspicioData(null);
    window.sessionStorage.setItem('receivePoll', false);
  };

  useEffect(() => {
    onSelectedRadio(selectedRadio);
  }, [selectedRadio]);

  useEffect(() => {
    const acssNonVTReasons = sessionStorage.getItem('vzwACSSNonVTReasons');
    if (acssNonVTReasons) {
      setVzwACSSReasons(JSON.parse(acssNonVTReasons));
    }
  }, []);
  useEffect(() => {
    if (getCustomerByMtnSuccess?.status === 'fulfilled') {
      const customerByMtnEmail = getCustomerByMtnSuccess?.data?.customer?.email || '';
      if (!customerByMtnEmail) {
        const filteredVTOptionsSCM = viewTogetherOptionsSCM.filter((i) => i.children !== 'Email Address' && i.value !== 'Email Address');
        setFilteredViewTogetherOptionsSCM(filteredVTOptionsSCM);
      }
    }
  }, [getCustomerByMtnSuccess?.status]);
  
  /* istanbul ignore next */
  useEffect(() => {
    if (isViewTogetherFlow && isAcssVtPerksEnabled) {
      handleLongPolling(getResultGenerateInspicioId?.data?.receievInspicioToken || receievInspicioToken);
    }
  }, [isViewTogetherFlow]);

  const retailReasons = [
    { label: 'Please Select one of the options below', value: '' },
    { label: 'Inaccurate Bill Summary Presentation / NBS', value: 'Inaccurate Bill Summary Presentation / NB' },
    { label: 'Systemic Issue Impeding Transaction', value: 'Systemic Issue Impeding Transaction' },
    {
      label: 'Device unavailable / Device is broken - PTA unavailable',
      value: 'Device unavailable / Device is broken - PTA unavailable',
    },
    {
      label: 'Language or accessibility (e.g. visually impaired) barriers',
      value: 'Language or accessibility (e.g. visually impaired) barriers',
    },
  ];

  useEffect(() => {
    if (showAccordion || openAccordian) {
      const receivePollFromSession = window.sessionStorage.getItem('receivePoll');
      if (receivePollFromSession === 'true') {
        setOpen(false);
      } else {
        setOpen(true);
      }
      window.scrollTo({ behavior: 'smooth', top: 0 });
    }
    return () => {
      setIsViewTogetherFlow(false);
    };
  }, [showAccordion, openAccordian]);
  const customerType = sessionStorage.getItem('customerType') ? sessionStorage.getItem('customerType') : '';
  const lookUpMTN = sessionStorage.getItem('tagActiveMTN')
    ? sessionStorage.getItem('tagActiveMTN')
    : customerProfile?.data?.customer?.lookupMtn;
  useEffect(() => {
    const isPostToPrePay = sessionStorage.getItem('newPostToPreIndicator') === 'true';
    const enableCustomerByMtn = isFunctionalityEnabled('scmCommonDefectFixFFlag', 'enableCustomerByMtnAfterLovFFlag','ACSS_SCM_ENABLE_VT_EMAIL_VALIDATION');
    if (enableCustomerByMtn && lookUpMTN && customerType !== 'N' && !isPostToPrePay) {
      getCustomerByMtn({ body: {}, spinner: false });
    }
  }, [lookUpMTN]);

  const requestSendMessage = reqSendMessage(
    getCartResponse,
    getNextBillSummaryRes,
    customerProfile,
    getResultSendLovLink,
    getResultSendMessage,
    orderReviewResponse,
    getResultGenerateInspicioId,
    fetchPriceSnapshot,
    customerType,
    lookUpMTN,
    unifiedNbsData,
  );
  const requestGeneratePaxQRCode = reqGeneratePaxQRCode(getCartResponse, customerProfile);

  /* istanbul ignore next */
  const getPegaTransactionType = (lineDetails) => {
    const lineActivities =
      lineDetails && lineDetails.lineInfo && lineDetails.lineInfo.length > 0
        ? lineDetails.lineInfo.map((line) => line.lineActivityType)
        : [];

    let pegaTransactionType = '';
    const acctMcsSubscription = lineDetails && lineDetails.acctMcsSubscription;
    const numOfAals = lineDetails && lineDetails.numofLinesAAL ? lineDetails.numofLinesAAL : 0;
    const numOfEups = lineDetails && lineDetails.numofLinesEUP ? lineDetails.numofLinesEUP : 0;

    if (lineActivities && lineActivities.length) {
      pegaTransactionType += lineActivities.some((val) => val && val.indexOf('NSE') > -1) ? 'N' : '';
      pegaTransactionType += lineActivities.some((val) => val && val.indexOf('EUP') > -1) || numOfEups > 0 ? 'U' : '';
      pegaTransactionType += lineActivities.some((val) => val && val.indexOf('AAL') > -1) || numOfAals > 0 ? 'A' : '';
      pegaTransactionType += lineActivities.some((val) => val && val.indexOf('CPC') > -1) ? 'C' : '';
      pegaTransactionType += lineActivities.some((val) => val && val.indexOf('FEA') > -1) ? 'F' : '';
      pegaTransactionType +=
        acctMcsSubscription &&
        acctMcsSubscription.length > 0 &&
        acctMcsSubscription.filter(
          (subscription) => subscription.actionIndicator === 'A' || subscription.actionIndicator === 'D',
        ).length > 0
          ? 'F'
          : '';
    }

    if (pegaTransactionType === '') {
      pegaTransactionType = 'U';
    }

    if (lineDetails?.tradeInDetail?.tradeInItems?.length > 0) {
      pegaTransactionType += 'T';
    }

    return pegaTransactionType;
  };
  const pegaTransactionTypeLov =
    getCartResponse?.lineDetails && getCartResponse.lineDetails?.lineInfo
      ? getPegaTransactionType(getCartResponse.lineDetails)
      : 'U';
const requestSendLovLink = reqSendLovLink(customerProfile, getCartResponse, spanishSelected, pegaTransactionTypeLov);
  const receievInspicioToken = window.sessionStorage.getItem('receievInspicioToken');
  const cluster = window.sessionStorage.getItem('vtCluster');
  const requestGenerateInspicioId = reqGenerateInspicioId(
    getCartResponse,
    customerProfile,
    isMultiLineRisaFFlagEnabled,
  );
  const [showQrContinue, setShowQrContinue] = useState(true);
  const [showVtaContinue, setShowVtaContinue] = useState(true);
  const [open, setOpen] = useState(true);
  const viewTogetherRef = useRef({
    spanishSelected,
    getCartResponse,
    getResultGenerateInspicioId,
    getResultSendMessage,
    getResultSendLovLink,
    emulatorLaunced,
  });

  useEffect(() => {
    viewTogetherRef.current = {
      spanishSelected,
      getCartResponse,
      getResultGenerateInspicioId,
      getResultSendMessage,
      getResultSendLovLink,
      emulatorLaunced,
    };
    if (getResultGenerateInspicioId && getResultGenerateInspicioId?.data?.receievInspicioToken) {
      window.sessionStorage.setItem('receievInspicioToken', getResultGenerateInspicioId?.data?.receievInspicioToken);
      window.sessionStorage.setItem('clientId', getResultGenerateInspicioId?.data?.receievInspicioToken);
    }
    if (getResultGenerateInspicioId && getResultGenerateInspicioId?.data?.sendInspicioToken) {
      window.sessionStorage.setItem('sendInspicioToken', getResultGenerateInspicioId?.data?.sendInspicioToken);
      window.sessionStorage.setItem('LovClientId', getResultGenerateInspicioId?.data?.sendInspicioToken);
    }
    if (getResultGenerateInspicioId && getResultGenerateInspicioId?.data?.inspicioAdditionalParam) {
      window.sessionStorage.setItem(
        'inspicioAdditionalParam',
        getResultGenerateInspicioId?.data?.inspicioAdditionalParam,
      );
    }
    if (getResultSendMessage && getResultSendMessage?.data?.cluster) {
      window.sessionStorage.setItem('vtCluster', getResultSendMessage?.data?.cluster);
    }
  }, [
    spanishSelected,
    getCartResponse,
    getResultGenerateInspicioId,
    getResultSendMessage,
    getResultSendLovLink,
    emulatorLaunced,
  ]);

  const handleQRCodeGenerateBtn = async () => {
    setQRGenerateClick(true);
    setPTAGenerateClick(false);
    setQRAltCheckmark(true);
    await callInspicioGenerateBtn(false);
    setShowQrContinue(false);
    console.log('Customer_Lov_URL:', getResultSendLovLink?.data?.serviceBody?.serviceResponse?.context?.orderUrl);
    handleHideContinueShowViewTogether(true);
    setIsViewTogetherFlow(true);
    window.sessionStorage.setItem('receivePoll', true);
  };

  const handeChangeSubReason = (e) => {
    onChangeSubReason(e.target.value);
  };

  /* istanbul ignore next */
  const lovupdatecaseAPICall = async () => {
    const dateStr = moment().format('YYYY-MM-DD HH:mm:ss');
    const zone = ' GMT';
    const timeStamp = dateStr + zone;
    const finalTransactionType = getCartResponse?.lineDetails?.lineInfo
      ? getPegaTransactionType(getCartResponse?.lineDetails)
      : 'U';
    const accountNumber = getCartResponse?.cartHeader?.fullAccountNumber
      ? getCartResponse?.cartHeader?.fullAccountNumber
      : '';
    const cartId = getCartResponse?.cartHeader?.cartId;
    const cartOrderNumber =
      getCartResponse?.orderDetails?.orderList?.find((order) => order.orderNumber)?.orderNumber || '';
    const locationCode = getCartResponse?.orderDetails?.locationCode;

    const lovCaseId =
      getResultSendLovLink &&
      getResultSendLovLink.data &&
      getResultSendLovLink?.data?.serviceBody &&
      getResultSendLovLink?.data?.serviceBody?.serviceResponse &&
      getResultSendLovLink?.data?.serviceBody?.serviceResponse?.context &&
      getResultSendLovLink?.data?.serviceBody?.serviceResponse?.context?.caseId
        ? getResultSendLovLink?.data?.serviceBody?.serviceResponse?.context?.caseId
        : '';
    if (!lovCaseId) {
      return;
    }
    const isTysFlow = getQueryParamByName('isTysFlow');
    const cartCreator = getCartResponse?.cartHeader?.cartCreator || '';
    const request = {
      serviceHeader: {
        clientId: 'INSPICIO',
        userId: sessionStorage.getItem('userId'),
        timestamp: timeStamp,
        serviceName: 'LOV',
      },
      serviceBody: {
        serviceRequest: {
          context: {
            caseId: lovCaseId,
            contextInfo: {
              callReason: 'LifeOnVerizon',
              processStep: 'UpdateCase',
              processAction: 'OrderReview',
            },
            customerInfo: {
              transactionType: finalTransactionType?.includes('N') ? 'A' : finalTransactionType,
              accountNumber:
                accountNumber !== '' && !finalTransactionType?.includes('N') ? formatAccountNumber(accountNumber) : '',
            },
            lovDetails: {
              cartId,
              orderNumber: cartOrderNumber,
              locationCode,
              paymentMethod: 'PTA',
              emulatorIndicator: 'N',
            },
          },
        },
      },
    };
    if (cartCreator) {
      request.serviceBody.serviceRequest.context.customerInfo.mtn = cartCreator;
    }
    if (isTysFlow) {
      request.serviceBody.serviceRequest.context.contextInfo.intent = 'TYS';
    }
    if (finalTransactionType?.indexOf('N') > -1) {
      request.serviceBody.serviceRequest.context.customerInfo.customerType = 'N';
      if (finalTransactionType?.indexOf('T') > -1) {
        request.serviceBody.serviceRequest.context.customerInfo.transactionType = 'AT';
      } else {
        request.serviceBody.serviceRequest.context.customerInfo.transactionType = 'A';
      }
    }
    await lovupdatecaseAPI({ body: request, spinner: false });
  };

  const handleContinueBtn = async () => {
    /* istanbul ignore next */
    if (ptaGenerateClicked) {
      setOpen(false);
    } else {
      await handleContinue({
        spanishSelected,
        getCartResponse,
        getResultGenerateInspicioId,
        getResultSendMessage,
        getResultSendLovLink,
        getNextBillSummaryRes,
        radioSelected,
        setEmulatorlaunch,
      });
    }
    onCloseAccordianToggle();
    lovupdatecaseAPICall();
  };

  const handleReceivePollApi = async (eventData) => {
    if (eventData?.detail?.payload?.action === 'load' && eventData?.detail?.payload?.pageName === 'lovorderreview') {
      onCloseAccordianToggle();
      setOpen(false);
      setShowModal(false);
    }
    if (eventData?.detail?.event === 'lovOrderReview' && eventData?.detail?.payload?.value === 'customerWindowClose') {
      handleShowViewTogether();
    }
    if (
      (eventData?.detail?.payload?.value === 'customerWindowClose' && eventData?.detail?.payload?.source === 'rep') ||
      eventData?.detail?.status === 'error' ||
      exitLovData?.value === 'customerWindowClose'
    ) {
      handleStopPooling();
      return;
    }
    if (eventData?.detail?.event === 'milestone') {
      setReceivedLovPollResponse(eventData?.detail?.payload);
      sessionStorage.setItem('lovMileStone', eventData?.detail?.payload?.value);
    }
    if (isIpad() && eventData?.detail?.event === 'openRepEmulator') {
      console.log(autoSelectRC, 'RetailCompanion_log_2');
      invokeShellFunction(eventData?.detail?.payload?.flow === 'rc' ? 'START-VT-RC' : 'VT-STARTED');
    }

    await handleReceivePoll({
      eventData,
      getCartResponse,
      customerProfile,
      landing,
      updatedEmail,
      paperLessBilling,
      getOrderWrite,
      requestBodySendMessage,
      spanishSelected,
      getResultGenerateInspicioId,
      getResultSendMessage,
      getResultSendLovLink,
      getNextBillSummaryRes,
      orderReviewResponse,
      fetchPriceSnapshot,
      unifiedNbsData,
      emulatorLaunced,
      setEmulatorlaunch,
      dispatch,
      orderWriteStatus,
      updateVisionRemark,
      ...viewTogetherRef.current,
    });
  };

  /* istanbul ignore next */
  useEffect(() => {
    window.sessionStorage.setItem('stopPollFromSession', false);
    if (!isAcssVtPerksEnabled) document.addEventListener('receivePoll', handleReceivePollApi);

    if (isAcssVtPerksEnabled) Emitter?.removeAllListeners('VT_RECEIVE_EVENT');

    if (isAcssVtPerksEnabled) {
      Emitter.on('VT_RECEIVE_EVENT', (eventData) => {
        const eventDatavar = { detail: eventData };
        handleReceivePollApi(eventDatavar);
      });
    }

    if (scmCheckoutMfeEnabled) {
      const event = { target: { value: 'SMS' } };
      selectedRadioButton(event);
    }
    if (autoSelectRC && radioSelected === 'Retail Companion') {
      console.log(autoSelectRC, 'RetailCompanion_log_3');
      handlePTAGenerateBtn();
      sessionStorage.setItem('isRCCart', 'false');
    }
    return () => {
      if (!isAcssVtPerksEnabled) {
        document.removeEventListener('receivePoll', handleReceivePollApi);
        window.sessionStorage.setItem('stopPollFromSession', true);
      }
    };
  }, []);

  useEffect(() => {
    const isReceivePoll = sessionStorage.getItem('receivePoll');
    if (isReceivePoll === 'true') {
      setIsViewTogetherFlow(true);
    }
  }, []);
  useEffect(() => {
    if (exitLovData?.value === 'customerWindowClose') {
      handleStopPooling();
    }
  }, [exitLovData]);

  const callInspicioGenerateBtn = async (ptaClick) => {
    const inspicioData = await callInspicioApi(ptaClick);
    const token = inspicioData?.sendInspicioToken;
    const additionalUrlParams = await getAdditionalParams(inspicioData);
    /* istanbul ignore next */
    const pegaTransactionType =
      getCartResponse?.lineDetails && getCartResponse?.lineDetails?.lineInfo
        ? getPegaTransactionType(getCartResponse?.lineDetails)
        : 'U';
    requestSendMessage.payload.pegaTransactionType = pegaTransactionType;
    const sndMsgResponse = await requestBodySendMessage({ body: { ...requestSendMessage, clientId: token } });
    requestSendLovLink.inspicioCluster = sndMsgResponse?.data?.cluster;

    if (radioSelected === 'View Together using PTA' || radioSelected === 'Retail Companion') {
      delete requestSendLovLink.mvaUrlIndicator;
    }
    const result = await requestBodySendLovLink({
      body: { ...requestSendLovLink, additionalUrlParams, inspicioToken: btoa(token) },
    });
    const customerUrl = result?.data?.serviceBody?.serviceResponse?.context?.orderUrl;
    const isPtaSelected = radioSelected !== 'View Together using PTA' && { mvaUrl: customerUrl };
    const requestSendEmail = reqSendEmail(getCartResponse, spanishSelected, customerProfile, sndMsgResponse);
    await requestBodySendEmail({
      body: {
        data: { ...requestSendEmail.data, additionalUrlParams, inspicioToken: btoa(token), ...isPtaSelected },
        meta: requestSendEmail.meta,
      },
    });
  };

  useEffect(() => {
    const requestBodyAllActiveMTNs = {
      accountNumber: getCartResponse?.cartHeader?.fullAccountNumber || '',
    };
    if (customerType !== 'N' && Object?.keys(getCartResponse ?? {})?.length !== 0) {
      getActiveMTNRequest({ body: requestBodyAllActiveMTNs, spinner: false, mock: false });
    }
  }, [getCartResponse]);

  useEffect(() => {
    if (scmCheckoutMfeEnabled && getActiveMTNResponse?.data?.customer?.billAccounts?.length > 0) {
      const mtnValues = getMTNList(getActiveMTNResponse?.data?.customer?.billAccounts) || [];
      /* istanbul ignore else */
      if (mtnValues?.length > 0) {
        setMtnList(mtnValues);
        setselectedSmsMDN(mtnValues.length ? mtnValues[0].value : '');
      }
    }
  }, [getActiveMTNResponse]);

  const callInspicioApi = async (ptaClick) => {
    sessionStorage.setItem('vtRadioSelected', radioSelected);
    const receivePoll = window.sessionStorage.getItem('receivePoll');
    const vtLovCaseid = window.sessionStorage.getItem('vtCaseId');
    if (!sendInspicioData && receivePoll !== 'true' && !vtLovCaseid) {
      requestGenerateInspicioId.clientName = ptaClick ? 'OMNI-RETAIL-PAX' : getCartResponse?.cartHeader?.sourceSystem;
      const response = await requestBodyGenerateInspicioId({ body: requestGenerateInspicioId });
      const data = response?.data;
      setSendInspicioData(data);
      const vtTrustlyAdditionalMerchantRefToken = data?.vtTrustlyAdditionalMerchantRefToken;
      sessionStorage.setItem('vtTrustlyAdditionalMerchantRefToken', vtTrustlyAdditionalMerchantRefToken);
      sessionStorage.setItem('encryptedCartId', data?.encryptedCartId);
      return data;
    }
    return sendInspicioData;
  };

  const handlePTAGenerateBtn = async () => {
    setPTAGenerateClick(true);
    setQRGenerateClick(false);
    const totalDueToday = getCartResponse?.orderDetails?.totalDueToday;
    if (totalDueToday > 0) {
      const paxResponse = await requestBodyGeneratePaxQRCode({ body: requestGeneratePaxQRCode });
      const paxAuth = paxResponse?.data?.authToken;
      const qrCode = paxResponse?.data?.qrCode;
      window.sessionStorage.setItem('paxAuth', paxAuth);
      window.sessionStorage.setItem('paxRCQrCode', qrCode);
    }
    setShowModal(true);
    setQRAltCheckmark(false);
    setPTAAltCheckmark(true);
    await callInspicioGenerateBtn(true);
    setShowVtaContinue(false);
    handleHideContinueShowViewTogether(true);
    setIsViewTogetherFlow(true);
    window.sessionStorage.setItem('receivePoll', true);
  };

  const getAdditionalParams = async (inspicioData) => {
    const uswin = window.sessionStorage.getItem('userId');
    const locationCode = getCartResponse?.orderDetails?.locationCode;
    const isPtaSelected = radioSelected === 'View Together using PTA';
    const isRetailCompanionSelected = radioSelected === 'Retail Companion';
    const appProperties = JSON.parse(sessionStorage.getItem('APP_PROPERTIES')) || {};
    const isDir =
      appProperties?.isInspicioDirectCallsEnabled === 'TRUE' ||
      appProperties?.isInspicioDirectCallsForChannelEnabled === 'TRUE';

    const isBbFlow = orderReviewResponse?.data?.ptechEnabledForRetailLoc;
    let additionalUrlParams = '&vt=Y';
    /* istanbul ignore next */
    if (inspicioData?.inspicioAdditionalParam) {
      additionalUrlParams += `&o=${inspicioData.inspicioAdditionalParam}`;
    }
    if (isPtaSelected) {
      additionalUrlParams += `&px=Y&si=${uswin}&loc=${locationCode}`;
    }
    if (isRetailCompanionSelected) {
      additionalUrlParams += `&rc=Y&si=${uswin}&loc=${locationCode}`;
    }
    /* istanbul ignore next */
    if (isDir) {
      additionalUrlParams += `&dir=Y`;
    }
    /* istanbul ignore next */
    if (isBbFlow) {
      additionalUrlParams += `&bb=Y`;
      window.sessionStorage.setItem('ptechEnabledForRetailLoc', isBbFlow);
    }
    /* istanbul ignore else */
    if (storeVTDocumentFFlag === 'TRUE') {
      additionalUrlParams += `&nb=Y`;
    }
    return additionalUrlParams;
  };

  const handleSendClick = async () => {
    const inspicioData = await callInspicioApi(false);
    const token = inspicioData?.sendInspicioToken || sessionStorage.getItem('sendInspicioToken') || '';
    const additionalUrlParams = await getAdditionalParams(inspicioData);
    let sndMsgResponse = {}
    try {
      const sendMsgRequest = () => requestBodySendMessage({ body: { ...requestSendMessage, clientId: token } });
      const delay = (time) => new Promise((resolve) => {
          setTimeout(resolve, time)
        });

      sndMsgResponse = await sendMsgRequest();

      /* istanbul ignore else */
      if (!sndMsgResponse?.data?.cluster) {
        await delay(500);
        sndMsgResponse = await sendMsgRequest();
      }

      const responseCluster = sndMsgResponse?.data?.cluster;

      /* istanbul ignore else */
      if (!responseCluster) {
        setShowSendMessageError(true);
        return;
      }

    } catch (error) {
      console.log("Error sending message", error);

      try {
        const sendMsgRequest = () => requestBodySendMessage({ body: { ...requestSendMessage, clientId: token } });
        sndMsgResponse = await sendMsgRequest();

        /* istanbul ignore else */
        if (!sndMsgResponse?.data?.cluster) {
          setShowSendMessageError(true);
          return;
        }

      } catch (retryError) {
      console.log("Error sending message (retry attempt failed):", retryError);
        setShowSendMessageError(true);
        return;
      }
    }
    requestSendLovLink.inspicioCluster = sndMsgResponse?.data?.cluster;
    requestSendLovLink.qrCodeIndicator = 'N';
    if (radioSelected === 'SMS') {
      requestSendLovLink.smsIndicator = 'Y';
      requestSendLovLink.smsMtn = selectedSmsMDN;
      requestSendLovLink.lovCaseId = window.sessionStorage.getItem('vtCaseId') || '';
    } else if (radioSelected === 'Email Address') {
      requestSendLovLink.emailIndicator = 'Y';
      requestSendLovLink.emailAddress = getCartResponse?.orderDetails?.spocs?.notificationOptions?.primaryEmailId;
      requestSendLovLink.lovCaseId = window.sessionStorage.getItem('vtCaseId') || '';
    }

    /* istanbul ignore else */
    if(vtSubChannelIndicatorFFlag === 'TRUE') {
      requestSendLovLink.subChannel = 'SCM';
    }

    /* istanbul ignore else */
    if (scmCheckoutMfeEnabled) {
      delete requestSendLovLink.mvaUrlIndicator;
    }
    const receivePoll = window.sessionStorage.getItem('receivePoll');
    const stopPollFromSession = window.sessionStorage.getItem('stopPollFromSession');

    /* istanbul ignore else */
    if (receivePoll !== 'true' && sndMsgResponse?.data?.cluster) {
      if (stopPollFromSession === 'true') {
        window.sessionStorage.setItem('stopPollFromSession', false);
      }

      setIsViewTogetherFlow(true);
      await requestBodySendLovLink({
        body: { ...requestSendLovLink, additionalUrlParams, inspicioToken: btoa(token) },
      });
      handleHideContinueShowViewTogether(true);
      window.sessionStorage.setItem('receivePoll', true);
    }
  };

  const onMDNSelected = (e) => {
    setselectedSmsMDN(e?.target?.value);
  };

  const handleSendEmailClick = async () => {
    await handleSendClick();
    setDisplaySendEmailActionClick(false);
    if (scmCheckoutMfeEnabled) {
      const inspicioURLLink = await handleLogCustomerUrl({
        spanishSelected,
        getCartResponse,
        getResultGenerateInspicioId,
        getResultSendMessage,
        getResultSendLovLink,
        getNextBillSummaryRes,
        radioSelected,
        ...viewTogetherRef.current,
      });
      setInspicioURLValue(inspicioURLLink);
    }
  };

  const handleSendSmsClick = async () => {
    await handleSendClick();
    setDisplaySendSmsActionClick(false);
    if (scmCheckoutMfeEnabled) {
      const inspicioURLLink = await handleLogCustomerUrl({
        spanishSelected,
        getCartResponse,
        getResultGenerateInspicioId,
        getResultSendMessage,
        getResultSendLovLink,
        getNextBillSummaryRes,
        radioSelected,
        ...viewTogetherRef.current,
      });
      setInspicioURLValue(inspicioURLLink);
    }
  };

  const onCloseAccordianToggle = () => {
    setOpen(false);
    if (onAccordianToggle) {
      onAccordianToggle();
    }
  };

  const handlePooling = async () => {
    if (radioSelected === 'VT') {
      handleStopPooling();
    }
  };

  const handleStopPooling = () => {
    setIsViewTogetherFlow(false);
    setEmulatorlaunch(false);
    // log the Inspicio receive message url and payload
    console.error(`DEBUG - VT - handleStopPooling - Stop long polling`, '');
    window.sessionStorage.setItem('stopPollFromSession', true);
    window.sessionStorage.removeItem('receivePoll');
    window.sessionStorage.removeItem('emulatorlaunched');
    setReceivedLovPollResponse('');
  };

  const invokeShellFunction = async (flow) => {
    try {
      const vtURL = flow === 'VT-STARTED' ? '' : getResultSendEmail?.data?.inspicioUrl;
      const title = flow === 'VT-STARTED' ? 'VT-STARTED' : 'START-VT-RC';
      const shellDescription = JSON.stringify({ viewTogetherUrl: vtURL });
      const shellParams = { title, description: shellDescription };
      executeShellFunction('Shell', 'sendSSEMessage', 'none', shellParams);
    } catch (error) {
      console.log(error);
    }
  };

  const time = getResultSendLovLink?.data?.serviceBody?.serviceResponse?.context?.caseCreatedDateTime;
  console.log('inspicioUrl', getResultSendLovLink?.data?.serviceBody?.serviceResponse?.context?.orderUrl);
  return (
    <ViewTogetherAccordianWrapper>
      {isViewTogetherFlow && !isAcssVtPerksEnabled && (
        <ReceivePoll
          clientId={getResultGenerateInspicioId?.data?.receievInspicioToken || receievInspicioToken}
          cluster={getResultSendMessage?.data?.cluster || cluster}
        />
      )}
      <HorizontalLine
        style={{ borderTop: isDark() ? `4px solid ${DARK_THEME_COLOR}` : `4px solid ${DARK_THEME_BGCOLOR}` }}
      />
      <Accordion bottomLine surface={isDark() ? 'dark' : 'light'}>
        <AccordionItem opened={open}>
          <AccordionHeader bold trigger={{ type: 'icon', alignment: 'top' }} onClick={() => onAccordianToggle()}>
            <AccordionTitle data-testid='view-together-accordion'>
              <TitleText>
                View Together
                {(showQRAltCheckmark || showPTAAltCheckmark) && getResultSendEmail?.data && (
                  <AlternateCheckMark>
                    <Icon name='checkmark-alt' size='large' color='#00AC3E' surface={isDark() ? 'dark' : 'light'} />
                    <QRCodeGenerate>
                      {showQRAltCheckmark ? 'QR Code Generated' : 'PTA QR Code Generated'}
                    </QRCodeGenerate>
                  </AlternateCheckMark>
                )}
                {(radioSelected === 'SMS' || radioSelected === 'Email Address') && getResultSendLovLink?.data && (
                  <AlternateCheckMark>
                    <Icon name='checkmark-alt' size='large' color='#00AC3E' surface={isDark() ? 'dark' : 'light'} />
                    <QRCodeGenerate>Link sent on {time}</QRCodeGenerate>
                  </AlternateCheckMark>
                )}
              </TitleText>
            </AccordionTitle>
          </AccordionHeader>
          <AccordionDetail>
            <AccordianContentWrapper>
              <SpanishToggle>
                <Toggle
                  value='default'
                  surface={isDark() ? 'dark' : 'light'}
                  disabled={false}
                  showText
                  textWeight='regular'
                  textSize='small'
                  textPosition='left'
                  statusText={() => 'SPANISH'}
                  onChange={handleToggleChange}
                />
              </SpanishToggle>

              <RadioButtonStyle>
                <RadioButtonGroup
                  onChange={(e) => selectedRadioButton(e)}
                  error={false}
                  value={radioSelected}
                  data={!scmCheckoutMfeEnabled ? viewTogetherOptions : filteredViewTogetherOptionsSCM}
                  surface={isDark() ? 'dark' : 'light'}
                />
              </RadioButtonStyle>
              {radioSelected === 'View Together using PTA' && !ptaGenerateClicked && (
                <ViewTogetherText data-testid='view-together-pta'>
                  Please check the PTA device availability before selecting this option
                </ViewTogetherText>
              )}
              {radioSelected === 'Retail Companion' && !ptaGenerateClicked && (
                <ViewTogetherText data-testid='view-together-rc'>
                  Please check the Retail Companion device availability before selecting this option
                </ViewTogetherText>
              )}

              {showModal && getResultSendEmail?.data && (
                <div>
                  <Modal
                    data-testid='scan-qr-code'
                    id='QRCode'
                    surface={isDark() ? 'dark' : 'light'}
                    ariaLabel='QR Modal'
                    opened={showModal}
                    onOpenedChange={(opened) => {
                      if (!opened) setShowModal(false);
                    }}
                  >
                    <QRCodeGenerateText>Scan QR Code</QRCodeGenerateText>
                    <ModalBody>
                      <QRCodeGenerateWidth>
                        <div dangerouslySetInnerHTML={{ __html: getResultSendEmail?.data?.qrCodeData }} />
                        <div style={{ marginLeft: '175px' }}>
                          <Button
                            data-testid='go-back'
                            onClick={() => setShowModal(false)}
                            surface={isDark() ? 'dark' : 'light'}
                          >
                            Go Back
                          </Button>
                        </div>
                      </QRCodeGenerateWidth>
                    </ModalBody>
                  </Modal>
                </div>
              )}

              {radioSelected === 'Customer QR Code' && (
                <div>
                  {getResultSendEmail?.data && qrGenerateClicked && !ptaGenerateClicked && (
                    <div style={{ display: 'flex' }}>
                      <div
                        data-testid='qr-code-data'
                        dangerouslySetInnerHTML={{
                          __html: getResultSendEmail?.data?.qrCodeData,
                        }}
                        onClick={openModal}
                        className='qrCode'
                        tabIndex='0'
                        aria-label='Show modal for QR Code'
                        role='button'
                        onKeyDown={(e) => e.key === 'Enter' && openModal}
                      />
                      <QRCodeText>Scan the QR code to review and complete your order.</QRCodeText>
                    </div>
                  )}
                  <ButtonWrapper>
                    <ButtonGroup
                      surface={isDark() ? 'dark' : 'light'}
                      data-testid='qr-code-button'
                      ariaLabel='qr-code-button'
                      childWidth='100%'
                      viewport='desktop'
                      rowQuantity={{ desktop: 1 }}
                      data={[
                        {
                          children: 'Generate',
                          size: 'large',
                          use: qrGenerateClicked ? 'secondary' : 'primary',
                          width: '170px',
                          onClick: () => handleQRCodeGenerateBtn(),
                        },
                        {
                          children: 'Continue',
                          size: 'large',
                          use: 'primary',
                          width: '170px',
                          disabled: showQrContinue,
                          ariaLabel: 'Continue',
                          onClick: () => handleContinueBtn(),
                        },
                      ]}
                      alignment='center'
                    />
                  </ButtonWrapper>
                </div>
              )}

              {(radioSelected === 'View Together using PTA' || radioSelected === 'Retail Companion') && (
                <div>
                  {getResultSendEmail?.data && ptaGenerateClicked && !qrGenerateClicked && (
                    <div style={{ display: 'flex' }}>
                      <div
                        data-testid='pta-data'
                        dangerouslySetInnerHTML={{
                          __html: getResultSendEmail?.data?.qrCodeData,
                        }}
                        onClick={openModal}
                        className='pta'
                        tabIndex='0'
                        aria-label='Show modal for PTA'
                        role='button'
                        onKeyDown={(e) => e.key === 'Enter' && openModal}
                      />
                      <QRCodeText>Scan the QR code using PTA</QRCodeText>
                    </div>
                  )}
                  <ButtonWrapper>
                    <ButtonGroup
                      surface={isDark() ? 'dark' : 'light'}
                      data-testid='qr-code-button'
                      childWidth='100%'
                      viewport='desktop'
                      rowQuantity={{ desktop: 1 }}
                      data={[
                        {
                          children: 'Generate',
                          size: 'large',
                          use: ptaGenerateClicked ? 'secondary' : 'primary',
                          width: '170px',
                          onClick: () => handlePTAGenerateBtn(),
                        },
                        {
                          children: 'Continue',
                          size: 'large',
                          use: 'primary',
                          width: '170px',
                          disabled: showVtaContinue,
                          onClick: () => handleContinueBtn(),
                        },
                      ]}
                      alignment='center'
                    />
                  </ButtonWrapper>
                </div>
              )}

              {radioSelected === 'SMS' && (
                <div>
                  <DropdownWrapper>
                    {customerType === 'N' && (
                      <SmsInput
                        selectedSmsMDN={selectedSmsMDN}
                        setselectedSmsMDN={setselectedSmsMDN}
                        setEnableSendBtn={setEnableSendBtn}
                      />
                    )}
                    {customerType !== 'N' && scmCheckoutMfeEnabled && mtnList.length > 0 && (
                      <DropdownSelect
                        label='Select MDN'
                        errorText='Select a MDN'
                        error={false}
                        disabled={false}
                        readOnly={false}
                        inlineLabel={false}
                        onChange={onMDNSelected}
                        width='250px'
                        value={selectedSmsMDN}
                        surface={isDark() ? 'dark' : 'light'}
                      >
                        {mtnList?.map((resp) => (
                          <option key={resp.value}>{resp?.label}</option>
                        ))}
                      </DropdownSelect>
                    )}

                    <ButtonStyle>
                      <Button
                        data-testid='send-button-sms'
                        size='small'
                        width='100px'
                        disabled={(!enableSendBtn && !mtnList) || false}
                        use={displaySendSmsActionClick ? 'primary' : 'secondary'}
                        onClick={handleSendSmsClick}
                        surface={isDark() ? 'dark' : 'light'}
                      >
                        {displaySendSmsActionClick ? 'Send' : 'Re-send'}
                      </Button>
                    </ButtonStyle>
                  </DropdownWrapper>

                  <AddMargin>
                    <Button
                      size='large'
                      disabled={displaySendSmsActionClick}
                      onClick={handleContinueBtn}
                      data-testid='sendsms-test-id'
                      use='primary'
                      width='170px'
                      surface={isDark() ? 'dark' : 'light'}
                    >
                      Continue
                    </Button>
                  </AddMargin>
                </div>
              )}

              {radioSelected === 'Email Address' && (
                <div>
                  <DropdownWrapper>
                    <Input
                      data-testid='email-address'
                      type='text'
                      label='Email Address'
                      readOnly
                      error={false}
                      width='350px'
                      defaultValue={getCartResponse?.orderDetails?.spocs?.notificationOptions?.primaryEmailId}
                    />
                    <ButtonStyle>
                      <Button
                        data-testid='send-button-email'
                        size='small'
                        width='100px'
                        disabled={false}
                        use={displaySendEmailActionClick ? 'primary' : 'secondary'}
                        onClick={handleSendEmailClick}
                        surface={isDark() ? 'dark' : 'light'}
                      >
                        {displaySendEmailActionClick ? 'Send' : 'Re-send'}
                      </Button>
                    </ButtonStyle>
                  </DropdownWrapper>

                  <AddMargin>
                    <Button
                      size='large'
                      onClick={handleContinueBtn}
                      disabled={displaySendEmailActionClick}
                      use='primary'
                      width='170px'
                      surface={isDark() ? 'dark' : 'light'}
                    >
                      Continue
                    </Button>
                  </AddMargin>
                </div>
              )}

              {radioSelected === 'VT' && (
                <div>
                  <DropdownWrapper>
                    <DropdownSelect
                      data-testid='select-reason-vt'
                      label='Select reason'
                      error={false}
                      disabled={false}
                      readOnly={false}
                      inlineLabel={false}
                      width='450px'
                      value={subReasonSelected}
                      onChange={(e) => handeChangeSubReason(e)}
                      surface={isDark() ? 'dark' : 'light'}
                    >
                      {scmCheckoutMfeEnabled && vzwACSSReasons?.length
                        ? vzwACSSReasons.map((ele) => (
                            <option key={ele.label} value={ele.value}>
                              {ele.label}
                            </option>
                          ))
                        : retailReasons.map((ele) => (
                            <option key={ele} value={ele.value}>
                              {ele.label}
                            </option>
                          ))}
                    </DropdownSelect>
                  </DropdownWrapper>

                  <AddMargin>
                    <Button
                      size='large'
                      onClick={() => {
                        handleShowViewTogether();
                        onAccordianToggle();
                        handlePooling();
                      }}
                      disabled={!subReasonSelected}
                      use='primary'
                      width='170px'
                      data-testid='continue-vt'
                      surface={isDark() ? 'dark' : 'light'}
                    >
                      Continue
                    </Button>
                  </AddMargin>
                </div>
              )}
              {inspicioURLValue && (
                <input type='hidden' id='shareByteLink' data-testid='hidden-input' value={inspicioURLValue} />
              )}
            </AccordianContentWrapper>
          </AccordionDetail>
        </AccordionItem>
      </Accordion>
    </ViewTogetherAccordianWrapper>
  );
};

ViewTogether.propTypes = {
  showAccordion: PropTypes.bool,
  getCartResponse: PropTypes.any,
  getNextBillSummaryRes: PropTypes.any,
  handleToggleChange: PropTypes.func,
  spanishSelected: PropTypes.bool,
  setShowSendMessageError: PropTypes.func,
  customerProfile: PropTypes.any,
  handleShowViewTogether: PropTypes.func,
  onAccordianToggle: PropTypes.func,
  openAccordian: PropTypes.bool,
  setSelectedReviewMode: PropTypes.func,
  onChangeSubReason: PropTypes.func,
  subReasonSelected: PropTypes.any,
  onChangeRadio: PropTypes.func,
  selectedRadio: PropTypes.any,
  autoSelectRC: PropTypes.any,
  handleHideContinueShowViewTogether: PropTypes.func,
  landing: PropTypes.object,
  paperLessBilling: PropTypes.string,
  updatedEmail: PropTypes.string,
  orderReviewResponse: PropTypes.any,
  fetchPriceSnapshot: PropTypes.any,
  unifiedNbsData: PropTypes.any,
  setReceivedLovPollResponse: PropTypes.func,
  exitLovData: PropTypes.any,
};

export default ViewTogether;
