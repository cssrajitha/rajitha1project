import Emitter from 'onevzsoemfeframework/Emitter';
import { logInfoToKibana, isFunctionalityEnabled } from 'onevzsoemfecommon/Helpers';
import { getInspicioRecieveServiceUrl, mapSoeHost } from '../../utils/index';



// eslint-disable-next-line no-promise-executor-return
const wait = async (ms) => new Promise((res) => setTimeout(res, ms));

const recurLongPoll = async (clientId, onlyOnce, maxErrors, delay, stopPolling = false) => {
  if (!onlyOnce && !stopPolling) {
    await wait(delay);
    await handleLongPolling(clientId, onlyOnce, maxErrors, delay);
  }
};

const stopPollingCheck = () => {
  let isStopPolling = true;
  const stopPollFromSession = window.sessionStorage.getItem('stopPollFromSession');
    /* istanbul ignore else */
    if (stopPollFromSession !== 'true') {
      isStopPolling = false;
    }

  return isStopPolling;
};

const updateLongPollingUrl = isFunctionalityEnabled('scmCommonDefectFixFFlag', 'scmLongPollUpdateUrlEnabled', 'ACSS_SC_LONGPOLL_UPDATE_URL_ENABLED');

// const url = 'https://inspicio-uat.verizonwireless.com/inspicio/receive';
export const handleLongPolling = async (clientId, onlyOnce = false, maxErrors = 5, delay = 1000) => {
  let url = ''
  /* istanbul ignore else */
  if (updateLongPollingUrl) {
    url = `${mapSoeHost()}/inspicioservice/inspicio/receiveMessage`;
  } else {
    url = getInspicioRecieveServiceUrl();
  }

  const formattedUrls = url?.replace(/([^:]\/)\/+/g, '$1');
  const cluster = sessionStorage.getItem('vtCluster')
    
  if (maxErrors === 0) return;
  const payload = {
    clientId,
    cluster: cluster || 'S',
  };

  const reqHeader = {
    Accept: 'application/json, text/plain, */*',
    'Content-Type': 'application/json',
    Referer: window.location.origin
  };

  /* istanbul ignore else */
  if (updateLongPollingUrl) {
    reqHeader.cartId = sessionStorage.getItem('acssMfeCartId') || '';
    reqHeader.caseId = sessionStorage.getItem('acssMfeCaseId') || '';
    reqHeader.soeguisubkey = sessionStorage.getItem('soeguisubkey') || '';
    reqHeader.soeguivalue = sessionStorage.getItem('soeguivalue') || '';
    reqHeader.channelId = sessionStorage.getItem('channelId') || '';
 }

  try {
    const response = await fetch(formattedUrls, {
      method: 'POST',
      headers: reqHeader,
      body: JSON.stringify(payload),
    });

    const responseData = await response.json();

    if (responseData?.status === 'error') {
      await recurLongPoll(clientId, onlyOnce, maxErrors - 1, delay);
      return;
    }

    if (responseData?.status !== 'Timeout' &&  responseData?.status !== 'timeout') {
      logInfoToKibana(`DEBUG - VT - Receive message - ${clientId}  cluster  ${cluster}  response: ${JSON.stringify(responseData)}`, '');
      const vtPayloadsend ={event: responseData.event, payload: responseData.payload }
      Emitter.emit('VT_RECEIVE_EVENT', vtPayloadsend );
    }
    
    await recurLongPoll(clientId, onlyOnce, maxErrors, delay, stopPollingCheck());
  } catch (err) {
    await recurLongPoll(clientId, onlyOnce, maxErrors - 1, delay);
  }
};
