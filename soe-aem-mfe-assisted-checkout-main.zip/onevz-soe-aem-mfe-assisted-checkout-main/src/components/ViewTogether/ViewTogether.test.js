import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import StoreProvider from '../../modules/store';
import ViewTogether from './ViewTogether';
import * as ViewTogetherApiCallHook from '../../modules/services/APIService/ViewTogetherApiCallHook';
import handleReceivePoll, { handleLogCustomerUrl } from './handleReceivePoll';
import * as InfoApiCallHook from '../../modules/services/APIService/InfoAPICallHook';
import mockGetAllActiveMtnResult from '../../__mock__/getAllActiveMtns.json';

jest.mock('onevzsoemfecommon/Helpers', () => {
  const actual = jest.requireActual('onevzsoemfecommon/Helpers');
  return {
    ...actual,
    isFunctionalityEnabled: jest.fn(() => true),
  };
});

// Mock handleReceivePoll
jest.mock('./handleReceivePoll');

jest.mock('onevzsoemfeframework/DomService', () => ({
  isIpad: () => true,
  executeShellFunction: jest.fn(),
}));

jest.mock('onevzsoemfecommon/APIService', () => ({
  ...jest.requireActual('onevzsoemfecommon/APIService'),
  useLazyLovupdatecaseQuery: jest.fn(),
}));

const mockedUsedNavigate = jest.fn();
const mockRequestSendLovLink = jest.fn();
const mockOnChangeRadio = jest.fn();
const mockOnChangeSubReason = jest.fn();
const mockhandleHideContinueShowViewTogether = jest.fn();
const setReceivedLovPollResponse = jest.fn();
const mockData = {
  requestBodySendLovLink: mockRequestSendLovLink,
  getResultSendLovLink: { data: { serviceBody: { serviceResponse: { context: { caseId: 'test' } } } } },
  requestBodyGenerateInspicioId: jest.fn(),
  requestBodySendMessage: jest.fn().mockResolvedValue({ data: { cluster: 'TEST' } }),
  requestBodySendEmail: jest.fn(),
  getResultSendEmail: { data: {} },
  requestBodyGeneratePaxQRCode: jest.fn(),
  getResultGenerateInspicioId: { data: { sendInspicioToken: 'OMNI', inspicioAdditionalParam: '1234' } },
  getResultSendMessage: { data: {} },
  getActiveMTNRequest: jest.fn(),
  getActiveMTNResponse: { data: mockGetAllActiveMtnResult },
};
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockedUsedNavigate,
}));

const timeout = 10000; // Reduced from 30000 to prevent CI timeouts
jest.setTimeout(timeout);
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: () => ['TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE'],
  }),
  { multiLineRisaFFlag: true }
);
describe('Open accordion on click of view together', () => {
  const inStorePickupProps = {
    setSelectedReviewMode: jest.fn(),
    setSelectedReason: jest.fn(),
    setShowSendMessageError: jest.fn(),
  };
  const generateInspicioIDJson = {
    isSuccess: true,
    data: {
      sendInspicioID: 'LOV-AGENT-OMNI-RETAIL-7257f49e-3371-45',
      receievInspicioID: 'LOV-CUST-OMNI-RETAIL-7257f49e-3371-45',
      tokenTimestamp: 'xKcjtBn8ZARZwcJtjHWDBw',
      receievInspicioToken: 'LOV-CUST-OMNI-RETAIL-7257f49e-3371-45;xKcjtBn8ZARZwcJtjHWDBw',
      sendInspicioToken: '1235678',
      inspicioAdditionalParam: '-dTi_OY7f8NRgdjmz1B-T9U-2Br5GcpUpbLstFAULNI',
    },
  };

  const handlers = [
    rest.post(`*/inspicioservice/inspicio/generateInspicioID`, (req, res, ctx) =>
      res(ctx.status(200), ctx.json(generateInspicioIDJson))
    ),
  ];
  const server = setupServer(...handlers);

  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }

    window.ResizeObserver = ResizeObserver;

    server.listen();
  });

  afterAll(() => {
    server.close();
  });

  test('renders view together page', () => {
    const { getByTestId } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            {...inStorePickupProps}
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = getByTestId('view-together-accordion');
    expect(titleElement).toBeInTheDocument();
  });

  test('render view together with show accordion', () => {
    const { getByTestId, getByLabelText } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = getByTestId('view-together-accordion');
    expect(titleElement).toBeInTheDocument();
    const spanishToggle = getByTestId('test-hitArea');
    expect(spanishToggle).toBeInTheDocument();
    fireEvent.click(spanishToggle);
    const radioButtonPTA = getByLabelText('radio two');
    expect(radioButtonPTA).toBeInTheDocument();
    fireEvent.click(radioButtonPTA);
    const ptaText = getByTestId('view-together-pta');
    expect(ptaText).toBeInTheDocument();
    const radioButtonSMS = getByLabelText('send sms');
    expect(radioButtonSMS).toBeInTheDocument();
    fireEvent.click(radioButtonSMS);
    // const smsText = getByText('Select MDN');
    // expect(smsText).toBeInTheDocument();
    const radioButtonEmail = getByLabelText('send email address');
    expect(radioButtonEmail).toBeInTheDocument();
    fireEvent.click(radioButtonEmail);
    const emailText = getByTestId('email-address');
    expect(emailText).toBeInTheDocument();
    const radioButtonVT = getByLabelText('customer cannot complete in VT');
    expect(radioButtonVT).toBeInTheDocument();
    fireEvent.click(radioButtonVT);
    const vtText = getByTestId('select-reason-vt');
    expect(vtText).toBeInTheDocument();
  });

  test('render customer qr code on click', async () => {
    const { getByTestId, getByLabelText } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
            selectedRadio='Customer QR Code'
            updatedEmail='verizon@gmail.com'
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = getByTestId('view-together-accordion');
    expect(titleElement).toBeInTheDocument();

    const generateButton = getByLabelText('Generate');
    expect(generateButton).toBeInTheDocument();
    fireEvent.click(generateButton);

    await waitFor(() => {
      const viewTogetherPTA = getByLabelText('radio two');
      expect(viewTogetherPTA).toBeInTheDocument();
      fireEvent.click(viewTogetherPTA);

      const generateButtonOnPTA = getByLabelText('Generate');
      expect(generateButtonOnPTA).toBeInTheDocument();
      fireEvent.click(generateButtonOnPTA);

      const radioButtonSMS = getByLabelText('send sms');
      expect(radioButtonSMS).toBeInTheDocument();
      fireEvent.click(radioButtonSMS);
      const sendSMS = getByTestId('send-button-sms');
      expect(sendSMS).toBeInTheDocument();
      fireEvent.click(sendSMS);

      const radioButtonEmail = getByLabelText('send email address');
      expect(radioButtonEmail).toBeInTheDocument();
      fireEvent.click(radioButtonEmail);
      const sendEmail = getByTestId('send-button-email');
      expect(sendEmail).toBeInTheDocument();
      fireEvent.click(sendEmail);
    });
  });

  test('render view together PTA generate on click', async () => {
    const getCartResponse = {
      cartHeader: {
        caseId: 'example_case_id',
        sourceSystem: 'OMNI-RETAIL',
        cartId: 'example_cart_id',
      },
    };
    const onAccordianToggle = jest.fn();
    const { getByTestId, getByLabelText } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            {...inStorePickupProps}
            showAccordion
            getCartResponse={getCartResponse}
            onAccordianToggle={onAccordianToggle}
            spanishSelected
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
            updatedEmail='verizon@gmail.com'
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = getByTestId('view-together-accordion');
    expect(titleElement).toBeInTheDocument();

    const viewTogetherPTA = getByLabelText('radio two');
    expect(viewTogetherPTA).toBeInTheDocument();
    fireEvent.click(viewTogetherPTA);

    const generateButtonOnPTA = getByLabelText('Generate');
    expect(generateButtonOnPTA).toBeInTheDocument();
    fireEvent.click(generateButtonOnPTA);

    const customerQR = getByLabelText('radio one');
    expect(customerQR).toBeInTheDocument();
    fireEvent.click(customerQR);

    const generateButton = getByLabelText('Generate');
    expect(generateButton).toBeInTheDocument();
    fireEvent.click(generateButton);

    // Reduced timeout for CI efficiency
    await new Promise((resolve) => setTimeout(resolve, 100));
    await waitFor(() => {
      const generateButton1 = getByLabelText('Generate');
      expect(generateButton1).toBeInTheDocument();
      const continueButton = getByLabelText('Continue');
      expect(continueButton).toBeInTheDocument();
      fireEvent.click(continueButton);
    });
  });

  test('render view together Retail Companion generate on click', async () => {
    const getCartResponse = {
      cartHeader: {
        caseId: 'example_case_id',
        sourceSystem: 'OMNI-RETAIL',
        cartId: 'example_cart_id',
      },
      orderDetails: {
        totalDueToday: 1,
      },
    };
    const onAccordianToggle = jest.fn();
    const { getByTestId, getByLabelText } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            {...inStorePickupProps}
            showAccordion
            getCartResponse={getCartResponse}
            onAccordianToggle={onAccordianToggle}
            spanishSelected
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
            updatedEmail='verizon@gmail.com'
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = getByTestId('view-together-accordion');
    expect(titleElement).toBeInTheDocument();

    const viewTogetherPTA = getByLabelText('radio six');
    expect(viewTogetherPTA).toBeInTheDocument();
    fireEvent.click(viewTogetherPTA);

    const generateButtonOnPTA = getByLabelText('Generate');
    expect(generateButtonOnPTA).toBeInTheDocument();
    fireEvent.click(generateButtonOnPTA);

    // Reduced timeout for CI efficiency
    await new Promise((resolve) => setTimeout(resolve, 100));
    await waitFor(() => {
      const generateButton1 = getByLabelText('Generate');
      expect(generateButton1).toBeInTheDocument();
      const continueButton = getByLabelText('Continue');
      expect(continueButton).toBeInTheDocument();
      fireEvent.click(continueButton);
    });
  });

  test('render hide PTA device option for splitFulfilmet', async () => {
    window.sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'TRUE' }));
    const getCartResponse = {
      orderDetails: {
        itemLevelShipment: true,
      },
    };
    const onAccordianToggle = jest.fn();
    const { getByTestId, queryByLabelText } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            {...inStorePickupProps}
            showAccordion
            getCartResponse={getCartResponse}
            onAccordianToggle={onAccordianToggle}
            spanishSelected
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
            updatedEmail='verizon@gmail.com'
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = getByTestId('view-together-accordion');
    expect(titleElement).toBeInTheDocument();

    const viewTogetherPTA = queryByLabelText('radio two');
    expect(viewTogetherPTA).not.toBeInTheDocument();
  });

  test('render view together PTA generate on click', async () => {
    const { getByTestId, getByLabelText } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = getByTestId('view-together-accordion');
    expect(titleElement).toBeInTheDocument();

    const viewTogetherPTA = getByLabelText('radio two');
    expect(viewTogetherPTA).toBeInTheDocument();
    fireEvent.click(viewTogetherPTA);

    const generateButtonOnPTA = getByLabelText('Generate');
    expect(generateButtonOnPTA).toBeInTheDocument();
    fireEvent.click(generateButtonOnPTA);

    const customerQR = getByLabelText('radio one');
    expect(customerQR).toBeInTheDocument();
    fireEvent.click(customerQR);

    const generateButton = getByLabelText('Generate');
    expect(generateButton).toBeInTheDocument();
    fireEvent.click(generateButton);

    // Reduced timeout for CI efficiency
    await new Promise((resolve) => setTimeout(resolve, 100));
    await waitFor(() => {
      const generateButton1 = getByLabelText('Generate');
      expect(generateButton1).toBeInTheDocument();
      const continueButton = getByLabelText('Continue');
      expect(continueButton).toBeInTheDocument();
      fireEvent.click(continueButton);
    });
  });

  test('renders dropdown options for MDNs', () => {
    const mockMtns = [
      { mtn: '1234567890' },
      { mtn: '9876543210' },
      // Add more mock MTNs as needed
    ];

    const mockBillAccount = {
      mtns: mockMtns,
    };

    const mockCustomerProfile = {
      billAccounts: [mockBillAccount],
    };

    const mockGetCartResponse = {
      customerProfile: mockCustomerProfile,
    };

    const { getByTestId } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
            getCartResponse={mockGetCartResponse}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const titleElement = getByTestId('view-together-accordion');
    expect(titleElement).toBeInTheDocument();
  });

  test('updates subReasonSelected state on dropdown select', async () => {
    const mockHandleShowViewTogether = jest.fn();
    const mockonAccordianToggle = jest.fn();
    const { getByTestId, getByLabelText } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
            handleShowViewTogether={mockHandleShowViewTogether}
            onAccordianToggle={mockonAccordianToggle}
            showAccordion
            subReasonSelected='Systemic Issue Impeding Transaction'
            {...inStorePickupProps}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    // Simulate selecting an option from the dropdown
    const radioButtonVT = getByLabelText('customer cannot complete in VT');
    expect(radioButtonVT).toBeInTheDocument();
    fireEvent.click(radioButtonVT);

    const selectElement = getByTestId('select-reason-vt');
    fireEvent.change(selectElement, { target: { value: 'Systemic Issue Impeding Transaction' } });

    await waitFor(() => {
      const continueButton = getByTestId('continue-vt');
      expect(continueButton).toBeInTheDocument();
      fireEvent.click(continueButton);

      expect(mockHandleShowViewTogether).toHaveBeenCalledTimes(1);
    });
  });

  test('dispatch event 1', async () => {
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData);
    window.mfe = { scmCheckoutMfeEnable: true };
    const mockGetCartResponse = {
      cartHeader: {
        caseId: 'example_case_id',
        sourceSystem: 'OMNI-RETAIL',
        cartId: 'example_cart_id',
      },
      orderDetails: { customerType: 'N' },
      lineDetails: {
        lineInfo: [
          {
            primaryUserInfo: { emailId: 'verizon@Gmail.com' },
            lineActivityType: 'EUPBYOD',
            itemsInfo: [
              {
                cartItems: {
                  cartItem: [
                    {
                      cartItemType: 'SIM',
                      isCustomerProvidedSIM: true,
                      inventory: {
                        isAvailable: true,
                        isBackorder: true,
                        isDeliverBy: false,
                        isPreOrder: true,
                        qtyAvailable: 10198,
                        isShipBy: false,
                      },
                    },
                  ],
                },
              },
            ],
          },
        ],
      },
    };
    const mockCustomerProfile = {
      data: {
        customer: { cartId: '12345' },
      },
    };

    const mockLandingData = {
      quoteDetails: [
        {
          item: {
            cartId: '12345',
            quoteId: '45678',
          },
        },
      ],
    };

    const { getByTestId } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
            updatedEmail={null}
            getCartResponse={mockGetCartResponse}
            customerProfile={mockCustomerProfile}
            landing={mockLandingData}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = getByTestId('view-together-accordion');
    expect(titleElement).toBeInTheDocument();

    const receivePollEvent = new CustomEvent('receivePoll', {
      detail: {
        event: 'submit',
        payload: {
          field: 'pageName',
          value: 'orderReview',
        },
        status: 'Success',
        cluster: 'S',
        reducedTimeout: 'Y',
        linkExpiredDays: 0,
        linkExpiredMins: 0,
      },
    });

    fireEvent(window.document, receivePollEvent);

    await waitFor(() => {
      expect(handleReceivePoll).toHaveBeenCalledTimes(1);
    });
  });

  test('dispatch lovOrderReview event', async () => {
    const mockHandleShowViewTogether = jest.fn();
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData);
    window.mfe = { scmCheckoutMfeEnable: true };
    const mockGetCartResponse = {
      cartHeader: {
        caseId: 'example_case_id',
        sourceSystem: 'OMNI-RETAIL',
        cartId: 'example_cart_id',
      },
      orderDetails: { customerType: 'N' },
      lineDetails: {
        lineInfo: [
          {
            primaryUserInfo: { emailId: 'verizon@Gmail.com' },
            lineActivityType: 'EUPBYOD',
            itemsInfo: [
              {
                cartItems: {
                  cartItem: [
                    {
                      cartItemType: 'SIM',
                      isCustomerProvidedSIM: true,
                      inventory: {
                        isAvailable: true,
                        isBackorder: true,
                        isDeliverBy: false,
                        isPreOrder: true,
                        qtyAvailable: 10198,
                        isShipBy: false,
                      },
                    },
                  ],
                },
              },
            ],
          },
        ],
      },
    };
    const mockCustomerProfile = {
      data: {
        customer: { cartId: '12345' },
      },
    };

    const mockLandingData = {
      quoteDetails: [
        {
          item: {
            cartId: '12345',
            quoteId: '45678',
          },
        },
      ],
    };

    const { getByTestId } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
            updatedEmail={null}
            getCartResponse={mockGetCartResponse}
            customerProfile={mockCustomerProfile}
            landing={mockLandingData}
            handleShowViewTogether={mockHandleShowViewTogether}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = getByTestId('view-together-accordion');
    expect(titleElement).toBeInTheDocument();

    const receivePollEvent = new CustomEvent('receivePoll', {
      detail: {
        event: 'lovOrderReview',
        payload: {
          field: 'pageName',
          value: 'customerWindowClose',
        },
        status: 'Success',
        cluster: 'S',
        reducedTimeout: 'Y',
        linkExpiredDays: 0,
        linkExpiredMins: 0,
      },
    });

    fireEvent(window.document, receivePollEvent);

    await waitFor(() => {
      expect(mockHandleShowViewTogether).toHaveBeenCalledTimes(1);
    });
  });

  test('dispatch event for mileStone', async () => {
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData);
    window.mfe = { scmCheckoutMfeEnable: false };
    const mockError = new Error('Test error');
    const mockExecuteShellFunction = jest.fn(() => {
      throw mockError;
    });
    jest.mock('onevzsoemfeframework/DomService', () => ({
      executeShellFunction: () => mockExecuteShellFunction,
    }));
    const onCloseAccordianToggleMock = jest.fn();
    const setOpenMock = jest.fn();
    const { getByTestId } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
            updatedEmail={null}
            onCloseAccordianToggle={onCloseAccordianToggleMock}
            setOpen={setOpenMock}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = getByTestId('view-together-accordion');
    expect(titleElement).toBeInTheDocument();

    const receivePollEvent = new CustomEvent('receivePoll', {
      detail: {
        event: 'openRepEmulator',
        payload: {
          action: 'openRepEmulator',
          value: 'makePayment',
          flow: 'rc',
        },
        status: 'Success',
        cluster: 'S',
        reducedTimeout: 'Y',
        linkExpiredDays: 0,
        linkExpiredMins: 0,
      },
    });

    fireEvent(window.document, receivePollEvent);

    await waitFor(() => {
      expect(handleReceivePoll).toHaveBeenCalledTimes(1);
    });
  });

  test('dispatch event for mileStone', async () => {
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData);
    window.mfe = { scmCheckoutMfeEnable: false };

    const onCloseAccordianToggleMock = jest.fn();
    const setOpenMock = jest.fn();
    const { getByTestId } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
            updatedEmail={null}
            onCloseAccordianToggle={onCloseAccordianToggleMock}
            setOpen={setOpenMock}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = getByTestId('view-together-accordion');
    expect(titleElement).toBeInTheDocument();

    const receivePollEvent = new CustomEvent('receivePoll', {
      detail: {
        event: 'openRepEmulator',
        payload: {
          action: 'openRepEmulator',
          value: 'makePayment',
        },
        status: 'Success',
        cluster: 'S',
        reducedTimeout: 'Y',
        linkExpiredDays: 0,
        linkExpiredMins: 0,
      },
    });

    fireEvent(window.document, receivePollEvent);

    await waitFor(() => {
      expect(handleReceivePoll).toHaveBeenCalledTimes(1);
    });
  });

  test('dispatch event', async () => {
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData);
    window.mfe = { scmCheckoutMfeEnable: false };
    sessionStorage.setItem('customerType', 'PE');
    sessionStorage.setItem('tagActiveMTN', 12345678);
    const mockGetCartResponse = {
      cartHeader: {
        caseId: 'example_case_id',
        sourceSystem: 'OMNI-RETAIL',
        cartId: 'example_cart_id',
      },
      orderDetails: {
        customerType: 'N',
        accessoryFinancingOfferInfo: {
          splitPaymentInfo: [
            {
              orderNumber: '0',
              nonAccessoryTotal: 257.48,
              accessoryTotal: 624.79,
              totalFinanceAmount: 0.0,
              monthlyFinanceAmount: 0.0,
              isAfo: true,
              isDfo: true,
            },
          ],
        },
      },
      lineDetails: {
        lineInfo: [
          {
            primaryUserInfo: { emailId: 'verizon@Gmail.com' },
            lineActivityType: 'EUPBYOD',
            itemsInfo: [
              {
                cartItems: {
                  cartItem: [
                    {
                      cartItemType: 'SIM',
                      isCustomerProvidedSIM: true,
                    },
                  ],
                },
              },
            ],
          },
        ],
      },
    };
    const mockCustomerProfile = {
      data: {
        customer: { cartId: '12345' },
      },
    };

    const mockLandingData = {
      quoteDetails: [
        {
          item: {
            cartId: '12345',
            quoteId: '45678',
          },
        },
      ],
    };

    const { getByTestId, getByLabelText } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
            updatedEmail={null}
            getCartResponse={mockGetCartResponse}
            customerProfile={mockCustomerProfile}
            landing={mockLandingData}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = getByTestId('view-together-accordion');
    expect(titleElement).toBeInTheDocument();

    const viewTogetherPTA = getByLabelText('radio two');
    expect(viewTogetherPTA).toBeInTheDocument();
    fireEvent.click(viewTogetherPTA);

    const generateButtonOnPTA = getByLabelText('Generate');
    expect(generateButtonOnPTA).toBeInTheDocument();
    fireEvent.click(generateButtonOnPTA);

    const customerQR = getByLabelText('radio one');
    expect(customerQR).toBeInTheDocument();
    fireEvent.click(customerQR);

    const generateButton = getByLabelText('Generate');
    expect(generateButton).toBeInTheDocument();
    fireEvent.click(generateButton);

    const receivePollEvent = new CustomEvent('receivePoll', {
      detail: {
        event: 'submit',
        payload: {
          field: 'pageName',
          value: 'orderReview',
        },
        status: 'Success',
        cluster: 'S',
        reducedTimeout: 'Y',
        linkExpiredDays: 0,
        linkExpiredMins: 0,
      },
    });

    fireEvent(window.document, receivePollEvent);

    await waitFor(() => {
      expect(handleReceivePoll).toHaveBeenCalledTimes(1);
    });
  });

  test('dispatch event', async () => {
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData);
    window.mfe = { scmCheckoutMfeEnable: false };
    const mockGetCartResponse = {
      cartHeader: {
        caseId: 'example_case_id',
        sourceSystem: 'OMNI-RETAIL',
        cartId: 'example_cart_id',
      },
      orderDetails: {
        customerType: 'N',
        accessoryFinancingOfferInfo: {
          splitPaymentInfo: [
            {
              orderNumber: '0',
              nonAccessoryTotal: 257.48,
              accessoryTotal: 624.79,
              totalFinanceAmount: 0.0,
              monthlyFinanceAmount: 0.0,
              isAfo: true,
              isDfo: true,
            },
          ],
        },
      },
      lineDetails: {
        lineInfo: [
          {
            primaryUserInfo: { emailId: 'verizon@Gmail.com' },
            lineActivityType: 'EUPBYOD',
            itemsInfo: [
              {
                cartItems: {
                  cartItem: [
                    {
                      cartItemType: 'SIM',
                      isCustomerProvidedSIM: true,
                    },
                  ],
                },
              },
            ],
          },
        ],
      },
    };
    const mockCustomerProfile = {
      data: {
        customer: { cartId: '12345' },
      },
    };

    const mockLandingData = {
      quoteDetails: [
        {
          item: {
            cartId: '12345',
            quoteId: '45678',
          },
        },
      ],
    };

    const onCloseAccordianToggleMock = jest.fn();
    const setOpenMock = jest.fn();
    const { getByTestId } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
            updatedEmail={null}
            getCartResponse={mockGetCartResponse}
            customerProfile={mockCustomerProfile}
            landing={mockLandingData}
            onCloseAccordianToggle={onCloseAccordianToggleMock}
            setOpen={setOpenMock}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = getByTestId('view-together-accordion');
    expect(titleElement).toBeInTheDocument();

    const receivePollEvent = new CustomEvent('receivePoll', {
      detail: {
        event: 'submit',
        payload: {
          action: 'load',
          pageName: 'lovorderreview',
        },
        status: 'Success',
        cluster: 'S',
        reducedTimeout: 'Y',
        linkExpiredDays: 0,
        linkExpiredMins: 0,
      },
    });

    fireEvent(window.document, receivePollEvent);

    await waitFor(() => {
      expect(handleReceivePoll).toHaveBeenCalledTimes(1);
    });
  });

  test('dispatch event customerWindowClose', async () => {
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData);
    window.mfe = { scmCheckoutMfeEnable: false };
    const mockGetCartResponse = {
      cartHeader: {
        caseId: 'example_case_id',
        sourceSystem: 'OMNI-RETAIL',
        cartId: 'example_cart_id',
      },
      orderDetails: {
        customerType: 'N',
        accessoryFinancingOfferInfo: {
          splitPaymentInfo: [
            {
              orderNumber: '0',
              nonAccessoryTotal: 257.48,
              accessoryTotal: 624.79,
              totalFinanceAmount: 0.0,
              monthlyFinanceAmount: 0.0,
              isAfo: true,
              isDfo: true,
            },
          ],
        },
      },
      lineDetails: {
        lineInfo: [
          {
            primaryUserInfo: { emailId: 'verizon@Gmail.com' },
            lineActivityType: 'EUPBYOD',
            itemsInfo: [
              {
                cartItems: {
                  cartItem: [
                    {
                      cartItemType: 'SIM',
                      isCustomerProvidedSIM: true,
                    },
                  ],
                },
              },
            ],
          },
        ],
      },
    };
    const mockCustomerProfile = {
      data: {
        customer: { cartId: '12345' },
      },
    };

    const mockLandingData = {
      quoteDetails: [
        {
          item: {
            cartId: '12345',
            quoteId: '45678',
          },
        },
      ],
    };

    const onCloseAccordianToggleMock = jest.fn();
    const setOpenMock = jest.fn();
    const { getByTestId } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
            updatedEmail={null}
            getCartResponse={mockGetCartResponse}
            customerProfile={mockCustomerProfile}
            landing={mockLandingData}
            onCloseAccordianToggle={onCloseAccordianToggleMock}
            setOpen={setOpenMock}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = getByTestId('view-together-accordion');
    expect(titleElement).toBeInTheDocument();

    const receivePollEvent = new CustomEvent('receivePoll', {
      detail: {
        event: 'submit',
        payload: {
          action: 'customerWindowClose',
          value: 'customerWindowClose',
          source: 'rep',
        },
        status: 'Success',
        cluster: 'S',
        reducedTimeout: 'Y',
        linkExpiredDays: 0,
        linkExpiredMins: 0,
      },
    });

    fireEvent(window.document, receivePollEvent);

    await waitFor(() => {
      expect(handleReceivePoll).toHaveBeenCalledTimes(0);
    });
  });

  test('dispatch event for mileStone', async () => {
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData);
    window.mfe = { scmCheckoutMfeEnable: false };
    const mockGetCartResponse = {
      cartHeader: {
        caseId: 'example_case_id',
        sourceSystem: 'OMNI-RETAIL',
        cartId: 'example_cart_id',
      },
      orderDetails: {
        customerType: 'N',
        accessoryFinancingOfferInfo: {
          splitPaymentInfo: [
            {
              orderNumber: '0',
              nonAccessoryTotal: 257.48,
              accessoryTotal: 624.79,
              totalFinanceAmount: 0.0,
              monthlyFinanceAmount: 0.0,
              isAfo: true,
              isDfo: true,
            },
          ],
        },
      },
      lineDetails: {
        lineInfo: [
          {
            primaryUserInfo: { emailId: 'verizon@Gmail.com' },
            lineActivityType: 'EUPBYOD',
            itemsInfo: [
              {
                cartItems: {
                  cartItem: [
                    {
                      cartItemType: 'SIM',
                      isCustomerProvidedSIM: true,
                    },
                  ],
                },
              },
            ],
          },
        ],
      },
    };
    const mockCustomerProfile = {
      data: {
        customer: { cartId: '12345' },
      },
    };

    const mockLandingData = {
      quoteDetails: [
        {
          item: {
            cartId: '12345',
            quoteId: '45678',
          },
        },
      ],
    };

    const onCloseAccordianToggleMock = jest.fn();
    const setOpenMock = jest.fn();
    const { getByTestId } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
            updatedEmail={null}
            getCartResponse={mockGetCartResponse}
            customerProfile={mockCustomerProfile}
            landing={mockLandingData}
            onCloseAccordianToggle={onCloseAccordianToggleMock}
            setOpen={setOpenMock}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = getByTestId('view-together-accordion');
    expect(titleElement).toBeInTheDocument();

    const receivePollEvent = new CustomEvent('receivePoll', {
      detail: {
        event: 'milestone',
        payload: {
          action: 'milestone',
          value: 'makePayment',
        },
        status: 'Success',
        cluster: 'S',
        reducedTimeout: 'Y',
        linkExpiredDays: 0,
        linkExpiredMins: 0,
      },
    });

    fireEvent(window.document, receivePollEvent);

    await waitFor(() => {
      expect(handleReceivePoll).toHaveBeenCalledTimes(1);
    });
  });

  test('Button uses primary style and shows "Send" label when displaySendEmailActionClick is true :1', async () => {
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData);

    const { getByTestId, getByLabelText, rerender } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const viewTogetherInstance = getByTestId('view-together-accordion');
    viewTogetherInstance.displaySendEmailActionClick = true;
    rerender(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    await waitFor(() => {
      const radioButtonEmail = getByLabelText('send email address');
      expect(radioButtonEmail).toBeInTheDocument();
      fireEvent.click(radioButtonEmail);
      const button = getByTestId('send-button-email');
      expect(button).toBeInTheDocument();
      expect(button).toHaveTextContent('Send');
      fireEvent.click(button);
      // expect(screen.getByTestId('hidden-input')).toBeInTheDocument();
    });
  });

  test('Button uses primary style and shows "Send" label when displaySendEmailActionClick is true and stopPollFromSession is true', async () => {
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData);
    const { getByTestId, getByLabelText, rerender } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const viewTogetherInstance = getByTestId('view-together-accordion');
    viewTogetherInstance.displaySendEmailActionClick = true;
    rerender(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    await waitFor(() => {
      window.sessionStorage.setItem('stopPollFromSession', true);
      const radioButtonEmail = getByLabelText('send email address');
      expect(radioButtonEmail).toBeInTheDocument();
      fireEvent.click(radioButtonEmail);
      const button = getByTestId('send-button-email');
      expect(button).toBeInTheDocument();
      fireEvent.click(button);
      const stopPollFromSession = window.sessionStorage.getItem('stopPollFromSession');
      expect(stopPollFromSession).toBe('true');
    });
  });

  test('Button uses primary style and shows "Send" label when displaySendEmailActionClick is true:2', async () => {
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData);
    window.mfe = { scmCheckoutMfeEnable: true };
    const { getByTestId, getByLabelText, rerender } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            // inspicioURLValue ='testing value'
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const viewTogetherInstance = getByTestId('view-together-accordion');
    viewTogetherInstance.displaySendEmailActionClick = true;
    rerender(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            // inspicioURLValue ='testing value'
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    await waitFor(() => {
      const radioButtonSMS = getByLabelText('send sms');
      expect(radioButtonSMS).toBeInTheDocument();
      fireEvent.click(radioButtonSMS);
      const sendSMS = getByTestId('send-button-sms');
      expect(sendSMS).toBeInTheDocument();
      fireEvent.click(sendSMS);

      // const selectMdn = screen.getByRole('combobox', {
      //   name: 'select mdn required',
      // });
      // fireEvent.change(selectMdn);

      const radioButtonEmail = getByLabelText('send email address');
      expect(radioButtonEmail).toBeInTheDocument();
      fireEvent.click(radioButtonEmail);
      const button = getByTestId('send-button-email');
      expect(button).toBeInTheDocument();
      expect(button).toHaveTextContent('Send');
      fireEvent.click(button);
    });
  });
  test('Button uses primary style and shows "Send" label when displaySendEmailActionClick is true:3', async () => {
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData);
    handleLogCustomerUrl.mockResolvedValue('vza.test');
    window.mfe = { scmCheckoutMfeEnable: true };
    const { getByTestId, getByLabelText, rerender } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            // inspicioURLValue ='testing value'
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const viewTogetherInstance = getByTestId('view-together-accordion');
    viewTogetherInstance.displaySendEmailActionClick = true;
    rerender(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            // inspicioURLValue ='testing value'
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const radioButtonSMS = getByLabelText('send sms');
    fireEvent.click(radioButtonSMS);
    const sendSMS = getByTestId('send-button-sms');
    fireEvent.click(sendSMS);

    // FIX: Wait for the hidden input to appear asynchronously
    const hiddenInput = await screen.findByTestId('hidden-input');
    expect(hiddenInput).toBeInTheDocument();
  });

  test('test new customer SMS component', async () => {
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData);
    window.mfe = { scmCheckoutMfeEnable: true };
    sessionStorage.setItem('customerType', 'N');
    const { getByTestId, getByLabelText, rerender } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const viewTogetherInstance = getByTestId('view-together-accordion');
    viewTogetherInstance.displaySendEmailActionClick = true;
    rerender(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    await waitFor(() => {
      const radioButtonSMS = getByLabelText('send sms');
      expect(radioButtonSMS).toBeInTheDocument();
      fireEvent.click(radioButtonSMS);
      // expect(screen.getByTestId('hidden-input')).toBeInTheDocument();
    });
  });

  test('isDark true', () => {
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData);
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    const { getByTestId } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            {...inStorePickupProps}
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = getByTestId('view-together-accordion');
    expect(titleElement).toBeInTheDocument();
  });
  test('Show Non VT Option dropdown when scmCheckoutMfeEnable enable', async () => {
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => mockData);
    const reasons = [
      { value: 'Systemic Issue Impeding Transaction', label: 'Systemic Issue Impeding Transaction' },
      { value: '2', label: 'Reason 2' },
    ];

    sessionStorage.setItem('vzwACSSNonVTReasons', JSON.stringify(reasons));

    window.mfe = { scmCheckoutMfeEnable: true };
    const mockHandleShowViewTogether = jest.fn();
    const mockonAccordianToggle = jest.fn();
    const { getByTestId, getByLabelText } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
            handleShowViewTogether={mockHandleShowViewTogether}
            onAccordianToggle={mockonAccordianToggle}
            showAccordion
            subReasonSelected={reasons}
            {...inStorePickupProps}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const radioButtonVT = getByLabelText('customer cannot complete in VT');
    expect(radioButtonVT).toBeInTheDocument();
    fireEvent.click(radioButtonVT);

    const selectElement = getByTestId('select-reason-vt');
    fireEvent.change(selectElement, { target: { value: 'Systemic Issue Impeding Transaction' } });

    await waitFor(() => {
      const continueButton = getByTestId('continue-vt');
      expect(continueButton).toBeInTheDocument();
      fireEvent.click(continueButton);

      expect(mockHandleShowViewTogether).toHaveBeenCalledTimes(1);
    });
  });

  test('isDark true with getResultGenerateInspicioId and getResultSendMessage', () => {
    const mockData1 = {
      ...mockData,
      getResultGenerateInspicioId: { data: { sendInspicioToken: 'OMNI', receievInspicioToken: '1234' } },
      getResultSendMessage: { data: { cluster: 'PROD' } },
    };
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData1);
    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => mockData);
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    const { getByTestId } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            {...inStorePickupProps}
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = getByTestId('view-together-accordion');
    expect(titleElement).toBeInTheDocument();
  });

  test('should call setShowSendMessageError when both send message attempts fail for SMS', async () => {
    sessionStorage.clear();
    sessionStorage.setItem('customerType', 'PE');
    window.mfe = { scmCheckoutMfeEnable: true };

    const mockRequestBodySendMessage = jest.fn();
    const mockSetShowSendMessageError = jest.fn();

    mockRequestBodySendMessage
      .mockRejectedValueOnce(new Error('First API call failed'))
      .mockRejectedValueOnce(new Error('Second API call failed'));

    const mockRequestGenerateInspicioId = jest.fn().mockResolvedValue({
      data: {
        sendInspicioToken: 'test-token-123',
        inspicioAdditionalParam: 'test-param-456',
      },
    });

    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => ({
      ...mockData,
      requestBodySendMessage: mockRequestBodySendMessage,
      requestBodyGenerateInspicioId: mockRequestGenerateInspicioId,
    }));

    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => ({
      getActiveMTNRequest: jest.fn(),
      getActiveMTNResponse: {
        data: {
          customer: {
            billAccounts: [{ mtns: [{ mtn: '1234567890' }] }],
          },
        },
      },
    }));

    render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            {...inStorePickupProps}
            showAccordion
            setShowSendMessageError={mockSetShowSendMessageError}
            onChangeRadio={jest.fn()}
            selectedRadio='SMS'
            getCartResponse={{
              cartHeader: { sourceSystem: 'OMNI-RETAIL' },
              orderDetails: { spocs: { notificationOptions: { primaryEmailId: 'test@test.com' } } },
            }}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const sendButton = screen.getByTestId('send-button-sms');
    fireEvent.click(sendButton);

    await waitFor(() => {
      expect(mockRequestBodySendMessage).toHaveBeenCalledTimes(2);
      expect(mockSetShowSendMessageError).toHaveBeenCalledWith(true);
    });
  });

  test('should call setShowSendMessageError if retry succeeds but has no cluster data', async () => {
    sessionStorage.clear();

    const mockSetShowSendMessageError = jest.fn();
    const mockRequestBodySendMessage = jest.fn()
      .mockRejectedValueOnce(new Error('Initial call failed'))
      .mockResolvedValueOnce({ data: { someOtherData: 'value' } });
    const mockRequestGenerateInspicioId = jest.fn().mockResolvedValue({
      data: {
        sendInspicioToken: 'test-token-123',
        inspicioAdditionalParam: 'test-param-456',
      },
    });

    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => ({
      ...mockData,
      requestBodySendMessage: mockRequestBodySendMessage,
      requestBodyGenerateInspicioId: mockRequestGenerateInspicioId,
    }));

    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => ({
      getActiveMTNRequest: jest.fn(),
      getActiveMTNResponse: { data: {} },
    }));

    render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            {...inStorePickupProps}
            showAccordion
            setShowSendMessageError={mockSetShowSendMessageError}
            onChangeRadio={jest.fn()}
            selectedRadio='SMS'
            getCartResponse={{
              cartHeader: { sourceSystem: 'OMNI-RETAIL' },
              orderDetails: { spocs: { notificationOptions: { primaryEmailId: 'test@test.com' } } },
            }}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const sendButton = screen.getByTestId('send-button-sms');
    fireEvent.click(sendButton);

    await waitFor(() => {
      expect(mockRequestBodySendMessage).toHaveBeenCalledTimes(2);
      expect(mockSetShowSendMessageError).toHaveBeenCalledWith(true);
    });
  });

  test('should initiate polling if send message succeeds and polling is not yet active', async () => {
    // 1. Setup
    sessionStorage.clear();
    const mockHandleHideContinueShowViewTogether = jest.fn();
    const mockRequestSendLovLink = jest.fn();

    // 2. Configure mocks to force the desired code path
    const mockRequestBodySendMessage = jest.fn().mockResolvedValue({
      data: { cluster: 'PROD-CLUSTER' }, // This call must succeed with a cluster
    });

    const mockRequestGenerateInspicioId = jest.fn().mockResolvedValue({
      data: {
        sendInspicioToken: 'test-token-123',
        inspicioAdditionalParam: 'test-param-456',
      },
    });

    // FIX: Make the hook mock explicit to avoid conflicts with shared mockData
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => ({
      requestBodySendMessage: mockRequestBodySendMessage,
      requestBodyGenerateInspicioId: mockRequestGenerateInspicioId,
      requestBodySendLovLink: mockRequestSendLovLink,
      // Provide default mocks for other functions returned by the hook
      requestBodySendEmail: jest.fn(),
      requestBodyGeneratePaxQRCode: jest.fn(),
      getResultGenerateInspicioId: {},
      getResultSendMessage: {},
      getResultSendLovLink: {},
      getResultSendEmail: {},
    }));

    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => ({
      getActiveMTNRequest: jest.fn(),
      getActiveMTNResponse: { data: {} },
    }));

    // 3. Render the component
    render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            {...inStorePickupProps}
            showAccordion
            onChangeRadio={jest.fn()}
            selectedRadio='SMS'
            handleHideContinueShowViewTogether={mockHandleHideContinueShowViewTogether} // Pass the mock prop
            getCartResponse={{
              cartHeader: { sourceSystem: 'OMNI-RETAIL' },
              orderDetails: { spocs: { notificationOptions: { primaryEmailId: 'test@test.com' } } },
            }}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    // 4. Trigger the action
    const sendButton = screen.getByTestId('send-button-sms');
    fireEvent.click(sendButton);

    // 5. Assert the result
    await waitFor(() => {
      // FIX: Assert that a function inside the 'if' block was called.
      // This is a more direct and stable way to confirm the code path was executed.
      expect(mockHandleHideContinueShowViewTogether).toHaveBeenCalledWith(true);
      expect(mockRequestSendLovLink).toHaveBeenCalled();
    });
  });

  test('resets stopPollFromSession flag when starting a new session via email', async () => {
    // Define a comprehensive mock data object for all hooks
    const mockApiData = {
      requestBodySendLovLink: jest.fn().mockResolvedValue({}),
      getResultSendLovLink: { data: { serviceBody: { serviceResponse: { context: { caseId: 'test' } } } } },
      requestBodyGenerateInspicioId: jest.fn().mockResolvedValue({ data: { sendInspicioToken: 'test-token' } }),
      requestBodySendMessage: jest.fn().mockResolvedValue({ data: { cluster: 'TEST' } }),
      requestBodySendEmail: jest.fn().mockResolvedValue({}),
      getResultSendEmail: { data: {} },
      requestBodyGeneratePaxQRCode: jest.fn(),
      getResultGenerateInspicioId: { data: { sendInspicioToken: 'OMNI' } },
      getResultSendMessage: { data: {} },
      getActiveMTNRequest: jest.fn(),
      getActiveMTNResponse: { data: mockGetAllActiveMtnResult },
    };

    // Mock all the necessary API call hooks
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockApiData);
    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => mockApiData);
    // THIS MOCK WAS MISSING AND IS THE PRIMARY FIX
    jest.spyOn(require('../../modules/services/APIService/AgreementsAPICallHook'), 'default').mockImplementation(() => ({
        getOrderWrite: jest.fn(),
    }));


    const { getByTestId, getByLabelText } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
            getCartResponse={{
              orderDetails: { spocs: { notificationOptions: { primaryEmailId: 'test@test.com' } } },
              cartHeader: {},
            }}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    // 1. Simulate a previously stopped session
    window.sessionStorage.setItem('stopPollFromSession', 'true');
    expect(window.sessionStorage.getItem('stopPollFromSession')).toBe('true');

    // 2. Select the 'Email Address' radio button
        // Use the control's aria-label as defined in viewTogetherOptionsHelper
    const radioButtonEmail = getByLabelText('send email address');
    fireEvent.click(radioButtonEmail);

    // 3. Click the 'Send' button to trigger the target logic
    const sendButton = getByTestId('send-button-email');
    fireEvent.click(sendButton);

    // 4. Wait for async operations and assert the flag is correctly reset
    await waitFor(() => {
      expect(window.sessionStorage.getItem('stopPollFromSession')).toBe('false');
    });
  });
  
  // New test for feature-flagged getCustomerByMtn: ensure Email option hidden without email
  test('does NOT show Email Address option when getCustomerByMtn has no email', async () => {
    const apiHook = require('../../modules/services/APIService/APIServiceCallHook');
    const mtnSpy = jest
      .spyOn(apiHook, 'useLazyGetCustomerByMtnQuery')
      .mockReturnValue([
        jest.fn(),
        {
          status: 'fulfilled',
          isUninitialized: false,
          isLoading: false,
          isSuccess: true,
          isError: false,
          isFetching: false,
          data: { customer: {} },
        },
      ]);

    const infoSpy = jest
      .spyOn(InfoApiCallHook, 'default')
      .mockImplementation(() => ({ getActiveMTNRequest: jest.fn(), getActiveMTNResponse: { data: {} }, updateVisionRemark: jest.fn() }));

    // Minimal stubs for hooks destructured by ViewTogether
    const vtSpy = jest
      .spyOn(ViewTogetherApiCallHook, 'default')
      .mockImplementation(() => ({
        requestBodyGenerateInspicioId: jest.fn(),
        requestBodySendMessage: jest.fn(),
        requestBodySendLovLink: jest.fn(),
        requestBodySendEmail: jest.fn(),
        requestBodyGeneratePaxQRCode: jest.fn(),
        getResultGenerateInspicioId: { data: {} },
        getResultSendMessage: { data: {} },
        getResultSendLovLink: { data: {} },
        getResultSendEmail: { data: {} },
      }));

    const agreementsSpy = jest
      .spyOn(require('../../modules/services/APIService/AgreementsAPICallHook'), 'default')
      .mockImplementation(() => ({ getOrderWrite: jest.fn() }));

    window.mfe = { scmCheckoutMfeEnable: true };

    const { getByTestId } = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewTogether
            showAccordion
            {...inStorePickupProps}
            handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
            onChangeSubReason={mockOnChangeSubReason}
            onChangeRadio={mockOnChangeRadio}
            setReceivedLovPollResponse={setReceivedLovPollResponse}
            customerProfile={{ data: { customer: { lookupMtn: '123' } } }}
            getCartResponse={{ orderDetails: { spocs: { notificationOptions: {} } } }}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    expect(getByTestId('view-together-accordion')).toBeInTheDocument();

    await waitFor(() => {
      expect(screen.queryByText('Email Address')).toBeNull();
    });

    mtnSpy.mockRestore();
    infoSpy.mockRestore();
    vtSpy.mockRestore();
    agreementsSpy.mockRestore();
  });

  // Test cases for getCustomerByMtn useEffect (lines 338-343)
  describe('getCustomerByMtn useEffect coverage', () => {
    beforeEach(() => {
      // Ensure functionality is enabled
      const { isFunctionalityEnabled } = require('onevzsoemfecommon/Helpers');
      isFunctionalityEnabled.mockReturnValue(true);
    });

    test('should call getCustomerByMtn when all conditions are met', async () => {
      // Set up sessionStorage BEFORE rendering to ensure lookUpMTN is calculated properly
      sessionStorage.clear();
      sessionStorage.setItem('customerType', 'E'); // Not 'N'
      sessionStorage.setItem('tagActiveMTN', '1234567890');
      sessionStorage.removeItem('newPostToPreIndicator'); // Not post-to-pre

      const mockGetCustomerByMtn = jest.fn().mockResolvedValue({ data: { customer: {} } });
      const apiHook = require('../../modules/services/APIService/APIServiceCallHook');
      const mtnSpy = jest
        .spyOn(apiHook, 'useLazyGetCustomerByMtnQuery')
        .mockReturnValue([
          mockGetCustomerByMtn,
          {
            status: 'pending',
            isUninitialized: false,
            isLoading: false,
            isSuccess: false,
            isError: false,
            isFetching: false,
            data: null,
          },
        ]);

      const infoSpy = jest
        .spyOn(InfoApiCallHook, 'default')
        .mockImplementation(() => ({ 
          getActiveMTNRequest: jest.fn(), 
          getActiveMTNResponse: { data: {} }, 
          updateVisionRemark: jest.fn() 
        }));

      const vtSpy = jest
        .spyOn(ViewTogetherApiCallHook, 'default')
        .mockImplementation(() => ({
          requestBodyGenerateInspicioId: jest.fn(),
          requestBodySendMessage: jest.fn(),
          requestBodySendLovLink: jest.fn(),
          requestBodySendEmail: jest.fn(),
          requestBodyGeneratePaxQRCode: jest.fn(),
          getResultGenerateInspicioId: { data: {} },
          getResultSendMessage: { data: {} },
          getResultSendLovLink: { data: {} },
          getResultSendEmail: { data: {} },
        }));

      const agreementsSpy = jest
        .spyOn(require('../../modules/services/APIService/AgreementsAPICallHook'), 'default')
        .mockImplementation(() => ({ getOrderWrite: jest.fn() }));

      const { getByTestId } = render(
        <BrowserRouter>
          <StoreProvider>
            <ViewTogether
              showAccordion
              {...inStorePickupProps}
              handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
              onChangeSubReason={mockOnChangeSubReason}
              onChangeRadio={mockOnChangeRadio}
              setReceivedLovPollResponse={setReceivedLovPollResponse}
              customerProfile={{ data: { customer: { lookupMtn: '1234567890' } } }}
              getCartResponse={{ orderDetails: {}, cartHeader: { fullAccountNumber: '123456' } }}
            />
          </StoreProvider>
        </BrowserRouter>
      );

      expect(getByTestId('view-together-accordion')).toBeInTheDocument();

      // Wait and verify the API was called
      await waitFor(() => {
        expect(mockGetCustomerByMtn).toHaveBeenCalled();
      }, { timeout: 5000 });
      
      expect(mockGetCustomerByMtn).toHaveBeenCalledWith({ body: {}, spinner: false });

      mtnSpy.mockRestore();
      infoSpy.mockRestore();
      vtSpy.mockRestore();
      agreementsSpy.mockRestore();
      sessionStorage.clear();
    });

    test('should NOT call getCustomerByMtn when customerType is N (new customer)', async () => {
      const mockGetCustomerByMtn = jest.fn();
      const apiHook = require('../../modules/services/APIService/APIServiceCallHook');
      const mtnSpy = jest
        .spyOn(apiHook, 'useLazyGetCustomerByMtnQuery')
        .mockReturnValue([
          mockGetCustomerByMtn,
          {
            status: 'pending',
            isUninitialized: true,
            isLoading: false,
            isSuccess: false,
            isError: false,
            isFetching: false,
            data: null,
          },
        ]);

      const infoSpy = jest
        .spyOn(InfoApiCallHook, 'default')
        .mockImplementation(() => ({ 
          getActiveMTNRequest: jest.fn(), 
          getActiveMTNResponse: { data: {} }, 
          updateVisionRemark: jest.fn() 
        }));

      const vtSpy = jest
        .spyOn(ViewTogetherApiCallHook, 'default')
        .mockImplementation(() => ({
          requestBodyGenerateInspicioId: jest.fn(),
          requestBodySendMessage: jest.fn(),
          requestBodySendLovLink: jest.fn(),
          requestBodySendEmail: jest.fn(),
          requestBodyGeneratePaxQRCode: jest.fn(),
          getResultGenerateInspicioId: { data: {} },
          getResultSendMessage: { data: {} },
          getResultSendLovLink: { data: {} },
          getResultSendEmail: { data: {} },
        }));

      const agreementsSpy = jest
        .spyOn(require('../../modules/services/APIService/AgreementsAPICallHook'), 'default')
        .mockImplementation(() => ({ getOrderWrite: jest.fn() }));

      // Set customerType to 'N' (new customer)
      sessionStorage.setItem('customerType', 'N');
      sessionStorage.setItem('tagActiveMTN', '1234567890');

      const { getByTestId } = render(
        <BrowserRouter>
          <StoreProvider>
            <ViewTogether
              showAccordion
              {...inStorePickupProps}
              handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
              onChangeSubReason={mockOnChangeSubReason}
              onChangeRadio={mockOnChangeRadio}
              setReceivedLovPollResponse={setReceivedLovPollResponse}
              customerProfile={{ data: { customer: { lookupMtn: '1234567890' } } }}
              getCartResponse={{ orderDetails: {}, cartHeader: {} }}
            />
          </StoreProvider>
        </BrowserRouter>
      );

      expect(getByTestId('view-together-accordion')).toBeInTheDocument();

      await waitFor(() => {
        expect(mockGetCustomerByMtn).not.toHaveBeenCalled();
      });

      mtnSpy.mockRestore();
      infoSpy.mockRestore();
      vtSpy.mockRestore();
      agreementsSpy.mockRestore();
      sessionStorage.clear();
    });

    test('should NOT call getCustomerByMtn when lookUpMTN is not set', async () => {
      const mockGetCustomerByMtn = jest.fn();
      const apiHook = require('../../modules/services/APIService/APIServiceCallHook');
      const mtnSpy = jest
        .spyOn(apiHook, 'useLazyGetCustomerByMtnQuery')
        .mockReturnValue([
          mockGetCustomerByMtn,
          {
            status: 'pending',
            isUninitialized: true,
            isLoading: false,
            isSuccess: false,
            isError: false,
            isFetching: false,
            data: null,
          },
        ]);

      const infoSpy = jest
        .spyOn(InfoApiCallHook, 'default')
        .mockImplementation(() => ({ 
          getActiveMTNRequest: jest.fn(), 
          getActiveMTNResponse: { data: {} }, 
          updateVisionRemark: jest.fn() 
        }));

      const vtSpy = jest
        .spyOn(ViewTogetherApiCallHook, 'default')
        .mockImplementation(() => ({
          requestBodyGenerateInspicioId: jest.fn(),
          requestBodySendMessage: jest.fn(),
          requestBodySendLovLink: jest.fn(),
          requestBodySendEmail: jest.fn(),
          requestBodyGeneratePaxQRCode: jest.fn(),
          getResultGenerateInspicioId: { data: {} },
          getResultSendMessage: { data: {} },
          getResultSendLovLink: { data: {} },
          getResultSendEmail: { data: {} },
        }));

      const agreementsSpy = jest
        .spyOn(require('../../modules/services/APIService/AgreementsAPICallHook'), 'default')
        .mockImplementation(() => ({ getOrderWrite: jest.fn() }));

      // No lookUpMTN set
      sessionStorage.setItem('customerType', 'E');
      sessionStorage.removeItem('tagActiveMTN');

      const { getByTestId } = render(
        <BrowserRouter>
          <StoreProvider>
            <ViewTogether
              showAccordion
              {...inStorePickupProps}
              handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
              onChangeSubReason={mockOnChangeSubReason}
              onChangeRadio={mockOnChangeRadio}
              setReceivedLovPollResponse={setReceivedLovPollResponse}
              customerProfile={{ data: { customer: {} } }}
              getCartResponse={{ orderDetails: {}, cartHeader: {} }}
            />
          </StoreProvider>
        </BrowserRouter>
      );

      expect(getByTestId('view-together-accordion')).toBeInTheDocument();

      await waitFor(() => {
        expect(mockGetCustomerByMtn).not.toHaveBeenCalled();
      });

      mtnSpy.mockRestore();
      infoSpy.mockRestore();
      vtSpy.mockRestore();
      agreementsSpy.mockRestore();
      sessionStorage.clear();
    });

    test('should NOT call getCustomerByMtn when isPostToPrePay is true', async () => {
      const mockGetCustomerByMtn = jest.fn();
      const apiHook = require('../../modules/services/APIService/APIServiceCallHook');
      const mtnSpy = jest
        .spyOn(apiHook, 'useLazyGetCustomerByMtnQuery')
        .mockReturnValue([
          mockGetCustomerByMtn,
          {
            status: 'pending',
            isUninitialized: true,
            isLoading: false,
            isSuccess: false,
            isError: false,
            isFetching: false,
            data: null,
          },
        ]);

      const infoSpy = jest
        .spyOn(InfoApiCallHook, 'default')
        .mockImplementation(() => ({ 
          getActiveMTNRequest: jest.fn(), 
          getActiveMTNResponse: { data: {} }, 
          updateVisionRemark: jest.fn() 
        }));

      const vtSpy = jest
        .spyOn(ViewTogetherApiCallHook, 'default')
        .mockImplementation(() => ({
          requestBodyGenerateInspicioId: jest.fn(),
          requestBodySendMessage: jest.fn(),
          requestBodySendLovLink: jest.fn(),
          requestBodySendEmail: jest.fn(),
          requestBodyGeneratePaxQRCode: jest.fn(),
          getResultGenerateInspicioId: { data: {} },
          getResultSendMessage: { data: {} },
          getResultSendLovLink: { data: {} },
          getResultSendEmail: { data: {} },
        }));

      const agreementsSpy = jest
        .spyOn(require('../../modules/services/APIService/AgreementsAPICallHook'), 'default')
        .mockImplementation(() => ({ getOrderWrite: jest.fn() }));

      // Set post-to-pre indicator
      sessionStorage.setItem('customerType', 'E');
      sessionStorage.setItem('tagActiveMTN', '1234567890');
      sessionStorage.setItem('newPostToPreIndicator', 'true');

      const { getByTestId } = render(
        <BrowserRouter>
          <StoreProvider>
            <ViewTogether
              showAccordion
              {...inStorePickupProps}
              handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
              onChangeSubReason={mockOnChangeSubReason}
              onChangeRadio={mockOnChangeRadio}
              setReceivedLovPollResponse={setReceivedLovPollResponse}
              customerProfile={{ data: { customer: { lookupMtn: '1234567890' } } }}
              getCartResponse={{ orderDetails: {}, cartHeader: {} }}
            />
          </StoreProvider>
        </BrowserRouter>
      );

      expect(getByTestId('view-together-accordion')).toBeInTheDocument();

      await waitFor(() => {
        expect(mockGetCustomerByMtn).not.toHaveBeenCalled();
      });

      mtnSpy.mockRestore();
      infoSpy.mockRestore();
      vtSpy.mockRestore();
      agreementsSpy.mockRestore();
      sessionStorage.clear();
    });
  });

  // Test cases for customerByMtnEmail useEffect filtering (lines 289-292)
  describe('customerByMtnEmail filtering useEffect coverage', () => {
    const setupSpies = (mtnQueryReturnValue) => {
      const apiHook = require('../../modules/services/APIService/APIServiceCallHook');
      const mtnSpy = jest
        .spyOn(apiHook, 'useLazyGetCustomerByMtnQuery')
        .mockReturnValue(mtnQueryReturnValue);

      const infoSpy = jest
        .spyOn(InfoApiCallHook, 'default')
        .mockImplementation(() => ({
          getActiveMTNRequest: jest.fn(),
          getActiveMTNResponse: { data: {} },
          updateVisionRemark: jest.fn(),
        }));

      const vtSpy = jest
        .spyOn(ViewTogetherApiCallHook, 'default')
        .mockImplementation(() => ({
          requestBodyGenerateInspicioId: jest.fn(),
          requestBodySendMessage: jest.fn(),
          requestBodySendLovLink: jest.fn(),
          requestBodySendEmail: jest.fn(),
          requestBodyGeneratePaxQRCode: jest.fn(),
          getResultGenerateInspicioId: { data: {} },
          getResultSendMessage: { data: {} },
          getResultSendLovLink: { data: {} },
          getResultSendEmail: { data: {} },
        }));

      const agreementsSpy = jest
        .spyOn(require('../../modules/services/APIService/AgreementsAPICallHook'), 'default')
        .mockImplementation(() => ({ getOrderWrite: jest.fn() }));

      return { mtnSpy, infoSpy, vtSpy, agreementsSpy };
    };

    const cleanupSpies = ({ mtnSpy, infoSpy, vtSpy, agreementsSpy }) => {
      mtnSpy.mockRestore();
      infoSpy.mockRestore();
      vtSpy.mockRestore();
      agreementsSpy.mockRestore();
      sessionStorage.clear();
    };

    test('should filter out Email Address option when customerByMtnEmail is empty string', async () => {
      window.mfe = { scmCheckoutMfeEnable: true };
      sessionStorage.setItem('customerType', 'E');
      sessionStorage.setItem('tagActiveMTN', '1234567890');

      const spies = setupSpies([
        jest.fn(),
        {
          status: 'fulfilled',
          isUninitialized: false,
          isLoading: false,
          isSuccess: true,
          isError: false,
          isFetching: false,
          data: { customer: { email: '' } },
        },
      ]);

      const { getByTestId } = render(
        <BrowserRouter>
          <StoreProvider>
            <ViewTogether
              showAccordion
              {...inStorePickupProps}
              handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
              onChangeSubReason={mockOnChangeSubReason}
              onChangeRadio={mockOnChangeRadio}
              setReceivedLovPollResponse={setReceivedLovPollResponse}
              customerProfile={{ data: { customer: { lookupMtn: '1234567890' } } }}
              getCartResponse={{ orderDetails: {}, cartHeader: { fullAccountNumber: '123456' } }}
            />
          </StoreProvider>
        </BrowserRouter>
      );

      expect(getByTestId('view-together-accordion')).toBeInTheDocument();

      await waitFor(() => {
        expect(screen.queryByText('Email Address')).toBeNull();
      });

      cleanupSpies(spies);
    });

    test('should filter out Email Address option when customer object has no email property', async () => {
      window.mfe = { scmCheckoutMfeEnable: true };
      sessionStorage.setItem('customerType', 'E');
      sessionStorage.setItem('tagActiveMTN', '1234567890');

      const spies = setupSpies([
        jest.fn(),
        {
          status: 'fulfilled',
          isUninitialized: false,
          isLoading: false,
          isSuccess: true,
          isError: false,
          isFetching: false,
          data: { customer: {} },
        },
      ]);

      const { getByTestId } = render(
        <BrowserRouter>
          <StoreProvider>
            <ViewTogether
              showAccordion
              {...inStorePickupProps}
              handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
              onChangeSubReason={mockOnChangeSubReason}
              onChangeRadio={mockOnChangeRadio}
              setReceivedLovPollResponse={setReceivedLovPollResponse}
              customerProfile={{ data: { customer: { lookupMtn: '1234567890' } } }}
              getCartResponse={{ orderDetails: {}, cartHeader: { fullAccountNumber: '123456' } }}
            />
          </StoreProvider>
        </BrowserRouter>
      );

      expect(getByTestId('view-together-accordion')).toBeInTheDocument();

      await waitFor(() => {
        expect(screen.queryByText('Email Address')).toBeNull();
      });

      cleanupSpies(spies);
    });

    test('should keep Email Address option when customerByMtnEmail has a valid email', async () => {
      window.mfe = { scmCheckoutMfeEnable: true };
      sessionStorage.setItem('customerType', 'E');
      sessionStorage.setItem('tagActiveMTN', '1234567890');

      const spies = setupSpies([
        jest.fn(),
        {
          status: 'fulfilled',
          isUninitialized: false,
          isLoading: false,
          isSuccess: true,
          isError: false,
          isFetching: false,
          data: { customer: { email: 'user@vzw.com' } },
        },
      ]);

      const { getByTestId } = render(
        <BrowserRouter>
          <StoreProvider>
            <ViewTogether
              showAccordion
              {...inStorePickupProps}
              handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
              onChangeSubReason={mockOnChangeSubReason}
              onChangeRadio={mockOnChangeRadio}
              setReceivedLovPollResponse={setReceivedLovPollResponse}
              customerProfile={{ data: { customer: { lookupMtn: '1234567890' } } }}
              getCartResponse={{ orderDetails: {}, cartHeader: { fullAccountNumber: '123456' } }}
            />
          </StoreProvider>
        </BrowserRouter>
      );

      expect(getByTestId('view-together-accordion')).toBeInTheDocument();

      await waitFor(() => {
        expect(screen.queryByText('Email Address')).not.toBeNull();
      });

      cleanupSpies(spies);
    });

    test('should not filter Email Address option when getCustomerByMtnSuccess status is not fulfilled', async () => {
      window.mfe = { scmCheckoutMfeEnable: true };
      sessionStorage.setItem('customerType', 'E');
      sessionStorage.setItem('tagActiveMTN', '1234567890');

      const spies = setupSpies([
        jest.fn(),
        {
          status: 'pending',
          isUninitialized: false,
          isLoading: true,
          isSuccess: false,
          isError: false,
          isFetching: true,
          data: null,
        },
      ]);

      const { getByTestId } = render(
        <BrowserRouter>
          <StoreProvider>
            <ViewTogether
              showAccordion
              {...inStorePickupProps}
              handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
              onChangeSubReason={mockOnChangeSubReason}
              onChangeRadio={mockOnChangeRadio}
              setReceivedLovPollResponse={setReceivedLovPollResponse}
              customerProfile={{ data: { customer: { lookupMtn: '1234567890' } } }}
              getCartResponse={{ orderDetails: {}, cartHeader: { fullAccountNumber: '123456' } }}
            />
          </StoreProvider>
        </BrowserRouter>
      );

      expect(getByTestId('view-together-accordion')).toBeInTheDocument();

      await waitFor(() => {
        expect(screen.queryByText('Email Address')).not.toBeNull();
      });

      cleanupSpies(spies);
    });

    test('should not filter Email Address option when getCustomerByMtnSuccess has error status', async () => {
      window.mfe = { scmCheckoutMfeEnable: true };
      sessionStorage.setItem('customerType', 'E');
      sessionStorage.setItem('tagActiveMTN', '1234567890');

      const spies = setupSpies([
        jest.fn(),
        {
          status: 'rejected',
          isUninitialized: false,
          isLoading: false,
          isSuccess: false,
          isError: true,
          isFetching: false,
          data: null,
        },
      ]);

      const { getByTestId } = render(
        <BrowserRouter>
          <StoreProvider>
            <ViewTogether
              showAccordion
              {...inStorePickupProps}
              handleHideContinueShowViewTogether={mockhandleHideContinueShowViewTogether}
              onChangeSubReason={mockOnChangeSubReason}
              onChangeRadio={mockOnChangeRadio}
              setReceivedLovPollResponse={setReceivedLovPollResponse}
              customerProfile={{ data: { customer: { lookupMtn: '1234567890' } } }}
              getCartResponse={{ orderDetails: {}, cartHeader: { fullAccountNumber: '123456' } }}
            />
          </StoreProvider>
        </BrowserRouter>
      );

      expect(getByTestId('view-together-accordion')).toBeInTheDocument();

      await waitFor(() => {
        expect(screen.queryByText('Email Address')).not.toBeNull();
      });

      cleanupSpies(spies);
    });
  });
});
