import React from 'react';
import { render } from '@testing-library/react';
import AcssViewTogether from './AcssViewTogether';

jest.mock('./ViewTogether', () => () => <div>Mocked ViewTogether Component</div>);

describe('AcssViewTogether', () => {


  test('renders ViewTogether when showAccordion is true and passes cart data', () => {
    const handleToggleChange = jest.fn();
    const mockCart = { id: 'CART123' };
    render(
      <AcssViewTogether
        ViewTogetherProps={{
          
                          showAccordion:true,
                          openAccordian:true,
                          handleToggleChange:jest.fn(),
                          data: { data: { cart: mockCart } },
                          spanishSelected:false,
                          customerProfile: {},
                          handleShowViewTogether:jest.fn(),
                          onAccordianToggle:jest.fn(),
                          setShowSendMessageError:jest.fn(),
                          setSelectedReviewMode:jest.fn(),
                          setSelectedReason:jest.fn(),
                          subReasonSelected:'',
                          onChangeSubReason:jest.fn(),
                          selectedRadio:'',
                          autoSelectRC:false,
                          onChangeRadio:jest.fn(),
                          handleHideContinueShowViewTogether:jest.fn(),
                          orderReviewResponse: {},
                          fetchPriceSnapshot:jest.fn(),
                          setReceivedLovPollResponse:jest.fn(),
                          exitLovData: {}
        }}
      />,
    );
  });

  
});
