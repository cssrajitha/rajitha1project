/* eslint-disable no-nested-ternary */

import { has } from 'lodash';

const scmCheckoutMfeEnabled = window?.mfe?.scmCheckoutMfeEnable;

export const isDFOOrderCheck = (cart) =>
  cart?.orderDetails?.accessoryFinancingOfferInfo?.splitPaymentInfo?.filter((data) => data?.isDfo).length > 0;

const getAdditionalIndicatorForVT = (vtPerksStatus) => {
  let additionalIndicator = '';
  if (vtPerksStatus !== '') {
    additionalIndicator = vtPerksStatus;
  }
  if (
    sessionStorage.getItem('channel')?.includes('OMNI-RETAIL') &&
    /true/i.test(sessionStorage.getItem('VZEClickToCall')) &&
    /true/i.test(sessionStorage.getItem('isFromVZEngage'))
  ) {
    additionalIndicator += 'VZEngage';
  }
  return additionalIndicator;
};

const getPlanDetailsVT = (fpsLineLevelResponse) => {
  const linePlanDetails = [];
  try {
    fpsLineLevelResponse?.lines?.forEach((psLine) => {
      const planItem = psLine?.selectedPlan || psLine?.existingPlan || {};
      linePlanDetails.push({
        mtn: psLine?.mtn,
        planDetails: {
          planId: planItem?.planId,
          displayName: planItem?.displayName,
          planPrice: planItem?.price?.discountedPrice,
          planCategoryCd: planItem?.planCategoryCd,
        },
      });
    });
  } catch (error) {
    console.log('error occured during buiding lineLevelPromotions node');
  }
  return linePlanDetails;
};

const getDiscountsAndPromotions = (fpsLineLevelResponse) => {
  const lineLevelPromotions = [];
  try {
    fpsLineLevelResponse?.lines?.forEach((psLine) => {
      const linePromotions =
        (psLine &&
          psLine.addons &&
          psLine.addons.length &&
          psLine.addons.filter(
            (addon) => addon && addon.isDisplayable && (addon.isPromoDiscount || addon.isPlanDiscount),
          )) ||
        [];
      const uniqueLinePromo =
        linePromotions?.length > 0 &&
        linePromotions?.filter((value, index, self) => self.findIndex((v) => v.sorId === value.sorId) === index);
      lineLevelPromotions.push({ mtn: psLine?.mtn, promotions: uniqueLinePromo });
    });
  } catch (error) {
    console.log('error occured during buiding lineLevelPromotions node');
  }
  return lineLevelPromotions;
};

const getSharedDiscountsAndPromotions = (pricingSnapshotResponse) => {
  let genAddOns = [];
  let discountedAddOns = [];
  try {
    const discountedFeatures =
      pricingSnapshotResponse?.shared?.addons &&
      pricingSnapshotResponse.shared.addons
        .filter(({ isDisplayable, actionIndicator }) => isDisplayable && actionIndicator !== 'D')
        .map(
          ({
            sorId: visFeatureCode,
            skuName: featureDesc,
            price: { regularPrice, discountedPrice },
            isPromoDiscount,
            isGeneralAddon,
            isSubscription,
          }) => ({
            visFeatureCode,
            featureDesc,
            featurePrice: discountedPrice < regularPrice ? discountedPrice : regularPrice,
            discountedPrice,
            regularPrice,
            isPromoDiscount,
            isGeneralAddon,
            isSubscription,
          }),
        );
    genAddOns = discountedFeatures?.filter((features) => features.isGeneralAddon);
    discountedAddOns = discountedFeatures?.filter((features) => !features.isGeneralAddon);
  } catch (error) {
    console.log('error occured during buiding lineLevelPromotions node');
  }
  return {
    genAddOns,
    discountedAddOns,
  };
};

export const reqSendMessage = (
  getCartResponse,
  getNextBillSummaryRes,
  customerProfile,
  getResultSendLovLink,
  getResultSendMessage,
  orderReviewResponse,
  getResultGenerateInspicioId,
  fetchPriceSnapshot,
  customerType,
  lookUpMTN,
  unifiedNbsData,
) => ({
  event: 'pageNavigation',
  clientId: getResultGenerateInspicioId?.data?.sendInspicioToken || sessionStorage.getItem('sendInspicioToken') || '',
  cluster: getResultSendMessage?.data?.cluster || sessionStorage.getItem('vtCluster') || '',
  payload: {
    isDFONewVVCCard: !!(
      /true/i.test(sessionStorage.getItem('isVVCAplicationCreated')) && isDFOOrderCheck(getCartResponse)
    ),
    pegaTransactionType: '',
    pageName: 'orderReview',
    mlmoPC: false,
    isNSA: 'Y',
    lovCaseId: getResultSendLovLink?.data?.serviceBody?.serviceResponse?.context?.caseId || '',
    currentMonthlyBill: fetchPriceSnapshot?.subAccounts?.[0]?.totals?.grandTotalDueMonthly?.currentTotal
      ? fetchPriceSnapshot?.subAccounts?.[0]?.totals?.grandTotalDueMonthly?.currentTotal
      : 0,
    channel: getCartResponse?.cartHeader?.cartCreatorChannelId,
    cartData: getCartResponse,
    nbsData: getNextBillSummaryRes?.data,
    cartId: customerProfile?.data?.customer?.cartId || '',
    isAutoPayEnrolled: getCartResponse?.customerProfile?.billAccounts?.[0]?.paymentInfo?.isAutoPayEnrolled || false,
    afoFlag:
      getCartResponse?.orderDetails?.accessoryFinancingOfferInfo?.customerEligible &&
      getCartResponse?.orderDetails?.accessoryFinancingOfferInfo?.offerAccepted
        ? 'Y'
        : 'N',
    costcoFlow: false,
    vtflow: 'Y',
    loggedInUser: customerProfile?.data?.customer?.loggedInUser ? customerProfile?.data?.customer?.loggedInUser : '',
    repUserId: customerProfile?.data?.customer?.loggedInUser ? customerProfile?.data?.customer?.loggedInUser : '',
    accountHashCode: customerProfile?.data?.customer?.customerHash || '',
    mtnHashCode:
      customerProfile?.data?.customer?.billAccounts?.[0]?.mtns?.find((line) => line?.mtn === lookUpMTN)?.mtnHashCode ||
      '',
    agentRole: sessionStorage.getItem('leadsUserRole') ? sessionStorage.getItem('leadsUserRole') : '',
    additionalIndicator:
      getAdditionalIndicatorForVT(
        orderReviewResponse?.data?.lovData?.vtPerksStatus || getResultGenerateInspicioId?.data?.vtPerksStatus,
      ) || '',
    csFlag:
      sessionStorage.getItem('assistedFlags') &&
      sessionStorage.getItem('assistedFlags')?.isContentsquareEnabled === 'TRUE'
        ? 'true'
        : 'false',
    customerRole: customerProfile?.data?.customer?.billAccounts?.[0]?.mtns?.find((line) => line?.mtn === lookUpMTN)
      ?.mobileInfoAttributes?.accountOwner,
    customerType: customerProfile?.data?.customer?.customerAttributes?.customerType
      ? customerProfile?.data?.customer?.customerAttributes?.customerType
      : customerType || getCartResponse?.orderDetails?.customerType || '',
    newCustomerMtn: lookUpMTN || '',
    encryptedCartId: getResultGenerateInspicioId?.data?.encryptedCartId || '',
    isMultiLineRisaEnabled: JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.isMultiLineRisaEnabled === 'TRUE',
    numberOfLines: sessionStorage.getItem('numberOfLines') ? sessionStorage.getItem('numberOfLines') : '',
    tenure: sessionStorage.getItem('tenure') ? sessionStorage.getItem('tenure') : '',
    linePlanDetails: getPlanDetailsVT(fetchPriceSnapshot?.subAccounts?.[0]),
    lineLevelPromotions: getDiscountsAndPromotions(fetchPriceSnapshot?.subAccounts?.[0]),
    sharedPromotions: getSharedDiscountsAndPromotions(fetchPriceSnapshot?.subAccounts?.[0]),
    displayProfSetupCharges:
      /true/i.test(sessionStorage.getItem('assistedFlags')?.displayProfSetupCharges) ||
      sessionStorage.getItem('assistedFlags')?.isContentsquareEnabled === 'TRUE',
    lineLevelPlanChangeMessages: [],
    giftPurchaseChecked: false,
    showNseNextBillSummary: false,
    subAccountsInfo: customerProfile?.data?.customer?.subAccounts ? customerProfile?.data?.customer?.subAccounts : '',
    unifiedNbsData:
      JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.enableFullBlownMfeNbsPosFFlag === 'TRUE'
        ? unifiedNbsData?.data
        : '',
    promoEndingMtns:
      JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.promoLostDisplayFFlag === 'TRUE' &&
      sessionStorage.getItem('promoEndingMtns') &&
      sessionStorage.getItem('promoEndingMtns') !== 'undefined' &&
      sessionStorage.getItem('promoEndingMtns') !== 'null'
        ? JSON.parse(sessionStorage.getItem('promoEndingMtns'))
        : [],
  },
});

export const reqGenerateInspicioId = (getCartResponse, customerProfile, isMultiLineRisaFFlagEnabled) => ({
  clientName: '',
  lov: true,
  offsetMin: '50',
  delay: true,
  orderNumber: getCartResponse?.orderDetails?.orderList?.[0]?.orderNumber,
  orderLocationNum: getCartResponse?.orderDetails?.locationCode,
  amount: getCartResponse?.orderDetails?.totalDueToday,
  creditAppNum: getCartResponse?.orderDetails?.orderList?.[0]?.creditApplication?.creditApplicationNum,
  cartId: isMultiLineRisaFFlagEnabled === 'TRUE' ? customerProfile?.data?.customer?.cartId : '',
});

export const reqSendLovLink = (customerProfile, getCartResponse, spanishSelected, pegaTransactionType) => ({
  accountNumber: customerProfile?.data?.customer?.accountNo,
  cartCreator: getCartResponse?.cartHeader?.cartCreator,
  caseId: customerProfile?.data?.customer?.caseId,
  cartId: scmCheckoutMfeEnabled ? sessionStorage.getItem('acssMfeCartId') : customerProfile?.data?.customer?.cartId,
  CustomerId: customerProfile?.data?.customer?.accountNo,
  firstName: getCartResponse?.lineDetails?.lineInfo[0]?.serviceInfo?.primaryUserInfo?.firstName,
  ECPDId: getCartResponse?.ecpdProfile?.profileId || '',
  header: {
    correlationId: '',
  },
  smsIndicator: 'N',
  smsMtn: '',
  emailIndicator: 'N',
  emailAddress: '',
  otherIndicator: 'N',
  reason: '',
  lovEligible: 'Y',
  creditAppNum: getCartResponse?.orderDetails?.orderList?.[0]?.creditApplication?.creditApplicationNum,
  orderNumber: getCartResponse?.orderDetails?.orderList?.[0]?.orderNumber,
  locationCode: getCartResponse?.orderDetails?.locationCode,
  repId: getCartResponse?.cartHeader?.cartCreatorSalesRepId,
  languageIndicator: 'E',
  billCycleDate: getCartResponse?.orderDetails?.effectiveDateDetails?.nextBillCycleBeginDate,
  paymentMethod: '',
  transactionType: pegaTransactionType?.toString() || '',
  callId: '',
  emailId: getCartResponse?.orderDetails?.spocs?.notificationOptions?.primaryEmailId,
  lovCaseId: '',
  qrCodeIndicator: 'Y',
  urlPasskeyIndicator: 'N',
  spanishIndicator: spanishSelected ? 'Y' : 'N',
  registeredUser: 'N',
  viewTogetherEnabled: 'Y',
  byodFlow: '',
  copyUrlIndicator: 'N',
  consentAccepted: false,
  nonVzwMTN: false,
  mvaUrlIndicator: 'Y',
  inspicioCluster: '',
  additionalUrlParams: '',
  scmVTFlow: scmCheckoutMfeEnabled ? 'Y' : 'N',
});

export const reqSendEmail = (getCartResponse, spanishSelected, customerProfile, getResultSendMessage) => ({
  data: {
    pageName: 'lovOrderReview',
    cluster: getResultSendMessage?.data?.cluster || '',
    channel: getCartResponse?.cartHeader?.sourceSystem,
    tradeIn: 'N',
    cartId: getCartResponse?.cartHeader?.cartId || customerProfile?.data?.customer?.cartId,
    caseId: getCartResponse?.cartHeader?.caseId || customerProfile?.data?.customer?.caseId,
    qrCode: true,
    lov: true,
    spanishIndicator: spanishSelected,
    additionalUrlParams: '',
    mvaUrl: '',
    inspicioToken: '',
  },
  meta: {
    client: 'POSMOBILE',
    clientCorrrelationId:
      'ick-ClrSuZPeM-UmBI-2SFB6t1zB_dFDy3IfCcConCuwmPSIXyrD!1375284084!obsneocgzap08!5106!-1!1564408961747',
    timestamp: '2019-07-29T10:25:59.791-04:00',
    user: 'c0huska',
  },
});
export const isPreOrBackOrder = (cartData) => {
  let isPOBOOrder = false;
  if (cartData && cartData?.lineDetails && cartData?.lineDetails?.lineInfo) {
    const lineInfo = cartData?.lineDetails?.lineInfo || [];
    lineInfo.forEach((line) => {
      /* istanbul ignore next */
      if (!isPOBOOrder) {
        isPOBOOrder = !!(
          has(line, 'itemsInfo[0].cartItems.cartItem') &&
          line?.itemsInfo[0]?.cartItems?.cartItem?.find(
            (item) => item?.inventory && (item?.inventory?.isPreOrder || item?.inventory?.isBackorder),
          )
        );
      }
    });
  }
  return isPOBOOrder;
};

export const reqGeneratePaxQRCode = (getCartResponse, customerProfile) => {
  let doPreAuth = false;

  if (isPreOrBackOrder(getCartResponse)) {
    doPreAuth = isPreOrBackOrder(getCartResponse);
  } else if (isDFOOrderCheck(getCartResponse)) {
    doPreAuth = true;
  }
  return {
    orderNumber: getCartResponse?.orderDetails?.orderList?.[0]?.orderNumber,
    cartId: customerProfile?.data?.customer?.cartId || sessionStorage.getItem('cartId'),
    paymentAmount: getCartResponse?.orderDetails?.totalDueToday,
    machineName: sessionStorage.getItem('machineName') ? sessionStorage.getItem('machineName') : '',
    locationCode: getCartResponse?.orderDetails?.locationCode,
    loggedInUser: customerProfile?.data?.customer?.loggedInUser,
    accountNumber: getCartResponse?.cartHeader?.fullAccountNumber,
    context: 'order',
    doPreAuth,
    cartType: 'NSA_Order',
  };
};
