import React from 'react';
import PropTypes from 'prop-types';
import ViewTogether from './ViewTogether';

const AcssViewTogether = ({ViewTogetherProps}) => {
    const {
        showAccordion, 
        openAccordian, 
        handleToggleChange, 
        data, 
        spanishSelected, 
        customerProfile, 
        handleShowViewTogether, 
        onAccordianToggle, 
        setShowSendMessageError,
        setSelectedReviewMode,
        setSelectedReason,
        subReasonSelected,
        onChangeSubReason,
        selectedRadio,
        autoSelectRC,
        onChangeRadio,
        handleHideContinueShowViewTogether,
        orderReviewResponse,
        fetchPriceSnapshot,
        setReceivedLovPollResponse,
        exitLovData
    } = ViewTogetherProps;
    return (
        <div>
             {showAccordion && (
                        <ViewTogether
                          showAccordion={showAccordion}
                          openAccordian={openAccordian}
                          handleToggleChange={handleToggleChange}
                                getCartResponse={data?.data?.cart}
                          spanishSelected={spanishSelected}
                          customerProfile={customerProfile}
                          handleShowViewTogether={handleShowViewTogether}
                          onAccordianToggle={onAccordianToggle}
                          setShowSendMessageError={setShowSendMessageError}
                          setSelectedReviewMode={setSelectedReviewMode}
                          setSelectedReason={setSelectedReason}
                          subReasonSelected={subReasonSelected}
                          onChangeSubReason={onChangeSubReason}
                          selectedRadio={selectedRadio}
                          autoSelectRC={autoSelectRC}
                          onChangeRadio={onChangeRadio}
                          handleHideContinueShowViewTogether={handleHideContinueShowViewTogether}
                          orderReviewResponse={orderReviewResponse}
                          fetchPriceSnapshot={fetchPriceSnapshot}
                          setReceivedLovPollResponse={setReceivedLovPollResponse}
                          exitLovData={exitLovData}
                        />
                      )}
        </div>
    );
};

AcssViewTogether.propTypes = {
  ViewTogetherProps: PropTypes.shape({
    showAccordion: PropTypes.bool,
    openAccordian: PropTypes.bool,
    handleToggleChange: PropTypes.func,
    data: PropTypes.object,
    spanishSelected: PropTypes.bool,
    customerProfile: PropTypes.object,
    handleShowViewTogether: PropTypes.func,
    onAccordianToggle: PropTypes.func,
    setShowSendMessageError: PropTypes.func,
    setSelectedReviewMode: PropTypes.func,
    setSelectedReason: PropTypes.func,
    subReasonSelected: PropTypes.string,
    onChangeSubReason: PropTypes.func,
    selectedRadio: PropTypes.string,
    autoSelectRC: PropTypes.bool,
    onChangeRadio: PropTypes.func,
    handleHideContinueShowViewTogether: PropTypes.func,
    orderReviewResponse: PropTypes.object,
    fetchPriceSnapshot: PropTypes.func,
    setReceivedLovPollResponse: PropTypes.func,
    exitLovData: PropTypes.object,
  }),
};



export default AcssViewTogether;