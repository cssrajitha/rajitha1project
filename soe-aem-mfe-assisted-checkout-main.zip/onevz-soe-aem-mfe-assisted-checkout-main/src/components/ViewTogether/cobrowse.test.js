import Emitter from 'onevzsoemfeframework/Emitter';
import { handleLongPolling } from "./cobrowse";

jest.mock('onevzsoemfecommon/Helpers', () => ({
  ...jest.requireActual('onevzsoemfecommon/Helpers'),
  isFunctionalityEnabled: (flag, atribute) =>{
    if(flag === 'scmCommonDefectFixFFlag' && atribute === 'scmLongPollUpdateUrlEnabled'){
      return true;
    }   
    return false
  },
}));

// Emitter.emit = mockEmit;
jest.mock('onevzsoemfeframework/Emitter');
jest.setTimeout(6000);
describe('handleLongPolling', () => {
    beforeEach(()=>{
       global.fetch= jest.fn();
       jest.clearAllMocks();
    });
    test('should stop polling when maxerror is zero',async() =>{
        const result = await handleLongPolling('client123',true,0,1000);
        expect(result).toBeUndefined();
        expect(fetch).not.toHaveBeenCalled();
    })

    test('should emit event on successful response', async ()=>{
        const emitspy =jest.spyOn(Emitter, 'emit').mockImplementation(() =>{});
        fetch.mockResolvedValueOnce({
            status:200,
            json:async ()=>({status:'success',event:'TEST_EVENT',payload:{message:'Hello'}}),
        });
        await handleLongPolling('client123',true,5,1000);

        expect(emitspy).toHaveBeenLastCalledWith('VT_RECEIVE_EVENT',{
            event:'TEST_EVENT',
            payload:{message:'Hello'},
        });
        emitspy.mockRestore();
    });

    test('should retry on "error status', async ()=>{
        fetch.mockResolvedValueOnce({
            status:200,
            json:async ()=>({status:'error'}),
        });
        const spy = jest.spyOn(global,'setTimeout');

        await handleLongPolling('client123',true,1,10);
        expect(fetch).toHaveBeenCalledTimes(1);
        spy.mockRestore();
    });
    test('should retry on "error status', async ()=>{
        fetch.mockResolvedValueOnce({
            status:200,
            json:async ()=>({status:'timeout'}),
        });
        const spy = jest.spyOn(global,'setTimeout');

        await handleLongPolling('client123',true,1,10);
        expect(fetch).toHaveBeenCalledTimes(1);
        spy.mockRestore();
    });
    

    test('should stop polling if sessionstorage stoppollfromsession s "true', async()=>{
        jest.spyOn(window.sessionStorage.__proto__,'getItem').mockReturnValue(true);

        fetch.mockResolvedValueOnce({
            status:200,
            json: async () => ({status: 'success', event: 'STOP_EVENT',payload: {} }),
        });
        await handleLongPolling('client123',false,5,1000);
        expect(fetch).toHaveBeenCalledTimes(1)
    });
    test('should stop polling if sessionstorage stoppollfromsession s "true', async()=>{
        // jest.spyOn(window.sessionStorage.__proto__,'getItem').mockReturnValue(true);
        sessionStorage.setItem('stopPollFromSession ', 'false')

        fetch.mockResolvedValueOnce({
            status:200,
            json: async () => ({status: 'success', event: 'STOP_EVENT',payload: {} }),
        });
        await handleLongPolling('client123',false,5,1000);
        expect(fetch).toHaveBeenCalledTimes(1)
    });
    test('should retry polling on fetch failure (catchblock)', async ()=>{
        fetch.mockRejectedValueOnce(new Error('Network error'));

        await handleLongPolling('clientFail',false,2,100);
        expect(fetch).toHaveBeenCalledTimes(2);
    });

    test('should retry polling on fetch failure (catchblock) with default value', async ()=>{
        fetch.mockRejectedValueOnce(new Error('Network error'));
        await handleLongPolling('clientFail');
        expect(fetch).toHaveBeenCalledTimes(15);
    });

     test('should call with updated URL when flag is on - scmLongPollUpdateUrlEnabled', async ()=>{
        await handleLongPolling('clientID');
    });
} )