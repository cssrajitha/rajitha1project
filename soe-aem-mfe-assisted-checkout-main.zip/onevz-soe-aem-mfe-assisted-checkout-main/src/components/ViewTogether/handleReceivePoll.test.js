import Emitter from 'onevzsoemfeframework/Emitter';
import { isFunctionalityEnabled } from 'onevzsoemfecommon/Helpers';
import handleReceivePoll, {
  extractEnv,
  handleLogCustomerUrl,
  handleContinue,
  handleOrderWriteSuccessMsg,
  handleOrderWriteErrorMsg,
} from './handleReceivePoll';

jest.mock('onevzsoemfecommon/Helpers', () => ({
  ...jest.requireActual('onevzsoemfecommon/APIService'),
  isFunctionalityEnabled: jest.fn(),
}));

describe('handleReceivePoll', () => {
  const mockRequestSendLovLink = jest.fn();
  const mockData = {
    requestBodySendLovLink: mockRequestSendLovLink,
    getResultSendLovLink: {
      data: {
        serviceBody: { serviceResponse: { context: { caseId: 'test' } } },
      },
    },
    requestBodyGenerateInspicioId: jest.fn(),
    requestBodySendMessage: jest.fn(),
    requestBodySendEmail: jest.fn(),
    getResultSendEmail: { data: {} },
    requestBodyGeneratePaxQRCode: jest.fn(),
    getResultGenerateInspicioId: { data: {} },
    getResultSendMessage: { data: {} },
  };

  const mockEventDataUpdate = {
    detail: {
      event: 'updateTncParams',
      payload: { some: 'data' },
    },
  };

  const mockEventDataVTrefresh = {
    detail: {
      event: 'vtRefreshPayment',
      payload: { some: 'data' },
    },
  };

  const mockEventDataResender = {
    detail: {
      event: 'resendor',
      payload: { some: 'data' },
    },
  };

  const mockEventDataLovResend = {
    detail: {
      event: 'lovresendblankpage',
      payload: { some: 'data' },
    },
  };

  const mockEventDataOpenRepEmulator = {
    detail: {
      event: 'openRepEmulator',
      payload: { some: 'data' },
    },
  };

  const mockEventDataSubmit = {
    detail: {
      event: 'submit',
      payload: { pageName: 'orderReview' },
    },
  };

  const mockGetCartResponse = {
    cartHeader: {
      cartCreator: 'creator',
      caseId: 'caseId',
    },
    orderDetails: {
      customerType: 'N',
      spocs: { notificationOptions: { primaryEmailId: 'email@domain.com' } },
      orderList: [{ creditApplication: { creditApplicationNum: '12345' } }],
    },
    lineDetails: {
      lineInfo: [
        {
          primaryUserInfo: { emailId: 'lineEmail@domain.com' },
          lineActivityType: 'EUPBYOD',
        },
      ],
      tradeInDetail: { tradeInItems: [{ id: 'tradeInItem' }] },
    },
    quote: { quoteId: 'quoteId' },
  };

  const mockCustomerProfile = {
    data: {
      customer: { cartId: 'cartId', accountNo: 'accountNo', regNo: '51' },
    },
  };

  const mockLanding = {
    quoteDetails: [{ cartId: 'cartId', quoteId: 'quoteId' }],
  };

  const updatedEmail = 'updatedEmail@domain.com';
  const paperLessBilling = 'Y';

  beforeEach(() => {
    jest.clearAllMocks();
    sessionStorage.setItem(
      'responseList',
      JSON.stringify([
        {
          dispositionOptionId: '18',
          rank: 'rank',
          propositionId: 'propId',
          soiEngagementId: 'soiId',
          offerContainerId: 'offerId',
        },
      ]),
    );
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ isMitekSimSwapEnabled: 'TRUE',cpcChargebackFFlag:'TRUE' }));
    sessionStorage.setItem('locationData', JSON.stringify({ city: 'city', state: 'state' }));
    sessionStorage.setItem(
      'geoFenceResponse',
      JSON.stringify({ geoFenceCheck: 'false', ipadLatitude: '12.34', ipadLongitude: '56.78', reason: 'Out of range' }),
    );
  });

  it('should handle updateTncParams event', async () => {
    const mockGetOrderWrite = jest.fn();
    await handleReceivePoll({
      eventData: mockEventDataUpdate,
      getCartResponse: mockGetCartResponse,
      customerProfile: mockCustomerProfile,
      landing: mockLanding,
      updatedEmail,
      paperLessBilling,
      getOrderWrite: mockGetOrderWrite,
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
    });
  });

  it('should handle vtRefreshPayment event', async () => {
    const mockGetOrderWrite = jest.fn();
    Emitter.emit('vtRefreshPayment_event', 'test');
    await handleReceivePoll({
      eventData: mockEventDataVTrefresh,
      getCartResponse: mockGetCartResponse,
      customerProfile: mockCustomerProfile,
      landing: mockLanding,
      updatedEmail,
      paperLessBilling,
      getOrderWrite: mockGetOrderWrite,
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
    });
  });

  it('should handle resendor event', async () => {
    const mockGetOrderWrite = jest.fn();
    await handleReceivePoll({
      eventData: mockEventDataResender,
      getCartResponse: mockGetCartResponse,
      customerProfile: mockCustomerProfile,
      landing: mockLanding,
      updatedEmail,
      paperLessBilling,
      getOrderWrite: mockGetOrderWrite,
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
    });
  });

  it('should handle lovresendblankpage event', async () => {
    const mockGetOrderWrite = jest.fn();
    await handleReceivePoll({
      eventData: mockEventDataLovResend,
      getCartResponse: mockGetCartResponse,
      customerProfile: mockCustomerProfile,
      landing: mockLanding,
      updatedEmail,
      paperLessBilling,
      getOrderWrite: mockGetOrderWrite,
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
    });
  });

  it('should handle openRepEmulator event', async () => {
    const mockGetOrderWrite = jest.fn();
    await handleReceivePoll({
      eventData: mockEventDataOpenRepEmulator,
      getCartResponse: mockGetCartResponse,
      customerProfile: mockCustomerProfile,
      setEmulatorlaunch: jest.fn(),
      landing: mockLanding,
      updatedEmail,
      paperLessBilling,
      getOrderWrite: mockGetOrderWrite,
      requestBodySendMessage: mockData.requestBodySendMessage,
      spanishSelected: true,
      getResultGenerateInspicioId: {},
      getResultSendMessage: {},
      getResultSendLovLink: {},
    });
  });

  it('should handle submit event with orderReview value and submit to Agreements API', async () => {
    const mockGetOrderWrite = jest.fn();
    await handleReceivePoll({
      eventData: mockEventDataSubmit,
      getCartResponse: mockGetCartResponse,
      customerProfile: mockCustomerProfile,
      landing: mockLanding,
      updatedEmail,
      paperLessBilling,
      getOrderWrite: mockGetOrderWrite,
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
    });

    expect(mockGetOrderWrite).toHaveBeenCalledTimes(1);

    expect(window.location.href).toBe('http://localhost/');
  });

  it('should handle submit event with orderReview value and submit to Agreements API added custom Profile override', async () => {
    const mockGetOrderWrite = jest.fn();
    const newmockCustomerProfile = {
      data: {
        customer: { cartId: null, accountNo: null, regNo: null },
      },
    };

    await handleReceivePoll({
      eventData: mockEventDataSubmit,
      getCartResponse: mockGetCartResponse,
      customerProfile: newmockCustomerProfile,
      landing: mockLanding,
      updatedEmail,
      paperLessBilling,
      getOrderWrite: mockGetOrderWrite,
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
    });

    expect(mockGetOrderWrite).toHaveBeenCalledTimes(1);

    expect(window.location.href).toBe('http://localhost/');
  });

  it('should handle submit event with orderReview pageName', async () => {
    const mockGetOrderWrite = jest.fn();
    const mockEventDataSubmitPageName = {
      detail: {
        event: 'submit',
        payload: { pageName: 'orderReview' },
      },
    };

    await handleReceivePoll({
      eventData: mockEventDataSubmitPageName,
      getCartResponse: mockGetCartResponse,
      customerProfile: mockCustomerProfile,
      landing: mockLanding,
      updatedEmail,
      paperLessBilling,
      getOrderWrite: mockGetOrderWrite.mockResolvedValue({
        data: {},
      }),
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
    });

    expect(window.location.href).toBe('http://localhost/');
  });

  it('should set serviceWriteRequired to false when email is empty', async () => {
    const mockGetOrderWrite = jest.fn();

    const mockGetCartResponseEmptyEmail = {
      ...mockGetCartResponse,
      orderDetails: {
        ...mockGetCartResponse.orderDetails,
        spocs: { notificationOptions: { primaryEmailId: '' } },
      },
    };

    await handleReceivePoll({
      eventData: mockEventDataSubmit,
      getCartResponse: mockGetCartResponseEmptyEmail,
      customerProfile: mockCustomerProfile,
      landing: mockLanding,
      updatedEmail,
      paperLessBilling,
      getOrderWrite: mockGetOrderWrite,
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
    });

    expect(mockGetOrderWrite).toHaveBeenCalledTimes(1);
  });

  it('should set quoteId was empty to false when email is empty', async () => {
    const mockGetOrderWrite = jest.fn();

    const mockGetCartResponseEmptyEmail = {
      ...mockGetCartResponse,
      orderDetails: {
        ...mockGetCartResponse.orderDetails,
        spocs: { notificationOptions: { primaryEmailId: '' } },
      },
      quote: { quoteId: '' },
    };

    await handleReceivePoll({
      eventData: mockEventDataSubmit,
      getCartResponse: mockGetCartResponseEmptyEmail,
      customerProfile: mockCustomerProfile,
      landing: mockLanding,
      updatedEmail,
      paperLessBilling,
      getOrderWrite: mockGetOrderWrite,
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
    });

    expect(mockGetOrderWrite).toHaveBeenCalledTimes(1);
  });

  it('should handle standAloneTradeIn scenario', async () => {
    const mockGetOrderWrite = jest.fn();
    const mockGetCartResponseStandalone = {
      ...mockGetCartResponse,
      cartHeader: {
        ...mockGetCartResponse.cartHeader,
        sourceSystem: 'source',
      },
      lineDetails: {
        ...mockGetCartResponse.lineDetails,
        acctMcsSubscription: [{ id: '123456' }],
        lineInfo: [], // No lines to trigger standAloneTradeIn
      },
      orderDetails: {
        ...mockGetCartResponse.orderDetails,
        customerType: 'Y',
      },
    };
    const mockLandingStandalone = {
      ...mockLanding.quoteDetails,
      quoteDetails: [],
    };
    const noEmailUpdated = null;
    await handleReceivePoll({
      eventData: mockEventDataSubmit,
      getCartResponse: mockGetCartResponseStandalone,
      customerProfile: mockCustomerProfile,
      landing: mockLandingStandalone,
      noEmailUpdated,
      paperLessBilling,
      getOrderWrite: mockGetOrderWrite,
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
    });

    expect(mockGetOrderWrite).toHaveBeenCalledTimes(1);
  });

  it('should handle hasEupByodWithSimCpe scenario', async () => {
    const mockGetOrderWrite = jest.fn();

    const mockGetCartResponseEupByod = {
      ...mockGetCartResponse,
      lineDetails: {
        lineInfo: [
          {
            primaryUserInfo: { emailId: 'lineEmail@domain.com' },
            lineActivityType: 'EUPBYOD',
            itemsInfo: [
              {
                cartItems: {
                  cartItem: [
                    {
                      cartItemType: 'SIM',
                      isCustomerProvidedSIM: true,
                    },
                  ],
                },
              },
            ],
          },
        ],
      },
    };
    const noEmailUpdated = null;
    await handleReceivePoll({
      eventData: mockEventDataSubmit,
      getCartResponse: mockGetCartResponseEupByod,
      customerProfile: mockCustomerProfile,
      landing: mockLanding,
      noEmailUpdated,
      paperLessBilling,
      getOrderWrite: mockGetOrderWrite,
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
    });

    expect(mockGetOrderWrite).toHaveBeenCalledTimes(1);
  });

  it('should handle hasEupByodWithSimCpe  -  SCM -> orderWriteStatus = true', async () => {
    isFunctionalityEnabled.mockReturnValue(true);

    const mockGetOrderWrite = () => ({
      error: {
        status: 500,
        data: {
          errors: [
            {
              namespace: 'POJON-pega-orderSubmit',
              name: 'Down stream error',
              id: '1009',
              debug_id: '',
              message:
                'Service error occured on POJON with message the HTTP response code of 500 indicated a server error. The response data may contain a reason.',
              serviceErrMsg:
                'Service error occured on POJON with message the HTTP response code of 500 indicated a server error. The response data may contain a reason.',
              msgType: 'G',
              cfeMsg: true,
            },
          ],
        },
      },
    });

    const mockGetCartResponseEupByod = {
      ...mockGetCartResponse,
      lineDetails: {
        lineInfo: [
          {
            primaryUserInfo: { emailId: 'lineEmail@domain.com' },
            lineActivityType: 'EUPBYOD',
            itemsInfo: [
              {
                cartItems: {
                  cartItem: [
                    {
                      cartItemType: 'SIM',
                      isCustomerProvidedSIM: true,
                    },
                  ],
                },
              },
            ],
          },
        ],
      },
    };
    const noEmailUpdated = null;
    await handleReceivePoll({
      eventData: mockEventDataSubmit,
      getCartResponse: mockGetCartResponseEupByod,
      customerProfile: mockCustomerProfile,
      landing: mockLanding,
      noEmailUpdated,
      paperLessBilling,
      getOrderWrite: mockGetOrderWrite,
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
      dispatch: jest.fn(),
      orderWriteStatus: { current: true },
    });
  });

  it('should handle hasEupByodWithSimCpe  -  SCM -> orderWriteStatus = false', async () => {
    isFunctionalityEnabled.mockReturnValue(true);

    const mockGetOrderWrite = () => ({
      error: {
        status: 500,
        data: {
          errors: [
            {
              namespace: 'POJON-pega-orderSubmit',
              name: 'Down stream error',
              id: '1009',
              debug_id: '',
              message:
                'Service error occured on POJON with message the HTTP response code of 500 indicated a server error. The response data may contain a reason.',
              serviceErrMsg:
                'Service error occured on POJON with message the HTTP response code of 500 indicated a server error. The response data may contain a reason.',
              msgType: 'G',
              cfeMsg: true,
            },
          ],
        },
      },
    });

    const mockGetCartResponseEupByod = {
      ...mockGetCartResponse,
      lineDetails: {
        lineInfo: [
          {
            primaryUserInfo: { emailId: 'lineEmail@domain.com' },
            lineActivityType: 'EUPBYOD',
            itemsInfo: [
              {
                cartItems: {
                  cartItem: [
                    {
                      cartItemType: 'SIM',
                      isCustomerProvidedSIM: true,
                    },
                  ],
                },
              },
            ],
          },
        ],
      },
    };
    const noEmailUpdated = null;
    await handleReceivePoll({
      eventData: mockEventDataSubmit,
      getCartResponse: mockGetCartResponseEupByod,
      customerProfile: mockCustomerProfile,
      landing: mockLanding,
      noEmailUpdated,
      paperLessBilling,
      getOrderWrite: mockGetOrderWrite,
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
      dispatch: jest.fn(),
      orderWriteStatus: { current: false },
    });
  });

  it('should handle hasEupByodWithSimCpe  -  SCM -> orderWriteStatus = false, with error', async () => {
    isFunctionalityEnabled.mockReturnValue(true);

    const mockGetCartResponseEupByod = {
      ...mockGetCartResponse,
      lineDetails: {
        lineInfo: [
          {
            primaryUserInfo: { emailId: 'lineEmail@domain.com' },
            lineActivityType: 'EUPBYOD',
            itemsInfo: [
              {
                cartItems: {
                  cartItem: [
                    {
                      cartItemType: 'SIM',
                      isCustomerProvidedSIM: true,
                    },
                  ],
                },
              },
            ],
          },
        ],
      },
    };
    const noEmailUpdated = null;
    await handleReceivePoll({
      eventData: mockEventDataSubmit,
      getCartResponse: mockGetCartResponseEupByod,
      customerProfile: mockCustomerProfile,
      landing: mockLanding,
      noEmailUpdated,
      paperLessBilling,
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
      dispatch: jest.fn(),
      orderWriteStatus: { current: false },
    });
  });

  it('should handle hasEupByodWithSimCpe  -  SCM -> orderWriteStatus = false, with error', async () => {
    isFunctionalityEnabled.mockReturnValue(false);

    const mockGetCartResponseEupByod = {
      ...mockGetCartResponse,
      lineDetails: {
        lineInfo: [
          {
            primaryUserInfo: { emailId: 'lineEmail@domain.com' },
            lineActivityType: 'EUPBYOD',
            itemsInfo: [
              {
                cartItems: {
                  cartItem: [
                    {
                      cartItemType: 'SIM',
                      isCustomerProvidedSIM: true,
                    },
                  ],
                },
              },
            ],
          },
        ],
      },
    };
    const noEmailUpdated = null;
    await handleReceivePoll({
      eventData: mockEventDataSubmit,
      getCartResponse: mockGetCartResponseEupByod,
      customerProfile: mockCustomerProfile,
      landing: mockLanding,
      noEmailUpdated,
      paperLessBilling,
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
      dispatch: jest.fn(),
      orderWriteStatus: { current: false },
    });
  });
  it('should handle isCPCorFEAonlyOrder scenario', async () => {
    const mockGetOrderWrite = jest.fn();

    const mockGetCartResponseCPCFEA = {
      ...mockGetCartResponse,
      lineDetails: {
        lineInfo: [
          {
            primaryUserInfo: { emailId: 'lineEmail@domain.com' },
            lineActivityType: 'CPC',
            itemsInfo: [
              {
                cartItems: {
                  cartItem: [
                    {
                      cartItemType: 'Accessory',
                    },
                  ],
                },
              },
            ],
          },
        ],
      },
    };

    await handleReceivePoll({
      eventData: mockEventDataSubmit,
      getCartResponse: mockGetCartResponseCPCFEA,
      customerProfile: mockCustomerProfile,
      landing: mockLanding,
      updatedEmail,
      paperLessBilling,
      getOrderWrite: mockGetOrderWrite,
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
    });
    expect(mockGetOrderWrite).toHaveBeenCalledTimes(1);
  });

  it('should handle scenario when isMitekSimSwapEnabled is false', async () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ isMitekSimSwapEnabled: 'FALSE' }));

    const mockGetOrderWrite = jest.fn();

    await handleReceivePoll({
      eventData: mockEventDataSubmit,
      getCartResponse: mockGetCartResponse,
      customerProfile: mockCustomerProfile,
      landing: mockLanding,
      updatedEmail,
      paperLessBilling,
      getOrderWrite: mockGetOrderWrite,
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
    });

    expect(mockGetOrderWrite).toHaveBeenCalledTimes(1);
  });

  it('should handle scenario when isMitekSimSwapEnabled is false 01', async () => {
    window.mfe = { scmCheckoutMfeEnable: false };
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ isMitekSimSwapEnabled: 'FALSE' }));

    const mockGetOrderWrite = jest.fn();

    await handleReceivePoll({
      eventData: mockEventDataSubmit,
      getCartResponse: mockGetCartResponse,
      customerProfile: mockCustomerProfile,
      landing: mockLanding,
      updatedEmail,
      paperLessBilling,
      getOrderWrite: mockGetOrderWrite,
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
    });

    expect(mockGetOrderWrite).toHaveBeenCalledTimes(1);
  });

  it('should handle scenario when isMitekSimSwapEnabled is false 01', async () => {
    window.mfe = { scmCheckoutMfeEnable: false, historyRef: [] };
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ isMitekSimSwapEnabled: 'FALSE' }));

    const mockGetOrderWrite = jest.fn();

    await handleReceivePoll({
      eventData: mockEventDataSubmit,
      getCartResponse: mockGetCartResponse,
      customerProfile: mockCustomerProfile,
      landing: mockLanding,
      updatedEmail,
      paperLessBilling,
      getOrderWrite: mockGetOrderWrite,
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
    });

    expect(mockGetOrderWrite).toHaveBeenCalledTimes(1);
  });

  it('should handle scenario when isMitekSimSwapEnabled is false 01', async () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] };
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ isMitekSimSwapEnabled: 'FALSE' }));

    const mockGetOrderWrite = jest.fn();

    await handleReceivePoll({
      eventData: mockEventDataSubmit,
      getCartResponse: mockGetCartResponse,
      customerProfile: mockCustomerProfile,
      landing: mockLanding,
      updatedEmail,
      paperLessBilling,
      getOrderWrite: mockGetOrderWrite,
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
    });

    expect(mockGetOrderWrite).toHaveBeenCalledTimes(1);
  });

  it('should handle isCPCorFEAonlyOrder scenario', async () => {
    const mockGetOrderWrite = jest.fn();
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] };
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ isMitekSimSwapEnabled: 'FALSE' }));
    sessionStorage.setItem('isViewTogether', true);
    const mockGetCartResponseCPCFEA = {
      ...mockGetCartResponse,
      lineDetails: {
        lineInfo: [
          {
            primaryUserInfo: { emailId: 'lineEmail@domain.com' },
            lineActivityType: 'CPC',
            itemsInfo: [
              {
                cartItems: {
                  cartItem: [],
                },
              },
            ],
          },
        ],
      },
    };

    await handleReceivePoll({
      eventData: mockEventDataSubmit,
      getCartResponse: mockGetCartResponseCPCFEA,
      customerProfile: mockCustomerProfile,
      landing: mockLanding,
      updatedEmail,
      paperLessBilling,
      getOrderWrite: mockGetOrderWrite,
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
    });
    expect(mockGetOrderWrite).toHaveBeenCalledTimes(1);
  });

  it('should handle isCPCorFEAonlyOrder scenario', async () => {
    const mockGetOrderWrite = jest.fn();
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] };
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ isMitekSimSwapEnabled: 'FALSE' }));
    sessionStorage.setItem('isViewTogether', true);
    delete window.location;
    // window.location = new URL('http://example.com/content/vcg/assisted');
    window.location = new URL('http://example.com/content/vcg/assisted/handoff.html');

    const mockGetCartResponseCPCFEA = {
      ...mockGetCartResponse,
      lineDetails: {
        lineInfo: [
          {
            primaryUserInfo: { emailId: 'lineEmail@domain.com' },
            lineActivityType: 'CPC',
            itemsInfo: [
              {
                cartItems: {
                  cartItem: [],
                },
              },
            ],
          },
        ],
      },
    };

    await handleReceivePoll({
      eventData: mockEventDataSubmit,
      getCartResponse: mockGetCartResponseCPCFEA,
      customerProfile: mockCustomerProfile,
      landing: mockLanding,
      updatedEmail,
      paperLessBilling,
      getOrderWrite: mockGetOrderWrite,
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
    });
    expect(mockGetOrderWrite).toHaveBeenCalledTimes(1);
  });
  it('should handle resendor event', async () => {
    sessionStorage.setItem('customerType', 'PE');
    sessionStorage.setItem('tagActiveMTN', 12345678);
    const mockGetOrderWrite = jest.fn();
    await handleReceivePoll({
      eventData: mockEventDataResender,
      getCartResponse: mockGetCartResponse,
      customerProfile: mockCustomerProfile,
      landing: mockLanding,
      updatedEmail,
      paperLessBilling,
      getOrderWrite: mockGetOrderWrite,
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
    });
  });
  it('should handle lovresenblankpage event', async () => {
    sessionStorage.setItem('customerType', 'PE');
    sessionStorage.setItem('tagActiveMTN', 12345678);
    const mockGetOrderWrite = jest.fn();
    await handleReceivePoll({
      eventData: mockEventDataLovResend,
      getCartResponse: mockGetCartResponse,
      customerProfile: mockCustomerProfile,
      landing: mockLanding,
      updatedEmail,
      paperLessBilling,
      getOrderWrite: mockGetOrderWrite,
      requestBodySendMessage: mockData.requestBodySendMessage,
      handleContinueBtn: jest.fn(),
    });
  });

  describe('sessionStorage accountNum handling after orderWrite', () => {
    beforeEach(() => {
      // Clear accountNum before each test in this suite
      sessionStorage.removeItem('accountNum');
    });

    it('should set accountNum in sessionStorage when scmUpgradeMfeEnable is true and fullAccountNumber is present', async () => {
      window.mfe = { scmCheckoutMfeEnable: true, scmUpgradeMfeEnable: true, historyRef: { push: jest.fn() } };

      const mockGetOrderWrite = jest.fn().mockResolvedValue({
        data: {
          fullAccountNumber: '1234567890',
          availablePaths: [],
        },
      });

      await handleReceivePoll({
        eventData: mockEventDataSubmit,
        getCartResponse: mockGetCartResponse,
        customerProfile: mockCustomerProfile,
        landing: mockLanding,
        updatedEmail,
        paperLessBilling,
        getOrderWrite: mockGetOrderWrite,
        requestBodySendMessage: mockData.requestBodySendMessage,
        dispatch: jest.fn(),
        orderWriteStatus: { current: false },
      });

      expect(sessionStorage.getItem('accountNum')).toBe('1234567890');
    });

    it('should not set accountNum when scmUpgradeMfeEnable is false', async () => {
      window.mfe = { scmCheckoutMfeEnable: true, scmUpgradeMfeEnable: false, historyRef: { push: jest.fn() } };

      const mockGetOrderWrite = jest.fn().mockResolvedValue({
        data: {
          fullAccountNumber: '1234567890',
          availablePaths: [],
        },
      });

      await handleReceivePoll({
        eventData: mockEventDataSubmit,
        getCartResponse: mockGetCartResponse,
        customerProfile: mockCustomerProfile,
        landing: mockLanding,
        updatedEmail,
        paperLessBilling,
        getOrderWrite: mockGetOrderWrite,
        requestBodySendMessage: mockData.requestBodySendMessage,
        dispatch: jest.fn(),
        orderWriteStatus: { current: false },
      });

      expect(sessionStorage.getItem('accountNum')).toBeNull();
    });

    it('should not set accountNum when fullAccountNumber is missing', async () => {
      window.mfe = { scmCheckoutMfeEnable: true, scmUpgradeMfeEnable: true, historyRef: { push: jest.fn() } };

      const mockGetOrderWrite = jest.fn().mockResolvedValue({
        data: {
          availablePaths: [],
        },
      });

      await handleReceivePoll({
        eventData: mockEventDataSubmit,
        getCartResponse: mockGetCartResponse,
        customerProfile: mockCustomerProfile,
        landing: mockLanding,
        updatedEmail,
        paperLessBilling,
        getOrderWrite: mockGetOrderWrite,
        requestBodySendMessage: mockData.requestBodySendMessage,
        dispatch: jest.fn(),
        orderWriteStatus: { current: false },
      });

      expect(sessionStorage.getItem('accountNum')).toBeNull();
    });

    it('should not set accountNum when scmUpgradeMfeEnable is undefined', async () => {
      window.mfe = { scmCheckoutMfeEnable: true, historyRef: { push: jest.fn() } };

      const mockGetOrderWrite = jest.fn().mockResolvedValue({
        data: {
          fullAccountNumber: '1234567890',
          availablePaths: [],
        },
      });

      await handleReceivePoll({
        eventData: mockEventDataSubmit,
        getCartResponse: mockGetCartResponse,
        customerProfile: mockCustomerProfile,
        landing: mockLanding,
        updatedEmail,
        paperLessBilling,
        getOrderWrite: mockGetOrderWrite,
        requestBodySendMessage: mockData.requestBodySendMessage,
        dispatch: jest.fn(),
        orderWriteStatus: { current: false },
      });

      expect(sessionStorage.getItem('accountNum')).toBeNull();
    });
  });
});

describe('handleLogCustomerUrl', () => {
  beforeEach(() => {
    // Mock window.location.hostname
    Object.defineProperty(window, 'location', {
      value: {
        hostname: 'vzwqa3.verizonwireless.com',
      },
    });

    // Mock sessionStorage
    const mockSessionStorage = (() => {
      let store = {};
      return {
        getItem: jest.fn((key) => store[key] || null),
        setItem: jest.fn((key, value) => {
          store[key] = value?.toString();
        }),
        clear: jest.fn(() => {
          store = {};
        }),
      };
    })();
    Object.defineProperty(window, 'sessionStorage', {
      value: mockSessionStorage,
    });

    window.sessionStorage.setItem('userId', 'testUserId');
  });

  it('should construct and return the sanitized customer URL', async () => {
    const result = await handleLogCustomerUrl({
      spanishSelected: true,
      getCartResponse: {
        cartHeader: { cartId: 'CART123', sourceSystem: 'SYSTEM-X' },
        orderDetails: { locationCode: 'LOC001' },
        lineDetails: {
          tradeInDetail: {
            tradeInItems: [{}], // Simulate trade-in present
          },
        },
      },
      getResultGenerateInspicioId: {
        data: { sendInspicioToken: 'abc123' },
        inspicioAdditionalParam: 'extraParam',
      },
      getResultSendMessage: {
        data: { cluster: 'CL001' },
      },
      getResultSendLovLink: {
        data: {
          serviceBody: {
            serviceResponse: {
              context: {
                caseId: 'CASE123',
              },
            },
          },
        },
      },
      radioSelected: 'View Together using PTA',
    });

    // Expect token to be base64 of 'abc123'
    const encodedToken = btoa('abc123');

    expect(result).toContain('https://lifeonverizon.verizonwireless.com/lov/lovOrderReview.html');
    expect(result).toContain(`p=${encodedToken}`);
    expect(result).toContain('es=Y'); // Spanish selected
    expect(result).toContain('ct=CART123');
    expect(result).toContain('ca=CASE123');
    expect(result).toContain('o=extraParam');
    expect(result).toContain('t=Y'); // trade-in present
    expect(result).toContain('px=Y'); // PTA selected
    expect(result).toContain('si=testUserId');
    expect(result).toContain('loc=LOC001');
  });

  it('should handle missing optional data gracefully', async () => {
    const result = await handleLogCustomerUrl({});

    expect(result).toContain('https://lifeonverizon.verizonwireless.com/lov/lovOrderReview.html');
  });
});

it('should handle Retail Companion selection', async () => {
  const mockParams = {
    spanishSelected: false,
    getCartResponse: {
      orderDetails: { locationCode: 'LOC456' },
    },
    getResultGenerateInspicioId: {
      data: {
        vtFeatureFlagToken: 'paramToken',
      },
    },
    getResultSendMessage: {},
    getResultSendLovLink: {},
    radioSelected: 'Retail Companion',
    setEmulatorlaunch: jest.fn(),
  };

  await handleContinue(mockParams);
});

describe('Test handleOrderWriteErrorMsg', () => {
  beforeEach(() => {
    jest.resetAllMocks();
  });
  const getCartResponseMock = {
    cartHeader: {
      sourceSystem: 'ACSS',
    },
  };
  const orderWrite = {
    data: {
      errors: [
        {
          namespace: 'POJON-pega-orderSubmit',
          name: 'Down stream error',
          id: '1009',
          debug_id: '',
          message:
            'Service error occured on POJON with message the HTTP response code of 500 indicated a server error. The response data may contain a reason.',
          serviceErrMsg:
            'Service error occured on POJON with message the HTTP response code of 500 indicated a server error. The response data may contain a reason.',
          msgType: 'G',
          cfeMsg: true,
        },
      ],
    },
  };

  test('Test handleOrderWriteErrorMsg case 1 ', () => {
    handleOrderWriteErrorMsg({
      error: orderWrite,
      getCartResponse: getCartResponseMock,
      requestBodySendMessage: jest.fn(),
      dispatch: jest.fn(),
    });
  });

  test('Test handleOrderWriteErrorMsg case 2: java.lang.NullPointerException ', () => {
    const copyOrderWrite = JSON.parse(JSON.stringify(orderWrite));
    copyOrderWrite.data.errors[0].message = 'java.lang.NullPointerException';
    handleOrderWriteErrorMsg({
      error: copyOrderWrite,
      getCartResponse: getCartResponseMock,
      requestBodySendMessage: jest.fn(),
      dispatch: jest.fn(),
    });
  });

  test('Test handleOrderWriteErrorMsg case 3: error id = 120801 ', () => {
    const copyOrderWrite = JSON.parse(JSON.stringify(orderWrite));
    copyOrderWrite.data.errors[0].id = '120801';
    copyOrderWrite.data.errors[0].message = 'ShipmentConfirmResponse:120801';

    handleOrderWriteErrorMsg({
      error: copyOrderWrite,
      getCartResponse: getCartResponseMock,
      requestBodySendMessage: jest.fn(),
      dispatch: jest.fn(),
    });
  });

  test('Test handleOrderWriteErrorMsg case 4: with empty message ', () => {
    const copyOrderWrite = JSON.parse(JSON.stringify(orderWrite));
    copyOrderWrite.data.errors[0] = {};

    handleOrderWriteErrorMsg({
      error: copyOrderWrite,
      getCartResponse: getCartResponseMock,
      requestBodySendMessage: jest.fn(),
      dispatch: jest.fn(),
    });
  });
});

describe('Test handleOrderWriteSuccessMsg', () => {
  beforeEach(() => {
    jest.resetAllMocks();
  });
  const orderWrite = {
    data: {
      errors: [
        {
          namespace: 'POJON-pega-orderSubmit',
          name: 'Down stream error',
          id: '1009',
          debug_id: '',
          message:
            'Service error occured on POJON with message the HTTP response code of 500 indicated a server error. The response data may contain a reason.',
          serviceErrMsg:
            'Service error occured on POJON with message the HTTP response code of 500 indicated a server error. The response data may contain a reason.',
          msgType: 'G',
          cfeMsg: true,
        },
      ],
    },
  };

  test('Test handleOrderWriteSuccessMsg case 1', () => {
    const copyOrderWrite = JSON.parse(JSON.stringify(orderWrite));
    copyOrderWrite.data.errorMessage = 'Error';
    handleOrderWriteSuccessMsg({
      response: copyOrderWrite,
      getCartResponse: {},
      requestBodySendMessage: jest.fn(),
      dispatch: jest.fn(),
    });
  });

  test('Test handleOrderWriteSuccessMsg case 2: Response empty ', () => {
    const copyOrderWrite = JSON.parse(JSON.stringify(orderWrite));
    copyOrderWrite.data = null;
    handleOrderWriteSuccessMsg({
      response: copyOrderWrite,
      getCartResponse: {},
      requestBodySendMessage: jest.fn(),
      dispatch: jest.fn(),
    });
  });

  test('Test handleOrderWriteSuccessMsg case 3: Throw error ', () => {
    const copyOrderWrite = JSON.parse(JSON.stringify(orderWrite));
    handleOrderWriteErrorMsg({
      response: copyOrderWrite,
      getCartResponse: {},
      dispatch: jest.fn(),
    });
  });

  test('Test handleOrderWriteSuccessMsg case 4: Valid response ', () => {
    const copyOrderWrite = JSON.parse(JSON.stringify(orderWrite));
    handleOrderWriteSuccessMsg({
      response: copyOrderWrite,
      getCartResponse: {},
      requestBodySendMessage: jest.fn(),
      dispatch: jest.fn(),
    });
  });

  describe('extractEnv', () => {
    it('should return 3 for localhost', () => {
      expect(extractEnv('localhost')).toBe(3);
    });

    it('should return 1 for beta1 in url', () => {
      expect(extractEnv('beta1.verizonwireless.com')).toBe(1);
    });

    it('should return 2 for alpha in url', () => {
      expect(extractEnv('alpha.verizonwireless.com')).toBe(2);
    });

    it('should return 3 for beta2 in url', () => {
      expect(extractEnv('beta2.verizonwireless.com')).toBe(3);
    });

    it('should extract sit number from sit5', () => {
      expect(extractEnv('nssit5.verizonwireless.com')).toBe('5');
    });

    it('should extract sit number from sit6', () => {
      expect(extractEnv('nssit6.verizonwireless.com')).toBe('6');
    });

    it('should return 7 for url without sit/beta/alpha', () => {
      expect(extractEnv('lifeonverizon.verizonwireless.com')).toBe(7);
    });

    it('should handle url with sit and beta1', () => {
      expect(extractEnv('nssit5.beta1.verizonwireless.com')).toBe(1);
    });

    it('should handle url with sit and alpha', () => {
      expect(extractEnv('nssit6.alpha.verizonwireless.com')).toBe(2);
    });

    it('should handle url with sit and beta2', () => {
      expect(extractEnv('nssit6.beta2.verizonwireless.com')).toBe(3);
    });

    it('should handle url with sit and no match', () => {
      expect(extractEnv('nssit8.verizonwireless.com')).toBe('8');
    });
  });
  
});

