import { fireEvent, render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../modules/store';
import SmsInput from './SmsInput';
import { useLazyGetSMSConsentQuery } from '../../modules/services/APIService/APIServiceHooks';

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  __esModule: true,
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),

  useLazyGetSMSConsentQuery: jest.fn(),
}));

const successMdnResp = {
  data: {
    wireless: true,
    vzSpid: true,
    spid: '6006',
  },
};

const negativeMdnResp = {
  data: {
    wireless: false,
    vzSpid: true,
    spid: '6006',
  },
};

const mockDataUpdater = (resp) => {
  useLazyGetSMSConsentQuery.mockReturnValue([
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: resp,
    },
  ]);
};

describe('Test SmsInput Component', () => {
  test('renders Ispu Store Details - valid mdn', () => {
    mockDataUpdater(successMdnResp);
    render(
      <BrowserRouter>
        <StoreProvider>
          <SmsInput selectedSmsMDN='' setselectedSmsMDN={jest.fn()} setEnableSendBtn={jest.fn()} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const newcustomerMdn = screen.getByTestId('newcustomer-mdn');
    expect(newcustomerMdn).toBeInTheDocument();
    fireEvent.change(newcustomerMdn, { target: { value: '789456123' } });
    fireEvent.blur(newcustomerMdn);
  });

  test('renders Ispu Store Details - invalid mdn', () => {
    mockDataUpdater(negativeMdnResp);
    render(
      <BrowserRouter>
        <StoreProvider>
          <SmsInput selectedSmsMDN='3204' setselectedSmsMDN={jest.fn()} setEnableSendBtn={jest.fn()} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const newcustomerMdn = screen.getByTestId('newcustomer-mdn');
    expect(newcustomerMdn).toBeInTheDocument();
    fireEvent.change(newcustomerMdn, { target: { value: '789456123' } });
    fireEvent.blur(newcustomerMdn);
  });
});
