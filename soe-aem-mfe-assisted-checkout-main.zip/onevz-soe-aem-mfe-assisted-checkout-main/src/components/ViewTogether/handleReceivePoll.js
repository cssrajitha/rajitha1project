// handleReceivePoll.js
import { has } from 'lodash';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { getUIContextPath, acssMfeBasePath, isFunctionalityEnabled } from 'onevzsoemfecommon/Helpers';
import Emitter from 'onevzsoemfeframework/Emitter';
import { useNavigate } from 'react-router-dom';

import * as DOMPurify from 'dompurify';
import { reqSendMessage } from './ViewTogetherRequest';
import { scmVtMultitaskMode } from '../../utils/common';
import { handleDisqualifiedPropositions } from '../../utils/orderreviewUtil';

const generateCommonParams = ({
  getCartResponse,
  getResultGenerateInspicioId,
  getResultSendMessage,
  getResultSendLovLink,
  radioSelected,
}) => {
  const { cartHeader } = getCartResponse || {};
  const { sourceSystem = 'OMNI-RETAIL', cartId } = cartHeader || {};
  const tradeInItems = getCartResponse?.lineDetails?.tradeInDetail?.tradeInItems?.length > 0 ? 'Y' : 'N';
  const sendInspicioToken = getResultGenerateInspicioId?.data?.sendInspicioToken || window.sessionStorage.getItem('sendInspicioToken');
  const inspicioToken = sendInspicioToken ? btoa(sendInspicioToken) : '';
  const cluster = getResultSendMessage?.data?.cluster;
  const additionalParam = getResultGenerateInspicioId?.inspicioAdditionalParam || window.sessionStorage.getItem('inspicioAdditionalParam');
  const ffParam = getResultGenerateInspicioId?.data?.vtFeatureFlagToken;
  const caseId = getResultSendLovLink?.data?.serviceBody?.serviceResponse?.context?.caseId;
  const uswin = window.sessionStorage.getItem('userId');
  const locationCode = getCartResponse?.orderDetails?.locationCode;
  const isPtaSelected = radioSelected === 'View Together using PTA';

  return {
    cartId,
    sourceSystem,
    tradeInItems,
    inspicioToken,
    cluster,
    additionalParam,
    caseId,
    uswin,
    locationCode,
    isPtaSelected,
    ffParam
  }
}

export const handleContinue = async ({
  spanishSelected,
  getCartResponse,
  getResultGenerateInspicioId,
  getResultSendMessage,
  getResultSendLovLink,
  radioSelected,
  setEmulatorlaunch
}) => {

  const { 
    cartId,
    sourceSystem,
    tradeInItems,
    inspicioToken,
    cluster,
    additionalParam,
    caseId,
    uswin,
    locationCode,
    isPtaSelected,
    ffParam
  } = generateCommonParams({
    spanishSelected,
    getCartResponse,
    getResultGenerateInspicioId,
    getResultSendMessage,
    getResultSendLovLink,
    radioSelected,
    setEmulatorlaunch
  })

  const fullScreenParam = `width=${window.screen.width}, height=${window.screen.height}, top=0, left=0, fullscreen=yes`;
  const isRetailCompanionSelected = radioSelected === 'Retail Companion';

  const inspicioWindowParams = {
    sh: 'Y',
    p: inspicioToken,
    q: 'Y',
    h: caseId || '',
    i: cluster,
    c: sourceSystem,
    l: 'Y',
    em: 'EM',
    es: spanishSelected ? 'Y' : 'N',
  };
  let paramsUrl = `?sh=Y&p=${inspicioWindowParams.p}&q=${inspicioWindowParams.q}&h=${inspicioWindowParams.h}&i=${inspicioWindowParams.i}&c=${inspicioWindowParams.c}&l=${inspicioWindowParams.l}&em=${inspicioWindowParams.em}&es=${inspicioWindowParams.es}&vt=Y`;
  console.log({ paramsUrl });
  if (cartId) {
    paramsUrl += `&ct=${cartId}`;
  }
  if (caseId) {
    paramsUrl += `&ca=${caseId}`;
  }
  if (additionalParam) {
    paramsUrl += `&o=${additionalParam}`;
  }
  if (tradeInItems) {
    paramsUrl += `&t=${tradeInItems}`;
  }
  if (isPtaSelected) {
    paramsUrl += `&px=Y&si=${uswin}&loc=${locationCode}`;
  }
  if (isRetailCompanionSelected) {
    paramsUrl += `&rc=Y&si=${uswin}&loc=${locationCode}`;
  }
  if (ffParam) {
    paramsUrl += `&ff=${ffParam}`;
  }
  const liveReviewUrl = DOMPurify.sanitize(`${getLivePreviewUrl()}${paramsUrl}`);
  const liveReviewParam = DOMPurify.sanitize(
    `toolbar=no,status=no,menubar=no,scrollbars=yes,dialog=yes,resizable=yes,${fullScreenParam}`,
  );
  console.log({ liveReviewUrl });
  sessionStorage.setItem('repEmulatorUrl', liveReviewUrl);
  window.scrollTo(0, document.body.scrollHeight);
  window.lovEmulatorWindow = window.open(liveReviewUrl,  `newWindow_${caseId}`, liveReviewParam);
  setEmulatorlaunch(true);
  window.sessionStorage.setItem('emulatorlaunched', true);
  window.sessionStorage.setItem('vtCluster', getResultSendMessage?.data?.cluster);
};

export const getLivePreviewUrl = () => {
  const envMap = {
    1: 'vzwqa1',
    2: 'vzwqa2',
    3: 'vzwqa3',
    4: 'vzwqa4',
    5: 'nssit5',
    6: 'nssit6',
    7: 'lifeonverizon',
  };
  const host = window.location.hostname;
  const envKey = extractEnv(host);
  const env = envMap[`${envKey}`] || 'vzwqa3';
  return `https://${env}.verizonwireless.com/lov/repHome.html`;
};

export const getCustomerUrl = () => {
  const envMap = {
    1: 'vzwqa1',
    2: 'vzwqa2',
    3: 'vzwqa3',
    4: 'vzwqa4',
    5: 'nssit5',
    6: 'nssit6',
    7: 'lifeonverizon',
  };
  const host = window.location.hostname;
  const envKey = extractEnv(host);
  const env = envMap[`${envKey}`] || 'vzwqa3';
  return `https://${env}.verizonwireless.com/lov/lovOrderReview.html`;
};

export const handleLogCustomerUrl = async ({
  spanishSelected,
  getCartResponse,
  getResultGenerateInspicioId,
  getResultSendMessage,
  getResultSendLovLink,
  radioSelected,
}) => {

  const { 
    cartId,
    sourceSystem,
    tradeInItems,
    inspicioToken,
    cluster,
    additionalParam,
    caseId,
    uswin,
    locationCode,
    isPtaSelected 
  } = generateCommonParams({
    spanishSelected,
    getCartResponse,
    getResultGenerateInspicioId,
    getResultSendMessage,
    getResultSendLovLink,
    radioSelected
  })

  const inspicioWindowParams = {
    sh: 'Y',
    p: inspicioToken,
    q: 'Y',
    h: caseId || '',
    i: cluster,
    c: sourceSystem,
    l: 'Y',
    em: 'EM',
    es: spanishSelected ? 'Y' : 'N',
    vt: 'Y',
    co: 'Y'
  };
  let customerUrlParams = `?p=${inspicioWindowParams.p}&q=${inspicioWindowParams.q}&h=${inspicioWindowParams.h}&i=${inspicioWindowParams.i}&c=${inspicioWindowParams.c}&l=${inspicioWindowParams.l}&es=${inspicioWindowParams.es}&vt=${inspicioWindowParams.vt}&co=${inspicioWindowParams.co}`;
  console.log({ customerUrlParams });
  if (cartId) {
    customerUrlParams += `&ct=${cartId}`;
  }
  if (caseId) {
    customerUrlParams += `&ca=${caseId}`;
  }
  if (additionalParam) {
    customerUrlParams += `&o=${additionalParam}`;
  }
  if (tradeInItems) {
    customerUrlParams += `&t=${tradeInItems}`;
  }
  if (isPtaSelected) {
    customerUrlParams += `&px=Y&si=${uswin}&loc=${locationCode}`;
  }
  const customerUrl = DOMPurify.sanitize(`${getCustomerUrl()}${customerUrlParams}`);
  // console.log({ customerUrl });
  console.log('Customer URL:', customerUrl);
  const vtLovCaseid = getResultSendLovLink?.data?.serviceBody?.serviceResponse?.context?.caseId;
  window.sessionStorage.setItem('vtCaseId', vtLovCaseid);
  return customerUrl;
};

let navigate = '';
function useNavigateMFE() {
  navigate = useNavigate();
}
try {
  useNavigateMFE();
} catch (e) {
  /* istanbul ignore next */
  console.log('');
}

export const extractEnv = (url) => {
  let urlIndex = 3;
  if (url.indexOf('localhost') === -1) {
    const match = url.match(/(sit(\d)+)/);
    urlIndex = match ? match[2] : 7;
  }

  if (url.indexOf('beta1') !== -1) {
    urlIndex = 1;
  } else if (url.indexOf('alpha') !== -1) {
    urlIndex = 2;
  } else if (url.indexOf('beta2') !== -1) {
    urlIndex = 3;
  }
  
  return urlIndex;
};

const handleReceivePoll = async ({
  eventData,
  getCartResponse,
  customerProfile,
  landing,
  updatedEmail,
  paperLessBilling,
  getOrderWrite,
  requestBodySendMessage,
  spanishSelected,
  getResultGenerateInspicioId,
  getResultSendMessage,
  getNextBillSummaryRes,
  getResultSendLovLink,
  orderReviewResponse,
  fetchPriceSnapshot,
  unifiedNbsData,
  emulatorLaunced,
  setEmulatorlaunch,
  dispatch,
  orderWriteStatus,
  updateVisionRemark
}) => { /* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */
  if (eventData?.detail?.event === 'updateTncParams') {
    await requestBodySendMessage({ body: { ...eventData?.detail?.payload }, spinner: false, mock: false });
  }

  if (eventData?.detail?.event === 'vtRefreshPayment') {
    Emitter.emit('vtRefreshPayment_event', true);
  }

  if (!emulatorLaunced && eventData?.detail?.event === 'openRepEmulator') {
    handleContinue({
      spanishSelected,
      getCartResponse,
      getResultGenerateInspicioId,
      getResultSendMessage,
      getResultSendLovLink,
      setEmulatorlaunch
    });
  }

  if (
    (eventData?.detail?.event === 'resendor' && eventData?.detail?.event !== 'cancelPayment') ||
    (eventData?.detail?.event === 'resendor' && eventData?.payload?.action === 'resendorderreview') ||
    eventData?.detail?.event === 'lovresendblankpage'
  ) {
    const token = getResultGenerateInspicioId?.data?.sendInspicioToken || sessionStorage.getItem('sendInspicioToken') || '';
    const lookUpMTN = sessionStorage.getItem('tagActiveMTN')
      ? sessionStorage.getItem('tagActiveMTN')
      : customerProfile?.data?.customer?.lookupMtn;
    const customerType = sessionStorage.getItem('customerType')
      ? sessionStorage.getItem('customerType')
      : getCartResponse?.orderDetails?.customerType;
    const requestSendMessage = reqSendMessage(
      getCartResponse,
      getNextBillSummaryRes,
      customerProfile,
      getResultSendLovLink,
      getResultSendMessage,
      orderReviewResponse,
      getResultGenerateInspicioId,
      fetchPriceSnapshot,
      customerType,
      lookUpMTN,
      unifiedNbsData
    );

    const requestSendBody = { ...requestSendMessage, clientId: token };
    await requestBodySendMessage({
      body: requestSendBody,
      spinner: false,
      mock: false,
    });
    await requestBodySendMessage({
      body: requestSendBody,
      spinner: false,
      mock: false,
    });
  }

  /* istanbul ignore next */
  if (eventData?.detail?.event === 'cancelPayment') {
    navigate(`${getUIContextPath()}/order-review.html`);
  }

  if (eventData?.detail?.event === 'submit' && eventData?.detail?.payload?.pageName === 'orderReview') {
    const activeMtn = getCartResponse?.cartHeader?.cartCreator ?? '';
    const allowOnlyNumbers = (value) => /^[0-9\b]+$/.test(value);

    const response = sessionStorage.getItem('responseList');
    const responseList = JSON.parse(response);
    const responses = responseList?.filter((res) => res.dispositionOptionId === '18');
    const resList = responses?.map((res) => ({
      rank: res?.rank || '',
      propositionId: res?.propositionId || '',
      soiEngagementId: res?.soiEngagementId || '',
      offerContainerId: res?.offerContainerId || '',
    }));
    const scmCheckoutMfeEnabled = window?.mfe?.scmCheckoutMfeEnable;

    const customerType = getCartResponse?.orderDetails?.customerType || sessionStorage.getItem('customerType');
    let emailId = getCartResponse?.orderDetails?.spocs?.notificationOptions?.primaryEmailId || '';

    if (customerType === 'N' && updatedEmail !== null) emailId = updatedEmail;
    else if (customerType === 'N')
      emailId = getCartResponse?.lineDetails?.lineInfo?.[0]?.primaryUserInfo?.emailId || emailId;

    const quoteId = getCartResponse?.quote?.quoteId || '';
    const currentQuoteId = () => {
      const activeCartId = customerProfile?.data?.customer?.cartId || '';
      const isQuoteDetailsAvailable = landing?.quoteDetails || [];
      if (isQuoteDetailsAvailable.length > 0) {
        const currentQuote = isQuoteDetailsAvailable.filter((item) => item.cartId === activeCartId);
        return currentQuote.length > 0 ? currentQuote[0].quoteId : '';
      }
      return '';
    };

    const lines = has(getCartResponse, 'lineDetails.lineInfo') && getCartResponse?.lineDetails?.lineInfo;
    const channel = has(getCartResponse, 'cartHeader.sourceSystem')
      ? getCartResponse?.cartHeader?.sourceSystem
      : sessionStorage.getItem('channelId');

    const hasEupByodWithSimCpe =
      lines.length > 0 &&
      lines.every((line) =>
        line.lineActivityType !== ' ' && line.lineActivityType === 'EUPBYOD' && !channel?.includes('OMNI-INDIRECT')
          ? line?.itemsInfo?.[0]?.cartItems?.cartItem?.some(
              (item) => item.cartItemType === 'SIM' && item.isCustomerProvidedSIM === true,
            )
          : line.lineActivityType === 'EUPBYOD',
      );

    const lineInfoLength = !!(
      has(getCartResponse, 'lineDetails.lineInfo') && getCartResponse?.lineDetails?.lineInfo?.length
    );
    const tradeinItemsLength = !!(
      has(getCartResponse, 'lineDetails.tradeInDetail.tradeInItems') &&
      getCartResponse?.lineDetails?.tradeInDetail?.tradeInItems.length
    );
    const standAloneTradeIn = !!(!lineInfoLength && tradeinItemsLength);

    const isServiceOnlyOrder = () => {
      const hasOtherLines =
        lines.length > 0 &&
        lines.find(
          (line) =>
            (line.lineActivityType !== 'CPC' && line.lineActivityType !== 'FEA') ||
            ((line.lineActivityType === 'FEA' || line.lineActivityType === 'CPC') &&
              has(line, 'itemsInfo[0].cartItems.cartItem') &&
              line.itemsInfo[0].cartItems.cartItem.length > 0),
        );
      return !hasOtherLines;
    };

    const isCPCorFEAonlyOrder = lines.length > 0 ? isServiceOnlyOrder() : false;
    const isAccLevelSubItemPresent = () => {
      const accSubInCart = getCartResponse?.lineDetails?.acctMcsSubscription || [];
      let isAccSubInCart = false;
      if (accSubInCart?.[0]) isAccSubInCart = true;
      return isAccSubInCart;
    };

    const isAccLevelSubItemPresentValue = isAccLevelSubItemPresent();

    let intentType;
    if (standAloneTradeIn) intentType = 'StandAloneTradeIn';
    else if (hasEupByodWithSimCpe) intentType = 'EUPBYOD';
    else if (isCPCorFEAonlyOrder || isAccLevelSubItemPresentValue) intentType = 'Inline-CPC';
    else intentType = '';

    const geoFenceResponse =
      sessionStorage.getItem('geoFenceResponse') && JSON.parse(sessionStorage.getItem('geoFenceResponse'));
    const inGeoFenceRange =
      geoFenceResponse?.geoFenceCheck === 'false' && geoFenceResponse?.reason?.toLowerCase() === 'out of range';
    const outOfGeoFenceObj = {
      outOfGeoFence: inGeoFenceRange,
      ipadLatitude: geoFenceResponse?.ipadLatitude,
      ipadLongitude: geoFenceResponse?.ipadLongitude,
      storeName: JSON.parse(sessionStorage.getItem('STORE-LOCATION-DETAIL'))?.data?.storeInfo?.storeName,
    };
    const params = {
      mtn: activeMtn && allowOnlyNumbers(activeMtn) ? activeMtn : '',
      locationCode: getCartResponse?.orderDetails?.locationCode || '',
      accountNumber: customerProfile?.data?.customer?.accountNo || '',
      cartId: customerProfile?.data?.customer?.cartId || '',
      cartCreator: getCartResponse?.cartHeader?.cartCreator || '',
      caseId: getCartResponse?.cartHeader?.caseId || '',
      creditAppNum: getCartResponse?.orderDetails?.orderList?.[0]?.creditApplication?.creditApplicationNum || '',
      serviceWriteRequired: true,
      smsDestination: '',
      email: getCartResponse?.orderDetails?.spocs?.notificationOptions?.primaryEmailId || '',
      intent: customerType && customerType === 'N' ? 'NSE' : intentType,
      paperlessIndicator: customerType && customerType === 'N' ? paperLessBilling : null,
      paperLessEmail: customerType && customerType === 'N' && paperLessBilling ? emailId : null,
      header: { cartId: customerProfile?.data?.customer?.cartId || '' },
      responseList: resList,
      regNo: customerProfile?.data?.customer?.regNo || '51',
      quoteId: quoteId !== '' && quoteId !== '0000' ? quoteId : currentQuoteId(),
      purchaseOrderNumber: '',
      billingSystem: getCartResponse?.orderDetails?.billingSystem || '',
      ...(inGeoFenceRange && { ...outOfGeoFenceObj }),
    };

    if (
      params.email === '' ||
      params.email === getCartResponse?.orderDetails?.spocs?.notificationOptions?.primaryEmailId
    ) {
      params.serviceWriteRequired = false;
    }

    let noOfTradeItems = 0;
    if (tradeinItemsLength) noOfTradeItems = getCartResponse?.lineDetails?.tradeInDetail?.tradeInItems.length;
    const tradeInShippingType = getCartResponse?.lineDetails?.tradeInDetail?.tradeInShippingType;
    if (tradeinItemsLength) {
      params.tradeinCount = noOfTradeItems;
      params.tradeinShippingTypeForAssistedFlows = tradeInShippingType || '';
    }

    const appProperties = JSON.parse(sessionStorage.getItem('APP_PROPERTIES')) || {};
    const isMitekSimSwapEnabled = appProperties?.isMitekSimSwapEnabled === 'TRUE';
    const locationData = JSON.parse(sessionStorage.getItem('locationData'));
    if (isMitekSimSwapEnabled) {
      params.storeCity = locationData?.city || '';
      params.storeState = locationData?.state || '';
    }
    const isAcssVtPerksEnabled = window?.mfe?.acssVtPerksEnabled || false;
    const enableMsgForOrderWrite = isFunctionalityEnabled('scmCommonFixFFlag', 'enableMsgForOrderWrite');
    const cpcChargebackFFlag = appProperties?.cpcChargebackFFlag === 'TRUE';
    // Check for CPC chargeback feature flag and handle disqualified propositions before order write
    if (cpcChargebackFFlag && lines?.length > 0) {
      const customer = customerProfile?.data?.customer;
      handleDisqualifiedPropositions(lines, customer, updateVisionRemark);
    }

    if (enableMsgForOrderWrite && orderWriteStatus?.current) {
      dispatch(appMessageActions.addAppMessage('Checkout in Progress please wait ....', 'error'));
      return;
    }

    try {
      if (enableMsgForOrderWrite) {
        /* eslint-disable-next-line no-param-reassign */
        orderWriteStatus.current = true;
      }
      const orderWriteResult = await getOrderWrite({ body: params, spinner: true, mock: false });
      const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable;
      if(scmUpgradeMfeEnable && orderWriteResult?.data?.fullAccountNumber){
        sessionStorage.setItem('accountNum', orderWriteResult?.data?.fullAccountNumber);
      }
      
      if (enableMsgForOrderWrite) {
        /* eslint-disable-next-line no-param-reassign */
        orderWriteStatus.current = false;
        dispatch(appMessageActions.removeAppMessage({ summary: 'Checkout in Progress please wait ....' }));
      }

    /* istanbul ignore next */
    if (scmCheckoutMfeEnabled) {
      if (enableMsgForOrderWrite) {
        if (orderWriteResult?.error) {
          await handleOrderWriteErrorMsg({
            error: orderWriteResult.error,
            getCartResponse,
            requestBodySendMessage,
            dispatch,
          });
          return;
        } 
        if (orderWriteResult?.data) {
          const { isProceedNext } = await handleOrderWriteSuccessMsg({
            response: orderWriteResult,
            getCartResponse,
            requestBodySendMessage,
            dispatch,
          });
          if (!isProceedNext) return;
        }
      }

      if (isAcssVtPerksEnabled) Emitter?.removeAllListeners('VT_RECEIVE_EVENT');
      if ((isCPCorFEAonlyOrder || standAloneTradeIn) && sessionStorage.getItem('isViewTogether') && isAcssVtPerksEnabled) {
        if (window.location.href.indexOf('content/vcg/assisted/') === -1 ) {
          const vtordernum =
            (orderWriteResult?.data?.orderDetails && orderWriteResult?.data?.orderDetails[0]?.orderNum) || '';
            const cart = getCartResponse;
            const vtReqSendMessage = {
              clientId: window.sessionStorage.getItem('LovClientId') || '',
              cluster: window.sessionStorage.getItem('vtCluster') || '',
              event: 'pageNavigation',
              payload: {
                pageName: 'orderConfirmation',
                locationCode: cart?.cartHeader?.cartCreatorOrderLocationCode,
                orderNum: vtordernum,
                specialist: cart?.orderDetails?.salesRepId || '',
                mtn: cart?.lineDetails?.lineInfo?.[0]?.mtnDetails?.mobileNumber || '',
                city: cart?.lineDetails?.lineInfo?.[0].itemsInfo?.[0]?.shipping?.address?.city || '',
                state: cart?.lineDetails?.lineInfo?.[0].itemsInfo?.[0]?.shipping?.address?.state || '',
                zip: cart?.lineDetails?.lineInfo?.[0].itemsInfo?.[0]?.shipping?.address?.zipCode || '',
                chargeEffectiveDate: cart?.orderDetails?.effectiveDateDetails?.selectedDate,
                channel: cart?.cartHeader?.sourceSystem,
                repFirstName: '',
                repLastName: '',
                orderMtn: cart?.lineDetails?.lineInfo?.[0]?.mtnDetails?.mobileNumber || '',
                orderAccountNum: cart?.cartHeader?.fullAccountNumber || '',
                cartId: window.sessionStorage.getItem('cartId') || '',
                transactionType: 'C',
          
              },
            };
            await requestBodySendMessage({ body: vtReqSendMessage, spinner: false, mock: false });
            const resendTConfPayloadFFlag =  isFunctionalityEnabled('scmGeneralFixFFlag', 'resendTConfPayloadFFlag');
            /* istanbul ignore next */
            if (resendTConfPayloadFFlag) {
              setTimeout(() => {
                requestBodySendMessage({ body: vtReqSendMessage, spinner: false, mock: false });
              }, 2000);
            }
            window?.Emitter?.emit('ACSS_VT_SCM_CLOSE_ORDER_CONFIRM', { data: {} });
            window.sessionStorage.setItem('stopPollFromSession', true);
            return;
          }
          /* istanbul ignore next */
          if (window.location.href.indexOf('content/vcg/assisted/handoff.html') === -1 ) {
            window.Emitter?.emit('ACSS_SCM_SWITCH_TAB', { type: 'SWITCH_TAB', targetTab: 'CHECKOUT_TAB' });
            setTimeout(() => {
              window?.mfe?.historyRef.push(`${acssMfeBasePath}/care-order-confirmation.html`);  
            }, 2000);
          }
          else 
          {
            if(standAloneTradeIn){
              window.sessionStorage.setItem('stopPollFromSession', true);
            }else if (scmVtMultitaskMode()) {
              window?.Emitter?.emit('ACSS_VT_SCM_CHECKOUT_PROGRESS', { data: {'confirm':'Y'} });
              return;
            }
            window?.mfe?.historyRef.push(`${acssMfeBasePath}/care-order-confirmation.html`);
          }
        }
      else
      {
        if (scmVtMultitaskMode()) {
          window?.Emitter?.emit('ACSS_VT_SCM_CHECKOUT_PROGRESS', { data: {'payment':'Y'}  });
          return;
        }
        window?.mfe?.historyRef.push(
          `${acssMfeBasePath}/payment-agreement.html?ptechEnabledForRetailLoc=${
            orderReviewResponse?.data?.ptechEnabledForRetailLoc
          }&enableGiftCardInspicio=${getResultGenerateInspicioId?.data?.enableGiftCardInspicio || false}`,
        );
      }
    } else if (orderWriteResult?.data) {
      const hasReceivedConfirmationPath = orderWriteResult?.data?.availablePaths?.find(
        (rec) => rec.path === 'Confirmation',
      );
      if (hasReceivedConfirmationPath) {
        window.location.href = `/sales/assisted/new/order-confirmation.html`;
      } else {
        window.location.href = `/sales/assisted/new/payment-agreement.html?ptechEnabledForRetailLoc=${
          orderReviewResponse?.data?.ptechEnabledForRetailLoc
        }&enableGiftCardInspicio=${getResultGenerateInspicioId?.data?.enableGiftCardInspicio || false}`;
      }
    }
    } catch (err) {
      if (enableMsgForOrderWrite) {
        /* eslint-disable-next-line no-param-reassign */
        orderWriteStatus.current = false;
      }
    }
  }
};

export const handleOrderWriteErrorMsg = async ({ error, getCartResponse, requestBodySendMessage, dispatch }) => {
  const errMsg = has(error, 'data.errors[0].message') ? error?.data?.errors?.[0]?.message : '';
  let formattedErrMsg = '';
  if (errMsg) {
    formattedErrMsg = errMsg.includes('java.lang.NullPointerException')
        ? 'Something Went Wrong! Please restart the order.'
        : `${errMsg} , Please restart the order`;
    if (error?.data?.errors?.[0]?.id === '120801' && errMsg.includes('ShipmentConfirmResponse:120801')) {
      formattedErrMsg = 'Address Validation failed. Please restart the order.';
    }
    dispatch(appMessageActions.addAppMessage(formattedErrMsg, 'error', true, false));
  }
  await sendLovError({ getCartResponse, requestBodySendMessage });
};

export const handleOrderWriteSuccessMsg = async ({ response, getCartResponse, requestBodySendMessage, dispatch }) => {
  let isError = false;
  if (response?.data?.errors && response?.data?.errorMessage && response?.data?.errors.length) {
    isError = true;
    dispatch(
      appMessageActions.addAppMessage(
        `${response?.data?.errors?.[0]?.message} , Please restart the order.`,
        'error',
      ),
    );
    await sendLovError({ getCartResponse, requestBodySendMessage });
  } else if (!response || !response?.data) {
    isError = true;
    dispatch(appMessageActions.addAppMessage('Error while processing the order', 'error'));
    await sendLovError({ getCartResponse, requestBodySendMessage });
  }

  return { isProceedNext: !isError };
};

const sendLovError = async ({ getCartResponse, requestBodySendMessage }) => {
  try {
    const channel = has(getCartResponse, 'cartHeader.sourceSystem')
      ? getCartResponse?.cartHeader?.sourceSystem
      : sessionStorage.getItem('channelId');

    const request = {
      event: 'orderreviewerror',
      clientId: window.sessionStorage.getItem('LovClientId') || '',
      cluster: window.sessionStorage.getItem('vtCluster') || '',
      channel,
      payload: { error: 'Error while processing the order' },
    };
    await requestBodySendMessage({ body: request, spinner: false, mock: false });
  } catch (err) {
    console.log(err);
  }
};

export default handleReceivePoll;
