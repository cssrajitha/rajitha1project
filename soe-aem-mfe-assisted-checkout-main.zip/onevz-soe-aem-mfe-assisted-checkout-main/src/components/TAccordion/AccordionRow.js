import React, { useEffect, useState } from 'react';
import { Body } from '@vds/typography';
import { TableRow, Cell } from '@vds/tables';
import { isEmpty } from 'lodash';
import styled from 'styled-components';
import { Icon } from '@vds/icons';
import PropTypes from 'prop-types';
import { useSelector } from 'react-redux';
import AccordionAnimation from './AccordionAnimation';
import { DARK_THEME_COLOR, DARK_SURFACE } from '../constants/constants';

const PlanDescription = styled.div`
  padding-bottom: 2rem;
`;

const HighlightedText = styled.div`
  background: #000000;
  color: #ffffff;
  line-height: 1.65rem;
  padding: 0.125rem 0.25rem;
  border-radius: 7px;
  display: inline-block;
  width: 80%;
`;

const AddedhighlightedText = styled.div`
  background: #ffffff;
  color: #000000;
  border-radius: 2px;
  width: 20%;
`;

const CustomTableRow = styled.tr`
  cursor: pointer;
  position: relative;
  border-bottom: 0px !important;
  &:focus-visible {
    &::after {
      border: 1px dashed #d8dada;
    };
      content: '';
      height: calc(100% - 6px);
      left: 50%;
      position: absolute;
      top: 50%;
      transform: translate(-50%, -50%);
      width: calc(100% - 6px);
      z-index: 1;
    }
    outline: none;
  }
`;
const TriggerCell = styled(Cell)`
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
  padding: 2rem 0rem 2rem 0 !important;
  border: none !important;
`;
const CustomContentCell = styled(Cell)`
  padding: 0px 1rem 0px 0px !important;
  border: none !important;
  white-space: normal;
`;
const TriggerWrapper = styled.div`
  cursor: pointer;
  height: 24px;
  transform: rotate(${({ open }) => (open ? `-180deg` : `0deg`)});
  transition:
    transform 330ms cubic-bezier(0.22, 0.61, 0.36, 1),
    top 30ms cubic-bezier(0.22, 0.61, 0.36, 1);
  width: 24px;
  svg {
    polygon {
      fill: ${({ isDark }) => (isDark ? '#fffff' : 'grey')};
    }
  }
`;
const TableCell = styled(Cell)`
  padding: 2rem 2rem 2rem 0 !important;
  border: none !important;
  white-space: normal;
`;
const StyledTableRow = styled(TableRow)`
  border-bottom: 0.0625rem solid rgb(216, 218, 218) !important;
`;

const PaddingBottom12 = styled.div`
  padding: 2px 0 0.65rem 0;
`;

export default function AccordionRow(props) {
  const planReduxData = useSelector((state) => state?.plans?.data);
  const Perksinfo = planReduxData?.perkReferenceDataList;
  const selectedPerk = planReduxData?.selectedPerk;
  const selectedMTNValue = planReduxData?.selectedMTN;
  const oliveAsisstedPlanFeaturesFFlag =
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.oliveAsisstedPlanFeaturesFFlag === 'TRUE';

  const [open, setOpen] = useState(false);
  useEffect(() => {
    const { currentOpenRow } = props;
    if (currentOpenRow !== -1 && currentOpenRow !== props?.rowid && open) {
      setOpen(false);
    }
  }, [props?.currentOpenRow]);
  const isAddedLable = (name, perkId) => {
    const addedPerksArray = perkId?.split(',');
    let perksAdded = [];
    if (!isEmpty(selectedMTNValue?.selectedPerks)) {
      perksAdded = selectedMTNValue.selectedPerks;
    } else if (!isEmpty(selectedPerk)) {
      perksAdded = selectedPerk;
    } else {
      perksAdded = [];
    }
    let isAddedLableVal = false;
    if (!isEmpty(perksAdded)) {
      perksAdded?.forEach((element) => {
        if (
          (Perksinfo[element]?.perkTitle && Perksinfo[element].perkTitle === name) ||
          (Perksinfo[element]?.spoId && addedPerksArray?.includes(Perksinfo[element]?.spoId))
        ) {
          isAddedLableVal = true;
        }
      });
    }
    return isAddedLableVal;
  };

  const setOpend = () => {
    setOpen((prevOpen) => {
      const newOpen = !prevOpen;
      if (newOpen && props.setCurrentRow) {
        props.setCurrentRow(props?.rowid);
      }
      return newOpen;
    });
  };

  const getProductMapData = () => {
    const { productGroupName, planIdProductIdMap, planIds } = props;
    const newMappedIds = [];
    if (productGroupName) {
      newMappedIds.push(productGroupName);
    }
    planIds?.forEach((element) => {
      if (planIdProductIdMap?.planIdProductIdMap[String(element)]) {
        newMappedIds.push(planIdProductIdMap?.planIdProductIdMap[String(element)]);
      } else {
        newMappedIds.push('-');
      }
    });
    return newMappedIds;
  };

  const getHighlightedPlans = () => {
    const { productFeatureMap, productGroupName, comparePlanProductGroupName, compareToCurrentPlans } = props;
    let productIds = [];
    productIds = getProductMapData();

    const subGroupIdCheck = productIds?.filter(
      (items) =>
        productFeatureMap[items] &&
        productFeatureMap[items]?.compareProductSubGroupId &&
        productFeatureMap[items]?.compareProductSubGroupId,
    );
    const subGroupCopyCheck = productIds?.filter(
      (items) => productFeatureMap[items] && productFeatureMap[items]?.compareProductSubGroupCopy,
    );

    return productIds?.map((items, index) => {
      let isHighlighting = false;
      if (productIds.length - 1 === index) {
        isHighlighting =
          Number(productFeatureMap[productIds[index - 1]]?.compareProductWeightedValue ?? 0) <
          Number(productFeatureMap[productIds[index]]?.compareProductWeightedValue ?? 0);
      } else {
        isHighlighting =
          Number(productFeatureMap[productIds[index]]?.compareProductWeightedValue ?? 0) >
          Number(productFeatureMap[productIds[index + 1]]?.compareProductWeightedValue ?? 0);
      }
      const { isDark } = props;
      return (
        <TableCell key={items?.compareProductWeightedValue}>
          <Body size='large' color={isDark ? DARK_THEME_COLOR : ''} bold>
            <PaddingBottom12>
              {getText(index, compareToCurrentPlans, subGroupIdCheck, productFeatureMap)}
              <Body size='large' color='#6F7171'>
                {getTexts(index, compareToCurrentPlans, subGroupIdCheck, productFeatureMap, subGroupCopyCheck)}
              </Body>
            </PaddingBottom12>
          </Body>
          {isHighlighting && compareToCurrentPlans ? (
            <div>
              <HighlightedText>
                <Body size='large' bold color='#ffffff'>
                  <AddedhighlightedText>
                    {comparePlanProductGroupName &&
                      comparePlanProductGroupName === 'Perks' &&
                      index === 1 &&
                      isAddedLable(productFeatureMap[items]?.compareProductName, productFeatureMap[items]?.spoIds) && (
                        <Body size='large' color={isDark ? DARK_THEME_COLOR : ''} bold>
                          Added
                        </Body>
                      )}
                  </AddedhighlightedText>
                  <Icon name='star' size='small' color='#FFFFFF' />
                  <div>
                    <div
                      dangerouslySetInnerHTML={{
                        __html: getHtmlText(items),
                      }}
                    />
                    <div>
                      {oliveAsisstedPlanFeaturesFFlag !== true && (
                        <div dangerouslySetInnerHTML={{ __html: productFeatureMap[items]?.disclaimerText || '' }} />
                      )}
                    </div>{' '}
                  </div>
                </Body>
              </HighlightedText>{' '}
            </div>
          ) : (
            <Body size='large' color={isDark ? DARK_THEME_COLOR : ''}>
              {comparePlanProductGroupName &&
                comparePlanProductGroupName === 'Perks' &&
                index === 1 &&
                isAddedLable(productFeatureMap[items]?.compareProductName, productFeatureMap[items]?.spoIds) && (
                  <Body size='large' color={isDark ? DARK_THEME_COLOR : ''} bold>
                    Added
                  </Body>
                )}
              {getTextData(items, compareToCurrentPlans, productGroupName)}
            </Body>
          )}
        </TableCell>
      );
    });
  };
  const getHtmlText = (items) => {
    const { productFeatureMap, productGroupName } = props;
    let productName;
    if (productFeatureMap[items]?.compareProductName) {
      productName = productFeatureMap[items]?.compareProductName;
    } else if (items === productGroupName) {
      productName = productGroupName;
    } else {
      productName = '-';
    }
    return productName;
  };
  const getText = (index, compareToCurrentPlans, subGroupIdCheck, productFeatureMap) => {
    if (index === 0 && compareToCurrentPlans) {
      if (!isEmpty(subGroupIdCheck)) {
        return productFeatureMap[subGroupIdCheck[0]]?.compareProductSubGroupId;
      }
      return '';
    }
    return (
      <div style={{ visibility: 'hidden' }}>{productFeatureMap[subGroupIdCheck[0]]?.compareProductSubGroupId}</div>
    );
  };
  const getTexts = (index, compareToCurrentPlans, subGroupIdCheck, productFeatureMap, subGroupCopyCheck) => {
    if (index === 0 && compareToCurrentPlans) {
      if (!isEmpty(subGroupIdCheck)) {
        return productFeatureMap[subGroupCopyCheck[0]]?.compareProductSubGroupCopy;
      }
      return '';
    }
    return '';
  };
  const getTextData = (items, compareToCurrentPlans, productGroupName) => {
    if (compareToCurrentPlans) {
      return (
        <div
          dangerouslySetInnerHTML={{
            __html: getHtmlText(items),
          }}
        />
      );
    }
    return items === productGroupName ? (
      <Body size='large' color={props.isDark ? DARK_THEME_COLOR : ''} bold>
        {productGroupName}
      </Body>
    ) : (
      <div
        dangerouslySetInnerHTML={{
          __html: getHtmlText(items),
        }}
      />
    );
  };

  const { dataTrack, productFeatureMap } = props;
  let productIds = [];
  productIds = getProductMapData();
  return (
    <>
      <CustomTableRow
        data-testid='Accordian'
        data-track={`${dataTrack}" Accordion"${open ? '-close' : '-open'}`}
        tabIndex={0}
        open={open}
        onKeyDown={() => setOpend()}
        onClick={() => setOpend()}
      >
        {getHighlightedPlans()}
        <TriggerCell>
          <TriggerWrapper isDark={props.isDark} surface={props.isDark ? DARK_SURFACE : 'light'} open={open}>
            <svg
              id='Layer_1'
              className='acssDarkThemeCaret'
              data-name='Layer 1'
              xmlns='http://www.w3.org/2000/svg'
              viewBox='0 0 21.6 21.6'
            >
              <polygon points='10.8 15.71 1.8 6.71 2.62 5.89 10.8 14.07 18.98 5.89 19.8 6.71 10.8 15.71' />
            </svg>
          </TriggerWrapper>
        </TriggerCell>
      </CustomTableRow>
      <StyledTableRow>
        {productIds?.map((item) => (
          <CustomContentCell colSpan={1} key={item}>
            <AccordionAnimation height={open ? 'auto' : 0}>
              <PlanDescription>
                <Body size='large' color={props.isDark ? DARK_THEME_COLOR : ''}>
                  <div
                    data-testid='newAccordion'
                    className='ctcAccordionRow'
                    dangerouslySetInnerHTML={{
                      __html: productFeatureMap[item]?.compareProductDesc
                        ? productFeatureMap[item]?.compareProductDesc
                        : '-',
                    }}
                  />
                </Body>
              </PlanDescription>
            </AccordionAnimation>
          </CustomContentCell>
        ))}
      </StyledTableRow>
    </>
  );
}

AccordionRow.propTypes = {
  rowid: PropTypes.number,
  currentOpenRow: PropTypes.number,
  setCurrentRow: PropTypes.func,
  productGroupName: PropTypes.string,
  planIdProductIdMap: PropTypes.any,
  productFeatureMap: PropTypes.any,
  comparePlanProductGroupName: PropTypes.string,
  compareToCurrentPlans: PropTypes.any,
  dataTrack: PropTypes.any,
  planIds: PropTypes.any,
  isDark: PropTypes.bool,
};
