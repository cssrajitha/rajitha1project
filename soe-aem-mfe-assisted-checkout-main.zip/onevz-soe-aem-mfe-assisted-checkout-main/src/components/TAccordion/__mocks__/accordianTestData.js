export const planIdProductIdMap = {
  planIdProductIdMap: {
    63215: '71023',
    63217: '71022',
  },
};

export const productGroupName = 'Data';

export const productFeatureMap = {
  71022: {
    compareProductName: '5G Ultra Wideband',
    compareProductDesc:
      "Comparison based on analysis by Verizon of Ookla® Speedtest Intelligence® data for Verizon 5G UWB median download speeds vs Verizon 4G LTE median download speeds, Q4 2022.<br><br>Explore our current 5G and 4G LTE coverage maps.<br><br>Get access to the fastest speeds we offer with 5G Ultra Wideband. Combined with Verizon's 5G network, you get reliable coast to coast coverage. Download apps, games, entire playlists and TV series in seconds. You'll also get 5G Ultra Wideband mobile hotspot and crystal-clear 4K Ultra High Definition video streaming when activated on a capable device. Plus, access experiences from our exclusive 5G partners: Snapchat, Live Nation, Riot Games and Niantic. For full details, visit the <<5G experience page (https://www.verizon.com/5g/)>>.<br><br>5G Ultra Wideband available in select areas and access requires a 5G Ultra Wideband-capable device inside the 5G Ultra Wideband coverage area.",
  },
  71023: {
    compareProductName: 'Verizon 5G',
    compareProductDesc:
      "Get unlimited access to our 5G network. When combined with 5G Ultra Wideband, you’ll get our fastest performance. When network is experiencing heavy traffic, your data may be temporarily slowed.<br><br>Requires a 5G-capable device inside Verizon's 5G coverage area.",
  },
};

export const planIdProductIdMapCom = {
  planIdProductIdMap: {
    63215: '71023',
  },
};

export const comparePlanProductGroupName = 'Perks';

export const selectedMTN = {
  selectedPerks: ['201', '202'],
};

export const getPerksinfo = {
  201: {
    perkTitle: 'Verizon 5G',
  },
};
