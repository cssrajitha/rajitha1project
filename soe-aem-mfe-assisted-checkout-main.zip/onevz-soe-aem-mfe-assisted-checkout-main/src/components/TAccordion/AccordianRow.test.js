import React from 'react';
import { useLazyComparePlansQuery } from 'onevzsoemfecommon/PlanAPIService';
import configureAppStore from 'onevzsoemfeframework/Store';
import { createSlice } from '@reduxjs/toolkit';
import { Provider, useSelector } from 'react-redux';
import AccordionRow from './AccordionRow';
import { render, screen, fireEvent, act } from '../../utils/test-utils/renderHelper';
import StoreProvider from '../../modules/store';
import {
  planIdProductIdMap,
  productGroupName,
  productFeatureMap,
  planIdProductIdMapCom,
  comparePlanProductGroupName,
} from './__mocks__/accordianTestData';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import buildPlanMock from './__mocks__/BuildPlanMock';
import accordionRedux from './__mocks__/accordionRedux.json';
import accordionRedux1 from './__mocks__/accordionRedux1.json';
import accordionRedux2 from './__mocks__/accordionRedux2.json';
import AccordionAnimation from './AccordionAnimation';

const props = {
  isDark: true,
  currentOpenRow: 1,
  rowid: 20,
  setCurrentRow: jest.fn(),
  planIdProductIdMap: {
    groupName: 'TravelPass Days',
    planIdProductIdMap: {
      63215: '71044',
    },
  },
  selectedPerks: [],
  planIds: ['69185', '63215'],
  compareToCurrentPlans: [
    {
      productGroupName: 'Data & Network',
      productList: [
        {
          groupName: 'Data',
          planIdProductIdMap: {
            63215: '70001',
            69185: '71129',
          },
        },
        {
          groupName: 'Network',
          planIdProductIdMap: {
            63215: '70006',
            69185: '70005',
          },
        },
        {
          groupName: 'Mobile Hotspot Data',
          planIdProductIdMap: {
            69185: '71081',
          },
        },
        {
          groupName: 'High-speed international data, talk & text',
          planIdProductIdMap: {
            63215: '71076',
            69185: '71086',
          },
        },
        {
          groupName: "Int'l Talk & Text from the US",
          planIdProductIdMap: {
            63215: '71077',
            69185: '71141',
          },
        },
        {
          groupName: 'Verizon Family',
          planIdProductIdMap: {
            63215: '71139',
            69185: '71139',
          },
        },
        {
          groupName: 'Talk & Text',
          planIdProductIdMap: {
            63215: '60007',
            69185: '60007',
          },
        },
        {
          groupName: 'Streaming Quality',
          planIdProductIdMap: {
            63215: '60027',
            69185: '71087',
          },
        },
      ],
    },
    {
      productGroupName: 'Promotions & Savings',
      productList: [
        {
          groupName: 'Device savings',
          planIdProductIdMap: {
            63215: '71078',
            69185: '71132',
          },
        },
        {
          groupName: 'Verizon Home Internet',
          planIdProductIdMap: {
            63215: '71064',
            69185: '71025',
          },
        },
        {
          groupName: 'Connected Device Plan Discount',
          planIdProductIdMap: {
            69185: '71082',
          },
        },
      ],
    },
    {
      productGroupName: 'Perks',
      productList: [
        {
          groupName: 'Pick your own Perks',
          planIdProductIdMap: {
            63215: '71079',
            69185: '71079',
          },
        },
        {
          groupName: 'Disney Bundle',
          planIdProductIdMap: {
            63215: '71036',
            69185: '71036',
          },
        },
        {
          groupName: 'Netflix & Max (With Ads)',
          planIdProductIdMap: {
            63215: '71091',
            69185: '71091',
          },
        },
        {
          groupName: 'Apple One',
          planIdProductIdMap: {
            63215: '71039',
            69185: '71039',
          },
        },
        {
          groupName: 'Apple Music Family',
          planIdProductIdMap: {
            63215: '71040',
            69185: '71040',
          },
        },
        {
          groupName: 'YouTube Premium',
          planIdProductIdMap: {
            63215: '71134',
            69185: '71134',
          },
        },
        {
          groupName: '100 GB Mobile Hotspot',
          planIdProductIdMap: {
            63215: '71037',
            69185: '71037',
          },
        },
        {
          groupName: 'Cloud Storage',
          planIdProductIdMap: {
            63215: '71133',
            69185: '71133',
          },
        },
        {
          groupName: 'Google One AI Premium ',
          planIdProductIdMap: {
            63215: '71142',
            69185: '71142',
          },
        },
        {
          groupName: 'TravelPass Days',
          planIdProductIdMap: {
            63215: '71044',
          },
        },
      ],
    },
  ],
  productFeatureMap: {
    60007: {
      compareProductName: 'Unlimited',
      compareProductDesc:
        'Stay in touch and never worry about overage charges with unlimited Talk and Text on the network more people rely on.',
      compareProductWeightedValue: '3',
      compareProductSubGroupId: 'Talk & Text',
    },
    60027: {
      compareProductName: '480p SD',
      compareProductDesc: 'Video typically streams at 480p Standard Definition on smartphones.',
      compareProductWeightedValue: '480',
      compareProductSubGroupId: 'Streaming Quality',
    },
    70001: {
      compareProductName: 'Unlimited',
      compareProductDesc:
        'With no premium network access <br><br>When the network is experiencing heavy traffic, your data may be temporarily slowed.',
      compareProductWeightedValue: '100',
      compareProductSubGroupId: 'Data',
      disclaimerText: 'With no premium network access',
    },
    70005: {
      compareProductName: '5G Ultra Wideband',
      compareProductDesc:
        "5X faster than our regular 5G in the U.S., no matter how much you use.<br><br>Verizon 5G UWB median download speeds vs VZ low-band 5G median download speeds based on analysis by Verizon of Ookla® Speedtest Intelligence® data, Q1-Q2 2024. Explore our current <a target='_blank'  href='https://www.verizon.com/coverage-map/' classname='HandleMvaLink'>5G and 4G LTE coverage maps</a>.<br><br>Get access to the fastest speeds we offer with 5G Ultra Wideband. Combined with Verizon's 5G network, you get reliable coast to coast coverage. Download apps, games, entire playlists and TV series in seconds. You'll also get 5G Ultra Wideband mobile hotspot and crystal-clear 4K Ultra High Definition video streaming when activated on a capable device. Plus, access experiences from our exclusive 5G partners: Snapchat, Live Nation, Riot Games and Niantic. For full details, visit the <a target='_blank'  href='https://www.verizon.com/5g/' classname='HandleMvaLink'>5G experience page</a>.<br><br>5G Ultra Wideband access requires a 5G Ultra Wideband-capable device inside the 5G Ultra Wideband coverage area.",
      compareProductWeightedValue: '3',
      compareProductSubGroupId: 'Network',
      disclaimerText: 'Our fastest 5G network experience, 10X faster than 4G',
    },
    70006: {
      compareProductName: '5G',
      compareProductDesc:
        "Get unlimited access to our 5G network. When combined with 5G Ultra Wideband, you’ll get our fastest performance. When network is experiencing heavy traffic, your data may be temporarily slowed.<br><br>Requires a 5G-capable device inside Verizon's 5G coverage area.",
      compareProductWeightedValue: '2',
      compareProductSubGroupId: 'Network',
    },
    71025: {
      compareProductName: 'As low as $35/mo',
      compareProductDesc:
        'Get Fios for $35/mo w/ Auto Pay for existing postpaid mobile customers with a Verizon mobile plan (excludes prepaid, business and data-only plans) who then add and maintain a Fios 300 Mbps plan (where service is available). Mobile + Home Discount enrollment req’d. Get 5G Home and LTE Home for $35/mo w/ Auto Pay when combined with a postpaid mobile unlimited plan that includes 5G Ultra Wideband (where service is available).',
      compareProductWeightedValue: '50',
      compareProductSubGroupCopy: '50',
      compareProductSubGroupId: 'Verizon Home Internet',
    },
    71036: {
      compareProductName: 'Add for $10/mo',
      compareProductDesc:
        'Stream your favorite stories, originals and live sports with the Disney Bundle, featuring Disney+ (No Ads), Hulu (With Ads), and ESPN+ (With Ads).',
      compareProductWeightedValue: '2',
      spoIds: '2641',
      compareProductSubGroupId: 'Disney Bundle',
    },
    71037: {
      compareProductName: 'Add for $10/mo',
      compareProductDesc:
        'Get 100 GB of Mobile Hotspot data, allowing your smartphone to become a 5G / 4G Wi-Fi connection for devices like tablets, laptops and more.',
      compareProductWeightedValue: '1',
      spoIds: '2621',
      compareProductSubGroupId: '100 GB Mobile Hotspot',
    },
    71039: {
      compareProductName: 'Individual subscription Add for $10/mo<br><br>Family subscription Add for $20/mo',
      compareProductDesc:
        "All your Apple favorites, bundled together. That's Apple Music, Apple TV+, Apple Arcade and 50 GB of iCloud+.",
      compareProductWeightedValue: '4',
      compareProductSubGroupCopy: 'Available for Apple iOS devices',
      spoIds: '2678,2679',
      compareProductSubGroupId: 'Apple One',
    },
    71040: {
      compareProductName: 'Add for $10/mo',
      compareProductDesc:
        'Listen to 100+ million songs, ad-free, across all your devices. Hear sound all around with Spatial Audio. And try Apple Music Classical, featuring the world’s largest classical music catalog.',
      compareProductWeightedValue: '1',
      spoIds: '2677',
      compareProductSubGroupId: 'Apple Music Family',
    },
    71044: {
      compareProductName: '3/mo Add for $10/mo',
      compareProductDesc:
        'Get 3 TravelPass® days each month, accumulating up to 36 days each year. TravelPass days give you unlimited talk, text and data in more than 210+ countries for 24 hours, included each month for as long as you keep this perk. TravelPass® days expire 12 months after issue date.',
      compareProductWeightedValue: '3',
      spoIds: '2622',
      compareProductSubGroupId: 'TravelPass Days',
    },
    71064: {
      compareProductName: 'As low as $35/mo',
      compareProductDesc:
        'Get Fios $35/mo w/ Auto Pay for existing postpaid mobile customers with a Verizon mobile plan (excludes prepaid, business and data-only plans) who then add and maintain a Fios 300 Mbps plan (where service is available). Mobile + Home Discount enrollment req’d. Get 5G Home and LTE Home for $45/mo w/ Auto Pay when combined with a postpaid mobile unlimited plan (where service is available).',
      compareProductWeightedValue: '20',
      compareProductSubGroupId: 'Verizon Home Internet',
      disclaimerText: 'Service availability varies',
    },
    71076: {
      compareProductName: 'In Mexico & Canada',
      compareProductDesc:
        'Talk, text and use high-speed data when traveling in Mexico & Canada. After 2 GB/day, get unlimited 3G speeds.',
      compareProductWeightedValue: '1',
      compareProductSubGroupId: 'High-speed international data, talk & text',
    },
    71077: {
      compareProductName: 'To Mexico & Canada',
      compareProductDesc:
        'Includes unlimited talk and text to Mexico and Canada when you are in the US.<br><br>Unlimited texting from the US to over 200 countries and territories worldwide.',
      compareProductWeightedValue: '1',
      compareProductSubGroupId: "Int'l Talk & Text from the US",
    },
    71078: {
      compareProductName: 'Limited eligibility for new phone offers',
      compareProductDesc: 'Limited savings on smartphones.',
      compareProductWeightedValue: '1',
      compareProductSubGroupId: 'Device savings',
    },
    71079: {
      compareProductName: 'Yes',
      compareProductDesc: 'On myPlan, choose the perks you want. Only pay for what you need and save with each perk.',
      compareProductWeightedValue: '1',
      compareProductSubGroupId: 'Pick your own Perks',
    },
    71081: {
      compareProductName: '60 GB',
      compareProductDesc:
        'Get high-speed 5G/4G hotspot data that your other devices can use. Your smartphone becomes a Wi-Fi connection for devices like tablets, laptops and more.<br><br>After exceeding 60 GB/mo of 5G Ultra Wideband, 5G, or 4G LTE Mobile Hotspot data, you can still use hotspot at lower speeds of 3 Mbps when on 5G Ultra Wideband and 600 Kbps when on 5G / 4G LTE for the rest of the month. 5G access requires a 5G-capable device.',
      compareProductWeightedValue: '60',
      compareProductSubGroupId: 'Mobile Hotspot Data',
      disclaimerText:
        'After 60 GB of mobile hotspot data on Unlimited Ultimate and 30 GB on Unlimited Plus, speeds reduce to up to 3 Mbps on 5G Ultra Wideband, and 600 Kbps on 5G/4G LTE.',
    },
    71082: {
      compareProductName: 'Up to 50% off 2 data plans for a watch, tablet & more',
      compareProductDesc:
        'Get up to 50% off 2 eligible plans for qualifying smartwatch, tablet, hotspot or Hum in-car Wi-Fi devices. Eligible plans and discounts: 50% off Unlimited and More Unlimited for tablets; Essential and Plus plans for mobile hotspot devices; Unlimited for HumX; Unlimited + In Car WiFi for Hum+; and Unlimited and Number Share plans for smartwatches. $20 off Premium and Pro plans for mobile hotspot devices.',
      compareProductWeightedValue: '2',
      compareProductSubGroupId: 'Connected Device Plan Discount',
    },
    71086: {
      compareProductName: 'In 210+ countries',
      compareProductDesc:
        'Talk, text and use high-speed data when traveling in Mexico & Canada.  After 2 GB/day, get unlimited 3G speeds.<br><br>Plus, unlimited talk and text, and access high-speed data when traveling in 210+ countries and destinations. After 10 GB/mo of high-speed data, get unlimited 2G speeds.',
      compareProductWeightedValue: '2',
      compareProductSubGroupId: 'High-speed international data, talk & text',
    },
    71087: {
      compareProductName: 'Up to 1080p HD',
      compareProductDesc:
        'Video streaming defaults to 480p SD on smartphones, but you may choose to set your streaming to 1080p HD.',
      compareProductWeightedValue: '1080',
      compareProductSubGroupId: 'Streaming Quality',
    },
    71091: {
      compareProductName: 'Add for $10',
      compareProductDesc:
        'With the Netflix & Max (With Ads) bundle you can stream a wide variety of content on both services, including award-winning TV shows, movies, family favorites and more.',
      compareProductWeightedValue: '1',
      spoIds: '2839',
      compareProductSubGroupId: 'Netflix & Max (With Ads)',
    },
    71129: {
      compareProductName: 'Unlimited',
      compareProductDesc:
        'With unlimited premium network access <br><br> Get unlimited 5G / 4G LTE premium data per month.',
      compareProductWeightedValue: '200',
      compareProductSubGroupId: 'Data',
      disclaimerText: 'With unlimited premium network access',
    },
    71132: {
      compareProductName: 'Ultimate Phone Upgrade',
      compareProductDesc:
        'Both new and existing customers  are eligible to receive our best current in-market smartphone offer with trade-in, whether they upgrade an existing device or add a line to the Unlimited Ultimate plan.',
      compareProductWeightedValue: '3',
      compareProductSubGroupId: 'Device savings',
      disclaimerText: 'Ultimate Phone Upgrade',
    },
    71133: {
      compareProductName: 'Unlimited Individual Cloud Storage Add for $10/mo',
      compareProductDesc:
        'Securely store and access your photos, videos and more on all your devices. Includes unlimited storage for one user.',
      compareProductWeightedValue: '1',
      spoIds: '3199',
      compareProductSubGroupId: 'Cloud Storage',
    },
    71134: {
      compareProductName: 'Add for $10/mo',
      compareProductDesc:
        'Get all of YouTube, YouTube Music and YouTube Kids ad-free. Enjoy uninterrupted YouTube videos and music how and when you want; offline, on the go or in the background while using other apps.',
      compareProductWeightedValue: '1',
      spoIds: '3192',
      compareProductSubGroupId: 'YouTube Premium',
    },
    71139: {
      compareProductName: 'Always $0/mo',
      compareProductDesc:
        'Helps keep loved ones safe and connected. It features location sharing, Safe Walk with SOS, driving insights for the primary member, and monitoring of Verizon calls and texts. Additionally, the Verizon Network enables location sharing even when devices are not paired.',
      compareProductWeightedValue: '3',
      compareProductSubGroupId: 'Verizon Family',
    },
    71141: {
      compareProductName: 'To Mexico, Canada, +1 country of your choice',
      compareProductDesc:
        'Global Choice plan included. Choose one of the 140 countries and get a bundle of minutes to call that country.<br><br>Unlimited talk and text to Mexico and Canada when you are in the US.<br><br>Unlimited texting from the US to over 200 countries and territories worldwide.',
      compareProductWeightedValue: '2',
      compareProductSubGroupId: "Int'l Talk & Text from the US",
    },
    71142: {
      compareProductName: 'Add for $10/mo',
      compareProductDesc:
        'Get the best of Google AI and 2 TB of cloud storage with the Google One AI Premium plan. Learn, create, and work smarter with Gemini Advanced and Gemini in Gmail, Docs, and more.',
      compareProductWeightedValue: '1',
      spoIds: '3339',
      compareProductSubGroupId: 'Google One AI Premium ',
    },
  },
  comparePlanProductGroupName: 'Perks',
  getPerksinfo: {
    2621: {
      spoId: '2621',
      perkTitle: '100 GB Mobile Hotspot',
      perkInclusion: 'With this perk, you get 100 GB of mobile hotspot data.',
      perkOriginalPrice: '45.0',
      perkDuplicateWarningInd: false,
      eligiblePlanIds: ['63217', '63216', '63215', '63214', '69185', '69183'],
      perkLogo: 'https://ss7.vzw.com/is/content/VerizonWireless/perk-tile-mobile-hotspot-logo',
      perkToggle: false,
      perkBackgroundImage: 'perk-tile-mobile-hotspot',
      categoryCodes: ['NOREASSIGN', 'MHSPERK', 'MHSBLKMTX', 'NOTRANSFER', 'ADS', 'DONOTREACT', 'BYOPERK'],
      perkTextAppearance: 'Light',
      mutualExclusions: [],
      perkDescription: 'With this perk, you get 100 GB of mobile hotspot data.',
      perkBackgroundColor: '#F72B30;',
      perkCategory: ['All Perks', 'Popular', 'Network'],
    },
    2622: {
      spoId: '2622',
      perkTitle: '3 TravelPass Days',
      perkInclusion: 'Three TravelPass days (each a 24-hour session) are included each month.',
      perkOriginalPrice: '36.0',
      perkDuplicateWarningInd: false,
      eligiblePlanIds: ['63217', '63216', '63215', '63214', '58701', '58699'],
      perkLogo: 'https://ss7.vzw.com/is/content/VerizonWireless/perk-tile-three-travelpass-days-logo',
      perkToggle: false,
      perkBackgroundImage: 'perk-tile-three-travelpass-days',
      categoryCodes: ['NOREASSIGN', 'NOTRANSFER', 'AS', 'DONOTREACT', 'BYOPERK', 'TPBYOPERK'],
      perkTextAppearance: 'Light',
      perkDescription: 'Three TravelPass days (each a 24-hour session) are included each month.',
      perkBackgroundColor: '#000000;',
      perkCategory: ['All Perks', 'Network'],
    },
    2677: {
      spoId: '2677',
      perkTitle: 'Apple Music Family',
      perkInclusion:
        'With an Apple Music family subscription, up to six people can enjoy all the features and the full catalog of Apple Music, including their own personal music library and music recommendations based on what they love to listen to.',
      perkOriginalPrice: '16.99',
      perkDuplicateWarningInd: true,
      eligiblePlanIds: [
        '63217',
        '63216',
        '63215',
        '63214',
        '58701',
        '58699',
        '69185',
        '69183',
        '67571',
        '67576',
        '67567',
        '67568',
        '67577',
        '67584',
        '50127',
        '50129',
        '50044',
        '50116',
        '50010',
        '65655',
        '50128',
        '50130',
        '50055',
        '50117',
        '50011',
        '65656',
        '39425',
        '39428',
        '25878',
        '32525',
        '32523',
        '17542',
        '38365',
        '75560',
        '75561',
        '75565',
        '79601',
        '75322',
        '70535',
      ],
      perkLogo: 'https://ss7.vzw.com/is/content/VerizonWireless/perk-tile-apple-music-family-logo',
      perkToggle: false,
      perkBackgroundImage: 'perk-tile-apple-music-family',
      categoryCodes: [
        'NOREASSIGN',
        'BYOAPLMTX2',
        'NOTRANSFER',
        'SUBELIG',
        'VZMUSIC',
        'DONOTREACT',
        'AS',
        'BYOPERK',
        'BYOAPPLE',
      ],
      perkTextAppearance: 'Dark',
      mutualExclusions: ['2679', '2678'],
      perkDescription: 'Apple Music gives you access to over 100 million songs and 30,000 playlists, ad-free.',
      perkBackgroundColor: 'linear-gradient(236.93deg, #BEECF1 41.13%, #E5EACF 97.48%);',
      perkCategory: ['All Perks', 'Family'],
    },
    2678: {
      spoId: '2678',
      perkTitle: 'Apple One Individual',
      perkInclusion: 'Enjoy access to Apple Music, Apple TV+, Apple Arcade, and 50 GB of iCloud+.',
      perkOriginalPrice: '19.95',
      perkDuplicateWarningInd: false,
      eligiblePlanIds: [
        '63217',
        '63216',
        '63215',
        '63214',
        '58701',
        '58699',
        '69185',
        '69183',
        '67571',
        '67576',
        '67567',
        '67568',
        '67577',
        '67584',
        '50127',
        '50129',
        '50044',
        '50116',
        '50010',
        '65655',
        '50128',
        '50130',
        '50055',
        '50117',
        '50011',
        '65656',
        '39425',
        '39428',
        '25878',
        '32525',
        '32523',
        '17542',
        '38365',
        '75560',
        '75561',
        '75565',
        '79601',
        '75322',
        '70535',
      ],
      perkLogo: 'https://ss7.vzw.com/is/content/VerizonWireless/perk-tile-apple-one-logo',
      perkToggle: false,
      perkBackgroundImage: 'perk-tile-apple-one',
      categoryCodes: [
        'NOREASSIGN',
        'BYOAPLMTX3',
        'BYOAPLMTX1',
        'BYOAPLMTX2',
        'NOTRANSFER',
        'APONESNGL',
        'SUBELIG',
        'AS',
        'DONOTREACT',
        'BYOAPPLE',
        'BYOPERK',
        'APPLEONE',
      ],
      perkTextAppearance: 'Dark',
      groupBy: [
        {
          id: 'grpBy4001',
          spoSorIds: ['2678', '2679'],
          description: 'Individual subscription|Family subscription',
          displayName: 'Apple One',
          customerSegment: ['FWA', 'VZW', 'FIOS'],
        },
      ],
      mutualExclusions: ['2679', '2677'],
      perkDescription: 'Enjoy access to Apple Music, Apple TV+, Apple Arcade, and 50 GB of iCloud+.',
      perkBackgroundColor: '#F6F6F6;',
      perkCategory: ['All Perks', 'Popular', 'Family', 'Movies & TV'],
    },
    2679: {
      spoId: '2679',
      perkTitle: 'Apple One Family',
      perkInclusion: 'Enjoy access to Apple Music, Apple TV+, Apple Arcade, and shareable 200 GB of iCloud+.',
      perkOriginalPrice: '25.95',
      perkDuplicateWarningInd: true,
      eligiblePlanIds: [
        '63217',
        '63216',
        '63215',
        '63214',
        '58701',
        '58699',
        '69185',
        '69183',
        '67571',
        '67576',
        '67567',
        '67568',
        '67577',
        '67584',
        '50127',
        '50129',
        '50044',
        '50116',
        '50010',
        '65655',
        '50128',
        '50130',
        '50055',
        '50117',
        '50011',
        '65656',
        '39425',
        '39428',
        '25878',
        '32525',
        '32523',
        '17542',
        '38365',
        '75560',
        '75561',
        '75565',
        '79601',
        '75322',
        '70535',
      ],
      perkLogo: 'https://ss7.vzw.com/is/content/VerizonWireless/perk-tile-apple-one-logo',
      perkToggle: false,
      perkBackgroundImage: 'perk-tile-apple-one',
      categoryCodes: [
        'NOREASSIGN',
        'BYOAPLMTX3',
        'BYOAPLMTX1',
        'BYOAPLMTX2',
        'NOTRANSFER',
        'SUBELIG',
        'DONOTREACT',
        'AS',
        'BYOPERK',
        'APONEFMLY',
        'BYOAPPLE',
        'APPLEONE',
      ],
      perkTextAppearance: 'Dark',
      groupBy: [
        {
          id: 'grpBy4001',
          spoSorIds: ['2678', '2679'],
          description: 'Individual subscription|Family subscription',
          displayName: 'Apple One',
          customerSegment: ['FWA', 'VZW', 'FIOS'],
        },
      ],
      mutualExclusions: ['2678', '2677'],
      perkDescription: 'Enjoy access to Apple Music, Apple TV+, Apple Arcade, and shareable 200 GB of iCloud+.',
      perkBackgroundColor: '#F6F6F6;',
      perkCategory: ['All Perks'],
    },
    2839: {
      spoId: '2839',
      perkTitle: 'Netflix & Max (With Ads)',
      perkInclusion:
        'The Netflix & Max perk lets you stream a wide variety of award-winning TV shows, movies, fresh originals and more with subscriptions to Netflix Standard with Ads and Max (With Ads plan).',
      perkOriginalPrice: '16.98',
      perkDuplicateWarningInd: true,
      eligiblePlanIds: [
        '63217',
        '63216',
        '63215',
        '63214',
        '58701',
        '58699',
        '69183',
        '69185',
        '67571',
        '67567',
        '67577',
        '50127',
        '50129',
        '50044',
        '50116',
        '50010',
        '65655',
        '50128',
        '50130',
        '50055',
        '50117',
        '50011',
        '65656',
        '39425',
        '39428',
        '25878',
        '32525',
        '32523',
        '17542',
        '38365',
        '75560',
        '75561',
        '75565',
        '67568',
        '67584',
        '67576',
        '79601',
        '75322',
        '70535',
      ],
      perkLogo: 'https://ss7.vzw.com/is/content/verizon/20x20SVG_Transparent',
      perkToggle: false,
      perkBackgroundImage: 'perk-tile-net-max',
      categoryCodes: ['NOREASSIGN', 'NOTRANSFER', 'SUBELIG', 'AS', 'DONOTREACT', 'BYONETMAX', 'BYOPERK'],
      perkTextAppearance: 'Light',
      perkDescription:
        'With Netflix & Max (With Ads), you can stream a wide variety of content on both services, including award-winning TV shows, movies, family favorites and more.',
      perkBackgroundColor: 'linear-gradient(#040108, #490CA5)',
      perkCategory: ['All Perks', 'Popular', 'Family', 'Movies & TV'],
    },
    3192: {
      spoId: '3192',
      perkTitle: 'YouTube Premium',
      perkInclusion: 'Get all of YouTube, YouTube Music and YouTube Kids ad-free.',
      perkOriginalPrice: '13.99',
      perkDuplicateWarningInd: false,
      eligiblePlanIds: [
        '67571',
        '67576',
        '67567',
        '67568',
        '67577',
        '67584',
        '50127',
        '50129',
        '50044',
        '50116',
        '50010',
        '65655',
        '50128',
        '50130',
        '50055',
        '50117',
        '50011',
        '65656',
        '39425',
        '39428',
        '25878',
        '32525',
        '32523',
        '17542',
        '38365',
        '75560',
        '75561',
        '75565',
        '69185',
        '63217',
        '63215',
        '69183',
        '63216',
        '63214',
        '58701',
        '58699',
        '79601',
        '75322',
        '70535',
      ],
      perkLogo: 'https://ss7.vzw.com/is/content/VerizonWireless/perk-tile-youtube-premium-logo',
      perkToggle: false,
      perkBackgroundImage: 'perk-tile-youtube-premium',
      categoryCodes: ['NOREASSIGN', 'NOTRANSFER', 'SUBELIG', 'AS', 'DONOTREACT', 'BYOPERK', 'BYOYOUTUBE'],
      perkTextAppearance: 'Dark',
      perkDescription:
        'Get all of YouTube, YouTube Music and YouTube Kids ad-free. Enjoy uninterrupted YouTube videos and music how and when you want; offline, on the go or in the background while using other apps.',
      perkBackgroundColor:
        'linear-gradient(146deg, rgba(250,223,194,1) 0%, rgba(231,203,251,1) 35%, rgba(211,242,240,1) 100%);',
      perkCategory: ['All Perks', 'Family'],
    },
    3199: {
      spoId: '3199',
      perkTitle: 'Unlimited Individual Cloud Storage',
      perkInclusion: 'Includes unlimited cloud storage for one user.',
      perkOriginalPrice: '13.99',
      perkDuplicateWarningInd: false,
      eligiblePlanIds: [
        '63217',
        '63216',
        '63215',
        '63214',
        '58701',
        '58699',
        '69183',
        '69185',
        '67571',
        '67567',
        '67577',
        '50127',
        '50044',
        '50010',
        '50128',
        '50055',
        '50011',
        '39425',
        '39428',
        '25878',
        '32525',
        '32523',
        '17542',
        '38365',
        '75560',
        '75561',
        '75565',
        '79601',
        '75322',
        '70535',
      ],
      perkLogo: 'https://ss7.vzw.com/is/content/VerizonWireless/perk-tile-unlimited-cloud-storage-logo',
      perkToggle: false,
      perkBackgroundImage: 'perk-tile-unlimited-cloud-storage',
      categoryCodes: ['BYOCLDUNLI', 'NOREASSIGN', 'BYOCLOUD', 'BYOCLDMTX', 'NOTRANSFER', 'VT', 'DONOTREACT', 'BYOPERK'],
      perkTextAppearance: 'Light',
      groupBy: [
        {
          id: 'grpBy8017',
          spoSorIds: ['3199', '3198'],
          description: 'Individual storage|Group storage',
          displayName: 'Unlimited Cloud Storage',
          customerSegment: ['FWA', 'FIOS'],
        },
      ],
      mutualExclusions: [],
      perkDescription:
        'Securely store and access your photos, videos and more on all your compatible devices. Includes unlimited storage for one user.',
      perkBackgroundColor: '#EE0000;',
      perkCategory: ['All Perks', 'Network'],
    },
    3339: {
      spoId: '3339',
      perkTitle: 'Google One AI Premium',
      perkInclusion:
        "Unlock Google's next-gen AI with Gemini Advanced and get Gemini in Gmail, Docs, and more. Plus, you get 2 TB of cloud storage – all included with the Google One AI Premium plan.",
      perkOriginalPrice: '19.99',
      perkDuplicateWarningInd: true,
      eligiblePlanIds: [
        '67571',
        '67576',
        '67567',
        '67568',
        '67577',
        '67584',
        '50127',
        '50129',
        '50044',
        '50116',
        '50010',
        '65655',
        '50128',
        '50130',
        '50055',
        '50117',
        '50011',
        '65656',
        '39425',
        '39428',
        '25878',
        '32525',
        '32523',
        '17542',
        '38365',
        '75560',
        '75561',
        '75565',
        '79601',
        '75322',
        '70535',
        '69185',
        '69183',
        '63217',
        '63216',
        '63215',
        '63214',
        '58701',
        '58689',
      ],
      perkLogo: 'https://ss7.vzw.com/is/content/VerizonWireless/perk-tile-google-one-ai-premium-logo',
      perkToggle: false,
      perkBackgroundImage: 'perk-tile-google-one-ai-premium',
      categoryCodes: ['NOREASSIGN', 'NOTRANSFER', 'SUBELIG', 'AS', 'DONOTREACT', 'BYOGOOGLE1', 'BYOPERK'],
      perkTextAppearance: 'Light',
      perkDescription:
        "Unlock Google's next-gen AI with Gemini Advanced and get Gemini in Gmail, Docs, and more. Plus, you get 2 TB of cloud storage – all included with the Google One AI Premium plan.",
      perkBackgroundColor: '#202124;',
      perkCategory: ['All Perks', 'Family'],
    },
  },
  CompareToConnect: 'CompareToConnect',
};

const props1 = {
  isDark: 'true',
  currentOpenRow: 1,
  rowid: 20,
  setCurrentRow: jest.fn(),
  planIdProductIdMap: {
    groupName: 'TravelPass Days',
    planIdProductIdMap: {
      63215: '71044',
    },
  },
  selectedPerks: [],
  planIds: ['69185', '63215'],
  productFeatureMap: {
    60007: {
      compareProductName: 'Unlimited',
      compareProductDesc:
        'Stay in touch and never worry about overage charges with unlimited Talk and Text on the network more people rely on.',
      compareProductWeightedValue: '3',
      compareProductSubGroupId: 'Talk & Text',
    },
    60027: {
      compareProductName: '480p SD',
      compareProductDesc: 'Video typically streams at 480p Standard Definition on smartphones.',
      compareProductWeightedValue: '480',
      compareProductSubGroupId: 'Streaming Quality',
    },
    70001: {
      compareProductName: 'Unlimited',
      compareProductDesc:
        'With no premium network access <br><br>When the network is experiencing heavy traffic, your data may be temporarily slowed.',
      compareProductWeightedValue: '100',
      compareProductSubGroupId: 'Data',
      disclaimerText: 'With no premium network access',
    },
    70005: {
      compareProductName: '5G Ultra Wideband',
      compareProductDesc:
        "5X faster than our regular 5G in the U.S., no matter how much you use.<br><br>Verizon 5G UWB median download speeds vs VZ low-band 5G median download speeds based on analysis by Verizon of Ookla® Speedtest Intelligence® data, Q1-Q2 2024. Explore our current <a target='_blank'  href='https://www.verizon.com/coverage-map/' classname='HandleMvaLink'>5G and 4G LTE coverage maps</a>.<br><br>Get access to the fastest speeds we offer with 5G Ultra Wideband. Combined with Verizon's 5G network, you get reliable coast to coast coverage. Download apps, games, entire playlists and TV series in seconds. You'll also get 5G Ultra Wideband mobile hotspot and crystal-clear 4K Ultra High Definition video streaming when activated on a capable device. Plus, access experiences from our exclusive 5G partners: Snapchat, Live Nation, Riot Games and Niantic. For full details, visit the <a target='_blank'  href='https://www.verizon.com/5g/' classname='HandleMvaLink'>5G experience page</a>.<br><br>5G Ultra Wideband access requires a 5G Ultra Wideband-capable device inside the 5G Ultra Wideband coverage area.",
      compareProductWeightedValue: '3',
      compareProductSubGroupId: 'Network',
      disclaimerText: 'Our fastest 5G network experience, 10X faster than 4G',
    },
    70006: {
      compareProductName: '5G',
      compareProductDesc:
        "Get unlimited access to our 5G network. When combined with 5G Ultra Wideband, you’ll get our fastest performance. When network is experiencing heavy traffic, your data may be temporarily slowed.<br><br>Requires a 5G-capable device inside Verizon's 5G coverage area.",
      compareProductWeightedValue: '2',
      compareProductSubGroupId: 'Network',
    },
    71025: {
      compareProductName: 'As low as $35/mo',
      compareProductDesc:
        'Get Fios for $35/mo w/ Auto Pay for existing postpaid mobile customers with a Verizon mobile plan (excludes prepaid, business and data-only plans) who then add and maintain a Fios 300 Mbps plan (where service is available). Mobile + Home Discount enrollment req’d. Get 5G Home and LTE Home for $35/mo w/ Auto Pay when combined with a postpaid mobile unlimited plan that includes 5G Ultra Wideband (where service is available).',
      compareProductWeightedValue: '50',
      compareProductSubGroupCopy: '50',
      compareProductSubGroupId: 'Verizon Home Internet',
    },
    71036: {
      compareProductName: 'Add for $10/mo',
      compareProductDesc:
        'Stream your favorite stories, originals and live sports with the Disney Bundle, featuring Disney+ (No Ads), Hulu (With Ads), and ESPN+ (With Ads).',
      compareProductWeightedValue: '2',
      spoIds: '2641',
      compareProductSubGroupId: 'Disney Bundle',
    },
    71037: {
      compareProductName: 'Add for $10/mo',
      compareProductDesc:
        'Get 100 GB of Mobile Hotspot data, allowing your smartphone to become a 5G / 4G Wi-Fi connection for devices like tablets, laptops and more.',
      compareProductWeightedValue: '1',
      spoIds: '2621',
      compareProductSubGroupId: '100 GB Mobile Hotspot',
    },
    71039: {
      compareProductName: 'Individual subscription Add for $10/mo<br><br>Family subscription Add for $20/mo',
      compareProductDesc:
        "All your Apple favorites, bundled together. That's Apple Music, Apple TV+, Apple Arcade and 50 GB of iCloud+.",
      compareProductWeightedValue: '4',
      compareProductSubGroupCopy: 'Available for Apple iOS devices',
      spoIds: '2678,2679',
      compareProductSubGroupId: 'Apple One',
    },
    71040: {
      compareProductName: 'Add for $10/mo',
      compareProductDesc:
        'Listen to 100+ million songs, ad-free, across all your devices. Hear sound all around with Spatial Audio. And try Apple Music Classical, featuring the world’s largest classical music catalog.',
      compareProductWeightedValue: '1',
      spoIds: '2677',
      compareProductSubGroupId: 'Apple Music Family',
    },
    71044: {
      compareProductName: '3/mo Add for $10/mo',
      compareProductDesc:
        'Get 3 TravelPass® days each month, accumulating up to 36 days each year. TravelPass days give you unlimited talk, text and data in more than 210+ countries for 24 hours, included each month for as long as you keep this perk. TravelPass® days expire 12 months after issue date.',
      compareProductWeightedValue: '3',
      spoIds: '2622',
      compareProductSubGroupId: 'TravelPass Days',
    },
    71064: {
      compareProductName: 'As low as $35/mo',
      compareProductDesc:
        'Get Fios $35/mo w/ Auto Pay for existing postpaid mobile customers with a Verizon mobile plan (excludes prepaid, business and data-only plans) who then add and maintain a Fios 300 Mbps plan (where service is available). Mobile + Home Discount enrollment req’d. Get 5G Home and LTE Home for $45/mo w/ Auto Pay when combined with a postpaid mobile unlimited plan (where service is available).',
      compareProductWeightedValue: '20',
      compareProductSubGroupId: 'Verizon Home Internet',
      disclaimerText: 'Service availability varies',
    },
    71076: {
      compareProductName: 'In Mexico & Canada',
      compareProductDesc:
        'Talk, text and use high-speed data when traveling in Mexico & Canada. After 2 GB/day, get unlimited 3G speeds.',
      compareProductWeightedValue: '1',
      compareProductSubGroupId: 'High-speed international data, talk & text',
    },
    71077: {
      compareProductName: 'To Mexico & Canada',
      compareProductDesc:
        'Includes unlimited talk and text to Mexico and Canada when you are in the US.<br><br>Unlimited texting from the US to over 200 countries and territories worldwide.',
      compareProductWeightedValue: '1',
      compareProductSubGroupId: "Int'l Talk & Text from the US",
    },
    71078: {
      compareProductName: 'Limited eligibility for new phone offers',
      compareProductDesc: 'Limited savings on smartphones.',
      compareProductWeightedValue: '1',
      compareProductSubGroupId: 'Device savings',
    },
    71079: {
      compareProductName: 'Yes',
      compareProductDesc: 'On myPlan, choose the perks you want. Only pay for what you need and save with each perk.',
      compareProductWeightedValue: '1',
      compareProductSubGroupId: 'Pick your own Perks',
    },
    71081: {
      compareProductName: '60 GB',
      compareProductDesc:
        'Get high-speed 5G/4G hotspot data that your other devices can use. Your smartphone becomes a Wi-Fi connection for devices like tablets, laptops and more.<br><br>After exceeding 60 GB/mo of 5G Ultra Wideband, 5G, or 4G LTE Mobile Hotspot data, you can still use hotspot at lower speeds of 3 Mbps when on 5G Ultra Wideband and 600 Kbps when on 5G / 4G LTE for the rest of the month. 5G access requires a 5G-capable device.',
      compareProductWeightedValue: '60',
      compareProductSubGroupId: 'Mobile Hotspot Data',
      disclaimerText:
        'After 60 GB of mobile hotspot data on Unlimited Ultimate and 30 GB on Unlimited Plus, speeds reduce to up to 3 Mbps on 5G Ultra Wideband, and 600 Kbps on 5G/4G LTE.',
    },
    71082: {
      compareProductName: 'Up to 50% off 2 data plans for a watch, tablet & more',
      compareProductDesc:
        'Get up to 50% off 2 eligible plans for qualifying smartwatch, tablet, hotspot or Hum in-car Wi-Fi devices. Eligible plans and discounts: 50% off Unlimited and More Unlimited for tablets; Essential and Plus plans for mobile hotspot devices; Unlimited for HumX; Unlimited + In Car WiFi for Hum+; and Unlimited and Number Share plans for smartwatches. $20 off Premium and Pro plans for mobile hotspot devices.',
      compareProductWeightedValue: '2',
      compareProductSubGroupId: 'Connected Device Plan Discount',
    },
    71086: {
      compareProductName: 'In 210+ countries',
      compareProductDesc:
        'Talk, text and use high-speed data when traveling in Mexico & Canada.  After 2 GB/day, get unlimited 3G speeds.<br><br>Plus, unlimited talk and text, and access high-speed data when traveling in 210+ countries and destinations. After 10 GB/mo of high-speed data, get unlimited 2G speeds.',
      compareProductWeightedValue: '2',
      compareProductSubGroupId: 'High-speed international data, talk & text',
    },
    71087: {
      compareProductName: 'Up to 1080p HD',
      compareProductDesc:
        'Video streaming defaults to 480p SD on smartphones, but you may choose to set your streaming to 1080p HD.',
      compareProductWeightedValue: '1080',
      compareProductSubGroupId: 'Streaming Quality',
    },
    71091: {
      compareProductName: 'Add for $10',
      compareProductDesc:
        'With the Netflix & Max (With Ads) bundle you can stream a wide variety of content on both services, including award-winning TV shows, movies, family favorites and more.',
      compareProductWeightedValue: '1',
      spoIds: '2839',
      compareProductSubGroupId: 'Netflix & Max (With Ads)',
    },
    71129: {
      compareProductName: 'Unlimited',
      compareProductDesc:
        'With unlimited premium network access <br><br> Get unlimited 5G / 4G LTE premium data per month.',
      compareProductWeightedValue: '200',
      compareProductSubGroupId: 'Data',
      disclaimerText: 'With unlimited premium network access',
    },
    71132: {
      compareProductName: 'Ultimate Phone Upgrade',
      compareProductDesc:
        'Both new and existing customers  are eligible to receive our best current in-market smartphone offer with trade-in, whether they upgrade an existing device or add a line to the Unlimited Ultimate plan.',
      compareProductWeightedValue: '3',
      compareProductSubGroupId: 'Device savings',
      disclaimerText: 'Ultimate Phone Upgrade',
    },
    71133: {
      compareProductName: 'Unlimited Individual Cloud Storage Add for $10/mo',
      compareProductDesc:
        'Securely store and access your photos, videos and more on all your devices. Includes unlimited storage for one user.',
      compareProductWeightedValue: '1',
      spoIds: '3199',
      compareProductSubGroupId: 'Cloud Storage',
    },
    71134: {
      compareProductName: 'Add for $10/mo',
      compareProductDesc:
        'Get all of YouTube, YouTube Music and YouTube Kids ad-free. Enjoy uninterrupted YouTube videos and music how and when you want; offline, on the go or in the background while using other apps.',
      compareProductWeightedValue: '1',
      spoIds: '3192',
      compareProductSubGroupId: 'YouTube Premium',
    },
    71139: {
      compareProductName: 'Always $0/mo',
      compareProductDesc:
        'Helps keep loved ones safe and connected. It features location sharing, Safe Walk with SOS, driving insights for the primary member, and monitoring of Verizon calls and texts. Additionally, the Verizon Network enables location sharing even when devices are not paired.',
      compareProductWeightedValue: '3',
      compareProductSubGroupId: 'Verizon Family',
    },
    71141: {
      compareProductName: 'To Mexico, Canada, +1 country of your choice',
      compareProductDesc:
        'Global Choice plan included. Choose one of the 140 countries and get a bundle of minutes to call that country.<br><br>Unlimited talk and text to Mexico and Canada when you are in the US.<br><br>Unlimited texting from the US to over 200 countries and territories worldwide.',
      compareProductWeightedValue: '2',
      compareProductSubGroupId: "Int'l Talk & Text from the US",
    },
    71142: {
      compareProductName: 'Add for $10/mo',
      compareProductDesc:
        'Get the best of Google AI and 2 TB of cloud storage with the Google One AI Premium plan. Learn, create, and work smarter with Gemini Advanced and Gemini in Gmail, Docs, and more.',
      compareProductWeightedValue: '1',
      spoIds: '3339',
      compareProductSubGroupId: 'Google One AI Premium ',
    },
  },
  comparePlanProductGroupName: 'Perks',
  getPerksinfo: {
    2621: {
      spoId: '2621',
      perkTitle: '100 GB Mobile Hotspot',
      perkInclusion: 'With this perk, you get 100 GB of mobile hotspot data.',
      perkOriginalPrice: '45.0',
      perkDuplicateWarningInd: false,
      eligiblePlanIds: ['63217', '63216', '63215', '63214', '69185', '69183'],
      perkLogo: 'https://ss7.vzw.com/is/content/VerizonWireless/perk-tile-mobile-hotspot-logo',
      perkToggle: false,
      perkBackgroundImage: 'perk-tile-mobile-hotspot',
      categoryCodes: ['NOREASSIGN', 'MHSPERK', 'MHSBLKMTX', 'NOTRANSFER', 'ADS', 'DONOTREACT', 'BYOPERK'],
      perkTextAppearance: 'Light',
      mutualExclusions: [],
      perkDescription: 'With this perk, you get 100 GB of mobile hotspot data.',
      perkBackgroundColor: '#F72B30;',
      perkCategory: ['All Perks', 'Popular', 'Network'],
    },
    2622: {
      spoId: '2622',
      perkTitle: '3 TravelPass Days',
      perkInclusion: 'Three TravelPass days (each a 24-hour session) are included each month.',
      perkOriginalPrice: '36.0',
      perkDuplicateWarningInd: false,
      eligiblePlanIds: ['63217', '63216', '63215', '63214', '58701', '58699'],
      perkLogo: 'https://ss7.vzw.com/is/content/VerizonWireless/perk-tile-three-travelpass-days-logo',
      perkToggle: false,
      perkBackgroundImage: 'perk-tile-three-travelpass-days',
      categoryCodes: ['NOREASSIGN', 'NOTRANSFER', 'AS', 'DONOTREACT', 'BYOPERK', 'TPBYOPERK'],
      perkTextAppearance: 'Light',
      perkDescription: 'Three TravelPass days (each a 24-hour session) are included each month.',
      perkBackgroundColor: '#000000;',
      perkCategory: ['All Perks', 'Network'],
    },
    2677: {
      spoId: '2677',
      perkTitle: 'Apple Music Family',
      perkInclusion:
        'With an Apple Music family subscription, up to six people can enjoy all the features and the full catalog of Apple Music, including their own personal music library and music recommendations based on what they love to listen to.',
      perkOriginalPrice: '16.99',
      perkDuplicateWarningInd: true,
      eligiblePlanIds: [
        '63217',
        '63216',
        '63215',
        '63214',
        '58701',
        '58699',
        '69185',
        '69183',
        '67571',
        '67576',
        '67567',
        '67568',
        '67577',
        '67584',
        '50127',
        '50129',
        '50044',
        '50116',
        '50010',
        '65655',
        '50128',
        '50130',
        '50055',
        '50117',
        '50011',
        '65656',
        '39425',
        '39428',
        '25878',
        '32525',
        '32523',
        '17542',
        '38365',
        '75560',
        '75561',
        '75565',
        '79601',
        '75322',
        '70535',
      ],
      perkLogo: 'https://ss7.vzw.com/is/content/VerizonWireless/perk-tile-apple-music-family-logo',
      perkToggle: false,
      perkBackgroundImage: 'perk-tile-apple-music-family',
      categoryCodes: [
        'NOREASSIGN',
        'BYOAPLMTX2',
        'NOTRANSFER',
        'SUBELIG',
        'VZMUSIC',
        'DONOTREACT',
        'AS',
        'BYOPERK',
        'BYOAPPLE',
      ],
      perkTextAppearance: 'Dark',
      mutualExclusions: ['2679', '2678'],
      perkDescription: 'Apple Music gives you access to over 100 million songs and 30,000 playlists, ad-free.',
      perkBackgroundColor: 'linear-gradient(236.93deg, #BEECF1 41.13%, #E5EACF 97.48%);',
      perkCategory: ['All Perks', 'Family'],
    },
    2678: {
      spoId: '2678',
      perkTitle: 'Apple One Individual',
      perkInclusion: 'Enjoy access to Apple Music, Apple TV+, Apple Arcade, and 50 GB of iCloud+.',
      perkOriginalPrice: '19.95',
      perkDuplicateWarningInd: false,
      eligiblePlanIds: [
        '63217',
        '63216',
        '63215',
        '63214',
        '58701',
        '58699',
        '69185',
        '69183',
        '67571',
        '67576',
        '67567',
        '67568',
        '67577',
        '67584',
        '50127',
        '50129',
        '50044',
        '50116',
        '50010',
        '65655',
        '50128',
        '50130',
        '50055',
        '50117',
        '50011',
        '65656',
        '39425',
        '39428',
        '25878',
        '32525',
        '32523',
        '17542',
        '38365',
        '75560',
        '75561',
        '75565',
        '79601',
        '75322',
        '70535',
      ],
      perkLogo: 'https://ss7.vzw.com/is/content/VerizonWireless/perk-tile-apple-one-logo',
      perkToggle: false,
      perkBackgroundImage: 'perk-tile-apple-one',
      categoryCodes: [
        'NOREASSIGN',
        'BYOAPLMTX3',
        'BYOAPLMTX1',
        'BYOAPLMTX2',
        'NOTRANSFER',
        'APONESNGL',
        'SUBELIG',
        'AS',
        'DONOTREACT',
        'BYOAPPLE',
        'BYOPERK',
        'APPLEONE',
      ],
      perkTextAppearance: 'Dark',
      groupBy: [
        {
          id: 'grpBy4001',
          spoSorIds: ['2678', '2679'],
          description: 'Individual subscription|Family subscription',
          displayName: 'Apple One',
          customerSegment: ['FWA', 'VZW', 'FIOS'],
        },
      ],
      mutualExclusions: ['2679', '2677'],
      perkDescription: 'Enjoy access to Apple Music, Apple TV+, Apple Arcade, and 50 GB of iCloud+.',
      perkBackgroundColor: '#F6F6F6;',
      perkCategory: ['All Perks', 'Popular', 'Family', 'Movies & TV'],
    },
    2679: {
      spoId: '2679',
      perkTitle: 'Apple One Family',
      perkInclusion: 'Enjoy access to Apple Music, Apple TV+, Apple Arcade, and shareable 200 GB of iCloud+.',
      perkOriginalPrice: '25.95',
      perkDuplicateWarningInd: true,
      eligiblePlanIds: [
        '63217',
        '63216',
        '63215',
        '63214',
        '58701',
        '58699',
        '69185',
        '69183',
        '67571',
        '67576',
        '67567',
        '67568',
        '67577',
        '67584',
        '50127',
        '50129',
        '50044',
        '50116',
        '50010',
        '65655',
        '50128',
        '50130',
        '50055',
        '50117',
        '50011',
        '65656',
        '39425',
        '39428',
        '25878',
        '32525',
        '32523',
        '17542',
        '38365',
        '75560',
        '75561',
        '75565',
        '79601',
        '75322',
        '70535',
      ],
      perkLogo: 'https://ss7.vzw.com/is/content/VerizonWireless/perk-tile-apple-one-logo',
      perkToggle: false,
      perkBackgroundImage: 'perk-tile-apple-one',
      categoryCodes: [
        'NOREASSIGN',
        'BYOAPLMTX3',
        'BYOAPLMTX1',
        'BYOAPLMTX2',
        'NOTRANSFER',
        'SUBELIG',
        'DONOTREACT',
        'AS',
        'BYOPERK',
        'APONEFMLY',
        'BYOAPPLE',
        'APPLEONE',
      ],
      perkTextAppearance: 'Dark',
      groupBy: [
        {
          id: 'grpBy4001',
          spoSorIds: ['2678', '2679'],
          description: 'Individual subscription|Family subscription',
          displayName: 'Apple One',
          customerSegment: ['FWA', 'VZW', 'FIOS'],
        },
      ],
      mutualExclusions: ['2678', '2677'],
      perkDescription: 'Enjoy access to Apple Music, Apple TV+, Apple Arcade, and shareable 200 GB of iCloud+.',
      perkBackgroundColor: '#F6F6F6;',
      perkCategory: ['All Perks'],
    },
    2839: {
      spoId: '2839',
      perkTitle: 'Netflix & Max (With Ads)',
      perkInclusion:
        'The Netflix & Max perk lets you stream a wide variety of award-winning TV shows, movies, fresh originals and more with subscriptions to Netflix Standard with Ads and Max (With Ads plan).',
      perkOriginalPrice: '16.98',
      perkDuplicateWarningInd: true,
      eligiblePlanIds: [
        '63217',
        '63216',
        '63215',
        '63214',
        '58701',
        '58699',
        '69183',
        '69185',
        '67571',
        '67567',
        '67577',
        '50127',
        '50129',
        '50044',
        '50116',
        '50010',
        '65655',
        '50128',
        '50130',
        '50055',
        '50117',
        '50011',
        '65656',
        '39425',
        '39428',
        '25878',
        '32525',
        '32523',
        '17542',
        '38365',
        '75560',
        '75561',
        '75565',
        '67568',
        '67584',
        '67576',
        '79601',
        '75322',
        '70535',
      ],
      perkLogo: 'https://ss7.vzw.com/is/content/verizon/20x20SVG_Transparent',
      perkToggle: false,
      perkBackgroundImage: 'perk-tile-net-max',
      categoryCodes: ['NOREASSIGN', 'NOTRANSFER', 'SUBELIG', 'AS', 'DONOTREACT', 'BYONETMAX', 'BYOPERK'],
      perkTextAppearance: 'Light',
      perkDescription:
        'With Netflix & Max (With Ads), you can stream a wide variety of content on both services, including award-winning TV shows, movies, family favorites and more.',
      perkBackgroundColor: 'linear-gradient(#040108, #490CA5)',
      perkCategory: ['All Perks', 'Popular', 'Family', 'Movies & TV'],
    },
    3192: {
      spoId: '3192',
      perkTitle: 'YouTube Premium',
      perkInclusion: 'Get all of YouTube, YouTube Music and YouTube Kids ad-free.',
      perkOriginalPrice: '13.99',
      perkDuplicateWarningInd: false,
      eligiblePlanIds: [
        '67571',
        '67576',
        '67567',
        '67568',
        '67577',
        '67584',
        '50127',
        '50129',
        '50044',
        '50116',
        '50010',
        '65655',
        '50128',
        '50130',
        '50055',
        '50117',
        '50011',
        '65656',
        '39425',
        '39428',
        '25878',
        '32525',
        '32523',
        '17542',
        '38365',
        '75560',
        '75561',
        '75565',
        '69185',
        '63217',
        '63215',
        '69183',
        '63216',
        '63214',
        '58701',
        '58699',
        '79601',
        '75322',
        '70535',
      ],
      perkLogo: 'https://ss7.vzw.com/is/content/VerizonWireless/perk-tile-youtube-premium-logo',
      perkToggle: false,
      perkBackgroundImage: 'perk-tile-youtube-premium',
      categoryCodes: ['NOREASSIGN', 'NOTRANSFER', 'SUBELIG', 'AS', 'DONOTREACT', 'BYOPERK', 'BYOYOUTUBE'],
      perkTextAppearance: 'Dark',
      perkDescription:
        'Get all of YouTube, YouTube Music and YouTube Kids ad-free. Enjoy uninterrupted YouTube videos and music how and when you want; offline, on the go or in the background while using other apps.',
      perkBackgroundColor:
        'linear-gradient(146deg, rgba(250,223,194,1) 0%, rgba(231,203,251,1) 35%, rgba(211,242,240,1) 100%);',
      perkCategory: ['All Perks', 'Family'],
    },
    3199: {
      spoId: '3199',
      perkTitle: 'Unlimited Individual Cloud Storage',
      perkInclusion: 'Includes unlimited cloud storage for one user.',
      perkOriginalPrice: '13.99',
      perkDuplicateWarningInd: false,
      eligiblePlanIds: [
        '63217',
        '63216',
        '63215',
        '63214',
        '58701',
        '58699',
        '69183',
        '69185',
        '67571',
        '67567',
        '67577',
        '50127',
        '50044',
        '50010',
        '50128',
        '50055',
        '50011',
        '39425',
        '39428',
        '25878',
        '32525',
        '32523',
        '17542',
        '38365',
        '75560',
        '75561',
        '75565',
        '79601',
        '75322',
        '70535',
      ],
      perkLogo: 'https://ss7.vzw.com/is/content/VerizonWireless/perk-tile-unlimited-cloud-storage-logo',
      perkToggle: false,
      perkBackgroundImage: 'perk-tile-unlimited-cloud-storage',
      categoryCodes: ['BYOCLDUNLI', 'NOREASSIGN', 'BYOCLOUD', 'BYOCLDMTX', 'NOTRANSFER', 'VT', 'DONOTREACT', 'BYOPERK'],
      perkTextAppearance: 'Light',
      groupBy: [
        {
          id: 'grpBy8017',
          spoSorIds: ['3199', '3198'],
          description: 'Individual storage|Group storage',
          displayName: 'Unlimited Cloud Storage',
          customerSegment: ['FWA', 'FIOS'],
        },
      ],
      mutualExclusions: [],
      perkDescription:
        'Securely store and access your photos, videos and more on all your compatible devices. Includes unlimited storage for one user.',
      perkBackgroundColor: '#EE0000;',
      perkCategory: ['All Perks', 'Network'],
    },
    3339: {
      spoId: '3339',
      perkTitle: 'Google One AI Premium',
      perkInclusion:
        "Unlock Google's next-gen AI with Gemini Advanced and get Gemini in Gmail, Docs, and more. Plus, you get 2 TB of cloud storage – all included with the Google One AI Premium plan.",
      perkOriginalPrice: '19.99',
      perkDuplicateWarningInd: true,
      eligiblePlanIds: [
        '67571',
        '67576',
        '67567',
        '67568',
        '67577',
        '67584',
        '50127',
        '50129',
        '50044',
        '50116',
        '50010',
        '65655',
        '50128',
        '50130',
        '50055',
        '50117',
        '50011',
        '65656',
        '39425',
        '39428',
        '25878',
        '32525',
        '32523',
        '17542',
        '38365',
        '75560',
        '75561',
        '75565',
        '79601',
        '75322',
        '70535',
        '69185',
        '69183',
        '63217',
        '63216',
        '63215',
        '63214',
        '58701',
        '58689',
      ],
      perkLogo: 'https://ss7.vzw.com/is/content/VerizonWireless/perk-tile-google-one-ai-premium-logo',
      perkToggle: false,
      perkBackgroundImage: 'perk-tile-google-one-ai-premium',
      categoryCodes: ['NOREASSIGN', 'NOTRANSFER', 'SUBELIG', 'AS', 'DONOTREACT', 'BYOGOOGLE1', 'BYOPERK'],
      perkTextAppearance: 'Light',
      perkDescription:
        "Unlock Google's next-gen AI with Gemini Advanced and get Gemini in Gmail, Docs, and more. Plus, you get 2 TB of cloud storage – all included with the Google One AI Premium plan.",
      perkBackgroundColor: '#202124;',
      perkCategory: ['All Perks', 'Family'],
    },
  },
  CompareToConnect: 'CompareToConnect',
};

jest.mock(
  'onevzsoemfecommon/PlanAPIService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/PlanAPIService'),
    useLazyComparePlansQuery: jest.fn(),
  }),
  { virtual: true },
);
jest.mock('react-redux', () => ({
  ...jest.requireActual('react-redux'),
  useSelector: jest.fn(),
}));

const mockState = {
  plans: {
    data: accordionRedux1,
  },
};

const mockState1 = {
  plans: {
    data: accordionRedux2,
  },
};

describe('ComparePlans Conditional Rendering1', () => {
  beforeEach(() => {
    const mockLazyQuery = jest.fn();

    useSelector.mockImplementation((selector) => selector(mockState));
    useLazyComparePlansQuery.mockReturnValue([
      mockLazyQuery,
      {
        status: 'fulfilled',
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: false,
        isFetching: false,
      },
    ]);
    const initialState = {};
    const plansSlice = createSlice({
      name: 'plans',
      initialState,
      reducers: {
        plansdata: (state, action) => action.payload,
      },
    });

    const store = configureAppStore({ plans: plansSlice.reducer }, rootSaga);
    render(
      <Provider store={store}>
        <AccordionRow {...props1} />,
      </Provider>,
      {
        reducers: {
          plans: plansSlice.reducer,
        },
        sagas: rootSaga,
        preloadedState: {},
      },
    );
  });

  test('should return false when perk is not found', () => {
    const isAddedLabel = (perk, id) => perk === 'Unknown Perk' && id === '999';
    const result = isAddedLabel('Unknown Perk', '999');

    expect(result).toBe(true);
  });

  test('should render highlighted body when index is 1', async () => {
    const index = 1;

    const isAddedLable = jest.fn(); // Mock function
    if (comparePlanProductGroupName === 'Perks' && index === 1 && isAddedLable('5G', '1')) {
      const addedText = screen.getByText('Added');
      expect(addedText).toBeInTheDocument();
    }
    screen.logTestingPlaygroundURL();
    const Accordian = await screen.findByTestId('Accordian');
    expect(Accordian).toBeInTheDocument();
    fireEvent.click(Accordian);
  });
});

describe('ComparePlans Conditional Rendering1', () => {
  beforeEach(() => {
    const mockLazyQuery = jest.fn();

    useSelector.mockImplementation((selector) => selector(mockState1));
    useLazyComparePlansQuery.mockReturnValue([
      mockLazyQuery,
      {
        status: 'fulfilled',
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: false,
        isFetching: false,
      },
    ]);
    const initialState = {};
    const plansSlice = createSlice({
      name: 'plans',
      initialState,
      reducers: {
        plansdata: (state, action) => action.payload,
      },
    });

    const store = configureAppStore({ plans: plansSlice.reducer }, rootSaga);
    render(
      <Provider store={store}>
        <AccordionRow {...props1} />,
      </Provider>,
      {
        reducers: {
          plans: plansSlice.reducer,
        },
        sagas: rootSaga,
        preloadedState: {},
      },
    );
  });

  test('should return false when perk is not found', () => {
    const isAddedLabel = (perk, id) => perk === 'Unknown Perk' && id === '999';
    const result = isAddedLabel('Unknown Perk', '999');

    expect(result).toBe(true);
  });

  test('should render highlighted body when index is 1', async () => {
    const index = 1;

    const isAddedLable = jest.fn(); // Mock function
    if (comparePlanProductGroupName === 'Perks' && index === 1 && isAddedLable('5G', '1')) {
      const addedText = screen.getByText('Added');
      expect(addedText).toBeInTheDocument();
    }
    screen.logTestingPlaygroundURL();
    const Accordian = await screen.findByTestId('Accordian');
    expect(Accordian).toBeInTheDocument();
    fireEvent.click(Accordian);
  });
});

describe(`<Accordian component - `, () => {
  beforeEach(() => {
    render(
      <AccordionRow
        rowid={0}
        currentOpenRow={0}
        planIdProductIdMap={planIdProductIdMap}
        productGroupName={productGroupName}
        productFeatureMap={productFeatureMap}
        CompareToConnect='CompareToConnect'
        isDark
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });

  test('should open desc cell', async () => {
    const Accordian = await screen.findByTestId('Accordian');
    expect(Accordian).toBeInTheDocument();
    fireEvent.click(Accordian);
    jest.setTimeout(15000); // Reduced from 50000
    fireEvent.click(Accordian);
  });
  test('should open desc cell', async () => {
    const Accordian = await screen.findByTestId('Accordian');
    expect(Accordian).toBeInTheDocument();
    fireEvent.keyDown(Accordian, { key: 'Enter' });
  });
});
describe(`<Accordian component - `, () => {
  beforeEach(() => {
    render(
      <AccordionRow
        planIdProductIdMap={planIdProductIdMapCom}
        productFeatureMap={productFeatureMap}
        comparePlanProductGroupName={comparePlanProductGroupName}
        CompareToConnect='CompareToConnect'
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });
  test('should open desc cell', async () => {
    const Accordian = await screen.findByTestId('Accordian');
    expect(Accordian).toBeInTheDocument();
    fireEvent.click(Accordian);
    fireEvent.click(Accordian);
  });
  test('should open desc cell', async () => {
    const Accordian = await screen.findByTestId('Accordian');
    expect(Accordian).toBeInTheDocument();
    fireEvent.keyDown(Accordian, { key: 'Enter' });
  });
});
describe(`<Accordian component - `, () => {
  beforeEach(() => {
    render(
      <AccordionRow
        planIdProductIdMap={planIdProductIdMapCom}
        productGroupName={productGroupName}
        productFeatureMap={productFeatureMap}
        CompareToConnect='CompareToConnect'
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });
  test('should open desc cell', async () => {
    const Accordian = await screen.findByTestId('Accordian');
    expect(Accordian).toBeInTheDocument();
    fireEvent.click(Accordian);
    fireEvent.click(Accordian);
  });
});
describe(`<Accordian component - `, () => {
  beforeEach(() => {
    render(
      <AccordionRow
        rowid={1}
        currentOpenRow={0}
        planIdProductIdMap={planIdProductIdMap}
        productGroupName={productGroupName}
        productFeatureMap={productFeatureMap}
        CompareToConnect='CompareToConnect'
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });

  test('should open desc cell', async () => {
    const Accordian = await screen.findByTestId('Accordian');
    expect(Accordian).toBeInTheDocument();
    fireEvent.click(Accordian);
    fireEvent.click(Accordian);
  });
  test('should open desc cell', async () => {
    const Accordian = await screen.findByTestId('Accordian');
    expect(Accordian).toBeInTheDocument();
    fireEvent.keyDown(Accordian, { key: 'Enter' });
  });
});
describe(`<Accordian component - `, () => {
  beforeEach(() => {
    render(<AccordionRow {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('should open desc cell', async () => {
    const Accordian = await screen.findByTestId('Accordian');
    expect(Accordian).toBeInTheDocument();
    fireEvent.click(Accordian);
    fireEvent.click(Accordian);
  });
  test('should open desc cell', async () => {
    const Accordian = await screen.findByTestId('Accordian');
    expect(Accordian).toBeInTheDocument();
    fireEvent.keyDown(Accordian, { key: 'Enter' });
  });
});
describe(`<Accordian component - `, () => {
  beforeEach(() => {
    buildPlanMock.isDark = true;
    props.isDark = true;
    render(<AccordionRow {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('should open desc cell', async () => {
    const Accordian = await screen.findByTestId('Accordian');
    expect(Accordian).toBeInTheDocument();
    fireEvent.click(Accordian);
    fireEvent.click(Accordian);
  });
  test('should open desc cell', async () => {
    const Accordian = await screen.findByTestId('Accordian');
    expect(Accordian).toBeInTheDocument();
    fireEvent.keyDown(Accordian, { key: 'Enter' });
  });
});
describe(`Accordian component with redux data`, () => {
  beforeEach(() => {
    const initialState = accordionRedux;
    const plansSlice = createSlice({
      name: 'plans',
      initialState,
      reducers: {
        plansdata: (state, action) => action.payload,
      },
    });
    render(<AccordionRow {...props} />, {
      reducers: { plans: plansSlice.reducer },
      sagas: rootSaga,
      preloadedState: accordionRedux,
    });
  });
  test('should open desc cell', async () => {
    const Accordian = await screen.findByTestId('Accordian');
    expect(Accordian).toBeInTheDocument();
    fireEvent.click(Accordian);
  });
});

describe('AccordianAnimation', () => {
  const props_animation = {
    height: 'auto',
    opened: true,
  };
  const props2 = {
    height: '100px',
    opened: false,
  };
  const initialState = accordionRedux;
  let plansSlice;
  beforeEach(() => {
    plansSlice = createSlice({
      name: 'plans',
      initialState,
      reducers: {
        plansdata: (state, action) => action.payload,
      },
    });
    render(<AccordionAnimation {...props_animation} />, {
      reducers: { plans: plansSlice.reducer },
      sagas: rootSaga,
      preloadedState: accordionRedux,
    });
  });
  test('AccordianAnimation compoent should render', () => {
    const { rerender } = render(<AccordionAnimation {...props_animation} />, {
      reducers: { plans: plansSlice.reducer },
      sagas: rootSaga,
      preloadedState: accordionRedux,
    });
    act(() => {
      rerender(<AccordionAnimation {...props2} />, {
        reducers: { plans: plansSlice.reducer },
        sagas: rootSaga,
        preloadedState: accordionRedux,
      });
    });
    const prevState = { height: 'auto' };
    const isCurrentHeightAuto = prevState.height === 'auto';
    expect(isCurrentHeightAuto).toBe(true);
  });
});

describe('AccordianAnimation', () => {
  const props_animation = {
    height: '100px',
    opened: false,
  };
  const props2 = {
    height: '200px',
    opened: true,
  };
  const initialState = accordionRedux;
  let plansSlice;
  beforeEach(() => {
    plansSlice = createSlice({
      name: 'plans',
      initialState,
      reducers: {
        plansdata: (state, action) => action.payload,
      },
    });
    render(<AccordionAnimation {...props_animation} />, {
      reducers: { plans: plansSlice.reducer },
      sagas: rootSaga,
      preloadedState: accordionRedux,
    });
  });

  test('AccordianAnimation compoent should render', () => {
    jest.useFakeTimers();
    const { rerender } = render(<AccordionAnimation {...props_animation} />, {
      reducers: { plans: plansSlice.reducer },
      sagas: rootSaga,
      preloadedState: accordionRedux,
    });
    act(() => {
      rerender(<AccordionAnimation {...props2} />, {
        reducers: { plans: plansSlice.reducer },
        sagas: rootSaga,
        preloadedState: accordionRedux,
      });
    });
    const prevState = { height: 'auto' };
    const isCurrentHeightAuto = prevState.height === 'auto';
    expect(isCurrentHeightAuto).toBe(true);
    jest.runAllTimers(3000);
  });
});

describe('AccordianAnimation', () => {
  const props_animation = {
    height: 'auto',
    opened: false,
  };
  const props2 = {
    height: '100px',
    opened: true,
  };
  const initialState = accordionRedux;
  let plansSlice;
  beforeEach(() => {
    plansSlice = createSlice({
      name: 'plans',
      initialState,
      reducers: {
        plansdata: (state, action) => action.payload,
      },
    });
    render(
      <StoreProvider>
        <AccordionAnimation {...props_animation} />
      </StoreProvider>,
      {
        reducers: { plans: plansSlice.reducer },
        sagas: rootSaga,
        preloadedState: accordionRedux,
      },
    );
  });
  test('AccordianAnimation compoent should render', () => {
    jest.useFakeTimers();
    const { rerender } = render(<AccordionAnimation {...props_animation} />, {
      reducers: { plans: plansSlice.reducer },
      sagas: rootSaga,
      preloadedState: accordionRedux,
    });
    act(() => {
      rerender(<AccordionAnimation {...props2} />, {
        reducers: { plans: plansSlice.reducer },
        sagas: rootSaga,
        preloadedState: accordionRedux,
      });
    });
    const prevState = { height: 'auto' };
    const isCurrentHeightAuto = prevState.height === 'auto';
    expect(isCurrentHeightAuto).toBe(true);
    jest.runAllTimers(3000);
  });
});

describe('AccordianAnimation', () => {
  const props_animation = {
    height: 'auto',
    opened: false,
  };
  const props2 = {
    height: '100px',
    opened: true,
  };
  const initialState = accordionRedux;
  let plansSlice;
  beforeEach(() => {
    plansSlice = createSlice({
      name: 'plans',
      initialState,
      reducers: {
        plansdata: (state, action) => action.payload,
      },
    });
    render(<AccordionAnimation {...props_animation} />, {
      reducers: { plans: plansSlice.reducer },
      sagas: rootSaga,
      preloadedState: accordionRedux,
    });
  });
  test('AccordianAnimation compoent should render', () => {
    jest.useFakeTimers();
    const { rerender } = render(<AccordionAnimation {...props_animation} />, {
      reducers: { plans: plansSlice.reducer },
      sagas: rootSaga,
      preloadedState: accordionRedux,
    });
    act(() => {
      rerender(<AccordionAnimation {...props2} />, {
        reducers: { plans: plansSlice.reducer },
        sagas: rootSaga,
        preloadedState: accordionRedux,
      });
    });
    const prevState = { height: 'auto' };
    const isCurrentHeightAuto = prevState.height === 'auto';
    expect(isCurrentHeightAuto).toBe(true);
    jest.runAllTimers(3000);
  });
});
describe('ComparePlans Conditional Rendering', () => {
  beforeEach(() => {
    jest.resetModules(); // Reset modules between test
    const initialState = accordionRedux;
    const plansSlice = createSlice({
      name: 'plans',
      initialState,
      reducers: {
        plansdata: (state, action) => action.payload,
      },
    });
    props.isDark = 'false';
    render(<AccordionRow {...props} />, {
      reducers: { plans: plansSlice.reducer },
      sagas: rootSaga,
      preloadedState: accordionRedux,
    });
  });

  test('should return false when perk is not found', () => {
    const isAddedLabel = (perk, id) => perk === 'Unknown Perk' && id === '999';
    const result = isAddedLabel('Unknown Perk', '999');

    expect(result).toBe(true);
  });

  test('should render highlighted body when index is 1', () => {
    const index = 1;

    const isAddedLable = jest.fn(); // Mock function
    if (comparePlanProductGroupName === 'Perks' && index === 1 && isAddedLable('5G', '1')) {
      const addedText = screen.getByText('Added');
      expect(addedText).toBeInTheDocument();
      expect(props.isDark).toBeInTheDocument();
    }
  });

  test('should render highlighted body when index is 1', () => {
    const index = 1;
    const items = 71039;
    const isAddedLable = jest.fn();
    if (
      comparePlanProductGroupName === 'Perks' &&
      index === 1 &&
      isAddedLable(props.productFeatureMap[items]?.compareProductName, props.productFeatureMap[items]?.spoIds)
    ) {
      const addedText = screen.getByText('Added');
      expect(addedText).toBeInTheDocument();
    }
  });
});

describe('ComparePlans Conditional Rendering--selectedMTN', () => {
  test('should return false when perk is not found', () => {
    const isAddedLabel = (perk, id) => perk === 'Unknown Perk' && id === '999';
    const result = isAddedLabel('Unknown Perk', '999');

    expect(result).toBe(true);
  });

  test('should render highlighted body when index is 1', () => {
    const index = 1;

    const isAddedLable = jest.fn(); // Mock function
    if (comparePlanProductGroupName === 'Perks' && index === 1 && isAddedLable('5G', '1')) {
      const addedText = screen.getByText('Added');
      expect(addedText).toBeInTheDocument();
      expect(props.isDark).toBeInTheDocument();
    }
  });
});
