import { fireEvent, render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../modules/store';
import customerJson from './__mock__/mockedCustomerProfile.json';
import newCustomerJson from './__mock__/mockedNewCustomerProfiles.json';
import IspuStoreDetails from './IspuStoreDetails';

const timeout = 10000;
jest.setTimeout(timeout);

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => jest.fn(),
}));

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
  useLazyUpdateShippingOptionsQuery: () => [
    () => {},
    {
      status: 'initialiazed',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: {},
    },
  ],
}));

const storeData = {
  stores: [
    {
      id: 'R00000126382',
      storeName: 'Woodbridge',
      isExpressStore: 'N',
      storeType: 'Store',
      retailId: 'R00000126382',
      storeStatus: 'Open',
      businessName: 'Verizon Wireless',
      zipPlus: '1311',
      fipsCode: '3402381950',
      area: 'Headquarters',
      region: 'Atlantic North',
      disasterImpacted: 'N',
      distance: 16.9,
      netaceLocationCode: 'D2215-01',
      zipCode: '07095',
      state: 'NJ',
      city: 'Woodbridge',
      phoneNumber: '7323267500',
      direct: 'Y',
      inStorePickupFlag: 'Y',
      items: {
        itemCount: 1,
        item: [
          {
            quantity: 0,
            itemCode: 'MTLW3LL/A',
            quantityAllocated: '0',
          },
        ],
      },
      hoursMon: '10:00 AM 08:00 PM',
      hoursTue: '10:00 AM 08:00 PM',
      hoursWed: '10:00 AM 08:00 PM',
      hoursThu: '10:00 AM 08:00 PM',
      hoursFri: '10:00 AM 08:00 PM',
      hoursSat: '10:00 AM 07:00 PM',
      hoursSun: '11:00 AM 06:00 PM',

      address1: '302 Woodbridge Ctr Dr',
      currentGmtOffSet: '-5',
      ispuServices: 'CURBSIDE',
      eligbleForGoAndGrab: 'false',

      lowInventory: false,
      estimatedReadyByDate: '08/10/2024',
    },
  ],
};

const indirectStoreData = {
  stores: [
    {
      id: 'R00000126382',
      storeName: 'Woodbridge',
      isExpressStore: 'N',
      storeType: 'Store',
      retailId: 'R00000126382',
      storeStatus: 'Open',
      businessName: 'Verizon Wireless',
      zipPlus: '1311',
      fipsCode: '3402381950',
      area: 'Headquarters',
      region: 'Atlantic North',
      disasterImpacted: 'N',
      distance: 16.9,
      netaceLocationCode: 'D2215-01',
      zipCode: '07095',
      state: 'NJ',
      city: 'Woodbridge',
      phoneNumber: '7323267500',
      direct: 'N',
      inStorePickupFlag: 'Y',
      items: {
        itemCount: 1,
        item: [
          {
            quantity: 0,
            itemCode: 'MTLW3LL/A',
            quantityAllocated: '0',
          },
        ],
      },
      hoursMon: '10:00 AM 08:00 PM',
      hoursTue: '10:00 AM 08:00 PM',
      hoursWed: '10:00 AM 08:00 PM',
      hoursThu: '10:00 AM 08:00 PM',
      hoursFri: '10:00 AM 08:00 PM',
      hoursSat: '10:00 AM 07:00 PM',
      hoursSun: '11:00 AM 06:00 PM',

      address1: '302 Woodbridge Ctr Dr',
      currentGmtOffSet: '-5',
      ispuServices: 'CURBSIDE',
      eligbleForGoAndGrab: 'false',

      lowInventory: false,
      estimatedReadyByDate: '08/10/2024',
    },
  ],
};

const NoDirectInDirectStore = {
  stores: [
    {
      id: 'R00000126382',
      storeName: 'Woodbridge',
      isExpressStore: 'N',
      storeType: 'Store',
      retailId: 'R00000126382',
      storeStatus: 'Open',
      businessName: 'Verizon Wireless',
      zipPlus: '1311',
      fipsCode: '3402381950',
      area: 'Headquarters',
      region: 'Atlantic North',
      disasterImpacted: 'N',
      distance: 16.9,
      netaceLocationCode: 'D2215-01',
      zipCode: '07095',
      state: 'NJ',
      city: 'Woodbridge',
      phoneNumber: '7323267500',
      inStorePickupFlag: 'Y',
      items: {
        itemCount: 1,
        item: [
          {
            quantity: 0,
            itemCode: 'MTLW3LL/A',
            quantityAllocated: '0',
          },
        ],
      },
      hoursMon: '10:00 AM 08:00 PM',
      hoursTue: '10:00 AM 08:00 PM',
      hoursWed: '10:00 AM 08:00 PM',
      hoursThu: '10:00 AM 08:00 PM',
      hoursFri: '10:00 AM 08:00 PM',
      hoursSat: '10:00 AM 07:00 PM',
      hoursSun: '11:00 AM 06:00 PM',

      address1: '302 Woodbridge Ctr Dr',
      currentGmtOffSet: '-5',
      ispuServices: 'CURBSIDE',
      eligbleForGoAndGrab: 'false',
      storeAvailableServices: 'DS~INSTORE~CURBSIDE~LOCKER',
      lowInventory: false,
      estimatedReadyByDate: '08/10/2024',
    },
  ],
};

describe('Ispu Store Details Component', () => {
  beforeEach(() => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <IspuStoreDetails storeData={storeData} customerData={customerJson} />
        </StoreProvider>
      </BrowserRouter>
    );
  });

  test('renders Ispu Store Details', () => {
    const titleElement = screen.getByTestId('ispu-store-details');
    expect(titleElement).toBeInTheDocument();
  });

  test('renders Ispu Store Details', () => {
    const pickUpBtn = screen.getByText('Pickup from this store');
    expect(pickUpBtn).toBeInTheDocument();
    fireEvent.click(pickUpBtn);
  });
});

describe('Ispu Store Details Component', () => {
  beforeEach(() => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <IspuStoreDetails storeData={indirectStoreData} customerData={customerJson} />
        </StoreProvider>
      </BrowserRouter>
    );
  });

  test('renders Ispu Store Details', () => {
    const titleElement = screen.getByTestId('ispu-store-details');
    expect(titleElement).toBeInTheDocument();
  });

  test('renders Ispu Store Details', () => {
    const pickUpBtn = screen.getByText('Pickup from this store');
    expect(pickUpBtn).toBeInTheDocument();
    fireEvent.click(pickUpBtn);
  });
});

describe('Ispu Store Details Component', () => {
  beforeEach(() => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <IspuStoreDetails storeData={NoDirectInDirectStore} customerData={newCustomerJson} />
        </StoreProvider>
      </BrowserRouter>
    );
  });

  test('renders Ispu Store Details', () => {
    const titleElement = screen.getByTestId('ispu-store-details');
    expect(titleElement).toBeInTheDocument();
  });

  test('renders Ispu Store Details', () => {
    const pickUpBtn = screen.getByText('Pickup from this store');
    expect(pickUpBtn).toBeInTheDocument();
    fireEvent.click(pickUpBtn);
  });
});

describe('Ispu Store Details Component', () => {
  beforeEach(() => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <IspuStoreDetails
            storeData={{
              stores: [],
            }}
            customerData={newCustomerJson}
          />
        </StoreProvider>
      </BrowserRouter>
    );
  });

  test('renders Ispu Store Details', () => {
    const titleElement = screen.getByTestId('ispu-store-details');
    expect(titleElement).toBeInTheDocument();
  });
});
