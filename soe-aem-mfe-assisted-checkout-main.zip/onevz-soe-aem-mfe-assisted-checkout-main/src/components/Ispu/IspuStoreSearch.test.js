import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../modules/store';
import cartJson from './__mock__/mockedCartData.json';
import noCustomerCartJson from './__mock__/mockedCartDataNoCustType.json';
import customerJson from './__mock__/mockedCustomerProfile.json';
import IspuStoreSearch from './IspuStoreSearch';

const timeout = 10000;
jest.setTimeout(timeout);

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => jest.fn(),
  useState: jest.fn(),
}));

const storeData = {
  stores: [
    {
      id: 'R00000126382',
      storeName: 'Woodbridge',
      isExpressStore: 'N',
      storeType: 'Store',
      retailId: 'R00000126382',
      storeStatus: 'Open',
      businessName: 'Verizon Wireless',
      zipPlus: '1311',
      fipsCode: '3402381950',
      area: 'Headquarters',
      region: 'Atlantic North',
      disasterImpacted: 'N',
      distance: 0.99,
      netaceLocationCode: 'D2215-01',
      zipCode: '07095',
      state: 'NJ',
      city: 'Woodbridge',
      phoneNumber: '7323267500',
      direct: 'Y',
      inStorePickupFlag: 'Y',
      items: {
        itemCount: 1,
        item: [
          {
            quantity: 0,
            itemCode: 'ASK-NCQ1338FA',
            quantityAllocated: '0',
          },
        ],
      },
      hoursMon: '10:00 AM 08:00 PM',
      hoursTue: '10:00 AM 08:00 PM',
      hoursWed: '10:00 AM 08:00 PM',
      hoursThu: '10:00 AM 08:00 PM',
      hoursFri: '10:00 AM 08:00 PM',
      hoursSat: '10:00 AM 07:00 PM',
      hoursSun: '11:00 AM 06:00 PM',
      location: {
        longitude: -74.300064,
        latitude: 40.556675,
      },
      address1: '302 Woodbridge Ctr Dr',
      currentGmtOffSet: '-5',
      ispuServices: 'CURBSIDE',
      eligbleForGoAndGrab: 'false',
      storeAvailableServices: 'DS~INSTORE~CURBSIDE~LOCKER',
      lowInventory: false,
      estimatedReadyByDate: '08/20/2024',
    },
    {
      id: 'R00000165652',
      storeName: 'Westfield',
      isExpressStore: 'N',
      storeType: 'Store',
      retailId: 'R00000165652',
      storeStatus: 'Open',
      businessName: 'Verizon Wireless',
      zipPlus: '1421',
      fipsCode: '3403979040',
      area: 'Headquarters',
      region: 'Atlantic North',
      disasterImpacted: 'N',
      distance: 6.32,
      netaceLocationCode: 'D5425-01',
      zipCode: '07090',
      state: 'NJ',
      city: 'Westfield',
      phoneNumber: '9087891201',
      direct: 'Y',
      inStorePickupFlag: 'Y',
      items: {
        itemCount: 1,
        item: [
          {
            quantity: 0,
            itemCode: 'ASK-NCQ1338FA',
            quantityAllocated: '0',
          },
        ],
      },
      hoursMon: '10:00 AM 08:00 PM',
      hoursTue: '10:00 AM 08:00 PM',
      hoursWed: '10:00 AM 08:00 PM',
      hoursThu: '10:00 AM 08:00 PM',
      hoursFri: '10:00 AM 08:00 PM',
      hoursSat: '09:00 AM 06:00 PM',
      hoursSun: '10:00 AM 05:00 PM',
      location: {
        longitude: -74.345955,
        latitude: 40.65034,
      },
      address1: '109 North Ave W',
      currentGmtOffSet: '-5',
      ispuServices: 'LOCKER',
      eligbleForGoAndGrab: 'false',
      storeAvailableServices: 'INSTORE~LOCKER',
      lowInventory: false,
    },
    {
      id: 'R00000001576',
      storeName: 'Staten Island',
      isExpressStore: 'N',
      storeType: 'Store',
      retailId: 'R00000001576',
      storeStatus: 'Open',
      businessName: 'Verizon Wireless',
      zipPlus: '5859',
      fipsCode: '3608551000',
      area: 'Headquarters',
      region: 'Atlantic North',
      disasterImpacted: 'N',
      distance: 6.42,
      netaceLocationCode: 'D2302-01',
      zipCode: '10314',
      state: 'NY',
      city: 'Staten Island',
      phoneNumber: '7189824980',
      direct: 'Y',
      inStorePickupFlag: 'Y',
      items: {
        itemCount: 1,
        item: [
          {
            quantity: 0,
            itemCode: 'ASK-NCQ1338FA',
            quantityAllocated: '0',
          },
        ],
      },
      hoursMon: '10:00 AM 08:00 PM',
      hoursTue: '10:00 AM 08:00 PM',
      hoursWed: '10:00 AM 08:00 PM',
      hoursThu: '10:00 AM 08:00 PM',
      hoursFri: '10:00 AM 08:00 PM',
      hoursSat: '10:00 AM 08:00 PM',
      hoursSun: '10:00 AM 05:00 PM',
      location: {
        longitude: -74.16903,
        latitude: 40.57835,
      },
      address1: '2791 Richmond Ave',
      address2: 'Pergament Mall',
      currentGmtOffSet: '-5',
      ispuServices: 'CURBSIDE',
      eligbleForGoAndGrab: 'false',
      storeAvailableServices: 'CURBSIDE~INSTORE',
      lowInventory: false,
    },
    {
      id: 'R00000163265',
      storeName: 'South Plainfield',
      isExpressStore: 'N',
      storeType: 'Store',
      retailId: 'R00000163265',
      storeStatus: 'Open',
      businessName: 'Verizon Wireless',
      zipPlus: '1139',
      fipsCode: '3402369390',
      area: 'Headquarters',
      region: 'Atlantic North',
      disasterImpacted: 'N',
      distance: 7.51,
      netaceLocationCode: 'D5424-01',
      zipCode: '07080',
      state: 'NJ',
      city: 'South Plainfield',
      phoneNumber: '9087530801',
      direct: 'Y',
      inStorePickupFlag: 'Y',
      items: {
        itemCount: 1,
        item: [
          {
            quantity: 0,
            itemCode: 'ASK-NCQ1338FA',
            quantityAllocated: '0',
          },
        ],
      },
      hoursMon: '10:00 AM 08:00 PM',
      hoursTue: '10:00 AM 08:00 PM',
      hoursWed: '10:00 AM 08:00 PM',
      hoursThu: '10:00 AM 08:00 PM',
      hoursFri: '10:00 AM 08:00 PM',
      hoursSat: '09:00 AM 07:00 PM',
      hoursSun: '10:00 AM 05:00 PM',
      location: {
        longitude: -74.43249,
        latitude: 40.554512,
      },
      address1: '7000 Hadley Rd',
      currentGmtOffSet: '-5',
      ispuServices: 'LOCKER',
      eligbleForGoAndGrab: 'false',
      storeAvailableServices: 'INSTORE~LOCKER',
      lowInventory: false,
    },
    {
      id: 'R00000004694',
      storeName: 'Watchung',
      isExpressStore: 'N',
      storeType: 'Store',
      retailId: 'R00000004694',
      storeStatus: 'Open',
      businessName: 'Verizon Wireless',
      zipPlus: '6511',
      fipsCode: '3403577600',
      area: 'Headquarters',
      region: 'Atlantic North',
      disasterImpacted: 'N',
      distance: 8.17,
      netaceLocationCode: 'D2280-01',
      zipCode: '07069',
      state: 'NJ',
      city: 'Watchung',
      phoneNumber: '9084901688',
      direct: 'Y',
      inStorePickupFlag: 'Y',
      items: {
        itemCount: 1,
        item: [
          {
            quantity: 0,
            itemCode: 'ASK-NCQ1338FA',
            quantityAllocated: '0',
          },
        ],
      },
      hoursMon: '10:00 AM 08:00 PM',
      hoursTue: '10:00 AM 08:00 PM',
      hoursWed: '10:00 AM 08:00 PM',
      hoursThu: '10:00 AM 08:00 PM',
      hoursFri: '10:00 AM 08:00 PM',
      hoursSat: '09:00 AM 07:00 PM',
      hoursSun: '11:00 AM 06:00 PM',
      location: {
        longitude: -74.41187,
        latitude: 40.643234,
      },
      address1: '1620 Us Highway 22',
      currentGmtOffSet: '-5',
      ispuServices: 'LOCKER',
      eligbleForGoAndGrab: 'false',
      storeAvailableServices: 'LOCKER~INSTORE',
      lowInventory: false,
    },
    {
      id: 'R00000001416',
      storeName: 'Union NJ',
      isExpressStore: 'N',
      storeType: 'Store',
      retailId: 'R00000001416',
      storeStatus: 'Open',
      businessName: 'Verizon Wireless',
      fipsCode: '3403974510',
      area: 'Headquarters',
      region: 'Atlantic North',
      disasterImpacted: 'N',
      distance: 8.34,
      netaceLocationCode: 'D2213-01',
      zipCode: '07083',
      state: 'NJ',
      city: 'Union',
      phoneNumber: '9086244100',
      direct: 'Y',
      inStorePickupFlag: 'Y',
      items: {
        itemCount: 1,
        item: [
          {
            quantity: 0,
            itemCode: 'ASK-NCQ1338FA',
            quantityAllocated: '0',
          },
        ],
      },
      hoursMon: '10:00 AM 08:00 PM',
      hoursTue: '10:00 AM 08:00 PM',
      hoursWed: '10:00 AM 08:00 PM',
      hoursThu: '10:00 AM 08:00 PM',
      hoursFri: '10:00 AM 08:00 PM',
      hoursSat: '09:00 AM 07:00 PM',
      hoursSun: '11:00 AM 06:00 PM',
      location: {
        longitude: -74.303375,
        latitude: 40.689278,
      },
      address1: '2490 Us Highway 22 W',
      address2: 'Center Island',
      currentGmtOffSet: '-5',
      ispuServices: 'LOCKER',
      eligbleForGoAndGrab: 'false',
      storeAvailableServices: 'LOCKER~INSTORE',
      lowInventory: false,
    },
    {
      id: 'R00000253899',
      storeName: 'East Brunswick',
      isExpressStore: 'N',
      storeType: 'Store',
      retailId: 'R00000253899',
      storeStatus: 'Open',
      businessName: 'Verizon Wireless',
      zipPlus: '2107',
      fipsCode: '3402300000',
      area: 'Headquarters',
      region: 'Atlantic North',
      disasterImpacted: 'N',
      distance: 9.74,
      netaceLocationCode: 'D2226-01',
      zipCode: '08816',
      state: 'NJ',
      city: 'East Brunswick',
      phoneNumber: '7324164900',
      direct: 'Y',
      inStorePickupFlag: 'Y',
      items: {
        itemCount: 1,
        item: [
          {
            quantity: 0,
            itemCode: 'ASK-NCQ1338FA',
            quantityAllocated: '0',
          },
        ],
      },
      hoursMon: '10:00 AM 08:00 PM',
      hoursTue: '10:00 AM 08:00 PM',
      hoursWed: '10:00 AM 08:00 PM',
      hoursThu: '10:00 AM 08:00 PM',
      hoursFri: '10:00 AM 08:00 PM',
      hoursSat: '10:00 AM 07:00 PM',
      hoursSun: '11:00 AM 06:00 PM',
      location: {
        longitude: -74.40144,
        latitude: 40.45602,
      },
      address1: '323 State Route 18',
      currentGmtOffSet: '-5',
      ispuServices: 'CURBSIDE',
      eligbleForGoAndGrab: 'false',
      storeAvailableServices: 'CURBSIDE~INSTORE',
      lowInventory: false,
    },
    {
      id: 'R00000046668',
      storeName: 'Hazlet',
      isExpressStore: 'N',
      storeType: 'Store',
      retailId: 'R00000046668',
      storeStatus: 'Open',
      businessName: 'Verizon Wireless',
      zipPlus: '1505',
      fipsCode: '3402500000',
      area: 'Headquarters',
      region: 'Atlantic North',
      disasterImpacted: 'N',
      distance: 12.02,
      netaceLocationCode: 'D2291-01',
      zipCode: '07730',
      state: 'NJ',
      city: 'Hazlet',
      phoneNumber: '7322039160',
      direct: 'Y',
      inStorePickupFlag: 'Y',
      items: {
        itemCount: 1,
        item: [
          {
            quantity: 0,
            itemCode: 'ASK-NCQ1338FA',
            quantityAllocated: '0',
          },
        ],
      },
      hoursMon: '10:00 AM 08:00 PM',
      hoursTue: '10:00 AM 08:00 PM',
      hoursWed: '10:00 AM 08:00 PM',
      hoursThu: '10:00 AM 08:00 PM',
      hoursFri: '10:00 AM 08:00 PM',
      hoursSat: '09:00 AM 07:00 PM',
      hoursSun: '10:00 AM 05:00 PM',
      location: {
        longitude: -74.17833,
        latitude: 40.417652,
      },
      address1: '2996 State Route 35',
      currentGmtOffSet: '-5',
      ispuServices: 'LOCKER24',
      eligbleForGoAndGrab: 'false',
      storeAvailableServices: 'LOCKER24~INSTORE',
      lowInventory: false,
    },
    {
      id: 'R00000004169',
      storeName: 'Short Hills',
      isExpressStore: 'N',
      storeType: 'Store',
      retailId: 'R00000004169',
      storeStatus: 'Open',
      businessName: 'Verizon Wireless',
      zipPlus: '2746',
      fipsCode: '3401346410',
      area: 'Headquarters',
      region: 'Atlantic North',
      disasterImpacted: 'N',
      distance: 12.47,
      netaceLocationCode: 'D2230-01',
      zipCode: '07078',
      state: 'NJ',
      city: 'Short Hills',
      phoneNumber: '9733134900',
      direct: 'Y',
      inStorePickupFlag: 'Y',
      items: {
        itemCount: 1,
        item: [
          {
            quantity: 0,
            itemCode: 'ASK-NCQ1338FA',
            quantityAllocated: '0',
          },
        ],
      },
      hoursMon: '10:00 AM 08:00 PM',
      hoursTue: '10:00 AM 08:00 PM',
      hoursWed: '10:00 AM 08:00 PM',
      hoursThu: '10:00 AM 08:00 PM',
      hoursFri: '10:00 AM 08:00 PM',
      hoursSat: '10:00 AM 08:00 PM',
      hoursSun: '11:00 AM 06:00 PM',
      location: {
        longitude: -74.3643,
        latitude: 40.740604,
      },
      address1: '1200 Morris Tpke',
      currentGmtOffSet: '-5',
      ispuServices: 'INSTORE',
      eligbleForGoAndGrab: 'false',
      storeAvailableServices: 'INSTORE',
      lowInventory: false,
    },
    {
      id: 'R00000000115',
      storeName: 'North Brunswick',
      isExpressStore: 'N',
      storeType: 'Store',
      retailId: 'R00000000115',
      storeStatus: 'Open',
      businessName: 'Verizon Wireless',
      zipPlus: '4119',
      fipsCode: '3402352605',
      area: 'Headquarters',
      region: 'Atlantic North',
      disasterImpacted: 'N',
      distance: 13.45,
      netaceLocationCode: 'D2295-01',
      zipCode: '08902',
      state: 'NJ',
      city: 'North Brunswick',
      phoneNumber: '7323988573',
      direct: 'Y',
      inStorePickupFlag: 'Y',
      items: {
        itemCount: 1,
        item: [
          {
            quantity: 0,
            itemCode: 'ASK-NCQ1338FA',
            quantityAllocated: '0',
          },
        ],
      },
      hoursMon: '10:00 AM 07:00 PM',
      hoursTue: '10:00 AM 07:00 PM',
      hoursWed: '10:00 AM 07:00 PM',
      hoursThu: '10:00 AM 07:00 PM',
      hoursFri: '10:00 AM 07:00 PM',
      hoursSat: '09:00 AM 07:00 PM',
      hoursSun: '10:00 AM 05:00 PM',
      location: {
        longitude: -74.4938,
        latitude: 40.450527,
      },
      address1: '1020 Cozzens Ln',
      currentGmtOffSet: '-5',
      ispuServices: 'LOCKER',
      eligbleForGoAndGrab: 'false',
      storeAvailableServices: 'INSTORE~LOCKER',
      lowInventory: false,
    },
    {
      id: 'R00000003153',
      storeName: 'Bay Ridge Brooklyn II',
      isExpressStore: 'N',
      storeType: 'Store',
      retailId: 'R00000003153',
      storeStatus: 'Open',
      businessName: 'Verizon Wireless',
      zipPlus: '4704',
      fipsCode: '3604751000',
      area: 'Headquarters',
      region: 'Atlantic North',
      disasterImpacted: 'N',
      distance: 14.35,
      netaceLocationCode: 'D2304-01',
      zipCode: '11209',
      state: 'NY',
      city: 'Brooklyn',
      phoneNumber: '7184916680',
      direct: 'Y',
      inStorePickupFlag: 'Y',
      items: {
        itemCount: 1,
        item: [
          {
            quantity: 0,
            itemCode: 'ASK-NCQ1338FA',
            quantityAllocated: '0',
          },
        ],
      },
      hoursMon: '10:00 AM 07:00 PM',
      hoursTue: '10:00 AM 07:00 PM',
      hoursWed: '10:00 AM 07:00 PM',
      hoursThu: '10:00 AM 07:00 PM',
      hoursFri: '10:00 AM 07:00 PM',
      hoursSat: '10:00 AM 07:00 PM',
      hoursSun: '10:00 AM 05:00 PM',
      location: {
        longitude: -74.02626,
        latitude: 40.621784,
      },
      address1: '8524 5th Ave',
      currentGmtOffSet: '-5',
      ispuServices: 'INSTORE',
      eligbleForGoAndGrab: 'false',
      storeAvailableServices: 'INSTORE',
      lowInventory: false,
    },
  ],
  itemCount: 0,
  shippingISPU: false,
  selectedStoreAvailable: false,
  userInstoreEligibility: false,
  numberOfStores: 11,
  favStoreRequested: false,
};

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
  useLazyCheckInStoreAvailabilityQuery: () => [
    () => {},
    {
      status: 'pending',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: storeData,
    },
  ],
}));

describe('IspuStoreSearch Component', () => {
  beforeEach(() => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <IspuStoreSearch CartDetailsResult={cartJson} CustomerProfileResult={customerJson} />
        </StoreProvider>
      </BrowserRouter>
    );
  });

  test('renders IspuStoreSearch', async () => {
    await waitFor(() => {
      const titleElement = screen.getByTestId('ispu-store-search');
      expect(titleElement).toBeInTheDocument();

      const updateZipcode = screen.getByLabelText('zipcode');
      expect(updateZipcode).toBeInTheDocument();
      fireEvent.change(updateZipcode, { target: { value: '12345' } });
    });
  });

  test('renders IspuStoreSearch with short zipcode', async () => {
    await waitFor(() => {
      const titleElement = screen.getByTestId('ispu-store-search');
      expect(titleElement).toBeInTheDocument();

      const updateZipcode = screen.getByLabelText('zipcode');
      expect(updateZipcode).toBeInTheDocument();

      fireEvent.change(updateZipcode, { target: { value: '1234' } });
    });
  });

  test('renders IspuStoreSearch with no zipcode', async () => {
    await waitFor(() => {
      const titleElement = screen.getByTestId('ispu-store-search');
      expect(titleElement).toBeInTheDocument();

      const updateZipcode = screen.getByLabelText('zipcode');
      expect(updateZipcode).toBeInTheDocument();

      fireEvent.change(updateZipcode, { target: { value: '' } });
    });
  });

  test('renders IspuStoreSearch Button click', async () => {
    await waitFor(() => {
      const titleElement = screen.getByTestId('ispu-store-search');
      expect(titleElement).toBeInTheDocument();

      const findStores = screen.getByText('Find stores');
      expect(findStores).toBeInTheDocument();

      fireEvent.click(findStores);
    });
  });

  test('renders IspuStoreSearch toggle click', async () => {
    await waitFor(() => {
      const toggle = screen.getByLabelText('show-only-inventory-toggle');
      expect(toggle).toBeInTheDocument();

      fireEvent.click(toggle);
    });
  });

  test('renders IspuStoreSearch Next/Previous click', async () => {
    await waitFor(() => {
      const toggle = screen.getByLabelText('show-only-inventory-toggle');
      expect(toggle).toBeInTheDocument();

      fireEvent.click(toggle);

      screen.debug();
      const nextButton = screen.getByText('Next');
      expect(nextButton).toBeInTheDocument();

      fireEvent.click(nextButton);

      const previousButton = screen.getByText('Previous');
      expect(previousButton).toBeInTheDocument();

      fireEvent.click(previousButton);
    });
  });

  test('renders IspuStoreSearch btn-back click', async () => {
    await waitFor(() => {
      const backBtn = screen.getByTestId('btn-back');
      expect(backBtn).toBeInTheDocument();

      fireEvent.click(backBtn);
    });
  });
});

describe('IspuStoreSearch Component without customerType', () => {
  beforeEach(() => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <IspuStoreSearch CartDetailsResult={noCustomerCartJson} CustomerProfileResult={customerJson} />
        </StoreProvider>
      </BrowserRouter>
    );
  });

  test('renders IspuStoreSearch', async () => {
    await waitFor(() => {
      const titleElement = screen.getByTestId('ispu-store-search');
      expect(titleElement).toBeInTheDocument();

      const updateZipcode = screen.getByLabelText('zipcode');
      expect(updateZipcode).toBeInTheDocument();
      fireEvent.change(updateZipcode, { target: { value: '12345' } });

      const findStores = screen.getByText('Find stores');
      expect(findStores).toBeInTheDocument();

      fireEvent.click(findStores);
    });
  });
});
