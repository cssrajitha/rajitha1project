import { Button } from '@vds/buttons';
import { Icon } from '@vds/icons';
import { Input } from '@vds/inputs';
import { Line } from '@vds/lines';
import { Toggle } from '@vds/toggles';
import { Body, Title } from '@vds/typography';
import { useEffect, useState } from 'react';
import styled from 'styled-components';

import PropTypes from 'prop-types';
import { BackClickable, PaddingBottom12 } from '../../StyledConstants';
import { useLazyCheckInStoreAvailabilityQuery } from '../../modules/services/APIService/APIServiceHooks';
import { allowOnlyNumbers } from '../../utils/common';
import IspuStoreDetails from './IspuStoreDetails';

const FlexBoxGrowOne = styled.div`
  display: flex;
  flex-grow: 1;
  height: 4rem;
  align-items: center;
  gap: 7px;
`;

export const FlexAlignContainerItemsCenter = styled.div`
  display: flex;
  align-items: center !important;
  justify-content: space-between;
`;

const FixedHeader = styled.div`
  max-width: 64rem;
  background-color: rgb(255, 255, 255);
  top: 0;
  z-index: 1;
  width: 100%;
  position: fixed;
`;

const Seperator = styled.span`
  margin: 0px 5px 9px -20px;
  font-size: 30px;
`;

const Container = styled.div`
  margin: 120px 0px 30px 0px;
`;

const ToggleContainer = styled.div`
  display: flex;
  gap: 15px;
`;

const SearchStoreContainer = styled.div`
  margin-top: 50px;
  display: grid;
  grid-template-columns: 6fr 3fr;
`;

const StoreContainer = styled.div`
  margin-top: 30px;
`;

const FaqContainer = styled.div`
  margin-top: 10px;
  display: flex;
  flex-direction: column;
`;

const FaqTitle = styled.span`
  margin: auto;
`;

const ListOrder = styled.li`
  list-style-type: none;
`;

const InputContainer = styled.div`
  margin-top: 10px;
  display: flex;
  flex-direction: row;
  gap: 20px;
  height: 45px;
  [class^='StyledInput-VDS'] {
    font-weight: 600;
  }
`;

const TextLinkWrapper = styled.div`
  text-align: left;
  a {
    display: block;
    margin-bottom: 5px;
    border: none;
    text-decoration: underline;
    white-space: normal;
  }
  a:hover {
    border: none;
  }
`;

const TextContainer = styled.div`
  display: flex;
  margin: auto;
  gap: 10px;
`;

const PaginationContainer = styled.div`
  display: flex;
  gap: 40px;
  justify-content: center;
  margin: 10px 0px 0px 10px;
`;

const FooterContainer = styled.div`
  margin: 10px 0px 30px 0px;
`;

const correlationId =
  'ick-ClrSuZPeM-UmBI-2SFB6t1zB_dFDy3IfCcConCuwmPSIXyrD!1375284084!obsneocgzap08!5106!-1!1564408961747';
const timeStamp = '2019-07-29T10:25:59.791-04:00';

export default function IspuStoreSearch({ CartDetailsResult, CustomerProfileResult }) {
  const [showAvailableStoresOnly, setShowAvailableStoresOnly] = useState(true);
  const [datasetCount, setDatasetCount] = useState(1);
  const [zipCode, setZipCode] = useState('');
  const [zipcodeError, setZipcodeError] = useState(false);

  const [checkInStoreAvailabilityRequest, checkInStoreAvailabilityResult] = useLazyCheckInStoreAvailabilityQuery();
  const lineDetails = CartDetailsResult?.data?.data?.cart?.lineDetails;
  const cartHeader = CartDetailsResult?.data?.data?.cart?.cartHeader;
  const customerType = CartDetailsResult?.data?.data?.cart?.orderDetails?.customerType || 'E';
  const zipCodeFromLine = lineDetails?.lineInfo?.[0]?.serviceInfo?.primaryUserInfo?.address?.zipCode;

  useEffect(() => {
    if (zipCodeFromLine) setZipCode(zipCodeFromLine);
  }, [zipCodeFromLine]);

  const handleZipcodeChange = (e) => {
    if (e.target.value) {
      if (allowOnlyNumbers(e.target.value) && e.target.value.length <= 5) {
        setZipCode(e.target.value);
      }
      if (e.target.value.length < 5) {
        setZipcodeError(true);
      } else {
        setZipcodeError(false);
      }
    } else {
      setZipCode('');
      setZipcodeError(false);
    }
  };

  const findStore = (dataSetFindStore, showAvailableStores) => {
    let sorIds = [];

    if (lineDetails) {
      const cartItems = lineDetails?.lineInfo
        ?.flatMap((line) => line?.itemsInfo || [])
        .flatMap((item) => item?.cartItems || [])
        .flatMap((cartItemObj) => cartItemObj?.cartItem);
      sorIds = cartItems?.filter((each) => each?.cartItemType === 'DEVICE').map((cartItem) => cartItem?.sorId);
    }
    const request = {
      meta: {
        clientCorrrelationId: correlationId,
        timestamp: timeStamp,
      },
      data: {
        zipCode,
        excludeIndirect: cartHeader?.visionCustomerType === 'BE' || false,
        range: 50,
        sorIds,
        customerType,
        showOnlyAvailableStores: showAvailableStores,
        ...(showAvailableStores === false ? { dataSet: dataSetFindStore } : ''),
      },
    };

    checkInStoreAvailabilityRequest({ body: request, spinner: true, mock: false });
  };

  const handleToggleChange = () => {
    setShowAvailableStoresOnly((prevState) => {
      const newState = !prevState;
      findStore(1, newState);
      return newState;
    });
  };

  const handlePrevious = () => {
    setDatasetCount((prevState) => {
      const newState = prevState - 1;
      findStore(newState, showAvailableStoresOnly);
      return newState;
    });
  };

  const handleNext = () => {
    setDatasetCount((prevState) => {
      const newState = prevState + 1;
      findStore(newState, showAvailableStoresOnly);
      return newState;
    });
  };

  return (
    <>
      <FixedHeader data-testid='header'>
        <FlexAlignContainerItemsCenter>
          <FlexBoxGrowOne>
            <BackClickable
              data-testid='btn-back'
              onClick={() => {
                window.location.href = '/sales/assisted/new/shipping-details.html';
              }}
            >
              <Icon name='left-caret' size='XLarge' medium='true' />
            </BackClickable>
            <Seperator>|</Seperator>

            <Title size='small' bold primitive='h1'>
              In-Store availability
            </Title>
          </FlexBoxGrowOne>
        </FlexAlignContainerItemsCenter>
        <Line type='secondary' />
      </FixedHeader>

      <Container data-testid='ispu-store-search'>
        <PaddingBottom12>
          <Title size='small' bold primitive='h1'>
            Check In-Store availability
          </Title>
        </PaddingBottom12>

        <Title>Store(s) in your area have the device(s) available for store pickup right now</Title>
        <SearchStoreContainer>
          <StoreContainer>
            <Body size='large' bold>
              Search for a Store
            </Body>
            <InputContainer>
              <Input
                type='text'
                ariaLabel='zipcode'
                readOnly={false}
                required
                width='38%'
                error={zipcodeError}
                errorText={zipcodeError && 'Please enter a valid zip code!'}
                value={zipCode}
                onChange={(e) => handleZipcodeChange(e)}
              />
              <Button onClick={() => findStore(1, true)} disabled={zipcodeError}>
                Find stores
              </Button>
            </InputContainer>
          </StoreContainer>
          <FaqContainer>
            <FaqTitle>
              <Title size='small'>FAQ</Title>
            </FaqTitle>

            <Body size='large'>
              How Does In-Store Pickup Work?
              <ListOrder>
                Check for In-Store Pickup Availability - Search for a store by zip code or by state. Product
                availability will show for each store. Click the `Pickup From Store` button.
              </ListOrder>
              <ListOrder>Place your order online.</ListOrder>
              <ListOrder>
                We will send you an email when your order is ready at the store. Note: Please pick up your items(s)
                within 3 days of purchase.
              </ListOrder>
              <ListOrder>
                Go to the store - You will need a valid government-issue photo ID to pick up your order. Only the
                account owner or account managers will be eligible to pick up your order.
              </ListOrder>
            </Body>
          </FaqContainer>
        </SearchStoreContainer>
      </Container>
      {checkInStoreAvailabilityResult?.data && (
        <>
          <ToggleContainer>
            <Body size='large' bold>
              Show only inventory available stores
            </Body>{' '}
            <Toggle
              ariaLabel='show-only-inventory-toggle'
              surface='light'
              disabled={false}
              onChange={handleToggleChange}
              on={showAvailableStoresOnly}
            />
          </ToggleContainer>
          <IspuStoreDetails
            storeData={checkInStoreAvailabilityResult?.data}
            customerData={CustomerProfileResult?.data?.data}
          />

          {!showAvailableStoresOnly &&
            !(datasetCount === 1 && checkInStoreAvailabilityResult?.data.stores?.length < 10) && (
              <>
                <Line type='secondary' />
                <PaginationContainer>
                  {datasetCount > 1 && (
                    <TextLinkWrapper onClick={handlePrevious}>
                      <TextContainer>
                        <Icon name='left-arrow' size='large' medium='true' />
                        <Body size='large' bold>
                          Previous
                        </Body>
                      </TextContainer>
                    </TextLinkWrapper>
                  )}
                  {datasetCount <= 5 && (
                    <TextLinkWrapper onClick={handleNext}>
                      <TextContainer>
                        <Body size='large' bold>
                          Next
                        </Body>
                        <Icon name='right-arrow' size='large' medium='true' />
                      </TextContainer>
                    </TextLinkWrapper>
                  )}
                </PaginationContainer>
              </>
            )}
        </>
      )}
      <FooterContainer>
        <Line type='secondary' />
      </FooterContainer>
    </>
  );
}

IspuStoreSearch.propTypes = {
  CartDetailsResult: PropTypes.object,
  CustomerProfileResult: PropTypes.object,
};
