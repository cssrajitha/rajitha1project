import { Button } from '@vds/buttons';
import { Line } from '@vds/lines';
import { Body, Title } from '@vds/typography';
import moment from 'moment';
import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { useNavigate } from 'react-router';
import { useLazyUpdateShippingOptionsQuery } from '../../modules/services/APIService/APIServiceHooks';

const Container = styled.div`
  margin: 10px 0px 0px 0px;
`;

const TitlContainer = styled.div`
  margin: 0px 0px 30px 30px;
`;

const StoreContainer = styled.div`
  margin: 20px 0px 20px 20px;
  display: grid;
  grid-template-columns: 1fr 5fr 5fr 5fr;
`;

const MarginTop10 = styled.div`
  margin-top: 0.4375rem;
`;

const PaddingTop = styled.div`
  padding-top: 0.4375rem;
`;

const ColumnContainer = styled.div``;

const ButtonContainer = styled.div`
  margin: auto;
`;

const getStoreType = (storeType) => {
  if (storeType === 'Y') {
    return '(Direct store)';
  }
  if (storeType === 'N') {
    return '(Indirect store)';
  }
  return '';
};

const fallbackText =
  'Inventory is not available in stores nearby the searched location, please try in a different location or turn-off the toggle to explore more stores';

const storeText = 'Stores near you';

const iff = (condition, trueValue, falseValue) => (condition ? trueValue : falseValue);

const slotsArray = ['hoursSun', 'hoursMon', 'hoursTue', 'hoursWed', 'hoursThu', 'hoursFri', 'hoursSat'];

export default function IspuStoreDetails({ storeData, customerData }) {
  const [updateShippingOptionRequest, updateShippingOptionResult] = useLazyUpdateShippingOptionsQuery();
  const navigate = useNavigate();

  const timeSlots = (store, day) => (
    <div key={day}>
      <PaddingTop>
        <Body size='large'>
          {day.replace('hours', '')} :{' '}
          {iff(
            store?.[day]?.trim(),
            iff(
              store[day].includes('AM '),
              store[day].replace('AM ', 'AM-'),
              iff(
                store[day].includes('Closed '),
                store[day].replace('Closed ', 'Closed-'),
                iff(store[day].includes('PM '), store[day].replace('PM ', 'PM-'), store[day])
              )
            ),
            store[day]
          )}
        </Body>
      </PaddingTop>
    </div>
  );

  const handleStorePickup = (location) => {
    const payload = {
      serviceHeader: {
        clientId: 'VZW-NETACE',
        statusMsg: 'PEGA generated message',
        correlationId: '69a66ef4d7e344dfb2db299209ea8333',
        sessionId: '',
        serviceName: 'SalesOrderPurchase',
        userId: customerData?.customer?.loggedInUser,
        statusCode: '0',
      },
      serviceBody: {
        serviceRequest: {
          context: {
            skipCheckoutCall: true,
            caseId: customerData?.customer?.caseId,
            cartId: customerData?.customer?.cartId,
            customerInfo: {
              accountNumber: customerData?.customer?.accountNo,
              cartCreator: customerData?.customer?.lookupMtn,
              processingMTN: customerData?.customer?.lookupMtn,
            },
            cartInfo: {
              cartId: customerData?.customer?.cartId,
              action: 'UPDATE',
              itemType: 'SHIPPINGOPTION',
              intendType: customerData?.customer?.customerAttributes?.customerType === 'N' ? 'NSE' : 'EUP',
              shipmentInfo: [
                {
                  multiLineSeqNumber: 1,
                  shipping: {
                    depletionLocation: location,
                    shippingDescription: 'In-Store Pick Up',
                  },
                },
              ],
            },
            contextInfo: {
              callReason: 'SalesOrderPurchase',
              intent: 'Upgrade',
              processStep: 'OrderReview-Shipping',
              processAction: 'updateShippingOptions',
            },
          },
        },
      },
    };
    updateShippingOptionRequest({ body: payload, spinner: true, mock: false });
  };

  useEffect(() => {
    if (updateShippingOptionResult?.status === 'fulfilled') navigate(`/sales/assisted/new/order-review.html`);
  }, [updateShippingOptionResult]);

  return (
    <Container data-testid='ispu-store-details'>
      <TitlContainer>
        <Title size='medium' bold>
          {storeData?.stores?.length > 0 ? storeText : fallbackText}
        </Title>
      </TitlContainer>
      <Line type='secondary' />
      {storeData?.stores.map((store, index) => (
        <div key={store.storeName}>
          <Line type='secondary' />
          <StoreContainer>
            <Title bold>{index + 1}</Title>
            <ColumnContainer>
              <Title bold>{store.storeName}</Title>
              <MarginTop10>
                <Body size='large'>{getStoreType(store?.direct)}</Body>
                <Body size='large'>
                  {(store?.storeAvailableServices?.includes('CURBSIDE') ||
                    store?.storeAvailableServices?.includes('LOCKER') ||
                    store?.storeAvailableServices?.includes('LOCKER24')) &&
                    'Curbside, Locker Pickup Enabled'}
                </Body>

                <Body size='large'>{`${store.address1}`}</Body>
                <Body size='large'>{`${store.city}, ${store.state}`}</Body>
                <MarginTop10>
                  <Body size='large'>Phone : {store.phoneNumber}</Body>
                </MarginTop10>
                <Title bold>
                  {store?.items?.item?.[0]?.quantityAllocated} of {store?.items?.item?.[0]?.quantityAllocated} item(s)
                  available
                </Title>
              </MarginTop10>
            </ColumnContainer>
            <ColumnContainer>
              <Title bold>{store.distance} Miles away</Title>
              {slotsArray.map((day) => timeSlots(store, day))}
            </ColumnContainer>
            {store.estimatedReadyByDate && (
              <ButtonContainer>
                <Title bold>Ready By {moment(new Date(store.estimatedReadyByDate)).format('MMMM Do')}</Title>
                <PaddingTop>
                  <Button onClick={() => handleStorePickup(store?.netaceLocationCode)}>Pickup from this store</Button>
                </PaddingTop>
              </ButtonContainer>
            )}
          </StoreContainer>
        </div>
      ))}
    </Container>
  );
}

IspuStoreDetails.propTypes = {
  storeData: PropTypes.object,
  customerData: PropTypes.object,
};
