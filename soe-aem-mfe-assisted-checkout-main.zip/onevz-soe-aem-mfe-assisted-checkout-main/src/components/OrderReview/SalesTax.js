import { useState } from 'react';
import styled from 'styled-components';
import { TileContainer } from '@vds/tiles';
import { TextLink } from '@vds/buttons';
import PropTypes from 'prop-types';
import { has } from 'lodash';
import SalesTaxModal from './SalesTaxModal';
import { formatCurrency } from '../../utils/common';
import { invokeTagging } from '../../utils/test-utils/utils';

import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR } from '../constants/constants';

const TileWrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
`;
const PriceWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 0.25rem;
  padding: 12px 8px 8px 8px;
`;

const Title = styled.div`
  font-size: 20px;
  font-weight: 700;
  line-height: 1.25rem;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  letter-spacing: 0.03125rem;
  margin: 0px;
  text-decoration: none;
  width: 178px;
`;

const Value = styled.div`
  font-size: 20px;
  font-weight: 700;
  line-height: 1.25rem;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  letter-spacing: 0.03125rem;
  margin: 0px;
  text-decoration: none;
`;

const LinkWrapper = styled.div`
  text-align: left;
  padding-left: 8px;
  padding-bottom: 1rem;
`;

const TileContainerWrapper = styled.div`
  [class^='OuterTileContainer'] {
    border-radius: 0px !important;
    height: 100%;
  }
`;

const SalesTax = ({ cart, readOrder, isReadOrderMfeFFlag }) => {
  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;
  const bgColor = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.themeProps?.background;
  /**
   * To get all salesTax
   */
  const getSalesTax = (lines) => {
    const taxDetail = [];
    lines.forEach((line) => {
      const mobileNumber = line.mobileNumber ? line.mobileNumber : '';
      let tax =
        has(line, 'itemsInfo') &&
        line.itemsInfo.map((item) => {
          const salesTax =
            (has(item, 'cartItems.cartItem') &&
              item.cartItems.cartItem.map((cartItem) => (has(cartItem, 'taxDetailsList') ? cartItem : []))) ||
            [];
          return salesTax?.reduce((a, b) => a.concat(b), []) || [];
        });
      tax = tax.reduce((a, b) => a.concat(b), []);
      let subTotal = 0;
      tax.forEach((currTax) => {
        subTotal += parseFloat(currTax.taxAmount ? currTax.taxAmount : 0);
        return subTotal;
      });
      const data = {
        mobileNumber,
        taxDetails: tax,
        subTotal,
      };
      taxDetail.push(data);
    });
    return taxDetail;
  };

  const salesTax = getSalesTax(cart.lineDetails.lineInfo);

  const [isSalesTaxModalVisible, setisSalesTaxModalVisible] = useState(false);

  const handleViewSalesTax = () => {
    if (isReadOrderMfeFFlag && readOrder === true) {
      invokeTagging('openView', 'salesTax');
    } else {
      invokeTagging('openView', 'Tax Details');
    }
    setisSalesTaxModalVisible(true);
  };

  const closeModal = () => {
    invokeTagging('closeView', '');
    setisSalesTaxModalVisible(false);
  };

  return (
    <>
      <TileContainerWrapper data-testId='salesTax'>
        <TileContainer padding='0' height='auto' width='384px' backgroundColor={isDark ? bgColor : 'white'}>
          <TileWrapper>
            <PriceWrapper>
              <Title
                style={{
                  color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                  backgroundColor: isDark ? bgColor : 'inherit',
                }}
              >
                Sales tax
              </Title>
              <Value
                style={{
                  color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                  backgroundColor: isDark ? bgColor : 'inherit',
                }}
              >
                {formatCurrency(cart.orderDetails.totalTaxAmount)}
              </Value>
            </PriceWrapper>
            <LinkWrapper>
              <TextLink
                type='standAlone'
                data-testId='view-salesTax'
                surface={isDark ? 'dark' : 'light'}
                disabled={false}
                size='small'
                onClick={() => {
                  handleViewSalesTax();
                }}
              >
                {' '}
                View
              </TextLink>
            </LinkWrapper>
          </TileWrapper>
        </TileContainer>
      </TileContainerWrapper>
      {isSalesTaxModalVisible && (
        <SalesTaxModal
          opened={isSalesTaxModalVisible}
          closeModal={closeModal}
          salesTax={salesTax}
          orderDetails={cart.orderDetails}
        />
      )}
    </>
  );
};

SalesTax.propTypes = {
  cart: PropTypes.object,
  readOrder: PropTypes.bool,
  isReadOrderMfeFFlag: PropTypes.bool,
};

export default SalesTax;
