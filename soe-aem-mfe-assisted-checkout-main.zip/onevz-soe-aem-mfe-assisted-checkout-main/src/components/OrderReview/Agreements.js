import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router';
import PropTypes from 'prop-types';
import styled, { createGlobalStyle } from 'styled-components';
import { has } from 'lodash';
import DOMPurify from 'dompurify';
import { Modal, ModalTitle, ModalBody, ModalFooter } from '@vds/modals';
import PDFView from './PDFView';
import { invokeTagging } from '../../utils/test-utils/utils';
import { callOpenViewMFE } from '../../utils/tagging';
import { scmVtMultitaskMode } from '../../utils/common';

const ComponentStyle = createGlobalStyle`
  #agreementsmodal {
    [class^='Overlay-VDS'] {
      background-color: rgba(0, 0, 0);
    }
    [class^='ModalDialog-VDS'] {
      max-width:1024px; 
      border-radius: 0;
      padding: 0;
    }
    [class^='ModalDialogWrapper-VDS'] {
        > span {
          width: 100%;
          height: 100%;

        > div {
          width:100% !important;
          height: 100% !important;

          > div {
            padding:0 !important;
          }
        }
      }
    }

    [class^='StyledModalBody-VDS'] {
      height: 80vh;
    }

    [class^='IconWrapper-VDS'] {
      z-index: 99999;
    }
    
    [class^='StyledHeader-VDS'] {
      border-bottom: 1px solid #ccc;
      position: sticky;
      top:0;
      background: #fff;
      z-index: 999;
      padding: 1rem 0;
    }
    [class^='StyledFooter-VDS'] {
      border-top:  ${(props) => (!props.ipad ? '1px solid #ccc' : 'initial')};
      position: sticky;
      bottom:0;
      background: #fff;
      padding-top: 0.5rem;
      margin-top:  ${(props) => (!props.ipad ? 'initial' : '20px')};
    }
  }
`;

const MarginWrapper = styled.div`
  padding: 0 1rem;
`;

const ModalTitleWrapper = styled.div`
  [class^='StyledHeaderText-VDS'] {
    font-size: 20px;
    font-weight: bold;
    color: #959595;
  }
`;

const ContentBodyWrapper = styled.div`
  background-color: #f6f6f6;
  height: 75vh;
  overflow-y: scroll;
  text-align: center;
  scrollbar-width: thin !important;
`;

const Content = createGlobalStyle`
  #pdfFrame{
    width: 95%;
    height: 70vh;
    margin: 2.5%;
    margin-top: 5%;
  }
`;

const HtmlContentWrapper = styled.div`
  height: 'auto';
  padding-left: '24px';
  line-height: '1.5rem';
`;

const Agreements = (props) => {
  const [openViewTriggered, setOpenViewTriggered] = useState(false);
  const [agreementsData, setAgreementsData] = useState({
    activeAgreement: '',
    hasReachedBottom: sessionStorage.getItem('enableDPTandC') !== 'true',
    enableScroll: false,
    maxPdfPages: 0,
  });

  const scmCheckoutMfeEnabled = window?.mfe?.scmCheckoutMfeEnable;
  const refundReadOrderMfeFFlag =
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.refundReadOrderMfeFFlag === 'TRUE';
  const isRxOrderReviewFlag = props?.isRxOrderReview && refundReadOrderMfeFFlag;

  let navigate = '';

  function useNavigateMFE() {
    navigate = useNavigate();
  }

  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }

  useEffect(() => {
    setAgreementsData({
      ...agreementsData,
      activeAgreement: props.agreementModalData?.title === '' && 'DP',
    });
  }, []);

  const handleScroll = (e) => {
    const { scrollHeight, scrollTop, clientHeight: targetPosition } = e.target;
    const currentPosition = scrollHeight - Math.ceil(scrollTop);
    const relaxation = 10;
    const hasReachedBottom =
      currentPosition > targetPosition - relaxation && currentPosition < targetPosition + relaxation;
    if (hasReachedBottom) {
      setAgreementsData({ ...agreementsData, hasReachedBottom: false });
    }
  };

  const handleAccept = () => {
    const { type, response } = props.installmentAgreementResult;
    if (response?.length > 1 && agreementModalData?.isFirstPdf) {
      props.setShowAgreementModal(false);
      setTimeout(() => {
        props.handleAgreementData({ type, body: response?.[1]?.installmentContractData ?? '', isFirstPdf: false });
      }, 1000);
    } else if (!scmCheckoutMfeEnabled) {
      navigate(
        isRxOrderReviewFlag
          ? `/sales/assisted/new/payment-agreement.html?isRxorderreview=Y`
          : `/sales/assisted/new/payment-agreement.html`,
      );
    } else {
      if (scmVtMultitaskMode()) {
        window?.Emitter?.emit('ACSS_VT_SCM_CHECKOUT_PROGRESS', { data: { payment: 'Y' } });
        return;
      }
      window?.mfe?.historyRef.push(
        isRxOrderReviewFlag ? `payment-agreement.html?isRxorderreview=Y` : `payment-agreement.html`,
      );
    }
    commonTaggingActionHamburgerMenu();
  };

  const commonTaggingActionHamburgerMenu = () => {
    // This is used for MFE Tagging where we are making openview call
    const objOV = {
      channel: 'Order',
      detail: '',
      flow: 'EUP|RFEX-read-order',
      name: 'orderReview',
      intent: 'Order',
      cartId: props?.cartid || '',
      accountNumber: props?.accountnumber || '',
    };
    callOpenViewMFE(objOV);
  };

  const handlePDFViewError = () => {
    setAgreementsData({
      ...agreementsData,
      hasReachedBottom: true,
    });
  };

  const isIpad = !!/iPad|iPhone/i.exec(navigator.userAgent);
  const { channel } = props;

  const agreemnetsProps = {
    tradeinHeaderLabel: 'Trade-in Terms and Conditions',
    dpHeaderLabel: 'Device Payment Terms and Conditions',
    acceptButtonLabel: 'Accept & continue',
    okButtonLableForCare: 'Ok',
    agreementLabel: 'Agreement Details',
  };

  const agreementModalData = props.agreementModalData || {};
  const modalTitle = (
    <span className='u-textBold u-text20 text-grey '>
      {has(agreementModalData, 'title') && agreementModalData.title !== ''
        ? agreementModalData.title
        : agreemnetsProps.agreementLabel}
    </span>
  );

  useEffect(() => {
    if (!openViewTriggered && agreementModalData.type && agreementModalData.type.toLowerCase() === 'pdf') {
      invokeTagging('openView', 'Agreements Details');
      setOpenViewTriggered(true);
    }
  }, [agreementModalData.type]);

  const isChannel =
    channel?.indexOf('OMNI-RETAIL') > -1 || channel?.indexOf('OMNI-D2D') > -1 || channel?.indexOf('OMNI-INDIRECT') > -1;

  const modalFooter = (
    <ModalFooter
      buttonData={{
        primary: {
          children: `${isChannel ? agreemnetsProps.acceptButtonLabel : agreemnetsProps.okButtonLableForCare}`,
          width: `${isChannel ? '220px' : '125px'}`,
          'data-track': `${isChannel ? agreemnetsProps.acceptButtonLabel : agreemnetsProps.okButtonLableForCare}`,
          onClick: () => {
            handleAccept();
          },
          close: true,
          disabled: agreementsData.hasReachedBottom,
        },
      }}
    />
  );

  let modalContent = <div />;
  if (agreementModalData?.type && agreementModalData?.type.toLowerCase() === 'html') {
    modalContent = (
      <>
        <ContentBodyWrapper data-testid='html-content' onScroll={handleScroll}>
          <br />
          <br />
          <HtmlContentWrapper
            dangerouslySetInnerHTML={{
              __html: DOMPurify.sanitize(agreementModalData.body),
            }}
          />
          <br />
        </ContentBodyWrapper>
        <div>{modalFooter}</div>
      </>
    );
  } else if (agreementModalData.type && agreementModalData.type.toLowerCase() === 'pdf' && isIpad) {
    const { body } = agreementModalData;
    modalContent = (
      <>
        <PDFView src={body} onScroll={handleScroll} onError={handlePDFViewError} />
        {modalFooter}
      </>
    );
  } else if (agreementModalData.type && agreementModalData.type.toLowerCase() === 'pdf') {
    const { body } = agreementModalData;
    modalContent = (
      <>
        <div>
          <ContentBodyWrapper id='dpAgreementModalBody' data-testid='pdf-content' onScroll={handleScroll}>
            <Content />
            <object id='pdfFrame' data={`data:application/pdf;base64,${body}`} title='Agreement' type='application/pdf'>
              PDF
            </object>
          </ContentBodyWrapper>
        </div>
        <div>{modalFooter}</div>
      </>
    );
  }
  return (
    <>
      <ComponentStyle ipad={isIpad} />
      <div data-testid='agreementsmodal'>
        <Modal
          id='agreementsmodal'
          fullScreenDialog
          opened={props.showAgreementModal}
          onOpenedChange={(open) => {
            if (!open) props.setShowAgreementModal(false);
          }}
          disableOutsideClick
        >
          <MarginWrapper>
            <ModalTitleWrapper>
              <ModalTitle>{modalTitle}</ModalTitle>
            </ModalTitleWrapper>
            <div id='devicePaymentAgreementModalContent'>
              <ModalBody>{modalContent}</ModalBody>
            </div>
          </MarginWrapper>
        </Modal>
      </div>
    </>
  );
};

Agreements.propTypes = {
  showAgreementModal: PropTypes.bool,
  setShowAgreementModal: PropTypes.func,
  handleAgreementData: PropTypes.func,
  agreementModalData: PropTypes.object,
  channel: PropTypes.string,
  installmentAgreementResult: PropTypes.object,
  cartid: PropTypes.string,
  accountnumber: PropTypes.string,
  isRxOrderReview: PropTypes.bool,
};

export default Agreements;
