import { render, screen, fireEvent } from '@testing-library/react';
import * as React from 'react';
import { BrowserRouter } from 'react-router-dom';
import DownPaymentView from './DownPaymentView';
import StoreProvider from '../../modules/store';
import customerJson from '../../__mock__/retrieve-customer.json';
import cartJson from '../../__mock__/retrive-cart.json';
import { wait } from '../../utils/test-utils/utils';

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
  useLazyGetDeviceDetailsQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: { data: {} },
    },
  ],
}));

jest.mock('onevzsoemfecommon/APIService', () => ({
  ...jest.requireActual('onevzsoemfecommon/APIService'),
  useLazyGetFetchDownpaymentQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: {
        fetchDownPaymentResponse: [
          {
            mtn: '6037312091',
            customerName: 'BEN MANUEL',
            deviceFinanceLimit: 2500,
            totalFinanceLimit: 7000,
            sorId: 'MTQP3LL/A',
            firstMonthPrice: 28.04,
            remaingingMonthPrice: 27.77,
            dpTerm: 36,
            downPayment: '0.0',
            deviceDescription: 'iPhone 15 Pro',
            devicePrice: '999.99',
            maxDownPaymentAmount: 999.63,
            showSellerPrice: false,
            taxAmount: 0,
            spendingLimitAmountExceededBy: '0.0',
            spendingLimitAmountExceeded: false,
            mandatoryDownPayment: 0,
            userSelectedDownPayment: 0,
            instantCreditDownPayment: 0,
            totalDeviceDollar: 0,
            totalRemainingDeviceDollar: 0,
            totalUsedDeviceDollar: 0,
            deviceDollarDownpayment: 0,
            deviceDownPayment: 0,
            vzDollarTotalAmount: 0,
            vzDollarUsedByLine: 0,
            vzDollarUsedByAllLines: 0,
            discountedPrice: 999.99,
          },
          {
            customerName: 'BEN MANUEL',
            deviceFinanceLimit: 2500,
            totalFinanceLimit: 7000,
            sorId: 'MTQP3LL/A',
            firstMonthPrice: 28.04,
            remaingingMonthPrice: 27.77,
            dpTerm: 36,
            deviceDescription: 'iPhone 15 Pro',
            devicePrice: '999.99',
            maxDownPaymentAmount: 999.63,
            showSellerPrice: false,
            taxAmount: 0,
            spendingLimitAmountExceededBy: '0.0',
            spendingLimitAmountExceeded: false,
            mandatoryDownPayment: 0,
            userSelectedDownPayment: 0,
            instantCreditDownPayment: 0,
            totalDeviceDollar: 0,
            totalRemainingDeviceDollar: 0,
            totalUsedDeviceDollar: 0,
            deviceDollarDownpayment: 0,
            deviceDownPayment: 0,
            vzDollarTotalAmount: 0,
            vzDollarUsedByLine: 0,
            vzDollarUsedByAllLines: 0,
            discountedPrice: 999.99,
          },
        ],
      },
    },
  ],
  useLazyComputeDPPricesQuery: () => [
    () => {},
    {
      status: 'Success',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: {
        status: 'Success',
        downPayment: 400,
        remainingMonthPrice: 300,
        firstMonthPrice: 200,
        mtn: '6037312091',
      },
    },
  ],
}));

// eslint-disable-next-line react/prop-types
jest.mock('onevzsoemfecommon/DownPayment', () => ({ setDownPayment }) => (
  <>
    <input type='text' />
    <button type='button' onClick={() => setDownPayment(11, '$', '6037312091')}>
      click
    </button>
  </>
));

const fetchDownPaymentResult = [
  {
    mtn: '6037312091',
    customerName: 'BEN MANUEL',
    deviceFinanceLimit: 2500,
    totalFinanceLimit: 7000,
    sorId: 'MTQP3LL/A',
    firstMonthPrice: 28.04,
    remaingingMonthPrice: 27.77,
    dpTerm: 36,
    downPayment: '0.0',
    deviceDescription: 'iPhone 15 Pro',
    devicePrice: '999.99',
    maxDownPaymentAmount: 999.63,
    showSellerPrice: false,
    taxAmount: 0,
    spendingLimitAmountExceededBy: '0.0',
    spendingLimitAmountExceeded: false,
    mandatoryDownPayment: 0,
    userSelectedDownPayment: 0,
    instantCreditDownPayment: 0,
    totalDeviceDollar: 0,
    totalRemainingDeviceDollar: 0,
    totalUsedDeviceDollar: 0,
    deviceDollarDownpayment: 0,
    deviceDownPayment: 0,
    vzDollarTotalAmount: 0,
    vzDollarUsedByLine: 0,
    vzDollarUsedByAllLines: 0,
    discountedPrice: 999.99,
  },
  {
    mtn: '123',
    customerName: 'BEN MANUEL',
    deviceFinanceLimit: 2500,
    totalFinanceLimit: 7000,
    sorId: 'MTQP3LL/A',
    firstMonthPrice: 28.04,
    remaingingMonthPrice: 27.77,
    dpTerm: 36,
    deviceDescription: 'iPhone 15 Pro',
    devicePrice: '999.99',
    maxDownPaymentAmount: 999.63,
    showSellerPrice: false,
    taxAmount: 0,
    spendingLimitAmountExceededBy: '0.0',
    spendingLimitAmountExceeded: false,
    mandatoryDownPayment: 0,
    userSelectedDownPayment: 0,
    instantCreditDownPayment: 0,
    totalDeviceDollar: 0,
    totalRemainingDeviceDollar: 0,
    totalUsedDeviceDollar: 0,
    deviceDollarDownpayment: 0,
    deviceDownPayment: 0,
    vzDollarTotalAmount: 0,
    vzDollarUsedByLine: 0,
    vzDollarUsedByAllLines: 0,
    discountedPrice: 999.99,
  },
];
describe('DownPaymentView Component', () => {
  test('renders DownPaymentView', () => {
    sessionStorage.setItem('cartId', '1234567');
    const handleDPClose = jest.fn();
    const handleDPDone = jest.fn();
    const setDownpayment = jest.fn();
    const CustomerProfileResult = {
      data: customerJson,
    };
    const requestBodyDeviceDetails = {};

    render(
      <BrowserRouter>
        <StoreProvider>
          <DownPaymentView
            handleDPClose={handleDPClose}
            CustomerProfileResult={CustomerProfileResult}
            activeMtn=''
            setDownPayment={setDownpayment}
            handleDPDone={handleDPDone}
            requestBodyDeviceDetails={requestBodyDeviceDetails}
            cart={cartJson.data.cart}
            fetchDownPaymentResult={fetchDownPaymentResult}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getByTestId('downpaymentView');
    expect(titleElement).toBeInTheDocument();
    const inputValue = screen.getAllByRole('textbox')[0];
    fireEvent.blur(inputValue, { target: { value: '56' } });
    fireEvent.change(inputValue, { target: { value: '56' } });
    const doneBtn = screen.getByTestId('handleDPDone-button');
    fireEvent.click(doneBtn);
    wait(1000);
    expect(doneBtn).toBeInTheDocument();
  });
  test('renders DownPaymentView--without cartID value in payload', () => {
    const handleDPClose = jest.fn();
    const handleDPDone = jest.fn();
    const setDownpayment = jest.fn();
    const CustomerProfileResult = {
      data: customerJson,
    };
    const requestBodyDeviceDetails = {};
    render(
      <BrowserRouter>
        <StoreProvider>
          <DownPaymentView
            handleDPClose={handleDPClose}
            CustomerProfileResult={CustomerProfileResult}
            activeMtn=''
            setDownPayment={setDownpayment}
            handleDPDone={handleDPDone}
            requestBodyDeviceDetails={requestBodyDeviceDetails}
            fetchDownPaymentResult={fetchDownPaymentResult}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getByTestId('downpaymentView');
    expect(titleElement).toBeInTheDocument();
    const inputValue = screen.getAllByRole('textbox')[1];
    fireEvent.blur(inputValue, { target: { value: '56' } });
    fireEvent.change(inputValue, { target: { value: '56' } });
    fireEvent.click(screen.getAllByText('click')[0]);
    const doneBtn = screen.getByTestId('handleDPDone-button');
    fireEvent.click(doneBtn);
    wait(1000);
    expect(doneBtn).toBeInTheDocument();
  });

  test('renders DownPaymentView--without active mtn value in payload', () => {
    const handleDPClose = jest.fn();
    const handleDPDone = jest.fn();
    const setDownpayment = jest.fn();
    const CustomerProfileResult = {
      data: customerJson,
    };
    const requestBodyDeviceDetails = {};
    render(
      <BrowserRouter>
        <StoreProvider>
          <DownPaymentView
            handleDPClose={handleDPClose}
            CustomerProfileResult={CustomerProfileResult}
            setDownPayment={setDownpayment}
            handleDPDone={handleDPDone}
            requestBodyDeviceDetails={requestBodyDeviceDetails}
            fetchDownPaymentResult={fetchDownPaymentResult}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getByTestId('downpaymentView');
    expect(titleElement).toBeInTheDocument();
    const inputValue = screen.getAllByRole('textbox')[0];
    fireEvent.blur(inputValue, { target: { value: '56' } });
    fireEvent.change(inputValue, { target: { value: '56' } });
    const doneBtn = screen.getByTestId('handleDPDone-button');
    fireEvent.click(doneBtn);
    wait(1000);
    expect(doneBtn).toBeInTheDocument();
  });

  test('renders DownPaymentView--without active mtn value in payload', () => {
    const handleDPClose = jest.fn();
    const handleDPDone = jest.fn();
    const setDownpayment = jest.fn();
    const CustomerProfileResult = {
      data: customerJson,
    };
    const requestBodyDeviceDetails = {};
    render(
      <BrowserRouter>
        <StoreProvider>
          <DownPaymentView
            handleDPClose={handleDPClose}
            CustomerProfileResult={CustomerProfileResult}
            setDownPayment={setDownpayment}
            handleDPDone={handleDPDone}
            requestBodyDeviceDetails={requestBodyDeviceDetails}
            fetchDownPaymentResult={fetchDownPaymentResult}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getByTestId('downpaymentView');
    expect(titleElement).toBeInTheDocument();

    const doneBtn = screen.getByTestId('handleDPDone-button');
    fireEvent.click(doneBtn);
    wait(1000);
    expect(doneBtn).toBeInTheDocument();
  });

  test('renders DownPaymentView--without accountNo value in payload', () => {
    const handleDPClose = jest.fn();
    const handleDPDone = jest.fn();
    const setDownpayment = jest.fn();
    const CustomerProfileResult = {
      data: customerJson,
    };
    const accountNumber = 'accountNo';
    delete CustomerProfileResult.data.data.customer[accountNumber];
    const requestBodyDeviceDetails = {};
    render(
      <BrowserRouter>
        <StoreProvider>
          <DownPaymentView
            handleDPClose={handleDPClose}
            CustomerProfileResult={CustomerProfileResult}
            setDownPayment={setDownpayment}
            handleDPDone={handleDPDone}
            requestBodyDeviceDetails={requestBodyDeviceDetails}
            fetchDownPaymentResult={fetchDownPaymentResult}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getByTestId('downpaymentView');
    expect(titleElement).toBeInTheDocument();
    const inputValue = screen.getAllByRole('textbox')[0];
    fireEvent.blur(inputValue, { target: { value: '56' } });
    fireEvent.change(inputValue, { target: { value: '56' } });
    const doneBtn = screen.getByTestId('handleDPDone-button');
    fireEvent.click(doneBtn);
    wait(1000);
    expect(doneBtn).toBeInTheDocument();
  });
});
