/* eslint-disable no-nested-ternary */
import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { has, isEmpty } from 'lodash';
import DOMPurify from 'dompurify';
import styled from 'styled-components';
import { Icon } from '@vds/icons';
import PropTypes from 'prop-types';
import { Line } from '@vds/lines';
import { Modal } from '@vds/modals';
import { Body } from '@vds/typography';
import { TileContainer } from '@vds/tiles';
import { TitleLockup } from '@vds/type-lockups';
import { TextLink, Button } from '@vds/buttons';
import { Input as VdsInput } from '@vds/inputs';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import DeviceLockInformation from 'onevzsoemfecommon/DeviceLockInformation';
import { Tooltip } from '@vds/tooltips';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import DevicesModal from './DevicesModal';
import { invokeTagging } from '../../utils/test-utils/utils';
import {
  formatPhoneNumberWithSymbol,
  getPlanDetail,
  getCamelCaseName,
  formatCurrency,
  getDisplayableFeatures,
} from '../../utils/common';
import { FlexBox, PaddingBot24, PaddingBottom12, StyledPaddingLeft8, Padding16 } from '../../StyledConstants';
import PriceInfo from './PriceInfo';
import InfoApiCallHook from '../../modules/services/APIService/InfoAPICallHook';
import {
  requestBodyUserInfo,
  requestBodyPricingSnap,
  requestBodyAllActiveMTN,
  requestBodyGetDetails,
} from '../../modules/services/APIService/APIRequestBody';
import Devices from './Devices';
import DiscountPromotions from './DiscountPromotions';
import ExistingServicePerks from './ExistingServicePerks';
import AccessoriesCheckoutDetails from './AccessoriesCheckoutDetails';
import NetworkIcon from '../../assests/NetworkIcon.png';
import AddIcon from '../../assests/orderReviewIcons/addIcon.png';
import CusIcon from '../../assests/orderReviewIcons/cus-copyIcon.png';
import HeadIcon from '../../assests/orderReviewIcons/head-copyIcon.png';
import MobileIcon from '../../assests/orderReviewIcons/mobile-copyIcon.png';
import PlanIcon from '../../assests/orderReviewIcons/p-copyIcon.png';
import { TAX_SOFT_SKU } from '../../appconfig';
import perkImages from '../../assests/perkIcons/perkIcons';
import {
  DARK_THEME_COLOR,
  DARK_THEME_BGCOLOR,
  activationStyleYellow,
  activationStyleGreen,
} from '../constants/constants';
import DFOPriceInfo from './DFOPriceInfo';
import ActivationStatus from '../ReadOrder/ActivationStatus';
import { callOpenViewMFE, OpenViewTagging } from '../../utils/tagging';

const EditInfoWrapper = styled.div`
  padding: 20px 0;
`;
const StyledPaddingTopBot15 = styled.div`
  padding-top: 25px;
  padding-bottom: 15px;
`;
const ImgWrapper = styled.div`
  display: flex;
  width: 252px;
  height: 215px;
  cursor: pointer;
`;
const LeftSideWrapper = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  margin-top: 2rem;
  min-width: 236px;
  padding: 0 10px;
`;
const TextLinkWrapper = styled.div`
  margin-right: auto;
  a {
    display: block;
    margin-bottom: 5px;
    border: none;
    text-decoration: underline;
    white-space: normal;
    float: left;
  }
  a:hover {
    border: none;
  }
  [id^='EditLine-font'] {
    font-size: 15px;
    font-family: BrandFont-Text, Arial, sans-serif !important;
  }
`;

const InfoWrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  justify-content: flex-start;
`;

const LineWrapper = styled.div`
  display: block;
`;

const BreakdownWrapper = styled.div`
  display: flex;
`;

const lineActivityIndicator = {
  AAL: 'Add a line',
  EUP: 'Equipment upgrade',
  FEA: 'Services & perks change',
  CPC: 'Price plan change',
  SOC: 'SIM Only Change',
  indirectEUP: 'Device Upgrade',
  indirectAAL5G: 'New Line',
};

const TileContainerWrapper = styled.div`
  display: flex;
  height: 100%;
  [class^='OuterTileContainer'] {
    border-radius: 0px !important;
    height: 100%;
    padding: 0px;
  }
`;

const TileWrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
`;

const LinkWrapper = styled.div`
  text-align: left;
  padding-left: 1rem;
  padding-bottom: 1rem;
  padding-top: 1rem;
`;

const NameWrapper = styled.div`
  text-align: left;
  padding: 0 1rem;
`;

const AccessoriesWrapper = styled.div`
  width: 384px;
  margin-top: 20px;
`;

const CheckoutLineWrapper = styled.div`
  margin-top: 5px;
`;

const EligibleText = styled.div`
  font-size: 12px;
  .highlight-text {
    margin-left: 5px;
    color: #0c7810;
  }
`;
const NewTitleLockup = styled.div`
  [class^='StyledTypography-VDS'] {
    font-size: 18px;
  }
`;

const PriceWrapper = styled.div`
  display: flex;
  justify-content: ${(props) => props.addSpacing && 'space-between'};
  margin-bottom: 0.25rem;
  padding: ${(props) => (props.bottomBorder ? '4px 0px' : '0px')};
  border-bottom: ${(props) => (props.bottomBorder ? '1px solid #ccc' : '')};
  margin-bottom: ${(props) => (props.bottomBorder ? '8px' : '')};

  p {
    font-family: BrandFont-Text, Helvetica, Arial, sans-serif;
    font-size: 18px;
    line-height: normal;
  }
`;

const Title = styled.div`
  font-size: 20px;
  font-weight: 700;
  line-height: 1.25rem;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  letter-spacing: 0.03125rem;
  color: rgb(0, 0, 0);
  margin: 0px;
  text-decoration: none;
`;
const BorderLine = styled.div`
  border-bottom: 1px solid rgb(216, 218, 218);
  height: 0.0625rem;
  width: 100%;
`;

const SetupAndGoWrapper = styled.div`
  padding: 8px 14px;
`;
const ImageWrapper = styled.div`
  padding-left: 0.75rem;
`;

const IconImageWrapper = styled.img`
  margin-right: 0.375rem;
`;

const baseURL = window.location.origin;
const iconPaths = {
  addALineIconPath: '/content/dam/vcg/assisted/addIcon.png',
  upgradeLineIconPath: '/content/dam/vcg/assisted/mobile-copyIcon.png',
  accessoriesIconPath: '/content/dam/vcg/assisted/head-copyIcon.png',
  featureChangeIconPath: '/content/dam/vcg/assisted/cus-copyIcon.png',
  planChangeIconPath: '/content/dam/vcg/assisted/p-copyIcon.png',
};
const AALIconPath = iconPaths.addALineIconPath ? DOMPurify.sanitize(baseURL + iconPaths.addALineIconPath) : '';
const eupIconPath = iconPaths.upgradeLineIconPath ? DOMPurify.sanitize(baseURL + iconPaths.upgradeLineIconPath) : '';
const cpcIconPath = iconPaths.planChangeIconPath ? DOMPurify.sanitize(baseURL + iconPaths.planChangeIconPath) : '';
const feaIconPath = DOMPurify.sanitize(baseURL + iconPaths.featureChangeIconPath);
const accessoryIconPath = DOMPurify.sanitize(baseURL + iconPaths.accessoriesIconPath);

const CheckoutLine = ({
  line,
  lineInfo,
  customerName,
  fetchPriceSnapshot,
  planId,
  cart,
  showDownpaymentView,
  setHideShippingDetails,
  CustomerProfileRefetch,
  CartDetailsRefetch,
  fetchPriceSnapshotRefetch,
  setProfInstallappointmentFlag,
  readOrder,
  lineDeviceAndSimIds,
  activationStats,
  orderStatus,
  cartHeader,
  readOrderData,
  hasSubAccount,
  subAccount,
  rspFetchReadOrder,
}) => {
  const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable;
  const dispatch = useDispatch();
  const [viewMoreText, setViewMoreText] = useState('View more');
  const [showEditInfo, setShowEditInfo] = useState(false);
  const [firstName, setFirstName] = useState(customerName);
  const [name, setName] = useState(customerName);
  const [showModal, setShowModal] = useState(false);
  const scmCheckoutMfeEnabled = window?.mfe?.scmCheckoutMfeEnable;
  const [nameError, setNameError] = useState(false);
  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;
  const bgColor = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.themeProps?.background;
  const [monthlyInstallmentAmount, setMonthlyInstallmentAmount] = useState(
    line?.installmentInfo?.monthlyInstallment || 0,
  );
  const [isReadOrderMfe] = getAssistedCradlePropertyV2(['readOrderMfeFFlag']);
  const isReadOrderMfeFFlag = /true/i.test(isReadOrderMfe);
  const [isDeviceModalVisible, setisDeviceModalVisible] = useState(false);

  const handleViewDevices = () => {
    invokeTagging('openView', 'Edit Device');
    setisDeviceModalVisible(true);
  };

  const closeDeviceModal = () => {
    setisDeviceModalVisible(false);
  };

  const postToNewPreIndicator = cart?.orderDetails?.isPrePayCart;

  const capitalizeWords = (text) =>
    text
      .split(' ')
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');

  const openModal = () => {
    invokeTagging('openView', 'Device Lock Information');
    setShowModal(true);
  };

  const closeModal = () => {
    invokeTagging('closeView', '');
    setShowModal(false);
  };
  const getLineFeatures = (mtn) => {
    const isPrepay = !!(postToNewPreIndicator === 'Y');
    const lineAccessFee = isPrepay
      ? lineInfo?.filter((item) => item.mobileNumber === mtn)
      : subAccount?.[0]?.lines.find((ele) => ele.mtn === mtn);
    return lineAccessFee;
  };
  const { submitUserInfo, submitUserInforSuccess, fetchPricingSnapRequest, getActiveMTNRequest } = InfoApiCallHook();

  const saveUserInfo = () => {
    if (firstName?.length) {
      const nameRegEx = /^[a-zA-Z]+([',. -][a-zA-Z]+)*$/g;
      if (firstName?.match(nameRegEx) === null) {
        setNameError(true);
        return;
      }

      const payload = JSON.parse(JSON.stringify(requestBodyUserInfo));
      payload.lines[0].firstName = firstName;
      payload.lines[0].email = emailId;
      payload.lines[0].mtn = mtn;
      submitUserInfo({ body: payload, spinner: false, mock: false });
      if (scmCheckoutMfeEnabled) {
        const acssMFEcartId = sessionStorage.getItem('acssMfeCartId');
        const requestBodyFetchPricing = {
          cartId: acssMFEcartId,
          requestSource: 'ORDER_REVIEW',
        };
        fetchPricingSnapRequest({ body: requestBodyFetchPricing, spinner: true, mock: false });
      } else {
        fetchPricingSnapRequest({ body: requestBodyPricingSnap, spinner: true, mock: false });
      }
      if (cart?.orderDetails?.customerType !== 'N') {
        getActiveMTNRequest({ body: requestBodyAllActiveMTN, spinner: true, mock: false });
      }
      setShowEditInfo(false);
    }
  };

  const planDetail = getPlanDetail(line);
  let cartItems = [];
  cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
  const isNewLine = line?.mtnDetails?.lineNumber?.includes('newLine');
  let lineActivityIndicatorIndex = line?.lineActivityType || '';
  if (
    (line?.lineActivityType?.includes('BYOD') && isNewLine) ||
    ((line?.lineActivityType?.includes('NSE') ||
      line?.lineActivityType?.includes('NSE_LTE') ||
      line?.lineActivityType?.includes('NSE_5G')) &&
      isNewLine)
  ) {
    lineActivityIndicatorIndex = 'AAL';
  }

  const currentDevice = has(line, 'serviceInfo.currentDevice.oldLteVoraEquipInfo.lteVoraDeviceInfo')
    ? line.serviceInfo.currentDevice.oldLteVoraEquipInfo.lteVoraDeviceInfo
    : {};

  const mtn = line?.mtnDetails?.mobileNumber || line?.mtnDetails?.lineNumber;

  const lineActivityType = lineActivityIndicator[lineActivityIndicatorIndex] || '';

  const sbdOffer = line?.serviceInfo?.sbdOffer || [];
  const mobileNumber = has(line, 'mobileNumber') ? line.mobileNumber : '';
  const serviceInfo = has(line, 'serviceInfo') ? line.serviceInfo : {};
  const primaryUserInfo = has(serviceInfo, 'primaryUserInfo') ? serviceInfo.primaryUserInfo : {};
  const emailId = primaryUserInfo?.emailId;
  const readOrderLineInfo = lineInfo || [];
  const readOrderLine =
    readOrderLineInfo.length && readOrderLineInfo.find((lineItem) => lineItem?.mobileNumber === mobileNumber);

  const offerAmount = cartItems?.cartItem?.find((cartItem) => cartItem?.cartItemType === 'UPGRADE_FEE');
  const upgradeFeeAmount = offerAmount?.itemPrice;
  const buyOutAmount = cartItems?.cartItem?.find(
    (cartItem) => cartItem?.cartItemType === 'SOFT_SKU' && cartItem?.itemCode === 'BUYOUTPMT',
  );
  const retailAmount = cartItems?.cartItem?.find((item) => item?.priceType === 'MONTH_TO_MONTH');

  /* istanbul ignore next */
  const deviceCartItem = cartItems?.cartItem?.find(
    (item) => item?.cartItemType === 'DEVICE' || (line?.buySimOnly && item?.cartItemType === 'SIM'),
  );

  const setupGoAmount = cartItems?.cartItem?.find(
    (cartItem) =>
      cartItem?.cartItemType === 'SOFT_SKU' &&
      cartItem?.prodCode1 === 'LAB' &&
      cartItem?.prodCode2 === 'SER' &&
      cartItem?.prodCode4 === 'SUG',
  );

  if (setupGoAmount) {
    setHideShippingDetails(!!setupGoAmount);
  }

  const getPaymentLabel = () => {
    if (readOrder && isReadOrderMfeFFlag) {
      return !sessionStorage?.getItem('channel')?.includes('OMNI-INDIRECT')
        ? 'Device Balance/Device downpayment'
        : 'Down payment';
    }
    return 'Down payment';
  };

  const getSetupGoCartItemType = (cartDevice) => (
    <SetupAndGoWrapper>
      <PriceWrapper>
        <Title color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>Setup & Go</Title>
        <Tooltip size='medium' surface={isDark ? 'dark' : 'light'}>
          One-time service charge for in store device set up assistance with a Verizon expert.
        </Tooltip>
      </PriceWrapper>
      <PriceWrapper addSpacing>
        <Body size='medium' color={isDark ? DARK_THEME_COLOR : ''}>
          Service Charge{' '}
        </Body>
        <StyledPaddingLeft8>
          <Body size='medium' color={isDark ? DARK_THEME_COLOR : ''}>
            {cartDevice?.discountedPrice >= 0
              ? formatCurrency(cartDevice.discountedPrice)
              : formatCurrency(cartDevice.itemPrice)}
          </Body>
        </StyledPaddingLeft8>
      </PriceWrapper>
    </SetupAndGoWrapper>
  );

  const rebateOffers = deviceCartItem?.rebateOffers;

  const displayLineFeatures =
    readOrder && isReadOrderMfeFFlag
      ? fetchPriceSnapshot?.data?.data?.subAccounts?.[0]?.lines?.find((lineList) => lineList.mtn === mobileNumber)
      : subAccount?.[0]?.lines?.find((lineList) => lineList.mtn === mobileNumber);
  const fpsReferences = fetchPriceSnapshot?.data?.data?.reference;
  const displayableFeatures = getDisplayableFeatures(displayLineFeatures);
  const { newFeatures, existingFeatures, oldFeatures } = displayableFeatures;
  let features = [];
  if (!isEmpty(displayableFeatures)) {
    features = [...newFeatures, ...existingFeatures];
  }

  const defaultImageLabel = 'https://ss7.vzw.com/is/image/VerizonWireless/device_protection_120817?$pngalpha$';
  const getImage = (sorId) => {
    let imageUrl = defaultImageLabel;
    if (!isEmpty(displayableFeatures)) {
      const pricingSnapShotReference = fetchPriceSnapshot?.data?.data?.reference;
      const pngalphaLabel = '?$pngalpha$';
      const skuImg =
        has(pricingSnapShotReference, 'skus') &&
        pricingSnapShotReference.skus.length &&
        pricingSnapShotReference.skus.find((sku) => sku.sorId === sorId);
      if (has(skuImg, 'imageUrlMap.defaultImage')) {
        imageUrl = skuImg.imageUrlMap.defaultImage.includes(pngalphaLabel)
          ? skuImg.imageUrlMap.defaultImage
          : skuImg.imageUrlMap.defaultImage + pngalphaLabel;
      }
    }
    return imageUrl;
  };
  let activationStatusMdn = [];
  activationStatusMdn = readOrderData?.activationDtls?.filter(
    (activation) => activation?.mobileNumber === line?.mobileNumber,
  );
  const activationStatus = activationStatusMdn?.[0]?.activationMessage;
  const [showActivationModal, setShowActivationModal] = useState(false);
  const displayDeviceContent = (element = {}) => {
    const isPreOrder = has(element, 'inventory.isPreOrder')
      ? element?.inventory?.isPreOrder
      : element?.inventoryStatus?.isPreOrder;
    const isBackorder = has(element, 'inventory.isBackorder')
      ? element?.inventory?.isBackorder
      : element?.inventoryStatus?.isBackorder;
    const shippingDate = element?.preBackDate;
    const ispuItem = has(line, 'ispuItem') ? line?.ispuItem : false;
    const preOrderText =
      isPreOrder && isPreOrder === true && !ispuItem ? (
        <TitleLockup
          surface={isDark ? 'dark' : 'light'}
          data={{
            title: {
              size: 'bodyLarge',
              children: (
                <div className='u-text18 bold u-paddingYLarge '>
                  {' '}
                  Pre order estimated <br />
                  ship date {shippingDate || ''}{' '}
                </div>
              ),
              bold: true,
            },
          }}
        />
      ) : (
        ''
      );
    const backOrderText =
      isBackorder && isBackorder === true && !ispuItem ? (
        <TitleLockup
          surface={isDark ? 'dark' : 'light'}
          data={{
            title: {
              size: 'bodyLarge',
              children: (
                <div className='u-text18 bold u-paddingYLarge'>
                  {' '}
                  Back order estimated <br />
                  ship date {shippingDate || ''}{' '}
                </div>
              ),
              bold: true,
            },
          }}
        />
      ) : (
        ''
      );
    const colorDisplayName = isCPCorFEA ? element?.color?.description : element?.color?.colorDisplayName || '';
    const isPrepay = !!(postToNewPreIndicator === 'Y');
    const lineFeaturesDetails = getLineFeatures(line?.mobileNumber);
    const lineFeatures = isPrepay === true ? lineFeaturesDetails[0] : lineFeaturesDetails;
    const addonsDueMonthly = isPrepay
      ? lineFeatures?.totalDueAddOnMonthly
      : lineFeatures?.addonsDueMonthly?.regularPrice;

    const shipmentStatus = readOrderLine?.shipmentStatus ? readOrderLine?.shipmentStatus : '';
    const isDFO = element?.isDfoSelected && element?.eMIVerizonPayment;
    const isLineAccessCharge =
      lineFeatures?.existingPlan?.isLineAccessCharge || lineFeatures?.selectedPlan?.isLineAccessCharge;

    // Getting data from fetchsnapshot to integrate below values
    const lineType = mtnLine;
    let planPrice = '';
    let payment = '';
    let price = '';
    let lineAccessFee = '';
    let addOns = [];

    if (lineType && Array.isArray(lineType)) {
      lineType.forEach((lineFeature) => {
        if (has(lineFeature, 'selectedPlan.planId') || has(lineFeature, 'existingPlan.planId')) {
          planPrice = lineFeature?.existingPlan?.planPerksCost
            ? lineFeature?.existingPlan?.planPerksCost
            : lineFeature?.selectedPlan?.planPerksCost;
          payment = lineFeature?.selectedPlan?.displayName
            ? lineFeature?.selectedPlan?.displayName
            : lineFeature?.existingPlan?.displayName;
          price = lineFeature?.selectedPlan?.price.discountedPrice
            ? lineFeature?.selectedPlan?.price.discountedPrice
            : lineFeature?.existingPlan?.price.discountedPrice;
        }
        lineAccessFee = lineFeature?.selectedPlan?.price?.regularPrice
          ? lineFeature?.selectedPlan?.price?.regularPrice
          : lineFeature?.existingPlan?.price?.regularPrice;
        addOns = lineFeature?.addons?.filter((ele) => ele?.isPerk && ele?.actionIndicator !== 'D');
      });
    }

    const hasDownPaymentDDapplied = () => {
      const DownPaymentDD =
        has(line, 'installmentInfo.downPayment') &&
        has(line, 'installmentInfo.deviceDollarDownpayment') &&
        line?.installmentInfo?.deviceDollarDownpayment > 0
          ? {
              downPayment: formatCurrency(line?.installmentInfo?.downPayment),
              DDdownPayment: formatCurrency(line?.installmentInfo?.deviceDollarDownpayment),
              DPafterDDapplied:
                has(line, 'installmentInfo.userSelectedDownPayment') &&
                line?.installmentInfo?.userSelectedDownPayment > 0
                  ? formatCurrency(line?.installmentInfo?.userSelectedDownPayment)
                  : line?.installmentInfo && formatCurrency(line?.installmentInfo?.mandatoryDownPayment),
            }
          : {};

      return DownPaymentDD;
    };

    const showDP = element?.priceType === 'VERIZON_EDGE' && isEmpty(hasDownPaymentDDapplied());

    const { setUpLater = null } = line?.serviceInfo || {};
    const ispuFlag = !!line?.ispuItem;
    const isCLNRFlow = sessionStorage.getItem('isCLNRFlow') || false;
    const showDeviceAboveAccessory =
      ['EUP', 'AAL', 'AAL_LTE', 'AAL_5G', 'NSE_5G'].includes(line?.lineActivityType) ?? false;
    const showDeviceHeading = showDeviceAboveAccessory && !isCLNRFlow;
    const isTGWSelected = lineInfo?.find((tgwLine) => tgwLine?.tanglewoodSelected === 'Y')?.tanglewoodSelected === 'Y';
    const handleFirstName = (fName) => {
      setNameError(false);
      setFirstName(fName);
    };

    let shouldAllowEdit;
    /* istanbul ignore next */
    const is5GEligible = ['AAL_LTE', 'AAL_5G'].includes(line?.lineActivityType) ?? false;
    const isStatusEditable = !readOrder || (readOrder && orderStatus !== 'CO');
    if (scmCheckoutMfeEnabled) {
      const meets5GCriteria = is5GEligible && retailAmount?.itemPrice > 0;
      shouldAllowEdit = showDeviceAboveAccessory && isStatusEditable && (meets5GCriteria || !is5GEligible);
    } else {
      shouldAllowEdit = showDeviceAboveAccessory && isStatusEditable;
    }

    return (
      <>
        {hasSubAccount && (
          <>
            <Padding16>
              <Title>{subAccount?.[0]?.subAccountId}</Title>
            </Padding16>
            <BorderLine />
          </>
        )}
        <CheckoutLineWrapper key={name}>
          <FlexBox>
            <LeftSideWrapper>
              {element?.cartItemType !== 'ACCESSORY' && (
                <>
                  <NewTitleLockup>
                    <TitleLockup
                      surface={isDark ? 'dark' : 'light'}
                      data={{
                        title: {
                          size: 'titleSmall',
                          children: capitalizeWords(name),
                          bold: true,
                        },
                        subtitle: {
                          color: 'secondary',
                          size: 'titleSmall',
                          children: line?.mobileNumber && formatPhoneNumberWithSymbol(line.mobileNumber, '-'),
                        },
                      }}
                    />
                  </NewTitleLockup>
                  <NewTitleLockup>
                    <TitleLockup
                      surface={isDark ? 'dark' : 'light'}
                      data={{
                        title: {
                          size: 'titleSmall',
                          children: lineActivityType,
                          bold: true,
                        },
                        subtitle: {
                          size: 'titleSmall',
                          children:
                            has(planDetail, 'planInfo.pricePlanDesc') && !planDetail.isAccount
                              ? planDetail.planInfo.pricePlanDesc
                              : '',
                        },
                      }}
                    />
                  </NewTitleLockup>
                  {line &&
                    !line?.buySimOnly &&
                    (line?.lineActivityType === 'EUPBYOD' || line?.lineActivityType === 'AALBYOD') && (
                      <TitleLockup
                        surface={isDark ? 'dark' : 'light'}
                        data={{
                          title: {
                            size: 'titleSmall',
                            children: 'DEVICE Change',
                            bold: true,
                          },
                        }}
                      />
                    )}
                  <ImageWrapper>
                    {line &&
                      !line?.buySimOnly &&
                      (line?.lineActivityType?.includes('AAL') ||
                        line?.lineActivityType?.includes('AAL_LTE') ||
                        line?.lineActivityType?.includes('AAL_5G') ||
                        line?.lineActivityType?.includes('NSE') ||
                        line?.lineActivityType?.includes('NSE_LTE') ||
                        line?.lineActivityType?.includes('BYOD') ||
                        (line?.lineActivityType && line.lineActivityType === 'NSE_5G')) && (
                        <IconImageWrapper
                          src={!scmCheckoutMfeEnabled ? AALIconPath : AddIcon}
                          className='margin-right-micro'
                          alt='add-line-icon'
                        />
                      )}
                    {line &&
                      (line?.lineActivityType?.includes('EUP') ||
                        line?.lineActivityType === 'NSE_5G' ||
                        line?.lineActivityType?.includes('AAL') ||
                        line?.lineActivityType?.includes('AAL_LTE') ||
                        line?.lineActivityType?.includes('AAL_5G') ||
                        lineActivityType === 'AAL' ||
                        line.buySimOnly) && (
                        <IconImageWrapper
                          src={!scmCheckoutMfeEnabled ? eupIconPath : MobileIcon}
                          alt='upgrade-line-icon'
                          className='margin-right-micro'
                          data-testid='upgrade-line-icon'
                        />
                      )}
                    {accessories && accessories.length > 0 && (
                      <IconImageWrapper
                        src={!scmCheckoutMfeEnabled ? accessoryIconPath : HeadIcon}
                        className='margin-right-micro'
                        alt='accessories-icon'
                      />
                    )}
                    {line &&
                      (line?.lineActivityType?.includes('AAL') ||
                        line?.lineActivityType?.includes('AAL_LTE') ||
                        line?.lineActivityType?.includes('AAL_5G') ||
                        line?.lineActivityType?.includes('NSE') ||
                        line?.lineActivityType?.includes('NSE_LTE') ||
                        (line?.lineActivityType && line.lineActivityType === 'CPC') ||
                        (line?.lineActivityType && line.lineActivityType === 'NSE_5G') ||
                        (line?.lineActivityType?.includes('BYOD') && !line?.buySimOnly) ||
                        line?.selectedFeaturesList?.newPricePlanInfo) && (
                        <IconImageWrapper
                          src={!scmCheckoutMfeEnabled ? cpcIconPath : PlanIcon}
                          alt='plan-change-icon'
                          className='margin-right-micro'
                        />
                      )}
                    {((userAddedFeatures && userAddedFeatures.length > 0) || line.buySimOnly) && (
                      <IconImageWrapper
                        src={!scmCheckoutMfeEnabled ? feaIconPath : CusIcon}
                        className='margin-right-micro'
                        alt='feature-change-icon'
                      />
                    )}
                  </ImageWrapper>
                  <LineWrapper>
                    {readOrder && isReadOrderMfeFFlag && (
                      <>
                        <TextLink
                          type='standAlone'
                          data-testid='activation-view-link'
                          style={
                            activationStatus === 'Not sent for activation'
                              ? activationStyleYellow
                              : activationStyleGreen
                          }
                          surface='light'
                          disabled={false}
                          onClick={() => {
                            setShowActivationModal(true);
                            const obj = {
                              channel: 'Order',
                              detail: 'activationStatus',
                              flow: 'EUP|read-order',
                              name: 'read-order',
                              intent: 'Order',
                              cartId: sessionStorage.getItem('cartId'),
                              isAutoPayEnrolled: readOrderData?.cart?.lineDetails?.isAutoPayEnrolled || '',
                              zip: readOrderData?.cart?.orderDetails?.accountAddress?.zipCode || '',
                            };
                            callOpenViewMFE(obj);
                          }}
                          text-align='right'
                        >
                          {getCamelCaseName(activationStatus)}
                        </TextLink>
                        <Icon
                          name={activationStatus === 'Not sent for activation' ? 'warning' : 'checkmark-alt'}
                          size='small'
                          color='#000000'
                        />
                      </>
                    )}
                  </LineWrapper>
                  {showActivationModal && (
                    <Modal
                      opened={showActivationModal}
                      fullScreenDialog
                      disableOutsideClick
                      closeButton={null}
                      disableAnimation
                    >
                      <ActivationStatus
                        cartData={readOrderData?.cartData}
                        closeActivationStatus={() => setShowActivationModal(false)}
                        viewOnlyActivationStatusFlag
                        customerProfile={readOrderData?.customerProfile}
                        readOrderData={readOrderData?.readOrderData}
                      />
                    </Modal>
                  )}
                  <ImgWrapper data-testid='mfe-true' onClick={() => handleViewDevices()}>
                    <img
                      src={element?.imageUrlMap?.defaultImage ? element.imageUrlMap.defaultImage : ''}
                      style={{ maxHeight: isTGWSelected ? '80px' : '200px' }}
                      alt={`${element?.manufacturer || ''} ${element?.description || ''}`}
                      className='u-cursorPointer'
                    />
                  </ImgWrapper>
                  <NewTitleLockup>
                    <TitleLockup
                      surface={isDark ? 'dark' : 'light'}
                      data={{
                        title: {
                          size: 'titleSmall',
                          children: element?.manufacturer
                            ? `${element?.manufacturer} ${element?.description}`
                            : element.description,
                          bold: true,
                        },
                        subtitle: {
                          color: 'secondary',
                          size: 'titleSmall',
                          children:
                            element?.capacity && colorDisplayName
                              ? `${element.capacity} / ${getCamelCaseName(colorDisplayName)}`
                              : '',
                        },
                      }}
                    />
                  </NewTitleLockup>
                  {setUpLater !== null && (
                    <NewTitleLockup>
                      <TitleLockup
                        surface={isDark ? 'dark' : 'light'}
                        data={{
                          title: {
                            size: 'titleSmall',
                            children: setUpLater && !ispuFlag ? 'Setup later' : 'Setup now',
                            bold: true,
                          },
                        }}
                      />
                    </NewTitleLockup>
                  )}
                  {emailId && (
                    <NewTitleLockup style={{ 'word-break': 'break-all' }}>
                      <TitleLockup
                        surface={isDark ? 'dark' : 'light'}
                        data={{
                          subtitle: {
                            size: 'titleSmall',
                            children: `${emailId.toLowerCase()}`,
                            bold: true,
                          },
                        }}
                      />
                    </NewTitleLockup>
                  )}
                  {shipmentStatus && (
                    <TitleLockup
                      surface={isDark ? 'dark' : 'light'}
                      data={{
                        title: {
                          size: 'titleSmall',
                          children: `Shipment Status : ${shipmentStatus === 'S' ? 'Shipped' : 'Pending'}`,
                        },
                      }}
                    />
                  )}
                  {preOrderText ||
                    (backOrderText && (
                      <div>
                        {preOrderText}
                        {backOrderText}
                      </div>
                    ))}
                  <TextLinkWrapper>
                    {readOrder && isReadOrderMfeFFlag && !showEditInfo ? (
                      <TextLink
                        id='EditLine-font'
                        data-testid='edit-line-information-read-order'
                        data-track='Edit line information'
                        type='standAlone'
                        size='large'
                        onClick={() => {
                          setFirstName('');
                          setShowEditInfo(true);
                        }}
                        surface={isDark ? 'dark' : 'light'}
                      >
                        Edit line information
                      </TextLink>
                    ) : (
                      !showEditInfo && (
                        <TextLink
                          id='EditLine-font'
                          data-testid='edit-line-information'
                          data-track='Edit line information'
                          type='standAlone'
                          size='large'
                          onClick={() => setShowEditInfo(true)}
                          surface={isDark ? 'dark' : 'light'}
                        >
                          Edit line information
                        </TextLink>
                      )
                    )}

                    {showEditInfo && (
                      <EditInfoWrapper>
                        <Body size='large' data-testid='first-name-label' color={isDark ? DARK_THEME_COLOR : ''}>
                          First Name
                        </Body>

                        <VdsInput
                          onChange={(e) => handleFirstName(e.target.value)}
                          type='text'
                          iconName='name'
                          id='fName'
                          className='input-default'
                          formControlName='name'
                          value={firstName}
                          data-testid='first-name-input'
                          required
                          error={nameError}
                          errorText='Please Enter a valid name.'
                          surface={isDark ? 'dark' : 'light'}
                        />
                        <PaddingBot24 />
                        <Body size='large' data-testid='email-label' color={isDark ? DARK_THEME_COLOR : ''}>
                          Email Address
                        </Body>

                        <VdsInput
                          data-testid='email-input'
                          iconName='emailId'
                          formControlName='emailId'
                          name='emailId'
                          value={emailId?.toLowerCase()}
                          className='input-default'
                          required
                          readOnly
                          surface={isDark ? 'dark' : 'light'}
                        />

                        <StyledPaddingTopBot15>
                          <Button
                            size='small'
                            width={80}
                            disabled={false}
                            onClick={saveUserInfo}
                            data-testid='save-btn'
                            surface={isDark ? 'dark' : 'light'}
                          >
                            Save
                          </Button>
                          <PaddingBottom12 />
                          <Button
                            id='updateCancel'
                            width={100}
                            onClick={() => setShowEditInfo(false)}
                            use='secondary'
                            size='small'
                            data-testid='cancel-btn'
                            surface={isDark ? 'dark' : 'light'}
                          >
                            Cancel
                          </Button>
                        </StyledPaddingTopBot15>
                      </EditInfoWrapper>
                    )}
                    {element?.hasDeviceUnlockPolicy && !scmCheckoutMfeEnabled && !readOrder && (
                      <TextLink
                        id='EditLine-font'
                        type='standAlone'
                        size='large'
                        onClick={openModal}
                        data-testid='device-lock-information'
                        data-track='Important device lock information'
                        surface={isDark ? 'dark' : 'light'}
                      >
                        Important device lock information
                      </TextLink>
                    )}
                  </TextLinkWrapper>
                </>
              )}
            </LeftSideWrapper>
            <InfoWrapper>
              <BreakdownWrapper>
                <Devices
                  line={line}
                  element={element}
                  planDetail={planDetail}
                  handleViewDevices={handleViewDevices}
                  monthlyInstallmentAmount={monthlyInstallmentAmount}
                  lineAccessFee={lineAccessFee}
                  hasExchangeDeviceInLine={hasExchangeDeviceInLine}
                  lineActivityTypeData={lineActivityTypeData}
                  isLineAccessCharge={isLineAccessCharge}
                />
                {isDFO ? (
                  <DFOPriceInfo
                    id='dfoDevice'
                    title='Device'
                    bgColor={isDark ? bgColor : 'white'}
                    info={[
                      {
                        payment: 'Verizon Visa Card Financing',
                        price: formatCurrency(element?.itemPrice),
                        hideMonthly: true,
                        isBold: true,
                        key: 'totalAmount',
                        hasSubText: true,
                      },
                      {
                        payment: ` Estimated monthly Verizon Visa Card Payment for 36 month `,
                        price: formatCurrency(element?.eMIVerizonPayment),
                        key: 'monthlyAmount',
                      },
                      ...(upgradeFeeAmount
                        ? [
                            {
                              payment: `Upgrade fee`,
                              price: formatCurrency(upgradeFeeAmount),
                              key: 'upgradeFee',
                              hideMonthly: true,
                            },
                          ]
                        : []),
                    ]}
                    handleViewDevices={handleViewDevices}
                  />
                ) : (
                  <div>
                    <PriceInfo
                      id='device'
                      line={line}
                      hideMonthly
                      title={showDeviceHeading ? 'Device' : ''}
                      bgColor={isDark ? bgColor : 'white'}
                      info={[
                        ...(showDP
                          ? [
                              {
                                payment: getPaymentLabel(),
                                price: formatCurrency(parseFloat(line?.installmentInfo?.downPayment || 0)),
                                handleClick: () => {
                                  OpenViewTagging(
                                    'Down Payment',
                                    'Down Payment',
                                    'EUP|RFEX-read-order',
                                    'orderReview',
                                    rspFetchReadOrder,
                                  );
                                  if (!scmUpgradeMfeEnable) {
                                    showDownpaymentView(element);
                                  } else {
                                    showDownpaymentView(element, true);
                                  }
                                },
                                style: {
                                  labelFont: '18px',
                                  valueFont: '22px',
                                },
                              },
                            ]
                          : []),
                        ...(retailAmount
                          ? [{ payment: 'Retail Price', price: formatCurrency(retailAmount.itemPrice) }]
                          : []),
                        ...(offerAmount
                          ? [
                              {
                                payment: 'Upgrade fee',
                                price: formatCurrency(offerAmount?.itemPrice),
                                style: {
                                  labelFont: '16px',
                                  valueFont: '16px',
                                },
                              },
                            ]
                          : []),
                        ...(buyOutAmount
                          ? [
                              {
                                payment: 'Buyout Amount',
                                price: buyOutAmount?.itemPrice && formatCurrency(buyOutAmount.itemPrice),
                                style: {
                                  labelFont: '18px',
                                  valueFont: '22px',
                                },
                              },
                            ]
                          : []),

                        ...(rebateOffers
                          ? rebateOffers
                              .filter((item) => item.rebateAmount > 0)
                              .map((item) => ({
                                payment: (
                                  <EligibleText>
                                    <span>{item?.description}</span>
                                    <span className='highlight-text'>Eligible</span>
                                  </EligibleText>
                                ),
                              }))
                          : []),
                      ]}
                      // Below condition is added for POSMFE-3134
                      linkName={shouldAllowEdit ? 'Edit' : ''}	
                      linkTestId='showDownpaymentLink'
                      onLinkClick={() => {
                        if (!scmUpgradeMfeEnable) {
                          showDownpaymentView(element);
                        } else {
                          showDownpaymentView(element, true);
                        }
                      }}
                    />
                    {setupGoAmount && getSetupGoCartItemType(setupGoAmount)}
                  </div>
                )}
              </BreakdownWrapper>
              {!isPrepay && !planDetail?.isAccount && lineType?.length > 0 && (
                <PriceInfo
                  line={line}
                  id='plan'
                  title='Plan'
                  lineType={lineType}
                  price={formatCurrency(planPrice)}
                  info={[
                    {
                      payment,
                      price,
                      image: NetworkIcon,
                    },
                    ...addOns.map((ele) => ({
                      payment: ele?.skuName,
                      price: ele?.price?.discountedPrice,
                      image: perkImages[ele?.sorId]?.src,
                    })),
                  ]}
                  planId={planId}
                  isPrepay={isPrepay}
                  linkName='ViewPlans'
                  mtn={mtn} // sending to modal popup
                  bgColor={isDark ? bgColor : 'white'}
                />
              )}
              <BreakdownWrapper>
                <div>
                  <PriceInfo
                    line
                    id='perks'
                    title='Services & perks'
                    price={formatCurrency(addonsDueMonthly)}
                    bgColor={isDark ? bgColor : 'white'}
                  />
                  {/* lineLevelFeatures */}
                  <TileContainerWrapper>
                    <TileContainer
                      padding='1.5rem 0 0 0'
                      height='auto'
                      width='384px'
                      surface={isDark ? 'dark' : 'light'}
                    >
                      <TileWrapper>
                        <div className='' style={{ minHeight: '140px' }}>
                          {features &&
                            features.length > 0 &&
                            (viewMoreText === 'View more' ? features.slice(0, 3) : features).map((feature) => {
                              if (feature.isPerk) return null;

                              return (
                                <div
                                  key={feature?.sorId}
                                  className=''
                                  style={{
                                    display: 'inline-block',
                                    width: '33%',
                                    verticalAlign: 'top',
                                  }}
                                >
                                  <div className=''>
                                    <div>
                                      <img
                                        data-testId='image'
                                        alt={feature?.skuName ? feature?.skuName?.substr(0, 14) : ''}
                                        src={getImage(feature?.sorId)}
                                        style={{ height: '85px', margin: '0px 10px' }}
                                      />
                                    </div>
                                  </div>
                                  <NameWrapper className=''>
                                    {isPrepay ? (
                                      <div className=''>
                                        <div className=''>
                                          {/* <span className="Icon Icon--alert"></span> */}

                                          <div
                                            style={{
                                              wordBreak: 'break-word',
                                              'font-family': 'BrandFont-Text, Helvetica, Arial, sans-serif',
                                              'font-size': '18px',
                                              color: '#747676',
                                              overflow: 'hidden',
                                              height: '4rem',
                                            }}
                                            dangerouslySetInnerHTML={{
                                              __html: feature.skuName ? feature.skuName.substr(0, 25) : '',
                                            }}
                                          />
                                        </div>
                                      </div>
                                    ) : (
                                      <div className=''>
                                        {/* feature.serviceInEffectLater && <span className="Icon Icon--info font-15"></span> */}
                                        <div
                                          className=''
                                          style={{
                                            'padding-left': '0.4375rem',
                                            wordBreak: 'break-word',
                                            'font-family': 'BrandFont-Text, Helvetica, Arial, sans-serif',
                                            'font-size': scmCheckoutMfeEnabled ? '15px' : '18px',
                                            color: '#747676',
                                            overflow: 'hidden',
                                            height: '4rem',
                                          }}
                                          dangerouslySetInnerHTML={{
                                            __html: feature.skuName ? feature.skuName.substr(0, 14) : '',
                                          }}
                                        />
                                      </div>
                                    )}
                                  </NameWrapper>
                                </div>
                              );
                            })}
                        </div>

                        {features && features.length > 3 && (
                          <LinkWrapper>
                            <TextLink
                              type='standAlone'
                              data-testid='handleviewmore'
                              surface={isDark ? 'dark' : 'light'}
                              disabled={false}
                              size='small'
                              onClick={handleViewMore}
                            >
                              {viewMoreText}
                            </TextLink>
                          </LinkWrapper>
                        )}
                      </TileWrapper>
                    </TileContainer>
                  </TileContainerWrapper>
                </div>
                <AccessoriesWrapper>
                  <AccessoriesCheckoutDetails
                    data={{
                      data: {
                        cart,
                      },
                    }}
                    showAccordion={false}
                    itemsInfo={line?.itemsInfo}
                    mtn={mobileNumber}
                    hideSupport
                    isFromCheckout
                    setProfInstallappointmentFlag={setProfInstallappointmentFlag}
                  />
                </AccessoriesWrapper>
              </BreakdownWrapper>

              <ExistingServicePerks
                features={features}
                existingFeatures={existingFeatures}
                newFeatures={newFeatures}
                oldFeatures={oldFeatures}
                line={line}
                element={element}
                fpsReferences={fpsReferences}
                fetchPriceSnapshotSubAccount={subAccount}
                readOrderData={readOrderData}
              />
              <DiscountPromotions cartItem={element} lineData={line} fetchPriceSnapshot={mtnLine} isPrepay={isPrepay} />
            </InfoWrapper>
          </FlexBox>
          <Line type='primary' />

          <Modal
            id='ImportantDevicelockModal'
            surface={isDark ? 'dark' : 'light'}
            fullScreenDialog
            closeButton={null}
            disableAnimation={false}
            disableOutsideClick={false}
            ariaLabel='Important Device lock Modal'
            data-testid='device-info-modal'
            opened={showModal}
          >
            <DeviceLockInformation
              closeDeviceInformation={closeModal}
              productId={requestBodyGetDetails?.data?.productId}
            />
          </Modal>

          {isDeviceModalVisible && (
            <DevicesModal
              setMonthlyInstallmentAmount={setMonthlyInstallmentAmount}
              sbdOffer={sbdOffer}
              line={line}
              element={element}
              opened={isDeviceModalVisible}
              closeModal={closeDeviceModal}
              cart={cart}
              CustomerProfileRefetch={CustomerProfileRefetch}
              CartDetailsRefetch={CartDetailsRefetch}
              fetchPriceSnapshotRefetch={fetchPriceSnapshotRefetch}
              readOrder={readOrder}
              lineDeviceAndSimIds={lineDeviceAndSimIds}
              activationStatus={activationStats}
              orderStatus={orderStatus}
              cartHeader={cartHeader}
            />
          )}
        </CheckoutLineWrapper>
      </>
    );
  };

  const handleViewMore = () => {
    setViewMoreText(viewMoreText === 'View more' ? 'View less' : 'View more');
  };

  useEffect(() => {
    if (readOrder && isReadOrderMfeFFlag) {
      fetchPriceSnapshotRefetch();
    }
  }, []);

  useEffect(() => {
    /* istanbul ignore next */
    if (submitUserInforSuccess?.isSuccess) {
      dispatch(appMessageActions.addAppMessage('User information updated successfully.', 'success', true, true));
      setTimeout(() => {
        dispatch(appMessageActions.clearAppMessages());
      }, 3000);
      setName(firstName);
      CartDetailsRefetch();
    }
  }, [submitUserInforSuccess]);

  const isfiveG_lineActivityType =
    has(line, 'lineActivityType') && (line.lineActivityType === 'AAL_5G' || line.lineActivityType === 'NSE_5G');
  const accessories = cartItems?.cartItem?.filter(
    (item) =>
      item?.cartItemType === 'ACCESSORY' ||
      (item?.cartItemType === 'SOFT_SKU' && (item?.itemCode === TAX_SOFT_SKU || isfiveG_lineActivityType)) ||
      (item?.cartItemType === 'SOFT_SKU' &&
        item?.prodCode1 === 'LAB' &&
        item?.prodCode2 === 'SER' &&
        item?.prodCode4 === 'SUG') ||
      (item?.cartItemType === 'SOFT_SKU' && item?.prodCode1 === 'CRD' && item?.prodCode2 === 'GIF'),
  );

  const exchangeDeviceCartItems = cartItems?.cartItem?.filter((item) => {
    const updatedItem = { ...item };
    if (updatedItem.cartItemType === 'DEVICE') {
      updatedItem.type = 'exchange';
    } else {
      updatedItem.type = updatedItem.type ? updatedItem.type : '';
    }
    return (updatedItem.prodCode1 === 'LTE' || updatedItem.cartItemType === 'DEVICE') && !updatedItem.tradeInAutoPull;
  });
  const hasExchangeDeviceInLine = exchangeDeviceCartItems && exchangeDeviceCartItems.length > 0;
  const lineActivityTypeData =
    has(line, 'lineActivityType') && (line.lineActivityType === 'EXC' || line.lineActivityType === 'CCH');

  const selectedFeatures = has(line, 'serviceInfo.selectedFeaturesList.visFeature')
    ? line.serviceInfo.selectedFeaturesList.visFeature
    : [];

  const userAddedFeatures = selectedFeatures.filter(
    (feature) =>
      feature?.addDeleteInd !== 'D' &&
      feature?.level !== 'A' &&
      feature?.sfoPackageGroupCode !== 'LC' &&
      (feature?.source === 'USER' ||
        feature?.sfoPackageGroupCode === 'EQ' ||
        (feature?.source === 'FOM' && parseFloat(feature?.featurePrice) > 0)),
  );

  const mtnLine = subAccount?.[0]?.lines?.filter((ele) => ele.mtn === mobileNumber);

  const isCPCorFEA =
    has(line, 'lineActivityType') && (line?.lineActivityType === 'CPC' || line?.lineActivityType === 'FEA');

  return (
    <div data-testid='checkoutLine'>
      {cartItems?.cartItem
        ?.filter((item) => item?.cartItemType === 'DEVICE' || (line?.buySimOnly && item?.cartItemType === 'SIM'))
        .map((element) => displayDeviceContent(element))}

      {isCPCorFEA && displayDeviceContent(currentDevice)}
    </div>
  );
};

CheckoutLine.propTypes = {
  line: PropTypes.object,
  lineInfo: PropTypes.array,
  customerName: PropTypes.string,
  fetchPriceSnapshot: PropTypes.object,
  planId: PropTypes.number,
  cart: PropTypes.object,
  showDownpaymentView: PropTypes.func,
  setHideShippingDetails: PropTypes.func,
  CustomerProfileRefetch: PropTypes.func,
  CartDetailsRefetch: PropTypes.func,
  fetchPriceSnapshotRefetch: PropTypes.func,
  setProfInstallappointmentFlag: PropTypes.func,
  readOrder: PropTypes.bool,
  lineDeviceAndSimIds: PropTypes.object,
  activationStats: PropTypes.object,
  orderStatus: PropTypes.string,
  cartHeader: PropTypes.object,
  readOrderData: PropTypes.object,
  hasSubAccount: PropTypes.bool,
  subAccount: PropTypes.array,
  rspFetchReadOrder: PropTypes.object,
};

export default CheckoutLine;
