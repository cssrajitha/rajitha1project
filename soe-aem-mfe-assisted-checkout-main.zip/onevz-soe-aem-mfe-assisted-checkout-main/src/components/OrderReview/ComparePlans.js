/* eslint-disable no-nested-ternary */
import React, { useState, Fragment } from 'react';
import { Body, Title } from '@vds/typography';
import { Tooltip } from '@vds/tooltips';
import { Button } from '@vds/buttons';
import { Table, TableHeader, TableHead, TableBody, TableRow, Cell } from '@vds/tables';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import { formatCurrency } from 'onevzsoemfecommon/Helpers';

import isEmpty from 'lodash/isEmpty';
import { useSelector } from 'react-redux';
import AccordionRow from '../TAccordion/AccordionRow';
import { DARK_THEME_BGCOLOR, DARK_THEME_COLOR } from '../constants/constants';

const HighlightedTextBlue = styled.div`
  background: #4169e1;
  color: #ffffff;
  padding: 0.125rem 0.25rem;
  border-radius: 2px;
  display: inline-block;
`;
const Margin0 = styled.div`
  margin: 0px !important;
`;
const Margin0Flex = styled.div`
  margin: 0px !important;
  display: inline-flex;
`;
const PricePanel = styled.div`
  margin: 0px !important;
  padding-top: 1rem;
`;

const CustomTableRow = styled(TableRow)`
  border-bottom: 0px !important;
`;
const CustomTable = styled(Table)`
  table-layout: fixed;
  border: 0px;
  thead {
    border-top: none !important;
    position: sticky;
    background: linear-gradient(to top, rgb(216, 218, 218) 1.5px, white 0px, white 100%);
    z-index: 1;
    top: -32px;
  }
`;
const CustomTableHeader = styled(TableHeader)`
  padding: 2rem 2rem 2rem 0 !important;
  border: none !important;
  width: 47%;
  :last-child {
    width: 6%;
  }
`;

const TableCell = styled(Cell)`
  padding: 2rem 2rem 2rem 0 !important;
  border: none !important;
  white-space: normal;
`;
const Width100 = styled.div`
  width: 100%;
`;
const DollarWrapper = styled.div`
  display: flex;
  width: 100%;
  justify-content: space-between;
`;

const PlanPiceWrapper = styled.div`
  max-width: 138px;
  padding: 0.25rem 0.75rem 0 0;
`;
const LineWrapper = styled.div`
  padding: 0.75rem 0 0.5rem 0;
`;
const ButtonWrapper = styled.div`
  display: inline-block;
`;

export default function ComparePlans(props) {
  const { isDark } = props;
  const [currentOpenRow, setCurrentOpenRow] = useState(-1);
  const planReduxData = useSelector((state) => state?.plans?.data);
  const getPerksinfo = planReduxData?.perkReferenceDataList;
  const selectedMTN = planReduxData?.linesinfo?.find((item) => item?.mtn === props?.mtn);
  const setCurrentRow = (currentOpenRowData) => {
    setCurrentOpenRow(currentOpenRowData);
  };

  const {
    currentPlanDisplayName,
    CurrentPlanCost,
    selectedPlanName,
    selectedPlanCost,
    totalSelectedPerks,
    label,
    planIds,
    selectedPerks,
    ComparePlanAPIResponse,
    newPlanAndPerksCost = [],
    bundleprice = [],
    propositionName,
  } = props;
  let idCount = 0;
  let totalAmountOff = 0;
  let perkSpoList = [];
  const comparePlans = ComparePlanAPIResponse?.comparePlans;
  const productFeatureMap = ComparePlanAPIResponse?.productFeatureMap;
  const perksObj = comparePlans?.filter((obj) => obj?.productGroupName === 'Perks');
  const perkRemoved = comparePlans?.filter((obj) => obj?.productGroupName !== 'Perks');
  const selectingPerks = !isEmpty(perksObj) && [...perksObj[0].productList];
  const pickPerks = selectingPerks?.sort((a, b) => {
    if (a?.groupName === 'Pick your own Perks') {
      return -1;
    }
    if (b?.groupName === 'Pick your own Perks') {
      return 1;
    }
    return 0;
  });
  const perksFinal = { productGroupName: 'Perks', productList: pickPerks };
  perkRemoved?.splice(2, 0, perksFinal);

  const displayName = currentPlanDisplayName;
  if (label === 'mtnExpanded') {
    const lineVal =
      newPlanAndPerksCost?.length > 0 && newPlanAndPerksCost?.find((line) => line?.mtn === selectedMTN?.mtn);
    perkSpoList =
      lineVal?.perkOptionsPrice?.perkSpoList?.filter(
        (item) => !selectedMTN?.skippedSavingPerks?.includes(item?.spoId),
      ) || [];
    totalAmountOff =
      lineVal?.perkOptionsPrice?.perkSpoList?.length > 0 &&
      lineVal?.perkOptionsPrice?.perkSpoList
        ?.filter((item) => !selectedMTN?.skippedSavingPerks?.includes(item?.spoId))
        ?.reduce((total, perkList) => total + parseFloat(perkList?.price?.totalAmountOff), 0);
  } else {
    const lineVal =
      bundleprice?.lines?.length > 0 && bundleprice?.lines?.find((line) => line?.mtn === selectedMTN?.mtn);
    const proposition =
      lineVal?.planPerksBundlesCost?.length > 0 &&
      lineVal?.planPerksBundlesCost?.find((bundle) => bundle?.propositionName === propositionName);
    perkSpoList =
      proposition?.perkOptionsPrice?.perkSpoList?.filter(
        (item) => !selectedMTN?.skippedSavingPerks?.includes(item?.spoId),
      ) || [];
    totalAmountOff =
      proposition?.perkOptionsPrice?.perkSpoList?.length > 0 &&
      proposition?.perkOptionsPrice?.perkSpoList
        ?.filter((item) => !selectedMTN?.skippedSavingPerks?.includes(item?.spoId))
        ?.reduce((total, perkList) => total + parseFloat(perkList?.price?.totalAmountOff), 0);
  }
  const [editOrSelectBtn, seteditOrSelectBtn] = useState(false);
  const [editOrSelectBtnRecommended, seteditOrSelectBtnRecommended] = useState(false);

  const renderToolTip = (perkSpoListVal, totalAmountOffVal) => (
    <Tooltip title='' size='small' surface='light'>
      <Width100>
        {perkSpoListVal?.map((perkList) => (
          <DollarWrapper>
            <PlanPiceWrapper>
              <Body size='small'>{props?.getPerksinfo?.[perkList?.spoId]?.perkTitle}</Body>
            </PlanPiceWrapper>
            <Body size='small' bold>
              {formatCurrency(perkList?.price?.totalAmountOff)}
            </Body>
          </DollarWrapper>
        ))}
        <LineWrapper>{/* <Line type="primary" /> */}</LineWrapper>
        <DollarWrapper>
          <PlanPiceWrapper>
            <Body size='small'>Total</Body>
          </PlanPiceWrapper>
          <Body size='small' bold>
            {formatCurrency(totalAmountOffVal)}
          </Body>
        </DollarWrapper>
      </Width100>
    </Tooltip>
  );

  const onSelectePopularBundle = (planId, index) => {
    seteditOrSelectBtn(true);
    const data = { isFrom: 'popularPlan', planId, index };
    props?.selectBundle(data);
  };

  const onSelectRecommendedBundle = (planId) => {
    seteditOrSelectBtnRecommended(true);
    const data = { isFrom: 'recommendedPlan', planId, isRecommendedPlan: true };
    props?.selectBundle(data);
  };

  const onSelectBuildBundle = () => {
    const planTabs = { recommendedPlanTab: false, popularPlanTab: false, buildPlanTab: true };
    const selectCustomize = props.setSelectedCustomize({ clicked: true, ...planTabs });
    const closeModal = props.closeModal();
    if (props?.label === 'mtnExpanded') {
      return closeModal;
    }
    return selectCustomize;
  };

  return (
    <CustomTable striped={false}>
      <TableHead>
        <CustomTableHeader style={{ backgroundColor: isDark ? DARK_THEME_BGCOLOR : DARK_THEME_COLOR }}>
          <Body size='medium' color={isDark ? DARK_THEME_COLOR : ''}>
            Current
          </Body>
          <Margin0>
            <Title size='small' color={isDark ? DARK_THEME_COLOR : ''} bold>
              <div
                dangerouslySetInnerHTML={{
                  __html: displayName,
                }}
              />
            </Title>
          </Margin0>
          <PricePanel>
            <Body size='medium' bold primitive='span' color={isDark ? DARK_THEME_COLOR : ''}>
              ${CurrentPlanCost?.planPrice ? CurrentPlanCost?.planPrice : '0'}/mo&nbsp;
            </Body>
            <Body size='medium' primitive='span' color={isDark ? DARK_THEME_COLOR : ''}>
              for this line
            </Body>
          </PricePanel>
        </CustomTableHeader>
        <CustomTableHeader style={{ backgroundColor: isDark ? DARK_THEME_BGCOLOR : DARK_THEME_COLOR }}>
          <Body size='small' bold color={isDark ? DARK_THEME_COLOR : ''}>
            {/mtnExpanded|Popular|OrderReview/i.test(label) ? (
              <Body size='medium' bold color={isDark ? DARK_THEME_COLOR : ''}>
                New
              </Body>
            ) : (
              <HighlightedTextBlue>Recommended</HighlightedTextBlue>
            )}
          </Body>
          <Margin0Flex>
            <Title size='small' color={isDark ? DARK_THEME_COLOR : ''} bold>
              {selectedPlanName}
            </Title>
            <Title size='small' color={isDark ? DARK_THEME_COLOR : ''} bold>
              {' '}
              <div style={{ paddingLeft: '3px' }}>with {totalSelectedPerks} Perks</div>
            </Title>
          </Margin0Flex>
          <PricePanel>
            <Body size='medium' bold primitive='span' color={isDark ? DARK_THEME_COLOR : ''}>
              ${selectedPlanCost}/mo&nbsp;
            </Body>
            <Body size='medium' primitive='span' color={isDark ? DARK_THEME_COLOR : ''}>
              for this line
            </Body>
          </PricePanel>

          <PricePanel>
            {totalAmountOff > 0 && (
              <Body size='small' color='#00ac3e' primitive='span' bold>
                {' '}
                ${totalAmountOff?.toFixed(2)} savings.{renderToolTip(perkSpoList, totalAmountOff)}
              </Body>
            )}
          </PricePanel>

          {editOrSelectBtn ||
          (props?.index === props?.currentPlanIndex && label === 'Popular') ||
          label === 'mtnExpanded' ? (
            <Button
              size='small'
              disabled={false}
              surface='light'
              use='secondary'
              data-track='buildPlan_Select'
              data-testid='buildPlan_Select'
              onClick={() => onSelectBuildBundle()}
              ariaLabel='Select for Build Plan'
            >
              Edit
            </Button>
          ) : label === 'Popular' ? (
            <Button
              size='small'
              disabled={false}
              surface='light'
              use='secondary'
              data-track='popularPlan_Select'
              data-testid='popularPlan_Select'
              onClick={() => onSelectePopularBundle(props?.planId, props?.index)}
              ariaLabel='Select for Popular Plans'
            >
              Select
            </Button>
          ) : label === 'Recommended' && (editOrSelectBtnRecommended || props?.selectedRecommended) ? (
            <Button
              size='small'
              disabled={false}
              surface='light'
              use='secondary'
              data-track='recommendedPlan_Select'
              data-testid='recommendedPlan_Select'
              onClick={() => onSelectBuildBundle()}
              ariaLabel='Select for Recommended Plans'
            >
              Edit
            </Button>
          ) : (
            <Button
              size='small'
              disabled={false}
              surface='light'
              use='secondary'
              data-track='recommendedPlan_Select'
              data-testid='recommendedPlan_Select'
              onClick={() => onSelectRecommendedBundle(props?.recommendedpricePlanId)}
              ariaLabel='Select for Recommended Plans'
            >
              Select
            </Button>
          )}
        </CustomTableHeader>
        <CustomTableHeader style={{ backgroundColor: isDark ? DARK_THEME_BGCOLOR : DARK_THEME_COLOR }} />
      </TableHead>
      <TableBody>
        {perkRemoved?.map((comparePlan) => (
          <Fragment key={comparePlan?.productGroupName}>
            <CustomTableRow colSpan={1}>
              <TableCell key={comparePlan?.productGroupName}>
                <Title size='medium' color={isDark ? DARK_THEME_COLOR : ''} bold>
                  {comparePlan?.productGroupName}
                </Title>
              </TableCell>
              <TableCell>
                {comparePlan?.productGroupName === 'Perks' && (
                  <ButtonWrapper>
                    <Button
                      size='small'
                      disabled={false}
                      surface='light'
                      use='secondary'
                      width='100%'
                      data-track='recommendationtab_Customize'
                      data-testid='recommendationtab_Customize'
                      onClick={() => onSelectBuildBundle()}
                    >
                      Customize Perks
                    </Button>
                  </ButtonWrapper>
                )}
              </TableCell>
            </CustomTableRow>
            {comparePlan?.productList?.map((item) => {
              const rowid = idCount;
              idCount += 1;
              return (
                <AccordionRow
                  isDark={isDark}
                  key={idCount}
                  setCurrentRow={setCurrentRow}
                  currentOpenRow={currentOpenRow}
                  rowid={rowid}
                  planIdProductIdMap={item}
                  selectedPerks={selectedPerks}
                  planIds={planIds}
                  compareToCurrentPlans={comparePlans}
                  productFeatureMap={productFeatureMap}
                  comparePlanProductGroupName={comparePlan?.productGroupName}
                  selectedMTN={selectedMTN}
                  getPerksinfo={getPerksinfo}
                  CompareToConnect='CompareToConnect'
                />
              );
            })}
          </Fragment>
        ))}
      </TableBody>
    </CustomTable>
  );
}
ComparePlans.propTypes = {
  label: PropTypes.any,
  CurrentPlanCost: PropTypes.any,
  currentPlanDisplayName: PropTypes.string,
  selectedPlanName: PropTypes.string,
  selectedPlanCost: PropTypes.any,
  totalSelectedPerks: PropTypes.any,
  selectedPerks: PropTypes.any,
  planIds: PropTypes.any,
  productFeatureMap: PropTypes.any,
  ComparePlanAPIResponse: PropTypes.any,
  mtn: PropTypes.any,
  isDark: PropTypes.bool,
  newPlanAndPerksCost: PropTypes.array,
  bundleprice: PropTypes.array,
  propositionName: PropTypes.string,
  getPerksinfo: PropTypes.object,
  selectBundle: PropTypes.func,
  currentPlanIndex: PropTypes.number,
  index: PropTypes.number,
  selectedRecommended: PropTypes.bool,
  planId: PropTypes.string,
  setSelectedCustomize: PropTypes.func,
  closeModal: PropTypes.func,
  recommendedpricePlanId: PropTypes.string,
};
