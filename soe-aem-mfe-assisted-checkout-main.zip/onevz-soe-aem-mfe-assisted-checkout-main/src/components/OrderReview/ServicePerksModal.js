import React, { useEffect, useState } from 'react';
import styled, { createGlobalStyle } from 'styled-components';
import { has } from 'lodash';
import { Modal, ModalTitle, ModalBody, ModalFooter } from '@vds/modals';
import { Line } from '@vds/lines';
import { Body } from '@vds/typography';
import PropTypes from 'prop-types';
import { Icon } from '@vds/icons';
import moment from 'moment';
import { scmCheckoutMfeEnabled } from '../../utils/common';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR } from '../constants/constants';

const MarginSides = styled.div`
  padding: 0 1rem;
`;

const ModalContentWrapper = styled.div`
  display: flex;
  > div:first-child {
    flex: 1;
  }
  > div:last-child {
    flex: 2;
  }
`;

const ModalHeader = styled.div`
  font-size: 22px;
  font-weight: bold;
`;

const Title = styled.div`
  font-size: 18px;
  font-weight: bold;
  line-height: 1.25rem;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  letter-spacing: 0.03125rem;
  margin-top: 20px;
  margin-bottom: 30px;
  text-decoration: none;
`;

const ElementWrapper = styled.div`
  display: flex;
`;

const TotalLeftFeatureWrapper = styled.div`
  width: 48%;
  padding: 20px 0;
  border-top: 1px solid #ccc;
`;

const ContainerWrapperTotal = styled.span`
  font-weight: bold;
  float: left;
`;

const LeftContainerWrapperPrice = styled.span`
  font-weight: bold;
  float: right;
  padding-right: 40px;
`;

const TotalRightFeatureWrapper = styled.div`
  background-color: #f4f4f4;
  width: 48%;
  padding: 20px 10px;
  border-top: 1px solid #ccc;
`;

const RightContainerWrapperPrice = styled.span`
  font-weight: bold;
  float: right;
  padding-right: 30px;
`;

const LeftOldWhiteBox = styled.div`
  width: 48%;
  padding: 10px 0;
  margin-top: 20px;
`;

const TitleWhiteBox = styled.div`
  font-weight: bold;
  font-size: 20px;
  margin: 10px 0;
`;

const ElementBox = styled.div`
  margin: 14px 0;
  border-top: 1px solid #ccc;
`;

const RightNewGrayBox = styled.div`
  width: 48%;
  padding: 10px;
  margin-top: 20px;
`;

const TitleGrayBox = styled.span`
  font-weight: bold;
  font-size: 20px;
`;

const TextLink = styled.span`
  text-decoration: underline;
  padding-right: 14px;
  font-size: 18px;
  float: right;
  cursor: pointer;
`;

const ElementRemoveBox = styled.div`
  margin: 10px 0;
  border-top: 1px solid #ccc;
`;

const PriceInfo = styled.div`
  float: right;
  fontweight: bold;
  width: 4rem;
  margin-right: 5px;
  padding-top: 10px;
`;

const ListView = styled.div`
  display: flex;
  width: 100%;
`;

const PageTitle = styled.div`
  display: flex;
  justify-content: space-between;
  margin: 20px;
`;

const SubTitle = styled(Title)`
  margin-top: 0px !important;
  margin-bottom: 0px !important;
  font-size: 22px !important;
`;

const CloseIconWrapper = styled.a`
  cursor: pointer;
  color: #000000 !important;
`;

const HorizontalDivider = styled.div`
  border-bottom: 1px solid #d8dada;
  max-width: 100%;
`;

let centerTheFeatureText = false;

const formatCurrency = (value) => {
  if (Number?.isNaN(value)) return;
  const sign = value < 0 ? '-' : '';
  const numValue = Number(Math.abs(value)).toFixed(2);
  const currencyString = `${sign}$${numValue}`;
  return currencyString;
};

const featuresTotal = (features) => {
  let total = 0;
  if (features && features.length > 0) {
    features.map((feature) => {
      total += parseFloat(feature.price.regularPrice);
      return total;
    });
  }
  return total;
};

const ServicePerksModal = ({
  opened,
  closeModal,
  existingFeatures,
  oldFeatures,
  newFeatures,
  fpsReferences,
  defaultImageLabel,
  fetchPriceSnapshotSubAccount,
  line,
  readOrderData,
  isRefundReadOrder,
  refundfeatureflag,
}) => {
  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;
  const bgColor = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.themeProps?.background;
  const readOrderMfeFFlag = JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.readOrderMfeFFlag === 'TRUE';
  const isFromReadOrder = sessionStorage.getItem('readOrder');
  const readOrderFFFlag = readOrderMfeFFlag && isFromReadOrder;
  const [orderEffectiveDate, setOrderEffectiveDate] = useState({
    effectiveDate: null,
    isFutureDate: false,
    isPastDate: false,
  });

  useEffect(() => {
    const effectiveDate = readOrderData?.cart?.orderDetails?.effectiveDateDetails?.selectedDate;
    if (effectiveDate && readOrderFFFlag) {
      const now = moment().format('MM/DD/YYYY');
      const eDate = moment(effectiveDate).format('MM/DD/YYYY');
      const isFutureDate = moment(now).isBefore(moment(eDate));
      const isPastDate = moment(now).isAfter(moment(eDate));
      setOrderEffectiveDate({ effectiveDate, isFutureDate, isPastDate });
    }
  }, []);

  const handleClick = (btn) => {
    if (btn === 'done') {
      closeModal();
    }
  };

  const ComponentStyle = createGlobalStyle`
  #perksModal {
    [class^='Overlay-VDS'] {
      width: ${scmCheckoutMfeEnabled() ? '76.5%' : 'inherit'};
    }

    [class^='Overlay-VDS'] {
      background-color: rgba(0, 0, 0, 0.8);
    }
    [class^='ModalDialog-VDS'] {
      max-width:${scmCheckoutMfeEnabled() ? '945px' : '1024px'};
      border-radius: 0;
      padding: 0;
    }
    [class^='ModalDialogWrapper-VDS'] {
        > span {
          width: 100%;
          height: 100%;

        > div {
          width:100% !important;
          height: 100% !important;

          > div {
            padding:0 !important;
          }
        }
      }
    }


    [class^='IconWrapper-VDS'] {
      z-index: 99999;
    }
    
    [class^='StyledHeader-VDS'] {
      position: sticky;
      top:0;
      z-index: 999;
      padding: 1rem 0 0 0;
      ${scmCheckoutMfeEnabled ? 'background: white;' : ''}
    }
    [class^='StyledFooter-VDS'] {
      border-top: 1px solid #ccc;
      position: sticky;
      bottom:0;
      padding-top: 2rem;
      ${scmCheckoutMfeEnabled ? 'background: white;' : ''}
    }
  }
`;
  const mobileNumber = has(line, 'mobileNumber') ? line.mobileNumber : '';
  const [featureState, setFeatureState] = useState({ HideFeatures: true, showRemovedFeatures: false });

  const getTheImage = (featureSku) => {
    let imageUrl = '';
    if (fpsReferences && fpsReferences.skus && fpsReferences.skus.length > 0) {
      const refFound = fpsReferences.skus.find((sku) => sku.sorId === featureSku);
      imageUrl = (refFound && refFound.imageUrlMap && refFound.imageUrlMap.defaultImage) || defaultImageLabel || '';
    }
    centerTheFeatureText = imageUrl !== '';
    return imageUrl;
  };

  const renderFeatures = (featuresList, isLeftSideAddOns) =>
    featuresList &&
    featuresList.length > 0 &&
    featuresList.map((feature) => (
      <ListView key={feature.sorId}>
        <span style={{ width: '5rem' }}>
          <img
            alt=''
            src={getTheImage(feature.sorId)}
            style={{
              maxHeight: '50px',
              marginLeft: '5px',
              marginRight: 0,
              filter: isLeftSideAddOns ? '' : 'brightness(0.95)',
              backgroundColor: isDark ? DARK_THEME_COLOR : 'transparent',
            }}
          />
        </span>
        <span
          dangerouslySetInnerHTML={{
            __html: feature.skuName ? feature.skuName : '',
          }}
          style={{
            width: centerTheFeatureText ? '20rem' : '15rem',
            'text-align': 'justify',
            'padding-top': '10px',
            color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
            backgroundColor: isDark ? bgColor : '',
          }}
        />
        <PriceInfo>
          {feature.price && (
            <span>
              {formatCurrency(
                feature.price.discountedFeaturePrice !== undefined &&
                  feature.price.discountedFeaturePrice < feature.price.regularPrice
                  ? feature.price.discountedFeaturePrice
                  : feature.price.regularPrice,
              )}
            </span>
          )}
          <br />
          {feature.price &&
            feature.price.discountedFeaturePrice !== undefined &&
            feature.price.discountedFeaturePrice < feature.price.regularPrice && (
              <s>{formatCurrency(feature.price.regularPrice)}</s>
            )}
        </PriceInfo>
      </ListView>
    ));

  const getLineLevelAddonsDueMonthly = () => {
    const selectedMtn = line.mobileNumber;
    const subAccountForRef =
      fetchPriceSnapshotSubAccount?.length > 0 &&
      fetchPriceSnapshotSubAccount.filter((subAccount) =>
        subAccount.lines.some((linemtn) => linemtn.mtn === selectedMtn),
      )[0];
    const selectedDevicePriceSnpshot =
      has(subAccountForRef, 'lines') &&
      subAccountForRef.lines.length > 0 &&
      subAccountForRef.lines.filter((linemtn) => linemtn.mtn === selectedMtn);
    const addonsDueMonthly =
      selectedDevicePriceSnpshot.length > 0 ? selectedDevicePriceSnpshot[0].addonsDueMonthly : [];
    return has(addonsDueMonthly, 'discountedPrice') ? addonsDueMonthly.discountedPrice : 0;
  };

  function changeEffectiveDate() {
    window.location.href = `/sales/assisted/home.html`;
  }

  return (
    <>
      <ComponentStyle />
      <div data-testId='perksModal'>
        <Modal
          id='perksModal'
          fullScreenDialog
          opened={opened}
          surface={isDark ? 'dark' : 'light'}
          width='100%'
          disableAnimation={false}
          disableOutsideClick={false}
          closeButton={null}
          onOpenedChange={(open) => {
            if (!open) closeModal();
          }}
        >
          <ModalTitle>
            <PageTitle style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
              <ModalHeader size='small' color='#4a4a4a' bold>
                {`Services & perks for ${mobileNumber && mobileNumber.slice(0, 6).replace(/(\d{3})/g, '$1.')}${
                  mobileNumber && mobileNumber.slice(6)
                }`}
              </ModalHeader>
              <CloseIconWrapper
                onClick={() => {
                  closeModal();
                }}
              >
                <Icon name='close' size='XLarge' />
              </CloseIconWrapper>
            </PageTitle>
          </ModalTitle>
          <HorizontalDivider />
          <MarginSides>
            <ModalBody surface={isDark ? 'dark' : 'light'}>
              <ModalContentWrapper>
                <div>
                  <SubTitle style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                    Services & perks changes
                  </SubTitle>
                  <ElementWrapper>
                    <LeftOldWhiteBox>
                      {isRefundReadOrder && refundfeatureflag && (
                        <TitleWhiteBox style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                          Current monthly
                        </TitleWhiteBox>
                      )}
                      {!isRefundReadOrder && (
                        <TitleWhiteBox style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                          Old monthly
                        </TitleWhiteBox>
                      )}
                      <ElementBox>
                        <Title className='' style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                          Services & perks
                        </Title>
                        {renderFeatures(existingFeatures, true)}
                      </ElementBox>
                    </LeftOldWhiteBox>
                    <div style={{ width: '1%' }} />
                    <RightNewGrayBox
                      className='New-Monthly'
                      style={{
                        color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                        backgroundColor: isDark ? bgColor : '#f4f4f4',
                      }}
                    >
                      <div className='' style={{ margin: '10px 0' }}>
                        <TitleGrayBox>New monthly</TitleGrayBox>
                        {featureState.HideFeatures && (
                          <TextLink
                            className='link'
                            tabIndex='0'
                            aria-label='Show removed Services & perks'
                            style={{ 'font-weight': 'bold', color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}
                            role='button'
                            onKeyPress={(e) =>
                              e.key === 'Enter' && setFeatureState({ showRemovedFeatures: true, HideFeatures: false })
                            }
                            onClick={() => setFeatureState({ showRemovedFeatures: true, HideFeatures: false })}
                          >
                            Show removed Services & perks
                          </TextLink>
                        )}
                        {!featureState.HideFeatures && (
                          <TextLink
                            className='link'
                            tabIndex='0'
                            aria-label='Hide removed Services & perks'
                            style={{ 'font-weight': 'bold', color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}
                            role='button'
                            onKeyPress={(e) =>
                              e.key === 'Enter' && setFeatureState({ showRemovedFeatures: false, HideFeatures: true })
                            }
                            onClick={() => setFeatureState({ showRemovedFeatures: false, HideFeatures: true })}
                          >
                            Hide removed Services & perks
                          </TextLink>
                        )}
                      </div>
                      <ElementBox>
                        <Title style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                          Newly added Services & perks
                        </Title>
                        {renderFeatures(newFeatures, false)}
                      </ElementBox>
                      <ElementBox>
                        <Title style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                          Existing Services & perks
                        </Title>
                        {renderFeatures(existingFeatures, false)}
                      </ElementBox>
                      {featureState.showRemovedFeatures && (
                        <ElementRemoveBox className=''>
                          <Title style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                            {' '}
                            Removed Services & perks
                          </Title>
                          {renderFeatures(oldFeatures, false)}
                        </ElementRemoveBox>
                      )}
                    </RightNewGrayBox>
                  </ElementWrapper>

                  <ElementWrapper>
                    <TotalLeftFeatureWrapper>
                      <ContainerWrapperTotal style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                        {' '}
                        Total
                      </ContainerWrapperTotal>
                      <LeftContainerWrapperPrice>
                        {formatCurrency(featuresTotal(existingFeatures))}
                      </LeftContainerWrapperPrice>
                    </TotalLeftFeatureWrapper>
                    <div style={{ width: '1%' }} />
                    <TotalRightFeatureWrapper
                      className='New-Monthly '
                      style={{
                        color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                        backgroundColor: isDark ? bgColor : '#f4f4f4',
                      }}
                    >
                      <ContainerWrapperTotal style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                        Total
                      </ContainerWrapperTotal>
                      <RightContainerWrapperPrice style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                        {formatCurrency(getLineLevelAddonsDueMonthly())}
                      </RightContainerWrapperPrice>
                    </TotalRightFeatureWrapper>
                  </ElementWrapper>

                  <div style={{ height: '8vh' }} />
                  {readOrderFFFlag && <Line type='secondary' />}
                </div>
              </ModalContentWrapper>
              {readOrderFFFlag && !isRefundReadOrder && (
                <div style={{ padding: '1.3125rem' }}>
                  {(orderEffectiveDate.isFutureDate || orderEffectiveDate.isPastDate) && (
                    <Body size='large' stylew={{ padding: '1.3125rem' }}>
                      {orderEffectiveDate.isFutureDate
                        ? `Your new Services & perks will take effect on : ${orderEffectiveDate.effectiveDate}`
                        : `Your new Services & perks has been activated and backdated to : ${orderEffectiveDate.effectiveDate}`}
                    </Body>
                  )}
                  <TextLink
                    className='link'
                    tabIndex='0'
                    aria-label='Change'
                    style={{ 'font-weight': 'bold', color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}
                    role='link'
                    onClick={() => changeEffectiveDate()}
                  >
                    Change
                  </TextLink>
                  <div style={{ height: '4vh' }} />
                </div>
              )}
            </ModalBody>
            <ModalFooter
              surface={isDark ? 'dark' : 'light'}
              buttonData={{
                primary: {
                  children: 'Done',
                  width: '150px',
                  onClick: () => handleClick('done'),
                },
              }}
            />
          </MarginSides>
        </Modal>
      </div>
    </>
  );
};

ServicePerksModal.propTypes = {
  opened: PropTypes.object,
  closeModal: PropTypes.func,
  existingFeatures: PropTypes.any,
  newFeatures: PropTypes.any,
  oldFeatures: PropTypes.any,
  defaultImageLabel: PropTypes.string,
  line: PropTypes.object,
  fpsReferences: PropTypes.any,
  fetchPriceSnapshotSubAccount: PropTypes.array,
  readOrderData: PropTypes.object,
  isRefundReadOrder: PropTypes.bool,
  refundfeatureflag: PropTypes.bool,
};

export default ServicePerksModal;
