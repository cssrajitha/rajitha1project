import React from 'react';
import PropTypes from 'prop-types';
import { PDFView as CommonPDFView } from 'onevzsoemfecommon/PDFView';
import styled from 'styled-components';

const PDFWrapper = styled.div`
  height: 75vh;
  width: auto;
  overflow-y: scroll;
  overflow-x: hidden;
  scrollbar-width: thin !important;
`;

function PDFView(props) {
  return (
    <PDFWrapper id='pdf' data-testid='pdf-view' onScroll={props.onScroll}>
      <CommonPDFView src={props.src} onError={props.onError} />
    </PDFWrapper>
  );
}

PDFView.propTypes = {
  src: PropTypes.any,
  onError: PropTypes.func,
  onScroll: PropTypes.func,
};

export default PDFView;
