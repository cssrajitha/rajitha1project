export const cartDatasetandGoMock = {
    "data": {
      "cart": {
        "customerProfile": {
          "billAccounts": [
            {
              "mtns": [
                {
                  "mtn": "8138531515",
                  "equipmentUpgradeEligibility": {
                    "upgradeEligibilityDate": "07/28/2025",
                    "upgradeEligible": true,
                    "twoYearContract": {}
                  },
                  "mobileInfoAttributes": {
                    "smartFamilyParent": false,
                    "accessRoles": {
                      "owner": false,
                      "manager": false,
                      "member": false
                    }
                  },
                  "equipmentInfos": [
                    {
                      "deviceInfo": {
                        "modelName": "Apple Watch Series 7 GPS + Cellular, 45mm Midnight Aluminum Case with Midnight Sport Band - Regular",
                        "deviceId": "358427486768156",
                        "deviceIdType": "IME",
                        "deviceSku": "MKJ73LL/A"
                      },
                      "simInfo": {
                        "modelName": "STM SOFT SIM",
                        "simId": "89148000008309669319",
                        "simSku": "SOFTSIM-CMR-S"
                      }
                    }
                  ],
                  "lineSharingIndicator": "R",
                  "pricePlanInfo": {
                    "planId": "18056",
                    "planAttributes": {
                      "sharePlan": false
                    }
                  },
                  "currentSpo": [
                    {
                      "spoId": "732",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    }
                  ]
                },
                {
                  "mtn": "8133477604",
                  "equipmentUpgradeEligibility": {
                    "upgradeEligibilityDate": "07/14/2025",
                    "upgradeEligible": true,
                    "twoYearContract": {}
                  },
                  "mobileInfoAttributes": {
                    "smartFamilyParent": false,
                    "accessRoles": {
                      "owner": false,
                      "manager": true,
                      "member": false
                    }
                  },
                  "equipmentInfos": [
                    {
                      "deviceInfo": {
                        "modelName": "IPHONE 13 PRO MAX 128 SR BLU",
                        "deviceId": "352865677734782",
                        "deviceIdType": "IME",
                        "deviceSku": "CLNRAPL13PM128SB"
                      },
                      "simInfo": {
                        "modelName": "SIM SKU 4G 5G",
                        "simId": "89148000009826583322",
                        "simSku": "BULKSIM5G-SA-A"
                      }
                    }
                  ],
                  "lineSharingIndicator": "L",
                  "pricePlanInfo": {
                    "planId": "50430",
                    "planAttributes": {
                      "sharePlan": false
                    }
                  },
                  "currentSpo": [
                    {
                      "spoId": "384",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    },
                    {
                      "spoId": "732",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    },
                    {
                      "spoId": "1255",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    },
                    {
                      "spoId": "1535",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    },
                    {
                      "spoId": "1692",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    },
                    {
                      "spoId": "1801",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    },
                    {
                      "spoId": "2006",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    },
                    {
                      "spoId": "2107",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    },
                    {
                      "spoId": "2108",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    },
                    {
                      "spoId": "2176",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    },
                    {
                      "spoId": "2996",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    }
                  ]
                }
              ],
              "fiosEligibilityCategory": "",
              "accountAddress": {
                "zipCode": "33569",
                "zipCodePlus4": "0000",
                "fipsCode": "1205760950",
                "addressLine1": "6013 PORTSDALE PL UNIT 201",
                "addressLine2": "",
                "city": "RIVERVIEW",
                "state": "FL",
                "scrubbedAddress": {
                  "streetName": "PORTSDALE",
                  "streetNumber": "6013",
                  "streetType": "PL",
                  "streetDirection": "",
                  "apartmentNo": "201",
                  "pobox": "",
                  "ruralDeliveryNo": "",
                  "ruralRouteNo": "",
                  "city": "RIVERVIEW",
                  "state": "FL",
                  "country": "",
                  "zipCode": "33578",
                  "zipCodePlus4": "4097"
                }
              },
              "accountAttributes": {
                "autopay": {
                  "autoPayDiscount": "5.00"
                }
              },
              "accountOffers": {
                "lineLevelOffers": {
                  "productOffers": [
                    {
                      "spoId": "384",
                      "price": "0.00",
                      "description": "INTL TRAVEL VOICE & DATA PAYGO"
                    },
                    {
                      "spoId": "732",
                      "price": "0.00",
                      "description": "CDMA-LESS ROAM TIER OVERRIDE"
                    },
                    {
                      "spoId": "1255",
                      "price": "0.00",
                      "description": "TRAVELPASS"
                    },
                    {
                      "spoId": "1535",
                      "price": "0.00",
                      "description": "DIGITAL SECURE PROVISIONING"
                    },
                    {
                      "spoId": "1692",
                      "price": "0.00",
                      "description": "5G DYNAMIC SPECTRUM SHARING"
                    },
                    {
                      "spoId": "1801",
                      "price": "0.00",
                      "description": "UNLIMITED PLAN INDICATOR"
                    },
                    {
                      "spoId": "2006",
                      "price": "0.00",
                      "description": "CALL FILTER PLUS PROVISIONING"
                    },
                    {
                      "spoId": "2107",
                      "price": "0.00",
                      "description": "5G ULTRA WIDEBAND ACCESS"
                    },
                    {
                      "spoId": "2108",
                      "price": "0.00",
                      "description": "5G ULTRA WIDEBAND PROVISIONING"
                    },
                    {
                      "spoId": "2176",
                      "price": "0.00",
                      "description": "APPLE ARCADE INCL WITH PLAN"
                    },
                    {
                      "spoId": "2996",
                      "price": "0.00",
                      "description": "MOBILE HOTSPOT 5GB"
                    }
                  ]
                }
              }
            }
          ],
          "customerAttributes": {
            "taxExemptCode": "N",
            "digitalCustomerType": "B2C"
          }
        },
        "cartHasOnlyAccessories": false,
        "cartHasConflicts": true,
        "conflictsAccepted": true,
        "flow": "NAO|AAL_5G|AAL|NAO",
        "cartHeader": {
          "winBackAccountNumber": "",
          "vendorId": "NETACE",
          "ani": 8133477604,
          "repRole": "POSSYSTST",
          "locationType": "S",
          "isVzPhEligible": true,
          "sourceSystem": "OMNI-RETAIL",
          "fullAccountNumber": "0325654132-1",
          "status": "A",
          "createTimestamp": "2024-10-14T05:30:54.69-04:00[US/Eastern]",
          "lastUpdateTimestamp": "2024-10-14T06:20:33.98-04:00[US/Eastern]",
          "cartCreator": "8133477604",
          "cartCreatorChannelId": "OMNI-RETAIL",
          "cartCreatorOrderLocationCode": "0026301",
          "cartCreatorSalesRepId": "ENC",
          "visionCustomerType": "PE",
          "maverickLocation": false,
          "preConfiguredCartType": "BAU",
          "preConfiguredCartTypeDuringAddDevice": "BAU",
          "isCoreRep": false,
          "isERTRep": false
        },
        "orderDetails": {
          "totalUpgradeFee": 0.0,
          "totalDeviceDollar": 0.0,
          "totalRemainingDeviceDollar": 0.0,
          "totalUsedDeviceDollar": 0.0,
          "totalAccountLevelAccCost": 0.0,
          "totalAccountLevelAccCostWithTax": 0.0,
          "totalShippingCost": 0.0,
          "totalDiscountedShippingCost": 0.0,
          "hqUser": false,
          "returnException": false,
          "verizonCardPromoOfferList": [],
          "verizonCardApplicationInfo": {},
          "taxDetailsList": [
            {
              "taxSequenceNum": 1,
              "taxPassType": "10",
              "taxAmount": "91.74",
              "taxDescription": "FL State Sales Tax",
              "taxType": "01",
              "mldSequenceNum": 1,
              "taxSurcharge": "T"
            },
            {
              "taxSequenceNum": 2,
              "taxPassType": "20",
              "taxAmount": "22.93",
              "taxDescription": "Hillsborough Cnty Sales Tax",
              "taxType": "02",
              "mldSequenceNum": 2,
              "taxSurcharge": "T"
            }
          ],
          "subTotalDueTodayWithoutUpgradeFee": 698.95,
          "subTotalDueMonthlyForAALBYODEUP": 121.0,
          "shipTogetherPref": true,
          "assistanceOptedByCustomer": false,
          "locationState": "NJ",
          "totalVerizonDollarUsed": "0.0",
          "isShellAccountSelected": false,
          "fullfillmentLocation": "1000001",
          "guestOrInactiveRefundLines": false,
          "totalDueMonthlyOnProfile": 0.0,
          "subTotalDueMonthlyOnProfile": 0.0,
          "totalMonthlyTaxesOnProfile": 0.0,
          "subTotalOtherLinesOnProfile": 0.0,
          "estimatedNextMonthChargeOnProfile": 0.0,
          "originalSubTotalDueMonthly": 423.3,
          "totalDueMonthlyAfterDiscounts": 307.05,
          "accessoryFinancingOfferInfo": {
            "installmentTerm": "12",
            "installmentInfo": {
              "monthlyInstallment": 0.0,
              "accessoryTotal": 751.37
            },
            "offerEligibleAmount": 100.0,
            "offerExpiryDate": "12/31/2025",
            "offerDisQualifiedAfterRemoveAcc": false,
            "dfoInstallmentInfo": {
              "monthlyInstallment": 0.0,
              "dfoDevicesTotal": 0.0,
              "installmentTerm": "36",
              "dfoTotalSalesTax": 0.0
            },
            "splitPaymentInfo": [
              {
                "orderNumber": "22004373",
                "nonAccessoryTotal": 62.25,
                "accessoryTotal": 751.37,
                "totalFinanceAmount": 0.0,
                "monthlyFinanceAmount": 0.0,
                "isAfo": true,
                "isDfo": false
              }
            ],
            "offerAvailable": true,
            "customerEligible": true,
            "offerAccepted": false,
            "disclosureAgreementSent": false
          },
          "totalTaxAdjustmentAmount": 0.0,
          "totalActivationFees": 0.0,
          "fiveGHomeOrder": false,
          "totalRefundAmount": 0.0,
          "totalExchangeAmount": 0.0,
          "totalRefundTaxAmount": 0.0,
          "totalExchangeTaxAmount": 0.0,
          "digitalExchange": false,
          "remainingAmountAfterAffirmApplied": 0.0,
          "cashOptionEnabled": false,
          "affirmCreditCheckFailed": false,
          "payTodayWithoutDfo": 813.62,
          "orderType": "PS",
          "locationCode": "0026301",
          "customerType": "U",
          "billingSystem": "VE",
          "totalTaxAmount": "114.67",
          "chargeSummary": [
            {
              "chargeType": "ActivationFee",
              "amount": 35.0,
              "finalPrice": 35.0
            }
          ],
          "spocs": {
            "notificationOptions": {
              "contactPhoneNumber": "9703050307",
              "primaryEmailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM"
            }
          },
          "totalDueToday": 813.62,
          "runningTotalDueToday": 813.62,
          "totalDueTodayFlag": false,
          "totalDueMonthly": 325.8,
          "subTotalDueMonthly": 307.05,
          "subTotalDueToday": 698.95,
          "subTotalMonthlyTaxes": 0.0,
          "estimatedNextMonthCharge": 517.99,
          "totalMonthlyTaxes": 18.75,
          "subTotalOtherLines": 133.83,
          "subTotalOtherLinesTaxes": 0.0,
          "instantDRCCredit": false,
          "isAttachmentCompleted": false,
          "nextMonthBillTotal": 0.0,
          "customerNotification": {
            "smsLanguage": "E"
          },
          "effectiveDateDetails": {
            "suggestedBackDate": "",
            "suggestedFutureDate": "",
            "currentBillCycleBeginDate": "10/06/2024",
            "nextBillCycleBeginDate": "11/06/2024",
            "onDemandDate": "10/14/2024",
            "onDemandRangeInDays": "45",
            "selectedDate": "10/14/2024",
            "onDemandAllowed": true,
            "backDateAllowed": false,
            "futureDateAllowed": false
          },
          "orderChannelId": "OMNI-RETAIL",
          "orderList": [
            {
              "creditApplication": {
                "creditApplicationNum": 414220049,
                "creditApprovalStatus": "AP",
                "creditStatusReason": "CA Customer Systematic Approval",
                "internationalEligibility": true,
                "securityDepositAmount": "0",
                "serviceClass": "B",
                "lineCreditClass": "1D",
                "creditAppEdited": false
              },
              "orderActivityType": "EUP",
              "orderNumber": 0,
              "numOfLinesForOrderActivityType": 0,
              "preOrderNumber": 0,
              "digitalOrderId": 0,
              "managerApprovalRequired": false
            },
            {
              "orderActivityType": "ACC",
              "orderNumber": 22004358,
              "numOfLinesForOrderActivityType": 0,
              "preOrderNumber": 0,
              "digitalOrderId": 994734874731161,
              "managerApprovalRequired": false
            },
            {
              "creditApplication": {
                "creditApplicationNum": 411220050,
                "creditApprovalStatus": "AP",
                "creditStatusReason": "CA Customer Systematic Approval",
                "internationalEligibility": false,
                "creditAdvisory": "APP 411220050 APPROVED  - WITH NO DEPOSIT REQUIRED 'B '",
                "securityDepositAmount": "0",
                "serviceClass": "B",
                "lineCreditClass": "1D",
                "creditAppEdited": false
              },
              "orderActivityType": "AAL_5G",
              "orderNumber": 22004369,
              "numOfLinesForOrderActivityType": 1,
              "preOrderNumber": 0,
              "digitalOrderId": 0,
              "managerApprovalRequired": false
            },
            {
              "creditApplication": {
                "creditApplicationNum": 410220052,
                "creditApprovalStatus": "AP",
                "creditStatusReason": "CA Customer Systematic Approval",
                "internationalEligibility": false,
                "creditAdvisory": "APP 410220052 APPROVED  - WITH NO DEPOSIT REQUIRED 'B '",
                "securityDepositAmount": "0",
                "serviceClass": "B",
                "lineCreditClass": "1D",
                "creditAppEdited": false
              },
              "orderActivityType": "AAL",
              "orderNumber": 22004373,
              "numOfLinesForOrderActivityType": 2,
              "preOrderNumber": 0,
              "digitalOrderId": 0,
              "managerApprovalRequired": false
            }
          ],
          "outletId": "000000263",
          "registerNumber": "51",
          "saleType": "P",
          "salesRepId": "ENC",
          "enableSplitShipment": false,
          "splitShipmentIndicator": false,
          "cartReadyForCheckout": true,
          "isSingleModConnectedDevice": false,
          "fiveGUpSellAccountLevel": false,
          "customerOnTrialPlan": false,
          "availableSlotsForGrantee": "0",
          "totalDownPaymentAmt": 0.0,
          "totalEdgeBuyOutAmount": 0.0,
          "expressCheckout": false,
          "nbxInfo": {
            "isPreQualifiedNBX": true,
            "syfOfferId": "8806908917",
            "propositionMessage": "Thank You! You have been Pre-Approved.Sign up and receive: $100 sign up bonus and more",
            "propositionName": "Pre-Qualified - Transaction Flow",
            "propositionId": "GC_01",
            "vzccFeedbackStatus": "DECLINED",
            "isVZCCHolder": false,
            "sessionId": "6558661564718555627",
            "soiEngagementId": "501002526",
            "isPreScreenRepresentment": "N"
          },
          "isEQPandPPLOfferApplied": false,
          "cartTotalDiscounts": {
            "totalDiscount": "0.0",
            "barCodeOfferAppliedOnOrder": false,
            "discountDetails": []
          },
          "memberTotalDueToday": 0.0,
          "customerConsent": "Y",
          "totalDwosCost": "0.0",
          "billingState": "FL",
          "isTradeInOfferSelected": false,
          "isAssignMtnRequired": false,
          "fiosCapable": false,
          "fiosEligible": false,
          "quoteWithoutCredit": false,
          "uswinAuthenticationRequired": true,
          "newPreToPostInfo": {
            "newPreToPostIndicator": "E",
            "newPreToPostMtns": {
              "accountOwner": "",
              "accountMembers": []
            }
          },
          "totalDueTodayWithoutDiscount": 813.62,
          "subTotalDueTodayWithoutDiscount": 698.95,
          "isComboOrder": "Y",
          "totalPerksSavings": "0.0"
        },
        "lineDetails": {
          "lineInfo": [
            {
              "isCommonPDP": false,
              "isTradeInIntentSelected": false,
              "multiLineSeqNumber": 3,
              "lineActivityType": "ACC",
              "totalDueToday": 353.66,
              "totalDueTodayWithoutTax": 328.99,
              "totalDueTodayWithoutTaxWithoutDiscount": 328.99,
              "totalDueMonthly": 133.83,
              "mobileNumber": "8133477604",
              "showGlobalChoiceOffer": false,
              "serviceInfo": {
                "planDiscount": {
                  "planEligibleForAutoPayPaperLessDiscount": false,
                  "discountIncluded": false,
                  "totalPlanCostIncludingLineAccessFee": "0.0"
                },
                "serviceAddress": {
                  "addressLine1": "6013 PORTSDALE PL UNIT 201",
                  "addressLine2": "",
                  "zipCode": "33578",
                  "zipCode4": "4097",
                  "firstName": "DON",
                  "lastName": "WRIGHT",
                  "city": "RIVERVIEW",
                  "state": "FL"
                },
                "comparePlan": false,
                "primaryUserInfo": {
                  "firstName": "DON",
                  "lastName": "WRIGHT",
                  "address": {
                    "firmName": "",
                    "apartmentNo": "201",
                    "type": "PL",
                    "streetNumber": "6013",
                    "streetName": "PORTSDALE",
                    "addressLine2": "",
                    "addressLine1": "6013 PORTSDALE PL UNIT 201",
                    "poBoxNo": "",
                    "ruralRouteNo": "",
                    "ruralDelNo": "",
                    "city": "RIVERVIEW",
                    "state": "FL",
                    "zipCode": "33578",
                    "zipCode4": "4097",
                    "county": "",
                    "countryCode": "US",
                    "fipsCode": "1205760950",
                    "firstName": "DON",
                    "lastName": "WRIGHT",
                    "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                    "phoneNumber": "9089349238",
                    "streetType": "PL",
                    "streetDirection": ""
                  },
                  "isValidAddress": true,
                  "bsnsName": "",
                  "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                  "midInitials": ""
                },
                "mtn": "8133477604",
                "min": "8132580300",
                "oldPricePlanId": "50430",
                "contractTermId": "48",
                "currentDevice": {
                  "oldLteVoraEquipInfo": {
                    "iccid": "89148000009826583322",
                    "lteVoraDeviceInfo": {
                      "deviceId": "352865677734782",
                      "deviceType": "5GE",
                      "deviceSku": "CLNRAPL13PM128SB",
                      "description": "IPHONE 13 PRO MAX 128 SR BLU",
                      "imageUrlMap": {
                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue",
                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-lg$",
                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-med$",
                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-mini$",
                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-thumb$"
                      },
                      "color": {},
                      "manufacturer": "Apple"
                    }
                  }
                },
                "isSharePlanAdded": false,
                "mea": "V0T",
                "isE911AddressValidated": false,
                "oldPlanFlag": "L",
                "orderDevice": {
                  "lteVoraEquipInfo": {
                    "lteEqpt": {},
                    "lteVoraDeviceInfo": {}
                  }
                },
                "kidsPlanParentMtn": false,
                "mcsSubscription": [],
                "fiveGUpSell": false,
                "e911AddressSameAsServiceAddress": false,
                "unpairedGrantor": false,
                "totalAddedFeaturesPrice": "0.0"
              },
              "itemsInfo": [
                {
                  "depletionType": "F",
                  "attention": "DON WRIGHT",
                  "shipping": {
                    "address": {
                      "firmName": "",
                      "apartmentNo": "201",
                      "type": "R",
                      "streetNumber": "6013",
                      "streetName": "PORTSDALE",
                      "addressLine2": "",
                      "addressLine1": "6013 PORTSDALE PL UNIT 201",
                      "poBoxNo": "",
                      "ruralDelNo": "",
                      "city": "RIVERVIEW",
                      "state": "FL",
                      "zipCode": "33578",
                      "zipCode4": "4097",
                      "county": "",
                      "countryCode": "",
                      "fipsCode": "1205760950",
                      "firstName": "DON",
                      "lastName": "WRIGHT",
                      "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                      "phoneNumber": "9089349238",
                      "streetType": "PL",
                      "streetDirection": ""
                    },
                    "bsnsName": "",
                    "shippingCode": "SHP002",
                    "shippingCost": "0.00",
                    "shippingDescription": "Free 2 Day by 8pm",
                    "cbrPhone": "9089349238",
                    "firstName": "DON",
                    "lastName": "WRIGHT",
                    "midInitials": "",
                    "isUseUnVerifiedAddress": false,
                    "isValidAddress": false,
                    "email": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                    "shipToCustomerAddress": false
                  },
                  "fipsCode": "1205760950",
                  "itemCount": 2,
                  "itemTabSeqNum": 0,
                  "cartItems": {
                    "cartItem": [
                      {
                        "discountAmount": 0.0,
                        "deviceDollarApplied": 0.0,
                        "promoHubOfferList": {
                          "promoHubOfferList": [],
                          "offerCount": 0
                        },
                        "qrScanNeededForEsimActivation": false,
                        "isPreconfigureDuringAddDevice": false,
                        "deviceDisplayName": "AirPods 4 with Active Noise Cancellation",
                        "accessoryGiftCardAmount": 0.0,
                        "tradeInAmountTowardsUserDPUsed": 0.0,
                        "sorDeviceCategory": "Bluetooth Headphones",
                        "vendingKioskItem": "false",
                        "tradeInAutoPull": false,
                        "priceAdjustment": false,
                        "priceAdjustmentQty": 0,
                        "newPurchasedQty": 1,
                        "canonicalUrl": "products/apple-airpods-4-with-active-noise-cancellation/",
                        "selectedForRFEX": false,
                        "selectedForPAD": false,
                        "bogoItem": false,
                        "refxItemSeqNum": 0,
                        "restrictedAccySku": false,
                        "maxAccyPurchaseLimit": false,
                        "giftCard": false,
                        "itemCode": "MXP93LL/A",
                        "totalPriceWithDiscount": 179.0,
                        "sorId": "MXP93LL/A",
                        "skuId": "sku6016076",
                        "cartItemType": "ACCESSORY",
                        "description": "AirPods 4 with Active Noise Cancellation",
                        "qty": 1,
                        "bundleSeqNum": 0,
                        "itemPrice": "179.00",
                        "discountedPercentage": 0.0,
                        "discountedPrice": 179.0,
                        "buyOutTaxAmountUnbilled": 0.0,
                        "buyOutAmountWithoutTax": 0.0,
                        "taxAmount": 13.42,
                        "imageUrlMap": {
                          "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset",
                          "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-lg$",
                          "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-med$",
                          "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-mini$",
                          "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-thumb$"
                        },
                        "prodCode1": "LAB",
                        "prodCode2": "SER",
                        "prodCode3": "OEM",
                        "prodCode4": "000",
                        "prodCode5": "000",
                        "btaEligible": "true",
                        "depletionType": "F",
                        "catalogPrice": 179.0,
                        "instantCreditAmountUsed": 0.0,
                        "instantCreditAmountUsedForTaxes": 0.0,
                        "color": {
                          "color": "#F9F8F3",
                          "colorDisplayName": "WHITE"
                        },
                        "unitTaxBasedPrice": 179.0,
                        "itemNrpPrice": 179.0,
                        "discounts": [],
                        "availableReasonCode": [],
                        "inventory": {
                          "isAvailable": true,
                          "isBackorder": false,
                          "isDeliverBy": false,
                          "isPreOrder": false,
                          "qtyAvailable": 1426,
                          "isShipBy": false
                        },
                        "isCustomerProvidedSIM": false,
                        "isNetworkExtender": false,
                        "ispuEligible": true,
                        "itemSeqNum": 11,
                        "sddEligible": true,
                        "smartIMEI": false,
                        "year": 0,
                        "sellerPrice": "0.0",
                        "productId": "acc20893304",
                        "taxDetailsList": [
                          {
                            "taxSequenceNum": 1,
                            "taxPassType": "10",
                            "taxAmount": "10.74",
                            "taxDescription": "FL State Sales Tax",
                            "taxType": "01",
                            "mldSequenceNum": 1,
                            "taxSurcharge": "T"
                          },
                          {
                            "taxSequenceNum": 2,
                            "taxPassType": "20",
                            "taxAmount": "2.68",
                            "taxDescription": "Hillsborough Cnty Sales Tax",
                            "taxType": "02",
                            "mldSequenceNum": 2,
                            "taxSurcharge": "T"
                          }
                        ],
                        "manufacturer": "Apple",
                        "quantityOnHand": 1426,
                        "iconicPhone": false,
                        "ringBell": false,
                        "isPreconfigureEnabled": false,
                        "isHumDevice": false,
                        "isSmartLocator": false,
                        "isSecurityAlarm": false,
                        "isMotoMod": false,
                        "isConnectedCar": false,
                        "accountLevelAccessory": false,
                        "byodESimPhone": false,
                        "scannedItem": false,
                        "appleCareAccessoryFlag": false,
                        "quantityAllowed": true,
                        "isDfoSelected": false
                      },
                      {
                        "discountAmount": 0.0,
                        "deviceDollarApplied": 0.0,
                        "promoHubOfferList": {
                          "promoHubOfferList": [],
                          "offerCount": 0
                        },
                        "qrScanNeededForEsimActivation": false,
                        "isPreconfigureDuringAddDevice": false,
                        "deviceDisplayName": "Soundgear Sense Open-Ear Headphones - Black",
                        "accessoryGiftCardAmount": 0.0,
                        "tradeInAmountTowardsUserDPUsed": 0.0,
                        "sorDeviceCategory": "Bluetooth Headphones",
                        "vendingKioskItem": "false",
                        "tradeInAutoPull": false,
                        "priceAdjustment": false,
                        "priceAdjustmentQty": 0,
                        "newPurchasedQty": 1,
                        "canonicalUrl": "products/jbl-soundgear-sense-open-ear-headphones/",
                        "selectedForRFEX": false,
                        "selectedForPAD": false,
                        "bogoItem": false,
                        "refxItemSeqNum": 0,
                        "restrictedAccySku": false,
                        "maxAccyPurchaseLimit": false,
                        "giftCard": false,
                        "itemCode": "JBLSNDGEARSNSBLKAM",
                        "totalPriceWithDiscount": 149.99,
                        "sorId": "JBLSNDGEARSNSBLKAM",
                        "skuId": "sku6013494",
                        "cartItemType": "ACCESSORY",
                        "description": "Soundgear Sense Open-Ear Headphones - Black",
                        "qty": 1,
                        "bundleSeqNum": 0,
                        "itemPrice": "149.99",
                        "discountedPercentage": 0.0,
                        "discountedPrice": 149.99,
                        "buyOutTaxAmountUnbilled": 0.0,
                        "buyOutAmountWithoutTax": 0.0,
                        "taxAmount": 11.25,
                        "imageUrlMap": {
                          "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset",
                          "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-lg$",
                          "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-med$",
                          "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-mini$",
                          "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-thumb$"
                        },
                        "prodCode1": "ACC",
                        "prodCode2": "BLU",
                        "prodCode3": "OEM",
                        "prodCode4": "000",
                        "prodCode5": "000",
                        "btaEligible": "true",
                        "depletionType": "F",
                        "catalogPrice": 149.99,
                        "instantCreditAmountUsed": 0.0,
                        "instantCreditAmountUsedForTaxes": 0.0,
                        "color": {
                          "color": "#000000",
                          "colorDisplayName": "BLACK"
                        },
                        "unitTaxBasedPrice": 149.99,
                        "itemNrpPrice": 149.99,
                        "discounts": [],
                        "availableReasonCode": [],
                        "inventory": {
                          "isAvailable": true,
                          "isBackorder": false,
                          "isDeliverBy": false,
                          "isPreOrder": false,
                          "qtyAvailable": 1018,
                          "isShipBy": false
                        },
                        "isCustomerProvidedSIM": false,
                        "isNetworkExtender": false,
                        "ispuEligible": true,
                        "itemSeqNum": 12,
                        "sddEligible": true,
                        "smartIMEI": false,
                        "year": 0,
                        "sellerPrice": "0.0",
                        "productId": "acc20892292",
                        "taxDetailsList": [
                          {
                            "taxSequenceNum": 1,
                            "taxPassType": "10",
                            "taxAmount": "9.00",
                            "taxDescription": "FL State Sales Tax",
                            "taxType": "01",
                            "mldSequenceNum": 1,
                            "taxSurcharge": "T"
                          },
                          {
                            "taxSequenceNum": 2,
                            "taxPassType": "20",
                            "taxAmount": "2.25",
                            "taxDescription": "Hillsborough Cnty Sales Tax",
                            "taxType": "02",
                            "mldSequenceNum": 2,
                            "taxSurcharge": "T"
                          }
                        ],
                        "manufacturer": "JBL",
                        "quantityOnHand": 0,
                        "iconicPhone": false,
                        "ringBell": false,
                        "isPreconfigureEnabled": false,
                        "isHumDevice": false,
                        "isSmartLocator": false,
                        "isSecurityAlarm": false,
                        "isMotoMod": false,
                        "isConnectedCar": false,
                        "accountLevelAccessory": false,
                        "byodESimPhone": false,
                        "scannedItem": false,
                        "appleCareAccessoryFlag": false,
                        "quantityAllowed": true,
                        "isDfoSelected": false
                      },
                      {
                        "discountAmount": 0.0,
                        "deviceDollarApplied": 0.0,
                        "qrScanNeededForEsimActivation": false,
                        "isPreconfigureDuringAddDevice": false,
                        "accessoryGiftCardAmount": 0.0,
                        "tradeInAmountTowardsUserDPUsed": 0.0,
                        "vendingKioskItem": "false",
                        "tradeInAutoPull": false,
                        "priceAdjustment": false,
                        "priceAdjustmentQty": 0,
                        "newPurchasedQty": 0,
                        "selectedForRFEX": false,
                        "selectedForPAD": false,
                        "bogoItem": false,
                        "refxItemSeqNum": 0,
                        "restrictedAccySku": false,
                        "maxAccyPurchaseLimit": false,
                        "giftCard": false,
                        "itemCode": "SHP002",
                        "totalPriceWithDiscount": 0.0,
                        "sorId": "SHP002",
                        "cartItemType": "SHIPPING",
                        "mobileNumber": "8133477604",
                        "description": "Free 2 Day by 8pm",
                        "qty": 1,
                        "bundleSeqNum": 0,
                        "itemPrice": "0.0",
                        "discountedPercentage": 0.0,
                        "discountedPrice": 0.0,
                        "buyOutTaxAmountUnbilled": 0.0,
                        "buyOutAmountWithoutTax": 0.0,
                        "depletionType": "F",
                        "instantCreditAmountUsed": 0.0,
                        "instantCreditAmountUsedForTaxes": 0.0,
                        "itemCost": 0.0,
                        "discounts": [],
                        "availableReasonCode": [],
                        "isCustomerProvidedSIM": false,
                        "isNetworkExtender": false,
                        "ispuEligible": false,
                        "itemSeqNum": 0,
                        "sddEligible": false,
                        "smartIMEI": false,
                        "year": 0,
                        "sellerPrice": "0.0",
                        "taxDetailsList": [],
                        "iconicPhone": false,
                        "ringBell": false,
                        "isPreconfigureEnabled": false,
                        "isHumDevice": false,
                        "isSmartLocator": false,
                        "isSecurityAlarm": false,
                        "isMotoMod": false,
                        "isConnectedCar": false,
                        "accountLevelAccessory": false,
                        "byodESimPhone": false,
                        "appleCareAccessoryFlag": false,
                        "quantityAllowed": false,
                        "isDfoSelected": false
                      },
                      {
                        "discountAmount": 0.0,
                        "deviceDollarApplied": 0.0,
                        "promoHubOfferList": {
                          "promoHubOfferList": [],
                          "offerCount": 0
                        },
                        "qrScanNeededForEsimActivation": false,
                        "isPreconfigureDuringAddDevice": false,
                        "deviceDisplayName": "AirPods 4 with Active Noise Cancellation",
                        "accessoryGiftCardAmount": 0.0,
                        "tradeInAmountTowardsUserDPUsed": 0.0,
                        "sorDeviceCategory": "Bluetooth Headphones",
                        "vendingKioskItem": "false",
                        "tradeInAutoPull": false,
                        "priceAdjustment": false,
                        "priceAdjustmentQty": 0,
                        "newPurchasedQty": 1,
                        "canonicalUrl": "products/apple-airpods-4-with-active-noise-cancellation/",
                        "selectedForRFEX": false,
                        "selectedForPAD": false,
                        "bogoItem": false,
                        "refxItemSeqNum": 0,
                        "restrictedAccySku": false,
                        "maxAccyPurchaseLimit": false,
                        "giftCard": false,
                        "itemCode": "MXP93LL/A",
                        "totalPriceWithDiscount": 179.0,
                        "sorId": "MXP93LL/A",
                        "skuId": "sku6016076",
                        "cartItemType": "ACCESSORY",
                        "description": "AirPods 4 with Active Noise Cancellation",
                        "qty": 1,
                        "bundleSeqNum": 0,
                        "itemPrice": "179.00",
                        "discountedPercentage": 0.0,
                        "discountedPrice": 179.0,
                        "buyOutTaxAmountUnbilled": 0.0,
                        "buyOutAmountWithoutTax": 0.0,
                        "taxAmount": 13.42,
                        "imageUrlMap": {
                          "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset",
                          "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-lg$",
                          "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-med$",
                          "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-mini$",
                          "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-thumb$"
                        },
                        "prodCode1": "LAB",
                        "prodCode2": "SER",
                        "prodCode3": "OEM",
                        "prodCode4": "000",
                        "prodCode5": "000",
                        "btaEligible": "true",
                        "depletionType": "F",
                        "catalogPrice": 179.0,
                        "instantCreditAmountUsed": 0.0,
                        "instantCreditAmountUsedForTaxes": 0.0,
                        "color": {
                          "color": "#F9F8F3",
                          "colorDisplayName": "WHITE"
                        },
                        "unitTaxBasedPrice": 179.0,
                        "itemNrpPrice": 179.0,
                        "discounts": [],
                        "availableReasonCode": [],
                        "inventory": {
                          "isAvailable": true,
                          "isBackorder": false,
                          "isDeliverBy": false,
                          "isPreOrder": false,
                          "qtyAvailable": 1426,
                          "isShipBy": false
                        },
                        "isCustomerProvidedSIM": false,
                        "isNetworkExtender": false,
                        "ispuEligible": true,
                        "itemSeqNum": 11,
                        "sddEligible": true,
                        "smartIMEI": false,
                        "year": 0,
                        "sellerPrice": "0.0",
                        "productId": "acc20893304",
                        "taxDetailsList": [
                          {
                            "taxSequenceNum": 1,
                            "taxPassType": "10",
                            "taxAmount": "10.74",
                            "taxDescription": "FL State Sales Tax",
                            "taxType": "01",
                            "mldSequenceNum": 1,
                            "taxSurcharge": "T"
                          },
                          {
                            "taxSequenceNum": 2,
                            "taxPassType": "20",
                            "taxAmount": "2.68",
                            "taxDescription": "Hillsborough Cnty Sales Tax",
                            "taxType": "02",
                            "mldSequenceNum": 2,
                            "taxSurcharge": "T"
                          }
                        ],
                        "manufacturer": "Apple",
                        "quantityOnHand": 1426,
                        "iconicPhone": false,
                        "ringBell": false,
                        "isPreconfigureEnabled": false,
                        "isHumDevice": false,
                        "isSmartLocator": false,
                        "isSecurityAlarm": false,
                        "isMotoMod": false,
                        "isConnectedCar": false,
                        "accountLevelAccessory": false,
                        "byodESimPhone": false,
                        "scannedItem": false,
                        "appleCareAccessoryFlag": false,
                        "quantityAllowed": true,
                        "isDfoSelected": false
                      }
                    ]
                  },
                  "isPromoSelected": false,
                  "isTradeInSelected": false,
                  "taxExemptionTypes": ""
                }
              ],
              "mtnDetails": {
                "lineNumber": "8133477604",
                "mobileNumber": "8133477604"
              },
              "lineNumber": "8133477604",
              "fiveGToFourGDownGrade": false,
              "lineCreator": "8133477604",
              "amRole": "",
              "lineRefundTotal": 0.0,
              "lineExchangeTotal": 328.99,
              "totalDueMonthlyBeforeCredit": 0.0,
              "sugAllowed": false,
              "totalDueAddOnMonthly": 0.0,
              "totalPriceOfPlanAndPerks": "0.0",
              "isCpe": false,
              "isLTEHomeLine": false,
              "isDevicePlanCompatible": false,
              "portinMtnAssignment": false,
              "impactedLine": false,
              "preOrBackOrder": false,
              "ispuItem": false,
              "ispuItemBYOD": false,
              "isModConnected": false,
              "modDevice": false,
              "byodCapable": false,
              "isCarLine": false,
              "buySimOnly": false,
              "broadBandInd": false,
              "ispuDownPaymentAdjstRequired": false,
              "ispuDownPaymentAmount": 0.0,
              "lineWithSkipMDN": false,
              "protectionNotRequired": false
            },
            
            {
                "isCommonPDP": false,
                "isTradeInIntentSelected": false,
                "multiLineSeqNumber": 3,
                "lineActivityType": "ACC",
                "totalDueToday": 353.66,
                "totalDueTodayWithoutTax": 328.99,
                "totalDueTodayWithoutTaxWithoutDiscount": 328.99,
                "totalDueMonthly": 133.83,
                "mobileNumber": "8133477604",
                "showGlobalChoiceOffer": false,
                "serviceInfo": {
                  "planDiscount": {
                    "planEligibleForAutoPayPaperLessDiscount": false,
                    "discountIncluded": false,
                    "totalPlanCostIncludingLineAccessFee": "0.0"
                  },
                  "serviceAddress": {
                    "addressLine1": "6013 PORTSDALE PL UNIT 201",
                    "addressLine2": "",
                    "zipCode": "33578",
                    "zipCode4": "4097",
                    "firstName": "DON",
                    "lastName": "WRIGHT",
                    "city": "RIVERVIEW",
                    "state": "FL"
                  },
                  "comparePlan": false,
                  "primaryUserInfo": {
                    "firstName": "DON",
                    "lastName": "WRIGHT",
                    "address": {
                      "firmName": "",
                      "apartmentNo": "201",
                      "type": "PL",
                      "streetNumber": "6013",
                      "streetName": "PORTSDALE",
                      "addressLine2": "",
                      "addressLine1": "6013 PORTSDALE PL UNIT 201",
                      "poBoxNo": "",
                      "ruralRouteNo": "",
                      "ruralDelNo": "",
                      "city": "RIVERVIEW",
                      "state": "FL",
                      "zipCode": "33578",
                      "zipCode4": "4097",
                      "county": "",
                      "countryCode": "US",
                      "fipsCode": "1205760950",
                      "firstName": "DON",
                      "lastName": "WRIGHT",
                      "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                      "phoneNumber": "9089349238",
                      "streetType": "PL",
                      "streetDirection": ""
                    },
                    "isValidAddress": true,
                    "bsnsName": "",
                    "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                    "midInitials": ""
                  },
                  "mtn": "8133477604",
                  "min": "8132580300",
                  "oldPricePlanId": "50430",
                  "contractTermId": "48",
                  "currentDevice": {
                    "oldLteVoraEquipInfo": {
                      "iccid": "89148000009826583322",
                      "lteVoraDeviceInfo": {
                        "deviceId": "352865677734782",
                        "deviceType": "5GE",
                        "deviceSku": "CLNRAPL13PM128SB",
                        "description": "IPHONE 13 PRO MAX 128 SR BLU",
                        "imageUrlMap": {
                          "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue",
                          "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-lg$",
                          "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-med$",
                          "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-mini$",
                          "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-thumb$"
                        },
                        "color": {},
                        "manufacturer": "Apple"
                      }
                    }
                  },
                  "isSharePlanAdded": false,
                  "mea": "V0T",
                  "isE911AddressValidated": false,
                  "oldPlanFlag": "L",
                  "orderDevice": {
                    "lteVoraEquipInfo": {
                      "lteEqpt": {},
                      "lteVoraDeviceInfo": {}
                    }
                  },
                  "kidsPlanParentMtn": false,
                  "mcsSubscription": [],
                  "fiveGUpSell": false,
                  "e911AddressSameAsServiceAddress": false,
                  "unpairedGrantor": false,
                  "totalAddedFeaturesPrice": "0.0"
                },
                "itemsInfo": [
                  {
                    "depletionType": "F",
                    "attention": "DON WRIGHT",
                    "shipping": {
                      "address": {
                        "firmName": "",
                        "apartmentNo": "201",
                        "type": "R",
                        "streetNumber": "6013",
                        "streetName": "PORTSDALE",
                        "addressLine2": "",
                        "addressLine1": "6013 PORTSDALE PL UNIT 201",
                        "poBoxNo": "",
                        "ruralDelNo": "",
                        "city": "RIVERVIEW",
                        "state": "FL",
                        "zipCode": "33578",
                        "zipCode4": "4097",
                        "county": "",
                        "countryCode": "",
                        "fipsCode": "1205760950",
                        "firstName": "DON",
                        "lastName": "WRIGHT",
                        "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                        "phoneNumber": "9089349238",
                        "streetType": "PL",
                        "streetDirection": ""
                      },
                      "bsnsName": "",
                      "shippingCode": "SHP002",
                      "shippingCost": "0.00",
                      "shippingDescription": "Free 2 Day by 8pm",
                      "cbrPhone": "9089349238",
                      "firstName": "DON",
                      "lastName": "WRIGHT",
                      "midInitials": "",
                      "isUseUnVerifiedAddress": false,
                      "isValidAddress": false,
                      "email": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                      "shipToCustomerAddress": false
                    },
                    "fipsCode": "1205760950",
                    "itemCount": 2,
                    "itemTabSeqNum": 0,
                    "cartItems": {
                      "cartItem": [
                        {
                          "discountAmount": 0.0,
                          "deviceDollarApplied": 0.0,
                          "promoHubOfferList": {
                            "promoHubOfferList": [],
                            "offerCount": 0
                          },
                          "qrScanNeededForEsimActivation": false,
                          "isPreconfigureDuringAddDevice": false,
                          "deviceDisplayName": "AirPods 4 with Active Noise Cancellation",
                          "accessoryGiftCardAmount": 0.0,
                          "tradeInAmountTowardsUserDPUsed": 0.0,
                          "sorDeviceCategory": "Bluetooth Headphones",
                          "vendingKioskItem": "false",
                          "tradeInAutoPull": false,
                          "priceAdjustment": false,
                          "priceAdjustmentQty": 0,
                          "newPurchasedQty": 1,
                          "canonicalUrl": "products/apple-airpods-4-with-active-noise-cancellation/",
                          "selectedForRFEX": false,
                          "selectedForPAD": false,
                          "bogoItem": false,
                          "refxItemSeqNum": 0,
                          "restrictedAccySku": false,
                          "maxAccyPurchaseLimit": false,
                          "giftCard": false,
                          "itemCode": "MXP93LL/A",
                          "totalPriceWithDiscount": 179.0,
                          "sorId": "MXP93LL/A",
                          "skuId": "sku6016076",
                          "cartItemType": "ACCESSORY",
                          "description": "AirPods 4 with Active Noise Cancellation",
                          "qty": 1,
                          "bundleSeqNum": 0,
                          "itemPrice": "179.00",
                          "discountedPercentage": 0.0,
                          "discountedPrice": 179.0,
                          "buyOutTaxAmountUnbilled": 0.0,
                          "buyOutAmountWithoutTax": 0.0,
                          "taxAmount": 13.42,
                          "imageUrlMap": {
                            "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset",
                            "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-lg$",
                            "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-med$",
                            "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-mini$",
                            "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-thumb$"
                          },
                          "prodCode1": "LAB",
                          "prodCode2": "SER",
                          "prodCode3": "OEM",
                          "prodCode4": "000",
                          "prodCode5": "000",
                          "btaEligible": "true",
                          "depletionType": "F",
                          "catalogPrice": 179.0,
                          "instantCreditAmountUsed": 0.0,
                          "instantCreditAmountUsedForTaxes": 0.0,
                          "color": {
                            "color": "#F9F8F3",
                            "colorDisplayName": "WHITE"
                          },
                          "unitTaxBasedPrice": 179.0,
                          "itemNrpPrice": 179.0,
                          "discounts": [],
                          "availableReasonCode": [],
                          "inventory": {
                            "isAvailable": true,
                            "isBackorder": false,
                            "isDeliverBy": false,
                            "isPreOrder": false,
                            "qtyAvailable": 1426,
                            "isShipBy": false
                          },
                          "isCustomerProvidedSIM": false,
                          "isNetworkExtender": false,
                          "ispuEligible": true,
                          "itemSeqNum": 11,
                          "sddEligible": true,
                          "smartIMEI": false,
                          "year": 0,
                          "sellerPrice": "0.0",
                          "productId": "acc20893304",
                          "taxDetailsList": [
                            {
                              "taxSequenceNum": 1,
                              "taxPassType": "10",
                              "taxAmount": "10.74",
                              "taxDescription": "FL State Sales Tax",
                              "taxType": "01",
                              "mldSequenceNum": 1,
                              "taxSurcharge": "T"
                            },
                            {
                              "taxSequenceNum": 2,
                              "taxPassType": "20",
                              "taxAmount": "2.68",
                              "taxDescription": "Hillsborough Cnty Sales Tax",
                              "taxType": "02",
                              "mldSequenceNum": 2,
                              "taxSurcharge": "T"
                            }
                          ],
                          "manufacturer": "Apple",
                          "quantityOnHand": 1426,
                          "iconicPhone": false,
                          "ringBell": false,
                          "isPreconfigureEnabled": false,
                          "isHumDevice": false,
                          "isSmartLocator": false,
                          "isSecurityAlarm": false,
                          "isMotoMod": false,
                          "isConnectedCar": false,
                          "accountLevelAccessory": false,
                          "byodESimPhone": false,
                          "scannedItem": false,
                          "appleCareAccessoryFlag": false,
                          "quantityAllowed": true,
                          "isDfoSelected": false
                        },
                        {
                          "discountAmount": 0.0,
                          "deviceDollarApplied": 0.0,
                          "promoHubOfferList": {
                            "promoHubOfferList": [],
                            "offerCount": 0
                          },
                          "qrScanNeededForEsimActivation": false,
                          "isPreconfigureDuringAddDevice": false,
                          "deviceDisplayName": "Soundgear Sense Open-Ear Headphones - Black",
                          "accessoryGiftCardAmount": 0.0,
                          "tradeInAmountTowardsUserDPUsed": 0.0,
                          "sorDeviceCategory": "Bluetooth Headphones",
                          "vendingKioskItem": "false",
                          "tradeInAutoPull": false,
                          "priceAdjustment": false,
                          "priceAdjustmentQty": 0,
                          "newPurchasedQty": 1,
                          "canonicalUrl": "products/jbl-soundgear-sense-open-ear-headphones/",
                          "selectedForRFEX": false,
                          "selectedForPAD": false,
                          "bogoItem": false,
                          "refxItemSeqNum": 0,
                          "restrictedAccySku": false,
                          "maxAccyPurchaseLimit": false,
                          "giftCard": false,
                          "itemCode": "JBLSNDGEARSNSBLKAM",
                          "totalPriceWithDiscount": 149.99,
                          "sorId": "JBLSNDGEARSNSBLKAM",
                          "skuId": "sku6013494",
                          "cartItemType": "ACCESSORY",
                          "description": "Soundgear Sense Open-Ear Headphones - Black",
                          "qty": 1,
                          "bundleSeqNum": 0,
                          "itemPrice": "149.99",
                          "discountedPercentage": 0.0,
                          "discountedPrice": 149.99,
                          "buyOutTaxAmountUnbilled": 0.0,
                          "buyOutAmountWithoutTax": 0.0,
                          "taxAmount": 11.25,
                          "imageUrlMap": {
                            "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset",
                            "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-lg$",
                            "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-med$",
                            "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-mini$",
                            "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-thumb$"
                          },
                          "prodCode1": "ACC",
                          "prodCode2": "BLU",
                          "prodCode3": "OEM",
                          "prodCode4": "000",
                          "prodCode5": "000",
                          "btaEligible": "true",
                          "depletionType": "F",
                          "catalogPrice": 149.99,
                          "instantCreditAmountUsed": 0.0,
                          "instantCreditAmountUsedForTaxes": 0.0,
                          "color": {
                            "color": "#000000",
                            "colorDisplayName": "BLACK"
                          },
                          "unitTaxBasedPrice": 149.99,
                          "itemNrpPrice": 149.99,
                          "discounts": [],
                          "availableReasonCode": [],
                          "inventory": {
                            "isAvailable": true,
                            "isBackorder": false,
                            "isDeliverBy": false,
                            "isPreOrder": false,
                            "qtyAvailable": 1018,
                            "isShipBy": false
                          },
                          "isCustomerProvidedSIM": false,
                          "isNetworkExtender": false,
                          "ispuEligible": true,
                          "itemSeqNum": 12,
                          "sddEligible": true,
                          "smartIMEI": false,
                          "year": 0,
                          "sellerPrice": "0.0",
                          "productId": "acc20892292",
                          "taxDetailsList": [
                            {
                              "taxSequenceNum": 1,
                              "taxPassType": "10",
                              "taxAmount": "9.00",
                              "taxDescription": "FL State Sales Tax",
                              "taxType": "01",
                              "mldSequenceNum": 1,
                              "taxSurcharge": "T"
                            },
                            {
                              "taxSequenceNum": 2,
                              "taxPassType": "20",
                              "taxAmount": "2.25",
                              "taxDescription": "Hillsborough Cnty Sales Tax",
                              "taxType": "02",
                              "mldSequenceNum": 2,
                              "taxSurcharge": "T"
                            }
                          ],
                          "manufacturer": "JBL",
                          "quantityOnHand": 0,
                          "iconicPhone": false,
                          "ringBell": false,
                          "isPreconfigureEnabled": false,
                          "isHumDevice": false,
                          "isSmartLocator": false,
                          "isSecurityAlarm": false,
                          "isMotoMod": false,
                          "isConnectedCar": false,
                          "accountLevelAccessory": false,
                          "byodESimPhone": false,
                          "scannedItem": false,
                          "appleCareAccessoryFlag": false,
                          "quantityAllowed": true,
                          "isDfoSelected": false
                        },
                        {
                          "discountAmount": 0.0,
                          "deviceDollarApplied": 0.0,
                          "qrScanNeededForEsimActivation": false,
                          "isPreconfigureDuringAddDevice": false,
                          "accessoryGiftCardAmount": 0.0,
                          "tradeInAmountTowardsUserDPUsed": 0.0,
                          "vendingKioskItem": "false",
                          "tradeInAutoPull": false,
                          "priceAdjustment": false,
                          "priceAdjustmentQty": 0,
                          "newPurchasedQty": 0,
                          "selectedForRFEX": false,
                          "selectedForPAD": false,
                          "bogoItem": false,
                          "refxItemSeqNum": 0,
                          "restrictedAccySku": false,
                          "maxAccyPurchaseLimit": false,
                          "giftCard": false,
                          "itemCode": "SHP002",
                          "totalPriceWithDiscount": 0.0,
                          "sorId": "SHP002",
                          "cartItemType": "SHIPPING",
                          "mobileNumber": "8133477604",
                          "description": "Free 2 Day by 8pm",
                          "qty": 1,
                          "bundleSeqNum": 0,
                          "itemPrice": "0.0",
                          "discountedPercentage": 0.0,
                          "discountedPrice": 0.0,
                          "buyOutTaxAmountUnbilled": 0.0,
                          "buyOutAmountWithoutTax": 0.0,
                          "depletionType": "F",
                          "instantCreditAmountUsed": 0.0,
                          "instantCreditAmountUsedForTaxes": 0.0,
                          "itemCost": 0.0,
                          "discounts": [],
                          "availableReasonCode": [],
                          "isCustomerProvidedSIM": false,
                          "isNetworkExtender": false,
                          "ispuEligible": false,
                          "itemSeqNum": 0,
                          "sddEligible": false,
                          "smartIMEI": false,
                          "year": 0,
                          "sellerPrice": "0.0",
                          "taxDetailsList": [],
                          "iconicPhone": false,
                          "ringBell": false,
                          "isPreconfigureEnabled": false,
                          "isHumDevice": false,
                          "isSmartLocator": false,
                          "isSecurityAlarm": false,
                          "isMotoMod": false,
                          "isConnectedCar": false,
                          "accountLevelAccessory": false,
                          "byodESimPhone": false,
                          "appleCareAccessoryFlag": false,
                          "quantityAllowed": false,
                          "isDfoSelected": false
                        },
                        {
                          "discountAmount": 0.0,
                          "deviceDollarApplied": 0.0,
                          "promoHubOfferList": {
                            "promoHubOfferList": [],
                            "offerCount": 0
                          },
                          "qrScanNeededForEsimActivation": false,
                          "isPreconfigureDuringAddDevice": false,
                          "deviceDisplayName": "AirPods 4 with Active Noise Cancellation",
                          "accessoryGiftCardAmount": 0.0,
                          "tradeInAmountTowardsUserDPUsed": 0.0,
                          "sorDeviceCategory": "Bluetooth Headphones",
                          "vendingKioskItem": "false",
                          "tradeInAutoPull": false,
                          "priceAdjustment": false,
                          "priceAdjustmentQty": 0,
                          "newPurchasedQty": 1,
                          "canonicalUrl": "products/apple-airpods-4-with-active-noise-cancellation/",
                          "selectedForRFEX": false,
                          "selectedForPAD": false,
                          "bogoItem": false,
                          "refxItemSeqNum": 0,
                          "restrictedAccySku": false,
                          "maxAccyPurchaseLimit": false,
                          "giftCard": false,
                          "itemCode": "MXP93LL/A",
                          "totalPriceWithDiscount": 179.0,
                          "sorId": "MXP93LL/A",
                          "skuId": "sku6016076",
                          "cartItemType": "ACCESSORY",
                          "description": "AirPods 4 with Active Noise Cancellation",
                          "qty": 1,
                          "bundleSeqNum": 0,
                          "itemPrice": "179.00",
                          "discountedPercentage": 0.0,
                          "discountedPrice": 179.0,
                          "buyOutTaxAmountUnbilled": 0.0,
                          "buyOutAmountWithoutTax": 0.0,
                          "taxAmount": 13.42,
                          "imageUrlMap": {
                            "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset",
                            "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-lg$",
                            "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-med$",
                            "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-mini$",
                            "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-thumb$"
                          },
                          "prodCode1": "TAX",
                          "prodCode2": "SPC",
                          "prodCode3": "OEM",
                          "prodCode4": "000",
                          "prodCode5": "000",
                          "btaEligible": "true",
                          "depletionType": "F",
                          "catalogPrice": 179.0,
                          "instantCreditAmountUsed": 0.0,
                          "instantCreditAmountUsedForTaxes": 0.0,
                          "color": {
                            "color": "#F9F8F3",
                            "colorDisplayName": "WHITE"
                          },
                          "unitTaxBasedPrice": 179.0,
                          "itemNrpPrice": 179.0,
                          "discounts": [],
                          "availableReasonCode": [],
                          "inventory": {
                            "isAvailable": true,
                            "isBackorder": false,
                            "isDeliverBy": false,
                            "isPreOrder": false,
                            "qtyAvailable": 1426,
                            "isShipBy": false
                          },
                          "isCustomerProvidedSIM": false,
                          "isNetworkExtender": false,
                          "ispuEligible": true,
                          "itemSeqNum": 11,
                          "sddEligible": true,
                          "smartIMEI": false,
                          "year": 0,
                          "sellerPrice": "0.0",
                          "productId": "acc20893304",
                          "taxDetailsList": [
                            {
                              "taxSequenceNum": 1,
                              "taxPassType": "10",
                              "taxAmount": "10.74",
                              "taxDescription": "FL State Sales Tax",
                              "taxType": "01",
                              "mldSequenceNum": 1,
                              "taxSurcharge": "T"
                            },
                            {
                              "taxSequenceNum": 2,
                              "taxPassType": "20",
                              "taxAmount": "2.68",
                              "taxDescription": "Hillsborough Cnty Sales Tax",
                              "taxType": "02",
                              "mldSequenceNum": 2,
                              "taxSurcharge": "T"
                            }
                          ],
                          "manufacturer": "Apple",
                          "quantityOnHand": 1426,
                          "iconicPhone": false,
                          "ringBell": false,
                          "isPreconfigureEnabled": false,
                          "isHumDevice": false,
                          "isSmartLocator": false,
                          "isSecurityAlarm": false,
                          "isMotoMod": false,
                          "isConnectedCar": false,
                          "accountLevelAccessory": false,
                          "byodESimPhone": false,
                          "scannedItem": false,
                          "appleCareAccessoryFlag": false,
                          "quantityAllowed": true,
                          "isDfoSelected": false
                        }
                      ]
                    },
                    "isPromoSelected": false,
                    "isTradeInSelected": false,
                    "taxExemptionTypes": ""
                  }
                ],
                "mtnDetails": {
                  "lineNumber": "8133477604",
                  "mobileNumber": "8133477604"
                },
                "lineNumber": "8133477604",
                "fiveGToFourGDownGrade": false,
                "lineCreator": "8133477604",
                "amRole": "",
                "lineRefundTotal": 0.0,
                "lineExchangeTotal": 328.99,
                "totalDueMonthlyBeforeCredit": 0.0,
                "sugAllowed": false,
                "totalDueAddOnMonthly": 0.0,
                "totalPriceOfPlanAndPerks": "0.0",
                "isCpe": false,
                "isLTEHomeLine": false,
                "isDevicePlanCompatible": false,
                "portinMtnAssignment": false,
                "impactedLine": false,
                "preOrBackOrder": false,
                "ispuItem": false,
                "ispuItemBYOD": false,
                "isModConnected": false,
                "modDevice": false,
                "byodCapable": false,
                "isCarLine": false,
                "buySimOnly": false,
                "broadBandInd": false,
                "ispuDownPaymentAdjstRequired": false,
                "ispuDownPaymentAmount": 0.0,
                "lineWithSkipMDN": false,
                "protectionNotRequired": false
              }
          ],
          "numOfAccessoryAndDeviceItemsInCart": 6,
          "totalEdgeUpAmount": 0.0,
          "totalEdgeBuyOutAmount": 0.0,
          "tradeInDetail": {},
          "totalDownPaymentAmt": 0.0,
          "numOfLinesWithDevices": 2,
          "discountGainIndicators": [],
          "discountLossIndicators": [],
          "subscriptionInfos": [],
          "numofApprovedLines": 0,
          "rfexPayments": [],
          "numOfLines": 4,
          "numofLinesAAL": 2,
          "numofLinesEUP": 0,
          "payments": [],
          "lineSeq": 0,
          "vlcactivePhoneCount": 0,
          "fivegOrderind": true,
          "aceOrderCreated": true,
          "serviceLinesCreated": false,
          "aceItemsModified": true,
          "enableLineInfoFFlag": true,
          "clnrOrderFlag": false,
          "broadbandInd": false,
          "isAutoPayEnrolled": "N",
          "isAutoPayPaperLessDiscountEligible": "Y",
          "isPaperLessEnrolled": "Y",
          "totalEligibleAutoPayPaperLessDiscount": "25.00",
          "tabletJetpackDiscountMultiLineLoss": "N",
          "acctMcsSubscription": [],
          "spendingLimitAmountExceededBy": "0.0",
          "numofAccessories": 4,
          "subAccountNBSInfo": [
            {
              "billAccounts": [
                {
                  "billSummary": {
                    "grandTotal": {
                      "newMonthCharge": "325.80",
                      "nextMonthCharge": "517.99"
                    },
                    "planCharge": {
                      "newMonthCharge": "251.50",
                      "nextMonthCharge": "422.34"
                    },
                    "lineAccessFees": {
                      "newMonthCharge": "0.00",
                      "nextMonthCharge": "0.00"
                    },
                    "devicePayments": {
                      "newMonthCharge": "68.60",
                      "nextMonthCharge": "68.79"
                    },
                    "surcharges": {
                      "newMonthCharge": "12.92",
                      "nextMonthCharge": "21.26"
                    },
                    "taxesAndFees": {
                      "newMonthCharge": "5.83",
                      "nextMonthCharge": "12.14"
                    },
                    "totalAddOns": {
                      "newMonthCharge": "36.95",
                      "nextMonthCharge": "36.95"
                    },
                    "appleMusic": {
                      "newMonthCharge": "0.00",
                      "nextMonthCharge": "0.00"
                    },
                    "mobileProtection": {
                      "newMonthCharge": "26.95",
                      "nextMonthCharge": "26.95"
                    },
                    "planAccessFeeTotal": {
                      "newMonthCharge": "251.50",
                      "nextMonthCharge": "422.34"
                    },
                    "taxGrandTotal": {
                      "newMonthCharge": "18.75",
                      "nextMonthCharge": "33.40"
                    },
                    "subTotal": {
                      "newMonthCharge": "307.05",
                      "nextMonthCharge": "484.59"
                    },
                    "autoPayDiscount": {
                      "accountTotalAutoPayDiscount": "25.00",
                      "isCustomerEnrolledForAutopay": false,
                      "subTotalNewMonthwithAutoPayDisc": "282.05"
                    },
                    "dateRange": {
                      "thisMonth": "10/06/2024-11/05/2024",
                      "nextMonth": "11/06/2024-12/05/2024"
                    }
                  },
                  "nbs": {
                    "accountNumber": "0325654132-00001",
                    "nextBillCycleStartDate": "11/06/2024",
                    "balancePastDue": {
                      "pastDueAmount": "0.00",
                      "paymentsReceived": "0.00",
                      "previousBalance": "295.88",
                      "balanceType": "Current Balance",
                      "unbilledPayment": "-144.64",
                      "totUnpaidBalance": "151.24",
                      "paymentMessage": "You have paid a portion of your current bill. The remaining balance of $151.24 is due on 10/28/2024.",
                      "unbilledOCC": "0.00"
                    },
                    "monthlyChargesInfo": {
                      "accountLevelCharges": [
                        {
                          "thisMonthCharge": "-25.00",
                          "nextMonthCharge": "-25.00",
                          "chargeRefId": "1781",
                          "description": "LOYALTY $25 DISC 2-3 PHONES",
                          "itemType": [
                            {
                              "equipment": false,
                              "feature": false,
                              "naf": false,
                              "occ": false,
                              "plan": false,
                              "promo": false,
                              "accequipment": false,
                              "sfo": false,
                              "spo": false,
                              "addOn": false
                            }
                          ],
                          "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                          "listPrice": "-25.00",
                          "netPrice": "-25.00"
                        }
                      ],
                      "accountLevelTotal": {
                        "thisMonthCharge": "-25.00",
                        "nextMonthCharge": "-41.94",
                        "differenceBetweenThisMonthAndNextMonthCharge": "-16.94",
                        "totalOneTimeCharge": "-16.94",
                        "newMonthMrcWithNoAddOn": "-25.00",
                        "nextMonthMrcWithNoAddOn": "-25.00",
                        "nextMonthAcctLevelSurcharges": "0.00",
                        "newMonthAcctLevelSurcharges": "0.00",
                        "nextMonthAccountLevelTax": "0.00",
                        "newMonthAccountLevelTax": "0.00",
                        "chargeTotals": [
                          {
                            "itemRef": "SPO",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "-25.00",
                            "nextMonthCharge": "-25.00"
                          },
                          {
                            "itemRef": "Total Addons",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "0.00",
                            "nextMonthCharge": "0.00"
                          }
                        ]
                      },
                      "mtnLevelChargeDetails": [
                        {
                          "mtn": "8133477604",
                          "thisMonthCharge": "133.83",
                          "nextMonthCharge": "190.73",
                          "differenceBetweenThisMonthAndNextMonthCharge": "56.90",
                          "thisMonthSurcharges": "4.68",
                          "previousMonthCharge": "0.00",
                          "nextMonthSurcharges": "4.92",
                          "differenceBetweenThisMonthAndNextMonthSurcharges": "0.24",
                          "thisMonthTax": "2.08",
                          "nextMonthTax": "2.26",
                          "differenceBetweenThisMonthAndNextMonthTax": "0.18",
                          "chargeDetails": [
                            {
                              "thisMonthCharge": "84.00",
                              "nextMonthCharge": "84.00",
                              "chargeRefId": "50430",
                              "description": "5G PLAY MORE",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "84.00",
                              "netPrice": "84.00",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            },
                            {
                              "thisMonthCharge": "30.83",
                              "nextMonthCharge": "30.83",
                              "chargeRefId": "352396479769529",
                              "description": "Device Payment",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "30.83",
                              "netPrice": "30.83",
                              "loanNumber": "1587790945",
                              "nextInstallmentNumber": "25",
                              "totalInstallmentNumber": "36",
                              "outstandingLoanAmount": "339.13",
                              "loanAmount": "1110.00",
                              "loanCode": "A"
                            },
                            {
                              "thisMonthCharge": "19.00",
                              "nextMonthCharge": "19.00",
                              "chargeRefId": "88690",
                              "description": "VERIZON MOBILE PROTECT",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "19.00",
                              "netPrice": "19.00",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            }
                          ],
                          "oneTimeChargeDetails": [
                            {
                              "thisMonthCharge": "0.00",
                              "nextMonthCharge": "56.90",
                              "chargeRefId": "50430",
                              "description": "5G PLAY MORE",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "56.90",
                              "netPrice": "56.90",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            }
                          ],
                          "nickname": "DON WRIGHT",
                          "suppressAdvInd": "N",
                          "newMonthMtnMrcWithNoAddOn": "114.83",
                          "nextMonthMtnMrcWithNoAddOn": "114.83",
                          "newMonthGrandTotalWithTaxes": "140.59",
                          "nextMonthGrandTotalWithTaxes": "197.91",
                          "chargeTotals": [
                            {
                              "itemRef": "Equipment",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "30.83",
                              "nextMonthCharge": "30.83"
                            },
                            {
                              "itemRef": "Total Addons",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "19.00",
                              "nextMonthCharge": "19.00"
                            },
                            {
                              "itemRef": "PPLAN",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "84.00",
                              "nextMonthCharge": "84.00"
                            },
                            {
                              "itemRef": "Auto Pay",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "5.00",
                              "nextMonthCharge": "5.00"
                            }
                          ],
                          "mtnChangeInd": false
                        },
                        {
                          "mtn": "8137244660",
                          "thisMonthCharge": "55.00",
                          "nextMonthCharge": "92.25",
                          "differenceBetweenThisMonthAndNextMonthCharge": "37.25",
                          "thisMonthSurcharges": "0.00",
                          "previousMonthCharge": "0.00",
                          "nextMonthSurcharges": "0.00",
                          "differenceBetweenThisMonthAndNextMonthSurcharges": "0.00",
                          "thisMonthTax": "0.00",
                          "nextMonthTax": "0.00",
                          "differenceBetweenThisMonthAndNextMonthTax": "0.00",
                          "chargeDetails": [
                            {
                              "thisMonthCharge": "80.00",
                              "nextMonthCharge": "80.00",
                              "chargeRefId": "75561",
                              "description": "5G HOME PLUS",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "80.00",
                              "netPrice": "80.00",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            },
                            {
                              "thisMonthCharge": "-25.00",
                              "nextMonthCharge": "-25.00",
                              "chargeRefId": "2722",
                              "description": "MOBILE + HOME DISCOUNT",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "-25.00",
                              "netPrice": "-25.00",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            },
                            {
                              "thisMonthCharge": "10.00",
                              "nextMonthCharge": "10.00",
                              "chargeRefId": "3239",
                              "description": "WHOLE-HOME WI-FI",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "-10.00",
                              "listPrice": "10.00",
                              "netPrice": "0.00",
                              "promo1Id": "20996",
                              "promo1Desc": "WHOLE-HOME WI-FI DISCOUNT",
                              "promo1Discount": "-10.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            },
                            {
                              "thisMonthCharge": "10.00",
                              "nextMonthCharge": "10.00",
                              "chargeRefId": "2641",
                              "description": "DISNEY BUNDLE",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "-10.00",
                              "listPrice": "10.00",
                              "netPrice": "0.00",
                              "promo1Id": "21015",
                              "promo1Desc": "DISNEY BUNDLE PROMO",
                              "promo1Discount": "-10.00",
                              "promo1EndDate": "10/11/2025",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            }
                          ],
                          "oneTimeChargeDetails": [
                            {
                              "thisMonthCharge": "0.00",
                              "nextMonthCharge": "54.19",
                              "chargeRefId": "75561",
                              "description": "5G HOME PLUS",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "54.19",
                              "netPrice": "54.19",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            },
                            {
                              "thisMonthCharge": "0.00",
                              "nextMonthCharge": "-16.94",
                              "chargeRefId": "2722",
                              "description": "MOBILE + HOME DISCOUNT",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "-16.94",
                              "netPrice": "-16.94",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            },
                            {
                              "thisMonthCharge": "0.00",
                              "nextMonthCharge": "6.77",
                              "chargeRefId": "3239",
                              "description": "WHOLE-HOME WI-FI",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "-6.77",
                              "listPrice": "6.77",
                              "netPrice": "0.00",
                              "promo1Id": "20996",
                              "promo1Desc": "WHOLE-HOME WI-FI DISCOUNT",
                              "promo1Discount": "-6.77",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            }
                          ],
                          "nickname": "New line",
                          "suppressAdvInd": "N",
                          "newMonthMtnMrcWithNoAddOn": "55.00",
                          "nextMonthMtnMrcWithNoAddOn": "55.00",
                          "newMonthGrandTotalWithTaxes": "55.00",
                          "nextMonthGrandTotalWithTaxes": "92.25",
                          "chargeTotals": [
                            {
                              "itemRef": "SPO",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "-25.00",
                              "nextMonthCharge": "-25.00"
                            },
                            {
                              "itemRef": "Total Addons",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "0.00",
                              "nextMonthCharge": "0.00"
                            },
                            {
                              "itemRef": "PPLAN",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "80.00",
                              "nextMonthCharge": "80.00"
                            },
                            {
                              "itemRef": "Auto Pay",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "10.00",
                              "nextMonthCharge": "10.00"
                            }
                          ],
                          "mtnChangeInd": false
                        },
                        {
                          "mtn": "8137277652",
                          "thisMonthCharge": "121.00",
                          "nextMonthCharge": "215.77",
                          "differenceBetweenThisMonthAndNextMonthCharge": "94.77",
                          "thisMonthSurcharges": "4.32",
                          "previousMonthCharge": "0.00",
                          "nextMonthSurcharges": "12.38",
                          "differenceBetweenThisMonthAndNextMonthSurcharges": "8.06",
                          "thisMonthTax": "2.75",
                          "nextMonthTax": "8.83",
                          "differenceBetweenThisMonthAndNextMonthTax": "6.08",
                          "chargeDetails": [
                            {
                              "thisMonthCharge": "80.00",
                              "nextMonthCharge": "80.00",
                              "chargeRefId": "63217",
                              "description": "UNLIMITED PLUS",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "80.00",
                              "netPrice": "80.00",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            },
                            {
                              "thisMonthCharge": "23.05",
                              "nextMonthCharge": "23.24",
                              "description": "Device Payment",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.19",
                              "listPrice": "23.05",
                              "netPrice": "23.05",
                              "loanNumber": "0",
                              "nextInstallmentNumber": "1",
                              "totalInstallmentNumber": "36",
                              "outstandingLoanAmount": "806.75",
                              "loanAmount": "829.99",
                              "loanCode": "A"
                            },
                            {
                              "thisMonthCharge": "7.95",
                              "nextMonthCharge": "7.95",
                              "chargeRefId": "85913",
                              "description": "WIRELESS PHONE PROTECTION",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "7.95",
                              "netPrice": "7.95",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            },
                            {
                              "thisMonthCharge": "10.00",
                              "nextMonthCharge": "10.00",
                              "chargeRefId": "2641",
                              "description": "DISNEY BUNDLE",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "10.00",
                              "netPrice": "10.00",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            }
                          ],
                          "oneTimeChargeDetails": [
                            {
                              "thisMonthCharge": "0.00",
                              "nextMonthCharge": "54.19",
                              "chargeRefId": "63217",
                              "description": "UNLIMITED PLUS",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "54.19",
                              "netPrice": "54.19",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            },
                            {
                              "thisMonthCharge": "0.00",
                              "nextMonthCharge": "5.39",
                              "chargeRefId": "85913",
                              "description": "WIRELESS PHONE PROTECTION",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "5.39",
                              "netPrice": "5.39",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            },
                            {
                              "thisMonthCharge": "0.00",
                              "nextMonthCharge": "35.00",
                              "chargeRefId": "3",
                              "description": "ACTIVATION FEE",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "listPrice": "0.0",
                              "netPrice": "0.0",
                              "recurringIndicator": "N",
                              "balanceDueIndicator": "N"
                            }
                          ],
                          "nickname": "New line",
                          "suppressAdvInd": "N",
                          "newMonthMtnMrcWithNoAddOn": "103.05",
                          "nextMonthMtnMrcWithNoAddOn": "103.24",
                          "newMonthGrandTotalWithTaxes": "128.07",
                          "nextMonthGrandTotalWithTaxes": "236.98",
                          "chargeTotals": [
                            {
                              "itemRef": "Equipment",
                              "differenceBetweenThisAndNextMonthCharge": "-0.19",
                              "thisMonthCharge": "23.05",
                              "nextMonthCharge": "23.05"
                            },
                            {
                              "itemRef": "Total Addons",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "17.95",
                              "nextMonthCharge": "17.95"
                            },
                            {
                              "itemRef": "PPLAN",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "80.00",
                              "nextMonthCharge": "80.00"
                            },
                            {
                              "itemRef": "OCC",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "0.00",
                              "nextMonthCharge": "0.00"
                            },
                            {
                              "itemRef": "Auto Pay",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "10.00",
                              "nextMonthCharge": "10.00"
                            }
                          ],
                          "mtnChangeInd": false
                        },
                        {
                          "mtn": "8138531515",
                          "thisMonthCharge": "22.22",
                          "nextMonthCharge": "27.78",
                          "differenceBetweenThisMonthAndNextMonthCharge": "5.56",
                          "thisMonthSurcharges": "3.92",
                          "previousMonthCharge": "0.00",
                          "nextMonthSurcharges": "3.96",
                          "differenceBetweenThisMonthAndNextMonthSurcharges": "0.04",
                          "thisMonthTax": "1.00",
                          "nextMonthTax": "1.05",
                          "differenceBetweenThisMonthAndNextMonthTax": "0.05",
                          "chargeDetails": [
                            {
                              "thisMonthCharge": "15.00",
                              "nextMonthCharge": "15.00",
                              "chargeRefId": "18056",
                              "description": "NUMBER SHARE",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "-7.50",
                              "listPrice": "15.00",
                              "netPrice": "7.50",
                              "promo1Id": "19979",
                              "promo1Desc": "50% ACCESS FEE DISCOUNT FROM 813.727.7652",
                              "promo1Discount": "-7.50",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            },
                            {
                              "thisMonthCharge": "14.72",
                              "nextMonthCharge": "14.72",
                              "chargeRefId": "358427486768156",
                              "description": "Device Payment",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "14.72",
                              "netPrice": "14.72",
                              "loanNumber": "1588437200",
                              "nextInstallmentNumber": "25",
                              "totalInstallmentNumber": "36",
                              "outstandingLoanAmount": "161.92",
                              "loanAmount": "529.99",
                              "loanCode": "A"
                            }
                          ],
                          "oneTimeChargeDetails": [
                            {
                              "thisMonthCharge": "0.00",
                              "nextMonthCharge": "11.13",
                              "chargeRefId": "18056",
                              "description": "NUMBER SHARE",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "-5.57",
                              "listPrice": "11.13",
                              "netPrice": "5.56",
                              "promo1Id": "19979",
                              "promo1Desc": "50% ACCESS FEE DISCOUNT FROM 813.727.7652",
                              "promo1Discount": "-5.57",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            }
                          ],
                          "nickname": "DON WRIGHT",
                          "suppressAdvInd": "N",
                          "newMonthMtnMrcWithNoAddOn": "22.22",
                          "nextMonthMtnMrcWithNoAddOn": "22.22",
                          "newMonthGrandTotalWithTaxes": "27.14",
                          "nextMonthGrandTotalWithTaxes": "32.79",
                          "chargeTotals": [
                            {
                              "itemRef": "Equipment",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "14.72",
                              "nextMonthCharge": "14.72"
                            },
                            {
                              "itemRef": "PPLAN",
                              "differenceBetweenThisAndNextMonthCharge": "-7.50",
                              "thisMonthCharge": "15.00",
                              "nextMonthCharge": "15.00"
                            }
                          ],
                          "mtnChangeInd": false
                        }
                      ],
                      "accountLevelOneTimeCharges": [
                        {
                          "thisMonthCharge": "0.00",
                          "nextMonthCharge": "-16.94",
                          "chargeRefId": "1781",
                          "description": "LOYALTY $25 DISC 2-3 PHONES",
                          "itemType": [
                            {
                              "equipment": false,
                              "feature": false,
                              "naf": false,
                              "occ": false,
                              "plan": false,
                              "promo": false,
                              "accequipment": false,
                              "sfo": false,
                              "spo": false,
                              "addOn": false
                            }
                          ],
                          "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                          "listPrice": "-16.94",
                          "netPrice": "-16.94"
                        }
                      ]
                    },
                    "monthlyTotalsInfo": {
                      "thisMonthCharge": "325.80",
                      "thisMonthChargeDateRange": "10/06/2024-11/05/2024",
                      "nextMonthCharge": "517.99",
                      "nextMonthChargeDateRange": "11/06/2024-12/05/2024",
                      "differenceBetweenThisMonthAndNextMonthCharge": "192.19",
                      "previousCycleFormattedDateRange": "Sep 06,2024 - Oct 05,2024"
                    },
                    "surchargesInfo": {
                      "thisMonthCharge": 12.92,
                      "nextMonthCharge": 21.26,
                      "differenceBetweenThisMonthAndNextMonthSurcharges": "8.34"
                    },
                    "taxesAndFeesInfo": {
                      "thisMonthCharge": 5.83,
                      "nextMonthCharge": 12.14,
                      "differenceBetweenThisMonthAndNextMonthTax": "6.31"
                    },
                    "autoPayDiscount": {
                      "accountTotalAutoPayDiscount": "25.00",
                      "isCustomerEnrolledForAutopay": false,
                      "subTotalNewMonthwithAutoPayDisc": "282.05"
                    },
                    "barGraphDetails": {
                      "invoiceCount": "3",
                      "invoiceLastMonth": "151.24",
                      "invoiceLastMonthCycleEnddate": "07/05/2024",
                      "invoiceTwoMonthPrevious": "144.64",
                      "invoiceTwoMonthCycleEnddate": "06/05/2024"
                    },
                    "nbsIndicators": {
                      "languageIndicator": "E",
                      "partialBillIndicator": "N"
                    },
                    "pendingChargesAndDiscounts": {
                      "mtnLevelPendingInfo": [],
                      "discountsPendingActionDetails": {
                        "apoPaperlessAmount": "-25.00",
                        "totalPendingDiscount": "-25.00",
                        "newMonthlyTotalWithPendingDiscounts": "300.80"
                      }
                    }
                  },
                  "billAccountNo": "1"
                }
              ]
            }
          ],
          "subAccountNbsDetails": [],
          "bagTax": false,
          "couponDetails": [{}]
        },
        "refundOrderDetails": {
          "orderNum": 0,
          "totalDueToday": "0.0",
          "subTotalDueToday": "0.0",
          "totalTaxAmount": "0.0",
          "creditApplicationNum": 0
        },
        "globalPromotions": {},
        "sfoLossReferenceDataList": [],
        "spoLossReferenceDataList": [],
        "verizonUpToastMessage": {
          "toastMessages": [],
          "eligibleProducts": []
        },
        "cartValidationErrors": [
          {
            "errorCategory": "Cart",
            "errorLevel": "Warning",
            "errorCode": "1011",
            "errorMessage": "Cart5GAppointment details are missing in Cart serviceInfo",
            "fieldPath": "8137244660"
          },
          {
            "errorCategory": "Cart",
            "errorLevel": "Warning",
            "errorCode": "1090",
            "errorMessage": "Shipping is Required",
            "fieldPath": ""
          },
          {
            "errorCategory": "Cart",
            "errorLevel": "Warning",
            "errorCode": "1016",
            "errorMessage": "Email Address is missing in shipping addresstype",
            "fieldPath": "8138531515"
          },
          {
            "errorCategory": "Cart",
            "errorLevel": "Warning",
            "errorCode": "1017",
            "errorMessage": "Phone Number is missing in shipping addresstype",
            "fieldPath": "8138531515"
          },
          {
            "errorCategory": "Cart",
            "errorLevel": "Warning",
            "errorCode": "1091",
            "errorMessage": "Payment is Required",
            "fieldPath": ""
          }
        ],
        "programEligibility": {
          "profileRemainingSpendingLimitAmount": 3407.85,
          "lineSpendingLimitAmount": 2000.0
        },
        "accountEligibility": false,
        "displayCartValidationErrors": true
      },
      "warningMessages": [],
      "basicORSmartPhoneExists": true,
      "fiveGDeviceORLTEHomeExists": false,
      "cartHasAccessories": true,
      "iscartHasVZHP": false,
      "isPortInLaterThrottled": true,
      "featureConfigurationProfileData": {
      },
      "featureFlags": {
        "rfexEligibilityForDfoFFlag": true
      },
      "orderPlaced": false,
      "validateCart": false,
      "redesignFlow": false,
      "validateAppointments": false,
      "newCustomer": false,
      "isLocalStoreOfferEnabled": false
    },
    "meta": {
      "timestamp": "1728901236632",
      "cxpCorrelationId": "2024-10-14T10:20:36.+0000:447ad94deaa89a69:cxp-shopping-services-585cdf5cdc-k7fjb:nssit2"
    }
  }
  
export const salesTaxcartDataMock = {
    "data": {
      "cart": {
        "customerProfile": {
          "billAccounts": [
            {
              "mtns": [
                {
                  "mtn": "8138531515",
                  "equipmentUpgradeEligibility": {
                    "upgradeEligibilityDate": "07/28/2025",
                    "upgradeEligible": true,
                    "twoYearContract": {}
                  },
                  "mobileInfoAttributes": {
                    "smartFamilyParent": false,
                    "accessRoles": {
                      "owner": false,
                      "manager": false,
                      "member": false
                    }
                  },
                  "equipmentInfos": [
                    {
                      "deviceInfo": {
                        "modelName": "Apple Watch Series 7 GPS + Cellular, 45mm Midnight Aluminum Case with Midnight Sport Band - Regular",
                        "deviceId": "358427486768156",
                        "deviceIdType": "IME",
                        "deviceSku": "MKJ73LL/A"
                      },
                      "simInfo": {
                        "modelName": "STM SOFT SIM",
                        "simId": "89148000008309669319",
                        "simSku": "SOFTSIM-CMR-S"
                      }
                    }
                  ],
                  "lineSharingIndicator": "R",
                  "pricePlanInfo": {
                    "planId": "18056",
                    "planAttributes": {
                      "sharePlan": false
                    }
                  },
                  "currentSpo": [
                    {
                      "spoId": "732",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    }
                  ]
                },
                {
                  "mtn": "8133477604",
                  "equipmentUpgradeEligibility": {
                    "upgradeEligibilityDate": "07/14/2025",
                    "upgradeEligible": true,
                    "twoYearContract": {}
                  },
                  "mobileInfoAttributes": {
                    "smartFamilyParent": false,
                    "accessRoles": {
                      "owner": false,
                      "manager": true,
                      "member": false
                    }
                  },
                  "equipmentInfos": [
                    {
                      "deviceInfo": {
                        "modelName": "IPHONE 13 PRO MAX 128 SR BLU",
                        "deviceId": "352865677734782",
                        "deviceIdType": "IME",
                        "deviceSku": "CLNRAPL13PM128SB"
                      },
                      "simInfo": {
                        "modelName": "SIM SKU 4G 5G",
                        "simId": "89148000009826583322",
                        "simSku": "BULKSIM5G-SA-A"
                      }
                    }
                  ],
                  "lineSharingIndicator": "L",
                  "pricePlanInfo": {
                    "planId": "50430",
                    "planAttributes": {
                      "sharePlan": false
                    }
                  },
                  "currentSpo": [
                    {
                      "spoId": "384",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    },
                    {
                      "spoId": "732",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    },
                    {
                      "spoId": "1255",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    },
                    {
                      "spoId": "1535",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    },
                    {
                      "spoId": "1692",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    },
                    {
                      "spoId": "1801",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    },
                    {
                      "spoId": "2006",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    },
                    {
                      "spoId": "2107",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    },
                    {
                      "spoId": "2108",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    },
                    {
                      "spoId": "2176",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    },
                    {
                      "spoId": "2996",
                      "price": "0.00",
                      "finalPrice": "0.00"
                    }
                  ]
                }
              ],
              "fiosEligibilityCategory": "",
              "accountAddress": {
                "zipCode": "33569",
                "zipCodePlus4": "0000",
                "fipsCode": "1205760950",
                "addressLine1": "6013 PORTSDALE PL UNIT 201",
                "addressLine2": "",
                "city": "RIVERVIEW",
                "state": "FL",
                "scrubbedAddress": {
                  "streetName": "PORTSDALE",
                  "streetNumber": "6013",
                  "streetType": "PL",
                  "streetDirection": "",
                  "apartmentNo": "201",
                  "pobox": "",
                  "ruralDeliveryNo": "",
                  "ruralRouteNo": "",
                  "city": "RIVERVIEW",
                  "state": "FL",
                  "country": "",
                  "zipCode": "33578",
                  "zipCodePlus4": "4097"
                }
              },
              "accountAttributes": {
                "autopay": {
                  "autoPayDiscount": "5.00"
                }
              },
              "accountOffers": {
                "lineLevelOffers": {
                  "productOffers": [
                    {
                      "spoId": "384",
                      "price": "0.00",
                      "description": "INTL TRAVEL VOICE & DATA PAYGO"
                    },
                    {
                      "spoId": "732",
                      "price": "0.00",
                      "description": "CDMA-LESS ROAM TIER OVERRIDE"
                    },
                    {
                      "spoId": "1255",
                      "price": "0.00",
                      "description": "TRAVELPASS"
                    },
                    {
                      "spoId": "1535",
                      "price": "0.00",
                      "description": "DIGITAL SECURE PROVISIONING"
                    },
                    {
                      "spoId": "1692",
                      "price": "0.00",
                      "description": "5G DYNAMIC SPECTRUM SHARING"
                    },
                    {
                      "spoId": "1801",
                      "price": "0.00",
                      "description": "UNLIMITED PLAN INDICATOR"
                    },
                    {
                      "spoId": "2006",
                      "price": "0.00",
                      "description": "CALL FILTER PLUS PROVISIONING"
                    },
                    {
                      "spoId": "2107",
                      "price": "0.00",
                      "description": "5G ULTRA WIDEBAND ACCESS"
                    },
                    {
                      "spoId": "2108",
                      "price": "0.00",
                      "description": "5G ULTRA WIDEBAND PROVISIONING"
                    },
                    {
                      "spoId": "2176",
                      "price": "0.00",
                      "description": "APPLE ARCADE INCL WITH PLAN"
                    },
                    {
                      "spoId": "2996",
                      "price": "0.00",
                      "description": "MOBILE HOTSPOT 5GB"
                    }
                  ]
                }
              }
            }
          ],
          "customerAttributes": {
            "taxExemptCode": "N",
            "digitalCustomerType": "B2C"
          }
        },
        "cartHasOnlyAccessories": false,
        "cartHasConflicts": true,
        "conflictsAccepted": true,
        "flow": "NAO|AAL_5G|AAL|NAO",
        "cartHeader": {
          "winBackAccountNumber": "",
          "vendorId": "NETACE",
          "ani": 8133477604,
          "repRole": "POSSYSTST",
          "locationType": "S",
          "isVzPhEligible": true,
          "sourceSystem": "OMNI-RETAIL",
          "fullAccountNumber": "0325654132-1",
          "status": "A",
          "createTimestamp": "2024-10-14T05:30:54.69-04:00[US/Eastern]",
          "lastUpdateTimestamp": "2024-10-14T06:20:33.98-04:00[US/Eastern]",
          "cartCreator": "8133477604",
          "cartCreatorChannelId": "OMNI-RETAIL",
          "cartCreatorOrderLocationCode": "0026301",
          "cartCreatorSalesRepId": "ENC",
          "visionCustomerType": "PE",
          "maverickLocation": false,
          "preConfiguredCartType": "BAU",
          "preConfiguredCartTypeDuringAddDevice": "BAU",
          "isCoreRep": false,
          "isERTRep": false
        },
        "orderDetails": {
          "totalUpgradeFee": 0.0,
          "totalDeviceDollar": 0.0,
          "totalRemainingDeviceDollar": 0.0,
          "totalUsedDeviceDollar": 0.0,
          "totalAccountLevelAccCost": 0.0,
          "totalAccountLevelAccCostWithTax": 0.0,
          "totalShippingCost": 0.0,
          "totalDiscountedShippingCost": 0.0,
          "hqUser": false,
          "returnException": false,
          "verizonCardPromoOfferList": [],
          "verizonCardApplicationInfo": {},
          "taxDetailsList": [
            {
              "taxSequenceNum": 1,
              "taxPassType": "10",
              "taxAmount": "91.74",
              "taxDescription": "FL State Sales Tax",
              "taxType": "01",
              "mldSequenceNum": 1,
              "taxSurcharge": "T"
            },
            {
              "taxSequenceNum": 2,
              "taxPassType": "20",
              "taxAmount": "22.93",
              "taxDescription": "Hillsborough Cnty Sales Tax",
              "taxType": "02",
              "mldSequenceNum": 2,
              "taxSurcharge": "T"
            }
          ],
          "subTotalDueTodayWithoutUpgradeFee": 698.95,
          "subTotalDueMonthlyForAALBYODEUP": 121.0,
          "shipTogetherPref": true,
          "assistanceOptedByCustomer": false,
          "locationState": "NJ",
          "totalVerizonDollarUsed": "0.0",
          "isShellAccountSelected": false,
          "fullfillmentLocation": "1000001",
          "guestOrInactiveRefundLines": false,
          "totalDueMonthlyOnProfile": 0.0,
          "subTotalDueMonthlyOnProfile": 0.0,
          "totalMonthlyTaxesOnProfile": 0.0,
          "subTotalOtherLinesOnProfile": 0.0,
          "estimatedNextMonthChargeOnProfile": 0.0,
          "originalSubTotalDueMonthly": 423.3,
          "totalDueMonthlyAfterDiscounts": 307.05,
          "accessoryFinancingOfferInfo": {
            "installmentTerm": "12",
            "installmentInfo": {
              "monthlyInstallment": 0.0,
              "accessoryTotal": 751.37
            },
            "offerEligibleAmount": 100.0,
            "offerExpiryDate": "12/31/2025",
            "offerDisQualifiedAfterRemoveAcc": false,
            "dfoInstallmentInfo": {
              "monthlyInstallment": 0.0,
              "dfoDevicesTotal": 0.0,
              "installmentTerm": "36",
              "dfoTotalSalesTax": 0.0
            },
            "splitPaymentInfo": [
              {
                "orderNumber": "22004373",
                "nonAccessoryTotal": 62.25,
                "accessoryTotal": 751.37,
                "totalFinanceAmount": 0.0,
                "monthlyFinanceAmount": 0.0,
                "isAfo": true,
                "isDfo": false
              }
            ],
            "offerAvailable": true,
            "customerEligible": true,
            "offerAccepted": false,
            "disclosureAgreementSent": false
          },
          "totalTaxAdjustmentAmount": 0.0,
          "totalActivationFees": 0.0,
          "fiveGHomeOrder": false,
          "totalRefundAmount": 0.0,
          "totalExchangeAmount": 0.0,
          "totalRefundTaxAmount": 0.0,
          "totalExchangeTaxAmount": 0.0,
          "digitalExchange": false,
          "remainingAmountAfterAffirmApplied": 0.0,
          "cashOptionEnabled": false,
          "affirmCreditCheckFailed": false,
          "payTodayWithoutDfo": 813.62,
          "orderType": "PS",
          "locationCode": "0026301",
          "customerType": "U",
          "billingSystem": "VE",
          "totalTaxAmount": "114.67",
          "chargeSummary": [
            {
              "chargeType": "ActivationFee",
              "amount": 35.0,
              "finalPrice": 35.0
            }
          ],
          "spocs": {
            "notificationOptions": {
              "contactPhoneNumber": "9703050307",
              "primaryEmailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM"
            }
          },
          "totalDueToday": 813.62,
          "runningTotalDueToday": 813.62,
          "totalDueTodayFlag": false,
          "totalDueMonthly": 325.8,
          "subTotalDueMonthly": 307.05,
          "subTotalDueToday": 698.95,
          "subTotalMonthlyTaxes": 0.0,
          "estimatedNextMonthCharge": 517.99,
          "totalMonthlyTaxes": 18.75,
          "subTotalOtherLines": 133.83,
          "subTotalOtherLinesTaxes": 0.0,
          "instantDRCCredit": false,
          "isAttachmentCompleted": false,
          "nextMonthBillTotal": 0.0,
          "customerNotification": {
            "smsLanguage": "E"
          },
          "effectiveDateDetails": {
            "suggestedBackDate": "",
            "suggestedFutureDate": "",
            "currentBillCycleBeginDate": "10/06/2024",
            "nextBillCycleBeginDate": "11/06/2024",
            "onDemandDate": "10/14/2024",
            "onDemandRangeInDays": "45",
            "selectedDate": "10/14/2024",
            "onDemandAllowed": true,
            "backDateAllowed": false,
            "futureDateAllowed": false
          },
          "orderChannelId": "OMNI-RETAIL",
          "orderList": [
            {
              "creditApplication": {
                "creditApplicationNum": 414220049,
                "creditApprovalStatus": "AP",
                "creditStatusReason": "CA Customer Systematic Approval",
                "internationalEligibility": true,
                "securityDepositAmount": "0",
                "serviceClass": "B",
                "lineCreditClass": "1D",
                "creditAppEdited": false
              },
              "orderActivityType": "EUP",
              "orderNumber": 0,
              "numOfLinesForOrderActivityType": 0,
              "preOrderNumber": 0,
              "digitalOrderId": 0,
              "managerApprovalRequired": false
            },
            {
              "orderActivityType": "ACC",
              "orderNumber": 22004358,
              "numOfLinesForOrderActivityType": 0,
              "preOrderNumber": 0,
              "digitalOrderId": 994734874731161,
              "managerApprovalRequired": false
            },
            {
              "creditApplication": {
                "creditApplicationNum": 411220050,
                "creditApprovalStatus": "AP",
                "creditStatusReason": "CA Customer Systematic Approval",
                "internationalEligibility": false,
                "creditAdvisory": "APP 411220050 APPROVED  - WITH NO DEPOSIT REQUIRED 'B '",
                "securityDepositAmount": "0",
                "serviceClass": "B",
                "lineCreditClass": "1D",
                "creditAppEdited": false
              },
              "orderActivityType": "AAL_5G",
              "orderNumber": 22004369,
              "numOfLinesForOrderActivityType": 1,
              "preOrderNumber": 0,
              "digitalOrderId": 0,
              "managerApprovalRequired": false
            },
            {
              "creditApplication": {
                "creditApplicationNum": 410220052,
                "creditApprovalStatus": "AP",
                "creditStatusReason": "CA Customer Systematic Approval",
                "internationalEligibility": false,
                "creditAdvisory": "APP 410220052 APPROVED  - WITH NO DEPOSIT REQUIRED 'B '",
                "securityDepositAmount": "0",
                "serviceClass": "B",
                "lineCreditClass": "1D",
                "creditAppEdited": false
              },
              "orderActivityType": "AAL",
              "orderNumber": 22004373,
              "numOfLinesForOrderActivityType": 2,
              "preOrderNumber": 0,
              "digitalOrderId": 0,
              "managerApprovalRequired": false
            }
          ],
          "outletId": "000000263",
          "registerNumber": "51",
          "saleType": "P",
          "salesRepId": "ENC",
          "enableSplitShipment": false,
          "splitShipmentIndicator": false,
          "cartReadyForCheckout": true,
          "isSingleModConnectedDevice": false,
          "fiveGUpSellAccountLevel": false,
          "customerOnTrialPlan": false,
          "availableSlotsForGrantee": "0",
          "totalDownPaymentAmt": 0.0,
          "totalEdgeBuyOutAmount": 0.0,
          "expressCheckout": false,
          "nbxInfo": {
            "isPreQualifiedNBX": true,
            "syfOfferId": "8806908917",
            "propositionMessage": "Thank You! You have been Pre-Approved.Sign up and receive: $100 sign up bonus and more",
            "propositionName": "Pre-Qualified - Transaction Flow",
            "propositionId": "GC_01",
            "vzccFeedbackStatus": "DECLINED",
            "isVZCCHolder": false,
            "sessionId": "6558661564718555627",
            "soiEngagementId": "501002526",
            "isPreScreenRepresentment": "N"
          },
          "isEQPandPPLOfferApplied": false,
          "cartTotalDiscounts": {
            "totalDiscount": "0.0",
            "barCodeOfferAppliedOnOrder": false,
            "discountDetails": []
          },
          "memberTotalDueToday": 0.0,
          "customerConsent": "Y",
          "totalDwosCost": "0.0",
          "billingState": "FL",
          "isTradeInOfferSelected": false,
          "isAssignMtnRequired": false,
          "fiosCapable": false,
          "fiosEligible": false,
          "quoteWithoutCredit": false,
          "uswinAuthenticationRequired": true,
          "newPreToPostInfo": {
            "newPreToPostIndicator": "E",
            "newPreToPostMtns": {
              "accountOwner": "",
              "accountMembers": []
            }
          },
          "totalDueTodayWithoutDiscount": 813.62,
          "subTotalDueTodayWithoutDiscount": 698.95,
          "isComboOrder": "Y",
          "totalPerksSavings": "0.0"
        },
        "lineDetails": {
          "lineInfo": [
            {
              "isCommonPDP": false,
              "isTradeInIntentSelected": false,
              "multiLineSeqNumber": 3,
              "lineActivityType": "ACC",
              "totalDueToday": 353.66,
              "totalDueTodayWithoutTax": 328.99,
              "totalDueTodayWithoutTaxWithoutDiscount": 328.99,
              "totalDueMonthly": 133.83,
              "mobileNumber": "8133477604",
              "showGlobalChoiceOffer": false,
              "serviceInfo": {
                "planDiscount": {
                  "planEligibleForAutoPayPaperLessDiscount": false,
                  "discountIncluded": false,
                  "totalPlanCostIncludingLineAccessFee": "0.0"
                },
                "serviceAddress": {
                  "addressLine1": "6013 PORTSDALE PL UNIT 201",
                  "addressLine2": "",
                  "zipCode": "33578",
                  "zipCode4": "4097",
                  "firstName": "DON",
                  "lastName": "WRIGHT",
                  "city": "RIVERVIEW",
                  "state": "FL"
                },
                "comparePlan": false,
                "primaryUserInfo": {
                  "firstName": "DON",
                  "lastName": "WRIGHT",
                  "address": {
                    "firmName": "",
                    "apartmentNo": "201",
                    "type": "PL",
                    "streetNumber": "6013",
                    "streetName": "PORTSDALE",
                    "addressLine2": "",
                    "addressLine1": "6013 PORTSDALE PL UNIT 201",
                    "poBoxNo": "",
                    "ruralRouteNo": "",
                    "ruralDelNo": "",
                    "city": "RIVERVIEW",
                    "state": "FL",
                    "zipCode": "33578",
                    "zipCode4": "4097",
                    "county": "",
                    "countryCode": "US",
                    "fipsCode": "1205760950",
                    "firstName": "DON",
                    "lastName": "WRIGHT",
                    "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                    "phoneNumber": "9089349238",
                    "streetType": "PL",
                    "streetDirection": ""
                  },
                  "isValidAddress": true,
                  "bsnsName": "",
                  "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                  "midInitials": ""
                },
                "mtn": "8133477604",
                "min": "8132580300",
                "oldPricePlanId": "50430",
                "contractTermId": "48",
                "currentDevice": {
                  "oldLteVoraEquipInfo": {
                    "iccid": "89148000009826583322",
                    "lteVoraDeviceInfo": {
                      "deviceId": "352865677734782",
                      "deviceType": "5GE",
                      "deviceSku": "CLNRAPL13PM128SB",
                      "description": "IPHONE 13 PRO MAX 128 SR BLU",
                      "imageUrlMap": {
                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue",
                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-lg$",
                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-med$",
                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-mini$",
                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-thumb$"
                      },
                      "color": {},
                      "manufacturer": "Apple"
                    }
                  }
                },
                "isSharePlanAdded": false,
                "mea": "V0T",
                "isE911AddressValidated": false,
                "oldPlanFlag": "L",
                "orderDevice": {
                  "lteVoraEquipInfo": {
                    "lteEqpt": {},
                    "lteVoraDeviceInfo": {}
                  }
                },
                "kidsPlanParentMtn": false,
                "mcsSubscription": [],
                "fiveGUpSell": false,
                "e911AddressSameAsServiceAddress": false,
                "unpairedGrantor": false,
                "totalAddedFeaturesPrice": "0.0"
              },
              "itemsInfo": [
                {
                  "depletionType": "F",
                  "attention": "DON WRIGHT",
                  "shipping": {
                    "address": {
                      "firmName": "",
                      "apartmentNo": "201",
                      "type": "R",
                      "streetNumber": "6013",
                      "streetName": "PORTSDALE",
                      "addressLine2": "",
                      "addressLine1": "6013 PORTSDALE PL UNIT 201",
                      "poBoxNo": "",
                      "ruralDelNo": "",
                      "city": "RIVERVIEW",
                      "state": "FL",
                      "zipCode": "33578",
                      "zipCode4": "4097",
                      "county": "",
                      "countryCode": "",
                      "fipsCode": "1205760950",
                      "firstName": "DON",
                      "lastName": "WRIGHT",
                      "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                      "phoneNumber": "9089349238",
                      "streetType": "PL",
                      "streetDirection": ""
                    },
                    "bsnsName": "",
                    "shippingCode": "SHP002",
                    "shippingCost": "0.00",
                    "shippingDescription": "Free 2 Day by 8pm",
                    "cbrPhone": "9089349238",
                    "firstName": "DON",
                    "lastName": "WRIGHT",
                    "midInitials": "",
                    "isUseUnVerifiedAddress": false,
                    "isValidAddress": false,
                    "email": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                    "shipToCustomerAddress": false
                  },
                  "fipsCode": "1205760950",
                  "itemCount": 2,
                  "itemTabSeqNum": 0,
                  "cartItems": {
                    "cartItem": [
                      {
                        "discountAmount": 0.0,
                        "deviceDollarApplied": 0.0,
                        "promoHubOfferList": {
                          "promoHubOfferList": [],
                          "offerCount": 0
                        },
                        "qrScanNeededForEsimActivation": false,
                        "isPreconfigureDuringAddDevice": false,
                        "deviceDisplayName": "AirPods 4 with Active Noise Cancellation",
                        "accessoryGiftCardAmount": 0.0,
                        "tradeInAmountTowardsUserDPUsed": 0.0,
                        "sorDeviceCategory": "Bluetooth Headphones",
                        "vendingKioskItem": "false",
                        "tradeInAutoPull": false,
                        "priceAdjustment": false,
                        "priceAdjustmentQty": 0,
                        "newPurchasedQty": 1,
                        "canonicalUrl": "products/apple-airpods-4-with-active-noise-cancellation/",
                        "selectedForRFEX": false,
                        "selectedForPAD": false,
                        "bogoItem": false,
                        "refxItemSeqNum": 0,
                        "restrictedAccySku": false,
                        "maxAccyPurchaseLimit": false,
                        "giftCard": false,
                        "itemCode": "MXP93LL/A",
                        "totalPriceWithDiscount": 179.0,
                        "sorId": "MXP93LL/A",
                        "skuId": "sku6016076",
                        "cartItemType": "ACCESSORY",
                        "description": "AirPods 4 with Active Noise Cancellation",
                        "qty": 1,
                        "bundleSeqNum": 0,
                        "itemPrice": "179.00",
                        "discountedPercentage": 0.0,
                        "discountedPrice": 179.0,
                        "buyOutTaxAmountUnbilled": 0.0,
                        "buyOutAmountWithoutTax": 0.0,
                        "taxAmount": 13.42,
                        "imageUrlMap": {
                          "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset",
                          "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-lg$",
                          "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-med$",
                          "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-mini$",
                          "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-thumb$"
                        },
                        "prodCode1": "TAX",
                        "prodCode2": "SPC",
                        "prodCode3": "OEM",
                        "prodCode4": "000",
                        "prodCode5": "000",
                        "btaEligible": "true",
                        "depletionType": "F",
                        "catalogPrice": 179.0,
                        "instantCreditAmountUsed": 0.0,
                        "instantCreditAmountUsedForTaxes": 0.0,
                        "color": {
                          "color": "#F9F8F3",
                          "colorDisplayName": "WHITE"
                        },
                        "unitTaxBasedPrice": 179.0,
                        "itemNrpPrice": 179.0,
                        "discounts": [],
                        "availableReasonCode": [],
                        "inventory": {
                          "isAvailable": true,
                          "isBackorder": false,
                          "isDeliverBy": false,
                          "isPreOrder": false,
                          "qtyAvailable": 1426,
                          "isShipBy": false
                        },
                        "isCustomerProvidedSIM": false,
                        "isNetworkExtender": false,
                        "ispuEligible": true,
                        "itemSeqNum": 11,
                        "sddEligible": true,
                        "smartIMEI": false,
                        "year": 0,
                        "sellerPrice": "0.0",
                        "productId": "acc20893304",
                        "taxDetailsList": [
                          {
                            "taxSequenceNum": 1,
                            "taxPassType": "10",
                            "taxAmount": "10.74",
                            "taxDescription": "FL State Sales Tax",
                            "taxType": "01",
                            "mldSequenceNum": 1,
                            "taxSurcharge": "T"
                          },
                          {
                            "taxSequenceNum": 2,
                            "taxPassType": "20",
                            "taxAmount": "2.68",
                            "taxDescription": "Hillsborough Cnty Sales Tax",
                            "taxType": "02",
                            "mldSequenceNum": 2,
                            "taxSurcharge": "T"
                          }
                        ],
                        "manufacturer": "Apple",
                        "quantityOnHand": 1426,
                        "iconicPhone": false,
                        "ringBell": false,
                        "isPreconfigureEnabled": false,
                        "isHumDevice": false,
                        "isSmartLocator": false,
                        "isSecurityAlarm": false,
                        "isMotoMod": false,
                        "isConnectedCar": false,
                        "accountLevelAccessory": false,
                        "byodESimPhone": false,
                        "scannedItem": false,
                        "appleCareAccessoryFlag": false,
                        "quantityAllowed": true,
                        "isDfoSelected": false
                      },
                      {
                        "discountAmount": 0.0,
                        "deviceDollarApplied": 0.0,
                        "promoHubOfferList": {
                          "promoHubOfferList": [],
                          "offerCount": 0
                        },
                        "qrScanNeededForEsimActivation": false,
                        "isPreconfigureDuringAddDevice": false,
                        "deviceDisplayName": "Soundgear Sense Open-Ear Headphones - Black",
                        "accessoryGiftCardAmount": 0.0,
                        "tradeInAmountTowardsUserDPUsed": 0.0,
                        "sorDeviceCategory": "Bluetooth Headphones",
                        "vendingKioskItem": "false",
                        "tradeInAutoPull": false,
                        "priceAdjustment": false,
                        "priceAdjustmentQty": 0,
                        "newPurchasedQty": 1,
                        "canonicalUrl": "products/jbl-soundgear-sense-open-ear-headphones/",
                        "selectedForRFEX": false,
                        "selectedForPAD": false,
                        "bogoItem": false,
                        "refxItemSeqNum": 0,
                        "restrictedAccySku": false,
                        "maxAccyPurchaseLimit": false,
                        "giftCard": false,
                        "itemCode": "JBLSNDGEARSNSBLKAM",
                        "totalPriceWithDiscount": 149.99,
                        "sorId": "JBLSNDGEARSNSBLKAM",
                        "skuId": "sku6013494",
                        "cartItemType": "SOFT_SKU",
                        "description": "Soundgear Sense Open-Ear Headphones - Black",
                        "qty": 1,
                        "bundleSeqNum": 0,
                        "itemPrice": "149.99",
                        "discountedPercentage": 0.0,
                        "discountedPrice": 149.99,
                        "buyOutTaxAmountUnbilled": 0.0,
                        "buyOutAmountWithoutTax": 0.0,
                        "taxAmount": 11.25,
                        "imageUrlMap": {
                          "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset",
                          "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-lg$",
                          "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-med$",
                          "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-mini$",
                          "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-thumb$"
                        },
                        "prodCode1": "TAX",
                        "prodCode2": "SPC",
                        "prodCode3": "OEM",
                        "prodCode4": "000",
                        "prodCode5": "000",
                        "btaEligible": "true",
                        "depletionType": "F",
                        "catalogPrice": 149.99,
                        "instantCreditAmountUsed": 0.0,
                        "instantCreditAmountUsedForTaxes": 0.0,
                        "color": {
                          "color": "#000000",
                          "colorDisplayName": "BLACK"
                        },
                        "unitTaxBasedPrice": 149.99,
                        "itemNrpPrice": 149.99,
                        "discounts": [],
                        "availableReasonCode": [],
                        "inventory": {
                          "isAvailable": true,
                          "isBackorder": false,
                          "isDeliverBy": false,
                          "isPreOrder": false,
                          "qtyAvailable": 1018,
                          "isShipBy": false
                        },
                        "isCustomerProvidedSIM": false,
                        "isNetworkExtender": false,
                        "ispuEligible": true,
                        "itemSeqNum": 12,
                        "sddEligible": true,
                        "smartIMEI": false,
                        "year": 0,
                        "sellerPrice": "0.0",
                        "productId": "acc20892292",
                        "taxDetailsList": [
                          {
                            "taxSequenceNum": 1,
                            "taxPassType": "10",
                            "taxAmount": "9.00",
                            "taxDescription": "FL State Sales Tax",
                            "taxType": "01",
                            "mldSequenceNum": 1,
                            "taxSurcharge": "T"
                          },
                          {
                            "taxSequenceNum": 2,
                            "taxPassType": "20",
                            "taxAmount": "2.25",
                            "taxDescription": "Hillsborough Cnty Sales Tax",
                            "taxType": "02",
                            "mldSequenceNum": 2,
                            "taxSurcharge": "T"
                          }
                        ],
                        "manufacturer": "JBL",
                        "quantityOnHand": 0,
                        "iconicPhone": false,
                        "ringBell": false,
                        "isPreconfigureEnabled": false,
                        "isHumDevice": false,
                        "isSmartLocator": false,
                        "isSecurityAlarm": false,
                        "isMotoMod": false,
                        "isConnectedCar": false,
                        "accountLevelAccessory": false,
                        "byodESimPhone": false,
                        "scannedItem": false,
                        "appleCareAccessoryFlag": false,
                        "quantityAllowed": true,
                        "isDfoSelected": false
                      },
                      {
                        "discountAmount": 0.0,
                        "deviceDollarApplied": 0.0,
                        "qrScanNeededForEsimActivation": false,
                        "isPreconfigureDuringAddDevice": false,
                        "accessoryGiftCardAmount": 0.0,
                        "tradeInAmountTowardsUserDPUsed": 0.0,
                        "vendingKioskItem": "false",
                        "tradeInAutoPull": false,
                        "priceAdjustment": false,
                        "priceAdjustmentQty": 0,
                        "newPurchasedQty": 0,
                        "selectedForRFEX": false,
                        "selectedForPAD": false,
                        "bogoItem": false,
                        "refxItemSeqNum": 0,
                        "restrictedAccySku": false,
                        "maxAccyPurchaseLimit": false,
                        "giftCard": false,
                        "itemCode": "SHP002",
                        "totalPriceWithDiscount": 0.0,
                        "sorId": "SHP002",
                        "cartItemType": "SHIPPING",
                        "mobileNumber": "8133477604",
                        "description": "Free 2 Day by 8pm",
                        "qty": 1,
                        "bundleSeqNum": 0,
                        "itemPrice": "0.0",
                        "discountedPercentage": 0.0,
                        "discountedPrice": 0.0,
                        "buyOutTaxAmountUnbilled": 0.0,
                        "buyOutAmountWithoutTax": 0.0,
                        "depletionType": "F",
                        "instantCreditAmountUsed": 0.0,
                        "instantCreditAmountUsedForTaxes": 0.0,
                        "itemCost": 0.0,
                        "discounts": [],
                        "availableReasonCode": [],
                        "isCustomerProvidedSIM": false,
                        "isNetworkExtender": false,
                        "ispuEligible": false,
                        "itemSeqNum": 0,
                        "sddEligible": false,
                        "smartIMEI": false,
                        "year": 0,
                        "sellerPrice": "0.0",
                        "taxDetailsList": [],
                        "iconicPhone": false,
                        "ringBell": false,
                        "isPreconfigureEnabled": false,
                        "isHumDevice": false,
                        "isSmartLocator": false,
                        "isSecurityAlarm": false,
                        "isMotoMod": false,
                        "isConnectedCar": false,
                        "accountLevelAccessory": false,
                        "byodESimPhone": false,
                        "appleCareAccessoryFlag": false,
                        "quantityAllowed": false,
                        "isDfoSelected": false
                      },
                      {
                        "discountAmount": 0.0,
                        "deviceDollarApplied": 0.0,
                        "promoHubOfferList": {
                          "promoHubOfferList": [],
                          "offerCount": 0
                        },
                        "qrScanNeededForEsimActivation": false,
                        "isPreconfigureDuringAddDevice": false,
                        "deviceDisplayName": "AirPods 4 with Active Noise Cancellation",
                        "accessoryGiftCardAmount": 0.0,
                        "tradeInAmountTowardsUserDPUsed": 0.0,
                        "sorDeviceCategory": "Bluetooth Headphones",
                        "vendingKioskItem": "false",
                        "tradeInAutoPull": false,
                        "priceAdjustment": false,
                        "priceAdjustmentQty": 0,
                        "newPurchasedQty": 1,
                        "canonicalUrl": "products/apple-airpods-4-with-active-noise-cancellation/",
                        "selectedForRFEX": false,
                        "selectedForPAD": false,
                        "bogoItem": false,
                        "refxItemSeqNum": 0,
                        "restrictedAccySku": false,
                        "maxAccyPurchaseLimit": false,
                        "giftCard": false,
                        "itemCode": "MXP93LL/A",
                        "totalPriceWithDiscount": 179.0,
                        "sorId": "MXP93LL/A",
                        "skuId": "sku6016076",
                        "cartItemType": "ACCESSORY",
                        "description": "AirPods 4 with Active Noise Cancellation",
                        "qty": 1,
                        "bundleSeqNum": 0,
                        "itemPrice": "179.00",
                        "discountedPercentage": 0.0,
                        "discountedPrice": 179.0,
                        "buyOutTaxAmountUnbilled": 0.0,
                        "buyOutAmountWithoutTax": 0.0,
                        "taxAmount": 13.42,
                        "imageUrlMap": {
                          "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset",
                          "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-lg$",
                          "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-med$",
                          "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-mini$",
                          "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-thumb$"
                        },
                        "prodCode1": "TAX",
                        "prodCode2": "SPC",
                        "prodCode3": "OEM",
                        "prodCode4": "000",
                        "prodCode5": "000",
                        "btaEligible": "true",
                        "depletionType": "F",
                        "catalogPrice": 179.0,
                        "instantCreditAmountUsed": 0.0,
                        "instantCreditAmountUsedForTaxes": 0.0,
                        "color": {
                          "color": "#F9F8F3",
                          "colorDisplayName": "WHITE"
                        },
                        "unitTaxBasedPrice": 179.0,
                        "itemNrpPrice": 179.0,
                        "discounts": [],
                        "availableReasonCode": [],
                        "inventory": {
                          "isAvailable": true,
                          "isBackorder": false,
                          "isDeliverBy": false,
                          "isPreOrder": false,
                          "qtyAvailable": 1426,
                          "isShipBy": false
                        },
                        "isCustomerProvidedSIM": false,
                        "isNetworkExtender": false,
                        "ispuEligible": true,
                        "itemSeqNum": 11,
                        "sddEligible": true,
                        "smartIMEI": false,
                        "year": 0,
                        "sellerPrice": "0.0",
                        "productId": "acc20893304",
                        "taxDetailsList": [
                          {
                            "taxSequenceNum": 1,
                            "taxPassType": "10",
                            "taxAmount": "10.74",
                            "taxDescription": "FL State Sales Tax",
                            "taxType": "01",
                            "mldSequenceNum": 1,
                            "taxSurcharge": "T"
                          },
                          {
                            "taxSequenceNum": 2,
                            "taxPassType": "20",
                            "taxAmount": "2.68",
                            "taxDescription": "Hillsborough Cnty Sales Tax",
                            "taxType": "02",
                            "mldSequenceNum": 2,
                            "taxSurcharge": "T"
                          }
                        ],
                        "manufacturer": "Apple",
                        "quantityOnHand": 1426,
                        "iconicPhone": false,
                        "ringBell": false,
                        "isPreconfigureEnabled": false,
                        "isHumDevice": false,
                        "isSmartLocator": false,
                        "isSecurityAlarm": false,
                        "isMotoMod": false,
                        "isConnectedCar": false,
                        "accountLevelAccessory": false,
                        "byodESimPhone": false,
                        "scannedItem": false,
                        "appleCareAccessoryFlag": false,
                        "quantityAllowed": true,
                        "isDfoSelected": false
                      }
                    ]
                  },
                  "isPromoSelected": false,
                  "isTradeInSelected": false,
                  "taxExemptionTypes": ""
                }
              ],
              "mtnDetails": {
                "lineNumber": "8133477604",
                "mobileNumber": "8133477604"
              },
              "lineNumber": "8133477604",
              "fiveGToFourGDownGrade": false,
              "lineCreator": "8133477604",
              "amRole": "",
              "lineRefundTotal": 0.0,
              "lineExchangeTotal": 328.99,
              "totalDueMonthlyBeforeCredit": 0.0,
              "sugAllowed": false,
              "totalDueAddOnMonthly": 0.0,
              "totalPriceOfPlanAndPerks": "0.0",
              "isCpe": false,
              "isLTEHomeLine": false,
              "isDevicePlanCompatible": false,
              "portinMtnAssignment": false,
              "impactedLine": false,
              "preOrBackOrder": false,
              "ispuItem": false,
              "ispuItemBYOD": false,
              "isModConnected": false,
              "modDevice": false,
              "byodCapable": false,
              "isCarLine": false,
              "buySimOnly": false,
              "broadBandInd": false,
              "ispuDownPaymentAdjstRequired": false,
              "ispuDownPaymentAmount": 0.0,
              "lineWithSkipMDN": false,
              "protectionNotRequired": false
            },
            
            {
                "isCommonPDP": false,
                "isTradeInIntentSelected": false,
                "multiLineSeqNumber": 3,
                "lineActivityType": "ACC",
                "totalDueToday": 353.66,
                "totalDueTodayWithoutTax": 328.99,
                "totalDueTodayWithoutTaxWithoutDiscount": 328.99,
                "totalDueMonthly": 133.83,
                "mobileNumber": "8133477604",
                "showGlobalChoiceOffer": false,
                "serviceInfo": {
                  "planDiscount": {
                    "planEligibleForAutoPayPaperLessDiscount": false,
                    "discountIncluded": false,
                    "totalPlanCostIncludingLineAccessFee": "0.0"
                  },
                  "serviceAddress": {
                    "addressLine1": "6013 PORTSDALE PL UNIT 201",
                    "addressLine2": "",
                    "zipCode": "33578",
                    "zipCode4": "4097",
                    "firstName": "DON",
                    "lastName": "WRIGHT",
                    "city": "RIVERVIEW",
                    "state": "FL"
                  },
                  "comparePlan": false,
                  "primaryUserInfo": {
                    "firstName": "DON",
                    "lastName": "WRIGHT",
                    "address": {
                      "firmName": "",
                      "apartmentNo": "201",
                      "type": "PL",
                      "streetNumber": "6013",
                      "streetName": "PORTSDALE",
                      "addressLine2": "",
                      "addressLine1": "6013 PORTSDALE PL UNIT 201",
                      "poBoxNo": "",
                      "ruralRouteNo": "",
                      "ruralDelNo": "",
                      "city": "RIVERVIEW",
                      "state": "FL",
                      "zipCode": "33578",
                      "zipCode4": "4097",
                      "county": "",
                      "countryCode": "US",
                      "fipsCode": "1205760950",
                      "firstName": "DON",
                      "lastName": "WRIGHT",
                      "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                      "phoneNumber": "9089349238",
                      "streetType": "PL",
                      "streetDirection": ""
                    },
                    "isValidAddress": true,
                    "bsnsName": "",
                    "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                    "midInitials": ""
                  },
                  "mtn": "8133477604",
                  "min": "8132580300",
                  "oldPricePlanId": "50430",
                  "contractTermId": "48",
                  "currentDevice": {
                    "oldLteVoraEquipInfo": {
                      "iccid": "89148000009826583322",
                      "lteVoraDeviceInfo": {
                        "deviceId": "352865677734782",
                        "deviceType": "5GE",
                        "deviceSku": "CLNRAPL13PM128SB",
                        "description": "IPHONE 13 PRO MAX 128 SR BLU",
                        "imageUrlMap": {
                          "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue",
                          "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-lg$",
                          "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-med$",
                          "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-mini$",
                          "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-thumb$"
                        },
                        "color": {},
                        "manufacturer": "Apple"
                      }
                    }
                  },
                  "isSharePlanAdded": false,
                  "mea": "V0T",
                  "isE911AddressValidated": false,
                  "oldPlanFlag": "L",
                  "orderDevice": {
                    "lteVoraEquipInfo": {
                      "lteEqpt": {},
                      "lteVoraDeviceInfo": {}
                    }
                  },
                  "kidsPlanParentMtn": false,
                  "mcsSubscription": [],
                  "fiveGUpSell": false,
                  "e911AddressSameAsServiceAddress": false,
                  "unpairedGrantor": false,
                  "totalAddedFeaturesPrice": "0.0"
                },
                "itemsInfo": [
                  {
                    "depletionType": "F",
                    "attention": "DON WRIGHT",
                    "shipping": {
                      "address": {
                        "firmName": "",
                        "apartmentNo": "201",
                        "type": "R",
                        "streetNumber": "6013",
                        "streetName": "PORTSDALE",
                        "addressLine2": "",
                        "addressLine1": "6013 PORTSDALE PL UNIT 201",
                        "poBoxNo": "",
                        "ruralDelNo": "",
                        "city": "RIVERVIEW",
                        "state": "FL",
                        "zipCode": "33578",
                        "zipCode4": "4097",
                        "county": "",
                        "countryCode": "",
                        "fipsCode": "1205760950",
                        "firstName": "DON",
                        "lastName": "WRIGHT",
                        "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                        "phoneNumber": "9089349238",
                        "streetType": "PL",
                        "streetDirection": ""
                      },
                      "bsnsName": "",
                      "shippingCode": "SHP002",
                      "shippingCost": "0.00",
                      "shippingDescription": "Free 2 Day by 8pm",
                      "cbrPhone": "9089349238",
                      "firstName": "DON",
                      "lastName": "WRIGHT",
                      "midInitials": "",
                      "isUseUnVerifiedAddress": false,
                      "isValidAddress": false,
                      "email": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                      "shipToCustomerAddress": false
                    },
                    "fipsCode": "1205760950",
                    "itemCount": 2,
                    "itemTabSeqNum": 0,
                    "cartItems": {
                      "cartItem": [
                        {
                          "discountAmount": 0.0,
                          "deviceDollarApplied": 0.0,
                          "promoHubOfferList": {
                            "promoHubOfferList": [],
                            "offerCount": 0
                          },
                          "qrScanNeededForEsimActivation": false,
                          "isPreconfigureDuringAddDevice": false,
                          "deviceDisplayName": "AirPods 4 with Active Noise Cancellation",
                          "accessoryGiftCardAmount": 0.0,
                          "tradeInAmountTowardsUserDPUsed": 0.0,
                          "sorDeviceCategory": "Bluetooth Headphones",
                          "vendingKioskItem": "false",
                          "tradeInAutoPull": false,
                          "priceAdjustment": false,
                          "priceAdjustmentQty": 0,
                          "newPurchasedQty": 1,
                          "canonicalUrl": "products/apple-airpods-4-with-active-noise-cancellation/",
                          "selectedForRFEX": false,
                          "selectedForPAD": false,
                          "bogoItem": false,
                          "refxItemSeqNum": 0,
                          "restrictedAccySku": false,
                          "maxAccyPurchaseLimit": false,
                          "giftCard": false,
                          "itemCode": "MXP93LL/A",
                          "totalPriceWithDiscount": 179.0,
                          "sorId": "MXP93LL/A",
                          "skuId": "sku6016076",
                          "cartItemType": "ACCESSORY",
                          "description": "AirPods 4 with Active Noise Cancellation",
                          "qty": 1,
                          "bundleSeqNum": 0,
                          "itemPrice": "179.00",
                          "discountedPercentage": 0.0,
                          "discountedPrice": 179.0,
                          "buyOutTaxAmountUnbilled": 0.0,
                          "buyOutAmountWithoutTax": 0.0,
                          "taxAmount": 13.42,
                          "imageUrlMap": {
                            "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset",
                            "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-lg$",
                            "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-med$",
                            "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-mini$",
                            "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-thumb$"
                          },
                          "prodCode1": "TAX",
                          "prodCode2": "SPC",
                          "prodCode3": "OEM",
                          "prodCode4": "000",
                          "prodCode5": "000",
                          "btaEligible": "true",
                          "depletionType": "F",
                          "catalogPrice": 179.0,
                          "instantCreditAmountUsed": 0.0,
                          "instantCreditAmountUsedForTaxes": 0.0,
                          "color": {
                            "color": "#F9F8F3",
                            "colorDisplayName": "WHITE"
                          },
                          "unitTaxBasedPrice": 179.0,
                          "itemNrpPrice": 179.0,
                          "discounts": [],
                          "availableReasonCode": [],
                          "inventory": {
                            "isAvailable": true,
                            "isBackorder": false,
                            "isDeliverBy": false,
                            "isPreOrder": false,
                            "qtyAvailable": 1426,
                            "isShipBy": false
                          },
                          "isCustomerProvidedSIM": false,
                          "isNetworkExtender": false,
                          "ispuEligible": true,
                          "itemSeqNum": 11,
                          "sddEligible": true,
                          "smartIMEI": false,
                          "year": 0,
                          "sellerPrice": "0.0",
                          "productId": "acc20893304",
                          "taxDetailsList": [
                            {
                              "taxSequenceNum": 1,
                              "taxPassType": "10",
                              "taxAmount": "10.74",
                              "taxDescription": "FL State Sales Tax",
                              "taxType": "01",
                              "mldSequenceNum": 1,
                              "taxSurcharge": "T"
                            },
                            {
                              "taxSequenceNum": 2,
                              "taxPassType": "20",
                              "taxAmount": "2.68",
                              "taxDescription": "Hillsborough Cnty Sales Tax",
                              "taxType": "02",
                              "mldSequenceNum": 2,
                              "taxSurcharge": "T"
                            }
                          ],
                          "manufacturer": "Apple",
                          "quantityOnHand": 1426,
                          "iconicPhone": false,
                          "ringBell": false,
                          "isPreconfigureEnabled": false,
                          "isHumDevice": false,
                          "isSmartLocator": false,
                          "isSecurityAlarm": false,
                          "isMotoMod": false,
                          "isConnectedCar": false,
                          "accountLevelAccessory": false,
                          "byodESimPhone": false,
                          "scannedItem": false,
                          "appleCareAccessoryFlag": false,
                          "quantityAllowed": true,
                          "isDfoSelected": false
                        },
                        {
                          "discountAmount": 0.0,
                          "deviceDollarApplied": 0.0,
                          "promoHubOfferList": {
                            "promoHubOfferList": [],
                            "offerCount": 0
                          },
                          "qrScanNeededForEsimActivation": false,
                          "isPreconfigureDuringAddDevice": false,
                          "deviceDisplayName": "Soundgear Sense Open-Ear Headphones - Black",
                          "accessoryGiftCardAmount": 0.0,
                          "tradeInAmountTowardsUserDPUsed": 0.0,
                          "sorDeviceCategory": "Bluetooth Headphones",
                          "vendingKioskItem": "false",
                          "tradeInAutoPull": false,
                          "priceAdjustment": false,
                          "priceAdjustmentQty": 0,
                          "newPurchasedQty": 1,
                          "canonicalUrl": "products/jbl-soundgear-sense-open-ear-headphones/",
                          "selectedForRFEX": false,
                          "selectedForPAD": false,
                          "bogoItem": false,
                          "refxItemSeqNum": 0,
                          "restrictedAccySku": false,
                          "maxAccyPurchaseLimit": false,
                          "giftCard": false,
                          "itemCode": "JBLSNDGEARSNSBLKAM",
                          "totalPriceWithDiscount": 149.99,
                          "sorId": "JBLSNDGEARSNSBLKAM",
                          "skuId": "sku6013494",
                          "cartItemType": "ACCESSORY",
                          "description": "Soundgear Sense Open-Ear Headphones - Black",
                          "qty": 1,
                          "bundleSeqNum": 0,
                          "itemPrice": "149.99",
                          "discountedPercentage": 0.0,
                          "discountedPrice": 149.99,
                          "buyOutTaxAmountUnbilled": 0.0,
                          "buyOutAmountWithoutTax": 0.0,
                          "taxAmount": 11.25,
                          "imageUrlMap": {
                            "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset",
                            "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-lg$",
                            "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-med$",
                            "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-mini$",
                            "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-thumb$"
                          },
                          "prodCode1": "TAX",
                          "prodCode2": "SPC",
                          "prodCode3": "OEM",
                          "prodCode4": "000",
                          "prodCode5": "000",
                          "btaEligible": "true",
                          "depletionType": "F",
                          "catalogPrice": 149.99,
                          "instantCreditAmountUsed": 0.0,
                          "instantCreditAmountUsedForTaxes": 0.0,
                          "color": {
                            "color": "#000000",
                            "colorDisplayName": "BLACK"
                          },
                          "unitTaxBasedPrice": 149.99,
                          "itemNrpPrice": 149.99,
                          "discounts": [],
                          "availableReasonCode": [],
                          "inventory": {
                            "isAvailable": true,
                            "isBackorder": false,
                            "isDeliverBy": false,
                            "isPreOrder": false,
                            "qtyAvailable": 1018,
                            "isShipBy": false
                          },
                          "isCustomerProvidedSIM": false,
                          "isNetworkExtender": false,
                          "ispuEligible": true,
                          "itemSeqNum": 12,
                          "sddEligible": true,
                          "smartIMEI": false,
                          "year": 0,
                          "sellerPrice": "0.0",
                          "productId": "acc20892292",
                          "taxDetailsList": [
                            {
                              "taxSequenceNum": 1,
                              "taxPassType": "10",
                              "taxAmount": "9.00",
                              "taxDescription": "FL State Sales Tax",
                              "taxType": "01",
                              "mldSequenceNum": 1,
                              "taxSurcharge": "T"
                            },
                            {
                              "taxSequenceNum": 2,
                              "taxPassType": "20",
                              "taxAmount": "2.25",
                              "taxDescription": "Hillsborough Cnty Sales Tax",
                              "taxType": "02",
                              "mldSequenceNum": 2,
                              "taxSurcharge": "T"
                            }
                          ],
                          "manufacturer": "JBL",
                          "quantityOnHand": 0,
                          "iconicPhone": false,
                          "ringBell": false,
                          "isPreconfigureEnabled": false,
                          "isHumDevice": false,
                          "isSmartLocator": false,
                          "isSecurityAlarm": false,
                          "isMotoMod": false,
                          "isConnectedCar": false,
                          "accountLevelAccessory": false,
                          "byodESimPhone": false,
                          "scannedItem": false,
                          "appleCareAccessoryFlag": false,
                          "quantityAllowed": true,
                          "isDfoSelected": false
                        },
                        {
                          "discountAmount": 0.0,
                          "deviceDollarApplied": 0.0,
                          "qrScanNeededForEsimActivation": false,
                          "isPreconfigureDuringAddDevice": false,
                          "accessoryGiftCardAmount": 0.0,
                          "tradeInAmountTowardsUserDPUsed": 0.0,
                          "vendingKioskItem": "false",
                          "tradeInAutoPull": false,
                          "priceAdjustment": false,
                          "priceAdjustmentQty": 0,
                          "newPurchasedQty": 0,
                          "selectedForRFEX": false,
                          "selectedForPAD": false,
                          "bogoItem": false,
                          "refxItemSeqNum": 0,
                          "restrictedAccySku": false,
                          "maxAccyPurchaseLimit": false,
                          "giftCard": false,
                          "itemCode": "SHP002",
                          "totalPriceWithDiscount": 0.0,
                          "sorId": "SHP002",
                          "cartItemType": "SHIPPING",
                          "mobileNumber": "8133477604",
                          "description": "Free 2 Day by 8pm",
                          "qty": 1,
                          "bundleSeqNum": 0,
                          "itemPrice": "0.0",
                          "discountedPercentage": 0.0,
                          "discountedPrice": 0.0,
                          "buyOutTaxAmountUnbilled": 0.0,
                          "buyOutAmountWithoutTax": 0.0,
                          "depletionType": "F",
                          "instantCreditAmountUsed": 0.0,
                          "instantCreditAmountUsedForTaxes": 0.0,
                          "itemCost": 0.0,
                          "discounts": [],
                          "availableReasonCode": [],
                          "isCustomerProvidedSIM": false,
                          "isNetworkExtender": false,
                          "ispuEligible": false,
                          "itemSeqNum": 0,
                          "sddEligible": false,
                          "smartIMEI": false,
                          "year": 0,
                          "sellerPrice": "0.0",
                          "taxDetailsList": [],
                          "iconicPhone": false,
                          "ringBell": false,
                          "isPreconfigureEnabled": false,
                          "isHumDevice": false,
                          "isSmartLocator": false,
                          "isSecurityAlarm": false,
                          "isMotoMod": false,
                          "isConnectedCar": false,
                          "accountLevelAccessory": false,
                          "byodESimPhone": false,
                          "appleCareAccessoryFlag": false,
                          "quantityAllowed": false,
                          "isDfoSelected": false
                        },
                        {
                          "discountAmount": 0.0,
                          "deviceDollarApplied": 0.0,
                          "promoHubOfferList": {
                            "promoHubOfferList": [],
                            "offerCount": 0
                          },
                          "qrScanNeededForEsimActivation": false,
                          "isPreconfigureDuringAddDevice": false,
                          "deviceDisplayName": "AirPods 4 with Active Noise Cancellation",
                          "accessoryGiftCardAmount": 0.0,
                          "tradeInAmountTowardsUserDPUsed": 0.0,
                          "sorDeviceCategory": "Bluetooth Headphones",
                          "vendingKioskItem": "false",
                          "tradeInAutoPull": false,
                          "priceAdjustment": false,
                          "priceAdjustmentQty": 0,
                          "newPurchasedQty": 1,
                          "canonicalUrl": "products/apple-airpods-4-with-active-noise-cancellation/",
                          "selectedForRFEX": false,
                          "selectedForPAD": false,
                          "bogoItem": false,
                          "refxItemSeqNum": 0,
                          "restrictedAccySku": false,
                          "maxAccyPurchaseLimit": false,
                          "giftCard": false,
                          "itemCode": "MXP93LL/A",
                          "totalPriceWithDiscount": 179.0,
                          "sorId": "MXP93LL/A",
                          "skuId": "sku6016076",
                          "cartItemType": "ACCESSORY",
                          "description": "AirPods 4 with Active Noise Cancellation",
                          "qty": 1,
                          "bundleSeqNum": 0,
                          "itemPrice": "179.00",
                          "discountedPercentage": 0.0,
                          "discountedPrice": 179.0,
                          "buyOutTaxAmountUnbilled": 0.0,
                          "buyOutAmountWithoutTax": 0.0,
                          "taxAmount": 13.42,
                          "imageUrlMap": {
                            "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset",
                            "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-lg$",
                            "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-med$",
                            "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-mini$",
                            "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-thumb$"
                          },
                          "prodCode1": "TAX",
                          "prodCode2": "SPC",
                          "prodCode3": "OEM",
                          "prodCode4": "000",
                          "prodCode5": "000",
                          "btaEligible": "true",
                          "depletionType": "F",
                          "catalogPrice": 179.0,
                          "instantCreditAmountUsed": 0.0,
                          "instantCreditAmountUsedForTaxes": 0.0,
                          "color": {
                            "color": "#F9F8F3",
                            "colorDisplayName": "WHITE"
                          },
                          "unitTaxBasedPrice": 179.0,
                          "itemNrpPrice": 179.0,
                          "discounts": [],
                          "availableReasonCode": [],
                          "inventory": {
                            "isAvailable": true,
                            "isBackorder": false,
                            "isDeliverBy": false,
                            "isPreOrder": false,
                            "qtyAvailable": 1426,
                            "isShipBy": false
                          },
                          "isCustomerProvidedSIM": false,
                          "isNetworkExtender": false,
                          "ispuEligible": true,
                          "itemSeqNum": 11,
                          "sddEligible": true,
                          "smartIMEI": false,
                          "year": 0,
                          "sellerPrice": "0.0",
                          "productId": "acc20893304",
                          "taxDetailsList": [
                            {
                              "taxSequenceNum": 1,
                              "taxPassType": "10",
                              "taxAmount": "10.74",
                              "taxDescription": "FL State Sales Tax",
                              "taxType": "01",
                              "mldSequenceNum": 1,
                              "taxSurcharge": "T"
                            },
                            {
                              "taxSequenceNum": 2,
                              "taxPassType": "20",
                              "taxAmount": "2.68",
                              "taxDescription": "Hillsborough Cnty Sales Tax",
                              "taxType": "02",
                              "mldSequenceNum": 2,
                              "taxSurcharge": "T"
                            }
                          ],
                          "manufacturer": "Apple",
                          "quantityOnHand": 1426,
                          "iconicPhone": false,
                          "ringBell": false,
                          "isPreconfigureEnabled": false,
                          "isHumDevice": false,
                          "isSmartLocator": false,
                          "isSecurityAlarm": false,
                          "isMotoMod": false,
                          "isConnectedCar": false,
                          "accountLevelAccessory": false,
                          "byodESimPhone": false,
                          "scannedItem": false,
                          "appleCareAccessoryFlag": false,
                          "quantityAllowed": true,
                          "isDfoSelected": false
                        }
                      ]
                    },
                    "isPromoSelected": false,
                    "isTradeInSelected": false,
                    "taxExemptionTypes": ""
                  }
                ],
                "mtnDetails": {
                  "lineNumber": "8133477604",
                  "mobileNumber": "8133477604"
                },
                "lineNumber": "8133477604",
                "fiveGToFourGDownGrade": false,
                "lineCreator": "8133477604",
                "amRole": "",
                "lineRefundTotal": 0.0,
                "lineExchangeTotal": 328.99,
                "totalDueMonthlyBeforeCredit": 0.0,
                "sugAllowed": false,
                "totalDueAddOnMonthly": 0.0,
                "totalPriceOfPlanAndPerks": "0.0",
                "isCpe": false,
                "isLTEHomeLine": false,
                "isDevicePlanCompatible": false,
                "portinMtnAssignment": false,
                "impactedLine": false,
                "preOrBackOrder": false,
                "ispuItem": false,
                "ispuItemBYOD": false,
                "isModConnected": false,
                "modDevice": false,
                "byodCapable": false,
                "isCarLine": false,
                "buySimOnly": false,
                "broadBandInd": false,
                "ispuDownPaymentAdjstRequired": false,
                "ispuDownPaymentAmount": 0.0,
                "lineWithSkipMDN": false,
                "protectionNotRequired": false
              }
          ],
          "numOfAccessoryAndDeviceItemsInCart": 6,
          "totalEdgeUpAmount": 0.0,
          "totalEdgeBuyOutAmount": 0.0,
          "tradeInDetail": {},
          "totalDownPaymentAmt": 0.0,
          "numOfLinesWithDevices": 2,
          "discountGainIndicators": [],
          "discountLossIndicators": [],
          "subscriptionInfos": [],
          "numofApprovedLines": 0,
          "rfexPayments": [],
          "numOfLines": 4,
          "numofLinesAAL": 2,
          "numofLinesEUP": 0,
          "payments": [],
          "lineSeq": 0,
          "vlcactivePhoneCount": 0,
          "fivegOrderind": true,
          "aceOrderCreated": true,
          "serviceLinesCreated": false,
          "aceItemsModified": true,
          "enableLineInfoFFlag": true,
          "clnrOrderFlag": false,
          "broadbandInd": false,
          "isAutoPayEnrolled": "N",
          "isAutoPayPaperLessDiscountEligible": "Y",
          "isPaperLessEnrolled": "Y",
          "totalEligibleAutoPayPaperLessDiscount": "25.00",
          "tabletJetpackDiscountMultiLineLoss": "N",
          "acctMcsSubscription": [],
          "spendingLimitAmountExceededBy": "0.0",
          "numofAccessories": 4,
          "subAccountNBSInfo": [
            {
              "billAccounts": [
                {
                  "billSummary": {
                    "grandTotal": {
                      "newMonthCharge": "325.80",
                      "nextMonthCharge": "517.99"
                    },
                    "planCharge": {
                      "newMonthCharge": "251.50",
                      "nextMonthCharge": "422.34"
                    },
                    "lineAccessFees": {
                      "newMonthCharge": "0.00",
                      "nextMonthCharge": "0.00"
                    },
                    "devicePayments": {
                      "newMonthCharge": "68.60",
                      "nextMonthCharge": "68.79"
                    },
                    "surcharges": {
                      "newMonthCharge": "12.92",
                      "nextMonthCharge": "21.26"
                    },
                    "taxesAndFees": {
                      "newMonthCharge": "5.83",
                      "nextMonthCharge": "12.14"
                    },
                    "totalAddOns": {
                      "newMonthCharge": "36.95",
                      "nextMonthCharge": "36.95"
                    },
                    "appleMusic": {
                      "newMonthCharge": "0.00",
                      "nextMonthCharge": "0.00"
                    },
                    "mobileProtection": {
                      "newMonthCharge": "26.95",
                      "nextMonthCharge": "26.95"
                    },
                    "planAccessFeeTotal": {
                      "newMonthCharge": "251.50",
                      "nextMonthCharge": "422.34"
                    },
                    "taxGrandTotal": {
                      "newMonthCharge": "18.75",
                      "nextMonthCharge": "33.40"
                    },
                    "subTotal": {
                      "newMonthCharge": "307.05",
                      "nextMonthCharge": "484.59"
                    },
                    "autoPayDiscount": {
                      "accountTotalAutoPayDiscount": "25.00",
                      "isCustomerEnrolledForAutopay": false,
                      "subTotalNewMonthwithAutoPayDisc": "282.05"
                    },
                    "dateRange": {
                      "thisMonth": "10/06/2024-11/05/2024",
                      "nextMonth": "11/06/2024-12/05/2024"
                    }
                  },
                  "nbs": {
                    "accountNumber": "0325654132-00001",
                    "nextBillCycleStartDate": "11/06/2024",
                    "balancePastDue": {
                      "pastDueAmount": "0.00",
                      "paymentsReceived": "0.00",
                      "previousBalance": "295.88",
                      "balanceType": "Current Balance",
                      "unbilledPayment": "-144.64",
                      "totUnpaidBalance": "151.24",
                      "paymentMessage": "You have paid a portion of your current bill. The remaining balance of $151.24 is due on 10/28/2024.",
                      "unbilledOCC": "0.00"
                    },
                    "monthlyChargesInfo": {
                      "accountLevelCharges": [
                        {
                          "thisMonthCharge": "-25.00",
                          "nextMonthCharge": "-25.00",
                          "chargeRefId": "1781",
                          "description": "LOYALTY $25 DISC 2-3 PHONES",
                          "itemType": [
                            {
                              "equipment": false,
                              "feature": false,
                              "naf": false,
                              "occ": false,
                              "plan": false,
                              "promo": false,
                              "accequipment": false,
                              "sfo": false,
                              "spo": false,
                              "addOn": false
                            }
                          ],
                          "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                          "listPrice": "-25.00",
                          "netPrice": "-25.00"
                        }
                      ],
                      "accountLevelTotal": {
                        "thisMonthCharge": "-25.00",
                        "nextMonthCharge": "-41.94",
                        "differenceBetweenThisMonthAndNextMonthCharge": "-16.94",
                        "totalOneTimeCharge": "-16.94",
                        "newMonthMrcWithNoAddOn": "-25.00",
                        "nextMonthMrcWithNoAddOn": "-25.00",
                        "nextMonthAcctLevelSurcharges": "0.00",
                        "newMonthAcctLevelSurcharges": "0.00",
                        "nextMonthAccountLevelTax": "0.00",
                        "newMonthAccountLevelTax": "0.00",
                        "chargeTotals": [
                          {
                            "itemRef": "SPO",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "-25.00",
                            "nextMonthCharge": "-25.00"
                          },
                          {
                            "itemRef": "Total Addons",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "0.00",
                            "nextMonthCharge": "0.00"
                          }
                        ]
                      },
                      "mtnLevelChargeDetails": [
                        {
                          "mtn": "8133477604",
                          "thisMonthCharge": "133.83",
                          "nextMonthCharge": "190.73",
                          "differenceBetweenThisMonthAndNextMonthCharge": "56.90",
                          "thisMonthSurcharges": "4.68",
                          "previousMonthCharge": "0.00",
                          "nextMonthSurcharges": "4.92",
                          "differenceBetweenThisMonthAndNextMonthSurcharges": "0.24",
                          "thisMonthTax": "2.08",
                          "nextMonthTax": "2.26",
                          "differenceBetweenThisMonthAndNextMonthTax": "0.18",
                          "chargeDetails": [
                            {
                              "thisMonthCharge": "84.00",
                              "nextMonthCharge": "84.00",
                              "chargeRefId": "50430",
                              "description": "5G PLAY MORE",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "84.00",
                              "netPrice": "84.00",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            },
                            {
                              "thisMonthCharge": "30.83",
                              "nextMonthCharge": "30.83",
                              "chargeRefId": "352396479769529",
                              "description": "Device Payment",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "30.83",
                              "netPrice": "30.83",
                              "loanNumber": "1587790945",
                              "nextInstallmentNumber": "25",
                              "totalInstallmentNumber": "36",
                              "outstandingLoanAmount": "339.13",
                              "loanAmount": "1110.00",
                              "loanCode": "A"
                            },
                            {
                              "thisMonthCharge": "19.00",
                              "nextMonthCharge": "19.00",
                              "chargeRefId": "88690",
                              "description": "VERIZON MOBILE PROTECT",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "19.00",
                              "netPrice": "19.00",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            }
                          ],
                          "oneTimeChargeDetails": [
                            {
                              "thisMonthCharge": "0.00",
                              "nextMonthCharge": "56.90",
                              "chargeRefId": "50430",
                              "description": "5G PLAY MORE",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "56.90",
                              "netPrice": "56.90",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            }
                          ],
                          "nickname": "DON WRIGHT",
                          "suppressAdvInd": "N",
                          "newMonthMtnMrcWithNoAddOn": "114.83",
                          "nextMonthMtnMrcWithNoAddOn": "114.83",
                          "newMonthGrandTotalWithTaxes": "140.59",
                          "nextMonthGrandTotalWithTaxes": "197.91",
                          "chargeTotals": [
                            {
                              "itemRef": "Equipment",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "30.83",
                              "nextMonthCharge": "30.83"
                            },
                            {
                              "itemRef": "Total Addons",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "19.00",
                              "nextMonthCharge": "19.00"
                            },
                            {
                              "itemRef": "PPLAN",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "84.00",
                              "nextMonthCharge": "84.00"
                            },
                            {
                              "itemRef": "Auto Pay",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "5.00",
                              "nextMonthCharge": "5.00"
                            }
                          ],
                          "mtnChangeInd": false
                        },
                        {
                          "mtn": "8137244660",
                          "thisMonthCharge": "55.00",
                          "nextMonthCharge": "92.25",
                          "differenceBetweenThisMonthAndNextMonthCharge": "37.25",
                          "thisMonthSurcharges": "0.00",
                          "previousMonthCharge": "0.00",
                          "nextMonthSurcharges": "0.00",
                          "differenceBetweenThisMonthAndNextMonthSurcharges": "0.00",
                          "thisMonthTax": "0.00",
                          "nextMonthTax": "0.00",
                          "differenceBetweenThisMonthAndNextMonthTax": "0.00",
                          "chargeDetails": [
                            {
                              "thisMonthCharge": "80.00",
                              "nextMonthCharge": "80.00",
                              "chargeRefId": "75561",
                              "description": "5G HOME PLUS",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "80.00",
                              "netPrice": "80.00",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            },
                            {
                              "thisMonthCharge": "-25.00",
                              "nextMonthCharge": "-25.00",
                              "chargeRefId": "2722",
                              "description": "MOBILE + HOME DISCOUNT",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "-25.00",
                              "netPrice": "-25.00",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            },
                            {
                              "thisMonthCharge": "10.00",
                              "nextMonthCharge": "10.00",
                              "chargeRefId": "3239",
                              "description": "WHOLE-HOME WI-FI",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "-10.00",
                              "listPrice": "10.00",
                              "netPrice": "0.00",
                              "promo1Id": "20996",
                              "promo1Desc": "WHOLE-HOME WI-FI DISCOUNT",
                              "promo1Discount": "-10.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            },
                            {
                              "thisMonthCharge": "10.00",
                              "nextMonthCharge": "10.00",
                              "chargeRefId": "2641",
                              "description": "DISNEY BUNDLE",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "-10.00",
                              "listPrice": "10.00",
                              "netPrice": "0.00",
                              "promo1Id": "21015",
                              "promo1Desc": "DISNEY BUNDLE PROMO",
                              "promo1Discount": "-10.00",
                              "promo1EndDate": "10/11/2025",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            }
                          ],
                          "oneTimeChargeDetails": [
                            {
                              "thisMonthCharge": "0.00",
                              "nextMonthCharge": "54.19",
                              "chargeRefId": "75561",
                              "description": "5G HOME PLUS",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "54.19",
                              "netPrice": "54.19",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            },
                            {
                              "thisMonthCharge": "0.00",
                              "nextMonthCharge": "-16.94",
                              "chargeRefId": "2722",
                              "description": "MOBILE + HOME DISCOUNT",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "-16.94",
                              "netPrice": "-16.94",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            },
                            {
                              "thisMonthCharge": "0.00",
                              "nextMonthCharge": "6.77",
                              "chargeRefId": "3239",
                              "description": "WHOLE-HOME WI-FI",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "-6.77",
                              "listPrice": "6.77",
                              "netPrice": "0.00",
                              "promo1Id": "20996",
                              "promo1Desc": "WHOLE-HOME WI-FI DISCOUNT",
                              "promo1Discount": "-6.77",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            }
                          ],
                          "nickname": "New line",
                          "suppressAdvInd": "N",
                          "newMonthMtnMrcWithNoAddOn": "55.00",
                          "nextMonthMtnMrcWithNoAddOn": "55.00",
                          "newMonthGrandTotalWithTaxes": "55.00",
                          "nextMonthGrandTotalWithTaxes": "92.25",
                          "chargeTotals": [
                            {
                              "itemRef": "SPO",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "-25.00",
                              "nextMonthCharge": "-25.00"
                            },
                            {
                              "itemRef": "Total Addons",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "0.00",
                              "nextMonthCharge": "0.00"
                            },
                            {
                              "itemRef": "PPLAN",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "80.00",
                              "nextMonthCharge": "80.00"
                            },
                            {
                              "itemRef": "Auto Pay",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "10.00",
                              "nextMonthCharge": "10.00"
                            }
                          ],
                          "mtnChangeInd": false
                        },
                        {
                          "mtn": "8137277652",
                          "thisMonthCharge": "121.00",
                          "nextMonthCharge": "215.77",
                          "differenceBetweenThisMonthAndNextMonthCharge": "94.77",
                          "thisMonthSurcharges": "4.32",
                          "previousMonthCharge": "0.00",
                          "nextMonthSurcharges": "12.38",
                          "differenceBetweenThisMonthAndNextMonthSurcharges": "8.06",
                          "thisMonthTax": "2.75",
                          "nextMonthTax": "8.83",
                          "differenceBetweenThisMonthAndNextMonthTax": "6.08",
                          "chargeDetails": [
                            {
                              "thisMonthCharge": "80.00",
                              "nextMonthCharge": "80.00",
                              "chargeRefId": "63217",
                              "description": "UNLIMITED PLUS",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "80.00",
                              "netPrice": "80.00",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            },
                            {
                              "thisMonthCharge": "23.05",
                              "nextMonthCharge": "23.24",
                              "description": "Device Payment",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.19",
                              "listPrice": "23.05",
                              "netPrice": "23.05",
                              "loanNumber": "0",
                              "nextInstallmentNumber": "1",
                              "totalInstallmentNumber": "36",
                              "outstandingLoanAmount": "806.75",
                              "loanAmount": "829.99",
                              "loanCode": "A"
                            },
                            {
                              "thisMonthCharge": "7.95",
                              "nextMonthCharge": "7.95",
                              "chargeRefId": "85913",
                              "description": "WIRELESS PHONE PROTECTION",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "7.95",
                              "netPrice": "7.95",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            },
                            {
                              "thisMonthCharge": "10.00",
                              "nextMonthCharge": "10.00",
                              "chargeRefId": "2641",
                              "description": "DISNEY BUNDLE",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "10.00",
                              "netPrice": "10.00",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            }
                          ],
                          "oneTimeChargeDetails": [
                            {
                              "thisMonthCharge": "0.00",
                              "nextMonthCharge": "54.19",
                              "chargeRefId": "63217",
                              "description": "UNLIMITED PLUS",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "54.19",
                              "netPrice": "54.19",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            },
                            {
                              "thisMonthCharge": "0.00",
                              "nextMonthCharge": "5.39",
                              "chargeRefId": "85913",
                              "description": "WIRELESS PHONE PROTECTION",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "5.39",
                              "netPrice": "5.39",
                              "promo1Id": "0",
                              "promo1Discount": "0.00",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            },
                            {
                              "thisMonthCharge": "0.00",
                              "nextMonthCharge": "35.00",
                              "chargeRefId": "3",
                              "description": "ACTIVATION FEE",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "listPrice": "0.0",
                              "netPrice": "0.0",
                              "recurringIndicator": "N",
                              "balanceDueIndicator": "N"
                            }
                          ],
                          "nickname": "New line",
                          "suppressAdvInd": "N",
                          "newMonthMtnMrcWithNoAddOn": "103.05",
                          "nextMonthMtnMrcWithNoAddOn": "103.24",
                          "newMonthGrandTotalWithTaxes": "128.07",
                          "nextMonthGrandTotalWithTaxes": "236.98",
                          "chargeTotals": [
                            {
                              "itemRef": "Equipment",
                              "differenceBetweenThisAndNextMonthCharge": "-0.19",
                              "thisMonthCharge": "23.05",
                              "nextMonthCharge": "23.05"
                            },
                            {
                              "itemRef": "Total Addons",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "17.95",
                              "nextMonthCharge": "17.95"
                            },
                            {
                              "itemRef": "PPLAN",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "80.00",
                              "nextMonthCharge": "80.00"
                            },
                            {
                              "itemRef": "OCC",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "0.00",
                              "nextMonthCharge": "0.00"
                            },
                            {
                              "itemRef": "Auto Pay",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "10.00",
                              "nextMonthCharge": "10.00"
                            }
                          ],
                          "mtnChangeInd": false
                        },
                        {
                          "mtn": "8138531515",
                          "thisMonthCharge": "22.22",
                          "nextMonthCharge": "27.78",
                          "differenceBetweenThisMonthAndNextMonthCharge": "5.56",
                          "thisMonthSurcharges": "3.92",
                          "previousMonthCharge": "0.00",
                          "nextMonthSurcharges": "3.96",
                          "differenceBetweenThisMonthAndNextMonthSurcharges": "0.04",
                          "thisMonthTax": "1.00",
                          "nextMonthTax": "1.05",
                          "differenceBetweenThisMonthAndNextMonthTax": "0.05",
                          "chargeDetails": [
                            {
                              "thisMonthCharge": "15.00",
                              "nextMonthCharge": "15.00",
                              "chargeRefId": "18056",
                              "description": "NUMBER SHARE",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "-7.50",
                              "listPrice": "15.00",
                              "netPrice": "7.50",
                              "promo1Id": "19979",
                              "promo1Desc": "50% ACCESS FEE DISCOUNT FROM 813.727.7652",
                              "promo1Discount": "-7.50",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            },
                            {
                              "thisMonthCharge": "14.72",
                              "nextMonthCharge": "14.72",
                              "chargeRefId": "358427486768156",
                              "description": "Device Payment",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                              "listPrice": "14.72",
                              "netPrice": "14.72",
                              "loanNumber": "1588437200",
                              "nextInstallmentNumber": "25",
                              "totalInstallmentNumber": "36",
                              "outstandingLoanAmount": "161.92",
                              "loanAmount": "529.99",
                              "loanCode": "A"
                            }
                          ],
                          "oneTimeChargeDetails": [
                            {
                              "thisMonthCharge": "0.00",
                              "nextMonthCharge": "11.13",
                              "chargeRefId": "18056",
                              "description": "NUMBER SHARE",
                              "itemType": [
                                {
                                  "equipment": false,
                                  "feature": false,
                                  "naf": false,
                                  "occ": false,
                                  "plan": false,
                                  "promo": false,
                                  "accequipment": false,
                                  "sfo": false,
                                  "spo": false,
                                  "addOn": false
                                }
                              ],
                              "differenceBetweenThisMonthAndNextMonthCharge": "-5.57",
                              "listPrice": "11.13",
                              "netPrice": "5.56",
                              "promo1Id": "19979",
                              "promo1Desc": "50% ACCESS FEE DISCOUNT FROM 813.727.7652",
                              "promo1Discount": "-5.57",
                              "promo2Id": "0",
                              "promo2Discount": "0.00",
                              "promo3Id": "0",
                              "promo3Discount": "0.00"
                            }
                          ],
                          "nickname": "DON WRIGHT",
                          "suppressAdvInd": "N",
                          "newMonthMtnMrcWithNoAddOn": "22.22",
                          "nextMonthMtnMrcWithNoAddOn": "22.22",
                          "newMonthGrandTotalWithTaxes": "27.14",
                          "nextMonthGrandTotalWithTaxes": "32.79",
                          "chargeTotals": [
                            {
                              "itemRef": "Equipment",
                              "differenceBetweenThisAndNextMonthCharge": "0.00",
                              "thisMonthCharge": "14.72",
                              "nextMonthCharge": "14.72"
                            },
                            {
                              "itemRef": "PPLAN",
                              "differenceBetweenThisAndNextMonthCharge": "-7.50",
                              "thisMonthCharge": "15.00",
                              "nextMonthCharge": "15.00"
                            }
                          ],
                          "mtnChangeInd": false
                        }
                      ],
                      "accountLevelOneTimeCharges": [
                        {
                          "thisMonthCharge": "0.00",
                          "nextMonthCharge": "-16.94",
                          "chargeRefId": "1781",
                          "description": "LOYALTY $25 DISC 2-3 PHONES",
                          "itemType": [
                            {
                              "equipment": false,
                              "feature": false,
                              "naf": false,
                              "occ": false,
                              "plan": false,
                              "promo": false,
                              "accequipment": false,
                              "sfo": false,
                              "spo": false,
                              "addOn": false
                            }
                          ],
                          "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                          "listPrice": "-16.94",
                          "netPrice": "-16.94"
                        }
                      ]
                    },
                    "monthlyTotalsInfo": {
                      "thisMonthCharge": "325.80",
                      "thisMonthChargeDateRange": "10/06/2024-11/05/2024",
                      "nextMonthCharge": "517.99",
                      "nextMonthChargeDateRange": "11/06/2024-12/05/2024",
                      "differenceBetweenThisMonthAndNextMonthCharge": "192.19",
                      "previousCycleFormattedDateRange": "Sep 06,2024 - Oct 05,2024"
                    },
                    "surchargesInfo": {
                      "thisMonthCharge": 12.92,
                      "nextMonthCharge": 21.26,
                      "differenceBetweenThisMonthAndNextMonthSurcharges": "8.34"
                    },
                    "taxesAndFeesInfo": {
                      "thisMonthCharge": 5.83,
                      "nextMonthCharge": 12.14,
                      "differenceBetweenThisMonthAndNextMonthTax": "6.31"
                    },
                    "autoPayDiscount": {
                      "accountTotalAutoPayDiscount": "25.00",
                      "isCustomerEnrolledForAutopay": false,
                      "subTotalNewMonthwithAutoPayDisc": "282.05"
                    },
                    "barGraphDetails": {
                      "invoiceCount": "3",
                      "invoiceLastMonth": "151.24",
                      "invoiceLastMonthCycleEnddate": "07/05/2024",
                      "invoiceTwoMonthPrevious": "144.64",
                      "invoiceTwoMonthCycleEnddate": "06/05/2024"
                    },
                    "nbsIndicators": {
                      "languageIndicator": "E",
                      "partialBillIndicator": "N"
                    },
                    "pendingChargesAndDiscounts": {
                      "mtnLevelPendingInfo": [],
                      "discountsPendingActionDetails": {
                        "apoPaperlessAmount": "-25.00",
                        "totalPendingDiscount": "-25.00",
                        "newMonthlyTotalWithPendingDiscounts": "300.80"
                      }
                    }
                  },
                  "billAccountNo": "1"
                }
              ]
            }
          ],
          "subAccountNbsDetails": [],
          "bagTax": false,
          "couponDetails": [{}]
        },
        "refundOrderDetails": {
          "orderNum": 0,
          "totalDueToday": "0.0",
          "subTotalDueToday": "0.0",
          "totalTaxAmount": "0.0",
          "creditApplicationNum": 0
        },
        "globalPromotions": {},
        "sfoLossReferenceDataList": [],
        "spoLossReferenceDataList": [],
        "verizonUpToastMessage": {
          "toastMessages": [],
          "eligibleProducts": []
        },
        "cartValidationErrors": [
          {
            "errorCategory": "Cart",
            "errorLevel": "Warning",
            "errorCode": "1011",
            "errorMessage": "Cart5GAppointment details are missing in Cart serviceInfo",
            "fieldPath": "8137244660"
          },
          {
            "errorCategory": "Cart",
            "errorLevel": "Warning",
            "errorCode": "1090",
            "errorMessage": "Shipping is Required",
            "fieldPath": ""
          },
          {
            "errorCategory": "Cart",
            "errorLevel": "Warning",
            "errorCode": "1016",
            "errorMessage": "Email Address is missing in shipping addresstype",
            "fieldPath": "8138531515"
          },
          {
            "errorCategory": "Cart",
            "errorLevel": "Warning",
            "errorCode": "1017",
            "errorMessage": "Phone Number is missing in shipping addresstype",
            "fieldPath": "8138531515"
          },
          {
            "errorCategory": "Cart",
            "errorLevel": "Warning",
            "errorCode": "1091",
            "errorMessage": "Payment is Required",
            "fieldPath": ""
          }
        ],
        "programEligibility": {
          "profileRemainingSpendingLimitAmount": 3407.85,
          "lineSpendingLimitAmount": 2000.0
        },
        "accountEligibility": false,
        "displayCartValidationErrors": true
      },
      "warningMessages": [],
      "basicORSmartPhoneExists": true,
      "fiveGDeviceORLTEHomeExists": false,
      "cartHasAccessories": true,
      "iscartHasVZHP": false,
      "isPortInLaterThrottled": true,
      "featureConfigurationProfileData": {
      },
      "featureFlags": {
        "rfexEligibilityForDfoFFlag": true
      },
      "orderPlaced": false,
      "validateCart": false,
      "redesignFlow": false,
      "validateAppointments": false,
      "newCustomer": false,
      "isLocalStoreOfferEnabled": false
    },
    "meta": {
      "timestamp": "1728901236632",
      "cxpCorrelationId": "2024-10-14T10:20:36.+0000:447ad94deaa89a69:cxp-shopping-services-585cdf5cdc-k7fjb:nssit2"
    }
}

export const bagTaxMockData = {
  "data": {
    "cart": {
      "customerProfile": {
        "billAccounts": [
          {
            "mtns": [
              {
                "mtn": "8138531515",
                "equipmentUpgradeEligibility": {
                  "upgradeEligibilityDate": "07/28/2025",
                  "upgradeEligible": true,
                  "twoYearContract": {}
                },
                "mobileInfoAttributes": {
                  "smartFamilyParent": false,
                  "accessRoles": {
                    "owner": false,
                    "manager": false,
                    "member": false
                  }
                },
                "equipmentInfos": [
                  {
                    "deviceInfo": {
                      "modelName": "Apple Watch Series 7 GPS + Cellular, 45mm Midnight Aluminum Case with Midnight Sport Band - Regular",
                      "deviceId": "358427486768156",
                      "deviceIdType": "IME",
                      "deviceSku": "MKJ73LL/A"
                    },
                    "simInfo": {
                      "modelName": "STM SOFT SIM",
                      "simId": "89148000008309669319",
                      "simSku": "SOFTSIM-CMR-S"
                    }
                  }
                ],
                "lineSharingIndicator": "R",
                "pricePlanInfo": {
                  "planId": "18056",
                  "planAttributes": {
                    "sharePlan": false
                  }
                },
                "currentSpo": [
                  {
                    "spoId": "732",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  }
                ]
              },
              {
                "mtn": "8133477604",
                "equipmentUpgradeEligibility": {
                  "upgradeEligibilityDate": "07/14/2025",
                  "upgradeEligible": true,
                  "twoYearContract": {}
                },
                "mobileInfoAttributes": {
                  "smartFamilyParent": false,
                  "accessRoles": {
                    "owner": false,
                    "manager": true,
                    "member": false
                  }
                },
                "equipmentInfos": [
                  {
                    "deviceInfo": {
                      "modelName": "IPHONE 13 PRO MAX 128 SR BLU",
                      "deviceId": "352865677734782",
                      "deviceIdType": "IME",
                      "deviceSku": "CLNRAPL13PM128SB"
                    },
                    "simInfo": {
                      "modelName": "SIM SKU 4G 5G",
                      "simId": "89148000009826583322",
                      "simSku": "BULKSIM5G-SA-A"
                    }
                  }
                ],
                "lineSharingIndicator": "L",
                "pricePlanInfo": {
                  "planId": "50430",
                  "planAttributes": {
                    "sharePlan": false
                  }
                },
                "currentSpo": [
                  {
                    "spoId": "384",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  },
                  {
                    "spoId": "732",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  },
                  {
                    "spoId": "1255",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  },
                  {
                    "spoId": "1535",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  },
                  {
                    "spoId": "1692",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  },
                  {
                    "spoId": "1801",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  },
                  {
                    "spoId": "2006",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  },
                  {
                    "spoId": "2107",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  },
                  {
                    "spoId": "2108",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  },
                  {
                    "spoId": "2176",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  },
                  {
                    "spoId": "2996",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  }
                ]
              }
            ],
            "fiosEligibilityCategory": "",
            "accountAddress": {
              "zipCode": "33569",
              "zipCodePlus4": "0000",
              "fipsCode": "1205760950",
              "addressLine1": "6013 PORTSDALE PL UNIT 201",
              "addressLine2": "",
              "city": "RIVERVIEW",
              "state": "FL",
              "scrubbedAddress": {
                "streetName": "PORTSDALE",
                "streetNumber": "6013",
                "streetType": "PL",
                "streetDirection": "",
                "apartmentNo": "201",
                "pobox": "",
                "ruralDeliveryNo": "",
                "ruralRouteNo": "",
                "city": "RIVERVIEW",
                "state": "FL",
                "country": "",
                "zipCode": "33578",
                "zipCodePlus4": "4097"
              }
            },
            "accountAttributes": {
              "autopay": {
                "autoPayDiscount": "5.00"
              }
            },
            "accountOffers": {
              "lineLevelOffers": {
                "productOffers": [
                  {
                    "spoId": "384",
                    "price": "0.00",
                    "description": "INTL TRAVEL VOICE & DATA PAYGO"
                  },
                  {
                    "spoId": "732",
                    "price": "0.00",
                    "description": "CDMA-LESS ROAM TIER OVERRIDE"
                  },
                  {
                    "spoId": "1255",
                    "price": "0.00",
                    "description": "TRAVELPASS"
                  },
                  {
                    "spoId": "1535",
                    "price": "0.00",
                    "description": "DIGITAL SECURE PROVISIONING"
                  },
                  {
                    "spoId": "1692",
                    "price": "0.00",
                    "description": "5G DYNAMIC SPECTRUM SHARING"
                  },
                  {
                    "spoId": "1801",
                    "price": "0.00",
                    "description": "UNLIMITED PLAN INDICATOR"
                  },
                  {
                    "spoId": "2006",
                    "price": "0.00",
                    "description": "CALL FILTER PLUS PROVISIONING"
                  },
                  {
                    "spoId": "2107",
                    "price": "0.00",
                    "description": "5G ULTRA WIDEBAND ACCESS"
                  },
                  {
                    "spoId": "2108",
                    "price": "0.00",
                    "description": "5G ULTRA WIDEBAND PROVISIONING"
                  },
                  {
                    "spoId": "2176",
                    "price": "0.00",
                    "description": "APPLE ARCADE INCL WITH PLAN"
                  },
                  {
                    "spoId": "2996",
                    "price": "0.00",
                    "description": "MOBILE HOTSPOT 5GB"
                  }
                ]
              }
            }
          }
        ],
        "customerAttributes": {
          "taxExemptCode": "N",
          "digitalCustomerType": "B2C"
        }
      },
      "cartHasOnlyAccessories": false,
      "cartHasConflicts": true,
      "conflictsAccepted": true,
      "flow": "NAO|AAL_5G|AAL|NAO",
      "cartHeader": {
        "winBackAccountNumber": "",
        "vendorId": "NETACE",
        "ani": 8133477604,
        "repRole": "POSSYSTST",
        "locationType": "S",
        "isVzPhEligible": true,
        "sourceSystem": "OMNI-RETAIL",
        "fullAccountNumber": "0325654132-1",
        "status": "A",
        "createTimestamp": "2024-10-14T05:30:54.69-04:00[US/Eastern]",
        "lastUpdateTimestamp": "2024-10-14T06:20:33.98-04:00[US/Eastern]",
        "cartCreator": "8133477604",
        "cartCreatorChannelId": "OMNI-RETAIL",
        "cartCreatorOrderLocationCode": "0026301",
        "cartCreatorSalesRepId": "ENC",
        "visionCustomerType": "PE",
        "maverickLocation": false,
        "preConfiguredCartType": "BAU",
        "preConfiguredCartTypeDuringAddDevice": "BAU",
        "isCoreRep": false,
        "isERTRep": false
      },
      "orderDetails": {
        "totalUpgradeFee": 0.0,
        "totalDeviceDollar": 0.0,
        "totalRemainingDeviceDollar": 0.0,
        "totalUsedDeviceDollar": 0.0,
        "totalAccountLevelAccCost": 0.0,
        "totalAccountLevelAccCostWithTax": 0.0,
        "totalShippingCost": 0.0,
        "totalDiscountedShippingCost": 0.0,
        "hqUser": false,
        "returnException": false,
        "verizonCardPromoOfferList": [],
        "verizonCardApplicationInfo": {},
        "taxDetailsList": [
          {
            "taxSequenceNum": 1,
            "taxPassType": "10",
            "taxAmount": "91.74",
            "taxDescription": "FL State Sales Tax",
            "taxType": "01",
            "mldSequenceNum": 1,
            "taxSurcharge": "T"
          },
          {
            "taxSequenceNum": 2,
            "taxPassType": "20",
            "taxAmount": "22.93",
            "taxDescription": "Hillsborough Cnty Sales Tax",
            "taxType": "02",
            "mldSequenceNum": 2,
            "taxSurcharge": "T"
          }
        ],
        "subTotalDueTodayWithoutUpgradeFee": 698.95,
        "subTotalDueMonthlyForAALBYODEUP": 121.0,
        "shipTogetherPref": true,
        "assistanceOptedByCustomer": false,
        "locationState": "NJ",
        "totalVerizonDollarUsed": "0.0",
        "isShellAccountSelected": false,
        "fullfillmentLocation": "1000001",
        "guestOrInactiveRefundLines": false,
        "totalDueMonthlyOnProfile": 0.0,
        "subTotalDueMonthlyOnProfile": 0.0,
        "totalMonthlyTaxesOnProfile": 0.0,
        "subTotalOtherLinesOnProfile": 0.0,
        "estimatedNextMonthChargeOnProfile": 0.0,
        "originalSubTotalDueMonthly": 423.3,
        "totalDueMonthlyAfterDiscounts": 307.05,
        "accessoryFinancingOfferInfo": {
          "installmentTerm": "12",
          "installmentInfo": {
            "monthlyInstallment": 0.0,
            "accessoryTotal": 751.37
          },
          "offerEligibleAmount": 100.0,
          "offerExpiryDate": "12/31/2025",
          "offerDisQualifiedAfterRemoveAcc": false,
          "dfoInstallmentInfo": {
            "monthlyInstallment": 0.0,
            "dfoDevicesTotal": 0.0,
            "installmentTerm": "36",
            "dfoTotalSalesTax": 0.0
          },
          "splitPaymentInfo": [
            {
              "orderNumber": "22004373",
              "nonAccessoryTotal": 62.25,
              "accessoryTotal": 751.37,
              "totalFinanceAmount": 0.0,
              "monthlyFinanceAmount": 0.0,
              "isAfo": true,
              "isDfo": false
            }
          ],
          "offerAvailable": true,
          "customerEligible": true,
          "offerAccepted": false,
          "disclosureAgreementSent": false
        },
        "totalTaxAdjustmentAmount": 0.0,
        "totalActivationFees": 0.0,
        "fiveGHomeOrder": false,
        "totalRefundAmount": 0.0,
        "totalExchangeAmount": 0.0,
        "totalRefundTaxAmount": 0.0,
        "totalExchangeTaxAmount": 0.0,
        "digitalExchange": false,
        "remainingAmountAfterAffirmApplied": 0.0,
        "cashOptionEnabled": false,
        "affirmCreditCheckFailed": false,
        "payTodayWithoutDfo": 813.62,
        "orderType": "PS",
        "locationCode": "0026301",
        "customerType": "U",
        "billingSystem": "VE",
        "totalTaxAmount": "114.67",
        "chargeSummary": [
          {
            "chargeType": "ActivationFee",
            "amount": 35.0,
            "finalPrice": 35.0
          }
        ],
        "spocs": {
          "notificationOptions": {
            "contactPhoneNumber": "9703050307",
            "primaryEmailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM"
          }
        },
        "totalDueToday": 813.62,
        "runningTotalDueToday": 813.62,
        "totalDueTodayFlag": false,
        "totalDueMonthly": 325.8,
        "subTotalDueMonthly": 307.05,
        "subTotalDueToday": 698.95,
        "subTotalMonthlyTaxes": 0.0,
        "estimatedNextMonthCharge": 517.99,
        "totalMonthlyTaxes": 18.75,
        "subTotalOtherLines": 133.83,
        "subTotalOtherLinesTaxes": 0.0,
        "instantDRCCredit": false,
        "isAttachmentCompleted": false,
        "nextMonthBillTotal": 0.0,
        "customerNotification": {
          "smsLanguage": "E"
        },
        "effectiveDateDetails": {
          "suggestedBackDate": "",
          "suggestedFutureDate": "",
          "currentBillCycleBeginDate": "10/06/2024",
          "nextBillCycleBeginDate": "11/06/2024",
          "onDemandDate": "10/14/2024",
          "onDemandRangeInDays": "45",
          "selectedDate": "10/14/2024",
          "onDemandAllowed": true,
          "backDateAllowed": false,
          "futureDateAllowed": false
        },
        "orderChannelId": "OMNI-RETAIL",
        "orderList": [
          {
            "creditApplication": {
              "creditApplicationNum": 414220049,
              "creditApprovalStatus": "AP",
              "creditStatusReason": "CA Customer Systematic Approval",
              "internationalEligibility": true,
              "securityDepositAmount": "0",
              "serviceClass": "B",
              "lineCreditClass": "1D",
              "creditAppEdited": false
            },
            "orderActivityType": "EUP",
            "orderNumber": 0,
            "numOfLinesForOrderActivityType": 0,
            "preOrderNumber": 0,
            "digitalOrderId": 0,
            "managerApprovalRequired": false
          },
          {
            "orderActivityType": "ACC",
            "orderNumber": 22004358,
            "numOfLinesForOrderActivityType": 0,
            "preOrderNumber": 0,
            "digitalOrderId": 994734874731161,
            "managerApprovalRequired": false
          },
          {
            "creditApplication": {
              "creditApplicationNum": 411220050,
              "creditApprovalStatus": "AP",
              "creditStatusReason": "CA Customer Systematic Approval",
              "internationalEligibility": false,
              "creditAdvisory": "APP 411220050 APPROVED  - WITH NO DEPOSIT REQUIRED 'B '",
              "securityDepositAmount": "0",
              "serviceClass": "B",
              "lineCreditClass": "1D",
              "creditAppEdited": false
            },
            "orderActivityType": "AAL_5G",
            "orderNumber": 22004369,
            "numOfLinesForOrderActivityType": 1,
            "preOrderNumber": 0,
            "digitalOrderId": 0,
            "managerApprovalRequired": false
          },
          {
            "creditApplication": {
              "creditApplicationNum": 410220052,
              "creditApprovalStatus": "AP",
              "creditStatusReason": "CA Customer Systematic Approval",
              "internationalEligibility": false,
              "creditAdvisory": "APP 410220052 APPROVED  - WITH NO DEPOSIT REQUIRED 'B '",
              "securityDepositAmount": "0",
              "serviceClass": "B",
              "lineCreditClass": "1D",
              "creditAppEdited": false
            },
            "orderActivityType": "AAL",
            "orderNumber": 22004373,
            "numOfLinesForOrderActivityType": 2,
            "preOrderNumber": 0,
            "digitalOrderId": 0,
            "managerApprovalRequired": false
          }
        ],
        "outletId": "000000263",
        "registerNumber": "51",
        "saleType": "P",
        "salesRepId": "ENC",
        "enableSplitShipment": false,
        "splitShipmentIndicator": false,
        "cartReadyForCheckout": true,
        "isSingleModConnectedDevice": false,
        "fiveGUpSellAccountLevel": false,
        "customerOnTrialPlan": false,
        "availableSlotsForGrantee": "0",
        "totalDownPaymentAmt": 0.0,
        "totalEdgeBuyOutAmount": 0.0,
        "expressCheckout": false,
        "nbxInfo": {
          "isPreQualifiedNBX": true,
          "syfOfferId": "8806908917",
          "propositionMessage": "Thank You! You have been Pre-Approved.Sign up and receive: $100 sign up bonus and more",
          "propositionName": "Pre-Qualified - Transaction Flow",
          "propositionId": "GC_01",
          "vzccFeedbackStatus": "DECLINED",
          "isVZCCHolder": false,
          "sessionId": "6558661564718555627",
          "soiEngagementId": "501002526",
          "isPreScreenRepresentment": "N"
        },
        "isEQPandPPLOfferApplied": false,
        "cartTotalDiscounts": {
          "totalDiscount": "0.0",
          "barCodeOfferAppliedOnOrder": false,
          "discountDetails": []
        },
        "memberTotalDueToday": 0.0,
        "customerConsent": "Y",
        "totalDwosCost": "0.0",
        "billingState": "FL",
        "isTradeInOfferSelected": false,
        "isAssignMtnRequired": false,
        "fiosCapable": false,
        "fiosEligible": false,
        "quoteWithoutCredit": false,
        "uswinAuthenticationRequired": true,
        "newPreToPostInfo": {
          "newPreToPostIndicator": "E",
          "newPreToPostMtns": {
            "accountOwner": "",
            "accountMembers": []
          }
        },
        "totalDueTodayWithoutDiscount": 813.62,
        "subTotalDueTodayWithoutDiscount": 698.95,
        "isComboOrder": "Y",
        "totalPerksSavings": "0.0"
      },
      "lineDetails": {
        "lineInfo": [
          {
            "isCommonPDP": false,
            "isTradeInIntentSelected": false,
            "multiLineSeqNumber": 3,
            "lineActivityType": "ACC",
            "totalDueToday": 353.66,
            "totalDueTodayWithoutTax": 328.99,
            "totalDueTodayWithoutTaxWithoutDiscount": 328.99,
            "totalDueMonthly": 133.83,
            "mobileNumber": "8133477604",
            "showGlobalChoiceOffer": false,
            "serviceInfo": {
              "planDiscount": {
                "planEligibleForAutoPayPaperLessDiscount": false,
                "discountIncluded": false,
                "totalPlanCostIncludingLineAccessFee": "0.0"
              },
              "serviceAddress": {
                "addressLine1": "6013 PORTSDALE PL UNIT 201",
                "addressLine2": "",
                "zipCode": "33578",
                "zipCode4": "4097",
                "firstName": "DON",
                "lastName": "WRIGHT",
                "city": "RIVERVIEW",
                "state": "FL"
              },
              "comparePlan": false,
              "primaryUserInfo": {
                "firstName": "DON",
                "lastName": "WRIGHT",
                "address": {
                  "firmName": "",
                  "apartmentNo": "201",
                  "type": "PL",
                  "streetNumber": "6013",
                  "streetName": "PORTSDALE",
                  "addressLine2": "",
                  "addressLine1": "6013 PORTSDALE PL UNIT 201",
                  "poBoxNo": "",
                  "ruralRouteNo": "",
                  "ruralDelNo": "",
                  "city": "RIVERVIEW",
                  "state": "FL",
                  "zipCode": "33578",
                  "zipCode4": "4097",
                  "county": "",
                  "countryCode": "US",
                  "fipsCode": "1205760950",
                  "firstName": "DON",
                  "lastName": "WRIGHT",
                  "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                  "phoneNumber": "9089349238",
                  "streetType": "PL",
                  "streetDirection": ""
                },
                "isValidAddress": true,
                "bsnsName": "",
                "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                "midInitials": ""
              },
              "mtn": "8133477604",
              "min": "8132580300",
              "oldPricePlanId": "50430",
              "contractTermId": "48",
              "currentDevice": {
                "oldLteVoraEquipInfo": {
                  "iccid": "89148000009826583322",
                  "lteVoraDeviceInfo": {
                    "deviceId": "352865677734782",
                    "deviceType": "5GE",
                    "deviceSku": "CLNRAPL13PM128SB",
                    "description": "IPHONE 13 PRO MAX 128 SR BLU",
                    "imageUrlMap": {
                      "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue",
                      "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-lg$",
                      "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-med$",
                      "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-mini$",
                      "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-thumb$"
                    },
                    "color": {},
                    "manufacturer": "Apple"
                  }
                }
              },
              "isSharePlanAdded": false,
              "mea": "V0T",
              "isE911AddressValidated": false,
              "oldPlanFlag": "L",
              "orderDevice": {
                "lteVoraEquipInfo": {
                  "lteEqpt": {},
                  "lteVoraDeviceInfo": {}
                }
              },
              "kidsPlanParentMtn": false,
              "mcsSubscription": [],
              "fiveGUpSell": false,
              "e911AddressSameAsServiceAddress": false,
              "unpairedGrantor": false,
              "totalAddedFeaturesPrice": "0.0"
            },
            "itemsInfo": [
              {
                "depletionType": "F",
                "attention": "DON WRIGHT",
                "shipping": {
                  "address": {
                    "firmName": "",
                    "apartmentNo": "201",
                    "type": "R",
                    "streetNumber": "6013",
                    "streetName": "PORTSDALE",
                    "addressLine2": "",
                    "addressLine1": "6013 PORTSDALE PL UNIT 201",
                    "poBoxNo": "",
                    "ruralDelNo": "",
                    "city": "RIVERVIEW",
                    "state": "FL",
                    "zipCode": "33578",
                    "zipCode4": "4097",
                    "county": "",
                    "countryCode": "",
                    "fipsCode": "1205760950",
                    "firstName": "DON",
                    "lastName": "WRIGHT",
                    "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                    "phoneNumber": "9089349238",
                    "streetType": "PL",
                    "streetDirection": ""
                  },
                  "bsnsName": "",
                  "shippingCode": "SHP002",
                  "shippingCost": "0.00",
                  "shippingDescription": "Free 2 Day by 8pm",
                  "cbrPhone": "9089349238",
                  "firstName": "DON",
                  "lastName": "WRIGHT",
                  "midInitials": "",
                  "isUseUnVerifiedAddress": false,
                  "isValidAddress": false,
                  "email": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                  "shipToCustomerAddress": false
                },
                "fipsCode": "1205760950",
                "itemCount": 2,
                "itemTabSeqNum": 0,
                "cartItems": {
                  "cartItem": [
                    {
                      "discountAmount": 0.0,
                      "deviceDollarApplied": 0.0,
                      "promoHubOfferList": {
                        "promoHubOfferList": [],
                        "offerCount": 0
                      },
                      "qrScanNeededForEsimActivation": false,
                      "isPreconfigureDuringAddDevice": false,
                      "deviceDisplayName": "AirPods 4 with Active Noise Cancellation",
                      "accessoryGiftCardAmount": 0.0,
                      "tradeInAmountTowardsUserDPUsed": 0.0,
                      "sorDeviceCategory": "Bluetooth Headphones",
                      "vendingKioskItem": "false",
                      "tradeInAutoPull": false,
                      "priceAdjustment": false,
                      "priceAdjustmentQty": 0,
                      "newPurchasedQty": 1,
                      "canonicalUrl": "products/apple-airpods-4-with-active-noise-cancellation/",
                      "selectedForRFEX": false,
                      "selectedForPAD": false,
                      "bogoItem": false,
                      "refxItemSeqNum": 0,
                      "restrictedAccySku": false,
                      "maxAccyPurchaseLimit": false,
                      "giftCard": false,
                      "itemCode": "MXP93LL/A",
                      "totalPriceWithDiscount": 179.0,
                      "sorId": "MXP93LL/A",
                      "skuId": "sku6016076",
                      "cartItemType": "SOFT_SKU",
                      "description": "AirPods 4 with Active Noise Cancellation",
                      "qty": 1,
                      "bundleSeqNum": 0,
                      "itemPrice": "179.00",
                      "discountedPercentage": 0.0,
                      "discountedPrice": 179.0,
                      "buyOutTaxAmountUnbilled": 0.0,
                      "buyOutAmountWithoutTax": 0.0,
                      "taxAmount": 13.42,
                      "imageUrlMap": {
                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset",
                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-lg$",
                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-med$",
                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-mini$",
                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-thumb$"
                      },
                      "prodCode1": "TAX",
                      "prodCode2": "BAG",
                      "prodCode3": "OEM",
                      "prodCode4": "000",
                      "prodCode5": "000",
                      "btaEligible": "true",
                      "depletionType": "F",
                      "catalogPrice": 179.0,
                      "instantCreditAmountUsed": 0.0,
                      "instantCreditAmountUsedForTaxes": 0.0,
                      "color": {
                        "color": "#F9F8F3",
                        "colorDisplayName": "WHITE"
                      },
                      "unitTaxBasedPrice": 179.0,
                      "itemNrpPrice": 179.0,
                      "discounts": [],
                      "availableReasonCode": [],
                      "inventory": {
                        "isAvailable": true,
                        "isBackorder": false,
                        "isDeliverBy": false,
                        "isPreOrder": false,
                        "qtyAvailable": 1426,
                        "isShipBy": false
                      },
                      "isCustomerProvidedSIM": false,
                      "isNetworkExtender": false,
                      "ispuEligible": true,
                      "itemSeqNum": 11,
                      "sddEligible": true,
                      "smartIMEI": false,
                      "year": 0,
                      "sellerPrice": "0.0",
                      "productId": "acc20893304",
                      "taxDetailsList": [
                        {
                          "taxSequenceNum": 1,
                          "taxPassType": "10",
                          "taxAmount": "10.74",
                          "taxDescription": "FL State Sales Tax",
                          "taxType": "01",
                          "mldSequenceNum": 1,
                          "taxSurcharge": "T"
                        },
                        {
                          "taxSequenceNum": 2,
                          "taxPassType": "20",
                          "taxAmount": "2.68",
                          "taxDescription": "Hillsborough Cnty Sales Tax",
                          "taxType": "02",
                          "mldSequenceNum": 2,
                          "taxSurcharge": "T"
                        }
                      ],
                      "manufacturer": "Apple",
                      "quantityOnHand": 1426,
                      "iconicPhone": false,
                      "ringBell": false,
                      "isPreconfigureEnabled": false,
                      "isHumDevice": false,
                      "isSmartLocator": false,
                      "isSecurityAlarm": false,
                      "isMotoMod": false,
                      "isConnectedCar": false,
                      "accountLevelAccessory": false,
                      "byodESimPhone": false,
                      "scannedItem": false,
                      "appleCareAccessoryFlag": false,
                      "quantityAllowed": true,
                      "isDfoSelected": false
                    },
                    {
                      "discountAmount": 0.0,
                      "deviceDollarApplied": 0.0,
                      "promoHubOfferList": {
                        "promoHubOfferList": [],
                        "offerCount": 0
                      },
                      "qrScanNeededForEsimActivation": false,
                      "isPreconfigureDuringAddDevice": false,
                      "deviceDisplayName": "Soundgear Sense Open-Ear Headphones - Black",
                      "accessoryGiftCardAmount": 0.0,
                      "tradeInAmountTowardsUserDPUsed": 0.0,
                      "sorDeviceCategory": "Bluetooth Headphones",
                      "vendingKioskItem": "false",
                      "tradeInAutoPull": false,
                      "priceAdjustment": false,
                      "priceAdjustmentQty": 0,
                      "newPurchasedQty": 1,
                      "canonicalUrl": "products/jbl-soundgear-sense-open-ear-headphones/",
                      "selectedForRFEX": false,
                      "selectedForPAD": false,
                      "bogoItem": false,
                      "refxItemSeqNum": 0,
                      "restrictedAccySku": false,
                      "maxAccyPurchaseLimit": false,
                      "giftCard": false,
                      "itemCode": "JBLSNDGEARSNSBLKAM",
                      "totalPriceWithDiscount": 149.99,
                      "sorId": "JBLSNDGEARSNSBLKAM",
                      "skuId": "sku6013494",
                      "cartItemType": "SOFT_SKU",
                      "description": "Soundgear Sense Open-Ear Headphones - Black",
                      "qty": 1,
                      "bundleSeqNum": 0,
                      "itemPrice": "149.99",
                      "discountedPercentage": 0.0,
                      "discountedPrice": 149.99,
                      "buyOutTaxAmountUnbilled": 0.0,
                      "buyOutAmountWithoutTax": 0.0,
                      "taxAmount": 11.25,
                      "imageUrlMap": {
                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset",
                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-lg$",
                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-med$",
                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-mini$",
                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-thumb$"
                      },
                      "prodCode1": "TAX",
                      "prodCode2": "SPC",
                      "prodCode3": "OEM",
                      "prodCode4": "000",
                      "prodCode5": "000",
                      "btaEligible": "true",
                      "depletionType": "F",
                      "catalogPrice": 149.99,
                      "instantCreditAmountUsed": 0.0,
                      "instantCreditAmountUsedForTaxes": 0.0,
                      "color": {
                        "color": "#000000",
                        "colorDisplayName": "BLACK"
                      },
                      "unitTaxBasedPrice": 149.99,
                      "itemNrpPrice": 149.99,
                      "discounts": [],
                      "availableReasonCode": [],
                      "inventory": {
                        "isAvailable": true,
                        "isBackorder": false,
                        "isDeliverBy": false,
                        "isPreOrder": false,
                        "qtyAvailable": 1018,
                        "isShipBy": false
                      },
                      "isCustomerProvidedSIM": false,
                      "isNetworkExtender": false,
                      "ispuEligible": true,
                      "itemSeqNum": 12,
                      "sddEligible": true,
                      "smartIMEI": false,
                      "year": 0,
                      "sellerPrice": "0.0",
                      "productId": "acc20892292",
                      "taxDetailsList": [
                        {
                          "taxSequenceNum": 1,
                          "taxPassType": "10",
                          "taxAmount": "9.00",
                          "taxDescription": "FL State Sales Tax",
                          "taxType": "01",
                          "mldSequenceNum": 1,
                          "taxSurcharge": "T"
                        },
                        {
                          "taxSequenceNum": 2,
                          "taxPassType": "20",
                          "taxAmount": "2.25",
                          "taxDescription": "Hillsborough Cnty Sales Tax",
                          "taxType": "02",
                          "mldSequenceNum": 2,
                          "taxSurcharge": "T"
                        }
                      ],
                      "manufacturer": "JBL",
                      "quantityOnHand": 0,
                      "iconicPhone": false,
                      "ringBell": false,
                      "isPreconfigureEnabled": false,
                      "isHumDevice": false,
                      "isSmartLocator": false,
                      "isSecurityAlarm": false,
                      "isMotoMod": false,
                      "isConnectedCar": false,
                      "accountLevelAccessory": false,
                      "byodESimPhone": false,
                      "scannedItem": false,
                      "appleCareAccessoryFlag": false,
                      "quantityAllowed": true,
                      "isDfoSelected": false
                    },
                    {
                      "discountAmount": 0.0,
                      "deviceDollarApplied": 0.0,
                      "qrScanNeededForEsimActivation": false,
                      "isPreconfigureDuringAddDevice": false,
                      "accessoryGiftCardAmount": 0.0,
                      "tradeInAmountTowardsUserDPUsed": 0.0,
                      "vendingKioskItem": "false",
                      "tradeInAutoPull": false,
                      "priceAdjustment": false,
                      "priceAdjustmentQty": 0,
                      "newPurchasedQty": 0,
                      "selectedForRFEX": false,
                      "selectedForPAD": false,
                      "bogoItem": false,
                      "refxItemSeqNum": 0,
                      "restrictedAccySku": false,
                      "maxAccyPurchaseLimit": false,
                      "giftCard": false,
                      "itemCode": "SHP002",
                      "totalPriceWithDiscount": 0.0,
                      "sorId": "SHP002",
                      "cartItemType": "SHIPPING",
                      "mobileNumber": "8133477604",
                      "description": "Free 2 Day by 8pm",
                      "qty": 1,
                      "bundleSeqNum": 0,
                      "itemPrice": "0.0",
                      "discountedPercentage": 0.0,
                      "discountedPrice": 0.0,
                      "buyOutTaxAmountUnbilled": 0.0,
                      "buyOutAmountWithoutTax": 0.0,
                      "depletionType": "F",
                      "instantCreditAmountUsed": 0.0,
                      "instantCreditAmountUsedForTaxes": 0.0,
                      "itemCost": 0.0,
                      "discounts": [],
                      "availableReasonCode": [],
                      "isCustomerProvidedSIM": false,
                      "isNetworkExtender": false,
                      "ispuEligible": false,
                      "itemSeqNum": 0,
                      "sddEligible": false,
                      "smartIMEI": false,
                      "year": 0,
                      "sellerPrice": "0.0",
                      "taxDetailsList": [],
                      "iconicPhone": false,
                      "ringBell": false,
                      "isPreconfigureEnabled": false,
                      "isHumDevice": false,
                      "isSmartLocator": false,
                      "isSecurityAlarm": false,
                      "isMotoMod": false,
                      "isConnectedCar": false,
                      "accountLevelAccessory": false,
                      "byodESimPhone": false,
                      "appleCareAccessoryFlag": false,
                      "quantityAllowed": false,
                      "isDfoSelected": false
                    },
                    {
                      "discountAmount": 0.0,
                      "deviceDollarApplied": 0.0,
                      "promoHubOfferList": {
                        "promoHubOfferList": [],
                        "offerCount": 0
                      },
                      "qrScanNeededForEsimActivation": false,
                      "isPreconfigureDuringAddDevice": false,
                      "deviceDisplayName": "AirPods 4 with Active Noise Cancellation",
                      "accessoryGiftCardAmount": 0.0,
                      "tradeInAmountTowardsUserDPUsed": 0.0,
                      "sorDeviceCategory": "Bluetooth Headphones",
                      "vendingKioskItem": "false",
                      "tradeInAutoPull": false,
                      "priceAdjustment": false,
                      "priceAdjustmentQty": 0,
                      "newPurchasedQty": 1,
                      "canonicalUrl": "products/apple-airpods-4-with-active-noise-cancellation/",
                      "selectedForRFEX": false,
                      "selectedForPAD": false,
                      "bogoItem": false,
                      "refxItemSeqNum": 0,
                      "restrictedAccySku": false,
                      "maxAccyPurchaseLimit": false,
                      "giftCard": false,
                      "itemCode": "MXP93LL/A",
                      "totalPriceWithDiscount": 179.0,
                      "sorId": "MXP93LL/A",
                      "skuId": "sku6016076",
                      "cartItemType": "ACCESSORY",
                      "description": "AirPods 4 with Active Noise Cancellation",
                      "qty": 1,
                      "bundleSeqNum": 0,
                      "itemPrice": "179.00",
                      "discountedPercentage": 0.0,
                      "discountedPrice": 179.0,
                      "buyOutTaxAmountUnbilled": 0.0,
                      "buyOutAmountWithoutTax": 0.0,
                      "taxAmount": 13.42,
                      "imageUrlMap": {
                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset",
                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-lg$",
                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-med$",
                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-mini$",
                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-thumb$"
                      },
                      "prodCode1": "TAX",
                      "prodCode2": "SPC",
                      "prodCode3": "OEM",
                      "prodCode4": "000",
                      "prodCode5": "000",
                      "btaEligible": "true",
                      "depletionType": "F",
                      "catalogPrice": 179.0,
                      "instantCreditAmountUsed": 0.0,
                      "instantCreditAmountUsedForTaxes": 0.0,
                      "color": {
                        "color": "#F9F8F3",
                        "colorDisplayName": "WHITE"
                      },
                      "unitTaxBasedPrice": 179.0,
                      "itemNrpPrice": 179.0,
                      "discounts": [],
                      "availableReasonCode": [],
                      "inventory": {
                        "isAvailable": true,
                        "isBackorder": false,
                        "isDeliverBy": false,
                        "isPreOrder": false,
                        "qtyAvailable": 1426,
                        "isShipBy": false
                      },
                      "isCustomerProvidedSIM": false,
                      "isNetworkExtender": false,
                      "ispuEligible": true,
                      "itemSeqNum": 11,
                      "sddEligible": true,
                      "smartIMEI": false,
                      "year": 0,
                      "sellerPrice": "0.0",
                      "productId": "acc20893304",
                      "taxDetailsList": [
                        {
                          "taxSequenceNum": 1,
                          "taxPassType": "10",
                          "taxAmount": "10.74",
                          "taxDescription": "FL State Sales Tax",
                          "taxType": "01",
                          "mldSequenceNum": 1,
                          "taxSurcharge": "T"
                        },
                        {
                          "taxSequenceNum": 2,
                          "taxPassType": "20",
                          "taxAmount": "2.68",
                          "taxDescription": "Hillsborough Cnty Sales Tax",
                          "taxType": "02",
                          "mldSequenceNum": 2,
                          "taxSurcharge": "T"
                        }
                      ],
                      "manufacturer": "Apple",
                      "quantityOnHand": 1426,
                      "iconicPhone": false,
                      "ringBell": false,
                      "isPreconfigureEnabled": false,
                      "isHumDevice": false,
                      "isSmartLocator": false,
                      "isSecurityAlarm": false,
                      "isMotoMod": false,
                      "isConnectedCar": false,
                      "accountLevelAccessory": false,
                      "byodESimPhone": false,
                      "scannedItem": false,
                      "appleCareAccessoryFlag": false,
                      "quantityAllowed": true,
                      "isDfoSelected": false
                    }
                  ]
                },
                "isPromoSelected": false,
                "isTradeInSelected": false,
                "taxExemptionTypes": ""
              }
            ],
            "mtnDetails": {
              "lineNumber": "8133477604",
              "mobileNumber": "8133477604"
            },
            "lineNumber": "8133477604",
            "fiveGToFourGDownGrade": false,
            "lineCreator": "8133477604",
            "amRole": "",
            "lineRefundTotal": 0.0,
            "lineExchangeTotal": 328.99,
            "totalDueMonthlyBeforeCredit": 0.0,
            "sugAllowed": false,
            "totalDueAddOnMonthly": 0.0,
            "totalPriceOfPlanAndPerks": "0.0",
            "isCpe": false,
            "isLTEHomeLine": false,
            "isDevicePlanCompatible": false,
            "portinMtnAssignment": false,
            "impactedLine": false,
            "preOrBackOrder": false,
            "ispuItem": false,
            "ispuItemBYOD": false,
            "isModConnected": false,
            "modDevice": false,
            "byodCapable": false,
            "isCarLine": false,
            "buySimOnly": false,
            "broadBandInd": false,
            "ispuDownPaymentAdjstRequired": false,
            "ispuDownPaymentAmount": 0.0,
            "lineWithSkipMDN": false,
            "protectionNotRequired": false
          },
          
          {
              "isCommonPDP": false,
              "isTradeInIntentSelected": false,
              "multiLineSeqNumber": 3,
              "lineActivityType": "ACC",
              "totalDueToday": 353.66,
              "totalDueTodayWithoutTax": 328.99,
              "totalDueTodayWithoutTaxWithoutDiscount": 328.99,
              "totalDueMonthly": 133.83,
              "mobileNumber": "8133477604",
              "showGlobalChoiceOffer": false,
              "serviceInfo": {
                "planDiscount": {
                  "planEligibleForAutoPayPaperLessDiscount": false,
                  "discountIncluded": false,
                  "totalPlanCostIncludingLineAccessFee": "0.0"
                },
                "serviceAddress": {
                  "addressLine1": "6013 PORTSDALE PL UNIT 201",
                  "addressLine2": "",
                  "zipCode": "33578",
                  "zipCode4": "4097",
                  "firstName": "DON",
                  "lastName": "WRIGHT",
                  "city": "RIVERVIEW",
                  "state": "FL"
                },
                "comparePlan": false,
                "primaryUserInfo": {
                  "firstName": "DON",
                  "lastName": "WRIGHT",
                  "address": {
                    "firmName": "",
                    "apartmentNo": "201",
                    "type": "PL",
                    "streetNumber": "6013",
                    "streetName": "PORTSDALE",
                    "addressLine2": "",
                    "addressLine1": "6013 PORTSDALE PL UNIT 201",
                    "poBoxNo": "",
                    "ruralRouteNo": "",
                    "ruralDelNo": "",
                    "city": "RIVERVIEW",
                    "state": "FL",
                    "zipCode": "33578",
                    "zipCode4": "4097",
                    "county": "",
                    "countryCode": "US",
                    "fipsCode": "1205760950",
                    "firstName": "DON",
                    "lastName": "WRIGHT",
                    "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                    "phoneNumber": "9089349238",
                    "streetType": "PL",
                    "streetDirection": ""
                  },
                  "isValidAddress": true,
                  "bsnsName": "",
                  "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                  "midInitials": ""
                },
                "mtn": "8133477604",
                "min": "8132580300",
                "oldPricePlanId": "50430",
                "contractTermId": "48",
                "currentDevice": {
                  "oldLteVoraEquipInfo": {
                    "iccid": "89148000009826583322",
                    "lteVoraDeviceInfo": {
                      "deviceId": "352865677734782",
                      "deviceType": "5GE",
                      "deviceSku": "CLNRAPL13PM128SB",
                      "description": "IPHONE 13 PRO MAX 128 SR BLU",
                      "imageUrlMap": {
                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue",
                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-lg$",
                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-med$",
                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-mini$",
                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-thumb$"
                      },
                      "color": {},
                      "manufacturer": "Apple"
                    }
                  }
                },
                "isSharePlanAdded": false,
                "mea": "V0T",
                "isE911AddressValidated": false,
                "oldPlanFlag": "L",
                "orderDevice": {
                  "lteVoraEquipInfo": {
                    "lteEqpt": {},
                    "lteVoraDeviceInfo": {}
                  }
                },
                "kidsPlanParentMtn": false,
                "mcsSubscription": [],
                "fiveGUpSell": false,
                "e911AddressSameAsServiceAddress": false,
                "unpairedGrantor": false,
                "totalAddedFeaturesPrice": "0.0"
              },
              "itemsInfo": [
                {
                  "depletionType": "F",
                  "attention": "DON WRIGHT",
                  "shipping": {
                    "address": {
                      "firmName": "",
                      "apartmentNo": "201",
                      "type": "R",
                      "streetNumber": "6013",
                      "streetName": "PORTSDALE",
                      "addressLine2": "",
                      "addressLine1": "6013 PORTSDALE PL UNIT 201",
                      "poBoxNo": "",
                      "ruralDelNo": "",
                      "city": "RIVERVIEW",
                      "state": "FL",
                      "zipCode": "33578",
                      "zipCode4": "4097",
                      "county": "",
                      "countryCode": "",
                      "fipsCode": "1205760950",
                      "firstName": "DON",
                      "lastName": "WRIGHT",
                      "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                      "phoneNumber": "9089349238",
                      "streetType": "PL",
                      "streetDirection": ""
                    },
                    "bsnsName": "",
                    "shippingCode": "SHP002",
                    "shippingCost": "0.00",
                    "shippingDescription": "Free 2 Day by 8pm",
                    "cbrPhone": "9089349238",
                    "firstName": "DON",
                    "lastName": "WRIGHT",
                    "midInitials": "",
                    "isUseUnVerifiedAddress": false,
                    "isValidAddress": false,
                    "email": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                    "shipToCustomerAddress": false
                  },
                  "fipsCode": "1205760950",
                  "itemCount": 2,
                  "itemTabSeqNum": 0,
                  "cartItems": {
                    "cartItem": [
                      {
                        "discountAmount": 0.0,
                        "deviceDollarApplied": 0.0,
                        "promoHubOfferList": {
                          "promoHubOfferList": [],
                          "offerCount": 0
                        },
                        "qrScanNeededForEsimActivation": false,
                        "isPreconfigureDuringAddDevice": false,
                        "deviceDisplayName": "AirPods 4 with Active Noise Cancellation",
                        "accessoryGiftCardAmount": 0.0,
                        "tradeInAmountTowardsUserDPUsed": 0.0,
                        "sorDeviceCategory": "Bluetooth Headphones",
                        "vendingKioskItem": "false",
                        "tradeInAutoPull": false,
                        "priceAdjustment": false,
                        "priceAdjustmentQty": 0,
                        "newPurchasedQty": 1,
                        "canonicalUrl": "products/apple-airpods-4-with-active-noise-cancellation/",
                        "selectedForRFEX": false,
                        "selectedForPAD": false,
                        "bogoItem": false,
                        "refxItemSeqNum": 0,
                        "restrictedAccySku": false,
                        "maxAccyPurchaseLimit": false,
                        "giftCard": false,
                        "itemCode": "MXP93LL/A",
                        "totalPriceWithDiscount": 179.0,
                        "sorId": "MXP93LL/A",
                        "skuId": "sku6016076",
                        "cartItemType": "ACCESSORY",
                        "description": "AirPods 4 with Active Noise Cancellation",
                        "qty": 1,
                        "bundleSeqNum": 0,
                        "itemPrice": "179.00",
                        "discountedPercentage": 0.0,
                        "discountedPrice": 179.0,
                        "buyOutTaxAmountUnbilled": 0.0,
                        "buyOutAmountWithoutTax": 0.0,
                        "taxAmount": 13.42,
                        "imageUrlMap": {
                          "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset",
                          "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-lg$",
                          "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-med$",
                          "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-mini$",
                          "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-thumb$"
                        },
                        "prodCode1": "TAX",
                        "prodCode2": "SPC",
                        "prodCode3": "OEM",
                        "prodCode4": "000",
                        "prodCode5": "000",
                        "btaEligible": "true",
                        "depletionType": "F",
                        "catalogPrice": 179.0,
                        "instantCreditAmountUsed": 0.0,
                        "instantCreditAmountUsedForTaxes": 0.0,
                        "color": {
                          "color": "#F9F8F3",
                          "colorDisplayName": "WHITE"
                        },
                        "unitTaxBasedPrice": 179.0,
                        "itemNrpPrice": 179.0,
                        "discounts": [],
                        "availableReasonCode": [],
                        "inventory": {
                          "isAvailable": true,
                          "isBackorder": false,
                          "isDeliverBy": false,
                          "isPreOrder": false,
                          "qtyAvailable": 1426,
                          "isShipBy": false
                        },
                        "isCustomerProvidedSIM": false,
                        "isNetworkExtender": false,
                        "ispuEligible": true,
                        "itemSeqNum": 11,
                        "sddEligible": true,
                        "smartIMEI": false,
                        "year": 0,
                        "sellerPrice": "0.0",
                        "productId": "acc20893304",
                        "taxDetailsList": [
                          {
                            "taxSequenceNum": 1,
                            "taxPassType": "10",
                            "taxAmount": "10.74",
                            "taxDescription": "FL State Sales Tax",
                            "taxType": "01",
                            "mldSequenceNum": 1,
                            "taxSurcharge": "T"
                          },
                          {
                            "taxSequenceNum": 2,
                            "taxPassType": "20",
                            "taxAmount": "2.68",
                            "taxDescription": "Hillsborough Cnty Sales Tax",
                            "taxType": "02",
                            "mldSequenceNum": 2,
                            "taxSurcharge": "T"
                          }
                        ],
                        "manufacturer": "Apple",
                        "quantityOnHand": 1426,
                        "iconicPhone": false,
                        "ringBell": false,
                        "isPreconfigureEnabled": false,
                        "isHumDevice": false,
                        "isSmartLocator": false,
                        "isSecurityAlarm": false,
                        "isMotoMod": false,
                        "isConnectedCar": false,
                        "accountLevelAccessory": false,
                        "byodESimPhone": false,
                        "scannedItem": false,
                        "appleCareAccessoryFlag": false,
                        "quantityAllowed": true,
                        "isDfoSelected": false
                      },
                      {
                        "discountAmount": 0.0,
                        "deviceDollarApplied": 0.0,
                        "promoHubOfferList": {
                          "promoHubOfferList": [],
                          "offerCount": 0
                        },
                        "qrScanNeededForEsimActivation": false,
                        "isPreconfigureDuringAddDevice": false,
                        "deviceDisplayName": "Soundgear Sense Open-Ear Headphones - Black",
                        "accessoryGiftCardAmount": 0.0,
                        "tradeInAmountTowardsUserDPUsed": 0.0,
                        "sorDeviceCategory": "Bluetooth Headphones",
                        "vendingKioskItem": "false",
                        "tradeInAutoPull": false,
                        "priceAdjustment": false,
                        "priceAdjustmentQty": 0,
                        "newPurchasedQty": 1,
                        "canonicalUrl": "products/jbl-soundgear-sense-open-ear-headphones/",
                        "selectedForRFEX": false,
                        "selectedForPAD": false,
                        "bogoItem": false,
                        "refxItemSeqNum": 0,
                        "restrictedAccySku": false,
                        "maxAccyPurchaseLimit": false,
                        "giftCard": false,
                        "itemCode": "JBLSNDGEARSNSBLKAM",
                        "totalPriceWithDiscount": 149.99,
                        "sorId": "JBLSNDGEARSNSBLKAM",
                        "skuId": "sku6013494",
                        "cartItemType": "ACCESSORY",
                        "description": "Soundgear Sense Open-Ear Headphones - Black",
                        "qty": 1,
                        "bundleSeqNum": 0,
                        "itemPrice": "149.99",
                        "discountedPercentage": 0.0,
                        "discountedPrice": 149.99,
                        "buyOutTaxAmountUnbilled": 0.0,
                        "buyOutAmountWithoutTax": 0.0,
                        "taxAmount": 11.25,
                        "imageUrlMap": {
                          "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset",
                          "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-lg$",
                          "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-med$",
                          "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-mini$",
                          "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-thumb$"
                        },
                        "prodCode1": "TAX",
                        "prodCode2": "SPC",
                        "prodCode3": "OEM",
                        "prodCode4": "000",
                        "prodCode5": "000",
                        "btaEligible": "true",
                        "depletionType": "F",
                        "catalogPrice": 149.99,
                        "instantCreditAmountUsed": 0.0,
                        "instantCreditAmountUsedForTaxes": 0.0,
                        "color": {
                          "color": "#000000",
                          "colorDisplayName": "BLACK"
                        },
                        "unitTaxBasedPrice": 149.99,
                        "itemNrpPrice": 149.99,
                        "discounts": [],
                        "availableReasonCode": [],
                        "inventory": {
                          "isAvailable": true,
                          "isBackorder": false,
                          "isDeliverBy": false,
                          "isPreOrder": false,
                          "qtyAvailable": 1018,
                          "isShipBy": false
                        },
                        "isCustomerProvidedSIM": false,
                        "isNetworkExtender": false,
                        "ispuEligible": true,
                        "itemSeqNum": 12,
                        "sddEligible": true,
                        "smartIMEI": false,
                        "year": 0,
                        "sellerPrice": "0.0",
                        "productId": "acc20892292",
                        "taxDetailsList": [
                          {
                            "taxSequenceNum": 1,
                            "taxPassType": "10",
                            "taxAmount": "9.00",
                            "taxDescription": "FL State Sales Tax",
                            "taxType": "01",
                            "mldSequenceNum": 1,
                            "taxSurcharge": "T"
                          },
                          {
                            "taxSequenceNum": 2,
                            "taxPassType": "20",
                            "taxAmount": "2.25",
                            "taxDescription": "Hillsborough Cnty Sales Tax",
                            "taxType": "02",
                            "mldSequenceNum": 2,
                            "taxSurcharge": "T"
                          }
                        ],
                        "manufacturer": "JBL",
                        "quantityOnHand": 0,
                        "iconicPhone": false,
                        "ringBell": false,
                        "isPreconfigureEnabled": false,
                        "isHumDevice": false,
                        "isSmartLocator": false,
                        "isSecurityAlarm": false,
                        "isMotoMod": false,
                        "isConnectedCar": false,
                        "accountLevelAccessory": false,
                        "byodESimPhone": false,
                        "scannedItem": false,
                        "appleCareAccessoryFlag": false,
                        "quantityAllowed": true,
                        "isDfoSelected": false
                      },
                      {
                        "discountAmount": 0.0,
                        "deviceDollarApplied": 0.0,
                        "qrScanNeededForEsimActivation": false,
                        "isPreconfigureDuringAddDevice": false,
                        "accessoryGiftCardAmount": 0.0,
                        "tradeInAmountTowardsUserDPUsed": 0.0,
                        "vendingKioskItem": "false",
                        "tradeInAutoPull": false,
                        "priceAdjustment": false,
                        "priceAdjustmentQty": 0,
                        "newPurchasedQty": 0,
                        "selectedForRFEX": false,
                        "selectedForPAD": false,
                        "bogoItem": false,
                        "refxItemSeqNum": 0,
                        "restrictedAccySku": false,
                        "maxAccyPurchaseLimit": false,
                        "giftCard": false,
                        "itemCode": "SHP002",
                        "totalPriceWithDiscount": 0.0,
                        "sorId": "SHP002",
                        "cartItemType": "SHIPPING",
                        "mobileNumber": "8133477604",
                        "description": "Free 2 Day by 8pm",
                        "qty": 1,
                        "bundleSeqNum": 0,
                        "itemPrice": "0.0",
                        "discountedPercentage": 0.0,
                        "discountedPrice": 0.0,
                        "buyOutTaxAmountUnbilled": 0.0,
                        "buyOutAmountWithoutTax": 0.0,
                        "depletionType": "F",
                        "instantCreditAmountUsed": 0.0,
                        "instantCreditAmountUsedForTaxes": 0.0,
                        "itemCost": 0.0,
                        "discounts": [],
                        "availableReasonCode": [],
                        "isCustomerProvidedSIM": false,
                        "isNetworkExtender": false,
                        "ispuEligible": false,
                        "itemSeqNum": 0,
                        "sddEligible": false,
                        "smartIMEI": false,
                        "year": 0,
                        "sellerPrice": "0.0",
                        "taxDetailsList": [],
                        "iconicPhone": false,
                        "ringBell": false,
                        "isPreconfigureEnabled": false,
                        "isHumDevice": false,
                        "isSmartLocator": false,
                        "isSecurityAlarm": false,
                        "isMotoMod": false,
                        "isConnectedCar": false,
                        "accountLevelAccessory": false,
                        "byodESimPhone": false,
                        "appleCareAccessoryFlag": false,
                        "quantityAllowed": false,
                        "isDfoSelected": false
                      },
                      {
                        "discountAmount": 0.0,
                        "deviceDollarApplied": 0.0,
                        "promoHubOfferList": {
                          "promoHubOfferList": [],
                          "offerCount": 0
                        },
                        "qrScanNeededForEsimActivation": false,
                        "isPreconfigureDuringAddDevice": false,
                        "deviceDisplayName": "AirPods 4 with Active Noise Cancellation",
                        "accessoryGiftCardAmount": 0.0,
                        "tradeInAmountTowardsUserDPUsed": 0.0,
                        "sorDeviceCategory": "Bluetooth Headphones",
                        "vendingKioskItem": "false",
                        "tradeInAutoPull": false,
                        "priceAdjustment": false,
                        "priceAdjustmentQty": 0,
                        "newPurchasedQty": 1,
                        "canonicalUrl": "products/apple-airpods-4-with-active-noise-cancellation/",
                        "selectedForRFEX": false,
                        "selectedForPAD": false,
                        "bogoItem": false,
                        "refxItemSeqNum": 0,
                        "restrictedAccySku": false,
                        "maxAccyPurchaseLimit": false,
                        "giftCard": false,
                        "itemCode": "MXP93LL/A",
                        "totalPriceWithDiscount": 179.0,
                        "sorId": "MXP93LL/A",
                        "skuId": "sku6016076",
                        "cartItemType": "ACCESSORY",
                        "description": "AirPods 4 with Active Noise Cancellation",
                        "qty": 1,
                        "bundleSeqNum": 0,
                        "itemPrice": "179.00",
                        "discountedPercentage": 0.0,
                        "discountedPrice": 179.0,
                        "buyOutTaxAmountUnbilled": 0.0,
                        "buyOutAmountWithoutTax": 0.0,
                        "taxAmount": 13.42,
                        "imageUrlMap": {
                          "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset",
                          "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-lg$",
                          "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-med$",
                          "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-mini$",
                          "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-thumb$"
                        },
                        "prodCode1": "TAX",
                        "prodCode2": "SPC",
                        "prodCode3": "OEM",
                        "prodCode4": "000",
                        "prodCode5": "000",
                        "btaEligible": "true",
                        "depletionType": "F",
                        "catalogPrice": 179.0,
                        "instantCreditAmountUsed": 0.0,
                        "instantCreditAmountUsedForTaxes": 0.0,
                        "color": {
                          "color": "#F9F8F3",
                          "colorDisplayName": "WHITE"
                        },
                        "unitTaxBasedPrice": 179.0,
                        "itemNrpPrice": 179.0,
                        "discounts": [],
                        "availableReasonCode": [],
                        "inventory": {
                          "isAvailable": true,
                          "isBackorder": false,
                          "isDeliverBy": false,
                          "isPreOrder": false,
                          "qtyAvailable": 1426,
                          "isShipBy": false
                        },
                        "isCustomerProvidedSIM": false,
                        "isNetworkExtender": false,
                        "ispuEligible": true,
                        "itemSeqNum": 11,
                        "sddEligible": true,
                        "smartIMEI": false,
                        "year": 0,
                        "sellerPrice": "0.0",
                        "productId": "acc20893304",
                        "taxDetailsList": [
                          {
                            "taxSequenceNum": 1,
                            "taxPassType": "10",
                            "taxAmount": "10.74",
                            "taxDescription": "FL State Sales Tax",
                            "taxType": "01",
                            "mldSequenceNum": 1,
                            "taxSurcharge": "T"
                          },
                          {
                            "taxSequenceNum": 2,
                            "taxPassType": "20",
                            "taxAmount": "2.68",
                            "taxDescription": "Hillsborough Cnty Sales Tax",
                            "taxType": "02",
                            "mldSequenceNum": 2,
                            "taxSurcharge": "T"
                          }
                        ],
                        "manufacturer": "Apple",
                        "quantityOnHand": 1426,
                        "iconicPhone": false,
                        "ringBell": false,
                        "isPreconfigureEnabled": false,
                        "isHumDevice": false,
                        "isSmartLocator": false,
                        "isSecurityAlarm": false,
                        "isMotoMod": false,
                        "isConnectedCar": false,
                        "accountLevelAccessory": false,
                        "byodESimPhone": false,
                        "scannedItem": false,
                        "appleCareAccessoryFlag": false,
                        "quantityAllowed": true,
                        "isDfoSelected": false
                      }
                    ]
                  },
                  "isPromoSelected": false,
                  "isTradeInSelected": false,
                  "taxExemptionTypes": ""
                }
              ],
              "mtnDetails": {
                "lineNumber": "8133477604",
                "mobileNumber": "8133477604"
              },
              "lineNumber": "8133477604",
              "fiveGToFourGDownGrade": false,
              "lineCreator": "8133477604",
              "amRole": "",
              "lineRefundTotal": 0.0,
              "lineExchangeTotal": 328.99,
              "totalDueMonthlyBeforeCredit": 0.0,
              "sugAllowed": false,
              "totalDueAddOnMonthly": 0.0,
              "totalPriceOfPlanAndPerks": "0.0",
              "isCpe": false,
              "isLTEHomeLine": false,
              "isDevicePlanCompatible": false,
              "portinMtnAssignment": false,
              "impactedLine": false,
              "preOrBackOrder": false,
              "ispuItem": false,
              "ispuItemBYOD": false,
              "isModConnected": false,
              "modDevice": false,
              "byodCapable": false,
              "isCarLine": false,
              "buySimOnly": false,
              "broadBandInd": false,
              "ispuDownPaymentAdjstRequired": false,
              "ispuDownPaymentAmount": 0.0,
              "lineWithSkipMDN": false,
              "protectionNotRequired": false
            }
        ],
        "numOfAccessoryAndDeviceItemsInCart": 6,
        "totalEdgeUpAmount": 0.0,
        "totalEdgeBuyOutAmount": 0.0,
        "tradeInDetail": {},
        "totalDownPaymentAmt": 0.0,
        "numOfLinesWithDevices": 2,
        "discountGainIndicators": [],
        "discountLossIndicators": [],
        "subscriptionInfos": [],
        "numofApprovedLines": 0,
        "rfexPayments": [],
        "numOfLines": 4,
        "numofLinesAAL": 2,
        "numofLinesEUP": 0,
        "payments": [],
        "lineSeq": 0,
        "vlcactivePhoneCount": 0,
        "fivegOrderind": true,
        "aceOrderCreated": true,
        "serviceLinesCreated": false,
        "aceItemsModified": true,
        "enableLineInfoFFlag": true,
        "clnrOrderFlag": false,
        "broadbandInd": false,
        "isAutoPayEnrolled": "N",
        "isAutoPayPaperLessDiscountEligible": "Y",
        "isPaperLessEnrolled": "Y",
        "totalEligibleAutoPayPaperLessDiscount": "25.00",
        "tabletJetpackDiscountMultiLineLoss": "N",
        "acctMcsSubscription": [],
        "spendingLimitAmountExceededBy": "0.0",
        "numofAccessories": 4,
        "subAccountNBSInfo": [
          {
            "billAccounts": [
              {
                "billSummary": {
                  "grandTotal": {
                    "newMonthCharge": "325.80",
                    "nextMonthCharge": "517.99"
                  },
                  "planCharge": {
                    "newMonthCharge": "251.50",
                    "nextMonthCharge": "422.34"
                  },
                  "lineAccessFees": {
                    "newMonthCharge": "0.00",
                    "nextMonthCharge": "0.00"
                  },
                  "devicePayments": {
                    "newMonthCharge": "68.60",
                    "nextMonthCharge": "68.79"
                  },
                  "surcharges": {
                    "newMonthCharge": "12.92",
                    "nextMonthCharge": "21.26"
                  },
                  "taxesAndFees": {
                    "newMonthCharge": "5.83",
                    "nextMonthCharge": "12.14"
                  },
                  "totalAddOns": {
                    "newMonthCharge": "36.95",
                    "nextMonthCharge": "36.95"
                  },
                  "appleMusic": {
                    "newMonthCharge": "0.00",
                    "nextMonthCharge": "0.00"
                  },
                  "mobileProtection": {
                    "newMonthCharge": "26.95",
                    "nextMonthCharge": "26.95"
                  },
                  "planAccessFeeTotal": {
                    "newMonthCharge": "251.50",
                    "nextMonthCharge": "422.34"
                  },
                  "taxGrandTotal": {
                    "newMonthCharge": "18.75",
                    "nextMonthCharge": "33.40"
                  },
                  "subTotal": {
                    "newMonthCharge": "307.05",
                    "nextMonthCharge": "484.59"
                  },
                  "autoPayDiscount": {
                    "accountTotalAutoPayDiscount": "25.00",
                    "isCustomerEnrolledForAutopay": false,
                    "subTotalNewMonthwithAutoPayDisc": "282.05"
                  },
                  "dateRange": {
                    "thisMonth": "10/06/2024-11/05/2024",
                    "nextMonth": "11/06/2024-12/05/2024"
                  }
                },
                "nbs": {
                  "accountNumber": "0325654132-00001",
                  "nextBillCycleStartDate": "11/06/2024",
                  "balancePastDue": {
                    "pastDueAmount": "0.00",
                    "paymentsReceived": "0.00",
                    "previousBalance": "295.88",
                    "balanceType": "Current Balance",
                    "unbilledPayment": "-144.64",
                    "totUnpaidBalance": "151.24",
                    "paymentMessage": "You have paid a portion of your current bill. The remaining balance of $151.24 is due on 10/28/2024.",
                    "unbilledOCC": "0.00"
                  },
                  "monthlyChargesInfo": {
                    "accountLevelCharges": [
                      {
                        "thisMonthCharge": "-25.00",
                        "nextMonthCharge": "-25.00",
                        "chargeRefId": "1781",
                        "description": "LOYALTY $25 DISC 2-3 PHONES",
                        "itemType": [
                          {
                            "equipment": false,
                            "feature": false,
                            "naf": false,
                            "occ": false,
                            "plan": false,
                            "promo": false,
                            "accequipment": false,
                            "sfo": false,
                            "spo": false,
                            "addOn": false
                          }
                        ],
                        "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                        "listPrice": "-25.00",
                        "netPrice": "-25.00"
                      }
                    ],
                    "accountLevelTotal": {
                      "thisMonthCharge": "-25.00",
                      "nextMonthCharge": "-41.94",
                      "differenceBetweenThisMonthAndNextMonthCharge": "-16.94",
                      "totalOneTimeCharge": "-16.94",
                      "newMonthMrcWithNoAddOn": "-25.00",
                      "nextMonthMrcWithNoAddOn": "-25.00",
                      "nextMonthAcctLevelSurcharges": "0.00",
                      "newMonthAcctLevelSurcharges": "0.00",
                      "nextMonthAccountLevelTax": "0.00",
                      "newMonthAccountLevelTax": "0.00",
                      "chargeTotals": [
                        {
                          "itemRef": "SPO",
                          "differenceBetweenThisAndNextMonthCharge": "0.00",
                          "thisMonthCharge": "-25.00",
                          "nextMonthCharge": "-25.00"
                        },
                        {
                          "itemRef": "Total Addons",
                          "differenceBetweenThisAndNextMonthCharge": "0.00",
                          "thisMonthCharge": "0.00",
                          "nextMonthCharge": "0.00"
                        }
                      ]
                    },
                    "mtnLevelChargeDetails": [
                      {
                        "mtn": "8133477604",
                        "thisMonthCharge": "133.83",
                        "nextMonthCharge": "190.73",
                        "differenceBetweenThisMonthAndNextMonthCharge": "56.90",
                        "thisMonthSurcharges": "4.68",
                        "previousMonthCharge": "0.00",
                        "nextMonthSurcharges": "4.92",
                        "differenceBetweenThisMonthAndNextMonthSurcharges": "0.24",
                        "thisMonthTax": "2.08",
                        "nextMonthTax": "2.26",
                        "differenceBetweenThisMonthAndNextMonthTax": "0.18",
                        "chargeDetails": [
                          {
                            "thisMonthCharge": "84.00",
                            "nextMonthCharge": "84.00",
                            "chargeRefId": "50430",
                            "description": "5G PLAY MORE",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "84.00",
                            "netPrice": "84.00",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          },
                          {
                            "thisMonthCharge": "30.83",
                            "nextMonthCharge": "30.83",
                            "chargeRefId": "352396479769529",
                            "description": "Device Payment",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "30.83",
                            "netPrice": "30.83",
                            "loanNumber": "1587790945",
                            "nextInstallmentNumber": "25",
                            "totalInstallmentNumber": "36",
                            "outstandingLoanAmount": "339.13",
                            "loanAmount": "1110.00",
                            "loanCode": "A"
                          },
                          {
                            "thisMonthCharge": "19.00",
                            "nextMonthCharge": "19.00",
                            "chargeRefId": "88690",
                            "description": "VERIZON MOBILE PROTECT",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "19.00",
                            "netPrice": "19.00",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          }
                        ],
                        "oneTimeChargeDetails": [
                          {
                            "thisMonthCharge": "0.00",
                            "nextMonthCharge": "56.90",
                            "chargeRefId": "50430",
                            "description": "5G PLAY MORE",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "56.90",
                            "netPrice": "56.90",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          }
                        ],
                        "nickname": "DON WRIGHT",
                        "suppressAdvInd": "N",
                        "newMonthMtnMrcWithNoAddOn": "114.83",
                        "nextMonthMtnMrcWithNoAddOn": "114.83",
                        "newMonthGrandTotalWithTaxes": "140.59",
                        "nextMonthGrandTotalWithTaxes": "197.91",
                        "chargeTotals": [
                          {
                            "itemRef": "Equipment",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "30.83",
                            "nextMonthCharge": "30.83"
                          },
                          {
                            "itemRef": "Total Addons",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "19.00",
                            "nextMonthCharge": "19.00"
                          },
                          {
                            "itemRef": "PPLAN",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "84.00",
                            "nextMonthCharge": "84.00"
                          },
                          {
                            "itemRef": "Auto Pay",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "5.00",
                            "nextMonthCharge": "5.00"
                          }
                        ],
                        "mtnChangeInd": false
                      },
                      {
                        "mtn": "8137244660",
                        "thisMonthCharge": "55.00",
                        "nextMonthCharge": "92.25",
                        "differenceBetweenThisMonthAndNextMonthCharge": "37.25",
                        "thisMonthSurcharges": "0.00",
                        "previousMonthCharge": "0.00",
                        "nextMonthSurcharges": "0.00",
                        "differenceBetweenThisMonthAndNextMonthSurcharges": "0.00",
                        "thisMonthTax": "0.00",
                        "nextMonthTax": "0.00",
                        "differenceBetweenThisMonthAndNextMonthTax": "0.00",
                        "chargeDetails": [
                          {
                            "thisMonthCharge": "80.00",
                            "nextMonthCharge": "80.00",
                            "chargeRefId": "75561",
                            "description": "5G HOME PLUS",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "80.00",
                            "netPrice": "80.00",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          },
                          {
                            "thisMonthCharge": "-25.00",
                            "nextMonthCharge": "-25.00",
                            "chargeRefId": "2722",
                            "description": "MOBILE + HOME DISCOUNT",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "-25.00",
                            "netPrice": "-25.00",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          },
                          {
                            "thisMonthCharge": "10.00",
                            "nextMonthCharge": "10.00",
                            "chargeRefId": "3239",
                            "description": "WHOLE-HOME WI-FI",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "-10.00",
                            "listPrice": "10.00",
                            "netPrice": "0.00",
                            "promo1Id": "20996",
                            "promo1Desc": "WHOLE-HOME WI-FI DISCOUNT",
                            "promo1Discount": "-10.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          },
                          {
                            "thisMonthCharge": "10.00",
                            "nextMonthCharge": "10.00",
                            "chargeRefId": "2641",
                            "description": "DISNEY BUNDLE",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "-10.00",
                            "listPrice": "10.00",
                            "netPrice": "0.00",
                            "promo1Id": "21015",
                            "promo1Desc": "DISNEY BUNDLE PROMO",
                            "promo1Discount": "-10.00",
                            "promo1EndDate": "10/11/2025",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          }
                        ],
                        "oneTimeChargeDetails": [
                          {
                            "thisMonthCharge": "0.00",
                            "nextMonthCharge": "54.19",
                            "chargeRefId": "75561",
                            "description": "5G HOME PLUS",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "54.19",
                            "netPrice": "54.19",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          },
                          {
                            "thisMonthCharge": "0.00",
                            "nextMonthCharge": "-16.94",
                            "chargeRefId": "2722",
                            "description": "MOBILE + HOME DISCOUNT",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "-16.94",
                            "netPrice": "-16.94",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          },
                          {
                            "thisMonthCharge": "0.00",
                            "nextMonthCharge": "6.77",
                            "chargeRefId": "3239",
                            "description": "WHOLE-HOME WI-FI",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "-6.77",
                            "listPrice": "6.77",
                            "netPrice": "0.00",
                            "promo1Id": "20996",
                            "promo1Desc": "WHOLE-HOME WI-FI DISCOUNT",
                            "promo1Discount": "-6.77",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          }
                        ],
                        "nickname": "New line",
                        "suppressAdvInd": "N",
                        "newMonthMtnMrcWithNoAddOn": "55.00",
                        "nextMonthMtnMrcWithNoAddOn": "55.00",
                        "newMonthGrandTotalWithTaxes": "55.00",
                        "nextMonthGrandTotalWithTaxes": "92.25",
                        "chargeTotals": [
                          {
                            "itemRef": "SPO",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "-25.00",
                            "nextMonthCharge": "-25.00"
                          },
                          {
                            "itemRef": "Total Addons",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "0.00",
                            "nextMonthCharge": "0.00"
                          },
                          {
                            "itemRef": "PPLAN",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "80.00",
                            "nextMonthCharge": "80.00"
                          },
                          {
                            "itemRef": "Auto Pay",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "10.00",
                            "nextMonthCharge": "10.00"
                          }
                        ],
                        "mtnChangeInd": false
                      },
                      {
                        "mtn": "8137277652",
                        "thisMonthCharge": "121.00",
                        "nextMonthCharge": "215.77",
                        "differenceBetweenThisMonthAndNextMonthCharge": "94.77",
                        "thisMonthSurcharges": "4.32",
                        "previousMonthCharge": "0.00",
                        "nextMonthSurcharges": "12.38",
                        "differenceBetweenThisMonthAndNextMonthSurcharges": "8.06",
                        "thisMonthTax": "2.75",
                        "nextMonthTax": "8.83",
                        "differenceBetweenThisMonthAndNextMonthTax": "6.08",
                        "chargeDetails": [
                          {
                            "thisMonthCharge": "80.00",
                            "nextMonthCharge": "80.00",
                            "chargeRefId": "63217",
                            "description": "UNLIMITED PLUS",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "80.00",
                            "netPrice": "80.00",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          },
                          {
                            "thisMonthCharge": "23.05",
                            "nextMonthCharge": "23.24",
                            "description": "Device Payment",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.19",
                            "listPrice": "23.05",
                            "netPrice": "23.05",
                            "loanNumber": "0",
                            "nextInstallmentNumber": "1",
                            "totalInstallmentNumber": "36",
                            "outstandingLoanAmount": "806.75",
                            "loanAmount": "829.99",
                            "loanCode": "A"
                          },
                          {
                            "thisMonthCharge": "7.95",
                            "nextMonthCharge": "7.95",
                            "chargeRefId": "85913",
                            "description": "WIRELESS PHONE PROTECTION",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "7.95",
                            "netPrice": "7.95",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          },
                          {
                            "thisMonthCharge": "10.00",
                            "nextMonthCharge": "10.00",
                            "chargeRefId": "2641",
                            "description": "DISNEY BUNDLE",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "10.00",
                            "netPrice": "10.00",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          }
                        ],
                        "oneTimeChargeDetails": [
                          {
                            "thisMonthCharge": "0.00",
                            "nextMonthCharge": "54.19",
                            "chargeRefId": "63217",
                            "description": "UNLIMITED PLUS",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "54.19",
                            "netPrice": "54.19",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          },
                          {
                            "thisMonthCharge": "0.00",
                            "nextMonthCharge": "5.39",
                            "chargeRefId": "85913",
                            "description": "WIRELESS PHONE PROTECTION",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "5.39",
                            "netPrice": "5.39",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          },
                          {
                            "thisMonthCharge": "0.00",
                            "nextMonthCharge": "35.00",
                            "chargeRefId": "3",
                            "description": "ACTIVATION FEE",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "listPrice": "0.0",
                            "netPrice": "0.0",
                            "recurringIndicator": "N",
                            "balanceDueIndicator": "N"
                          }
                        ],
                        "nickname": "New line",
                        "suppressAdvInd": "N",
                        "newMonthMtnMrcWithNoAddOn": "103.05",
                        "nextMonthMtnMrcWithNoAddOn": "103.24",
                        "newMonthGrandTotalWithTaxes": "128.07",
                        "nextMonthGrandTotalWithTaxes": "236.98",
                        "chargeTotals": [
                          {
                            "itemRef": "Equipment",
                            "differenceBetweenThisAndNextMonthCharge": "-0.19",
                            "thisMonthCharge": "23.05",
                            "nextMonthCharge": "23.05"
                          },
                          {
                            "itemRef": "Total Addons",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "17.95",
                            "nextMonthCharge": "17.95"
                          },
                          {
                            "itemRef": "PPLAN",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "80.00",
                            "nextMonthCharge": "80.00"
                          },
                          {
                            "itemRef": "OCC",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "0.00",
                            "nextMonthCharge": "0.00"
                          },
                          {
                            "itemRef": "Auto Pay",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "10.00",
                            "nextMonthCharge": "10.00"
                          }
                        ],
                        "mtnChangeInd": false
                      },
                      {
                        "mtn": "8138531515",
                        "thisMonthCharge": "22.22",
                        "nextMonthCharge": "27.78",
                        "differenceBetweenThisMonthAndNextMonthCharge": "5.56",
                        "thisMonthSurcharges": "3.92",
                        "previousMonthCharge": "0.00",
                        "nextMonthSurcharges": "3.96",
                        "differenceBetweenThisMonthAndNextMonthSurcharges": "0.04",
                        "thisMonthTax": "1.00",
                        "nextMonthTax": "1.05",
                        "differenceBetweenThisMonthAndNextMonthTax": "0.05",
                        "chargeDetails": [
                          {
                            "thisMonthCharge": "15.00",
                            "nextMonthCharge": "15.00",
                            "chargeRefId": "18056",
                            "description": "NUMBER SHARE",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "-7.50",
                            "listPrice": "15.00",
                            "netPrice": "7.50",
                            "promo1Id": "19979",
                            "promo1Desc": "50% ACCESS FEE DISCOUNT FROM 813.727.7652",
                            "promo1Discount": "-7.50",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          },
                          {
                            "thisMonthCharge": "14.72",
                            "nextMonthCharge": "14.72",
                            "chargeRefId": "358427486768156",
                            "description": "Device Payment",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "14.72",
                            "netPrice": "14.72",
                            "loanNumber": "1588437200",
                            "nextInstallmentNumber": "25",
                            "totalInstallmentNumber": "36",
                            "outstandingLoanAmount": "161.92",
                            "loanAmount": "529.99",
                            "loanCode": "A"
                          }
                        ],
                        "oneTimeChargeDetails": [
                          {
                            "thisMonthCharge": "0.00",
                            "nextMonthCharge": "11.13",
                            "chargeRefId": "18056",
                            "description": "NUMBER SHARE",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "-5.57",
                            "listPrice": "11.13",
                            "netPrice": "5.56",
                            "promo1Id": "19979",
                            "promo1Desc": "50% ACCESS FEE DISCOUNT FROM 813.727.7652",
                            "promo1Discount": "-5.57",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          }
                        ],
                        "nickname": "DON WRIGHT",
                        "suppressAdvInd": "N",
                        "newMonthMtnMrcWithNoAddOn": "22.22",
                        "nextMonthMtnMrcWithNoAddOn": "22.22",
                        "newMonthGrandTotalWithTaxes": "27.14",
                        "nextMonthGrandTotalWithTaxes": "32.79",
                        "chargeTotals": [
                          {
                            "itemRef": "Equipment",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "14.72",
                            "nextMonthCharge": "14.72"
                          },
                          {
                            "itemRef": "PPLAN",
                            "differenceBetweenThisAndNextMonthCharge": "-7.50",
                            "thisMonthCharge": "15.00",
                            "nextMonthCharge": "15.00"
                          }
                        ],
                        "mtnChangeInd": false
                      }
                    ],
                    "accountLevelOneTimeCharges": [
                      {
                        "thisMonthCharge": "0.00",
                        "nextMonthCharge": "-16.94",
                        "chargeRefId": "1781",
                        "description": "LOYALTY $25 DISC 2-3 PHONES",
                        "itemType": [
                          {
                            "equipment": false,
                            "feature": false,
                            "naf": false,
                            "occ": false,
                            "plan": false,
                            "promo": false,
                            "accequipment": false,
                            "sfo": false,
                            "spo": false,
                            "addOn": false
                          }
                        ],
                        "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                        "listPrice": "-16.94",
                        "netPrice": "-16.94"
                      }
                    ]
                  },
                  "monthlyTotalsInfo": {
                    "thisMonthCharge": "325.80",
                    "thisMonthChargeDateRange": "10/06/2024-11/05/2024",
                    "nextMonthCharge": "517.99",
                    "nextMonthChargeDateRange": "11/06/2024-12/05/2024",
                    "differenceBetweenThisMonthAndNextMonthCharge": "192.19",
                    "previousCycleFormattedDateRange": "Sep 06,2024 - Oct 05,2024"
                  },
                  "surchargesInfo": {
                    "thisMonthCharge": 12.92,
                    "nextMonthCharge": 21.26,
                    "differenceBetweenThisMonthAndNextMonthSurcharges": "8.34"
                  },
                  "taxesAndFeesInfo": {
                    "thisMonthCharge": 5.83,
                    "nextMonthCharge": 12.14,
                    "differenceBetweenThisMonthAndNextMonthTax": "6.31"
                  },
                  "autoPayDiscount": {
                    "accountTotalAutoPayDiscount": "25.00",
                    "isCustomerEnrolledForAutopay": false,
                    "subTotalNewMonthwithAutoPayDisc": "282.05"
                  },
                  "barGraphDetails": {
                    "invoiceCount": "3",
                    "invoiceLastMonth": "151.24",
                    "invoiceLastMonthCycleEnddate": "07/05/2024",
                    "invoiceTwoMonthPrevious": "144.64",
                    "invoiceTwoMonthCycleEnddate": "06/05/2024"
                  },
                  "nbsIndicators": {
                    "languageIndicator": "E",
                    "partialBillIndicator": "N"
                  },
                  "pendingChargesAndDiscounts": {
                    "mtnLevelPendingInfo": [],
                    "discountsPendingActionDetails": {
                      "apoPaperlessAmount": "-25.00",
                      "totalPendingDiscount": "-25.00",
                      "newMonthlyTotalWithPendingDiscounts": "300.80"
                    }
                  }
                },
                "billAccountNo": "1"
              }
            ]
          }
        ],
        "subAccountNbsDetails": [],
        "bagTax": false,
        "couponDetails": [{}]
      },
      "refundOrderDetails": {
        "orderNum": 0,
        "totalDueToday": "0.0",
        "subTotalDueToday": "0.0",
        "totalTaxAmount": "0.0",
        "creditApplicationNum": 0
      },
      "globalPromotions": {},
      "sfoLossReferenceDataList": [],
      "spoLossReferenceDataList": [],
      "verizonUpToastMessage": {
        "toastMessages": [],
        "eligibleProducts": []
      },
      "cartValidationErrors": [
        {
          "errorCategory": "Cart",
          "errorLevel": "Warning",
          "errorCode": "1011",
          "errorMessage": "Cart5GAppointment details are missing in Cart serviceInfo",
          "fieldPath": "8137244660"
        },
        {
          "errorCategory": "Cart",
          "errorLevel": "Warning",
          "errorCode": "1090",
          "errorMessage": "Shipping is Required",
          "fieldPath": ""
        },
        {
          "errorCategory": "Cart",
          "errorLevel": "Warning",
          "errorCode": "1016",
          "errorMessage": "Email Address is missing in shipping addresstype",
          "fieldPath": "8138531515"
        },
        {
          "errorCategory": "Cart",
          "errorLevel": "Warning",
          "errorCode": "1017",
          "errorMessage": "Phone Number is missing in shipping addresstype",
          "fieldPath": "8138531515"
        },
        {
          "errorCategory": "Cart",
          "errorLevel": "Warning",
          "errorCode": "1091",
          "errorMessage": "Payment is Required",
          "fieldPath": ""
        }
      ],
      "programEligibility": {
        "profileRemainingSpendingLimitAmount": 3407.85,
        "lineSpendingLimitAmount": 2000.0
      },
      "accountEligibility": false,
      "displayCartValidationErrors": true
    },
    "warningMessages": [],
    "basicORSmartPhoneExists": true,
    "fiveGDeviceORLTEHomeExists": false,
    "cartHasAccessories": true,
    "iscartHasVZHP": false,
    "isPortInLaterThrottled": true,
    "featureConfigurationProfileData": {
    },
    "featureFlags": {
      "rfexEligibilityForDfoFFlag": true
    },
    "orderPlaced": false,
    "validateCart": false,
    "redesignFlow": false,
    "validateAppointments": false,
    "newCustomer": false,
    "isLocalStoreOfferEnabled": false
  },
  "meta": {
    "timestamp": "1728901236632",
    "cxpCorrelationId": "2024-10-14T10:20:36.+0000:447ad94deaa89a69:cxp-shopping-services-585cdf5cdc-k7fjb:nssit2"
  }
}
export const giftcardMock = {
  "data": {
    "cart": {
      "customerProfile": {
        "billAccounts": [
          {
            "mtns": [
              {
                "mtn": "8138531515",
                "equipmentUpgradeEligibility": {
                  "upgradeEligibilityDate": "07/28/2025",
                  "upgradeEligible": true,
                  "twoYearContract": {}
                },
                "mobileInfoAttributes": {
                  "smartFamilyParent": false,
                  "accessRoles": {
                    "owner": false,
                    "manager": false,
                    "member": false
                  }
                },
                "equipmentInfos": [
                  {
                    "deviceInfo": {
                      "modelName": "Apple Watch Series 7 GPS + Cellular, 45mm Midnight Aluminum Case with Midnight Sport Band - Regular",
                      "deviceId": "358427486768156",
                      "deviceIdType": "IME",
                      "deviceSku": "MKJ73LL/A"
                    },
                    "simInfo": {
                      "modelName": "STM SOFT SIM",
                      "simId": "89148000008309669319",
                      "simSku": "SOFTSIM-CMR-S"
                    }
                  }
                ],
                "lineSharingIndicator": "R",
                "pricePlanInfo": {
                  "planId": "18056",
                  "planAttributes": {
                    "sharePlan": false
                  }
                },
                "currentSpo": [
                  {
                    "spoId": "732",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  }
                ]
              },
              {
                "mtn": "8133477604",
                "equipmentUpgradeEligibility": {
                  "upgradeEligibilityDate": "07/14/2025",
                  "upgradeEligible": true,
                  "twoYearContract": {}
                },
                "mobileInfoAttributes": {
                  "smartFamilyParent": false,
                  "accessRoles": {
                    "owner": false,
                    "manager": true,
                    "member": false
                  }
                },
                "equipmentInfos": [
                  {
                    "deviceInfo": {
                      "modelName": "IPHONE 13 PRO MAX 128 SR BLU",
                      "deviceId": "352865677734782",
                      "deviceIdType": "IME",
                      "deviceSku": "CLNRAPL13PM128SB"
                    },
                    "simInfo": {
                      "modelName": "SIM SKU 4G 5G",
                      "simId": "89148000009826583322",
                      "simSku": "BULKSIM5G-SA-A"
                    }
                  }
                ],
                "lineSharingIndicator": "L",
                "pricePlanInfo": {
                  "planId": "50430",
                  "planAttributes": {
                    "sharePlan": false
                  }
                },
                "currentSpo": [
                  {
                    "spoId": "384",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  },
                  {
                    "spoId": "732",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  },
                  {
                    "spoId": "1255",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  },
                  {
                    "spoId": "1535",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  },
                  {
                    "spoId": "1692",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  },
                  {
                    "spoId": "1801",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  },
                  {
                    "spoId": "2006",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  },
                  {
                    "spoId": "2107",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  },
                  {
                    "spoId": "2108",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  },
                  {
                    "spoId": "2176",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  },
                  {
                    "spoId": "2996",
                    "price": "0.00",
                    "finalPrice": "0.00"
                  }
                ]
              }
            ],
            "fiosEligibilityCategory": "",
            "accountAddress": {
              "zipCode": "33569",
              "zipCodePlus4": "0000",
              "fipsCode": "1205760950",
              "addressLine1": "6013 PORTSDALE PL UNIT 201",
              "addressLine2": "",
              "city": "RIVERVIEW",
              "state": "FL",
              "scrubbedAddress": {
                "streetName": "PORTSDALE",
                "streetNumber": "6013",
                "streetType": "PL",
                "streetDirection": "",
                "apartmentNo": "201",
                "pobox": "",
                "ruralDeliveryNo": "",
                "ruralRouteNo": "",
                "city": "RIVERVIEW",
                "state": "FL",
                "country": "",
                "zipCode": "33578",
                "zipCodePlus4": "4097"
              }
            },
            "accountAttributes": {
              "autopay": {
                "autoPayDiscount": "5.00"
              }
            },
            "accountOffers": {
              "lineLevelOffers": {
                "productOffers": [
                  {
                    "spoId": "384",
                    "price": "0.00",
                    "description": "INTL TRAVEL VOICE & DATA PAYGO"
                  },
                  {
                    "spoId": "732",
                    "price": "0.00",
                    "description": "CDMA-LESS ROAM TIER OVERRIDE"
                  },
                  {
                    "spoId": "1255",
                    "price": "0.00",
                    "description": "TRAVELPASS"
                  },
                  {
                    "spoId": "1535",
                    "price": "0.00",
                    "description": "DIGITAL SECURE PROVISIONING"
                  },
                  {
                    "spoId": "1692",
                    "price": "0.00",
                    "description": "5G DYNAMIC SPECTRUM SHARING"
                  },
                  {
                    "spoId": "1801",
                    "price": "0.00",
                    "description": "UNLIMITED PLAN INDICATOR"
                  },
                  {
                    "spoId": "2006",
                    "price": "0.00",
                    "description": "CALL FILTER PLUS PROVISIONING"
                  },
                  {
                    "spoId": "2107",
                    "price": "0.00",
                    "description": "5G ULTRA WIDEBAND ACCESS"
                  },
                  {
                    "spoId": "2108",
                    "price": "0.00",
                    "description": "5G ULTRA WIDEBAND PROVISIONING"
                  },
                  {
                    "spoId": "2176",
                    "price": "0.00",
                    "description": "APPLE ARCADE INCL WITH PLAN"
                  },
                  {
                    "spoId": "2996",
                    "price": "0.00",
                    "description": "MOBILE HOTSPOT 5GB"
                  }
                ]
              }
            }
          }
        ],
        "customerAttributes": {
          "taxExemptCode": "N",
          "digitalCustomerType": "B2C"
        }
      },
      "cartHasOnlyAccessories": false,
      "cartHasConflicts": true,
      "conflictsAccepted": true,
      "flow": "NAO|AAL_5G|AAL|NAO",
      "cartHeader": {
        "winBackAccountNumber": "",
        "vendorId": "NETACE",
        "ani": 8133477604,
        "repRole": "POSSYSTST",
        "locationType": "S",
        "isVzPhEligible": true,
        "sourceSystem": "OMNI-RETAIL",
        "fullAccountNumber": "0325654132-1",
        "status": "A",
        "createTimestamp": "2024-10-14T05:30:54.69-04:00[US/Eastern]",
        "lastUpdateTimestamp": "2024-10-14T06:20:33.98-04:00[US/Eastern]",
        "cartCreator": "8133477604",
        "cartCreatorChannelId": "OMNI-RETAIL",
        "cartCreatorOrderLocationCode": "0026301",
        "cartCreatorSalesRepId": "ENC",
        "visionCustomerType": "PE",
        "maverickLocation": false,
        "preConfiguredCartType": "BAU",
        "preConfiguredCartTypeDuringAddDevice": "BAU",
        "isCoreRep": false,
        "isERTRep": false
      },
      "orderDetails": {
        "totalUpgradeFee": 0.0,
        "totalDeviceDollar": 0.0,
        "totalRemainingDeviceDollar": 0.0,
        "totalUsedDeviceDollar": 0.0,
        "totalAccountLevelAccCost": 0.0,
        "totalAccountLevelAccCostWithTax": 0.0,
        "totalShippingCost": 0.0,
        "totalDiscountedShippingCost": 0.0,
        "hqUser": false,
        "returnException": false,
        "verizonCardPromoOfferList": [],
        "verizonCardApplicationInfo": {},
        "taxDetailsList": [
          {
            "taxSequenceNum": 1,
            "taxPassType": "10",
            "taxAmount": "91.74",
            "taxDescription": "FL State Sales Tax",
            "taxType": "01",
            "mldSequenceNum": 1,
            "taxSurcharge": "T"
          },
          {
            "taxSequenceNum": 2,
            "taxPassType": "20",
            "taxAmount": "22.93",
            "taxDescription": "Hillsborough Cnty Sales Tax",
            "taxType": "02",
            "mldSequenceNum": 2,
            "taxSurcharge": "T"
          }
        ],
        "subTotalDueTodayWithoutUpgradeFee": 698.95,
        "subTotalDueMonthlyForAALBYODEUP": 121.0,
        "shipTogetherPref": true,
        "assistanceOptedByCustomer": false,
        "locationState": "NJ",
        "totalVerizonDollarUsed": "0.0",
        "isShellAccountSelected": false,
        "fullfillmentLocation": "1000001",
        "guestOrInactiveRefundLines": false,
        "totalDueMonthlyOnProfile": 0.0,
        "subTotalDueMonthlyOnProfile": 0.0,
        "totalMonthlyTaxesOnProfile": 0.0,
        "subTotalOtherLinesOnProfile": 0.0,
        "estimatedNextMonthChargeOnProfile": 0.0,
        "originalSubTotalDueMonthly": 423.3,
        "totalDueMonthlyAfterDiscounts": 307.05,
        "accessoryFinancingOfferInfo": {
          "installmentTerm": "12",
          "installmentInfo": {
            "monthlyInstallment": 0.0,
            "accessoryTotal": 751.37
          },
          "offerEligibleAmount": 100.0,
          "offerExpiryDate": "12/31/2025",
          "offerDisQualifiedAfterRemoveAcc": false,
          "dfoInstallmentInfo": {
            "monthlyInstallment": 0.0,
            "dfoDevicesTotal": 0.0,
            "installmentTerm": "36",
            "dfoTotalSalesTax": 0.0
          },
          "splitPaymentInfo": [
            {
              "orderNumber": "22004373",
              "nonAccessoryTotal": 62.25,
              "accessoryTotal": 751.37,
              "totalFinanceAmount": 0.0,
              "monthlyFinanceAmount": 0.0,
              "isAfo": true,
              "isDfo": false
            }
          ],
          "offerAvailable": true,
          "customerEligible": true,
          "offerAccepted": false,
          "disclosureAgreementSent": false
        },
        "totalTaxAdjustmentAmount": 0.0,
        "totalActivationFees": 0.0,
        "fiveGHomeOrder": false,
        "totalRefundAmount": 0.0,
        "totalExchangeAmount": 0.0,
        "totalRefundTaxAmount": 0.0,
        "totalExchangeTaxAmount": 0.0,
        "digitalExchange": false,
        "remainingAmountAfterAffirmApplied": 0.0,
        "cashOptionEnabled": false,
        "affirmCreditCheckFailed": false,
        "payTodayWithoutDfo": 813.62,
        "orderType": "PS",
        "locationCode": "0026301",
        "customerType": "U",
        "billingSystem": "VE",
        "totalTaxAmount": "114.67",
        "chargeSummary": [
          {
            "chargeType": "ActivationFee",
            "amount": 35.0,
            "finalPrice": 35.0
          }
        ],
        "spocs": {
          "notificationOptions": {
            "contactPhoneNumber": "9703050307",
            "primaryEmailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM"
          }
        },
        "totalDueToday": 813.62,
        "runningTotalDueToday": 813.62,
        "totalDueTodayFlag": false,
        "totalDueMonthly": 325.8,
        "subTotalDueMonthly": 307.05,
        "subTotalDueToday": 698.95,
        "subTotalMonthlyTaxes": 0.0,
        "estimatedNextMonthCharge": 517.99,
        "totalMonthlyTaxes": 18.75,
        "subTotalOtherLines": 133.83,
        "subTotalOtherLinesTaxes": 0.0,
        "instantDRCCredit": false,
        "isAttachmentCompleted": false,
        "nextMonthBillTotal": 0.0,
        "customerNotification": {
          "smsLanguage": "E"
        },
        "effectiveDateDetails": {
          "suggestedBackDate": "",
          "suggestedFutureDate": "",
          "currentBillCycleBeginDate": "10/06/2024",
          "nextBillCycleBeginDate": "11/06/2024",
          "onDemandDate": "10/14/2024",
          "onDemandRangeInDays": "45",
          "selectedDate": "10/14/2024",
          "onDemandAllowed": true,
          "backDateAllowed": false,
          "futureDateAllowed": false
        },
        "orderChannelId": "OMNI-RETAIL",
        "orderList": [
          {
            "creditApplication": {
              "creditApplicationNum": 414220049,
              "creditApprovalStatus": "AP",
              "creditStatusReason": "CA Customer Systematic Approval",
              "internationalEligibility": true,
              "securityDepositAmount": "0",
              "serviceClass": "B",
              "lineCreditClass": "1D",
              "creditAppEdited": false
            },
            "orderActivityType": "EUP",
            "orderNumber": 0,
            "numOfLinesForOrderActivityType": 0,
            "preOrderNumber": 0,
            "digitalOrderId": 0,
            "managerApprovalRequired": false
          },
          {
            "orderActivityType": "ACC",
            "orderNumber": 22004358,
            "numOfLinesForOrderActivityType": 0,
            "preOrderNumber": 0,
            "digitalOrderId": 994734874731161,
            "managerApprovalRequired": false
          },
          {
            "creditApplication": {
              "creditApplicationNum": 411220050,
              "creditApprovalStatus": "AP",
              "creditStatusReason": "CA Customer Systematic Approval",
              "internationalEligibility": false,
              "creditAdvisory": "APP 411220050 APPROVED  - WITH NO DEPOSIT REQUIRED 'B '",
              "securityDepositAmount": "0",
              "serviceClass": "B",
              "lineCreditClass": "1D",
              "creditAppEdited": false
            },
            "orderActivityType": "AAL_5G",
            "orderNumber": 22004369,
            "numOfLinesForOrderActivityType": 1,
            "preOrderNumber": 0,
            "digitalOrderId": 0,
            "managerApprovalRequired": false
          },
          {
            "creditApplication": {
              "creditApplicationNum": 410220052,
              "creditApprovalStatus": "AP",
              "creditStatusReason": "CA Customer Systematic Approval",
              "internationalEligibility": false,
              "creditAdvisory": "APP 410220052 APPROVED  - WITH NO DEPOSIT REQUIRED 'B '",
              "securityDepositAmount": "0",
              "serviceClass": "B",
              "lineCreditClass": "1D",
              "creditAppEdited": false
            },
            "orderActivityType": "AAL",
            "orderNumber": 22004373,
            "numOfLinesForOrderActivityType": 2,
            "preOrderNumber": 0,
            "digitalOrderId": 0,
            "managerApprovalRequired": false
          }
        ],
        "outletId": "000000263",
        "registerNumber": "51",
        "saleType": "P",
        "salesRepId": "ENC",
        "enableSplitShipment": false,
        "splitShipmentIndicator": false,
        "cartReadyForCheckout": true,
        "isSingleModConnectedDevice": false,
        "fiveGUpSellAccountLevel": false,
        "customerOnTrialPlan": false,
        "availableSlotsForGrantee": "0",
        "totalDownPaymentAmt": 0.0,
        "totalEdgeBuyOutAmount": 0.0,
        "expressCheckout": false,
        "nbxInfo": {
          "isPreQualifiedNBX": true,
          "syfOfferId": "8806908917",
          "propositionMessage": "Thank You! You have been Pre-Approved.Sign up and receive: $100 sign up bonus and more",
          "propositionName": "Pre-Qualified - Transaction Flow",
          "propositionId": "GC_01",
          "vzccFeedbackStatus": "DECLINED",
          "isVZCCHolder": false,
          "sessionId": "6558661564718555627",
          "soiEngagementId": "501002526",
          "isPreScreenRepresentment": "N"
        },
        "isEQPandPPLOfferApplied": false,
        "cartTotalDiscounts": {
          "totalDiscount": "0.0",
          "barCodeOfferAppliedOnOrder": false,
          "discountDetails": []
        },
        "memberTotalDueToday": 0.0,
        "customerConsent": "Y",
        "totalDwosCost": "0.0",
        "billingState": "FL",
        "isTradeInOfferSelected": false,
        "isAssignMtnRequired": false,
        "fiosCapable": false,
        "fiosEligible": false,
        "quoteWithoutCredit": false,
        "uswinAuthenticationRequired": true,
        "newPreToPostInfo": {
          "newPreToPostIndicator": "E",
          "newPreToPostMtns": {
            "accountOwner": "",
            "accountMembers": []
          }
        },
        "totalDueTodayWithoutDiscount": 813.62,
        "subTotalDueTodayWithoutDiscount": 698.95,
        "isComboOrder": "Y",
        "totalPerksSavings": "0.0"
      },
      "lineDetails": {
        "lineInfo": [
          {
            "isCommonPDP": false,
            "isTradeInIntentSelected": false,
            "multiLineSeqNumber": 3,
            "lineActivityType": "ACC",
            "totalDueToday": 353.66,
            "totalDueTodayWithoutTax": 328.99,
            "totalDueTodayWithoutTaxWithoutDiscount": 328.99,
            "totalDueMonthly": 133.83,
            "mobileNumber": "8133477604",
            "showGlobalChoiceOffer": false,
            "serviceInfo": {
              "planDiscount": {
                "planEligibleForAutoPayPaperLessDiscount": false,
                "discountIncluded": false,
                "totalPlanCostIncludingLineAccessFee": "0.0"
              },
              "serviceAddress": {
                "addressLine1": "6013 PORTSDALE PL UNIT 201",
                "addressLine2": "",
                "zipCode": "33578",
                "zipCode4": "4097",
                "firstName": "DON",
                "lastName": "WRIGHT",
                "city": "RIVERVIEW",
                "state": "FL"
              },
              "comparePlan": false,
              "primaryUserInfo": {
                "firstName": "DON",
                "lastName": "WRIGHT",
                "address": {
                  "firmName": "",
                  "apartmentNo": "201",
                  "type": "PL",
                  "streetNumber": "6013",
                  "streetName": "PORTSDALE",
                  "addressLine2": "",
                  "addressLine1": "6013 PORTSDALE PL UNIT 201",
                  "poBoxNo": "",
                  "ruralRouteNo": "",
                  "ruralDelNo": "",
                  "city": "RIVERVIEW",
                  "state": "FL",
                  "zipCode": "33578",
                  "zipCode4": "4097",
                  "county": "",
                  "countryCode": "US",
                  "fipsCode": "1205760950",
                  "firstName": "DON",
                  "lastName": "WRIGHT",
                  "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                  "phoneNumber": "9089349238",
                  "streetType": "PL",
                  "streetDirection": ""
                },
                "isValidAddress": true,
                "bsnsName": "",
                "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                "midInitials": ""
              },
              "mtn": "8133477604",
              "min": "8132580300",
              "oldPricePlanId": "50430",
              "contractTermId": "48",
              "currentDevice": {
                "oldLteVoraEquipInfo": {
                  "iccid": "89148000009826583322",
                  "lteVoraDeviceInfo": {
                    "deviceId": "352865677734782",
                    "deviceType": "5GE",
                    "deviceSku": "CLNRAPL13PM128SB",
                    "description": "IPHONE 13 PRO MAX 128 SR BLU",
                    "imageUrlMap": {
                      "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue",
                      "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-lg$",
                      "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-med$",
                      "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-mini$",
                      "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-thumb$"
                    },
                    "color": {},
                    "manufacturer": "Apple"
                  }
                }
              },
              "isSharePlanAdded": false,
              "mea": "V0T",
              "isE911AddressValidated": false,
              "oldPlanFlag": "L",
              "orderDevice": {
                "lteVoraEquipInfo": {
                  "lteEqpt": {},
                  "lteVoraDeviceInfo": {}
                }
              },
              "kidsPlanParentMtn": false,
              "mcsSubscription": [],
              "fiveGUpSell": false,
              "e911AddressSameAsServiceAddress": false,
              "unpairedGrantor": false,
              "totalAddedFeaturesPrice": "0.0"
            },
            "itemsInfo": [
              {
                "depletionType": "F",
                "attention": "DON WRIGHT",
                "shipping": {
                  "address": {
                    "firmName": "",
                    "apartmentNo": "201",
                    "type": "R",
                    "streetNumber": "6013",
                    "streetName": "PORTSDALE",
                    "addressLine2": "",
                    "addressLine1": "6013 PORTSDALE PL UNIT 201",
                    "poBoxNo": "",
                    "ruralDelNo": "",
                    "city": "RIVERVIEW",
                    "state": "FL",
                    "zipCode": "33578",
                    "zipCode4": "4097",
                    "county": "",
                    "countryCode": "",
                    "fipsCode": "1205760950",
                    "firstName": "DON",
                    "lastName": "WRIGHT",
                    "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                    "phoneNumber": "9089349238",
                    "streetType": "PL",
                    "streetDirection": ""
                  },
                  "bsnsName": "",
                  "shippingCode": "SHP002",
                  "shippingCost": "0.00",
                  "shippingDescription": "Free 2 Day by 8pm",
                  "cbrPhone": "9089349238",
                  "firstName": "DON",
                  "lastName": "WRIGHT",
                  "midInitials": "",
                  "isUseUnVerifiedAddress": false,
                  "isValidAddress": false,
                  "email": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                  "shipToCustomerAddress": false
                },
                "fipsCode": "1205760950",
                "itemCount": 2,
                "itemTabSeqNum": 0,
                "cartItems": {
                  "cartItem": [
                    {
                      "discountAmount": 0.0,
                      "deviceDollarApplied": 0.0,
                      "promoHubOfferList": {
                        "promoHubOfferList": [],
                        "offerCount": 0
                      },
                      "qrScanNeededForEsimActivation": false,
                      "isPreconfigureDuringAddDevice": false,
                      "deviceDisplayName": "AirPods 4 with Active Noise Cancellation",
                      "accessoryGiftCardAmount": 0.0,
                      "tradeInAmountTowardsUserDPUsed": 0.0,
                      "sorDeviceCategory": "Bluetooth Headphones",
                      "vendingKioskItem": "false",
                      "tradeInAutoPull": false,
                      "priceAdjustment": false,
                      "priceAdjustmentQty": 0,
                      "newPurchasedQty": 1,
                      "canonicalUrl": "products/apple-airpods-4-with-active-noise-cancellation/",
                      "selectedForRFEX": false,
                      "selectedForPAD": false,
                      "bogoItem": false,
                      "refxItemSeqNum": 0,
                      "restrictedAccySku": false,
                      "maxAccyPurchaseLimit": false,
                      "giftCard": false,
                      "itemCode": "MXP93LL/A",
                      "totalPriceWithDiscount": 179.0,
                      "sorId": "MXP93LL/A",
                      "skuId": "sku6016076",
                      "cartItemType": "ACCESSORY",
                      "description": "AirPods 4 with Active Noise Cancellation",
                      "qty": 1,
                      "bundleSeqNum": 0,
                      "itemPrice": "179.00",
                      "discountedPercentage": 0.0,
                      "discountedPrice": 179.0,
                      "buyOutTaxAmountUnbilled": 0.0,
                      "buyOutAmountWithoutTax": 0.0,
                      "taxAmount": 13.42,
                      "imageUrlMap": {
                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset",
                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-lg$",
                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-med$",
                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-mini$",
                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-thumb$"
                      },
                      "prodCode1": "GIF",
                      "prodCode2": "SER",
                      "prodCode3": "OEM",
                      "prodCode4": "000",
                      "prodCode5": "000",
                      "btaEligible": "true",
                      "depletionType": "F",
                      "catalogPrice": 179.0,
                      "instantCreditAmountUsed": 0.0,
                      "instantCreditAmountUsedForTaxes": 0.0,
                      "color": {
                        "color": "#F9F8F3",
                        "colorDisplayName": "WHITE"
                      },
                      "unitTaxBasedPrice": 179.0,
                      "itemNrpPrice": 179.0,
                      "discounts": [],
                      "availableReasonCode": [],
                      "inventory": {
                        "isAvailable": true,
                        "isBackorder": false,
                        "isDeliverBy": false,
                        "isPreOrder": false,
                        "qtyAvailable": 1426,
                        "isShipBy": false
                      },
                      "isCustomerProvidedSIM": false,
                      "isNetworkExtender": false,
                      "ispuEligible": true,
                      "itemSeqNum": 11,
                      "sddEligible": true,
                      "smartIMEI": false,
                      "year": 0,
                      "sellerPrice": "0.0",
                      "productId": "acc20893304",
                      "taxDetailsList": [
                        {
                          "taxSequenceNum": 1,
                          "taxPassType": "10",
                          "taxAmount": "10.74",
                          "taxDescription": "FL State Sales Tax",
                          "taxType": "01",
                          "mldSequenceNum": 1,
                          "taxSurcharge": "T"
                        },
                        {
                          "taxSequenceNum": 2,
                          "taxPassType": "20",
                          "taxAmount": "2.68",
                          "taxDescription": "Hillsborough Cnty Sales Tax",
                          "taxType": "02",
                          "mldSequenceNum": 2,
                          "taxSurcharge": "T"
                        }
                      ],
                      "manufacturer": "Apple",
                      "quantityOnHand": 1426,
                      "iconicPhone": false,
                      "ringBell": false,
                      "isPreconfigureEnabled": false,
                      "isHumDevice": false,
                      "isSmartLocator": false,
                      "isSecurityAlarm": false,
                      "isMotoMod": false,
                      "isConnectedCar": false,
                      "accountLevelAccessory": false,
                      "byodESimPhone": false,
                      "scannedItem": false,
                      "appleCareAccessoryFlag": false,
                      "quantityAllowed": true,
                      "isDfoSelected": false
                    },
                    {
                      "discountAmount": 0.0,
                      "deviceDollarApplied": 0.0,
                      "promoHubOfferList": {
                        "promoHubOfferList": [],
                        "offerCount": 0
                      },
                      "qrScanNeededForEsimActivation": false,
                      "isPreconfigureDuringAddDevice": false,
                      "deviceDisplayName": "Soundgear Sense Open-Ear Headphones - Black",
                      "accessoryGiftCardAmount": 0.0,
                      "tradeInAmountTowardsUserDPUsed": 0.0,
                      "sorDeviceCategory": "Bluetooth Headphones",
                      "vendingKioskItem": "false",
                      "tradeInAutoPull": false,
                      "priceAdjustment": false,
                      "priceAdjustmentQty": 0,
                      "newPurchasedQty": 1,
                      "canonicalUrl": "products/jbl-soundgear-sense-open-ear-headphones/",
                      "selectedForRFEX": false,
                      "selectedForPAD": false,
                      "bogoItem": false,
                      "refxItemSeqNum": 0,
                      "restrictedAccySku": false,
                      "maxAccyPurchaseLimit": false,
                      "giftCard": false,
                      "itemCode": "JBLSNDGEARSNSBLKAM",
                      "totalPriceWithDiscount": 149.99,
                      "sorId": "JBLSNDGEARSNSBLKAM",
                      "skuId": "sku6013494",
                      "cartItemType": "ACCESSORY",
                      "description": "Soundgear Sense Open-Ear Headphones - Black",
                      "qty": 1,
                      "bundleSeqNum": 0,
                      "itemPrice": "149.99",
                      "discountedPercentage": 0.0,
                      "discountedPrice": 149.99,
                      "buyOutTaxAmountUnbilled": 0.0,
                      "buyOutAmountWithoutTax": 0.0,
                      "taxAmount": 11.25,
                      "imageUrlMap": {
                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset",
                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-lg$",
                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-med$",
                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-mini$",
                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-thumb$"
                      },
                      "prodCode1": "ACC",
                      "prodCode2": "BLU",
                      "prodCode3": "OEM",
                      "prodCode4": "000",
                      "prodCode5": "000",
                      "btaEligible": "true",
                      "depletionType": "F",
                      "catalogPrice": 149.99,
                      "instantCreditAmountUsed": 0.0,
                      "instantCreditAmountUsedForTaxes": 0.0,
                      "color": {
                        "color": "#000000",
                        "colorDisplayName": "BLACK"
                      },
                      "unitTaxBasedPrice": 149.99,
                      "itemNrpPrice": 149.99,
                      "discounts": [],
                      "availableReasonCode": [],
                      "inventory": {
                        "isAvailable": true,
                        "isBackorder": false,
                        "isDeliverBy": false,
                        "isPreOrder": false,
                        "qtyAvailable": 1018,
                        "isShipBy": false
                      },
                      "isCustomerProvidedSIM": false,
                      "isNetworkExtender": false,
                      "ispuEligible": true,
                      "itemSeqNum": 12,
                      "sddEligible": true,
                      "smartIMEI": false,
                      "year": 0,
                      "sellerPrice": "0.0",
                      "productId": "acc20892292",
                      "taxDetailsList": [
                        {
                          "taxSequenceNum": 1,
                          "taxPassType": "10",
                          "taxAmount": "9.00",
                          "taxDescription": "FL State Sales Tax",
                          "taxType": "01",
                          "mldSequenceNum": 1,
                          "taxSurcharge": "T"
                        },
                        {
                          "taxSequenceNum": 2,
                          "taxPassType": "20",
                          "taxAmount": "2.25",
                          "taxDescription": "Hillsborough Cnty Sales Tax",
                          "taxType": "02",
                          "mldSequenceNum": 2,
                          "taxSurcharge": "T"
                        }
                      ],
                      "manufacturer": "JBL",
                      "quantityOnHand": 0,
                      "iconicPhone": false,
                      "ringBell": false,
                      "isPreconfigureEnabled": false,
                      "isHumDevice": false,
                      "isSmartLocator": false,
                      "isSecurityAlarm": false,
                      "isMotoMod": false,
                      "isConnectedCar": false,
                      "accountLevelAccessory": false,
                      "byodESimPhone": false,
                      "scannedItem": false,
                      "appleCareAccessoryFlag": false,
                      "quantityAllowed": true,
                      "isDfoSelected": false
                    },
                    {
                      "discountAmount": 0.0,
                      "deviceDollarApplied": 0.0,
                      "qrScanNeededForEsimActivation": false,
                      "isPreconfigureDuringAddDevice": false,
                      "accessoryGiftCardAmount": 0.0,
                      "tradeInAmountTowardsUserDPUsed": 0.0,
                      "vendingKioskItem": "false",
                      "tradeInAutoPull": false,
                      "priceAdjustment": false,
                      "priceAdjustmentQty": 0,
                      "newPurchasedQty": 0,
                      "selectedForRFEX": false,
                      "selectedForPAD": false,
                      "bogoItem": false,
                      "refxItemSeqNum": 0,
                      "restrictedAccySku": false,
                      "maxAccyPurchaseLimit": false,
                      "giftCard": false,
                      "itemCode": "SHP002",
                      "totalPriceWithDiscount": 0.0,
                      "sorId": "SHP002",
                      "cartItemType": "SHIPPING",
                      "mobileNumber": "8133477604",
                      "description": "Free 2 Day by 8pm",
                      "qty": 1,
                      "bundleSeqNum": 0,
                      "itemPrice": "0.0",
                      "discountedPercentage": 0.0,
                      "discountedPrice": 0.0,
                      "buyOutTaxAmountUnbilled": 0.0,
                      "buyOutAmountWithoutTax": 0.0,
                      "depletionType": "F",
                      "instantCreditAmountUsed": 0.0,
                      "instantCreditAmountUsedForTaxes": 0.0,
                      "itemCost": 0.0,
                      "discounts": [],
                      "availableReasonCode": [],
                      "isCustomerProvidedSIM": false,
                      "isNetworkExtender": false,
                      "ispuEligible": false,
                      "itemSeqNum": 0,
                      "sddEligible": false,
                      "smartIMEI": false,
                      "year": 0,
                      "sellerPrice": "0.0",
                      "taxDetailsList": [],
                      "iconicPhone": false,
                      "ringBell": false,
                      "isPreconfigureEnabled": false,
                      "isHumDevice": false,
                      "isSmartLocator": false,
                      "isSecurityAlarm": false,
                      "isMotoMod": false,
                      "isConnectedCar": false,
                      "accountLevelAccessory": false,
                      "byodESimPhone": false,
                      "appleCareAccessoryFlag": false,
                      "quantityAllowed": false,
                      "isDfoSelected": false
                    },
                    {
                      "discountAmount": 0.0,
                      "deviceDollarApplied": 0.0,
                      "promoHubOfferList": {
                        "promoHubOfferList": [],
                        "offerCount": 0
                      },
                      "qrScanNeededForEsimActivation": false,
                      "isPreconfigureDuringAddDevice": false,
                      "deviceDisplayName": "AirPods 4 with Active Noise Cancellation",
                      "accessoryGiftCardAmount": 0.0,
                      "tradeInAmountTowardsUserDPUsed": 0.0,
                      "sorDeviceCategory": "Bluetooth Headphones",
                      "vendingKioskItem": "false",
                      "tradeInAutoPull": false,
                      "priceAdjustment": false,
                      "priceAdjustmentQty": 0,
                      "newPurchasedQty": 1,
                      "canonicalUrl": "products/apple-airpods-4-with-active-noise-cancellation/",
                      "selectedForRFEX": false,
                      "selectedForPAD": false,
                      "bogoItem": false,
                      "refxItemSeqNum": 0,
                      "restrictedAccySku": false,
                      "maxAccyPurchaseLimit": false,
                      "giftCard": false,
                      "itemCode": "MXP93LL/A",
                      "totalPriceWithDiscount": 179.0,
                      "sorId": "MXP93LL/A",
                      "skuId": "sku6016076",
                      "cartItemType": "ACCESSORY",
                      "description": "AirPods 4 with Active Noise Cancellation",
                      "qty": 1,
                      "bundleSeqNum": 0,
                      "itemPrice": "179.00",
                      "discountedPercentage": 0.0,
                      "discountedPrice": 179.0,
                      "buyOutTaxAmountUnbilled": 0.0,
                      "buyOutAmountWithoutTax": 0.0,
                      "taxAmount": 13.42,
                      "imageUrlMap": {
                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset",
                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-lg$",
                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-med$",
                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-mini$",
                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-thumb$"
                      },
                      "prodCode1": "GIF",
                      "prodCode2": "SER",
                      "prodCode3": "OEM",
                      "prodCode4": "000",
                      "prodCode5": "000",
                      "btaEligible": "true",
                      "depletionType": "F",
                      "catalogPrice": 179.0,
                      "instantCreditAmountUsed": 0.0,
                      "instantCreditAmountUsedForTaxes": 0.0,
                      "color": {
                        "color": "#F9F8F3",
                        "colorDisplayName": "WHITE"
                      },
                      "unitTaxBasedPrice": 179.0,
                      "itemNrpPrice": 179.0,
                      "discounts": [],
                      "availableReasonCode": [],
                      "inventory": {
                        "isAvailable": true,
                        "isBackorder": false,
                        "isDeliverBy": false,
                        "isPreOrder": false,
                        "qtyAvailable": 1426,
                        "isShipBy": false
                      },
                      "isCustomerProvidedSIM": false,
                      "isNetworkExtender": false,
                      "ispuEligible": true,
                      "itemSeqNum": 11,
                      "sddEligible": true,
                      "smartIMEI": false,
                      "year": 0,
                      "sellerPrice": "0.0",
                      "productId": "acc20893304",
                      "taxDetailsList": [
                        {
                          "taxSequenceNum": 1,
                          "taxPassType": "10",
                          "taxAmount": "10.74",
                          "taxDescription": "FL State Sales Tax",
                          "taxType": "01",
                          "mldSequenceNum": 1,
                          "taxSurcharge": "T"
                        },
                        {
                          "taxSequenceNum": 2,
                          "taxPassType": "20",
                          "taxAmount": "2.68",
                          "taxDescription": "Hillsborough Cnty Sales Tax",
                          "taxType": "02",
                          "mldSequenceNum": 2,
                          "taxSurcharge": "T"
                        }
                      ],
                      "manufacturer": "Apple",
                      "quantityOnHand": 1426,
                      "iconicPhone": false,
                      "ringBell": false,
                      "isPreconfigureEnabled": false,
                      "isHumDevice": false,
                      "isSmartLocator": false,
                      "isSecurityAlarm": false,
                      "isMotoMod": false,
                      "isConnectedCar": false,
                      "accountLevelAccessory": false,
                      "byodESimPhone": false,
                      "scannedItem": false,
                      "appleCareAccessoryFlag": false,
                      "quantityAllowed": true,
                      "isDfoSelected": false
                    }
                  ]
                },
                "isPromoSelected": false,
                "isTradeInSelected": false,
                "taxExemptionTypes": ""
              }
            ],
            "mtnDetails": {
              "lineNumber": "8133477604",
              "mobileNumber": "8133477604"
            },
            "lineNumber": "8133477604",
            "fiveGToFourGDownGrade": false,
            "lineCreator": "8133477604",
            "amRole": "",
            "lineRefundTotal": 0.0,
            "lineExchangeTotal": 328.99,
            "totalDueMonthlyBeforeCredit": 0.0,
            "sugAllowed": false,
            "totalDueAddOnMonthly": 0.0,
            "totalPriceOfPlanAndPerks": "0.0",
            "isCpe": false,
            "isLTEHomeLine": false,
            "isDevicePlanCompatible": false,
            "portinMtnAssignment": false,
            "impactedLine": false,
            "preOrBackOrder": false,
            "ispuItem": false,
            "ispuItemBYOD": false,
            "isModConnected": false,
            "modDevice": false,
            "byodCapable": false,
            "isCarLine": false,
            "buySimOnly": false,
            "broadBandInd": false,
            "ispuDownPaymentAdjstRequired": false,
            "ispuDownPaymentAmount": 0.0,
            "lineWithSkipMDN": false,
            "protectionNotRequired": false
          },
          
          {
              "isCommonPDP": false,
              "isTradeInIntentSelected": false,
              "multiLineSeqNumber": 3,
              "lineActivityType": "ACC",
              "totalDueToday": 353.66,
              "totalDueTodayWithoutTax": 328.99,
              "totalDueTodayWithoutTaxWithoutDiscount": 328.99,
              "totalDueMonthly": 133.83,
              "mobileNumber": "8133477604",
              "showGlobalChoiceOffer": false,
              "serviceInfo": {
                "planDiscount": {
                  "planEligibleForAutoPayPaperLessDiscount": false,
                  "discountIncluded": false,
                  "totalPlanCostIncludingLineAccessFee": "0.0"
                },
                "serviceAddress": {
                  "addressLine1": "6013 PORTSDALE PL UNIT 201",
                  "addressLine2": "",
                  "zipCode": "33578",
                  "zipCode4": "4097",
                  "firstName": "DON",
                  "lastName": "WRIGHT",
                  "city": "RIVERVIEW",
                  "state": "FL"
                },
                "comparePlan": false,
                "primaryUserInfo": {
                  "firstName": "DON",
                  "lastName": "WRIGHT",
                  "address": {
                    "firmName": "",
                    "apartmentNo": "201",
                    "type": "PL",
                    "streetNumber": "6013",
                    "streetName": "PORTSDALE",
                    "addressLine2": "",
                    "addressLine1": "6013 PORTSDALE PL UNIT 201",
                    "poBoxNo": "",
                    "ruralRouteNo": "",
                    "ruralDelNo": "",
                    "city": "RIVERVIEW",
                    "state": "FL",
                    "zipCode": "33578",
                    "zipCode4": "4097",
                    "county": "",
                    "countryCode": "US",
                    "fipsCode": "1205760950",
                    "firstName": "DON",
                    "lastName": "WRIGHT",
                    "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                    "phoneNumber": "9089349238",
                    "streetType": "PL",
                    "streetDirection": ""
                  },
                  "isValidAddress": true,
                  "bsnsName": "",
                  "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                  "midInitials": ""
                },
                "mtn": "8133477604",
                "min": "8132580300",
                "oldPricePlanId": "50430",
                "contractTermId": "48",
                "currentDevice": {
                  "oldLteVoraEquipInfo": {
                    "iccid": "89148000009826583322",
                    "lteVoraDeviceInfo": {
                      "deviceId": "352865677734782",
                      "deviceType": "5GE",
                      "deviceSku": "CLNRAPL13PM128SB",
                      "description": "IPHONE 13 PRO MAX 128 SR BLU",
                      "imageUrlMap": {
                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue",
                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-lg$",
                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-med$",
                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-mini$",
                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-thumb$"
                      },
                      "color": {},
                      "manufacturer": "Apple"
                    }
                  }
                },
                "isSharePlanAdded": false,
                "mea": "V0T",
                "isE911AddressValidated": false,
                "oldPlanFlag": "L",
                "orderDevice": {
                  "lteVoraEquipInfo": {
                    "lteEqpt": {},
                    "lteVoraDeviceInfo": {}
                  }
                },
                "kidsPlanParentMtn": false,
                "mcsSubscription": [],
                "fiveGUpSell": false,
                "e911AddressSameAsServiceAddress": false,
                "unpairedGrantor": false,
                "totalAddedFeaturesPrice": "0.0"
              },
              "itemsInfo": [
                {
                  "depletionType": "F",
                  "attention": "DON WRIGHT",
                  "shipping": {
                    "address": {
                      "firmName": "",
                      "apartmentNo": "201",
                      "type": "R",
                      "streetNumber": "6013",
                      "streetName": "PORTSDALE",
                      "addressLine2": "",
                      "addressLine1": "6013 PORTSDALE PL UNIT 201",
                      "poBoxNo": "",
                      "ruralDelNo": "",
                      "city": "RIVERVIEW",
                      "state": "FL",
                      "zipCode": "33578",
                      "zipCode4": "4097",
                      "county": "",
                      "countryCode": "",
                      "fipsCode": "1205760950",
                      "firstName": "DON",
                      "lastName": "WRIGHT",
                      "emailId": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                      "phoneNumber": "9089349238",
                      "streetType": "PL",
                      "streetDirection": ""
                    },
                    "bsnsName": "",
                    "shippingCode": "SHP002",
                    "shippingCost": "0.00",
                    "shippingDescription": "Free 2 Day by 8pm",
                    "cbrPhone": "9089349238",
                    "firstName": "DON",
                    "lastName": "WRIGHT",
                    "midInitials": "",
                    "isUseUnVerifiedAddress": false,
                    "isValidAddress": false,
                    "email": "CXT.DOTCOM.REGRESSION@VERIZON.COM",
                    "shipToCustomerAddress": false
                  },
                  "fipsCode": "1205760950",
                  "itemCount": 2,
                  "itemTabSeqNum": 0,
                  "cartItems": {
                    "cartItem": [
                      {
                        "discountAmount": 0.0,
                        "deviceDollarApplied": 0.0,
                        "promoHubOfferList": {
                          "promoHubOfferList": [],
                          "offerCount": 0
                        },
                        "qrScanNeededForEsimActivation": false,
                        "isPreconfigureDuringAddDevice": false,
                        "deviceDisplayName": "AirPods 4 with Active Noise Cancellation",
                        "accessoryGiftCardAmount": 0.0,
                        "tradeInAmountTowardsUserDPUsed": 0.0,
                        "sorDeviceCategory": "Bluetooth Headphones",
                        "vendingKioskItem": "false",
                        "tradeInAutoPull": false,
                        "priceAdjustment": false,
                        "priceAdjustmentQty": 0,
                        "newPurchasedQty": 1,
                        "canonicalUrl": "products/apple-airpods-4-with-active-noise-cancellation/",
                        "selectedForRFEX": false,
                        "selectedForPAD": false,
                        "bogoItem": false,
                        "refxItemSeqNum": 0,
                        "restrictedAccySku": false,
                        "maxAccyPurchaseLimit": false,
                        "giftCard": false,
                        "itemCode": "MXP93LL/A",
                        "totalPriceWithDiscount": 179.0,
                        "sorId": "MXP93LL/A",
                        "skuId": "sku6016076",
                        "cartItemType": "ACCESSORY",
                        "description": "AirPods 4 with Active Noise Cancellation",
                        "qty": 1,
                        "bundleSeqNum": 0,
                        "itemPrice": "179.00",
                        "discountedPercentage": 0.0,
                        "discountedPrice": 179.0,
                        "buyOutTaxAmountUnbilled": 0.0,
                        "buyOutAmountWithoutTax": 0.0,
                        "taxAmount": 13.42,
                        "imageUrlMap": {
                          "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset",
                          "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-lg$",
                          "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-med$",
                          "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-mini$",
                          "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-thumb$"
                        },
                        "prodCode1": "GIF",
                        "prodCode2": "SER",
                        "prodCode3": "OEM",
                        "prodCode4": "000",
                        "prodCode5": "000",
                        "btaEligible": "true",
                        "depletionType": "F",
                        "catalogPrice": 179.0,
                        "instantCreditAmountUsed": 0.0,
                        "instantCreditAmountUsedForTaxes": 0.0,
                        "color": {
                          "color": "#F9F8F3",
                          "colorDisplayName": "WHITE"
                        },
                        "unitTaxBasedPrice": 179.0,
                        "itemNrpPrice": 179.0,
                        "discounts": [],
                        "availableReasonCode": [],
                        "inventory": {
                          "isAvailable": true,
                          "isBackorder": false,
                          "isDeliverBy": false,
                          "isPreOrder": false,
                          "qtyAvailable": 1426,
                          "isShipBy": false
                        },
                        "isCustomerProvidedSIM": false,
                        "isNetworkExtender": false,
                        "ispuEligible": true,
                        "itemSeqNum": 11,
                        "sddEligible": true,
                        "smartIMEI": false,
                        "year": 0,
                        "sellerPrice": "0.0",
                        "productId": "acc20893304",
                        "taxDetailsList": [
                          {
                            "taxSequenceNum": 1,
                            "taxPassType": "10",
                            "taxAmount": "10.74",
                            "taxDescription": "FL State Sales Tax",
                            "taxType": "01",
                            "mldSequenceNum": 1,
                            "taxSurcharge": "T"
                          },
                          {
                            "taxSequenceNum": 2,
                            "taxPassType": "20",
                            "taxAmount": "2.68",
                            "taxDescription": "Hillsborough Cnty Sales Tax",
                            "taxType": "02",
                            "mldSequenceNum": 2,
                            "taxSurcharge": "T"
                          }
                        ],
                        "manufacturer": "Apple",
                        "quantityOnHand": 1426,
                        "iconicPhone": false,
                        "ringBell": false,
                        "isPreconfigureEnabled": false,
                        "isHumDevice": false,
                        "isSmartLocator": false,
                        "isSecurityAlarm": false,
                        "isMotoMod": false,
                        "isConnectedCar": false,
                        "accountLevelAccessory": false,
                        "byodESimPhone": false,
                        "scannedItem": false,
                        "appleCareAccessoryFlag": false,
                        "quantityAllowed": true,
                        "isDfoSelected": false
                      },
                      {
                        "discountAmount": 0.0,
                        "deviceDollarApplied": 0.0,
                        "promoHubOfferList": {
                          "promoHubOfferList": [],
                          "offerCount": 0
                        },
                        "qrScanNeededForEsimActivation": false,
                        "isPreconfigureDuringAddDevice": false,
                        "deviceDisplayName": "Soundgear Sense Open-Ear Headphones - Black",
                        "accessoryGiftCardAmount": 0.0,
                        "tradeInAmountTowardsUserDPUsed": 0.0,
                        "sorDeviceCategory": "Bluetooth Headphones",
                        "vendingKioskItem": "false",
                        "tradeInAutoPull": false,
                        "priceAdjustment": false,
                        "priceAdjustmentQty": 0,
                        "newPurchasedQty": 1,
                        "canonicalUrl": "products/jbl-soundgear-sense-open-ear-headphones/",
                        "selectedForRFEX": false,
                        "selectedForPAD": false,
                        "bogoItem": false,
                        "refxItemSeqNum": 0,
                        "restrictedAccySku": false,
                        "maxAccyPurchaseLimit": false,
                        "giftCard": false,
                        "itemCode": "JBLSNDGEARSNSBLKAM",
                        "totalPriceWithDiscount": 149.99,
                        "sorId": "JBLSNDGEARSNSBLKAM",
                        "skuId": "sku6013494",
                        "cartItemType": "ACCESSORY",
                        "description": "Soundgear Sense Open-Ear Headphones - Black",
                        "qty": 1,
                        "bundleSeqNum": 0,
                        "itemPrice": "149.99",
                        "discountedPercentage": 0.0,
                        "discountedPrice": 149.99,
                        "buyOutTaxAmountUnbilled": 0.0,
                        "buyOutAmountWithoutTax": 0.0,
                        "taxAmount": 11.25,
                        "imageUrlMap": {
                          "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset",
                          "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-lg$",
                          "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-med$",
                          "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-mini$",
                          "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-thumb$"
                        },
                        "prodCode1": "ACC",
                        "prodCode2": "BLU",
                        "prodCode3": "OEM",
                        "prodCode4": "000",
                        "prodCode5": "000",
                        "btaEligible": "true",
                        "depletionType": "F",
                        "catalogPrice": 149.99,
                        "instantCreditAmountUsed": 0.0,
                        "instantCreditAmountUsedForTaxes": 0.0,
                        "color": {
                          "color": "#000000",
                          "colorDisplayName": "BLACK"
                        },
                        "unitTaxBasedPrice": 149.99,
                        "itemNrpPrice": 149.99,
                        "discounts": [],
                        "availableReasonCode": [],
                        "inventory": {
                          "isAvailable": true,
                          "isBackorder": false,
                          "isDeliverBy": false,
                          "isPreOrder": false,
                          "qtyAvailable": 1018,
                          "isShipBy": false
                        },
                        "isCustomerProvidedSIM": false,
                        "isNetworkExtender": false,
                        "ispuEligible": true,
                        "itemSeqNum": 12,
                        "sddEligible": true,
                        "smartIMEI": false,
                        "year": 0,
                        "sellerPrice": "0.0",
                        "productId": "acc20892292",
                        "taxDetailsList": [
                          {
                            "taxSequenceNum": 1,
                            "taxPassType": "10",
                            "taxAmount": "9.00",
                            "taxDescription": "FL State Sales Tax",
                            "taxType": "01",
                            "mldSequenceNum": 1,
                            "taxSurcharge": "T"
                          },
                          {
                            "taxSequenceNum": 2,
                            "taxPassType": "20",
                            "taxAmount": "2.25",
                            "taxDescription": "Hillsborough Cnty Sales Tax",
                            "taxType": "02",
                            "mldSequenceNum": 2,
                            "taxSurcharge": "T"
                          }
                        ],
                        "manufacturer": "JBL",
                        "quantityOnHand": 0,
                        "iconicPhone": false,
                        "ringBell": false,
                        "isPreconfigureEnabled": false,
                        "isHumDevice": false,
                        "isSmartLocator": false,
                        "isSecurityAlarm": false,
                        "isMotoMod": false,
                        "isConnectedCar": false,
                        "accountLevelAccessory": false,
                        "byodESimPhone": false,
                        "scannedItem": false,
                        "appleCareAccessoryFlag": false,
                        "quantityAllowed": true,
                        "isDfoSelected": false
                      },
                      {
                        "discountAmount": 0.0,
                        "deviceDollarApplied": 0.0,
                        "qrScanNeededForEsimActivation": false,
                        "isPreconfigureDuringAddDevice": false,
                        "accessoryGiftCardAmount": 0.0,
                        "tradeInAmountTowardsUserDPUsed": 0.0,
                        "vendingKioskItem": "false",
                        "tradeInAutoPull": false,
                        "priceAdjustment": false,
                        "priceAdjustmentQty": 0,
                        "newPurchasedQty": 0,
                        "selectedForRFEX": false,
                        "selectedForPAD": false,
                        "bogoItem": false,
                        "refxItemSeqNum": 0,
                        "restrictedAccySku": false,
                        "maxAccyPurchaseLimit": false,
                        "giftCard": false,
                        "itemCode": "SHP002",
                        "totalPriceWithDiscount": 0.0,
                        "sorId": "SHP002",
                        "cartItemType": "SHIPPING",
                        "mobileNumber": "8133477604",
                        "description": "Free 2 Day by 8pm",
                        "qty": 1,
                        "bundleSeqNum": 0,
                        "itemPrice": "0.0",
                        "discountedPercentage": 0.0,
                        "discountedPrice": 0.0,
                        "buyOutTaxAmountUnbilled": 0.0,
                        "buyOutAmountWithoutTax": 0.0,
                        "depletionType": "F",
                        "instantCreditAmountUsed": 0.0,
                        "instantCreditAmountUsedForTaxes": 0.0,
                        "itemCost": 0.0,
                        "discounts": [],
                        "availableReasonCode": [],
                        "isCustomerProvidedSIM": false,
                        "isNetworkExtender": false,
                        "ispuEligible": false,
                        "itemSeqNum": 0,
                        "sddEligible": false,
                        "smartIMEI": false,
                        "year": 0,
                        "sellerPrice": "0.0",
                        "taxDetailsList": [],
                        "iconicPhone": false,
                        "ringBell": false,
                        "isPreconfigureEnabled": false,
                        "isHumDevice": false,
                        "isSmartLocator": false,
                        "isSecurityAlarm": false,
                        "isMotoMod": false,
                        "isConnectedCar": false,
                        "accountLevelAccessory": false,
                        "byodESimPhone": false,
                        "appleCareAccessoryFlag": false,
                        "quantityAllowed": false,
                        "isDfoSelected": false
                      },
                      {
                        "discountAmount": 0.0,
                        "deviceDollarApplied": 0.0,
                        "promoHubOfferList": {
                          "promoHubOfferList": [],
                          "offerCount": 0
                        },
                        "qrScanNeededForEsimActivation": false,
                        "isPreconfigureDuringAddDevice": false,
                        "deviceDisplayName": "AirPods 4 with Active Noise Cancellation",
                        "accessoryGiftCardAmount": 0.0,
                        "tradeInAmountTowardsUserDPUsed": 0.0,
                        "sorDeviceCategory": "Bluetooth Headphones",
                        "vendingKioskItem": "false",
                        "tradeInAutoPull": false,
                        "priceAdjustment": false,
                        "priceAdjustmentQty": 0,
                        "newPurchasedQty": 1,
                        "canonicalUrl": "products/apple-airpods-4-with-active-noise-cancellation/",
                        "selectedForRFEX": false,
                        "selectedForPAD": false,
                        "bogoItem": false,
                        "refxItemSeqNum": 0,
                        "restrictedAccySku": false,
                        "maxAccyPurchaseLimit": false,
                        "giftCard": false,
                        "itemCode": "MXP93LL/A",
                        "totalPriceWithDiscount": 179.0,
                        "sorId": "MXP93LL/A",
                        "skuId": "sku6016076",
                        "cartItemType": "ACCESSORY",
                        "description": "AirPods 4 with Active Noise Cancellation",
                        "qty": 1,
                        "bundleSeqNum": 0,
                        "itemPrice": "179.00",
                        "discountedPercentage": 0.0,
                        "discountedPrice": 179.0,
                        "buyOutTaxAmountUnbilled": 0.0,
                        "buyOutAmountWithoutTax": 0.0,
                        "taxAmount": 13.42,
                        "imageUrlMap": {
                          "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset",
                          "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-lg$",
                          "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-med$",
                          "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-mini$",
                          "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/mxp93ll-a-iset?$acc-thumb$"
                        },
                        "prodCode1": "TAX",
                        "prodCode2": "SPC",
                        "prodCode3": "OEM",
                        "prodCode4": "000",
                        "prodCode5": "000",
                        "btaEligible": "true",
                        "depletionType": "F",
                        "catalogPrice": 179.0,
                        "instantCreditAmountUsed": 0.0,
                        "instantCreditAmountUsedForTaxes": 0.0,
                        "color": {
                          "color": "#F9F8F3",
                          "colorDisplayName": "WHITE"
                        },
                        "unitTaxBasedPrice": 179.0,
                        "itemNrpPrice": 179.0,
                        "discounts": [],
                        "availableReasonCode": [],
                        "inventory": {
                          "isAvailable": true,
                          "isBackorder": false,
                          "isDeliverBy": false,
                          "isPreOrder": false,
                          "qtyAvailable": 1426,
                          "isShipBy": false
                        },
                        "isCustomerProvidedSIM": false,
                        "isNetworkExtender": false,
                        "ispuEligible": true,
                        "itemSeqNum": 11,
                        "sddEligible": true,
                        "smartIMEI": false,
                        "year": 0,
                        "sellerPrice": "0.0",
                        "productId": "acc20893304",
                        "taxDetailsList": [
                          {
                            "taxSequenceNum": 1,
                            "taxPassType": "10",
                            "taxAmount": "10.74",
                            "taxDescription": "FL State Sales Tax",
                            "taxType": "01",
                            "mldSequenceNum": 1,
                            "taxSurcharge": "T"
                          },
                          {
                            "taxSequenceNum": 2,
                            "taxPassType": "20",
                            "taxAmount": "2.68",
                            "taxDescription": "Hillsborough Cnty Sales Tax",
                            "taxType": "02",
                            "mldSequenceNum": 2,
                            "taxSurcharge": "T"
                          }
                        ],
                        "manufacturer": "Apple",
                        "quantityOnHand": 1426,
                        "iconicPhone": false,
                        "ringBell": false,
                        "isPreconfigureEnabled": false,
                        "isHumDevice": false,
                        "isSmartLocator": false,
                        "isSecurityAlarm": false,
                        "isMotoMod": false,
                        "isConnectedCar": false,
                        "accountLevelAccessory": false,
                        "byodESimPhone": false,
                        "scannedItem": false,
                        "appleCareAccessoryFlag": false,
                        "quantityAllowed": true,
                        "isDfoSelected": false
                      }
                    ]
                  },
                  "isPromoSelected": false,
                  "isTradeInSelected": false,
                  "taxExemptionTypes": ""
                }
              ],
              "mtnDetails": {
                "lineNumber": "8133477604",
                "mobileNumber": "8133477604"
              },
              "lineNumber": "8133477604",
              "fiveGToFourGDownGrade": false,
              "lineCreator": "8133477604",
              "amRole": "",
              "lineRefundTotal": 0.0,
              "lineExchangeTotal": 328.99,
              "totalDueMonthlyBeforeCredit": 0.0,
              "sugAllowed": false,
              "totalDueAddOnMonthly": 0.0,
              "totalPriceOfPlanAndPerks": "0.0",
              "isCpe": false,
              "isLTEHomeLine": false,
              "isDevicePlanCompatible": false,
              "portinMtnAssignment": false,
              "impactedLine": false,
              "preOrBackOrder": false,
              "ispuItem": false,
              "ispuItemBYOD": false,
              "isModConnected": false,
              "modDevice": false,
              "byodCapable": false,
              "isCarLine": false,
              "buySimOnly": false,
              "broadBandInd": false,
              "ispuDownPaymentAdjstRequired": false,
              "ispuDownPaymentAmount": 0.0,
              "lineWithSkipMDN": false,
              "protectionNotRequired": false
            }
        ],
        "numOfAccessoryAndDeviceItemsInCart": 6,
        "totalEdgeUpAmount": 0.0,
        "totalEdgeBuyOutAmount": 0.0,
        "tradeInDetail": {},
        "totalDownPaymentAmt": 0.0,
        "numOfLinesWithDevices": 2,
        "discountGainIndicators": [],
        "discountLossIndicators": [],
        "subscriptionInfos": [],
        "numofApprovedLines": 0,
        "rfexPayments": [],
        "numOfLines": 4,
        "numofLinesAAL": 2,
        "numofLinesEUP": 0,
        "payments": [],
        "lineSeq": 0,
        "vlcactivePhoneCount": 0,
        "fivegOrderind": true,
        "aceOrderCreated": true,
        "serviceLinesCreated": false,
        "aceItemsModified": true,
        "enableLineInfoFFlag": true,
        "clnrOrderFlag": false,
        "broadbandInd": false,
        "isAutoPayEnrolled": "N",
        "isAutoPayPaperLessDiscountEligible": "Y",
        "isPaperLessEnrolled": "Y",
        "totalEligibleAutoPayPaperLessDiscount": "25.00",
        "tabletJetpackDiscountMultiLineLoss": "N",
        "acctMcsSubscription": [],
        "spendingLimitAmountExceededBy": "0.0",
        "numofAccessories": 4,
        "subAccountNBSInfo": [
          {
            "billAccounts": [
              {
                "billSummary": {
                  "grandTotal": {
                    "newMonthCharge": "325.80",
                    "nextMonthCharge": "517.99"
                  },
                  "planCharge": {
                    "newMonthCharge": "251.50",
                    "nextMonthCharge": "422.34"
                  },
                  "lineAccessFees": {
                    "newMonthCharge": "0.00",
                    "nextMonthCharge": "0.00"
                  },
                  "devicePayments": {
                    "newMonthCharge": "68.60",
                    "nextMonthCharge": "68.79"
                  },
                  "surcharges": {
                    "newMonthCharge": "12.92",
                    "nextMonthCharge": "21.26"
                  },
                  "taxesAndFees": {
                    "newMonthCharge": "5.83",
                    "nextMonthCharge": "12.14"
                  },
                  "totalAddOns": {
                    "newMonthCharge": "36.95",
                    "nextMonthCharge": "36.95"
                  },
                  "appleMusic": {
                    "newMonthCharge": "0.00",
                    "nextMonthCharge": "0.00"
                  },
                  "mobileProtection": {
                    "newMonthCharge": "26.95",
                    "nextMonthCharge": "26.95"
                  },
                  "planAccessFeeTotal": {
                    "newMonthCharge": "251.50",
                    "nextMonthCharge": "422.34"
                  },
                  "taxGrandTotal": {
                    "newMonthCharge": "18.75",
                    "nextMonthCharge": "33.40"
                  },
                  "subTotal": {
                    "newMonthCharge": "307.05",
                    "nextMonthCharge": "484.59"
                  },
                  "autoPayDiscount": {
                    "accountTotalAutoPayDiscount": "25.00",
                    "isCustomerEnrolledForAutopay": false,
                    "subTotalNewMonthwithAutoPayDisc": "282.05"
                  },
                  "dateRange": {
                    "thisMonth": "10/06/2024-11/05/2024",
                    "nextMonth": "11/06/2024-12/05/2024"
                  }
                },
                "nbs": {
                  "accountNumber": "0325654132-00001",
                  "nextBillCycleStartDate": "11/06/2024",
                  "balancePastDue": {
                    "pastDueAmount": "0.00",
                    "paymentsReceived": "0.00",
                    "previousBalance": "295.88",
                    "balanceType": "Current Balance",
                    "unbilledPayment": "-144.64",
                    "totUnpaidBalance": "151.24",
                    "paymentMessage": "You have paid a portion of your current bill. The remaining balance of $151.24 is due on 10/28/2024.",
                    "unbilledOCC": "0.00"
                  },
                  "monthlyChargesInfo": {
                    "accountLevelCharges": [
                      {
                        "thisMonthCharge": "-25.00",
                        "nextMonthCharge": "-25.00",
                        "chargeRefId": "1781",
                        "description": "LOYALTY $25 DISC 2-3 PHONES",
                        "itemType": [
                          {
                            "equipment": false,
                            "feature": false,
                            "naf": false,
                            "occ": false,
                            "plan": false,
                            "promo": false,
                            "accequipment": false,
                            "sfo": false,
                            "spo": false,
                            "addOn": false
                          }
                        ],
                        "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                        "listPrice": "-25.00",
                        "netPrice": "-25.00"
                      }
                    ],
                    "accountLevelTotal": {
                      "thisMonthCharge": "-25.00",
                      "nextMonthCharge": "-41.94",
                      "differenceBetweenThisMonthAndNextMonthCharge": "-16.94",
                      "totalOneTimeCharge": "-16.94",
                      "newMonthMrcWithNoAddOn": "-25.00",
                      "nextMonthMrcWithNoAddOn": "-25.00",
                      "nextMonthAcctLevelSurcharges": "0.00",
                      "newMonthAcctLevelSurcharges": "0.00",
                      "nextMonthAccountLevelTax": "0.00",
                      "newMonthAccountLevelTax": "0.00",
                      "chargeTotals": [
                        {
                          "itemRef": "SPO",
                          "differenceBetweenThisAndNextMonthCharge": "0.00",
                          "thisMonthCharge": "-25.00",
                          "nextMonthCharge": "-25.00"
                        },
                        {
                          "itemRef": "Total Addons",
                          "differenceBetweenThisAndNextMonthCharge": "0.00",
                          "thisMonthCharge": "0.00",
                          "nextMonthCharge": "0.00"
                        }
                      ]
                    },
                    "mtnLevelChargeDetails": [
                      {
                        "mtn": "8133477604",
                        "thisMonthCharge": "133.83",
                        "nextMonthCharge": "190.73",
                        "differenceBetweenThisMonthAndNextMonthCharge": "56.90",
                        "thisMonthSurcharges": "4.68",
                        "previousMonthCharge": "0.00",
                        "nextMonthSurcharges": "4.92",
                        "differenceBetweenThisMonthAndNextMonthSurcharges": "0.24",
                        "thisMonthTax": "2.08",
                        "nextMonthTax": "2.26",
                        "differenceBetweenThisMonthAndNextMonthTax": "0.18",
                        "chargeDetails": [
                          {
                            "thisMonthCharge": "84.00",
                            "nextMonthCharge": "84.00",
                            "chargeRefId": "50430",
                            "description": "5G PLAY MORE",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "84.00",
                            "netPrice": "84.00",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          },
                          {
                            "thisMonthCharge": "30.83",
                            "nextMonthCharge": "30.83",
                            "chargeRefId": "352396479769529",
                            "description": "Device Payment",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "30.83",
                            "netPrice": "30.83",
                            "loanNumber": "1587790945",
                            "nextInstallmentNumber": "25",
                            "totalInstallmentNumber": "36",
                            "outstandingLoanAmount": "339.13",
                            "loanAmount": "1110.00",
                            "loanCode": "A"
                          },
                          {
                            "thisMonthCharge": "19.00",
                            "nextMonthCharge": "19.00",
                            "chargeRefId": "88690",
                            "description": "VERIZON MOBILE PROTECT",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "19.00",
                            "netPrice": "19.00",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          }
                        ],
                        "oneTimeChargeDetails": [
                          {
                            "thisMonthCharge": "0.00",
                            "nextMonthCharge": "56.90",
                            "chargeRefId": "50430",
                            "description": "5G PLAY MORE",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "56.90",
                            "netPrice": "56.90",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          }
                        ],
                        "nickname": "DON WRIGHT",
                        "suppressAdvInd": "N",
                        "newMonthMtnMrcWithNoAddOn": "114.83",
                        "nextMonthMtnMrcWithNoAddOn": "114.83",
                        "newMonthGrandTotalWithTaxes": "140.59",
                        "nextMonthGrandTotalWithTaxes": "197.91",
                        "chargeTotals": [
                          {
                            "itemRef": "Equipment",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "30.83",
                            "nextMonthCharge": "30.83"
                          },
                          {
                            "itemRef": "Total Addons",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "19.00",
                            "nextMonthCharge": "19.00"
                          },
                          {
                            "itemRef": "PPLAN",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "84.00",
                            "nextMonthCharge": "84.00"
                          },
                          {
                            "itemRef": "Auto Pay",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "5.00",
                            "nextMonthCharge": "5.00"
                          }
                        ],
                        "mtnChangeInd": false
                      },
                      {
                        "mtn": "8137244660",
                        "thisMonthCharge": "55.00",
                        "nextMonthCharge": "92.25",
                        "differenceBetweenThisMonthAndNextMonthCharge": "37.25",
                        "thisMonthSurcharges": "0.00",
                        "previousMonthCharge": "0.00",
                        "nextMonthSurcharges": "0.00",
                        "differenceBetweenThisMonthAndNextMonthSurcharges": "0.00",
                        "thisMonthTax": "0.00",
                        "nextMonthTax": "0.00",
                        "differenceBetweenThisMonthAndNextMonthTax": "0.00",
                        "chargeDetails": [
                          {
                            "thisMonthCharge": "80.00",
                            "nextMonthCharge": "80.00",
                            "chargeRefId": "75561",
                            "description": "5G HOME PLUS",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "80.00",
                            "netPrice": "80.00",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          },
                          {
                            "thisMonthCharge": "-25.00",
                            "nextMonthCharge": "-25.00",
                            "chargeRefId": "2722",
                            "description": "MOBILE + HOME DISCOUNT",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "-25.00",
                            "netPrice": "-25.00",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          },
                          {
                            "thisMonthCharge": "10.00",
                            "nextMonthCharge": "10.00",
                            "chargeRefId": "3239",
                            "description": "WHOLE-HOME WI-FI",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "-10.00",
                            "listPrice": "10.00",
                            "netPrice": "0.00",
                            "promo1Id": "20996",
                            "promo1Desc": "WHOLE-HOME WI-FI DISCOUNT",
                            "promo1Discount": "-10.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          },
                          {
                            "thisMonthCharge": "10.00",
                            "nextMonthCharge": "10.00",
                            "chargeRefId": "2641",
                            "description": "DISNEY BUNDLE",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "-10.00",
                            "listPrice": "10.00",
                            "netPrice": "0.00",
                            "promo1Id": "21015",
                            "promo1Desc": "DISNEY BUNDLE PROMO",
                            "promo1Discount": "-10.00",
                            "promo1EndDate": "10/11/2025",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          }
                        ],
                        "oneTimeChargeDetails": [
                          {
                            "thisMonthCharge": "0.00",
                            "nextMonthCharge": "54.19",
                            "chargeRefId": "75561",
                            "description": "5G HOME PLUS",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "54.19",
                            "netPrice": "54.19",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          },
                          {
                            "thisMonthCharge": "0.00",
                            "nextMonthCharge": "-16.94",
                            "chargeRefId": "2722",
                            "description": "MOBILE + HOME DISCOUNT",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "-16.94",
                            "netPrice": "-16.94",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          },
                          {
                            "thisMonthCharge": "0.00",
                            "nextMonthCharge": "6.77",
                            "chargeRefId": "3239",
                            "description": "WHOLE-HOME WI-FI",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "-6.77",
                            "listPrice": "6.77",
                            "netPrice": "0.00",
                            "promo1Id": "20996",
                            "promo1Desc": "WHOLE-HOME WI-FI DISCOUNT",
                            "promo1Discount": "-6.77",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          }
                        ],
                        "nickname": "New line",
                        "suppressAdvInd": "N",
                        "newMonthMtnMrcWithNoAddOn": "55.00",
                        "nextMonthMtnMrcWithNoAddOn": "55.00",
                        "newMonthGrandTotalWithTaxes": "55.00",
                        "nextMonthGrandTotalWithTaxes": "92.25",
                        "chargeTotals": [
                          {
                            "itemRef": "SPO",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "-25.00",
                            "nextMonthCharge": "-25.00"
                          },
                          {
                            "itemRef": "Total Addons",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "0.00",
                            "nextMonthCharge": "0.00"
                          },
                          {
                            "itemRef": "PPLAN",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "80.00",
                            "nextMonthCharge": "80.00"
                          },
                          {
                            "itemRef": "Auto Pay",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "10.00",
                            "nextMonthCharge": "10.00"
                          }
                        ],
                        "mtnChangeInd": false
                      },
                      {
                        "mtn": "8137277652",
                        "thisMonthCharge": "121.00",
                        "nextMonthCharge": "215.77",
                        "differenceBetweenThisMonthAndNextMonthCharge": "94.77",
                        "thisMonthSurcharges": "4.32",
                        "previousMonthCharge": "0.00",
                        "nextMonthSurcharges": "12.38",
                        "differenceBetweenThisMonthAndNextMonthSurcharges": "8.06",
                        "thisMonthTax": "2.75",
                        "nextMonthTax": "8.83",
                        "differenceBetweenThisMonthAndNextMonthTax": "6.08",
                        "chargeDetails": [
                          {
                            "thisMonthCharge": "80.00",
                            "nextMonthCharge": "80.00",
                            "chargeRefId": "63217",
                            "description": "UNLIMITED PLUS",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "80.00",
                            "netPrice": "80.00",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          },
                          {
                            "thisMonthCharge": "23.05",
                            "nextMonthCharge": "23.24",
                            "description": "Device Payment",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.19",
                            "listPrice": "23.05",
                            "netPrice": "23.05",
                            "loanNumber": "0",
                            "nextInstallmentNumber": "1",
                            "totalInstallmentNumber": "36",
                            "outstandingLoanAmount": "806.75",
                            "loanAmount": "829.99",
                            "loanCode": "A"
                          },
                          {
                            "thisMonthCharge": "7.95",
                            "nextMonthCharge": "7.95",
                            "chargeRefId": "85913",
                            "description": "WIRELESS PHONE PROTECTION",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "7.95",
                            "netPrice": "7.95",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          },
                          {
                            "thisMonthCharge": "10.00",
                            "nextMonthCharge": "10.00",
                            "chargeRefId": "2641",
                            "description": "DISNEY BUNDLE",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "10.00",
                            "netPrice": "10.00",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          }
                        ],
                        "oneTimeChargeDetails": [
                          {
                            "thisMonthCharge": "0.00",
                            "nextMonthCharge": "54.19",
                            "chargeRefId": "63217",
                            "description": "UNLIMITED PLUS",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "54.19",
                            "netPrice": "54.19",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          },
                          {
                            "thisMonthCharge": "0.00",
                            "nextMonthCharge": "5.39",
                            "chargeRefId": "85913",
                            "description": "WIRELESS PHONE PROTECTION",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "5.39",
                            "netPrice": "5.39",
                            "promo1Id": "0",
                            "promo1Discount": "0.00",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          },
                          {
                            "thisMonthCharge": "0.00",
                            "nextMonthCharge": "35.00",
                            "chargeRefId": "3",
                            "description": "ACTIVATION FEE",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "listPrice": "0.0",
                            "netPrice": "0.0",
                            "recurringIndicator": "N",
                            "balanceDueIndicator": "N"
                          }
                        ],
                        "nickname": "New line",
                        "suppressAdvInd": "N",
                        "newMonthMtnMrcWithNoAddOn": "103.05",
                        "nextMonthMtnMrcWithNoAddOn": "103.24",
                        "newMonthGrandTotalWithTaxes": "128.07",
                        "nextMonthGrandTotalWithTaxes": "236.98",
                        "chargeTotals": [
                          {
                            "itemRef": "Equipment",
                            "differenceBetweenThisAndNextMonthCharge": "-0.19",
                            "thisMonthCharge": "23.05",
                            "nextMonthCharge": "23.05"
                          },
                          {
                            "itemRef": "Total Addons",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "17.95",
                            "nextMonthCharge": "17.95"
                          },
                          {
                            "itemRef": "PPLAN",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "80.00",
                            "nextMonthCharge": "80.00"
                          },
                          {
                            "itemRef": "OCC",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "0.00",
                            "nextMonthCharge": "0.00"
                          },
                          {
                            "itemRef": "Auto Pay",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "10.00",
                            "nextMonthCharge": "10.00"
                          }
                        ],
                        "mtnChangeInd": false
                      },
                      {
                        "mtn": "8138531515",
                        "thisMonthCharge": "22.22",
                        "nextMonthCharge": "27.78",
                        "differenceBetweenThisMonthAndNextMonthCharge": "5.56",
                        "thisMonthSurcharges": "3.92",
                        "previousMonthCharge": "0.00",
                        "nextMonthSurcharges": "3.96",
                        "differenceBetweenThisMonthAndNextMonthSurcharges": "0.04",
                        "thisMonthTax": "1.00",
                        "nextMonthTax": "1.05",
                        "differenceBetweenThisMonthAndNextMonthTax": "0.05",
                        "chargeDetails": [
                          {
                            "thisMonthCharge": "15.00",
                            "nextMonthCharge": "15.00",
                            "chargeRefId": "18056",
                            "description": "NUMBER SHARE",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "-7.50",
                            "listPrice": "15.00",
                            "netPrice": "7.50",
                            "promo1Id": "19979",
                            "promo1Desc": "50% ACCESS FEE DISCOUNT FROM 813.727.7652",
                            "promo1Discount": "-7.50",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          },
                          {
                            "thisMonthCharge": "14.72",
                            "nextMonthCharge": "14.72",
                            "chargeRefId": "358427486768156",
                            "description": "Device Payment",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                            "listPrice": "14.72",
                            "netPrice": "14.72",
                            "loanNumber": "1588437200",
                            "nextInstallmentNumber": "25",
                            "totalInstallmentNumber": "36",
                            "outstandingLoanAmount": "161.92",
                            "loanAmount": "529.99",
                            "loanCode": "A"
                          }
                        ],
                        "oneTimeChargeDetails": [
                          {
                            "thisMonthCharge": "0.00",
                            "nextMonthCharge": "11.13",
                            "chargeRefId": "18056",
                            "description": "NUMBER SHARE",
                            "itemType": [
                              {
                                "equipment": false,
                                "feature": false,
                                "naf": false,
                                "occ": false,
                                "plan": false,
                                "promo": false,
                                "accequipment": false,
                                "sfo": false,
                                "spo": false,
                                "addOn": false
                              }
                            ],
                            "differenceBetweenThisMonthAndNextMonthCharge": "-5.57",
                            "listPrice": "11.13",
                            "netPrice": "5.56",
                            "promo1Id": "19979",
                            "promo1Desc": "50% ACCESS FEE DISCOUNT FROM 813.727.7652",
                            "promo1Discount": "-5.57",
                            "promo2Id": "0",
                            "promo2Discount": "0.00",
                            "promo3Id": "0",
                            "promo3Discount": "0.00"
                          }
                        ],
                        "nickname": "DON WRIGHT",
                        "suppressAdvInd": "N",
                        "newMonthMtnMrcWithNoAddOn": "22.22",
                        "nextMonthMtnMrcWithNoAddOn": "22.22",
                        "newMonthGrandTotalWithTaxes": "27.14",
                        "nextMonthGrandTotalWithTaxes": "32.79",
                        "chargeTotals": [
                          {
                            "itemRef": "Equipment",
                            "differenceBetweenThisAndNextMonthCharge": "0.00",
                            "thisMonthCharge": "14.72",
                            "nextMonthCharge": "14.72"
                          },
                          {
                            "itemRef": "PPLAN",
                            "differenceBetweenThisAndNextMonthCharge": "-7.50",
                            "thisMonthCharge": "15.00",
                            "nextMonthCharge": "15.00"
                          }
                        ],
                        "mtnChangeInd": false
                      }
                    ],
                    "accountLevelOneTimeCharges": [
                      {
                        "thisMonthCharge": "0.00",
                        "nextMonthCharge": "-16.94",
                        "chargeRefId": "1781",
                        "description": "LOYALTY $25 DISC 2-3 PHONES",
                        "itemType": [
                          {
                            "equipment": false,
                            "feature": false,
                            "naf": false,
                            "occ": false,
                            "plan": false,
                            "promo": false,
                            "accequipment": false,
                            "sfo": false,
                            "spo": false,
                            "addOn": false
                          }
                        ],
                        "differenceBetweenThisMonthAndNextMonthCharge": "0.00",
                        "listPrice": "-16.94",
                        "netPrice": "-16.94"
                      }
                    ]
                  },
                  "monthlyTotalsInfo": {
                    "thisMonthCharge": "325.80",
                    "thisMonthChargeDateRange": "10/06/2024-11/05/2024",
                    "nextMonthCharge": "517.99",
                    "nextMonthChargeDateRange": "11/06/2024-12/05/2024",
                    "differenceBetweenThisMonthAndNextMonthCharge": "192.19",
                    "previousCycleFormattedDateRange": "Sep 06,2024 - Oct 05,2024"
                  },
                  "surchargesInfo": {
                    "thisMonthCharge": 12.92,
                    "nextMonthCharge": 21.26,
                    "differenceBetweenThisMonthAndNextMonthSurcharges": "8.34"
                  },
                  "taxesAndFeesInfo": {
                    "thisMonthCharge": 5.83,
                    "nextMonthCharge": 12.14,
                    "differenceBetweenThisMonthAndNextMonthTax": "6.31"
                  },
                  "autoPayDiscount": {
                    "accountTotalAutoPayDiscount": "25.00",
                    "isCustomerEnrolledForAutopay": false,
                    "subTotalNewMonthwithAutoPayDisc": "282.05"
                  },
                  "barGraphDetails": {
                    "invoiceCount": "3",
                    "invoiceLastMonth": "151.24",
                    "invoiceLastMonthCycleEnddate": "07/05/2024",
                    "invoiceTwoMonthPrevious": "144.64",
                    "invoiceTwoMonthCycleEnddate": "06/05/2024"
                  },
                  "nbsIndicators": {
                    "languageIndicator": "E",
                    "partialBillIndicator": "N"
                  },
                  "pendingChargesAndDiscounts": {
                    "mtnLevelPendingInfo": [],
                    "discountsPendingActionDetails": {
                      "apoPaperlessAmount": "-25.00",
                      "totalPendingDiscount": "-25.00",
                      "newMonthlyTotalWithPendingDiscounts": "300.80"
                    }
                  }
                },
                "billAccountNo": "1"
              }
            ]
          }
        ],
        "subAccountNbsDetails": [],
        "bagTax": false,
        "couponDetails": [{}]
      },
      "refundOrderDetails": {
        "orderNum": 0,
        "totalDueToday": "0.0",
        "subTotalDueToday": "0.0",
        "totalTaxAmount": "0.0",
        "creditApplicationNum": 0
      },
      "globalPromotions": {},
      "sfoLossReferenceDataList": [],
      "spoLossReferenceDataList": [],
      "verizonUpToastMessage": {
        "toastMessages": [],
        "eligibleProducts": []
      },
      "cartValidationErrors": [
        {
          "errorCategory": "Cart",
          "errorLevel": "Warning",
          "errorCode": "1011",
          "errorMessage": "Cart5GAppointment details are missing in Cart serviceInfo",
          "fieldPath": "8137244660"
        },
        {
          "errorCategory": "Cart",
          "errorLevel": "Warning",
          "errorCode": "1090",
          "errorMessage": "Shipping is Required",
          "fieldPath": ""
        },
        {
          "errorCategory": "Cart",
          "errorLevel": "Warning",
          "errorCode": "1016",
          "errorMessage": "Email Address is missing in shipping addresstype",
          "fieldPath": "8138531515"
        },
        {
          "errorCategory": "Cart",
          "errorLevel": "Warning",
          "errorCode": "1017",
          "errorMessage": "Phone Number is missing in shipping addresstype",
          "fieldPath": "8138531515"
        },
        {
          "errorCategory": "Cart",
          "errorLevel": "Warning",
          "errorCode": "1091",
          "errorMessage": "Payment is Required",
          "fieldPath": ""
        }
      ],
      "programEligibility": {
        "profileRemainingSpendingLimitAmount": 3407.85,
        "lineSpendingLimitAmount": 2000.0
      },
      "accountEligibility": false,
      "displayCartValidationErrors": true
    },
    "warningMessages": [],
    "basicORSmartPhoneExists": true,
    "fiveGDeviceORLTEHomeExists": false,
    "cartHasAccessories": true,
    "iscartHasVZHP": false,
    "isPortInLaterThrottled": true,
    "featureConfigurationProfileData": {
    },
    "featureFlags": {
      "rfexEligibilityForDfoFFlag": true
    },
    "orderPlaced": false,
    "validateCart": false,
    "redesignFlow": false,
    "validateAppointments": false,
    "newCustomer": false,
    "isLocalStoreOfferEnabled": false
  },
  "meta": {
    "timestamp": "1728901236632",
    "cxpCorrelationId": "2024-10-14T10:20:36.+0000:447ad94deaa89a69:cxp-shopping-services-585cdf5cdc-k7fjb:nssit2"
  }
}