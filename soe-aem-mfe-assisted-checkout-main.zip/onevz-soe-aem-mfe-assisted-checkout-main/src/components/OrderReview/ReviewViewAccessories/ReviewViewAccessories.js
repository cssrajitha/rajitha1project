import PropTypes from 'prop-types';
import React from 'react';
import styled from 'styled-components';
import AccessoriesCheckoutDetails from '../AccessoriesCheckoutDetails';

const AccessoriesWrapper = styled.div`
  padding-top: ${(props)=>(props.isQAFlow ? "" : "20px")};
`;

export default function ReviewViewAccessories({ cartData, isQAFlow =false, showModal, setIsNewCustomer, refetchCartDetails }) {
  const lineInfoData = cartData?.data?.cart?.lineDetails?.lineInfo;
  const filterAccLines = lineInfoData?.filter(
    (line) => line?.lineActivityType === 'ACC' || line?.lineActivityType === 'NSEACC'
  );
  let filterdLineInfoData = filterAccLines?.filter((line) =>
    line?.itemsInfo.some((item) => item?.cartItems?.cartItem?.some((acc) => acc.cartItemType === 'ACCESSORY'))
  );
  let readOrderStatus = '';
if(isQAFlow){
  readOrderStatus = cartData?.data?.orderStatus;
    filterdLineInfoData = filterAccLines?.filter((line) =>
      line?.itemsInfo.some((item) => item?.cartItems?.cartItem?.some((acc) => (acc.prodCode1 === "LAB" && acc.prodCode2 === "SER") || (acc.prodCode1 === "TAX" && acc.prodCode2 === "SPC") || (acc.prodCode1 === "TAX" && acc.prodCode2 === "BAG") || acc.prodCode2 === 'GIF' || acc.cartItemType === 'ACCESSORY'))
    )
}
  return (
    <div data-testid='review-accessory'>
      {filterdLineInfoData &&
        filterdLineInfoData.length > 0 &&
        filterdLineInfoData.map((line) => (
          <AccessoriesWrapper key={line?.mobileNumber} isQAFlow={isQAFlow}>
            <AccessoriesCheckoutDetails
              data={{
                data: {
                  cart: cartData?.data?.cart,
                },
              }}
              lineInfoData={line}
              showAccordion={false}
              itemsInfo={line?.itemsInfo}
              mtn={line?.mobileNumber}
              hideSupport
              isFromCheckout
              alignHorizontal
              isQAFlow={isQAFlow}
              showModal={showModal}
              setIsNewCustomer={setIsNewCustomer}
              readOrderStatus={readOrderStatus}
              refetchCartDetails={refetchCartDetails}
            />
          </AccessoriesWrapper>
        ))}
    </div>
  );
}

ReviewViewAccessories.propTypes = {
  cartData: PropTypes.object,
  isQAFlow: PropTypes.bool,
  showModal: PropTypes.func,
  setIsNewCustomer: PropTypes.func,
  refetchCartDetails: PropTypes.func,
};
