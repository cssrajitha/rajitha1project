// eslint-disable-next-line max-classes-per-file
import { render, screen } from '@testing-library/react';
import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import cartJson from './__mock__/retrive-cart.json';
import {bagTaxMockData, cartDatasetandGoMock, giftcardMock, salesTaxcartDataMock} from './__mock__/QAretrievecartMock';
import StoreProvider from '../../../modules/store';
import ReviewViewAccessories from './ReviewViewAccessories';

jest.mock('../../../utils/tagging');

describe('Review View Accessory Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  beforeEach(() => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ReviewViewAccessories cartData={cartJson} />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('renders Review View Accessory component', () => {
    const titleElement = screen.getByTestId('review-accessory');
    expect(titleElement).toBeInTheDocument();
  });
});

describe('Review View Accessory Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  beforeEach(() => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ReviewViewAccessories cartData={cartJson} isQAFlow />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('renders Review View Accessory component', () => {
    const titleElement = screen.getByTestId('review-accessory');
    expect(titleElement).toBeInTheDocument();
  });
});

describe('Review View Accessory Component setupandgo', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  beforeEach(() => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ReviewViewAccessories cartData={cartDatasetandGoMock} isQAFlow />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('renders Review View Accessory component', () => {
    const titleElement = screen.getByTestId('review-accessory');
    expect(titleElement).toBeInTheDocument();
  });
});


describe('Review View Accessory Component setupandgo', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  beforeEach(() => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ReviewViewAccessories cartData={cartDatasetandGoMock} isQAFlow={true} />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('renders Review View Accessory component', () => {
    const titleElement = screen.getByTestId('review-accessory');
    expect(titleElement).toBeInTheDocument();
  });
});

describe('Review View Accessory Component salestax', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  beforeEach(() => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ReviewViewAccessories cartData={salesTaxcartDataMock} isQAFlow />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('renders Review View Accessory component', () => {
    const titleElement = screen.getByTestId('review-accessory');
    expect(titleElement).toBeInTheDocument();
  });
});

describe('Review View Accessory Component GIFTCARD', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  beforeEach(() => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ReviewViewAccessories cartData={giftcardMock} isQAFlow />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('renders Review View Accessory component', () => {
    const titleElement = screen.getByTestId('review-accessory');
    expect(titleElement).toBeInTheDocument();
  });
});

describe('Review View Accessory Component bagtax', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  beforeEach(() => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ReviewViewAccessories cartData={bagTaxMockData} isQAFlow />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('renders Review View Accessory component', () => {
    const titleElement = screen.getByTestId('review-accessory');
    expect(titleElement).toBeInTheDocument();
  });
});