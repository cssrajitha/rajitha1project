import React from 'react';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import { Line } from '@vds/lines';

const RectangleBox = styled.div`
  display: 'block';
  position: absolute;
  background-color: white;
  border: 1px solid black;
  padding: 10px 10px 10px 20px;
  left: 100px;
  width: 250px;
  align-items: center;
  justify-content: center;
  z-index: 999999;

  top: -10px !important;
`;

const Arrow = styled.div`
  tab-size: 4;
  word-break: break-word;
  cursor: pointer;
  visibility: visible;
  line-height: 1.5;
  font-size: 0.875rem;
  box-sizing: border-box;
  position: absolute;
  background: white;
  width: 0.5rem;
  height: 0.5rem;
  /* border-right: 0px solid rgb(0, 0, 0); */
  /* border-bottom: 0px solid rgb(0, 0, 0); */
  /* border-image: initial; */
  left: -5px;
  margin-top: -0.4rem;
  transform: rotate(-45deg);
  color: black !important;
  outline: black !important;
  border-left: 1px solid black !important;
  border-top: 1px solid black !important;
  top: 50% !important;
`;

const TooltipContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 5px;
`;
const Row = styled.div`
  display: flex;
  font-family: BrandFont-Text, Arial, sans-serif;
  font-size: 14px;
  justify-content: space-between;
`;

function PriceDetailsModal({ marketPrice, item }) {
  const sedOfferDescription = item?.sedOfferList?.sedOffer?.[0]?.description;
  const sedOfferAmount = item?.sedOfferList?.sedOffer?.[0]?.discAmt;

  const manualDiscountDescription = item?.manualDiscountDescription;
  const manualDiscountAmount = item?.manualDiscountPrice;

  return (
    <RectangleBox>
      <Arrow />
      <TooltipContainer>
        <Row>
          <div>TooltipContainer</div> <div>${marketPrice}</div>
        </Row>
        {sedOfferDescription && sedOfferAmount && (
          <Row>
            <div>{sedOfferDescription}</div> <div>-${sedOfferAmount}</div>
          </Row>
        )}
        {manualDiscountDescription && manualDiscountAmount && (
          <Row>
            <div>{manualDiscountDescription}</div> <div>-${manualDiscountAmount.toFixed(2)}</div>
          </Row>
        )}
        <Line />

        <Row>
          <div>
            <b>Discounted Price</b>
          </div>{' '}
          <div>
            <b>${item?.priceAfterDiscount.toFixed(2)}</b>
          </div>
        </Row>
      </TooltipContainer>
    </RectangleBox>
  );
}

PriceDetailsModal.propTypes = {
  marketPrice: PropTypes.object,
  item: PropTypes.object,
};

export default PriceDetailsModal;
