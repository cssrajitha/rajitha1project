import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import { GIF_PROD_CODE } from '../Refund/constants';

export const isRfexFlow = sessionStorage?.getItem('refundexchange');
export const roPrintReciptFlagInd = sessionStorage?.getItem('roPrintReciptFlagInd')
  ? sessionStorage.getItem('roPrintReciptFlagInd')
  : '';
export const indirectCheckVOreceipt =
  sessionStorage?.getItem('channel')?.includes('OMNI-INDIRECT') && roPrintReciptFlagInd;

const isbrowserUrl = window?.location?.pathname?.includes('read-order.html');

export const printDirectThermalPrint = (viewreceiptpdcContent, orderConfirmationData, device) => {
  const receiptText = viewreceiptpdcContent.viewReceipt;
  const copies = '01';
  const popDrawer = 'FALSE';
  // barcode info
  const confPageInfo = orderConfirmationData?.data.getConfirmationPage || null;
  const orderNumber = (confPageInfo && confPageInfo.orderNumber) || '';
  const location = (confPageInfo && confPageInfo.locationCode) || '';
  const barcodeParams = {
    orderNumber,
    location,
    hasSignature: false,
  };
  if (device?.thermalPrint) {
    device?.thermalPrint?.connect(receiptText, copies, popDrawer, barcodeParams);
  }
};

export const orderDocumetRecipt = (readOrderData, orderNo) => {
  const isRfexReadOrder = !!readOrderData?.cart?.orderDetails?.orderType || isbrowserUrl;
  const readOrderCartHeader = readOrderData?.cart?.cartHeader;
  const readOrderOrderDetails = readOrderData?.cart?.orderDetails;
  const getCartId = readOrderData?.cart?.cartHeader?.cartId || '';
  const getLindetails = readOrderData?.cart?.lineDetails || '';

  const readOrderCartId = readOrderCartHeader?.cartId || getCartId;
  const location = readOrderOrderDetails?.locationCode || '';
  const orderList = readOrderOrderDetails?.orderList || '';
  const orderNumber =
    Array.isArray(orderNo) && orderNo.length > 1
      ? orderNo.filter((num) => num !== 0)
      : (readOrderData?.cart?.orderDetails?.orderNumber ?? orderNo);
  const accountNumber = readOrderCartHeader?.fullAccountNumber || '';
  const cartData = readOrderData?.cart || [];
  const lineDetails = getLindetails || [];

  const lineInfo =
    isRfexFlow && isRfexReadOrder
      ? lineDetails?.lineInfo
      : cartData && cartData?.lineDetails && cartData?.lineDetails?.lineInfo;
  const mtnList = [];
  const orderNum1 = [];
  lineInfo?.forEach((data) => {
    const mtn = data && data.mobileNumber ? data.mobileNumber : '';
    mtnList.push(mtn);
  });
  if (mtnList.length === 0) {
    const cartCreater = cartData && cartData.cartHeader && cartData.cartHeader.cartCreator;
    mtnList.push(cartCreater);
  }
  orderNum1.push(orderNumber);
  const requestObj = {
    data: {
      orderNumber: isRfexFlow && isRfexReadOrder ? orderList[0].orderNumber : orderNumber,
      cartId: readOrderCartId || '',
      locationCode: location || '',
      mtn: mtnList || '',
      accountNumber: accountNumber || '',
      orderType: readOrderData?.cart?.orderDetails?.orderType || '',
      isReadOrder: true,
    },
  };

  return requestObj;
};

export function printerDevices(locationCode) {
  const locationQueryParam = getQueryParamByName('orderLocationCode') || '';
  const request = {
    locationCode: locationQueryParam || locationCode || '',
  };
  return request;
}

export const posNbsFlowType = (obj) => {
  const pageIndicator = obj?.nbsTypeFlags;
  const flowType = obj?.mfeRequestPayload;
  let retType = 'ondemand';
  if (pageIndicator?.isOrderReview) {
    retType = 'preorder';
  } else if (pageIndicator?.isReadOrder && flowType?.onDemand) {
    retType = 'ondemand';
  } else if (pageIndicator?.isReadOrder && flowType?.postOrder) {
    retType = 'postorder';
  } else if (pageIndicator?.expressFlow || pageIndicator?.isCheckout) {
    retType = 'postorder';
  } else {
    retType = 'preorder';
  }
  return retType;
};

export const getAccessRole = (lookupMtn, cartInfo) => {
  const loookUpMtnData = cartInfo?.data?.data?.cart?.customerProfile?.billAccounts?.[0]?.mtns?.[0]
    ? cartInfo.data.data.cart.customerProfile.billAccounts[0].mtns.filter((line) => line.mtn === lookupMtn)
    : [];
  const lineData = loookUpMtnData?.[0] ?? {};
  const accessRoles = lineData?.mobileInfoAttributes?.accessRoles ?? {};
  const { manager = false, member = false, owner = false } = accessRoles;
  let vzwRole = '';
  if (manager) {
    vzwRole = 'accountManager';
  } else if (owner) {
    vzwRole = 'accountHolder';
  } else if (member) {
    vzwRole = 'mobileSecure';
  }
  return vzwRole;
};

export const nbsMfeModuleProps = (nbsState, unifiedMfeRequest) => {
  const payloadKeys = [
    'onDemand',
    'emailSuppressInd',
    'serviceOnly',
    'isBTAOnly',
    'zeroChargeFeatureOnly',
    'isStandaloneUpgradeDevice',
    'localOnly',
    'isLovEnabled',
    'nseFlow',
    'customerType',
    'postOrder',
    'readOrder',
    'tanglewoodQualified',
  ];
  const nbsTypeFlags = {};
  const mfeRequestPayload = Object.keys(unifiedMfeRequest)?.reduce((object, key) => {
    const modObject = { ...object };
    if (payloadKeys?.includes(key)) {
      modObject[key] = unifiedMfeRequest[key];
    }
    return modObject;
  }, {});
  const applicationType = 'POS_ORDERING';
  const unifiedNbsData = nbsState?.unifiedNbsData;
  const properties = ['isReadOrder', 'isOrderReview', 'expressFlow', 'isCheckout'];
  const vzwRole = unifiedMfeRequest?.vzwRole;
  properties.forEach((property) => {
    nbsTypeFlags[property] = nbsState[property];
  });

  const showSuspenseLoader = true;
  const moduleProps = {
    applicationType,
    mfeRequestPayload,
    nbsTypeFlags,
    unifiedNbsData,
    vzwRole,
    showSuspenseLoader,
  };

  return moduleProps;
};

export const maskCC = (ccNumber) => {
  let maskedNumber = '';
  if (ccNumber) {
    const cardNum = ccNumber;
    const cardLen = cardNum?.length;
    const last4 = cardNum?.substring(cardLen - 4, cardLen);
    const firstNums = cardNum?.substring(0, cardLen - 4);
    maskedNumber = firstNums?.replace(/[a-zA-Z0-9]/g, 'X');
    maskedNumber += last4;
  }
  return maskedNumber;
};
export const showGiftCardData = (isQAFlow, item) => {
  const isGiftCardEncrypted =
  /true/i.test(JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.encryptGCNumberForQAFFlag) || false;
  const isGiftCard = item.prodCode2 === GIF_PROD_CODE;
  const maskedGCNumber = isGiftCard && maskCC(item.accessoryGiftCardId);
  const isGCEncryptedForQA  = isQAFlow && isGiftCardEncrypted;
  const gcNumber = isGCEncryptedForQA ? maskedGCNumber : item.accessoryGiftCardId;
  return isGiftCard ? (<p size='small' style={{ fontStyle: 'italic' }}>
        GCNumber: {gcNumber}
      </p>
  ) : null;
}