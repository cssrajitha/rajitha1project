import React from 'react';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { isIpad, executeShellFunction } from 'onevzsoemfeframework/DomService';
import ViewOrderDocument from './ViewOrderDocument';
import StoreProvider from '../../../modules/store/index';
import readOrder from './__mocks__/readOrder.json';
import readOrderViewAndPrintReceipt from './__mocks__/readOrderViewAndPrintReceipt.json';
import readOrderViewAndPrintReceipt1 from './__mocks__/readOrderViewAndPrintReceipt1.json';
import readOrderDocument from './__mocks__/readOrderDocument.json';
import * as EmailApiCallHook from '../../../modules/services/APIService/EmailApiCallHook';
import * as InfoApiCallHook from '../../../modules/services/APIService/InfoAPICallHook';

const printpriview = readOrderViewAndPrintReceipt;

const printDirectThermalPrint = jest.fn();
const mockemailReceipt = jest.fn();
const documentList = readOrderViewAndPrintReceipt;

jest.mock('../../../modules/services/APIService/APIServiceHooks', () => ({
  ...jest.requireActual('../../../modules/services/APIService/APIServiceHooks'),
  useLazyReadOrderRetrieveInstallmentAgreementQuery: [jest.fn(), { data: { getDocument: { response: {} } } }],
  useLazyViewOrPrintEdgeUpReturnLabelQuery: [{}],
}));

beforeEach(() => {
  sessionStorage.setItem('channel', 'OMNI-RETAIL');
  jest.spyOn(EmailApiCallHook, 'default').mockReturnValue({
    regenerateReceipts: jest.fn().mockResolvedValue({
      meta: {
        timestamp: '1739346711673',
        cxpCorrelationId: '2025-02-12T07:51:51.+0000:598c3641d40f6c7c:cxp-document-services-57f49656b5-nf94d:nssit3',
      },
      data: {
        documents: [
          {
            documentId: '12345',
            documentName: 'purchaseReceipt',
            documentType: 'PDF',
            documentData: 'receiptData',
          },
        ],
        signatureRequired: false,
      },
    }),
    getDevices: jest.fn(),
    getDevicesResult: { data: { data: 'receiptData' }, status: 'fulfilled' },
    emailReceipt: jest.fn(),
    emailReceiptResult: { data: { data: 'receiptData' }, status: 'fulfilled' },
  });
  jest.spyOn(InfoApiCallHook, 'default').mockReturnValue({
    updateVisionRemark: jest.fn(),
    getUpdateVisionRemarkResponse: { data: { data: 'receiptData' }, status: 'fulfilled' },
    readOrderDocInfo: jest.fn(),
    readOrderDPReceiptApi: jest
      .fn()
      .mockResolvedValue({ data: { getDocument: { response: {} } }, status: 'fulfilled' }),
    readOrderDocInfoRes: { data: { data: documentList, status: 'Success' }, status: 'fulfilled' },
  });
});

jest.mock('./ViewReceiptModal', () => ({ setClosePrintVeiw, setViewReceiptContentPDF }) => {
  setClosePrintVeiw(false);
  setViewReceiptContentPDF({
    viewReceipt: 'yes',
    viewReceiptArr: [
      {
        categoryName: 'GR',
      },
    ],
  });
});

const SetDocList = jest.fn();
const HandleRegenerate = jest.fn();
const setClsoPrintView = jest.fn();
const customerJson = {
  data: {
    customer: {
      caseId: 'SOP-16631496-E01',
      cartId: 'cce6a277-b5b2-4ce0-bc89-8b0e2ae95cf2',
      processStep: 'MTNSelectionPage',
      availablePaths: [
        {
          path: 'MTNSelectionPage',
        },
      ],
      customerId: '325893599',
      customerHash: 'cccff0728bd1a30e896d15347b8ead72f887ea845508d33c3d7ce1a3735b9e95',
      contactAddress: {
        state: 'GA',
      },
      customerName: {
        firstName: 'DAN',
        lastName: 'JETER',
      },

      billAccounts: [{ billAccountNo: 1 }],
    },
  },
};

const props = {
  value: true,
  setshowViewAndPrintReceipt: jest.fn(),
  handleToggle: jest.fn(),
  isRefundReadOrder: false,
  readorder: true,
  emailId: 'test@example.com',
  regeneratedReceiptEnabled: false,
  deviceManager: { getInstance: jest.fn().mockReturnValue({}) },
  orderConfirmationData: { data: { getConfirmationPage: {} } },
  toggleViewModal: jest.fn(),
  hideViewPrintReceipt: jest.fn(),
  orderNo: '12345',
  data: { data: { data: { cart: { lineDetails: {} } } } },
  readOrderData: readOrder.data,
  cartDetails: readOrder.data.cart.cartHeader,
  locationCode: 'loc123',
  readOrderViewAndPrintReceipt: printpriview,
  customerProfile: customerJson,
  customerInfo: { billAccounts: [{ billAccountNo: '1' }], billingSystem: 'VZB', loggedInUser: 'machakr' },
};

jest.mock('onevzsoemfeframework/DomService', () => ({
  isIpad: jest.fn(),
  executeShellFunction: jest.fn(),
}));

beforeAll(() => {
  class ResizeObserver {
    constructor() {
      this.observe = () => jest.fn();
      this.unobserve = () => jest.fn();
      this.disconnect = () => jest.fn();
    }
  }
  window.ResizeObserver = ResizeObserver;
  SetDocList.mockClear();
  HandleRegenerate.mockClear();
  setClsoPrintView.mockClear();
});

describe('OrderConfirmation Component', () => {
  isIpad.mockReturnValue(false);
  sessionStorage.setItem('channel', 'OMNI-RETAIL');

  test('renders OrderConfirmation component', () => {
    const data = {
      viewReceipt: 'yes',
      viewReceiptArr: [
        {
          categoryName: 'GR',
        },
      ],
    };
    const expectedReturnValue = {
      viewReceipt: 'yes',
      viewReceiptArr: [
        {
          categoryName: 'GR',
        },
      ],
    };

    const expectedregenreat = {
      documents: [],
      isRegeneratedReceiptTriggered: true,
    };
    const expectedregenreatValue = {
      documents: [],
      isRegeneratedReceiptTriggered: true,
    };

    const mockResponse = { data: { data: 'receiptData' }, status: 'fulfilled' };
    mockemailReceipt.mockResolvedValueOnce(mockResponse);
    SetDocList.mockReturnValue(expectedReturnValue);
    HandleRegenerate.mockReturnValue(expectedregenreatValue);

    render(
      <BrowserRouter>
        <StoreProvider>
          <ViewOrderDocument {...props} viewreceiptpdcContent={expectedReturnValue} />
        </StoreProvider>
      </BrowserRouter>,
    );
    expect(screen.getByTestId('review-OrderDocument')).toBeInTheDocument();
    window.mfe = { scmCheckoutMfeEnable: true, isDark: true };
    const documentContainerTest = screen.getByTestId('items-at-OrderDocument');
    expect(documentContainerTest).toBeInTheDocument();

    const result = SetDocList(data);

    expect(SetDocList).toHaveBeenCalledWith(data);
    expect(result).toEqual(expectedReturnValue);
    const regenreate = HandleRegenerate(expectedregenreat);

    expect(HandleRegenerate).toHaveBeenCalledWith(expectedregenreat);
    expect(regenreate).toEqual(expectedregenreatValue);

    const viewPrintReceiptTitleTest = screen.getByTestId('viewPrintReceiptTitleTest');
    expect(viewPrintReceiptTitleTest).toBeInTheDocument();

    const deviceAgreeP = screen.getByTestId('devicePaymentAgreement-Print');
    expect(deviceAgreeP).toBeInTheDocument();
    fireEvent.click(deviceAgreeP);

    const customeAgreementEmail = screen.getByTestId('devicePaymentAgreement-Email');
    expect(customeAgreementEmail).toBeInTheDocument();
    fireEvent.click(customeAgreementEmail);

    const devicePaymentAgreementE = screen.getByTestId('devicePaymentAgreement-Edit');
    expect(devicePaymentAgreementE).toBeInTheDocument();
    fireEvent.mouseDown(devicePaymentAgreementE);
    expect(mockemailReceipt).not.toHaveBeenCalledWith({
      body: {
        data: {
          cartId: '12345',
          signatureData: '',
        },
      },
    });

    const EmailTxt = screen.getByTestId('devicePaymentAgreement-EmailTxt');
    expect(EmailTxt).toBeInTheDocument();
    fireEvent.blur(EmailTxt);
    fireEvent.change(EmailTxt, { target: { value: '' } });

    const EmailSave = screen.getByTestId('devicePaymentAgreement-Save');
    expect(EmailSave).toBeInTheDocument();
    fireEvent.mouseDown(EmailSave);
    waitFor(() => expect(screen.getByTestId('devicePaymentAgreement-EmailTxt')).toBeInTheDocument());
    fireEvent.change(EmailTxt, { target: { value: 'krishna.macharla@verizon.com' } });
    fireEvent.mouseDown(EmailSave);

    const giftcartTest = screen.getByTestId('giftReceipt-Print');
    expect(giftcartTest).toBeInTheDocument();
    fireEvent.click(giftcartTest);

    const tradeInReceipt = screen.getByTestId('tradeInReceipt-Print');
    expect(tradeInReceipt).toBeInTheDocument();
    fireEvent.click(tradeInReceipt);

    const giftcartTestEmail = screen.getByTestId('giftReceipt-Email');
    expect(giftcartTestEmail).toBeInTheDocument();
    fireEvent.click(giftcartTestEmail);

    const customerAgreementTest = screen.getByTestId('customerAgreement-Print');
    expect(customerAgreementTest).toBeInTheDocument();
    fireEvent.click(customerAgreementTest);
    const customerAgreementEmail = screen.getByTestId('customerAgreement-Email');
    expect(customerAgreementEmail).toBeInTheDocument();
    fireEvent.click(customerAgreementEmail);

    const isRingAgreement = screen.getByTestId('isRingAgreement-Print');
    expect(isRingAgreement).toBeInTheDocument();
    fireEvent.click(isRingAgreement);
    const isRingAgreementEmail = screen.getByTestId('isRingAgreement-Email');
    expect(isRingAgreementEmail).toBeInTheDocument();
    fireEvent.click(isRingAgreementEmail);

    const closeButton = screen.getByTestId('close-button');
    expect(closeButton).toBeInTheDocument();
    fireEvent.click(closeButton);

    setClsoPrintView.mockReturnValue(false, '10');
    const result1 = setClsoPrintView(false);
    expect(setClsoPrintView).toHaveBeenCalledWith(result1);
  });
  test('renders OrderConfirmation ipad component', () => {
    isIpad.mockReturnValue(true);
    const data = {
      viewReceipt: 'yes',
      viewReceiptArr: [
        {
          categoryName: 'GR',
        },
      ],
    };
    const expectedReturnValue = {
      viewReceipt: 'yes',
      viewReceiptArr: [
        {
          categoryName: 'GR',
        },
      ],
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <ViewOrderDocument {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    expect(screen.getByTestId('review-OrderDocument')).toBeInTheDocument();
    const documentContainerTest = screen.getByTestId('items-at-OrderDocument');
    expect(documentContainerTest).toBeInTheDocument();

    SetDocList.mockReturnValue(expectedReturnValue);

    const result = SetDocList(data);

    expect(SetDocList).toHaveBeenCalledWith(data);
    expect(result).toEqual(expectedReturnValue);

    const viewPrintReceiptTitleTest = screen.getByTestId('viewPrintReceiptTitleTest');
    expect(viewPrintReceiptTitleTest).toBeInTheDocument();

    const deviceAgreeP = screen.getByTestId('devicePaymentAgreement-Print');
    expect(deviceAgreeP).toBeInTheDocument();
    fireEvent.click(deviceAgreeP);
    const customeAgreementEmail = screen.getByTestId('devicePaymentAgreement-Email');
    expect(customeAgreementEmail).toBeInTheDocument();
    fireEvent.click(customeAgreementEmail);

    const devicePaymentAgreementE = screen.getByTestId('devicePaymentAgreement-Edit');
    expect(devicePaymentAgreementE).toBeInTheDocument();
    fireEvent.mouseDown(devicePaymentAgreementE);

    const EmailTxt = screen.getByTestId('devicePaymentAgreement-EmailTxt');
    expect(EmailTxt).toBeInTheDocument();
    fireEvent.blur(EmailTxt);
    fireEvent.change(EmailTxt, { target: { value: '' } });

    const EmailSave = screen.getByTestId('devicePaymentAgreement-Save');
    expect(EmailSave).toBeInTheDocument();
    fireEvent.mouseDown(EmailSave);
    waitFor(() => expect(screen.getByTestId('devicePaymentAgreement-EmailTxt')).toBeInTheDocument());
    fireEvent.change(EmailTxt, { target: { value: 'krishna.macharla@verizon.com' } });
    fireEvent.mouseDown(EmailSave);

    const giftcartTest = screen.getByTestId('giftReceipt-Print');
    expect(giftcartTest).toBeInTheDocument();
    fireEvent.click(giftcartTest);

    const giftcartTestEmail = screen.getByTestId('giftReceipt-Email');
    expect(giftcartTestEmail).toBeInTheDocument();
    fireEvent.click(giftcartTestEmail);

    const customerAgreementTest = screen.getByTestId('customerAgreement-Print');
    expect(customerAgreementTest).toBeInTheDocument();
    fireEvent.click(customerAgreementTest);
    const customerAgreementEmail = screen.getByTestId('customerAgreement-Email');
    expect(customerAgreementEmail).toBeInTheDocument();
    fireEvent.click(customerAgreementEmail);

    const closeButton = screen.getByTestId('close-button');
    expect(closeButton).toBeInTheDocument();
    fireEvent.click(closeButton);

    setClsoPrintView.mockReturnValue(false, 10);
    const result1 = setClsoPrintView(false);
    expect(setClsoPrintView).toHaveBeenCalledWith(result1);
  });

  test('renders OrderConfirmation component', () => {
    const props1 = { ...props, readOrderViewAndPrintReceipt: readOrderViewAndPrintReceipt1, isRefundReadOrder: true };
    render(
      <BrowserRouter>
        <StoreProvider>
          <ViewOrderDocument {...props1} />
        </StoreProvider>
      </BrowserRouter>,
    );
    expect(screen.getByTestId('review-OrderDocument')).toBeInTheDocument();
    const documentContainerTest = screen.getByTestId('items-at-OrderDocument');
    expect(documentContainerTest).toBeInTheDocument();

    const viewPrintReceiptTitleTest = screen.getByTestId('viewPrintReceiptTitleTest');
    expect(viewPrintReceiptTitleTest).toBeInTheDocument();

    const deviceAgreeP = screen.getByTestId('devicePaymentAgreement-Print');
    expect(deviceAgreeP).toBeInTheDocument();
    fireEvent.click(deviceAgreeP);
    const customeAgreementEmail = screen.getByTestId('devicePaymentAgreement-Email');
    expect(customeAgreementEmail).toBeInTheDocument();
    fireEvent.click(customeAgreementEmail);

    const modalfooter = screen.getByTestId('footerContent');
    expect(modalfooter).toBeInTheDocument();
    fireEvent.click(modalfooter);

    expect(screen.getByRole('button', { name: 'Done' })).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Done' }), {});

    const closeButton = screen.getByTestId('close-button');
    expect(closeButton).toBeInTheDocument();
    fireEvent.click(closeButton);
  });

  test('renders OrderConfirmation component', () => {
    const props1 = {
      ...props,
      readOrderViewAndPrintReceipt: readOrderViewAndPrintReceipt1,
      isRefundReadOrder: true,
      readorder: false,
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <ViewOrderDocument {...props1} />
        </StoreProvider>
      </BrowserRouter>,
    );
    expect(screen.getByTestId('review-OrderDocument')).toBeInTheDocument();
    const documentContainerTest = screen.getByTestId('items-at-OrderDocument');
    expect(documentContainerTest).toBeInTheDocument();

    const viewPrintReceiptTitleTest = screen.getByTestId('viewPrintReceiptTitleTest');
    expect(viewPrintReceiptTitleTest).toBeInTheDocument();

    const modalfooter = screen.getByTestId('footerContent');
    expect(modalfooter).toBeInTheDocument();
    fireEvent.click(modalfooter);

    expect(screen.getByRole('button', { name: 'Done' })).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Done' }), {});

    const closeButton = screen.getByTestId('close-button');
    expect(closeButton).toBeInTheDocument();
    fireEvent.click(closeButton);
  });
  test('renders Ipad', () => {
    isIpad.mockReturnValue(true);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    executeShellFunction.mockReturnValue({});
    const props1 = { ...props, readOrderViewAndPrintReceipt: readOrderDocument };
    render(
      <BrowserRouter>
        <StoreProvider>
          <ViewOrderDocument {...props1} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const QRcodePrintTest = screen.getByTestId('isQRCode-QRCode');
    expect(QRcodePrintTest).toBeInTheDocument();
    fireEvent.click(QRcodePrintTest);
  });

  test('calls printDirectThermalPrint when categoryName is "GR" and device is not iPad', async () => {
    isIpad.mockReturnValue(false);
    const props1 = { ...props, readOrderViewAndPrintReceipt: { data: { document: [] } } };
    const viewreceiptpdcContent = {
      viewReceiptArr: [{ categoryName: 'GR' }],
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <ViewOrderDocument
            {...props1}
            viewreceiptpdcContent={viewreceiptpdcContent}
            isRegeneratedReceiptTriggered={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    printDirectThermalPrint('', '', '');
    await waitFor(() => {
      expect(printDirectThermalPrint).toHaveBeenCalled();
    });
  });

  test('calls viewReceiptfn when isRegeneratedReceiptTriggered is true', async () => {
    const viewreceiptpdcContent = {
      viewReceiptArr: [{ categoryName: 'GR' }],
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <ViewOrderDocument
            {...props}
            viewreceiptpdcContent={viewreceiptpdcContent}
            isRegeneratedReceiptTriggered={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('does not call viewReceiptfn when isRegeneratedReceiptTriggered is false', async () => {
    const viewreceiptpdcContent = {
      viewReceiptArr: [{ categoryName: 'GR' }],
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <ViewOrderDocument
            {...props}
            viewreceiptpdcContent={viewreceiptpdcContent}
            isRegeneratedReceiptTriggered={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });
  test('renders OrderConfirmation ipad component', () => {
    isIpad.mockReturnValue(true);
    jest.spyOn(EmailApiCallHook, 'default').mockReturnValue({
      regenerateReceipts: jest.fn().mockResolvedValue({
        meta: {
          timestamp: '1739346711673',
          cxpCorrelationId: '2025-02-12T07:51:51.+0000:598c3641d40f6c7c:cxp-document-services-57f49656b5-nf94d:nssit3',
        },
        data: {
          documents: [],
          signatureRequired: false,
        },
      }),
      getDevices: jest.fn(),
      getDevicesResult: {
        data: { data: 'receiptData', getLocationByLocationCode: { devices: [{ type: 'DIRECT_PRINTER' }] } },
        status: 'fulfilled',
      },
      emailReceipt: jest.fn(),
      emailReceiptResult: { data: { data: 'receiptData' }, status: 'fulfilled' },
    });
    const props1 = {
      value: true,
      handleToggle: jest.fn(),
      readorder: true,
      emailId: 'test@example.com',
      regeneratedReceiptEnabled: false,
      deviceManager: { getInstance: jest.fn().mockReturnValue({}) },
      orderConfirmationData: { data: { getConfirmationPage: {} } },
      toggleViewModal: jest.fn(),
      hideViewPrintReceipt: jest.fn(),
      orderNo: [0, 12345],
      readOrderData: readOrder.data,
      cartDetails: readOrder.data.cart.cartHeader,
      locationCode: 'loc123',
      customerProfile: {},
      customerInfo: {},
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <ViewOrderDocument {...props1} readOrderViewAndPrintReceipt={{ documents: [] }} />
        </StoreProvider>
      </BrowserRouter>,
    );
    expect(screen.getByTestId('review-OrderDocument')).toBeInTheDocument();
    expect(screen.getByTestId('textLinkTest')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('textLinkTest'));
  });
});
