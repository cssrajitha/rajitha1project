import React from 'react';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import GenerateReceipt from './generateReceipt';
import * as EmailApiCallHook from '../../../modules/services/APIService/EmailApiCallHook';

describe('GenerateReceipt Component', () => {
  const mockRegenerateReceipts = jest.fn();
  const mockHandleEventReceipts = jest.fn();

  beforeEach(() => {
    jest.spyOn(EmailApiCallHook, 'default').mockReturnValue({
      regenerateReceipts: mockRegenerateReceipts,
    });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('renders the component with the correct text', () => {
    render(<GenerateReceipt HandleEventReceipts={mockHandleEventReceipts} />);
    expect(screen.getByTestId('container-test')).toBeInTheDocument();
    expect(screen.getByTestId('Container-content-test')).toHaveTextContent(
      'There was an issue while generating the receipt. Please click here to generate receipt'
    );
    expect(screen.getByTestId('textLinkTest')).toBeInTheDocument();
  });

  it('calls regenerateReceipts with the correct parameters and HandleEventReceipts with the correct data', async () => {
    const mockResponse = { data: { data: 'receiptData' } };
    mockRegenerateReceipts.mockResolvedValueOnce(mockResponse);

    render(<GenerateReceipt HandleEventReceipts={mockHandleEventReceipts} />);
    const link = screen.getByTestId('textLinkTest');

    fireEvent.click(link);

    expect(mockRegenerateReceipts).toHaveBeenCalledWith({
      body: {
        data: {
          cartId: undefined,
          signatureData: '',
          language: 'ENGLISH',
          printInd: false,
          emailInd: false,
          escAuthInd: 'SSN',
          documentName: 'purchaseReceipt',
          pageName: 'orderConfirmation',
        },
      },
      mock: false,
    });

    await waitFor(() => {
      expect(mockHandleEventReceipts).not.toHaveBeenCalledWith('receiptData');
    });
  });
});
