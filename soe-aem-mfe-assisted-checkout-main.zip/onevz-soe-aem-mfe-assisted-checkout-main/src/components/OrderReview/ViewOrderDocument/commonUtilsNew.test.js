import { posNbsFlowType, getAccessRole } from './commonUtils';

jest.mock('onevzsoemfecommon/Helpers');

describe('commonUtils', () => {
  beforeEach(() => {
    sessionStorage.clear();
    jest.clearAllMocks();
  });

  test('posNbsFlowType coverage', () => {
    let obj = {
      nbsTypeFlags: {
        isOrderReview: true,
        expressFlow: false,
        isReadOrder: false,
        isCheckout: false,
      },
      mfeRequestPayload: {
        onDemand: false,
        postOrder: false,
      },
    };
    posNbsFlowType(obj);

    obj = {
      nbsTypeFlags: {
        isOrderReview: false,
        expressFlow: true,
        isReadOrder: false,
        isCheckout: false,
      },
      mfeRequestPayload: {
        onDemand: false,
        postOrder: false,
      },
    };
    posNbsFlowType(obj);

    obj = {
      nbsTypeFlags: {
        isOrderReview: false,
        expressFlow: false,
        isReadOrder: false,
        isCheckout: true,
      },
      mfeRequestPayload: {
        onDemand: false,
        postOrder: false,
      },
    };
    posNbsFlowType(obj);

    obj = {
      nbsTypeFlags: {
        isOrderReview: false,
        expressFlow: false,
        isReadOrder: true,
        isCheckout: false,
      },
      mfeRequestPayload: {
        onDemand: true,
        postOrder: false,
      },
    };
    posNbsFlowType(obj);

    obj = {
      nbsTypeFlags: {
        isOrderReview: false,
        expressFlow: false,
        isReadOrder: true,
        isCheckout: false,
      },
      mfeRequestPayload: {
        onDemand: false,
        postOrder: true,
      },
    };
    posNbsFlowType(obj);
  });

  test('getAccessRole coverage', () => {
    let cartinfo = {
      data: {
        data: {
          cart: {
            customerProfile: {
              billAccounts: [
                {
                  mtns: [
                    {
                      mtn: '2817327433',
                      mobileInfoAttributes: {
                        smartFamilyParent: false,
                        accessRoles: {
                          owner: true,
                          manager: false,
                          member: false,
                        },
                      },
                    },
                  ],
                },
              ],
            },
          },
        },
      },
    };
    getAccessRole('2817327433', cartinfo);

    cartinfo = {
      data: {
        data: {
          cart: {
            customerProfile: {
              billAccounts: [
                {
                  mtns: [
                    {
                      mtn: '2817327433',
                      mobileInfoAttributes: {
                        smartFamilyParent: false,
                        accessRoles: {
                          owner: false,
                          manager: true,
                          member: false,
                        },
                      },
                    },
                  ],
                },
              ],
            },
          },
        },
      },
    };
    getAccessRole('2817327433', cartinfo);

    cartinfo = {
      data: {
        data: {
          cart: {
            customerProfile: {
              billAccounts: [
                {
                  mtns: [
                    {
                      mtn: '2817327433',
                      mobileInfoAttributes: {
                        smartFamilyParent: false,
                        accessRoles: {
                          owner: false,
                          manager: false,
                          member: true,
                        },
                      },
                    },
                  ],
                },
              ],
            },
          },
        },
      },
    };
    getAccessRole('2817327433', cartinfo);
  });
});
