import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import styled, { createGlobalStyle } from 'styled-components';

import { Modal } from '@vds/modals';
import { Title } from '@vds/typography';
import PDFViewer from 'pdf-viewer-reactjs';

import { useLazyGetViewReceiptQuery } from '../../../modules/services/APIService/APIServiceCallHook';
import { DARK_THEME_BGCOLOR, LIGHT_THEME_BGCOLOR, receiptText } from '../../../appconfig';
import { OpenViewTagging } from '../../../utils/tagging';

const PrintModalContainer = styled.div`
  display: relative;
`;

const ModalContainer = styled.div`
  border-bottom: 1px solid rgb(216, 218, 218);
  padding: 15px;
  > h5 {
    font-family: BrandFontBold, Sans-serif !important;
    font-size: 15px;
  }
`;

const MaxWidth = styled.div`
  [class^='ModalDialog-VDS-'] {
    max-width: 1133px;
  }
`;

const ComponentStyle = createGlobalStyle`
  #ViewReceiptButton {
  [id="close-button"]{
    opacity: 100%;
    }
    [class^='Overlay-VDS'] {
      background-color: rgba(0, 0, 0, 0.8);
    }
    [class^='ModalDialog-VDS'] {
      max-width:1024px; 
      border-radius: 0;
      padding: 0;
    }
    [class^='ModalDialogWrapper-VDS'] {
        > span {
          width: 100%;
          height: 100%;

        > div {
          width:100% !important;
          height: 100% !important;

          > div {
            padding:0 !important;
          }
        }
      }
    }
    [class^='StyledModalBody-VDS'] {
      height: 100% !important;
    }

    [class^='IconWrapper-VDS'] {
      z-index: 99999;
    }
    
    [class^='StyledHeader-VDS'] {
      border-bottom: 1px solid #ccc;
      position: sticky;
      top:0;
      background: #fff;
      z-index: 999;
      padding: 1rem 0;
    }
    [class^='StyledFooter-VDS'] {
      border-top: 1px solid #ccc;
      position: sticky;
      bottom:0;
      background: #fff;
      padding-top: 2rem;
    }
  }

`;

function ViewReceiptModal({
  titletxt,
  getConfirmationPageValue,
  openPrintView,
  setClosePrintVeiw,
  setViewReceiptContentPDF,
  readOrderData,
  PrintDetails,
  orderNo,
  locationCode,
}) {
  const [getViewreceipt, getViewreceiptResult] = useLazyGetViewReceiptQuery();

  const [pdfContent, setPdfContent] = useState({ content: '', isPdfContent: true });

  const isIpad = () => navigator.userAgent.match(/iPad|iPhone/i); // If user uses ipad/iphone
  const isDark = () => (window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark) || false;
  const themeFontColor = () => (isDark() ? LIGHT_THEME_BGCOLOR : DARK_THEME_BGCOLOR);
  const themeSurface = () => (isDark() ? 'dark' : 'light');

  useEffect(() => {
    if (getConfirmationPageValue && getConfirmationPageValue?.status === 'fulfilled' && openPrintView) {
      setPdfContent({
        ...pdfContent,
        content: getConfirmationPageValue?.data?.data?.response?.[0]?.installmentContractData,
        isPdfContent: true,
      });
    } else {
      const nonZeroOrderNum = orderNo?.filter((orders) => orders !== 0) || [];
      const orderNum =
        readOrderData?.cart?.orderDetails?.orderList?.[0].orderNumber === 0
          ? nonZeroOrderNum.toString()
          : readOrderData?.cart?.orderDetails?.orderList?.[0].orderNumber;

      const params = {
        meta: {
          accountNumber: readOrderData?.cart?.cartHeader?.fullAccountNumber || '',
          function: 'viewFromCustRep',
          documentName: PrintDetails?.orderDocumentDetails?.documentName || '',
          documentId: PrintDetails?.orderDocumentDetails?.documentId || '',
          orderNumber: orderNum,
          cartId: readOrderData?.cart?.cartId || '',
          isReadOrder: true,
          deviceType:
            (isIpad() &&
              PrintDetails?.orderDocumentDetails?.documentName !== 'purchaseReceipt' &&
              PrintDetails?.orderDocumentDetails?.documentName !== 'buyOutPaymentReceipt') ||
            (!isIpad() &&
              (PrintDetails?.orderDocumentDetails?.documentName === 'giftReceipt' ||
                PrintDetails?.orderDocumentDetails?.documentName === 'tradeInReceipt' ||
                PrintDetails?.orderDocumentDetails?.documentName === 'preBackOrderReceipt'))
              ? 'mobile'
              : 'desktop',
          readOrderReqInfo: {
            orderNumber: orderNo?.length > 1 ? nonZeroOrderNum : orderNo,
            orderType: readOrderData?.cart?.orderDetails?.orderType || '',
            locationCode: locationCode || '',
            channelId: 'OMNI-RETAIL',
            accOnly: readOrderData?.cart?.cartHeader?.accOnly || false,
          },
        },
      };
      getViewreceipt({
        body: params,
        mock: false,
      });
    }
  }, []);
  useEffect(() => {
    if (getViewreceiptResult?.data?.status === 'Success') {
      if (getViewreceiptResult?.data?.data?.getDocument?.barCode) {
        setPdfContent({ ...pdfContent, content: '', isPdfContent: false });
      } else {
        const getDocumentList = {
          viewReceipt: getViewreceiptResult?.data?.data?.getDocument?.receiptData,
          viewReceiptArr: getViewreceiptResult?.data?.data?.getDocument,
          isNext: getViewreceiptResult?.data?.data?.getDocument.length > 1,
          isPrev: false,
          currentIndex: 0,
          length: getViewreceiptResult?.data?.data?.getDocument.length,
        };
        setViewReceiptContentPDF(getDocumentList);
        setPdfContent({
          ...pdfContent,
          content: getViewreceiptResult?.data?.data?.getDocument?.receiptData,
          isPdfContent: true,
        });
      }
    }
  }, [getViewreceiptResult?.data?.status]);

  const receiptTitle = titletxt || receiptText;
  const pdfContentData = `data:application/pdf;base64,${pdfContent?.content}`;

  return (
    <PrintModalContainer data-testid='PrintModalContainerTest'>
      {openPrintView && (
        <MaxWidth data-testId='ViewReceiptButton'>
          <ComponentStyle />
          <Modal
            id='ViewReceiptButton'
            data-testId='ViewReceiptButtonTest'
            fullScreenDialog
            width={100}
            disableFocusLock
            opened={openPrintView && pdfContent?.isPdfContent}
            surface={themeSurface()}
            disableOutsideClick
            disableAnimation
            onOpenedChange={(opened) => {
              if (!opened) {
                OpenViewTagging('closeView', 'Close', 'EUP|RFEX-read-order', readOrderData);
                setClosePrintVeiw(false, getViewreceiptResult?.data?.data?.getDocument?.barCode);
              }
            }}
          >
            <ModalContainer>
              <Title data-testid='titileTest' bold size='small' color={themeFontColor()}>
                {receiptTitle}
              </Title>
            </ModalContainer>
            <div>
              {pdfContent?.content &&
                (isIpad() ? (
                  <PDFViewer
                    data-testid='pdfViewer'
                    document={{ base64: pdfContent?.content }}
                    navbarOnTop
                    scale={1.5}
                    canvasCss='pdfCanvas u-marginTopMedium u-paddingTopMedium'
                  />
                ) : (
                  <object
                    data={pdfContentData}
                    width='95%'
                    height='800px'
                    title={titletxt || 'Purchase Receipt'}
                    type='application/pdf'
                    aria-label='receipt'
                  />
                ))}
            </div>
          </Modal>
        </MaxWidth>
      )}
    </PrintModalContainer>
  );
}

ViewReceiptModal.propTypes = {
  titletxt: PropTypes.string,
  getConfirmationPageValue: PropTypes.object,
  openPrintView: PropTypes.bool,
  setClosePrintVeiw: PropTypes.func,
  setViewReceiptContentPDF: PropTypes.func,
  readOrderData: PropTypes.object,
  PrintDetails: PropTypes.object,
  orderNo: PropTypes.string,
  locationCode: PropTypes.string,
};

export default ViewReceiptModal;
