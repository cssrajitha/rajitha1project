// Filename: commonUtils.test.js
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import {
  isRfexFlow,
  roPrintReciptFlagInd,
  indirectCheckVOreceipt,
  printDirectThermalPrint,
  orderDocumetRecipt,
  printerDevices,
  posNbsFlowType,
  getAccessRole,
  nbsMfeModuleProps,
  showGiftCardData,
} from './commonUtils';

jest.mock('onevzsoemfecommon/Helpers', () => ({
  getQueryParamByName: jest.fn(),
}));

describe('commonUtils', () => {
  sessionStorage.setItem('readOrder', 'false');
  sessionStorage.setItem('channel', 'OMNI-RETAIL-TAB');
  sessionStorage.setItem('refundexchange', 'true');
  sessionStorage.setItem('roPrintReciptFlagInd', 'true');
  const orderConfirmationData = {
    data: {},
  };

  beforeEach(() => {
    sessionStorage.clear();
    jest.clearAllMocks();
  });

  test('isRfexFlow should return sessionStorage value', () => {
    sessionStorage.setItem('refundexchange', 'true');
    expect(isRfexFlow).toBe(null);
  });

  test('roPrintReciptFlagInd should return sessionStorage value or empty string', () => {
    sessionStorage.setItem('roPrintReciptFlagInd', 'true');
    expect(roPrintReciptFlagInd).toBe('');
    sessionStorage.removeItem('roPrintReciptFlagInd');
    expect(roPrintReciptFlagInd).toBe('');
  });

  test('indirectCheckVOreceipt should return correct value based on sessionStorage', () => {
    sessionStorage.setItem('channel', 'OMNI-INDIRECT');
    sessionStorage.setItem('roPrintReciptFlagInd', 'true');
    expect(indirectCheckVOreceipt).toBe(undefined);
  });

  test('printDirectThermalPrint should call thermalPrint.connect with correct params', () => {
    sessionStorage.setItem('roPrintReciptFlagInd', 'true');
    const mockDevice = {
      thermalPrint: {
        connect: jest.fn(),
      },
    };
    const viewreceiptpdcContent = { viewReceipt: 'receipt text' };
    const orderConfirmationData1 = {
      data: {
        getConfirmationPage: {
          orderNumber: '12345',
          locationCode: 'LOC001',
        },
      },
    };
    printDirectThermalPrint(viewreceiptpdcContent, orderConfirmationData1, mockDevice);
    expect(mockDevice.thermalPrint.connect).toHaveBeenCalledWith('receipt text', '01', 'FALSE', {
      orderNumber: '12345',
      location: 'LOC001',
      hasSignature: false,
    });
  });

  test('orderDocumetRecipt should return correct request object', () => {
    sessionStorage.setItem('roPrintReciptFlagInd', 'true');
    const mockDevice = {
      thermalPrint: {
        connect: jest.fn(),
      },
    };
    const viewreceiptpdcContent = { viewReceipt: 'receipt text' };
    printDirectThermalPrint(viewreceiptpdcContent, orderConfirmationData, mockDevice);
    const readOrderData = {
      cart: {
        orderDetails: { orderType: 'type1', orderList: [{ orderNumber: '12345' }] },
        cartHeader: { cartId: 'cart123', fullAccountNumber: 'acc123' },
        lineDetails: { lineInfo: [{ mobileNumber: '9876543210' }] },
      },
    };
    const orderNo = '12345';
    const result = orderDocumetRecipt(readOrderData, orderNo);
    expect(result).toEqual({
      data: {
        orderNumber: '12345',
        cartId: 'cart123',
        locationCode: '',
        mtn: ['9876543210'],
        accountNumber: 'acc123',
        orderType: 'type1',
        isReadOrder: true,
      },
    });
  });
  test('orderDocumetRecipt should return correct request object', () => {
    const mockDevice = {
      thermalPrint: {
        connect: jest.fn(),
      },
    };
    const viewreceiptpdcContent = { viewReceipt: 'receipt text' };
    printDirectThermalPrint(viewreceiptpdcContent, orderConfirmationData, mockDevice);
    const readOrderData = {};
    const orderNo = '12345';
    const result = orderDocumetRecipt(readOrderData, orderNo);
    expect(result).not.toEqual({
      data: {
        orderNumber: '12345',
        cartId: '',
        locationCode: '',
        mtn: ['9876543210', undefined],
        accountNumber: '',
        orderType: '',
        isReadOrder: true,
      },
    });
  });

  test('posNbsFlowType should return correct flow type', () => {
    const obj = {
      nbsTypeFlags: { isOrderReview: true },
      mfeRequestPayload: {},
    };
    expect(posNbsFlowType(obj)).toBe('preorder');
  });
  test('posNbsFlowType should return correct flow type1', () => {
    const obj = {
      nbsTypeFlags: { expressFlow: true },
      mfeRequestPayload: {},
    };
    expect(posNbsFlowType(obj)).toBe('postorder');
  });
  test('posNbsFlowType should return correct flow type2', () => {
    const obj = {
      nbsTypeFlags: { isCheckout: true },
      mfeRequestPayload: {},
    };
    expect(posNbsFlowType(obj)).toBe('postorder');
  });
  test('posNbsFlowType should return correct flow type5', () => {
    const obj = {
      nbsTypeFlags: { onDemand: true },
      mfeRequestPayload: {},
    };
    expect(posNbsFlowType(obj)).toBe('preorder');
  });
  test('posNbsFlowType should return correct flow type3', () => {
    const obj = {
      nbsTypeFlags: { isReadOrder: true, postOrder: true },
      mfeRequestPayload: {},
    };
    expect(posNbsFlowType(obj)).toBe('preorder');
  });

  test('posNbsFlowType should return correct flow type6', () => {
    const obj = {
      nbsTypeFlags: { isReadOrder: true, onDemand: true },
      mfeRequestPayload: {},
    };
    expect(posNbsFlowType(obj)).toBe('preorder');
  });

  test('getAccessRole should return correct role', () => {
    const cartInfo = {
      data: {
        data: {
          cart: {
            customerProfile: {
              billAccounts: [
                {
                  mtns: [
                    {
                      mtn: '12345',
                      mobileInfoAttributes: { accessRoles: { manager: true } },
                    },
                  ],
                },
              ],
            },
          },
        },
      },
    };
    expect(getAccessRole('12345', cartInfo)).toBe('accountManager');
  });

  test('getAccessRole should return correct role', () => {
    const cartInfo = {
      data: {
        data: {
          cart: {
            customerProfile: {
              billAccounts: [
                {
                  mtns: [
                    {
                      mtn: '12345',
                      mobileInfoAttributes: { accessRoles: { owner: true } },
                    },
                  ],
                },
              ],
            },
          },
        },
      },
    };
    expect(getAccessRole('12345', cartInfo)).toBe('accountHolder');
  });

  test('getAccessRole should return correct role', () => {
    const cartInfo = {
      data: {
        data: {
          cart: {
            customerProfile: {
              billAccounts: [
                {
                  mtns: [
                    {
                      mtn: '12345',
                      mobileInfoAttributes: { accessRoles: { member: true } },
                    },
                  ],
                },
              ],
            },
          },
        },
      },
    };
    expect(getAccessRole('12345', cartInfo)).toBe('mobileSecure');
  });
  test('nbsMfeModuleProps should return correct module props', () => {
    const nbsState = { isReadOrder: true, isOrderReview: false };
    const unifiedMfeRequest = { onDemand: true, vzwRole: 'role1' };
    const result = nbsMfeModuleProps(nbsState, unifiedMfeRequest);
    expect(result).toEqual({
      applicationType: 'POS_ORDERING',
      mfeRequestPayload: { onDemand: true },
      nbsTypeFlags: { isReadOrder: true, isOrderReview: false },
      unifiedNbsData: undefined,
      vzwRole: 'role1',
      showSuspenseLoader: true,
    });
  });
});

describe('printerDevices', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should return request object with locationCode from query parameter', () => {
    getQueryParamByName.mockReturnValue('QUERY_LOCATION_CODE');
    const result = printerDevices('LOCATION_CODE');
    expect(result).toEqual({ locationCode: 'QUERY_LOCATION_CODE' });
    expect(getQueryParamByName).toHaveBeenCalledWith('orderLocationCode');
  });

  it('should return request object with locationCode from argument if query parameter is empty', () => {
    getQueryParamByName.mockReturnValue('');
    const result = printerDevices('LOCATION_CODE');
    expect(result).toEqual({ locationCode: 'LOCATION_CODE' });
    expect(getQueryParamByName).toHaveBeenCalledWith('orderLocationCode');
  });

  it('should return request object with empty locationCode if both query parameter and argument are empty', () => {
    getQueryParamByName.mockReturnValue('');
    const result = printerDevices('');
    expect(result).toEqual({ locationCode: '' });
    expect(getQueryParamByName).toHaveBeenCalledWith('orderLocationCode');
  });
});

describe('giftcard data', () => {
  sessionStorage.setItem('readOrder', 'false');
  sessionStorage.setItem('channel', 'OMNI-RETAIL-TAB');
  sessionStorage.setItem('refundexchange', 'true');
  sessionStorage.setItem('roPrintReciptFlagInd', 'true');
  const orderConfirmationData = {
    data: {},
  };

  beforeEach(() => {
    sessionStorage.clear();
    jest.clearAllMocks();
  });

  test('isQAFlow true', () => {
    showGiftCardData(true,  {
      "discountAmount": 0.0,
      "deviceDollarApplied": 0.0,
      "promoHubOfferList": {
          "promoHubOfferList": [],
          "offerCount": 0
      },
      "qrScanNeededForEsimActivation": false,
      "isPreconfigureDuringAddDevice": false,
      "accessoryGiftCardId": "CULTHAOF7639",
      "accessoryGiftCardAmount": 100.0,
      "tradeInAmountTowardsUserDPUsed": 0.0,
      "vendingKioskItem": "false",
      "tradeInAutoPull": false,
      "priceAdjustment": false,
      "priceAdjustmentQty": 0,
      "newPurchasedQty": 0,
      "selectedForRFEX": false,
      "selectedForPAD": false,
      "bogoItem": false,
      "refxItemSeqNum": 0,
      "restrictedAccySku": false,
      "maxAccyPurchaseLimit": false,
      "giftCard": false,
      "orderNumber": 0,
      "itemCode": "GCVZWBLK0518",
      "totalPriceWithDiscount": 100.0,
      "sorId": "GCVZWBLK0518",
      "cartItemType": "SOFT_SKU",
      "description": "Verizon Gift Cards",
      "qty": 1,
      "bundleSeqNum": 0,
      "itemPrice": "100.0",
      "deviceId": "CULTHAOF7639",
      "discountedPercentage": 0.0,
      "discountedPrice": 100.0,
      "buyOutTaxAmountUnbilled": 0.0,
      "buyOutAmountWithoutTax": 0.0,
      "prodCode1": "CRD",
      "prodCode2": "GIF",
      "prodCode3": "000",
      "prodCode4": "000",
      "catalogPrice": 100.0,
      "instantCreditAmountUsed": 0.0,
      "instantCreditAmountUsedForTaxes": 0.0,
      "unitTaxBasedPrice": 100.0,
      "itemNrpPrice": 100.0,
      "discounts": [],
      "availableReasonCode": [],
      "isCustomerProvidedSIM": false,
      "isNetworkExtender": false,
      "ispuEligible": false,
      "itemSeqNum": 1,
      "sddEligible": false,
      "smartIMEI": false,
      "year": 0,
      "sellerPrice": "0.0",
      "productId": "acc10120010",
      "taxDetailsList": [],
      "iconicPhone": false,
      "ringBell": false,
      "isPreconfigureEnabled": false,
      "isHumDevice": false,
      "isSmartLocator": false,
      "isSecurityAlarm": false,
      "isMotoMod": false,
      "isConnectedCar": false,
      "accountLevelAccessory": false,
      "byodESimPhone": false,
      "appleCareAccessoryFlag": false,
      "quantityAllowed": false,
      "isDfoSelected": false
  })
  });
  test('isQAFlow true empty card', () => {
    showGiftCardData(true,  {
      "discountAmount": 0.0,
      "deviceDollarApplied": 0.0,
      "promoHubOfferList": {
          "promoHubOfferList": [],
          "offerCount": 0
      },
      "qrScanNeededForEsimActivation": false,
      "isPreconfigureDuringAddDevice": false,
      "accessoryGiftCardId": "",
      "accessoryGiftCardAmount": 100.0,
      "tradeInAmountTowardsUserDPUsed": 0.0,
      "vendingKioskItem": "false",
      "tradeInAutoPull": false,
      "priceAdjustment": false,
      "priceAdjustmentQty": 0,
      "newPurchasedQty": 0,
      "selectedForRFEX": false,
      "selectedForPAD": false,
      "bogoItem": false,
      "refxItemSeqNum": 0,
      "restrictedAccySku": false,
      "maxAccyPurchaseLimit": false,
      "giftCard": false,
      "orderNumber": 0,
      "itemCode": "GCVZWBLK0518",
      "totalPriceWithDiscount": 100.0,
      "sorId": "GCVZWBLK0518",
      "cartItemType": "SOFT_SKU",
      "description": "Verizon Gift Cards",
      "qty": 1,
      "bundleSeqNum": 0,
      "itemPrice": "100.0",
      "deviceId": "CULTHAOF7639",
      "discountedPercentage": 0.0,
      "discountedPrice": 100.0,
      "buyOutTaxAmountUnbilled": 0.0,
      "buyOutAmountWithoutTax": 0.0,
      "prodCode1": "CRD",
      "prodCode2": "GIF",
      "prodCode3": "000",
      "prodCode4": "000",
      "catalogPrice": 100.0,
      "instantCreditAmountUsed": 0.0,
      "instantCreditAmountUsedForTaxes": 0.0,
      "unitTaxBasedPrice": 100.0,
      "itemNrpPrice": 100.0,
      "discounts": [],
      "availableReasonCode": [],
      "isCustomerProvidedSIM": false,
      "isNetworkExtender": false,
      "ispuEligible": false,
      "itemSeqNum": 1,
      "sddEligible": false,
      "smartIMEI": false,
      "year": 0,
      "sellerPrice": "0.0",
      "productId": "acc10120010",
      "taxDetailsList": [],
      "iconicPhone": false,
      "ringBell": false,
      "isPreconfigureEnabled": false,
      "isHumDevice": false,
      "isSmartLocator": false,
      "isSecurityAlarm": false,
      "isMotoMod": false,
      "isConnectedCar": false,
      "accountLevelAccessory": false,
      "byodESimPhone": false,
      "appleCareAccessoryFlag": false,
      "quantityAllowed": false,
      "isDfoSelected": false
  })
  });
  test('isQAFlow true', () => {
    showGiftCardData(true,  {
      "discountAmount": 0.0,
      "deviceDollarApplied": 0.0,
      "promoHubOfferList": {
          "promoHubOfferList": [],
          "offerCount": 0
      },
      "qrScanNeededForEsimActivation": false,
      "isPreconfigureDuringAddDevice": false,
      "accessoryGiftCardId": "7639",
      "accessoryGiftCardAmount": 100.0,
      "tradeInAmountTowardsUserDPUsed": 0.0,
      "vendingKioskItem": "false",
      "tradeInAutoPull": false,
      "priceAdjustment": false,
      "priceAdjustmentQty": 0,
      "newPurchasedQty": 0,
      "selectedForRFEX": false,
      "selectedForPAD": false,
      "bogoItem": false,
      "refxItemSeqNum": 0,
      "restrictedAccySku": false,
      "maxAccyPurchaseLimit": false,
      "giftCard": false,
      "orderNumber": 0,
      "itemCode": "GCVZWBLK0518",
      "totalPriceWithDiscount": 100.0,
      "sorId": "GCVZWBLK0518",
      "cartItemType": "SOFT_SKU",
      "description": "Verizon Gift Cards",
      "qty": 1,
      "bundleSeqNum": 0,
      "itemPrice": "100.0",
      "deviceId": "CULTHAOF7639",
      "discountedPercentage": 0.0,
      "discountedPrice": 100.0,
      "buyOutTaxAmountUnbilled": 0.0,
      "buyOutAmountWithoutTax": 0.0,
      "prodCode1": "CRD",
      "prodCode2": "GIF",
      "prodCode3": "000",
      "prodCode4": "000",
      "catalogPrice": 100.0,
      "instantCreditAmountUsed": 0.0,
      "instantCreditAmountUsedForTaxes": 0.0,
      "unitTaxBasedPrice": 100.0,
      "itemNrpPrice": 100.0,
      "discounts": [],
      "availableReasonCode": [],
      "isCustomerProvidedSIM": false,
      "isNetworkExtender": false,
      "ispuEligible": false,
      "itemSeqNum": 1,
      "sddEligible": false,
      "smartIMEI": false,
      "year": 0,
      "sellerPrice": "0.0",
      "productId": "acc10120010",
      "taxDetailsList": [],
      "iconicPhone": false,
      "ringBell": false,
      "isPreconfigureEnabled": false,
      "isHumDevice": false,
      "isSmartLocator": false,
      "isSecurityAlarm": false,
      "isMotoMod": false,
      "isConnectedCar": false,
      "accountLevelAccessory": false,
      "byodESimPhone": false,
      "appleCareAccessoryFlag": false,
      "quantityAllowed": false,
      "isDfoSelected": false
  })
  });
  test('isQAFlow true flag on', () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ encryptGCNumberForQAFFlag: 'TRUE', vtNbsMfeFFlag: 'TRUE' }));
    showGiftCardData(true,  {
      "discountAmount": 0.0,
      "deviceDollarApplied": 0.0,
      "promoHubOfferList": {
          "promoHubOfferList": [],
          "offerCount": 0
      },
      "qrScanNeededForEsimActivation": false,
      "isPreconfigureDuringAddDevice": false,
      "accessoryGiftCardId": "CULTHAOF7639",
      "accessoryGiftCardAmount": 100.0,
      "tradeInAmountTowardsUserDPUsed": 0.0,
      "vendingKioskItem": "false",
      "tradeInAutoPull": false,
      "priceAdjustment": false,
      "priceAdjustmentQty": 0,
      "newPurchasedQty": 0,
      "selectedForRFEX": false,
      "selectedForPAD": false,
      "bogoItem": false,
      "refxItemSeqNum": 0,
      "restrictedAccySku": false,
      "maxAccyPurchaseLimit": false,
      "giftCard": false,
      "orderNumber": 0,
      "itemCode": "GCVZWBLK0518",
      "totalPriceWithDiscount": 100.0,
      "sorId": "GCVZWBLK0518",
      "cartItemType": "SOFT_SKU",
      "description": "Verizon Gift Cards",
      "qty": 1,
      "bundleSeqNum": 0,
      "itemPrice": "100.0",
      "deviceId": "CULTHAOF7639",
      "discountedPercentage": 0.0,
      "discountedPrice": 100.0,
      "buyOutTaxAmountUnbilled": 0.0,
      "buyOutAmountWithoutTax": 0.0,
      "prodCode1": "CRD",
      "prodCode2": "GIF",
      "prodCode3": "000",
      "prodCode4": "000",
      "catalogPrice": 100.0,
      "instantCreditAmountUsed": 0.0,
      "instantCreditAmountUsedForTaxes": 0.0,
      "unitTaxBasedPrice": 100.0,
      "itemNrpPrice": 100.0,
      "discounts": [],
      "availableReasonCode": [],
      "isCustomerProvidedSIM": false,
      "isNetworkExtender": false,
      "ispuEligible": false,
      "itemSeqNum": 1,
      "sddEligible": false,
      "smartIMEI": false,
      "year": 0,
      "sellerPrice": "0.0",
      "productId": "acc10120010",
      "taxDetailsList": [],
      "iconicPhone": false,
      "ringBell": false,
      "isPreconfigureEnabled": false,
      "isHumDevice": false,
      "isSmartLocator": false,
      "isSecurityAlarm": false,
      "isMotoMod": false,
      "isConnectedCar": false,
      "accountLevelAccessory": false,
      "byodESimPhone": false,
      "appleCareAccessoryFlag": false,
      "quantityAllowed": false,
      "isDfoSelected": false
  })
  });
});