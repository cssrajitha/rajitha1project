import React from 'react';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { isIpad } from 'onevzsoemfeframework/DomService';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../../modules/store';
import ViewReceiptModal from './ViewReceiptModal';
import { useLazyGetViewReceiptQuery } from '../../../modules/services/APIService/APIServiceCallHook';

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => jest.fn(),
}));

jest.mock('../../../modules/services/APIService/APIServiceCallHook', () => ({
  ...jest.requireActual('../../../modules/services/APIService/APIServiceCallHook'),
  useLazyGetViewReceiptQuery: jest.fn(),
}));

jest.mock('onevzsoemfeframework/DomService', () => ({
  isIpad: jest.fn(),
}));

describe('ViewReceiptModal', () => {
  const mockSetClosePrintVeiw = jest.fn();
  isIpad.mockReturnValue(false);
  beforeEach(() => {
    jest.clearAllMocks();
    useLazyGetViewReceiptQuery.mockReturnValue([
      jest.fn(),
      {
        data: {
          status: 'Success',
          data: {
            getDocument: {
              receiptData: 'mockPdfContent',
              barCode: 'mockBarCode',
            },
          },
          meta: {
            timestamp: '2025-02-06T12:41:25Z',
            cxpCorrelationId: '2025-02-06T12:41:25.+0000:5c67cc8bc7eee10b:cxp-document-services-7d54bd4d8-jshrp:nssit3',
          },
        },
      },
    ]);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test('renders PDF content when getConfirmationPageValue is fulfilled and openPrintView is true', () => {
    isIpad.mockReturnValue(true);
    const getConfirmationPageValue = {
      status: 'fulfilled',
      data: {
        data: {
          response: [
            {
              installmentContractData: 'mockPdfContent',
            },
          ],
        },
        status: 'Success',
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <ViewReceiptModal
            name='testName'
            title='testTitle'
            getConfirmationPageValue={getConfirmationPageValue}
            cartDetails={{ cart: { prePayValue: { orderDetails: { isPrePayCart: 'Y' } } } }}
            openPrintView
            setClosePrintVeiw={mockSetClosePrintVeiw}
            setViewReceiptContentPDF={jest.fn()}
            orderNo={[0, 123456789]}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const title = screen.getByTestId('PrintModalContainerTest');
    expect(title).toBeInTheDocument();

    waitFor(() => {
      const modalclosebutton = screen.getByTestId('modal-close-button');
      fireEvent.click(modalclosebutton);
    });
  });

  test('does not render PDF content when openPrintView is true get viewreceipt', () => {
    useLazyGetViewReceiptQuery.mockReturnValue([
      jest.fn(),
      {
        status: 'Success',
        data: {
          data: {
            getDocument: {
              receiptData: 'mockPdfContent',
            },
          },
          status: 'Success',
        },
      },
    ]);
    isIpad.mockReturnValue(true);
    const getVeiwReceipt = {
      data: {
        getDocument: {
          receiptData: 'mockPdfContent',
          barCode: 'mockBarCode',
        },
      },
    };
    render(
      <ViewReceiptModal
        name='testName'
        title='testTitle'
        getConfirmationPageValue={null}
        cartDetails={{ cart: { prePayValue: { orderDetails: { isPrePayCart: 'Y' } } } }}
        openPrintView={false}
        setClosePrintVeiw={mockSetClosePrintVeiw}
        getViewreceiptResult={getVeiwReceipt}
        setViewReceiptContentPDF={jest.fn()}
        orderDetails={{ orderDocumentDetails: { orderNumber: 123456789, documentName: 'purchaseReceipt' } }}
      />,
    );

    const title = screen.getByTestId('PrintModalContainerTest');
    expect(title).toBeInTheDocument();
  });

  test('does not render PDF content when openPrintView is true', () => {
    window.mfe = { scmCheckoutMfeEnable: true, isDark: true };
    useLazyGetViewReceiptQuery.mockReturnValue([
      jest.fn(),
      {
        status: 'Success',
        data: {
          data: {
            getDocument: {
              receiptData: 'mockPdfContent',
              barCode: 'mockBarCode',
            },
            status: 'Success',
          },
        },
      },
    ]);
    const getVeiwReceipt = {
      data: {
        getDocument: {
          receiptData: 'mockPdfContent',
        },
      },
    };
    render(
      <ViewReceiptModal
        name='testName'
        title='testTitle'
        getConfirmationPageValue={null}
        cartDetails={{ cart: { prePayValue: { orderDetails: { isPrePayCart: 'Y' } } } }}
        openPrintView={false}
        setClosePrintVeiw={mockSetClosePrintVeiw}
        getViewreceiptResult={getVeiwReceipt}
        setViewReceiptContentPDF={jest.fn()}
      />,
    );

    const title = screen.getByTestId('PrintModalContainerTest');
    expect(title).toBeInTheDocument();
  });

  test('calls setClosePrintVeiw with false when modal is closed', () => {
    isIpad.mockReturnValue(true);
    render(
      <ViewReceiptModal
        name='testName'
        title='testTitle'
        getConfirmationPageValue={null}
        cartDetails={{ cart: { prePayValue: { orderDetails: { isPrePayCart: 'Y' } } } }}
        openPrintView
        setClosePrintVeiw={mockSetClosePrintVeiw}
        setViewReceiptContentPDF={jest.fn()}
      />,
    );

    global.window.vzdl = { page: { detail: 'View' } };
    expect(window.vzdl.page.detail).toEqual('View');
  });
  test('calls setClosePrintVeiw readorderdata empty', () => {
    isIpad.mockReturnValue(true);
    render(
      <ViewReceiptModal
        name='testName'
        title='testTitle'
        getConfirmationPageValue={null}
        cartDetails={{ cart: { prePayValue: { orderDetails: { isPrePayCart: 'Y' } } } }}
        openPrintView
        setClosePrintVeiw={mockSetClosePrintVeiw}
        setViewReceiptContentPDF={jest.fn()}
        readOrderData={{ cart: { orderDetails: { orderList: [{ orderNumber: 0 }] } } }}
      />,
    );

    global.window.vzdl = { page: { detail: 'View' } };
    expect(window.vzdl.page.detail).toEqual('View');
  });
});
