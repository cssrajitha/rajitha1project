import React from 'react';
import { TextLink } from '@vds/buttons';
import { Icon } from '@vds/icons';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import EmailApiCallHook from '../../../modules/services/APIService/EmailApiCallHook';

export const StyledRoDisplayErrorMessage = styled.div`
  font-weight: bold;
  padding-top: 28px;
  padding-bottom: 28px;
  margin-top: 10px;
  padding-left: 0px !important;
  border-bottom: 1px solid #d8dada;
  [class^='StyledAnchor-VDS'] {
    font-size: large !important;
  }
`;
const StyledTextLink = styled(TextLink)`
  color: #007bff; /* Replace with the color value for 'u-colorInfo' */
  text-decoration: none;
  cursor: pointer;
  font-weight: bold !important;
  font-size: large !important;

  &:hover {
    text-decoration: underline;
  }

  &:focus {
    outline: none;
  }
`;

const StyledIcon = styled.span`
  background-color: white;
  border-radius: 50%;
  top: 5px;
  #infoIcon {
    position: relative !important;
    top: 3px;
  }
`;

const TextcontentLabel = styled.span`
  padding-left: 5px;
  font-size: 18px;
`;

function GenerateReceipt({ HandleEventReceipts, readOrderData }) {
  const { regenerateReceipts } = EmailApiCallHook();
  let isRegeneratedReceiptTriggered = false;

  const regenerateReceiptsReq = () => {
    const req = {
      data: {
        cartId: readOrderData?.cart?.cartHeader?.cartId,
        signatureData: '',
        language: 'ENGLISH',
        printInd: false,
        emailInd: false,
        escAuthInd: 'SSN',
        documentName: 'purchaseReceipt',
        pageName: 'orderConfirmation',
      },
    };

    regenerateReceipts({ body: req, mock: false })
      .then((res) => {
        isRegeneratedReceiptTriggered = true;
        HandleEventReceipts(res?.data?.data, isRegeneratedReceiptTriggered);
      })
      .catch((error) => {
        HandleEventReceipts(error, false); // error handling for regenerate receipt
      });
  };

  return (
    <StyledRoDisplayErrorMessage data-testid='container-test'>
      <StyledIcon>
        <Icon lineColor='#ffbc3d' name='info' id='infoIcon' />
      </StyledIcon>
      <TextcontentLabel data-testid='Container-content-test'>
        There was an issue while generating the receipt. Please &nbsp;
        <StyledTextLink data-testid='textLinkTest' tabIndex='0' role='button' onClick={regenerateReceiptsReq}>
          click here
        </StyledTextLink>
        &nbsp;to generate receipt
      </TextcontentLabel>
    </StyledRoDisplayErrorMessage>
  );
}

GenerateReceipt.propTypes = {
  HandleEventReceipts: PropTypes.func.isRequired,
  readOrderData: PropTypes.object.isRequired,
};

export default GenerateReceipt;
