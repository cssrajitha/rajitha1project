import { Modal, ModalBody } from '@vds/modals';
import React, { Fragment, useEffect, useState } from 'react';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import PropTypes from 'prop-types';
import { useNavigate } from 'react-router-dom';
// eslint-disable-next-line import/no-extraneous-dependencies
import withPeripherals from '@vz-soe-utils/withperipherals';
// eslint-disable-next-line import/no-extraneous-dependencies
import { isIpad } from 'onevzsoemfeframework/DomService';
import styled, { createGlobalStyle } from 'styled-components';
import { Icon } from '@vds/icons';
import { Title } from '@vds/typography';
import { Button, TextLink } from '@vds/buttons';
import { Input } from '@vds/inputs';
import { useDispatch } from 'react-redux';
import { Divider } from '../../ItemsAtGlance/ItemsAtGlance';
import ViewReceiptModal from './ViewReceiptModal';
import { orderDocumetRecipt, printDirectThermalPrint, printerDevices } from './commonUtils';
import EmailApiCallHook from '../../../modules/services/APIService/EmailApiCallHook';
import InfoApiCallHook from '../../../modules/services/APIService/InfoAPICallHook';
import { CUSTOMER_AGREEMENT, documentReceiptsItems, orderNumberLabel, RING_AGREEMENT } from '../../../appconfig';
import GenerateReceipt from './generateReceipt';
import { OpenViewTagging } from '../../../utils/tagging';

const ViewOrderDocumentContainer = styled.div`
  .smaller {
    font-size: smaller !important;
    font-weight: bold !important;
  }
  .u-paddingTop28,
  .u-paddingY28 {
    padding-top: 28px !important;
  }
  .bold {
    font-family: BrandFontBold, Sans-serif !important;
    font-size: 18px;
  }
`;
const FooterContent = styled.div`
  position: fixed;
  bottom: 0;
  width: 100%;
  padding: 10px;
  background: #fff;
  border-top: 1px solid #ccc;
  z-index: 1000;
`;

const CustomModalBody = styled.div`
  height: auto;
  overflow: auto;
  padding-bottom: 60px;
`;
const StyledDocumentName = styled.div`
  display: flex;
  flex: 0 0 41.66667%;
  max-width: 41.66667%;
  font-weight: bold;
  font-size: 18px;
`;

const StyledDocumentButtonList = styled.div`
  display: flex;
  gap: 10px;
`;

const StyledOrderNumberLabel = styled.div`
  display: flex;
  font-weight: bold;
  padding-top: 28px;
  padding-bottom: 28px;
  margin-top: 10px;
  border-bottom: 1px solid #d8dada;
  font-size: 18px;
`;
const LabelText = styled.span`
  font-weight: bold;
`;
const LabelValue = styled.span`
  font-weight: normal;
  padding-left: 10px;
`;
export const ModalWrapper = styled.div`
  #ModalWrapperId {
    [class^='Overlay-VDS'] {
      background-color: rgba(0, 0, 0);
    }
    [class^='StyledFooter-VDS'] {
      padding: 0px !important;
    }
    [class^='ModalDialogWrapper-VDS'] {
      padding: 0px !important;
    }
  }
`;

const DocumentCotnainer = styled.div`
  position: relative;
`;

const ComponentStyle = createGlobalStyle`

    [class^='ModalDialog-VDS'] {
    padding:8px 0px 0px 12px !important;
      width: 100%;
      max-width: 1133px !important;
      
    }

    [class^='ModalDialogWrapper-VDS'] {
    padding:0px 0px 5px 10px !important;
        > span {
        height: 100% !important;
        > div {
        height: 100% !important;
        > div {
    display: inline-block !important;
    position: relative !important;
       
}
        }
}
}
      
       [class^='StyledAnchor-VDS'] {
      font-weight: bold; 
      font-size: smaller !important;
    }

    [class^='Overlay-VDS']{
    background: rgba(0, 0, 0);
    }

    [id="close-button"]{
    opacity: 0;
    }
    [class^="StyledModalBody-VDS"]{
    padding:0px;
}

`;

const EmailListContainer = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
  align-items: center;
`;
const EmailInputContainer = styled.div`
  flex-direction: row;
  justify-content: flex-end;
  align-items: center;
`;
const PaddingTopSmall = styled.div`
  padding-top: 10px;
`;

export const Header = styled.div`
  box-sizing: border-box;
  margin: 0 -8px;
  padding: 0;
`;

export const TitleWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  margin: 10px;
`;

export const IconWrapper = styled.div`
  cursor: pointer;
  color: #000000 !important;
`;
const NotradeInReceipt = styled.div`
  text-align: right;
`;
export const DocumentContent = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid #d8dada;
  padding: 20px 0;
`;
const StyledBtnAndEmail = styled.div`
  display: flex;
  flex-direction: column;
  gap: 10px;
  text-justify: left;
  min-width: 500px;
`;

const StyledEmailList = styled.div`
  font-size: 18px;
  padding-right: 10px;
`;

function ViewOrderDocument(props) {
  const dispatch = useDispatch();

  let isPurchaseReceiptPresent = false;
  let isRegeneratedReceiptTriggered = false;

  const { getDevices, getDevicesResult, emailReceipt, emailReceiptResult } = EmailApiCallHook();
  const {
    readOrderDPReceiptApi,
    updateVisionRemark,
    getUpdateVisionRemarkResponse,
    readOrderDocInfo,
    readOrderDocInfoRes,
  } = InfoApiCallHook();
  const {
    readorder,
    locationCode,
    emailId,
    orderNo,
    value,
    handleToggle,
    cartDetails,
    readOrderData,
    customerProfile,
    customerInfo,
    data,
    isRefundReadOrder,
    setshowViewAndPrintReceipt,
  } = props;
  const [readOrderViewReceipt, setReadOrderViewReceipt] = useState({});
  const [open, setOpen] = useState(value);
  const [viewreceiptpdcContent, setViewreceiptpdcContent] = useState({
    viewReceipt: {},
    viewReceiptArr: [],
    isNext: 0,
    isPrev: false,
    currentIndex: 0,
    length: 0,
  });
  const [openPrintDetails, setopenPrintDetails] = useState({
    openPrintView: false,
    PrintDetails: {},
    printerDevicesList: [],
    isGetDevicesLoading: false,
    orderDocumentDetails: {},
  });
  const orderNumber =
    Array.isArray(orderNo) && orderNo.length > 1
      ? orderNo.filter((num) => num !== 0).join('/')
      : (readOrderData?.cart?.orderDetails?.orderNumber ?? orderNo);
  const isDark = () => (window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark) || false;
  const themeSurface = () => (isDark() ? 'dark' : 'light');

  const setDocList = (docData) => {
    setViewreceiptpdcContent({ ...viewreceiptpdcContent, docData });
  };
  const setClsoPrintView = (val, barcode) => {
    if (barcode) {
      setopenPrintDetails({ ...openPrintDetails, openPrintView: val });
    } else {
      setopenPrintDetails({ ...openPrintDetails, openPrintView: val });
      onHide();
    }
  };
  const [showROViewPrintReceipt, setshowROViewPrintReceipt] = useState(true);

  const showListMtnModel = showROViewPrintReceipt || false;
  const channelID = sessionStorage.getItem('channel');

  const [state, setState] = useState({
    showPrint: false,
    showEdit: [],
    device: props?.deviceManager?.getInstance() || {},
    emailList: [],
    saveEmailList: [],
    showIndirectBuyoutDetail: false,
    showRetunLabelDetail: false,
    buyoutEmailId: '',
    returnLabelEmailId: '',
    dpEmailId: '',
    customerAgreementData: '',
  });
  const [getInstallmentInfo, setInstallmentInfo] = useState([]);
  const documentName = (element) => {
    if (readorder) {
      let isValid = false;
      readOrderViewReceipt?.documents?.map((obj) => {
        if (obj.documentName === element.id) {
          isValid = true;
        }
        return isValid;
      });
      return isValid;
    }
  };
  const navigate = useNavigate();

  const updateEmailAddress = (email, index) => {
    const emailListData = state.emailList;
    emailListData[index].emailId = email;
    setState({ ...state, emailList: emailListData });
  };

  const handleOnBlurEmailId = (emailid, index) => {
    const emailListData = state.emailList;
    emailListData[index].emailId = emailid.replace(/\s/g, '');
    setState({ ...state, emailList: emailListData });
  };

  const save = (i) => {
    const email = state.emailList[i].emailId;
    const isValid = email && email.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i);
    if (!isValid) {
      dispatch(appMessageActions.addAppMessage('Enter a valid email address', 'error', true, true));
    } else {
      const temp = state.showEdit;
      temp[i].showEdit = !temp[i].showEdit;
      const emailListData = state.saveEmailList;
      emailListData[i].emailId = state.emailList[i].emailId;
      setState({ ...state, showEdit: temp, saveEmailList: emailListData });
    }
  };

  const sendEmailReceipt = (element, email) => {
    readOrderViewReceipt?.documents?.map((document) => {
      if (element.id === document.documentName) {
        const sendEmailRequest = {
          meta: {
            function: 'eMAILFromCustRep',
            cartid: readOrderData?.cart?.cartHeader?.cartId,
            documentName: document?.documentName,
            documentId: document?.documentId,
            emailList: [email],
            isReadOrder: true,
            mtn: readorder && document?.documentName === 'returnLabel' ? document?.mtn : '',
            readOrderReqInfo: {
              orderNumber: orderNo,
              orderType: document?.orderType,
              channelId: channelID,
              installmentDetails: document?.documentName === 'devicePaymentAgreement' ? getInstallmentInfo : [],
              locationCode,
              accOnly: readOrderData?.cart?.lineDetails?.lineInfo?.[0]?.lineActivityType !== 'ACC' || false,
            },
          },
        };

        emailReceipt({ body: sendEmailRequest });
      }
      return;
    });
  };
  const installmentInfo = [];
  const viewReceiptfn = () => {
    const sourceAccessedFrom = !isIpad() ? 'Desktop' : 'Tab';
    const cartDetails1 = data?.data?.cart?.lineDetails;
    const fName =
      cartDetails1?.lineInfo?.[0]?.serviceInfo?.primaryUserInfo?.firstName || customerInfo?.customerName?.firstName;
    const lName =
      cartDetails1?.lineInfo?.[0]?.serviceInfo?.primaryUserInfo?.lastName || customerInfo?.customerName?.lastName;
    const contactName = `${fName} ${lName}` || '';
    const remarkText = `Contact Name: ${contactName} accessed receipt for ${orderNo} from ${sourceAccessedFrom}`;
    const billAccNum = customerProfile?.data?.customer?.billAccounts?.[0]?.billAccountNo || '';
    const cust_Id =
      customerProfile?.data?.customer?.customerId || readOrderData?.cart?.cartHeader?.fullAccountNumber?.split('-')[0];
    updateRemarks(remarkText, cust_Id, billAccNum, contactName);
  };

  const updateRemarks = (text, custId, billAccno, respContactName) => {
    const cartDetails1 = data?.data?.cart?.lineDetails;
    const billingSys = customerInfo?.billingSystem;
    const mdn = cartDetails1?.lineInfo?.[0]?.mtnDetails.mobileNumber
      ? cartDetails1?.lineInfo?.[0]?.mtnDetails.mobileNumber
      : cartDetails1?.lineInfo?.[0]?.mtnDetails.lineNumber;

    const req = {
      mdn: mdn || customerInfo?.lookupMtn,
      requestMapping: 'autoRemarksUpdate',
      contactName: respContactName,
      billAccountType: 'C',
      location: '',
      page: '1',
      accessLvl: '1',
      remarkText: text,
      customerId: custId ? custId.split('-')[0] : '',
      billingSystem: billingSys,
      billAccountNumber: billAccno,
      remarkType: '',
      remarkLevel: 'A',
    };

    updateVisionRemark({ body: req });
    const requestObj = orderDocumetRecipt(readOrderData, orderNo);
    readOrderDocInfo({ body: requestObj });
  };
  useEffect(() => {
    if (readOrderDocInfoRes?.status === 'fulfilled') {
      setReadOrderViewReceipt(readOrderDocInfoRes?.data?.data);
    }
  }, [readOrderDocInfoRes?.data, getUpdateVisionRemarkResponse?.data]);

  useEffect(() => {
    if (emailReceiptResult?.status === 'fulfilled') {
      dispatch(appMessageActions.addAppMessage('Email Successfully Sent', 'success', true, true));
    }
  }, [emailReceiptResult?.data]);

  useEffect(() => {
    viewReceiptfn();
    const showEditCheck = [];
    const emailCheck = [];
    const saveEmailCheck = [];

    if (documentReceiptsItems?.length > 0) {
      documentReceiptsItems.forEach((item) => {
        showEditCheck.push({
          showEdit: false,
        });
        emailCheck.push({
          emailId: item?.emailId || emailId,
        });
        saveEmailCheck.push({
          emailId: item?.emailId || emailId,
        });
      });
    }

    setState({ ...state, showEdit: showEditCheck, emailList: emailCheck, saveEmailList: saveEmailCheck });

    const lineDetail = readOrderData?.cart?.lineDetails;

    if (lineDetail?.lineInfo?.length > 0) {
      lineDetail?.lineInfo?.map((line) => {
        if (line?.installmentContractDetail) {
          const { installmentLoanNumber = '', orderNum = '' } = line.installmentContractDetail;
          const dataList = {
            installmentNum: installmentLoanNumber,
            orderNumber: orderNum,
          };
          const isDuplicate = installmentInfo?.some(
            (item) => item.installmentNum === dataList.installmentNum && item.orderNumber === dataList.orderNumber,
          );
          if (!isDuplicate) {
            installmentInfo?.push(dataList);
          }
        }
        setInstallmentInfo(installmentInfo);
        return installmentInfo;
      });
    }
  }, []);

  const onHide = () => {
    if (readorder && isRefundReadOrder) {
      setOpen(false);
      setshowViewAndPrintReceipt(false);
      setshowROViewPrintReceipt(false);
    } else {
      handleToggle('');
    }
    OpenViewTagging('closeView', 'Close', 'EUP|RFEX-read-order', readOrderData);
    setState({ ...state, showPrint: false });
  };

  useEffect(() => {
    if (getDevicesResult?.status === 'fulfilled') {
      const devices = getDevicesResult?.data?.getLocationByLocationCode?.devices;
      const deviceLsit = devices?.filter((item) => item.type === 'DIRECT_PRINTER');
      setopenPrintDetails({ ...openPrintDetails, printerDevicesList: deviceLsit, isGetDevicesLoading: true });
    }
  }, [getDevicesResult?.data]);

  useEffect(() => {
    const categoryName = viewreceiptpdcContent?.viewReceiptArr[0]?.categoryName || '';
    if (!isIpad() && categoryName === 'GR') {
      printDirectThermalPrint();
    }
    if (isRegeneratedReceiptTriggered) {
      viewReceiptfn();
    }
  }, [viewreceiptpdcContent, isRegeneratedReceiptTriggered]);

  const openPrint = (elements) => {
    if (
      isIpad() &&
      !getDevicesResult?.printerDevicesList?.length &&
      !openPrintDetails?.isGetDevicesLoading &&
      !(channelID === 'OMNI-INDIRECT')
    ) {
      const req = printerDevices(locationCode);
      getDevices({ body: req, spinner: true });
    }
    const orderDocumentDetails = readOrderViewReceipt?.documents?.find((rec) => rec.documentName === elements.id);
    if (elements.id === 'customerAgreement') {
      window.open(CUSTOMER_AGREEMENT, '_blank');
      OpenViewTagging(elements.name, 'customerAgreement', 'EUP|RFEX-read-order', readOrderData);
      return;
    }
    if (elements.id === 'isRingAgreement') {
      window.open(RING_AGREEMENT, '_blank');
      OpenViewTagging('isRingAgreement', 'isRingAgreement', 'EUP|RFEX-read-order', readOrderData);
      return;
    }
    if (elements.id === 'devicePaymentAgreement') {
      if (readorder) {
        const req = {
          data: {
            locationCode,
            installmentDetails: getInstallmentInfo,
          },
        };
        readOrderDPReceiptApi({ body: req }).then((res) => {
          setopenPrintDetails({
            ...openPrintDetails,
            openPrintView: true,
            PrintDetails: elements,
            installmentContractDetail: res,
          });
        });
        return;
      }
    }

    if (readorder) {
      if (elements.id === 'giftReceipt' || elements.id === 'tradeInReceipt') {
        if (!isIpad()) {
          setopenPrintDetails({
            ...openPrintDetails,
            openPrintView: true,
            PrintDetails: elements,
            orderDocumentDetails,
          });
          OpenViewTagging('giftReceipt', 'giftReceipt', 'EUP|RFEX-read-order', readOrderData);
          return;
        }
      } else {
        setopenPrintDetails({
          ...openPrintDetails,
          openPrintView: true,
          PrintDetails: elements,
          orderDocumentDetails,
        });
        OpenViewTagging(elements.name, elements.name, 'EUP|RFEX-read-order', readOrderData);
      }
    }
  };

  let updatedDocuments;
  const HandleRegenerate = (docData, isGetTrigger) => {
    if (readOrderViewReceipt?.documents?.length === 0 && isGetTrigger) {
      isRegeneratedReceiptTriggered = isGetTrigger;
      updatedDocuments = docData.documents;
    } else {
      navigate(`/sales/assisted/new/order-confirmation.html?readOrder=true`);
    }
    viewReceiptfn();
    const currentReadOrderViewAndPrintReceipt = {
      ...readOrderViewReceipt,
      documents: updatedDocuments,
    };
    setReadOrderViewReceipt(currentReadOrderViewAndPrintReceipt);
  };

  const edit = (i) => {
    const temp = state.showEdit;
    temp[i].showEdit = !temp[i].showEdit;
    setState({ ...state, showEdit: temp });
  };
  let ErrorContent;

  if (showListMtnModel && readorder) {
    if (readOrderViewReceipt?.documents?.find((rec) => rec.documentName === 'purchaseReceipt')) {
      isPurchaseReceiptPresent = true;
    }
    if (
      !documentReceiptsItems ||
      documentReceiptsItems?.length === 0 ||
      !readOrderViewReceipt ||
      readOrderViewReceipt?.documents?.length === 0 ||
      !isPurchaseReceiptPresent
    ) {
      ErrorContent = <GenerateReceipt HandleEventReceipts={HandleRegenerate} readOrderData={readOrderData} />;
    }
  }
  const content = (
    <Header>
      <TitleWrapper>
        <Title size='small' color='#000000' bold data-testid='viewPrintReceiptTitleTest'>
          View and Print receipt
        </Title>
        <IconWrapper
          data-testid='close-button'
          onClick={() => {
            setOpen(false);
            if (isRefundReadOrder) {
              setshowViewAndPrintReceipt(false);
            } else {
              handleToggle('');
            }
          }}
        >
          <Icon name='close' size='medium' data-testid='IconTitle' />
        </IconWrapper>
      </TitleWrapper>
      <Divider />
    </Header>
  );

  return (
    <ViewOrderDocumentContainer data-testid='review-OrderDocument'>
      <ComponentStyle />
      <ModalWrapper data-testid='items-at-OrderDocument' id='ModalWrapperId'>
        <Modal
          data-testid='viewOrderDocumentModal'
          surface={themeSurface()}
          fullScreenDialog
          width='100%'
          ariaLabel='view Order Document'
          disableFocusLock
          opened={open}
          id='viewOrderDocumentModal'
          disableOutsideClick
          onOpenedChange={(opened) => !opened && setOpen(false)}
        >
          <ModalBody id='ModalBody-content'>
            {content}
            <CustomModalBody>
              <StyledOrderNumberLabel>
                <LabelText>{orderNumberLabel}</LabelText> <LabelValue>{orderNumber}</LabelValue>
              </StyledOrderNumberLabel>

              {ErrorContent}

              {documentReceiptsItems?.map((element, i) => (
                <DocumentCotnainer>
                  {documentName(element) && (
                    <DocumentContent
                      data-testid='documentContainerTest'
                      className='Grid Grid--gapless border-bottom-grey-light u-paddingYLarge u-flexAlignItemsCenter'
                    >
                      <StyledDocumentName data-testid={`${element.id}-DocumentName`}>{element.name}</StyledDocumentName>
                      <StyledBtnAndEmail>
                        <StyledDocumentButtonList>
                          {element.btn2 && element.btn2.toLowerCase() === 'print' && (
                            <Button
                              size='small'
                              use='secondary'
                              style={{ width: '170px', padding: '4px' }}
                              onClick={() => openPrint(element)}
                              data-testid={`${element.id}-Print`}
                            >
                              {element.btn2}
                            </Button>
                          )}
                          {element.btn1 && element.btn1.toLowerCase() === 'email' && (
                            <Button
                              size='small'
                              use='secondary'
                              style={{ width: '170px', padding: '4px' }}
                              onClick={() => sendEmailReceipt(element, state.saveEmailList[i].emailId)}
                              data-testid={`${element.id}-Email`}
                            >
                              {element.btn1}
                            </Button>
                          )}
                          {element.btn3 && element.btn3.toLowerCase() === 'sms' ? (
                            <Button
                              size='small'
                              use='secondary'
                              utton
                              style={{ width: '170px', padding: '4px' }}
                              data-testid={`${element.id}-SMS`}
                            >
                              {element.btn3}
                            </Button>
                          ) : (
                            <Fragment>
                              {element.id === 'isQRCode' && (
                                <Button
                                  use='secondary'
                                  size='small'
                                  data-testid={`${element.id}-QRCode`}
                                  style={{ width: '170px', padding: '4px' }}
                                >
                                  {element.btn3}
                                </Button>
                              )}{' '}
                            </Fragment>
                          )}
                        </StyledDocumentButtonList>
                        {element && element.id !== 'tradeInReceipt' && (
                          <NotradeInReceipt className='u-textRight'>
                            {state.showEdit && state.showEdit[i] && !state.showEdit[i].showEdit && (
                              <EmailListContainer>
                                <StyledEmailList className='font-18'>
                                  {state.emailList[i] && state.emailList[i].emailId}
                                </StyledEmailList>
                                <TextLink
                                  data-testid={`${element.id}-Edit`}
                                  className='smaller'
                                  onMouseDown={() => edit(i)}
                                >
                                  {' '}
                                  Edit{' '}
                                </TextLink>
                              </EmailListContainer>
                            )}
                            {state.showEdit && state.showEdit[i] && state.showEdit[i].showEdit && (
                              <EmailInputContainer className='u-paddingTopSmall contains-PII'>
                                <Input
                                  type='text'
                                  name='email'
                                  iconName='index'
                                  data-testid={`${element.id}-EmailTxt`}
                                  value={
                                    state.emailList[i] && state.emailList[i].emailId ? state.emailList[i].emailId : ''
                                  }
                                  onChange={(e) => updateEmailAddress(e.target.value, i)}
                                  onBlur={(e) => handleOnBlurEmailId(e.target.value, i)}
                                />
                                <PaddingTopSmall className='u-paddingTopSmall'>
                                  <TextLink data-testid={`${element.id}-Save`} onMouseDown={() => save(i)}>
                                    Save
                                  </TextLink>
                                </PaddingTopSmall>
                              </EmailInputContainer>
                            )}
                          </NotradeInReceipt>
                        )}
                      </StyledBtnAndEmail>
                    </DocumentContent>
                  )}
                </DocumentCotnainer>
              ))}
            </CustomModalBody>
          </ModalBody>
          <FooterContent>
            <Button
              id='modalFooterConeButton'
              data-testid='footerContent'
              size='small'
              use='primay'
              style={{ width: '130px', padding: '4px', display: 'block', margin: '0 auto' }}
              onClick={() => onHide()}
            >
              Done
            </Button>
          </FooterContent>
        </Modal>
      </ModalWrapper>
      {openPrintDetails?.openPrintView && (
        <ViewReceiptModal
          PrintDetails={openPrintDetails}
          name={openPrintDetails?.PrintDetails?.id}
          titletxt={openPrintDetails?.PrintDetails?.name}
          getConfirmationPageValue={openPrintDetails?.installmentContractDetail}
          cartDetails={cartDetails}
          openPrintView={openPrintDetails?.openPrintView}
          setClosePrintVeiw={setClsoPrintView}
          setViewReceiptContentPDF={setDocList}
          readOrderData={readOrderData}
          orderNo={orderNo}
          locationCode={locationCode}
        />
      )}
    </ViewOrderDocumentContainer>
  );
}

ViewOrderDocument.propTypes = {
  value: PropTypes.bool,
  handleToggle: PropTypes.func,
  readorder: PropTypes.bool,
  emailId: PropTypes.string,
  deviceManager: PropTypes.object,
  orderNo: PropTypes.array,
  readOrderData: PropTypes.object,
  cartDetails: PropTypes.object,
  locationCode: PropTypes.string,
  customerInfo: PropTypes.object,
  customerProfile: PropTypes.object,
  data: PropTypes.object,
  isRefundReadOrder: PropTypes.bool,
  setshowViewAndPrintReceipt: PropTypes.func,
};

export default withPeripherals(ViewOrderDocument);
