import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import styled, { createGlobalStyle } from 'styled-components';
import { Line } from '@vds/lines';
import { Body } from '@vds/typography';
import { TextLink } from '@vds/buttons';
import { TileContainer } from '@vds/tiles';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { Icon } from '@vds/icons';
import { FlexBox, PaddingLeft12, StyledPaddingLeft8, StyledPaddingTop8Bot8 } from '../../StyledConstants';
import { formatCurrency, getPlanDetail } from '../../utils/common';
import SharedDetailsModal from './SharedDetailsModal';
import AccountDetailsModal from './AccountDetailsModal';
import AccountSectionAPICallHook from '../../modules/services/APIService/AccountSectionAPICallHook';
import { invokeTagging } from '../../utils/test-utils/utils';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR } from '../constants/constants';

const ComponentStyle = createGlobalStyle`
[class^='OuterTileContainer-VDS'] {
  border-radius: 0px !important;
}
`;

const LeftSideWrapper = styled.div`
  display: flex;
  flex-direction: column;
  min-width: 236px;
  padding: 0 10px;
  justify-content: center;
`;

const InfoWrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  justify-content: flex-start;
`;

const TileContainerWrapper = styled.div`
  [class^='OuterTileContainer'] {
    border-radius: 0px !important;
    height: 100%;
  }
`;

const TileWrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
`;
const PriceWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 0.25rem;
  padding: 8px 14px;
  border-bottom: ${(props) => (props.hasBorderBottom ? '1px solid rgb(216, 218, 218)' : 'none')};
`;

const Title = styled.div`
  font-size: 18px;
  font-weight: 700;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  letter-spacing: 0.03125rem;
  width: ${(props) => (props.isFeaturePriceZero ? '70%' : '100%')};
`;

const LinkWrapper = styled.div`
  text-align: left;
  padding-left: 1rem;
  padding-bottom: 1rem;
  width: calc(384px - 1rem);
  background-color: #f6f6f6;
`;

const SubTitle = styled(Title)`
  color: grey;
  margin-top: 10px;
  font-size: 17px;
`;

const AccountValueWrapper = styled.div`
  padding-left: 0.5rem;
  display: flex;
  align-items: center;
`;

const InfoContainer = styled.div`
  display: flex;
  align-items: center;
  padding: 0px 10px 25px;
`;

const InfoText = styled.div`
  color: #959595;
  font-size: 15px;
  margin-left: 5px;
  font-family: BrandFont-Text, Arial, sans-serif;
`;

const InfoIcon = styled.div`
  cursor: default;
  &:hover {
    cursor: pointer;
  }
`;

const AccountDetails = ({ data, mtn, discountedFeatures, fetchPriceSnapshot, activeSubAccountId, readOrder }) => {
  const [showModal, setShowModal] = useState(false);
  const [showSharedModal, setShowSharedModal] = useState(false);
  const { getReferences, getReferencesResult } = AccountSectionAPICallHook();
  const lineInfo = data?.data?.cart?.lineDetails?.lineInfo || [];
  const { planInfo, planDetails, isAccount, isCPC, newPlanId, oldPlanId } = getPlanDetail(lineInfo?.[0]) || {};
  const originalPlanPrice = planInfo?.accessFee ? planInfo.accessFee : '0.00';
  const discountedPrice = planDetails?.discountedPrice ? planDetails.discountedPrice : '';
  const planPrice =
    discountedPrice !== '' && discountedPrice !== originalPlanPrice ? discountedPrice : originalPlanPrice;
  const servicePlanId = lineInfo[0]?.serviceInfo?.selectedALPShareList?.newAlpShareInfo[0]?.servicePlanId || '';
  const oldServicePlanId = lineInfo[0]?.serviceInfo?.selectedALPShareList?.alpShareInfo[0]?.servicePlanId || '';
  const planInfoReference = getReferencesResult?.data?.data?.planReferences || [];
  const paperLess = data?.data?.cart?.lineDetails?.isPaperLessBilling || null;
  const isPrepayCart = data?.data?.cart?.orderDetails?.isPrePayCart === 'Y';
  const subAccDisplayName = data?.data?.cart?.orderDetails?.subAccountInfo?.[0]?.subAccountDisplayName;
  const isCLNRFlow = sessionStorage.getItem('isCLNRFlow') || false;
  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;
  const bgColor = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.themeProps?.background;
  const references = planInfoReference?.find((reference) =>
    isCPC ? reference.planId === newPlanId : reference.planId === oldPlanId,
  );
  const genAddOns = discountedFeatures?.filter((features) => features.isGeneralAddon);
  const discountedAddOns = discountedFeatures?.filter((features) => !features.isGeneralAddon);
  const shared = fetchPriceSnapshot?.subAccounts?.[0]?.shared;
  const totalDiscountsAndPromotions = shared?.promosTotal?.discountedPrice || '';
  const [isReadOrderMfe] = getAssistedCradlePropertyV2(['readOrderMfeFFlag']);
  const isReadOrderMfeFFlag = /true/i.test(isReadOrderMfe);

  const getFetchPricedSnapshot = () => {
    if (fetchPriceSnapshot?.subAccounts?.length > 0) {
      if (fetchPriceSnapshot?.subAccounts?.length > 1) {
        return fetchPriceSnapshot?.subAccounts?.find(
          (subAcc) =>
            subAcc?.subAccountId &&
            activeSubAccountId &&
            (activeSubAccountId === subAcc.subAccountId || activeSubAccountId.includes('SubAccount ')),
        );
      }
      return fetchPriceSnapshot?.subAccounts?.find((subAcc) => subAcc?.subAccountType?.toLowerCase() === 'existing');
    }
    return {};
  };

  const pricedSnapshot = getFetchPricedSnapshot();

  const getSharedPlan = () => {
    const serviceInfo = lineInfo[0]?.serviceInfo;

    return serviceInfo?.selectedALPShareList &&
      ((serviceInfo?.selectedALPShareList.alpShareInfo &&
        serviceInfo?.oldPlanFlag === 'A' &&
        serviceInfo?.newPlanFlag === 'A' &&
        serviceInfo.selectedALPShareList.alpShareInfo.length > 0 &&
        serviceInfo.selectedALPShareList.alpShareInfo.find((sharedPlan) => sharedPlan.addDeleteInd !== 'D')) ||
        (serviceInfo?.newPlanFlag === 'A' &&
          serviceInfo?.selectedALPShareList?.newAlpShareInfo?.find((sharedPlan) => sharedPlan.addDeleteInd === 'A')))
      ? serviceInfo.selectedALPShareList
      : {};
  };
  const planIDS = [servicePlanId, oldServicePlanId]?.filter((planId) => planId);

  const sharedPlan = getSharedPlan();

  useEffect(() => {
    if (getReferencesResult.status === 'uninitialized' && isAccount && planInfo) {
      const params = {
        isPrepayFlow: isPrepayCart,
        planIds: planIDS,
      };
      getReferences({
        body: params,
        spinner: false,
        mock: false,
      });
    }
  }, [getReferencesResult, isAccount, planInfo]);
  const toggleModal = (isOpen) => {
    setShowModal(isOpen);
  };

  const toggleSharedModal = (isOpen) => {
    setShowSharedModal(isOpen);
  };

  const renderPrice = () => {
    if (planInfo?.accessFee === planPrice) {
      return planPrice;
    }
    return originalPlanPrice;
  };

  const formatedPlan = () => {
    let formattedPlanName = '';
    if (sharedPlan?.newAlpShareInfo?.length > 0) {
      formattedPlanName = sharedPlan.newAlpShareInfo[0].formattedPlanName;
    } else if (sharedPlan?.alpShareInfo?.length > 0) {
      formattedPlanName = sharedPlan.alpShareInfo[0].formattedPlanName || '';
    }
    return formattedPlanName || '';
  };

  const viewSharedFeatures = () => {
    setShowSharedModal(true);
    invokeTagging('openView', 'Features');
  };

  const getSharedAddOns = (item, linkAtTheBottom = true) =>
    item.length === 0 ? (
      ''
    ) : (
      <div>
        {item.map(({ featureDesc, featurePrice, addDeleteInd }) => {
          if (addDeleteInd !== 'D') {
            return (
              <TileContainer
                key={featureDesc}
                padding='1.5rem 0 0 0'
                height='auto'
                width='384px'
                surface={isDark ? 'dark' : 'light'}
              >
                <TileWrapper>
                  {readOrder && isReadOrderMfeFFlag ? (
                    <PriceWrapper>
                      <Title isFeaturePriceZero={parseFloat(featurePrice) === 0}>{featureDesc || null}</Title>

                      {parseFloat(featurePrice) !== 0 && (
                        <AccountValueWrapper>
                          <Title style={{ whiteSpace: 'nowrap' }}>{formatCurrency(parseFloat(featurePrice))}</Title>
                        </AccountValueWrapper>
                      )}
                    </PriceWrapper>
                  ) : (
                    <PriceWrapper>
                      <Title>{featureDesc || null}</Title>

                      <AccountValueWrapper>
                        <Title style={{ whiteSpace: 'nowrap' }}>{formatCurrency(parseFloat(featurePrice))}</Title>
                      </AccountValueWrapper>
                    </PriceWrapper>
                  )}
                </TileWrapper>
              </TileContainer>
            );
          }
          return null;
        })}

        {shared?.flags?.serviceInEffectLaterMsg && (
          <TileContainer padding='1.5rem 0 0 0' height='auto' width='384px' surface={isDark ? 'dark' : 'light'}>
            <InfoContainer>
              <InfoIcon>
                <Icon name='info' size='small' color='grey' />
              </InfoIcon>
              <InfoText>{shared.flags.serviceInEffectLaterMsg}</InfoText>
            </InfoContainer>
          </TileContainer>
        )}

        {linkAtTheBottom && !isCLNRFlow && (
          <LinkWrapper
            style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR, backgroundColor: isDark ? bgColor : '' }}
          >
            <TextLink
              type='standAlone'
              data-testId='viewShared'
              surface={isDark ? 'dark' : 'light'}
              disabled={false}
              size='small'
              onClick={viewSharedFeatures}
              data-track='View shared add-ons'
            >
              {' '}
              {isPrepayCart ? 'View shared Add-ons' : 'View shared Services & perks'}
            </TextLink>
          </LinkWrapper>
        )}
      </div>
    );

  return (
    <>
      {subAccDisplayName && (
        <>
          <StyledPaddingTop8Bot8>
            <Title>{subAccDisplayName}</Title>
          </StyledPaddingTop8Bot8>
          <Line type='primary' surface={isDark ? 'dark' : 'light'} />
        </>
      )}
      <ComponentStyle />
      {!isPrepayCart && (
        <>
          <FlexBox>
            <LeftSideWrapper>
              <Title>Account</Title>
              {isAccount && references && <SubTitle>{references.displayName}</SubTitle>}
            </LeftSideWrapper>
            <InfoWrapper>
              {isAccount && (
                <>
                  {planInfo && (
                    <TileContainerWrapper data-testid='account-details'>
                      <TileContainer
                        padding='1.5rem 0 0 0'
                        height='auto'
                        width='384px'
                        surface={isDark ? 'dark' : 'light'}
                      >
                        <TileWrapper>
                          <PriceWrapper>
                            <Body size='large' bold color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                              {planInfo.servicePlanDesc || null}
                            </Body>
                            <StyledPaddingLeft8>
                              <Body size='medium' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                                {formatCurrency(renderPrice())}
                              </Body>
                            </StyledPaddingLeft8>
                          </PriceWrapper>
                          <PaddingLeft12>
                            <div
                              id='account_formattedPlanName'
                              dangerouslySetInnerHTML={{
                                __html: formatedPlan() || '',
                              }}
                            />
                          </PaddingLeft12>
                        </TileWrapper>
                      </TileContainer>
                    </TileContainerWrapper>
                  )}

                  {paperLess === 'Y' ? (
                    <div className='font-15 bold u-paddingTopMedium'>You are enrolled in paperless</div>
                  ) : (
                    ''
                  )}
                  {planInfo && !isCLNRFlow && (
                    <LinkWrapper
                      style={{
                        color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                        backgroundColor: isDark ? bgColor : '',
                      }}
                    >
                      <TextLink
                        type='standAlone'
                        data-testId='view-account'
                        surface={isDark ? 'dark' : 'light'}
                        disabled={false}
                        size='small'
                        onClick={() => {
                          invokeTagging('openView', 'Plans Detail');
                          toggleModal(true);
                        }}
                      >
                        {' '}
                        View
                      </TextLink>
                    </LinkWrapper>
                  )}
                </>
              )}
              <div>
                {genAddOns?.length > 0 && getSharedAddOns(genAddOns, true)}

                {discountedAddOns?.length > 0 && (
                  <React.Fragment>
                    <TileContainer
                      padding='1.5rem 0 0 0'
                      height='auto'
                      width='384px'
                      surface={isDark ? 'dark' : 'light'}
                    >
                      <TileWrapper>
                        <PriceWrapper hasBorderBottom>
                          <Title>Discounts and promotions</Title>
                          <StyledPaddingLeft8>
                            <Body size='medium' bold color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                              {formatCurrency(totalDiscountsAndPromotions)}
                            </Body>
                          </StyledPaddingLeft8>
                        </PriceWrapper>
                      </TileWrapper>
                    </TileContainer>
                    {getSharedAddOns(discountedAddOns, false)}
                  </React.Fragment>
                )}
              </div>
            </InfoWrapper>
          </FlexBox>
          <Line type='primary' surface={isDark ? 'dark' : 'light'} />
        </>
      )}
      {showModal ? (
        <AccountDetailsModal
          opened
          planId={servicePlanId}
          lineInfo={lineInfo}
          isPrepay={isPrepayCart}
          mtn={mtn}
          cart={data?.data?.cart}
          planReferences={planInfoReference}
          toggleModal={(isOpen) => toggleModal(isOpen)}
        />
      ) : null}

      {showSharedModal ? (
        <SharedDetailsModal
          opened
          planId={servicePlanId}
          orderDetails={data?.data?.cart?.orderDetails}
          pricedSnapshot={pricedSnapshot}
          toggleModal={(isOpen) => toggleSharedModal(isOpen)}
        />
      ) : null}
    </>
  );
};

AccountDetails.propTypes = {
  data: PropTypes.object,
  mtn: PropTypes.string,
  discountedFeatures: PropTypes.object,
  fetchPriceSnapshot: PropTypes.object,
  activeSubAccountId: PropTypes.string,
  readOrder: PropTypes.bool,
};

export default AccountDetails;
