import React, { useEffect, useState } from 'react';
import { isEmpty } from 'lodash';
import { TextLink } from '@vds/buttons';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import { Modal, ModalTitle } from '@vds/modals';
import { Line } from '@vds/lines';
import { Grid, Row, Col } from '@vds/grids';
import { TileContainer } from '@vds/tiles';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR } from '../constants/constants';
// import StoreLocatorModal from './StoreLocatorModal';
import { useLazyGetStoreTradeInformationQuery } from '../../modules/services/APIService/APIServiceHooks';
import { isEnabledTradeReturnOptionsInContactCenterApps, isSDDInCart } from '../../utils/common';

const LinkWrapper = styled.div`
  text-align: left;
  padding-bottom: ${(props) => (props.paddingBottom ? props.paddingBottom : '1rem')};
  padding-top: ${(props) => (props.paddingTop ? props.paddingTop : '1rem')};
  padding-left: ${(props) => (props.paddingLeft ? '1rem' : '0')};
`;

const Title = styled.div`
  font-weight: 700;
  line-height: 1.25rem;
  letter-spacing: 0.03125rem;
  margin: 0px;
  text-decoration: none;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  font-size: 20px;
  color: rgb(0, 0, 0);
`;

const TitleSM = styled.div`
  font-weight: bold;
  font-size: 16px;
  margin-top: 5px;
`;

const StyledModal = styled(Modal)`
  padding: 20px 40px;
  height: 60vh;
`;

const Divider = styled.div`
  border-top: 1px solid #000;
  margin: 10px 0rem;
`;

const LeftCol = styled(Col)`
  padding: 0px !important;
`;

const TileWrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
`;

const TileContainerWrapper = styled.div`
  [class^='OuterTileContainer'] {
    border-radius: 0px !important;
    height: 100%;
    padding: 8px 8px 8px 8px;
  }
`;
const StoreTradein = (cartDetails) => {
  const [cartDetailsData] = useState(cartDetails?.cartDetails);
  const [storeInformation, setStoreInformation] = useState({});
  const [storeTimingsArr, setStoreTimingsArr] = useState([]);
  const [showStoreInfoModal, setShowStoreInfoModal] = useState(false);
  const [showStoreLocatorModal, setShowStoreLocatorModal] = useState(false);
  const [showTradeAnywhereForBEWithoutEcpdCustomers, setShowTradeAnywhereForBEWithoutEcpdCustomers] = useState(true);
  const channel = sessionStorage.getItem('channel');
  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;
  const bgColor = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.themeProps?.background;
  const [storeInfoReq, storeInfoResponse] = useLazyGetStoreTradeInformationQuery();

  const appProperties = JSON.parse(sessionStorage.getItem('APP_PROPERTIES')) || {};
  const customerType = (sessionStorage.getItem('customerType') || '').toLowerCase();
  const enableReturnAnywhereAssisted = appProperties?.enableReturnAnywhereAssisted.toLowerCase() === 'true';
  const blockRTSForBEWithoutEcpdCustomers = appProperties?.blockRTSForBEWithoutEcpdCustomers.toLowerCase() === 'true';
  const isCostcoAgent = false;

  const enableReturnOptionsInContactCenterApps =
    isEnabledTradeReturnOptionsInContactCenterApps(showTradeAnywhereForBEWithoutEcpdCustomers, isCostcoAgent) &&
    !isSDDInCart(cartDetailsData);

  const tradeInType = cartDetailsData?.lineDetails?.tradeInDetail?.tradeInType;
  const tradeInShippingType = cartDetailsData?.lineDetails?.tradeInDetail?.tradeInShippingType;

  const isAddressAvailable = `${(storeInformation?.storeAddressLine1 ?? '') || (storeInformation?.address1 ?? '')}`;
  const cityAvailable = `${storeInformation?.city ?? ''}`;
  const stateAvailable = `${storeInformation?.state ?? ''}`;
  const storeAddress = `${storeInformation?.storeAddressLine1 || storeInformation?.address1}, ${
    storeInformation?.city
  }, ${storeInformation?.state}`;

  useEffect(() => {
    if (blockRTSForBEWithoutEcpdCustomers && cartDetailsData?.orderDetails?.billingSystem?.toLowerCase() === 'vb') {
      setShowTradeAnywhereForBEWithoutEcpdCustomers(false);
    }
  }, [blockRTSForBEWithoutEcpdCustomers, cartDetailsData]);

  useEffect(() => {
    const tradeInItems = cartDetailsData?.lineDetails?.tradeInDetail?.tradeInItems || [];
    if (tradeInItems.length > 0) {
      const preferredStoreId = tradeInItems[0]?.preferredStoreId;
      if (preferredStoreId) {
        storeInfoReq({
          body: {
            storeId: preferredStoreId,
          },
          mock: false,
        });
      }
    }
  }, [cartDetailsData?.lineDetails?.tradeInDetail]);

  useEffect(() => {
    if (storeInfoResponse?.isSuccess && !storeInfoResponse?.isFetching) {
      setStoreInformation(storeInfoResponse.data.data.storeInformation);
      const transformedStoreTimings = transformStoreHoursToArray(storeInfoResponse.data.data.storeInformation);
      setStoreTimingsArr(transformedStoreTimings);
    }
  }, [storeInfoResponse]);

  const formatHours = (hours) => {
    const timingsArray = hours.split(' ');
    const hoursText =
      timingsArray.length === 4 && `${timingsArray[0]} ${timingsArray[1]} - ${timingsArray[2]} ${timingsArray[3]}`;
    return hoursText;
  };

  const transformStoreHoursToArray = (data) => {
    const daysOfWeek = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    return daysOfWeek.map((day) => ({
      day,
      hours: formatHours(data[`hours${day}`]),
    }));
  };
  const toggleStoreInfoModal = () => {
    setShowStoreInfoModal(!showStoreInfoModal);
  };

  const toggleStoreLocatorModal = () => {
    setShowStoreLocatorModal(!showStoreLocatorModal);
  };

  // const updateStoreLocation = (store) => {
  //   const payload = {
  //     tradeInType: 'Home',
  //     tradeInShippingType: 'return_store',
  //     preferredStoreId: store?.netaceLocationCode,
  //     preferredStoreAddress: `${store?.storeName}, ${store?.storeAddressLine1 || store?.address1}, ${store?.city}, ${
  //       store?.state
  //     }`,
  //   };
  //   console.log('payload', payload);
  //   // call the api here
  // };

  const isEnabledReturnChoicesForNewCustomerInRetail = () => {
    const enableReturnOptionsForNewCustomerInRetail =
      appProperties?.enableReturnOptionsForNewCustomerInRetail.toLowerCase() === 'true';
    return enableReturnOptionsForNewCustomerInRetail && customerType === 'n';
  };

  return (
    enableReturnAnywhereAssisted &&
    showTradeAnywhereForBEWithoutEcpdCustomers &&
    (customerType !== 'n' ||
      isEnabledReturnChoicesForNewCustomerInRetail() ||
      enableReturnOptionsInContactCenterApps) &&
    (channel?.includes('OMNI-RETAIL') || enableReturnOptionsInContactCenterApps) &&
    tradeInType?.toLowerCase() === 'home' &&
    tradeInShippingType?.toLowerCase() === 'return_store' && (
      <TileContainerWrapper>
        <TileContainer
          padding='1.5rem 0 0 0'
          height='auto'
          width='384px'
          backgroundColor={bgColor}
          surface={isDark ? 'dark' : 'light'}
        >
          <TileWrapper
            style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR, backgroundColor: isDark ? bgColor : '' }}
          >
            <LinkWrapper
              paddingTop='0px'
              paddingBottom='0px'
              style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR, backgroundColor: isDark ? bgColor : '' }}
            >
              <Title
                size='medium'
                style={{
                  color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                  backgroundColor: isDark ? bgColor : '',
                }}
              >
                Store drop-off point for Trade-in
                <TitleSM>{storeInformation.storeName}</TitleSM>
              </Title>
              <div style={{ marginTop: '8px' }}>
                {!isEmpty(isAddressAvailable) && !isEmpty(cityAvailable) && !isEmpty(stateAvailable) ? (
                  <div>{storeAddress}</div>
                ) : (
                  ''
                )}
              </div>
              <Line type='secondary' style={{ margin: '20px 0px 0px 0px' }} />
              {!isEmpty(isAddressAvailable) && !isEmpty(cityAvailable) && !isEmpty(stateAvailable) && (
                <div style={{ marginTop: '8px' }}>
                  <TextLink
                    type='standAlone'
                    surface={isDark ? 'dark' : 'light'}
                    disabled={false}
                    size='small'
                    data-testId='storeTradein'
                    onClick={toggleStoreInfoModal}
                  >
                    View store details
                  </TextLink>
                </div>
              )}

              {cartDetailsData?.cartHeader?.status?.toLowerCase() !== 's' && (
                <TextLink
                  type='standAlone'
                  surface={isDark ? 'dark' : 'light'}
                  disabled={false}
                  size='small'
                  data-testId='storeTradein'
                  onClick={toggleStoreLocatorModal}
                >
                  Edit location
                </TextLink>
              )}
            </LinkWrapper>

            {showStoreInfoModal && (
              <StyledModal
                ariaLabel='store information modal'
                id='storeInformationModal'
                className='storeInformationModal'
                surface='light'
                disableAnimation={false}
                disableOutsideClick={false}
                opened={showStoreInfoModal}
                onOpenedChange={(opened) => !opened && setShowStoreInfoModal(false)}
              >
                <div className='storeInformationModal'>
                  <ModalTitle className='u-paddingTopMedium'>
                    <div className='u-paddingYSmall storePickupPointText'>Store Pickup Point</div>
                    <Divider />
                  </ModalTitle>
                  <div className='u-lineHeightNormal'>
                    <div
                      style={{
                        fontWeight: 'bold',
                        fontSize: '16px',
                        paddingTop: '8px',
                        paddingBottom: '8px',
                      }}
                    >
                      {storeInformation?.storeName}
                    </div>
                    <div className='u-text16'>
                      {`${storeInformation?.address1}, ${storeInformation?.city}, ${storeInformation?.state}`}
                    </div>
                    <div className='u-text16'>{storeInformation?.phoneNumber}</div>
                    <div
                      style={{
                        fontWeight: 'bold',
                        fontSize: '16px',
                        paddingTop: '8px',
                        paddingBottom: '8px',
                      }}
                    >
                      Store Hours
                    </div>
                    {storeTimingsArr.map((timing) => (
                      <Grid bleed='1272' rowGutter='10px'>
                        <Row>
                          <LeftCol
                            colSizes={{
                              desktop: 6,
                            }}
                          >
                            {timing.day}
                          </LeftCol>
                          <Col
                            colSizes={{
                              desktop: 6,
                            }}
                          >
                            {timing.hours}
                          </Col>
                        </Row>
                      </Grid>
                    ))}
                  </div>
                </div>
              </StyledModal>
            )}
            <div style={{ height: '100%', position: 'relative', overflowY: 'hidden' }}>
              {/* {showStoreLocatorModal && (
            <StoreLocatorModal
              toggleStoreLocatorModal={toggleStoreLocatorModal}
              updateStoreLocation={updateStoreLocation}
            />
          )} */}
            </div>
          </TileWrapper>
        </TileContainer>
      </TileContainerWrapper>
    )
  );
};

StoreTradein.prototype = {
  cartDetails: PropTypes.object,
};

export default StoreTradein;
