import { Accordion, AccordionDetail, AccordionHeader, AccordionItem, AccordionTitle } from '@vds/accordions';
import { RadioButtonGroup } from '@vds/radio-buttons';
import React, { useEffect, useState } from 'react';
import styled, { createGlobalStyle } from 'styled-components';
import PropTypes from 'prop-types';
import { DropdownSelect } from '@vds/selects';
import { Input } from '@vds/inputs';
import { Checkbox } from '@vds/checkboxes';
import { Button } from '@vds/buttons';
import { Icon } from '@vds/icons';
import { affirmModalConstants } from '../../appconfig';
import ViewTogetherApiCallHook from '../../modules/services/APIService/ViewTogetherApiCallHook';
import {
  getInspisioPayload,
  getSendEmailAffirmPayload,
  getSendMessageAffirmPayload,
} from './AccessoryAndAffirmRequest';

const RadioButtonStyle = styled.div`
  & > div {
    display: flex;
    flex-direction: row !important;
    align-items: flex-end;
  }
  ,
  & label {
    margin-right: 8rem !important;
  }
`;

const DropDowmWrapper = styled.div`
  margin: 20px 10px;
  [class^='StyledTypography-VDS'] {
    font-size: 16px;
    font-family: BrandFontRegular, Arial, sans-serif;
  }
  [class^='FlexedRowContainer-VDS'] {
    width: 430px;
  }
  [class^='SelectEl-VDS'] {
    font-size: 14px;
    font-family: BrandFontRegular, sans-serif;
  }
  [class^='FlexedRowContainer-VDS'] {
    width: 430px;
  }
`;

const ComponentStyle = createGlobalStyle`
    #affirmModel {
      [class^='TriggerIconWrapper-VDS'] {
        margin-top: 0rem;
      }
      [class^='WrapperDiv-VDS']{
        [class^='StyledTypography-VDS'] {
          font-weight: 700;
          font-size: 24px;
          padding-bottom: 12px;
          font-family: Verizon-NHG-eDS;
          letter-spacing: 0.03125rem;
      }
      }
      [class^='CheckboxWrapper-VDS']{
        [class^='StyledTypography-VDS'] {
            font-weight: unset;
            font-family: BrandFontRegular, Arial, sans-serif;
        }
      }
      [class^='StyledButton-VDS'] {
          margin-top: 20px;
          padding: 0 30px;
      }
    }
`;

const IconWrapper = styled.div`
  display: flex;
  gap: 5px;
  margin: 20px 0;
  > svg {
    width: 24px;
    height: 24px;
  }
  > div {
    font-size: 20px;
    color: deepskyblue;
    font-family: BrandFontRegular, Arial, sans-serif;
  }
`;

const AffirmAccodion = ({
  showAffirmModal,
  customerMtns,
  emailValue,
  cartDetails,
  setShowAffirmPaymentConfirmation,
  setShowAffirmAccordion,
}) => {
  const {
    requestBodyGenerateInspicioId,
    getResultGenerateInspicioId,
    requestBodySendMessage,
    getResultSendMessage,
    requestBodySendEmail,
    getResultSendEmail,
    receiveMessage,
    receiveMessageResult,
    updateAffirm,
  } = ViewTogetherApiCallHook();
  const [open, setOpen] = useState(showAffirmModal);
  const [selectedMDN, setSelectedMDN] = useState(customerMtns?.[0]);
  const [showMDNSection, setShowMDNSection] = useState(false);
  const [showEmailSection, setShowEmailSection] = useState(false);
  const [checked, setChecked] = useState(false);
  const [isDisabled, setIsDisabled] = useState(true);
  const [sendInspicioData, setSendInspicioData] = useState(null);
  const [linkSent, setLinkSent] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const maxRetries = 10;

  const handleChange = (e) => {
    const mode = e.target.value;
    if (mode === 'SMS') {
      setShowMDNSection(true);
      setShowEmailSection(false);
    } else {
      setShowMDNSection(false);
      setShowEmailSection(true);
    }
  };
  const generateInspicioCall = () => {
    if (!sendInspicioData) {
      setRetryCount(0);
      const inspicioPayload = getInspisioPayload();
      requestBodyGenerateInspicioId({
        body: { ...inspicioPayload },
        spinner: false,
      });
    } else {
      setRetryCount(0);
      setLinkSent(false);
      sendMessageCall(sendInspicioData?.sendInspicioToken);
    }
  };

  const sendMessageCall = (token) => {
    const sendMessagePayload = getSendMessageAffirmPayload(cartDetails?.data?.cart, token);
    requestBodySendMessage({
      body: { ...sendMessagePayload },
      spinner: false,
    });
  };

  const sendLinkInspicio = (sendRes, token) => {
    const clusterId = sendRes?.cluster;
    let xbox = false;
    if (
      !xbox &&
      cartDetails?.data?.cart?.lineDetails?.lineInfo[0]?.itemsInfo[0]?.cartItems?.cartItem[0]?.deviceDisplayName
        .toLowerCase()
        .includes('xbox')
    ) {
      xbox = true;
    }
    const currentDate = new Date();
    const dd = currentDate.getDate() < 10 ? `0${currentDate.getDate()}` : currentDate.getDate();
    const mm = currentDate.getMonth() + 1 < 10 ? `0${currentDate.getMonth()}${1}` : currentDate.getMonth() + 1;
    const yyyy = currentDate.getFullYear();
    const currDate = `${mm}/${dd}/${yyyy}`;
    const sendEmailObj = {
      cartDetails,
      token,
      selectedMDN,
      clusterId,
      xbox,
      showEmailSection,
      emailValue,
      currDate,
    };
    const sendEmailAffirmPayload = getSendEmailAffirmPayload(sendEmailObj);
    requestBodySendEmail({ body: { ...sendEmailAffirmPayload }, spinner: false, mock: false });
  };

  const updateAffirmPayment = async (data) => {
    const res = await updateAffirm({
      body: {
        intendType: 'ACC',
        paymentData: [
          {
            paymRegisterNum: cartDetails?.data?.cart?.orderDetails?.registerNumber,
            paymentAmount: cartDetails?.data?.cart?.orderDetails?.affirmFinancingOfferInfo?.totalAffirmAccessoryAmount,
            paymentType: 'AF',
            savedCC: false,
            affirmPayment: {
              successToken: data?.payload?.affirmPayload?.checkout_token,
            },
          },
        ],
      },
      spinner: false,
    });
    if (res?.data && res?.status === 'fulfilled') {
      setShowAffirmPaymentConfirmation(true);
    }
  };

  const receiveCall = () => {
    receiveMessage({
      body: {
        clientId: sendInspicioData?.receievInspicioToken,
        cluster: window.sessionStorage.getItem('vtCluster') || '',
      },
      spinner: false,
    });
  };

  useEffect(() => {
    if (getResultGenerateInspicioId?.data && !sendInspicioData) {
      setSendInspicioData(getResultGenerateInspicioId?.data);
      sendMessageCall(getResultGenerateInspicioId?.data?.sendInspicioToken);
    }
  }, [getResultGenerateInspicioId]);

  useEffect(() => {
    if (getResultSendMessage?.data) {
      sendLinkInspicio(getResultSendMessage?.data, sendInspicioData?.sendInspicioToken);
    }
  }, [getResultSendMessage]);

  useEffect(() => {
    if (getResultGenerateInspicioId?.data && getResultSendMessage?.data && getResultSendEmail?.data && !linkSent) {
      setLinkSent(true);
      receiveCall();
    }
  }, [getResultGenerateInspicioId, getResultSendMessage, getResultSendEmail]);

  useEffect(() => {
    const linkSentSuccessfully =
      getResultGenerateInspicioId?.status === 'fulfilled' &&
      getResultSendMessage?.status === 'fulfilled' &&
      getResultSendEmail?.status === 'fulfilled';

    const receiveMessageResponse =
      receiveMessageResult?.status === 'fulfilled' && receiveMessageResult?.data?.status === 'Success';

    const timeoutId = setTimeout(() => {
      if (linkSentSuccessfully) {
        if (receiveMessageResponse) {
          updateAffirmPayment(receiveMessageResult?.data);
        } else if (retryCount < maxRetries) {
          receiveCall();
          setRetryCount(retryCount + 1);
        }
      }
    }, 1000);
    return () => clearTimeout(timeoutId);
  }, [receiveMessageResult]);

  useEffect(() => {
    if (checked && (selectedMDN || emailValue)) {
      setIsDisabled(false);
    } else {
      setIsDisabled(true);
    }
  }, [selectedMDN, checked, emailValue]);
  const handleAccordionClose = () => {
    setOpen(!open);
    setShowAffirmAccordion(false);
  };
  return (
    <>
      <ComponentStyle />
      <Accordion data-testId='affirmModel' id='affirmModel' topLine>
        <AccordionItem opened={open}>
          <AccordionHeader trigger={{ type: 'icon', alignment: 'top' }} onClick={handleAccordionClose}>
            <AccordionTitle>{affirmModalConstants.title}</AccordionTitle>
          </AccordionHeader>
          <AccordionDetail>
            <RadioButtonStyle>
              <RadioButtonGroup
                id='radio-btn'
                data-testId='radio-btn'
                onChange={handleChange}
                defaultValue='null'
                data={[
                  {
                    name: 'SMS',
                    children: 'SMS',
                    value: 'SMS',
                  },
                  {
                    name: 'Email',
                    children: 'Email',
                    value: 'Email',
                  },
                ]}
              />
            </RadioButtonStyle>
            {(showEmailSection || showMDNSection) && (
              <>
                <DropDowmWrapper>
                  {showMDNSection && (
                    <DropdownSelect
                      label='Select MDN'
                      errorText='Select a state'
                      width='20%'
                      id='select-mdn'
                      data-testid='reason-dropdown'
                      className='reason-dd'
                      value={selectedMDN}
                      onChange={(e) => setSelectedMDN(e.target.value)}
                    >
                      {customerMtns?.map((item) => (
                        <option key={item}>{item}</option>
                      ))}
                    </DropdownSelect>
                  )}
                  {showEmailSection && <Input type='text' label='Email' readOnly value={emailValue} />}
                </DropDowmWrapper>

                <Checkbox
                  name='affirm'
                  width='auto'
                  label={affirmModalConstants.checkboxText}
                  onChange={() => setChecked(!checked)}
                  selected={checked}
                />
                {linkSent && (
                  <IconWrapper>
                    <Icon name='checkmark-alt' size='medium' color='#000' />
                    <div>Link Sent</div>
                  </IconWrapper>
                )}
                <Button size='large' disabled={isDisabled} use='primary' onClick={generateInspicioCall}>
                  {linkSent ? 'Resend link' : 'Send Link'}
                </Button>
              </>
            )}
          </AccordionDetail>
        </AccordionItem>
      </Accordion>
    </>
  );
};

AffirmAccodion.propTypes = {
  showAffirmModal: PropTypes.bool,
  customerMtns: PropTypes.array,
  emailValue: PropTypes.string,
  cartDetails: PropTypes.object,
  setShowAffirmPaymentConfirmation: PropTypes.func,
  setShowAffirmAccordion: PropTypes.func,
};

export default AffirmAccodion;
