import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../modules/store';
import retriveCartJson from '../../__mock__/retrive-cart.json';
import retriveCartJsonnonIspu from '../../__mock__/retrieveCartnonIspu.json';
import retriveCartDueTodayFlagJson from '../../__mock__/retrieveCartMock.json';
import retriveCartJson1 from '../../__mock__/alternateRetrieve-cart.json';
import retriveCartJson2 from '../../__mock__/alternateRetrive-cart.json';
import PriceBreakDown from './PriceBreakDown';
import * as monthlyChargesApiCallHook from '../../pages/home/container/monthlyChargesApiCallHook';
import * as InfoApiCallHook from '../../modules/services/APIService/InfoAPICallHook';
import { setUserAgentIPad } from '../../utils/test-utils/utils';

describe('PriceBreakDown Component', () => {
  setUserAgentIPad();
  const mockGetOtherLineCharges = jest.fn();
  const MockmonthlyCharges = [{ itemType: 'EQUIPMENT', description: 'Monthly Plan Charge', thisMonthCharge: 100 }];
  const mockGetEnrollGiftPurchase = jest.fn();
  beforeEach(() => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ enablePartialNbsPosFFlag: 'TRUE' }));
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ enableFullBlownMfeNbsPosFFlag: 'TRUE' }));
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'TRUE' }));
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ readOrderMfeFFlag: 'TRUE' }));
    sessionStorage.setItem('readOrder', 'true');
  });
  const MOCK_GET_ACTIVE_MTN_LIST = {
    data: {
      status: 0,
      customer: {
        email: 'WIZTLMUOB_ZWZ@VZW.COM',
        billAccounts: [
          {
            mtns: [
              {
                nickName: 'JACK D SMITH-9643',
                mtn: '2059229643',
                mtnStatus: {
                  active: true,
                  suspendedWithBilling: false,
                  suspendedWithoutBilling: false,
                  disconnected: false,
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      category: {
                        basicphone: false,
                        smartphone: false,
                        connectedDevice: false,
                        internetDevice: false,
                        tablet: false,
                        smartwatch: false,
                      },
                      deviceId: '350627354252161',
                      SMSCapable: false,
                    },
                    simInfo: {
                      simId: '89148000008300737495',
                    },
                  },
                ],
                sedOfferInfoList: [],
              },
              {
                nickName: 'JACK D SMITH-0949',
                mtn: '2565990949',
                mtnStatus: {
                  active: true,
                  suspendedWithBilling: false,
                  suspendedWithoutBilling: false,
                  disconnected: false,
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      category: {
                        basicphone: false,
                        smartphone: true,
                        connectedDevice: false,
                        internetDevice: false,
                        tablet: false,
                        smartwatch: false,
                      },
                      deviceId: '352917266205235',
                      SMSCapable: true,
                    },
                    simInfo: {
                      simId: '89148000009936413147',
                    },
                  },
                ],
                sedOfferInfoList: [
                  {
                    category: 'Simple BIC',
                  },
                ],
              },
              {
                nickName: 'JACK D SMITH-7140',
                mtn: '2565997140',
                mtnStatus: {
                  active: true,
                  suspendedWithBilling: false,
                  suspendedWithoutBilling: false,
                  disconnected: false,
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      category: {
                        basicphone: false,
                        smartphone: false,
                        connectedDevice: true,
                        internetDevice: false,
                        tablet: false,
                        smartwatch: true,
                      },
                      deviceId: '354907091265007',
                      SMSCapable: false,
                    },
                    simInfo: {
                      simId: '89148000005847326006',
                    },
                  },
                ],
                sedOfferInfoList: [],
              },
              {
                nickName: 'JACK D SMITH-8699',
                mtn: '2566098699',
                mtnStatus: {
                  active: true,
                  suspendedWithBilling: false,
                  suspendedWithoutBilling: false,
                  disconnected: false,
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      category: {
                        basicphone: false,
                        smartphone: false,
                        connectedDevice: true,
                        internetDevice: false,
                        tablet: false,
                        smartwatch: true,
                      },
                      deviceId: '357129146914656',
                      SMSCapable: false,
                    },
                    simInfo: {
                      simId: '89148000007541538423',
                    },
                  },
                ],
                sedOfferInfoList: [],
              },
              {
                nickName: 'JACK D SMITH-9760',
                mtn: '2566099760',
                mtnStatus: {
                  active: true,
                  suspendedWithBilling: false,
                  suspendedWithoutBilling: false,
                  disconnected: false,
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      category: {
                        basicphone: false,
                        smartphone: true,
                        connectedDevice: false,
                        internetDevice: false,
                        tablet: false,
                        smartwatch: false,
                      },
                      deviceId: '358393411004374',
                      SMSCapable: true,
                    },
                    simInfo: {
                      simId: '89148000009005262011',
                    },
                  },
                ],
                sedOfferInfoList: [
                  {
                    category: 'BMSM OFFER',
                  },
                  {
                    category: 'SPO OFFER - TRADE',
                  },
                ],
              },
              {
                nickName: 'JACK D SMITH-6795',
                mtn: '6153596795',
                mtnStatus: {
                  active: true,
                  suspendedWithBilling: false,
                  suspendedWithoutBilling: false,
                  disconnected: false,
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      category: {
                        basicphone: false,
                        smartphone: true,
                        connectedDevice: false,
                        internetDevice: false,
                        tablet: false,
                        smartwatch: false,
                      },
                      deviceId: '352917267434669',
                      SMSCapable: true,
                    },
                    simInfo: {
                      simId: '89148000010360002166',
                    },
                  },
                ],
                sedOfferInfoList: [],
              },
              {
                nickName: 'JACK D SMITH-7539',
                mtn: '6156867539',
                mtnStatus: {
                  active: true,
                  suspendedWithBilling: false,
                  suspendedWithoutBilling: false,
                  disconnected: false,
                },
                equipmentInfos: [
                  {
                    deviceInfo: {
                      category: {
                        basicphone: false,
                        smartphone: false,
                        connectedDevice: true,
                        internetDevice: false,
                        tablet: false,
                        smartwatch: true,
                      },
                      deviceId: '359809370218191',
                      SMSCapable: false,
                    },
                    simInfo: {
                      simId: '89148000008955592674',
                    },
                  },
                ],
                sedOfferInfoList: [
                  {
                    category: 'BMSM OFFER',
                  },
                  {
                    category: 'SPO OFFER - TRADE',
                  },
                ],
              },
            ],
          },
        ],
      },
    },
  };

  const mockOtherLineChargesResult = ({ monthlyCharges = [], oneTimeCharges = [], addOnsCharges = [] } = {}) => ({
    data: {
      mtnLevelChargeDetails: [
        {
          mtn: '1234567890',
          monthlyCharges,
          oneTimeCharges,
          addOnsCharges,
        },
      ],
      totalOtherLinesCharges: 50,
    },
  });
  test('renders PriceBreakDown', () => {
    window.mfe = {
      scmCheckoutMfeEnable: true,
      historyRef: [],
      isDark: true,
      themeProps: { background: '#eeeeee' },
      scmCheckoutMfeEnabled: true,
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceBreakDown
            selectedMode='VT'
            data={retriveCartJson}
            hideShippingDetails
            selectedReason='test'
            readOrderData={{ orderStatus: 'CR' }}
            isLovEnabled
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getAllByText(/Subtotal due monthly/i);
    expect(titleElement[0]).toBeInTheDocument();
  });

  test('renders 5G Shipment address', () => {
    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: mockOtherLineChargesResult(),
    }));

    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceBreakDown data={retriveCartJson1} />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getAllByText('Subtotal due monthly');
    expect(titleElement[0]).toBeInTheDocument();
  });

  test('renders Service install address', () => {
    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: mockOtherLineChargesResult(),
    }));

    const retriveRes = { ...retriveCartJson1 };
    retriveCartJson1.data.cart.lineDetails.lineInfo[0].lineActivityType = 'NSE_5G';
    delete retriveCartJson1.data.cart.lineDetails.lineInfo[0].serviceInfo.cart5GAddress.addressLine1;
    delete retriveCartJson1.data.cart.lineDetails.lineInfo[0].serviceInfo.cart5GAddress.city;
    delete retriveCartJson1.data.cart.lineDetails.lineInfo[0].serviceInfo.cart5GAddress.state;
    delete retriveCartJson1.data.cart.lineDetails.lineInfo[0].serviceInfo.cart5GAddress.zipCode;
    delete retriveCartJson1.data.cart.lineDetails.lineInfo[0].serviceInfo?.primaryUserInfo?.address?.phoneNumber;

    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceBreakDown data={retriveRes} />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getAllByText('Subtotal due monthly');
    expect(titleElement[0]).toBeInTheDocument();
  });

  test('renders PriceBreakDown', () => {
    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getEnrollGiftPurchase: jest.fn(),
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: { data: mockOtherLineChargesResult({ monthlyCharges: MockmonthlyCharges }) },
    }));
    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => ({
      getActiveMTNRequest: jest.fn(),
      getActiveMTNResponse: MOCK_GET_ACTIVE_MTN_LIST,
    }));
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceBreakDown
            data={retriveCartJson}
            selectedMode='VT'
            selectedReason='test'
            readOrderData={{ orderStatus: 'CR' }}
            hideShippingDetails
            isLovEnabled
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    const titleElement = screen.getAllByText('Subtotal due today');
    expect(titleElement[0]).toBeInTheDocument();
    const totalAmount = screen.getAllByText('$414.96');
    expect(totalAmount[0]).toBeInTheDocument();
    screen.debug();
    const link = screen.getAllByRole('link', { 'aria-label': 'View' });
    fireEvent.click(link[0]);
  });

  test('handles checkbox onChange event', async () => {
    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: mockOtherLineChargesResult(),
      getEnrollGiftPurchase: mockGetEnrollGiftPurchase,
    }));

    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => ({
      getActiveMTNRequest: jest.fn(),
      getActiveMTNResponse: MOCK_GET_ACTIVE_MTN_LIST,
    }));
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceBreakDown
            data={retriveCartJson}
            selectedMode='VT'
            selectedReason='test'
            readOrderData={{ orderStatus: 'CR' }}
            hideShippingDetails
            isLovEnabled
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const titleElement = screen.getAllByText('Subtotal due today');
    expect(titleElement[0]).toBeInTheDocument();
    const totalAmount = screen.getAllByText('$414.96');
    expect(totalAmount[0]).toBeInTheDocument();
    const termsCheckBox = screen.getByText('Supress email notifications for order.');
    fireEvent.click(termsCheckBox);
    expect(mockGetEnrollGiftPurchase).toHaveBeenCalled();
  });

  // test('isDark false case', () => {
  //   window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] ,isDark: false, themeProps: {background: '#eeeeee'}};
  //   render(
  //     <BrowserRouter>
  //       <StoreProvider>
  //         <PriceBreakDown selectedMode='VT' data={retriveCartJson} selectedReason='test' isLovEnabled />
  //       </StoreProvider>
  //     </BrowserRouter>,
  //   );
  //   const titleElement = screen.getAllByText(/Subtotal due monthly/i);
  //   expect(titleElement[0]).toBeInTheDocument();
  // });

  test('Test DFO', () => {
    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: mockOtherLineChargesResult(),
      getEnrollGiftPurchase: mockGetEnrollGiftPurchase,
    }));

    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => ({
      getActiveMTNRequest: jest.fn(),
      getActiveMTNResponse: MOCK_GET_ACTIVE_MTN_LIST,
    }));
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceBreakDown
            data={retriveCartJson}
            selectedMode='VT'
            selectedReason='test'
            readOrderData={{ orderStatus: 'CR' }}
            hideShippingDetails
            isLovEnabled
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const titleElement = screen.getAllByText('Subtotal due today');
    expect(titleElement[0]).toBeInTheDocument();
    const totalAmount = screen.getAllByText('$414.96');
    expect(totalAmount[0]).toBeInTheDocument();
    const checkbox = screen.getByText('Gift Purchase');
    fireEvent.click(checkbox);
    //   expect(mockGetEnrollGiftPurchase).toHaveBeenCalledTimes(1)
  });
  test('Test DFO isdark ', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: false, themeProps: { background: '#eeeeee' } };
    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: mockOtherLineChargesResult(),
      getEnrollGiftPurchase: mockGetEnrollGiftPurchase,
    }));

    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => ({
      getActiveMTNRequest: jest.fn(),
      getActiveMTNResponse: MOCK_GET_ACTIVE_MTN_LIST,
    }));
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceBreakDown
            data={retriveCartJson}
            selectedMode='VT'
            selectedReason='test'
            readOrderData={{ orderStatus: 'CR' }}
            hideShippingDetails
            isLovEnabled
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const titleElement = screen.getAllByText('Subtotal due today');
    expect(titleElement[0]).toBeInTheDocument();
    const totalAmount = screen.getAllByText('$414.96');
    expect(totalAmount[0]).toBeInTheDocument();
    const checkbox = screen.getByText('Gift Purchase');
    fireEvent.click(checkbox);
    // await waitFor(()=> expect(mockGetEnrollGiftPurchase).toHaveBeenCalledTimes(1))
  });

  test('renders Total Payment running Total DueToday', () => {
    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: mockOtherLineChargesResult(),
    }));
    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => ({
      getActiveMTNRequest: jest.fn(),
      getActiveMTNResponse: MOCK_GET_ACTIVE_MTN_LIST,
    }));
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceBreakDown
            selectedMode='VT'
            data={retriveCartDueTodayFlagJson}
            selectedReason='test'
            readOrderData={{ orderStatus: 'CR' }}
            hideShippingDetails
            isLovEnabled
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getAllByText(/Total Payment/i);
    expect(titleElement[0]).toBeInTheDocument();
  });

  test('Test Notification Information ', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: false, themeProps: { background: '#eeeeee' } };
    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: mockOtherLineChargesResult(),
      getEnrollGiftPurchase: mockGetEnrollGiftPurchase,
    }));

    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => ({
      getActiveMTNRequest: jest.fn(),
      getActiveMTNResponse: MOCK_GET_ACTIVE_MTN_LIST,
    }));
    sessionStorage.setItem('channel', 'OMNI-RETAIL-TAB');
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceBreakDown
            data={retriveCartJsonnonIspu}
            selectedMode='VT'
            selectedReason='test'
            readOrderData={{ orderStatus: 'CR' }}
            hideShippingDetails
            isLovEnabled
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getAllByText(/Notification/i);
    expect(titleElement[0]).toBeInTheDocument();
  });

  test('renders Shipping and Service Install Address', () => {
    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: mockOtherLineChargesResult(),
    }));

    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => ({
      getActiveMTNRequest: jest.fn(),
      getActiveMTNResponse: { data: {} },
    }));

    const retriveRes = { ...retriveCartJson1 };
    retriveRes.data.cart.lineDetails.lineInfo[0].lineActivityType = 'NSE_5G';
    retriveRes.data.cart.lineDetails.lineInfo[0].serviceInfo.cart5GAddress = {
      addressLine1: '123 Main St',
      city: 'Anytown',
      state: 'CA',
      zipCode: '12345',
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceBreakDown
            data={retriveRes}
            hideShippingDetails={false}
            pageContext='ReadOrder'
            readOrderData={{ orderStatus: 'CR' }}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const shippingElement = screen.getAllByText('Shipping');
    expect(shippingElement[0]).toBeInTheDocument();

    const serviceInstallAddressElement = screen.getAllByText('Service Install Address');
    expect(serviceInstallAddressElement[0]).toBeInTheDocument();
  });

  test('renders Shipping details when depletionType is not L and hideShippingDetails is false', () => {
    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: mockOtherLineChargesResult(),
    }));

    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => ({
      getActiveMTNRequest: jest.fn(),
      getActiveMTNResponse: { data: {} },
    }));

    const retriveRes = { ...retriveCartJson1 };
    retriveRes.data.cart.lineDetails.lineInfo[0].lineActivityType = 'NSE_5G';
    retriveRes.data.cart.lineDetails.lineInfo[0].serviceInfo.cart5GAddress = {
      addressLine1: '123 Main St',
      city: 'Anytown',
      state: 'CA',
      zipCode: '12345',
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceBreakDown
            data={retriveRes}
            hideShippingDetails={false}
            pageContext='ReadOrder'
            readOrderData={{ orderStatus: 'CR' }}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const shippingElement = screen.getAllByText('Shipping');
    expect(shippingElement[0]).toBeInTheDocument();
  });

  test('does not render Shipping details when hideShippingDetails is true', () => {
    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: mockOtherLineChargesResult(),
    }));

    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => ({
      getActiveMTNRequest: jest.fn(),
      getActiveMTNResponse: { data: {} },
    }));

    const retriveRes = { ...retriveCartJson1 };
    retriveRes.data.cart.lineDetails.lineInfo[0].lineActivityType = 'NSE_5G';
    retriveRes.data.cart.lineDetails.lineInfo[0].serviceInfo.cart5GAddress = {
      addressLine1: '123 Main St',
      city: 'Anytown',
      state: 'CA',
      zipCode: '12345',
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceBreakDown
            data={retriveRes}
            hideShippingDetails
            pageContext='ReadOrder'
            readOrderData={{ orderStatus: 'CR' }}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const shippingElement = screen.queryByText('Shipping');
    expect(shippingElement).toBeNull();
  });
  test('does not render discount details when Quick accessory is true', () => {
    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: mockOtherLineChargesResult(),
    }));

    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => ({
      getActiveMTNRequest: jest.fn(),
      getActiveMTNResponse: { data: {} },
    }));

    const retriveRes = { ...retriveCartJson1 };

    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceBreakDown
            data={retriveRes}
            hideShippingDetails
            pageContext='ReadOrder'
            readOrderData={{ orderStatus: 'CR' }}
            isQAFlow
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const discounts = screen.getByTestId('add-discounts');
    fireEvent.click(discounts);
    fireEvent.click(screen.getByRole('img', { name: 'close icon' }));
  });
  test('does not render discount details when Quick accessory is true', () => {
    window.mfe = {
      scmCheckoutMfeEnable: true,
      historyRef: [],
      isDark: true,
      themeProps: { background: '#eeeeee' },
      scmCheckoutMfeEnabled: true,
    };
    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: mockOtherLineChargesResult(),
    }));

    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => ({
      getActiveMTNRequest: jest.fn(),
      getActiveMTNResponse: { data: {} },
    }));

    const retriveRes = { ...retriveCartJson1 };

    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceBreakDown
            data={retriveRes}
            hideShippingDetails
            pageContext='ReadOrder'
            readOrderData={{ orderStatus: 'CR' }}
            isQAFlow
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const discounts = screen.getByTestId('add-discounts');
    fireEvent.click(discounts);
    fireEvent.click(screen.getByRole('img', { name: 'close icon' }));
  });

  test('render discount details when Quick accessory is true with discount total', () => {
    window.mfe = {
      scmCheckoutMfeEnable: true,
      historyRef: [],
      isDark: true,
      themeProps: { background: '#eeeeee' },
      scmCheckoutMfeEnabled: true,
    };
    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: mockOtherLineChargesResult(),
    }));

    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => ({
      getActiveMTNRequest: jest.fn(),
      getActiveMTNResponse: { data: {} },
    }));

    const retriveRes = JSON.parse(JSON.stringify(retriveCartJson1));
    retriveRes.data.cart.lineDetails.lineInfo[0].itemsInfo[0].cartItems.cartItem[0].discountAmount = 10.0;

    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceBreakDown
            data={retriveRes}
            hideShippingDetails
            pageContext='ReadOrder'
            readOrderData={{ orderStatus: 'CR' }}
            isQAFlow
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const discounts = screen.getByTestId('add-discounts');
    fireEvent.click(discounts);
    fireEvent.click(screen.getByRole('img', { name: 'close icon' }));
  });

  test('render discount details when Quick accessory is true - NSE and shipping address is not updated', () => {
    window.mfe = {
      scmCheckoutMfeEnable: true,
      historyRef: [],
      isDark: true,
      themeProps: { background: '#eeeeee' },
      scmCheckoutMfeEnabled: true,
    };
    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: mockOtherLineChargesResult(),
    }));

    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => ({
      getActiveMTNRequest: jest.fn(),
      getActiveMTNResponse: { data: {} },
    }));

    const retriveRes = JSON.parse(JSON.stringify(retriveCartJson2));
    retriveRes.data.cart.lineDetails.lineInfo[0].itemsInfo[0].cartItems.cartItem[0].discountAmount = 10.0;
    retriveRes.data.cart.cartHeader.cartCreator = null;
    retriveRes.data.cart.lineDetails.lineInfo[0].itemsInfo[0].shipping.address.zipCode = null;

    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceBreakDown
            data={retriveRes}
            hideShippingDetails
            pageContext='ReadOrder'
            readOrderData={{ orderStatus: 'CR' }}
            isQAFlow
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const discounts = screen.getByTestId('add-discounts');
    fireEvent.click(discounts);
  });

  test('render discount details when Quick accessory is true and manager approval loads', () => {
    window.mfe = {
      scmCheckoutMfeEnable: true,
      historyRef: [],
      isDark: true,
      themeProps: { background: '#eeeeee' },
      scmCheckoutMfeEnabled: true,
    };
    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: mockOtherLineChargesResult(),
    }));

    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => ({
      getActiveMTNRequest: jest.fn(),
      getActiveMTNResponse: { data: {} },
    }));

    const retriveRes = JSON.parse(JSON.stringify(retriveCartJson1));
    retriveRes.data.cart.lineDetails.lineInfo[0].itemsInfo[0].cartItems.cartItem[0].discountAmount = 10.0;

    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceBreakDown
            data={retriveRes}
            hideShippingDetails
            pageContext='ReadOrder'
            readOrderData={{ orderStatus: 'CR' }}
            isQAFlow
            showManagerApprovalView
            setShowManagerApprovalView={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );
  });

  test('renders Consumer disclosure for Telesales channel in QA flow', () => {
    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: mockOtherLineChargesResult(),
    }));

    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => ({
      getActiveMTNRequest: jest.fn(),
      getActiveMTNResponse: { data: {} },
    }));

    const retriveRes = { ...retriveCartJson1 };

    sessionStorage.setItem('channel', 'OMNI-TELESALES');

    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceBreakDown
            data={retriveRes}
            hideShippingDetails
            pageContext='ReadOrder'
            readOrderData={{ orderStatus: 'CR' }}
            isQAFlow
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const discounts = screen.getByTestId('consumer-disclosure');
    fireEvent.click(discounts);

    sessionStorage.setItem('channel', 'OMNI-RETAIL');
  });
});

describe('PriceBreakDown Component - nextBillSummaryData Logic', () => {
  const mockSetMontlyDue = jest.fn();
  const mockSetTotalTax = jest.fn();
  const mockGetEnrollGiftPurchase = jest.fn();

  beforeEach(() => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ readOrderMfeFFlag: 'TRUE' }));
    jest.spyOn(React, 'useState').mockImplementation((initialValue) => {
      if (initialValue === undefined) return [undefined, mockSetMontlyDue];
      if (initialValue === null) return [null, mockSetTotalTax];
      return [initialValue, jest.fn()];
    });

    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getEnrollGiftPurchase: mockGetEnrollGiftPurchase,
      getOtherLineCharges: jest.fn(),
      otherLineChargesResult: jest.fn(),
    }));

    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => ({
      getActiveMTNRequest: jest.fn(),
      getActiveMTNResponse: { data: {} },
    }));
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  const mockNextBillSummaryData = {
    nbsVo: {
      monthlyTotalsInfo: {
        newMonthSubtotal: '200.50',
        newMonthNoChangeMdnsTotal: '50.25',
        newMonthTotalTax: '15.75',
      },
    },
  };

  const mockCartData = {
    data: {
      cart: {
        lineDetails: {
          subAccountNBSInfo: [
            {
              billAccounts: [
                {
                  billSummary: {
                    taxesAndFees: {
                      newMonthCharge: '10.00',
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    },
  };

  it('should calculate and set monthly due and total tax correctly when nextBillSummaryData is provided', async () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceBreakDown data={mockCartData} nextBillSummaryData={mockNextBillSummaryData} readOrder />
        </StoreProvider>
      </BrowserRouter>
    );
  });

  it('should fallback to cart taxes when nextBillSummaryData is not provided', async () => {
    const mockNextBillSummaryDataWithoutTax = {
      nbsVo: {
        monthlyTotalsInfo: {
          newMonthSubtotal: '200.50',
          newMonthNoChangeMdnsTotal: '50.25',
        },
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceBreakDown data={mockCartData} nextBillSummaryData={mockNextBillSummaryDataWithoutTax} readOrder />
        </StoreProvider>
      </BrowserRouter>
    );
  });
  it('should fallback to cart taxes when nextBillSummaryData is not provided', async () => {
    const mockNextBillSummaryDataWithoutTax = {
      nbsVo: {
        monthlyTotalsInfo: {
          newMonthSubtotal: '200.50',
          newMonthNoChangeMdnsTotal: null,
        },
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceBreakDown data={mockCartData} nextBillSummaryData={mockNextBillSummaryDataWithoutTax} readOrder />
        </StoreProvider>
      </BrowserRouter>
    );
  });
});
