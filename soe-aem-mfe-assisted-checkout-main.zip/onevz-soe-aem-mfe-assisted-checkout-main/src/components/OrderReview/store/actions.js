export const updateUnifiedNbsData = (request) => ({
  type: 'UPDATE_UNIFIED_NBS_DATA',
  payload: request,
});

export const updateOneUINbsRespSuccess = (request) => ({
  type: 'UPDATE_ONE_UI_NBS_RESP_SUCCESS',
  payload: request,
});

export const updatePartialNbsData = (request) => ({
  type: 'UPDATE_PARTIAL_NBS_DATA',
  payload: request,
});
