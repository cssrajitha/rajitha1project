export const getUnifiedNbsData = (state) => state?.checkoutMfe?.unifiedNbsData || '';

export const getOneUINbsResp = (state) => state?.checkoutMfe?.oneUINbsResp || null;

export const getPartialNbsData = (state) => state?.checkoutMfe?.partialNbsData;
