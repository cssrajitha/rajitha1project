import { checkoutMfe, INITIAL_STATE } from './reducer';

describe('checkoutMfe reducer', () => {
  // Test Case 1: Initial state
  it('should return the initial state when no action is provided', () => {
    // Arrange
    const action = { type: 'UNKNOWN_ACTION' };

    // Act
    const newState = checkoutMfe(undefined, action);

    // Assert
    expect(newState).toEqual(INITIAL_STATE);
  });

  // Test Case 2: Unhandled action type
  it('should return the current state for an unhandled action', () => {
    // Arrange
    const currentState = {
      ...INITIAL_STATE,
      unifiedNbsData: 'some existing data',
    };
    const action = { type: 'ANOTHER_UNHANDLED_ACTION' };

    // Act
    const newState = checkoutMfe(currentState, action);

    // Assert
    expect(newState).toEqual(currentState);
  });

  // Test Case 3: 'UPDATE_UNIFIED_NBS_DATA' action
  it('should handle UPDATE_UNIFIED_NBS_DATA and update unifiedNbsData', () => {
    // Arrange
    const currentState = {
      ...INITIAL_STATE,
      unifiedNbsData: 'old data',
    };
    const action = {
      type: 'UPDATE_UNIFIED_NBS_DATA',
      payload: 'new-unified-data-from-action',
    };

    // Act
    const newState = checkoutMfe(currentState, action);

    // Assert
    const expectedState = {
      ...currentState,
      unifiedNbsData: 'new-unified-data-from-action',
    };
    expect(newState).toEqual(expectedState);
  });

  // Test Case 4: 'UPDATE_ONE_UI_NBS_RESP_SUCCESS' action
  it('should handle UPDATE_ONE_UI_NBS_RESP_SUCCESS and update oneUINbsResp', () => {
    // Arrange
    const currentState = {
      ...INITIAL_STATE,
      oneUINbsResp: { status: 'failure' },
    };
    const mockResponse = {
      status: 'success',
      data: [{ id: 1, name: 'product' }],
    };
    const action = {
      type: 'UPDATE_ONE_UI_NBS_RESP_SUCCESS',
      payload: mockResponse,
    };

    // Act
    const newState = checkoutMfe(currentState, action);

    // Assert
    const expectedState = {
      ...currentState,
      oneUINbsResp: mockResponse,
    };
    expect(newState).toEqual(expectedState);
  });
});

describe('Reducer - UPDATE_PARTIAL_NBS_DATA', () => {
  it('should update partialNbsData in the state', () => {
    // Initial state
    const initialState = {
      partialNbsData: null,
      otherStateProperty: 'someValue',
    };

    // Action to dispatch
    const action = {
      type: 'UPDATE_PARTIAL_NBS_DATA',
      payload: { key: 'value' }, // Mock payload
    };

    // Expected state after the action
    const expectedState = {
      ...initialState,
      partialNbsData: { key: 'value' },
    };

    // Call the reducer
    const newState = checkoutMfe(initialState, action);

    // Assert the new state
    expect(newState).toEqual(expectedState);
  });
});
