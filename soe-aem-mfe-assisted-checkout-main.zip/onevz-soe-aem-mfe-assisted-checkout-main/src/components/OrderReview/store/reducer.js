/* eslint-disable default-param-last */
export const INITIAL_STATE = {
  unifiedNbsData: '',
  oneUINbsResp: null,
  oneUINbsRespFailure: false,
  partialNbsData: null,
};

export const checkoutMfe = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case 'UPDATE_UNIFIED_NBS_DATA':
      return {
        ...state,
        unifiedNbsData: action?.payload,
      };
    case 'UPDATE_ONE_UI_NBS_RESP_SUCCESS':
      return {
        ...state,
        oneUINbsResp: action?.payload,
      };
    case 'UPDATE_PARTIAL_NBS_DATA':
      return {
        ...state,
        partialNbsData: action?.payload,
      };
    default:
      return state;
  }
};
