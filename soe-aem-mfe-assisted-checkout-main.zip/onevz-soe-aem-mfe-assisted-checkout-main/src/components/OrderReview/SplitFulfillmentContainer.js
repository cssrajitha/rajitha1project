import { useState } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { Icon } from '@vds/icons';
import { Title } from '@vds/typography';
import { isEmpty } from 'lodash';
import { formatMtnWithDecimals } from '../../utils/common';

const LeftSideWrapper = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  min-width: 236px;
  padding: 0px 10px;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  font-size: 20px;
  width: 10%;
  margin-top: 8px;
`;
const InfoWrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
`;
const FlexBoxContainer = styled.div`
  display: flex;
  border-bottom: 1px solid rgb(216, 218, 218);
`;
const CollapsedViewFlexContainer = styled.div`
  display: flex;
  border-bottom: 1px solid black;
  margin-top: 8px;
`;
const FlexContainer = styled.div`
  display: flex;
  justify-content: space-between;
  font-size: 20px;
  padding-bottom: 10px;
`;
const DeviceName = styled.div`
  font-size: 18px;
  font-weight: bold;
`;
const CollapseDeviceNames = styled.span`
  font-size: 18px;
  background-color: #f4f4f4;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  padding: 4px;
  margin-right: 10px;
`;
const CollapseViewOrderType = styled.div`
  font-size: 18px;
  font-weight: bold;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
`;
const CollapseDeviceList = styled.span`
  margin-left: 0px;
`;
const StoreAddress = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 10px;
`;
const MarginTop10 = styled.div`
  margin-top: 10px;
`;
const CollapseList = styled.div`
  margin-top: 10px;
  margin-bottom: 16px;
  display: flex;
  display: grid;
  grid-template-columns: 1fr 8fr;
  grid-column-gap: 8px;
  grid-row-gap: 8px;
`;
const FulfillmentHeaderMargin = styled.div`
  margin-top: 12px !important;
  border-bottom: 1px solid rgb(216, 218, 218);
`;
const StoreContainer = styled.div`
  margin: 10px 0px 10px 10px;
  display: grid;
  grid-template-columns: 5fr 5fr;
  grid-column-gap: 8px;
  grid-row-gap: 8px;
`;
const StoreItem = styled.div`
  background-color: #f4f4f4;
  padding: 10px;
  font-size: 16px;
  border-radius: 10px;
`;
const CollapseViewContainer = styled.div`
  margin: 10px 0px 10px 10px;
  display: grid;
  grid-template-columns: 9fr 1fr;
  grid-column-gap: 8px;
  grid-row-gap: 8px;
`;
const CollapseViewItem = styled.div`
  font-size: 16px;
  display: flex;
  justify-content: flex-end;
`;
const ImgWrapper = styled.div`
  display: flex;
  margin-top: 0.5rem;
  margin-left: 10px;
  img {
    max-height: 52px !important;
    max-width: 60px !important;
  }
`;
const ItemBox = styled.div`
  display: flex;
  flex-wrap: wrap;
`;
const FlexItemLeft = styled.div`
  flex: 14%;
`;
const FlexItemRight = styled.div`
  flex: 70%;
  padding: 5px 0 0px 0;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  font-size: 16px;
  line-height: 1.5rem !important;
`;
const CursorPointerWrapper = styled.span`
  cursor: pointer;
`;
const LineSeperator = styled.div`
  border-bottom: 1px solid black;
`;
const AddressHeader = styled.div`
  font-size: 20px;
  margin-top: 8px;
`;
const AddressDetails = styled.div`
  font-size: 16px;
  margin-bottom: 10px;
`;

const SplitFulfillmentContainer = (props) => {
  const [expandView, setExpandView] = useState(true);
  const cartLineInfoVal = props?.cart?.lineDetails?.lineInfo || [];
  const totalCartItems = [];
  cartLineInfoVal?.map((line) =>
    line?.itemsInfo?.[0]?.cartItems?.cartItem?.map((item) => {
      if (item?.cartItemType === 'DEVICE' || item?.cartItemType === 'ACCESSORY') {
        const newItem = { ...item };
        newItem.mobileNumber = line.mobileNumber;
        totalCartItems.push(newItem);
      }
      return 0;
    }),
  );

  const LocalStoreLines = totalCartItems?.filter(
    (item) =>
      item?.depletionType === 'L' &&
      cartLineInfoVal?.find((line) => line?.mobileNumber === item?.mobileNumber && !line?.ispuItem),
  );
  const ShippedLines = totalCartItems?.filter((item) => item?.depletionType === 'F');
  const InstorePickupLines = totalCartItems?.filter(
    (item) =>
      item?.depletionType === 'L' &&
      cartLineInfoVal?.find((line) => line?.mobileNumber === item?.mobileNumber && line?.ispuItem),
  );

  const shippingAddressData = cartLineInfoVal?.find((line) => line.mobileNumber === ShippedLines?.[0]?.mobileNumber);
  const shippedAddress = (!isEmpty(shippingAddressData) && shippingAddressData?.itemsInfo?.[0].shipping?.address) || '';

  const handleExpandAndCollapseView = (data) => {
    setExpandView(!data);
  };

  const handleFulllNameMinimize = (deviceName) => {
    let fulllName = deviceName;
    if (deviceName?.length > 28) {
      fulllName = deviceName && `${deviceName.slice(0, 24)}...`;
    }
    return fulllName;
  };

  const handleDeviceInfoTile = (item, isShip, isInstore) => {
    const line = cartLineInfoVal?.find((data) => data?.mobileNumber === item?.mobileNumber);
    const {
      firstName = '',
      lastName = '',
      address = '',
      preferFirstName = '',
    } = line?.serviceInfo?.primaryUserInfo || '';
    const customerName = address?.firmName ? address.firmName : preferFirstName || `${firstName} ${lastName}`;
    const MDN = line?.mtnDetails?.mobileNumber;
    const deviceURL = item?.imageUrlMap?.defaultImage;
    const deviceName = item?.manufacturer ? `${item?.manufacturer} ${item?.description}` : item?.description;
    const shippingDescription = line?.itemsInfo?.[0]?.shipping?.shippingDescription || '';
    const InstorePickupAddress = line?.itemsInfo?.[0]?.shipping?.address;
    return (
      <StoreItem>
        <ItemBox>
          <FlexItemLeft>
            <ImgWrapper>
              <img src={deviceURL} alt='devicelogo' />
            </ImgWrapper>
          </FlexItemLeft>
          <FlexItemRight>
            <DeviceName>{handleFulllNameMinimize(deviceName)}</DeviceName>
            <div>
              {customerName} | {formatMtnWithDecimals(MDN)}
            </div>
            {shippingDescription && (isShip || isInstore) && <MarginTop10>{shippingDescription}</MarginTop10>}
            {isInstore && InstorePickupAddress && (
              <>
                <StoreAddress>
                  <div>{props?.StoreAddress}</div>
                </StoreAddress>
                <div>{InstorePickupAddress?.addressLine1}</div>
                <div>
                  {InstorePickupAddress?.city}, {InstorePickupAddress?.state}, {InstorePickupAddress?.zipCode}
                </div>
              </>
            )}
          </FlexItemRight>
        </ItemBox>
      </StoreItem>
    );
  };

  const handleCollapsedViewDevice = (line) => {
    const deviceName = line?.manufacturer ? `${line?.manufacturer} ${line?.description}` : line?.description;
    return <CollapseDeviceNames>{handleFulllNameMinimize(deviceName)}</CollapseDeviceNames>;
  };

  const handleCollapsedViewDevicesList = (fulfillmentArrayData, fulfillmentType) => (
    <CollapseList>
      <CollapseViewOrderType>{fulfillmentType}</CollapseViewOrderType>
      <CollapseDeviceList>{fulfillmentArrayData?.map((item) => handleCollapsedViewDevice(item))}</CollapseDeviceList>
    </CollapseList>
  );

  return (
    <>
      {expandView && (
        <div>
          <FulfillmentHeaderMargin>
            <FlexContainer>
              <Title size='small' bold>
                {props?.FulfilmentHeader}
              </Title>
              <Title>
                <span
                  role='presentation'
                  data-testid='collapseViewTestId'
                  onClick={() => handleExpandAndCollapseView(expandView)}
                >
                  <CursorPointerWrapper>
                    <Icon name='up-caret' size='large' medium='true' />
                  </CursorPointerWrapper>
                </span>
              </Title>
            </FlexContainer>
          </FulfillmentHeaderMargin>
          {!isEmpty(LocalStoreLines) && (
            <FlexBoxContainer>
              <LeftSideWrapper>{props?.LocalStore}</LeftSideWrapper>
              <InfoWrapper>
                <StoreContainer>
                  {LocalStoreLines?.map((item) => handleDeviceInfoTile(item, false, false))}
                </StoreContainer>
              </InfoWrapper>
            </FlexBoxContainer>
          )}
          {!isEmpty(ShippedLines) && (
            <FlexBoxContainer>
              <LeftSideWrapper>
                {props?.ShippedItems}
                <AddressHeader>{props?.ShippingAddress}</AddressHeader>
                <AddressDetails>
                  {shippedAddress?.addressLine1}, {shippedAddress?.city}, {shippedAddress?.state},{' '}
                  {shippedAddress?.zipCode}
                </AddressDetails>
              </LeftSideWrapper>
              <InfoWrapper>
                <StoreContainer>{ShippedLines?.map((item) => handleDeviceInfoTile(item, true, false))}</StoreContainer>
              </InfoWrapper>
            </FlexBoxContainer>
          )}
          {!isEmpty(InstorePickupLines) && (
            <FlexBoxContainer>
              <LeftSideWrapper>{props?.InstorePickup}</LeftSideWrapper>
              <InfoWrapper>
                <StoreContainer>
                  {InstorePickupLines?.map((item) => handleDeviceInfoTile(item, false, true))}
                </StoreContainer>
              </InfoWrapper>
            </FlexBoxContainer>
          )}
          <LineSeperator />
        </div>
      )}
      {!expandView && (
        <CollapsedViewFlexContainer>
          <LeftSideWrapper>
            <Title size='small' bold>
              {props?.FulfilmentHeader}
            </Title>
            <div>{totalCartItems?.length} Items</div>
          </LeftSideWrapper>
          <InfoWrapper>
            <CollapseViewContainer>
              <FlexItemLeft>
                {!isEmpty(LocalStoreLines) && handleCollapsedViewDevicesList(LocalStoreLines, 'Local')}
                {!isEmpty(ShippedLines) && handleCollapsedViewDevicesList(ShippedLines, 'Ship')}
                {!isEmpty(InstorePickupLines) && handleCollapsedViewDevicesList(InstorePickupLines, 'In-store')}
              </FlexItemLeft>
              <CollapseViewItem
                role='presentation'
                data-testid='expandViewTestId'
                onClick={() => handleExpandAndCollapseView(expandView)}
              >
                <CursorPointerWrapper>
                  <Icon name='down-caret' size='large' medium='true' />
                </CursorPointerWrapper>
              </CollapseViewItem>
            </CollapseViewContainer>
          </InfoWrapper>
        </CollapsedViewFlexContainer>
      )}
    </>
  );
};

SplitFulfillmentContainer.defaultProps = {
  FulfilmentHeader: 'Fulfillment',
  LocalStore: 'Local Store',
  ShippedItems: 'Shipped Items',
  InstorePickup: 'In-store Pickup',
  ShippingAddress: 'Shipping Address',
  StoreAddress: 'Store Address',
};

SplitFulfillmentContainer.propTypes = {
  FulfilmentHeader: PropTypes.string,
  cart: PropTypes.object,
  LocalStore: PropTypes.string,
  ShippedItems: PropTypes.string,
  InstorePickup: PropTypes.string,
  ShippingAddress: PropTypes.string,
  StoreAddress: PropTypes.string,
};

export default SplitFulfillmentContainer;
