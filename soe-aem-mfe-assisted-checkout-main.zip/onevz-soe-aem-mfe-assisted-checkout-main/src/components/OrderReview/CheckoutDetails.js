import { useState } from 'react';
import PropTypes from 'prop-types';
import DownPaymentPage from 'onevzsoemfecommon/DownPaymentDevice';
import CheckoutLine from './CheckoutLine';

const CheckoutDetails = ({
  cart,
  customer,
  fetchPriceSnapshot,
  setHideShippingDetails,
  CustomerProfileRefetch,
  CartDetailsRefetch,
  fetchPriceSnapshotRefetch,
  setProfInstallappointmentFlag,
  readOrder,
  lineDeviceAndSimIds,
  activationStatus,
  orderStatus,
  cartHeader,
  readOrderData,
  hasSubAccount,
  rspFetchReadOrder,
}) => {
  const lineDetails = cart && cart.lineDetails ? cart.lineDetails : {};
  const lineInfo = lineDetails ? lineDetails.lineInfo : [];
  const planId = cart?.customerProfile?.billAccounts?.[0]?.mtns?.[0]?.pricePlanInfo?.planId;
  const serviceInfo = lineInfo?.[0]?.serviceInfo;

  const visionCustomerType = cart?.cartHeader?.visionCustomerType;

  const customerName =
    visionCustomerType && serviceInfo?.primaryUserInfo?.address?.firmName
      ? serviceInfo.primaryUserInfo.address.firmName
      : serviceInfo?.primaryUserInfo?.preferFirstName || serviceInfo?.primaryUserInfo?.firstName || '';

  let customerEmail = '';
  if (customer) {
    customerEmail = customer.email;
  }

  const [showDownpayment, setShowDownpayment] = useState(false);
  const [showDownpaymentModal, setShowDownpaymentModal] = useState(false);
  const [mtn, setMtn] = useState();

  const getDetails = (element) => {
    const { mobileNumber } = element;
    setMtn(mobileNumber);
  };

  const showDownpaymentView = (element = null, modal = false) => {
    if (element) getDetails(element);
    if (modal) {
      setShowDownpaymentModal(true);
    } else {
      setShowDownpayment(true);
    }
  };

  const handleDPDone = () => {
    setShowDownpayment(false);
    setShowDownpaymentModal(false);
    CustomerProfileRefetch();
    CartDetailsRefetch();
    fetchPriceSnapshotRefetch();
  };

  const CustomerProfileResult = {
    data: {
      data: {
        customer,
      },
    },
  };
  const subAccountDetails = (mobileNumber, fetchPriceSnapshotData) => {
    const filtredSubAccount = fetchPriceSnapshotData?.data?.data?.subAccounts?.filter((account) =>
      account.lines?.some((line) => line?.mtn === mobileNumber),
    );
    return filtredSubAccount;
  };
  const downPaymentHeaderProps = {
    header: 'Down Payments',
  };
  return (
    <div data-testid='checkoutDetail'>
      {lineInfo?.map((line) =>
        line ? (
          <CheckoutLine
            key={`${line.lineNumber}-${line?.installmentInfo?.downPayment}`}
            showDownpaymentView={showDownpaymentView}
            line={line}
            lineInfo={lineInfo}
            customerName={customerName}
            fetchPriceSnapshot={fetchPriceSnapshot}
            planId={planId}
            email={customerEmail}
            cart={cart}
            setHideShippingDetails={setHideShippingDetails}
            CustomerProfileRefetch={CustomerProfileRefetch}
            CartDetailsRefetch={CartDetailsRefetch}
            fetchPriceSnapshotRefetch={fetchPriceSnapshotRefetch}
            setProfInstallappointmentFlag={setProfInstallappointmentFlag}
            readOrder={readOrder}
            lineDeviceAndSimIds={lineDeviceAndSimIds}
            activationStatus={activationStatus}
            orderStatus={orderStatus}
            cartHeader={cartHeader}
            readOrderData={readOrderData}
            hasSubAccount={hasSubAccount}
            subAccount={subAccountDetails(line?.mobileNumber, fetchPriceSnapshot)}
            rspFetchReadOrder={rspFetchReadOrder}
          />
        ) : (
          ''
        ),
      )}
      {(showDownpayment || showDownpaymentModal) && (
        <DownPaymentPage
          CustomerData={CustomerProfileResult?.data?.data?.customer}
          mtn={mtn}
          fromPage=''
          closeClickHandler={handleDPDone}
          closeIcon
          cartHeader={cart?.cartHeader}
          CartLineInfo={cart?.lineDetails?.lineInfo}
          headerData={downPaymentHeaderProps}
        />
      )}
    </div>
  );
};

CheckoutDetails.propTypes = {
  cart: PropTypes.object,
  customer: PropTypes.object,
  fetchPriceSnapshot: PropTypes.object,
  setHideShippingDetails: PropTypes.func,
  CustomerProfileRefetch: PropTypes.func,
  CartDetailsRefetch: PropTypes.func,
  fetchPriceSnapshotRefetch: PropTypes.func,
  setProfInstallappointmentFlag: PropTypes.func,
  readOrder: PropTypes.bool,
  lineDeviceAndSimIds: PropTypes.object,
  activationStatus: PropTypes.object,
  orderStatus: PropTypes.string,
  cartHeader: PropTypes.object,
  readOrderData: PropTypes.object,
  hasSubAccount: PropTypes.bool,
  rspFetchReadOrder: PropTypes.object,
};
export default CheckoutDetails;
