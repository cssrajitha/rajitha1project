import { fireEvent, render, screen } from '@testing-library/react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import AffirmAccordion from './AffirmAccordion';
import cart from '../../__mock__/retrive-cart.json';
import * as ViewTogetherApiCallHook from '../../modules/services/APIService/ViewTogetherApiCallHook';
import { affirmModalConstants } from '../../appconfig';
import StoreProvider from '../../modules/store';

const mockFunc = jest.fn();
const ApiMockFunc = {
  requestBodySendMessage: mockFunc,
  receiveMessage: mockFunc,
  requestBodySendEmail: mockFunc,
  updateAffirm: mockFunc,
  requestBodyGenerateInspicioId: mockFunc,
};
const InspicioMockData = {
  getResultGenerateInspicioId: {
    data: {
      sendInspicioID: 'AGENT-OMNI-RETAIL-91c861fa-dc28-4c',
      receievInspicioID: 'CUST-OMNI-RETAIL-91c861fa-dc28-4c',
      tokenTimestamp: 'tDmO2Z4AGqW8tZCk25Otww',
      receievInspicioToken: 'CUST-OMNI-RETAIL-91c861fa-dc28-4c;tDmO2Z4AGqW8tZCk25Otww',
      sendInspicioToken: 'AGENT-OMNI-RETAIL-91c861fa-dc28-4c;tDmO2Z4AGqW8tZCk25Otww',
    },
    status: 'fulfilled',
  },
};
const sendMessageMockData = {
  getResultSendMessage: {
    data: { status: 'Sent', cluster: 'S', linkExpiredDays: 0, linkExpiredMins: 0 },
    status: 'fulfilled',
  },
};
const sendEmailMockData = {
  getResultSendEmail: {
    data: {
      sendEmailStatus: 'Success',
      inspicioUrl:
        'https://vzwqa3.verizonwireless.com/lov/lovOrderReview.html?p=QUdFTlQtT01OSS1SRVRBSUwtOTFjODYxZmEtZGMyOC00Yzt0RG1PMlo0QUdxVzh0WkNrMjVPdHd3&q=Y&i=S&c=OMNI-RETAIL',
    },
    status: 'fulfilled',
  },
};
const receiveMockData = {
  receiveMessageResult: {
    data: {
      event: 'affirmCheckout',
      payload: {
        affirmPayload: {
          created: '2024-07-01T11:01:03.129239',
          checkout_token: '8X4VJLBT24V1OOER',
        },
        action: 'AffirmPaymentsuccessEvent',
      },
      status: 'Success',
      cluster: 'S',
      reducedTimeout: 'Y',
      linkExpiredDays: 0,
      linkExpiredMins: 0,
    },
    status: 'fulfilled',
  },
};
const receiveFailMockData = {
  receiveMessageResult: {
    data: {
      event: 'affirmCheckout',
      payload: {
        affirmPayload: {
          created: '2024-07-01T11:01:03.129239',
          checkout_token: '8X4VJLBT24V1OOER',
        },
        action: 'AffirmPaymentsuccessEvent',
      },
      status: 'Success',
      cluster: 'S',
      reducedTimeout: 'Y',
      linkExpiredDays: 0,
      linkExpiredMins: 0,
    },
    status: 'Failed',
  },
};

const props = {
  showAffirmModal: true,
  customerMtns: [
    {
      mtn: '147852369',
    },
    {
      mtn: '874963512',
    },
    {
      mtn: '785498785',
    },
  ],
  emailValue: 'abc@gmail.com',
  cartDetails: cart,
  setShowAffirmPaymentConfirmation: mockFunc,
  setShowAffirmAccordion: mockFunc,
};
const generateInspicioIDResponse = {
  data: {
    sendInspicioID: 'AGENT-OMNI-RETAIL-91c861fa-dc28-4c',
    receievInspicioID: 'CUST-OMNI-RETAIL-91c861fa-dc28-4c',
    tokenTimestamp: 'tDmO2Z4AGqW8tZCk25Otww',
    receievInspicioToken: 'CUST-OMNI-RETAIL-91c861fa-dc28-4c;tDmO2Z4AGqW8tZCk25Otww',
    sendInspicioToken: 'AGENT-OMNI-RETAIL-91c861fa-dc28-4c;tDmO2Z4AGqW8tZCk25Otww',
  },
  status: 'fulfilled',
};
const generateInspicioID = [
  rest.post(`*/generateInspicioID`, (req, res, ctx) => res(ctx.status(200), ctx.json(generateInspicioIDResponse))),
];
const server = setupServer(...generateInspicioID);

describe('Affirm accordion', () => {
  beforeEach(async () => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
    server.listen();
  });
  beforeAll(() => server.listen());
  afterEach(() => server.resetHandlers());
  afterAll(() => server.close());
  test('close accordion', () => {
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => ApiMockFunc);
    render(
      <StoreProvider>
        <AffirmAccordion {...props} />
      </StoreProvider>,
    );
    const closeAccordion = screen.getAllByText('Affirm financing credit application');
    fireEvent.click(closeAccordion[0]);
  });
  test('SMS selected', async () => {
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => ApiMockFunc);
    render(
      <StoreProvider>
        <AffirmAccordion {...props} />
      </StoreProvider>,
    );
    const SMSRadioButton = screen.getByRole('radio', { name: 'SMS' });
    fireEvent.click(SMSRadioButton);
    const checkBoxButton = screen.getByText(affirmModalConstants.checkboxText);
    fireEvent.click(checkBoxButton);
    const sendLinkButton = screen.getByText('Send Link');
    fireEvent.click(sendLinkButton);
  });
  test('Receive message failed scenario', async () => {
    const mockData = {
      ...ApiMockFunc,
      ...InspicioMockData,
      ...sendMessageMockData,
      ...sendEmailMockData,
      ...receiveFailMockData,
    };
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData);
    render(
      <StoreProvider>
        <AffirmAccordion {...props} />
      </StoreProvider>,
    );
  });
  test('SMS selected ', async () => {
    const mockData = {
      ...ApiMockFunc,
      ...InspicioMockData,
      ...sendMessageMockData,
      ...sendEmailMockData,
      ...receiveMockData,
    };
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData);
    render(
      <StoreProvider>
        <AffirmAccordion {...props} />
      </StoreProvider>,
    );
    const SMSRadioButton = screen.getByRole('radio', { name: 'SMS' });
    fireEvent.click(SMSRadioButton);
    const checkBoxButton = screen.getByText(affirmModalConstants.checkboxText);
    expect(checkBoxButton).toBeInTheDocument();
    fireEvent.click(checkBoxButton);
    const sendLinkButton = screen.getByText('Resend link');
    expect(sendLinkButton).toBeInTheDocument();
    fireEvent.click(sendLinkButton);
  });
  test('Email selected', async () => {
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => ApiMockFunc);
    render(
      <StoreProvider>
        <AffirmAccordion {...props} />
      </StoreProvider>,
    );
    const EmailRadioButton = screen.getByRole('radio', { name: 'Email' });
    fireEvent.click(EmailRadioButton);
    const checkBoxButton = screen.getByText(affirmModalConstants.checkboxText);
    fireEvent.click(checkBoxButton);
    const sendLinkButton = screen.getByText('Send Link');
    expect(sendLinkButton).toBeInTheDocument();
    fireEvent.click(sendLinkButton);
  });
});
