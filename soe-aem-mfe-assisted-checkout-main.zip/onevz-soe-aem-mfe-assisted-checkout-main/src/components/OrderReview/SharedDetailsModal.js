import styled, { createGlobalStyle } from 'styled-components';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { Body, Title } from '@vds/typography';
import { Modal, ModalTitle, ModalBody, ModalFooter } from '@vds/modals';
import PropTypes from 'prop-types';
import { has } from 'lodash';
import { Line } from '@vds/lines';
import { useState } from 'react';
import moment from 'moment';
import { formatCurrency, scmCheckoutMfeEnabled } from '../../utils/common';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR , isDark , bgColor  } from '../constants/constants';

const ComponentStyle = createGlobalStyle`
  #sharedDetailsModal {
    [class^='Overlay-VDS'] {
      background-color: rgba(0, 0, 0, 0.8);
    }
    [class^='ModalDialog-VDS'] {
      max-width:1024px; 
      border-radius: 0;
      padding: 0;
    }
    [class^='ModalDialogWrapper-VDS'] {
        > span {
          width: 100%;
          height: 100%;

        > div {
          width:100% !important;
          height: 100% !important;

          > div {
            padding:0 !important;
          }
        }
      }
    }

    [class^='StyledModalBody-VDS'] {
      height: 80vh;
      padding: 0.7rem 0px 0px;
      overflow: auto;
    }

    [class^='IconWrapper-VDS'] {
      z-index: 99999;
    }
    
    [class^='StyledHeader-VDS'] {
      border-bottom: 1px solid #ccc;
      position: sticky;
      top:0;      
      z-index: 999;
      padding: 1rem 2rem;
      ${scmCheckoutMfeEnabled ? 'background: "white";' : ''}
    }
    [class^='StyledFooter-VDS'] {
      border-top: 1px solid #ccc;
      position: sticky;
      bottom:0;
    }
  }
    [class^='ButtonGroupRow-VDS']{
    flex-direction:row !important;
    > div {
      padding-right:0.75rem;
    }
  }
`;

const MarginSides = styled.div`
  padding: 0;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
`;

const ModalContentWrapper = styled.div`
  display: flex;
  flex-direction: column;
  padding: 0rem 1rem;
`;

const AccountContainer = styled.div`
  padding-top: 1.3125rem !important;
  padding-right: 1.3125rem !important;
  padding-bottom: 1.3125rem !important;
  padding-left: 1.3125rem !important;
`;

const PlanTitle = styled.div`
  padding-bottom: 5px;
`;

const TileWrapper = styled.div`
  display: flex;
  width: 100%;
`;
const TileItems = styled.div`
  flex-basis: 50%;
  padding-right: 3.75rem;
  background-color: ${(props) => props.backgroundColor && '#f6f6f6'};
  &:last-child {
    padding-right: 0px;
  }
`;

const FooterTileItems = styled(TileItems)`
  padding-top: 0px;
`;
const PlanContent = styled.div`
  display: flex;
  justify-content: space-between;
  padding-top: 10px;
  padding-bottom: 10px;
  margin: 15px 0px;
`;

const OrderLabelText = styled.div`
  width: 70%;
`;

const ChangeLink = styled.div`
  font-weight: bold;
  cursor: pointer;
  font-size: 18px !important;
  font-family: BrandFontBold, sans-serif !important;
  letter-spacing: -0.5px;
`;

const DescriptionPriceSection = styled.div`
  display: flex;
  justify-content: space-between;
`;

const BodyFont = styled.div`
  [class^='StyledTypography-VDS__'] {
    font-size: 24px !important;
    font-family: BrandFontBold, sans-serif !important;
    letter-spacing: -0.5px;
  }
`;
const BodyFont2 = styled.div`
  [class^='StyledTypography-VDS__'] {
    font-size: 20px !important;
    font-family: BrandFontBold, sans-serif !important;
    letter-spacing: -0.5px;
  }
`;

const Titles = {
  accountAddonchangesTitle: 'Shared Services & perks',
  accountAddonchangesTitlePrePay: 'Shared add-ons',
  sharedFeaturesChanges: 'Shared Services & perks Changes',
  sharedFeaturesChangesPrePay: 'Shared add-ons Changes',
  existingSharedFeatureLabel: 'Existing shared Services & perks',
  existingSharedFeatureLabelPrePay: 'Existing shared add-ons',
  accountOldmonthlyTitle: 'Old monthly',
  viewAddonesTitle: 'Services & perks',
  viewAddonesTitlePrePay: 'Add-ons',
  accountTotalTitle: 'Total',
  accountNewmonthlyTitle: 'New monthly',
  viewAddedSharedFeaturesTitle: 'Newly added shared Services & perks',
  viewAddedSharedFeaturesTitlePrePay: 'Newly added shared add-ons',
  viewAddonesremovedTitle: 'Removed Services & perks',
  viewAddonesremovedTitlePrePay: 'Removed add-ons',
  viewSharedFeaturesRemoved: 'Removed shared Services & perks',
  viewSharedFeaturesRemovedPrePay: 'Removed shared add-ons',
  showRemovedFeaturesTitle: 'Show removed Services & perks',
  showRemovedFeaturesTitlePrePay: 'Show removed add-ons',
  hideRemovedFeatures: 'Hide removed Services & perks',
  hideRemovedFeaturesPrePay: 'Hide removed add-ons',
  accountBtndoneTitle: 'Done',
  accountSharedfeaturesTitle: 'Add shared Services & perks',
  accountSharedfeaturesTitlePrePay: 'Add shared add-ons',
  effectiveDateLabel: {
    pastDate: 'Your new Services & perks has been activated and backdated to : ',
    futureDate: 'Your new Services & perks will take effect on : ',
  },
  effectiveDateLabelPrePay: {
    pastDate: 'Your new add-ons has been activated and backdated to : ',
    futureDate: 'Your new add-ons will take effect on : ',  
  },
  changeEffectiveDateLabel: 'Change',
  noSharedFeatureLabel: 'No shared Services & perk(s)',
  noSharedFeatureLabelPrePay: 'No shared add-on(s) ',
};

const getIsPrepayCart = () =>
  sessionStorage.getItem('newPostToPreIndicator') ? sessionStorage.getItem('newPostToPreIndicator') : false;

const SharedDetailsModal = ({ opened, toggleModal, pricedSnapshot, orderDetails }) => {
  const isPrepayCart = getIsPrepayCart();
  const [showRemovedFeatures, setShowRemovedFeatures] = useState(false);
  const [isLandingRedesignFlow] = getAssistedCradlePropertyV2(['isLandingRedesignFlow']);
  const changePlan = () => {
    if (!scmCheckoutMfeEnabled()) {
      window.location.href = `/sales/assisted/landing.html`;
    } else {
      window.Emitter.emit('ACSS_SCM_SWITCH_TAB', { type: 'SWITCH_TAB', targetTab: 'PERKS_TAB' });
    }
  };

  const {
    allSourceExistingSharedFeatures,
    newSharedFeatures,
    oldSharedFeatures,
    existingSharedFeatures,
    existingSharedFeaturesTotal,
    newFeatureTotal,
    orderEffectiveDate,
    effectiveDate,
  } = useSharedDetails(pricedSnapshot, orderDetails);
  const getOrderDetailLabel = () => {
    if (orderEffectiveDate.isFutureDate) {
      return `${
        isPrepayCart ? Titles.effectiveDateLabelPrePay.futureDate : Titles.effectiveDateLabel.futureDate
      } ${effectiveDate}`;
    }
    return `${
      isPrepayCart ? Titles.effectiveDateLabelPrePay.pastDate : Titles.effectiveDateLabel.pastDate
    } ${effectiveDate}`;
  };

  const changeEffectiveDate = () => {
    if (isLandingRedesignFlow === 'TRUE') {
      window.location.href = `/sales/assisted/landing.html`;
    } else {
      window.location.href = `/sales/assisted/home.html`;
    }
  };

  return (
    <>
      <ComponentStyle />
      <div data-testId='sharedDetailsModal'>
        <Modal
          id='sharedDetailsModal'
          opened={opened}
          fullScreenDialog
          surface={isDark() ? 'dark' : 'light'}
          onOpenedChange={toggleModal}
          disableAnimation={false}
          disableOutsideClick={false}
          width='100%'
        >
          <MarginSides>
            <ModalTitle>
              <Title size='small' bold color={isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                {isPrepayCart ? Titles.accountAddonchangesTitlePrePay : Titles.accountAddonchangesTitle}
              </Title>
            </ModalTitle>
            <ModalBody>
              <ModalContentWrapper>
                <SharedFeaturesSection
                  isPrepayCart={isPrepayCart}
                  existingSharedFeaturesTotal={existingSharedFeaturesTotal}
                  newFeatureTotal={newFeatureTotal}
                  allSourceExistingSharedFeatures={allSourceExistingSharedFeatures}
                  newSharedFeatures={newSharedFeatures}
                  showRemovedFeatures={showRemovedFeatures}
                  setShowRemovedFeatures={setShowRemovedFeatures}
                  existingSharedFeatures={existingSharedFeatures}
                  oldSharedFeatures={oldSharedFeatures}
                />
                {(orderEffectiveDate.isFutureDate || orderEffectiveDate.isPastDate) &&
                  (newSharedFeatures.length > 0 || allSourceExistingSharedFeatures.length > 0) && (
                    <EffectiveDate
                      getOrderDetailLabel={getOrderDetailLabel}
                      changeEffectiveDate={changeEffectiveDate}
                    />
                  )}
              </ModalContentWrapper>
            </ModalBody>
            <RenderFooter toggleModal={toggleModal} isPrepayCart={isPrepayCart} changePlan={changePlan}/>
          </MarginSides>
        </Modal>
      </div>
    </>
  );
};

const SharedFeaturesSection = ({
  isPrepayCart,
  existingSharedFeaturesTotal,
  newFeatureTotal,
  allSourceExistingSharedFeatures,
  newSharedFeatures,
  showRemovedFeatures,
  setShowRemovedFeatures,
  existingSharedFeatures,
  oldSharedFeatures
}) => (
  <div className='plan-details' style={{width: scmCheckoutMfeEnabled ? 'auto' : 'unset'}}>
    <div className='custom-modal-body'>
      {existingSharedFeaturesTotal || newFeatureTotal || existingSharedFeatures ? (
        <AccountContainer>
          <BodyFont>
            <Body size='large' bold color={isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
              {isPrepayCart ? Titles.sharedFeaturesChangesPrePay : Titles.sharedFeaturesChanges}
            </Body>
          </BodyFont>
          <TileWrapper>
            <ExistingSharedFeatures
              allSourceExistingSharedFeatures={allSourceExistingSharedFeatures}
              isPrepayCart={isPrepayCart}
            />
            <NewSharedFeatures
              newSharedFeatures={newSharedFeatures}
              showRemovedFeatures={showRemovedFeatures}
              isPrepayCart={isPrepayCart}
              allSourceExistingSharedFeatures={allSourceExistingSharedFeatures}
              oldSharedFeatures={oldSharedFeatures}
              setShowRemovedFeatures={setShowRemovedFeatures}
            />
          </TileWrapper>
          <FooterSection existingSharedFeaturesTotal={existingSharedFeaturesTotal} newFeatureTotal={newFeatureTotal}/>
        </AccountContainer>
      ) : (
        <AccountContainer>
          <Body size='large' color={isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>{isPrepayCart ? Titles.noSharedFeatureLabelPrePay : Titles.noSharedFeatureLabel}</Body>
        </AccountContainer>
      )}
    </div>
  </div>
);

const ExistingSharedFeatures = ({ allSourceExistingSharedFeatures }) => (
  <TileItems>
    <PlanContent>
      <PlanTitle>
        <BodyFont2>
          <Body size='large' bold color={isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
            {Titles.accountOldmonthlyTitle}
          </Body>
        </BodyFont2>
      </PlanTitle>
      <div />
    </PlanContent>
    <Line type='secondary' surface={isDark() ? 'dark' : 'light'}/>
    <PlanContent>
      <div>
        <Body size='large' bold color={isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
          {Titles.accountAddonchangesTitle}
        </Body>
      </div>
      <div />
    </PlanContent>
    <RenderFeatures features={allSourceExistingSharedFeatures}/>
  </TileItems>
);

const NewSharedFeatures = ({
  allSourceExistingSharedFeatures,
  newSharedFeatures,
  showRemovedFeatures,
  isPrepayCart,
  setShowRemovedFeatures,
  oldSharedFeatures
}) => (
  <TileItems>
    <PlanContent>
      <PlanTitle>
        <BodyFont2>
          <Body size='large' bold color={isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
            {Titles.accountNewmonthlyTitle}
          </Body>
        </BodyFont2>
      </PlanTitle>
      <div>
        {showRemovedFeatures ? (
          <ChangeLink
            type='standAlone'
            data-testid='hide-feature'
            style={{
              color: isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR
            }}
            disabled={false}
            size='medium'
            onClick={() => setShowRemovedFeatures(false)}
          >
            {isPrepayCart ? Titles.hideRemovedFeaturesPrePay : Titles.hideRemovedFeatures}
          </ChangeLink>
        ) : (
          <ChangeLink
            type='standAlone'
            data-testid='show-feature'
            style={{
              color: isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR
            }}
            disabled={false}
            size='medium'
            onClick={() => setShowRemovedFeatures(true)}
            data-track={isPrepayCart ? Titles.showRemovedFeaturesTitlePrePay : Titles.showRemovedFeaturesTitle}
          >
            {isPrepayCart ? Titles.showRemovedFeaturesTitlePrePay : Titles.showRemovedFeaturesTitle}
          </ChangeLink>
        )}
      </div>
    </PlanContent>
    <Line type='secondary' surface={isDark() ? 'dark' : 'light'} />
    <PlanContent>
      <div>
        <Body size='large' bold color={isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
          {isPrepayCart ? Titles.viewAddedSharedFeaturesTitlePrePay : Titles.viewAddedSharedFeaturesTitle}
        </Body>
      </div>
      <div />
    </PlanContent>
    <RenderFeatures features={newSharedFeatures}/>
    <Line type='secondary' surface={isDark() ? 'dark' : 'light'}/>
    <PlanContent>
      <div>
        <Body size='large' bold color={isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
          {isPrepayCart ? Titles.existingSharedFeatureLabelPrePay : Titles.existingSharedFeatureLabel}
        </Body>
      </div>
      <div />
    </PlanContent>
    <RenderFeatures features={allSourceExistingSharedFeatures}/>
    {showRemovedFeatures ? (
      <>
        <Line type='secondary' surface={isDark() ? 'dark' : 'light'}/>
        <PlanContent>
          <div>
            <Body size='large' bold color={isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
              {isPrepayCart ? Titles.viewSharedFeaturesRemovedPrePay : Titles.viewSharedFeaturesRemoved}
            </Body>
          </div>
          <div />
        </PlanContent>
        <RenderFeatures features={oldSharedFeatures}/>
      </>
    ) : null}
  </TileItems>
);

const RenderFeatures = ({ features }) => (
  <div>
    {features &&
      features.length > 0 &&
      features.map((feature) => (
        <div key={`${feature.featureDesc}`}>
          {has(feature, 'imageUrlMap.defaultImage') ? <img src={feature.imageUrlMap.defaultImage} alt='' /> : null}
          <DescriptionPriceSection style={{
                color: isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                backgroundColor: isDark() ? bgColor() : 'inherit',
              }}>
            <div dangerouslySetInnerHTML={{ __html: feature.featureDesc ? feature.featureDesc : '' }} />
            <Body size='large' color={isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>{formatCurrency(feature.featurePrice)}</Body>
          </DescriptionPriceSection>
        </div>
      ))}
  </div>
);
const FooterSection = ({ existingSharedFeaturesTotal, newFeatureTotal }) => (
  <TileWrapper>
    <FooterTileItems>
      <Line type='secondary' surface={isDark() ? 'dark' : 'light'}/>
      <PlanContent>
        <Body size='large' bold color={isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
          {Titles.accountTotalTitle}
        </Body>
        <Body size='large' bold color={isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
          {formatCurrency(existingSharedFeaturesTotal)}
        </Body>
      </PlanContent>
    </FooterTileItems>
    <FooterTileItems>
      <Line type='secondary' surface={isDark() ? 'dark' : 'light'}/>
      <PlanContent>
        <Body size='large' bold color={isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
          {Titles.accountTotalTitle}
        </Body>
        <Body size='large' bold color={isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
          {formatCurrency(newFeatureTotal)}
        </Body>
      </PlanContent>
    </FooterTileItems>
  </TileWrapper>
);

const useSharedDetails = (pricedSnapshot, orderDetails) => {
  const getSharedFeatures = (filter) => {
    const { shared: { addons = [] } = {} } = pricedSnapshot || {};
    return addons
      .filter(filter)
      .map(({ sorId: visFeatureCode, skuName: featureDesc, price: { regularPrice, discountedPrice } }) => ({
        visFeatureCode,
        featureDesc,
        featurePrice: discountedPrice < regularPrice ? discountedPrice : regularPrice,
        discountedPrice,
        regularPrice,
      }));
  };
  const getExistingSharedFeatures = () =>
    getSharedFeatures(
      ({ isDisplayable, actionIndicator, isPromoDiscount }) =>
        isDisplayable && !isPromoDiscount && (actionIndicator === 'Z' || actionIndicator === 'K'),
    );

  const getAllSourceExistingSharedFeatures = () =>
    getSharedFeatures(
      ({ actionIndicator, isPromoDiscount }) =>
        (actionIndicator === 'K' || actionIndicator === 'Z') && !isPromoDiscount,
    );
  const getNewSharedFeatures = () =>
    getSharedFeatures(({ isDisplayable, actionIndicator }) => isDisplayable && actionIndicator === 'A');

  const getOldSharedFeatures = () =>
    getSharedFeatures(({ isUserSelected, actionIndicator }) => isUserSelected && actionIndicator === 'D');

  const getExistingFeaturesTotal = () => {
    const existingFeatures = getExistingSharedFeatures();
    return existingFeatures.reduce((total, feature) => total + parseFloat(feature.featurePrice), 0);
  };

  const getNewFeaturesTotal = () => {
    const newFeatures = getNewSharedFeatures();
    return newFeatures.reduce((total, feature) => total + parseFloat(feature.featurePrice), getExistingFeaturesTotal());
  };

  const effectiveDate = orderDetails?.effectiveDateDetails?.selectedDate || '';

  const validateEffectiveDate = () => {
    const now = moment().format('MM/DD/YYYY');
    const eDate = moment(effectiveDate).format('MM/DD/YYYY');
    return {
      isFutureDate: moment(now).isBefore(moment(eDate)),
      isPastDate: moment(now).isAfter(moment(eDate)),
    };
  };

  const allSourceExistingSharedFeatures = getAllSourceExistingSharedFeatures();
  const newSharedFeatures = getNewSharedFeatures();
  const oldSharedFeatures = getOldSharedFeatures();
  const existingSharedFeatures = getExistingSharedFeatures();
  const existingSharedFeaturesTotal = getExistingFeaturesTotal();
  const newFeatureTotal = getNewFeaturesTotal();
  const orderEffectiveDate = validateEffectiveDate();
  return {
    allSourceExistingSharedFeatures,
    newSharedFeatures,
    oldSharedFeatures,
    existingSharedFeatures,
    existingSharedFeaturesTotal,
    newFeatureTotal,
    orderEffectiveDate,
    effectiveDate,
  };
};

const RenderFooter = ({ toggleModal, isPrepayCart, changePlan }) => (
  <ModalFooter
    surface={isDark() ? 'dark' : 'light'}
    buttonData={{
      primary: {
        children: 'Done',
        width: '225px',
        onClick: () => toggleModal(false),
      },
      close: {
        children: isPrepayCart ? 'Add shared add-ons' : 'Add shared Services & perks',
        'data-track': `${isPrepayCart ? 'Add shared add-ons' : 'Add shared Services & perks'}`,
        width: '300px',
        onClick: () => changePlan(),
      },
    }}
  />
);

const EffectiveDate = ({ getOrderDetailLabel, changeEffectiveDate }) => (
  <PlanContent style={{ color: isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
      <OrderLabelText style={{ color: isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
      <div>{getOrderDetailLabel()}</div>
    </OrderLabelText>
    <ChangeLink
      type='standAlone'
      data-testid='change-date'
      style={{
              color: isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR
            }}
      disabled={false}
      size='medium'
      onClick={() => changeEffectiveDate()}
    >
      {Titles.changeEffectiveDateLabel}
    </ChangeLink>
  </PlanContent>
);
SharedDetailsModal.propTypes = {
  opened: PropTypes.object,
  toggleModal: PropTypes.func,
  orderDetails: PropTypes.object,
  pricedSnapshot: PropTypes.object,
};

SharedFeaturesSection.propTypes = {
  isPrepayCart: PropTypes.bool,
  existingSharedFeaturesTotal: PropTypes.string,
  newFeatureTotal: PropTypes.string,
  allSourceExistingSharedFeatures: PropTypes.array,
  newSharedFeatures: PropTypes.array,
  showRemovedFeatures: PropTypes.bool,
  setShowRemovedFeatures: PropTypes.func,
  existingSharedFeatures: PropTypes.array,
  oldSharedFeatures: PropTypes.array,
};

EffectiveDate.propTypes = {
  getOrderDetailLabel: PropTypes.func,
  changeEffectiveDate: PropTypes.func,
};

RenderFooter.propTypes = {
  toggleModal: PropTypes.func,
  isPrepayCart: PropTypes.bool,
  changePlan: PropTypes.func,
};

FooterSection.propTypes = {
  existingSharedFeaturesTotal: PropTypes.string,
  newFeatureTotal: PropTypes.string,
};

RenderFeatures.propTypes = {
  features: PropTypes.array,
};

NewSharedFeatures.propTypes = {
  allSourceExistingSharedFeatures: PropTypes.array,
  newSharedFeatures: PropTypes.array,
  showRemovedFeatures: PropTypes.bool,
  isPrepayCart: PropTypes.bool,
  setShowRemovedFeatures: PropTypes.func,
  oldSharedFeatures: PropTypes.array,
};
ExistingSharedFeatures.propTypes = {
  allSourceExistingSharedFeatures: PropTypes.array,
};
export default SharedDetailsModal;
