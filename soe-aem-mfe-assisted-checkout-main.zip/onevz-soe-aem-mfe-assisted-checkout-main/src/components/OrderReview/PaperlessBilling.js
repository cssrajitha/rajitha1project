import { Checkbox } from '@vds/checkboxes';
import PropTypes from 'prop-types';
import { Tooltip } from '@vds/tooltips';
import { useEffect, useState } from 'react';
import { Button } from '@vds/buttons';
import styled from 'styled-components';
import { Title } from '@vds/typography';
import { Icon } from '@vds/icons';
import { FlexBox } from '../../StyledConstants';
import EmailValidationInput from './InStorePickUpNotification/EmailValidationInput';
import PaperLessBillingApiCallHook from '../../modules/services/APIService/PaperLessBillingApiCallHook';
import { OrderTotalsProps } from '../../appconfig';

const Wrapper = styled.div`
  display: flex;
  border-top: 1px solid black;
  justify-content: space-between;
  padding: 20px 0;
`;

const CheckboxWrapper = styled.div`
  display: flex;
`;

const LeftSideWrapper = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  min-width: 600px;
  padding: 0px 10px;
`;

const LinkWrapper = styled.div`
  margin-bottom: 17px;
  [class^='StyledButton-VDS'] {
    margin: 0px !important;
    background: none !important;
    border: 0px !important;
    padding: 0px !important;
    color: #000000;
    text-decoration: underline;
    border-radius: 0px;
    font-weight: normal !important;
    font-family: BrandFont-Text, Arial, sans-serif !important;
    font-size: 12px !important;
    &:hover {
      box-shadow: none;
    }
  }
  min-width: 76px;
  min-height: 45px;
`;

const RightSideWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between !important;
`;

const BodyWrapper = styled.div`
  font-size: 13px;
  color: #747676 !important;
  font-family: BrandFontBold, Sans-serif !important;
  font-weight: bold;
  line-height: 15px;
  padding-top: 5px;
`;

const EmailWrapper = styled.div`
  font-size: 18px;
  width: 100px;
  font-weight: bold;
  word-wrap: break-word;
  width: 300px;
  font-family: BrandFontBold, Sans-serif !important;
`;

const TooltipWrapper = styled.div`
  [class^='TooltipWrapper-VDS'] {
    margin: 0px;
    margin-top: 1px;
    margin-left: 5px;
  }
`;

const PaperlessBilling = (props) => {
  const { cart, setPaperLessBilling, setUpdatedEmail } = props;

  const customerType = cart?.cart?.orderDetails?.customerType;
  const emailId = cart?.cart?.lineDetails?.lineInfo?.[0]?.serviceInfo?.primaryUserInfo?.emailId ?? '';
  const primaryEmaill = cart?.cart?.orderDetails?.spocs?.notificationOptions?.primaryEmailId;

  const { paperLessBilling } = PaperLessBillingApiCallHook();

  const [paperFreeBillingChecked, setPaperFreeBillingChecked] = useState(false);
  const [email, setEmail] = useState('');
  const [newCustomerEmail, setNewCustomerEmail] = useState({
    value: customerType === 'N' ? emailId : primaryEmaill,
    error: false,
  });

  useEffect(() => {
    if (customerType === 'N' && !paperFreeBillingChecked) {
      setPaperFreeBillingChecked(true);
      setNewCustomerEmail({ value: customerType === 'N' ? emailId : primaryEmaill, error: false });
      setEmail(emailId);
    }
  }, [cart]);

  const [isEmailEditable, setIsEmailEditable] = useState(false);

  const readOrder = !!window?.location?.pathname?.includes('read-order.html');
  const channelId = cart?.cart?.orderDetails?.orderChannelId;
  const channelIdRetail = !!(channelId && channelId.indexOf('OMNI-RETAIL') > -1);
  const channelIdD2D = !!(channelId && channelId.indexOf('OMNI-D2D') > -1);
  const channelIdIndirect = !!(channelId && channelId.indexOf('OMNI-INDIRECT') > -1);
  const subAccountInfo = cart?.cart?.orderDetails?.subAccountInfo ?? [];

  const paperFreeBillingCheck = () => {
    const type = 'AAL';
    if (customerType === 'N') {
      setPaperFreeBillingChecked(!paperFreeBillingChecked);
      setPaperLessBilling(!paperFreeBillingChecked);
    } else {
      const cartId = cart?.cart?.cartHeader?.cartId ?? '';
      const data = {
        cartId,
        intendType: type,
        paperlessbilling: !paperFreeBillingChecked,
      };

      paperLessBilling({ body: data, spinner: false, mock: false });
      setPaperFreeBillingChecked(!paperFreeBillingChecked);
      setPaperLessBilling(!paperFreeBillingChecked);
    }
  };

  const validateEmailAddress = () => {
    if (!newCustomerEmail.error) {
      if (!newCustomerEmail.error) {
        setEmail(newCustomerEmail.value);
        setIsEmailEditable(false);
        setUpdatedEmail(newCustomerEmail.value);
      }
    }
  };

  const validateEmail = (value) => {
    const isValid = value?.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i);
    return !!isValid;
  };

  const isValidEmail = validateEmail(newCustomerEmail.value);

  const handleEmailValue = (data) => {
    const emailData = {};
    emailData.value = data.email;
    emailData.error = data.isEmailError;
    setNewCustomerEmail(emailData);
  };

  const editEmail = () => {
    setIsEmailEditable(true);
  };

  const isPaperLessBilling =
    cart?.cart?.orderDetails?.isPrePayCart !== 'Y' &&
    (cart?.cart?.orderDetails?.customerType === 'N' ||
      (readOrder && (channelIdRetail || channelIdD2D || channelIdIndirect) && subAccountInfo?.length <= 0));

  if (!isPaperLessBilling) {
    return null;
  }

  return (
    <Wrapper>
      {isPaperLessBilling && (
        <>
          <LeftSideWrapper>
            <CheckboxWrapper>
              <Checkbox
                name='Paper free billing'
                checked={paperFreeBillingChecked}
                selected={paperFreeBillingChecked}
                onChange={paperFreeBillingCheck}
                disabled={readOrder && !channelIdIndirect}
              >
                <FlexBox>
                  <Title bold>{OrderTotalsProps.enrollPaperFree}</Title>
                  <TooltipWrapper>
                    <Tooltip renderAnchorElement={() => <Icon name='question' size={25} />}>
                      {OrderTotalsProps.tooltipContent}
                    </Tooltip>
                  </TooltipWrapper>
                </FlexBox>
                <BodyWrapper>{OrderTotalsProps.enrolPaperFreeBillingDesc}</BodyWrapper>
              </Checkbox>
            </CheckboxWrapper>
          </LeftSideWrapper>

          <RightSideWrapper>
            {customerType === 'N' && !readOrder && isEmailEditable && (
              <div>
                {(isEmailEditable || !isValidEmail) && (newCustomerEmail.value !== '' || isEmailEditable) && (
                  <EmailValidationInput
                    testId='paperless-test'
                    required
                    id='inspicioEmailAddress'
                    name='emailAddress'
                    placeholder='Enter Email Address'
                    ariaDescribedBy='InputHelpText'
                    data={{ email: newCustomerEmail.value }}
                    iconName=''
                    autoComplete='off'
                    style={{ marginTop: '0px' }}
                    handleEmailValue={handleEmailValue}
                    isCustomerTypeNSE={customerType === 'N' || false}
                  />
                )}
              </div>
            )}
            {customerType === 'N' && !isEmailEditable && <EmailWrapper>{email}</EmailWrapper>}
            <LinkWrapper>
              {paperFreeBillingChecked && !isEmailEditable && <Button onClick={editEmail}>Edit</Button>}
              {isEmailEditable && (
                <Button data-testid='DoneBtn' onClick={validateEmailAddress} disabled={newCustomerEmail.error}>
                  Done
                </Button>
              )}
            </LinkWrapper>
          </RightSideWrapper>
        </>
      )}
    </Wrapper>
  );
};

PaperlessBilling.propTypes = {
  cart: PropTypes.object,
  setPaperLessBilling: PropTypes.func,
  setUpdatedEmail: PropTypes.func,
};

export default PaperlessBilling;
