/* eslint-disable */
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import Emitter from 'onevzsoemfeframework/Emitter';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import AccessoriesCheckoutDetails from './AccessoriesCheckoutDetails';
import StoreProvider from '../../modules/store';
import cartJson from '../../__mock__/retrive-cart.json';
import cartDetails from './__mock__/cartDetails.json';
import getClickToCallDetailsJson from '../../__mock__/getClickToCallDetails.json';
import * as clickToCallAPICallHook from '../../modules/services/APIService/ClickToCallAPICallHook';
import * as GetAccessApiCallHook from '../../modules/services/APIService/GetAccessAPICallHook';
import { getSetupAndGoCart } from '../../__mock__/setup-go-cart';
import scheduleAppointmentJson from './__mock__/scheduleAppointment.json';
import * as InfoApiCallHook from '../../modules/services/APIService/InfoAPICallHook';

const showRepGuidedScreen = false;

jest.mock('./ViewOrderDocument/ViewOrderDocument', () => () => (
  <div data-testid='mock-ViewOrderDocument'>
    Mocked ViewOrderDocument Component
    <div>value:{true} </div>
    <div>readorder:{true} </div>
    <div>orderNo:{12345}</div>
  </div>
));
jest.mock('onevzsoemfecommon/ViewAddRemark', () => ({
  __esModule: true,
  default: ({ handleBack, handleClose }) => (
    <div>
      <button type='button' data-testid='manager-approval-view-back' onClick={handleBack}>
        back
      </button>
      <button type='button' data-testid='manager-approval-view-close' onClick={handleClose}>
        close
      </button>
    </div>
  ),
  virtual: true,
}));

jest.mock('onevzsoemfecommon/Helpers', () => ({
  ...jest.requireActual('onevzsoemfecommon/Helpers'),
  getQueryParamByName: jest.fn(),
}));

jest.mock('onevzsoemfeframework/AssistedCradleService', () => ({
  __esModule: true,
  ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
  getAssistedCradlePropertyV2: jest.fn(), // Ensure it's a Jest mock function
}));

jest.mock('../../modules/services/APIService/APIServiceCallHook', () => {
  const actualModule = jest.requireActual('../../modules/services/APIService/APIServiceCallHook');
  return {
    ...actualModule,
    useLazySendSecurePaymentEmailQuery: () => [
      jest.fn().mockImplementation(() =>
        Promise.resolve({
          data: {
            data: {
              emailId: 'test@test.com',
            },
          },
        })
      ),
      {
        status: 'fulfilled',
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: false,
        isFetching: false,
        data: {
          data: {
            emailId: 'test@test.com',
          },
        },
      },
    ],
  };
});

jest.mock('./ScheduleAppointment', () => ({
  __esModule: true,
  default: ({ closeAppointment }) => (
    <div>
      <button type='button' data-testid='mocked-schedule-appointment' onClick={closeAppointment}>
        Schedule Appointment Component Mock
      </button>
    </div>
  ),
}));

jest.mock('../../utils/tagging');

describe('Accessories Checkout Details Component', () => {
  const mockSaveOrder = jest.fn();
  const mockAddAccessories = jest.fn();
  const mockGetCustomer = jest.fn();

  const mockReadOrderResponse = {
    orderStatus: 'CR',
    cart: {
      cartHeader: {
        status: 'S',
        fullAccountNumber: '0486957317-1',
      },
      orderDetails: {
        orderList: [{ orderNumber: '20331588' }, { orderNumber: '20331589' }],
      },
    },
    lovIndicator: 'YY',
  };

  const inStorePickupProps = {
    setSelectedReviewMode: jest.fn(),
    setSelectedReason: jest.fn(),
    readOrderResponse: mockReadOrderResponse, // added for common testing
  };
  const mockData = {
    getClickToCallDetailsRequest: mockSaveOrder,
    getClickToCallDetailsResult: { data: getClickToCallDetailsJson },
    requestBodySendMessage: jest.fn(),
  };

  const mockAddAccessoriesData = {
    addAccessories: mockAddAccessories,
    addAccessoriesSuccess: { data: true },
    getCustomerByMtn: mockGetCustomer,
  };

  const mockAddAppMessage = jest.fn();
  const mockClearAppMessage = jest.fn();

  jest.mock('onevzsoemfecommon/AppMessageActions', () => ({
    addAppMessage: mockAddAppMessage,
    clearAppMessages: mockClearAppMessage,
  }));

  beforeEach(() => {
    window.mfe = { scmDeviceMfeEnable: true, scmCheckoutMfeEnable: true, scmUpgradeMfeEnable: true };
    window.mfe.historyRef = jest.fn();
    window.mfe.historyRef.push = jest.fn();
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({ enablePartialNbsPosFFlag: 'TRUE', vtNbsMfeFFlag: 'TRUE' })
    );
    getQueryParamByName.mockReturnValue('false');
  });

  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
    window.mfe = { scmCheckoutMfeEnable: true };
  });
  test('renders AccessoriesCheckoutDetails', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getByText(/Accessories /i);
    expect(titleElement).toBeInTheDocument();
  });

  test('renders AccessoriesCheckoutDetails with getCartDetailsResults prop', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);

    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            getCartDetailsResults={cartDetails}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getByText(/Accessories /i);
    expect(titleElement).toBeInTheDocument();
  });

  test('Should open ModalSideNav once user click on icon', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const ModalSideNav = screen.getByTestId('ModalSideNav');
    expect(ModalSideNav).toBeInTheDocument();
  });

  test('should open modal on click of clicktocall icon ', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            // {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const clicktocallBtn = screen.getByTestId('clicktocall');
    fireEvent.click(clicktocallBtn);
    setTimeout(() => {
      const modal = screen.getByTestId('clicktocall-modal');
      expect(modal).toBeInTheDocument();
    }, 3000);
  });

  test('should open modal on click of clicktocall icon false ', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            // {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const clicktocallBtn = screen.getByTestId('clicktocall');
    fireEvent.click(clicktocallBtn);
    setTimeout(() => {
      const modal = screen.getByTestId('clicktocall-modal');
      expect(modal).toBeInTheDocument();
    }, 3000);
  });

  test('Should open Glance Modal once user click of View items at a glance', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('glance');
    fireEvent.click(title);
    const modal = screen.getByTestId('glance-modal');
    expect(modal).toBeInTheDocument();
    expect(window.vzdl.page.detail).toEqual('Items At A Glance');
  });

  test('Should trigger click of credit Status link', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']); // Override mock
    window.mfe = { scmUpgradeMfeEnable: true, isProspectNewCustomerTab: true };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const menu = screen.getByTestId('three-dot-menu');
    fireEvent.click(menu);
    const title = screen.getByTestId('creditApproval');
    expect(title).toBeInTheDocument();
    fireEvent.click(title);
  });
  test('Should trigger click of credit Status link12', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']); // Override mock
    window.mfe = { scmUpgradeMfeEnable: true, isProspectNewCustomerTab: true, scmCheckoutMfeEnable: true };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const menu = screen.getByTestId('three-dot-menu');
    fireEvent.click(menu);
    const title = screen.getByTestId('creditApproval');
    expect(title).toBeInTheDocument();
    fireEvent.click(title);
  });
  test('Should trigger downpayment  click', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']); // Override mock
    let itemsInfo = cartJson.data.cart.lineDetails.lineInfo[0].itemsInfo;
    window.mfe = { scmUpgradeMfeEnable: true, isProspectNewCustomerTab: true, scmCheckoutMfeEnable: true };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            itemsInfo={itemsInfo}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const menu = screen.getByTestId('three-dot-menu');
    fireEvent.click(menu);
    const title = screen.getByTestId('downPayment');
    expect(title).toBeInTheDocument();
    fireEvent.click(title);
  });
  test('Should trigger click of credit Status link12', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']); // Override mock
    window.mfe = { scmUpgradeMfeEnable: true, isProspectNewCustomerTab: true, scmCheckoutMfeEnable: true };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const menu = screen.getByTestId('three-dot-menu');
    fireEvent.click(menu);
    const title = screen.getByTestId('creditApproval');
    expect(title).toBeInTheDocument();
    fireEvent.click(title);
  });
  test('Should render side-menu when three-dot menu is clicked', async () => {
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']); // Override mock
    window.mfe = {
      scmUpgradeMfeEnable: true,
      scmCheckoutMfeEnable: true,
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            data={cartJson}
            showRepGuidedScreen={false}
            showAffirmAccordion={false}
            isFromReadOrder={false}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const threeDotMenu = screen.getByTestId('three-dot-menu');
    fireEvent.click(threeDotMenu);

  });

  test('should apply top position of 40px to ProspectMenu when scmCheckoutMfe is enabled', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);

    window.mfe = {
      scmUpgradeMfeEnable: true,
      isProspectNewCustomerTab: true,
      scmCheckoutMfeEnable: true,
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            data={cartJson}
            showRepGuidedScreen={false}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const threeDotMenu = screen.getByTestId('three-dot-menu');
    fireEvent.click(threeDotMenu);

  });

  test('dont render Apply Mobile and Manage client account if scmUpgradeMfe flag is true', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: true, isProspectNewCustomerTab: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const backdrop = screen.getByTestId('back-drop');
    const element = screen.queryByText('Apply Mobile');
    expect(element).toBeNull();
    const element2 = screen.queryByText('Manage client account');
    expect(element2).toBeNull();
  });

  test('render Apply Mobile if isProspectNewCustomerTab flag is true', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: true, isProspectNewCustomerTab: true };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const threeDotMenu = screen.getByTestId('three-dot-menu');
    fireEvent.click(threeDotMenu);
    const element = screen.getByTestId('is_apply_mh_discount')
    fireEvent.click(element);
    expect(element).toBeInTheDocument();
  });

  test('Should open Collateral Modal once user click of View collateral', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('collateral');
    fireEvent.click(title);
    const modal = screen.getByTestId('collateral-modal');
    expect(modal).toBeInTheDocument();
    expect(window.vzdl.page.detail).toEqual('Collateral');
  });


  test('Should open Discounts Modal once user click of View Discounts Modal', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails {...{ ...inStorePickupProps, setViewdiscountOpen: jest.fn() }} data={cartJson} />
        </StoreProvider>
      </BrowserRouter>
    );
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('discounts');
    fireEvent.click(title);
    const modal = screen.getByTestId('discounts-modal');
    expect(modal).toBeInTheDocument();
  });

  test('Should close glance modal on click of X button', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('glance');
    fireEvent.click(title);
    const closeButton = screen.getByTestId('close-button');
    fireEvent.click(closeButton);
    const modal = screen.queryByTestId('glance-modal');
    expect(modal).toBeNull();
    expect(window.vzdl.page.detail).toEqual('');
  });

  test('Should close collateral modal on click of X button', () => {
    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('collateral');
    fireEvent.click(title);
    const closeButton = screen.getByTestId('close-button');
    fireEvent.click(closeButton);
    const modal = screen.queryByTestId('collateral-modal');
    expect(modal).toBeNull();
    expect(window.vzdl.page.detail).toEqual('');
  });

  test('Should have edit & delete accessories link', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            isQAFlow={true}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    await waitFor(() => {
      const deleteLink = screen.getByTestId('delete-accessories-link');
      expect(deleteLink).toBeInTheDocument();
      const editLink = screen.getByTestId('edit-accessories-link');
      expect(editLink).toBeInTheDocument();
    });
  });

  test('Should open edit  modal on click edit accessories link', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            isQAFlow={true}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    await waitFor(() => {
      const editLink = screen.getByTestId('edit-accessories-link');
      expect(editLink).toBeInTheDocument();
      fireEvent.click(editLink);
      setTimeout(() => {
        expect(screen.getByTestId('edit-accessories-title')).toBeInTheDocument();
      }, 3000);
    });
  });

  test('Should open edit  modal on click of accessories image', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    await waitFor(() => {
      const editLink = screen.getByTestId('edit-accessories-image-0');
      expect(editLink).toBeInTheDocument();
      fireEvent.click(editLink);
      setTimeout(() => {
        expect(screen.getByTestId('edit-accessories-title')).toBeInTheDocument();
      }, 3000);
      expect(window.vzdl.page.detail).toEqual('Accessories');
    });
  });

  it('Should delete function on click delete accessories link', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    await waitFor(() => {
      const deleteLink = screen.getByTestId('delete-accessories-link');
      expect(deleteLink).toBeInTheDocument();
      fireEvent.click(deleteLink);
      setTimeout(() => {
        expect(screen.getByTestId('accessories-title')).not.toBeInTheDocument();
      }, 2000);
    });
  });

  it('Should delete function on click delete accessories link ACSS', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    await waitFor(() => {
      const deleteLink = screen.getByTestId('delete-accessories-link');
      expect(deleteLink).toBeInTheDocument();
      fireEvent.click(deleteLink);
      Emitter.emit('ADD_SELECTED_DEVICE_TO_CART', {});
      setTimeout(() => {
        expect(screen.getByTestId('accessories-title')).not.toBeInTheDocument();
      }, 3000);
    });
  });

  it('Should render setup and go', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={getSetupAndGoCart(0, 'ACC')}
            customerInfo={{
              customerName: {
                firstName: 'Firstname',
                preferPronoun: 'pronoun name',
              },
            }}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    expect(screen.getByText(/Setup & Go Service Charge/i)).toBeInTheDocument();
    expect(screen.getByText(/0.00/i)).toBeInTheDocument();
    expect(screen.getByText(/firstname/i)).toBeInTheDocument();
  });

  it('Should render setup and go with discount price', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails {...inStorePickupProps} data={getSetupAndGoCart(159.88, 'ACC')} />
        </StoreProvider>
      </BrowserRouter>
    );
    expect(screen.getByText(/159.88/i)).toBeInTheDocument();
  });

  it('schedule appointment details and click on link', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails {...inStorePickupProps} data={scheduleAppointmentJson} />
        </StoreProvider>
      </BrowserRouter>
    );
    const scheduleAppointmentLink = screen.getByTestId('schedule-appointment');
    expect(scheduleAppointmentLink).toBeInTheDocument();
    fireEvent.click(scheduleAppointmentLink);

    const mockComp = screen.getByTestId('mocked-schedule-appointment');
    expect(mockComp).toBeInTheDocument();
    fireEvent.click(mockComp);
  });

  it('isDark true', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails {...inStorePickupProps} data={scheduleAppointmentJson} />
        </StoreProvider>
      </BrowserRouter>
    );
    const scheduleAppointmentLink = screen.getByTestId('schedule-appointment');
    expect(scheduleAppointmentLink).toBeInTheDocument();
    fireEvent.click(scheduleAppointmentLink);
  });

  it('should render <OrderSummaryLine />', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails {...inStorePickupProps} data={scheduleAppointmentJson} />
        </StoreProvider>
      </BrowserRouter>
    );
    const orderSummary = screen.getByTestId('order-summary-line');
    expect(orderSummary).toBeInTheDocument();
    expect(orderSummary).toHaveTextContent('Order number: 20331588/20331589');
    expect(orderSummary).toHaveTextContent(`Order Status: CR`);
    expect(orderSummary).toHaveTextContent(`Acc number: 0486957317`);
  });

  it('Should delete function on click delete accessories link1', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    window.mfe = { scmCheckoutMfeEnable: false };
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    await waitFor(() => {
      const deleteLink = screen.getByTestId('delete-accessories-link');
      expect(deleteLink).toBeInTheDocument();
      fireEvent.click(deleteLink);
      setTimeout(() => {
        expect(screen.getByTestId('accessories-title')).not.toBeInTheDocument();
      }, 2000);
    });
  });
  test('Should open edit  modal on click edit accessories link', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock
    let cartMockData = cartJson;
    cartMockData.data.cart.lineDetails.lineInfo[0].itemsInfo[0].cartItems.cartItem[0].prodCode2 = 'GIF';
    cartMockData.data.cart.lineDetails.lineInfo[0].itemsInfo[0].cartItems.cartItem[0].deviceDisplayName = '';
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartMockData}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            isQAFlow={true}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    await waitFor(() => {
      const editLink = screen.getByTestId('edit-accessories-link');
      expect(editLink).toBeInTheDocument();
      fireEvent.click(editLink);
      setTimeout(() => {
        expect(screen.getByTestId('edit-accessories-title')).toBeInTheDocument();
      }, 3000);
    });
  });
});

describe('Accessories Checkout Details Component', () => {
  const mockSaveOrder = jest.fn();
  const mockAddAccessories = jest.fn();
  const mockGetCustomer = jest.fn();
  const inStorePickupProps = {
    setSelectedReviewMode: jest.fn(),
    setSelectedReason: jest.fn(),
  };
  const mockData = {
    getClickToCallDetailsRequest: mockSaveOrder,
    getClickToCallDetailsResult: { data: getClickToCallDetailsJson },
  };

  const mockAddAccessoriesData = {
    addAccessories: mockAddAccessories,
    addAccessoriesSuccess: { data: true },
    getCustomerByMtn: mockGetCustomer,
  };

  const mockAddAppMessage = jest.fn();
  const mockClearAppMessage = jest.fn();

  jest.mock('onevzsoemfecommon/AppMessageActions', () => ({
    addAppMessage: mockAddAppMessage,
    clearAppMessages: mockClearAppMessage,
  }));

  beforeEach(() => {
    window.mfe = { scmDeviceMfeEnable: true, scmCheckoutMfeEnable: true };
    window.mfe.historyRef = jest.fn();
    window.mfe.historyRef.push = jest.fn();
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({ enablePartialNbsPosFFlag: 'FALSE', vtNbsMfeFFlag: 'TRUE' })
    );
    getQueryParamByName.mockReturnValue('false');
  });

  test('renders AccessoriesCheckoutDetails', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    const appointmentMockCartJson = {
      data: {
        data: {
          cart: {
            cartHeader: {
              cartCreator: 'creator',
              caseId: 'caseId',
            },
            orderDetails: {
              customerType: 'N',
              spocs: { notificationOptions: { primaryEmailId: 'email@domain.com' } },
              orderList: [{ creditApplication: { creditApplicationNum: '12345' }, orderNumber: '20331589' }],
            },
            lineDetails: {
              lineInfo: [
                {
                  serviceInfo: {
                    cart5GAppointment: {
                      customerInstructions: '',
                      emailAddress: 'SENTHIL.KUMAR.BHOOPALAN@ONE.VERIZON.COM',
                      eventCorrelationId: '60611_1737642957399_182',
                      firstName: 'BRIAN',
                      homePhone: '9089349238',
                      installApptSelectedDate: {
                        availableDate: '20250201',
                        availableDay: '6',
                        availableType: '0',
                        serviceProviderAccount: '1115183',
                        serviceProviderName: 'ASURION INSTALLER',
                        slotLength: '2',
                        slotStartTime: '0800',
                      },
                      lastName: 'WRIGHT',
                      preferredContactType: 'Email',
                      primaryPhoneType: 'Home',
                    },
                  },
                },
              ],
              tradeInDetail: { tradeInItems: [{ id: 'tradeInItem' }] },
            },
            quote: { quoteId: 'quoteId' },
          },
        },
      },
    };

    const mockInfoApiData = {
      getCartRequest: jest.fn(),
      getCartResponse: appointmentMockCartJson,
      submitUserInfo: jest.fn(),

      fetchPricingSnapRequest: jest.fn(),
      getActiveMTNRequest: jest.fn(),
      orderReviewRequest: jest.fn(),
    };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getByText(/Accessories /i);
    expect(titleElement).toBeInTheDocument();
  });
});

describe('Accessories Read Order Component', () => {
  const mockSaveOrder = jest.fn();
  const mockAddAccessories = jest.fn();
  const mockGetCustomer = jest.fn();

  const mockReadOrderResponse = {
    orderStatus: 'CR',
    cart: {
      cartHeader: {
        status: 'S',
        fullAccountNumber: '0486957317-1',
      },
      orderDetails: {
        orderList: [{ orderNumber: '20331588' }, { orderNumber: '20331589' }],
      },
    },
    lovIndicator: 'YY',
  };

  const inStorePickupProps = {
    setSelectedReviewMode: jest.fn(),
    setSelectedReason: jest.fn(),
    readOrderResponse: mockReadOrderResponse, // added for common testing
  };
  const mockData = {
    getClickToCallDetailsRequest: mockSaveOrder,
    getClickToCallDetailsResult: { data: getClickToCallDetailsJson },
  };

  const mockAddAccessoriesData = {
    addAccessories: mockAddAccessories,
    addAccessoriesSuccess: { data: true },
    getCustomerByMtn: mockGetCustomer,
  };

  const mockAddAppMessage = jest.fn();
  const mockClearAppMessage = jest.fn();

  jest.mock('onevzsoemfecommon/AppMessageActions', () => ({
    addAppMessage: mockAddAppMessage,
    clearAppMessages: mockClearAppMessage,
  }));

  beforeEach(() => {
    window.mfe = { scmDeviceMfeEnable: true, scmCheckoutMfeEnable: true, scmUpgradeMfeEnable: true };
    window.mfe.historyRef = jest.fn();
    window.mfe.historyRef.push = jest.fn();
    const appointmentMockCartJson = {
      data: {
        data: {
          cart: {
            cartHeader: {
              cartCreator: 'creator',
              caseId: 'caseId',
            },
            orderDetails: {
              customerType: 'N',
              spocs: { notificationOptions: { primaryEmailId: 'email@domain.com' } },
              orderList: [{ creditApplication: { creditApplicationNum: '12345' }, orderNumber: '20331589' }],
            },
            lineDetails: {
              lineInfo: [
                {
                  serviceInfo: {
                    cart5GAppointment: {
                      customerInstructions: '',
                      emailAddress: 'SENTHIL.KUMAR.BHOOPALAN@ONE.VERIZON.COM',
                      eventCorrelationId: '60611_1737642957399_182',
                      firstName: 'BRIAN',
                      homePhone: '9089349238',
                      installApptSelectedDate: {
                        availableDate: '20250201',
                        availableDay: '6',
                        availableType: '0',
                        serviceProviderAccount: '1115183',
                        serviceProviderName: 'ASURION INSTALLER',
                        slotLength: '2',
                        slotStartTime: '0800',
                      },
                      lastName: 'WRIGHT',
                      preferredContactType: 'Email',
                      primaryPhoneType: 'Home',
                    },
                  },
                },
              ],
              tradeInDetail: { tradeInItems: [{ id: 'tradeInItem' }] },
            },
            quote: { quoteId: 'quoteId' },
          },
        },
      },
    };

    const mockInfoApiData = {
      getCartRequest: jest.fn(),
      getCartResponse: appointmentMockCartJson,
      submitUserInfo: jest.fn(),

      fetchPricingSnapRequest: jest.fn(),
      getActiveMTNRequest: jest.fn(),
      orderReviewRequest: jest.fn(),
    };
    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => mockInfoApiData);
    getQueryParamByName.mockReturnValue('false');

    jest.clearAllMocks();
    jest.resetModules();
    jest.restoreAllMocks();
  });

  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  // new iteam added for read-Order
  test('Should open devicePayment Modal once user click of devicePayment', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            lines={cartJson.data.cart.lineDetails.lineInfo}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            readOrderResponse={{ orderStatus: 'CO' }}
            isFromReadOrder
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('devicePayment');
    fireEvent.click(title);

    // lines added to check the functionality of handleToggle
    const modal = screen.getByTestId('devicePayment-modal');
    expect(modal).toBeInTheDocument();
    const closeButton = screen.getByTestId('Agreement Status Close Modal');
    fireEvent.click(closeButton);
    // fireEvent.click(screen.getByTestId('viewadd-accessories-link'));
    expect(screen.queryByTestId('devicePayment-modal')).toBeNull();
  });

  test('Should open devicePayment Modal once user click of devicePayment', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            lines={cartJson.data.cart.lineDetails.lineInfo}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            readOrderResponse={{ orderStatus: 'CR' }}
            isFromReadOrder
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    fireEvent.click(screen.getByTestId('viewadd-accessories-link'));
  });

  test('Should open devicePayment Modal once user click of devicePayment', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            lines={cartJson.data.cart.lineDetails.lineInfo}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            readOrderResponse={{ orderStatus: 'CR' }}
            isFromReadOrder
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    fireEvent.click(screen.getByTestId('viewadd-accessories-link'));
  });

  test('Should open remarks Modal once user click of remarks', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            isFromReadOrder
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('remarks');
    fireEvent.click(title);
  });
  test('Should open glance Modal once user click of glance', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            isFromReadOrder
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('glance');
    fireEvent.click(title);
  });
  test('Should open collateral Modal once user click of collateral', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            isFromReadOrder
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('collateral');
    fireEvent.click(title);
  });
  test('Should open printreceipt Modal once user click of printreceipt', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);

    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    window.mfe = { scmUpgradeMfeEnable: false };
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            isFromReadOrder
            customerInfo={{ billAccounts: [{ billAccountNo: '1' }], billingSystem: 'VZB', loggedInUser: 'machakr' }}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('printreceipt');
    fireEvent.click(title);
    waitFor(() => {
      // const title1 = screen.getByTestId('ViewPrintReceiept');
      // fireEvent.click(title1);
      const ViewPrintReceieptModal = screen.getByTestId('ViewPrintReceiept-modal');
      expect(ViewPrintReceieptModal).toBeInTheDocument();
    });
  });
  test('Should open PaymentHistory Modal once user click of PaymentHistory', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    window.mfe = { scmUpgradeMfeEnable: false };
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            isFromReadOrder
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('PaymentHistory');
    fireEvent.click(title);
  });
  // test('Should open CreditStatus Modal once user click of CreditStatus', () => {
  //   getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock
  //   jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
  //   jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
  //   sessionStorage.setItem('readOrder', true);
  //   sessionStorage.setItem('channel', 'OMNI-RETAIL');
  //   render(
  //     <BrowserRouter>
  //       <StoreProvider>
  //         <AccessoriesCheckoutDetails
  //           {...inStorePickupProps}
  //           data={cartJson}
  //           showRepGuidedScreen={showRepGuidedScreen}
  //           showAffirmAccordion={false}
  //           isFromReadOrder
  //         />
  //       </StoreProvider>
  //     </BrowserRouter>,
  //   );
  //   global.window.vzdl = { page: { detail: '' } };
  //   const backdrop = screen.getAllByTestId('hamburger-icon')[0];
  //   fireEvent.click(backdrop);
  //   const title = screen.getByTestId('CreditStatus');
  //   fireEvent.click(title);
  // });

  test('Should open clicktocall Modal once user click of clicktocall', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    window.mfe = { scmUpgradeMfeEnable: false };
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            isFromReadOrder
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getAllByTestId('clicktocall')[0];
    fireEvent.click(title);
  });

  test('Should open trackit Modal once user click of trackit', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({ quickAccessoryCheckoutTaggingFFlag: 'TRUE', isTrackItEnabled: 'TRUE', vtNbsMfeFFlag: 'TRUE' }));
    window.mfe = { scmDeviceMfeEnable: true, scmCheckoutMfeEnable: true, isDark: true, scmUpgradeMfeEnable: false };
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            isFromReadOrder
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('trackit');
    fireEvent.click(title);
  });

  test('Should open resend paymenmt Modal once user click of resend payment link', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ isTrackItEnabled: 'TRUE', vtNbsMfeFFlag: 'TRUE' }));
    window.mfe = { scmDeviceMfeEnable: true, scmCheckoutMfeEnable: true, isDark: true, scmUpgradeMfeEnable: false };
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...{
              ...inStorePickupProps,
              readOrderResponse: {
                securePaymentOrderDetails: [
                  {
                    orderNumber: '12345',
                    paymentMethod: 'Credit Card',
                    amount: 100.0,
                    currency: 'USD',
                    isSecure: true,
                  },
                  {
                    orderNumber: '67890',
                    paymentMethod: 'PayPal',
                    amount: 50.0,
                    currency: 'USD',
                    isSecure: true,
                  },
                ],
                orderStatus: 'CR',
              },
            }}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            isFromReadOrder
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('resendPaymentLink');
    fireEvent.click(title);
  });

  test('renders AccessoriesCheckoutDetails with getCartDetailsResults prop', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);

    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            getCartDetailsResults={cartDetails}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getByText(/Accessories /i);
    expect(titleElement).toBeInTheDocument();
  });

  test('Should open View add remark Modal once user click of View/add remark', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    window.mfe = { scmUpgradeMfeEnable: false };
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('remarks');
    fireEvent.click(title);
    const modal = screen.getByTestId('viewAddRemarks-modal');
    expect(modal).toBeInTheDocument();
  });
});

describe('Accessories Read Order Component', () => {
  const mockSaveOrder = jest.fn();
  const mockAddAccessories = jest.fn();
  const mockGetCustomer = jest.fn();

  const mockReadOrderResponse = {
    orderStatus: 'CR',
    cart: {
      cartHeader: {
        status: 'S',
        fullAccountNumber: '0486957317-1',
      },
      orderDetails: {
        orderList: [{ orderNumber: '20331588' }, { orderNumber: '20331589' }],
      },
    },
    lovIndicator: 'YY',
  };

  const inStorePickupProps = {
    setSelectedReviewMode: jest.fn(),
    setSelectedReason: jest.fn(),
    readOrderResponse: mockReadOrderResponse, // added for common testing
  };
  const mockData = {
    getClickToCallDetailsRequest: mockSaveOrder,
    getClickToCallDetailsResult: { data: getClickToCallDetailsJson },
  };

  const mockAddAccessoriesData = {
    addAccessories: mockAddAccessories,
    addAccessoriesSuccess: { data: true },
    getCustomerByMtn: mockGetCustomer,
  };

  const mockAddAppMessage = jest.fn();
  const mockClearAppMessage = jest.fn();

  jest.mock('onevzsoemfecommon/AppMessageActions', () => ({
    addAppMessage: mockAddAppMessage,
    clearAppMessages: mockClearAppMessage,
  }));

  beforeEach(() => {
    window.mfe = { scmDeviceMfeEnable: true, scmCheckoutMfeEnable: true, scmUpgradeMfeEnable: true };
    window.mfe.historyRef = jest.fn();
    window.mfe.historyRef.push = jest.fn();
    const appointmentMockCartJson = {
      data: {
        data: {
          cart: {
            cartHeader: {
              cartCreator: 'creator',
              caseId: 'caseId',
            },
            orderDetails: {
              customerType: 'N',
              spocs: { notificationOptions: { primaryEmailId: 'email@domain.com' } },
              orderList: [{ creditApplication: { creditApplicationNum: '12345' }, orderNumber: '20331589' }],
            },
            lineDetails: {
              lineInfo: [
                {
                  serviceInfo: {
                    cart5GAppointment: {
                      customerInstructions: '',
                      emailAddress: 'SENTHIL.KUMAR.BHOOPALAN@ONE.VERIZON.COM',
                      eventCorrelationId: '60611_1737642957399_182',
                      firstName: 'BRIAN',
                      homePhone: '9089349238',
                      installApptSelectedDate: {
                        availableDate: '20250201',
                        availableDay: '6',
                        availableType: '0',
                        serviceProviderAccount: '1115183',
                        serviceProviderName: 'ASURION INSTALLER',
                        slotLength: '2',
                        slotStartTime: '0800',
                      },
                      lastName: 'WRIGHT',
                      preferredContactType: 'Email',
                      primaryPhoneType: 'Home',
                    },
                  },
                },
              ],
              tradeInDetail: { tradeInItems: [{ id: 'tradeInItem' }] },
            },
            quote: { quoteId: 'quoteId' },
          },
        },
      },
    };

    const mockInfoApiData = {
      getCartRequest: jest.fn(),
      getCartResponse: appointmentMockCartJson,
      submitUserInfo: jest.fn(),

      fetchPricingSnapRequest: jest.fn(),
      getActiveMTNRequest: jest.fn(),
      orderReviewRequest: jest.fn(),
    };
    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => mockInfoApiData);
    getQueryParamByName.mockReturnValue('true');
  });

  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  // new iteam added for read-Order
  test('Should open devicePayment Modal once user click of devicePayment', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            lines={cartJson.data.cart.lineDetails.lineInfo}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            readOrderResponse={{ orderStatus: 'CO' }}
            isFromReadOrder
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    fireEvent.click(screen.getByTestId('view-accessories-link'));
  });
});

describe('view discount and promos', () => {
  const mockAddAccessories = jest.fn();
  const mockGetCustomer = jest.fn();
  const mockSaveOrder = jest.fn();

  const mockData = {
    getClickToCallDetailsRequest: mockSaveOrder,
    getClickToCallDetailsResult: { data: getClickToCallDetailsJson },
  };
  const mockAddAccessoriesData = {
    addAccessories: mockAddAccessories,
    addAccessoriesSuccess: { data: true },
    getCustomerByMtn: mockGetCustomer,
  };
  const mockReadOrderResponse = {
    orderStatus: 'CR',
    cart: {
      cartHeader: {
        status: 'S',
        fullAccountNumber: '0486957317-1',
      },
      orderDetails: {
        orderList: [{ orderNumber: '20331588' }, { orderNumber: '20331589' }],
      },
    },
    lovIndicator: 'YY',
  };
  const inStorePickupProps = {
    setSelectedReviewMode: jest.fn(),
    setSelectedReason: jest.fn(),
    readOrderResponse: mockReadOrderResponse, // added for common testing
  };

  const appointmentMockCartJson = {
    data: {
      data: {
        cart: {
          cartHeader: {
            cartCreator: 'creator',
            caseId: 'caseId',
          },
          orderDetails: {
            customerType: 'N',
            spocs: { notificationOptions: { primaryEmailId: 'email@domain.com' } },
            orderList: [{ creditApplication: { creditApplicationNum: '12345' }, orderNumber: '20331589' }],
          },
          lineDetails: {
            lineInfo: [
              {
                serviceInfo: {
                  cart5GAppointment: {
                    customerInstructions: '',
                    emailAddress: 'SENTHIL.KUMAR.BHOOPALAN@ONE.VERIZON.COM',
                    eventCorrelationId: '60611_1737642957399_182',
                    firstName: 'BRIAN',
                    homePhone: '9089349238',
                    installApptSelectedDate: {
                      availableDate: '20250201',
                      availableDay: '6',
                      availableType: '0',
                      serviceProviderAccount: '1115183',
                      serviceProviderName: 'ASURION INSTALLER',
                      slotLength: '2',
                      slotStartTime: '0800',
                    },
                    lastName: 'WRIGHT',
                    preferredContactType: 'Email',
                    primaryPhoneType: 'Home',
                  },
                },
              },
            ],
            tradeInDetail: { tradeInItems: [{ id: 'tradeInItem' }] },
          },
          quote: { quoteId: 'quoteId' },
        },
      },
    },
  };
  const mockInfoApiData = {
    getCartRequest: jest.fn(),
    getCartResponse: appointmentMockCartJson,
    submitUserInfo: jest.fn(),

    fetchPricingSnapRequest: jest.fn(),
    getActiveMTNRequest: jest.fn(),
    orderReviewRequest: jest.fn(),

    updateVisionRemark: jest.fn(),
    readOrderDocInfo: jest.fn(),
  };

  beforeEach(() => {
    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => mockInfoApiData);
  });
  test('Should open Discounts Modal once user click of View Discounts Modal when scmUpgradeMfeEnable true and not readorder flow', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']); // Override mock
    sessionStorage.setItem('readOrder', '');
    window.mfe = { scmUpgradeMfeEnable: true };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails {...{ ...inStorePickupProps, setViewdiscountOpen: jest.fn() }} data={cartJson} />
        </StoreProvider>
      </BrowserRouter>
    );
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('discounts');
    fireEvent.click(title);
    const modal = screen.getByTestId('discounts-modal');
    expect(modal).toBeInTheDocument();
    const closeBtn = screen.getByTestId('btn-exit-dialog');
    expect(closeBtn).toBeInTheDocument();
    fireEvent.click(closeBtn);
  });
  test('Should open Discounts Modal once user click of View Discounts Modal when scmUpgradeMfeEnable false and readorder flow', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock
    sessionStorage.setItem('readOrder', 'true');
    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails {...{ ...inStorePickupProps, setViewdiscountOpen: jest.fn() }} data={cartJson} />
        </StoreProvider>
      </BrowserRouter>
    );
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('discountsAndPromos');
    fireEvent.click(title);
    const modal = screen.getByTestId('discounts-modal');
    expect(modal).toBeInTheDocument();
    const closeBtn = screen.getByTestId('btn-exit-dialog');
    expect(closeBtn).toBeInTheDocument();
    fireEvent.click(closeBtn);
  });

  test('Should open Discounts Modal once user click of View Discounts Modal when scmUpgradeMfeEnable true and readorder flow', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock
    sessionStorage.setItem('readOrder', 'true');
    window.mfe = { scmUpgradeMfeEnable: true };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails {...{ ...inStorePickupProps, setViewdiscountOpen: jest.fn() }} data={cartJson} />
        </StoreProvider>
      </BrowserRouter>
    );
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('discountsAndPromos');
    fireEvent.click(title);
    const modal = screen.getByTestId('discounts-modal');
    expect(modal).toBeInTheDocument();
    const closeBtn = screen.getByTestId('btn-exit-dialog');
    expect(closeBtn).toBeInTheDocument();
    fireEvent.click(closeBtn);
  });
});

describe('Accessories Read Order Component', () => {
  const mockSaveOrder = jest.fn();
  const mockAddAccessories = jest.fn();
  const mockGetCustomer = jest.fn();

  const mockReadOrderResponse = {
    orderStatus: 'CO',
    cart: {
      cartHeader: {
        status: 'S',
        fullAccountNumber: '0486957317-1',
      },
      orderDetails: {
        orderList: [{ orderNumber: '20331588' }, { orderNumber: '20331589' }],
      },
    },
    lovIndicator: 'YY',
  };

  const inStorePickupProps = {
    setSelectedReviewMode: jest.fn(),
    setSelectedReason: jest.fn(),
    readOrderResponse: mockReadOrderResponse, // added for common testing
  };
  const mockData = {
    getClickToCallDetailsRequest: mockSaveOrder,
    getClickToCallDetailsResult: { data: getClickToCallDetailsJson },
  };

  const mockAddAccessoriesData = {
    addAccessories: mockAddAccessories,
    addAccessoriesSuccess: { data: true },
    getCustomerByMtn: mockGetCustomer,
  };

  const mockAddAppMessage = jest.fn();
  const mockClearAppMessage = jest.fn();

  jest.mock('onevzsoemfecommon/AppMessageActions', () => ({
    addAppMessage: mockAddAppMessage,
    clearAppMessages: mockClearAppMessage,
  }));

  beforeEach(() => {
    window.mfe = { scmDeviceMfeEnable: true, scmCheckoutMfeEnable: true, scmUpgradeMfeEnable: true };
    window.mfe.historyRef = jest.fn();
    window.mfe.historyRef.push = jest.fn();
    const appointmentMockCartJson = {
      data: {
        data: {
          cart: {
            cartHeader: {
              cartCreator: 'creator',
              caseId: 'caseId',
            },
            orderDetails: {
              customerType: 'N',
              spocs: { notificationOptions: { primaryEmailId: 'email@domain.com' } },
              orderList: [{ creditApplication: { creditApplicationNum: '12345' }, orderNumber: '20331589' }],
            },
            lineDetails: {
              lineInfo: [
                {
                  serviceInfo: {
                    cart5GAppointment: {
                      customerInstructions: '',
                      emailAddress: 'SENTHIL.KUMAR.BHOOPALAN@ONE.VERIZON.COM',
                      eventCorrelationId: '60611_1737642957399_182',
                      firstName: 'BRIAN',
                      homePhone: '9089349238',
                      installApptSelectedDate: {
                        availableDate: '20250201',
                        availableDay: '6',
                        availableType: '0',
                        serviceProviderAccount: '1115183',
                        serviceProviderName: 'ASURION INSTALLER',
                        slotLength: '2',
                        slotStartTime: '0800',
                      },
                      lastName: 'WRIGHT',
                      preferredContactType: 'Email',
                      primaryPhoneType: 'Home',
                    },
                  },
                },
              ],
              tradeInDetail: { tradeInItems: [{ id: 'tradeInItem' }] },
            },
            quote: { quoteId: 'quoteId' },
          },
        },
      },
    };

    const mockInfoApiData = {
      getCartRequest: jest.fn(),
      getCartResponse: appointmentMockCartJson,
      submitUserInfo: jest.fn(),

      fetchPricingSnapRequest: jest.fn(),
      getActiveMTNRequest: jest.fn(),
      orderReviewRequest: jest.fn(),
    };
    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => mockInfoApiData);
    getQueryParamByName.mockReturnValue('true');
  });

  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  // new iteam added for read-Order
  test('Should open devicePayment Modal once user click of devicePayment', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            lines={cartJson.data.cart.lineDetails.lineInfo}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            readOrderResponse={{ orderStatus: 'CO' }}
            isFromReadOrder
            readOrderStatus={'CO'}
            isQAFlow={true}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
  });
});
