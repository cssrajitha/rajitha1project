import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import Emitter from 'onevzsoemfeframework/Emitter';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import StoreProvider from '../../modules/store';
import AccessoriesCheckoutDetails from './AccessoriesCheckoutDetails';
import cartJson from '../../__mock__/retrive-cart.json';
import EditAccessories from './EditAccessories';

jest.mock('../../utils/tagging');
jest.mock('onevzsoemfecommon/Helpers', () => ({
  ...jest.requireActual('onevzsoemfecommon/Helpers'),
  getQueryParamByName: jest.fn(),
}));

describe('Edit Accessories Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  beforeEach(() => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails data={cartJson} />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('renders Edit Accessories', async () => {
    await waitFor(() => {
      const editLink = screen.getByTestId('edit-accessories-link');
      expect(editLink).toBeInTheDocument();
      fireEvent.click(editLink);
      setTimeout(() => {
        expect(screen.getByTestId('edit-accessories-title')).toBeInTheDocument();
      }, 3000);
    });
  });

  test('Modal done click', async () => {
    global.window.vzdl = { page: { detail: '' } };
    await waitFor(() => {
      const editLink = screen.getByTestId('edit-accessories-link');
      expect(editLink).toBeInTheDocument();
      fireEvent.click(editLink);
      setTimeout(async () => {
        const DoneBtn = await screen.getByRole('button', { name: 'Done' });
        expect(DoneBtn).toBeInTheDocument();
        fireEvent.click(DoneBtn);
        expect(editLink).toBeInTheDocument();
        expect(window.vzdl.page.detail).toEqual('');
      }, 3000);
    });
  });

  test('button click', async () => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0]?.itemsInfo[0];
    const cartItems = line?.cartItems?.cartItem?.filter((i) => i.quantityAllowed) || [];
    const mtnDetail = cartJson.data.cart.lineDetails?.lineInfo?.[0]?.serviceInfo?.mtn;
    const total = cartJson.data.cart?.orderDetails?.subTotalDueToday;
    const goBackFn = jest.fn();
    global.window.vzdl = { page: { detail: '' } };
    render(
      <BrowserRouter>
        <StoreProvider>
          <EditAccessories closeModal={goBackFn} opened mtn={mtnDetail} cart={cartItems} total={total} />
        </StoreProvider>
      </BrowserRouter>,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    const DoneBtn = screen.getByText(/Done/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
    expect(goBackFn).toHaveBeenCalledTimes(1);
    expect(window.vzdl.page.detail).toEqual('');
  });

  test('Modal Shop Accessories click', async () => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0]?.itemsInfo[0];
    const cartItems = line?.cartItems?.cartItem?.filter((i) => i.quantityAllowed) || [];
    const mtnDetail = cartJson.data.cart.lineDetails?.lineInfo?.[0]?.serviceInfo?.mtn;
    const total = cartJson.data.cart?.orderDetails?.subTotalDueToday;
    const goBackFn = jest.fn();
    global.window.vzdl = { page: { detail: '' } };
    render(
      <BrowserRouter>
        <StoreProvider>
          <EditAccessories closeModal={goBackFn} opened mtn={mtnDetail} cart={cartItems} total={total} />
        </StoreProvider>
      </BrowserRouter>,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    const ShopAccessBtn = screen.getByText(/Shop Accessories/i);
    expect(ShopAccessBtn).toBeInTheDocument();
    fireEvent.click(ShopAccessBtn, {});
    expect(window.vzdl.page.detail).toEqual('Accessories');
  });

  test('Modal Shop Accessories click', async () => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0]?.itemsInfo[0];
    const cartItems = line?.cartItems?.cartItem?.filter((i) => i.quantityAllowed) || [];
    const mtnDetail = cartJson.data.cart.lineDetails?.lineInfo?.[0]?.serviceInfo?.mtn;
    const total = cartJson.data.cart?.orderDetails?.subTotalDueToday;
    const goBackFn = jest.fn();
    global.window.vzdl = { page: { detail: '' } };
    render(
      <BrowserRouter>
        <StoreProvider>
          <EditAccessories closeModal={goBackFn} opened mtn={mtnDetail} isQAFlow cart={cartItems} total={total} />
        </StoreProvider>
      </BrowserRouter>,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    const ShopAccessBtn = screen.getByText(/Shop Accessories/i);
    expect(ShopAccessBtn).toBeInTheDocument();
    fireEvent.click(ShopAccessBtn, {});
  
  });

  test('Modal Shop Accessories title', async () => {
    await waitFor(() => {
      const editLink = screen.getByTestId('edit-accessories-link');
      expect(editLink).toBeInTheDocument();
      fireEvent.click(editLink);
      setTimeout(() => {
        expect(screen.getByTestId('edit-accessories-title')).toBeInTheDocument();
        expect(screen.getByText(/`Accessories for ${mtnDetail} ($${total})`/i));
        expect(screen.getByTestId('item-qty-1')).toBeInTheDocument();
      }, 3000);
    });
  });
});

describe('Edit Accessories Component', () => {
  beforeAll(() => {});

  beforeEach(() => {
    window.mfe = { scmCheckoutMfeEnable: true };
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails data={cartJson} />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('renders Edit Accessories', async () => {
    await waitFor(() => {
      const editLink = screen.getByTestId('edit-accessories-link');
      expect(editLink).toBeInTheDocument();
      fireEvent.click(editLink);
      setTimeout(() => {
        expect(screen.getByTestId('edit-accessories-title')).toBeInTheDocument();
      }, 3000);
    });
  });

  test('Modal done click', async () => {
    global.window.vzdl = { page: { detail: '' } };
    await waitFor(() => {
      const editLink = screen.getByTestId('edit-accessories-link');
      expect(editLink).toBeInTheDocument();
      fireEvent.click(editLink);
      setTimeout(async () => {
        const DoneBtn = await screen.getByRole('button', { name: 'Done' });
        expect(DoneBtn).toBeInTheDocument();
        fireEvent.click(DoneBtn);
        expect(editLink).toBeInTheDocument();
        expect(window.vzdl.page.detail).toEqual('');
      }, 3000);
    });
  });

  test('button click', async () => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0]?.itemsInfo[0];
    const cartItems = line?.cartItems?.cartItem?.filter((i) => i.quantityAllowed) || [];
    const mtnDetail = cartJson.data.cart.lineDetails?.lineInfo?.[0]?.serviceInfo?.mtn;
    const total = cartJson.data.cart?.orderDetails?.subTotalDueToday;
    const goBackFn = jest.fn();
    global.window.vzdl = { page: { detail: '' } };
    render(
      <BrowserRouter>
        <StoreProvider>
          <EditAccessories closeModal={goBackFn} opened mtn={mtnDetail} cart={cartItems} total={total} />
        </StoreProvider>
      </BrowserRouter>,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    const DoneBtn = screen.getByText(/Done/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
    expect(goBackFn).toHaveBeenCalledTimes(1);
    expect(window.vzdl.page.detail).toEqual('');
  });

  test('Modal Shop Accessories click', async () => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0]?.itemsInfo[0];
    const cartItems = line?.cartItems?.cartItem?.filter((i) => i.quantityAllowed) || [];
    const mtnDetail = cartJson.data.cart.lineDetails?.lineInfo?.[0]?.serviceInfo?.mtn;
    const total = cartJson.data.cart?.orderDetails?.subTotalDueToday;
    const goBackFn = jest.fn();
    global.window.vzdl = { page: { detail: '' } };
    render(
      <BrowserRouter>
        <StoreProvider>
          <EditAccessories closeModal={goBackFn} opened mtn={mtnDetail} cart={cartItems} total={total} />
        </StoreProvider>
      </BrowserRouter>,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    const ShopAccessBtn = screen.getByText(/Shop Accessories/i);
    expect(ShopAccessBtn).toBeInTheDocument();
    fireEvent.click(ShopAccessBtn, {});
    Emitter.emit('ACSS_SCM_SWITCH_TAB', { type: 'SWITCH_TAB', targetTab: 'DEVICE_TAB' });
  });

  test('Modal Shop Accessories title', async () => {
    await waitFor(() => {
      const editLink = screen.getByTestId('edit-accessories-link');
      expect(editLink).toBeInTheDocument();
      fireEvent.click(editLink);
      setTimeout(() => {
        expect(screen.getByTestId('edit-accessories-title')).toBeInTheDocument();
        expect(screen.getByText(/`Accessories for ${mtnDetail} ($${total})`/i));
        expect(screen.getByTestId('item-qty-1')).toBeInTheDocument();
      }, 3000);
    });
  });
});

describe('Edit Accessories Component - isQAFlow true', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  beforeEach(() => {
    getQueryParamByName.mockReturnValue('true');
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails data={cartJson} />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('renders Edit Accessories', async () => {
    await waitFor(() => {
      const editLink = screen.getByTestId('edit-accessories-link');
      expect(editLink).toBeInTheDocument();
      fireEvent.click(editLink);
      setTimeout(() => {
        expect(screen.getByTestId('edit-accessories-title')).toBeInTheDocument();
      }, 3000);
    });
  });

  test('Modal done click', async () => {
    global.window.vzdl = { page: { detail: '' } };
    await waitFor(() => {
      const editLink = screen.getByTestId('edit-accessories-link');
      expect(editLink).toBeInTheDocument();
      fireEvent.click(editLink);
      setTimeout(async () => {
        const DoneBtn = await screen.getByRole('button', { name: 'Done' });
        expect(DoneBtn).toBeInTheDocument();
        fireEvent.click(DoneBtn);
        expect(editLink).toBeInTheDocument();
        expect(window.vzdl.page.detail).toEqual('');
      }, 3000);
    });
  });
  
  test('Modal Shop Accessories click', async () => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0]?.itemsInfo[0];
    const cartItems = line?.cartItems?.cartItem?.filter((i) => i.quantityAllowed) || [];
    const mtnDetail = cartJson.data.cart.lineDetails?.lineInfo?.[0]?.serviceInfo?.mtn;
    const total = cartJson.data.cart?.orderDetails?.subTotalDueToday;
    const goBackFn = jest.fn();
    global.window.vzdl = { page: { detail: '' } };
    render(
      <BrowserRouter>
        <StoreProvider>
          <EditAccessories closeModal={goBackFn} opened mtn={mtnDetail} cart={cartItems} total={total} />
        </StoreProvider>
      </BrowserRouter>,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    const ShopAccessBtn = screen.getByText(/Shop Accessories/i);
    expect(ShopAccessBtn).toBeInTheDocument();
    fireEvent.click(ShopAccessBtn, {});
    expect(window.vzdl.page.detail).toEqual('Accessories');
  });
});