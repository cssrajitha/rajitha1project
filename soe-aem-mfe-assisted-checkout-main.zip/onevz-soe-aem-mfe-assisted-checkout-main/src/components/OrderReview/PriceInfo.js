/* eslint-disable no-nested-ternary */
import { TextLink } from '@vds/buttons';
import React, { useEffect, useState } from 'react';
import { Line } from '@vds/lines';
import { Notification } from '@vds/notifications';
import { TileContainer } from '@vds/tiles';
import { Body } from '@vds/typography';
import { Row } from '@vds/grids';
import moment from 'moment';
import { useNavigate } from 'react-router-dom';
import Emitter from 'onevzsoemfeframework/Emitter';
import { formatPhoneNumber, getUIContextPathBAU, getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { propTypes } from 'pdf-viewer-reactjs';
import { useLazyComparePlansQuery } from 'onevzsoemfecommon/PlanAPIService';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { useLazyGetCartDetailsQuery } from '../../modules/services/APIService/APIServiceCallHook';
import CompareToCurrentPlan from './CompareToCurrentPlan';
import ViewPlansModal from './ViewPlansModal';
import EditTradein from './EditTradein';
import PreviewBill from './PreviewBill';
import { PaddingTop16, StyledPaddingLeft8 } from '../../StyledConstants';
import { formatCurrency, formatDateOrdinal } from '../../utils/common';
import GetNextBillSummaryHook from '../../modules/services/APIService/GetNextBillSummary';
import { invokeTagging } from '../../utils/test-utils/utils';
import { tradeInConstants } from '../../appconfig';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR } from '../constants/constants';
import ShippingDetailsModal from './ShippingDetailsModal';
import StoreTradein from './StoreTradein';

const getPadding = ({ noPadding, line }) => {
  if (noPadding) {
    return '0px 14px';
  }
  if (line) {
    return '8px 14px';
  }
  return '8px';
};

const TileWrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  padding: ${(props) => getPadding(props)};
`;
const PriceWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: ${(props) => (props.noBottomMargin ? '0' : '0.25rem')};
  padding: ${(props) => (props.extraMargin ? '8px 0' : '4px 0')};
  border-bottom: ${(props) => (props.line ? '1px solid #ccc' : '')};
  &.clickable {
    cursor: pointer;
  }
  p {
    font-family: BrandFont-Text, Helvetica, Arial, sans-serif;
    font-size: ${(props) => (props.small ? '14px' : '18px')};
    line-height: normal;
  }
`;

const AmountWrapper = styled.div`
  p {
    font-family: BrandFont-Text, Helvetica, Arial, sans-serif;
    font-size: ${(props) => (props.fontSize ? props.fontSize : '18px')};
    line-height: normal;
  }
`;

const getTitleWidth = (props) => {
  if (props.titleWidth) {
    return props.titleWidth;
  }
  if (props.fullwidth) {
    return '100%';
  }
  return '220px';
};

const Title = styled.div`
  font-weight: 700;
  line-height: 1.25rem;
  letter-spacing: 0.03125rem;
  margin: 0px;
  text-decoration: none;
  width: ${(props) => getTitleWidth(props)};
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  font-size: 20px;
  color: rgb(0, 0, 0);
`;

const Value = styled.div`
  font-size: 20px;
  font-weight: 700;
  line-height: 1.25rem;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  letter-spacing: 0.03125rem;
  color: rgb(0, 0, 0);
  margin: 0px;
  text-decoration: none;
`;

const LinkWrapper = styled.div`
  text-align: left;
  padding-bottom: ${(props) => (props.paddingBottom ? props.paddingBottom : '1rem')};
  padding-top: ${(props) => (props.paddingTop ? props.paddingTop : '1rem')};
  padding-left: ${(props) => (props.paddingLeft ? '1rem' : '0')};
`;

const TileContainerWrapper = styled.div`
  [class^='OuterTileContainer'] {
    border-radius: 0px !important;
    height: 100%;
  }
`;

const PreviewLink = styled.div`
  cursor: pointer;
  color: #0077b4;
  text-decoration: underline;
  padding-bottom: 10px;
  margin-bottom: 10px;
`;

const MarginTop16 = styled.div`
  margin-top: 16px;
`;

const Imagewrap = styled.div`
  max-width: 100%;
  height: auto;
  margin-right: 10px;
`;

const ShippingWrapper = styled.div`
  padding: 0 8px;
  [id^='title_'] {
    font-size: 12px;
  }
  [class^='AlertWrapper-'] {
    padding: 14px 7px;
    min-height: 0;
  }
`;

const PriceImageWrapper = styled.div`
  display: flex;
  width: 160px;
  margin-left: 8px;
`;

const BlueText = styled.div`
  color: #0088ce;
  font-family: BrandFontBold, sans-serif;
  font-weight: bold;
  font-size: 16px;
`;
const SubTitle = styled.div`
  font-weight: normal;
  font-size: 18px;
  margin-top: 5px;
`;
const BelowLine = styled.div`
  font-size: 16px;
  font-family: BrandFont-Text, Arial, sans-serif;
`;
const NextLine = styled.div`
  white-space: pre-line;
  margin: 3px;
`;
const PriceInfo = (props) => {
  let navigate = '';
  const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable;
  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;
  const bgColor = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.themeProps?.background;
  const visFeature = props?.line?.serviceInfo?.selectedFeaturesList?.visFeature;
  const selectedPerks =
    Array.isArray(visFeature) &&
    visFeature?.length > 0 &&
    visFeature?.filter((Addone) => Addone?.customerSelected === 'Y' && Addone?.source === 'USER');
  const viewPlanEnable = props?.line?.serviceInfo?.comparePlan ? props?.line.serviceInfo.comparePlan : false;
  const oldPricePlanId = props?.line?.serviceInfo?.oldPricePlanId;
  const newPricePlanId = props?.line?.serviceInfo?.newPricePlanId;

  const isCPC = oldPricePlanId && newPricePlanId;

  const currentPlan = props?.line?.serviceInfo?.pricePlanInfo?.pricePlanCode;
  const selectedPlan = props?.line?.serviceInfo?.newPricePlanInfo?.pricePlanCode;

  const [nbsFFlagState] = getAssistedCradlePropertyV2(['enableFullBlownMfeNbsPosFFlag']);
  const isNbsMfe =
    /true/i.test(nbsFFlagState) ||
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.enableFullBlownMfeNbsPosFFlag === 'TRUE';

  const [isReadOrderMfe] = getAssistedCradlePropertyV2(['readOrderMfeFFlag']);
  const isReadOrderMfeFFlag = /true/i.test(isReadOrderMfe);

  const status = props?.cartDetails?.cartHeader?.status !== 'P' || props?.cartDetails?.cartHeader?.status !== 'C';
  const readOrderStatus = props?.orderStatus === 'CR';
  const orderStatusCR = status && readOrderStatus;
  const priceToViewPlans =
    props?.line?.serviceInfo?.pricePlanInfo?.planPrice || props?.line?.serviceInfo?.newPricePlanInfo?.planPrice;

  const planIds = newPricePlanId || oldPricePlanId || [oldPricePlanId, newPricePlanId];

  function useNavigateMFE() {
    navigate = useNavigate();
  }
  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }
  const showDeviceTradeincredit = props?.deviceCreditinfo?.length > 0;
  const [getCartRequest] = useLazyGetCartDetailsQuery();
  const [getComparePlansRequest, getComparePlanResult] = useLazyComparePlansQuery();
  const [showPreviewBill, setShowPreviewBill] = useState(false);
  const [showTradeinCredit, setTradeinCredit] = useState(false);
  const { getNextBillSummaryReq, getNextBillSummaryRes } = GetNextBillSummaryHook();
  const [deviceInfo, setdeviceInfo] = useState(true);
  const [linkInfo, setlinkInfo] = useState('View');
  const [comparePlan, setComparePlan] = useState(false);
  const [viewPlanModalOpen, setViewPlanModalOpen] = useState(false);
  const [planRefResp, setPlanRefResp] = useState({});
  const scmCheckoutMfeEnabled = window?.mfe?.scmCheckoutMfeEnable;
  const getShippingText = () => {
    let shipText = '';
    const tradeInShippingType = props?.address?.tradeInShippingType;
    const tradeInType = props?.address?.tradeInType;
    if (tradeInShippingType?.toLowerCase() === 'return_store' && tradeInType?.toLowerCase() === 'home') {
      shipText = tradeInConstants.tradeinLater;
    } else if (tradeInShippingType?.toLowerCase() === 'upsdrop-off_qrcode') {
      shipText = tradeInConstants.tradeQRCode;
    } else if (tradeInShippingType?.toLowerCase() === 'prepaidlabel') {
      shipText = tradeInConstants.tradePrepaidLabel;
    } else if (tradeInType?.toLowerCase() === 'home') {
      shipText = tradeInConstants.tradeinhome;
    } else if (props?.address?.tradeInItems?.length > 0) {
      shipText = tradeInConstants.tradeinNow;
    }

    return shipText;
  };
  const tradeinNow = getShippingText();
  const instantCreditEligibleLabel = 'Instant credit eligible';
  const isCLNRFlow = sessionStorage.getItem('isCLNRFlow') || false;
  const intentTypeValue = getQueryParamByName('intentType');

  useEffect(() => {
    if (getNextBillSummaryRes?.data?.nbsVo) {
      const details = {
        PAGE_LOADED: 'true',
        CUSTOM_EVENT: 'Pageview',
      };
      Emitter.emit('PAGE_LOADED', details);
    }
  }, [getNextBillSummaryRes?.data?.nbsVo]);

  const devicePriceInfo = (appliedPrice) => {
    if (appliedPrice > 0) {
      return formatCurrency(`${appliedPrice * -1}`);
    }
    return formatCurrency(`${appliedPrice}`);
  };

  const compareToCurrentRequest = async () => {
    if (selectedPlan && currentPlan) {
      const requestBody = { planIds: [currentPlan, selectedPlan] };
      getComparePlansRequest({ body: requestBody });
    }

    await getCartRequest({
      body: {
        data: {
          cartId: sessionStorage.getItem('cartId') || '',
        },
      },
      mock: false,
    })
      .then((retrieveCartResp) => {
        const currentPlanId =
          props?.line?.serviceInfo?.pricePlanInfo?.pricePlanCode ||
          props?.line?.serviceInfo?.newPricePlanInfo?.pricePlanCode;

        const matchingLine = retrieveCartResp?.data?.data?.cart?.lineDetails?.lineInfo?.find(
          (line) =>
            line?.serviceInfo?.pricePlanInfo?.pricePlanCode === currentPlanId ||
            line?.serviceInfo?.newPricePlanInfo?.pricePlanCode === currentPlanId,
        );

        const comparePlanVal = matchingLine?.serviceInfo?.comparePlan;
        setComparePlan(comparePlanVal);

        setViewPlanModalOpen(!comparePlanVal);
      })
      .catch((error) => {
        console.error('Error:', error);
      });
  };

  const shouldRenderViewPlansModal =
    !isCLNRFlow && intentTypeValue !== '5GHomeRFEX' && intentTypeValue !== '5GHomeRetailREFX' && !comparePlan;

  const shouldRenderCompareToCurrentPlan =
    !isCLNRFlow && intentTypeValue !== '5GHomeRFEX' && intentTypeValue !== '5GHomeRetailREFX' && !viewPlanModalOpen;

  const closeModal = () => {
    setShowPreviewBill(false);
  };

  const [showShippingModel, setShowShippingModel] = useState(false);
  const openShippingModel = () => {
    setShowShippingModel(true);
  };
  const closeShippingModel = () => {
    setShowShippingModel(false);
  };

  const openNextBillModel = () => {
    const isTGWSelected =
      props?.cartDetails?.lineDetails?.lineInfo?.find((line) => line?.tanglewoodSelected === 'Y')
        ?.tanglewoodSelected === 'Y';
    if (!isNbsMfe) {
      // Suppressing the bau nbs call when opening the model for unifiednbs mfe, since mfe makes independent call to unifiednbs service
      if (isTGWSelected) {
        getNextBillSummaryReq({
          body: { nseFlow: true, unifiedNbsFlag: false, enableVzdlFlow: true, tanglewoodQualified: true },
          spinner: false,
        });
      } else {
        getNextBillSummaryReq({ body: { nseFlow: true, unifiedNbsFlag: false, enableVzdlFlow: true }, spinner: false });
      }
    }
    invokeTagging('openView', 'Show NextBillSummary');
    setShowPreviewBill(true);
  };

  const closeModalPopup = () => {
    setTradeinCredit(false);
  };

  const handleRemove = () => {
    setdeviceInfo(false);
    setlinkInfo('Add');
  };

  const handleLinkclick = (e) => {
    e.preventDefault();
    if (isReadOrderMfeFFlag && props?.readOrder === true) {
      if (e.target.innerText === 'View') {
        setTradeinCredit(true);
        invokeTagging('openView', 'deviceTradeIn');
      } else if (!scmCheckoutMfeEnabled) {
        navigate(`${getUIContextPathBAU()}/landing.html`);
      } else {
        window?.mfe?.historyRef.push(`${getUIContextPathBAU()}/landing.html`);
      }
    } else {
      // eslint-disable-next-line no-lonely-if
      if (linkInfo === 'View') {
        setTradeinCredit(true);
      } else if (!scmCheckoutMfeEnabled) {
        navigate(`${getUIContextPathBAU()}/landing.html`);
      } else {
        window?.mfe?.historyRef.push(`${getUIContextPathBAU()}/landing.html`);
      }
    }
  };

  const handleEditShippingClick = () => {
    if (props?.isQAFlow) {
      window.location.href = `/sales/assisted/new/shipping-details.html?isQAFlow=true`;
    } else if (scmUpgradeMfeEnable) {
      if (props?.onLinkClick) {
        props?.onLinkClick();
      } else {
        openShippingModel();
      }
    } else if (props?.onLinkClick) {
      props?.onLinkClick();
    } else {
      window.location.href = `/sales/assisted/new/shipping-details.html`;
    }
  };

  const getCamelCaseName = (text) =>
    text
      ?.toLowerCase()
      .split(' ')
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');

  const getFilteredData = (lineData, isQAPreBackOrder = false) =>
    lineData.filter(
      ({ itemsInfo, lineActivityType }) =>
        itemsInfo &&
        itemsInfo.some(
          ({ shipping: { shippingCode } = {}, cartItems: { cartItem = [] } = {} }) =>
            ((shippingCode && shippingCode.trim() !== '') || isQAPreBackOrder) &&
            (!(
              (lineActivityType === 'EUPBYOD' || lineActivityType === 'BYOD') &&
              cartItem.some(({ isCustomerProvidedSIM }) => isCustomerProvidedSIM)
            ) ||
              ((lineActivityType === 'EUPBYOD' || lineActivityType === 'BYOD') &&
                cartItem.some(({ cartItemType }) => cartItemType === 'ACCESSORY'))),
        ),
    );
  const getUniqueShippingAddress = (lineInfoData) => {
    const uniqueAddress = lineInfoData.map(
      ({
        itemsInfo: [
          {
            shipping: {
              address: {
                preferFirstName,
                preferLastName,
                firstName,
                lastName,
                firmName,
                apartmentNo,
                aptNum,
                streetName,
                streetNumber,
                streetType,
                streetDirection,
                type,
                city,
                state,
                zipCode,
                phoneNumber,
                addressLine1,
                addressLine2,
                attention,
              },
              shippingDescription = '',
            },
          },
        ],
      }) =>
        JSON.stringify({
          address: {
            preferFirstName,
            preferLastName,
            firstName,
            lastName,
            firmName,
            apartmentNo,
            aptNum,
            streetName,
            streetNumber,
            streetType,
            streetDirection,
            type,
            city,
            state,
            zipCode,
            phoneNumber,
            addressLine1,
            addressLine2,
            attention,
          },
          shippingDescription,
        }),
    );
    const unqAddress = [...new Set(uniqueAddress)];
    return unqAddress;
  };

  const getMobileNumbersForAddress = (address, lineInfoData) => {
    const numbersAndImages = [];
    lineInfoData
      .map(
        ({
          mobileNumber,
          itemsInfo: [
            {
              shipping: {
                address: {
                  firstName,
                  lastName,
                  firmName,
                  apartmentNo,
                  aptNum,
                  streetName,
                  streetNumber,
                  streetType,
                  streetDirection,
                  type,
                  city,
                  state,
                  zipCode,
                  phoneNumber,
                  addressLine1,
                  addressLine2,
                  attention,
                },
                shippingDescription = '',
              },
              cartItems: {
                cartItem: [{ imageUrlMap }],
              },
            },
          ],
        }) => ({
          address: {
            firstName,
            lastName,
            firmName,
            apartmentNo,
            aptNum,
            streetName,
            streetNumber,
            streetType,
            streetDirection,
            type,
            city,
            state,
            zipCode,
            phoneNumber,
            addressLine1,
            addressLine2,
            attention,
          },
          shippingDescription,
          miniImage: (imageUrlMap && imageUrlMap.miniImage) || '',
          mobileNumber,
        }),
      )
      .forEach((tmpAdd) => {
        if (
          JSON.stringify(tmpAdd.address) === JSON.stringify(address) &&
          !numbersAndImages.some((someNumbers) => someNumbers.mobileNumber === tmpAdd.mobileNumber)
        ) {
          numbersAndImages.push({
            mobileNumber: tmpAdd.mobileNumber,
            miniImage: tmpAdd.miniImage,
            shippingDescription: tmpAdd.shippingDescription,
          });
        }
      });
    return numbersAndImages;
  };
  const multipleShippingAddress = () => {
    const isQAPreBackOrder = props?.isQAFlow && props.cartDetails?.lineDetails?.lineInfo?.[0]?.preOrBackOrder;
    const preBackItem =
      isQAPreBackOrder &&
      props.cartDetails?.lineDetails?.lineInfo?.[0]?.itemsInfo?.[0]?.cartItems?.cartItem?.find(
        (item) => item.preBackDate
      );
    const preBackDisplayDate = preBackItem?.preBackDate || '';
    const lineInfoData = getFilteredData(props.cartDetails.lineDetails.lineInfo, isQAPreBackOrder);
    return getUniqueShippingAddress(lineInfoData)?.map((uniqueAddress, index, arr) => {
      const { address, shippingDescription } = JSON.parse(uniqueAddress);
      const numbersAndImages = arr.length > 1 && getMobileNumbersForAddress(address, lineInfoData);
      return (
        <>
          <PaddingTop16 />
          {arr.length > 1 &&
            numbersAndImages.map(
              (currNumberAndImage) =>
                currNumberAndImage.shippingDescription === shippingDescription && (
                  <div key={currNumberAndImage}>
                    <img style={{ width: '31px', height: '44px' }} src={currNumberAndImage.miniImage} alt='Device' />
                    <div style={{ 'font-size': '9px' }}>
                      {currNumberAndImage.mobileNumber ? formatPhoneNumber(currNumberAndImage.mobileNumber) : ''}
                    </div>
                  </div>
                )
            )}
          <Body size='medium' color={isDark ? DARK_THEME_COLOR : ''}>
            {address?.firstName} {address?.lastName}
          </Body>
          <Body size='medium' color={isDark ? DARK_THEME_COLOR : ''}>
            {address?.addressLine1}
          </Body>
          <PaddingTop16 />
          <Body size='medium' color={isDark ? DARK_THEME_COLOR : ''}>
            {address?.city && getCamelCaseName(address?.city)} {address?.state} {address?.zipCode}
          </Body>
          <Body size='medium' color={isDark ? DARK_THEME_COLOR : ''}>
            {address.phoneNumber && formatPhoneNumber(address.phoneNumber)}
          </Body>
          <PaddingTop16 />
          <Body size='medium' color={isDark ? DARK_THEME_COLOR : ''}>
            {shippingDescription}
          </Body>
          <PaddingTop16 />
          {preBackDisplayDate && (
            <>
              <Body size='medium' color={isDark ? DARK_THEME_COLOR : ''} bold>
                For Preorder/Backorder item:
              </Body>
              <Body size='medium' color={isDark ? DARK_THEME_COLOR : ''}>
                {`Estimated Ship Date: ${formatDateOrdinal(new Date(moment(preBackDisplayDate).format('MM/DD/YYYY')))}`}
              </Body>
              <PaddingTop16 />
            </>
          )}
          {lineInfoData.length !== index && <Line type='secondary' surface={isDark ? 'dark' : 'light'} />}
        </>
      );
    });
  };

  const serviceInstallAddress = () => (
    <>
      <PaddingTop16 />
      <Body size='medium' color={isDark ? DARK_THEME_COLOR : ''}>
        {props?.shippingDetails?.address?.addressLine1}
      </Body>
      <Body size='medium' color={isDark ? DARK_THEME_COLOR : ''}>
        {props?.shippingDetails?.addressUnit}
      </Body>
      <PaddingTop16 />
      <Body size='medium' color={isDark ? DARK_THEME_COLOR : ''}>
        {props?.shippingDetails?.address?.city && getCamelCaseName(props?.shippingDetails?.address?.city)}{' '}
        {props?.shippingDetails?.address?.state} {props?.shippingDetails?.address?.zipCode}
      </Body>
      <Body size='medium' color={isDark ? DARK_THEME_COLOR : ''}>
        {formatPhoneNumber(props?.shippingDetails?.address?.phoneNumber)}
      </Body>
      <PaddingTop16 />
    </>
  );
  return (
    <TileContainerWrapper>
      <TileContainer
        padding={props?.padding ? props?.padding : '1.5rem 0 0 0'}
        height='auto'
        width='384px'
        backgroundColor={props?.bgColor}
        surface={isDark ? 'dark' : 'light'}
      >
        <TileWrapper
          id={props.id}
          line={props.line}
          noPadding={props.id === 'perks' || props.id === 'device'}
          style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR, backgroundColor: isDark ? bgColor : '' }}
        >
          <BlueText>
            {showDeviceTradeincredit && deviceInfo && props?.title === 'Device trade-in credit' ? tradeinNow : ''}
            <NextLine
              style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR, backgroundColor: isDark ? bgColor : '' }}
            >
              {showDeviceTradeincredit &&
              deviceInfo &&
              props?.title === 'Device trade-in credit' &&
              props?.address?.instantCreditEligible
                ? instantCreditEligibleLabel
                : ''}
            </NextLine>
            {showDeviceTradeincredit &&
              deviceInfo &&
              props?.title === 'Device trade-in credit' &&
              props?.address?.instantCreditEligible && <PaddingTop16 />}
          </BlueText>
          <PriceWrapper
            id={props.id}
            line={props.line}
            noBottomMargin={props.id === 'perks'}
            style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR, backgroundColor: isDark ? bgColor : '' }}
          >
            {!props?.deviceCreditinfo && (
              <Title
                fullwidth
                id={props.id}
                titleWidth={props.titleWidth}
                style={{
                  color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                  backgroundColor: isDark ? bgColor : '',
                }}
              >
                {props?.title}
                <br />
                {props?.subtitle && (
                  <SubTitle
                    style={{
                      color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                      backgroundColor: isDark ? bgColor : '',
                    }}
                  >
                    {props?.subtitle}
                  </SubTitle>
                )}
              </Title>
            )}
            <Value
              style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR, backgroundColor: isDark ? bgColor : '' }}
            >
              {props?.title !== 'Device trade-in credit' ? props?.price : ''}
              {props.readOrder &&
                isReadOrderMfeFFlag &&
                props?.title === 'Device trade-in credit' &&
                !showDeviceTradeincredit &&
                `$0.00`}
            </Value>
          </PriceWrapper>
          {props?.title === 'Device trade-in credit' && deviceInfo ? (
            <div>
              {props?.deviceCreditinfo &&
                Array.isArray(props?.deviceCreditinfo) &&
                props?.deviceCreditinfo?.map((item) => (
                  <>
                    <PriceWrapper key={item} id={props.id} line={props.line} noBottomMargin={props.id === 'perks'}>
                      <Title
                        fullwidth
                        id={props.id}
                        titleWidth={props.titleWidth}
                        style={{
                          color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                          backgroundColor: isDark ? bgColor : '',
                        }}
                      >
                        {props?.title}
                      </Title>
                      <Value
                        style={{
                          color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                          backgroundColor: isDark ? bgColor : '',
                        }}
                      >
                        {devicePriceInfo(item?.appliedPrice)}
                      </Value>
                    </PriceWrapper>
                    <BelowLine>({item?.equipCategory})</BelowLine>
                    <PaddingTop16 />
                  </>
                ))}
            </div>
          ) : (
            ''
          )}
          {props?.info?.map((pay) => (
            <PriceWrapper
              key={pay.payment}
              small={pay?.image}
              extraMargin={!!pay?.image && props.id !== 'plan'}
              className={pay.handleClick ? 'clickable' : ''}
              onClick={pay.handleClick || ''}
              noBottomMargin={props.id === 'plan'}
              style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR, backgroundColor: isDark ? bgColor : '' }}
            >
              <PriceImageWrapper
                style={{
                  color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                  backgroundColor: isDark ? bgColor : '',
                }}
              >
                {pay?.image && (
                  <Imagewrap>
                    <img src={pay?.image} alt='Network icon' />
                  </Imagewrap>
                )}
                <AmountWrapper
                  fontSize={pay?.style?.labelFont}
                  style={{
                    color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                    backgroundColor: isDark ? bgColor : '',
                  }}
                >
                  <Row>
                    <Body size='small' color={isDark ? DARK_THEME_COLOR : ''}>
                      {pay.payment}
                    </Body>
                    {isReadOrderMfeFFlag && props?.readOrder && pay?.description && (
                      <Body size='small' color='#747676'>
                        {pay?.description}
                      </Body>
                    )}
                  </Row>
                </AmountWrapper>
              </PriceImageWrapper>
              <StyledPaddingLeft8>
                <AmountWrapper
                  fontSize={pay?.style?.valueFont}
                  style={{
                    color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                    backgroundColor: isDark ? bgColor : '',
                  }}
                >
                  <Body size='small' color={isDark ? DARK_THEME_COLOR : ''}>
                    {props?.hideMonthly ? pay.price : `${pay.price}/mo*`}
                  </Body>
                </AmountWrapper>
              </StyledPaddingLeft8>
            </PriceWrapper>
          ))}
          {props?.shippingAddress ? (
            <>
              <ShippingWrapper
                style={{
                  color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                  backgroundColor: isDark ? bgColor : '',
                }}
              >
                <PaddingTop16 />
                <Notification
                  type='warning'
                  title='Please review addresses for any errors.'
                  fullBleed={false}
                  inline={false}
                  disableFocus
                  layout='horizontal'
                  hideCloseButton
                  surface={isDark ? 'dark' : 'light'}
                />
                {props?.cartDetails?.lineDetails?.lineInfo && multipleShippingAddress()}
                {props?.shippingDetails && serviceInstallAddress()}
              </ShippingWrapper>
              <Line type='secondary' surface={isDark ? 'dark' : 'light'} />
            </>
          ) : (
            ''
          )}
          {isReadOrderMfeFFlag &&
          props?.readOrder === true &&
          props?.linkName === 'ViewTrade' &&
          props?.title === 'Device trade-in credit' ? (
            showDeviceTradeincredit ? (
              <PriceWrapper
                paddingTop='12px'
                paddingBottom='12px'
                style={{
                  color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                  backgroundColor: isDark ? bgColor : '',
                }}
              >
                <TextLink
                  type='standAlone'
                  surface={isDark ? 'dark' : 'light'}
                  disabled={false}
                  size='small'
                  data-testId='viewLink'
                  onClick={(e) => handleLinkclick(e)}
                >
                  View
                </TextLink>
              </PriceWrapper>
            ) : orderStatusCR ? (
              <PriceWrapper
                paddingTop='12px'
                paddingBottom='12px'
                style={{
                  color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                  backgroundColor: isDark ? bgColor : '',
                }}
              >
                <TextLink
                  type='standAlone'
                  surface={isDark ? 'dark' : 'light'}
                  disabled={false}
                  size='small'
                  data-testId='addLink'
                  onClick={(e) => handleLinkclick(e)}
                >
                  Add
                </TextLink>
              </PriceWrapper>
            ) : (
              ''
            )
          ) : (
            <>
              {!props.readOrder &&
                props?.linkName &&
                props?.linkName !== 'ViewPlans' &&
                props?.linkName !== 'Preview your next bill' && (
                  <LinkWrapper
                    paddingLeft={props?.shippingAddress}
                    paddingTop='12px'
                    paddingBottom='12px'
                    style={{
                      color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                      backgroundColor: isDark ? bgColor : '',
                    }}
                  >
                    <TextLink
                      type='standAlone'
                      surface={isDark ? 'dark' : 'light'}
                      disabled={false}
                      size='small'
                      data-testId={props.linkTestId || 'link'}
                      onClick={handleEditShippingClick}
                    >
                      {!showDeviceTradeincredit && props?.linkName}
                    </TextLink>
                  </LinkWrapper>
                )}
              {showDeviceTradeincredit ? (
                <LinkWrapper>
                  <TextLink
                    type='standAlone'
                    data-testId='link'
                    surface={isDark ? 'dark' : 'light'}
                    disabled={false}
                    size='small'
                    onClick={handleLinkclick}
                  >
                    {linkInfo}
                  </TextLink>
                </LinkWrapper>
              ) : (
                ''
              )}
            </>
          )}
          {props?.linkName === 'Preview your next bill' ? (
            <LinkWrapper
              paddingTop='0px'
              paddingBottom='0px'
              style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR, backgroundColor: isDark ? bgColor : '' }}
            >
              <Title
                size='medium'
                style={{
                  color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                  backgroundColor: isDark ? bgColor : '',
                }}
              >
                <MarginTop16>
                  <PreviewLink>
                    <TextLink data-track='NextBillSummary' onClick={() => openNextBillModel()}>
                      {props?.linkName}
                    </TextLink>
                  </PreviewLink>
                </MarginTop16>
              </Title>
            </LinkWrapper>
          ) : (
            ''
          )}
          {props.readOrder && isReadOrderMfeFFlag && props?.title === 'Store drop-off point for Trade-in'
            ? Object.keys(props.cartTradeinDetails).length > 0 && (
                <StoreTradein cartDetails={props.cartTradeinDetails} />
              )
            : ''}
          <PreviewBill
            billData={getNextBillSummaryRes?.data?.nbsVo}
            opened={showPreviewBill}
            cartInfo={props?.cartDetails}
            closeModal={closeModal}
            isNbsMfe={isNbsMfe}
            fetchUnifiedNbsData={props?.fetchUnifiedNbsData}
          />
          {scmUpgradeMfeEnable && showShippingModel && <ShippingDetailsModal opened closeModal={closeShippingModel} />}
          {shouldRenderViewPlansModal && (
            <ViewPlansModal
              opened={viewPlanModalOpen}
              planId={planIds}
              setPlanRefResp={setPlanRefResp}
              planRefResp={planRefResp}
              setViewPlansModal={setViewPlanModalOpen}
              mtn={props?.mtn}
              price={formatCurrency(priceToViewPlans)}
              orderStatusCR={orderStatusCR}
              isCPC={isCPC}
            />
          )}
          {shouldRenderCompareToCurrentPlan && (
            <>
              <CompareToCurrentPlan
                displayName={props?.line?.serviceInfo?.primaryUserInfo?.firstName}
                mtn={props?.mtn}
                modelName={
                  isReadOrderMfeFFlag && props?.readOrder
                    ? props?.line?.serviceInfo?.existingDevice?.displayName
                    : props?.line?.serviceInfo?.currentDevice?.oldLteVoraEquipInfo?.lteVoraDeviceInfo?.description
                }
                selectedPlanName={props?.line?.serviceInfo?.newPricePlanInfo?.pricePlanDisplayName}
                compareCurrentReq={[
                  props?.line?.serviceInfo?.pricePlanInfo?.pricePlanCode,
                  props?.line?.serviceInfo?.newPricePlanInfo?.pricePlanCode,
                ]}
                label='OrderReview'
                currentPlanDisplayName={props?.line?.serviceInfo?.pricePlanInfo?.pricePlanDisplayName}
                CurrentPlanCost={props?.line?.serviceInfo?.pricePlanInfo}
                selectedPlanCost={props?.line?.totalPriceOfPlanAndPerks}
                selectedPerks={selectedPerks}
                viewPlanEnable={viewPlanEnable || props?.title === 'Plan'}
                propositionName=''
                isDark={isDark}
                ComparePlanAPIResponse={getComparePlanResult.data}
                compareToCurrentRequest={compareToCurrentRequest}
                lineType={props?.lineType}
              />
              <EditTradein
                popupInfo={props?.deviceCreditinfo}
                addressPopup={props?.address}
                opened={showTradeinCredit}
                cartInfo={props?.cartDetails}
                closeModal={closeModalPopup}
                onRemove={handleRemove}
              />
            </>
          )}
        </TileWrapper>
      </TileContainer>
    </TileContainerWrapper>
  );
};

PriceInfo.propTypes = {
  bgColor: PropTypes.string,
  title: PropTypes.string,
  subtitle: PropTypes.string,
  price: PropTypes.string,
  info: PropTypes.array,
  shippingAddress: PropTypes.bool,
  linkName: PropTypes.string,
  onLinkClick: PropTypes.func,
  id: PropTypes.string,
  linkTestId: PropTypes.string,
  mtn: PropTypes.string,
  line: PropTypes.bool,
  padding: PropTypes.string,
  hideMonthly: PropTypes.string,
  titleWidth: PropTypes.string,
  deviceCreditinfo: propTypes.array,
  address: propTypes.object,
  cartDetails: propTypes.any,
  shippingDetails: PropTypes.any,
  fetchUnifiedNbsData: PropTypes.string,
  readOrder: PropTypes.bool,
  cartTradeinDetails: PropTypes.any,
  orderStatus: PropTypes.string,
  isQAFlow: PropTypes.bool,
  lineType: PropTypes.array,
};

PriceInfo.defaultProps = {
  id: '',
  line: false,
};

export default PriceInfo;
