import * as React from 'react';
import { render, screen, fireEvent, waitFor, act } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { isFunctionalityEnabled } from 'onevzsoemfecommon/Helpers/common_functions';
import { setUserAgentIPad } from '../../utils/test-utils/utils';
import ManualDiscountView from './ManualDiscountView';
import StoreProvider from '../../modules/store';
import customerJson from '../../__mock__/retrieve-customer.json';
import cartJson from '../../__mock__/retrive-cart.json';
import mockManualDiscountJson from '../../__mock__/get-manual-discount.json';
import mockManualDiscountJWithDiscountJson from '../../__mock__/get-manual-discount-with-disc.json';
import mockUpdateBarCodeJson from '../../__mock__/updateBarCode.json';
import mockUpdateManualDiscountJson from '../../__mock__/updateManualDiscount.json';
import {
  useLazyGetManualDiscountQuery,
  useLazyGetValidateCartAndCheckoutQuery,
  useLazyUpdateBarcodeQuery,
  useLazyUpdateManualDiscountQuery,
} from '../../modules/services/APIService/APIServiceHooks';

jest.mock('@vds/loaders', () => ({
  Loader: () => <div>VDS LOADER</div>,
  __esModule: true,
  default: () => <div>VDS LOADER</div>,
}));

jest.mock('onevzsoemfecommon/ManagerApprovalView', () => ({
  __esModule: true,
  default: ({ handleBack, handleClose }) => (
    <div>
      <button type='button' data-testid='manager-approval-view-back' onClick={handleBack}>
        back
      </button>
      <button type='button' data-testid='manager-approval-view-close' onClick={handleClose}>
        close
      </button>
    </div>
  ),
}));

jest.mock('onevzsoemfeframework/AssistedCradleService', () => ({
  __esModule: true,
  ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
  getAssistedCradlePropertyV2: jest.fn(), // Ensure it's a Jest mock function
}));

jest.mock('onevzsoemfecommon/Helpers/common_functions', () => ({
  __esModule: true,
  ...jest.requireActual('onevzsoemfecommon/Helpers/common_functions'),
  isFunctionalityEnabled: jest.fn(),
}));

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  __esModule: true,
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
  useLazyGetManualDiscountQuery: jest.fn(),
  useLazyUpdateManualDiscountQuery: jest.fn(),
  useLazyGetValidateCartAndCheckoutQuery: jest.fn(),
  useLazyUpdateBarcodeQuery: jest.fn(),
}));

const mockDataUpdater = (
  getManualDiscountMock,
  updateManualDiscountMock,
  getValidateCartAndCheckoutMock,
  updateBarcodeMock,
) => {
  useLazyGetManualDiscountQuery.mockReturnValue([
    jest.fn(),
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: getManualDiscountMock,
    },
  ]);

  useLazyUpdateManualDiscountQuery.mockReturnValue([
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: updateManualDiscountMock,
    },
  ]);

  useLazyGetValidateCartAndCheckoutQuery.mockReturnValue([
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: getValidateCartAndCheckoutMock,
    },
  ]);

  useLazyUpdateBarcodeQuery.mockReturnValue([
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: updateBarcodeMock,
    },
  ]);
};

const mockDataUpdaterReject = (
  getManualDiscountMock,
  updateManualDiscountMock,
  getValidateCartAndCheckoutMock,
  updateBarcodeMock,
) => {
  useLazyGetManualDiscountQuery.mockReturnValue([
    jest.fn(),
    {
      status: 'rejected',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: getManualDiscountMock,
    },
  ]);

  useLazyUpdateManualDiscountQuery.mockReturnValue([
    () => {},
    {
      status: 'rejected',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: updateManualDiscountMock,
    },
  ]);

  useLazyGetValidateCartAndCheckoutQuery.mockReturnValue([
    () => {},
    {
      status: 'rejected',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: getValidateCartAndCheckoutMock,
    },
  ]);

  useLazyUpdateBarcodeQuery.mockReturnValue([
    () => {},
    {
      status: 'rejected',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: updateBarcodeMock,
    },
  ]);
};

const mockDataUpdaterPending = (
  getManualDiscountMock,
  updateManualDiscountMock,
  getValidateCartAndCheckoutMock,
  updateBarcodeMock,
) => {
  useLazyGetManualDiscountQuery.mockReturnValue([
    jest.fn(),
    {
      status: 'pending',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: getManualDiscountMock,
    },
  ]);

  useLazyUpdateManualDiscountQuery.mockReturnValue([
    () => {},
    {
      status: 'pending',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: updateManualDiscountMock,
    },
  ]);

  useLazyGetValidateCartAndCheckoutQuery.mockReturnValue([
    () => {},
    {
      status: 'pending',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: getValidateCartAndCheckoutMock,
    },
  ]);

  useLazyUpdateBarcodeQuery.mockReturnValue([
    () => {},
    {
      status: 'pending',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: updateBarcodeMock,
    },
  ]);
};

describe('ManualDiscountView Component with Existing discount', () => {
  sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ positionFFlag: 'TRUE' }));
  sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ paddingFFlag: 'TRUE' }));
  test('renders ManualDiscount View - Manager viewback button check', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

    const handleClose = jest.fn();
    mockDataUpdater(
      mockManualDiscountJWithDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateBarCodeJson,
    );

    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView handleClose={handleClose} cart={cartJson.data.cart} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const managerApprovalViewBack = screen.getByTestId('manager-approval-view-back');
    expect(managerApprovalViewBack).toBeInTheDocument();
    fireEvent.click(managerApprovalViewBack);
  });

  test('renders ManualDiscount View - Manager viewback button check', () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ positionFFlag: 'FALSE' }));
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ paddingFFlag: 'FALSE' }));
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']);
    const handleClose = jest.fn();
    mockDataUpdater(
      mockManualDiscountJWithDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateBarCodeJson,
    );

    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView handleClose={handleClose} cart={cartJson.data.cart} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const managerApprovalViewBack = screen.getByTestId('manager-approval-view-back');
    expect(managerApprovalViewBack).toBeInTheDocument();
    fireEvent.click(managerApprovalViewBack);
  });

  test('renders ManualDiscount View - Manager view close button check', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

    const handleClose = jest.fn();
    mockDataUpdater(
      mockManualDiscountJWithDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateBarCodeJson,
    );

    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView handleClose={handleClose} cart={cartJson.data.cart} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const managerCloseBtn = await screen.findByTestId('manager-approval-view-close');
    expect(managerCloseBtn).toBeInTheDocument();
    fireEvent.click(managerCloseBtn);
  });
});

describe('ManualDiscountView Component', () => {
  sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ positionFFlag: 'TRUE' }));
  const doneClicked = true;
  let setShowManagerApprovalMock;
  beforeAll(() => {
    global.window = Object.create(window);
    setShowManagerApprovalMock = jest.fn();
  });
  beforeEach(() => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);
    global.window.mfe = {
      scmUpgradeMfeEnable: true,
      isDark: true,
      themeProps: {
        background: '#000000',
      },
    };
    jest.clearAllMocks();
  });
  afterAll(() => {
    global.window.mfe.scmUpgradeMfeEnable = false;
  });
  test('renders ManualDiscount View', () => {
    const handleClose = jest.fn();
    mockDataUpdater(
      mockManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateBarCodeJson,
    );
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView handleClose={handleClose} cart={cartJson.data.cart} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const managerApprovalViewBack = screen.getByTestId('manager-approval-view-back');
    expect(managerApprovalViewBack).toBeInTheDocument();
    fireEvent.click(managerApprovalViewBack);

    const titleElement = screen.getByTestId('manualDiscountView');
    expect(titleElement).toBeInTheDocument();
  });
  test('opens add promo code screen', () => {
    const handleClose = jest.fn();
    mockDataUpdater(
      mockManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateBarCodeJson,
    );
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView handleClose={handleClose} cart={cartJson.data.cart} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const managerApprovalViewBack = screen.getByTestId('manager-approval-view-back');
    expect(managerApprovalViewBack).toBeInTheDocument();
    fireEvent.click(managerApprovalViewBack);

    const titleElement = screen.getByTestId('manualDiscountView');
    expect(titleElement).toBeInTheDocument();
    const addPromoBtn = screen.getByTestId('handleAddCoupon-button');
    expect(addPromoBtn).toBeInTheDocument();
    fireEvent.click(addPromoBtn, {});
    const addPromoInput = screen.getByRole('textbox');
    expect(addPromoInput).toBeInTheDocument();
    fireEvent.change(addPromoInput, { target: { value: 'HHH' } });
    const scanBarBtn = screen.getByTestId('scanBarBtn');
    expect(scanBarBtn).toBeInTheDocument();
    fireEvent.click(scanBarBtn, { dataset: { barcode: 147852 } });
    const submitPromoBtn = screen.getByTestId('handlePromoSubmit-button');
    expect(submitPromoBtn).toBeInTheDocument();
    fireEvent.click(submitPromoBtn, {});
  });
  test('Done btn click', async () => {
    const handleClose = jest.fn();
    mockDataUpdater(
      mockManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateBarCodeJson,
    );
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView
            handleClose={handleClose}
            cart={cartJson.data.cart}
            customer={customerJson.data.customer}
            doneClicked={doneClicked}
            setShowManagerApproval={setShowManagerApprovalMock}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const managerApprovalViewBack = screen.getByTestId('manager-approval-view-back');
    expect(managerApprovalViewBack).toBeInTheDocument();
    fireEvent.click(managerApprovalViewBack);

    const titleElement = screen.getByTestId('manualDiscountView');
    expect(titleElement).toBeInTheDocument();
    const dicountInput = await waitFor(() => screen.findByTestId('discount-input'), { timeout: 3000 });
    expect(dicountInput).toBeInTheDocument();
    const discOptDollar = screen.getByTestId('dollar-discount');
    const discOptPercent = screen.getByTestId('percent-discount');
    expect(discOptPercent).toBeInTheDocument();

    fireEvent.change(dicountInput, { target: { value: 35 } });

    fireEvent.click(discOptDollar);
    fireEvent.blur(dicountInput, { target: { value: 35 } });

    fireEvent.change(dicountInput, { target: { value: 2000 } });

    fireEvent.change(dicountInput, { target: { value: 35 } });
    const reasonDD = screen.getByTestId('reason-dropdown');
    expect(reasonDD).toBeInTheDocument();
    fireEvent.change(reasonDD, { target: { value: 1 } });
    const handleDPDonebtn = screen.getByTestId('handleDPDone-button');
    expect(handleDPDonebtn).toBeInTheDocument();
    fireEvent.click(handleDPDonebtn);
  });

  test('Done btn click', async () => {
    mockDataUpdater(
      mockManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateBarCodeJson,
    );
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView
            handleClose={jest.fn()}
            cart={cartJson.data.cart}
            customer={customerJson.data.customer}
            doneClicked={doneClicked}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const managerApprovalViewBack = screen.getByTestId('manager-approval-view-back');
    expect(managerApprovalViewBack).toBeInTheDocument();
    fireEvent.click(managerApprovalViewBack);

    const titleElement = screen.getByTestId('manualDiscountView');
    expect(titleElement).toBeInTheDocument();
    const discOptDollar = screen.getByTestId('dollar-discount');
    const discOptPercent = screen.getByTestId('percent-discount');
    expect(discOptPercent).toBeInTheDocument();
    fireEvent.click(discOptDollar);
    const dicountInput = screen.getByTestId('discount-input');
    expect(dicountInput).toBeInTheDocument();
    fireEvent.blur(dicountInput, { target: { value: 10 } });

    fireEvent.change(dicountInput, { target: { value: 100 } });
    fireEvent.change(dicountInput, { target: { value: 2000 } });

    fireEvent.change(dicountInput, { target: { value: 10 } });
    const reasonDD = screen.getByTestId('reason-dropdown');
    expect(reasonDD).toBeInTheDocument();
    fireEvent.change(reasonDD, { target: { value: 1 } });
    const handleDPDonebtn = screen.getByTestId('handleDPDone-button');
    expect(handleDPDonebtn).toBeInTheDocument();
    fireEvent.click(handleDPDonebtn);
  });

  test('Done btn click for NSEQA flow', async () => {
    mockDataUpdater(
      mockManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateBarCodeJson,
    );
    const nseQACart = JSON.parse(JSON.stringify(cartJson));
    nseQACart.data.cart.cartHeader.cartCreator = '';
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView
            handleClose={jest.fn()}
            cart={nseQACart.data.cart}
            customer={customerJson.data.customer}
            doneClicked={doneClicked}
            isQAFlow
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByTestId('manualDiscountView');
    expect(titleElement).toBeInTheDocument();
    const discOptDollar = await waitFor(() => screen.findByTestId('dollar-discount'), { timeout: 3000 });
    const discOptPercent = screen.getByTestId('percent-discount');
    expect(discOptPercent).toBeInTheDocument();
    fireEvent.click(discOptDollar);
    const dicountInput = screen.getByTestId('discount-input');
    expect(dicountInput).toBeInTheDocument();
    fireEvent.blur(dicountInput, { target: { value: 10 } });

    fireEvent.change(dicountInput, { target: { value: 100 } });
    fireEvent.change(dicountInput, { target: { value: 2000 } });

    fireEvent.change(dicountInput, { target: { value: 10 } });
    const reasonDD = screen.getByTestId('reason-dropdown');
    expect(reasonDD).toBeInTheDocument();
    fireEvent.change(reasonDD, { target: { value: 1 } });
    const handleDPDonebtn = screen.getByTestId('handleDPDone-button');
    expect(handleDPDonebtn).toBeInTheDocument();
    fireEvent.click(handleDPDonebtn);
  });

  test('Done btn click and manager approval click', async () => {
    const handleClose = jest.fn();
    mockDataUpdater(
      mockManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateBarCodeJson,
    );
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView
            handleClose={handleClose}
            cart={cartJson.data.cart}
            customer={customerJson.data.customer}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const managerApprovalViewBack = screen.getByTestId('manager-approval-view-back');
    expect(managerApprovalViewBack).toBeInTheDocument();
    fireEvent.click(managerApprovalViewBack);

    const titleElement = screen.getByTestId('manualDiscountView');
    expect(titleElement).toBeInTheDocument();
    const discOptDollar = await waitFor(() => screen.findByTestId('dollar-discount'), { timeout: 3000 });
    const discOptPercent = screen.getByTestId('percent-discount');
    expect(discOptPercent).toBeInTheDocument();
    await waitFor(() => fireEvent.click(discOptDollar));
    const dicountInput = screen.getByTestId('discount-input');
    expect(dicountInput).toBeInTheDocument();
    fireEvent.blur(dicountInput, { target: { value: 10 } });
    fireEvent.change(dicountInput, { target: { value: 10 } });
    const reasonDD = screen.getByTestId('reason-dropdown');
    expect(reasonDD).toBeInTheDocument();
    fireEvent.change(reasonDD, { target: { value: 1 } });
    const notification = screen.getByTestId('Notification-close-button');
    fireEvent.click(notification);
    const handleDPDonebtn = screen.getByTestId('handleDPDone-button');
    expect(handleDPDonebtn).toBeInTheDocument();
    fireEvent.click(handleDPDonebtn);
  });
  test('Done btn click with $ selected', async () => {
    const handleClose = jest.fn();
    mockDataUpdater(
      mockManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateBarCodeJson,
    );
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView
            handleClose={handleClose}
            cart={cartJson.data.cart}
            customer={customerJson.data.customer}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const managerApprovalViewBack = screen.getByTestId('manager-approval-view-back');
    expect(managerApprovalViewBack).toBeInTheDocument();
    fireEvent.click(managerApprovalViewBack);

    const titleElement = screen.getByTestId('manualDiscountView');
    expect(titleElement).toBeInTheDocument();
    const discOptDollar = await waitFor(() => screen.findByTestId('dollar-discount'), { timeout: 3000 });
    const discOptPercent = screen.getByTestId('percent-discount');
    expect(discOptDollar).toBeInTheDocument();
    fireEvent.click(discOptPercent);

    const dicountInput = screen.getByTestId('discount-input');
    expect(dicountInput).toBeInTheDocument();
    fireEvent.blur(dicountInput, { target: { value: 10 } });
    fireEvent.change(dicountInput, { target: { value: 10 } });
    const reasonDD = screen.getByTestId('reason-dropdown');
    expect(reasonDD).toBeInTheDocument();
    fireEvent.change(reasonDD, { target: { value: 1 } });
    const handleDPDonebtn = screen.getByTestId('handleDPDone-button');
    expect(handleDPDonebtn).toBeInTheDocument();
    fireEvent.click(handleDPDonebtn);
  });

  test('reason drop down should be disabled when discount is 0  ', async () => {
    const handleClose = jest.fn();
    mockDataUpdater(
      mockManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateBarCodeJson,
    );
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView
            handleClose={handleClose}
            cart={cartJson.data.cart}
            customer={customerJson.data.customer}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const managerApprovalViewBack = screen.getByTestId('manager-approval-view-back');
    expect(managerApprovalViewBack).toBeInTheDocument();
    fireEvent.click(managerApprovalViewBack);

    const titleElement = screen.getByTestId('manualDiscountView');
    expect(titleElement).toBeInTheDocument();
    const discOptDollar = await waitFor(() => screen.findByTestId('dollar-discount'), { timeout: 3000 });
    const discOptPercent = screen.getByTestId('percent-discount');
    expect(discOptPercent).toBeInTheDocument();
    await waitFor(() => fireEvent.click(discOptDollar));
    const dicountInput = screen.getByTestId('discount-input');
    expect(dicountInput).toBeInTheDocument();
    fireEvent.blur(dicountInput, { target: { value: 0 } });
    fireEvent.change(dicountInput, { target: { value: 0 } });
    const reasonDD = screen.getByTestId('reason-dropdown');
    expect(reasonDD).toBeDisabled();
  });
  test('Done btn click without discount', async () => {
    const handleClose = jest.fn();
    mockDataUpdater(
      mockManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateBarCodeJson,
    );
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView
            handleClose={handleClose}
            cart={cartJson.data.cart}
            customer={customerJson.data.customer}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const managerApprovalViewBack = screen.getByTestId('manager-approval-view-back');
    expect(managerApprovalViewBack).toBeInTheDocument();
    fireEvent.click(managerApprovalViewBack);

    const titleElement = screen.getByTestId('manualDiscountView');
    expect(titleElement).toBeInTheDocument();
    const discOptDollar = await waitFor(() => screen.findByTestId('dollar-discount'), { timeout: 3500 });
    const discOptPercent = screen.getByTestId('percent-discount');
    expect(discOptPercent).toBeInTheDocument();
    await waitFor(() => fireEvent.click(discOptDollar));

    const reasonDD = screen.getByTestId('reason-dropdown');
    expect(reasonDD).toBeInTheDocument();
    fireEvent.change(reasonDD, { target: { value: 1 } });
    const handleDPDonebtn = screen.getByTestId('handleDPDone-button');
    expect(handleDPDonebtn).toBeInTheDocument();
    fireEvent.click(handleDPDonebtn);
  });

  test('btn-exit-dialog click', () => {
    const handleClose = jest.fn();
    mockDataUpdater(
      mockManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateBarCodeJson,
    );
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView handleClose={handleClose} cart={cartJson.data.cart} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const managerApprovalViewBack = screen.getByTestId('manager-approval-view-back');
    expect(managerApprovalViewBack).toBeInTheDocument();
    fireEvent.click(managerApprovalViewBack);

    const titleElement = screen.getByTestId('manualDiscountView');
    expect(titleElement).toBeInTheDocument();
    const exitBtn = screen.getByTestId('btn-exit-dialog');
    expect(exitBtn).toBeInTheDocument();
    fireEvent.click(exitBtn);
    const manualDiscountViewId = screen.getByTestId('manualDiscountView');
    expect(manualDiscountViewId).toBeInTheDocument();
  });

  test('Promo Remove btn click', async () => {
    const handleClose = jest.fn();
    mockDataUpdater(
      mockManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateBarCodeJson,
    );
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView handleClose={handleClose} cart={cartJson.data.cart} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const managerApprovalViewBack = screen.getByTestId('manager-approval-view-back');
    expect(managerApprovalViewBack).toBeInTheDocument();
    fireEvent.click(managerApprovalViewBack);

    const titleElement = screen.getByTestId('manualDiscountView');
    expect(titleElement).toBeInTheDocument();

    const dicountInput = await waitFor(() => screen.findByTestId('discount-input'), {
      timeout: 4000,
    });
    expect(dicountInput).toBeInTheDocument();
    await waitFor(() => fireEvent.blur(dicountInput, { target: { value: 10 } }));
    const reasonDD = screen.getByTestId('reason-dropdown');
    expect(reasonDD).toBeInTheDocument();
    fireEvent.change(reasonDD, { target: { value: 1 } });
    const handlePromoRemovebtn = screen.getByTestId('promo-remove-btn');
    expect(handlePromoRemovebtn).toBeInTheDocument();
    fireEvent.click(handlePromoRemovebtn, {});
  });

  test('Done btn click and dont show manager approval screen when isFunctionalityEnabled = false', async () => {
    isFunctionalityEnabled.mockImplementation(() => false);
    mockDataUpdater(
      mockManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateBarCodeJson,
    );
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView
            handleClose={jest.fn()}
            cart={cartJson.data.cart}
            customer={customerJson.data.customer}
            doneClicked={doneClicked}
            refetchCartDetails={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const managerApprovalViewBack = screen.getByTestId('manager-approval-view-close');
    expect(managerApprovalViewBack).toBeInTheDocument();
    fireEvent.click(managerApprovalViewBack);

    const titleElement = screen.getByTestId('manualDiscountView');
    expect(titleElement).toBeInTheDocument();
    const discOptDollar = screen.getByTestId('dollar-discount');
    const discOptPercent = screen.getByTestId('percent-discount');
    expect(discOptPercent).toBeInTheDocument();
    fireEvent.click(discOptDollar);
    const dicountInput = screen.getByTestId('discount-input');
    expect(dicountInput).toBeInTheDocument();
    fireEvent.blur(dicountInput, { target: { value: 10 } });

    fireEvent.change(dicountInput, { target: { value: 100 } });
    fireEvent.change(dicountInput, { target: { value: 2000 } });

    fireEvent.change(dicountInput, { target: { value: 10 } });
    const reasonDD = screen.getByTestId('reason-dropdown');
    expect(reasonDD).toBeInTheDocument();
    fireEvent.change(reasonDD, { target: { value: 1 } });
    const handleDPDonebtn = screen.getByTestId('handleDPDone-button');
    expect(handleDPDonebtn).toBeInTheDocument();

    await act(async () => {
      fireEvent.click(handleDPDonebtn);
      // Call the mock data updater immediately after the click
      mockDataUpdater(
        JSON.parse(JSON.stringify(mockManualDiscountJson)),
        JSON.parse(JSON.stringify(mockUpdateManualDiscountJson)),
        JSON.parse(JSON.stringify(mockUpdateManualDiscountJson)),
        mockUpdateBarCodeJson,
      );
    });
  });

  test('Done btn click and dont show manager approval screen when promise reject', async () => {
    mockDataUpdaterReject(
      mockManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateBarCodeJson,
    );
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView
            handleClose={jest.fn()}
            cart={cartJson.data.cart}
            customer={customerJson.data.customer}
            doneClicked={doneClicked}
            refetchCartDetails={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const managerApprovalViewBack = screen.getByTestId('manager-approval-view-close');
    expect(managerApprovalViewBack).toBeInTheDocument();
    fireEvent.click(managerApprovalViewBack);

    const titleElement = screen.getByTestId('manualDiscountView');
    expect(titleElement).toBeInTheDocument();
    const discOptDollar = screen.getByTestId('dollar-discount');
    const discOptPercent = screen.getByTestId('percent-discount');
    expect(discOptPercent).toBeInTheDocument();
    fireEvent.click(discOptDollar);
    const dicountInput = screen.getByTestId('discount-input');
    expect(dicountInput).toBeInTheDocument();
    fireEvent.blur(dicountInput, { target: { value: 10 } });

    fireEvent.change(dicountInput, { target: { value: 100 } });
    fireEvent.change(dicountInput, { target: { value: 2000 } });

    fireEvent.change(dicountInput, { target: { value: 10 } });
    const reasonDD = screen.getByTestId('reason-dropdown');
    expect(reasonDD).toBeInTheDocument();
    fireEvent.change(reasonDD, { target: { value: 1 } });
    const handleDPDonebtn = screen.getByTestId('handleDPDone-button');
    expect(handleDPDonebtn).toBeInTheDocument();

    await act(async () => {
      fireEvent.click(handleDPDonebtn);
      // Call the mock data updater immediately after the click
      mockDataUpdaterPending(
        JSON.parse(JSON.stringify(mockManualDiscountJson)),
        JSON.parse(JSON.stringify(mockUpdateManualDiscountJson)),
        JSON.parse(JSON.stringify(mockUpdateManualDiscountJson)),
        mockUpdateBarCodeJson,
      );
    });
  });
});

describe('Done btn click', () => {
  let setShowManagerApprovalMock;
  const doneClicked = true;
  beforeAll(() => {
    global.window = Object.create(window);
    setShowManagerApprovalMock = jest.fn();
  });
  beforeEach(() => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

    global.window.mfe = {
      scmUpgradeMfeEnable: true,
      scmCheckoutMfeEnable: true,
      isDark: true,
      themeProps: {
        background: '#000000',
      },
    };
    jest.clearAllMocks();
  });
  afterAll(() => {
    global.window.mfe.scmUpgradeMfeEnable = false;
  });
  test('Triggering to handoff page by making ValidateCartandcheckout API Call', () => {
    const handleClose = jest.fn();
    delete mockManualDiscountJson.data.barcode;
    mockDataUpdater(
      mockManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateBarCodeJson,
    );
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView
            handleClose={handleClose}
            cart={cartJson.data.cart}
            customer={customerJson.data.customer}
            doneClicked={doneClicked}
            setShowManagerApproval={setShowManagerApprovalMock}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const managerApprovalViewBack = screen.getByTestId('manager-approval-view-back');
    expect(managerApprovalViewBack).toBeInTheDocument();
    fireEvent.click(managerApprovalViewBack);

    const handleDPDonebtn = screen.getByTestId('handleDPDone-button');
    expect(handleDPDonebtn).toBeInTheDocument();
    fireEvent.click(handleDPDonebtn);
  });
});

describe('ManualDiscountView Component add promocode success', () => {
  setUserAgentIPad();
  beforeEach(() => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);
  });
  test('barcode scan ipad', () => {
    const handleClose = jest.fn();
    mockDataUpdater(
      mockManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateBarCodeJson,
    );
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView handleClose={handleClose} cart={cartJson.data.cart} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const managerApprovalViewBack = screen.getByTestId('manager-approval-view-back');
    expect(managerApprovalViewBack).toBeInTheDocument();
    fireEvent.click(managerApprovalViewBack);

    const addPromoBtn = screen.getByTestId('handleAddCoupon-button');
    expect(addPromoBtn).toBeInTheDocument();
    fireEvent.click(addPromoBtn, {});
    const addPromoInput = screen.getByRole('textbox');
    expect(addPromoInput).toBeInTheDocument();
    fireEvent.change(addPromoInput, { target: { value: 'HHH' } });
    const scanBarBtn = screen.getByTestId('scanBarBtn');
    expect(scanBarBtn).toBeInTheDocument();
    fireEvent.click(scanBarBtn, {});
    const submitPromoBtn = screen.getByTestId('handlePromoSubmit-button');
    expect(submitPromoBtn).toBeInTheDocument();
    fireEvent.click(submitPromoBtn, {});
  });
  test('barcode scan ipad', () => {
    const handleClose = jest.fn();
    mockDataUpdater(
      mockManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateBarCodeJson,
    );
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView handleClose={handleClose} cart={cartJson.data.cart} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const managerApprovalViewBack = screen.getByTestId('manager-approval-view-back');
    expect(managerApprovalViewBack).toBeInTheDocument();
    fireEvent.click(managerApprovalViewBack);

    const addPromoBtn = screen.getByTestId('handleAddCoupon-button');
    expect(addPromoBtn).toBeInTheDocument();
    fireEvent.click(addPromoBtn, {});
    const closebutton = screen.getByTestId('btn-exit-dialog-promo');
    fireEvent.click(closebutton);
  });

  test('barcode scan ipad when scmUpgradeMfeEnabled', () => {
    global.window.mfe.scmUpgradeMfeEnable = true;
    const handleClose = jest.fn();
    mockDataUpdater(
      mockManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateBarCodeJson,
    );
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView handleClose={handleClose} cart={cartJson.data.cart} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const managerApprovalViewBack = screen.getByTestId('manager-approval-view-back');
    expect(managerApprovalViewBack).toBeInTheDocument();
    fireEvent.click(managerApprovalViewBack);

    const addPromoBtn = screen.getByTestId('handleAddCoupon-button');
    expect(addPromoBtn).toBeInTheDocument();
    fireEvent.click(addPromoBtn, {});
    const closebutton = screen.getByTestId('btn-exit-dialog-promo');
    fireEvent.click(closebutton);
    global.window.mfe.scmUpgradeMfeEnable = false;
  });
});

describe('ManualDiscountView Component add promocode Error', () => {
  setUserAgentIPad();
  beforeEach(() => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);
  });
  test('barcode scan ipad', () => {
    const handleClose = jest.fn();
    mockDataUpdater(mockManualDiscountJson, mockUpdateManualDiscountJson, mockUpdateManualDiscountJson, {
      errors: [{ message: 'error' }],
    });
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView handleClose={handleClose} cart={cartJson.data.cart} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const managerApprovalViewBack = screen.getByTestId('manager-approval-view-back');
    expect(managerApprovalViewBack).toBeInTheDocument();
    fireEvent.click(managerApprovalViewBack);

    const addCoupon = screen.getByTestId('handleAddCoupon-button');
    expect(addCoupon).toBeInTheDocument();
    fireEvent.click(addCoupon, {});
    const addpromoInput = screen.getByTestId('addpromo-input');
    expect(addpromoInput).toBeInTheDocument();
    fireEvent.change(addpromoInput, { target: { value: 'HHH' } });
    const addPromoBtn = screen.getByTestId('handlePromoSubmit-button');
    expect(addPromoBtn).toBeInTheDocument();
    fireEvent.click(addPromoBtn, {});
  });
});

describe('ManualDiscountView Component add promocode success and Add notification test', () => {
  setUserAgentIPad();
  beforeEach(() => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);
  });
  test('barcode scan ipad', () => {
    const handleClose = jest.fn();
    mockDataUpdater(
      mockManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateBarCodeJson,
    );
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView handleClose={handleClose} cart={cartJson.data.cart} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const managerApprovalViewBack = screen.getByTestId('manager-approval-view-close');
    expect(managerApprovalViewBack).toBeInTheDocument();
    fireEvent.click(managerApprovalViewBack);

    const addPromoBtn = screen.getByTestId('handleAddCoupon-button');
    expect(addPromoBtn).toBeInTheDocument();
    fireEvent.click(addPromoBtn, {});

    const addPromoInput = screen.getByRole('textbox');
    expect(addPromoInput).toBeInTheDocument();
    fireEvent.change(addPromoInput, { target: { value: 'HHH' } });
    const scanBarBtn = screen.getByTestId('scanBarBtn');
    expect(scanBarBtn).toBeInTheDocument();
    fireEvent.click(scanBarBtn, {});
    const submitPromoBtn = screen.getByTestId('handlePromoSubmit-button');
    expect(submitPromoBtn).toBeInTheDocument();
    fireEvent.click(submitPromoBtn, {});
  });

  test('barcode scan ipad', () => {
    const handleClose = jest.fn();
    mockDataUpdater(
      mockManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateBarCodeJson,
    );
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView handleClose={handleClose} cart={cartJson.data.cart} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const managerApprovalViewBack = screen.getByTestId('manager-approval-view-close');
    expect(managerApprovalViewBack).toBeInTheDocument();
    fireEvent.click(managerApprovalViewBack);

    const addPromoBtn = screen.getByTestId('handleAddCoupon-button');
    expect(addPromoBtn).toBeInTheDocument();
    fireEvent.click(addPromoBtn, {});

    const addPromoInput = screen.getByRole('textbox');
    expect(addPromoInput).toBeInTheDocument();
    fireEvent.change(addPromoInput, { target: { value: 'HHH' } });
    const scanBarBtn = screen.getByTestId('scanBarBtn');
    expect(scanBarBtn).toBeInTheDocument();
    fireEvent.click(scanBarBtn, {});
    const submitPromoBtn = screen.getByTestId('handlePromoSubmit-button');
    expect(submitPromoBtn).toBeInTheDocument();
    fireEvent.click(submitPromoBtn, {});
  });
});

describe('ManualDiscountView Component withoout cart id', () => {
  beforeEach(() => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);
  });
  test('renders ManualDiscount View', () => {
    const handleClose = jest.fn();
    mockDataUpdater({}, {}, {}, {});
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView handleClose={handleClose} cart={{}} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByTestId('manualDiscountView');
    expect(titleElement).toBeInTheDocument();
  });
});

describe('ManualDiscountView - promoModalPosition and positioning logic', () => {
  beforeEach(() => {
    sessionStorage.clear();
  });

  test('should return "absolute" when positionFFlag is TRUE and containerName is not "promo_code"', () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ positionFFlag: 'TRUE' }));
    const props = { containerName: 'some_other_container', scmUpgradeMfeEnable: false };

    const { container } = render(<ManualDiscountView {...props} />);
    const result = container.textContent; // Mock the return value or check the rendered output

    expect(result).toContain('absolute');
  });

  test('should return "fixed" when positionFFlag is FALSE', () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ positionFFlag: 'FALSE' }));
    const props = { containerName: 'promo_code', scmUpgradeMfeEnable: false };

    const { container } = render(<ManualDiscountView {...props} />);
    const result = container.textContent;

    expect(result).toContain('fixed');
  });

  test('should return "initital" when scmUpgradeMfeEnable is true', () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ positionFFlag: 'TRUE' }));
    const props = { containerName: 'promo_code', scmUpgradeMfeEnable: true };

    const { container } = render(<ManualDiscountView {...props} />);
    const result = container.textContent;

    expect(result).toContain('initital');
  });

  test('should return "fixed" when positionFFlag is TRUE but containerName is "promo_code"', () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ positionFFlag: 'TRUE' }));
    const props = { containerName: 'promo_code', scmUpgradeMfeEnable: false };

    const { container } = render(<ManualDiscountView {...props} />);
    const result = container.textContent;

    expect(result).toContain('fixed');
  });
});

describe('ManualDiscountView Component', () => {
  // const doneClicked = true;
  // let setShowManagerApprovalMock;
  beforeAll(() => {
    global.window = Object.create(window);
    // setShowManagerApprovalMock = jest.fn();
  });
  beforeEach(() => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);
    global.window.mfe = {
      scmUpgradeMfeEnable: true,
      isDark: true,
      themeProps: {
        background: '#000000',
      },
    };
    jest.clearAllMocks();
  });

  afterAll(() => {
    global.window.mfe.scmUpgradeMfeEnable = false;
  });

  test('renders ManualDiscount View', () => {
    const cartMockData = cartJson;
    cartMockData.data.cart.lineDetails.lineInfo[0].itemsInfo[0].cartItems.cartItem[0].prodCode2 = 'GIF';
    mockDataUpdater(
      mockManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateManualDiscountJson,
      mockUpdateBarCodeJson,
    );
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountView handleClose={jest.fn()} cart={cartMockData.data.cart} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const managerApprovalViewBack = screen.getByTestId('manager-approval-view-back');
    expect(managerApprovalViewBack).toBeInTheDocument();
    fireEvent.click(managerApprovalViewBack);

    const titleElement = screen.getByTestId('manualDiscountView');
    expect(titleElement).toBeInTheDocument();
  });
});
