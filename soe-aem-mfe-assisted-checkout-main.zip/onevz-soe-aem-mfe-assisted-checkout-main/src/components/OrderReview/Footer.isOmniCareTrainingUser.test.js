import React from 'react';
import { render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { useGetOffersPdpMutation } from 'onevzsoemfecommon/AccountAPIService';
import StoreProvider from '../../modules/store';
import Footer from './Footer';
import cartJson from '../../__mock__/retrive-cart.json';
import orderWrite from '../../__mock__/getOrderWrite.json';
import mtnsJson from '../../__mock__/getCustomerByMtns.json';
import getRetrieveInstallmentAgreementJson from '../../__mock__/getRetrieveInstallmentAgreement.json';
import retrieveAEMInfoManagerDataJson from '../../__mock__/retrieveAEMInfoManagerDataJson.json';
import * as orderWriteAPICallHook from '../../modules/services/APIService/AgreementsAPICallHook';
import { isServiceChangeFlag } from '../../utils/common';

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => jest.fn(),
}));

jest.mock('../../utils/common');

jest.mock('./Affirm', () => ({
  __esModule: true,
  default: () => <div>Affirm Mock</div>,
}));

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradlePropertyV2: () => ['FALSE'],
  }),
  { virtual: true },
);

jest.mock('./Agreements', () => ({
  __esModule: true,
  default: () => <div>Agreements Mock</div>,
}));

jest.mock('./VerizonOrAffirmFooter', () => ({
  __esModule: true,
  default: () => <div>VerizonOrAffirmFooter Mock</div>,
}));

jest.mock('onevzsoemfecommon/Helpers', () => ({
  getQueryParamByName: jest.fn(() => 'N'),
}));

jest.mock('../../modules/services/APIService/GetNextBillSummary', () => () => ({
  getNextBillSummaryReq: jest.fn(),
  getNextBillSummaryRes: { data: {} },
}));

jest.mock('../../modules/services/APIService/InfoAPICallHook', () => () => ({
  updateVisionRemark: jest.fn(),
}));

jest.mock('onevzsoemfecommon/AccountAPIService', () => ({
  useGetOffersPdpMutation: jest.fn(),
}));

jest.mock('onevzsoemfecommon/PreviewBill', () => ({
  __esModule: true,
  default: () => <div>PreviewBill Mock</div>,
}));

const mockSaveOrder = jest.fn();

const mockData = {
  getOrderWrite: mockSaveOrder,
  getOrderWriteResult: { data: null },
  getRetrieveInstallmentAgreement: mockSaveOrder,
  getRetrieveInstallmentAgreementResult: { data: null },
  retrieveAEMInfoManagerDataRequest: mockSaveOrder,
  retrieveAEMInfoManagerDataResponse: { data: null },
  updateAFOInfo: mockSaveOrder,
  updateVisionRemark: jest.fn(),
  getCustomerByMtns: mockSaveOrder,
  getCustomerByMtnsResult: { data: null },
};

const props = {
  isDark: true,
  cartDetailsResult: cartJson,
  customer: { regNo: '89878' },
  landing: {
    activeCartandCase: {
      cartId: 'f9a102c8-bd94-476b-8c36-f867597dc8ca',
      caseId: 'SOP-15788985-E01',
    },
    quoteDetails: [{ cartId: 'f9a102c8-bd94-476b-8c36-f867597dc8ca' }],
  },
  showAffirmModal: false,
  isAffirmLoanApproved: false,
  setShowAffirmModal: jest.fn(),
  setContinueBtnDisabled: jest.fn(),
  setShowAffirmAccordion: jest.fn(),
  getCartDetailsDataBody: jest.fn(),
  setEmailValue: jest.fn(),
  verizonVisaCardLinkSent: true,
  setCustomerMtns: jest.fn(),
  customerMtns: [],
  setShowRepGuidedScreen: jest.fn(),
  paperLessBilling: {},
  hideOrderDetails: false,
};

beforeAll(() => {
  class ResizeObserver {
    constructor() {
      this.observe = () => jest.fn();
      this.unobserve = () => jest.fn();
      this.disconnect = () => jest.fn();
    }
  }
  window.ResizeObserver = ResizeObserver;
});

let getOffersMock;
let getOffersResultsMock;

beforeEach(() => {
  getOffersMock = jest.fn();
  getOffersResultsMock = {
    data: null,
    error: null,
    isLoading: false,
    isSuccess: false,
    isError: false,
  };
  useGetOffersPdpMutation.mockReturnValue([getOffersMock, getOffersResultsMock]);
  sessionStorage.setItem('channel', 'OMNI-RETAIL');
  jest.clearAllMocks();
});

describe('Footer Component - getIsOmniCareTrainingUser method', () => {
  test('should call isServiceChangeFlag when component renders', () => {
    isServiceChangeFlag.mockReturnValue(false);
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);

    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            showViewTogether
            hideViewTogether={false}
            disableButton={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    expect(isServiceChangeFlag).toHaveBeenCalled();
  });

  test('should return true when isServiceChangeFlag returns true', () => {
    isServiceChangeFlag.mockReturnValue(true);
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);

    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            showViewTogether
            hideViewTogether={false}
            disableButton={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const viewTogetherBtn = screen.getByTestId('view-together-footer');
    expect(viewTogetherBtn).toBeInTheDocument();
    expect(viewTogetherBtn).toBeDisabled();
  });

  test('should return false when isServiceChangeFlag returns false', () => {
    isServiceChangeFlag.mockReturnValue(false);
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);

    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            showViewTogether
            hideViewTogether={false}
            disableButton={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const viewTogetherBtn = screen.getByTestId('view-together-footer');
    expect(viewTogetherBtn).toBeInTheDocument();
    expect(viewTogetherBtn).not.toBeDisabled();
  });

  test('should return false when isServiceChangeFlag throws an error', () => {
    isServiceChangeFlag.mockImplementation(() => {
      throw new Error('localStorage error');
    });
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);

    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            showViewTogether
            hideViewTogether={false}
            disableButton={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const viewTogetherBtn = screen.getByTestId('view-together-footer');
    expect(viewTogetherBtn).toBeInTheDocument();
    expect(viewTogetherBtn).not.toBeDisabled();
  });

  test('should handle catch block when isServiceChangeFlag throws error', () => {
    isServiceChangeFlag.mockImplementation(() => {
      throw new Error('Test error');
    });
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);

    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            showViewTogether
            hideViewTogether={false}
            disableButton={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    // The error should be caught and isOmniCareTrainingUser should be false
    const viewTogetherBtn = screen.getByTestId('view-together-footer');
    expect(viewTogetherBtn).not.toBeDisabled();
  });

  test('should disable View Together button when isOmniCareTrainingUser is true and showViewTogether is true', () => {
    isServiceChangeFlag.mockReturnValue(true);
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);

    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            showViewTogether
            hideViewTogether={false}
            disableButton={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const viewTogetherBtn = screen.getByTestId('view-together-footer');
    expect(viewTogetherBtn).toBeDisabled();
  });

  test('should not disable View Together button when isOmniCareTrainingUser is false', () => {
    isServiceChangeFlag.mockReturnValue(false);
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);

    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            showViewTogether
            hideViewTogether={false}
            disableButton={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const viewTogetherBtn = screen.getByTestId('view-together-footer');
    expect(viewTogetherBtn).not.toBeDisabled();
  });

  test('should disable button when both isOmniCareTrainingUser and disableButton are true', () => {
    isServiceChangeFlag.mockReturnValue(true);
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);

    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            showViewTogether
            hideViewTogether={false}
            disableButton
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const viewTogetherBtn = screen.getByTestId('view-together-footer');
    expect(viewTogetherBtn).toBeDisabled();
  });

  test('should calculate isViewTogetherDisabled based on props', () => {
    isServiceChangeFlag.mockReturnValue(true);
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);

    const { rerender } = render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            showViewTogether
            hideViewTogether={false}
            disableButton={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const viewTogetherBtn = screen.getByTestId('view-together-footer');
    expect(viewTogetherBtn).toBeDisabled();

    // Rerender with disableButton true - should still be disabled
    rerender(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            showViewTogether
            hideViewTogether={false}
            disableButton
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    expect(viewTogetherBtn).toBeDisabled();
  });
});
