import React, { useEffect, useState } from 'react';
import { executeShellFunction } from 'onevzsoemfeframework/DomService';

import PropTypes from 'prop-types';
import { Modal, ModalBody } from '@vds/modals';
import { Button } from '@vds/buttons';
import { Body, Title } from '@vds/typography';
import { Icon } from '@vds/icons';
import { Line } from '@vds/lines';
import { Input, TextArea } from '@vds/inputs';
import { DropdownSelect } from '@vds/selects';
import { DatePicker } from '@vds/date-pickers';
import moment from 'moment';
import styled, { createGlobalStyle } from 'styled-components';
import {
  BackClickable,
  PaddingTop12,
  PaddingTop16,
  PaddingTop24,
  PaddingTop4,
  PaddingTop96,
} from '../../StyledConstants';
import { covidBannerFiveGAppointment } from './ClickToCall/Constants';
import AppointmentAPICallHook from '../../modules/services/APIService/AppointmentAPICallHook';
import orderreviewApiCallHook from '../../pages/home/container/orderreviewApiCallHook';

const primaryPhoneList = [
  {
    label: 'Home Phone',
    value: 'Home',
  },
  {
    label: 'Mobile phone',
    value: 'Mobile',
  },
  {
    label: 'Work phone',
    value: 'Work',
  },
];
const secondaryPhoneList = [
  {
    label: 'Home Phone',
    value: 'Home',
  },
  {
    label: 'Mobile phone',
    value: 'Mobile',
  },
  {
    label: 'Work phone',
    value: 'Work',
  },
];
const preferredContactList = ['Email', 'Phone', 'SMS'];
/* istanbul ignore next */
const ComponentStyle = createGlobalStyle`

    [class^='ModalDialog-VDS'] {
      padding-top: 0;
      width: 100%;
      max-width: ${({ scmUpgradeMfeEnable }) => (scmUpgradeMfeEnable ? '1064px' : '1133px')};
    }

    [class^='Overlay-VDS']{
    background: ${({ scmUpgradeMfeEnable }) => (scmUpgradeMfeEnable ? 'rgba(0, 0, 0, 0.8)' : '#fff')};
    }

    [id="close-button"]{
    opacity: 0;
    }

`;
const StickyContainer = styled.div`
  display: flex;
  flex: 1;
  background-color: #0089ce;
  padding: 15px 50px;
  justify-content: space-between;
`;
const FlexAlignContainerItemsCenter = styled.div`
  display: flex;
  align-items: center !important;
  justify-content: space-between;
`;
const FlexBoxGrowOne = styled.div`
  display: flex;
  flex-grow: 1;
  height: 4rem;
`;
const LineSeperator = styled.div`
  // width: 1px;
  height: 50px;
  // background: #000000;
  top: 1rem;
  border-right: 1px solid #d8dada;
  position: relative;
`;
const ShopWrapper = styled.div`
  width: 50%;
  padding: 1.5rem 0.5rem 1.5rem 1.5rem;
  display: flex;
  justify-content: space-between;
`;
const CloseIconWrapper = styled.div`
  display: flex;
  margin-right: 30px;
  margin-top: 10px;
`;
const AddressValue = styled.div`
. height: 44px;
  width: 298px;
  color: #000000;
  font-family: "Neue Haas Grotesk Display Std";
  font-size: 15px;
  letter-spacing: 0;
  line-height: 22px;
  margin-bottom: 10px;
`;
const FieldLabel = styled.div`
  color: #747676;
  font-family: 'Neue Haas Grotesk Display Std';
  font-size: 15px;
  line-height: 25px;
  margin-bottom: 4px;
  line-height: 25px;
  letter-spacing: 0;
`;
const FieldsContainer = styled.div`
  display: flex;
  gap: 15px;
`;
const FieldsCol = styled.div`
  width: 33%;
`;
const ButtonWrapper = styled.div`
  display: flex;
  justify-content: center;
  margin-bottom: 80px;
  margin-top: 24px;
`;
const HeaderButtonWrapper = styled.div`
  display: flex;
  justify-content: center;
`;

const BodyWrapper = styled.div`
  padding-top: 25px;
  [class^='StyledTypography-VDS'] {
    color: red;
  }
`;

const ScheduleAppointment = (props) => {
  const {
    showscheduleAppointmentModal,
    setShowScheduleAppointmentModal,
    lineInfo,
    cartHeader,
    closeAppointment,
    isIpad,
  } = props;
  const [fullName, setFullName] = useState('');
  const [firstNm, setFirstNm] = useState('');
  const [lastNm, setLastNm] = useState('');
  const [completeAddress1, setCompleteAddress1] = useState('');
  const [completeAddress2, setCompleteAddress2] = useState('');
  const [floor, setFloor] = useState('');
  const [evntCorrelationId, setEvntCorrelationId] = useState('');
  const [primarymdn, setPrimarymdn] = useState('');
  const [primaryPhone, setPrimaryPhone] = useState('Home');
  const [validPrimarymdn, setValidPrimarymdn] = useState('');
  const [secondarymdn, setSecondarymdn] = useState('');
  const [secondaryPhone, setSecondaryPhone] = useState('Select');
  const [validsecondarymdn, setValidsecondarymdn] = useState('');
  const [preferredcontactMethod, setPreferredcontactMethod] = useState('Select');
  const [email, setEmail] = useState('');
  const [validEmail, setValidEmail] = useState('');
  const [disableContinue, setDisableContinue] = useState(true);
  const [specialInstructions, setSpecialInstructions] = useState('');

  const { get5GAppointments, get5GAppointmentsResult, save5GAppointment, save5GAppointmentResult } =
    AppointmentAPICallHook();
  const { CustomerProfileResult } = orderreviewApiCallHook();
  const cartId = CustomerProfileResult?.data?.data?.customer?.cartId || sessionStorage.getItem('acssMfeCartId');
  const [disableCalendar, setDisableCalendar] = useState(false);
  const [minDate, setMinDate] = useState('');
  const [maxDate, setMaxDate] = useState('');
  const [activeDates, setActiveDates] = useState([]);
  const [inactiveDates, setInactiveDates] = useState([]);
  const [dateRange, setDateRange] = useState([]);
  const [selectedDate, setSelectedDate] = useState('');
  const [slotTime, setSlotTime] = useState([]);
  const [slotSelected, setSlotSelected] = useState('Select a Time Slot');
  const [selectedTime, setSelectedTime] = useState();

  useEffect(() => {
    if (cartId) {
      const today = new Date();
      const prevDate = new Date(today);
      prevDate.setDate(today.getDate() - 1);
      const startDate = `${(prevDate.getMonth() + 1).toString().padStart(2, '0')}/${prevDate
        .getDate()
        .toString()
        .padStart(2, '0')}/${prevDate.getFullYear()}`;
      const body = {
        cartId,
        startDate,
        numberofDays: 30,
      };
      get5GAppointments({ body, spinner: true });
    }
  }, [cartId]);

  const getActiveandInactiveDates = () => {
    setDisableCalendar(!get5GAppointmentsResult?.data?.data?.available5GAppointments?.availability?.availabilityFound);
    const activeDate = [];
    const inactiveDate = [];

    const today = new Date();

    for (let i = 0; i <= 60; i++) {
      const currentDate = new Date(today);
      currentDate.setDate(today.getDate() + i);
      const formattedDate = `${currentDate.getMonth() + 1}/${currentDate.getDate()}/${currentDate.getFullYear()}`;
      const compareFormattedDate = `${currentDate.getFullYear()}${(currentDate.getMonth() + 1)
        .toString()
        .padStart(2, '0')}${currentDate.getDate().toString().padStart(2, '0')}`;
      const found = get5GAppointmentsResult?.data?.data?.available5GAppointments?.availability?.availabilityDates?.some(
        (item) => item?.availableDate === compareFormattedDate,
      );

      if (found) {
        activeDate.push(formattedDate);
      } else {
        inactiveDate.push(formattedDate);
      }
    }
    setActiveDates(activeDate);
    setInactiveDates(inactiveDate);

    const dt = new Date();
    dt.setDate(dt.getDate() + 29);
    setMaxDate(dt);
    const scoreRisk = get5GAppointmentsResult?.data?.data?.available5GAppointments?.riskScore?.scoreRisk;
    const minDt = new Date();
    if (scoreRisk === 'Medium' || scoreRisk === 'High') {
      minDt.setDate(minDt.getDate() + 4);
    }
    setMinDate(minDt);
    const range = handleAvailability(
      get5GAppointmentsResult?.data?.data?.available5GAppointments?.availability?.availabilityDates,
    );
    const fullRange = range.map((eachDay) => {
      const slots = Object.keys(eachDay).filter((key) => {
        if (key.includes('fullSlot')) {
          return key;
        }
        return undefined;
      });
      const firstSlotValue = eachDay?.fullSlot ? eachDay?.fullSlot : '';
      const slotValue = slots.map((slot) => {
        if (slot !== 'fullSlot') {
          return eachDay[slot];
        }
        return undefined;
      });
      if (slotValue[slotValue.length] === undefined) {
        slotValue.pop();
      }
      slotValue.unshift(firstSlotValue);
      eachDay.slotTime = slotValue; // eslint-disable-line no-param-reassign
      return eachDay;
    });
    setDateRange(fullRange);
  };
  useEffect(() => {
    getActiveandInactiveDates();
  }, [get5GAppointmentsResult?.data?.data]);

  useEffect(() => {
    if (save5GAppointmentResult?.data?.appointmentUpdated) {
      closeAppointment();
    }
  }, [save5GAppointmentResult]);

  useEffect(() => {
    const linInfo = lineInfo.filter((x) => x.lineActivityType === 'AAL_5G' || x.lineActivityType === 'NSE_5G');
    if (linInfo && linInfo.length > 0) {
      const { serviceInfo = {} } = linInfo[0];
      const { primaryUserInfo = {}, cart5GAddress = {} } = serviceInfo;
      const { address = {}, firstName = '', lastName = '' } = primaryUserInfo;
      const { emailId = '', phoneNumber = '' } = address;
      const {
        addressLine1 = '',
        city = '',
        state = '',
        zipCode = '',
        addressLine2 = '',
        flor = '',
        eventCorrelationId = '',
      } = cart5GAddress;
      let completeAddrs1;
      if (addressLine1 && addressLine2) {
        completeAddrs1 = `${addressLine1}, ${addressLine2}`;
      } else if (addressLine1) {
        completeAddrs1 = `${addressLine1}`;
      }
      const completeAddrs2 = `${city}, ${state} ${zipCode}`;
      setFullName(firstName && lastName ? `${firstName} ${lastName}` : '');
      setFirstNm(firstName);
      setLastNm(lastName);
      setCompleteAddress1(completeAddrs1);
      setCompleteAddress2(completeAddrs2);
      setFloor(flor);
      setPrimarymdn(phoneNumber);
      setEmail(emailId);
      setEvntCorrelationId(eventCorrelationId);
    }
  }, [props?.lineInfo]);

  const ExecuteCovidBanner5GInfoManagerLink = (theURL) => {
    const shellParams = {
      name: 'CovidBannerInfoManager',
      path: '',
      replace: 'true',
      params: `rawurl:${theURL}`,
    };
    executeShellFunction('Shell', 'showScreen', 'none', shellParams);
  };

  const handleContinue = () => {
    const selectedDt = moment(selectedDate).format('YYYYMMDD');
    const availabilityDates =
      get5GAppointmentsResult?.data?.data?.available5GAppointments?.availability?.availabilityDates?.filter(
        (eachDay) => eachDay.availableDate === selectedDt && eachDay.slotStartTime === selectedTime,
      );
    const installApptSelectedDate = availabilityDates && availabilityDates.length > 0 ? availabilityDates[0] : {};
    const apptInfo = {};
    if (primaryPhone === 'Home') {
      apptInfo.homePhone = primarymdn;
      apptInfo.primaryPhoneType = 'Home';
    }
    if (primaryPhone === 'Work') {
      apptInfo.workPhone = primarymdn;
      apptInfo.primaryPhoneType = 'Work';
    }
    if (primaryPhone === 'Mobile') {
      apptInfo.mobilePhone = primarymdn;
      apptInfo.primaryPhoneType = 'Mobile';
    }

    if (secondaryPhone === 'Home' && secondarymdn) {
      apptInfo.homePhone = secondarymdn;
    }
    if (secondaryPhone === 'Work' && secondarymdn) {
      apptInfo.workPhone = secondarymdn;
    }
    if (secondaryPhone === 'Mobile' && secondarymdn) {
      apptInfo.mobilePhone = secondarymdn;
    }

    apptInfo.preferredContactType = preferredcontactMethod;
    apptInfo.emailAddress = email;
    apptInfo.firstName = firstNm;
    apptInfo.lastName = lastNm;
    apptInfo.installationFloor = floor;
    apptInfo.languagePref = 'E';
    apptInfo.installApptSelectedDate = installApptSelectedDate;
    apptInfo.customerInstructions = specialInstructions;
    apptInfo.eventCorrelationId = evntCorrelationId;

    const data = {
      cartId,
      cartLineMtn: lineInfo[0]?.mobileNumber,
      apptInfo,
    };

    const cartInfo = {
      correlationId: '',
      cartId,
      caseId: CustomerProfileResult?.data?.data?.customer?.caseId,
      accountNumber: cartHeader?.fullAccountNumber,
      cartCreator: cartHeader?.cartCreator,
      processingMTN: lineInfo[0]?.mobileNumber,
      processStep: 'OrderReview-Shipping',
      processAction: 'UpdateScheduleAppointment',
      intendType: lineInfo[0]?.lineActivityType,
    };
    const body = {
      cartInfo,
      data,
    };
    save5GAppointment({ body, spinner: true });
  };
  const handleAvailability = (availabilityDates) => {
    let range = [];
    const val = [];
    const req = availabilityDates?.reduce((acc, obj, ind) => {
      if (acc?.availableDate === obj?.availableDate) {
        range = { ...acc };
        range[`slotStartTime${ind}`] = moment(obj.slotStartTime, 'hmm').format('hA');
        range[`slotLength${ind}`] = obj.slotLength;
        range[`slotEndTime${ind}`] = moment(obj.slotStartTime, 'hmm').add(obj.slotLength, 'h').format('hA');
        const slotStartTime = `slotStartTime${ind}`;
        const slotEndTime = `slotEndTime${ind}`;
        range[`fullSlot${ind}`] = `${range[slotStartTime]} - ${range[slotEndTime]}`;
      } else {
        if (Array.isArray(range) && range.length === 0 && acc) {
          range = acc;
        }
        val.unshift({
          ...range,
          availableDate: moment(range.availableDate).format('MM/DD/YY'),
          slotStartTime: moment(range.slotStartTime, 'hmm').format('hA'),
          slotEndTime: moment(range.slotStartTime, 'hmm').add(range.slotLength, 'h').format('hA'),
          fullSlot: `${moment(range.slotStartTime, 'hmm').format('hA')} - ${moment(range.slotStartTime, 'hmm')
            .add(range.slotLength, 'h')
            .format('hA')}`,
        });
        acc = obj; // eslint-disable-line no-param-reassign
      }
      return acc;
    });
    const lastDate = val.findIndex((date) => date.availableDate === req.availableDate);
    if (lastDate === -1) {
      val.push({
        ...req,
        availableDate: moment(req?.availableDate).format('MM/DD/YY'),
        slotStartTime: moment(req?.slotStartTime, 'hmm').format('hA'),
        slotEndTime: moment(req?.slotStartTime, 'hmm').add(req?.slotLength, 'h').format('hA'),
        fullSlot: `${moment(req?.slotStartTime, 'hmm').format('hA')} - ${moment(req?.slotStartTime, 'hmm')
          .add(req?.slotLength, 'h')
          .format('hA')}`,
      });
    }
    return val;
  };

  const enableContinue = () => {
    if (!primarymdn || validPrimarymdn === 'Please enter valid phone number') {
      setDisableContinue(true);
    } else if (
      secondaryPhone !== 'Select' &&
      (secondarymdn === '' || validsecondarymdn === 'Please enter valid phone number')
    ) {
      setDisableContinue(true);
    } else if (validEmail) {
      setDisableContinue(true);
    } else if (preferredcontactMethod === 'Select') {
      setDisableContinue(true);
    } else if (slotSelected === 'Select a Time Slot') {
      setDisableContinue(true);
    } else {
      setDisableContinue(false);
    }
  };

  useEffect(() => {
    enableContinue();
  }, [
    primaryPhone,
    primarymdn,
    validPrimarymdn,
    secondaryPhone,
    secondarymdn,
    validsecondarymdn,
    validEmail,
    preferredcontactMethod,
    slotSelected,
  ]);

  const validateEmail = (value) => {
    const isValid = value.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i);
    return isValid ? null : 'Please enter valid email';
  };
  const validatePhone = (value) => {
    const phoneList = value.split(',');
    let isValid = false;
    phoneList.forEach((element) => {
      isValid = element.match(/^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/);
    });
    return isValid ? '' : 'Please enter valid phone number';
  };

  const handleprimarymdn = (value) => {
    setPrimarymdn(value);
    setValidPrimarymdn(validatePhone(value));
  };
  const handlesecondarymdn = (value) => {
    setSecondarymdn(value);
    setValidsecondarymdn(validatePhone(value));
  };

  const handleSecondaryPhone = (value) => {
    setSecondaryPhone(value);
    if (value === 'Select') {
      setSecondarymdn('');
      setValidsecondarymdn('');
    }
  };

  const handleEmail = (value) => {
    setEmail(value);
    const val = validateEmail(value);
    setValidEmail(val);
  };

  const handleDate = (selectDate) => {
    setSelectedDate(selectDate);
    setSlotSelected('Select a Time Slot');
    let appointAvail;
    if (selectDate) {
      const startDate = moment(selectDate).format('MM/DD/YY');
      appointAvail = dateRange.filter((day) => {
        if (day.availableDate === startDate) {
          setSlotTime(day.slotTime);
          return true;
        }
        return false;
      });
    }
    if (selectDate && appointAvail.length === 0) {
      setSlotTime([]);
    }
  };

  const handleSlotTime = (value) => {
    const startTime = value.split('-');
    const time = moment(startTime[0], 'hA').format('kkmm');
    setSlotSelected(value);
    setSelectedTime(time);
  };

  const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable;

  return (
    <>
      <ComponentStyle  scmUpgradeMfeEnable={scmUpgradeMfeEnable} />
      <Modal
        className='schedule-Appointment-Modal'
        surface='light'
        disableAnimation={false}
        disableOutsideClick={false}
        ariaLabel='ColleteralInfo'
        opened={showscheduleAppointmentModal}
        fullScreenDialog={!scmUpgradeMfeEnable}
        {...(scmUpgradeMfeEnable ? { width: '100%' } : {})}
      >
        <StickyContainer>
          <PaddingTop12>
            <Title size='small' bold={false} color='#ffffff'>
              {covidBannerFiveGAppointment.covidBannerFiveGAppointment1}
              {isIpad ? (
                <>
                  {covidBannerFiveGAppointment.covidBannerFiveGAppointment3}
                  <HeaderButtonWrapper>
                    <Button
                      size='small'
                      onClick={() =>
                        ExecuteCovidBanner5GInfoManagerLink(
                          covidBannerFiveGAppointment.covidBannerFiveGAppointmentLinkUrl,
                        )
                      }
                      data-testid='ipad-btn'
                    >
                      {covidBannerFiveGAppointment.covidBannerFiveGAppointment2}
                    </Button>
                  </HeaderButtonWrapper>
                </>
              ) : (
                <>
                  <a
                    href={covidBannerFiveGAppointment.covidBannerFiveGAppointmentLinkUrl}
                    target='_blank'
                    style={{ color: '#000000' }}
                    data-testid='appointment-url-link'
                  >
                    {covidBannerFiveGAppointment.covidBannerFiveGAppointment2}
                  </a>
                  {covidBannerFiveGAppointment.covidBannerFiveGAppointment3}
                </>
              )}
            </Title>
          </PaddingTop12>
        </StickyContainer>
        <FlexAlignContainerItemsCenter>
          <FlexBoxGrowOne>
            <BackClickable
              data-testId='btn-back'
              onClick={() => {
                setShowScheduleAppointmentModal(false);
              }}
            >
              <Icon name='left-caret' size='XLarge' medium='true' />
            </BackClickable>
            <LineSeperator />
            <ShopWrapper width='170px'>
              <Title size='small' bold primitive='h1'>
                Schedule Appointment
              </Title>
            </ShopWrapper>
          </FlexBoxGrowOne>
          <CloseIconWrapper
            data-testid='close-btn-icon'
            onClick={() => {
              setShowScheduleAppointmentModal(false);
            }}
          >
            <span>
              <Icon name='close' size='large' />
            </span>
          </CloseIconWrapper>
        </FlexAlignContainerItemsCenter>
        <Line type='secondary' />
        <ModalBody>
          <Title size='large' bold>
            View availability{' '}
          </Title>
          <PaddingTop16 />
          <Line />
          <PaddingTop24 />

          <FieldLabel>Address</FieldLabel>
          <PaddingTop4 />

          <AddressValue>
            <Body size='large' bold>
              {fullName}
            </Body>
            <Body size='large'>{completeAddress1}</Body>
            <Body size='large'>{completeAddress2}</Body>
          </AddressValue>
          <PaddingTop12 />
          <FieldsContainer>
            <FieldsCol>
              <DropdownSelect
                value={primaryPhone}
                label='Primary Phone*'
                onChange={(e) => setPrimaryPhone(e.target.value)}
                error={false}
                disabled={false}
                readOnly={false}
                inlineLabel={false}
                width='100%'
                required
                data-testid='primaryPhone'
              >
                <option key='Select' value='Select' disabled='disabled'>
                  Select
                </option>
                {primaryPhoneList.map((option) => (
                  <option key={option} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </DropdownSelect>
            </FieldsCol>
            <FieldsCol>
              <Input
                label='Enter MDN'
                onChange={(e) => handleprimarymdn(e.target.value)}
                type='text'
                required
                disabled={false}
                error={false}
                errorText={validPrimarymdn}
                value={primarymdn}
                width='100%'
                data-testid='primaryMdn'
                helperText={primarymdn ? validPrimarymdn : ''}
                helperTextPlacement='bottom'
              />
            </FieldsCol>
          </FieldsContainer>
          <PaddingTop24 />
          <FieldsContainer>
            <FieldsCol>
              <DropdownSelect
                value={secondaryPhone}
                label='Secondary Phone'
                onChange={(e) => handleSecondaryPhone(e.target.value)}
                error={false}
                disabled={false}
                readOnly={false}
                inlineLabel={false}
                width='100%'
                required
                data-testid='secondaryPhone'
              >
                <option key='Select' value='Select'>
                  Select
                </option>
                {secondaryPhoneList.map((option) => (
                  <option key={option} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </DropdownSelect>
            </FieldsCol>
            <FieldsCol>
              <Input
                label='Enter MDN'
                onChange={(e) => handlesecondarymdn(e.target.value)}
                type='text'
                required
                disabled={false}
                error={false}
                value={secondarymdn}
                width='100%'
                data-testid='secondaryMdn'
                readOnly={secondaryPhone === 'Select'}
                helperText={validsecondarymdn}
                helperTextPlacement='bottom'
              />
            </FieldsCol>
          </FieldsContainer>
          <PaddingTop24 />
          <FieldsContainer>
            <FieldsCol>
              <Input
                label='Email*'
                onChange={(e) => handleEmail(e.target.value)}
                type='text'
                formControlName='name'
                value={email}
                width='100%'
                data-testid='emailInput'
                helperText={validEmail}
                helperTextPlacement='bottom'
              />
            </FieldsCol>
            <FieldsCol>
              <DropdownSelect
                value={preferredcontactMethod}
                label='Preferred contact method*'
                onChange={(e) => setPreferredcontactMethod(e.target.value)}
                error={false}
                disabled={false}
                readOnly={false}
                inlineLabel={false}
                width='100%'
                required
                data-testid='preferred-contact-method'
              >
                <option key='Select' value='Select' disabled='disabled'>
                  Select
                </option>
                {preferredContactList.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </DropdownSelect>
            </FieldsCol>
          </FieldsContainer>
          <PaddingTop24 />
          <TextArea
            label='Special Instructions'
            surface='light'
            readOnly={false}
            required={false}
            error={false}
            disabled={false}
            maxLength={null}
            width='67.5%'
            onChange={(e) => setSpecialInstructions(e.target.value)}
            data-testid='special-instructions'
          />
          <PaddingTop96 />
          <Line type='primary' />
          <PaddingTop24 />
          <FieldsContainer>
            <FieldsCol>
              <DatePicker
                type='calendar'
                size='large'
                surface='light'
                label='Installation'
                dateFormat='MM/DD/YYYY'
                onChange={(e) => handleDate(e)}
                data-testid='followUpDate'
                disabled={disableCalendar}
                alwaysOpen={false}
                inactiveDates={inactiveDates}
                activeDates={activeDates}
                maxDate={maxDate}
                minDate={minDate}
              />
            </FieldsCol>
            <FieldsCol>
              {!disableCalendar && selectedDate && slotTime && slotTime?.length > 0 ? (
                <DropdownSelect
                  value={slotSelected}
                  label='Select a Time Slot'
                  onChange={(e) => handleSlotTime(e.target.value)}
                  error={false}
                  disabled={false}
                  readOnly={false}
                  inlineLabel={false}
                  width='100%'
                  required
                  data-testid='time-slot-dropdown'
                >
                  {slotTime && (
                    <option key='Select a Time Slot' value='Select a Time Slot' disabled='disabled'>
                      Select a Time Slot
                    </option>
                  )}
                  {slotTime &&
                    slotTime?.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                </DropdownSelect>
              ) : (
                <BodyWrapper>
                  <Body size='medium'>No appointments returned. Please choose another date.</Body>
                </BodyWrapper>
              )}
            </FieldsCol>
          </FieldsContainer>
          <PaddingTop24 />
          <Line type='primary' />
          <ButtonWrapper>
            <Button
              size='medium'
              width={160}
              disabled={disableContinue}
              onClick={handleContinue}
              data-testid='continue-btn'
            >
              Continue
            </Button>
          </ButtonWrapper>
        </ModalBody>
      </Modal>
    </>
  );
};
ScheduleAppointment.propTypes = {
  showscheduleAppointmentModal: PropTypes.bool,
  setShowScheduleAppointmentModal: PropTypes.func,
  lineInfo: PropTypes.object,
  cartHeader: PropTypes.object,
  closeAppointment: PropTypes.func,
  isIpad: PropTypes.bool,
};
export default ScheduleAppointment;
