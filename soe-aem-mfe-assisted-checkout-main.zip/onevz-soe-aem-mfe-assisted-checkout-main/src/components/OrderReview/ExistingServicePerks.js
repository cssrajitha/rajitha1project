import { useState } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { TileContainer } from '@vds/tiles';
import { TextLink } from '@vds/buttons';
import { Icon } from '@vds/icons';
import ServicePerksModal from './ServicePerksModal';
import { invokeTagging } from '../../utils/test-utils/utils';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR } from '../constants/constants';

const TileWrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
`;
const PriceWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  margin: 0 1rem 0.25rem 1rem;
  padding: 8px 0px;
  border-bottom: 1px solid #d8dada;
`;

const Title = styled.div`
  font-size: 20px;
  font-weight: 700;
  line-height: 1.25rem;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  letter-spacing: 0.03125rem;
  margin: 0px;
  text-decoration: none;
`;

const Value = styled.div`
  font-size: 20px;
  font-weight: 700;
  line-height: 1.25rem;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  letter-spacing: 0.03125rem;
  color: rgb(0, 0, 0);
  margin: 0px;
  text-decoration: none;
`;

const LinkWrapper = styled.div`
  text-align: left;
  padding-left: 1rem;
  padding-bottom: 1rem;
  margin-top: 2rem;
`;

const TileContainerWrapper = styled.div`
  [class^='OuterTileContainer'] {
    border-radius: 0px !important;
    height: 100%;
  }
`;

const InfoContainer = styled.div`
  display: flex;
  align-items: center;
  padding: 0px 10px 25px;
`;

const InfoText = styled.div`
  color: #959595;
  font-size: 15px;
  margin-left: 5px;
  font-family: BrandFont-Text, Arial, sans-serif;
`;

const InfoIcon = styled.div`
  cursor: default;
  &:hover {
    cursor: pointer;
  }
`;

const ExistingServicePerks = ({
  features,
  existingFeatures,
  newFeatures,
  oldFeatures,
  fpsReferences,
  existingFeaturesTitle,
  defaultImageLabel,
  fetchPriceSnapshotSubAccount,
  line,
  element,
  readOrderData,
}) => {
  const [isViewModalVisible, setisViewModalVisible] = useState(false);
  const readOrderMfeFFlag = JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.readOrderMfeFFlag === 'TRUE';
  const isFromReadOrder = sessionStorage.getItem('readOrder');
  const psLines = fetchPriceSnapshotSubAccount?.[0]?.lines.filter(({ mtn }) => mtn === line?.mobileNumber);
  const psLine = psLines?.length ? psLines[0] : null;
  const isAALOrEUP =
    psLine?.flags?.serviceInEffectLaterMsg &&
    ['AAL', 'AAL_LTE', 'AAL_5G', 'EUP'].includes(psLine?.flags?.lineActivityType);

  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;
  const bgColor = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.themeProps?.background;

  const handleViewDevices = () => {
    if (isFromReadOrder && readOrderMfeFFlag) {
      invokeTagging('openView', 'services&PerkDetails');
    } else {
      invokeTagging('openView', 'Line Level Features');
    }
    setisViewModalVisible(true);
  };

  const closeModal = () => {
    invokeTagging('closeView', '');
    setisViewModalVisible(false);
  };

  return (
    <>
      <TileContainerWrapper data-testId='ExistingServicePerks'>
        <TileContainer padding='0' height='auto' width='384px' surface={isDark ? 'dark' : 'light'}>
          <TileWrapper>
            <PriceWrapper>
              <Title
                style={{
                  color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                  backgroundColor: isDark ? bgColor : '',
                }}
              >{`+ ${existingFeatures?.length} ${existingFeaturesTitle}`}</Title>
              <Value> </Value>
            </PriceWrapper>

            {isAALOrEUP && (
              <TileContainer padding='1.5rem 0 0 0' height='auto' width='384px' surface={isDark ? 'dark' : 'light'}>
                <InfoContainer>
                  <InfoIcon>
                    <Icon name='info' size='small' color='grey' />
                  </InfoIcon>
                  <InfoText data-testId='view-serviceInEffectLaterMsg'>{psLine.flags.serviceInEffectLaterMsg}</InfoText>
                </InfoContainer>
              </TileContainer>
            )}

            <LinkWrapper>
              <TextLink
                type='standAlone'
                data-testId='view-devices'
                surface={isDark ? 'dark' : 'light'}
                disabled={false}
                size='small'
                onClick={() => {
                  handleViewDevices();
                }}
              >
                {' '}
                View
              </TextLink>
            </LinkWrapper>
          </TileWrapper>
        </TileContainer>
      </TileContainerWrapper>
      {isViewModalVisible && (
        <ServicePerksModal
          features={features}
          newFeatures={newFeatures}
          existingFeatures={existingFeatures}
          oldFeatures={oldFeatures}
          defaultImageLabel={defaultImageLabel}
          opened={isViewModalVisible}
          closeModal={closeModal}
          line={line}
          element={element}
          fpsReferences={fpsReferences}
          fetchPriceSnapshotSubAccount={fetchPriceSnapshotSubAccount}
          readOrderData={readOrderData}
        />
      )}
    </>
  );
};

ExistingServicePerks.propTypes = {
  features: PropTypes.any,
  existingFeatures: PropTypes.any,
  newFeatures: PropTypes.any,
  oldFeatures: PropTypes.any,
  fpsReferences: PropTypes.any,
  existingFeaturesTitle: PropTypes.string,
  defaultImageLabel: PropTypes.string,
  line: PropTypes.object,
  element: PropTypes.object,
  fetchPriceSnapshotSubAccount: PropTypes.array,
  readOrderData: PropTypes.object,
};

ExistingServicePerks.defaultProps = {
  existingFeaturesTitle: ' Existing Services & perks',
  defaultImageLabel: 'https://ss7.vzw.com/is/image/VerizonWireless/device_protection_120817?$pngalpha$',
};
export default ExistingServicePerks;
