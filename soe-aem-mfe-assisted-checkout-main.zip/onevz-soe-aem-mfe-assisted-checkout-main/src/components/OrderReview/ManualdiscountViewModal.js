import styled, { createGlobalStyle } from 'styled-components';
import { Modal } from '@vds/modals';
import { useState } from 'react';
import PropTypes from 'prop-types';
import ManualDiscountView from './ManualDiscountView';
import { themeSurface } from '../constants/constants';

const ModalWrapper = styled.div`
  background-color: #fff;
`;
const ComponentStyle = createGlobalStyle`

    [class^='ModalDialog-VDS'] {
      padding-top: 0;
      width: 100%;
      max-width: 1133px !important;
    }

    [class^='Overlay-VDS']{
    background: rgb(0 0 0 / 70%);
    }

    [id="close-button"]{
    opacity: 0;
    }

`;

const ManualDiscountViewModal = ({ value, handleToggle, cartDetails, refetchCartDetails  }) => {
  const [open] = useState(value);
  const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable || false; 
  return (
    <>
      <ComponentStyle />
      <ModalWrapper data-testid='discounts-modal'>
        <Modal
          surface={themeSurface()}
          disableAnimation={false}
          disableOutsideClick={scmUpgradeMfeEnable}
          fullScreenDialog={!scmUpgradeMfeEnable}
          {
            ...(scmUpgradeMfeEnable? {
              width:'80%' ,
              maxHeight: '90%'
            }: {
              width: '100%'
            })
          }
          ariaLabel='Manual Discount'
          opened={open}
          closeButton={null}
        >
          <ManualDiscountView refetchCartDetails={refetchCartDetails} cart={cartDetails?.cart} handleClose={handleToggle} />
        </Modal>
      </ModalWrapper>
    </>
  );
};

ManualDiscountViewModal.propTypes = {
  handleToggle: PropTypes.func,
  cartDetails: PropTypes.object,
  value: PropTypes.bool,
  refetchCartDetails : PropTypes.func,
};

export default ManualDiscountViewModal;
