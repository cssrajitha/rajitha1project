import { render, screen, fireEvent } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import StoreProvider from '../../modules/store';
import cartJson from '../../__mock__/cart.json';
import cart5GFlow from '../../__mock__/cart5GFlow.json';
import DevicesModal from './DevicesModal';
import { scmCheckoutMfeEnabled } from '../../utils/common';

const compteDPJson = {
  isSuccess: true,
  data: {
    firstMonthPrice: 28.64,
    remainingMonthPrice: 28.61,
    dpTerm: 36,
    downPayment: 200,
  },
};
jest.mock('../../utils/common');

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
  useLazyComputeDPPricesQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: compteDPJson,
    },
  ],
}));
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradlePropertyV2: () => ['TRUE'],
  }),
  { virtual: true }
);
describe('Devices Component', () => {
  const handlers = [
    rest.post(`*/devicepricingservice/computeDPPrices`, (req, res, ctx) =>
      res(ctx.status(200), ctx.json(compteDPJson))
    ),
  ];
  const server = setupServer(...handlers);
  scmCheckoutMfeEnabled.mockImplementation(() => false);
  const CustomerProfileRefetch = jest.fn();
  const CartDetailsRefetch = jest.fn();
  const fetchPriceSnapshotRefetch = jest.fn();
  const renderDeviceModel = (props = {}) => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const sbdOffer = line?.serviceInfo?.sbdOffer || [];
    const setMonthlyInstallmentAmount = jest.fn();
    // window.mfe = { scmCheckoutMfeEnable: true };

    render(
      <BrowserRouter>
        <StoreProvider>
          <DevicesModal
            line={line}
            element={element}
            opened
            sbdOffer={sbdOffer}
            setMonthlyInstallmentAmount={setMonthlyInstallmentAmount}
            closeModal={() => {}}
            CustomerProfileRefetch={CustomerProfileRefetch}
            CartDetailsRefetch={CartDetailsRefetch}
            fetchPriceSnapshotRefetch={fetchPriceSnapshotRefetch}
            readOrder
            landingInfo={{
              devicedata: {
                eSimEtniApi: true, // This ensures the condition is satisfied
              },
            }}
            {...props}
          />
        </StoreProvider>
      </BrowserRouter>
    );
  };

  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;

    server.listen();
  });
  afterAll(() => {
    server.close();
  });

  test('5G Flow', async () => {
    const line = cart5GFlow.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const { cart } = cart5GFlow.data;
    renderDeviceModel({ line, element, cart });
    const DoneBtn = screen.getByText(/Change Device/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
  });

  test('read order only flow > isCPCorFEA enabled', async () => {
    const line = { ...cart5GFlow.data.cart.lineDetails.lineInfo[0], lineActivityType: 'CPC' };
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const { cart } = cart5GFlow.data;
    renderDeviceModel({ line, element, cart });
    const DoneBtn = screen.getByText(/Change Device/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
  });
  test('read order only flow > isCpe enabled and simId enabled', async () => {
    const line = {
      ...cart5GFlow.data.cart.lineDetails.lineInfo[0],
      isCpe: true,
      itemsInfo: [
        {
          cartItems: {
            cartItem: [
              {
                cartItemType: 'SIM',
                simId: '12345ABC',
              },
              {
                cartItemType: 'DEVICE',
                deviceDetails: {
                  deviceID: '67890XYZ',
                },
              },
            ],
          },
        },
      ],
    };
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const { cart } = cart5GFlow.data;
    renderDeviceModel({ line, element, cart });
    const DoneBtn = screen.getByText(/Change Device/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
  });
  test('read order only flow > isCpe enabled and showSalesTaxInfo enabled', async () => {
    const line = {
      ...cart5GFlow.data.cart.lineDetails.lineInfo[0],
      isCpe: true,
      itemsInfo: [
        {
          cartItems: {
            cartItem: [
              {
                cartItemType: 'lol',
                simId: '12345ABC',
              },
              {
                cartItemType: 'DEVICE',
                depletionType: 'L',
                deviceDetails: {
                  deviceID: '67890XYZ',
                },
              },
            ],
          },
        },
      ],
    };
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const { cart } = cart5GFlow.data;
    renderDeviceModel({ line, element, cart });
    const DoneBtn = screen.getByText(/Change Device/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
  });
  test('read order only flow > isCpe enabled and showSalesTaxInfo enabled', async () => {
    const line = {
      ...cart5GFlow.data.cart.lineDetails.lineInfo[0],
      isCpe: true,
      itemsInfo: [
        {
          cartItems: {
            cartItem: [
              {
                cartItemType: 'lol',
                simId: '12345ABC',
              },
              {
                cartItemType: 'DEVICE',
                depletionType: 'H',
                deviceDetails: {
                  deviceID: '67890XYZ',
                },
              },
            ],
          },
        },
      ],
    };
    const element = { simId: '123' };
    const { cart } = cart5GFlow.data;
    renderDeviceModel({ line, element, cart });
    const DoneBtn = screen.getByText(/Change Device/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
  });
  test('read order false', async () => {
    const line = {
      ...cart5GFlow.data.cart.lineDetails.lineInfo[0],
      lineActivityType: 'CPC',
      isCpe: true,
      itemsInfo: [
        {
          cartItems: {
            cartItem: [
              {
                cartItemType: 'lol',
                simId: '12345ABC',
              },
              {
                cartItemType: 'DEVICE',
                depletionType: 'H',
                deviceDetails: {
                  deviceID: '67890XYZ',
                },
              },
            ],
          },
        },
      ],
    };
    const element = { simId: '123' };
    const { cart } = cart5GFlow.data;
    renderDeviceModel({ line, element, cart, readOrder: false });
  });
  test('read order false and without lineActivityType', async () => {
    const line = {
      ...cart5GFlow.data.cart.lineDetails.lineInfo[0],
      isCpe: true,
      itemsInfo: [
        {
          cartItems: {
            cartItem: [
              {
                cartItemType: 'lol',
                simId: '12345ABC',
              },
              {
                cartItemType: 'DEVICE',
                depletionType: 'H',
                deviceDetails: {
                  deviceID: '67890XYZ',
                },
              },
            ],
          },
        },
      ],
    };
    const element = { simId: '123' };
    const { cart } = cart5GFlow.data;
    renderDeviceModel({ line, element, cart, readOrder: false });
  });
  test('read order false and without lineActivityType', async () => {
    const line = {
      ...cart5GFlow.data.cart.lineDetails.lineInfo[0],
      isCpe: true,
      itemsInfo: [
        {
          cartItems: {
            cartItem: [
              {
                cartItemType: 'lol',
                simId: '12345ABC',
              },
              {
                cartItemType: 'DEVICE',
                depletionType: 'H',
                deviceDetails: {
                  deviceID: '67890XYZ',
                },
              },
            ],
          },
        },
      ],
    };
    const mockLandingInfo = {
      landingInfo: {
        devicedata: {
          eSimEtniApi: true, // This ensures the condition is satisfied
        },
      },
    };
    const element = { simId: '123' };
    const { cart } = cart5GFlow.data;
    renderDeviceModel({ line, element, cart, readOrder: false, mockLandingInfo });
  });
});
