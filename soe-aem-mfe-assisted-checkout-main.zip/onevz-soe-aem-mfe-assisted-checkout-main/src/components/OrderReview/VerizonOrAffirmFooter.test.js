import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import VerizonOrAffirmFooter from './VerizonOrAffirmFooter';
import StoreProvider from '../../modules/store';
import * as AgreementsAPICallHook from '../../modules/services/APIService/AgreementsAPICallHook';

jest.mock('./Affirm', () => ({
  __esModule: true,
  default: () => (
    <div>
      <button type='button' data-testid='mocked-giftcard-manual'>
        Mocked Gift card manual
      </button>
    </div>
  ),
}));

const props = {
  verizonVisaChecked: true,
  isAffirmFinance: true,
  affirmFinanceChecked: false,
  setAffirmFinanceChecked: jest.fn(),
  getOffersResults: { issacPromo: { proposition: { isDirectApply: false, rewardsEnrolled: true } } },
  cartDetailsResult: {
    data: {
      cart: {
        orderDetails: {
          accessoryFinancingOfferInfo: { customerEligible: true, offerAvailable: true },
          affirmFinancingOfferInfo: { offerAvailable: false },
        },
      },
    },
  },
  customerMtns: [],
  showAccessoryVvcModal: jest.fn(),
  setVerizonVisaChecked: jest.fn(),
  getCartDetailsDataBody: jest.fn(),
  getCustomerByMtns: jest.fn(),
};

const mockData = {
  updateAFOInfo: jest.fn(),
  UpdateAFOInfoResponse: {
    data: {},
  },
};

describe('', () => {
  test('Basic render', () => {
    render(
      <StoreProvider>
        <VerizonOrAffirmFooter {...props} />
      </StoreProvider>,
    );
  });
  test('Verizon checked', () => {
    jest.spyOn(AgreementsAPICallHook, 'default').mockImplementation(() => mockData);
    render(
      <StoreProvider>
        <VerizonOrAffirmFooter {...props} />
      </StoreProvider>,
    );
    const verizonvisaCheckboxtext = screen.getByText('Use the Verizon visa card for Accessory financing.');
    expect(verizonvisaCheckboxtext).toBeInTheDocument();
    fireEvent.click(verizonvisaCheckboxtext);
  });
  test('Verizon checked', () => {
    jest.spyOn(AgreementsAPICallHook, 'default').mockImplementation(() => mockData);
    window.mfe = {
      isProspectNewCustomerTab: true
    };
    render(
      <StoreProvider>
        <VerizonOrAffirmFooter {...props} />
      </StoreProvider>,
    );
    const accessoryOffers = screen.getByTestId('accessory-offers');
    expect(accessoryOffers).toBeInTheDocument();
  });
  test('Verizon See detail clicked', () => {
    jest.spyOn(AgreementsAPICallHook, 'default').mockImplementation(() => mockData);
    render(
      <StoreProvider>
        <VerizonOrAffirmFooter {...props} />
      </StoreProvider>,
    );
    const verizonvisaCheckboxtext = screen.getByText('Details');
    expect(verizonvisaCheckboxtext).toBeInTheDocument();
    fireEvent.click(verizonvisaCheckboxtext);
  });
  test('Affirm checked', () => {
    jest.spyOn(AgreementsAPICallHook, 'default').mockImplementation(() => mockData);
    render(
      <StoreProvider>
        <VerizonOrAffirmFooter {...props} />
      </StoreProvider>,
    );
    // const affirmCheckboxtext = screen.getByText('As low as 0% APR when you pay over time with affirm');
    // expect(affirmCheckboxtext).toBeInTheDocument();
    // fireEvent.click(affirmCheckboxtext);
  });
});
