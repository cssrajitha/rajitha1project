import styled, { createGlobalStyle } from 'styled-components';
import { Title } from '@vds/typography';
import { Modal, ModalTitle, ModalBody } from '@vds/modals';
import PropTypes from 'prop-types';
import { isEmpty } from 'lodash';
import { useEffect } from 'react';
import { formatCurrency, formatPhoneNumberWithSymbol, scmCheckoutMfeEnabled, useCradleState } from '../../utils/common';
import monthlyChargesApiCallHook from '../../pages/home/container/monthlyChargesApiCallHook';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR } from '../constants/constants';

const MarginSides = styled.div`
  padding: 0;
`;

const ModalContentWrapper = styled.div`
  display: flex;
  flex-direction: column;
`;

const PlanItemsWrapper = styled.div`
  border-top: 0.07143rem solid #d8dada;
  padding: 2rem;
  margin-right: 0 !important;
  margin-left: 0 !important;
`;

const ItemTitle = styled.div`
  font-size: 18px !important;
`;

const ItemTitleContainer = styled.div`
  padding-bottom: 0 !important;
  font-size: 18px;
  font-weight: bold !important;
  padding-right: 1.75rem !important;
  margin-top: 10px;
`;

const ItemContainer = styled.div`
  padding-right: 1.75rem !important;
  margin-top: 35px;
`;

const ItemLabel = styled.div`
  font-size: 18px;
  font-weight: bold;
`;

const ValueContainer = styled.div`
  font-size: 18px;
  padding-top: 0.5rem !important;
  display: flex;
  justify-content: space-between;
`;

const TotalContainer = styled(PlanItemsWrapper)`
  display: flex;
  justify-content: space-between;
  padding-right: 3.75rem !important;
`;

const MonthlyChargesModal = ({ opened, toggleModal, lineInfo }) => {
  const ComponentStyle = createGlobalStyle`
  #monthlyChargesModal {
    [class^='Overlay-VDS'] {
      width: ${scmCheckoutMfeEnabled() ? '76.5%' : 'inherit'};
    }
    [class^='Overlay-VDS'] {
      background-color: rgba(0, 0, 0, 0.8);
    }
    [class^='ModalDialog-VDS'] {
      max-width:${scmCheckoutMfeEnabled() ? '800px' : '1024px'};
      border-radius: 0;
      padding: 0;
    }
    [class^='ModalDialogWrapper-VDS'] {
        > span {
          width: 100%;
          height: 100%;

        > div {
          width:100% !important;
          height: 100% !important;

          > div {
            padding:0 !important;
          }
        }
      }
    }

    [class^='StyledModalBody-VDS'] {
      height: 80vh;
      padding: 0.7rem 0px 0px;
      overflow-y: auto;
    }

    [class^='IconWrapper-VDS'] {
      z-index: 99999;
    }
    
    [class^='StyledHeader-VDS'] {
      border-bottom: 1px solid #ccc;
      position: sticky;
      top:0;
      z-index: 999;
      padding: 1rem 2rem;
    }
    [class^='StyledFooter-VDS'] {
      border-top: 1px solid #ccc;
      position: sticky;
      bottom:0;
    }
  }
`;
  const { getOtherLineCharges, otherLineChargesResult } = monthlyChargesApiCallHook();
  const cradleState = useCradleState();
  const nbsFFlagState = cradleState?.data?.enablePartialNbsPosFFlag === "TRUE";  
  const isPartialNbs = nbsFFlagState || JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.enablePartialNbsPosFFlag === 'TRUE';
  const otherLineChrgs = otherLineChargesResult?.data || {};
  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;
  useEffect(() => {
    if (otherLineChargesResult.status === 'uninitialized' && lineInfo) {
      const filteredLines = lineInfo?.filter((line) => line.lineActivityType !== 'ACC');
      const mtns = filteredLines?.map((line) => line.mobileNumber).filter((item) => item);
      const payload = { cartId: '', mtns, unifiedNbsFlag: isPartialNbs };
      if (mtns.length) {
        getOtherLineCharges({ body: payload, spinner: false, mock: false });
      }
    }
  }, [lineInfo]);

  const displayMonthlyChargeItemType = (itemType) => {
    const definedItemTypes = {
      PLAN: 'Plan',
      EQUIPMENT: 'Equipment Charges',
      OCC: 'OCC Charges',
      NAF: 'Plan',
    };
    if (Object.keys(definedItemTypes).includes(itemType)) {
      return definedItemTypes[itemType];
    }
    return itemType;
  };

  return (
    <>
      <ComponentStyle isDark />
      <div data-testId='monthlyChargesModal'>
        <Modal
          id='monthlyChargesModal'
          opened={opened}
          fullScreenDialog
          surface={isDark ? 'dark' : 'light'}
          onOpenedChange={toggleModal}
          disableAnimation={false}
          disableOutsideClick={false}
          width='100%'
        >
          <MarginSides>
            <ModalTitle>
              <Title size='small' bold color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                {`Monthly Charges for your other ${otherLineChrgs?.mtnLevelChargeDetails?.length || 0} lines`}
              </Title>
            </ModalTitle>
            <ModalBody>
              <ModalContentWrapper>
                {otherLineChrgs?.mtnLevelChargeDetails?.map((item) => {
                  if (item?.monthlyCharges?.length || item?.oneTimeCharges?.length || item?.addOnsCharges?.length) {
                    return (
                      <PlanItemsWrapper
                        key={`planwrapper-${item?.mtn}`}
                        style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}
                      >
                        <ItemTitleContainer>
                          <ItemTitle tabIndex='0'>{formatPhoneNumberWithSymbol(item.mtn, '-')}</ItemTitle>
                        </ItemTitleContainer>

                        {item?.monthlyCharges?.map((monthlyCharge) => (
                          <ItemContainer key={monthlyCharge}>
                            <ItemLabel data-testId='itemType'>
                              {displayMonthlyChargeItemType(monthlyCharge.itemType)}
                            </ItemLabel>
                            <ValueContainer>
                              <div>{monthlyCharge.description}</div>

                              <ItemLabel data-testId='monthlyCharges'>
                                {formatCurrency(monthlyCharge.thisMonthCharge)}
                              </ItemLabel>
                            </ValueContainer>
                          </ItemContainer>
                        ))}

                        {item?.oneTimeCharges?.map((monthlyCharge) => (
                          <ItemContainer
                            key={monthlyCharge}
                            style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}
                          >
                            {item && !isEmpty(item.oneTimeCharges) && <ItemLabel>One-time charges</ItemLabel>}

                            <ValueContainer style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                              <div>{monthlyCharge.description}</div>

                              <ItemLabel
                                data-testId='oneTimeCharges'
                                style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}
                              >
                                {formatCurrency(monthlyCharge.thisMonthCharge)}
                              </ItemLabel>
                            </ValueContainer>
                          </ItemContainer>
                        ))}

                        {item?.addOnsCharges?.map((monthlyCharge) => (
                          <ItemContainer key={monthlyCharge}>
                            {item && !isEmpty(item.addOnsCharges) && <ItemLabel>Add-on charges</ItemLabel>}
                            <ValueContainer>
                              <div>{monthlyCharge.description}</div>

                              <ItemLabel data-testId='addOnsCharges'>
                                {formatCurrency(monthlyCharge.thisMonthCharge)}
                              </ItemLabel>
                            </ValueContainer>
                          </ItemContainer>
                        ))}
                      </PlanItemsWrapper>
                    );
                  }
                  return null;
                })}
                <TotalContainer style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                  <ItemLabel>Total</ItemLabel>
                  <ItemLabel data-testId='total-amount'>
                    {formatCurrency(otherLineChrgs?.totalOtherLinesCharges || 0)}
                  </ItemLabel>
                </TotalContainer>
              </ModalContentWrapper>
            </ModalBody>
          </MarginSides>
        </Modal>
      </div>
    </>
  );
};

MonthlyChargesModal.propTypes = {
  opened: PropTypes.object,
  toggleModal: PropTypes.func,
  lineInfo: PropTypes.array,
};

export default MonthlyChargesModal;
