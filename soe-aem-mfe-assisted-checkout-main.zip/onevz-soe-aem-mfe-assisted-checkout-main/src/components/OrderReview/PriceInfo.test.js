import { fireEvent, render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import Emitter from 'onevzsoemfeframework/Emitter';
import StoreProvider from '../../modules/store';
import retriveCartJson from '../../__mock__/retrive-cart.json';
import multiCartJson from '../../__mock__/cart_multiple.json';
import alternateMulti_cart from '../../__mock__/alternateMulti_cart';
import PriceInfo from './PriceInfo';
import { formatCurrency } from '../../utils/common';

jest.mock('./EditTradein', () => ({
  __esModule: true,
  default: ({ onRemove, closeModal }) => (
    <div>
      <button type='button' data-testid='mocked-giftcard-manual' onClick={onRemove}>
        Remove button
      </button>
      <button type='button' data-testid='mocked-giftcard-manual' onClick={closeModal}>
        close modal
      </button>
    </div>
  ),
}));

jest.mock('./CompareToCurrentPlan', () => ({
  __esModule: true,
  default: ({ compareToCurrentRequest }) => (
    <div>
      <button type='button' data-testid='mocked-comapreTocurrentRq-manual' onClick={compareToCurrentRequest}>
        load New Modal{' '}
      </button>
    </div>
  ),
}));

jest.mock('./PreviewBill', () => ({
  __esModule: true,
  default: ({ closeModal }) => (
    <div>
      <button type='button' data-testid='mocked-giftcard-manual' onClick={closeModal}>
        Close preview modal
      </button>
    </div>
  ),
}));

jest.mock('../../modules/services/APIService/GetNextBillSummary', () => () => ({
  // GetNextBillSummaryHook: () => ({
  getNextBillSummaryReq: jest.fn(),
  getNextBillSummaryRes: { data: { nbsVo: 1 } },
  // }),
}));

beforeAll(() => {
  sessionStorage.setItem(
    'APP_PROPERTIES',
    JSON.stringify({ readOrderMfeFFlag: 'TRUE', isCheckoutMFEFlowEnabled: 'TRUE' })
  );
});

describe('PriceInfo Component', () => {
  beforeAll(() => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
  });
  test('renders PriceInfo', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceInfo
            title='Subtotal due monthly'
            price='$5.00'
            address={{
              tradeInShippingType: 'return_store',
              tradeInType: 'home',
            }}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getAllByText(/Subtotal due monthly/i);
    expect(titleElement[0]).toBeInTheDocument();
  });

  test('Should redirect to shipping details Page once user click on link (view/edit)', () => {
    const {
      data: {
        cart: {
          lineDetails: { lineInfo },
        },
      },
    } = retriveCartJson;
    const [lineInfo1] = lineInfo;
    const { itemsInfo } = lineInfo1;
    const { shipping } = itemsInfo[0];
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceInfo
            title='Shipping'
            bgColor='white'
            price='$99.00'
            shippingAddress
            shippingDetails={shipping}
            cartDetails={multiCartJson}
            linkName='Edit'
            address={{
              tradeInShippingType: 'upsdrop-off_qrcode',
            }}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const link = screen.getByTestId('link');
    fireEvent.click(link);
    expect(window.location.href).toBeTruthy();
  });

  test('Should redirect to shipping details Page once user click on link (view/edit) - isQAFlow', () => {
    const {
      data: {
        cart: {
          lineDetails: { lineInfo },
        },
      },
    } = retriveCartJson;
    const [lineInfo1] = lineInfo;
    const { itemsInfo } = lineInfo1;
    const { shipping } = itemsInfo[0];
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceInfo
            title='Shipping'
            bgColor='white'
            price='$99.00'
            shippingAddress
            shippingDetails={shipping}
            cartDetails={multiCartJson}
            linkName='Edit'
            address={{
              tradeInShippingType: 'upsdrop-off_qrcode',
            }}
            isQAFlow
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const link = screen.getByTestId('link');
    fireEvent.click(link);
    expect(window.location.href).toBeTruthy();
  });

  test('Should redirect to shipping details Page once user click on link (view/edit) - isQAFlow - Pre order', () => {
    const {
      data: {
        cart: {
          lineDetails: { lineInfo },
        },
      },
    } = retriveCartJson;
    const [lineInfo1] = lineInfo;
    const { itemsInfo } = lineInfo1;
    const { shipping } = itemsInfo[0];
    const newCartJson = JSON.parse(JSON.stringify(multiCartJson));
    newCartJson.lineDetails.lineInfo[0].preOrBackOrder = true;
    newCartJson.lineDetails.lineInfo[0].itemsInfo[0].cartItems.cartItem[0].preBackDate = '2025/06/11';
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceInfo
            title='Shipping'
            bgColor='white'
            price='$99.00'
            shippingAddress
            shippingDetails={shipping}
            cartDetails={newCartJson}
            linkName='Edit'
            address={{
              tradeInShippingType: 'upsdrop-off_qrcode',
            }}
            isQAFlow
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const link = screen.getByTestId('link');
    fireEvent.click(link);
    expect(window.location.href).toBeTruthy();
  });

  test('alternate multi cart', () => {
    const {
      data: {
        cart: {
          lineDetails: { lineInfo },
        },
      },
    } = retriveCartJson;
    const [lineInfo1] = lineInfo;
    const { itemsInfo } = lineInfo1;
    const { shipping } = itemsInfo[0];
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceInfo
            title='Shipping'
            bgColor='white'
            price='$99.00'
            shippingAddress
            shippingDetails={shipping}
            cartDetails={alternateMulti_cart}
            linkName='Edit'
            address={{
              tradeInShippingType: 'prepaidlabel',
            }}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const link = screen.getByTestId('link');
    fireEvent.click(link);
    expect(window.location.href).toBeTruthy();
  });

  test('Preview your next bill modal open', () => {
    const {
      data: {
        cart: {
          orderDetails: { estimatedNextMonthCharge },
        },
      },
    } = retriveCartJson;
    const estimatedNextBill = estimatedNextMonthCharge;
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceInfo
            title='Estimated next bill'
            subtitle='estimated subtitle'
            price={formatCurrency(estimatedNextBill)}
            linkName='Preview your next bill'
            variant='blue'
            padding='0px'
            address={{
              tradeInType: 'home',
            }}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    const link = screen.getByText('Preview your next bill');
    fireEvent.click(link);
    expect(window.vzdl.page.detail).toEqual('Show NextBillSummary');
  });

  test('covering the balance line of code', () => {
    const estimatedNextBill = 243.23;
    const deviceCreditinfoData = [
      {
        appliedPrice: 12.0,
        equipCategory: 'sample',
      },
      {
        appliedPrice: 221.0,
        equipCategory: 'new sample',
      },
    ];
    const infoData = [
      {
        payment: 'Down payment',
        price: '$0.00',
        description: 'test',
        image: 'url',
        handleClick: jest.fn(),
        hideMonthly: true,
        id: 'test',
      },
      {
        payment: 'Upgrade fee',
        price: '$0.00',
        image: 'url2',
        handleClick: jest.fn(),
        hideMonthly: false,
        id: 'plan',
      },
    ];
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceInfo
            title='Device trade-in credit'
            price={formatCurrency(estimatedNextBill)}
            linkName='ViewPlans'
            variant='blue'
            padding='0px'
            titleWidth
            info={infoData}
            deviceCreditinfo={deviceCreditinfoData}
            address={{
              tradeInItems: [1, 2],
            }}
            readOrder
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const link = screen.getByText('View');
    fireEvent.click(link);
    const closeBtn = screen.getByText('Close preview modal');
    fireEvent.click(closeBtn);
    const removeBtn = screen.getByText('Remove button');
    fireEvent.click(removeBtn);
    const addBtn = screen.getByText('Add');
    fireEvent.click(addBtn);
  });
  test('covering the balance line of code', () => {
    const estimatedNextBill = 243.23;
    const deviceCreditinfoData = [
      {
        appliedPrice: 12.0,
        equipCategory: 'sample',
      },
      {
        appliedPrice: 221.0,
        equipCategory: 'new sample',
      },
    ];
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceInfo
            title='Device trade-in credit'
            price={formatCurrency(estimatedNextBill)}
            linkName='ViewPlans'
            variant='blue'
            padding='0px'
            onLinkClick={jest.fn()}
            deviceCreditinfo={deviceCreditinfoData}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const viewBtn = screen.getByText('View');
    fireEvent.click(viewBtn);
    const closeBtn = screen.getByText('close modal');
    fireEvent.click(closeBtn);
  });

  test('renders PriceInfo', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceInfo
            title='Subtotal due monthly'
            price='$5.00'
            address={{
              tradeInShippingType: 'return_store',
              tradeInType: 'home',
            }}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getAllByText(/Subtotal due monthly/i);
    expect(titleElement[0]).toBeInTheDocument();
  });
  test('renders PriceInfo', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: false, themeProps: { background: '#eeeeee' } };
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceInfo
            title='Subtotal due monthly'
            price='$5.00'
            address={{
              tradeInShippingType: 'return_store',
              tradeInType: 'home',
            }}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getAllByText(/Subtotal due monthly/i);
    expect(titleElement[0]).toBeInTheDocument();
  });
});
describe('PriceInfo Component with scmUpgradeMfeEnable flag', () => {
  beforeAll(() => {
    Object.defineProperty(window, 'mfe', {
      value: {
        scmUpgradeMfeEnable: true,
      },
    });
  });
  beforeEach(() => {
    window.mfe = { scmUpgradeMfeEnable: true };
  });

  test('Should redirect to shipping details Page once user click on link (view/edit)', () => {
    const {
      data: {
        cart: {
          lineDetails: { lineInfo },
        },
      },
    } = retriveCartJson;
    const [lineInfo1] = lineInfo;
    const { itemsInfo } = lineInfo1;
    const { shipping } = itemsInfo[0];
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceInfo
            title='Shipping'
            bgColor='white'
            price='$99.00'
            shippingAddress
            shippingDetails={shipping}
            cartDetails={multiCartJson}
            linkName='Edit'
            address={{
              tradeInShippingType: 'upsdrop-off_qrcode',
            }}
            onLinkClick={false}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const link = screen.getByTestId('link');
    fireEvent.click(link);
    Emitter.emit('CLOSE_SHIPPING_DETAILS_MODAL');
  });
});

describe('PriceInfo Component with onLinkClick', () => {
  beforeAll(() => {
    Object.defineProperty(window, 'mfe', {
      value: {
        scmUpgradeMfeEnable: true,
      },
    });
  });
  beforeEach(() => {
    window.mfe = { scmUpgradeMfeEnable: true };
  });

  test('Should redirect to shipping details Page once user click on link (view/edit)', () => {
    const {
      data: {
        cart: {
          lineDetails: { lineInfo },
        },
      },
    } = retriveCartJson;
    const [lineInfo1] = lineInfo;
    const { itemsInfo } = lineInfo1;
    const { shipping } = itemsInfo[0];
    const onLinkClick = jest.fn();
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceInfo
            title='Shipping'
            bgColor='white'
            price='$99.00'
            shippingAddress
            shippingDetails={shipping}
            cartDetails={multiCartJson}
            linkName='Edit'
            address={{
              tradeInShippingType: 'upsdrop-off_qrcode',
            }}
            onLinkClick={onLinkClick}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const link = screen.getByTestId('link');
    fireEvent.click(link);
  });
});
describe('PriceInfo Component with onLinkClick', () => {
  beforeAll(() => {
    Object.defineProperty(window, 'mfe', {
      value: {
        scmUpgradeMfeEnable: true,
      },
    });
  });
  beforeEach(() => {
    window.mfe = { scmUpgradeMfeEnable: false };
  });

  test('Should redirect to shipping details Page once user click on link (view/edit)', () => {
    const {
      data: {
        cart: {
          lineDetails: { lineInfo },
        },
      },
    } = retriveCartJson;
    const [lineInfo1] = lineInfo;
    const { itemsInfo } = lineInfo1;
    const { shipping } = itemsInfo[0];
    const onLinkClick = jest.fn();
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceInfo
            title='Shipping'
            bgColor='white'
            price='$99.00'
            shippingAddress
            shippingDetails={shipping}
            cartDetails={multiCartJson}
            linkName='Edit'
            address={{
              tradeInShippingType: 'upsdrop-off_qrcode',
            }}
            onLinkClick={onLinkClick}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const link = screen.getByTestId('link');
    fireEvent.click(link);
  });
  test('Plans redirectiont to readorer flow modal', () => {
    sessionStorage.setItem('readOrder', 'true');
    const {
      data: {
        cart: {
          lineDetails: { lineInfo },
        },
      },
    } = retriveCartJson;
    const [lineInfo1] = lineInfo;
    const { itemsInfo } = lineInfo1;
    const { shipping } = itemsInfo[0];
    const onLinkClick = jest.fn();
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceInfo
            title='Shipping'
            bgColor='white'
            price='$99.00'
            shippingAddress
            shippingDetails={shipping}
            cartDetails={multiCartJson}
            linkName='Edit'
            address={{
              tradeInShippingType: 'upsdrop-off_qrcode',
            }}
            onLinkClick={onLinkClick}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const link = screen.getByTestId('link');
    fireEvent.click(link);
    const comapreTocurrentRq = screen.getByTestId('mocked-comapreTocurrentRq-manual');
    fireEvent.click(comapreTocurrentRq);
  });
});
