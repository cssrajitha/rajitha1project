import React, { useState } from 'react';
import { Modal, ModalTitle, ModalBody } from '@vds/modals';
import { Body, Title } from '@vds/typography';
import { Button, TextLink } from '@vds/buttons';
import { isIpad } from 'onevzsoemfeframework/DomService';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import ComparePlans from './ComparePlans';
import { makeOpenViewCall, getCurrTabData, makeCloseViewCall } from '../../utils/viewPlan';
import { DARK_THEME_COLOR, DARK_SURFACE, DARK_THEME_BGCOLOR } from '../constants/constants';

const Footer = styled.div`
  padding: 0rem 0px 0.25rem 0.125rem;
  margin-top: -0.5rem;
`;
const PaddingRight4 = styled.span`
  padding-right: 0.25rem;
`;
const PaddingTop8 = styled.span`
  padding-right: 0.25rem;
`;

export default function CompareToCurrentPlan(props) {
  const {
    mtn = '',
    displayName = '',
    modelName = '',
    label = '',
    currentPlanDisplayName = '',
    CurrentPlanCost,
    selectedPlanName,
    selectedPlanCost,
    selectedPerks,
    propositionName,
    isDark,
  } = props;
  const totalSelectedPerks = Array.isArray(selectedPerks) && selectedPerks?.length > 0 ? selectedPerks?.length : '0';
  const [showModal, setShowModal] = useState(false);
  const modalChanged = (data) => {
    setShowModal(data);
    makeOpenViewCall(
      `${getCurrTabData(props?.selectedCustomize)} | ${
        label === 'OrderReview' ? 'View Plan Change' : 'Compare To Current Plan'
      }`,
    );
  };
  const closeModal = () => {
    setShowModal(false);
    makeCloseViewCall();
  };
  const toggleBtn = props?.viewPlanEnable && props?.lineType?.length > 0 && (
    <TextLink
      type='standAlone'
      tabIndex='0'
      size='small'
      ariaLabel='Compare To Current Plan'
      surface={isDark ? 'dark' : 'light'}
      onClick={() => {
        props?.compareToCurrentRequest();
      }}
      data-track={label === 'OrderReview' ? 'ViewPlans' : 'Compare To Current Plan'}
    >
      {' '}
      {label === 'OrderReview' ? 'ViewPlans' : 'Compare To Current Plan'}
    </TextLink>
  );
  return (
    <div className={`${isIpad() ? 'mobile' : ''}`}>
      <Modal
        toggleButton={toggleBtn}
        opened={showModal}
        surface={isDark ? DARK_SURFACE : 'light'}
        width='70vw'
        fullScreenDialog={isIpad()}
        disableFocusLock
        hideCloseButton={false}
        disableOutsideClick
        onOpenedChange={modalChanged}
      >
        <ModalTitle>
          <Title size='large' color={isDark ? DARK_THEME_COLOR : ''} primitive='span' bold>
            {label === 'OrderReview' ? 'View Plan Change' : 'Compare To Current Plan'}
          </Title>
        </ModalTitle>
        <ModalBody>
          <PaddingTop8>
            <PaddingRight4>
              <Title size='small' color={isDark ? DARK_THEME_COLOR : ''} primitive='span' bold>
                {`${displayName} |`}
              </Title>
            </PaddingRight4>
            <Body size='large' color={isDark ? DARK_THEME_COLOR : ''} primitive='span'>
              {mtn}
            </Body>
            <Body size='large' color='#6F7171'>
              {modelName || '-'}
            </Body>
          </PaddingTop8>
          {props?.ComparePlanAPIResponse && (
            <ComparePlans
              currentPlanDisplayName={currentPlanDisplayName}
              CurrentPlanCost={CurrentPlanCost}
              label={label}
              index={props.index}
              selectedPlanName={selectedPlanName}
              selectedPlanCost={selectedPlanCost}
              totalSelectedPerks={totalSelectedPerks}
              selectedPerks={selectedPerks}
              planIds={props?.compareCurrentReq}
              pricePlanId={props?.pricePlanId}
              recommendedpricePlanId={props?.recommendedpricePlanId}
              currentPlanIndex={props?.currentPlanIndex}
              selectedRecommended={props?.selectedRecommended}
              propositionName={propositionName}
              ComparePlanAPIResponse={props.ComparePlanAPIResponse}
              isDark={isDark}
            />
          )}
          <Footer>
            <Button
              use='primary'
              size='large'
              onClick={closeModal}
              data-track='comparetocurrentPlan_Close'
              tabIndex='0'
              aria-label='CompareToCurrentCloseModal'
              style={isDark && { backgroundColor: DARK_THEME_COLOR, color: DARK_THEME_BGCOLOR }}
            >
              Close
            </Button>
          </Footer>
        </ModalBody>
      </Modal>
    </div>
  );
}
CompareToCurrentPlan.propTypes = {
  mtn: PropTypes.any,
  displayName: PropTypes.string,
  modelName: PropTypes.string,
  label: PropTypes.any,
  compareCurrentReq: PropTypes.any,
  pricePlanId: PropTypes.any,
  recommendedpricePlanId: PropTypes.any,
  currentPlanIndex: PropTypes.any,
  selectedRecommended: PropTypes.any,
  index: PropTypes.any,
  currentPlanDisplayName: PropTypes.string,
  CurrentPlanCost: PropTypes.any,
  selectedPlanName: PropTypes.any,
  selectedPlanCost: PropTypes.any,
  selectedPerks: PropTypes.any,
  propositionName: PropTypes.string,
  ComparePlanAPIResponse: PropTypes.any,
  viewPlanEnable: PropTypes.bool,
  compareToCurrentRequest: PropTypes.func,
  selectedCustomize: PropTypes.any,
  isDark: PropTypes.bool,
  lineType: PropTypes.array,
};
