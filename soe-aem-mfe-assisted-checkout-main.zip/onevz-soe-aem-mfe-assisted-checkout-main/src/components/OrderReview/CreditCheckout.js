import React, { useState, useEffect } from 'react';
import './Credit.css';
import PropTypes from 'prop-types';
import Credit from 'onevzsoemfecommon/Credit';
import { useLazyGetCreditRefreshQuery } from 'onevzsoemfecommon/CommonService';
import { callOpenViewMFE } from '../../utils/tagging';
import orderreviewApiCallHook from '../../pages/home/container/orderreviewApiCallHook';

const CREDIT_STATE = {
  address: {
    streetName: '',
    streetNum: '',
    apt: '',
    city: '',
    state: '',
    zip: '',
    zip4: '',
  },
  creditInfo: {
    creditDetails: [],
  },
  eligibility: {
    programEligibleIndicator: null,
    programEligibilityText: '',
    inEligibleReason: '',
    deviceFinanceLimit: '',
    totalFinanceLimit: '',
    totalFinanceLimitRemaining: '',
  },
  numOfLines: null,
  processStep: '',
  showModal: false,
  isApplicationNumClicked: true,
  refreshCreditCounter: 0,
  callVikiBot: false,
  isVikiEnabled: false,
  isEIDDisabled: false,
  isFiveG: false,
  fiveGfwaSecurityDeposit: {},
};

const CreditCheckout = (props) => {
  const { CustomerProfileResult } = orderreviewApiCallHook();
  const [showCreditModal, setShowCreditModal] = useState(false); // change the default value
  const [getCreditRefresh, getCreditRefreshResult] = useLazyGetCreditRefreshQuery();

  const [bannerContent, setBannerContent] = useState();
  const [getCreditBanner, setCreditBanner] = useState(false);
  const [creditDataValue, setCreditDataValue] = useState(CREDIT_STATE);
  const [readOrderResp] = useState(props?.readOrderResponse);

  useEffect(() => {
    console.log('credit new props', props);
    getCreditRefresh({
      body: {
        creditApplicationNum: readOrderResp?.cart?.orderDetails?.orderList?.[0].creditApplication?.creditApplicationNum,
        orderNumber: readOrderResp?.cart?.orderDetails?.orderList?.[0]?.orderNumber || '',
      },
      mock: false,
    });
  }, []);

  useEffect(() => {
    const orderList = readOrderResp?.cart?.orderDetails?.orderList;
    const creditApplicationNumber =
      readOrderResp?.cart?.orderDetails?.orderList?.[0].creditApplication?.creditApplicationNum;
    CREDIT_STATE.creditInfo.creditInfoRetrievedFromCart = orderList;
    CREDIT_STATE.creditInfo.creditApplicationNum = creditApplicationNumber;

    let BannerContent = {
      message: '',
      status: '',
      isCreditRefresh: '',
      locationCode: '',
      creditApplicationNum: '',
      statusCode: '',
      statusMsg: '',
      creditData: '',
    };

    if (getCreditRefreshResult?.isSuccess && !getCreditRefreshResult?.isFetching) {
      const creditDataResponse = getCreditRefreshResult?.data;
      const creditResponseData = creditDataResponse?.[0]?.data?.credit;
      CREDIT_STATE.creditInfo.credit = creditResponseData;
      const creditDetailsInfo = [];
      creditDataResponse?.forEach((creditData) => {
        const { data: { credit } = {} } = creditData || {};
        const obj = {};
        obj.creditApplicationNum = credit?.creditApplicationNum ? credit?.creditApplicationNum : '';
        obj.creditApprovalStatus = credit?.creditApprovalStatus ? credit?.creditApprovalStatus : '';
        obj.creditStatusReason = credit?.creditStatusReason ? credit?.creditStatusReason : '';
        obj.securityDepositAmount = credit?.securityDepositAmount ? credit?.securityDepositAmount : '0';
        obj.fwaSecurityDepositAmount = credit?.fwaSecurityDepositAmount ? credit?.fwaSecurityDepositAmount : '0';
        obj.customerType = credit?.customerType ? credit?.customerType : '';
        obj.bussOrIndvCustomer = credit?.bussOrIndvCustomer ? credit?.bussOrIndvCustomer : '';
        obj.tokenizedssn = credit?.tokenizedssn ? credit?.tokenizedssn : '';
        obj.locationCode = credit?.locationCode ? credit?.locationCode : '';
        creditDetailsInfo.push(obj);
      });
      CREDIT_STATE.creditInfo.creditDetails = [...creditDetailsInfo];

      console.log(`CREDIT_STATE${JSON.stringify(CREDIT_STATE)}`);
      setShowCreditModal(true);
      commonTaggingActionHamburgerMenu();

      if (creditResponseData?.creditApprovalStatus) {
        let message = 'Credit application not approved ';
        let status = 'warning';
        let statusCode = `${creditResponseData.creditApprovalStatus}`;
        let isCreditRefresh = true;
        if (creditResponseData?.creditApprovalStatus === 'AP') {
          message = 'Credit application approved';
          status = 'success';
          statusCode = '(AP)';
          isCreditRefresh = false;
        }

        BannerContent = {
          message: message + statusCode,
          status: creditResponseData.creditStatusReason,
          isCreditRefresh,
          locationCode: creditResponseData.locationCode,
          creditApplicationNum: creditResponseData.creditApplicationNum,
          statusCode,
          statusMsg: status,
          creditData: creditResponseData,
        };
        setBannerContent(BannerContent);
        setCreditBanner(true);
      }
    }
    setCreditDataValue(CREDIT_STATE);
  }, [getCreditRefreshResult, readOrderResp]);

  const commonTaggingActionHamburgerMenu = () => {
    // This is used for MFE Tagging where we are making openview call
    const objOV = {
      channel: 'Order',
      detail: 'creditStatus',
      flow: 'EUP|read-order',
      name: 'orderReview',
      intent: 'Order',
      cartId: CustomerProfileResult?.data?.data?.customer?.cartid || '',
      accountNumber: CustomerProfileResult?.data?.data?.customer?.accountnumber || '',
    };
    callOpenViewMFE(objOV);
  };

  const viewCreditModal = () => {
    props.handleClose();
    setShowCreditModal(false);
  };

  return (
    <div>
      {showCreditModal && (
        <Credit
          landing={CustomerProfileResult}
          credit={creditDataValue}
          showCreditModal={showCreditModal}
          viewCreditModal={viewCreditModal}
          getBannerContent={bannerContent}
          getCreditBanner={getCreditBanner}
          customerConsent={readOrderResp?.cart?.orderDetails?.customerConsent}
          customerInfo={CustomerProfileResult?.data?.data?.customer}
        />
      )}
    </div>
  );
};

CreditCheckout.propTypes = {
  handleClose: PropTypes.func, // modal close function
  readOrderResponse: PropTypes.object, // read order response
};

export default CreditCheckout;
