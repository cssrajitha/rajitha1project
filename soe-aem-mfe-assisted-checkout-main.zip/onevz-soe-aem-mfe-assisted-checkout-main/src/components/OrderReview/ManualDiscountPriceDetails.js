import React, { useEffect, useRef, useState } from 'react';
import PropTypes from 'prop-types';
import { Body } from '@vds/typography';
import { TextLink } from '@vds/buttons';
import styled from 'styled-components';

import { formatCurrency } from '../../utils/common';
import PriceDetailsModal from './PriceDetailsModal';
import { DARK_THEME_BGCOLOR, DARK_THEME_COLOR, isDark } from '../constants/constants';

const TextLinkContainer = styled.div`
  margin: 14px 0px 0px 0px;
  font-family: BrandFont-Text, Arial, sans-serif;
  font-size: 14px;
`;

const Container = styled.div`
  position: relative;
`;

const isOnlyZero = (value) => typeof value === 'number' && value === 0;

function ManualDiscountPriceDetails({ item }) {
  const themeTextColor = isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR;
  const [showPriceDetails, setShowPriceDetails] = useState(false);
  const isTariffFee = item.itemType === 'TARIFF_FEE';
  const marketPrice = item.itemPrice;
  let offerPrice = item.itemPrice !== item.priceAfterDiscount;
  const discountPercentValue = item?.discountPercent || 0;
  const discountPercentAmount = discountPercentValue && (item.priceAfterDiscount * discountPercentValue) / 100;
  const discountAmountValue = Number(item?.discountAmount) || Number(discountPercentAmount) || 0;

  let displayPrice = offerPrice
    ? item.priceAfterDiscount - discountAmountValue
    : item?.discountedPrice || item?.priceAfterDiscount;

  // Fix discounted price for scm only
  if (window?.mfe?.scmUpgradeMfeEnable) {
    displayPrice = item?.discountedPrice || item?.priceAfterDiscount;

    if (isTariffFee) {
      offerPrice = item.discountedPrice > 0;
      displayPrice = item && item.discountedPrice && item.discountedPrice > 0 ? item.discountedPrice : item.itemPrice;
    }
  }

  const popupRef = useRef(null);
  const handleOutSideClick = (e) => {
    if (popupRef.current && !popupRef.current.contains(e.target)) {
      setShowPriceDetails(false);
    }
  };
  useEffect(() => {
    document.addEventListener('click', handleOutSideClick);
    return () => {
      document.removeEventListener('click', handleOutSideClick);
    };
  }, []);

  return (
    <div data-testid='manual-discount-price-details'>
      <span className={offerPrice || !!item.discountedPrice || isOnlyZero(item?.discountedPrice) ? 'strike' : ''}>
        <Body size='large' color={themeTextColor}>
          {formatCurrency(marketPrice)}
        </Body>
      </span>

      {(item?.discountedPrice || offerPrice || isOnlyZero(item?.discountedPrice)) &&
        (isOnlyZero(item?.discountedPrice) ? (
          <span>
            <Body size='large' color={themeTextColor}>
              {formatCurrency(0)}
            </Body>
          </span>
        ) : (
          <span>
            <Body size='large' color={themeTextColor}>
              {formatCurrency(displayPrice)}
            </Body>
          </span>
        ))}
      {offerPrice && (
        <Container>
          <TextLinkContainer>
            <TextLink
              data-testid='pricing-details'
              onClick={(e) => {
                e.stopPropagation();
                setShowPriceDetails(true);
              }}
            >
              Pricing details
            </TextLink>
          </TextLinkContainer>

          {showPriceDetails && (
            <div ref={popupRef}>
              <PriceDetailsModal marketPrice={marketPrice} item={item} />
            </div>
          )}
        </Container>
      )}
      <span>
        <Body size='large' color={themeTextColor}>
          Line {item.mtn}
        </Body>
      </span>
    </div>
  );
}

ManualDiscountPriceDetails.propTypes = {
  item: PropTypes.object,
};

export default ManualDiscountPriceDetails;
