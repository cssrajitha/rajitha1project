import { Provider } from 'react-redux';
import { configureStore } from '@reduxjs/toolkit';
import { screen, fireEvent } from '@testing-library/react';
import { render } from '../../utils/test-utils/renderHelper';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import CompareToCurrentPlan from './CompareToCurrentPlan';

import {
  newMock,
  newRespose,
  CloseCompareToConnectPlanFlow,
  CloseCompareToConnectPlanFlow1,
  ComparePlansNewMock,
} from '../../__mock__/CompareToCurrentPlanMock';

jest.mock('./ComparePlans', () => jest.fn(() => null));

jest.mock('../../utils/viewPlan');

const mockStore = configureStore({ reducer: rootReducer });
describe(`<CompareToCurrentPlan/> component mount`, () => {
  beforeEach(() => {
    render(
      <Provider store={mockStore}>
        <CompareToCurrentPlan {...newMock} />
      </Provider>,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });
  test('should mount', () => {});
  test('should test CompareToCurrentPlan', async () => {
    render(<CompareToCurrentPlan {...newMock} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should test Close CompareToCurrentPlan', async () => {
    CloseCompareToConnectPlanFlow.isDark = true;
    render(<CompareToCurrentPlan {...newMock} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should test Close CompareToCurrentPlan 1', async () => {
    CloseCompareToConnectPlanFlow1.isDark = true;
    render(<CompareToCurrentPlan {...ComparePlansNewMock} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('should test Close CompareToCurrentPlan 1', async () => {
    CloseCompareToConnectPlanFlow1.isDark = false;
    render(<CompareToCurrentPlan {...CloseCompareToConnectPlanFlow1} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
});

describe('CompareToCurrentPlan Component', () => {
  const mockProps = {
    mtn: '123456',
    displayName: 'Sample Plan',
    modelName: 'Model X',
    label: 'Compare',
    currentPlanDisplayName: 'Current Plan',
    CurrentPlanCost: 100,
    selectedPlanName: 'New Plan',
    selectedPlanCost: 120,
    selectedPerks: ['Perk1', 'Perk2'],
    propositionName: 'Proposition X',
    isDark: true,
    ComparePlanAPIResponse: { data: 'Sample Data' },
    compareToCurrentRequest: jest.fn(),
    viewPlanEnable: true,
    compareCurrentReq: ['Plan1', 'Plan2'],
    pricePlanId: '123',
    recommendedpricePlanId: '456',
    lineType: [1, 2, 3],
    currentPlanIndex: 1,
    selectedRecommended: false,
    selectedCustomize: 'Customize 1',
    index: 0,
  };

  const mockProps1 = {
    mtn: '123456',
    displayName: 'Sample Plan',
    modelName: 'Model X',
    label: 'OrderReview',
    currentPlanDisplayName: 'Current Plan',
    CurrentPlanCost: 100,
    selectedPlanName: 'New Plan',
    selectedPlanCost: 120,
    selectedPerks: ['Perk1', 'Perk2'],
    propositionName: 'Proposition X',
    isDark: true,
    lineType: [1, 2, 3],
    ComparePlanAPIResponse: newRespose,
    compareToCurrentRequest: jest.fn(),
    viewPlanEnable: true,
    compareCurrentReq: ['Plan1', 'Plan2'],
    pricePlanId: '123',
    recommendedpricePlanId: '456',
    currentPlanIndex: 1,
    selectedRecommended: false,
    selectedCustomize: 'Customize 1',
    index: 0,
  };

  test('renders the component with correct title', () => {
    render(<CompareToCurrentPlan {...mockProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    expect(screen.getByText('Compare To Current Plan')).toBeInTheDocument();
  });

  test('clicking toggle button calls compareToCurrentRequest', () => {
    render(<CompareToCurrentPlan {...mockProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    fireEvent.click(screen.getByText('Compare To Current Plan'));
    expect(mockProps.compareToCurrentRequest).toHaveBeenCalled();
  });

  test('modal opens and closes properly', async () => {
    render(<CompareToCurrentPlan {...mockProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    fireEvent.click(screen.getByText('Compare To Current Plan'));
  });
  test('clicking toggle button calls compareToCurrentRequest11', async () => {
    render(<CompareToCurrentPlan {...mockProps1} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    fireEvent.click(screen.getByText('ViewPlans'));
    expect(mockProps1.compareToCurrentRequest).toHaveBeenCalled();
  });
});
