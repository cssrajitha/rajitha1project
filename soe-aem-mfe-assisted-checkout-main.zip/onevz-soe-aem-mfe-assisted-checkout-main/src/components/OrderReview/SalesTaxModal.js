import styled, { createGlobalStyle } from 'styled-components';
import { Title } from '@vds/typography';
import { Modal, ModalTitle, ModalBody } from '@vds/modals';
import PropTypes from 'prop-types';
import { TitleLockup } from '@vds/type-lockups';
import { formatCurrency } from '../../utils/common';
import { DARK_THEME_COLOR , DARK_THEME_BGCOLOR } from '../constants/constants';

const ComponentStyle = createGlobalStyle`
  #salesTaxModal {
    [class^='Overlay-VDS'] {
      background-color: rgba(0, 0, 0, 0.8);
    }
    [class^='ModalDialog-VDS'] {
      max-width:1024px; 
      border-radius: 0;
      padding: 0;
    }
    [class^='ModalDialogWrapper-VDS'] {
        > span {
          width: 100%;
          height: 100%;

        > div {
          width:100% !important;
          height: 100% !important;

          > div {
            padding:0 !important;
          }
        }
      }
    }

    [class^='IconWrapper-VDS'] {
      z-index: 99999;
      top: 5px;
    }

    [class^='StyledModalBody-VDS'] {
      height: 80vh;
      padding-top: 3rem;
    }

    [class^='StyledHeader-VDS'] {
      border-bottom: 1px solid #ccc;
      position: sticky;
      top:0;
      z-index: 999;
      padding: 1rem 0;
    }
  }
`;

const MarginSides = styled.div`
  padding: 0 1rem;
`;

const SubtotalWrappper = styled.div`
  margin-top: 20px;
  strong {
    font-size: 24px !important;
  }
`;

const PriceWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 0.25rem;
  padding: 0.5rem 0;
  font-size: 16px;
  span {
    display: flex;
    strong {
      margin-left: 5px;
    }
  }
  strong {
    display: flex;
    align-items: center;
    font-size: 18px;
    font-weight: bold;
    span {
      font-size: 18px;
      font-weight: bold;
      margin-right: 15px;
    }
  }
  button {
    font-size: 18px;
    font-weight: bold;
    border: 0;
    background: none;
    text-decoration: underline;
    color: #000;
    padding: 0;
    margin: 0 1rem 0 0;
  }
`;

const BorderBox = styled.div`
  margin-top: 15px;
  padding: 0.5rem 0;
  border-bottom: 1px solid #444;
`;

const SalesTaxModal = ({ opened, closeModal, salesTax, orderDetails }) => {
  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;
  const bgColor = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.themeProps?.background;
  const taxDescriptionLabel = (taxDetails) => {
    switch (taxDetails?.cartItemType?.toUpperCase()) {
      case 'UPGRADE_FEE':
        return ' on Upgrade Fee';
      case 'ACTIVATION_FEE':
        return ' on Activation Fee';
      case 'ACCESSORY':
        return ` on ${(taxDetails && taxDetails.deviceDisplayName) || ''} (${(taxDetails && taxDetails.qty) || ''})`;
      case 'SHIPPING':
        return ' on Shipping';
      default:
        return '';
    }
  };

  const taxSurchargeSubTotal = (taxDetails) => {
    let totalSurcharge = 0;
    taxDetails.forEach((item) => {
      if (item.taxDetailsList && item.taxDetailsList.length > 0) {
        totalSurcharge += item.taxDetailsList.reduce(
          (subtotal, acc) => parseFloat(acc.taxSurcharge === 'S' ? acc.taxAmount : 0) + subtotal,
          0,
        );
      }
    });

    return totalSurcharge;
  };

  return (
    <>
      <ComponentStyle />
      <div data-testId='salesTaxModal' style={{color:isDark?DARK_THEME_COLOR:DARK_THEME_BGCOLOR,backgroundColor:isDark?bgColor:''}}>
        <Modal
          id='salesTaxModal'
          fullScreenDialog
          opened={opened}
          surface={isDark ? 'dark' : 'light'}
          width='100%'
          disableAnimation={false}
          disableOutsideClick={false}
          onOpenedChange={(open) => {
            if (!open) closeModal();
          }}
        >
          <MarginSides>
            <ModalTitle surface={isDark ? 'dark' : 'light'}>
              <Title size='small' bold color={isDark?DARK_THEME_COLOR:DARK_THEME_BGCOLOR}>
                Sales Tax
              </Title>
            </ModalTitle>
            <ModalBody surface={isDark ? 'dark' : 'light'}>
              {salesTax &&
                salesTax.length > 0 &&
                salesTax.map(
                  (tax) =>
                    tax.taxDetails.length > 0 && (
                      <>
                        <TitleLockup
                          surface={isDark ? 'dark' : 'light'}
                          data={{
                            title: {
                              size: 'titleSmall',
                              children: `${tax.mobileNumber.slice(0, 6).replace(/(\d{3})/g, '$1-')} 
                               ${tax.mobileNumber && tax.mobileNumber.slice(6)}`,
                              bold: true,
                            },
                          }}
                        />
                        <TitleLockup
                          surface={isDark ? 'dark' : 'light'}
                          data={{
                            title: {
                              size: 'titleSmall',
                              children: 'Equipment Charges',
                              bold: true,
                            },
                          }}
                        />
                        <BorderBox>
                          {tax.taxDetails.map((taxDetails) =>
                            taxDetails.taxDetailsList.map((taxDetail) => (
                              <PriceWrapper key={taxDetail} isDark>
                                <span>
                                  {taxDetail.taxDescription} {taxDescriptionLabel(taxDetails)}
                                </span>
                                <span>{formatCurrency(taxDetail.taxAmount)}</span>{' '}
                              </PriceWrapper>
                            )),
                          )}

                          <PriceWrapper isDark>
                            <strong>Sub Total</strong>
                            <strong>{formatCurrency(tax.subTotal - taxSurchargeSubTotal(tax.taxDetails))}</strong>
                          </PriceWrapper>
                        </BorderBox>
                      </>
                    ),
                )}

              <SubtotalWrappper>
                <PriceWrapper isDark>
                  <strong>Total</strong>
                  <strong>{formatCurrency(orderDetails.totalTaxAmount)}</strong>
                </PriceWrapper>
              </SubtotalWrappper>
            </ModalBody>
          </MarginSides>
        </Modal>
      </div>
    </>
  );
};

SalesTaxModal.propTypes = {
  opened: PropTypes.object,
  closeModal: PropTypes.func,
  salesTax: PropTypes.array,
  orderDetails: PropTypes.object,
};

export default SalesTaxModal;
