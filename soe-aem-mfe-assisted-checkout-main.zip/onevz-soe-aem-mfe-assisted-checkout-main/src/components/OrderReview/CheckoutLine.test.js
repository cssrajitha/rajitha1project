import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import CheckoutLine from './CheckoutLine';
import StoreProvider from '../../modules/store';
import cartJson from '../../__mock__/retrive-cart.json';
import cartPlanJson from '../../__mock__/retrieveCartPlan.json';
import fetchPriceSnapshotJSON from '../../__mock__/fetchPricingSnapshot.json';
import { getSetupAndGoCart } from '../../__mock__/setup-go-cart';

const mocksubmitUserInfoResponse = {
  status: 'fulfilled',
  endpointName: 'saveUserInfo',
  requestId: 'E-nSN_fOS1v3I0gaLCdo7',
  originalArgs: {
    body: {
      cartId: 'bc283b6c-7a9f-441e-bed0-e2ffd26c1753',
      intendType: 'EUP',
      lines: [
        {
          mtn: '2202388248',
          email: 'eadizzovigh@vzw.com',
          firstName: 'nnn',
        },
      ],
    },
    spinner: false,
    mock: false,
  },
  startedTimeStamp: 1712856915626,
  data: {
    meta: {
      timestamp: '1710824661931',
      cxpCorrelationId: '2024-03-19T05:04:21.+0000:b9ae6553d9d13da7:cxp-shopping-services-5d5668cdb-wl4kc:nssit3',
    },
    data: {
      cartId: '6f1c140d-a5bc-4768-86ea-3045502a413e',
    },
  },
  fulfilledTimeStamp: 1712856915672,
  isUninitialized: false,
  isLoading: false,
  isSuccess: true,
  isError: false,
  currentData: {
    meta: {
      timestamp: '1710824661931',
      cxpCorrelationId: '2024-03-19T05:04:21.+0000:b9ae6553d9d13da7:cxp-shopping-services-5d5668cdb-wl4kc:nssit3',
    },
    data: {
      cartId: '6f1c140d-a5bc-4768-86ea-3045502a413e',
    },
  },
  isFetching: false,
};

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradlePropertyV2: () => ['TRUE'],
  }),
  { virtual: true }
);

const setHideShippingDetailsMock = jest.fn();
jest.mock('../../utils/tagging');
describe('Checkout Details Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  test('renders CheckoutDetails', () => {
    const openDevice = jest.fn();
    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={cartJson.data.cart.lineDetails.lineInfo[0]}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName='test'
            openDeviceInformation={openDevice}
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            cart={cartJson.data}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getByTestId('checkoutLine');
    expect(titleElement).toBeInTheDocument();
  });

  test('renders only plan without device', () => {
    sessionStorage.setItem('isCLNRFlow', true);
    const openDevice = jest.fn();
    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={cartPlanJson.data.cart.lineDetails.lineInfo[0]}
            lineInfo={cartPlanJson.data.cart.lineDetails.lineInfo}
            customerName='test'
            openDeviceInformation={openDevice}
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            cart={cartPlanJson.data}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getByTestId('checkoutLine');
    expect(titleElement).toBeInTheDocument();
  });

  test('renders Buyout Amount', () => {
    const openDevice = jest.fn();
    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={cartJson.data.cart.lineDetails.lineInfo[0]}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName='test'
            openDeviceInformation={openDevice}
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            cart={cartJson.data}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const buyoutElement = screen.getByText(/Buyout Amount/i);

    expect(buyoutElement).toBeInTheDocument();
  });

  test('renders rebate offer', () => {
    const openDevice = jest.fn();
    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={cartJson.data.cart.lineDetails.lineInfo[0]}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName='test'
            openDeviceInformation={openDevice}
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            cart={cartJson.data}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const rebateElement = screen.getByText(/UATREBATETEST/i);

    expect(rebateElement).toBeInTheDocument();
  });

  it('renders editline information', async () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={cartJson.data.cart.lineDetails.lineInfo[0]}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName='test'
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            email='test@gmail.com'
            cart={cartJson.data}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const editlineTextLink = screen.getByTestId('edit-line-information');
    expect(editlineTextLink).toBeInTheDocument();
    fireEvent.click(editlineTextLink);
    await waitFor(() => {
      const firstNameLabel = screen.getByTestId('first-name-label');
      expect(firstNameLabel).toBeInTheDocument();
      const firstNameInput = screen.getByTestId('first-name-input');
      expect(firstNameInput).toBeInTheDocument();
      fireEvent.change(firstNameInput, { target: { value: 'name' } });
      expect(firstNameInput).toHaveValue('name');
      const emailLabel = screen.getByTestId('email-label');
      expect(emailLabel).toBeInTheDocument();
      const emailInput = screen.getByTestId('email-input');
      expect(emailInput).toBeInTheDocument();
      expect(emailInput).toHaveValue('abhisekh.patro@one.verizon.com');

      const cancelBtn = screen.getByTestId('cancel-btn');
      expect(cancelBtn).toBeInTheDocument();
      const saveBtn = screen.getByTestId('save-btn');
      expect(saveBtn).toBeInTheDocument();
      fireEvent.click(cancelBtn);
      expect(cancelBtn).not.toBeInTheDocument();
    });
  });

  it('renders editline information onclick save', async () => {
    window.mfe = { scmCheckoutMfeEnable: true };
    const mocksubmitUserInfFn = jest.fn();
    const mockGetCartRequest = jest.fn();
    const mockFetchPricing = jest.fn();
    const mockGetActiveMTN = jest.fn();
    const mockOrderReview = jest.fn();
    jest.mock('../../modules/services/APIService/InfoAPICallHook', () => ({
      __esModule: true,
      default: () => ({
        submitUserInfo: mocksubmitUserInfFn,
        getCartRequest: mockGetCartRequest,
        fetchPricingSnapRequest: mockFetchPricing,
        getActiveMTNRequest: mockGetActiveMTN,
        orderReviewRequest: mockOrderReview,
        submitUserInforSuccess: mocksubmitUserInfoResponse,
      }),
    }));

    const mockAddAppMessage = jest.fn();
    const mockClearAppMessage = jest.fn();
    jest.mock('onevzsoemfecommon/AppMessageActions', () => ({
      addAppMessage: mockAddAppMessage,
      clearAppMessages: mockClearAppMessage,
    }));

    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={cartJson.data.cart.lineDetails.lineInfo[0]}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName='test'
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            email='test@gmail.com'
            cart={cartJson.data}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const editlineTextLink = screen.getByTestId('edit-line-information');
    expect(editlineTextLink).toBeInTheDocument();
    fireEvent.click(editlineTextLink);
    await waitFor(() => {
      fireEvent.change(screen.getByTestId('first-name-input'), {
        target: { value: 'new value' },
      });
      const saveBtn = screen.getByTestId('save-btn');
      expect(saveBtn).toBeInTheDocument();
      fireEvent.click(saveBtn);
      setTimeout(() => {
        expect(mocksubmitUserInfFn).toHaveBeenCalledTimes(1);
        expect(mockFetchPricing).toHaveBeenCalledTimes(1);
        expect(mockGetActiveMTN).toHaveBeenCalledTimes(1);
        expect(mockGetCartRequest).toHaveBeenCalledTimes(1);
        expect(mockOrderReview).toHaveBeenCalledTimes(1);
        expect(saveBtn).not.toBeInTheDocument();
        expect(mockAddAppMessage).toHaveBeenCalledTimes(1);
        setTimeout(() => {
          expect(mockClearAppMessage).toHaveBeenCalledTimes(1);
          expect(editlineTextLink).toBeInTheDocument();
        }, 3000);
      }, 3000);
    });
  });

  it('invalid name should not save', async () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={cartJson.data.cart.lineDetails.lineInfo[0]}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName='test'
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            email='test@gmail.com'
            cart={cartJson.data}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const editlineTextLink = screen.getByTestId('edit-line-information');
    expect(editlineTextLink).toBeInTheDocument();
    fireEvent.click(editlineTextLink);
    await waitFor(() => {
      fireEvent.change(screen.getByTestId('first-name-input'), {
        target: { value: 'new value 2' },
      });
      const saveBtn = screen.getByTestId('save-btn');
      expect(saveBtn).toBeInTheDocument();
      fireEvent.click(saveBtn);
    });
  });

  it('renders device lock information', async () => {
    global.window.vzdl = { page: { detail: '' } };
    window.mfe = { scmCheckoutMfeEnable: false };
    const { getByTestId } = render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={cartJson.data.cart.lineDetails.lineInfo[0]}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName='test'
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            cart={cartJson.data}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    const deviceLockinfoTextLink = getByTestId('device-lock-information');
    expect(deviceLockinfoTextLink).toBeInTheDocument();
    fireEvent.click(deviceLockinfoTextLink);
    setTimeout(async () => {
      const devicelockInfoModal = getByTestId('device-lock-info-modal');
      expect(devicelockInfoModal).toBeInTheDocument();
      expect(window.vzdl.page.detail).toEqual('Plans Detail');
      const backBtnModal = screen.getByTestId('btn-back');
      expect(backBtnModal).toBeInTheDocument();
      fireEvent.click(backBtnModal);
      global.window.vzdl = { page: { detail: '' } };
      await waitFor(() => {
        expect(deviceLockinfoTextLink).toBeInTheDocument();
      });
      expect(window.vzdl.page.detail).toEqual('');
    }, 2000);
  });

  test('Modal Change Devices click with mfe true', async () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={cartJson.data.cart.lineDetails.lineInfo[0]}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName='test'
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            email='test@gmail.com'
            cart={cartJson.data}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    // sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ isPDPMFEEnabled: 'TRUE' }));
    const DoneBtn = screen.getByTestId('mfe-true');
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
    expect(window.vzdl.page.detail).toEqual('Edit Device');
  });

  test('Modal Change Devices click with mfe true on read order', async () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={cartJson.data.cart.lineDetails.lineInfo[0]}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName='test'
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            email='test@gmail.com'
            cart={cartJson.data}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
            readOrder
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    const DoneBtn = screen.getByTestId('mfe-true');
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
  });

  test('Modal Change Devices click with mfe false', async () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={{
              ...cartJson.data.cart.lineDetails.lineInfo[0],
              installmentInfo: {
                ...cartJson.data.cart.lineDetails.lineInfo[0].installmentInfo,
                deviceDollarDownpayment: 1,
              },
              serviceInfo: null,
            }}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName='test'
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            email='test@gmail.com'
            cart={{ ...cartJson.data, orderDetails: { isPrePayCart: 'Y' } }}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    global.window.vzdl = { page: { detail: '' } };
    // sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ isPDPMFEEnabled: 'FALSE' }));
    const DoneBtn = screen.getByTestId('mfe-true');
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
    expect(window.vzdl.page.detail).toEqual('Edit Device');
  });

  test('On Click of Down Payment text', async () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={cartJson.data.cart.lineDetails.lineInfo[0]}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName='test'
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            email='test@gmail.com'
            cart={{ ...cartJson.data, orderDetails: { isPrePayCart: 'Y' } }}
            showDownpaymentView={jest.fn()}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const downPayment = screen.getByText('Down payment');
    fireEvent.click(downPayment, {});
    expect(downPayment).toBeInTheDocument();
  });

  test('If props is passed as empty and checking icon', async () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={{
              ...cartJson.data.cart.lineDetails.lineInfo[0],
              installmentInfo: {
                ...cartJson.data.cart.lineDetails.lineInfo[0].installmentInfo,
                deviceDollarDownpayment: 1,
                userSelectedDownPayment: 1,
              },
              serviceInfo: null,
              cartItems: { ...cartJson.data.cart.lineDetails.lineInfo[0] },
            }}
            lineInfo={undefined}
            customerName=''
            fetchPriceSnapshot={null}
            email=''
            cart={{}}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const icon = screen.getByTestId('upgrade-line-icon');
    expect(icon).toBeInTheDocument();
  });
  test('Should render setup and go', async () => {
    const line = {
      ...getSetupAndGoCart().data.cart.lineDetails.lineInfo[0],
      itemsInfo: [
        {
          cartItems: {
            cartItem: [
              ...getSetupAndGoCart().data.cart.lineDetails.lineInfo[0].itemsInfo[0].cartItems.cartItem,
              ...cartJson.data.cart.lineDetails.lineInfo[0].itemsInfo[0].cartItems.cartItem,
            ],
          },
        },
      ],
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={line}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName='test'
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            email='test@gmail.com'
            cart={{ ...cartJson.data, orderDetails: { isPrePayCart: 'Y' } }}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    expect(screen.getByText(/Setup & Go/i)).toBeInTheDocument();
    // expect(screen.getByText(/3000.99/i)).toBeInTheDocument();
  });
  it('Should render setup and go with discount price', async () => {
    const line = {
      ...getSetupAndGoCart(159.88).data.cart.lineDetails.lineInfo[0],
      itemsInfo: [
        {
          cartItems: {
            cartItem: [
              ...getSetupAndGoCart(159.88).data.cart.lineDetails.lineInfo[0].itemsInfo[0].cartItems.cartItem,
              ...cartJson.data.cart.lineDetails.lineInfo[0].itemsInfo[0].cartItems.cartItem,
            ],
          },
        },
      ],
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={line}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName='test'
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            email='test@gmail.com'
            cart={{ ...cartJson.data, orderDetails: { isPrePayCart: 'Y' } }}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    expect(screen.getByText(/159.88/i)).toBeInTheDocument();
  });

  test('renders Pre order estimated section', () => {
    const openDevice = jest.fn();
    const cartJsonMock = { ...cartJson.data.cart.lineDetails.lineInfo[0] };
    cartJsonMock.buySimOnly = true;
    cartJsonMock.ispuItem = undefined;
    cartJsonMock.itemsInfo[0].cartItems.cartItem[1] = {
      ...cartJsonMock.itemsInfo[0].cartItems.cartItem[1],
      inventoryStatus: { isPreOrder: true },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={cartJsonMock}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName='test'
            openDeviceInformation={openDevice}
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            cart={cartJson.data}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const preOrderText = screen.getByText(/Pre order estimated/);
    expect(preOrderText).toBeInTheDocument();
  });

  test('renders Back order estimated section', () => {
    const openDevice = jest.fn();
    const cartJsonMock = { ...cartJson.data.cart.lineDetails.lineInfo[0] };
    cartJsonMock.buySimOnly = true;
    cartJsonMock.ispuItem = undefined;
    cartJsonMock.itemsInfo[0].cartItems.cartItem[1] = {
      ...cartJsonMock.itemsInfo[0].cartItems.cartItem[1],
      inventoryStatus: { isBackorder: true },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={cartJsonMock}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName='test'
            openDeviceInformation={openDevice}
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            cart={cartJson.data}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const backOrderText = screen.getByText(/Back order estimated/);
    expect(backOrderText).toBeInTheDocument();
  });

  test('isDark true', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    const openDevice = jest.fn();
    const cartJsonMock = { ...cartJson.data.cart.lineDetails.lineInfo[0] };
    cartJsonMock.buySimOnly = true;
    cartJsonMock.ispuItem = undefined;
    cartJsonMock.itemsInfo[0].cartItems.cartItem[1] = {
      ...cartJsonMock.itemsInfo[0].cartItems.cartItem[1],
      inventoryStatus: { isBackorder: true },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={cartJsonMock}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName='test'
            openDeviceInformation={openDevice}
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            cart={cartJson.data}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const backOrderText = screen.getByText(/Back order estimated/);
    expect(backOrderText).toBeInTheDocument();
  });

  test('ISDFO true', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    const openDevice = jest.fn();
    const cartJsonMock = { ...cartJson.data.cart.lineDetails.lineInfo[0] };
    cartJsonMock.buySimOnly = true;
    cartJsonMock.ispuItem = undefined;
    cartJsonMock.itemsInfo[0].cartItems.cartItem[0].isDfoSelected = true;
    cartJsonMock.itemsInfo[0].cartItems.cartItem[0].eMIVerizonPayment = '23';
    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={cartJsonMock}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName='test'
            openDeviceInformation={openDevice}
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            cart={cartJson.data}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const backOrderText = screen.getByText(/Back order estimated/);
    expect(backOrderText).toBeInTheDocument();
  });
});
describe('Checkout Details Component 1', () => {
  it('renders editline information onclick save1', async () => {
    window.mfe = { scmCheckoutMfeEnable: false };
    const mocksubmitUserInfFn = jest.fn();
    const mockGetCartRequest = jest.fn();
    const mockFetchPricing = jest.fn();
    const mockGetActiveMTN = jest.fn();
    const mockOrderReview = jest.fn();
    jest.mock('../../modules/services/APIService/InfoAPICallHook', () => ({
      __esModule: true,
      default: () => ({
        submitUserInfo: mocksubmitUserInfFn,
        getCartRequest: mockGetCartRequest,
        fetchPricingSnapRequest: mockFetchPricing,
        getActiveMTNRequest: mockGetActiveMTN,
        orderReviewRequest: mockOrderReview,
        submitUserInforSuccess: mocksubmitUserInfoResponse,
      }),
    }));

    const mockAddAppMessage = jest.fn();
    const mockClearAppMessage = jest.fn();
    jest.mock('onevzsoemfecommon/AppMessageActions', () => ({
      addAppMessage: mockAddAppMessage,
      clearAppMessages: mockClearAppMessage,
    }));

    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={cartJson.data.cart.lineDetails.lineInfo[0]}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName='test'
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            email='test@gmail.com'
            cart={cartJson.data}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const editlineTextLink = screen.getByTestId('edit-line-information');
    expect(editlineTextLink).toBeInTheDocument();
    fireEvent.click(editlineTextLink);
    await waitFor(() => {
      fireEvent.change(screen.getByTestId('first-name-input'), {
        target: { value: 'new value' },
      });
      const saveBtn = screen.getByTestId('save-btn');
      expect(saveBtn).toBeInTheDocument();
      fireEvent.click(saveBtn);
      setTimeout(() => {
        expect(mocksubmitUserInfFn).toHaveBeenCalledTimes(1);
        expect(mockFetchPricing).toHaveBeenCalledTimes(1);
        expect(mockGetActiveMTN).toHaveBeenCalledTimes(1);
        expect(mockGetCartRequest).toHaveBeenCalledTimes(1);
        expect(mockOrderReview).toHaveBeenCalledTimes(1);
        expect(saveBtn).not.toBeInTheDocument();
        expect(mockAddAppMessage).toHaveBeenCalledTimes(1);
        setTimeout(() => {
          expect(mockClearAppMessage).toHaveBeenCalledTimes(1);
          expect(editlineTextLink).toBeInTheDocument();
        }, 3000);
      }, 3000);
    });
  });
});

describe('Checkout Details Component with scmupgrade flag', () => {
  beforeAll(() => {
    Object.defineProperty(window, 'mfe', {
      value: {
        scmUpgradeMfeEnable: true,
      },
    });
  });
  test('renders CheckoutDetails', () => {
    const openDevice = jest.fn();
    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={cartJson.data.cart.lineDetails.lineInfo[0]}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName='test'
            openDeviceInformation={openDevice}
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            cart={cartJson.data}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getByTestId('checkoutLine');
    expect(titleElement).toBeInTheDocument();
  });
});

describe('Checkout Details Component with tanglewoodSelected flag', () => {
  beforeAll(() => {
    global.window = Object.create(window);
  });
  beforeEach(() => {
    window.mfe = { scmDeviceMfeEnable: true };
    window.mfe.historyRef = jest.fn();
    window.mfe.historyRef.push = jest.fn();
    global.window.mfe = {
      scmCheckoutMfeEnable: true,
      isDark: true,
      themeProps: {
        background: '#000000',
      },
    };
    jest.clearAllMocks();
  });
  test('renders tanglewoodSelected', () => {
    const openDevice = jest.fn();
    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={cartJson.data.cart.lineDetails.lineInfo[0]}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName='test'
            openDeviceInformation={openDevice}
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            cart={cartJson.data}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getByTestId('checkoutLine');
    expect(titleElement).toBeInTheDocument();
  });
});

test('isDark true', () => {
  const openDevice = jest.fn();
  render(
    <BrowserRouter>
      <StoreProvider>
        <CheckoutLine
          line={cartJson.data.cart.lineDetails.lineInfo[0]}
          lineInfo={cartJson.data.cart.lineDetails.lineInfo}
          customerName='test'
          openDeviceInformation={openDevice}
          fetchPriceSnapshot={fetchPriceSnapshotJSON}
          cart={cartJson.data}
          setHideShippingDetails={setHideShippingDetailsMock}
          fetchPriceSnapshotRefetch={jest.fn()}
        />
      </StoreProvider>
    </BrowserRouter>
  );
  const titleElement = screen.getByTestId('checkoutLine');
  expect(titleElement).toBeInTheDocument();
});

test('calls callOpenViewMFE with correct object', () => {
  const openDevice = jest.fn();
  const callOpenViewMFE = jest.fn();
  sessionStorage.setItem('acssMfeCartId', 'testCartId');

  render(
    <BrowserRouter>
      <StoreProvider>
        <CheckoutLine
          line={cartJson.data.cart.lineDetails.lineInfo[0]}
          lineInfo={cartJson.data.cart.lineDetails.lineInfo}
          customerName='test'
          openDeviceInformation={openDevice}
          fetchPriceSnapshot={fetchPriceSnapshotJSON}
          cart={cartJson.data}
          setHideShippingDetails={setHideShippingDetailsMock}
          fetchPriceSnapshotRefetch={jest.fn()}
        />
      </StoreProvider>
    </BrowserRouter>
  );

  const editlineTextLink = screen.getByTestId('edit-line-information');
  fireEvent.click(editlineTextLink);

  const obj = {
    channel: 'Order',
    detail: 'activationStatus',
    flow: 'EUP|read-order',
    name: 'orderReview',
    intent: 'Order',
    cartId: 'testCartId',
    isAutoPayEnrolled: true,
    zip: '12345',
  };

  callOpenViewMFE(obj);

  expect(callOpenViewMFE).toHaveBeenCalledWith(obj);
});

test('read order edit line info', () => {
  const openDevice = jest.fn();
  sessionStorage.setItem('acssMfeCartId', 'testCartId');

  render(
    <BrowserRouter>
      <StoreProvider>
        <CheckoutLine
          line={cartJson.data.cart.lineDetails.lineInfo[0]}
          lineInfo={cartJson.data.cart.lineDetails.lineInfo}
          customerName='test'
          openDeviceInformation={openDevice}
          fetchPriceSnapshot={fetchPriceSnapshotJSON}
          cart={cartJson.data}
          setHideShippingDetails={setHideShippingDetailsMock}
          fetchPriceSnapshotRefetch={jest.fn()}
          readOrder
        />
      </StoreProvider>
    </BrowserRouter>
  );

  const editlineTextLink = screen.getByTestId('edit-line-information-read-order');
  fireEvent.click(editlineTextLink);
});

test('ISDFO false -> get Payment() true case', () => {
  window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
  const openDevice = jest.fn();
  const cartJsonMock = { ...cartJson.data.cart.lineDetails.lineInfo[0] };
  cartJsonMock.buySimOnly = true;
  cartJsonMock.ispuItem = undefined;
  cartJsonMock.itemsInfo[0].cartItems.cartItem[0].isDfoSelected = false;
  cartJsonMock.itemsInfo[0].cartItems.cartItem[0].eMIVerizonPayment = '23';
  render(
    <BrowserRouter>
      <StoreProvider>
        <CheckoutLine
          line={cartJsonMock}
          lineInfo={cartJson.data.cart.lineDetails.lineInfo}
          customerName='test'
          openDeviceInformation={openDevice}
          fetchPriceSnapshot={fetchPriceSnapshotJSON}
          cart={cartJson.data}
          setHideShippingDetails={setHideShippingDetailsMock}
          fetchPriceSnapshotRefetch={jest.fn()}
          readOrder
        />
      </StoreProvider>
    </BrowserRouter>
  );
  const backOrderText = screen.getByText(/Back order estimated/);
  expect(backOrderText).toBeInTheDocument();
});

test('ISDFO false -> get Payment() true case', () => {
  window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
  const openDevice = jest.fn();
  const cartJsonMock = { ...cartJson.data.cart.lineDetails.lineInfo[0] };
  cartJsonMock.buySimOnly = true;
  cartJsonMock.ispuItem = undefined;
  cartJsonMock.itemsInfo[0].cartItems.cartItem[0].isDfoSelected = false;
  cartJsonMock.itemsInfo[0].cartItems.cartItem[0].eMIVerizonPayment = '23';
  render(
    <BrowserRouter>
      <StoreProvider>
        <CheckoutLine
          line={cartJsonMock}
          lineInfo={cartJson.data.cart.lineDetails.lineInfo}
          customerName='test'
          openDeviceInformation={openDevice}
          fetchPriceSnapshot={fetchPriceSnapshotJSON}
          cart={cartJson.data}
          setHideShippingDetails={setHideShippingDetailsMock}
          fetchPriceSnapshotRefetch={jest.fn()}
          readOrder
        />
      </StoreProvider>
    </BrowserRouter>
  );
  const paymentType = screen.getByText(/Device Balance\/Device downpayment/);

  expect(paymentType).toBeInTheDocument();
});

test('ISDFO false -> get Payment() else case', () => {
  sessionStorage.setItem('channel', 'OMNI-INDIRECT');
  window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
  const openDevice = jest.fn();
  const cartJsonMock = { ...cartJson.data.cart.lineDetails.lineInfo[0] };
  cartJsonMock.buySimOnly = true;
  cartJsonMock.ispuItem = undefined;
  cartJsonMock.itemsInfo[0].cartItems.cartItem[0].isDfoSelected = false;
  cartJsonMock.itemsInfo[0].cartItems.cartItem[0].eMIVerizonPayment = '23';
  render(
    <BrowserRouter>
      <StoreProvider>
        <CheckoutLine
          line={cartJsonMock}
          lineInfo={cartJson.data.cart.lineDetails.lineInfo}
          customerName='test'
          openDeviceInformation={openDevice}
          fetchPriceSnapshot={fetchPriceSnapshotJSON}
          cart={cartJson.data}
          setHideShippingDetails={setHideShippingDetailsMock}
          fetchPriceSnapshotRefetch={jest.fn()}
          readOrder
        />
      </StoreProvider>
    </BrowserRouter>
  );
  const paymentType = screen.getByText(/Down payment/);

  expect(paymentType).toBeInTheDocument();
});

test('read activation status info', () => {
  const openDevice = jest.fn();
  sessionStorage.setItem('acssMfeCartId', 'testCartId');
  const readorderData = {
    activationDtls: [
      {
        mobileNumber: '5866349095',
        activationMessage: 'Not sent for activation',
      },
    ],
  };

  render(
    <BrowserRouter>
      <StoreProvider>
        <CheckoutLine
          line={cartJson.data.cart.lineDetails.lineInfo[0]}
          lineInfo={cartJson.data.cart.lineDetails.lineInfo}
          customerName='test'
          openDeviceInformation={openDevice}
          fetchPriceSnapshot={fetchPriceSnapshotJSON}
          cart={cartJson.data}
          setHideShippingDetails={setHideShippingDetailsMock}
          readOrder
          readOrderData={readorderData}
          fetchPriceSnapshotRefetch={jest.fn()}
        />
      </StoreProvider>
    </BrowserRouter>
  );
  fireEvent.click(screen.getByTestId('activation-view-link'));
});

test('read activation status info', () => {
  const openDevice = jest.fn();
  sessionStorage.setItem('acssMfeCartId', null);
  sessionStorage.setItem('cartId', null);
  const readorderData = {
    activationDtls: [
      {
        mobileNumber: '5866349095',
        activationMessage: 'test',
      },
    ],
  };

  render(
    <BrowserRouter>
      <StoreProvider>
        <CheckoutLine
          line={cartJson.data.cart.lineDetails.lineInfo[0]}
          lineInfo={cartJson.data.cart.lineDetails.lineInfo}
          customerName='test'
          openDeviceInformation={openDevice}
          fetchPriceSnapshot={fetchPriceSnapshotJSON}
          cart={cartJson.data}
          setHideShippingDetails={setHideShippingDetailsMock}
          readOrder
          readOrderData={readorderData}
          fetchPriceSnapshotRefetch={jest.fn()}
        />
      </StoreProvider>
    </BrowserRouter>
  );
  fireEvent.click(screen.getByTestId('activation-view-link'));

});

describe('shouldAllowEdit visibility based on 5G eligibility and scmCheckoutMfeEnable', () => {
  const baseLine = JSON.parse(JSON.stringify(cartJson.data.cart.lineDetails.lineInfo[0]));

  test('scm true + is5GEligible true + retailAmount.itemPrice > 0 -> edit visible', () => {
    window.mfe = { scmCheckoutMfeEnable: true };
    const line = JSON.parse(JSON.stringify(baseLine));
    line.lineActivityType = 'AAL_5G';
    line.itemsInfo = [
      {
        cartItems: {
          cartItem: [{ priceType: 'MONTH_TO_MONTH', itemPrice: 150 }, ...line.itemsInfo[0].cartItems.cartItem],
        },
      },
    ];

    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={line}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName="test"
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            cart={cartJson.data}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    expect(screen.getByTestId('checkoutLine')).toBeInTheDocument();
    expect(screen.queryByTestId('edit-line-information')).toBeInTheDocument();
  });

  test('scm true + is5GEligible true + retailAmount.itemPrice === 0 -> edit NOT visible', () => {
    window.mfe = { scmCheckoutMfeEnable: true };
    const line = JSON.parse(JSON.stringify(baseLine));
    line.lineActivityType = 'AAL_5G';
    line.itemsInfo = [
      {
        cartItems: {
          cartItem: [{ priceType: 'MONTH_TO_MONTH', itemPrice: 0 }, ...line.itemsInfo[0].cartItems.cartItem],
        },
      },
    ];

    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={line}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName="test"
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            cart={cartJson.data}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    expect(screen.queryByTestId('edit-line-information')).toBeInTheDocument();
  });

  test('scm true + is5GEligible false (EUP) + retailAmount.itemPrice === 0 -> edit visible', () => {
    window.mfe = { scmCheckoutMfeEnable: true };
    const line = JSON.parse(JSON.stringify(baseLine));
    line.lineActivityType = 'EUP'; // not in 5G eligible list but in showDeviceAboveAccessory
    line.itemsInfo = [
      {
        cartItems: {
          cartItem: [{ priceType: 'MONTH_TO_MONTH', itemPrice: 0 }, ...line.itemsInfo[0].cartItems.cartItem],
        },
      },
    ];

    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={line}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName="test"
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            cart={cartJson.data}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    expect(screen.queryByTestId('edit-line-information')).toBeInTheDocument();
  });

  test('scm false + is5GEligible true + retailAmount.itemPrice === 0 -> edit visible (scm disabled path)', () => {
    window.mfe = { scmCheckoutMfeEnable: false };
    const line = JSON.parse(JSON.stringify(baseLine));
    line.lineActivityType = 'AAL_5G';
    line.itemsInfo = [
      {
        cartItems: {
          cartItem: [{ priceType: 'MONTH_TO_MONTH', itemPrice: 0 }, ...line.itemsInfo[0].cartItems.cartItem],
        },
      },
    ];

    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutLine
            line={line}
            lineInfo={cartJson.data.cart.lineDetails.lineInfo}
            customerName="test"
            fetchPriceSnapshot={fetchPriceSnapshotJSON}
            cart={cartJson.data}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    expect(screen.queryByTestId('edit-line-information')).toBeInTheDocument();
  });
});