import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import StoreProvider from '../../modules/store';
import EditTradein from './EditTradein';
import tradeinprops from './__mock__/tradeinprops.json';

jest.mock('onevzsoemfeframework/AssistedCradleService', () => ({
  getAssistedCradlePropertyV2: jest.fn(() => ['true']),
}));

// Mock isVbg (component uses isVbg directly, not useVbgDetection)
const mockIsVbg = jest.fn(() => false);
jest.mock('onevzsoemfeframework/VbgAemUtil', () => ({
  isVbg: () => mockIsVbg(),
}));

// Mock the UpdateTradein mutation
const mockUpdateTradein = jest.fn();
jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  useUpdateTradeInMutation: () => [mockUpdateTradein],
}));

// Mock VBG Detection utility
const mockUseVbgDetection = jest.fn(() => false);
jest.mock('../../utils/vbgDetection', () => ({
  useVbgDetection: () => mockUseVbgDetection(),
}));

// Mock react-router-dom
const mockNavigate = jest.fn();
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockNavigate,
}));

describe('EditTradein Component', () => {
  beforeEach(() => {
    getAssistedCradlePropertyV2.mockReturnValue(['true']);
    mockUseVbgDetection.mockReturnValue(false);
    mockIsVbg.mockReturnValue(false);
    mockNavigate.mockClear();
    mockUpdateTradein.mockClear();
    jest.clearAllMocks();
  });
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  it('renders EditTradein component with basic elements', async () => {
    const mockOnRemove = jest.fn();
    const mockUpdateTradinBody = jest.fn();

    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] };
    global.window.vzdl = { page: { detail: '' } };

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein
            opened
            cartInfo={tradeinprops.cartInfo}
            popupInfo={tradeinprops.popupInfo}
            addressPopup={tradeinprops.addressPopup}
            onRemove={mockOnRemove}
            updateTradinBody={mockUpdateTradinBody}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    // Test basic rendering
    const titleElement = screen.getByText('Device trade in');
    expect(titleElement).toBeInTheDocument();

    const removeElement = screen.getByLabelText('left-caret icon');
    expect(removeElement).toBeInTheDocument();
  });

  it('renders EditTradein with scmCheckoutMfeEnable false', async () => {
    const mockOnRemove = jest.fn();
    const mockUpdateTradinBody = jest.fn();

    window.mfe = { scmCheckoutMfeEnable: false };
    global.window.vzdl = { page: { detail: '' } };

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein
            opened
            cartInfo={tradeinprops.cartInfo}
            popupInfo={tradeinprops.popupInfo}
            addressPopup={tradeinprops.addressPopup}
            onRemove={mockOnRemove}
            updateTradinBody={mockUpdateTradinBody}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    // Test basic rendering
    const titleElement = screen.getByText('Device trade in');
    expect(titleElement).toBeInTheDocument();

    const removeElement = screen.getByLabelText('left-caret icon');
    expect(removeElement).toBeInTheDocument();
  });

  test('Modal done click', async () => {
    const mockOnRemove = jest.fn();
    const mockClose = jest.fn();
    const mockUpdateTradinBody = jest.fn();
    jest.mock('onevzsoemfecommon/Helpers', () => ({
      getUIContextPathBAU: jest.fn(() => {}),
    }));

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein
            opened
            cartInfo={tradeinprops.cartInfo}
            popupInfo={tradeinprops.popupInfo}
            addressPopup={tradeinprops.addressPopup}
            onRemove={mockOnRemove}
            closeModal={mockClose}
            updateTradinBody={mockUpdateTradinBody}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const DoneBtn = screen.getByText(/Done/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
    expect(window.vzdl.page.detail).toEqual('');
  });

  test('Modal done click', async () => {
    const mockOnRemove = jest.fn();
    const mockClose = jest.fn();
    const mockUpdateTradinBody = jest.fn();
    jest.mock('onevzsoemfecommon/Helpers', () => ({
      getUIContextPathBAU: jest.fn(() => {}),
    }));
    const tradeIncredit = {
      cartInfo: {
        cartHeader: {
          cartCreatorChannelId: 'OMNI-INDIRECT',
        },
      },
    };

    const cartInfo = {
      cartInfo: {
        cartHeader: {
          cartCreatorChannelId: 'OMNI-INDIRECT',
        },
        lineDetails: {
          lineInfo: [
            {
              itemsInfo: [
                {
                  cartItems: {
                    cartItem: {
                      cartItemType: 'DEVICE',
                      instantCreditAmountUsedForTaxes: 2.0,
                      instantCreditAmountUsed: 2.0,
                      creditForActivationfee: 2.0,
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein
            opened
            cartInfo={cartInfo}
            popupInfo={tradeinprops.popupInfo}
            addressPopup={tradeinprops.addressPopup}
            onRemove={mockOnRemove}
            closeModal={mockClose}
            updateTradinBody={mockUpdateTradinBody}
            tradeIncredit={tradeIncredit}
            handleToggle={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const DoneBtn = screen.getByText(/Done/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
    expect(window.vzdl.page.detail).toEqual('');
  });
});

describe('TradeSectionModal', () => {
  beforeEach(() => {
    getAssistedCradlePropertyV2.mockReturnValue(['true']);
  });

  const mockCloseModal = jest.fn();
  const mockTradeInItems = [
    {
      deviceId: '12345',
      imgUrl: 'https://example.com/device.jpg',
      deviceName: 'Device 1',
      equipModel: 'Model 1',
      recycleDeviceSku: 'SKU123',
      recycleDeviceOffer: {
        dppCredit: '20',
        bicCreditDpTerm: 24,
      },
      computedPrice: '100',
      tradeInAutoPull: false,
    },
  ];
  const mockTradeInDetail = {
    instantCreditAmount: 50,
    totalInstantCreditAmountForTaxes: 10,
    instantCreditAmountRemaining: 40,
  };
  const mockLineInfo = [
    {
      mobileNumber: '1234567890',
      itemsInfo: [
        {
          refundCartItems: {
            cartItem: [
              {
                cartItemType: 'DEVICE',
                description: 'Device Description',
                mobileNumber: '1234567890',
              },
            ],
          },
        },
      ],
    },
  ];

  const rfexType = 'refund';

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders the modal with title and close icon', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein
            opened
            closeModal={mockCloseModal}
            tradeInItemstrade={mockTradeInItems}
            tradeInDetailtrade={mockTradeInDetail}
            lineInfo={mockLineInfo}
            rfexType={rfexType}
            refundreadOrder
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  it('calls closeModal when the close icon is clicked', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein
            opened
            closeModal={mockCloseModal}
            tradeInItemstrade={mockTradeInItems}
            tradeInDetailtrade={mockTradeInDetail}
            lineInfo={mockLineInfo}
            rfexType={rfexType}
            refundreadOrder
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  it('renders trade-in items with correct details', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein
            opened
            closeModal={mockCloseModal}
            tradeInItemstrade={mockTradeInItems}
            tradeInDetailtrade={mockTradeInDetail}
            lineInfo={mockLineInfo}
            rfexType={rfexType}
            refundreadOrder
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  it('renders total trade-in credit and other details', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein
            opened
            closeModal={mockCloseModal}
            tradeInItemstrade={mockTradeInItems}
            tradeInDetailtrade={mockTradeInDetail}
            lineInfo={mockLineInfo}
            rfexType={rfexType}
            refundreadOrder
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  it('calls closeModal when the Done button is clicked', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein
            opened
            closeModal={mockCloseModal}
            tradeInItemstrade={mockTradeInItems}
            tradeInDetailtrade={mockTradeInDetail}
            lineInfo={mockLineInfo}
            rfexType={rfexType}
            refundreadOrder
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  it('handles items without dppCredit gracefully', () => {
    const itemsWithoutDppCredit = [
      {
        deviceId: '67890',
        imgUrl: 'https://example.com/device2.jpg',
        deviceName: 'Device 2',
        equipModel: 'Model 2',
        recycleDeviceSku: 'SKU456',
        computedPrice: '200',
        tradeInAutoPull: true,
      },
    ];

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein
            opened
            closeModal={mockCloseModal}
            tradeInItemstrade={itemsWithoutDppCredit}
            tradeInDetailtrade={mockTradeInDetail}
            lineInfo={mockLineInfo}
            rfexType={rfexType}
            refundreadOrder
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  it('handles items with cartItemType other than DEVICE gracefully', () => {
    const itemsWithNonDeviceCartItemType = [
      {
        deviceId: '67891',
        imgUrl: 'https://example.com/device3.jpg',
        deviceName: 'Accessory 1',
        equipModel: 'Model 3',
        recycleDeviceSku: 'SKU789',
        cartItemType: 'ACCESSORY', // Non-DEVICE cartItemType
        computedPrice: '300',
        tradeInAutoPull: true,
      },
    ];

    const lineInfoWithNonDeviceItems = [
      {
        mobileNumber: '9876543210',
        itemsInfo: [
          {
            refundCartItems: {
              cartItem: itemsWithNonDeviceCartItemType,
            },
          },
        ],
      },
    ];

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein
            opened
            closeModal={mockCloseModal}
            tradeInItemstrade={[]}
            tradeInDetailtrade={mockTradeInDetail}
            lineInfo={lineInfoWithNonDeviceItems}
            rfexType={rfexType}
            refundreadOrder
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  it('uses the default value of 24 for bicCreditDPTerm when it is undefined', () => {
    const itemsWithUndefinedBicCreditDpTerm = [
      {
        deviceId: '67892',
        imgUrl: 'https://example.com/device4.jpg',
        deviceName: 'Device 4',
        equipModel: 'Model 4',
        recycleDeviceSku: 'SKU456',
        recycleDeviceOffer: {
          dppCredit: '30',
        },
        computedPrice: '400',
        tradeInAutoPull: true,
      },
    ];

    const mockTradeInDetails = {};

    const lineInfoWithUndefinedBicCreditDpTerm = [
      {
        itemsInfo: [
          {
            refundCartItems: {
              cartItem: [
                {
                  cartItemType: 'DEVICE',
                },
              ],
            },
          },
        ],
      },
    ];

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein
            opened
            closeModal={mockCloseModal}
            tradeInItemstrade={itemsWithUndefinedBicCreditDpTerm}
            tradeInDetailtrade={mockTradeInDetails}
            lineInfo={lineInfoWithUndefinedBicCreditDpTerm}
            rfexType={rfexType}
            refundreadOrder
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });
});

// VBG Feature Tests - Testing the differences added in feature_VBG52388-1301_TradeIn
describe('EditTradein VBG Feature Tests', () => {
  beforeEach(() => {
    getAssistedCradlePropertyV2.mockReturnValue(['true']);
    jest.clearAllMocks();
    mockIsVbg.mockReturnValue(true); // default VBG true for this suite; individual tests can override
  });

  test('should use address.emailId when primary emailId is not available in quoteWithoutCredit path', async () => {
    const mockOnRemove = jest.fn();
    const mockUpdateTradinBody = jest.fn();
    mockUseVbgDetection.mockReturnValue(true); // legacy mock (component no longer uses) kept for safety
    mockIsVbg.mockReturnValue(true);

    // Create cartInfo with quoteWithoutCredit but no primary emailId, only address.emailId
    const cartInfoWithAddressEmail = {
      cartHeader: {
        cartId: 'test-cart-id-2',
        caseId: 'test-case-id-2',
        customerType: 'N',
        cartCreatorChannelId: 'OMNI-RETAIL',
      },
      orderDetails: {
        quoteWithoutCredit: true,
      },
      lineDetails: {
        lineInfo: [
          {
            serviceInfo: {
              primaryUserInfo: {
                // No direct emailId, only address.emailId
                address: {
                  emailId: 'address-test@example.com',
                },
              },
            },
          },
        ],
      },
    };

    const popupInfoWithDevice = [
      {
        deviceId: '987654321',
        equipModel: 'Test Device 2',
        appliedPrice: '200.00',
      },
    ];

    window.mfe = { scmCheckoutMfeEnable: true };
    global.window.vzdl = { page: { detail: '' } };

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein
            opened
            cartInfo={cartInfoWithAddressEmail}
            popupInfo={popupInfoWithDevice}
            onRemove={mockOnRemove}
            updateTradinBody={mockUpdateTradinBody}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    // Find and click the remove link
    const removeLink = screen.getByText('Remove');
    expect(removeLink).toBeInTheDocument();

    fireEvent.click(removeLink);

    // Verify that updateTradein was called with address.emailId as creditAppNum
    await waitFor(() => {
      expect(mockUpdateTradein).toHaveBeenCalledWith({
        body: {
          cartId: 'test-cart-id-2',
          caseId: 'test-case-id-2',
          deviceId: '987654321',
          action: 'REMOVE',
          intendType: 'NSE',
          intent: 'Upgrade',
          pageContext: 'TRADEIN',
          creditAppNum: 'address-test@example.com', // Should use address.emailId
        },
      });
    });
  });
  // Add this test in the 'EditTradein VBG Feature Tests' describe block
  it('should handle remove device when neither creditApplication nor quoteWithoutCredit is present', async () => {
    const mockOnRemove = jest.fn();
    mockUseVbgDetection.mockReturnValue(true);
    mockIsVbg.mockReturnValue(true);

    // Create cartInfo with NEITHER creditApplication NOR quoteWithoutCredit
    const minimalCartInfo = {
      cartHeader: {
        cartId: 'test-cart-id',
        caseId: 'test-case-id',
        customerType: 'N',
        cartCreatorChannelId: 'OMNI-RETAIL',
      },
      orderDetails: {
        // No orderList with creditApplication
        // No quoteWithoutCredit (explicitly set to false)
        quoteWithoutCredit: false,
      },
    };

    const popupInfoWithDevice = [
      {
        deviceId: '123456789',
        equipModel: 'Test Device',
        appliedPrice: '100.00',
      },
    ];

    window.mfe = { scmCheckoutMfeEnable: true };
    global.window.vzdl = { page: { detail: '' } };

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein opened cartInfo={minimalCartInfo} popupInfo={popupInfoWithDevice} onRemove={mockOnRemove} />
        </StoreProvider>
      </BrowserRouter>,
    );

    // Find and click the remove link
    const removeLink = screen.getByText('Remove');
    expect(removeLink).toBeInTheDocument();

    fireEvent.click(removeLink);

    // Verify that updateTradein was called with undefined creditAppNum
    await waitFor(() => {
      expect(mockUpdateTradein).toHaveBeenCalledWith({
        body: {
          cartId: 'test-cart-id',
          caseId: 'test-case-id',
          deviceId: '123456789',
          action: 'REMOVE',
          intendType: 'NSE',
          intent: 'Upgrade',
          pageContext: 'TRADEIN',
          creditAppNum: undefined, // This should be undefined since both conditions are false
        },
      });
    });
  });
  it('should apply VBG device limit (10) when customer is VBG', async () => {
    mockUseVbgDetection.mockReturnValue(true);
    mockIsVbg.mockReturnValue(true);

    const tenDevices = Array.from({ length: 10 }, (_, i) => ({
      deviceId: `device${i + 1}`,
      equipModel: `Model ${i + 1}`,
      imgUrl: 'test.jpg',
      appliedPrice: 100,
      triageInfo: { triage: [] },
    }));

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein opened cartInfo={tradeinprops.cartInfo} popupInfo={tenDevices} closeModal={jest.fn()} />
        </StoreProvider>
      </BrowserRouter>,
    );

    await waitFor(() => {
      const button = screen.getByRole('button', { name: /Trade in more devices/i });
      expect(button).toBeDisabled();
    });
  });

  // UPDATED: non-VBG customers no longer have a hard device limit; button should remain enabled
  it('should NOT disable button at 5 devices when customer is not VBG and should navigate on click', async () => {
    mockUseVbgDetection.mockReturnValue(false);
    mockIsVbg.mockReturnValue(false);
    mockNavigate.mockClear();
    window.mfe = { scmCheckoutMfeEnable: false }; // ensure navigate is used

    const fiveDevices = Array.from({ length: 5 }, (_, i) => ({
      deviceId: `device${i + 1}`,
      equipModel: `Model ${i + 1}`,
      imgUrl: 'test.jpg',
      appliedPrice: 100,
      triageInfo: { triage: [] },
    }));

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein opened cartInfo={tradeinprops.cartInfo} popupInfo={fiveDevices} closeModal={jest.fn()} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const button = await screen.findByRole('button', { name: /Trade in more devices/i });
    expect(button).not.toBeDisabled();
    fireEvent.click(button);
    await waitFor(() => {
      expect(mockNavigate).toHaveBeenCalled();
    });
  });

  // NEW: confirm still enabled even well above former non-VBG limit
  it('should keep button enabled above 5 devices for non-VBG customers (regression check) and navigate on click', async () => {
    mockUseVbgDetection.mockReturnValue(false);
    mockIsVbg.mockReturnValue(false);
    mockNavigate.mockClear();
    window.mfe = { scmCheckoutMfeEnable: true };

    const twelveDevices = Array.from({ length: 12 }, (_, i) => ({
      deviceId: `device${i + 1}`,
      equipModel: `Model ${i + 1}`,
      imgUrl: 'test.jpg',
      appliedPrice: 100,
      triageInfo: { triage: [] },
    }));

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein opened cartInfo={tradeinprops.cartInfo} popupInfo={twelveDevices} closeModal={jest.fn()} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const button = await screen.findByRole('button', { name: /Trade in more devices/i });
    expect(button).not.toBeDisabled();
    fireEvent.click(button);
    window.mfe = { scmCheckoutMfeEnable: false };
  });

  it('should call handleRemove only for VBG customers', async () => {
    const mockOnRemove = jest.fn();
    mockUseVbgDetection.mockReturnValue(true);
    mockIsVbg.mockReturnValue(true);

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein
            opened
            cartInfo={{
              ...tradeinprops.cartInfo,
              cartHeader: {
                ...tradeinprops.cartInfo.cartHeader,
                cartCreatorChannelId: 'OMNI-RETAIL',
              },
            }}
            popupInfo={tradeinprops.popupInfo}
            onRemove={mockOnRemove}
            closeModal={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const removeButton = screen.getByText('Remove');
    fireEvent.click(removeButton);

    await waitFor(() => {
      expect(mockOnRemove).toHaveBeenCalledWith(tradeinprops.popupInfo[0]);
    });
  });

  it('should navigate to VBG trade-in page when VBG customer clicks "Trade in more devices"', async () => {
    mockUseVbgDetection.mockReturnValue(true);
    mockIsVbg.mockReturnValue(true);
    window.mfe = { scmCheckoutMfeEnable: false };

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein
            opened
            cartInfo={tradeinprops.cartInfo}
            popupInfo={[tradeinprops.popupInfo[0]]}
            closeModal={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const button = screen.getByText('Trade in more devices');
    fireEvent.click(button);

    await waitFor(() => {
      expect(button).toBeInTheDocument(); // Verify button interaction
    });
  });

  it('should navigate to regular trade-in page when non-VBG customer clicks "Trade in more devices"', async () => {
    mockUseVbgDetection.mockReturnValue(false);
    mockIsVbg.mockReturnValue(false);
    window.mfe = { scmCheckoutMfeEnable: false };

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein
            opened
            cartInfo={tradeinprops.cartInfo}
            popupInfo={[tradeinprops.popupInfo[0]]}
            closeModal={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const button = screen.getByText('Trade in more devices');
    fireEvent.click(button);

    await waitFor(() => {
      expect(button).toBeInTheDocument(); // Verify button interaction
    });
  });

  test('should handle remove device with quoteWithoutCredit scenario and extract emailId from serviceInfo', async () => {
    const mockOnRemove = jest.fn();
    const mockUpdateTradinBody = jest.fn();

    // Enable VBG customer for this test
    mockUseVbgDetection.mockReturnValue(true);
    mockIsVbg.mockReturnValue(true);

    // Create cartInfo with quoteWithoutCredit scenario and emailId in serviceInfo
    const cartInfoWithQuote = {
      cartHeader: {
        cartId: 'test-cart-id',
        caseId: 'test-case-id',
        customerType: 'N',
        cartCreatorChannelId: 'OMNI-RETAIL',
      },
      orderDetails: {
        quoteWithoutCredit: true, // This triggers the else if condition
      },
      lineDetails: {
        lineInfo: [
          {
            serviceInfo: {
              primaryUserInfo: {
                emailId: 'primary.user@test.com', // This should be extracted as cartCreatorNc
              },
            },
          },
        ],
      },
    };

    const popupInfoWithDevice = [
      {
        deviceId: '123456789',
        equipModel: 'Test Device',
        appliedPrice: '100.00',
      },
    ];

    window.mfe = { scmCheckoutMfeEnable: true };
    global.window.vzdl = { page: { detail: '' } };

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein
            opened
            cartInfo={cartInfoWithQuote}
            popupInfo={popupInfoWithDevice}
            onRemove={mockOnRemove}
            updateTradinBody={mockUpdateTradinBody}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    // Find and click the remove link
    const removeLink = screen.getByText('Remove');
    expect(removeLink).toBeInTheDocument();

    fireEvent.click(removeLink);

    // Verify the onRemove callback was called with the device
    await waitFor(() => {
      expect(mockOnRemove).toHaveBeenCalledWith(popupInfoWithDevice[0]);
    });

    // Verify notification appears
    expect(screen.getByText(/Device.*Removed Successfully/)).toBeInTheDocument();
  });

  test('should handle remove device with quoteWithoutCredit scenario and extract emailId from address', async () => {
    const mockOnRemove = jest.fn();
    const mockUpdateTradinBody = jest.fn();

    // Enable VBG customer for this test
    mockUseVbgDetection.mockReturnValue(true);
    mockIsVbg.mockReturnValue(true);

    // Create cartInfo with quoteWithoutCredit scenario and emailId in address
    const cartInfoWithQuote = {
      cartHeader: {
        cartId: 'test-cart-id',
        caseId: 'test-case-id',
        customerType: 'N',
        cartCreatorChannelId: 'OMNI-RETAIL',
      },
      orderDetails: {
        quoteWithoutCredit: true, // This triggers the else if condition
      },
      lineDetails: {
        lineInfo: [
          {
            serviceInfo: {
              primaryUserInfo: {
                // No emailId here, should fallback to address.emailId
                address: {
                  emailId: 'address.user@test.com', // This should be extracted as fallback
                },
              },
            },
          },
        ],
      },
    };

    const popupInfoWithDevice = [
      {
        deviceId: '987654321',
        equipModel: 'Test Device 2',
        appliedPrice: '200.00',
      },
    ];

    window.mfe = { scmCheckoutMfeEnable: true };
    global.window.vzdl = { page: { detail: '' } };

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein
            opened
            cartInfo={cartInfoWithQuote}
            popupInfo={popupInfoWithDevice}
            onRemove={mockOnRemove}
            updateTradinBody={mockUpdateTradinBody}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    // Find and click the remove link
    const removeLink = screen.getByText('Remove');
    expect(removeLink).toBeInTheDocument();

    fireEvent.click(removeLink);

    // Verify the onRemove callback was called with the device
    await waitFor(() => {
      expect(mockOnRemove).toHaveBeenCalledWith(popupInfoWithDevice[0]);
    });

    // Verify notification appears
    expect(screen.getByText(/Device.*Removed Successfully/)).toBeInTheDocument();
  });

  // Test case to cover the else condition in handleRemove (lines 523-525)
  it('should call onRemove without parameters when customer is not VBG', async () => {
    const mockOnRemove = jest.fn();
    const mockUpdateTradinBody = jest.fn();

    // Set VBG customer to false to trigger the else condition
    mockUseVbgDetection.mockReturnValue(false);
    mockIsVbg.mockReturnValue(false);

    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] };
    global.window.vzdl = { page: { detail: '' } };

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein
            opened
            cartInfo={tradeinprops.cartInfo}
            popupInfo={tradeinprops.popupInfo}
            addressPopup={tradeinprops.addressPopup}
            onRemove={mockOnRemove}
            updateTradinBody={mockUpdateTradinBody}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    // Find and click the Remove button
    const removeButton = screen.getByText('Remove');
    expect(removeButton).toBeInTheDocument();
    fireEvent.click(removeButton);

    // Verify that onRemove is called without parameters (else condition)
    await waitFor(() => {
      expect(mockOnRemove).toHaveBeenCalledWith(); // Called without parameters
      expect(mockOnRemove).toHaveBeenCalledTimes(1);
    });
  });

  // Test case to verify updateTradein API is not called for non-VBG customers
  it('should not call updateTradein API when customer is not VBG', async () => {
    const mockOnRemove = jest.fn();
    const mockUpdateTradinBody = jest.fn();

    // Set VBG customer to false
    mockUseVbgDetection.mockReturnValue(false);
    mockIsVbg.mockReturnValue(false);

    // Create a cartInfo with OMNI-RETAIL channel to ensure Remove button is visible
    const cartInfoWithRetail = {
      ...tradeinprops.cartInfo,
      cartHeader: {
        ...tradeinprops.cartInfo.cartHeader,
        cartCreatorChannelId: 'OMNI-RETAIL',
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein
            opened
            cartInfo={cartInfoWithRetail}
            popupInfo={tradeinprops.popupInfo}
            onRemove={mockOnRemove}
            updateTradinBody={mockUpdateTradinBody}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    // Click the Remove button
    const removeButton = screen.getByText('Remove');
    fireEvent.click(removeButton);

    // Verify that updateTradein API is NOT called for non-VBG customers
    await waitFor(() => {
      expect(mockUpdateTradein).not.toHaveBeenCalled();
      expect(mockOnRemove).toHaveBeenCalledWith(); // Called without device parameter
    });
  });

  // Test case to cover the "EUP" branch in intendType assignment (line 503)
  it('should set intendType to "EUP" when customerType is not "N" for VBG customer', async () => {
    const mockOnRemove = jest.fn();

    // Set VBG customer to true to enter the VBG handling logic
    mockUseVbgDetection.mockReturnValue(true);
    mockIsVbg.mockReturnValue(true);

    // Create cartInfo with customerType other than 'N' to trigger EUP branch
    const cartInfoWithExistingCustomer = {
      ...tradeinprops.cartInfo,
      cartHeader: {
        ...tradeinprops.cartInfo.cartHeader,
        cartCreatorChannelId: 'OMNI-RETAIL',
        customerType: 'E', // Existing customer, not 'N'
        cartId: 'test-cart-id',
        caseId: 'test-case-id',
      },
      orderDetails: {
        orderList: [
          {
            creditApplication: {
              creditApplicationNum: 'test-credit-app-num',
            },
          },
        ],
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein
            opened
            cartInfo={cartInfoWithExistingCustomer}
            popupInfo={tradeinprops.popupInfo}
            onRemove={mockOnRemove}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    // Click the Remove button to trigger handleRemove
    const removeButton = screen.getByText('Remove');
    fireEvent.click(removeButton);

    // Verify that updateTradein was called with intendType: 'EUP'
    await waitFor(() => {
      expect(mockUpdateTradein).toHaveBeenCalledWith({
        body: {
          cartId: 'test-cart-id',
          caseId: 'test-case-id',
          deviceId: tradeinprops.popupInfo[0].deviceId,
          action: 'REMOVE',
          intendType: 'EUP', // This should be 'EUP' since customerType is 'E'
          intent: 'Upgrade',
          pageContext: 'TRADEIN',
          creditAppNum: 'test-credit-app-num',
        },
      });
    });

    expect(mockOnRemove).toHaveBeenCalledWith(tradeinprops.popupInfo[0]);
  });

  // Test case to cover "EUP" branch with undefined customerType (defaults to 'N', but let's test explicit non-'N')
  it('should set intendType to "EUP" when customerType is explicitly set to existing customer types', async () => {
    const mockOnRemove = jest.fn();

    // Set VBG customer to true
    mockUseVbgDetection.mockReturnValue(true);
    mockIsVbg.mockReturnValue(true);

    // Test with various existing customer types that should result in 'EUP'
    const customerTypes = ['E', 'EXISTING', 'C', 'R'];

    // eslint-disable-next-line no-restricted-syntax
    for (const customerType of customerTypes) {
      const cartInfoWithCustomerType = {
        ...tradeinprops.cartInfo,
        cartHeader: {
          ...tradeinprops.cartInfo.cartHeader,
          cartCreatorChannelId: 'OMNI-RETAIL',
          customerType,
          cartId: 'test-cart-id',
          caseId: 'test-case-id',
        },
        orderDetails: {
          orderList: [
            {
              creditApplication: {
                creditApplicationNum: 'test-credit-app-num',
              },
            },
          ],
        },
      };

      render(
        <BrowserRouter>
          <StoreProvider>
            <EditTradein
              opened
              cartInfo={cartInfoWithCustomerType}
              popupInfo={tradeinprops.popupInfo}
              onRemove={mockOnRemove}
            />
          </StoreProvider>
        </BrowserRouter>,
      );

      // Click the Remove button
      const removeButton = screen.getByText('Remove');
      fireEvent.click(removeButton);

      // Verify intendType is 'EUP' for non-'N' customerType
      // eslint-disable-next-line no-await-in-loop
      await waitFor(() => {
        expect(mockUpdateTradein).toHaveBeenCalledWith({
          body: expect.objectContaining({
            intendType: 'EUP',
          }),
        });
      });

      // Clear mocks and unmount for next iteration
      mockUpdateTradein.mockClear();
      mockOnRemove.mockClear();
    }
  });

  // Test case to cover the else if path for quoteWithoutCredit (lines 493-497)
  it('should use emailId from quoteWithoutCredit path when VBG customer removes device', async () => {
    const mockOnRemove = jest.fn();

    // Set VBG customer to true to enter the VBG handling logic
    mockUseVbgDetection.mockReturnValue(true);
    mockIsVbg.mockReturnValue(true);

    // Create cartInfo with quoteWithoutCredit flag and emailId
    const cartInfoWithQuoteWithoutCredit = {
      ...tradeinprops.cartInfo,
      cartHeader: {
        ...tradeinprops.cartInfo.cartHeader,
        cartCreatorChannelId: 'OMNI-RETAIL',
        customerType: 'N',
        cartId: 'test-cart-id',
        caseId: 'test-case-id',
      },
      orderDetails: {
        quoteWithoutCredit: true, // This triggers the else if path
        // No creditApplication to ensure first if condition fails
      },
      lineDetails: {
        ...tradeinprops.cartInfo.lineDetails,
        lineInfo: [
          {
            ...tradeinprops.cartInfo.lineDetails.lineInfo[0],
            serviceInfo: {
              primaryUserInfo: {
                emailId: 'test@example.com', // This should be used as creditAppNum
              },
            },
          },
        ],
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein
            opened
            cartInfo={cartInfoWithQuoteWithoutCredit}
            popupInfo={tradeinprops.popupInfo}
            onRemove={mockOnRemove}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    // Click the Remove button to trigger handleRemove
    const removeButton = screen.getByText('Remove');
    fireEvent.click(removeButton);

    // Verify that updateTradein was called with emailId as creditAppNum
    await waitFor(() => {
      expect(mockUpdateTradein).toHaveBeenCalledWith({
        body: {
          cartId: 'test-cart-id',
          caseId: 'test-case-id',
          deviceId: tradeinprops.popupInfo[0].deviceId,
          action: 'REMOVE',
          intendType: 'NSE', // customerType is 'N'
          intent: 'Upgrade',
          pageContext: 'TRADEIN',
          creditAppNum: 'test@example.com', // Should use the emailId from quoteWithoutCredit path
        },
      });
    });
  });

  // Test case to cover the fallback to address.emailId in the else if path
  it('should use address.emailId when primary emailId is not available in quoteWithoutCredit path', async () => {
    const mockOnRemove = jest.fn();

    mockUseVbgDetection.mockReturnValue(true);

    // Create cartInfo with quoteWithoutCredit but no primary emailId, only address.emailId
    const cartInfoWithAddressEmail = {
      ...tradeinprops.cartInfo,
      cartHeader: {
        ...tradeinprops.cartInfo.cartHeader,
        cartCreatorChannelId: 'OMNI-RETAIL',
        customerType: 'N',
        cartId: 'test-cart-id-2',
        caseId: 'test-case-id-2',
      },
      orderDetails: {
        quoteWithoutCredit: true,
      },
      lineDetails: {
        ...tradeinprops.cartInfo.lineDetails,
        lineInfo: [
          {
            ...tradeinprops.cartInfo.lineDetails.lineInfo[0],
            serviceInfo: {
              primaryUserInfo: {
                // No direct emailId, only address.emailId
                address: {
                  emailId: 'address-test@example.com',
                },
              },
            },
          },
        ],
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein
            opened
            cartInfo={cartInfoWithAddressEmail}
            popupInfo={tradeinprops.popupInfo}
            onRemove={mockOnRemove}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    // Click the Remove button
    const removeButton = screen.getByText('Remove');
    fireEvent.click(removeButton);

    // Verify that updateTradein was called with address.emailId as creditAppNum
    await waitFor(() => {
      expect(mockUpdateTradein).toHaveBeenCalledWith({
        body: {
          cartId: 'test-cart-id-2',
          caseId: 'test-case-id-2',
          deviceId: tradeinprops.popupInfo[0].deviceId,
          action: 'REMOVE',
          intendType: 'NSE',
          intent: 'Upgrade',
          pageContext: 'TRADEIN',
          creditAppNum: 'address-test@example.com', // Should use address.emailId
        },
      });
    });
  });

  // Simple test specifically for EUP branch coverage
  it('should trigger EUP branch when customerType is not N', async () => {
    const mockOnRemove = jest.fn();
    mockUseVbgDetection.mockReturnValue(true);

    // Minimal cartInfo to trigger EUP
    const simpleCartInfo = {
      ...tradeinprops.cartInfo,
      cartHeader: {
        ...tradeinprops.cartInfo.cartHeader,
        cartCreatorChannelId: 'OMNI-RETAIL',
        customerType: 'E', // This should trigger EUP
      },
      orderDetails: {
        orderList: [
          {
            creditApplication: {
              creditApplicationNum: 'test123',
            },
          },
        ],
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <EditTradein opened cartInfo={simpleCartInfo} popupInfo={tradeinprops.popupInfo} onRemove={mockOnRemove} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const removeButton = screen.getByText('Remove');
    fireEvent.click(removeButton);

    // Just verify the API was called, focusing on intendType
    await waitFor(() => {
      expect(mockUpdateTradein).toHaveBeenCalledWith(
        expect.objectContaining({
          body: expect.objectContaining({
            intendType: 'EUP',
          }),
        }),
      );
    });
  });
});
