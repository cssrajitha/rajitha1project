import { render, screen, fireEvent } from '@testing-library/react';
import * as React from 'react';
import { BrowserRouter } from 'react-router-dom';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import CheckoutDetails from './CheckoutDetails';
import StoreProvider from '../../modules/store';
import cartJson from '../../__mock__/retrive-cart.json';
import customerJson from '../../__mock__/retrieve-customer.json';

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
  useLazyGetDeviceDetailsQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: { data: {} },
    },
  ],
}));

jest.mock('./CheckoutLine', () => ({
  __esModule: true,
  default: ({ showDownpaymentView }) => (
    <div>
      <button
        type='button'
        data-testid='downpyment-view'
        onClick={() => {
          showDownpaymentView({ productId: 123, skuId: 1233, mobileNumber: 1212122 }, true);
        }}
      >
        CheckoutLine mock
      </button>

      <button
        type='button'
        data-testid='show-downpyment'
        onClick={() => {
          showDownpaymentView({ productId: 123, skuId: 1233, mobileNumber: 1212122 }, false);
        }}
      >
        show-downpyment mock
      </button>

      <button
        type='button'
        data-testid='default-param-test'
        onClick={() => {
          showDownpaymentView();
        }}
      >
        show-downpyment mock
      </button>
    </div>
  ),
}));

jest.mock('onevzsoemfecommon/DownPaymentDevice', () => ({
  __esModule: true,
  default: ({ handleDPDone }) => (
    <div>
      <button
        type='button'
        data-testid='handleDPDone-button'
        onClick={() => {
          handleDPDone();
        }}
      >
        DownPaymentView mock
      </button>
    </div>
  ),
}));

jest.mock('onevzsoemfecommon/DownPaymentDevice', () => ({
  __esModule: true,
  default: ({ handleDPDone }) => (
    <div>
      <button
        type='button'
        data-testid='DownPaymentViewModal-view'
        onClick={() => {
          handleDPDone();
        }}
      >
        CheckoutLine mock
      </button>
    </div>
  ),
}));

describe('Checkout Details Component', () => {
  const handlers = [rest.post(`*/flexV2/customerProfile`, (req, res, ctx) => res(ctx.status(200)))];
  const server = setupServer(...handlers);
  const setHideShippingDetailsMock = jest.fn();
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  test('renders CheckoutDetails', () => {
    const openDevice = jest.fn();
    openDevice.mockReturnValueOnce(false);
    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutDetails
            cart={cartJson.data.cart}
            customer={customerJson.data.customer}
            openDeviceInformation={openDevice}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchDownPaymentResult={{ data: { fetchDownPaymentResponse: [{ mtn: 1234 }] } }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const downpymentView = screen.getAllByTestId('downpyment-view');
    fireEvent.click(downpymentView[0]);
    const titleElement = screen.getByTestId('checkoutDetail');
    expect(titleElement).toBeInTheDocument();
  });

  test('renders CheckoutDetails', () => {
    const openDevice = jest.fn();
    openDevice.mockReturnValueOnce(false);
    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutDetails
            cart={cartJson.data.cart}
            customer={customerJson.data.customer}
            openDeviceInformation={openDevice}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchDownPaymentResult={{ data: { fetchDownPaymentResponse: [{ mtn: 1234 }] } }}
            CustomerProfileRefetch={jest.fn()}
            CartDetailsRefetch={jest.fn()}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const downpymentView = screen.getAllByTestId('show-downpyment');
    fireEvent.click(downpymentView[0]);

    const titleElement = screen.getByTestId('checkoutDetail');
    expect(titleElement).toBeInTheDocument();
  });
  test('renders CheckoutDetails', () => {
    const openDevice = jest.fn();
    openDevice.mockReturnValueOnce(false);
    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutDetails
            cart={cartJson.data.cart}
            customer={customerJson.data.customer}
            openDeviceInformation={openDevice}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchDownPaymentResult={{ data: { fetchDownPaymentResponse: [{ mtn: 1234 }] } }}
            CustomerProfileRefetch={jest.fn()}
            CartDetailsRefetch={jest.fn()}
            fetchPriceSnapshotRefetch={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const downpymentView = screen.getAllByTestId('default-param-test');
    fireEvent.click(downpymentView[0]);

    const titleElement = screen.getByTestId('checkoutDetail');
    expect(titleElement).toBeInTheDocument();
  });
});

describe('Checkout Details Component with scmupgrade flag', () => {
  const handlers = [rest.post(`*/flexV2/customerProfile`, (req, res, ctx) => res(ctx.status(200)))];
  const server = setupServer(...handlers);
  const setHideShippingDetailsMock = jest.fn();
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
    server.listen();
  });
  afterAll(() => {
    server.close();
  });

  beforeEach(() => {
    window.mfe = { scmUpgradeMfeEnable: true };
  });

  test('renders CheckoutDetails without cart', () => {
    const openDevice = jest.fn();
    openDevice.mockReturnValueOnce(false);
    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutDetails
            customer={customerJson.data.customer}
            openDeviceInformation={openDevice}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchDownPaymentResult={{ data: { fetchDownPaymentResponse: [] } }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByTestId('checkoutDetail');
    expect(titleElement).toBeInTheDocument();
  });

  test('renders CheckoutDetails without cart line', () => {
    const openDevice = jest.fn();
    openDevice.mockReturnValueOnce(false);
    render(
      <BrowserRouter>
        <StoreProvider>
          <CheckoutDetails
            cart={{ lineDetails: {} }}
            customer={customerJson.data.customer}
            openDeviceInformation={openDevice}
            setHideShippingDetails={setHideShippingDetailsMock}
            fetchDownPaymentResult={{ data: { fetchDownPaymentResponse: [] } }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByTestId('checkoutDetail');
    expect(titleElement).toBeInTheDocument();
  });
});
