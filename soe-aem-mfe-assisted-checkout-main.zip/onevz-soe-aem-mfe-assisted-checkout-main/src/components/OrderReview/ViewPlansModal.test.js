import { render } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import { fireEvent, screen } from '../../utils/test-utils/renderHelper';
import StoreProvider from '../../modules/store';
import ViewPlansModal from './ViewPlansModal';
import planReferencesJson from '../../__mock__/planReferences.json';
import * as commonUtils from '../../utils/common';
import { useLazyGetReferencesQuery } from '../../modules/services/APIService/APIServiceHooks';
import * as AccountSectionAPICallHook from '../../modules/services/APIService/AccountSectionAPICallHook';

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
  useLazyGetReferencesQuery: jest.fn(),
}));
const mockNavigate = jest.fn();
jest.mock('../../utils/common');
jest.mock('react-router', () => ({
  ...jest.requireActual('react-router'),
  useNavigate: () => mockNavigate,
}));

describe('View Plans', () => {
  const mockGetReferences = jest.fn();
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
    server.listen();
  });

  beforeEach(() => {
    // const planId = 26872;
    // const isPrepay = false;
    // const planRefResp = planReferencesJson.data.planReferences;
    // const setPlanRefResp = jest.fn().mockReturnValue([planRefResp, {}]);
    // const setViewPlansModal = jest.fn().mockReturnValue([true, {}]);

    useLazyGetReferencesQuery.mockReturnValue([() => {}, { data: planReferencesJson, status: 'fulfilled' }]);
  });
  const pRefResp = planReferencesJson.data.planReferences;
  const handlers = [
    rest.post(`*/addonsservice/getReferences`, (req, res, ctx) => res(ctx.status(200), ctx.json(pRefResp))),
  ];

  const server = setupServer(...handlers);

  test('find screen elements in View Plans', () => {
    const planId = 26872;
    const isPrepay = false;
    const planRefResp = planReferencesJson.data.planReferences;
    const setPlanRefResp = jest.fn().mockReturnValue([planRefResp, {}]);
    const setViewPlansModal = jest.fn().mockReturnValue([true, {}]);
    render(
      <BrowserRouter>
        <StoreProvider>
          <ViewPlansModal
            opened
            planId={planId}
            isPrepay={isPrepay}
            setPlanRefResp={setPlanRefResp}
            planRefResp={planRefResp}
            setViewPlansModal={setViewPlansModal}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    expect(screen.getByTestId('viewPlans')).toBeInTheDocument();
    expect(screen.getByTestId('modal-close-button')).toBeInTheDocument();
    expect(screen.getByTestId('modal-footer')).toBeInTheDocument();
  });

  test('Modal Change Devices click', async () => {
    const planId = 26872;
    const isPrepay = false;
    const planRefResp = planReferencesJson.data.planReferences;
    const setPlanRefResp = jest.fn().mockReturnValue([planRefResp, {}]);
    const setViewPlansModal = jest.fn().mockReturnValue([true, {}]);
    // scmCheckoutMfeEnabled.mockImplementation(() => false);
    render(
      <BrowserRouter>
        <StoreProvider>
          <ViewPlansModal
            opened
            planId={planId}
            isPrepay={isPrepay}
            setPlanRefResp={setPlanRefResp}
            planRefResp={planRefResp}
            setViewPlansModal={setViewPlansModal}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const changePlanBtn = screen.getByText('Change Plan');
    expect(changePlanBtn).toBeInTheDocument();
    fireEvent.click(changePlanBtn, {});
    // expect(window.vzdl.page.detail).toEqual('Line Plan');
  });

  test('Modal done click', async () => {
    const planId = 26872;
    const isPrepay = false;
    const planRefResp = planReferencesJson.data.planReferences;
    const setPlanRefResp = jest.fn().mockReturnValue([planRefResp, {}]);
    const setViewPlansModal = jest.fn().mockReturnValue([true, {}]);
    render(
      <BrowserRouter>
        <StoreProvider>
          <ViewPlansModal
            opened
            planId={planId}
            isPrepay={isPrepay}
            setPlanRefResp={setPlanRefResp}
            planRefResp={planRefResp}
            setViewPlansModal={setViewPlansModal}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const DoneBtn = screen.getByText('Done');
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
    expect(window.vzdl.page.detail).toEqual('');
  });

  test('no modal created when api response not found', () => {
    const planId = 26872;
    const isPrepay = false;
    const planRefResp = undefined;
    const setPlanRefResp = jest.fn().mockReturnValue([planRefResp, {}]);
    const setViewPlansModal = jest.fn().mockReturnValue([true, {}]);
    // scmCheckoutMfeEnabled.mockImplementation(() => false);
    const container = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewPlansModal
            opened
            planId={planId}
            isPrepay={isPrepay}
            planRefResp={planRefResp}
            setPlanRefResp={setPlanRefResp}
            setViewPlansModal={setViewPlansModal}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    expect(container.childElementCount).toEqual(undefined);
  });

  test('Modal Change Plan click scm checkout flow', async () => {
    const planId = 26872;
    const isPrepay = false;
    const planRefResp = planReferencesJson.data.planReferences;
    const setPlanRefResp = jest.fn().mockReturnValue([planRefResp, {}]);
    const setViewPlansModal = jest.fn().mockReturnValue([true, {}]);
    window.mfe = { scmCheckoutMfeEnabled: true };
    window.Emitter = { emit: jest.fn() };
    const scmCheckoutMfeEnabledMock = jest.spyOn(commonUtils, 'scmCheckoutMfeEnabled');
    scmCheckoutMfeEnabledMock.mockReturnValue(true);
    render(
      <BrowserRouter>
        <StoreProvider>
          <ViewPlansModal
            opened
            planId={planId}
            isPrepay={isPrepay}
            setPlanRefResp={setPlanRefResp}
            planRefResp={planRefResp}
            setViewPlansModal={setViewPlansModal}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const changePlanBtn = screen.getByText('Change Plan');
    expect(changePlanBtn).toBeInTheDocument();
    fireEvent.click(changePlanBtn, {});
    // expect(window.vzdl.page.detail).toEqual('Line Plan');
  });

  test('isDark true', () => {
    const mockGetReferencesResult = () => ({
      data: {
        data: {
          planReferences: [
            {
              planId: '50427',
              monthlyAccessCharge: 60.0, // old
              description: 'oldDescription',
              displayName: 'oldDisplayName',
              featureText: 'oldFeatureText',
              dataOverageAllowance: '20',
              dataOverateAmount: '10',
              dataUnitOfMeasure: '2',
              imageUrlMap: { defaultImage: 'oldImageurl' },
            },
            {
              planId: '33333',
              monthlyAccessCharge: 70.0, // new
              description: 'newDescription',
              displayName: 'newDisplayName',
              featureText: 'newFeatureText',
              dataOverageAllowance: '30',
              dataOverateAmount: '15',
              dataUnitOfMeasure: '1',
              imageUrlMap: { defaultImage: 'newImageurl' },
            },
          ],
        },
      },
      status:'fulfilled',
    });
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] ,isDark: true, themeProps: {background: '#eeeeee'}};
    jest
      .spyOn(AccountSectionAPICallHook, 'default')
      .mockImplementation(() => ({ getReferences: mockGetReferences, getReferencesResult: mockGetReferencesResult() }));

    const planId = 26872;
    const isPrepay = false;
    const planRefResp = undefined;
    const setPlanRefResp = jest.fn().mockReturnValue([planRefResp, {}]);
    const setViewPlansModal = jest.fn().mockReturnValue([true, {}]);
    // scmCheckoutMfeEnabled.mockImplementation(() => false);
    const container = render(
      <BrowserRouter>
        <StoreProvider>
          <ViewPlansModal
            opened
            planId={planId}
            isPrepay={isPrepay}
            planRefResp={planRefResp}
            setPlanRefResp={setPlanRefResp}
            setViewPlansModal={setViewPlansModal}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    expect(container.childElementCount).toEqual(undefined);
  });
});
describe('View Plans', () => {
  beforeEach(() => {
    useLazyGetReferencesQuery.mockReturnValue([() => {}, { data: planReferencesJson, status: 'uninitialized' }]);
  });
  test('find screen elements in View Plans', () => {
    const planId = 26872;
    const isPrepay = false;
    const planRefResp = planReferencesJson.data.planReferences;
    const setPlanRefResp = jest.fn().mockReturnValue([{ ...planRefResp, planId: '', planTier: '' }, {}]);
    const setViewPlansModal = jest.fn().mockReturnValue([true, {}]);
    render(
      <BrowserRouter>
        <StoreProvider>
          <ViewPlansModal
            opened
            planId={planId}
            isPrepay={isPrepay}
            setPlanRefResp={setPlanRefResp}
            setViewPlansModal={setViewPlansModal}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });
});
describe('View Plans', () => {
  beforeEach(() => {
    useLazyGetReferencesQuery.mockReturnValue([
      () => {},
      {
        data: {
          data: { planReferences: [{ ...planReferencesJson.data.planReferences?.[0], planId: '', planTier: '' }] },
        },
        status: 'fulfilled',
      },
    ]);
  });
  test('find screen elements in View Plans', () => {
    const planId = 26872;
    const isPrepay = false;
    const planRefResp = planReferencesJson.data.planReferences;
    const setPlanRefResp = jest.fn().mockReturnValue([{ ...planRefResp, planId: '', planTier: '' }, {}]);
    const setViewPlansModal = jest.fn().mockReturnValue([true, {}]);
    render(
      <BrowserRouter>
        <StoreProvider>
          <ViewPlansModal
            opened
            planId={planId}
            isPrepay={isPrepay}
            setPlanRefResp={setPlanRefResp}
            setViewPlansModal={setViewPlansModal}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    expect(screen.getByTestId('viewPlans')).toBeInTheDocument();
    expect(screen.getByTestId('modal-close-button')).toBeInTheDocument();
    expect(screen.getByTestId('modal-footer')).toBeInTheDocument();
  });
});
