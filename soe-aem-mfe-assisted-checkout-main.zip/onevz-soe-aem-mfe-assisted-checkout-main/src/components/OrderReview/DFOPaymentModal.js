import styled from 'styled-components';
import { Line } from '@vds/lines';
import { Modal } from '@vds/modals';
import PropTypes from 'prop-types';
import { formatCurrency } from '../../utils/common';

const VVCTitle = styled.h2`
  font-size: 24px;
  font-weight: 600;
  margin-bottom: 10px;
`;

const DFOPay = styled.p`
  color: gray !important;
  font-size: 14px !important;
  margin: 0;
  margin-bottom: 10px;
`;
const Devices = styled.h2`
  margin-bottom: 6px;
  color: #000;
`;
const VVCDevice = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px !important;
`;

const VVCAmount = styled.div`
  font-weight: bold;
  color: #000000;
`;

const DFOPaymentModal = ({ opened, setShowDFOPaymentDetails, ...props }) => {
  const lineinfoList = props.dfoCart?.lineDetails?.lineInfo;
  const mtnNumberList =
    (props.dfoCart?.orderDetails?.accessoryFinancingOfferInfo?.splitPaymentInfo?.length > 0 &&
      props.dfoCart?.orderDetails?.accessoryFinancingOfferInfo?.splitPaymentInfo.map((item) => item.mtn)) ||
    [];
  const deviceLineInfo =
    lineinfoList &&
    lineinfoList.map((item) => {
      if (mtnNumberList.includes(item.mobileNumber)) {
        return item;
      }
      return null;
    });

  const totalVVCAmount =
    deviceLineInfo?.length > 0 &&
    deviceLineInfo.map((item) => {
      if (
        item?.itemsInfo?.length > 0 &&
        item?.itemsInfo[0].cartItems?.cartItem &&
        item?.itemsInfo[0].cartItems?.cartItem.length > 0
      ) {
        const returnObj = item.itemsInfo[0].cartItems.cartItem.filter((j) => j.cartItemType === 'DEVICE');
        if (returnObj?.length > 0) {
          const splitAmount =
            props.dfoCart?.orderDetails?.accessoryFinancingOfferInfo?.splitPaymentInfo?.length > 0 &&
            props.dfoCart?.orderDetails?.accessoryFinancingOfferInfo?.splitPaymentInfo.filter(
              (info) => info.mtn === returnObj[0].mobileNumber,
            );
          return {
            ...returnObj[0],
            splitValue: splitAmount?.length > 0 && splitAmount[0],
            servicezipcode: item?.serviceInfo?.serviceAddress,
          };
        }
      }
      return null;
    });

  const totalValue = totalVVCAmount?.length > 0 && totalVVCAmount.filter((item) => item !== null);

  const totalTaxAmout =
    totalValue?.length > 0 && totalValue?.reduce((acc, device) => acc + (device?.taxAmount || 0), 0);
  const EstZipcode = totalValue?.length > 0 && totalValue?.map((device) => device?.servicezipcode?.zipCode).join(',');

  const totalFinacedAmount =
    totalValue?.length > 0 &&
    totalValue?.reduce((acc, device) => acc + (device?.splitValue?.totalFinanceAmount || 0), 0);
  const totalMonthlyAmount =
    totalValue?.length > 0 &&
    totalValue?.reduce((acc, device) => acc + (device?.splitValue?.monthlyFinanceAmount || 0), 0);

  const closeModal = (show) => {
    if (!show) {
      setShowDFOPaymentDetails(false);
    }
  };

  return (
    <Modal fullScreenDialog={false} opened onOpenedChange={closeModal}>
      <VVCTitle data-testid='vvcTitle'>Verizon Visa® Card Financing </VVCTitle>
      <DFOPay>Estimated monthly payment(s) </DFOPay>
      <Devices>Devices</Devices>
      <DFOPay> 0%APR with 36 equal monthly payments.incl.tax</DFOPay>
      {totalValue?.length > 0 &&
        totalValue.map((devicelist) => (
          <VVCDevice>
            <div>
              <div>{devicelist?.description}</div>
              <span>{devicelist?.splitValue?.mtn} </span>
            </div>
            <VVCAmount>
              <span>{formatCurrency(devicelist?.itemPrice)}</span>
            </VVCAmount>
          </VVCDevice>
        ))}

      <VVCDevice>
        <div>Est sales tax for {EstZipcode}</div>
        <VVCAmount>
          <span>{formatCurrency(totalTaxAmout)}</span>
        </VVCAmount>
      </VVCDevice>
      <Line type='secondary' style={{ marginBottom: '10px' }} />
      <VVCDevice>
        <div>Est. amount financed</div>
        <VVCAmount>
          <span>{formatCurrency(totalFinacedAmount)}</span>
        </VVCAmount>
      </VVCDevice>
      <VVCDevice>
        <div style={{ fontWeight: 'bold' }}>Est. monthly payment</div>
        <VVCAmount>
          <span>{formatCurrency(totalMonthlyAmount)}</span>
        </VVCAmount>
      </VVCDevice>
    </Modal>
  );
};
DFOPaymentModal.propTypes = {
  opened: PropTypes.bool,
  dfoCart: PropTypes.object,
  setShowDFOPaymentDetails: PropTypes.func,
};
export default DFOPaymentModal;
