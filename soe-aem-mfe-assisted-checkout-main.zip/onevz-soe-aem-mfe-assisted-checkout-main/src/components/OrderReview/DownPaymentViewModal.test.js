import { render, screen, fireEvent } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../modules/store';
import DownPaymentViewModal from './DownPaymentViewModal';

describe('DownPaymentViewModal Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  beforeEach(() => {
    window.mfe = { scmDeviceMfeEnable: true };
    window.mfe.historyRef = jest.fn();
    window.mfe.historyRef.push = jest.fn();
  });
  
  test('renders DownPaymentViewModal', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <DownPaymentViewModal 
            handleDPClose = {() => {}}
            CustomerProfileResult = {[]}
            cart = {[]}
            setDownPayment = {() => {}}
            handleDPDone = {() => {}}
            requestBodyDeviceDetails = {[]}
            downpayment = {{}}
            fetchDownPaymentResult = {() => {}}/>
        </StoreProvider>
      </BrowserRouter>
    );
    const modalHeader = screen.getByTestId('downpayment-modal');
    expect(modalHeader).toBeInTheDocument();
  });
});
