import { render, screen, fireEvent } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../modules/store';
import cartJson from '../../__mock__/retrive-cart.json';
import AccountDetails from './AccountDetails';
import * as AccountSectionAPICallHook from '../../modules/services/APIService/AccountSectionAPICallHook';

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradlePropertyV2: () => ['TRUE'],
  }),
  { virtual: true }
);

describe('AccountDetails Component', () => {
  const mockGetReferences = jest.fn();
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  const mockGetReferencesResult = ({ status = 'uninitialized' } = {}) => ({
    data: {
      data: {
        planReferences: [
          {
            planId: '50427',
            monthlyAccessCharge: 60.0, // old
            description: 'oldDescription',
            displayName: 'oldDisplayName',
            featureText: 'oldFeatureText',
            dataOverageAllowance: '20',
            dataOverateAmount: '10',
            dataUnitOfMeasure: '2',
            imageUrlMap: { defaultImage: 'oldImageurl' },
          },
          {
            planId: '33333',
            monthlyAccessCharge: 70.0, // new
            description: 'newDescription',
            displayName: 'newDisplayName',
            featureText: 'newFeatureText',
            dataOverageAllowance: '30',
            dataOverateAmount: '15',
            dataUnitOfMeasure: '1',
            imageUrlMap: { defaultImage: 'newImageurl' },
          },
        ],
      },
    },
    status,
  });

  const mockFetchPriceSnapshot = (showMultipleAccount = false) => {
    const data = {
      subAccounts: [
        {
          shared: {
            promosTotal: {
              discountedPrice: '-20.0',
            },
            flags: {
              serviceInEffectLaterMsg: 'info',
            },
          },
          subAccountType: 'existing',
          subAccountId: 'SubAccount ',
        },
      ],
    };
    if (showMultipleAccount) {
      data.subAccounts.push({
        shared: {
          promosTotal: {
            discountedPrice: '-10.0',
          },
          flags: {
            serviceInEffectLaterMsg: 'info',
          },
        },
        subAccountId: 'SubAccount ',
      });
    }
    return data;
  };

  const mockDiscountedFeatures = [
    {
      isGeneralAddon: true,
      featureDesc: 'genAddOns',
      featurePrice: '18.0',
      addDeleteInd: 'C',
    },
    {
      isGeneralAddon: false,
      featureDesc: 'discountedAddOns',
      featurePrice: '18.0',
      addDeleteInd: 'C',
    },
    {
      isGeneralAddon: false,
      featureDesc: 'discountedAddOnsDelete Ind',
      featurePrice: '19.0',
      addDeleteInd: 'D',
    },
  ];

  const fetchPriceSnapshot1 = {
    subAccounts: [
      {
        subAccountId: 'SubAccount 123',
        name: 'SubAccount A',
      },
      {
        subAccountId: 'SubAccount 456',
        name: 'SubAccount B',
      },
    ],
  };

  const mockDiscountedFeaturesReadOrder = [
    {
      isGeneralAddon: true,
      featureDesc: 'genAddOns',
      featurePrice: '18.0',
      addDeleteInd: 'C',
    },
    {
      isGeneralAddon: false,
      featureDesc: null,
      featurePrice: '18.0',
      addDeleteInd: 'C',
    },
    {
      isGeneralAddon: false,
      featureDesc: 'discountedAddOnsDelete Ind',
      featurePrice: 0.0,
      addDeleteInd: 'D',
    },
  ];

  test('renders AccountDetails', () => {
    jest
      .spyOn(AccountSectionAPICallHook, 'default')
      .mockImplementation(() => ({ getReferences: mockGetReferences, getReferencesResult: mockGetReferencesResult() }));

    render(
      <BrowserRouter>
        <StoreProvider>
          <AccountDetails
            data={cartJson}
            discountedFeatures={mockDiscountedFeatures}
            fetchPriceSnapshot={mockFetchPriceSnapshot()}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getByTestId('account-details');
    const accessFee = screen.getByText(/80.0/i);
    const planDesc = screen.getByText(/Nationwide Talk & Text - 700/i);
    expect(titleElement).toBeInTheDocument();
    expect(accessFee).toBeInTheDocument();
    expect(planDesc).toBeInTheDocument();
  });

  test('renders modal', () => {
    jest
      .spyOn(AccountSectionAPICallHook, 'default')
      .mockImplementation(() => ({ getReferences: mockGetReferences, getReferencesResult: mockGetReferencesResult() }));

    render(
      <BrowserRouter>
        <StoreProvider>
          <AccountDetails data={cartJson} discountedFeatures={mockDiscountedFeatures} />
        </StoreProvider>
      </BrowserRouter>
    );
    const viewBtn = screen.getByTestId('view-account');
    expect(viewBtn).toBeInTheDocument();
    fireEvent.click(viewBtn, {});
  });

  test('Account Modal close click', async () => {
    jest
      .spyOn(AccountSectionAPICallHook, 'default')
      .mockImplementation(() => ({ getReferences: mockGetReferences, getReferencesResult: mockGetReferencesResult() }));

    render(
      <BrowserRouter>
        <StoreProvider>
          <AccountDetails data={cartJson} discountedFeatures={mockDiscountedFeatures} />
        </StoreProvider>
      </BrowserRouter>
    );
    const viewBtn = screen.getByTestId('view-account');
    expect(viewBtn).toBeInTheDocument();
    fireEvent.click(viewBtn, {});

    const DoneBtn = screen.getByText(/Done/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
  });

  test('Share Modal close click', async () => {
    jest
      .spyOn(AccountSectionAPICallHook, 'default')
      .mockImplementation(() => ({ getReferences: mockGetReferences, getReferencesResult: mockGetReferencesResult() }));

    render(
      <BrowserRouter>
        <StoreProvider>
          <AccountDetails
            data={cartJson}
            discountedFeatures={mockDiscountedFeatures}
            fetchPriceSnapshot={mockFetchPriceSnapshot(true)}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const viewShareBtn = screen.getByTestId('viewShared');
    expect(viewShareBtn).toBeInTheDocument();
    fireEvent.click(viewShareBtn, {});

    const DoneShareBtn = screen.getByText(/Done/i);
    expect(DoneShareBtn).toBeInTheDocument();
    fireEvent.click(DoneShareBtn, {});
  });

  test('isDark true', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    jest
      .spyOn(AccountSectionAPICallHook, 'default')
      .mockImplementation(() => ({ getReferences: mockGetReferences, getReferencesResult: mockGetReferencesResult() }));
    const { rerender } = render(
      <BrowserRouter>
        <StoreProvider>
          <AccountDetails data={cartJson} discountedFeatures={mockDiscountedFeatures} />
        </StoreProvider>
      </BrowserRouter>
    );
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: false, themeProps: { background: '#eeeeee' } };
    rerender(
      <BrowserRouter>
        <StoreProvider>
          <AccountDetails data={cartJson} discountedFeatures={mockDiscountedFeatures} />
        </StoreProvider>
      </BrowserRouter>
    );
    const viewBtn = screen.getByTestId('view-account');
    expect(viewBtn).toBeInTheDocument();
    fireEvent.click(viewBtn, {});
  });

  test('Account Modal close click', async () => {
    jest
      .spyOn(AccountSectionAPICallHook, 'default')
      .mockImplementation(() => ({ getReferences: mockGetReferences, getReferencesResult: mockGetReferencesResult() }));

    render(
      <BrowserRouter>
        <StoreProvider>
          <AccountDetails
            data={cartJson}
            discountedFeatures={mockDiscountedFeaturesReadOrder}
            readOrder
            fetchPriceSnapshot={fetchPriceSnapshot1}
            activeSubAccountId='SubAccount 12'
          />
        </StoreProvider>
      </BrowserRouter>
    );
  });
});
