/* eslint-disable react/button-has-type */
import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import { useLazyGetCreditRefreshQuery } from 'onevzsoemfecommon/CommonService';
import CreditCheckout from './CreditCheckout';
import { refreshResp } from './__mock__/refreshResp';
import orderreviewApiCallHook from '../../pages/home/container/orderreviewApiCallHook';

jest.mock('onevzsoemfecommon/Credit', () => ({
  __esModule: true,
  default: ({ viewCreditModal }) => (
    <div>
      Credit component
      <button onClick={viewCreditModal}>Close</button>
    </div>
  ),
}));

jest.mock('onevzsoemfecommon/CommonService', () => ({
  useLazyGetCreditRefreshQuery: jest.fn(),
}));

jest.mock('../../pages/home/container/orderreviewApiCallHook', () => jest.fn());

jest.mock('@vds/modals', () => ({
  ...jest.requireActual('@vds/modals'),
  // eslint-disable-next-line react/button-has-type, react/prop-types
  Modal: ({ children, ...props }) => (
    // eslint-disable-next-line react/prop-types
    <div {...props} data-testid={props.id}>
      {children}
    </div>
  ),
}));

const mockCustomerProfileResult = {
  data: {
    data: {
      customer: {
        cartid: '12345',
        accountnumber: '67890',
      },
    },
  },
};

describe('CreditCheckout Component', () => {
  const props = {
    landing: { data: {} },
    handleClose: jest.fn(),
    customerInfo: {},
    appNumber: '12345',
    data: {
      cart: {
        orderDetails: {
          orderList: [],
          customerConsent: 'Y',
        },
      },
    },
  };

  beforeEach(() => {
    useLazyGetCreditRefreshQuery.mockReturnValue([
      jest.fn(),
      { data: refreshResp.data, isFetching: false, isLoading: false, isSuccess: true },
    ]);
    orderreviewApiCallHook.mockImplementation(() => ({
      CustomerProfileResult: mockCustomerProfileResult,
    }));
  });

  it('should render the CreditCheckout component', () => {
    render(<CreditCheckout {...props} />);
  });

  it('should call viewCreditModal and handleClose when Close button is clicked', () => {
    const { getByText } = render(<CreditCheckout {...props} />);
    fireEvent.click(getByText('Close'));
    expect(props.handleClose).toHaveBeenCalled();
  });
});

describe('CreditCheckout Component negative scenario', () => {
  const props = {
    landing: { data: {} },
    handleClose: jest.fn(),
    customerInfo: {},
    appNumber: '12345',
    data: {
      cart: {
        orderDetails: {
          orderList: [],
          customerConsent: 'Y',
        },
      },
    },
  };

  const mockCustomerProfileResultNegative = {
    data: {
      data: {
        customer: {
          cartid: '',
          accountnumber: '',
        },
      },
    },
  };

  beforeEach(() => {
    orderreviewApiCallHook.mockImplementation(() => ({
      CustomerProfileResult: mockCustomerProfileResultNegative,
    }));
    useLazyGetCreditRefreshQuery.mockReturnValue([
      jest.fn(),
      {
        data: [
          {
            data: {
              credit: {
                tokenizedssn: true,
                creditApprovalStatus: '',
                creditStatusReason: '',
                creditApplicationNum: '',
                locationCode: '',
                securityDepositAmount: '',
                fwaSecurityDepositAmount: '',
                customerType: '',
                bussOrIndvCustomer: '',
              },
            },
            errors: null,
          },
        ],
        isFetching: false,
        isLoading: false,
        isSuccess: true,
      },
    ]);
  });

  it('should render the CreditCheckout component negative', () => {
    render(<CreditCheckout {...props} />);
  });
});
