import { fireEvent, render, screen } from '@testing-library/react';
import DFOPriceInfo from './DFOPriceInfo';

describe('DFOPriceInfo with DFO', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  const renderDFOPriceInfo = (props = {}) => {
    const info = [
      {
        payment: 'Verizon Visa Card Financing',
        price: '90',
        hideMonthly: true,
        isBold: true,
        key: 'totalAmount',
      },
      {
        payment: ` Estimated monthly Verizon Visa Card Payment for 36 month `,
        price: '890',
        key: 'monthlyAmount',
        hasSubText: true,
      },
    ];
    const id = 'dfoDevice';
    const title = 'Device';
    const bgColor = 'white';

    render(<DFOPriceInfo info={info} id={id} title={title} bgColor={bgColor} {...props} />);
  };

  test('test DFO Title Device', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    renderDFOPriceInfo();
    const title = screen.getByText('Device');
    expect(title).toBeInTheDocument();
  });
  test('test DFO Title Device isDark false', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: false, themeProps: { background: '#eeeeee' } };
    renderDFOPriceInfo();
    const title = screen.getByText('Device');
    expect(title).toBeInTheDocument();
  });
  test('test DFO Title Total Payment', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    renderDFOPriceInfo({ title: 'Total Payment' });
    const title = screen.getByText('Total Payment');
    expect(title).toBeInTheDocument();
  });
  test('test DFO Title Total Payment isdark false', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: false, themeProps: { background: '#eeeeee' } };
    renderDFOPriceInfo({ title: 'Total Payment' });
    const title = screen.getByText('Total Payment');
    expect(title).toBeInTheDocument();
  });
  test('test DFO Title Total Payment', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    renderDFOPriceInfo({ title: 'Total Payment' });
    const button = screen.getByTestId('paymentLink');
    fireEvent.click(button);
  });
});
