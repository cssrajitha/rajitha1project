import { TextLink } from '@vds/buttons';
import { DropdownSelect } from '@vds/selects';
import { Body } from '@vds/typography';
import cloneDeep from 'lodash/cloneDeep';
import PropTypes from 'prop-types';
import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import GenericPhone from '../../assests/generic_phone.png';
import { useLazyUpdateManualDiscountQuery } from '../../modules/services/APIService/APIServiceHooks';

import { dataSetter, executeDealy } from './utility';
import ManualDiscountPriceDetails from './ManualDiscountPriceDetails';

export const Padding24 = styled.div`
  padding: 1.5rem;
`;

export const FlexAlignContainerItemsCenter = styled.div`
  display: flex;
  align-items: center !important;
  justify-content: space-between;
`;

const DiscountBox = styled.div`
  border: 1px solid #979797 !important;
  width: 163px;
  height: 12 rem;
  padding: 0.5rem;
`;

const ButtonGroup = styled.div`
  display: flex;
`;

const ButtonSpan = styled.span`
  padding: 20px;
  display: flex;
  justify-content: center;
  width: 100%;
  background-color: ${(props) => props.inputColor};
`;

const DiscountInput = styled.input`
  padding-left: 10px;
  font-weight: bold;
  width: 145px;
  height: 40px;
  font-size: large;
  font-family: BrandFontBold, Sans-serif !important;
  &::placeholder: {
    font-family: BrandFontBold, Sans-serif !important;
  }
`;

const DrowpdownWrapper = styled.div`
  .reason-dd {
    border-radius: 0;
    border: 1px solid #ccc;
    width: 220px;
  }
`;

const TextContainer = styled.div`
  .strike {
    text-decoration: line-through;
  }
`;

const ImageContainer = styled.img`
  ${(props) => !props.isGeneric && 'width: 65px'};
  ${(props) => !props.isGeneric && 'height: 99px'};
`;

const DiscountSection = styled.div`
  display: flex;
  flex-direction: column;
  gap: 10px;
`;

export default function ManulDiscountItem({
  item,
  reasonCodeList,
  data,
  setData,
  cart,
  refreshManulaDiscountBody,
  setNotificationTitle,
  setNotificationType,
  setShowNotification,
  themeTextColor,
}) {
  const [removeManualDiscountBody, removeManualDiscountResult] = useLazyUpdateManualDiscountQuery();

  const [discount, setDiscount] = useState(0);
  const [dType, setDType] = useState('$');
  const [reason, setReason] = useState(null);
  const [isManualDiscount, setIsManualDiscount] = useState(item?.manualDiscountPrice);

  const handleHasDiscounts = (e, itemPrice) => {
    const upperLimit = dType === '$' ? itemPrice : 100;
    if (Number(e.target.value) <= upperLimit) {
      setDiscount(e.target.value);
      handleDiscount(e, itemPrice);
    }
  };

  const handleDiscount = (e, itemPrice) => {
    const newData = cloneDeep(item);

    const inputValue = Number(e.target.value) || 0;
    const inputAmount = dType === '$' ? Number(e.target.value) : (itemPrice * Number(e.target.value)) / 100 || 0;
    if (inputAmount <= itemPrice) {
      setIsManualDiscount(false);
      if (dType === '$') {
        newData.discountPercent = null;
        newData.discountAmount = inputValue;
        newData.discountedPrice = newData.itemPrice - inputValue;
      } else {
        newData.discountAmount = null;
        newData.discountPercent = inputValue;
        newData.discountedPrice = newData.itemPrice - (newData.itemPrice * inputValue) / 100;
      }
      if (inputValue === 0) setReason('select');
      setDiscount(inputValue);
    }

    dataSetter(setData, data, newData);
  };

  const downtype = (type) => {
    setDType(type);
    setReason('select');
    setDiscount(0);
    setIsManualDiscount(item?.manualDiscountPrice);
  };

  useEffect(() => {
    resetDiscountData();
  }, [dType]);

  useEffect(() => {
    if (discount === 0) {
      setIsManualDiscount(item?.manualDiscountPrice);
      resetDiscountData();
    }
  }, [discount]);

  const resetDiscountData = () => {
    const resetData = cloneDeep(item);
    resetData.dType = dType;
    resetData.discountPercent = null;
    resetData.discountAmount = null;
    resetData.discountedPrice = null;
    resetData.reason = null;
    resetData.reasonText = null;
    dataSetter(setData, data, resetData);
  };

  const handleReason = (e) => {
    const newReasonData = cloneDeep(item);
    newReasonData.reason = e.target.value;
    newReasonData.reasonText = e.target.options[e.target.selectedIndex].text;
    setReason(e.target.value);

    dataSetter(setData, data, newReasonData);
  };

  const handleRemove = () => {
    const payload = {
      cartInfo: { processingMTN: item?.mtn, intendType: 'EUP', processStep: 'OrderReview-Shipping', action: 'REMOVE' },
      data: {
        lines: [
          {
            mtn: item?.mtn,
            manualDiscount: [{ skuId: item?.sorSkuId }],
          },
        ],
      },
    };

    removeManualDiscountBody({ body: payload, spinner: true });
    setReason('select');
    setDiscount(0);
  };

  useEffect(() => {
    if (removeManualDiscountResult?.status === 'fulfilled') {
      const request = {
        data: {
          cartId: window?.mfe?.scmUpgradeMfeEnable
            ? sessionStorage.getItem('acssMfeCartId')
            : sessionStorage.getItem('cartId') || cart?.cartHeader?.cartId,
          locationCode: cart?.orderDetails?.locationCode,
        },
      };
      setShowNotification(true);
      setNotificationType('success');
      setNotificationTitle(
        removeManualDiscountResult?.data?.serviceBody?.serviceResponse?.context?.cartInfo?.statusMsg,
      );
      executeDealy(setShowNotification, window?.mfe?.scmUpgradeMfeEnable ? 1000 : 4000, false);
      refreshManulaDiscountBody({ body: request, mock: false });
    }
  }, [removeManualDiscountResult]);

  let placeHolderText;

  const getNetManualDisocunt = () => {
    if (window?.mfe?.scmUpgradeMfeEnable) {
      // eslint-disable-next-line no-unsafe-optional-chaining
      const netDiscountAmount = item?.manualDiscountPrice * item?.qty;
      return netDiscountAmount?.toFixed(2).toString();
    }
    return item?.manualDiscountPrice.toFixed(2).toString();
  };

  if (isManualDiscount) {
    placeHolderText = getNetManualDisocunt();
  } else {
    placeHolderText = dType === '$' ? '$0.00' : '%0.00';
  }

  const getDefaultValue = (reasonName) => reasonCodeList?.find((rsn) => rsn?.value === reasonName)?.key || '';

  let descriptionText = item.itemDescription;

  if (item.itemDescription === 'UPGRFEE') {
    descriptionText = 'UPGRADE FEE';
  } else if (item.itemDescription === 'TARIFFFEE' && window?.mfe?.scmUpgradeMfeEnable) {
    descriptionText = 'Manufacturer Cost Adjustment';
  }

  return (
    <div data-testid='manual-discount-item' className='row body content discount-items-container' key={item.itemType}>
      <div className='col-1'>
        <div>
          <ImageContainer
            isGeneric={!!item?.imageURL?.miniImage}
            src={item?.imageURL?.miniImage || GenericPhone}
            alt='alternateImage'
          />
        </div>
        <TextContainer>
          <span className='uppercase'>
            <Body size='large' color={themeTextColor}>
              {descriptionText}
            </Body>
          </span>

          <ManualDiscountPriceDetails item={item} />
        </TextContainer>
      </div>
      <div className='col-2'>
        <Body size='large' color={themeTextColor}>
          {item?.qty}
        </Body>
      </div>
      <div className='col-3'>
        <DiscountSection>
          <DiscountBox>
            <Body size='small' primitive='span' color='#959595'>
              Discounts
            </Body>

            <DiscountInput
              value={discount || ''}
              data-testId='discount-input'
              type='number'
              width='240px'
              name='price'
              placeholder={placeHolderText}
              onChange={(e) => handleHasDiscounts(e, item?.itemPrice)}
              min='0'
            />
            <ButtonGroup>
              <ButtonSpan
                data-testid='dollar-discount'
                onClick={() => downtype('$')}
                inputColor={dType === '$' ? '#959595' : '#f6f6f6'}
              >
                <Body color={dType === '$' ? 'white' : 'black'} bold>
                  $
                </Body>
              </ButtonSpan>
              <ButtonSpan
                data-testid='percent-discount'
                onClick={() => downtype('%')}
                inputColor={dType === '%' ? '#959595' : '#f6f6f6'}
              >
                <Body color={dType === '%' ? 'white' : 'black'} bold>
                  %
                </Body>
              </ButtonSpan>
            </ButtonGroup>
          </DiscountBox>

          {item?.manualDiscountPrice > 0 && (
            <div>
              <TextLink data-testid='remove-item' onClick={handleRemove}>
                {' '}
                Remove Discount
              </TextLink>
            </div>
          )}
        </DiscountSection>
      </div>
      <div className='col-4'>
        <DrowpdownWrapper>
          <Body size='small' primitive='span' color='#959595'>
            Select Reason
          </Body>
          <DropdownSelect
            disabled={(discount || 0) <= 0}
            size='small'
            data-testid='reason-dropdown'
            className='reason-dd'
            defaultValue={getDefaultValue(item?.manualDiscountDescription)}
            value={reason}
            onChange={(e) => handleReason(e)}
          >
            <option value='select' selected>
              Select Reason
            </option>
            {reasonCodeList?.map((code) => (
              <option key={code.key} style={{ width: '100%' }} value={code.key}>
                {code.value}
              </option>
            ))}
          </DropdownSelect>
        </DrowpdownWrapper>
      </div>
    </div>
  );
}

ManulDiscountItem.propTypes = {
  item: PropTypes.object,
  reasonCodeList: PropTypes.array,
  data: PropTypes.array,
  setData: PropTypes.func,
  refreshManulaDiscountBody: PropTypes.func,
  setNotificationTitle: PropTypes.func,
  setNotificationType: PropTypes.func,
  setShowNotification: PropTypes.func,
  cart: PropTypes.object,
  themeTextColor: PropTypes.string,
};
