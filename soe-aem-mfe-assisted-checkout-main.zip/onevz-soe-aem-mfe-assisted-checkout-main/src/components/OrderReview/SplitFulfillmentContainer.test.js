import React from 'react';
import { render, fireEvent, screen } from '@testing-library/react';
import StoreProvider from '../../modules/store';
import SplitFulfillmentContainer from './SplitFulfillmentContainer';
import cartMock from '../../__mock__/cartMock.json';

describe('', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  test('Basic render', () => {
    render(
      <StoreProvider>
        <SplitFulfillmentContainer cart={cartMock?.data?.cart} />
      </StoreProvider>,
    );
  });
  test('should check expand and collapse view', () => {
    render(
      <StoreProvider>
        <SplitFulfillmentContainer cart={cartMock?.data?.cart} />
      </StoreProvider>,
    );
    const collapseViewTestId = screen.getByTestId('collapseViewTestId');
    expect(collapseViewTestId).toBeInTheDocument();
    fireEvent.click(collapseViewTestId);
    const expandViewTestId = screen.getByTestId('expandViewTestId');
    expect(expandViewTestId).toBeInTheDocument();
    fireEvent.click(expandViewTestId);
  });
  test('Basic render without cart', () => {
    render(
      <StoreProvider>
        <SplitFulfillmentContainer />
      </StoreProvider>,
    );
  });
});
