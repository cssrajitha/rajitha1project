import { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import styled, { createGlobalStyle } from 'styled-components';
import { Title } from '@vds/typography';
import { Input as VdsInput } from '@vds/inputs';
import { TitleLockup } from '@vds/type-lockups';
import { Modal, ModalTitle, ModalBody, ModalFooter } from '@vds/modals';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import * as appLoaderActions from 'onevzsoemfecommon/AppLoaderActions';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { useDispatch } from 'react-redux';
import { Button } from '@vds/buttons';
import { has } from 'lodash';
import DOMPurify from 'dompurify';
import {
  formatCurrency,
  formatPhoneNumberWithSymbol,
  getCamelCaseName,
  scmCheckoutMfeEnabled,
} from '../../utils/common';
import { useLazyComputeDPPricesQuery } from '../../modules/services/APIService/APIServiceHooks';
import { invokeTagging } from '../../utils/test-utils/utils';
import orderreviewApiCallHook from '../../pages/home/container/orderreviewApiCallHook';
import InfoApiCallHook from '../../modules/services/APIService/InfoAPICallHook';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR } from '../constants/constants';

import { IconWrapper, StyledPaddingLeft8, FlexJustifyEnd } from '../../StyledConstants';

const MarginSides = styled.div`
  padding: 0 1rem;
`;

const ModalContentWrapper = styled.div`
  display: flex;
  > div:first-child {
    flex: 1;
  }
  > div:last-child {
    flex: 2;
  }
`;

const ImgWrapper = styled.div`
  display: flex;
  padding-right: 0.5rem;
  img {
    max-width: 100%;
    max-height: 250px;
  }
`;

const PriceWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 0.25rem;
  padding: 0.5rem 0;
  font-size: 15px;
  span {
    display: flex;
    strong {
      margin-left: ${(props) => (props.readOrder ? '0px' : '5px')};
    }
  }
  strong {
    display: flex;
    align-items: center;
    font-size: 18px;
    font-weight: bold;
    span {
      font-size: 18px;
      font-weight: bold;
    }
  }
  button {
    font-size: 18px;
    font-weight: bold;
    border: 0;
    background: none;
    text-decoration: underline;
    padding: 0;
    margin: 0 1rem 0 0;
  }
`;

const BorderBox = styled.div`
  padding: 0.5rem 0;
  border-bottom: 1px solid #ccc;
`;

const DevicePaymentBorderBox = styled(BorderBox)`
  padding: 1.5rem 0;
  &:last-child {
    border-bottom: none;
  }
`;

const FRPBodyStyle = styled.div`
  font-size: 13px;
  color: #747676;
  font-family: 'BrandFont-Display', Sans-serif !important;
  padding-bottom: 0.5rem;
`;

const UpgradeWrapper = styled.div`
  margin-top: 2rem;
`;

const SubTitle = styled.div`
  font-size: 15px;
  margin-top: 10px;
`;

const ErrorContainer = styled.div`
  text-align: center;
  margin-top: -32px;
  margin-bottom: 28px;
  color: rgb(213, 43, 30);
`;

const DevicesModal = ({
  opened,
  closeModal,
  element,
  line,
  sbdOffer,
  setMonthlyInstallmentAmount,
  cart,
  CustomerProfileRefetch,
  CartDetailsRefetch,
  fetchPriceSnapshotRefetch,
  readOrder,
  lineDeviceAndSimIds,
  activationStatus,
  landingInfo,
  orderStatus,
  cartHeader,
}) => {
  const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable || false;

  const ComponentStyle = createGlobalStyle`
  #devicesModal {
    [class^='Overlay-VDS'] {
      width: ${scmCheckoutMfeEnabled() ? '100%' : 'inherit'};
    }
    [class^='Overlay-VDS'] {
      background-color: rgba(0, 0, 0, 0.8);
    }
    [class^='ModalDialog-VDS'] {
      max-width:${scmCheckoutMfeEnabled() ? '80%' : '1024px'};
      border-radius: 0;
      padding: 0;
    }
    [class^='ModalDialogWrapper-VDS'] {
      ${scmCheckoutMfeEnabled() && `
        height: 100%;
      `}
        > span {
          width: 100%;
          height: 100%;

        > div {
          width:100% !important;
          height: 100% !important;

          > div {
            padding:0 !important;
          }
        }
      }
    }

    [class^='StyledModalBody-VDS'] {
      height: ${scmCheckoutMfeEnabled() ? 'auto' : '80vh'};
      overflow: auto;
      padding: 40px;
    }

    [class^='IconWrapper-VDS'] {
      z-index: 99999;
    }
    
    [class^='StyledHeader-VDS'] {
      border-bottom: 1px solid #ccc;
      position: sticky;
      top:0;
      z-index: 999;
      padding: 1rem 0;
      background-color: #FFFFFF;
    }
    [class^='StyledFooter-VDS'] {
      border-top: 1px solid #ccc;
      position: sticky;
      bottom:0;
      padding-top: 1.5rem;
      padding-bottom: 1.5rem;
      background-color: #FFFFFF;
    }
  }
`;

  const [computeDPPriceBody, computeDPPriceResult] = useLazyComputeDPPricesQuery();
  const { updateDownpaymentBody, CustomerProfileResult } = orderreviewApiCallHook();
  const { getActiveMTNRequest } = InfoApiCallHook();
  const [flexRedesign5GFFlag] = getAssistedCradlePropertyV2(['flexRedesign5GFFlag']);
  const [isReadOrderFlag] = getAssistedCradlePropertyV2(['readOrderMfeFFlag']);
  const isReadOrderFlagEnabled = /true/i.test(isReadOrderFlag);
  const dispatch = useDispatch();
  const channelId = cart?.orderDetails?.orderChannelId;
  channelId?.includes('OMNI-INDIRECT');
  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;
  const bgColor = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.themeProps?.background;
  const colorDisplayName = element?.color?.description || element?.color?.colorDisplayName || '';
  const priceType = element?.priceType;
  const priceTypeValue = priceType === 'MONTH_TO_MONTH' ? 'FRP' : 'DPP';
  const { isCpe, lineActivityType } = line;
  const cartItemsArray = line?.itemsInfo?.[0]?.cartItems?.cartItem;
  const showSalesTaxInfo = cartItemsArray && cartItemsArray?.find((item) => item?.cartItemType === 'DEVICE');
  const simInCart = cartItemsArray && cartItemsArray?.find((item) => item?.cartItemType === 'SIM');
  const isSimCpe = simInCart && simInCart.isCustomerProvidedSIM ? simInCart.isCustomerProvidedSIM : false;
  const retailPrice = element.discountedPrice !== element.itemPrice ? element.discountedPrice : element.itemPrice;
  // const downPayment =
  //   line &&
  //   line.installmentInfo &&
  //   line.installmentInfo.deviceDollarDownpayment &&
  //   line.installmentInfo.verizonDollarsDownpayment
  //     ? line.installmentInfo.deviceDollarDownpayment + line.installmentInfo.verizonDollarsDownpayment
  //     : 0;

  const { userSelectedDownPayment, mandatoryDownPayment } = line?.installmentInfo || {};
  let downPaymentValue = (userSelectedDownPayment || 0) + (mandatoryDownPayment || 0);
  if (channelId?.indexOf('OMNI-INDIRECT') > -1) {
    downPaymentValue = userSelectedDownPayment || 0;
  }
  const [editDP, setEditDP] = useState(`${downPaymentValue}`);
  const [showDPForm, setShowDPForm] = useState(false);

  const initialDbState = {
    firstMonthPrice: 0,
    remainingMonthPrice: line?.installmentInfo?.monthlyInstallment || 0,
    dpTerm: 36,
    downPayment: downPaymentValue,
  };

  const deviceDetails = line?.itemsInfo[0]?.cartItems?.cartItem?.find((d) => d.cartItemType === 'DEVICE');
  const deviceId = deviceDetails?.deviceId;
  const simDetails = line?.itemsInfo[0]?.cartItems?.cartItem?.find((d) => d.cartItemType === 'SIM');

  const simId = simDetails?.simId || simDetails?.deviceID || '';

  const [dpObj, setDpObj] = useState(initialDbState);
  const [isDPCancel, setIsDpCancel] = useState(false);

  const isCPCorFEA = line?.lineActivityType === 'CPC' || line?.lineActivityType === 'FEA';
  const currentDeviceDeviceId =
    line?.serviceInfo?.currentDevice?.oldLteVoraEquipInfo?.lteVoraDeviceInfo?.deviceId || '';
  const currentDeviceSimId = line?.serviceInfo?.currentDevice?.oldLteVoraEquipInfo?.iccid || '';
  const handleClick = async (btn, elem) => {
    if (btn === 'done') {
      if (!isReadOrderFlagEnabled && !readOrder) {
        invokeTagging('closeView', '');
      }
      if (downPaymentValue !== parseInt(editDP, 10)) {
        const customerType =
          new URLSearchParams(DOMPurify.sanitize(window.location.search))?.get('customerType') ||
          sessionStorage.getItem('customerType') ||
          cart?.orderDetails?.customerType;

        const addDpRequest = {
          cartInfo: {
            clientAppName: `VZW-${cart?.cartHeader?.vendorId}`,
            cartId: cart?.cartHeader?.cartId || sessionStorage.getItem('cartId'),
            caseId: CustomerProfileResult?.data?.data?.customer?.caseId,
            accountNumber: CustomerProfileResult?.data?.data?.customer?.accountNo ?? '',
            cartCreator: cart?.cartHeader?.cartCreator,
            processStep: 'DownPayment',
            intendType: customerType === 'N' ? 'NSE' : 'EUP',
          },
          data: {
            lines: [
              {
                mtn: cart?.lineDetails?.lineInfo[0]?.mtnDetails?.mobileNumber,
                lineDeviceDollar: 0,
                downPayment: {
                  amount: editDP,
                  percentage: 0,
                },
              },
            ],
          },
        };
        await updateDownpaymentBody({ body: addDpRequest, spinner: false });

        await CustomerProfileRefetch();
        await CartDetailsRefetch();
        await fetchPriceSnapshotRefetch();
        /* istanbul ignore next */
        if(!window?.mfe?.isProspectNewCustomerTab) await getActiveMTNRequest({ body: {}, spinner: false });
        dispatch(appLoaderActions.hide());
        dispatch(appMessageActions.addAppMessage('Downpayment Updated Successfully', 'success', true, true));
      }
      closeModal();
    } else if (btn === 'change') {
      invokeTagging('openView', 'Edit Device');

      if (!scmCheckoutMfeEnabled()) {
        changeDevice(elem);
      } else if (scmCheckoutMfeEnabled()) {
        window.Emitter.emit('ACSS_SCM_SWITCH_TAB', { type: 'SWITCH_TAB', targetTab: 'DEVICE_TAB' });
      }
    }
  };

  const changeDevice = (elem) => {
    const is5gDeviceSelected = line?.deviceTypeSelected === '5G Internet';

    if (line?.lineActivityType.includes('5G') && is5gDeviceSelected) {
      if (/true/i.test(flexRedesign5GFFlag)) {
        window.location.href = `/sales/assisted/pdp.html?productId=${elem?.productId}&deviceFromCart=true&deviceSKU=${elem.sorId}&isEditAndView=true&is5GMfePdpLoad=true&activeMtn=${line?.mobileNumber}`;
      } else {
        window.location.href = `/sales/assisted/product-detail.html?productId=${elem.productId}&deviceFromCart=true&deviceSKU=${elem.sorId}&isEditAndView=true`;
      }
    } else if (
      (channelId === 'OMNI-TELESALES' || channelId?.includes('OMNI-RETAIL') || channelId?.includes('OMNI-D2D')) &&
      !line?.lineActivityType.includes('5G') &&
      !line?.lineActivityType.includes('BYOD')
    ) {
      window.location.href = `/sales/assisted/product-detail.html?productId=${elem.productId}&deviceFromCart=true&deviceSKU=${elem.sorId}&activeMtn=${line?.mobileNumber}&isEditAndView=true`;
    } else if (channelId?.includes('OMNI-RETAIL') && line?.lineActivityType.includes('BYOD')) {
      window.location.href = `/sales/assisted/product-detail.html?deviceSKU=${elem.sorId}&activeMtn=${line?.mobileNumber}&isFromCPE=true&ByodDeviceCompitable=true&prospectByodFlow=true&deviceId=${elem.deviceId}&simId=${simDetails.eSIM}&isEditAndView=true`;
    } else {
      window.location.href = `/sales/assisted/landing.html?accountNo=${cart?.cartHeader?.fullAccountNumber}&lookupMTN=${cart?.cartHeader?.cartCreator}&channel=${channelId}&orderLocationCode=${cart?.cartHeader?.cartCreatorOrderLocationCode}`;
    }
  };

  const handleDPEdit = () => {
    setIsDpCancel(false);
    setShowDPForm(true);
  };

  const handleDPCancel = () => {
    setIsDpCancel(true);
    setEditDP(`${downPaymentValue}`);
    setShowDPForm(false);
  };

  const handleDpChange = (e) => {
    setEditDP(e.target.value);
  };

  const getItemPrice = () => {
    const hasToDisplayDiscountedPrice =
      has(element, 'discountedPrice') &&
      has(element, 'itemPrice') &&
      has(element, 'sellerPrice') &&
      channelId?.includes('OMNI-INDIRECT') &&
      parseFloat(element?.discountedPrice) >= 0
        ? parseFloat(element?.discountedPrice) !== parseFloat(element?.sellerPrice)
        : parseFloat(element?.discountedPrice) !== parseFloat(element?.itemPrice);
    let itemPrice = parseFloat(element?.itemPrice);
    if (hasToDisplayDiscountedPrice) {
      itemPrice = parseFloat(element?.discountedPrice);
    } else if (channelId?.includes('OMNI-INDIRECT')) {
      itemPrice = parseFloat(element?.sellerPrice);
    }
    return itemPrice;
  };

  const maskDeviceAndSimId = (deviceAndSimId) => {
    const roPage = readOrder && isReadOrderFlagEnabled;
    if (deviceAndSimId && roPage) {
      const [maskDevAndSimIDs] = getAssistedCradlePropertyV2(['maskDevAndSimIDs']);
      const maskDevAndSimIDsEnabled = /true/i.test(maskDevAndSimIDs);
      if (maskDevAndSimIDsEnabled) {
        return (
          deviceAndSimId.substring(0, 4) +
          deviceAndSimId.substring(4, deviceAndSimId.length - 4).replace(/\d/g, 'X') +
          deviceAndSimId.substring(deviceAndSimId.length - 4)
        );
      }
    }
    return deviceAndSimId;
  };

  const [showMaxDpLimitError, setShowMaxDpLimitError] = useState(false);
  const [maxDPLimitValue, setMaxDPLimitValue] = useState(0);

  const computeDp = () => {
    const itemPrice = getItemPrice();

    const maxDPLimit =
      has(line, 'installmentInfo.installmentTerm') && has(element, 'discountedPrice') && itemPrice
        ? parseFloat(itemPrice) - line.installmentInfo.installmentTerm / 100
        : 0;

    setMaxDPLimitValue(maxDPLimit);

    if (editDP > maxDPLimit) {
      setShowMaxDpLimitError(true);
    } else if (!isDPCancel) {
      setShowMaxDpLimitError(false);
      setShowDPForm(false);
      // Pending: Payload term should be dynamic:  installmentInfo
      // soe-assisted\src\components\OrderReview\Modals\ShowDetails\ShowDetails.js
      const computeDPPriceReq = {
        sorId: element.sorId,
        term: 36,
        downPayment: editDP !== null ? editDP : 0,
        isPercentage: false,
        agentOrFullRetailPrice: retailPrice,
      };

      computeDPPriceBody({ body: computeDPPriceReq });
      setIsDpCancel(false);
    }
  };

  useEffect(() => {
    if (computeDPPriceResult?.isSuccess) {
      setDpObj(computeDPPriceResult?.data);
      setMonthlyInstallmentAmount(computeDPPriceResult?.data?.remainingMonthPrice);
    }
  }, [computeDPPriceResult?.data?.downPayment]);

  const showTaxF = element?.taxBasis === 'F' && channelId !== 'OMNI-INDIRECT';
  const showTaxP = element?.taxBasis === 'P';
  const deviceIdandSimdIDs = lineDeviceAndSimIds?.filter((item) => item.mobileNumber === line?.mobileNumber);
  let simIDval = '';
  const devId = deviceIdandSimdIDs?.[0]?.deviceId || '';
  const deviceIdResp = element?.deviceId || element?.eDeviceId || '';
  const simIdResp = element?.simId || '';
  const simIccid = deviceIdandSimdIDs?.[0]?.simId || '';

  if (isCPCorFEA) {
    simIDval = currentDeviceSimId;
  } else if (isCpe && simId) {
    simIDval = simId;
  } else if (showSalesTaxInfo && showSalesTaxInfo?.depletionType === 'L') {
    simIDval = simId;
  } else if (element?.simId) {
    simIDval = element.simId;
  } else {
    simIDval = deviceIdandSimdIDs?.[0]?.simId || '';
  }

  let displayedDeviceId;

  if (isCPCorFEA && readOrder && isReadOrderFlagEnabled) {
    displayedDeviceId = maskDeviceAndSimId(currentDeviceDeviceId);
  } else if (isCPCorFEA) {
    displayedDeviceId = currentDeviceDeviceId;
  } else if (readOrder && isReadOrderFlagEnabled) {
    displayedDeviceId = maskDeviceAndSimId(deviceId || devId || deviceIdResp);
  } else {
    displayedDeviceId = deviceId;
  }
  const [skipIccidCall] = getAssistedCradlePropertyV2(['skipIccidCall']);
  const skipIccidCallEnabled = /true/i.test(skipIccidCall);
  const enableSimID =
    (!(
      landingInfo?.devicedata?.eSimEtniApi !== undefined &&
      landingInfo?.devicedata?.eSimEtniApi === true &&
      skipIccidCallEnabled
    ) &&
      simIDval) ||
    (activationStatus?.length > 0 && activationStatus[0].activationStatus === 'SUCCESS' && readOrder);

  let displayedSimId;

  if (isCPCorFEA && isReadOrderFlagEnabled && readOrder) {
    displayedSimId = maskDeviceAndSimId(currentDeviceSimId);
  } else if (isCPCorFEA) {
    displayedSimId = currentDeviceSimId;
  } else if (isReadOrderFlagEnabled && readOrder) {
    displayedSimId = maskDeviceAndSimId(simId || simIdResp || simIccid);
  } else {
    displayedSimId = simId;
  }

  let disableEditButtons = false;
  const statusCode = cartHeader && cartHeader.status;
  if (orderStatus === 'CR' && statusCode !== 'P' && statusCode !== 'C') {
    disableEditButtons = true;
  }

  return (
    <>
      <ComponentStyle isDark />
      <div data-testId='devicesModal'>
        <Modal
          id='devicesModal'
          fullScreenDialog={!scmUpgradeMfeEnable}
          opened={opened}
          surface={isDark ? 'dark' : 'light'}
          width={scmUpgradeMfeEnable ? '80%': '100%'}
          {...(scmUpgradeMfeEnable && { maxHeight:'90%'})}
          disableAnimation={false}
          disableOutsideClick={false}
          onOpenedChange={(open) => {
            if (!open) closeModal();
          }}
        >
          <MarginSides>
            <ModalTitle>
              <Title size='small' bold color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                Device for {line?.mobileNumber && formatPhoneNumberWithSymbol(line.mobileNumber, '-')}
              </Title>
            </ModalTitle>
            <ModalBody>
              {showMaxDpLimitError && (
                <ErrorContainer>Maximum downpayment allowed is : {maxDPLimitValue}</ErrorContainer>
              )}
              <ModalContentWrapper>
                <div>
                  <ImgWrapper>
                    <img
                      src={
                        element.imageUrlMap && element.imageUrlMap.defaultImage ? element.imageUrlMap.defaultImage : ''
                      }
                      alt={
                        `${element.manufacturer ? element.manufacturer : ''}` +
                        ' ' +
                        `${element.description ? element.description : ''}`
                      }
                      className='u-cursorPointer'
                    />
                  </ImgWrapper>
                </div>
                <div>
                  {/* <BorderBox> */}
                  <TitleLockup
                    surface={isDark ? 'dark' : 'light'}
                    data={{
                      title: {
                        size: 'titleSmall',
                        children: `${element.manufacturer ? element.manufacturer : ''}`,
                        bold: true,
                      },
                    }}
                  />
                  <TitleLockup
                    surface={isDark ? 'dark' : 'light'}
                    data={{
                      title: {
                        size: 'titleSmall',
                        children: ` ${element.description || ''} ${element.capacity || ''} ${
                          colorDisplayName !== '' ? `in ${getCamelCaseName(colorDisplayName)}` : ''
                        }`,
                        bold: true,
                      },
                    }}
                  />
                  <SubTitle>{`SKU# ${!isCPCorFEA ? element?.sorId : element?.deviceSku}`}</SubTitle>
                  <UpgradeWrapper>
                    {element.upgradeReasonCode && (
                      <SubTitle>{`Upgrade ${element.upgradeReasonCode} - ${element.upgradeReasonDesc}`}</SubTitle>
                    )}
                    {line?.installmentInfo?.upgradeOptionCode === 'UO' && (
                      <SubTitle>{`Upgrade after - ${line.installmentInfo.percentage}%`}</SubTitle>
                    )}
                  </UpgradeWrapper>
                  {(isCPCorFEA ||
                    deviceId ||
                    isCPCorFEA ||
                    (showSalesTaxInfo && showSalesTaxInfo.depletionType === 'L') ||
                    (isCpe && simId) ||
                    deviceIdandSimdIDs?.length > 0) && (
                    <PriceWrapper
                      readOrder={readOrder && isReadOrderFlagEnabled}
                      style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}
                    >
                      <span>
                        <strong>Device ID</strong>
                      </span>

                      <span style={{ flexDirection: 'column', alignItems: 'center' }}>
                        <div>{displayedDeviceId} </div>
                        <div>
                          {isCPCorFEA ||
                            (isCpe && lineActivityType && lineActivityType.includes('BYOD') && (
                              <span style={{ fontSize: '12px' }}>(Customer Provided)</span>
                            ))}
                        </div>
                      </span>
                    </PriceWrapper>
                  )}
                  {(isCPCorFEA || simId || enableSimID) && (
                    <>
                      <PriceWrapper
                        readOrder={readOrder && isReadOrderFlagEnabled}
                        style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}
                      >
                        <span>
                          <strong>SIM ID</strong>
                        </span>
                        <span>{displayedSimId}</span>
                      </PriceWrapper>
                      {(isSimCpe || currentDeviceSimId === simId) && (
                        <FlexJustifyEnd>(Keeping current SIM card )</FlexJustifyEnd>
                      )}
                    </>
                  )}
                  <FRPBodyStyle>
                    {sbdOffer &&
                      sbdOffer?.length > 0 &&
                      sbdOffer?.map((item) => (
                        <>
                          <div>
                            Bill Credit Offer: {item?.offerId} ${item?.discAmt}
                          </div>
                          <div>
                            Offer Name: {item?.offerId}- {item?.description}
                          </div>
                        </>
                      ))}
                  </FRPBodyStyle>
                  {!isCPCorFEA && (
                    <div>
                      {priceTypeValue === 'DPP' ? (
                        <>
                          <BorderBox />
                          <BorderBox>
                            <PriceWrapper style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                              <strong>Device payment</strong>
                            </PriceWrapper>
                            <PriceWrapper style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                              <span>Retail Price</span>
                              <strong>{formatCurrency(retailPrice)}</strong>
                            </PriceWrapper>
                            <PriceWrapper style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                              <span>Downpayment</span>
                              <strong>
                                {(readOrder && disableEditButtons) ||
                                  (!readOrder && !isReadOrderFlagEnabled && (
                                    <div>
                                      {showDPForm ? (
                                        <button
                                          data-testId='dp-cancel'
                                          type='button'
                                          onMouseDown={handleDPCancel}
                                          style={{
                                            color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                                            backgroundColor: isDark ? bgColor : '',
                                          }}
                                        >
                                          Cancel
                                        </button>
                                      ) : (
                                        <button
                                          data-testId='dp-edit'
                                          type='button'
                                          onMouseDown={handleDPEdit}
                                          style={{
                                            color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                                            backgroundColor: isDark ? bgColor : '',
                                          }}
                                        >
                                          Edit
                                        </button>
                                      )}
                                    </div>
                                  ))}

                                {showDPForm && (
                                  <VdsInput
                                    data-testId='dp-input'
                                    type='text'
                                    iconName='dp'
                                    width={200}
                                    formControlName='dp'
                                    name='dp'
                                    value={editDP}
                                    onChange={handleDpChange}
                                    onBlur={computeDp}
                                    surface={isDark ? 'dark' : 'light'}
                                  />
                                )}
                                {!showDPForm && formatCurrency(dpObj.downPayment || 0)}
                              </strong>
                            </PriceWrapper>
                          </BorderBox>
                          <DevicePaymentBorderBox>
                            <PriceWrapper style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                              <span>Financed amount</span>
                              <strong>{formatCurrency(retailPrice - dpObj.downPayment)}</strong>
                            </PriceWrapper>
                            <PriceWrapper style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                              <span>Months</span>
                              <strong>÷ {line?.installmentInfo?.installmentTerm}</strong>
                            </PriceWrapper>
                          </DevicePaymentBorderBox>
                          <DevicePaymentBorderBox>
                            <PriceWrapper style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                              <span>Monthly</span>
                              <strong>$ {dpObj.remainingMonthPrice || '--'}</strong>
                            </PriceWrapper>
                          </DevicePaymentBorderBox>
                          {showTaxF && (
                            <DevicePaymentBorderBox data-testid='tax-f'>
                              <PriceWrapper style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                                <span>
                                  Sales tax on principal amount{' '}
                                  <strong>({formatCurrency(element.itemNrpPrice)})</strong>
                                </span>
                                <strong>
                                  <span>Due Today</span> {formatCurrency(deviceDetails.taxAmount)}
                                </strong>
                              </PriceWrapper>
                            </DevicePaymentBorderBox>
                          )}
                          {showTaxP && (
                            <DevicePaymentBorderBox data-testid='tax-p'>
                              <PriceWrapper style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                                <span>
                                  Sales tax on principal amount{' '}
                                  <strong>({formatCurrency(element.itemNrpPrice)})</strong>
                                </span>

                                <strong>
                                  <span>Due Monthly</span> {formatCurrency(element.taxAmount)}
                                </strong>
                              </PriceWrapper>
                              <PriceWrapper style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                                <span>
                                  Sales tax on down paymount amount{' '}
                                  <strong>({formatCurrency(downPaymentValue)})</strong>
                                </span>
                                <strong>
                                  <span>Due Today</span> {formatCurrency(deviceDetails.taxAmount)}
                                </strong>
                              </PriceWrapper>
                            </DevicePaymentBorderBox>
                          )}
                        </>
                      ) : (
                        <>
                          <BorderBox />
                          <DevicePaymentBorderBox>
                            <PriceWrapper style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                              <span>
                                <strong>Retail Price</strong>
                              </span>
                              <strong>{formatCurrency(element.itemNrpPrice)}</strong>
                            </PriceWrapper>
                          </DevicePaymentBorderBox>
                        </>
                      )}
                    </div>
                  )}
                </div>
              </ModalContentWrapper>
            </ModalBody>
            <ModalFooter
              surface={isDark ? 'dark' : 'light'}
              buttonData={
                !isReadOrderFlagEnabled &&
                !readOrder && {
                  ...(!scmUpgradeMfeEnable && {
                    primary: {
                      children: 'Change Device',
                      width: '225px',
                      onClick: () => handleClick('change', element),
                    },
                  }),
                  close: {
                    children: 'Done',
                    width: '225px',
                    onClick: () => handleClick('done', element),
                  },
                }
              }
            >
              {isReadOrderFlagEnabled && readOrder && (
                <IconWrapper>
                  <StyledPaddingLeft8>
                    <Button width='225px' size='large' use='primary' onClick={() => handleClick('done', element)}>
                      Done
                    </Button>
                  </StyledPaddingLeft8>
                  <StyledPaddingLeft8>
                    <Button
                      width='225px'
                      data-testid='change-device'
                      disabled={readOrder && !disableEditButtons}
                      size='large'
                      use='secondary'
                      onClick={() => handleClick('change', element)}
                    >
                      Change Device
                    </Button>
                  </StyledPaddingLeft8>
                </IconWrapper>
              )}
            </ModalFooter>
          </MarginSides>
        </Modal>
      </div>
    </>
  );
};

DevicesModal.propTypes = {
  opened: PropTypes.object,
  cart: PropTypes.object,
  closeModal: PropTypes.func,
  element: PropTypes.object,
  line: PropTypes.object,
  sbdOffer: PropTypes.array,
  setMonthlyInstallmentAmount: PropTypes.func,
  CustomerProfileRefetch: PropTypes.func,
  CartDetailsRefetch: PropTypes.func,
  fetchPriceSnapshotRefetch: PropTypes.func,
  readOrder: PropTypes.bool,
  lineDeviceAndSimIds: PropTypes.object,
  activationStatus: PropTypes.object,
  landingInfo: PropTypes.object,
  orderStatus: PropTypes.string,
  cartHeader: PropTypes.object,
};

export default DevicesModal;
