import { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { Micro, Title } from '@vds/typography';

/**
 * Displays a single line summary of order status including: Order number(s), Status, Account Number (customerId), & "View Together" "Yes/No"
 *
 * @param {Map} props Map of required data
 * @param {Array<String>} props.orderNumberAry An array of order number strings. Order will have 1 or more numbers. If more than one, they will be concatenated for display.
 * @param {String} props.orderStatus The current orderStatus
 * @param {String} props.cartHeaderStatus The status of the cart header (used in checking if the status is "Incomplete")
 * @param {String} props.customerId The customerId for the order (this is the first part of the full account string => "customerId-subAccountNum"
 * @param {String} props.lovIndicator Read Order "lovIndicator" value used to check "View Together" status
 *
 * @returns {JSX|OrderSummaryLine}
 */
const OrderSummaryLine = (props) => {
  console.log('OrderSummaryLine/', { props });
  const [state, setState] = useState({
    lblOrderNumber: 'Order number:',
    valOrderNumber: '',
    valOrderStatus: '',
    valAccNumber: '',
    valViewTogether: props.lovIndicator === 'YY' ? 'Yes' : 'No',
  });

  /**
   * Checks if the order is considered incomplete based on header status AND cart status values.
   *
   * @returns {boolean}
   */
  const isIncomplete = () => {
    console.log('isIncomplete/', props.cartHeaderStatus, props.orderStatus);
    const bool =
      props.orderStatus === 'OM' || (props.orderStatus === 'CR' && !['P', 'C'].includes(props.cartHeaderStatus));
    return bool;
  };

  // recalculate labels & values when props change
  useEffect(() => {
    console.log('OrderLineSummary/useEffect/', { props, state });

    let lblOrderNumber = 'Order number:';
    if (isIncomplete()) {
      lblOrderNumber = `Incomplete ${lblOrderNumber}`;
    }
    const valViewTogether = props.lovIndicator === 'YY' ? 'Yes' : 'No';
    const valOrderNumber = props.orderNumberAry?.filter((orderNumber) => orderNumber !== 0)?.join('/');
    const valAccNumber = props.customerId;
    const valOrderStatus = props.orderStatus;

    setState({
      lblOrderNumber,
      valViewTogether,
      valOrderNumber,
      valAccNumber,
      valOrderStatus,
    });
  }, [props]);

  return (
    <FlexRow id={props.id} data-testid='order-summary-line'>
      <Section>
        <Micro color='#00000' bold='true' primitive='span'>
          {state.lblOrderNumber}&nbsp;&nbsp;
        </Micro>
        <Title size='small'>{state.valOrderNumber}</Title>
      </Section>
      <Section>
        <Micro color='#00000' bold='true' primitive='span'>
          Order Status:&nbsp;&nbsp;
        </Micro>
        <Title size='small'> {state.valOrderStatus}</Title>
      </Section>
      <Section>
        <Micro color='#00000' bold='true' primitive='span'>
          Acc number:&nbsp;&nbsp;
        </Micro>
        <Title size='small'>{state.valAccNumber}</Title>
      </Section>
      {props.lovIndicator && (
        <Section>
          <Micro color='#00000' bold='true' primitive='span'>
            View Together:&nbsp;&nbsp;
          </Micro>
          <Title size='small'>{state.valViewTogether}</Title>
        </Section>
      )}
    </FlexRow>
  );
};

OrderSummaryLine.propTypes = {
  orderStatus: PropTypes.string.isRequired,
  cartHeaderStatus: PropTypes.string.isRequired,
  lovIndicator: PropTypes.string.isRequired,
  orderNumberAry: PropTypes.arrayOf(PropTypes.string).isRequired,
  customerId: PropTypes.string.isRequired,
  id: PropTypes.string,
};

export default OrderSummaryLine;

const FlexRow = styled.div`
  font-family: BrandFontRegular, Sans-serif !important;
  font-size: 1.2rem !important;
  display: block;
  margin: 0;
  padding: 7px 8px;
  width: 1024px;
`;

const Section = styled.span`
  display: flex;
  align-items: baseline;
  float: left;
  // flex: 1 1 auto; /* Grow and shrink as needed */
  // justify-content: space-between;
  line-height: 24px;
  max-width: 100%;
  vertical-align: baseline;
  margin: 0;
  span {
    font-size: 15px;
    white-space: nowrap;
    margin-left: 0.875rem;
    line-height: 24px;
  }
`;
