import React from 'react';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import OrderSummaryLine from './OrderSummaryLine';

const baseProps = {
  orderStatus: '',
  cartHeaderStatus: '',
  lovIndicator: 'not yy',
  orderNumberAry: ['123123'],
};
describe('OrderSummaryLine Component', () => {
  let props = baseProps;

  beforeEach(() => {
    // reset props that may have been changed
    props = baseProps;
  });

  it('renders OrderSummaryLine component with order details', () => {
    const { getByTestId } = render(<OrderSummaryLine {...props} />);
    const orderSummaryLine = getByTestId('order-summary-line');
    expect(orderSummaryLine).toBeInTheDocument();
  });

  describe('Order Number', () => {
    it('displays a single order number', () => {
      props.orderNumberAry = ['123123'];
      const { getByTestId } = render(<OrderSummaryLine {...props} />);
      const orderSummaryLine = getByTestId('order-summary-line');
      expect(orderSummaryLine).toHaveTextContent('Order number: 123123');
    }); // displays a single order number

    it('displays multiple order numbers with slashes', () => {
      props.orderNumberAry = ['123123', '234234'];
      const { getByTestId } = render(<OrderSummaryLine {...props} />);
      const orderSummaryLine = getByTestId('order-summary-line');
      expect(orderSummaryLine).toHaveTextContent('Order number: 123123/234234');
    }); // displays multiple order numbers

    it('displays "Incomplete" order number when orderStatus === "CR" & cartHeaderStatus is not "P" or "C"', () => {
      props.orderStatus = 'CR';
      props.cartHeaderStatus = 'notPorC';
      const { getByTestId } = render(<OrderSummaryLine {...props} />);
      const orderSummaryLine = getByTestId('order-summary-line');
      expect(orderSummaryLine).toHaveTextContent('Incomplete Order number: 123123');
    }); // displays "Incomplete" order number

    it('displays "Incomplete" order number when orderStatus === "OM"', () => {
      props.orderStatus = 'OM';
      const { getByTestId } = render(<OrderSummaryLine {...props} />);
      const orderSummaryLine = getByTestId('order-summary-line');
      expect(orderSummaryLine).toHaveTextContent('Incomplete Order number: 123123');
    }); // displays "Incomplete" order number

    it('does not display "Incomplete" when orderStatus not "CR"', () => {
      props.orderStatus = 'notCR';
      const { getByTestId } = render(<OrderSummaryLine {...props} />);
      const orderSummaryLine = getByTestId('order-summary-line');
      expect(orderSummaryLine).toHaveTextContent('Order number: 123123');
    }); // doesn't display "Incomplete" order number

    it('does not display "Incomplete" when orderStatus is "CR" & cartHeaderStatus is "P"', () => {
      props.orderStatus = 'CR';
      props.cartHeaderStatus = 'P';
      const { getByTestId } = render(<OrderSummaryLine {...props} />);
      const orderSummaryLine = getByTestId('order-summary-line');
      expect(orderSummaryLine).toHaveTextContent('Order number: 123123');
    }); // doesn't display "Incomplete" order number

    it('does not display "Incomplete" when orderStatus is "CR" & cartHeaderStatus is "C"', () => {
      props.orderStatus = 'CR';
      props.cartHeaderStatus = 'C';
      const { getByTestId } = render(<OrderSummaryLine {...props} />);
      const orderSummaryLine = getByTestId('order-summary-line');
      expect(orderSummaryLine).toHaveTextContent('Order number: 123123');
    }); // doesn't display "Incomplete" order number
  }); // Order Number

  describe('Order Status', () => {
    it('displays the order status', () => {
      props.orderStatus = 'CO';
      const { getByTestId } = render(<OrderSummaryLine {...props} />);
      const orderSummaryLine = getByTestId('order-summary-line');
      expect(orderSummaryLine).toHaveTextContent('Order Status: CO');
    }); // displays order status
  }); // Order Status

  describe('Acc number (customerId)', () => {
    it('displays the Account number (customerId)', () => {
      props.customerId = '987654321';
      const { getByTestId } = render(<OrderSummaryLine {...props} />);
      const orderSummaryLine = getByTestId('order-summary-line');
      expect(orderSummaryLine).toHaveTextContent(`Acc number: ${props.customerId}`);
    }); // displays account number
  }); // Acc number

  describe('View Together', () => {
    it('Show "View Together: Yes" when lovIndicator === "YY"', () => {
      props.lovIndicator = 'YY';
      const { getByTestId } = render(<OrderSummaryLine {...props} />);
      const orderSummaryLine = getByTestId('order-summary-line');
      const textContent = orderSummaryLine.textContent.replace(/\s+/g, ' ').trim(); // Normalize spaces
      expect(textContent).toContain(
        'Order number: 123123/234234Order Status: COAcc number: 987654321View Together: Yes', // Match the received string
      );
    }); // Show "View Together => Yes"

    it('Show "View Together: No" when lovIndicator is NOT "YY"', () => {
      props.lovIndicator = 'notYY';
      const { getByTestId } = render(<OrderSummaryLine {...props} />);
      const orderSummaryLine = getByTestId('order-summary-line');
      const textContent = orderSummaryLine.textContent.replace(/\s+/g, ' ').trim(); // Extract text and normalize spaces
      expect(textContent).toContain(
        'Order number: 123123/234234Order Status: COAcc number: 987654321View Together: No', // Match the received string
      );
    }); // Show "View Together => No"
  }); // View Together
});
