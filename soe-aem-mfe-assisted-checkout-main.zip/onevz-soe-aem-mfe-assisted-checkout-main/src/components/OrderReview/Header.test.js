import { fireEvent, render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../modules/store';
import Header from './Header';
import retriveCartJson from '../../__mock__/retrive-cart.json';
import retrieveReadOrder from '../../__mock__/readOrder.json';

const mockedUsedNavigate = jest.fn();

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockedUsedNavigate,
}));
jest.mock('onevzsoemfecommon/LOVPageTracker', () => ({
  __esModule: true,
  default: ({ viewCreditModal }) => (
    <button type='button' data-testid='mocked-closeModal' onClick={viewCreditModal}>
      closeModal PreviewBill Mock
    </button>
  ),
}));

describe('Header Component', () => {
  beforeEach(() => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ enablePartialNbsPosFFlag: 'TRUE' }));
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ enableFullBlownMfeNbsPosFFlag: 'TRUE' }));
  });
  test('renders Header', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <Header />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByText(/Order review/i);
    expect(titleElement).toBeInTheDocument();
  });

  test('Should redirect to Shop Landing Page once user click on back button', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <Header data={retriveCartJson} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const backButton = screen.getByTestId('btn-back');
    fireEvent.click(backButton);
    expect(mockedUsedNavigate).toHaveBeenCalled();
    expect(mockedUsedNavigate).toHaveBeenCalledWith('/sales/assisted/new/handoff.html');
  });

  test('Should redirect to Shop Landing Page once user click on back button 01', () => {
    const mockhistroyRef = jest.fn();
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: jest.fn() };
    window.mfe.historyRef.push = mockhistroyRef;

    render(
      <BrowserRouter>
        <StoreProvider>
          <Header data={retriveCartJson} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const backButton = screen.getByTestId('btn-back');
    fireEvent.click(backButton);
    expect(mockhistroyRef).toHaveBeenCalled();
  });

  test('Should redirect to Shop Landing Page once user click on back button 02', () => {
    const closeIcon = false;
    window.mfe = { scmCheckoutMfeEnable: false };

    render(
      <BrowserRouter>
        <StoreProvider>
          <Header data={retriveCartJson} closeIcon={closeIcon} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const backButton = screen.getByTestId('btn-back');
    fireEvent.click(backButton);
    expect(mockedUsedNavigate).toHaveBeenCalled();
    expect(mockedUsedNavigate).toHaveBeenCalledWith('/sales/assisted/new/handoff.html');
  });

  test('Should redirect to Shop Landing Page once user click on back button', () => {
    const onBackClick = jest.fn();
    render(
      <BrowserRouter>
        <StoreProvider>
          <Header data={retriveCartJson} onBackClick={onBackClick} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const backButton = screen.getByTestId('btn-back');
    fireEvent.click(backButton);
    expect(onBackClick).toHaveBeenCalled();
  });

  test('Should redirect to Shop Landing Page once user click on back button 02', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: jest.fn() };
    window.mfe.historyRef.push = jest.fn();
    render(
      <BrowserRouter>
        <StoreProvider>
          <Header data={retriveCartJson} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const backButton = screen.getByTestId('btn-back');
    fireEvent.click(backButton);
  });

  test('renders isDarl true', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Header />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByText(/Order review/i);
    expect(titleElement).toBeInTheDocument();
  });

  test('scm checkout flag off', () => {
    window.mfe = { scmCheckoutMfeEnable: false, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Header />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByText(/Order review/i);
    expect(titleElement).toBeInTheDocument();
  });

  test(' isDark false', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: false, themeProps: { background: '#eeeeee' } };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Header />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByText(/Order review/i);
    expect(titleElement).toBeInTheDocument();
  });
});

export const getReadOrderFlag = () => {
  const appProperties = JSON.parse(sessionStorage.getItem('APP_PROPERTIES'));
  return appProperties?.readOrderMfeFFlag === 'TRUE';
};

describe('Header Component', () => {
  beforeEach(() => {
    window.mfe = { scmDeviceMfeEnable: true, scmCheckoutMfeEnable: true, scmUpgradeMfeEnable: true };
    window.mfe.historyRef = jest.fn();
    window.mfe.historyRef.push = jest.fn();
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ readOrderMfeFFlag: 'TRUE' }));
  });

  beforeAll(() => {
    window.mfe = { scmCheckoutMfeEnable: true };
  });

  afterEach(() => {
    jest.clearAllMocks();
    jest.resetAllMocks();
    jest.restoreAllMocks();
  });

  it('should set z-index to 2 and top to 3rem when scmCheckoutMfeEnabled is true', () => {
    const resp = { ...retriveCartJson };
    resp.data.cart.cartHeader.status = 'P';

    window.mfe = { scmCheckoutMfeEnable: true };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Header readOrder readOrderData={resp} />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  it('should set z-index to 2 and top to 3rem when scmCheckoutMfeEnabled is true', () => {
    window.mfe = { scmCheckoutMfeEnable: true };

    // Render the Header component
    render(
      <BrowserRouter>
        <StoreProvider>
          <Header readOrder readOrderData={retrieveReadOrder} />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('should map lineActivityType from lineInfo correctly', () => {
    const mockReadOrderData = {
      cart: {
        lineDetails: {
          lineInfo: [{ lineActivityType: 'REF' }, { lineActivityType: 'DOE' }, { lineActivityType: 'OTHER' }],
        },
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <Header readOrderData={mockReadOrderData} />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  it('should render for new customer', () => {
    const resp = { ...retriveCartJson };
    resp.data.cart.cartHeader.status = 'P';
    resp.data.cart.cartHeader.cartCreator = '';

    render(
      <BrowserRouter>
        <StoreProvider>
          <Header isQAFlow setIsNewCustomer={jest.fn()} data={resp} />
        </StoreProvider>
      </BrowserRouter>,
    );
  });
});
describe('Header Component - isAcssProspectNewCustomerTab Behavior', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    jest.resetAllMocks();
    window.mfe = {};
  });

  it('should render ProspectFixedHeaderStyle when isAcssProspectNewCustomerTab is true', () => {
    window.mfe = {
      isProspectNewCustomerTab: true,
      scmCheckoutMfeEnable: true,
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Header />
        </StoreProvider>
      </BrowserRouter>,
    );
    const headerElement = screen.getByTestId('header');
    expect(headerElement).toHaveStyle('top: 0');
    expect(headerElement).toHaveStyle('z-index: 1');
  });
  it('should render ProspectFixedHeaderStyle when isAcssProspectNewCustomerTab is true', () => {
    window.mfe = {
      isProspectNewCustomerTab: true,
      scmCheckoutMfeEnable: false,
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Header />
        </StoreProvider>
      </BrowserRouter>,
    );
    const headerElement = screen.getByTestId('header');
    expect(headerElement).toHaveStyle('top: 0');
    expect(headerElement).toHaveStyle('z-index: 1');
  });
  it('should render ProspectFixedHeaderStyle when isAcssProspectNewCustomerTab is true', () => {
    window.mfe = {
      isProspectNewCustomerTab: false,
      scmCheckoutMfeEnable: false,
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Header />
        </StoreProvider>
      </BrowserRouter>,
    );
    const headerElement = screen.getByTestId('header');
    expect(headerElement).toHaveStyle('top: 0px');
    expect(headerElement).toHaveStyle('z-index: 1');
  });

  // it('should render FixedHeaderStyle when isAcssProspectNewCustomerTab is false', () => {
  //   window.mfe.isProspectNewCustomerTab = false;
  //   render(
  //     <BrowserRouter>
  //       <StoreProvider>
  //         <Header />
  //       </StoreProvider>
  //     </BrowserRouter>,
  //   );
  //   const headerElement = screen.getByTestId('header');
  //   expect(headerElement).toHaveStyle('position: fixed');
  //   expect(headerElement).toHaveStyle('top: 0px');
  // });

  // it('should render ShopWrapper with width 400px when isAcssProspectNewCustomerTab is true', () => {
  //   window.mfe.isProspectNewCustomerTab = true;
  //   sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ enablePartialNbsPosFFlag: 'TRUE' })); // Ensure isPartialNbs is true
  //   render(
  //     <BrowserRouter>
  //       <StoreProvider>
  //         <Header />
  //       </StoreProvider>
  //     </BrowserRouter>,
  //   );
  //   const shopWrapper = screen.getByText((content) => content.includes('Est.')).closest('div');
  //   expect(shopWrapper).toHaveStyle('width: 400px');
  // });

  // it('should render ShopWrapper with width 354px when isAcssProspectNewCustomerTab is false', () => {
  //   window.mfe.isProspectNewCustomerTab = false;
  //   sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ enablePartialNbsPosFFlag: 'FALSE' })); // Ensure isPartialNbs is false
  //   render(
  //     <BrowserRouter>
  //       <StoreProvider>
  //         <Header />
  //       </StoreProvider>
  //     </BrowserRouter>,
  //   );
  //   const shopWrapper = screen.getByText((content) => content.includes('Est.')).closest('div');
  //   expect(shopWrapper).toHaveStyle('width: 354px');
  // });

  // it('should render ShopWrapper with width 375px when isAcssProspectNewCustomerTab is true for "Due today"', () => {
  //   window.mfe.isProspectNewCustomerTab = true;
  //   render(
  //     <BrowserRouter>
  //       <StoreProvider>
  //         <Header />
  //       </StoreProvider>
  //     </BrowserRouter>,
  //   );
  //   const shopWrapper = screen.getByText(/Due today/i).closest('div');
  //   expect(shopWrapper).toHaveStyle('width: 375px');
  // });

  // it('should render ShopWrapper with width 286px when isAcssProspectNewCustomerTab is false for "Due today"', () => {
  //   window.mfe.isProspectNewCustomerTab = false;
  //   render(
  //     <BrowserRouter>
  //       <StoreProvider>
  //         <Header />
  //       </StoreProvider>
  //     </BrowserRouter>,
  //   );
  //   const shopWrapper = screen.getByText(/Due today/i).closest('div');
  //   expect(shopWrapper).toHaveStyle('width: 286px');
  // });
});
