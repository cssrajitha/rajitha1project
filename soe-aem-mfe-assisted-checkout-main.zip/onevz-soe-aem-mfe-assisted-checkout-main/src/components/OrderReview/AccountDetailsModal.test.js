import { render, screen, fireEvent } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../modules/store';
import cartJson from '../../__mock__/retrive-cart.json';
import AccountDetailsModal from './AccountDetailsModal';

const mockToggleModal = jest.fn();

window = Object.create(window);
const url = 'http://localhost';
Object.defineProperty(window, 'location', {
  value: {
    href: url,
  },
  writable: true, // possibility to override
});

describe('AccountDetailsModal Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  const planReferences = [
    {
      planId: '50427',
      monthlyAccessCharge: 60.0, // old
      description: 'oldDescription',
      displayName: 'oldDisplayName',
      featureText: 'oldFeatureText',
      dataOverageAllowance: '20',
      dataOverateAmount: '10',
      dataUnitOfMeasure: '2',
    },
    {
      planId: '33333',
      monthlyAccessCharge: 70.0, // new
      description: 'newDescription',
      displayName: 'newDisplayName',
      featureText: 'newFeatureText',
      dataOverageAllowance: '30',
      dataOverateAmount: '15',
      dataUnitOfMeasure: '1',
    },
  ];

  const renderComponent = (lineInfo = cartJson.data.cart.lineDetails.lineInfo, isPrepay = false) => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccountDetailsModal
            lineInfo={lineInfo}
            opened
            planId='1234'
            isPrepay={isPrepay}
            toggleModal={mockToggleModal}
            mtn='345'
            cart={cartJson.data.cart}
            planReferences={planReferences}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  };

  const renderComponentBlank = () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccountDetailsModal cart={cartJson.data.cart} />
        </StoreProvider>
      </BrowserRouter>,
    );
  };

  test('renders accountDetails', () => {
    renderComponent();
    const titleElement = screen.getByTestId('accountDetailsModal');
    expect(titleElement).toBeInTheDocument();
  });

  test('renders accountDetails', () => {
    renderComponentBlank();
    const titleElement = screen.getByTestId('accountDetailsModal');
    expect(titleElement).toBeInTheDocument();
  });

  test('renders AccountDetails without isCPC', () => {
    const { lineInfo } = cartJson.data.cart.lineDetails;
    const { oldPricePlanId, ...serviceInfo } = lineInfo[0].serviceInfo;
    renderComponent([{ ...lineInfo[0], serviceInfo }]);
    const titleElement = screen.getByTestId('accountDetailsModal');
    expect(titleElement).toBeInTheDocument();
  });

  test('renders AccountDetails without isCPC', () => {
    const { lineInfo } = cartJson.data.cart.lineDetails;
    lineInfo[0].serviceInfo.selectedALPShareList.alpShareInfo = [];
    renderComponent(lineInfo);
    const titleElement = screen.getByTestId('accountDetailsModal');
    expect(titleElement).toBeInTheDocument();
  });

  test('Modal done click', async () => {
    renderComponent();
    const DoneBtn = screen.getByText(/Done/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
    expect(mockToggleModal).toHaveBeenCalledWith(false);
  });

  test('Modal Change Plans click', async () => {
    renderComponent();
    global.window.vzdl = { page: { detail: '' } };
    const DoneBtn = screen.getByText(/Change Plan/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
    expect(window.location.href).toBe(`/sales/assisted/plan-selection.html`);
  });

  test('Modal Change Plans click with mfe true', async () => {
    renderComponent();
    global.window.vzdl = { page: { detail: '' } };
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ isPlansMFEEnabled: 'TRUE' }));
    const DoneBtn = screen.getByText(/Change Plan/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
    expect(window.location.href).toBe(`/sales/assisted/new/gridwall.html?activeMtn=345&isPlanTabSelect=true`);
  });

  test('Modal Change Plans click with isPrepay true', async () => {
    renderComponent(cartJson.data.cart.lineDetails.lineInfo, true);
    global.window.vzdl = { page: { detail: '' } };
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ isPlansMFEEnabled: 'TRUE' }));
    const DoneBtn = screen.getByText(/Change Plan/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
    expect(window.location.href).toBe(`/sales/assisted/shop-plans.html`);
  });

  test('Modal Change effective date click', async () => {
    renderComponent(cartJson.data.cart.lineDetails.lineInfo, true);
    global.window.vzdl = { page: { detail: '' } };
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ isPlansMFEEnabled: 'TRUE' }));
    const DoneBtn = screen.getByTestId('change-date');
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
    expect(window.location.href).toBe(`/sales/assisted/home.html`);
  });
});
