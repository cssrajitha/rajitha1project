import { dataSetter, executeDealy, getClientAppName } from './utility';

const mockedData = [
  {
    itemType: 'ACCESSORY',
    mtn: '7736781234',
    sorSkuId: 'UHRA-RT-05',
    itemDescription: 'Ring AIR - Size 5 - Raw Titanium',
    itemPrice: 349.99,
    manualDiscountPrice: 0,
    itemSeq: '1',
    manualDiscountAdjustmentFLag: false,
    imageURL: {
      defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/UHRA-RT-05-iset',
      largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/UHRA-RT-05-iset?$acc-lg$',
      mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/UHRA-RT-05-iset?$acc-med$',
      miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/UHRA-RT-05-iset?$acc-mini$',
      thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/UHRA-RT-05-iset?$acc-thumb$',
    },
    manualDiscountDescription: 'Cust Service Initiated Discount',
    priceAfterDiscount: 195.99,
    mgrApprovalReq: 'Y',
    qty: 1,
    isRefundCartItem: false,
    discountPercent: null,
    discountAmount: 1,
    discountedPrice: 348.99,
  },
  {
    itemType: 'ACCESSORY',
    mtn: '7736781234',
    sorSkuId: 'JBLSNDGEARSNSBLKAM',
    itemDescription: 'Soundgear Sense Open-Ear Headphones - Black',
    itemPrice: 149.99,
    manualDiscountPrice: 0,
    itemSeq: '2',
    manualDiscountAdjustmentFLag: false,
    imageURL: {
      defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset',
      largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-lg$',
      mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-med$',
      miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-mini$',
      thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-thumb$',
    },
    sedOfferList: {
      sedOffer: [
        {
          offerId: '428422',
          itemSeqNum: 0,
          description: 'ACC Save up to $60 Select JBL Products',
          offerType: 'ITA',
          itemMonthlyDiscount: 30,
          itemMonthlyDiscountedPrice: 119.99,
          discountedRetailPrice: 119.99,
          discAmt: '30.00',
          discPrcnt: 0,
          priceInfo: {
            basePriceUsed: 'Y',
          },
          rebatesAllowed: 'N',
          barcodeID: '',
          promoBadges: [
            {
              badgeText: 'Save $XX',
              placement: 'ITEM-HEADER',
              pageId: 'CART',
              masterpageId: 'CART',
            },
          ],
          itemMonthlyRetailPrice: 149.99,
          isStrategicOffer: false,
        },
      ],
      count: 0,
    },
    manualDiscountDescription: 'Other Authorized Programs',
    priceAfterDiscount: 109.99,
    mgrApprovalReq: 'N',
    qty: 1,
    isRefundCartItem: false,
    dType: '$',
    discountPercent: null,
    discountAmount: null,
    discountedPrice: null,
    reason: null,
    reasonText: null,
  },
];

const mockedNewData = {
  itemType: 'ACCESSORY',
  mtn: '7736781234',
  sorSkuId: 'UHRA-RT-05',
  itemDescription: 'Ring AIR - Size 5 - Raw Titanium',
  itemPrice: 349.99,
  manualDiscountPrice: 0,
  itemSeq: '1',
  manualDiscountAdjustmentFLag: false,
  imageURL: {
    defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/UHRA-RT-05-iset',
    largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/UHRA-RT-05-iset?$acc-lg$',
    mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/UHRA-RT-05-iset?$acc-med$',
    miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/UHRA-RT-05-iset?$acc-mini$',
    thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/UHRA-RT-05-iset?$acc-thumb$',
  },
  manualDiscountDescription: 'Cust Service Initiated Discount',
  priceAfterDiscount: 195.99,
  mgrApprovalReq: 'Y',
  qty: 1,
  isRefundCartItem: false,
  discountPercent: null,
  discountAmount: 12,
  discountedPrice: 337.99,
};

describe('Check utility', () => {
  jest.useFakeTimers();
  test('execute the callback', () => {
    const mockCallback = jest.fn();
    executeDealy(mockCallback, 4000, false);
    jest.advanceTimersByTime(4000);

    expect(mockCallback).toHaveBeenCalledTimes(1);
  });

  test('data setter utility', () => {
    dataSetter(jest.fn(), mockedData, mockedNewData);
  });
});

describe('Check utility', () => {
  test('execute the getclientappname', () => {
    sessionStorage.setItem("channel","OMNI-TELESALES");
    getClientAppName();
    sessionStorage.clear();
    sessionStorage.setItem("channel","OMNI-RETAIL-TAB");
    getClientAppName();
    sessionStorage.clear();
    sessionStorage.setItem("channel","OMNI-RETAIL");
    getClientAppName();
    sessionStorage.clear();
    getClientAppName();
  });

  test('data setter utility', () => {
    dataSetter(jest.fn(), mockedData, mockedNewData);
  });
});
