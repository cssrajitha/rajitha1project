import React, { useEffect, useState } from 'react';
import { isVbg } from 'onevzsoemfeframework/VbgAemUtil';
import { Modal, ModalFooter } from '@vds/modals';
import PropTypes from 'prop-types';
import { Icon } from '@vds/icons';
import { Notification } from '@vds/notifications';
import { TextLinkCaret, Button } from '@vds/buttons';
import Emitter from 'onevzsoemfeframework/Emitter';
import { Title, Body } from '@vds/typography';
import styled, { createGlobalStyle } from 'styled-components';
import { getUIContextPathBAU } from 'onevzsoemfecommon/Helpers';
import { useNavigate } from 'react-router-dom';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { useUpdateTradeInMutation } from '../../modules/services/APIService/APIServiceHooks';
import { formatCurrency } from '../../utils/common';
import { BackClickable } from '../../StyledConstants';
import { invokeTagging } from '../../utils/test-utils/utils';
import { tradeInConstants } from '../../appconfig';

const FixedHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0rem 1.5rem 2rem 1.5rem;
  border-bottom: 1px solid #d8dada;
`;

const CloseIconWrapper = styled.div`
  cursor: pointer;
`;

const MarginSides = styled.div`
  margin-top: 30px;
`;

const FlexBoxGrowOne = styled.div`
  display: flex;
  flex-grow: 1;
  height: 4rem;
`;

const LineSeperator = styled.div`
  width: 1px;
  height: 50px;
  background: #000000;
  top: 1rem;
  border-right: 1px solid #d8dada;
  position: relative;
  margin-right: 10px;
`;

const HorizontalLine = styled.div`
  border: none;
  border-top: 1px solid rgba(0, 0, 0, 0.3);
  margin: 10px 0;
  width: 270%;
`;

const SpaceBetween = styled.div`
  margin-bottom: 20px;
`;

const Container = styled.div`
  display: flex;
  align-items: center;
  padding: 10px;
`;
const Container2 = styled.div`
  display: flex;
  align-items: center;
  padding: 10px;
  transform: translate(170px, -270px);
  margin-bottom: -270px;
`;
const Container3 = styled.div`
  display: flex;
  align-items: center;
  padding-left: 200px;
`;
const VerticlaAlign = styled.div`
  flex-direction: column;
  padding: 20px;
`;

const CenteredText = styled.div`
  display: flex;
  justify-content: center;
  height: 50vh;
  text-align: center;
  font-size: 20px;
  font-family: BrandFont-Text, Arial, sans-serif;
  padding: 65px;
`;

const ContainerFont = styled.div`
  [class^='StyledTypography-VDS__'] {
    font-size: 18px !important;
    font-family: BrandFontBold, sans-serif !important;
  }
`;

const DeviceFont = styled.div`
  font-size: 18px !important;
  font-family: BrandFontRegular, sans-serif !important;
`;

const TriageFont = styled.div`
  [class^='StyledTypography-VDS__'] {
    font-size: 16px !important;
    font-family: BrandFontRegular, sans-serif !important;
  }
`;

const BottomText = styled.div`
  position: fixed;
  bottom: 0;
  left: 200px;
  margin: 100px;
  transform: translate(0px, -30px);
`;

const ComponentStyle = createGlobalStyle`
  #deviceModal {
    [class^='Overlay-VDS'] {
      background-color: black;
    }
    [class^='ModalDialog-VDS'] {
      max-width:1024px; 
      border-radius: 0;
      padding: 0;
    }
    [class^='ModalDialogWrapper-VDS'] {
      padding:0;
        > span {
          width: 100%;
          height: 100%;
        > div {
          width:100% !important;
          height: 100% !important;
          > div {
            padding:0 !important;
          }
        }
      }
    }
    [class^='IconWrapper-VDS'] {
      z-index: 99999;
    }
    
    [class^='StyledHeader-VDS'] {
      border-bottom: 1px solid #ccc;
      position: sticky;
      top:0;
      background: #fff;
      z-index: 999;
      padding: 1rem 0;
    }
    [class^='StyledFooter-VDS'] {
      border-top: 1px solid #ccc;
      position: static;
      bottom:0;
      background: #fff;
      padding-top: 2rem;
    }
  }
  [class^='ButtonGroupRow-VDS']{
    flex-direction:row-reverse;
    > div {
      padding-right:0.75rem;
    }
  }
  .preview-bill-body [class^='TriggerIconWrapper-VDS']{
    display: none;
  }
  [class^='InnerElementWrapper-VDS']{
    padding: 0;
    min-height: auto;
  }
  .preview-bill-body [class^='StyledLine-VDS']{
    background-color: #000;
  }
`;

const IconPosition = styled.div`
  transform: translate(650px, 0px);
`;

const IconPositionRemove = styled.div`
  transform: translate(700px, 0px);
`;

const CaretWrapper = styled.a`
  font-size: 18px !important;
  font-family: BrandFontBold, sans-serif !important;
  position: relative;
  text-decoration: none;
  color: blue;
  cursor: pointer;
  display: inline-block;
  padding-right: 5px;

  &:hover::after {
    transform: translate(650px, 0px);
    content: '';
    display: block;
    position: absolute;
    left: 0;
    bottom: -2px;
    width: 100%;
    height: 1px;
    background-color: black;
  }
`;

const ContainerFont2 = styled.div`
  [class^='StyledTypography-VDS__'] {
    font-size: 18px !important;
    font-family: BrandFontBold, sans-serif !important;
  }
`;

const RectangleBox = styled.div`
  display: ${(props) => (props.isOpen ? 'block' : 'none')};
  border: 1px solid #ccc;
  width: 80%;
  padding: 20px;
  margin-top: 10px;
  white-space: pre; /* Preserve spacing for inline elements */
`;
const ListItem = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin: 5px 0;
`;

const Value = styled.span`
  margin-left: 5px;
`;

const BoxAdjust = styled.div`
  white-space: normal;
`;
const BoldTextA = styled.div`
  font-weight: Bold;
  font-size: 18px !important;
  font-family: BrandFontBold, sans-serif !important;
`;
const DeviceContainer = styled.div`
  [class^='StyledTypography-VDS'] {
    display: flex;
  }
`;
const CashRight = styled.div`
  transform: translate(700px, -20px);
`;
const AbsoluteImage = styled.img`
  pointer-events: none;
`;

const ModalfooterPadding = styled.div`
  padding: 20px;
`;

const ImageWrapper = styled.img`
  width: 8.75rem;
  height: 13.5rem;
`;

const TradeSectionModalWrapper = styled.div`
  position: relative;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
`;

const PopupPosition = styled.div`
  position: absolute;
  width: 95% !important;
  padding: 1.75rem 2.25rem 1rem 1.5rem;
`;

const TradeItemWrapper = styled.div`
  display: flex;
  padding: 1rem 0rem 2rem 0rem;
`;

const TradeItemImageWrapper = styled.div`
  width: 8.75rem;
`;

const TradeItemDetails = styled.div`
  flex: 1;
  padding-left: 1rem;
  padding-top: 1rem;
`;

const TradeItemDescription = styled.div`
  line-height: 1.375;
  font-size: 24px;
  font-weight: bold;
`;

const TradeItemSKU = styled.div`
  line-height: 1.125;
  font-size: 14px;
  padding: 0.25rem 0;
`;

const TradeItemDeviceID = styled.div`
  line-height: 1.125;
  font-size: 14px;
  padding-bottom: 0.5rem;
`;

const TradeItemCredit = styled.div`
  display: grid;
  gap: 0;
  padding-top: 1rem;
`;

const GridRow = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 0;
  padding: 1rem 0rem 0.5rem 0rem;
  border-top: 1px solid #d8dada;

  &:first-child {
    padding: 1.5rem 0rem 0.5rem 0rem;
    border-top: none;
  }
`;

const GridColumnLeft = styled.div`
  font-size: 16px;
  color: black;
`;

const GridColumnRight = styled.div`
  text-align: right;
  font-size: 18px;
  font-weight: bold;
`;

const GridColumnRightbottom = styled.div`
  text-align: right;
  font-size: 18px;
`;

const FixedFooter = styled.div`
  position: fixed;
  bottom: 0px;
  justify-content: center;
  width: 100%;
  padding: 1.5rem;
  border-top: 1px solid #000 !important;
  left: 0;
  right: 0;
  display: inline-flex;
  background-color: #fff;
  z-index: 1;
`;

const StyledButton = styled(Button)`
  font-weight: bold;
  padding: 0.25rem 1.75rem 0.25rem 1.75em;
`;

const EditTradein = ({
  popupInfo,
  cartInfo,
  onRemove,
  opened,
  closeModal,
  tradeInItemstrade,
  tradeInDetailtrade,
  rfexType,
  refundreadOrder,
  lineInfo,
}) => {
  let navigate = '';
  function useNavigateMFE() {
    navigate = useNavigate();
  }
  try {
    useNavigateMFE();
  } catch (e) {
    console.error('Navigation error:-', e);
  }

  const [isReadOrderFlag] = getAssistedCradlePropertyV2(['refundReadOrderMfeFFlag']);
  const isReadOrderFlagEnabled = /true/i.test(isReadOrderFlag);
  const [showMessage, setshowMessage] = useState(true);
  const [updateTradein] = useUpdateTradeInMutation();

  const [showNotification, setshowNotification] = useState(false);
  const [removedDevice, setRemovedDevice] = useState(null);
  const [tradeInItems, setTradeInItems] = useState(popupInfo || []);

  // 🔧 VBG Detection: Check for VBG customers to determine device limit
  const cartLineinfo = cartInfo?.lineDetails?.lineInfo;
  const cartItems = cartInfo?.lineDetails?.lineInfo?.[0]?.itemsInfo?.[0]?.cartItems?.cartItem || [];
  const tradeIncredit = cartInfo?.cartHeader;
  const tradeInDetail = cartInfo?.lineDetails?.tradeInDetail;
  const instantCreditEligible = cartInfo?.lineDetails?.tradeInDetail?.instantCreditEligible;
  const cartCreatorChannelId = cartInfo?.cartHeader?.cartCreatorChannelId;
  const getOrderList = cartInfo?.orderDetails?.orderList;
  const isRemove = getOrderList?.length > 0 && getOrderList?.find((activity) => activity.orderActivityType === 'TIN');
  const tradeInempty = "There are no current Trade-in's for this account";
  const taxetatBottom = '*Taxes and fees may adjust the trade in credit';
  let filteredDevices = [];
  const [isOpen, setIsOpen] = useState(false);
  const scmCheckoutMfeEnabled = window?.mfe?.scmCheckoutMfeEnable;
  const [vbgNSAtradeInFlagRaw] = getAssistedCradlePropertyV2(['vbgNSAtradeInFFlag']);
  const vbgNSAtradeInFlagEnabled = /true/i.test(vbgNSAtradeInFlagRaw);
  const isVbgCustomer = isVbg() && vbgNSAtradeInFlagEnabled;
  const handleToggle = () => {
    setIsOpen(!isOpen);
  };
  cartLineinfo?.forEach((item) => {
    item?.itemsInfo?.forEach((info) => {
      if (Array.isArray(info?.cartItems?.cartItem)) {
        const filteredItems = info?.cartItems?.cartItem?.filter(
          (cartItem) => cartItem?.cartItemType?.toLowerCase() === 'device',
        );
        filteredDevices = [...filteredDevices, ...filteredItems];
      }
    });
  });

  const filteredDeviceItems = [];
  lineInfo?.forEach((line) => {
    line.itemsInfo?.forEach((itemInfo) => {
      itemInfo.refundCartItems?.cartItem?.forEach((item) => {
        if (['DEVICE'].includes(item.cartItemType)) {
          const updatedItem = { ...item, mobileNumber: line.mobileNumber };
          filteredDeviceItems.push(updatedItem);
        }
      });
    });
  });

  const tradeDescription = (description) => <TradeItemDescription>{description}</TradeItemDescription>;

  const displayDescription = (item) => {
    let description = '';
    if (item?.recycleDeviceOffer?.dppCredit && parseFloat(item.recycleDeviceOffer.dppCredit) > 0) {
      const bicCreditDPTerm = item?.recycleDeviceOffer?.bicCreditDpTerm ?? 24;
      const appliedPrice = formatCurrency(parseFloat(item.recycleDeviceOffer.dppCredit));
      description = (
        <span>
          {appliedPrice}
          /mo credit for {bicCreditDPTerm} months
        </span>
      );
    } else {
      description = (
        <div>
          <span>{formatCurrency(item?.computedPrice)}</span>
        </div>
      );
    }
    return description;
  };

  let creditForActivationfee;
  let creditForActivationfee_taxSurcharge;
  cartItems?.map((item) => {
    if (
      (item.cartItemType.toLowerCase() === 'device' &&
        (item.instantCreditAmountUsed > 0 || item.instantCreditAmountUsedForTaxes > 0)) ||
      (item.cartItemType.toLowerCase() === 'accessory' &&
        (item.instantCreditAmountUsed > 0 || item.instantCreditAmountUsedForTaxes > 0))
    ) {
      filteredDevices.push(item);
    } else if (
      item.cartItemType === 'ACTIVATION_FEE' &&
      (item.instantCreditAmountUsed > 0 || item.instantCreditAmountUsedForTaxes > 0)
    ) {
      creditForActivationfee = item.instantCreditAmountUsed;
      creditForActivationfee_taxSurcharge = item.instantCreditAmountUsedForTaxes;
    }
    return;
  });

  const handleRemove = (deviceToRemove) => {
    if (isVbgCustomer) {
      // Remove device from local state
      const updatedTradeInItems = tradeInItems.filter((item) => item.deviceId !== deviceToRemove.deviceId);
      setTradeInItems(updatedTradeInItems);

      // Call UpdateTradein API with the same payload structure as TradeInfoTile
      let cartCreatorNc;
      if (cartInfo?.orderDetails?.orderList?.[0]?.creditApplication?.creditApplicationNum) {
        cartCreatorNc = cartInfo?.orderDetails?.orderList?.[0]?.creditApplication?.creditApplicationNum;
      } else if (cartInfo?.orderDetails?.quoteWithoutCredit) {
        cartCreatorNc =
          cartInfo?.lineDetails?.lineInfo?.[0]?.serviceInfo?.primaryUserInfo?.emailId ||
          cartInfo?.lineDetails?.lineInfo?.[0]?.serviceInfo?.primaryUserInfo?.address?.emailId;
      }

      // Determine intendType based on VBG customer status and existing customer type logic

      // Assuming customerType is available from props or can be derived from cartInfo
      const customerType = cartInfo?.cartHeader?.customerType || 'N';
      const intendType = customerType === 'N' ? 'NSE' : 'EUP';

      const request = {
        cartId: cartInfo?.cartHeader?.cartId,
        caseId: cartInfo?.cartHeader?.caseId,
        deviceId: deviceToRemove?.deviceId,
        action: 'REMOVE',
        intendType,
        intent: 'Upgrade',
        pageContext: 'TRADEIN',
        creditAppNum: cartCreatorNc,
      };

      updateTradein({ body: request });

      setRemovedDevice(deviceToRemove);
      setshowNotification(true);
      // Pass device information to parent component for removal
      onRemove(deviceToRemove);
    } else {
      setshowNotification(true);
      onRemove();
      setshowMessage(false);
    }
  };
  const handleClick = (btn) => {
    if (btn === 'done') {
      invokeTagging('closeView', '');
      closeModal();
    } else {
      invokeTagging('openView', 'Trade In');
      if (!scmCheckoutMfeEnabled) {
        if (isVbgCustomer) {
          navigate(`${getUIContextPathBAU()}/trade-in.html`);
        } else {
          navigate(`${getUIContextPathBAU()}/new/shop-tradein.html`);
        }
      } else {
        Emitter.emit('ACSS_SCM_DEVICE_SUBTAB', { subTab: 'DEVICE_TAB', targetTab: 'TRADEIN_TAB' });
      }
    }
  };

  // Device limit logic based on VBG customer status
  const maxDeviceLimit = isVbgCustomer ? 10 : 5;
  const currentDeviceCount = tradeInItems?.length || 0;
  const isDeviceLimitReached = currentDeviceCount >= maxDeviceLimit;
  useEffect(() => {
    setTradeInItems(popupInfo || []);
  }, [popupInfo]);

  useEffect(() => {}, [opened]);
  return (
    <>
      {!refundreadOrder && (
        <div>
          <ComponentStyle />
          <div data-testId='deviceModal'>
            <Modal
              id='deviceModal'
              fullScreenDialog={!scmCheckoutMfeEnabled}
              showCloseButton={!scmCheckoutMfeEnabled}
              modalHeight='100%'
              opened={opened}
              surface='light'
              width='100%'
              disableFocusLock
              closeButton={null}
              disableAnimation={false}
              disableOutsideClick={false}
              onOpenedChange={(open) => {
                if (!open) closeModal();
              }}
            >
              <FlexBoxGrowOne>
                <BackClickable data-testId='btn-back' onClick={closeModal}>
                  <Icon name='left-caret' size='XLarge' medium='true' />
                </BackClickable>
                <LineSeperator />
                <MarginSides>
                  <Title size='small' bold primitive='h1'>
                    Device trade in
                  </Title>
                </MarginSides>
              </FlexBoxGrowOne>

              <div data-testid='notification'>
                {showNotification && (
                  <Notification
                    type='success'
                    id='deviceID'
                    layout='vertical'
                    title={`Device ${removedDevice?.equipModel || removedDevice?.deviceId || ''} Removed Successfully`}
                    hideCloseButton={false}
                  />
                )}
              </div>
              <HorizontalLine />
              {(() => {
                // Determine what to show based on customer type and conditions
                const shouldShowItems = isVbgCustomer
                  ? tradeInItems && tradeInItems.length > 0
                  : showMessage && tradeInItems && tradeInItems.length > 0;

                if (shouldShowItems) {
                  return (
                    <>
                      {tradeInItems?.map((item) => (
                        <div key={item?.deviceId}>
                          <Container>
                            <div>
                              <AbsoluteImage src={item?.imgUrl} alt='Iphone' width='160px' />
                            </div>
                          </Container>
                          <Container2>
                            <VerticlaAlign>
                              <ContainerFont>
                                <Title size='small' bold primitive='h1'>
                                  {item?.equipModel}
                                </Title>
                              </ContainerFont>
                              <SpaceBetween />
                              <DeviceContainer>
                                <Title size='small' primitive='h1'>
                                  <BoldTextA>Device Id :</BoldTextA> <span>&nbsp;</span>{' '}
                                  <DeviceFont>{item?.deviceId}</DeviceFont>
                                </Title>
                              </DeviceContainer>
                              <SpaceBetween />
                              <div>
                                <CaretWrapper>
                                  <IconPosition>
                                    <TextLinkCaret
                                      type='standAlone'
                                      data-testid='Triage-Details'
                                      surface='light'
                                      disabled={false}
                                      size='large'
                                      onClick={handleToggle}
                                    >
                                      Triage Details
                                    </TextLinkCaret>
                                  </IconPosition>
                                </CaretWrapper>
                                <RectangleBox isOpen={isOpen}>
                                  <BoxAdjust>
                                    {item?.triageInfo?.triage?.map((item1) => (
                                      <ListItem key={item1?.questionText}>
                                        <TriageFont>
                                          <Body size='small'>{item1?.questionText}</Body>
                                        </TriageFont>
                                        <Value>
                                          <ContainerFont>
                                            <Body size='small' bold>
                                              {item1?.triageAnswer && item1?.triageAnswer === 'YES' ? 'Y' : 'N'}
                                            </Body>
                                          </ContainerFont>
                                        </Value>
                                      </ListItem>
                                    ))}
                                  </BoxAdjust>
                                </RectangleBox>
                              </div>
                              <SpaceBetween />
                              <ContainerFont2>
                                <Title size='small' bold primitive='h1'>
                                  {tradeIncredit?.cartCreatorChannelId === 'OMNI-INDIRECT'
                                    ? 'Total trade in value'
                                    : 'Total trade in credit'}{' '}
                                  <CashRight>
                                    <div>{formatCurrency(item?.appliedPrice)}</div>
                                  </CashRight>
                                </Title>
                                <SpaceBetween />
                                <HorizontalLine />
                                {!instantCreditEligible && (
                                  <div>
                                    {item?.creditType === 'ACT' && (
                                      <Title size='small' bold primitive='h1'>
                                        {tradeInConstants.accountTradeinType}
                                        <CashRight>
                                          <div>{formatCurrency(item?.appliedPrice)}</div>
                                        </CashRight>
                                      </Title>
                                    )}
                                    {item?.creditType === 'GFT' && (
                                      <Title size='small' bold primitive='h1'>
                                        {tradeInConstants.giftCardTradeInType}
                                        <CashRight>
                                          <div>{formatCurrency(item?.appliedPrice)}</div>
                                        </CashRight>
                                      </Title>
                                    )}
                                  </div>
                                )}
                                {(cartCreatorChannelId === 'OMNI-RETAIL' ||
                                  cartCreatorChannelId === 'OMNI-RETAIL-TAB') &&
                                !isRemove ? (
                                  <IconPositionRemove>
                                    <TextLinkCaret
                                      type='standAlone'
                                      data-testId='link'
                                      surface='light'
                                      disabled={false}
                                      size='large'
                                      onClick={() => handleRemove(item)}
                                    >
                                      Remove
                                    </TextLinkCaret>
                                  </IconPositionRemove>
                                ) : (
                                  ''
                                )}
                                <SpaceBetween />
                              </ContainerFont2>
                            </VerticlaAlign>
                          </Container2>
                        </div>
                      ))}
                      <SpaceBetween />
                      {filteredDevices?.map((item1) => (
                        <React.Fragment key={item1?.description}>
                          <Container3>
                            {item1?.instantCreditAmountUsedForTaxes > 0 && (
                              <Title size='small' bold primitive='h1'>
                                {tradeInConstants.creditTowardsTaxLabel} {item1?.manufacturer} &nbsp;
                                {item1?.description}&nbsp;
                                {item1?.capacity}
                                <CashRight>
                                  <div>{formatCurrency(item1?.instantCreditAmountUsedForTaxes)}</div>
                                </CashRight>
                              </Title>
                            )}
                          </Container3>
                          <Container3>
                            {item1?.instantCreditAmountUsed > 0 && (
                              <Title size='small' bold primitive='h1'>
                                {tradeInConstants.creditTowardsItemPriceLabel} {item1?.manufacturer} &nbsp;
                                {item1?.description}&nbsp;
                                {item1?.capacity}
                                <CashRight>
                                  <div>{formatCurrency(item1?.instantCreditAmountUsed)}</div>
                                </CashRight>
                              </Title>
                            )}
                          </Container3>
                        </React.Fragment>
                      ))}
                      {tradeInDetail?.instantCreditAmountRemaining > 0 && (
                        <Container3>
                          <Title size='small' bold primitive='h1'>
                            {tradeInConstants.creditTowardsAccountLabel}
                            <CashRight>
                              <div>{formatCurrency(tradeInDetail?.instantCreditAmountRemaining)}</div>
                            </CashRight>
                          </Title>
                        </Container3>
                      )}
                      {creditForActivationfee && creditForActivationfee > 0 && (
                        <Container3>
                          <Title size='small' bold primitive='h1'>
                            {tradeInConstants.creditTowardsActivationFee}
                            <CashRight>
                              <div>{formatCurrency(creditForActivationfee)}</div>
                            </CashRight>
                          </Title>
                        </Container3>
                      )}
                      {creditForActivationfee_taxSurcharge && creditForActivationfee_taxSurcharge > 0 && (
                        <Container3>
                          <Title size='small' bold primitive='h1'>
                            {tradeInConstants.creditTowardsActivationFeeSurcharge}
                            <CashRight>
                              <div>{formatCurrency(creditForActivationfee_taxSurcharge)}</div>
                            </CashRight>
                          </Title>
                        </Container3>
                      )}
                    </>
                  );
                }

                // Show empty state when no items or conditions not met
                return (
                  <>
                    <CenteredText> {tradeInempty} </CenteredText>
                    <BottomText>
                      {' '}
                      <Title size='small' bold primitive='h1'>
                        {taxetatBottom}
                      </Title>
                    </BottomText>
                  </>
                );
              })()}
              <ModalfooterPadding>
                <ModalFooter
                  buttonData={{
                    close: {
                      children: 'Done',
                      width: '225px',
                      use: 'primary',
                      onClick: () => handleClick('done'),
                    },
                    primary: {
                      children: 'Trade in more devices',
                      width: '225px',
                      use: 'secondary',
                      disabled: isVbgCustomer ? isDeviceLimitReached : false,
                      onClick: () =>
                        isVbgCustomer
                          ? !isDeviceLimitReached && handleClick('tradeInmoredevice')
                          : handleClick('tradeInmoredevice'),
                    },
                  }}
                />
              </ModalfooterPadding>
            </Modal>
          </div>
        </div>
      )}

      {isReadOrderFlagEnabled && refundreadOrder && (
        <TradeSectionModalWrapper data-testid='tradeSectionModal'>
          <FixedHeader>
            <Title size='small' bold color='#000'>
              Device trade in
            </Title>
            <CloseIconWrapper onClick={() => closeModal(rfexType)} data-testid='modal-close-button'>
              <Icon name='close' size='large' />
            </CloseIconWrapper>
          </FixedHeader>
          <PopupPosition>
            {tradeInItemstrade?.map((item) => (
              <TradeItemWrapper key={item.deviceId}>
                <TradeItemImageWrapper>
                  <ImageWrapper src={item?.imgUrl} alt={item?.deviceName} />
                </TradeItemImageWrapper>

                <TradeItemDetails>
                  {tradeDescription(item?.equipModel)}
                  <TradeItemSKU>
                    <span style={{ fontWeight: 'bold' }}>SKU:</span> {item?.recycleDeviceSku}
                  </TradeItemSKU>
                  <TradeItemDeviceID>
                    <span style={{ fontWeight: 'bold' }}>Device ID:</span> {item?.deviceId}
                  </TradeItemDeviceID>
                  <TradeItemCredit>
                    {item?.tradeInAutoPull === false && rfexType === 'refund'
                      ? 'Traded device returned to customer'
                      : ''}
                    <GridRow>
                      <GridColumnLeft>Maximum device recycle value</GridColumnLeft>
                      <GridColumnRight>{displayDescription(item)}</GridColumnRight>
                    </GridRow>
                  </TradeItemCredit>
                </TradeItemDetails>
              </TradeItemWrapper>
            ))}
            <GridRow>
              <GridColumnLeft>Total trade in credit</GridColumnLeft>
              <GridColumnRightbottom>{`${formatCurrency(
                tradeInDetailtrade?.instantCreditAmount ?? 0,
              )}`}</GridColumnRightbottom>
            </GridRow>
            {rfexType === 'refund' &&
              filteredDeviceItems?.map((Items) => (
                <GridRow key={Items.deviceId}>
                  <GridColumnLeft>
                    {`Credit Towards Tax on ${Items?.description ?? ''}. Line: (${Items?.mobileNumber ?? ''})`}
                  </GridColumnLeft>
                  <GridColumnRightbottom>
                    {`${formatCurrency(tradeInDetailtrade?.totalInstantCreditAmountForTaxes ?? 0)}`}
                  </GridColumnRightbottom>
                </GridRow>
              ))}
            {rfexType === 'refund' && (
              <GridRow>
                <GridColumnLeft>Credit to Customer Account</GridColumnLeft>
                <GridColumnRightbottom>{`${formatCurrency(
                  tradeInDetailtrade?.instantCreditAmountRemaining ?? 0,
                )}`}</GridColumnRightbottom>
              </GridRow>
            )}
          </PopupPosition>
          <FixedFooter>
            <StyledButton data-track='Done' type='submit' onClick={() => closeModal(rfexType)}>
              Done
            </StyledButton>
          </FixedFooter>
        </TradeSectionModalWrapper>
      )}
    </>
  );
};
EditTradein.propTypes = {
  opened: PropTypes.bool,
  closeModal: PropTypes.func,
  popupInfo: PropTypes.any,
  cartInfo: PropTypes.any,
  onRemove: PropTypes.func,
  rfexType: PropTypes.string,
  refundreadOrder: PropTypes.bool,
  tradeInDetailtrade: PropTypes.any,
  tradeInItemstrade: PropTypes.any,
  lineInfo: PropTypes.any,
};
export default EditTradein;
