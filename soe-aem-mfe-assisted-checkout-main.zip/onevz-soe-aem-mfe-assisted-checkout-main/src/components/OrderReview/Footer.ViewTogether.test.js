import React from 'react';
import { render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { useGetOffersPdpMutation } from 'onevzsoemfecommon/AccountAPIService';
import StoreProvider from '../../modules/store';
import Footer from './Footer';
import cartJson from '../../__mock__/retrive-cart.json';
import * as orderWriteAPICallHook from '../../modules/services/APIService/AgreementsAPICallHook';

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => jest.fn(),
}));

jest.mock('./VerizonOrAffirmFooter', () => ({
  __esModule: true,
  default: () => <div>Mocked VerizonOrAffirmFooter</div>,
}));

jest.mock('onevzsoemfecommon/AccountAPIService', () => ({
  useGetOffersPdpMutation: jest.fn(),
}));

jest.mock('onevzsoemfeframework/AssistedCradleService', () => ({
  __esModule: true,
  default: jest.fn(() => ({})),
  getAssistedCradlePropertyV2: () => ['FALSE'],
}));

jest.mock('../../utils/common', () => ({
  ...jest.requireActual('../../utils/common'),
  isServiceChangeFlag: jest.fn(() => false),
}));

import { isServiceChangeFlag } from '../../utils/common';

const mockIsServiceChangeFlag = isServiceChangeFlag;

const mockSaveOrder = jest.fn();

const mockData = {
  getOrderWrite: mockSaveOrder,
  getOrderWriteResult: { data: {} },
  getRetrieveInstallmentAgreement: mockSaveOrder,
  getRetrieveInstallmentAgreementResult: { data: {} },
  retrieveAEMInfoManagerDataRequest: mockSaveOrder,
  retrieveAEMInfoManagerDataResponse: null,
  updateAFOInfo: mockSaveOrder,
  getCustomerByMtns: mockSaveOrder,
  getCustomerByMtnsResult: { data: {} },
};

const baseProps = {
  cartDetailsResult: cartJson,
  customer: { regNo: '89878' },
  landing: {
    activeCartandCase: {
      cartId: 'f9a102c8-bd94-476b-8c36-f867597dc8ca',
      caseId: 'SOP-15788985-E01',
    },
    quoteDetails: [{ cartId: 'f9a102c8-bd94-476b-8c36-f867597dc8ca' }],
  },
  showAffirmModal: false,
  isAffirmLoanApproved: false,
  setShowAffirmModal: jest.fn(),
  setContinueBtnDisabled: jest.fn(),
  setShowAffirmAccordion: jest.fn(),
  getCartDetailsDataBody: jest.fn(),
  setEmailValue: jest.fn(),
  verizonVisaCardLinkSent: false,
  setCustomerMtns: jest.fn(),
  customerMtns: [],
  setShowRepGuidedScreen: jest.fn(),
  paperLessBilling: {},
  handleViewTogetherClick: jest.fn(),
  handleViewTogetherResumeClick: jest.fn(),
};

beforeAll(() => {
  class ResizeObserver {
    constructor() {
      this.observe = () => jest.fn();
      this.unobserve = () => jest.fn();
      this.disconnect = () => jest.fn();
    }
  }
  window.ResizeObserver = ResizeObserver;
});

beforeEach(() => {
  const getOffersMock = jest.fn();
  const getOffersResultsMock = {
    data: null,
    error: null,
    isLoading: false,
    isSuccess: false,
    isError: false,
  };
  useGetOffersPdpMutation.mockReturnValue([getOffersMock, getOffersResultsMock]);
  sessionStorage.setItem('channel', 'OMNI-RETAIL');
  jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);
  mockIsServiceChangeFlag.mockReturnValue(false);
});

describe('Footer Component - View Together Button Disabled State Tests', () => {
  test('View Together button should be disabled when showViewTogether is true and isOmniCareTrainingUser is true', () => {
    mockIsServiceChangeFlag.mockReturnValue(true);

    const newCartJson = JSON.parse(JSON.stringify(cartJson));
    newCartJson.data.cart.orderDetails.accessoryFinancingOfferInfo = null;
    newCartJson.data.cart.orderDetails.affirmFinancingOfferInfo = null;

    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...baseProps}
            cartDetailsResult={newCartJson}
            hideContinue={false}
            showViewTogether
            disableButton={false}
            hideViewTogether={false}
            isAllSetDone={false}
            hideOrderDetails={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const viewTogetherBtn = screen.getByTestId('view-together-footer');
    expect(viewTogetherBtn).toBeInTheDocument();
    expect(viewTogetherBtn).toBeDisabled();
    expect(viewTogetherBtn).toHaveTextContent('View Together');
  });

  test('View Together button should be disabled when showViewTogether is true and disableButton is true', () => {
    const newCartJson = JSON.parse(JSON.stringify(cartJson));
    newCartJson.data.cart.orderDetails.accessoryFinancingOfferInfo = null;
    newCartJson.data.cart.orderDetails.affirmFinancingOfferInfo = null;

    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...baseProps}
            cartDetailsResult={newCartJson}
            hideContinue={false}
            showViewTogether
            disableButton
            hideViewTogether={false}
            isAllSetDone={false}
            hideOrderDetails={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const viewTogetherBtn = screen.getByTestId('view-together-footer');
    expect(viewTogetherBtn).toBeInTheDocument();
    expect(viewTogetherBtn).toBeDisabled();
    expect(viewTogetherBtn).toHaveTextContent('View Together');
  });

  test('View Together button should be enabled when showViewTogether is true but disableButton is false', () => {
    const newCartJson = JSON.parse(JSON.stringify(cartJson));
    newCartJson.data.cart.orderDetails.accessoryFinancingOfferInfo = null;
    newCartJson.data.cart.orderDetails.affirmFinancingOfferInfo = null;

    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...baseProps}
            cartDetailsResult={newCartJson}
            hideContinue={false}
            showViewTogether
            disableButton={false}
            hideViewTogether={false}
            isAllSetDone={false}
            hideOrderDetails={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const viewTogetherBtn = screen.getByTestId('view-together-footer');
    expect(viewTogetherBtn).toBeInTheDocument();
    expect(viewTogetherBtn).not.toBeDisabled();
    expect(viewTogetherBtn).toHaveTextContent('View Together');
  });

  test('View Together button should be enabled when showViewTogether is false (Resume mode)', () => {
    const newCartJson = JSON.parse(JSON.stringify(cartJson));
    newCartJson.data.cart.orderDetails.accessoryFinancingOfferInfo = null;
    newCartJson.data.cart.orderDetails.affirmFinancingOfferInfo = null;

    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...baseProps}
            cartDetailsResult={newCartJson}
            hideContinue={false}
            showViewTogether={false}
            disableButton
            hideViewTogether={false}
            isAllSetDone={false}
            hideOrderDetails={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const viewTogetherBtn = screen.getByTestId('view-together-footer');
    expect(viewTogetherBtn).toBeInTheDocument();
    expect(viewTogetherBtn).not.toBeDisabled();
    expect(viewTogetherBtn).toHaveTextContent('Resume - View Together');
  });

  test('View Together button should have correct width based on showViewTogether prop', () => {
    const newCartJson = JSON.parse(JSON.stringify(cartJson));
    newCartJson.data.cart.orderDetails.accessoryFinancingOfferInfo = null;
    newCartJson.data.cart.orderDetails.affirmFinancingOfferInfo = null;

    const { rerender } = render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...baseProps}
            cartDetailsResult={newCartJson}
            hideContinue={false}
            showViewTogether
            disableButton={false}
            hideViewTogether={false}
            isAllSetDone={false}
            hideOrderDetails={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    let viewTogetherBtn = screen.getByTestId('view-together-footer');
    expect(viewTogetherBtn).toHaveAttribute('width', '150px');

    rerender(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...baseProps}
            cartDetailsResult={newCartJson}
            hideContinue={false}
            showViewTogether={false}
            disableButton={false}
            hideViewTogether={false}
            isAllSetDone={false}
            hideOrderDetails={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    viewTogetherBtn = screen.getByTestId('view-together-footer');
    expect(viewTogetherBtn).toHaveAttribute('width', '210px');
  });

  test('View Together button should not render when hideViewTogether is true', () => {
    const newCartJson = JSON.parse(JSON.stringify(cartJson));
    newCartJson.data.cart.orderDetails.accessoryFinancingOfferInfo = null;
    newCartJson.data.cart.orderDetails.affirmFinancingOfferInfo = null;

    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...baseProps}
            cartDetailsResult={newCartJson}
            hideContinue={false}
            showViewTogether
            disableButton={false}
            hideViewTogether
            isAllSetDone={false}
            hideOrderDetails={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const viewTogetherBtn = screen.queryByTestId('view-together-footer');
    expect(viewTogetherBtn).not.toBeInTheDocument();
  });
});
