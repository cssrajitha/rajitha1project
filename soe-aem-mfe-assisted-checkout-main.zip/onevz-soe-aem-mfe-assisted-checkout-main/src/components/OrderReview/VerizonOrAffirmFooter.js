import React, { useEffect } from 'react';
import { Checkbox } from '@vds/checkboxes';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { TextLink } from '@vds/buttons';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { affirmConstants, vvcConstants } from '../../appconfig';
import { getUpdateAFOPayload } from './AccessoryAndAffirmRequest';
import AgreementsAPICallHook from '../../modules/services/APIService/AgreementsAPICallHook';
import Affirm from './Affirm';

const AccessoryOffers = styled.div`
  padding: ${window?.mfe?.isProspectNewCustomerTab ? 0 : '0 0.875rem 0.875rem'};
  display: flex;
  gap: 10px;
  align-items: flex-end;
  width: 100%;
`;

const AffirmWrapper = styled.div`
  width: 50%;
`;

const VerizonVisaWrapper = styled.div`
  width: 50%;
`;
const AnchorText = styled(TextLink)`
  [class^='Wrapper-VDS'] {
    font-weight: bold;
  }
  margin-left: 30px;
`;

const VerizonOrAffirmFooter = ({
  verizonVisaChecked,
  isAffirmFinance,
  affirmFinanceChecked,
  setAffirmFinanceChecked,
  cartDetailsResult,
  customerMtns,
  showAccessoryVvcModal,
  setVerizonVisaChecked,
  getCustomerByMtns,
  getOffersResults,
  isQAFlow=false,
}) => {
  const { updateAFOInfo, UpdateAFOInfoResponse } = AgreementsAPICallHook();
  const [isAffirmLaunchEnabled] = getAssistedCradlePropertyV2(['isAffirmLaunchEnabled']);
  const showIsaacLink = getOffersResults?.issacPromo?.proposition?.isDirectApply;
  const showIsaacRewardsLink = getOffersResults?.issacPromo?.proposition?.rewardsEnrolled;
  const accessoryFinancingOfferInfo = cartDetailsResult?.data?.cart?.orderDetails?.accessoryFinancingOfferInfo;
  const afoVzccApplicationStatus = cartDetailsResult?.data?.cart?.orderDetails?.nbxInfo?.vzccApplicationStatus;
  /* istanbul ignore next */
  const enableAFO =
    (accessoryFinancingOfferInfo?.customerEligible &&
      accessoryFinancingOfferInfo?.offerAvailable &&
      !showIsaacLink &&
      showIsaacRewardsLink) ||
    (afoVzccApplicationStatus?.toLowerCase() === 'application_approved' &&
      accessoryFinancingOfferInfo?.customerEligible &&
      accessoryFinancingOfferInfo?.offerAvailable);
  
  useEffect(() => {
    if (UpdateAFOInfoResponse?.data) {
      if (
        !cartDetailsResult?.data?.cart?.orderDetails?.accessoryFinancingOfferInfo?.disclosureAgreementSent &&
        customerMtns?.length === 0
      ) {
        getCustomerByMtns({ body: { mtn: '', customerId: '' }, spinner: true, mock: false });
      }
    }
  }, [UpdateAFOInfoResponse]);

  const enableAccessoryVvc = () => {
    setVerizonVisaChecked(!verizonVisaChecked);
    const UpdateAFOPayload = getUpdateAFOPayload(cartDetailsResult?.data?.cart, !verizonVisaChecked);
    updateAFOInfo({ body: { ...UpdateAFOPayload }, spinner: true, mock: false });
  };
  /* istanbul ignore next */
  const enableAffirmFinance = () => {
    if (!affirmFinanceChecked && customerMtns?.length === 0) {
      getCustomerByMtns({ body: { mtn: '', customerId: '' }, spinner: true, mock: false });
    }
    setAffirmFinanceChecked(!affirmFinanceChecked);
  };
  const isPrePayCart = cartDetailsResult?.data?.cart?.orderDetails?.isPrePayCart !== 'Y';
  const affrimOfferAvailable = cartDetailsResult?.data?.cart?.orderDetails?.affirmFinancingOfferInfo?.offerAvailable;
  /* istanbul ignore next */
  return (
    <AccessoryOffers data-testid="accessory-offers">
      {enableAFO && (
        <VerizonVisaWrapper>
          <Checkbox
            id='verizon-visa-checkbox'
            data-testid='verizon-visa-checkbox'
            name='accessoryVVC'
            width='auto'
            label='VerizonVisa®Card'
            onChange={() => enableAccessoryVvc()}
            selected={verizonVisaChecked}
          >
            {vvcConstants.checkBoxText}
          </Checkbox>
          <AnchorText type='inline' onClick={() => showAccessoryVvcModal()}>
            {vvcConstants.detailstext}
          </AnchorText>
        </VerizonVisaWrapper>
      )}

      {!isQAFlow && isAffirmFinance && isPrePayCart && affrimOfferAvailable && isAffirmLaunchEnabled === 'TRUE' && (
        <AffirmWrapper>
          <Checkbox
            name='affirm'
            width='auto'
            label='Affirm'
            onChange={() => enableAffirmFinance()}
            selected={affirmFinanceChecked}
          >
            {affirmConstants.checkBoxtext}
          </Checkbox>
          <Affirm affirmConfirmationButton={affirmConstants.seeDetailsText} />
        </AffirmWrapper>
      )}
    </AccessoryOffers>
  );
};

VerizonOrAffirmFooter.propTypes = {
  verizonVisaChecked: PropTypes.bool,
  isAffirmFinance: PropTypes.bool,
  affirmFinanceChecked: PropTypes.bool,
  cartDetailsResult: PropTypes.object,
  customerMtns: PropTypes.bool,
  showAccessoryVvcModal: PropTypes.func,
  setAffirmFinanceChecked: PropTypes.func,
  setVerizonVisaChecked: PropTypes.func,
  getCustomerByMtns: PropTypes.func,
  getOffersResults: PropTypes.shape({
    issacPromo: PropTypes.shape({
      proposition: PropTypes.shape({
        isDirectApply: PropTypes.bool,
        rewardsEnrolled: PropTypes.bool,
      }),
    }),
  }),
  isQAFlow: PropTypes.bool,
};

export default VerizonOrAffirmFooter;
