import { fireEvent, render, screen } from '@testing-library/react';

import ManualDiscountPriceDetails from './ManualDiscountPriceDetails';

const mockedItem = (manualDiscount = false) => ({
  itemType: 'ACCESSORY',
  mtn: '7736781234',
  sorSkuId: 'JBLSNDGEARSNSBLKAM',
  itemDescription: 'Soundgear Sense Open-Ear Headphones - Black',
  itemPrice: 149.99,
  manualDiscountPrice: manualDiscount ? 10 : 0,
  itemSeq: '2',
  manualDiscountAdjustmentFLag: false,
  imageURL: {
    defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset',
    largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-lg$',
    mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-med$',
    miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-mini$',
    thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-thumb$',
  },
  sedOfferList: {
    sedOffer: [
      {
        offerId: '428422',
        itemSeqNum: 0,
        description: 'ACC Save up to $60 Select JBL Products',
        offerType: 'ITA',
        itemMonthlyDiscount: 30,
        itemMonthlyDiscountedPrice: 119.99,
        discountedRetailPrice: 119.99,
        discAmt: '30.00',
        discPrcnt: 0,
        priceInfo: {
          basePriceUsed: 'Y',
        },
        rebatesAllowed: 'N',
        barcodeID: '',
        promoBadges: [
          {
            badgeText: 'Save $XX',
            placement: 'ITEM-HEADER',
            pageId: 'CART',
            masterpageId: 'CART',
          },
        ],
        itemMonthlyRetailPrice: 149.99,
        isStrategicOffer: false,
      },
    ],
    count: 0,
  },
  manualDiscountDescription: 'Other Authorized Programs',
  priceAfterDiscount: 109.99,
  mgrApprovalReq: 'N',
  qty: 1,
  isRefundCartItem: false,
  dType: '$',
  discountPercent: null,
  discountAmount: null,
  discountedPrice: null,
  reason: null,
  reasonText: null,
});

describe('ManualDiscount Price Details Component', () => {
  test('renders ManualDiscountPriceDetails', () => {
    render(<ManualDiscountPriceDetails item={mockedItem()} />);

    const titleElement = screen.getByTestId('manual-discount-price-details');
    expect(titleElement).toBeInTheDocument();

    const priceDetailsLink = screen.getByTestId('pricing-details');
    expect(priceDetailsLink).toBeInTheDocument();
    fireEvent.click(priceDetailsLink);

    fireEvent.click(document);
  });

  test('renders ManualDiscountPriceDetails', () => {
    window.mfe = { scmUpgradeMfeEnable: true };

    render(<ManualDiscountPriceDetails item={mockedItem(true)} />);

    const titleElement = screen.getByTestId('manual-discount-price-details');
    expect(titleElement).toBeInTheDocument();

    const priceDetailsLink = screen.getByTestId('pricing-details');
    expect(priceDetailsLink).toBeInTheDocument();
    fireEvent.click(priceDetailsLink);

    fireEvent.click(document);
    window.mfe.scmUpgradeMfeEnable = false;
  });
  test('renders correctly for TARIFF_FEE when scmUpgradeMfeEnable is true', () => {
    window.mfe = { scmUpgradeMfeEnable: true };
    const mockTariffItem = {
      itemType: 'TARIFF_FEE',
      mtn: '1234567890',
      itemPrice: 35.0,
      discountedPrice: 25.0,
      priceAfterDiscount: 35.0,
    };
  
    const { rerender } = render(<ManualDiscountPriceDetails item={mockTariffItem} />);
  
    let originalPrice = screen.getByText('$35.00');
    expect(originalPrice.parentElement).toHaveClass('strike');
  
    expect(screen.getByText('$25.00')).toBeInTheDocument();
  
    const mockTariffItemZeroDiscount = {
      ...mockTariffItem,
      discountedPrice: 0,
    };
  
    rerender(<ManualDiscountPriceDetails item={mockTariffItemZeroDiscount} />);
  
    originalPrice = screen.getByText('$35.00');
    expect(originalPrice.parentElement).toHaveClass('strike');
  
    expect(screen.getByText('$0.00')).toBeInTheDocument();
    
    window.mfe.scmUpgradeMfeEnable = false;
  });
  test('calculates and displays price correctly with a percentage-based discount', () => {
    const itemWithPercentDiscount = {
      ...mockedItem(),
      itemPrice: 150.0,
      priceAfterDiscount: 120.0, 
      discountPercent: 10, 
      discountAmount: null, 
    };
  
    render(<ManualDiscountPriceDetails item={itemWithPercentDiscount} />);

    const marketPrice = screen.getByText('$150.00');
    expect(marketPrice.parentElement).toHaveClass('strike');
      expect(screen.getByText('$108.00')).toBeInTheDocument();
  });
});
