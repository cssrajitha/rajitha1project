import { fireEvent, render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../modules/store';
import ManulDiscountItem from './ManulDiscountItem';
import { useLazyUpdateManualDiscountQuery } from '../../modules/services/APIService/APIServiceHooks';
import mockUpdateManualDiscountJson from '../../__mock__/updateManualDiscount.json';
import cartJson from '../../__mock__/retrive-cart.json';

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  __esModule: true,
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),

  useLazyUpdateManualDiscountQuery: jest.fn(),
}));

const mockDataUpdater = (updateManualDiscountMock) => {
  useLazyUpdateManualDiscountQuery.mockReturnValue([
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: updateManualDiscountMock,
    },
  ]);
};

const mockedItem = (manualDiscount = false) => ({
  itemType: 'ACCESSORY',
  mtn: '7736781234',
  sorSkuId: 'JBLSNDGEARSNSBLKAM',
  itemDescription: 'Soundgear Sense Open-Ear Headphones - Black',
  itemPrice: 149.99,
  manualDiscountPrice: manualDiscount ? 10 : 0,
  itemSeq: '2',
  manualDiscountAdjustmentFLag: false,
  imageURL: {
    defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset',
    largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-lg$',
    mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-med$',
    miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-mini$',
    thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-thumb$',
  },
  sedOfferList: {
    sedOffer: [
      {
        offerId: '428422',
        itemSeqNum: 0,
        description: 'ACC Save up to $60 Select JBL Products',
        offerType: 'ITA',
        itemMonthlyDiscount: 30,
        itemMonthlyDiscountedPrice: 119.99,
        discountedRetailPrice: 119.99,
        discAmt: '30.00',
        discPrcnt: 0,
        priceInfo: {
          basePriceUsed: 'Y',
        },
        rebatesAllowed: 'N',
        barcodeID: '',
        promoBadges: [
          {
            badgeText: 'Save $XX',
            placement: 'ITEM-HEADER',
            pageId: 'CART',
            masterpageId: 'CART',
          },
        ],
        itemMonthlyRetailPrice: 149.99,
        isStrategicOffer: false,
      },
    ],
    count: 0,
  },
  manualDiscountDescription: 'Other Authorized Programs',
  priceAfterDiscount: 109.99,
  mgrApprovalReq: 'N',
  qty: 1,
  isRefundCartItem: false,
  dType: '$',
  discountPercent: null,
  discountAmount: null,
  discountedPrice: null,
  reason: null,
  reasonText: null,
});

const mockedCodes = [
  {
    key: 1,
    value: 'Accessory Offer',
  },
  {
    key: 4,
    value: 'BOGO/BAGO',
  },
  {
    key: 5,
    value: 'CLEU/ELEU Discount',
  },
  {
    key: 23,
    value: 'Cust Service Initiated Discount',
  },
  {
    key: 29,
    value: 'Device Payment Exchange',
  },
  {
    key: 96,
    value: 'Disaster Relief',
  },
  {
    key: 9,
    value: 'Manager Discretion',
  },
  {
    key: 19,
    value: 'NE2',
  },
  {
    key: 97,
    value: 'Other Authorized Programs',
  },
  {
    key: 13,
    value: 'Store Demo',
  },
  {
    key: 27,
    value: 'WFG/DOA Exchanges',
  },
  {
    key: 22,
    value: 'Warranty/Insurance Exception',
  },
];

const mockedData = [
  {
    itemType: 'ACCESSORY',
    mtn: '7736781234',
    sorSkuId: 'UHRA-RT-05',
    itemDescription: 'Ring AIR - Size 5 - Raw Titanium',
    itemPrice: 349.99,
    manualDiscountPrice: 0,
    itemSeq: '1',
    manualDiscountAdjustmentFLag: false,
    imageURL: {
      defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/UHRA-RT-05-iset',
      largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/UHRA-RT-05-iset?$acc-lg$',
      mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/UHRA-RT-05-iset?$acc-med$',
      miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/UHRA-RT-05-iset?$acc-mini$',
      thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/UHRA-RT-05-iset?$acc-thumb$',
    },
    manualDiscountDescription: 'Cust Service Initiated Discount',
    priceAfterDiscount: 195.99,
    mgrApprovalReq: 'Y',
    qty: 1,
    isRefundCartItem: false,
  },
  {
    itemType: 'ACCESSORY',
    mtn: '7736781234',
    sorSkuId: 'JBLSNDGEARSNSBLKAM',
    itemDescription: 'UPGRFEE',
    itemPrice: 149.99,
    manualDiscountPrice: 0,
    itemSeq: '2',
    manualDiscountAdjustmentFLag: false,
    imageURL: {
      defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset',
      largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-lg$',
      mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-med$',
      miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-mini$',
      thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/jblsndgearsnsblkam-iset?$acc-thumb$',
    },

    manualDiscountDescription: 'Other Authorized Programs',
    priceAfterDiscount: 109.99,
    mgrApprovalReq: 'N',
    qty: 1,
    isRefundCartItem: false,
    dType: '$',
    discountPercent: null,
    discountAmount: null,
    discountedPrice: null,
    reason: null,
    reasonText: null,
  },
];

describe('ManulDiscountItem Component', () => {
  test('renders ManulDiscountItem', () => {
    sessionStorage.setItem('cartId', 'test');
    mockDataUpdater(mockUpdateManualDiscountJson);
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManulDiscountItem
            item={mockedItem()}
            cart={cartJson.data.cart}
            reasonCodeList={mockedCodes}
            data={mockedData}
            refreshManulaDiscountBody={jest.fn()}
            setNotificationTitle={jest.fn()}
            setNotificationType={jest.fn()}
            setShowNotification={jest.fn()}
            setData={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const titleElement = screen.getByTestId('manual-discount-item');
    expect(titleElement).toBeInTheDocument();

    const dicountInput = screen.getByTestId('discount-input');
    expect(dicountInput).toBeInTheDocument();
    const discOptDollar = screen.getByTestId('dollar-discount');
    const discOptPercent = screen.getByTestId('percent-discount');
    expect(discOptPercent).toBeInTheDocument();

    fireEvent.change(dicountInput, { target: { value: 35 } });

    fireEvent.click(discOptDollar);
    fireEvent.blur(dicountInput, { target: { value: 35 } });

    fireEvent.change(dicountInput, { target: { value: 2000 } });
    fireEvent.change(dicountInput, { target: { value: 0 } });
    fireEvent.change(dicountInput, { target: { value: 149.99 } });
    fireEvent.change(dicountInput, { target: { value: 35 } });
    const reasonDD = screen.getByTestId('reason-dropdown');
    expect(reasonDD).toBeInTheDocument();
    fireEvent.change(reasonDD, { target: { value: 1 } });
  });

  test('renders ManulDiscountItem - validating inputs', () => {
    sessionStorage.setItem('cartId', 'test');
    mockDataUpdater(mockUpdateManualDiscountJson);
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManulDiscountItem
            item={mockedItem()}
            cart={cartJson.data.cart}
            reasonCodeList={mockedCodes}
            data={mockedData}
            refreshManulaDiscountBody={jest.fn()}
            setNotificationTitle={jest.fn()}
            setNotificationType={jest.fn()}
            setShowNotification={jest.fn()}
            setData={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    const dicountInput = screen.getByTestId('discount-input');
    expect(dicountInput).toBeInTheDocument();

    fireEvent.change(dicountInput, { target: { value: 149.99 } });
  });

  test('renders ManulDiscountItem', () => {
    sessionStorage.setItem('cartId', 'test');
    mockDataUpdater(mockUpdateManualDiscountJson);
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManulDiscountItem
            item={mockedItem}
            cart={cartJson.data.cart}
            reasonCodeList={mockedCodes}
            data={mockedData}
            refreshManulaDiscountBody={jest.fn()}
            setNotificationTitle={jest.fn()}
            setNotificationType={jest.fn()}
            setShowNotification={jest.fn()}
            setData={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getByTestId('manual-discount-item');
    expect(titleElement).toBeInTheDocument();

    const discOptDollar = screen.getByTestId('dollar-discount');
    const discOptPercent = screen.getByTestId('percent-discount');
    expect(discOptDollar).toBeInTheDocument();
    fireEvent.click(discOptPercent);

    const dicountInput = screen.getByTestId('discount-input');
    expect(dicountInput).toBeInTheDocument();

    fireEvent.blur(dicountInput, { target: { value: 10 } });
    fireEvent.change(dicountInput, { target: { value: 10 } });

    fireEvent.change(dicountInput, { target: { value: 10 } });
    const reasonDD = screen.getByTestId('reason-dropdown');

    expect(reasonDD).toBeInTheDocument();
    fireEvent.change(reasonDD, { target: { value: 1 } });
  });

  test('renders ManulDiscountItem with manual discount', () => {
    sessionStorage.removeItem('cartId');
    mockDataUpdater(mockUpdateManualDiscountJson);
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManulDiscountItem
            item={mockedItem(true)}
            cart={cartJson.data.cart}
            reasonCodeList={mockedCodes}
            data={mockedData}
            refreshManulaDiscountBody={jest.fn()}
            setNotificationTitle={jest.fn()}
            setNotificationType={jest.fn()}
            setShowNotification={jest.fn()}
            setData={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getByTestId('manual-discount-item');
    expect(titleElement).toBeInTheDocument();

    const discOptDollar = screen.getByTestId('dollar-discount');
    const discOptPercent = screen.getByTestId('percent-discount');
    expect(discOptDollar).toBeInTheDocument();
    fireEvent.click(discOptPercent);

    const dicountInput = screen.getByTestId('discount-input');
    expect(dicountInput).toBeInTheDocument();
    fireEvent.blur(dicountInput, { target: { value: 10 } });
    fireEvent.change(dicountInput, { target: { value: 10 } });
    const reasonDD = screen.getByTestId('reason-dropdown');
    expect(reasonDD).toBeInTheDocument();
    fireEvent.change(reasonDD, { target: { value: 1 } });

    const removeLink = screen.getByTestId('remove-item');
    fireEvent.click(removeLink);
  });

  test('renders ManulDiscountItem with manual discount when scmUpgradeMfeEnable = true', () => {
    window.mfe = { scmUpgradeMfeEnable : true };
    sessionStorage.removeItem('cartId');
    mockDataUpdater(mockUpdateManualDiscountJson);
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManulDiscountItem
            item={mockedItem(true)}
            cart={cartJson.data.cart}
            reasonCodeList={mockedCodes}
            data={mockedData}
            refreshManulaDiscountBody={jest.fn()}
            setNotificationTitle={jest.fn()}
            setNotificationType={jest.fn()}
            setShowNotification={jest.fn()}
            setData={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const titleElement = screen.getByTestId('manual-discount-item');
    expect(titleElement).toBeInTheDocument();

    const discOptDollar = screen.getByTestId('dollar-discount');
    const discOptPercent = screen.getByTestId('percent-discount');
    expect(discOptDollar).toBeInTheDocument();
    fireEvent.click(discOptPercent);

    const dicountInput = screen.getByTestId('discount-input');
    expect(dicountInput).toBeInTheDocument();
    fireEvent.blur(dicountInput, { target: { value: 10 } });
    fireEvent.change(dicountInput, { target: { value: 10 } });
    const reasonDD = screen.getByTestId('reason-dropdown');
    expect(reasonDD).toBeInTheDocument();
    fireEvent.change(reasonDD, { target: { value: 1 } });

    const removeLink = screen.getByTestId('remove-item');
    fireEvent.click(removeLink);
  });

  test('renders correct item description for special fee types', () => {

    mockDataUpdater(mockUpdateManualDiscountJson);

    // Test case for UPGRFEE
    const upgradeFeeItem = {
      ...mockedItem(),
      itemDescription: 'UPGRFEE',
    };

    const { rerender } = render(
      <BrowserRouter>
        <StoreProvider>
          <ManulDiscountItem
            item={upgradeFeeItem}
            cart={cartJson.data.cart}
            reasonCodeList={mockedCodes}
            data={mockedData}
            refreshManulaDiscountBody={jest.fn()}
            setNotificationTitle={jest.fn()}
            setNotificationType={jest.fn()}
            setShowNotification={jest.fn()}
            setData={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    expect(screen.getByText('UPGRADE FEE')).toBeInTheDocument();

    // Test case for TARIFFFEE with mfe flag enabled
    window.mfe = { scmUpgradeMfeEnable: true };
    const tariffFeeItem = {
      ...mockedItem(),
      itemDescription: 'TARIFFFEE',
    };

    rerender(
      <BrowserRouter>
        <StoreProvider>
          <ManulDiscountItem
            item={tariffFeeItem}
            cart={cartJson.data.cart}
            reasonCodeList={mockedCodes}
            data={mockedData}
            refreshManulaDiscountBody={jest.fn()}
            setNotificationTitle={jest.fn()}
            setNotificationType={jest.fn()}
            setShowNotification={jest.fn()}
            setData={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>
    );

    expect(screen.getByText('Manufacturer Cost Adjustment')).toBeInTheDocument();

    // Cleanup global mock
    delete window.mfe;
  });
});
