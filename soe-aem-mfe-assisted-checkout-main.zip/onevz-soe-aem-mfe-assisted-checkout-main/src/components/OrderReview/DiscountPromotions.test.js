import { render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../modules/store';
import pricingSnapshot from '../../__mock__/fetchPricingSnapshot.json';
import DiscountPromotions from './DiscountPromotions';
import cartJson from '../../__mock__/retrive-cart.json';
import humJson from './__mock__/humDevice.json';

describe('DiscountPromotions Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  test('renders Discounts and Promotions info', () => {
    const fetchPriceSnapshot = pricingSnapshot?.data?.data?.subAccounts[0]?.lines;
    const isPrepay = false;
    render(
      <BrowserRouter>
        <StoreProvider>
          <DiscountPromotions fetchPriceSnapshot={fetchPriceSnapshot} isPrepay={isPrepay} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByTestId('discountPromotions');
    expect(titleElement).toBeInTheDocument();
  });

  test('renders NA if connectedCarMobile & connectedCarColor is null', () => {
    const fetchPriceSnapshot = pricingSnapshot?.data?.data?.subAccounts[0]?.lines;
    const isPrepay = false;
    const lineData = cartJson.data.cart.lineDetails.lineInfo[0];
    const { cartItem } = { ...humJson.data.cart.lineDetails.lineInfo[0].itemsInfo[0].cartItems };
    const item = { ...cartItem[0] };
    delete item.connectedCarColor;
    delete item.connectedCarMobile;
    render(
      <BrowserRouter>
        <StoreProvider>
          <DiscountPromotions
            lineData={lineData}
            cartItem={item}
            fetchPriceSnapshot={fetchPriceSnapshot}
            isPrepay={isPrepay}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByText('NA');
    expect(titleElement).toBeInTheDocument();
  });

  test('renders HUM device info', () => {
    const fetchPriceSnapshot = pricingSnapshot?.data?.data?.subAccounts[0]?.lines;
    const isPrepay = false;
    const lineData = cartJson.data.cart.lineDetails.lineInfo[0];
    const { cartItem } = { ...humJson.data.cart.lineDetails.lineInfo[0].itemsInfo[0].cartItems };
    render(
      <BrowserRouter>
        <StoreProvider>
          <DiscountPromotions
            lineData={lineData}
            cartItem={cartItem[0]}
            fetchPriceSnapshot={fetchPriceSnapshot}
            isPrepay={isPrepay}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByText('Telematics Info');
    expect(titleElement).toBeInTheDocument();
  });
});
