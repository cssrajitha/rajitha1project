import { Modal, ModalTitle, ModalBody, ModalFooter } from '@vds/modals';
import PropTypes from 'prop-types';
import Emitter from 'onevzsoemfeframework/Emitter';
import styled, { createGlobalStyle } from 'styled-components';
import { Title, Body } from '@vds/typography';
import { PaddingBottom12 } from '../../StyledConstants';
import { invokeTagging } from '../../utils/test-utils/utils';

const ComponentStyle = createGlobalStyle`
  #editAccessModal {
    [class^='Overlay-VDS'] {
      background-color: rgba(0, 0, 0, 0.8);
    }
    [class^='ModalDialog-VDS'] {
      max-width:1024px; 
      border-radius: 0;
      padding: 0;
    }
    [class^='ModalDialogWrapper-VDS'] {
      padding:0;
        > span {
          width: 100%;
          height: 100%;

        > div {
          width:100% !important;
          height: 100% !important;

          > div {
            padding:0 !important;
          }
        }
      }
    }


    [class^='IconWrapper-VDS'] {
      z-index: 99999;
    }
    
    [class^='StyledHeader-VDS'] {
      border-bottom: 1px solid #ccc;
      position: sticky;
      top:0;
      background: #fff;
      z-index: 999;
      padding: 1rem 0;
    }
    [class^='StyledFooter-VDS'] {
      border-top: 1px solid #ccc;
      position: static;
      bottom:0;
      background: #fff;
      padding-top: 2rem;
    }
  }

  [class^='ButtonGroupRow-VDS']{
    flex-direction:row-reverse;
    > div {
      padding-right:0.75rem;
    }
  }
`;
const ProductContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  max-height: 700px;
  overflow-y: scroll;
`;

const InnerPadd = styled.div`
  padding: 0 25px;
`;

const FlexBoxFourColumn = styled.div`
  display: flex;
  flex-direction: column;
  align-items: start;
  width: 21%;
  padding: 0 20px;
  margin-bottom: 40px;
  margin-top: 40px;
  &:nth-child(4n) {
    padding-right: 0px;
  }
`;

const MarginSides = styled.div`
  padding: 0;
`;

const PriceDflexCtn = styled.div`
  display: flex;
`;

const handleShopAccessories = (isQAFlow) => {
  const scmCheckoutMfeEnabled = window?.mfe?.scmCheckoutMfeEnable || false;

  if (isQAFlow){
    window.location.href = '/sales/assisted/new/accessory-gridwall.html?isQAFlow=true';
  } else if (scmCheckoutMfeEnabled) {
    Emitter.emit('ACSS_SCM_SWITCH_TAB', { type: 'SWITCH_TAB', targetTab: 'DEVICE_TAB' });
    invokeTagging('openView', 'Accessories');
  }else{
    invokeTagging('openView', 'Accessories');
    window.location.href = '/sales/assisted/shop-accessories.html';
  }
}
const EditAccessories = ({ cart, opened, closeModal, total, mtn, isQAFlow=false, imageUrl = '' }) => (
  <div>
    <ComponentStyle />
    <div data-testId='editAccessModal'>
      <Modal
        id='editAccessModal'
        fullScreenDialog
        opened={opened}
        surface='light'
        width='100%'
        disableAnimation={false}
        disableOutsideClick={false}
        onOpenedChange={(open) => {
          if (!open) closeModal();
        }}
      >
        <MarginSides>
          <ModalTitle>
            <InnerPadd>
              <Title size='small' bold primitive='h1' data-testid='edit-accesories-title'>
                Accesories for {mtn} (${total} today)
              </Title>
            </InnerPadd>
          </ModalTitle>
          <ModalBody>
            <InnerPadd>
              <ProductContainer>
                {cart.map((item, index) => (
                  <FlexBoxFourColumn key={item.deviceDisplayName}>
                    <img src={item.imageUrlMap?.thumbImage ? item.imageUrlMap?.thumbImage : imageUrl} alt={item.deviceDisplayName ?  item.deviceDisplayName : item.description} />
                    <PaddingBottom12 />
                    <Title size='small' bold primitive='h2' data-testid='item-name'>
                      {item.deviceDisplayName ? item.deviceDisplayName : item.description}
                    </Title>
                    <PaddingBottom12 />
                    {item.itemPrice?.toString() === item.discountedPrice?.toString() ? (
                      <Title size='small' bold primitive='h3'>
                        ${item.itemPrice}
                      </Title>
                    ) : (
                      <PriceDflexCtn>
                        <Body strikethrough>
                          <Title size='small' bold primitive='h3' data-testid='item-price'>
                            ${item.itemPrice}
                          </Title>
                        </Body>
                        <MarginSides>
                          <Title size='small' bold primitive='h3'>
                            :${item.discountedPrice}
                          </Title>
                        </MarginSides>
                      </PriceDflexCtn>
                    )}
                    <PaddingBottom12 />
                    <Title size='small' data-testid={`item-qty-${index}`}>
                      QTY: {item.qty}
                    </Title>
                  </FlexBoxFourColumn>
                ))}
              </ProductContainer>
            </InnerPadd>
          </ModalBody>
          <ModalFooter
            buttonData={{
              close: {
                children: 'Shop Accessories',
                width: '225px',
                onClick: () => {
                  handleShopAccessories(isQAFlow)
                },
              },
              primary: {
                children: 'Done',
                width: '225px',
                onClick: () => {
                  invokeTagging('closeView', '');
                  closeModal();
                },
              },
            }}
          />
        </MarginSides>
      </Modal>
    </div>
  </div>
);

EditAccessories.propTypes = {
  cart: PropTypes.array,
  opened: PropTypes.bool,
  closeModal: PropTypes.func,
  total: PropTypes.number,
  mtn: PropTypes.string,
  isQAFlow: PropTypes.bool,
  imageUrl: PropTypes.string,
};

export default EditAccessories;
