import { render, screen, fireEvent } from '@testing-library/react';
import StoreProvider from '../../../modules/store';
import SubLineHeader from './SubLineHeader';

describe('Next Bill Summary Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  const setOpen = jest.fn();

  test('render initial component', () => {
    render(
      <StoreProvider>
        <SubLineHeader
          title='One-time charges and credits'
          nextMonthCharge={0}
          newMonthCharge={0}
          isOpen={false}
          setOpen={setOpen}
        />
      </StoreProvider>,
    );
    const titleText = screen.getByText('One-time charges and credits');
    expect(titleText).toBeInTheDocument();
    const nextMonthCharge = screen.getByTestId('next-month-charges');
    expect(nextMonthCharge.textContent).toEqual('$0.00');
    const newMonthCharge = screen.getByTestId('new-month-charges');
    expect(newMonthCharge.textContent).toEqual('$0.00');
  });

  test('Accordion Open Close functionality', () => {
    render(
      <StoreProvider>
        <SubLineHeader
          title='One-time charges and credits'
          nextMonthCharge={0}
          newMonthCharge={0}
          isOpen={false}
          setOpen={setOpen}
        />
      </StoreProvider>,
    );
    const chargesPlusTextBtn = screen.getByTestId('plusIcon');
    expect(chargesPlusTextBtn).toBeInTheDocument();
    fireEvent.click(chargesPlusTextBtn);
  });

  test('isDark true', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] ,isDark: true, themeProps: {background: '#eeeeee'}};
    render(
      <StoreProvider>
        <SubLineHeader
          title='One-time charges and credits'
          nextMonthCharge={0}
          newMonthCharge={0}
          isOpen={false}
          setOpen={setOpen}
        />
      </StoreProvider>,
    );
    
  });
});
