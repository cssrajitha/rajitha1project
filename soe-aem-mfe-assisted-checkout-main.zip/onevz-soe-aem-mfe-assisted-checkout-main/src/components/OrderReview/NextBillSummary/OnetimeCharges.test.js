import { render, screen, fireEvent } from '@testing-library/react';
import getNextBillSummaryNewCustomer from '../../../__mock__/getNextBillSummaryNewCustomer.json';
import StoreProvider from '../../../modules/store';
import OneTimeChargesVo from './OnetimeCharges';

describe('Next Bill Summary Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  test('render initial OneTimeCharges Component-01', () => {
    const lineLevelOneTimeChargesVo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelOneTimeChargesVo,
    };
    const lineLevelOneTimeOthVenChargesVo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]
        ?.lineLevelOneTimeOthVenChargesVo,
    };
    const mtnLevelOneTimeChargesTotals = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelTotal
        ?.mtnLevelOneTimeChargesTotals,
    };
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <OneTimeChargesVo
          expandAll={false}
          lineLevelOneTimeChargesVo={lineLevelOneTimeChargesVo}
          mtnLevelOneTimeChargesTotals={mtnLevelOneTimeChargesTotals}
          lineLevelOneTimeOthVenChargesVo={lineLevelOneTimeOthVenChargesVo}
          additionalInfo={additionalInfo}
          financedAmount={0}
        />
      </StoreProvider>,
    );
    const titleText = screen.getByText('One-time charges and credits');
    expect(titleText).toBeInTheDocument();
  });

  test('render initial OneTimeCharges Component-02', () => {
    const lineLevelOneTimeChargesVo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelOneTimeChargesVo,
    };
    const lineLevelOneTimeOthVenChargesVo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]
        ?.lineLevelOneTimeOthVenChargesVo,
    };
    const mtnLevelOneTimeChargesTotals = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelTotal
        ?.mtnLevelOneTimeChargesTotals,
    };
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <OneTimeChargesVo
          expandAll
          lineLevelOneTimeChargesVo={lineLevelOneTimeChargesVo}
          mtnLevelOneTimeChargesTotals={mtnLevelOneTimeChargesTotals}
          lineLevelOneTimeOthVenChargesVo={lineLevelOneTimeOthVenChargesVo}
          additionalInfo={additionalInfo}
          financedAmount={0}
        />
      </StoreProvider>,
    );
    const titleText = screen.getByText('One-time charges and credits');
    expect(titleText).toBeInTheDocument();
  });

  test('Accordion Open Close functionality', () => {
    const lineLevelOneTimeChargesVo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelOneTimeChargesVo,
    };
    const lineLevelOneTimeOthVenChargesVo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]
        ?.lineLevelOneTimeOthVenChargesVo,
    };
    const mtnLevelOneTimeChargesTotals = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelTotal
        ?.mtnLevelOneTimeChargesTotals,
    };
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <OneTimeChargesVo
          expandAll={false}
          lineLevelOneTimeChargesVo={lineLevelOneTimeChargesVo}
          mtnLevelOneTimeChargesTotals={mtnLevelOneTimeChargesTotals}
          lineLevelOneTimeOthVenChargesVo={lineLevelOneTimeOthVenChargesVo}
          additionalInfo={additionalInfo}
          financedAmount={0}
        />
      </StoreProvider>,
    );
    const chargesPlusTextBtn = screen.getByRole('button', { class: 'accordionButton' });
    expect(chargesPlusTextBtn).toBeInTheDocument();
    fireEvent.click(chargesPlusTextBtn);
  });

  test('isDark true', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] ,isDark: true, themeProps: {background: '#eeeeee'}};
    const lineLevelOneTimeChargesVo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelOneTimeChargesVo,
    };
    const lineLevelOneTimeOthVenChargesVo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]
        ?.lineLevelOneTimeOthVenChargesVo,
    };
    const mtnLevelOneTimeChargesTotals = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelTotal
        ?.mtnLevelOneTimeChargesTotals,
    };
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <OneTimeChargesVo
          expandAll={false}
          lineLevelOneTimeChargesVo={lineLevelOneTimeChargesVo}
          mtnLevelOneTimeChargesTotals={mtnLevelOneTimeChargesTotals}
          lineLevelOneTimeOthVenChargesVo={lineLevelOneTimeOthVenChargesVo}
          additionalInfo={additionalInfo}
          financedAmount={0}
        />
      </StoreProvider>,
    );
    const titleText = screen.getByText('One-time charges and credits');
    expect(titleText).toBeInTheDocument();
  });
});
