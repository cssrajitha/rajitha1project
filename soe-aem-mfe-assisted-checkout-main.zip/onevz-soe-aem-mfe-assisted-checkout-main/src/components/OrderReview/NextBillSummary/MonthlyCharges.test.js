import { render, screen, fireEvent } from '@testing-library/react';
import getNextBillSummaryNewCustomer from '../../../__mock__/getNextBillSummaryNewCustomer.json';
import StoreProvider from '../../../modules/store';
import MonthlyChargesVo from './MonthlyCharges';

describe('Next Bill Summary Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  test('render initial MonthlyCharges Component-01', () => {
    const lineLevelMonthlyChargesVo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelMonthlyChargesVo,
    };
    const mtnLevelMonthlyChargesTotals = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelTotal
        ?.lineLevelMonthlyChargesVo,
    };
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <MonthlyChargesVo
          expandAll={false}
          lineLevelMonthlyChargesVo={lineLevelMonthlyChargesVo}
          mtnLevelMonthlyChargesTotals={mtnLevelMonthlyChargesTotals}
          additionalInfo={additionalInfo}
          financedAmount={0}
        />
      </StoreProvider>,
    );
    const titleText = screen.getByText('Monthly charges and credits');
    expect(titleText).toBeInTheDocument();
  });

  test('render initial MonthlyCharges Component-02', () => {
    const lineLevelMonthlyChargesVo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelMonthlyChargesVo,
    };
    const mtnLevelMonthlyChargesTotals = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelTotal
        ?.lineLevelMonthlyChargesVo,
    };
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <MonthlyChargesVo
          expandAll
          lineLevelMonthlyChargesVo={lineLevelMonthlyChargesVo}
          mtnLevelMonthlyChargesTotals={mtnLevelMonthlyChargesTotals}
          additionalInfo={additionalInfo}
          financedAmount={0}
        />
      </StoreProvider>,
    );
    const titleText = screen.getByText('Monthly charges and credits');
    expect(titleText).toBeInTheDocument();
  });

  test('Accordion Open Close functionality', () => {
    const lineLevelMonthlyChargesVo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelMonthlyChargesVo,
    };
    const mtnLevelMonthlyChargesTotals = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelTotal
        ?.lineLevelMonthlyChargesVo,
    };
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <MonthlyChargesVo
          expandAll={false}
          lineLevelMonthlyChargesVo={lineLevelMonthlyChargesVo}
          mtnLevelMonthlyChargesTotals={mtnLevelMonthlyChargesTotals}
          additionalInfo={additionalInfo}
          financedAmount={0}
        />
      </StoreProvider>,
    );
    const chargesPlusTextBtn = screen.getByRole('button', { class: 'accordionButton' });
    expect(chargesPlusTextBtn).toBeInTheDocument();
    fireEvent.click(chargesPlusTextBtn);
  });

  test('isDark true', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] ,isDark: true, themeProps: {background: '#eeeeee'}};
    const lineLevelMonthlyChargesVo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelMonthlyChargesVo,
    };
    const mtnLevelMonthlyChargesTotals = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelTotal
        ?.lineLevelMonthlyChargesVo,
    };
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <MonthlyChargesVo
          expandAll={false}
          lineLevelMonthlyChargesVo={lineLevelMonthlyChargesVo}
          mtnLevelMonthlyChargesTotals={mtnLevelMonthlyChargesTotals}
          additionalInfo={additionalInfo}
          financedAmount={0}
        />
      </StoreProvider>,
    );
    const titleText = screen.getByText('Monthly charges and credits');
    expect(titleText).toBeInTheDocument();
  });
});
