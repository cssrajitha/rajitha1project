import React, { useState, useEffect, Fragment } from 'react';
import { Accordion, AccordionItem, AccordionHeader, AccordionDetail } from '@vds/accordions';
import PropTypes from 'prop-types';
import SubLineCharges from './SubLineCharges';
import SubLineHeader from './SubLineHeader';

const OneTimeChargesVo = (props) => {
  const {
    lineLevelOneTimeChargesVo,
    mtnLevelOneTimeChargesTotals: { nextMonthCharge },
    additionalInfo,
    financedAmount,
    expandAll,
  } = props;
  const [open, setOpen] = useState(false);
  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;

  useEffect(() => {
    if (expandAll === true) {
      setOpen(true);
    } else {
      setOpen(false);
    }
  }, [expandAll]);

  return (
    <Accordion bottomLine={false} surface={isDark ? 'dark' : 'light'}>
      <AccordionItem opened={open}>
        <AccordionHeader trigger={{ type: 'icon' }} onClick={() => setOpen(!open)}>
          <SubLineHeader
            title='One-time charges and credits'
            nextMonthCharge={nextMonthCharge}
            newMonthCharge={0}
            isOpen={open}
            setOpen={setOpen}
          />
        </AccordionHeader>
        <AccordionDetail>
          {lineLevelOneTimeChargesVo?.length > 0 &&
            lineLevelOneTimeChargesVo?.map((oneTimeCharges) => (
              <Fragment key='oneTime-subLine-index'>
                <SubLineCharges
                  charges={oneTimeCharges}
                  additionalInfo={additionalInfo}
                  financedAmount={financedAmount}
                />
              </Fragment>
            ))}
        </AccordionDetail>
      </AccordionItem>
    </Accordion>
  );
};

OneTimeChargesVo.propTypes = {
  lineLevelOneTimeChargesVo: PropTypes.any,
  mtnLevelOneTimeChargesTotals: PropTypes.any,
  additionalInfo: PropTypes.any,
  expandAll: PropTypes.bool,
  financedAmount: PropTypes.any,
};

export default OneTimeChargesVo;
