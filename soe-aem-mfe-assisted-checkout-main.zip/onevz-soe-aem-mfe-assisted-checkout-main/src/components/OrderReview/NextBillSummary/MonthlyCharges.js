import React, { useState, useEffect, Fragment } from 'react';
import { Accordion, AccordionItem, AccordionHeader, AccordionDetail } from '@vds/accordions';
import PropTypes from 'prop-types';
import SubLineCharges from './SubLineCharges';
import SubLineHeader from './SubLineHeader';

const MonthlyChargesVo = (props) => {
  const {
    lineLevelMonthlyChargesVo,
    mtnLevelMonthlyChargesTotals: { nextMonthCharge, newMonthCharge },
    additionalInfo = {},
    financedAmount,
    expandAll,
  } = props;
  const [open, setOpen] = useState(false);
  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;

  useEffect(() => {
    if (expandAll === true) {
      setOpen(true);
    } else {
      setOpen(false);
    }
  }, [expandAll]);

  return (
    <Accordion bottomLine={false} surface={isDark ? 'dark' : 'light'}>
      <AccordionItem opened={open}>
        <AccordionHeader trigger={{ type: 'icon' }} onClick={() => setOpen(!open)}>
          <SubLineHeader
            title='Monthly charges and credits'
            nextMonthCharge={nextMonthCharge}
            newMonthCharge={newMonthCharge}
            isOpen={open}
            setOpen={setOpen}
          />
        </AccordionHeader>
        <AccordionDetail>
          {lineLevelMonthlyChargesVo?.length > 0 &&
            lineLevelMonthlyChargesVo?.map((monthlyCharges) => (
              <Fragment key='monthly-subLine-index'>
                <SubLineCharges
                  charges={monthlyCharges}
                  additionalInfo={additionalInfo}
                  financedAmount={financedAmount}
                  showNextMonthPrice
                  showApoDiscount
                />
              </Fragment>
            ))}
        </AccordionDetail>
      </AccordionItem>
    </Accordion>
  );
};

MonthlyChargesVo.propTypes = {
  lineLevelMonthlyChargesVo: PropTypes.any,
  mtnLevelMonthlyChargesTotals: PropTypes.any,
  additionalInfo: PropTypes.any,
  expandAll: PropTypes.bool,
  financedAmount: PropTypes.any,
};
export default MonthlyChargesVo;
