import styled from 'styled-components';

export const Row = styled.div`
  display: flex;
  margin-bottom: 20px;
`;
export const SubRow = styled.div`
  display: flex;
  padding-top: 8px;
  padding-bottom: ${(p) => (p?.showAccordionDetail ? '0' : '48px')};
`;
export const SubSubRow = styled.div`
  display: flex;
  padding: 14px 0;
  :last-child {
    padding-bottom: 30px;
  }
`;
export const Col6 = styled.div`
  width: 50%;
`;
export const Col3 = styled.div`
  width: 25%;
`;
export const PaddLeft105Right21 = styled.div`
  padding-left: 105px;
  padding-right: 21px;
`;

export const PosAbsolute = styled.div`
  position: absolute;
  right: 0;
  z-index: 99;
  svg path {
    stroke: #000;
    stroke-width: 1px;
  }
`;
export const ColWarapper = styled.div`
  display: block;
  margin-bottom: 30px;
  margin-top: 30px;
`;

export const PreviewBillCol6 = styled.div`
  width: 58.33333%;
  h1 {
    font-size: 34px;
    letter-spacing: 0.4px;
  }
  h2 {
    font-size: 20px;
    letter-spacing: 0.4px;
  }
  h4 {
    font-size: 16px;
    letter-spacing: 0.4px;
  }
`;
export const PreviewBillCol3 = styled.div`
  width: 25%;
  h2 {
    font-size: 20px;
    letter-spacing: 0.4px;
  }
  h3 {
    font-size: 18px;
    letter-spacing: 0.4px;
  }
  h4 {
    font-size: 16px;
    letter-spacing: 0.4px;
  }
`;
export const PreviewBillCol2 = styled.div`
  width: 16.66667%;
  h2 {
    font-size: 20px;
    letter-spacing: 0.4px;
  }
  h3 {
    font-size: 18px;
    letter-spacing: 0.4px;
  }
  h4 {
    font-size: 16px;
    letter-spacing: 0.4px;
  }
`;
export const PaddingLeft28Width172 = styled.div`
  padding: 0 0 0 1.75rem;
  width: 172px;
`;

export const AccordionDetailWrapper = styled.div`
  margin-bottom: -2rem;
`;
