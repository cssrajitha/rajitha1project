import React, { useState, useEffect, Fragment } from 'react';
import { Accordion, AccordionItem, AccordionHeader, AccordionDetail } from '@vds/accordions';
import PropTypes from 'prop-types';
import SubLineCharges from './SubLineCharges';
import SubLineHeader from './SubLineHeader';

const AddOnChargesVo = (props) => {
  const {
    lineLevelAddOnsChargesVo,
    mtnLevelAddOnsChargesTotals: { nextMonthCharge, newMonthCharge },
    additionalInfo,
    financedAmount,
    expandAll,
  } = props;
  const [open, setOpen] = useState(false);
  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;
  useEffect(() => {
    if (expandAll === true) {
      setOpen(true);
    } else {
      setOpen(false);
    }
  }, [expandAll]);

  const isPrepayCart = sessionStorage.getItem('newPostToPreIndicator')
    ? sessionStorage.getItem('newPostToPreIndicator')
    : false;

  return (
    <Accordion bottomLine={false} surface={isDark ? 'dark' : 'light'}>
      <AccordionItem opened={open}>
        <AccordionHeader trigger={{ type: 'icon' }} onClick={() => setOpen(!open)}>
          <SubLineHeader
            title={isPrepayCart ? 'Add-ons' : 'Services & perks'}
            nextMonthCharge={nextMonthCharge}
            newMonthCharge={newMonthCharge}
            isOpen={open}
            setOpen={setOpen}
          />
        </AccordionHeader>
        <AccordionDetail>
          {lineLevelAddOnsChargesVo?.length > 0 &&
            lineLevelAddOnsChargesVo?.map((addOnCharges) => (
              <Fragment key='addOn-subLine-index'>
                <SubLineCharges
                  charges={addOnCharges}
                  additionalInfo={additionalInfo}
                  financedAmount={financedAmount}
                  showNextMonthPrice
                />
              </Fragment>
            ))}
        </AccordionDetail>
      </AccordionItem>
    </Accordion>
  );
};

AddOnChargesVo.propTypes = {
  lineLevelAddOnsChargesVo: PropTypes.any,
  mtnLevelAddOnsChargesTotals: PropTypes.any,
  additionalInfo: PropTypes.any,
  expandAll: PropTypes.bool,
  financedAmount: PropTypes.any,
};

export default AddOnChargesVo;
