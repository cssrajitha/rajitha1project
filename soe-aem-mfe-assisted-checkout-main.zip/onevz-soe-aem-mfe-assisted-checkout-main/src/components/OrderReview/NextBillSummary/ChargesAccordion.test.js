import { render, screen, fireEvent } from '@testing-library/react';
import getNextBillSummaryNewCustomer from '../../../__mock__/getNextBillSummaryNewCustomer.json';
import retriveCartJson from '../../../__mock__/retrive-cart.json';
import ChargesAccordion from './ChargesAccordion';
import StoreProvider from '../../../modules/store';

describe('Next Bill Summary Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  test('render initial ChargesAccordion Component-01', () => {
    render(
      <StoreProvider>
        <ChargesAccordion
          mtnData={getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]}
          expandAll={false}
          cartInfo={retriveCartJson?.data?.cart}
        />
      </StoreProvider>,
    );
    const titleText = screen.getByTestId('nickname-title-value');
    expect(titleText.textContent).toEqual('CHAITANYA NAWADE');
    const mtnText = screen.getByText('315.212.6442(new)');
    expect(mtnText).toBeInTheDocument();
    const pendingOrderText = screen.getByText('Pending order');
    expect(pendingOrderText).toBeInTheDocument();
    const nextMonthCharge = screen.getByTestId('nextmonth-charge-title-value');
    expect(nextMonthCharge.textContent).toEqual('$224.26');
    const newMonthCharge = screen.getByTestId('newmonth-charge-title-value');
    expect(newMonthCharge.textContent).toEqual('$98.35');
  });

  test('render initial ChargesAccordion Component-02', () => {
    render(
      <StoreProvider>
        <ChargesAccordion
          mtnData={getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]}
          expandAll
          cartInfo={retriveCartJson?.data?.cart}
        />
      </StoreProvider>,
    );
    const titleText = screen.getByTestId('nickname-title-value');
    expect(titleText.textContent).toEqual('CHAITANYA NAWADE');
    const mtnText = screen.getByText('315.212.6442(new)');
    expect(mtnText).toBeInTheDocument();
    const pendingOrderText = screen.getByText('Pending order');
    expect(pendingOrderText).toBeInTheDocument();
    const nextMonthCharge = screen.getByTestId('nextmonth-charge-title-value');
    expect(nextMonthCharge.textContent).toEqual('$224.26');
    const newMonthCharge = screen.getByTestId('newmonth-charge-title-value');
    expect(newMonthCharge.textContent).toEqual('$98.35');
  });

  test('Accordion Open Close functionality', () => {
    render(
      <StoreProvider>
        <ChargesAccordion
          mtnData={getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]}
          expandAll={false}
          cartInfo={retriveCartJson?.data?.cart}
        />
      </StoreProvider>,
    );
    const chargesPlusTextBtn = screen.getByTestId('charges-plus');
    expect(chargesPlusTextBtn).toBeInTheDocument();
    fireEvent.click(chargesPlusTextBtn);
  });

  test('Accordion Surcharges Details-01', () => {
    render(
      <StoreProvider>
        <ChargesAccordion
          mtnData={getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]}
          expandAll={false}
          cartInfo={retriveCartJson?.data?.cart}
        />
      </StoreProvider>,
    );
    const surchargesText = screen.getByText('Surcharges');
    expect(surchargesText).toBeInTheDocument();

    const surchargesNextMonthCharge = screen.getByTestId('surcharges-nextmonth-charge');
    expect(surchargesNextMonthCharge.textContent).toEqual('$18.84');

    const surchargesNewMonthCharge = screen.getByTestId('surcharges-newmonth-charge');
    expect(surchargesNewMonthCharge.textContent).toEqual('$6.89');
  });

  test('Accordion Surcharges Details-02', () => {
    const mtnLevelChargesDetails = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0],
    };
    const mtmDataMock = { ...mtnLevelChargesDetails, nextMonthSurcharges: 0 };
    render(
      <StoreProvider>
        <ChargesAccordion mtnData={mtmDataMock} expandAll={false} cartInfo={retriveCartJson?.data?.cart} />
      </StoreProvider>,
    );
    const surchargesText = screen.getByText('Surcharges');
    expect(surchargesText).toBeInTheDocument();

    const surchargesNextMonthCharge = screen.getByTestId('surcharges-nextmonth-charge');
    expect(surchargesNextMonthCharge.textContent).toEqual('$0.00');

    const surchargesNewMonthCharge = screen.getByTestId('surcharges-newmonth-charge');
    expect(surchargesNewMonthCharge.textContent).toEqual('$6.89');
  });

  test('Accordion Taxes & gov fees Details-01', () => {
    render(
      <StoreProvider>
        <ChargesAccordion
          mtnData={getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]}
          expandAll={false}
          cartInfo={retriveCartJson?.data?.cart}
        />
      </StoreProvider>,
    );
    const taxesAndGovFeesText = screen.getByText('Taxes & gov fees');
    expect(taxesAndGovFeesText).toBeInTheDocument();

    const taxesAndGovFeesNextMonthCharge = screen.getByTestId('taxesAndGovFees-nextmonth-charge');
    expect(taxesAndGovFeesNextMonthCharge.textContent).toEqual('$6.77');

    const taxesAndGovFeesNewMonthCharge = screen.getByTestId('taxesAndGovFees-newmonth-charge');
    expect(taxesAndGovFeesNewMonthCharge.textContent).toEqual('$1.73');
  });

  test('Accordion Taxes & gov fees Details-02', () => {
    const mtnLevelChargesDetails = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0],
    };
    const mtmDataMock = { ...mtnLevelChargesDetails, nextMonthTax: 0 };
    render(
      <StoreProvider>
        <ChargesAccordion mtnData={mtmDataMock} expandAll={false} cartInfo={retriveCartJson?.data?.cart} />
      </StoreProvider>,
    );
    const taxesAndGovFeesText = screen.getByText('Taxes & gov fees');
    expect(taxesAndGovFeesText).toBeInTheDocument();

    const taxesAndGovFeesNextMonthCharge = screen.getByTestId('taxesAndGovFees-nextmonth-charge');
    expect(taxesAndGovFeesNextMonthCharge.textContent).toEqual('$0.00');

    const taxesAndGovFeesNewMonthCharge = screen.getByTestId('taxesAndGovFees-newmonth-charge');
    expect(taxesAndGovFeesNewMonthCharge.textContent).toEqual('$1.73');
  });

  test('isDark true', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] ,isDark: true, themeProps: {background: '#eeeeee'}};
    render(
      <StoreProvider>
        <ChargesAccordion
          mtnData={getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]}
          expandAll={false}
          cartInfo={retriveCartJson?.data?.cart}
        />
      </StoreProvider>,
    );
    
  });
});
