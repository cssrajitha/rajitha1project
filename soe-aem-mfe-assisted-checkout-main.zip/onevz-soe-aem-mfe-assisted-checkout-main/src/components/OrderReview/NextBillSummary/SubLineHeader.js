import React from 'react';
import PropTypes from 'prop-types';
import { Title } from '@vds/typography';
import { Icon } from '@vds/icons';
import {
  PosAbsolute,
  SubRow,
  PreviewBillCol6,
  PreviewBillCol3,
  PreviewBillCol2,
  PaddingLeft28Width172,
} from './CommonStyles';
import { formatCurrency } from '../../../utils/common';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR } from '../../constants/constants';

const SubLineHeader = (props) => {
  const { title, nextMonthCharge, newMonthCharge, isOpen, setOpen } = props;
  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;
  return (
    <SubRow showAccordionDetail={isOpen} style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
      <PreviewBillCol6>
        <PaddingLeft28Width172>
          <Title size='medium' bold primitive='h2' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
            {title}
          </Title>
        </PaddingLeft28Width172>
      </PreviewBillCol6>
      <PreviewBillCol3 style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
        <Title
          size='medium'
          bold
          primitive='h2'
          data-testid='next-month-charges'
          color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}
        >
          {formatCurrency(nextMonthCharge)}
        </Title>
      </PreviewBillCol3>
      <PreviewBillCol2 style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
        <Title
          size='medium'
          bold
          primitive='h2'
          data-testid='new-month-charges'
          color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}
        >
          {formatCurrency(newMonthCharge)}
        </Title>
      </PreviewBillCol2>
      <PosAbsolute
        onClick={() => setOpen(!isOpen)}
        data-testid={isOpen ? 'minusIcon' : 'plusIcon'}
        style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}
      >
        <Icon name={isOpen ? 'minus' : 'plus'} size='XLarge' surface={isDark ? 'dark' : 'light'} />
      </PosAbsolute>
    </SubRow>
  );
};

SubLineHeader.propTypes = {
  title: PropTypes.string,
  nextMonthCharge: PropTypes.any,
  newMonthCharge: PropTypes.any,
  isOpen: PropTypes.bool,
  setOpen: PropTypes.func,
};
export default SubLineHeader;
