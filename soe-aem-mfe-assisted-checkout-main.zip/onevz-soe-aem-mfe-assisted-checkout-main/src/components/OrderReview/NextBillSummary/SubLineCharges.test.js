import { render, screen } from '@testing-library/react';
import getNextBillSummaryNewCustomer from '../../../__mock__/getNextBillSummaryNewCustomer.json';
import StoreProvider from '../../../modules/store';
import SubLineCharges from './SubLineCharges';

describe('Next Bill Summary Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  test('render initial component', () => {
    const oneTimeCharges = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]
        ?.lineLevelOneTimeChargesVo[0],
    };
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <SubLineCharges charges={oneTimeCharges} additionalInfo={additionalInfo} financedAmount={0} />
      </StoreProvider>,
    );
    const titleText = screen.getByText('UNLIMITED ULTIMATE');
    expect(titleText).toBeInTheDocument();
  });

  test('render initial component with title - APPLE ONE INDIVIDUAL', () => {
    const oneTimeCharges = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]
        ?.lineLevelAddOnsChargesVo[0],
    };
    oneTimeCharges.itemType.isEQUIPMENT = true;
    oneTimeCharges.loanNumber = '0';
    oneTimeCharges.nextInstallmentNumber = '1';
    oneTimeCharges.totalInstallmentNumber = '36';
    oneTimeCharges.outstandingLoanAmount = '0';
    oneTimeCharges.loanAmount = '0';
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <SubLineCharges charges={oneTimeCharges} additionalInfo={additionalInfo} financedAmount={999.99} />
      </StoreProvider>,
    );
    const titleText = screen.getByText('APPLE ONE INDIVIDUAL');
    expect(titleText).toBeInTheDocument();
  });

  test('render initial component with device payment', () => {
    const oneTimeCharges = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]
        ?.lineLevelAddOnsChargesVo[0],
    };
    oneTimeCharges.itemType.isEQUIPMENT = true;
    oneTimeCharges.description = 'device payment';
    oneTimeCharges.acctNextDefamt = '10.00';
    oneTimeCharges.loanNumber = '0';
    oneTimeCharges.nextInstallmentNumber = '1';
    oneTimeCharges.totalInstallmentNumber = '36';
    oneTimeCharges.outstandingLoanAmount = '0';
    oneTimeCharges.loanAmount = '0';
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <SubLineCharges charges={oneTimeCharges} additionalInfo={additionalInfo} financedAmount={999.99} />
      </StoreProvider>,
    );
    const titleText = screen.getByText(
      'device payment 1 of 36 ($999.99/36) ~ $989.99 remaining after this month ~ (agreement 0)',
    );
    expect(titleText).toBeInTheDocument();
  });

  test('render initial component Included with plan', () => {
    const oneTimeCharges = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]
        ?.lineLevelAddOnsChargesVo[0],
    };
    oneTimeCharges.spoCategoryCodeList[0].spoCategoryCode = 'GCPROMO';
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <SubLineCharges charges={oneTimeCharges} additionalInfo={additionalInfo} financedAmount={0} />
      </StoreProvider>,
    );
    const titleText = screen.getByText(/Included with plan/);
    expect(titleText).toBeInTheDocument();
  });

  test('render initial component Promotional Period date', () => {
    const oneTimeCharges = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]
        ?.lineLevelAddOnsChargesVo[0],
    };
    oneTimeCharges.itemType.isOCC = true;
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <SubLineCharges charges={oneTimeCharges} additionalInfo={additionalInfo} financedAmount={0} />
      </StoreProvider>,
    );
    const titleText = screen.getByText(/Promotional Period : Jul 11, 2024 - Aug 10, 2024/);
    expect(titleText).toBeInTheDocument();
  });

  test('render initial component Subscription Upgrade date', () => {
    const oneTimeCharges = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]
        ?.lineLevelAddOnsChargesVo[0],
    };
    oneTimeCharges.subTextInd = 'MYPLANPERK';
    oneTimeCharges.itemType.isOCC = true;
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <SubLineCharges charges={oneTimeCharges} additionalInfo={additionalInfo} financedAmount={0} />
      </StoreProvider>,
    );
    const subscriptionUpgradeText = screen.getByText(/Subscription Upgrade/);
    expect(subscriptionUpgradeText).toBeInTheDocument();
    const subscriptionUpgradeDate = screen.getByText(/(Jul 11 - Aug 10)/);
    expect(subscriptionUpgradeDate).toBeInTheDocument();
  });

  test('render initial component with expiry date', () => {
    const oneTimeCharges = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]
        ?.lineLevelAddOnsChargesVo[0],
    };
    oneTimeCharges.expiryDate = '08/10/2024';
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <SubLineCharges charges={oneTimeCharges} additionalInfo={additionalInfo} financedAmount={0} />
      </StoreProvider>,
    );
    const titleText = screen.getByText(/(Expires Aug 10, 2024, 2024)/);
    expect(titleText).toBeInTheDocument();
  });

  test('render initial component with promo1EndDate', () => {
    const oneTimeCharges = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]
        ?.lineLevelAddOnsChargesVo[0],
    };
    oneTimeCharges.itemType.isPROMO = true;
    oneTimeCharges.promo1EndDate = '08/10/2024';
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <SubLineCharges charges={oneTimeCharges} additionalInfo={additionalInfo} financedAmount={0} />
      </StoreProvider>,
    );
    const titleText = screen.getByText(/(Expires Aug 10, 2024, 2024)/);
    expect(titleText).toBeInTheDocument();
  });

  test('render initial component with promo2EndDate', () => {
    const oneTimeCharges = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]
        ?.lineLevelAddOnsChargesVo[0],
    };
    oneTimeCharges.itemType.isPROMO = true;
    oneTimeCharges.promo2EndDate = '08/10/2024';
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <SubLineCharges charges={oneTimeCharges} additionalInfo={additionalInfo} financedAmount={0} />
      </StoreProvider>,
    );
    const titleText = screen.getByText(/(Expires Aug 10, 2024, 2024)/);
    expect(titleText).toBeInTheDocument();
  });

  test('render initial component with promo3EndDate', () => {
    const oneTimeCharges = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]
        ?.lineLevelAddOnsChargesVo[0],
    };
    oneTimeCharges.itemType.isPROMO = true;
    oneTimeCharges.promo3EndDate = '08/10/2024';
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <SubLineCharges charges={oneTimeCharges} additionalInfo={additionalInfo} financedAmount={0} />
      </StoreProvider>,
    );
    const titleText = screen.getByText(/(Expires Aug 10, 2024, 2024)/);
    expect(titleText).toBeInTheDocument();
  });

  test('render initial component with promo1EndDate MONTHS ON US', () => {
    const oneTimeCharges = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]
        ?.lineLevelAddOnsChargesVo[0],
    };
    oneTimeCharges.itemType.isPROMO = true;
    oneTimeCharges.promo1EndDate = '10';
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <SubLineCharges charges={oneTimeCharges} additionalInfo={additionalInfo} financedAmount={0} />
      </StoreProvider>,
    );
    const titleText = screen.getByText(/(10 MONTHS ON US)/);
    expect(titleText).toBeInTheDocument();
  });

  test('render initial component with promo2EndDate MONTHS ON US', () => {
    const oneTimeCharges = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]
        ?.lineLevelAddOnsChargesVo[0],
    };
    oneTimeCharges.itemType.isPROMO = true;
    oneTimeCharges.promo2EndDate = '10';
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <SubLineCharges charges={oneTimeCharges} additionalInfo={additionalInfo} financedAmount={0} />
      </StoreProvider>,
    );
    const titleText = screen.getByText(/(10 MONTHS ON US)/);
    expect(titleText).toBeInTheDocument();
  });

  test('render initial component with promo3EndDate MONTHS ON US', () => {
    const oneTimeCharges = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]
        ?.lineLevelAddOnsChargesVo[0],
    };
    oneTimeCharges.itemType.isPROMO = true;
    oneTimeCharges.promo3EndDate = '10';
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <SubLineCharges charges={oneTimeCharges} additionalInfo={additionalInfo} financedAmount={0} />
      </StoreProvider>,
    );
    const titleText = screen.getByText(/(10 MONTHS ON US)/);
    expect(titleText).toBeInTheDocument();
  });
  test('isDark true', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] ,isDark: true, themeProps: {background: '#eeeeee'}};
    const oneTimeCharges = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]
        ?.lineLevelAddOnsChargesVo[0],
    };
    oneTimeCharges.itemType.isPROMO = true;
    oneTimeCharges.promo3EndDate = '10';
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <SubLineCharges charges={oneTimeCharges} additionalInfo={additionalInfo} financedAmount={0} />
      </StoreProvider>,
    );
    const titleText = screen.getByText(/(10 MONTHS ON US)/);
    expect(titleText).toBeInTheDocument();
  });
});
