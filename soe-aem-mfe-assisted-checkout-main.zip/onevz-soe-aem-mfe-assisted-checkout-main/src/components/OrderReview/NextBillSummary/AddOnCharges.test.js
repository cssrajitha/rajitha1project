import { render, screen, fireEvent } from '@testing-library/react';
import getNextBillSummaryNewCustomer from '../../../__mock__/getNextBillSummaryNewCustomer.json';
import StoreProvider from '../../../modules/store';
import AddOnChargesVo from './AddOnCharges';

describe('Next Bill Summary Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  test('render initial AddOnCharges Component-01', () => {
    const lineLevelAddOnsChargesVo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelAddOnsChargesVo,
    };
    const lineLevelAddOnsOthVenChargesVo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]
        ?.lineLevelAddOnsOthVenChargesVo,
    };
    const mtnLevelAddOnsChargesTotals = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelTotal
        ?.mtnLevelAddOnsChargesTotals,
    };
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <AddOnChargesVo
          expandAll={false}
          lineLevelAddOnsChargesVo={lineLevelAddOnsChargesVo}
          lineLevelAddOnsOthVenChargesVo={lineLevelAddOnsOthVenChargesVo}
          mtnLevelAddOnsChargesTotals={mtnLevelAddOnsChargesTotals}
          additionalInfo={additionalInfo}
          financedAmount={0}
        />
      </StoreProvider>,
    );
    const titleText = screen.getByText('Services & perks');
    expect(titleText).toBeInTheDocument();
  });

  test('render initial AddOnCharges Component-02', () => {
    const lineLevelAddOnsChargesVo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelAddOnsChargesVo,
    };
    const lineLevelAddOnsOthVenChargesVo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]
        ?.lineLevelAddOnsOthVenChargesVo,
    };
    const mtnLevelAddOnsChargesTotals = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelTotal
        ?.mtnLevelAddOnsChargesTotals,
    };
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <AddOnChargesVo
          expandAll
          lineLevelAddOnsChargesVo={lineLevelAddOnsChargesVo}
          lineLevelAddOnsOthVenChargesVo={lineLevelAddOnsOthVenChargesVo}
          mtnLevelAddOnsChargesTotals={mtnLevelAddOnsChargesTotals}
          additionalInfo={additionalInfo}
          financedAmount={0}
        />
      </StoreProvider>,
    );
    const titleText = screen.getByText('Services & perks');
    expect(titleText).toBeInTheDocument();
  });

  test('render initial AddOnCharges Component-03', () => {
    sessionStorage.setItem('newPostToPreIndicator', true);
    const lineLevelAddOnsChargesVo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelAddOnsChargesVo,
    };
    const lineLevelAddOnsOthVenChargesVo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]
        ?.lineLevelAddOnsOthVenChargesVo,
    };
    const mtnLevelAddOnsChargesTotals = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelTotal
        ?.mtnLevelAddOnsChargesTotals,
    };
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <AddOnChargesVo
          expandAll={false}
          lineLevelAddOnsChargesVo={lineLevelAddOnsChargesVo}
          lineLevelAddOnsOthVenChargesVo={lineLevelAddOnsOthVenChargesVo}
          mtnLevelAddOnsChargesTotals={mtnLevelAddOnsChargesTotals}
          additionalInfo={additionalInfo}
          financedAmount={0}
        />
      </StoreProvider>,
    );
    const titleText = screen.getByText('Add-ons');
    expect(titleText).toBeInTheDocument();
  });

  test('Accordion Open Close functionality', () => {
    const lineLevelAddOnsChargesVo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelAddOnsChargesVo,
    };
    const lineLevelAddOnsOthVenChargesVo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]
        ?.lineLevelAddOnsOthVenChargesVo,
    };
    const mtnLevelAddOnsChargesTotals = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelTotal
        ?.mtnLevelAddOnsChargesTotals,
    };
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <AddOnChargesVo
          expandAll={false}
          lineLevelAddOnsChargesVo={lineLevelAddOnsChargesVo}
          lineLevelAddOnsOthVenChargesVo={lineLevelAddOnsOthVenChargesVo}
          mtnLevelAddOnsChargesTotals={mtnLevelAddOnsChargesTotals}
          additionalInfo={additionalInfo}
          financedAmount={0}
        />
      </StoreProvider>,
    );
    const chargesPlusTextBtn = screen.getByRole('button', { class: 'accordionButton' });
    expect(chargesPlusTextBtn).toBeInTheDocument();
    fireEvent.click(chargesPlusTextBtn);
  });

  test('isDark true', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] ,isDark: true, themeProps: {background: '#eeeeee'}};
    const lineLevelAddOnsChargesVo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelAddOnsChargesVo,
    };
    const lineLevelAddOnsOthVenChargesVo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]
        ?.lineLevelAddOnsOthVenChargesVo,
    };
    const mtnLevelAddOnsChargesTotals = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.lineLevelTotal
        ?.mtnLevelAddOnsChargesTotals,
    };
    const additionalInfo = {
      ...getNextBillSummaryNewCustomer?.nbsVo?.lineLevelChargesVo?.mtnLevelChargeDetails[0]?.additionalInfo,
    };
    render(
      <StoreProvider>
        <AddOnChargesVo
          expandAll={false}
          lineLevelAddOnsChargesVo={lineLevelAddOnsChargesVo}
          lineLevelAddOnsOthVenChargesVo={lineLevelAddOnsOthVenChargesVo}
          mtnLevelAddOnsChargesTotals={mtnLevelAddOnsChargesTotals}
          additionalInfo={additionalInfo}
          financedAmount={0}
        />
      </StoreProvider>,
    );
    
  });
});
