import React, { useState, useEffect } from 'react';
import { AccordionItem, AccordionHeader, AccordionDetail } from '@vds/accordions';
import { Title } from '@vds/typography';
import { Icon } from '@vds/icons';
import PropTypes from 'prop-types';
import OneTimeChargesVo from './OnetimeCharges';
import MonthlyChargesVo from './MonthlyCharges';
import AddOnChargesVo from './AddOnCharges';
import {
  PosAbsolute,
  Row,
  SubRow,
  ColWarapper,
  PreviewBillCol6,
  PreviewBillCol3,
  PreviewBillCol2,
  PaddingLeft28Width172,
  AccordionDetailWrapper,
} from './CommonStyles';
import { financedAmount, formatCurrency, formatMtnWithDecimals } from '../../../utils/common';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR } from '../../constants/constants';

const ChargesAccordion = ({ expandAll, mtnData, cartInfo }) => {
  const {
    nickname,
    mtn,
    pendingActivationIndicator,
    lineLevelTotal: { nextMonthCharge, newMonthCharge },
    lineLevelTotal,
    lineLevelOneTimeChargesVo,
    lineLevelOneTimeOthVenChargesVo,
    lineLevelAddOnsChargesVo,
    lineLevelAddOnsOthVenChargesVo,
    lineLevelMonthlyChargesVo,
    additionalInfo,
    newMonthSurcharges,
    nextMonthSurcharges,
    nextMonthTax,
    newMonthTax,
  } = mtnData;

  const emptyTotals = {
    nextMonthCharge: '',
    newMonthCharge: '',
  };
  const mtnLevelOneTimeChargesTotals = lineLevelTotal?.mtnLevelOneTimeChargesTotals || emptyTotals;
  const mtnLevelMonthlyChargesTotals = lineLevelTotal?.mtnLevelMonthlyChargesTotals || emptyTotals;
  const mtnLevelAddOnsChargesTotals = lineLevelTotal?.mtnLevelAddOnsChargesTotals || emptyTotals;
  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;
  const isPendingActivationIndicator = pendingActivationIndicator && pendingActivationIndicator === 'Y';

  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (expandAll === true) {
      setOpen(true);
    } else {
      setOpen(false);
    }
  }, [expandAll]);

  const toggleOpen = () => {
    setOpen(!open);
  };
  return (
    <AccordionItem opened={open} surface={isDark ? 'dark' : 'light'}>
      <AccordionHeader trigger={{ type: 'icon' }} onClick={toggleOpen}>
        <ColWarapper data-testid='charges-accordion-header'>
          <Row>
            <PreviewBillCol6>
              <Title
                size='medium'
                bold
                primitive='h2'
                data-testid='nickname-title-value'
                color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}
              >
                {nickname}
              </Title>
              <Title
                size='medium'
                primitive='h2'
                color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}
              >{`${formatMtnWithDecimals(mtn)}${isPendingActivationIndicator ? '(new)' : ''}`}</Title>
              {isPendingActivationIndicator && (
                <Title size='medium' primitive='h2' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                  Pending order
                </Title>
              )}
            </PreviewBillCol6>
            <PreviewBillCol3>
              <Title
                size='small'
                bold
                primitive='h3'
                data-testid='nextmonth-charge-title-value'
                color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}
              >
                {formatCurrency(nextMonthCharge)}
              </Title>
            </PreviewBillCol3>
            <PreviewBillCol2>
              <Title
                size='small'
                bold
                primitive='h3'
                data-testid='newmonth-charge-title-value'
                color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}
              >
                {formatCurrency(newMonthCharge)}
              </Title>
            </PreviewBillCol2>
            <PosAbsolute onClick={toggleOpen} data-testid={open ? 'charges-minus' : 'charges-plus'}>
              <Icon
                name={open ? 'minus' : 'plus'}
                size='XLarge'
                color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}
              />
            </PosAbsolute>
          </Row>
        </ColWarapper>
      </AccordionHeader>
      <AccordionDetail>
        <AccordionDetailWrapper>
          {lineLevelOneTimeChargesVo?.length > 0 && (
            <OneTimeChargesVo
              expandAll={expandAll}
              lineLevelOneTimeChargesVo={lineLevelOneTimeChargesVo}
              mtnLevelOneTimeChargesTotals={mtnLevelOneTimeChargesTotals}
              lineLevelOneTimeOthVenChargesVo={lineLevelOneTimeOthVenChargesVo}
              additionalInfo={additionalInfo}
              financedAmount={financedAmount(cartInfo, mtn)}
            />
          )}
          {lineLevelMonthlyChargesVo?.length > 0 && (
            <MonthlyChargesVo
              expandAll={expandAll}
              lineLevelMonthlyChargesVo={lineLevelMonthlyChargesVo}
              mtnLevelMonthlyChargesTotals={mtnLevelMonthlyChargesTotals}
              additionalInfo={additionalInfo}
              financedAmount={financedAmount(cartInfo, mtn)}
            />
          )}
          {lineLevelAddOnsChargesVo?.length > 0 && (
            <AddOnChargesVo
              expandAll={expandAll}
              lineLevelAddOnsChargesVo={lineLevelAddOnsChargesVo}
              lineLevelAddOnsOthVenChargesVo={lineLevelAddOnsOthVenChargesVo}
              mtnLevelAddOnsChargesTotals={mtnLevelAddOnsChargesTotals}
              additionalInfo={additionalInfo}
              financedAmount={financedAmount(cartInfo, mtn)}
            />
          )}
          {(parseFloat(nextMonthSurcharges) !== 0 || parseFloat(newMonthSurcharges) !== 0) && (
            <SubRow data-testid='surcharges-ctn'>
              <PreviewBillCol6>
                <PaddingLeft28Width172>
                  <Title size='small' bold primitive='h4' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                    Surcharges
                  </Title>
                </PaddingLeft28Width172>
              </PreviewBillCol6>
              <PreviewBillCol3>
                <Title
                  size='small'
                  bold
                  primitive='h4'
                  data-testid='surcharges-nextmonth-charge'
                  color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}
                >
                  {formatCurrency(nextMonthSurcharges)}
                </Title>
              </PreviewBillCol3>
              <PreviewBillCol2>
                <Title
                  size='small'
                  bold
                  primitive='h4'
                  data-testid='surcharges-newmonth-charge'
                  color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}
                >
                  {formatCurrency(newMonthSurcharges)}
                </Title>
              </PreviewBillCol2>
            </SubRow>
          )}
          {(parseFloat(nextMonthTax) !== 0 || parseFloat(newMonthTax) !== 0) && (
            <SubRow>
              <PreviewBillCol6>
                <PaddingLeft28Width172>
                  <Title size='small' bold primitive='h4' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                    Taxes & gov fees
                  </Title>
                </PaddingLeft28Width172>
              </PreviewBillCol6>
              <PreviewBillCol3>
                <Title
                  size='small'
                  bold
                  primitive='h4'
                  data-testid='taxesAndGovFees-nextmonth-charge'
                  color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}
                >
                  {formatCurrency(nextMonthTax)}
                </Title>
              </PreviewBillCol3>
              <PreviewBillCol2>
                <Title
                  size='small'
                  bold
                  primitive='h4'
                  data-testid='taxesAndGovFees-newmonth-charge'
                  color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}
                >
                  {formatCurrency(newMonthTax)}
                </Title>
              </PreviewBillCol2>
            </SubRow>
          )}
        </AccordionDetailWrapper>
      </AccordionDetail>
    </AccordionItem>
  );
};

ChargesAccordion.propTypes = {
  mtnData: PropTypes.any,
  expandAll: PropTypes.bool,
  cartInfo: PropTypes.any,
};

export default ChargesAccordion;
