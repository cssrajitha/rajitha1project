import React from 'react';
import PropTypes from 'prop-types';
import { Body, Title } from '@vds/typography';
import { SubSubRow, PaddLeft105Right21, PreviewBillCol6, PreviewBillCol3, PreviewBillCol2 } from './CommonStyles';
import { convertDateRange, formatCurrency, formatMtnWithDecimals } from '../../../utils/common';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR, ADDINFO_LIGHT_COLOR } from '../../constants/constants';

const SubLineCharges = ({
  charges,
  showNextMonthPrice = false,
  showApoDiscount = false,
  additionalInfo = {},
  financedAmount,
}) => {
  const {
    hasNextMonthPromoDiscount,
    hasThisMonthPromoDiscount,
    nextMonthCharge,
    thisMonthCharge,
    description,
    chargeEffectiveDate,
    chargeEndDate,
    itemType = {},
    acctDefDescription = '',
    acctDefDescription2 = '',
    overageDesc = '',
    acctNextDefamt,
    spoCategoryCodeList = [],
    subTextInd = '',
  } = charges;

  const { isPROMO = false, isOCC = false, isAddOn = false, isPLAN = false, isNAF = false, isPerk = false } = itemType;
  const { isEQUIPMENT } = itemType;
  const spoCategoryCode = spoCategoryCodeList?.[0]?.spoCategoryCode;
  let displayDesc = description;
  const isSPO = itemType?.isSPO;
  const isSubscriptionUpgrade = subTextInd?.toUpperCase() === 'MYPLANPERK';
  const isAPODiscount = (isPLAN || isNAF) && charges?.apoIndicator === 'Y' && showApoDiscount;
  let promotionalDescriptionArray = [];
  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;

  promotionalDescriptionArray = description?.split('|')[1];
  if (charges?.description2 && charges?.description2 !== '') {
    displayDesc = description + charges.description2;
  }
  if (acctDefDescription !== '') {
    displayDesc = acctDefDescription + acctDefDescription2 + overageDesc;
  }

  const nxtMonthCharge = acctNextDefamt && acctNextDefamt !== '' ? acctNextDefamt : nextMonthCharge;

  if (isEQUIPMENT) {
    const loanNumber = charges?.loanNumber;
    const nextInstallmentNumber = charges?.nextInstallmentNumber;
    const totalInstallmentNumber = charges?.totalInstallmentNumber;
    const loanAmount = charges?.loanAmount > 0 ? charges.loanAmount : financedAmount;
    const outstandingLoanAmount =
      charges?.outstandingLoanAmount > 0 ? charges?.outstandingLoanAmount : financedAmount - nxtMonthCharge;

    displayDesc =
      description &&
      description.toLowerCase() === 'device payment' &&
      loanNumber &&
      nextInstallmentNumber &&
      totalInstallmentNumber &&
      outstandingLoanAmount &&
      loanAmount
        ? `${description} ${nextInstallmentNumber} of ${totalInstallmentNumber} ($${loanAmount}/${totalInstallmentNumber}) ~ $${outstandingLoanAmount} remaining after this month ~ (agreement ${loanNumber})`
        : description;
  }

  return (
    <SubSubRow>
      <PreviewBillCol6 style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
        <PaddLeft105Right21>
          <Title color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR} size='small' primitive='h4'>
            {displayDesc?.split('|')[0]}
          </Title>
          {isAPODiscount && (
            <>
              <Title color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR} size='small' primitive='h4'>
                {charges?.apoDescription}
              </Title>
              <Title color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR} size='small' primitive='h4'>
                {charges?.apoDescription2}
              </Title>
            </>
          )}
          {chargeEffectiveDate !== undefined && chargeEndDate !== undefined && (
            <Title color={isDark ? DARK_THEME_COLOR : ADDINFO_LIGHT_COLOR} size='small' primitive='h4'>
              {charges?.chargeRefId === '70995' && displayDesc?.toLowerCase() === 'second number' && (
                <>
                  {`Shared with ${formatMtnWithDecimals(additionalInfo?.[0]?.additionalInfoValue)}`}
                  <br />
                </>
              )}
              {isPROMO === true && (
                <>
                  {promotionalDescriptionArray}
                  <br />
                </>
              )}
              {isPerk === true && (
                <>
                  Plan perk <br />
                </>
              )}
              {spoCategoryCode === 'GCPROMO' && isSPO === true && (
                <>
                  Included with plan <br />
                </>
              )}
              {isOCC && isAddOn ? (
                <>
                  {isSubscriptionUpgrade && (
                    <>
                      <span>Subscription Upgrade</span>
                      <br />
                      {`(${convertDateRange(chargeEffectiveDate, isOCC, isAddOn, isSubscriptionUpgrade)} - ${convertDateRange(chargeEndDate, isOCC, isAddOn, isSubscriptionUpgrade)})`}
                    </>
                  )}
                  {!isSubscriptionUpgrade &&
                    `Promotional Period : ${convertDateRange(chargeEffectiveDate, isOCC, isAddOn)} - ${convertDateRange(chargeEndDate, isOCC, isAddOn)}`}
                </>
              ) : (
                `(${convertDateRange(chargeEffectiveDate, isOCC, isAddOn)} - ${convertDateRange(chargeEndDate, isOCC, isAddOn)})`
              )}
              {charges?.expiryDate !== '' && charges?.expiryDate?.length > 5 && (
                <>
                  <br />
                  {`(Expires ${convertDateRange(charges?.expiryDate, isOCC, isAddOn, isSubscriptionUpgrade)}, ${charges?.expiryDate?.substring(6, 10)})`}
                  <br />
                </>
              )}
              {charges?.itemType?.isPROMO &&
                ((charges?.promo1EndDate !== '' && charges?.promo1EndDate?.length > 5) ||
                  (charges?.promo2EndDate !== '' && charges?.promo2EndDate?.length > 5) ||
                  (charges?.promo3EndDate !== '' && charges?.promo3EndDate?.length > 5)) && (
                  <>
                    <br />
                    {`(Expires ${convertDateRange(charges?.promo1EndDate || charges?.promo2EndDate || charges?.promo3EndDate, isOCC, isAddOn, isSubscriptionUpgrade)}, ${charges?.promo1EndDate?.substring(6, 10) || charges?.promo2EndDate?.substring(6, 10) || charges?.promo3EndDate?.substring(6, 10)})`}
                    <br />
                  </>
                )}
              {charges?.itemType?.isPROMO &&
                ((charges?.promo1EndDate !== '' &&
                  charges?.promo1EndDate?.length >= 1 &&
                  charges?.promo1EndDate?.length < 3) ||
                  (charges?.promo2EndDate !== '' &&
                    charges?.promo2EndDate?.length >= 1 &&
                    charges?.promo2EndDate?.length < 3) ||
                  (charges?.promo3EndDate !== '' &&
                    charges?.promo3EndDate?.length >= 1 &&
                    charges?.promo3EndDate?.length < 3)) && (
                  <>
                    <br />
                    {`(${charges?.promo1EndDate || charges?.promo2EndDate || charges?.promo3EndDate} MONTHS ON US)`}
                    <br />
                  </>
                )}
            </Title>
          )}
        </PaddLeft105Right21>
      </PreviewBillCol6>
      <PreviewBillCol3 style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
        {isAPODiscount && nxtMonthCharge !== '0.00' ? (
          <>
            <Body size='small' primitive='h4' strikethrough>
              {formatCurrency(charges?.nextMonthUndiscCharge)}
            </Body>
            <Title color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR} size='small' primitive='h4'>
              {nxtMonthCharge !== 0 ? formatCurrency(nxtMonthCharge) : formatCurrency(thisMonthCharge)}
            </Title>
          </>
        ) : (
          <>
            {isPROMO && !hasNextMonthPromoDiscount && (
              <Title color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR} size='small' primitive='h4'>
                -
              </Title>
            )}
            {!(isPROMO && !hasNextMonthPromoDiscount) && (
              <Title color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR} size='small' primitive='h4'>
                {nxtMonthCharge !== 0 ? formatCurrency(nxtMonthCharge) : formatCurrency(thisMonthCharge)}
              </Title>
            )}
          </>
        )}
      </PreviewBillCol3>
      <PreviewBillCol2 style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
        {isAPODiscount ? (
          <>
            <Body size='small' primitive='h4' strikethrough>
              {formatCurrency(charges?.thisMonthUndiscCharge)}
            </Body>
            <Title color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR} size='small' primitive='h4'>
              {formatCurrency(thisMonthCharge)}
            </Title>
          </>
        ) : (
          <Title color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR} size='small' primitive='h4'>
            {formatCurrency((!showNextMonthPrice || isPROMO) && !hasThisMonthPromoDiscount ? 0 : thisMonthCharge)}
          </Title>
        )}
      </PreviewBillCol2>
    </SubSubRow>
  );
};

SubLineCharges.propTypes = {
  charges: PropTypes.any,
  showNextMonthPrice: PropTypes.any,
  showApoDiscount: PropTypes.any,
  additionalInfo: PropTypes.any,
  financedAmount: PropTypes.any,
};

export default SubLineCharges;
