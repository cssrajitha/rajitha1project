import { render, screen, fireEvent } from '@testing-library/react';
import getNextBillSummaryNewCustomer from '../../../__mock__/getNextBillSummaryNewCustomer.json';
import retriveCartJson from '../../../__mock__/retrive-cart.json';
import StoreProvider from '../../../modules/store';
import AccountLevelAccordion from './AccountLevelAccordion';

const accountLevelMonthlyChargesVoMock = {
  accountLevelCharges: [
    {
      listPrice: '40.00',
      netPrice: '40.00',
      thisMonthCharge: '40.00',
      nextMonthCharge: '40.00',
      differenceBetweenThisMonthAndNextMonthCharge: '0.00',
      chargeEffectiveDate: '04/08/2024',
      chargeEndDate: '05/07/2024',
      itemType: {
        isPROMO: false,
        isPerk: false,
        isAddOn: false,
        isSPO: false,
        isSFO: false,
        isACCEQUIPMENT: false,
        isEQUIPMENT: false,
        isFEATURE: false,
        isNAF: false,
        isOCC: false,
        isPLAN: true,
      },
      chargeRefId: '92765',
      description: 'MORE EVERY UNL TLK&TXT 2GB',
      hasNextMonthPromoDiscount: false,
      hasThisMonthPromoDiscount: false,
      promo1Discount: '0.00',
      promo2Discount: '0.00',
      promo3Discount: '0.00',
      planCategoryCode: '52',
    },
    {
      listPrice: '12.00',
      netPrice: '12.00',
      thisMonthCharge: '12.00',
      nextMonthCharge: '12.00',
      differenceBetweenThisMonthAndNextMonthCharge: '0.00',
      chargeEffectiveDate: '04/08/2024',
      chargeEndDate: '05/07/2024',
      itemType: {
        isPROMO: false,
        isPerk: false,
        isAddOn: false,
        isSPO: true,
        isSFO: false,
        isACCEQUIPMENT: false,
        isEQUIPMENT: false,
        isFEATURE: false,
        isNAF: false,
        isOCC: false,
        isPLAN: false,
      },
      chargeRefId: '2492',
      description: 'PLAN RATE ADJUSTMENT MULTI',
      hasNextMonthPromoDiscount: false,
      hasThisMonthPromoDiscount: false,
    },
  ],
  accountLevelTotal: {
    newMonthCharge: '52.00',
    nextMonthCharge: '52.00',
  },
};

describe('Next Bill Summary Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  test('render initial Account Level Accordion Component-01', () => {
    render(
      <StoreProvider>
        <AccountLevelAccordion
          accountLvlData={getNextBillSummaryNewCustomer?.nbsVo?.accountLevelChargesVo}
          expandAll={false}
          cartInfo={retriveCartJson?.data?.cart}
        />
      </StoreProvider>,
    );
    const titleText = screen.getByTestId('charges-nickname-title');
    expect(titleText.textContent).toEqual('Account Charges');
    const nextMonthCharge = screen.getByTestId('nextmonth-charge-title-value');
    expect(nextMonthCharge.textContent).toEqual('$0.00');
    const newMonthCharge = screen.getByTestId('newmonth-charge-title-value');
    expect(newMonthCharge.textContent).toEqual('$0.00');
  });

  test('render initial Account Level Accordion Component-02', () => {
    render(
      <StoreProvider>
        <AccountLevelAccordion
          accountLvlData={getNextBillSummaryNewCustomer?.nbsVo?.accountLevelChargesVo}
          expandAll
          cartInfo={retriveCartJson?.data?.cart}
        />
      </StoreProvider>,
    );
    const titleText = screen.getByTestId('charges-nickname-title');
    expect(titleText.textContent).toEqual('Account Charges');
    const nextMonthCharge = screen.getByTestId('nextmonth-charge-title-value');
    expect(nextMonthCharge.textContent).toEqual('$0.00');
    const newMonthCharge = screen.getByTestId('newmonth-charge-title-value');
    expect(newMonthCharge.textContent).toEqual('$0.00');
  });

  test('Accordion Open Close functionality', () => {
    render(
      <StoreProvider>
        <AccountLevelAccordion
          accountLvlData={getNextBillSummaryNewCustomer?.nbsVo?.accountLevelChargesVo}
          expandAll={false}
          cartInfo={retriveCartJson?.data?.cart}
        />
      </StoreProvider>,
    );
    const chargesPlusTextBtn = screen.getByTestId('charges-plus');
    expect(chargesPlusTextBtn).toBeInTheDocument();
    fireEvent.click(chargesPlusTextBtn);
  });

  test('render Accordion Details Section', () => {
    const accountLevelChargesVo = { ...getNextBillSummaryNewCustomer?.nbsVo?.accountLevelChargesVo };
    const accountLevelChargesVoMock = {
      ...accountLevelChargesVo,
      accountLevelMonthlyChargesVo: {
        ...accountLevelChargesVo?.accountLevelMonthlyChargesVo,
        ...accountLevelMonthlyChargesVoMock,
      },
    };
    render(
      <StoreProvider>
        <AccountLevelAccordion
          accountLvlData={accountLevelChargesVoMock}
          expandAll={false}
          cartInfo={retriveCartJson?.data?.cart}
        />
      </StoreProvider>,
    );
    const titleText1 = screen.getByText('Monthly charges and credits');
    expect(titleText1).toBeInTheDocument();
  });

  test('isDark true', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] ,isDark: true, themeProps: {background: '#eeeeee'}};
    render(
      <StoreProvider>
        <AccountLevelAccordion
          accountLvlData={getNextBillSummaryNewCustomer?.nbsVo?.accountLevelChargesVo}
          expandAll={false}
          cartInfo={retriveCartJson?.data?.cart}
        />
      </StoreProvider>,
    );
    
  });
});
