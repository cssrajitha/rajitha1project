import React, { useState, useEffect } from 'react';
import { AccordionItem, AccordionHeader, AccordionDetail } from '@vds/accordions';
import { Title } from '@vds/typography';
import { Icon } from '@vds/icons';
import PropTypes from 'prop-types';
import {
  PosAbsolute,
  Row,
  ColWarapper,
  PreviewBillCol6,
  PreviewBillCol3,
  PreviewBillCol2,
  AccordionDetailWrapper,
} from './CommonStyles';
import { financedAmount, formatCurrency, formatMtnWithDecimals } from '../../../utils/common';
import MonthlyChargesVo from './MonthlyCharges';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR } from '../../constants/constants';

const AccountLevelAccordion = ({ expandAll, accountLvlData, cartInfo }) => {
  const { mtn, accountLevelMonthlyChargesVo, nextMonthChargeWithTaxes, newMonthChargeWithTaxes } = accountLvlData;
  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (expandAll === true) {
      setOpen(true);
    } else {
      setOpen(false);
    }
  }, [expandAll]);

  const toggleOpen = () => {
    setOpen(!open);
  };
  return (
    <AccordionItem opened={open} surface={isDark ? 'dark' : 'light'}>
      <AccordionHeader trigger={{ type: 'icon' }} onClick={toggleOpen} surface={isDark ? 'dark' : 'light'}>
        <ColWarapper data-testid='charges-accordion-header'>
          <Row>
            <PreviewBillCol6>
              <Title
                size='medium'
                bold
                primitive='h2'
                data-testid='charges-nickname-title'
                color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}
              >
                Account Charges
              </Title>
              <Title size='medium' primitive='h2' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                {formatMtnWithDecimals(mtn)}
              </Title>
            </PreviewBillCol6>
            <PreviewBillCol3>
              <Title
                size='small'
                bold
                primitive='h3'
                data-testid='nextmonth-charge-title-value'
                color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}
              >
                {formatCurrency(nextMonthChargeWithTaxes)}
              </Title>
            </PreviewBillCol3>
            <PreviewBillCol2>
              <Title
                size='small'
                primitive='h3'
                bold
                data-testid='newmonth-charge-title-value'
                color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}
              >
                {formatCurrency(newMonthChargeWithTaxes)}
              </Title>
            </PreviewBillCol2>
            <PosAbsolute onClick={toggleOpen} data-testid={open ? 'charges-minus' : 'charges-plus'}>
              <Icon name={open ? 'minus' : 'plus'} size='XLarge' color={isDark ? DARK_THEME_COLOR : ''} />
            </PosAbsolute>
          </Row>
        </ColWarapper>
      </AccordionHeader>
      <AccordionDetail>
        <AccordionDetailWrapper>
          {accountLevelMonthlyChargesVo?.accountLevelCharges && accountLevelMonthlyChargesVo?.accountLevelTotal && (
            <MonthlyChargesVo
              expandAll={expandAll}
              lineLevelMonthlyChargesVo={accountLevelMonthlyChargesVo?.accountLevelCharges}
              mtnLevelMonthlyChargesTotals={accountLevelMonthlyChargesVo?.accountLevelTotal}
              financedAmount={financedAmount(cartInfo, mtn)}
            />
          )}
        </AccordionDetailWrapper>
      </AccordionDetail>
    </AccordionItem>
  );
};

AccountLevelAccordion.propTypes = {
  accountLvlData: PropTypes.any,
  expandAll: PropTypes.bool,
  cartInfo: PropTypes.any,
};

export default AccountLevelAccordion;
