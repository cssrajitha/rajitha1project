export const getUpdateAFOPayload = (cartDetails, checked) => ({
  cartInfo: {
    cartCreator: cartDetails?.cartHeader?.cartCreator,
    processingMTN: cartDetails?.cartHeader?.cartCreator,
    processStep: 'VerizonVisaCardAFO',
    intendType: 'EUP',
    action: 'UPDATE',
  },
  offerAccepted: checked,
  disclosureAgreementSent: cartDetails?.orderDetails?.accessoryFinancingOfferInfo?.disclosureAgreementSent,
});
export const getVerizonVisaSendMessagePayload = (cartDetails, token) => ({
  clientId: token,
  event: 'pageNavigation',
  cluster: window.sessionStorage.getItem('vtCluster') || '',
  payload: {
    pageName: 'orderReview',
    mlmoPC: 'false',
    isNSA: 'Y',
    channel: cartDetails?.cart?.cartHeader?.cartCreatorChannelId,
    caseId: cartDetails?.cart?.cartHeader?.caseId,
    afoFlag: 'Y',
    vtflow: 'Y',
  },
});

export const getVerizonVisaSendMailPayload = (cartDetails, token, currDate) => ({
  data: {
    pageName: 'lovOrderReview',
    cluster: window.sessionStorage.getItem('vtCluster') || '',
    sms: 'N',
    inspicioToken: token,
    channel: cartDetails?.cart?.cartHeader?.cartCreatorChannelId,
    cartId: cartDetails?.cart?.cartHeader?.cartId,
    caseId: cartDetails?.cart?.cartHeader?.caseId,
    mvaUrl: '',
    ordInfo: {
      orderDate: currDate,
      firstName: cartDetails?.cart?.lineDetails?.lineInfo[0]?.itemsInfo[0]?.shipping?.firstName,
      emailAddress: cartDetails?.cart?.lineDetails?.lineInfo[0]?.itemsInfo[0]?.shipping?.email,
      mtn: '',
      acctNumber: cartDetails?.cart?.cartHeader?.fullAccountNumber,
      amount: '',
      flow: 'AFO',
      enableInspicioDirectCall: false,
    },
  },
  meta: {
    client: 'POSMOBILE',
    user: 'c0huska',
    clientCorrrelationId: cartDetails?.meta?.cxpCorrelationId,
    timestamp: cartDetails?.meta?.timestamp,
  },
});

export const getInspisioPayload = () => ({
  clientName: sessionStorage.getItem('channel') ?? '',
  lov: false,
  offsetMin: '50',
  delay: true,
});

export const getSendEmailAffirmPayload = (sendEmailObj) => ({
  meta: {
    client: 'POSMOBILE',
    user: 'c0huska',
    clientCorrrelationId: sendEmailObj?.cartDetails?.meta?.cxpCorrelationId,
    timestamp: sendEmailObj?.cartDetails?.meta?.timestamp,
  },
  data: {
    pageName: sendEmailObj?.cartDetails?.data?.cart?.lineDetails?.lineInfo[0]?.itemsInfo[0]?.isTradeInSelected
      ? 'd2dtradein'
      : 'affirmpayment',
    cluster: sendEmailObj?.clusterId,
    sms: sendEmailObj?.showEmailSection ? 'Y' : 'N',
    inspicioToken: btoa(sendEmailObj.token),
    channel: sendEmailObj?.cartDetails?.data?.cart?.cartHeader?.cartCreatorChannelId,
    cartId: sendEmailObj?.cartDetails?.data?.cart?.cartHeader?.cartId,
    caseId: sendEmailObj?.cartDetails?.data?.cart?.cartHeader?.caseId,
    xbox: sendEmailObj?.xbox,
    mvaUrl: '',
    ordInfo: {
      orderDate: sendEmailObj.currDate,
      firstName: sendEmailObj?.cartDetails?.data?.cart?.lineDetails?.lineInfo[0]?.itemsInfo[0]?.shipping?.firstName,
      emailAddress: sendEmailObj?.showEmailSection ? sendEmailObj?.emailValue : '',
      mtn: !sendEmailObj?.showEmailSection ? sendEmailObj?.selectedMDN : '',
      acctNumber: sendEmailObj?.cartDetails?.data?.cart?.cartHeader?.fullAccountNumber,
      amount: '',
      flow: '',
      enableInspicioDirectCall: false,
    },
  },
});

export const getSendMessageAffirmPayload = (cartDetails, token) => {
  const lineInfo = cartDetails?.lineDetails?.lineInfo?.[0];
  const primaryUserInfo = lineInfo?.serviceInfo?.primaryUserInfo;
  const address = primaryUserInfo?.address;
  const billingAddress = cartDetails?.customerProfile?.billAccounts?.[0]?.accountAddress;
  const cartItem = lineInfo?.itemsInfo?.[0]?.cartItems?.cartItem?.[0];
  const affirmBillAmount = cartDetails?.orderDetails?.affirmFinancingOfferInfo;
  return {
    clientId: token,
    event: 'pageNavigation',
    cluster: window.sessionStorage.getItem('vtCluster') || '',
    payload: {
      first: primaryUserInfo?.firstName,
      last: primaryUserInfo?.lastName,
      shipping: {
        first: address?.firstName,
        last: address?.lastName,
        address: {
          line1: address?.addressLine1,
          line2: address?.addressLine2,
          city: address?.city,
          state: address?.state,
          zipcode: address?.zipCode,
        },
        email: address?.emailId,
        phone_number: address?.phoneNumber,
      },
      billing: {
        first: primaryUserInfo?.firstName,
        last: primaryUserInfo?.lastName,
        address: {
          line1: billingAddress?.addressLine1,
          line2: billingAddress?.addressLine2,
          city: billingAddress?.city,
          state: billingAddress?.state,
          streetNumber: billingAddress?.scrubbedAddress?.streetNumber,
          streetName: billingAddress?.scrubbedAddress?.streetName,
          streetType: billingAddress?.scrubbedAddress?.streetType,
          streetDirection: billingAddress?.scrubbedAddress?.streetDirection,
          apartmentNo: billingAddress?.scrubbedAddress?.apartmentNo,
          zipCode: billingAddress?.zipCode,
        },
        email: address?.emailId,
        phone_number: address?.phoneNumber,
      },
      email: address?.emailId,
      phone_number: address?.phoneNumber,
      items: [
        {
          display_name: cartItem?.deviceDisplayName,
          sku: cartItem?.sorId,
          unit_price: cartItem?.unitTaxBasedPrice,
          qty: cartItem?.qty,
          item_image_url: cartItem?.imageUrlMap?.defaultImage,
        },
      ],
      amount: {
        discount_amount: cartItem?.discountAmount,
        tax_amount: Math.round(Number(affirmBillAmount?.totalAffirmAccessoryTaxAmount) * 100),
        shipping_amount: Math.round(Number(affirmBillAmount?.shippingAmount) * 100),
        total: Math.round(Number(affirmBillAmount?.totalAffirmAccessoryAmount) * 100),
      },
    },
  };
};
