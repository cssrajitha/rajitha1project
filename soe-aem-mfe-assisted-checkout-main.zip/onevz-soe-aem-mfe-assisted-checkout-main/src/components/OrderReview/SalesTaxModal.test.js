import { render, screen, fireEvent } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { has } from 'lodash';
import StoreProvider from '../../modules/store';
import cartJson from '../../__mock__/retrive-cart.json';
import SalesTaxModal from './SalesTaxModal';

const getSalesTax = (lines) => {
  const taxDetail = [];
  lines.forEach((line) => {
    const mobileNumber = line.mobileNumber ? line.mobileNumber : '';
    let tax =
      has(line, 'itemsInfo') &&
      line.itemsInfo.map((item) => {
        const salesTax =
          has(item, 'cartItems.cartItem') &&
          item.cartItems.cartItem.map((cartItem) => (has(cartItem, 'taxDetailsList') ? cartItem : []));
        return salesTax.reduce((a, b) => a.concat(b), []);
      });
    tax = tax.reduce((a, b) => a.concat(b), []);
    let subTotal = 0;
    tax.forEach((currTax) => {
      subTotal += parseFloat(currTax.taxAmount ? currTax.taxAmount : 0);
      return subTotal;
    });
    const data = {
      mobileNumber,
      taxDetails: tax,
      subTotal,
    };
    taxDetail.push(data);
  });
  return taxDetail;
};

describe('salesTaxModal Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  test('renders Sales Tax Modal', () => {
    const salesTax = getSalesTax(cartJson.data.cart.lineDetails.lineInfo);
    render(
      <BrowserRouter>
        <StoreProvider>
          <SalesTaxModal
            opened
            closeModal={() => {}}
            salesTax={salesTax}
            orderDetails={cartJson.data.cart.orderDetails}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByTestId('salesTaxModal');
    expect(titleElement).toBeInTheDocument();
  });

  test('renders Sales Tax Modal - aactivation fee', () => {
    const salesTax = getSalesTax(cartJson.data.cart.lineDetails.lineInfo);
    salesTax[0].taxDetails[0].cartItemType = 'ACTIVATION_FEE';
    render(
      <BrowserRouter>
        <StoreProvider>
          <SalesTaxModal
            opened
            closeModal={() => {}}
            salesTax={salesTax}
            orderDetails={cartJson.data.cart.orderDetails}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByTestId('salesTaxModal');
    expect(titleElement).toBeInTheDocument();
  });

  test('renders Sales Tax Modal - shipping fee', () => {
    const mockClose = jest.fn();
    const salesTax = getSalesTax(cartJson.data.cart.lineDetails.lineInfo);
    salesTax[0].taxDetails[0].cartItemType = 'SHIPPING';
    render(
      <BrowserRouter>
        <StoreProvider>
          <SalesTaxModal
            opened
            closeModal={mockClose}
            salesTax={salesTax}
            orderDetails={cartJson.data.cart.orderDetails}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const titleElement = screen.getByTestId('salesTaxModal');
    expect(titleElement).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('modal-close-button'), {});
    expect(window.vzdl.page.detail).toEqual('');
  });

  test('isDark true', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] ,isDark: true, themeProps: {background: '#eeeeee'}};
    const salesTax = getSalesTax(cartJson.data.cart.lineDetails.lineInfo);
    render(
      <BrowserRouter>
        <StoreProvider>
          <SalesTaxModal
            opened
            closeModal={() => {}}
            salesTax={salesTax}
            orderDetails={cartJson.data.cart.orderDetails}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByTestId('salesTaxModal');
    expect(titleElement).toBeInTheDocument();
  });

  test('isDark false', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] ,isDark: false, themeProps: {background: '#eeeeee'}};
    const salesTax = getSalesTax(cartJson.data.cart.lineDetails.lineInfo);
    render(
      <BrowserRouter>
        <StoreProvider>
          <SalesTaxModal
            opened
            closeModal={() => {}}
            salesTax={salesTax}
            orderDetails={cartJson.data.cart.orderDetails}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByTestId('salesTaxModal');
    expect(titleElement).toBeInTheDocument();
  });
});
