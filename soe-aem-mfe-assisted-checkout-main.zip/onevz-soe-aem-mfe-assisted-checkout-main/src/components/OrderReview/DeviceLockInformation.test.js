import React from 'react';

import { render, screen, fireEvent } from '@testing-library/react';

import DeviceLockInformation from './DeviceLockInformation';

describe('DeviceLock Component', () => {
  it('renders DeviceLock component', () => {
    render(<DeviceLockInformation />);
    const title = screen.getByText('Important device lock Information');
    expect(title).toBeInTheDocument();
  });
  it('button click', async () => {
    const goBackFn = jest.fn();
    render(<DeviceLockInformation closeDeviceInformation={goBackFn} />);
    const button = await screen.findByTestId('btn-back');
    fireEvent.click(button);
    expect(goBackFn).toHaveBeenCalledTimes(1);
  });
});
