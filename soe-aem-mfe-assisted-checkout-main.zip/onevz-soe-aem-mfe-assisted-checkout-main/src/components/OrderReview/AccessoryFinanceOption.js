import { Accordion, AccordionDetail, AccordionHeader, AccordionItem } from '@vds/accordions';
import React, { useEffect, useState } from 'react';
import { Icon } from '@vds/icons';
import styled, { createGlobalStyle } from 'styled-components';
import { DropdownSelect } from '@vds/selects';
import { Button } from '@vds/buttons';
import PropTypes from 'prop-types';
import { Col6, ColWarapper, PosAbsolute, Row } from './NextBillSummary/CommonStyles';
import ViewTogetherApiCallHook from '../../modules/services/APIService/ViewTogetherApiCallHook';
import {
  getInspisioPayload,
  getVerizonVisaSendMailPayload,
  getVerizonVisaSendMessagePayload,
} from './AccessoryAndAffirmRequest';
import { requestBodyRetriveCart } from '../../modules/services/APIService/APIRequestBody';
import { AccessoryFinanceConstants } from '../../appconfig';
import { DARK_THEME_COLOR } from '../constants/constants';

const ComponentStyle = createGlobalStyle`
    #previewBillModel {
        [class^='TriggerIconWrapper-VDS']{
            display: none;
        }
        [class^='InnerElementWrapper-VDS']{
            padding: 0px !important;
        }
        [class^='StyledButton-VDS'] {
            padding: 0 20px;
            font-size: 14px;
        }
    }
`;

const DropDowmWrapper = styled.div`
  margin: 0 10px;
  [class^='StyledTypography-VDS'] {
    font-size: 16px;
    font-family: BrandFontRegular, Arial, sans-serif;
  }
  [class^='SelectEl-VDS'] {
    font-size: 14px;
    font-family: BrandFontRegular, sans-serif;
  }
`;

const ButtonWrapper = styled.div`
  margin-top: 20px;
  gap: 10px;
  display: flex;
  [class^='StyledChildWrapper-VDS'] {
    font-size: 16px;
    font-family: BrandFont-Text, Helvetica, Arial, sans-serif;
    padding: 10px 30px;
  }
`;

const HorizontalLine = styled.div`
  border: none;
  border-top: 1px solid rgba(0, 0, 0, 0.3);
  margin: 10px 0;
`;

const AccordianTitle = styled.div`
  font-size: 20px;
  font-family: BrandFont-Text, Helvetica, Arial, sans-serif;
  font-weight: 700;
`;

const AccordianSubtext = styled.div`
  font-size: 18px;
  font-family: BrandFont-Text, Arial, sans-serif;
  margin-bottom: 15px;
  line-height: 1.5rem;
`;

const SuccessWrapper = styled.span`
  display: flex;
  gap: 10px;
  align-items: flex-end;
`;

const AccessoryFinanceOption = ({
  cartDetailsResult,
  getCartDetailsDataBody,
  setVerizonVisaCardLinkSent,
  showRepGuidedScreen,
  customerMtns,
  setShowRepGuidedScreen,
}) => {
  const {
    requestBodyGenerateInspicioId,
    getResultGenerateInspicioId,
    requestBodySendMessage,
    getResultSendMessage,
    requestBodySendEmail,
    getResultSendEmail,
  } = ViewTogetherApiCallHook();
  const [open, setOpen] = useState(showRepGuidedScreen);
  const [selectedMDN, setSelectedMDN] = useState(customerMtns[0]);
  const [isDisabled, setIsDisabled] = useState(true);
  const [sendInspicioData, setSendInspicioData] = useState(null);
  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;
  useEffect(() => {
    if (getResultGenerateInspicioId?.data && getResultSendMessage?.data && getResultSendEmail?.data) {
      setIsDisabled(false);
      setVerizonVisaCardLinkSent(true);
    }
  }, [getResultGenerateInspicioId, getResultSendMessage, getResultSendEmail]);

  const handleContinue = () => {
    setShowRepGuidedScreen(false);
    getCartDetailsDataBody({ body: requestBodyRetriveCart, spinner: true, mock: false });
  };

  const callInspicioGenerateBtn = async () => {
    const inspicioData = await callInspicioApi();
    const token = inspicioData?.sendInspicioToken;
    const sendMessagePayload = getVerizonVisaSendMessagePayload(cartDetailsResult, token);
    await requestBodySendMessage({ body: { ...sendMessagePayload }, spinner: false, mock: false });

    const currentDate = new Date();
    const dd = currentDate.getDate() < 10 ? `0${currentDate.getDate()}` : currentDate.getDate();
    const mm = currentDate.getMonth() + 1 < 10 ? `0${currentDate.getMonth()}${1}` : currentDate.getMonth() + 1;
    const yyyy = currentDate.getFullYear();
    const currDate = `${mm}/${dd}/${yyyy}`;
    const sendMailPayload = getVerizonVisaSendMailPayload(cartDetailsResult, token, currDate);
    await requestBodySendEmail({ body: { ...sendMailPayload }, spinner: false, mock: false });
  };

  const callInspicioApi = async () => {
    if (!sendInspicioData) {
      const inspicioPayload = getInspisioPayload();
      const response = await requestBodyGenerateInspicioId({
        body: { ...inspicioPayload },
        spinner: false,
        mock: false,
      });
      const data = response?.data;
      setSendInspicioData(data);
      return data;
    }
    return sendInspicioData;
  };

  return (
    <div>
      <ComponentStyle />
      <Accordion
        data-testId='previewBillModel'
        id='previewBillModel'
        topLine
        bottomLine={false}
        surface={isDark ? 'dark' : 'light'}
      >
        <AccordionItem opened={open}>
          <AccordionHeader trigger={{ type: 'icon' }} onClick={() => setOpen(!open)}>
            <ColWarapper data-testid='charges-accordion-header'>
              <Row>
                <Col6>
                  <AccordianTitle size='small' bold data-testid='accordion-title'>
                    {AccessoryFinanceConstants.accordianTitle}
                  </AccordianTitle>
                </Col6>
                <Col6>
                  {!isDisabled && (
                    <SuccessWrapper>
                      <Icon name='checkmark-alt' size='medium' color='green' surface={isDark ? 'dark' : 'light'} />
                      <div>{AccessoryFinanceConstants.linkSentText}</div>
                    </SuccessWrapper>
                  )}
                </Col6>
                <PosAbsolute onClick={() => setOpen(!open)} data-testid={open ? 'charges-minus' : 'charges-plus'}>
                  <Icon name={open ? 'minus' : 'plus'} size='small' color={isDark ? DARK_THEME_COLOR : ''} />
                </PosAbsolute>
              </Row>
              {open && <HorizontalLine />}
            </ColWarapper>
          </AccordionHeader>
          <AccordionDetail>
            <div>
              <AccordianSubtext>{AccessoryFinanceConstants.accordionSubText}</AccordianSubtext>
              <DropDowmWrapper>
                <DropdownSelect
                  label='Select MDN'
                  errorText='Select a state'
                  width='20%'
                  id='select-mdn'
                  data-testid='reason-dropdown'
                  className='reason-dd'
                  value={selectedMDN}
                  onChange={(e) => setSelectedMDN(e.target.value)}
                  surface={isDark ? 'dark' : 'light'}
                >
                  {customerMtns.map((item) => (
                    <option key={item}>{item}</option>
                  ))}
                </DropdownSelect>
              </DropDowmWrapper>
              <ButtonWrapper>
                <Button
                  surface={isDark ? 'dark' : 'light'}
                  className='button'
                  use={isDisabled ? 'primary' : 'secondary'}
                  onClick={callInspicioGenerateBtn}
                >
                  {isDisabled ? AccessoryFinanceConstants.sendLabel : AccessoryFinanceConstants.resendLabel}
                </Button>
                <Button use='primary' onClick={handleContinue} disabled={isDisabled}>
                  {AccessoryFinanceConstants.continueLable}
                </Button>
              </ButtonWrapper>
            </div>
          </AccordionDetail>
        </AccordionItem>
      </Accordion>
    </div>
  );
};

AccessoryFinanceOption.propTypes = {
  showRepGuidedScreen: PropTypes.bool,
  customerMtns: PropTypes.array,
  setShowRepGuidedScreen: PropTypes.func,
  cartDetailsResult: PropTypes.array,
  getCartDetailsDataBody: PropTypes.func,
  setVerizonVisaCardLinkSent: PropTypes.func,
};

export default AccessoryFinanceOption;
