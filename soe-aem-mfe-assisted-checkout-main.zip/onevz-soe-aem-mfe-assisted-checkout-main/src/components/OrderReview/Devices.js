import styled from 'styled-components';
import { TileContainer } from '@vds/tiles';
import { Body } from '@vds/typography';
import { TextLink } from '@vds/buttons';
import PropTypes from 'prop-types';
import { has } from 'lodash';
import { StyledPaddingLeft8 } from '../../StyledConstants';
import { formatCurrency } from '../../utils/common';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR } from '../constants/constants';

const EmptyWrapper = styled.div`
  min-height: 140px;
`;

const TileWrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  padding: 0px 14px;
`;
const PriceWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 0.25rem;
  padding: ${(props) => (props.bottomBorder ? '4px 0px' : '0px')};
  border-bottom: ${(props) => (props.bottomBorder ? '1px solid #ccc' : '')};
  margin-bottom: ${(props) => (props.bottomBorder ? '8px' : '')};

  p {
    font-family: BrandFont-Text, Helvetica, Arial, sans-serif;
    font-size: 18px;
    line-height: normal;
  }
`;

const Title = styled.div`
  font-size: 20px;
  font-weight: 700;
  line-height: 1.25rem;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  letter-spacing: 0.03125rem;
  margin: 0px;
  text-decoration: none;
  width: 178px;
`;

const LinkWrapper = styled.div`
  text-align: left;
  padding-bottom: 1rem;
  margin-top: 2rem;
`;

const TileContainerWrapper = styled.div`
  [class^='OuterTileContainer'] {
    border-radius: 0px !important;
    height: 100%;
  }
`;

const Devices = ({ line, element, handleViewDevices, monthlyInstallmentAmount, planDetail, lineAccessFee = 0, hasExchangeDeviceInLine, lineActivityTypeData, isLineAccessCharge }) => {
  const financedAmount =
    (parseFloat(element?.discountedPrice) || parseFloat(element?.sellerPrice) || parseFloat(element?.itemPrice)) -
    (parseFloat(line?.installmentInfo?.downPayment) || 0);
  const firstInstallment = has(line, 'installmentInfo.firstInstallment')
    ? formatCurrency(line.installmentInfo.firstInstallment)
    : formatCurrency(0);
  const isJaxPlan = planDetail?.isJaxPlan || '';
  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;
  const bgColor = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.themeProps?.background;
  const isDFO = element?.isDfoSelected && element?.eMIVerizonPayment;
  return (
    <TileContainerWrapper data-testId='devices'>
      <TileContainer padding='1.5rem 0 0 0' height='auto' width='384px' surface={isDark ? 'dark' : 'light'}>
        <TileWrapper>
          <PriceWrapper bottomBorder>
            <Title
              style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR, backgroundColor: isDark ? bgColor : '' }}
            >
              Device
            </Title>
          </PriceWrapper>

          {has(line, 'installmentInfo') ? (
            <>
              <PriceWrapper
                style={{
                  color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                  backgroundColor: isDark ? bgColor : '',
                }}
              >
                <Body size='medium' color={isDark ? DARK_THEME_COLOR : ''}>
                  Device Payment
                </Body>
                <StyledPaddingLeft8>
                  <Body size='medium' color={isDark ? DARK_THEME_COLOR : ''}>
                    {formatCurrency(monthlyInstallmentAmount)}
                  </Body>
                </StyledPaddingLeft8>
              </PriceWrapper>

              <PriceWrapper
                style={{
                  color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                  backgroundColor: isDark ? bgColor : '',
                }}
              >
                <Body size='medium' color={isDark ? DARK_THEME_COLOR : ''}>
                  {`${financedAmount ? formatCurrency(financedAmount) : '-'}` +
                    ' / ' +
                    `${has(line, 'installmentInfo.installmentTerm') ? line.installmentInfo.installmentTerm : '-'}` +
                    ' months'}
                </Body>
                <StyledPaddingLeft8>
                  <Body size='medium' color={isDark ? DARK_THEME_COLOR : ''}>
                    {' '}
                  </Body>
                </StyledPaddingLeft8>
              </PriceWrapper>

              <PriceWrapper
                style={{
                  color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                  backgroundColor: isDark ? bgColor : '',
                }}
              >
                <Body size='medium' color={isDark ? DARK_THEME_COLOR : ''}>
                  1st Device Payment
                </Body>
                <StyledPaddingLeft8>
                  <Body size='medium' color={isDark ? DARK_THEME_COLOR : ''}>
                    {firstInstallment}
                  </Body>
                </StyledPaddingLeft8>
              </PriceWrapper>

              {!isJaxPlan && ((hasExchangeDeviceInLine && lineActivityTypeData && lineAccessFee) || isLineAccessCharge) ? (
                <PriceWrapper
                  style={{
                    color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                    backgroundColor: isDark ? bgColor : '',
                  }}
                >
                  <Body size='medium' color={isDark ? DARK_THEME_COLOR : ''}>
                    Line access
                  </Body>
                  <StyledPaddingLeft8>
                    <Body size='medium' color={isDark ? DARK_THEME_COLOR : ''}>
                      {formatCurrency(lineAccessFee)}
                    </Body>
                  </StyledPaddingLeft8>
                </PriceWrapper>
              ) : null}
            </>
          ) : (
            <EmptyWrapper
              data-testId='empty-wrapper'
              style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR, backgroundColor: isDark ? bgColor : '' }}
            />
          )}

          {!isDFO && (
            <LinkWrapper
              style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR, backgroundColor: isDark ? bgColor : '' }}
            >
              <TextLink
                type='standAlone'
                data-testId='view-devices'
                surface={isDark ? 'dark' : 'light'}
                disabled={false}
                size='small'
                onClick={() => {
                  handleViewDevices();
                }}
              >
                {' '}
                View
              </TextLink>
            </LinkWrapper>
          )}
        </TileWrapper>
      </TileContainer>
    </TileContainerWrapper>
  );
};

Devices.propTypes = {
  line: PropTypes.object,
  element: PropTypes.object,
  handleViewDevices: PropTypes.func,
  monthlyInstallmentAmount: PropTypes.any,
  planDetail: PropTypes.object,
  lineAccessFee: PropTypes.number,
  hasExchangeDeviceInLine: PropTypes.any,
  lineActivityTypeData: PropTypes.any,
  isLineAccessCharge: PropTypes.any,
};

export default Devices;
