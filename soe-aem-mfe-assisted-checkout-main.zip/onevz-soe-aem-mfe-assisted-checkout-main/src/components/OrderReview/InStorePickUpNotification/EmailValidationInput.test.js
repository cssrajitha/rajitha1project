import { setupServer } from 'msw/node';
import { rest } from 'msw';
import { fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import EmailValidationInput from './EmailValidationInput';
import StoreProvider from '../../../modules/store/index';

const validationProps = {
  name: 'emailAddress1',
  data: { email: 'VQNROOVI70@VZW.COM' },
  handleEmailValue: jest.fn(),
  customerInfo: { lookupMtn: '5866349095', customerId: '0286120415-00001' },
};

const server = setupServer(
  rest.post('*/emailValidate', (req, res, ctx) => {
    const { emailAddress } = req.body;
    switch (emailAddress) {
      case 'test@vzw.com':
        return res(ctx.json({ emailAddress, validationStatus: 'Valid' }));
      case 'manual@vzw.com':
        return res(ctx.json({ emailAddress, validationStatus: 'Manual_validation' }));
      case 'null@vzw.com':
        return res(ctx.json({ emailAddress, validationStatus: 'Manual_validation' }));
      default:
        return res(ctx.json({ emailAddress, validationStatus: 'Invalid' }));
    }
  }),
  rest.post('*/verifyEmail', (req, res, ctx) => {
    const { email } = req.body;
    switch (email) {
      case 'null@vzw.com':
        return res(ctx.json({ error: 'Some error message' }));
      default:
        return res(ctx.json({ data: { statusDescription: 'Request has been successfully submitted.' }, error: null }));
    }
  }),
);

describe('EmailValidationInput Component', () => {
  beforeEach(() => {
    render(
      <StoreProvider>
        <EmailValidationInput {...validationProps} />
      </StoreProvider>,
    );
  });
  beforeAll(() => server.listen());
  afterEach(() => server.resetHandlers());

  test('renders EmailValidationInput component', () => {
    const title = screen.getByText('Email Address');
    expect(title).toBeInTheDocument();
  });

  test('input field should show', async () => {
    const email = 'VQNROOVI70@VZW.COM';
    const emailValidationInput = screen.getByTestId('EmailValidationInput');
    const emailInput = within(emailValidationInput).getByRole('textbox');
    fireEvent.change(emailInput, { target: { value: '' } });
    fireEvent.change(emailInput, { target: { value: email } });
    expect(emailInput).toHaveValue(email);
  });

  test('show error message on blur for empty email pattern', async () => {
    const emailValidationInput = screen.getByTestId('EmailValidationInput');
    const emailInput = within(emailValidationInput).getByRole('textbox');
    fireEvent.change(emailInput, { target: { value: '' } });
    fireEvent.blur(emailInput);
    const errorMsg = await screen.findByText('Please enter a valid email address');
    expect(errorMsg).toBeInTheDocument();
  });

  test('show error message on blur for invalid email pattern', async () => {
    const emailValidationInput = screen.getByTestId('EmailValidationInput');
    const emailInput = within(emailValidationInput).getByRole('textbox');
    fireEvent.change(emailInput, { target: { value: 'invalid@vzw' } });
    fireEvent.blur(emailInput);
    const errorMsg = await screen.findByText('Please enter a valid email address');
    expect(errorMsg).toBeInTheDocument();
  });

  test('show error message on blur for invalid email input field', async () => {
    const emailValidationInput = screen.getByTestId('EmailValidationInput');
    const emailInput = within(emailValidationInput).getByRole('textbox');
    fireEvent.change(emailInput, { target: { value: 'invalid@vzw.com' } });
    fireEvent.blur(emailInput);
  });

  test('does not show error message on blur for valid email', async () => {
    const emailValidationInput = screen.getByTestId('EmailValidationInput');
    const emailInput = within(emailValidationInput).getByRole('textbox');
    fireEvent.change(emailInput, { target: { value: 'test@vzw.com' } });
    fireEvent.blur(emailInput);
    await waitFor(() => {
      expect(screen.queryByText('Please enter a valid email address')).not.toBeInTheDocument();
    });
  });

  test('Show notification when verifyEmail API gives statusDescription', async () => {
    const emailValidationInput = screen.getByTestId('EmailValidationInput');
    const emailInput = within(emailValidationInput).getByRole('textbox');
    fireEvent.change(emailInput, { target: { value: 'manual@vzw.com' } });
    fireEvent.blur(emailInput);
    const clickHereLink = await screen.findByRole('link', { name: 'click here' });
    fireEvent.click(clickHereLink);
    const ConfirmButton = await screen.findByRole('button', { name: 'Confirm' });
    fireEvent.click(ConfirmButton);
  });

  test('Show notification if verifyEmail Api gives error', async () => {
    const emailValidationInput = screen.getByTestId('EmailValidationInput');
    const emailInput = within(emailValidationInput).getByRole('textbox');
    fireEvent.change(emailInput, { target: { value: 'null@vzw.com' } });
    fireEvent.blur(emailInput);
    const clickHereLink = await screen.findByRole('link', { name: 'click here' });
    fireEvent.click(clickHereLink);
    const ClickButton = await screen.findByRole('button', {
      name: /click here/i,
    });
    expect(ClickButton).toBeInTheDocument();
    fireEvent.click(ClickButton);
  });
});
