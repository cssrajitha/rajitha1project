import { fireEvent, render, screen, within } from '@testing-library/react';
import DomService from 'onevzsoemfeframework/DomService';
import StoreProvider from '../../../modules/store/index';
import cartJson from '../../../__mock__/retriveCart.json';
import customerJson from '../../../__mock__/retrieve-customer.json';
import mockGetAllActiveMtnResult from '../../../__mock__/getAllActiveMtns.json';
import InStorePickUpNotification from './InStorePickUpNotification';
import * as InfoApiCallHook from '../../../modules/services/APIService/InfoAPICallHook';

jest.mock('onevzsoemfeframework/DomService', () => ({
  getQueryParamByName: () => 'Y',
}));

describe('InStorePickUpNotification Component', () => {
  sessionStorage.setItem('viewTogetherEnabled', true);
  sessionStorage.setItem('isLovEligibleFromSessionStorage', true);

  const mockValue = jest.fn();

  const mockData = {
    getActiveMTNRequest: mockValue,
    getActiveMTNResponse: { data: mockGetAllActiveMtnResult },
  };

  const props = {
    isLovEnabled: true,
    selectedMode: '',
    selectedReason: '',
  };

  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  test('renders InStorePickUpNotification component', () => {
    sessionStorage.setItem('customerType', 'N');
    sessionStorage.setItem('channel', 'OMNI-INDIRECT');
    sessionStorage.setItem('viewTogetherEnabled', true);
    const getQueryParamByNameMock = jest.spyOn(DomService, 'getQueryParamByName').mockImplementation(() => 'N');
    render(
      <StoreProvider>
        <InStorePickUpNotification {...props} cart={cartJson.data.cart} customerProfile={customerJson?.data} />
      </StoreProvider>,
    );
    const title = screen.getByText('In Store-Pick Up Notification');
    expect(title).toBeInTheDocument();
    getQueryParamByNameMock.mockRestore();
  });

  test('input field should show', async () => {
    render(
      <StoreProvider>
        <InStorePickUpNotification {...props} cart={cartJson.data.cart} customerProfile={customerJson?.data} />
      </StoreProvider>,
    );
    const email = 'VQNROOVI70@VZW.COM';
    const emailValidationInput = screen.getByTestId('EmailValidationInput');
    const emailInput = within(emailValidationInput).getByRole('textbox');
    fireEvent.change(emailInput, { target: { value: '' } });
    fireEvent.change(emailInput, { target: { value: email } });
    expect(emailInput).toHaveValue(email);
  });

  test('render inspicioCheckbox', async () => {
    sessionStorage.setItem('customerType', 'N');
    sessionStorage.setItem('newPostToPreIndicator', 'true');
    sessionStorage.setItem('viewTogetherEnabled', true);
    const getQueryParamByNameMock = jest.spyOn(DomService, 'getQueryParamByName').mockImplementation(() => 'N');
    sessionStorage.setItem('channel', 'OMNI-TELESALES');
    sessionStorage.setItem('path', 'order-review');
    const newProps = { ...props, selectedMode: 'VT', selectedReason: 'test' };
    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => mockData);

    render(
      <StoreProvider>
        <InStorePickUpNotification {...newProps} cart={cartJson.data.cart} />
      </StoreProvider>,
    );

    const inspicioCheckbox = screen.getByRole('checkbox');
    expect(inspicioCheckbox).toBeInTheDocument();
    getQueryParamByNameMock.mockRestore();
  });
});
