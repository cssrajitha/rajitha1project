import { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import moment from 'moment';
import { Title, Body } from '@vds/typography';
import { Checkbox } from '@vds/checkboxes';
import { Icon } from '@vds/icons';
import { DropdownSelect } from '@vds/selects';
import PickupDetailsAPICallHook from '../../../modules/services/APIService/PickupDetailsAPICallHook';

const PickupTitle = styled.div`
  padding: 0.875rem 0 !important;
`;

const AddressContainer = styled.div`
  display: flex;
  flex-flow: row wrap;
  padding: 0;
`;

const AddressLine = styled.div`
  width: 100%;
  padding-bottom: 0.4375rem !important;
`;

const DropdownWrapper = styled.div`
  margin-top: 0.5rem;
`;

const DropdownValueActionText = styled.div`
  margin-top: 0.5rem;
`;

const CheckboxWrapper = styled.div`
  span {
    display: flex;
    align-items: center;
  }
  margin-top: 0.5rem;
  [class^='CheckboxWrapper-VDS'] {
    margin-left: ${(props) => (props.marginLeft ? '0.5rem' : '0')};
  }
  label p {
    font-weight: 500;
    font-size: 0.875rem;
  }
  margin-bottom: 0.5rem;
`;

const PickupDetails = (props) => {
  const { getStoreInfo, storeInfoResult } = PickupDetailsAPICallHook();
  const { cart, customerType, customerProfile } = props;
  const [displayIspuDetail, setDisplayIspuDetail] = useState('');

  const fiveGHomeQualified = customerProfile?.fiveGHomeQualified;
  const lineInfo = cart?.lineDetails?.lineInfo || [];
  const lineDetails = lineInfo?.find(
    (line) => (line?.lineActivityType === 'AAL_5G' || line?.lineActivityType === 'NSE_5G') && fiveGHomeQualified,
  );
  const is5GDevice =
    (lineDetails?.lineActivityType === 'AAL_5G' || lineDetails?.lineActivityType === 'NSE_5G') && fiveGHomeQualified;

  useEffect(() => {
    checkISPUFlow();
  }, []);

  useEffect(() => {
    if (storeInfoResult?.data?.data?.ispuStores) {
      const ispuDetails = getIspuDetails(storeInfoResult?.data?.data?.ispuStores);
      if (ispuDetails) {
        setDisplayIspuDetail(ispuDetails);
      }
    }
  }, [storeInfoResult?.data]);

  const checkISPUFlow = () => {
    const storeLocationCode = [];
    lineInfo?.forEach((item) => {
      item?.itemsInfo?.forEach((item1) => {
        const ispuDetails = item1?.shipping?.storeinfo || {};
        if (ispuDetails?.netaceLocationCode) {
          storeLocationCode.push(ispuDetails?.netaceLocationCode);
        }
      });
    });
    if (storeLocationCode && storeLocationCode?.length > 0) {
      const request = {
        meta: {
          clientCorrrelationId: '',
          timestamp: '2019-07-29T10:25:59.791-04:00',
        },
        data: {
          locationCodeList: storeLocationCode,
          ...(customerType && customerType === 'N' ? { customerType } : {}),
          locationCode: '',
        },
      };
      getStoreInfo({ body: request });
    }
  };

  const pickupLabel = (serviceType) => {
    switch (serviceType) {
      case 'CURBSIDE':
        return 'Curbside pickup';
      case 'INSTORE':
        return 'Instore pickup';
      case 'LIMITEDCURB':
        return 'Limited Curbside pickup';
      case 'LOCKER':
      case 'LOCKER24':
        return 'Express locker pickup';
      case 'DS':
        return 'Door Side pickup';
      default:
        return '';
    }
  };

  const onChangeService = (e, netLocationCode) => {
    const ispuDetailsArr = [];
    if (displayIspuDetail && displayIspuDetail?.length > 0) {
      displayIspuDetail?.forEach((item) => {
        if (item?.netaceLocationCode?.toString() === netLocationCode?.toString()) {
          ispuDetailsArr.push({
            ...item,
            checked: e.target.value !== 'INSTORE' && item?.checked ? false : item.checked,
            ispuServiceSelectionValue: e.target.value,
          });
        } else {
          ispuDetailsArr.push(item);
        }
      });
      setDisplayIspuDetail(ispuDetailsArr);
    }
  };

  const getDropdownContent = (ispuInfo) => {
    let dropdownValues = [];
    const channel = sessionStorage.getItem('channel');
    const index = displayIspuDetail?.findIndex((x) => x?.mtnNumber === ispuInfo?.mtnNumber);
    ispuInfo?.storeAvailableServices?.forEach((service) => {
      if (
        service === 'CURBSIDE' ||
        service === 'INSTORE' ||
        service === 'LIMITEDCURB' ||
        ((channel === 'OMNI-TELESALES' || channel === 'CHAT-STORE') && service === 'DS') ||
        service === 'LOCKER' ||
        service === 'LOCKER24'
      ) {
        const label = pickupLabel(service); // curbside~instore

        dropdownValues.push({
          label,
          value: service,
        });

        if (is5GDevice && (service === 'LOCKER' || service === 'LOCKER24')) {
          dropdownValues = dropdownValues?.filter((item) => {
            const filterLockerService = !item?.value.includes('LOCKER');
            return filterLockerService;
          });
        }
      }
    });

    return (
      <DropdownSelect
        size='small'
        data-testid='remote-dropdown'
        className='remote-dd'
        width='337px'
        value={displayIspuDetail?.[index]?.ispuServiceSelectionValue || dropdownValues[0].value || ''}
        onChange={(e) => onChangeService(e, displayIspuDetail?.[index]?.netaceLocationCode)}
      >
        {dropdownValues?.map((item) => (
          <option key={item.value} value={item.value}>
            {item.label}
          </option>
        ))}
      </DropdownSelect>
    );
  };

  const getIspuDetails = (storeInfo) => {
    const ispuDetails = [];
    lineInfo?.forEach((item) => {
      item?.itemsInfo?.forEach((item1) => {
        let iSPUStoreInfoNode = [];
        if (item1?.shipping?.storeinfo) {
          const filterLocationCode = storeInfo?.filter(
            (sitem) => sitem?.netaceLocationCode === item1?.shipping?.storeinfo.netaceLocationCode,
          );
          iSPUStoreInfoNode = storeInfo && filterLocationCode?.length > 0 ? [...filterLocationCode] : [];
          const storeAvailableServiceDataSort = [];
          const storeAvailableServiceData =
            iSPUStoreInfoNode?.length > 0 && iSPUStoreInfoNode[0]?.storeAvailableServices?.split('~');
          const ispuService = iSPUStoreInfoNode?.length > 0 && iSPUStoreInfoNode[0]?.ispuServices;
          if (storeAvailableServiceData) {
            if (storeAvailableServiceData?.find((saitem) => saitem?.match(/LOCKER/))) {
              storeAvailableServiceDataSort.push(storeAvailableServiceData?.find((ditem) => ditem?.match(/LOCKER/)));
            }
            const selectedISPUService = storeAvailableServiceData?.find((sditem) => sditem === ispuService);
            if (selectedISPUService && !storeAvailableServiceDataSort?.includes(selectedISPUService)) {
              storeAvailableServiceDataSort.push(selectedISPUService);
            }
          }
          const filterAvailableServiceData = storeAvailableServiceData?.filter(
            (staitem) => staitem !== ispuService && !staitem?.match(/LOCKER/),
          );

          const storeAvailableServiceSortData = [...storeAvailableServiceDataSort, ...filterAvailableServiceData];

          const estimateDate = {};
          if (item1?.estimatedReadyByDate) {
            estimateDate.estimatedReadyByDate = item1?.estimatedReadyByDate;
          }

          ispuDetails.push({
            ...item1.shipping?.storeinfo,
            mtnNumber: item?.mtnDetails?.mobileNumber,
            multiLineSeqNumber: item?.multiLineSeqNumber,
            checked: false,
            ispuServiceSelectionValue: item1?.shipping?.storeinfo?.ispuServices || '',
            storeAvailableServices: storeAvailableServiceSortData,
            ...estimateDate,
          });
        }
      });
    });
    return ispuDetails;
  };

  const getStoreHours = (day, hours) => {
    let timings;
    if (day === 'Sun') {
      if (hours?.includes('AM ')) {
        timings = hours?.replace('AM ', 'AM-');
      } else if (hours?.includes('Closed ')) {
        timings = hours?.replace('Closed ', 'Closed-');
      } else if (hours?.includes('PM ')) {
        timings = hours?.replace('PM ', 'PM-');
      } else {
        timings = hours?.trim();
      }
    } else {
      timings = hours.replace('AM ', 'AM - ');
    }
    return `${day} ${timings}`;
  };

  const updateCheckBoxValue = (value, netaceLocationCode) => {
    const ispuDetailsArr = [];
    if (displayIspuDetail && displayIspuDetail?.length > 0) {
      displayIspuDetail.forEach((item) => {
        if (item?.netaceLocationCode?.toString() === netaceLocationCode?.toString()) {
          ispuDetailsArr.push({
            ...item,
            checked: value,
          });
        } else {
          ispuDetailsArr.push(item);
        }
      });
      setDisplayIspuDetail(ispuDetailsArr);
    }
  };

  return (
    <div>
      {displayIspuDetail &&
        displayIspuDetail?.length > 0 &&
        displayIspuDetail?.map((ispuInfo, i) => {
          const index = displayIspuDetail?.findIndex((x) => x?.mtnNumber === ispuInfo?.mtnNumber);
          return (
            <>
              <PickupTitle>
                <Title size='small' bold>
                  {ispuInfo?.estimatedReadyByDate ? (
                    <Title>{`Ready By ${moment(new Date(ispuInfo?.estimatedReadyByDate)).format('MMMM Do')}`} </Title>
                  ) : (
                    <Title size='small' bold>
                      Available for pickup at
                    </Title>
                  )}
                </Title>
              </PickupTitle>
              <AddressContainer>
                <AddressLine>
                  <Body size='large' primitive='span' bold>
                    {ispuInfo?.storeName}
                  </Body>
                </AddressLine>
                <AddressLine>
                  <Body size='large' primitive='span'>
                    {ispuInfo?.address1}
                  </Body>
                </AddressLine>
                <AddressLine>
                  <Body size='large'>{`${ispuInfo?.city}, ${ispuInfo?.state}, ${ispuInfo?.zipCode} `}</Body>
                </AddressLine>
                <AddressLine>
                  <Body size='large'>{`Store Hours: ${getStoreHours('Sun', ispuInfo?.hoursSun)} `}</Body>
                </AddressLine>
                <AddressLine>
                  <Body size='large'>{getStoreHours('Mon', ispuInfo?.hoursMon)}</Body>
                </AddressLine>
                <AddressLine>
                  <Body size='large'>{getStoreHours('Tue', ispuInfo?.hoursTue)}</Body>
                </AddressLine>
                <AddressLine>
                  <Body size='large'>{getStoreHours('Wed', ispuInfo?.hoursWed)}</Body>
                </AddressLine>
                <AddressLine>
                  <Body size='large'>{getStoreHours('Thu', ispuInfo?.hoursThu)}</Body>
                </AddressLine>
                <AddressLine>
                  <Body size='large'>{getStoreHours('Fri', ispuInfo?.hoursFri)}</Body>
                </AddressLine>
                <AddressLine>
                  <Body size='large'>{getStoreHours('Sat', ispuInfo?.hoursSat)}</Body>
                </AddressLine>
              </AddressContainer>
              <DropdownWrapper>
                {Array.isArray(ispuInfo?.storeAvailableServices) && ispuInfo?.storeAvailableServices?.length > 0 && (
                  <>
                    {' '}
                    <Body size='large' primitive='span' bold>
                      Select Service Type *
                    </Body>
                    <div style={{ marginTop: '5px', marginLeft: '5px' }}>{getDropdownContent(ispuInfo)}</div>
                  </>
                )}
              </DropdownWrapper>
              <DropdownValueActionText>
                {displayIspuDetail?.[i]?.ispuServiceSelectionValue === 'CURBSIDE' ? (
                  <>
                    <Body size='medium' bold primitive='span'>
                      Curb Side Pickup:
                    </Body>
                    <Body size='medium' primitive='span'>
                      {' '}
                      Meet rep at designated curb side spot
                    </Body>
                  </>
                ) : (
                  ''
                )}
                {displayIspuDetail?.[i]?.ispuServiceSelectionValue === 'INSTORE' ? (
                  <>
                    <Body size='medium' bold primitive='span'>
                      Inside Pickup:
                    </Body>
                    <Body size='medium' primitive='span'>
                      {' '}
                      Meet a rep inside the store
                    </Body>
                    <CheckboxWrapper>
                      <Checkbox
                        id='ispuCheckbox'
                        data-testId='ispuCheckbox'
                        name='ispuCheckbox'
                        selected={displayIspuDetail?.[index]?.checked || false}
                        onChange={() =>
                          updateCheckBoxValue(
                            !displayIspuDetail?.[index]?.checked,
                            displayIspuDetail?.[index]?.netaceLocationCode,
                          )
                        }
                        label='Yes, the customer needs assistance from an in-store representative'
                      />
                    </CheckboxWrapper>
                  </>
                ) : (
                  ''
                )}

                {displayIspuDetail?.[i]?.ispuServiceSelectionValue === 'LOCKER' ||
                displayIspuDetail?.[i]?.ispuServiceSelectionValue === 'LOCKER24' ? (
                  <>
                    <Body size='medium' primitive='span'>
                      Pick up from a locker, available 24/7
                    </Body>
                    <CheckboxWrapper marginLeft>
                      <div style={{ marginBottom: '5px' }}>
                        <Body size='large' bold primitive='span'>
                          ADA Compliant height <Icon name='international-symbol-of-access' size='large' />
                        </Body>
                      </div>
                      <Checkbox
                        id='ispuCheckbox'
                        data-testId='ispuCheckbox'
                        name='ispuCheckbox'
                        selected={displayIspuDetail?.[index]?.checked || false}
                        onChange={() =>
                          updateCheckBoxValue(
                            !displayIspuDetail?.[index]?.checked,
                            displayIspuDetail?.[index]?.netaceLocationCode,
                          )
                        }
                        label='place order in a locker below 36 inches.'
                      />
                    </CheckboxWrapper>
                  </>
                ) : (
                  ''
                )}
              </DropdownValueActionText>
            </>
          );
        })}
    </div>
  );
};

PickupDetails.propTypes = {
  customerProfile: PropTypes.object,
  cart: PropTypes.object,
  customerType: PropTypes.string,
};

export default PickupDetails;
