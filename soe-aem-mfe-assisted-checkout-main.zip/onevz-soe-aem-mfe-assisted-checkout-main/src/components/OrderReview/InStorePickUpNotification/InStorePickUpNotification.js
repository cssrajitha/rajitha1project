import PropTypes from 'prop-types';
import { Body } from '@vds/typography';
import { useState, useEffect } from 'react';
import { TileContainer } from '@vds/tiles';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import EmailValidationInput from './EmailValidationInput';
import customerInfoData from '../__mock__/customerInfoData.json';
import InspicioCheckBox from './InspicioCheckBox';
import PickupDetails from './PickupDetails';
import InfoApiCallHook from '../../../modules/services/APIService/InfoAPICallHook';
import { getMTNList } from '../../../utils/common';

const InStorePickUpNotification = (props) => {
  const { isFromShipping = false, cart, customerProfile, selectedMode, isLovEnabled, selectedReason } = props;

  const { getActiveMTNRequest, getActiveMTNResponse } = InfoApiCallHook();

  const [state, setState] = useState({
    email: '',
    error: false,
    isEmailDirty: false,
    mtn: [],
    checkBoxSelectedValue: true,
    selectedMtnValue: '',
    inspicioModel: false,
  });

  const [updateCartNotificationData, setUpdateCartNotificationData] = useState({
    selectedMtnValue: '',
    selectedEmail: '',
    selectedCheckboxValue: true,
  });

  useEffect(() => {
    const customerInfo = cart?.lineDetails?.lineInfo[0]?.serviceInfo?.primaryUserInfo || '';
    if (state.email !== cart?.orderDetails?.spocs?.notificationOptions?.primaryEmailId) {
      const lookupMtn = customerProfile?.data?.customer?.lookupMtn || '';

      setState({
        ...state,
        email: cart?.orderDetails?.spocs?.notificationOptions?.primaryEmailId || '',
        selectedMtnValue: lookupMtn || (state.mtn.length > 0 && state.mtn[0].mtn) || '',
      });
      cartNotificationData({
        selectedEmail: cart?.orderDetails?.spocs?.notificationOptions?.primaryEmailId,
        selectedMtnValue: lookupMtn || (state.mtn.length > 0 && state.mtn[0].mtn) || '',
      });
      if (customerType === 'N') {
        setState({ ...state, email: customerInfo?.emailId || '' });
        cartNotificationData({ selectedEmail: customerInfo?.emailId });
      }
    }
  }, [cart]);

  useEffect(() => {
    const requestBodyAllActiveMTNs = {
      accountNumber: cart?.cartHeader?.fullAccountNumber || '',
    };
    if (customerType !== 'N' && Object.keys(cart)?.length !== 0) {
      getActiveMTNRequest({ body: requestBodyAllActiveMTNs, spinner: false, mock: false });
    }
  }, [cart]);

  useEffect(() => {
    if (getActiveMTNResponse?.data?.customer?.billAccounts?.length > 0) {
      const mtnValues = getMTNList(getActiveMTNResponse?.data?.customer?.billAccounts) || [];
      if (mtnValues?.length > 0) {
        setState({
          ...state,
          mtn: mtnValues,
        });
      }
    }
  }, [getActiveMTNResponse]);

  const getISPUFlage = (lines) => {
    const isISPUItemOnCart = lines?.length > 0 ? lines.map((line) => line?.ispuItem || false) : false;
    return isISPUItemOnCart;
  };

  const lineInfo = cart?.lineDetails?.lineInfo || [];
  const ispuInfo = getISPUFlage(lineInfo);
  const ispuItemOnCart = !!(ispuInfo?.length > 0 && ispuInfo?.filter((boolVal) => boolVal).length > 0);

  const handleEmailValue = (data) => {
    const { email, isEmailError } = data;
    setState({
      ...state,
      email,
      isEmailDirty: isEmailError,
    });
    cartNotificationData({ selectedEmail: email, notificationEmailStatus: !isEmailError ? 'Valid' : 'Fake' });
  };

  const cartNotificationData = (value) => {
    const updateCartNotificationDataObj = { ...updateCartNotificationData };

    updateCartNotificationDataObj.selectedEmail = value?.selectedEmail || state.email;
    updateCartNotificationDataObj.notificationEmailStatus = value?.notificationEmailStatus || '';
    updateCartNotificationDataObj.selectedCheckboxValue = value?.selectedCheckboxValue
      ? !state.checkBoxSelectedValue
      : updateCartNotificationData.selectedCheckboxValue;
    updateCartNotificationDataObj.selectedMtnValue = value?.selectedMtnValue || state.selectedMtnValue;

    setUpdateCartNotificationData({ ...updateCartNotificationDataObj, ...updateCartNotificationData });
  };

  const isPrePayCart = cart?.orderDetails?.isPrePayCart === 'Y';
  const isSuspended = !!(sessionStorage.getItem('suspended') === 'suspended' && isPrePayCart);

  const customerType = getQueryParamByName('customerType') || sessionStorage.getItem('customerType');
  const techCoachRep = customerProfile?.data?.customer?.acssWebParams?.isTechCoachRep === 'Y' || false;

  const showCheckboxSection = () => {
    let enableCheckboxSection = false;
    const isPostToPreExistingCustomer = sessionStorage.getItem('newPostToPreIndicator') === 'true';
    if (
      !isPostToPreExistingCustomer ||
      (isPostToPreExistingCustomer &&
        sessionStorage.getItem('channel') === ('OMNI-TELESALES' || 'CHAT-STORE') &&
        sessionStorage.getItem('path')?.includes('order-review'))
    ) {
      enableCheckboxSection = true;
    }

    return enableCheckboxSection;
  };

  const newCustomerEmailId = cart?.lineDetails?.lineInfo[0]?.serviceInfo?.primaryUserInfo?.emailId || '';
  const isLovEligibleFromSessionStorage = sessionStorage.getItem('isLovEligibleFromSessionStorage');
  let isLovEligible =
    isLovEligibleFromSessionStorage && isLovEnabled && !(selectedMode === 'VT' && selectedReason !== '');
  if (isLovEligible && customerType === 'N' && !newCustomerEmailId) {
    isLovEligible = false;
  }

  return (
    <TileContainer padding={props.padding || '20px'} height='auto' width='384px' backgroundColor='white'>
      <div style={{ width: '100%' }}>
        <div style={{ paddingBottom: '16px' }}>
          {ispuItemOnCart ? (
            <Body bold size='large'>
              In Store-Pick Up Notification
            </Body>
          ) : (
            <Body bold size='large'>
              Notification Information
            </Body>
          )}
        </div>
        {!isFromShipping && (
          <div>
            <EmailValidationInput
              testId='CartTest'
              label='Email Address*'
              required
              id='inspicioEmailAddress'
              name='emailAddress'
              placeholder='Enter Email Address'
              ariaDescribedBy='InputHelpText'
              data={{ email: state.email }}
              customerInfo={customerInfoData}
              iconName=''
              autoComplete='off'
              style={{ marginTop: '0px' }}
              handleEmailValue={handleEmailValue}
              disabled={techCoachRep || isSuspended}
              isCustomerTypeNSE={customerType === 'N'}
            />
          </div>
        )}
        {showCheckboxSection() && ((customerType === 'N' && ispuItemOnCart) || state?.mtn?.length > 0) && (
          <InspicioCheckBox
            ispuItemOnCart={ispuItemOnCart}
            cartDetails={cart}
            cartNotificationData={cartNotificationData}
            state={state}
            setState={setState}
            customerType={customerType}
            customerProfile={customerProfile?.data?.customer}
            isLovEligible={isLovEligible}
            selectedMode={selectedMode}
          />
        )}
        {ispuItemOnCart && (
          <PickupDetails
            ispuItemOnCart={ispuItemOnCart}
            cart={cart}
            customerType={customerType}
            customerProfile={customerProfile?.data?.commonInfo}
          />
        )}
      </div>
    </TileContainer>
  );
};

InStorePickUpNotification.propTypes = {
  isFromShipping: PropTypes.bool,
  cart: PropTypes.object,
  customerProfile: PropTypes.any,
  selectedMode: PropTypes.string,
  isLovEnabled: PropTypes.bool,
  selectedReason: PropTypes.string,
  padding: PropTypes.string,
};

export default InStorePickUpNotification;
