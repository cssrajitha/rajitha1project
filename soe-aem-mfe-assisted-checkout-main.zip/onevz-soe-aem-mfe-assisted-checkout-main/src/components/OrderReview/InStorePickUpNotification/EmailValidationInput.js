import { Input } from '@vds/inputs';
import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { Tooltip } from '@vds/tooltips';
import { TextLink } from '@vds/buttons';
import { Notification } from '@vds/notifications';
import { Loader } from '@vds/loaders';
import { isValidEmail as isValidEmailFormat } from 'onevzsoemfecommon/Helpers';
import EmailApiCallHook from '../../../modules/services/APIService/EmailApiCallHook';

function EmailValidationInput(props) {
  const {
    name,
    data,
    handleEmailValue,
    iconName,
    label,
    id,
    placeholder,
    testId,
    disabled,
    ariaDescribedBy,
    autoComplete,
    required,
    isCustomerTypeNSE,
    customerInfo,
    isKeyPress,
  } = props;
  const { emailValidate, verifyEmail } = EmailApiCallHook();
  const [state, setState] = useState({
    email: '',
    emailError: '',
    currentEmail: null,
    emailSentNotification: '',
    btnDisabled: false,
    validationStatus: '',
    isValidEmail: false,
    isCurrentEmail: false,
    validateEmailCalled: false,
    onBlurCalled: false,
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (state.email !== data?.email) {
      const currentEmail = data?.email?.length > 0 ? data?.email : null;
      setState({
        ...state,
        email: data?.email || '',
        emailError: data?.emailError || '',
        currentEmail,
      });
    }
  }, [data]);

  const getEmailErrorStatus = (stateObj) => {
    const isEmailError = !!(stateObj.email === '' || stateObj.emailError || stateObj.emailSentNotification);
    return isEmailError;
  };

  const getValidEmailStatus = (stateObj) => {
    const { validationStatus } = stateObj;
    const isEmailError = getEmailErrorStatus(stateObj);
    const isValidEmail =
      validationStatus !== '' && (validationStatus === 'Valid' || validationStatus === 'White_listed') && !isEmailError;
    return isValidEmail;
  };

  const handleEmailInputOnChange = (event) => {
    const { value = '' } = event.target;
    const emailItem = value.replace(/\s/g, '');

    const stateObj = { ...state };
    stateObj.email = emailItem;
    stateObj.validationStatus = '';
    stateObj.emailError = '';
    stateObj.onBlurCalled = false;

    const validEmail = isValidEmailFormat(emailItem);

    stateObj.isCurrentEmail = state.currentEmail === emailItem && state.currentEmail !== null;
    stateObj.emailError = !validEmail ? 'Please enter a valid email address' : '';
    const isEmailError = getEmailErrorStatus(stateObj);
    const isValidEmail = getValidEmailStatus(stateObj);
    stateObj.isValidEmail = isValidEmail;
    const stopFlow = state.currentEmail === emailItem && state.currentEmail !== null ? true : !validEmail;
    let validEmailValue;

    if (state.currentEmail === emailItem && state.currentEmail !== null) {
      validEmailValue = false;
    } else if (!validEmail) {
      validEmailValue = isValidEmail;
    } else {
      validEmailValue = isValidEmail && !state.isCurrentEmail;
    }

    setState({ ...state, ...stateObj });

    handleEmailValue({
      ...data,
      email: emailItem,
      isEmailError,
      isValidEmail: validEmailValue,
      stopFlow,
    });
  };

  const handleEmailInputOnBlur = async () => {
    setState({ ...state, onBlurCalled: true });
    setLoading(true);
    const { email, isCurrentEmail } = state;
    const validEmail = isValidEmailFormat(email);
    const stateObj = { ...state };
    if (!validEmail) {
      stateObj.emailError = 'Please enter a valid email address';
      stateObj.validationStatus = '';

      const isEmailError = getEmailErrorStatus(stateObj);
      const isValidEmail = getValidEmailStatus(stateObj);
      stateObj.isValidEmail = isValidEmail;
      stateObj.onBlurCalled = true;

      setState({ ...state, ...stateObj });

      handleEmailValue({
        ...data,
        email,
        isEmailError,
        isValidEmail,
        stopFlow: true,
        onBlurCalled: true,
      });
      setLoading(false);
    } else if (validEmail && isCurrentEmail === false) {
      const params = {
        emailAddress: email,
      };
      setState({ ...state, validateEmailCalled: true });
      try {
        const res = await emailValidate({ body: params, spinner: false, mock: false });
        if (res?.data?.validationStatus === 'Valid' || res?.data?.validationStatus === 'White_listed') {
          stateObj.emailError = '';
        } else if (res?.data?.validationStatus === 'Manual_validation') {
          stateObj.emailError = res?.data?.validationStatus;
        } else {
          stateObj.emailError = 'Please enter a valid email address';
        }
        stateObj.validationStatus = res?.data?.validationStatus;
        stateObj.emailSentNotification = '';

        const isEmailError = getEmailErrorStatus(stateObj);
        const isValidEmail = getValidEmailStatus(stateObj);
        stateObj.isValidEmail = isValidEmail;
        stateObj.onBlurCalled = true;

        setState({ ...state, ...stateObj });

        handleEmailValue({
          ...data,
          email,
          isEmailError,
          isValidEmail,
          stopFlow: false,
          validationStatus: res?.data?.validationStatus,
        });

        setLoading(false);
      } catch (e) {
        setLoading(false);
      }
    } else if (isCurrentEmail === true) {
      handleEmailValue({
        ...data,
        email,
        isEmailError: true,
        isValidEmail: false,
        stopFlow: true,
        onBlurCalled: true,
      });
      setLoading(false);
    }
  };

  const handleEmailInputOnKeyPress = (e) => {
    if ((e.charCode === 13 || e.charCode === 32) && state.validateEmailCalled !== true) {
      handleEmailInputOnBlur();
    }
  };

  const verifyEmailAddress = async () => {
    setLoading(true);
    const stateObj = state;
    let body = {
      action: 'manual',
      email: state.email,
    };
    if (isCustomerTypeNSE) {
      body = { ...body, prospectCustomer: true };
    } else {
      const { lookupMtn = '', customerId = '' } = customerInfo;
      const accountNo = customerId?.split('-');
      body = { ...body, mtn: lookupMtn, customerId: accountNo[0], accountNumber: accountNo[1] };
    }
    try {
      const response = await verifyEmail({ body, spinner: false, mock: false });

      const successTitle = 'Please have customer check their email';
      const errorTitle = [response.data?.error];
      const successSubtitle = [
        `An email has been sent to ${state.email}`,
        <br key='email-validate-break' />,
        'After customer validates the email address, click confirm below.',
      ];
      const btnName = response?.data?.data?.statusDescription ? 'Confirm' : 'Click Here';

      stateObj.emailSentNotification = [
        <div key='send-email-notification'>
          <Notification
            type='info'
            title={response?.data?.data?.statusDescription ? successTitle : errorTitle}
            subtitle={response?.data?.data?.statusDescription ? successSubtitle : ''}
            layout='vertical'
            hideCloseButton
            data-testid={response?.data?.data?.statusDescription ? 'confirm' : 'click-here'}
            buttonData={[
              {
                children: btnName,
                onClick: () => handleEmailInputOnBlur(),
              },
            ]}
          />
        </div>,
      ];

      stateObj.emailError = '';
      const isEmailError = getEmailErrorStatus(stateObj);
      const isValidEmail = getValidEmailStatus(stateObj);
      stateObj.isValidEmail = isValidEmail;

      setState({ ...state, ...stateObj });
      handleEmailValue({
        ...data,
        email: state.email,
        isEmailError,
        isValidEmail,
      });
      setLoading(false);
    } catch (error) {
      setLoading(false);
    }
  };

  return (
    <div data-testid='EmailValidationInput'>
      <Input
        label={label || 'Email Address'}
        type='text'
        id={id || ''}
        placeholder={placeholder || ''}
        data-testid={testId || ''}
        iconName={iconName || ''}
        name={name || ''}
        onChange={(e) => handleEmailInputOnChange(e)}
        value={state.email}
        disabled={disabled || false}
        onBlur={() => !state.onBlurCalled && handleEmailInputOnBlur()}
        onKeyPress={(e) => isKeyPress === true && handleEmailInputOnKeyPress(e)}
        success={state.isValidEmail}
        aria-describedby={ariaDescribedBy || ''}
        autoComplete={autoComplete || ''}
        required={required || false}
        helperText={state.isCurrentEmail ? 'Current Email Address' : ''}
        helperTextPlacement='bottom'
        error={!!(state.emailError !== '' || state.emailSentNotification !== '')}
        errorText={
          state.emailError === 'Manual_validation'
            ? [
                'Please ',
                <TextLink
                  type='inline'
                  key='manul_valudation_link'
                  onClick={verifyEmailAddress}
                  style={{ zIndex: 999999 }}
                >
                  click here
                </TextLink>,
                ' to send an email to the customer to validate the email address.',
                <Tooltip size='medium' iconFillColor='primary' surface='light' key='manul_valudation_span'>
                  For security, we need to confirm this email address is valid.
                </Tooltip>,
              ]
            : state.emailError || ''
        }
      />
      {state.emailSentNotification}
      {loading && <Loader fullscreen active surface='light' />}
    </div>
  );
}

EmailValidationInput.propTypes = {
  name: PropTypes.string,
  data: PropTypes.object,
  handleEmailValue: PropTypes.func,
  iconName: PropTypes.string,
  label: PropTypes.string,
  id: PropTypes.string,
  placeholder: PropTypes.string,
  testId: PropTypes.string,
  disabled: PropTypes.bool,
  ariaDescribedBy: PropTypes.string,
  autoComplete: PropTypes.string,
  required: PropTypes.bool,
  isCustomerTypeNSE: PropTypes.bool,
  customerInfo: PropTypes.object,
  isKeyPress: PropTypes.bool,
};

export default EmailValidationInput;
