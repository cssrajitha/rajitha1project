import PropTypes from 'prop-types';
import { Checkbox } from '@vds/checkboxes';
import { DropdownSelect } from '@vds/selects';
import { Input as VdsInput } from '@vds/inputs';
import { isEmpty } from 'lodash';
import { Body, Micro } from '@vds/typography';
import { Button } from '@vds/buttons';
import { isValidPhoneNumber } from 'onevzsoemfecommon/Helpers/validation';
import styled from 'styled-components';

const ModalContainer = styled.div`
  position: fixed;
  top: 50%;
  left: 50%;
  width: 30%;
  height: 15%;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: white;
  transform: translate(-50%, -50%);
  padding: 15px;
  z-index: 99;
  box-shadow: 0px 0px 1px 0px;
`;

const ModalBody = styled.div`
  display: grid;
  grid-template-rows: 1fr 1fr;
  gap: 10px;
`;

const CenterSpan = styled.span`
  text-align: center;
`;

const MarginAuto = styled.div`
  margin: auto;
`;

const InspicioContentWrapper = styled.div`
  padding-bottom: 7px;
`;

const InspicioContentContainer = styled.div`
  padding-top: 21px;
`;

const InspicioContainer = styled.div`
  padding-top: 28px;
`;

const InspicioCheckBox = (props) => {
  const {
    ispuItemOnCart,
    cartDetails,
    cartNotificationData,
    state,
    setState,
    customerType,
    customerProfile,
    isLovEligible,
    selectedMode,
  } = props;

  const onInspicioCheckBoxChange = () => {
    const value = !state.checkBoxSelectedValue;
    const stateObj = { ...state };
    stateObj.checkBoxSelectedValue = value;
    const isIndirect = cartDetails?.cartHeader?.sourceSystem?.includes('OMNI-INDIRECT');
    setState({ ...state, ...stateObj });
    cartNotificationData({ selectedCheckboxValue: 'Changed' });
    if (state.checkBoxSelectedValue && !isIndirect) {
      stateObj.inspicioModel = true;
      setState({ ...state, ...stateObj });
    }
  };

  const selectedMtnValue = () => {
    let selectedValue = '';
    if (state.selectedMtnValue) {
      selectedValue = state.selectedMtnValue;
    } else if (customerProfile?.lookupMtn) {
      selectedValue = customerProfile?.lookupMtn;
    }
    // else if (this.props.isLovEligible && state.mtn && state.mtn.length > 0) {
    //   selectedValue = state.mtn[0].value;
    // }

    return selectedValue;
  };

  const handleMDN = (e) => {
    const stateObj = { ...state };
    stateObj.selectedMtnValue = e.target.value;
    setState({ ...state, ...stateObj });
    cartNotificationData({ selectedMtnValue: e.target.value, selectedEmail: state.email || '' });
  };

  const onChangeMDN = (e) => {
    if (e.target.value.length < 11) {
      const stateObj = { ...state };
      stateObj.selectedMtnValue = e.target.value;
      setState({ ...state, ...stateObj });
    }
  };

  const closeModal = () => {
    setState({
      ...state,
      inspicioModel: false,
    });
  };

  return (
    <InspicioContainer>
      {((customerType === 'N' && ispuItemOnCart) || state.mtn.length > 0) && (
        <Checkbox
          id='inspicioCheckbox'
          data-testId='inspicioCheckbox'
          name='inspicioMode'
          selected={state?.checkBoxSelectedValue === undefined ? true : state?.checkBoxSelectedValue}
          onChange={() => onInspicioCheckBoxChange()}
          label={
            ispuItemOnCart
              ? 'Send Text Messages for Customer Agreement, Order Confirmation and Shipping Notifications'
              : 'Send text messages for order confirmation and shipping notifications'
          }
          disabled={isLovEligible && selectedMode !== 'VT'}
        />
      )}
      {state.checkBoxSelectedValue !== undefined && !state.checkBoxSelectedValue ? (
        state.inspicioModel && (
          <div data-testid='inspicio-modal' id='inspicio-modal'>
            <ModalContainer>
              <ModalBody>
                <Body bold>
                  <CenterSpan>Unselecting the MDN will disable Inspicio mode for SMS</CenterSpan>
                </Body>
                <MarginAuto>
                  <Button data-testid='inspicio-modal-btn' width={30} onClick={() => closeModal()}>
                    Ok
                  </Button>
                </MarginAuto>
              </ModalBody>
            </ModalContainer>
          </div>
        )
      ) : (
        <>
          {state.mtn.length > 0 && (
            <InspicioContentContainer>
              <InspicioContentWrapper>
                <Micro bold>Select MDN to send text message *</Micro>
              </InspicioContentWrapper>
              <DropdownSelect
                value={selectedMtnValue()}
                onChange={(e) => handleMDN(e)}
                id='orderReviewNotificationDropdown'
                data-testid='orderReviewNotificationDropdown'
                disabled={isLovEligible && selectedMode === ''}
              >
                {state.mtn.map((item, i) => (
                  <option
                    key={item.value}
                    data-testid={`orderReviewNotificationDropdown-option-${i}`}
                    value={item.value}
                  >
                    {item.value}
                  </option>
                ))}
              </DropdownSelect>
            </InspicioContentContainer>
          )}
          {state.mtn.length === 0 && customerType && customerType === 'N' && ispuItemOnCart && (
            <InspicioContentContainer>
              <InspicioContentWrapper>
                <Micro bold>Enter MDN to send text Message*</Micro>
              </InspicioContentWrapper>
              <VdsInput
                label=''
                type='number'
                id='inspicioMDNInput'
                data-testid='inspicioMDNInput'
                name='inspicioMDNInput'
                maxlength={10}
                size={10}
                placeholder='Enter MDN Number'
                onBlur={(e) => handleMDN(e)}
                onChange={onChangeMDN}
                aria-describedby='InputHelpText'
                value={state.selectedMtnValue}
                iconName=''
                error={!isValidPhoneNumber(state.selectedMtnValue) && !isEmpty(state.selectedMtnValue)}
                errorText='Please enter a valid MDN'
              />
            </InspicioContentContainer>
          )}
        </>
      )}
    </InspicioContainer>
  );
};

InspicioCheckBox.propTypes = {
  ispuItemOnCart: PropTypes.bool,
  cartDetails: PropTypes.object,
  cartNotificationData: PropTypes.func,
  state: PropTypes.object,
  setState: PropTypes.func,
  customerType: PropTypes.string,
  customerProfile: PropTypes.object,
  isLovEligible: PropTypes.bool,
  selectedMode: PropTypes.string,
};

export default InspicioCheckBox;
