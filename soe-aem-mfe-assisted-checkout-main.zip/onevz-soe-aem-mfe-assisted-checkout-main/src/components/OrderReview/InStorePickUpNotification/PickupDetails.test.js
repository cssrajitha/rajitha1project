import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import StoreProvider from '../../../modules/store/index';
import { instorePickupCart } from '../../../__mock__/instore-pickup-cart';
import customerJson from '../../../__mock__/retrieve-customer.json';
import mockStoreInfo from '../../../__mock__/getStoreInformation.json';
import PickupDetails from './PickupDetails';
import * as PickupApiCallHook from '../../../modules/services/APIService/PickupDetailsAPICallHook';

describe('InStorePickUpNotification Component', () => {
  jest.mock('onevzsoemfecommon/Helpers', () => ({
    getQueryParamByName: jest.fn(() => 'N'),
  }));

  const mockValue = jest.fn();

  const mockData = {
    getStoreInfo: mockValue,
    storeInfoResult: { data: mockStoreInfo },
  };

  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  test('renders PickUpDetails component', () => {
    sessionStorage.setItem('channel', 'OMNI-TELESALES');
    jest.spyOn(PickupApiCallHook, 'default').mockImplementation(() => mockData);
    render(
      <StoreProvider>
        <PickupDetails
          ispuItemOnCart
          cart={instorePickupCart()}
          customerType='Y'
          customerProfile={customerJson?.data?.commonInfo}
        />
      </StoreProvider>,
    );
    const title = screen.getByText('Available for pickup at');
    expect(title).toBeInTheDocument();
    const Checkbox = screen.getByTestId('test-input', {
      name: 'ispuCheckbox',
    });
    expect(Checkbox).toBeInTheDocument();
    fireEvent.click(Checkbox);
  });

  test('change checkbox value', () => {
    sessionStorage.setItem('channel', 'OMNI-TELESALES');
    jest.spyOn(PickupApiCallHook, 'default').mockImplementation(() => mockData);
    render(
      <StoreProvider>
        <PickupDetails
          ispuItemOnCart
          cart={instorePickupCart('LOCKER')}
          customerType='Y'
          customerProfile={customerJson?.data?.commonInfo}
        />
      </StoreProvider>,
    );
    const title = screen.getByText('Available for pickup at');
    expect(title).toBeInTheDocument();
    const Checkbox = screen.getByTestId('test-input', {
      name: 'ispuCheckbox',
    });
    expect(Checkbox).toBeInTheDocument();
    fireEvent.click(Checkbox);
  });

  test('change dropdown and checkbox value', () => {
    sessionStorage.setItem('channel', 'CHAT-STORE');
    jest.spyOn(PickupApiCallHook, 'default').mockImplementation(() => mockData);
    render(
      <StoreProvider>
        <PickupDetails
          ispuItemOnCart
          cart={instorePickupCart()}
          customerType='Y'
          customerProfile={customerJson?.data?.commonInfo}
        />
      </StoreProvider>,
    );
    const title = screen.getByText('Available for pickup at');
    expect(title).toBeInTheDocument();
    fireEvent.change(screen.getByRole('combobox'), {
      target: { value: 'LOCKER' },
    });
    waitFor(() => {
      const Checkbox = screen.getByTestId('test-input', {
        name: 'ispuCheckbox',
      });
      expect(Checkbox).toBeInTheDocument();
      fireEvent.click(Checkbox);
    });
  });

  test('test ready by scenario', () => {
    sessionStorage.setItem('channel', 'CHAT-STORE');
    jest.spyOn(PickupApiCallHook, 'default').mockImplementation(() => mockData);
    render(
      <StoreProvider>
        <PickupDetails
          ispuItemOnCart
          cart={instorePickupCart('LOCKER24', '07/24/2024', 'PM ')}
          customerType='Y'
          customerProfile={customerJson?.data?.commonInfo}
        />
      </StoreProvider>,
    );
    const title = screen.getByText(/Ready By/i);
    expect(title).toBeInTheDocument();
  });

  test('test service closed hours', () => {
    sessionStorage.setItem('channel', 'CHAT-STORE');
    jest.spyOn(PickupApiCallHook, 'default').mockImplementation(() => mockData);
    render(
      <StoreProvider>
        <PickupDetails
          ispuItemOnCart
          cart={instorePickupCart('LOCKER24', '07/24/2024', 'Closed ')}
          customerType='Y'
          customerProfile={customerJson?.data?.commonInfo}
        />
      </StoreProvider>,
    );
    const title = screen.getByText(/Ready By/i);
    expect(title).toBeInTheDocument();
  });
});
