import { fireEvent, render, screen } from '@testing-library/react';
import StoreProvider from '../../../modules/store/index';
import cartJson from '../../../__mock__/retrive-cart.json';
import customerJson from '../../../__mock__/retrieve-customer.json';
import InspicioCheckBox from './InspicioCheckBox';

const validationProps = {
  ispuItemOnCart: true,
  cartDetails: cartJson.data.cart,
  cartNotificationData: jest.fn(),
  state: {
    mtn: [
      { label: '6102992029', value: '6102992029' },
      { label: '6102992830', value: '6102992830' },
      { label: '6103683623', value: '6103683623' },
      { label: '6106637197', value: '6106637197' },
    ],
    checkBoxSelectedValue: true,
    selectedMtnValue: '',
    inspicioModel: false,
  },
  setState: jest.fn(),
  customerType: 'N',
  customerProfile: customerJson?.data?.customer,
};

describe('InspicioCheckBox Component', () => {
  test('renders InspicioCheckBox component', () => {
    render(
      <StoreProvider>
        <InspicioCheckBox {...validationProps} />
      </StoreProvider>,
    );
    const inspicioCheckbox = screen.getByRole('checkbox');
    expect(inspicioCheckbox).toBeInTheDocument();
    const title = screen.getByText(
      'Send Text Messages for Customer Agreement, Order Confirmation and Shipping Notifications',
    );
    expect(title).toBeInTheDocument();
  });

  test('checkbox click click event', () => {
    render(
      <StoreProvider>
        <InspicioCheckBox {...validationProps} />
      </StoreProvider>,
    );
    const inspicioCheckbox = screen.getByRole('checkbox');
    expect(inspicioCheckbox).toBeInTheDocument();
    fireEvent.click(inspicioCheckbox, {});
  });

  test('renders InspicioModal', () => {
    const validationPropsCopy = {
      ...validationProps,
      state: { ...validationProps.state, checkBoxSelectedValue: false, inspicioModel: true },
    };
    sessionStorage.setItem('channel', 'OMNI-TELESALES');
    sessionStorage.setItem('path', 'order-review');

    const { rerender } = render(
      <StoreProvider>
        <InspicioCheckBox {...validationProps} />
      </StoreProvider>,
    );

    const inspicioCheckbox = screen.getByRole('checkbox');
    expect(inspicioCheckbox).toBeInTheDocument();
    fireEvent.change(inspicioCheckbox, {});

    rerender(
      <StoreProvider>
        <InspicioCheckBox {...validationPropsCopy} />
      </StoreProvider>,
    );

    const inspicioModal = screen.getByTestId('inspicio-modal');
    expect(inspicioModal).toBeInTheDocument();
  });

  test('renders InspicioModal button click', () => {
    const validationPropsCopy = {
      ...validationProps,
      state: { ...validationProps.state, checkBoxSelectedValue: false, inspicioModel: true },
    };
    sessionStorage.setItem('channel', 'OMNI-TELESALES');
    sessionStorage.setItem('path', 'order-review');

    const { rerender } = render(
      <StoreProvider>
        <InspicioCheckBox {...validationProps} />
      </StoreProvider>,
    );

    const inspicioCheckbox = screen.getByRole('checkbox');
    expect(inspicioCheckbox).toBeInTheDocument();
    fireEvent.change(inspicioCheckbox, {});

    rerender(
      <StoreProvider>
        <InspicioCheckBox {...validationPropsCopy} />
      </StoreProvider>,
    );

    const inspicioModal = screen.getByTestId('inspicio-modal');
    expect(inspicioModal).toBeInTheDocument();
    const inspicioModalBtn = screen.getByTestId('inspicio-modal-btn');
    expect(inspicioModalBtn).toBeInTheDocument();
    fireEvent.click(inspicioModalBtn);
  });

  test('render dropdwon container', () => {
    render(
      <StoreProvider>
        <InspicioCheckBox {...validationProps} />
      </StoreProvider>,
    );
    const inspicioCheckbox = screen.getByText('Select MDN to send text message *');
    expect(inspicioCheckbox).toBeInTheDocument();
  });

  test('render dropdwon container', () => {
    render(
      <StoreProvider>
        <InspicioCheckBox {...validationProps} />
      </StoreProvider>,
    );
    const inspicioCheckbox = screen.getByText('Select MDN to send text message *');
    expect(inspicioCheckbox).toBeInTheDocument();
    const notificationDropdown = screen.getByTestId('orderReviewNotificationDropdown');
    expect(notificationDropdown.value).toEqual('6102992029');
  });

  test('dropdwon value change event', () => {
    render(
      <StoreProvider>
        <InspicioCheckBox {...validationProps} />
      </StoreProvider>,
    );
    const inspicioCheckbox = screen.getByText('Select MDN to send text message *');
    expect(inspicioCheckbox).toBeInTheDocument();
    const notificationDropdownBtn = screen.getByTestId('orderReviewNotificationDropdown');
    fireEvent.change(notificationDropdownBtn, { target: { value: '6102992830' } });
  });

  test('render Input component', () => {
    const validationPropsCopy = { ...validationProps, state: { ...validationProps.state, mtn: [] } };
    render(
      <StoreProvider>
        <InspicioCheckBox {...validationPropsCopy} />
      </StoreProvider>,
    );
    const inspicioCheckbox = screen.getByText('Enter MDN to send text Message*');
    expect(inspicioCheckbox).toBeInTheDocument();
  });

  test('render Input component', () => {
    const validationPropsCopy = { ...validationProps, state: { ...validationProps.state, mtn: [] } };
    render(
      <StoreProvider>
        <InspicioCheckBox {...validationPropsCopy} />
      </StoreProvider>,
    );
    const inspicioMDNInput = screen.getByTestId('inspicioMDNInput');
    expect(inspicioMDNInput).toBeInTheDocument();
  });

  test('Input change event', () => {
    const validationPropsCopy = { ...validationProps, state: { ...validationProps.state, mtn: [] } };
    render(
      <StoreProvider>
        <InspicioCheckBox {...validationPropsCopy} />
      </StoreProvider>,
    );
    const inspicioMDNInput = screen.getByTestId('inspicioMDNInput');
    expect(inspicioMDNInput).toBeInTheDocument();
    fireEvent.change(inspicioMDNInput, { target: { value: '1457851245' } });
  });
});
