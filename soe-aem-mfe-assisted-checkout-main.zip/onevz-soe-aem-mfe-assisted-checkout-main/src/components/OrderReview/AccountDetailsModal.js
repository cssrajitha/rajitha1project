import styled, { createGlobalStyle } from 'styled-components';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { Body, Title } from '@vds/typography';
import { Modal, ModalTitle, ModalBody, ModalFooter } from '@vds/modals';
import PropTypes from 'prop-types';
import { has } from 'lodash';
import { Line } from '@vds/lines';
import { Tooltip } from '@vds/tooltips';
import moment from 'moment';
import { TextLink } from '@vds/buttons';
import { formatCurrency, getPlanDetail } from '../../utils/common';

const ComponentStyle = createGlobalStyle`
  #accountDetailsModal {
    [class^='Overlay-VDS'] {
      background-color: rgba(0, 0, 0, 0.8);
    }
    [class^='ModalDialog-VDS'] {
      max-width:1024px; 
      border-radius: 0;
      padding: 0;
    }
    [class^='ModalDialogWrapper-VDS'] {
        > span {
          width: 100%;
          height: 100%;

        > div {
          width:100% !important;
          height: 100% !important;

          > div {
            padding:0 !important;
          }
        }
      }
    }

    [class^='StyledModalBody-VDS'] {
      height: 80vh;
      padding: 0.7rem 0px 0px;
      overflow: auto;
    }

    [class^='IconWrapper-VDS'] {
      z-index: 99999;
    }
    
    [class^='StyledHeader-VDS'] {
      border-bottom: 1px solid #ccc;
      position: sticky;
      top:0;
      background: #fff;
      z-index: 999;
      padding: 1rem 2rem;
    }
    [class^='StyledFooter-VDS'] {
      border-top: 1px solid #ccc;
      position: sticky;
      bottom:0;
      background: #fff;
      padding-top: 1.5rem;
      padding-bottom: 1.5rem;
    }
  }
`;

const MarginSides = styled.div`
  padding: 0;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
`;

const ModalContentWrapper = styled.div`
  display: flex;
  flex-direction: column;
`;

const AccountContainer = styled.div`
  padding-top: 1.3125rem !important;
  padding-right: 1.3125rem !important;
  padding-bottom: 1.3125rem !important;
  padding-left: 1.3125rem !important;
`;

const PlanFooter = styled.div`
  padding-top: 20px;
  padding-bottom: 20px;
`;

const PlanTitle = styled.div`
  padding-bottom: 20px;
`;

const TileWrapper = styled.div`
  display: flex;
  width: 100%;
`;
const TileItems = styled.div`
  flex-basis: 50%;
  padding: 1.75rem;
  background-color: ${(props) => props.backgroundColor && '#f6f6f6'};
`;

const PlanContent = styled.div`
  display: flex;
  justify-content: space-between;
  padding-top: 10px;
  padding-bottom: 10px;
`;

const InfoIconContainer = styled.div`
  display: flex;
  align-items: center;
  margin-top: 5px;
  & .discount-price {
    margin-left: 20px;
  }
`;

const OrderLabelText = styled.div`
  width: 70%;
`;

const ChangeLink = styled(TextLink)`
  font-weight: bold;
  letter-spacing: normal;
`;

const NewPlanContainer = styled.div`
  display: flex;
  width: 100%;
  margin: 30px;
`;

const NewPlanRightSection = styled.div`
  width: calc(100% - 170px);
  margin-left: 20px;
  ul {
    list-style: none;
    padding-left: 0;
    margin: 1rem 0;
  }
  li {
    margin: 5px 0;
  }
`;

const ImageContainer = styled.div`
  height: 75px;
  width: 75px;
  img {
    max-width: 75px;
  }
`;

const AccountDetailsModal = ({
  opened,
  lineInfo = [],
  isPrepay = false,
  toggleModal,
  mtn,
  cart,
  planReferences = [],
}) => {
  const [isLandingRedesignFlow] = getAssistedCradlePropertyV2(['isLandingRedesignFlow']);
  const effectiveDate = cart.orderDetails.effectiveDateDetails.selectedDate;
  const getOrderEffectiveDate = () => {
    const now = moment().format('MM/DD/YYYY');
    const eDate = moment(effectiveDate).format('MM/DD/YYYY');
    return {
      isFutureDate: moment(now).isBefore(moment(eDate)),
      isPastDate: moment(now).isAfter(moment(eDate)),
    };
  };
  const orderEffectiveDate = getOrderEffectiveDate();

  const getAccPlanLine = (lineInfoDetails) => lineInfoDetails?.find((line) => hasSelectedALPShare(line));

  const hasSelectedALPShare = (line) =>
    (has(line, 'serviceInfo.selectedALPShareList.alpShareInfo') &&
      line.serviceInfo.selectedALPShareList.alpShareInfo.length > 0) ||
    (has(line, 'serviceInfo.selectedALPShareList.newAlpShareInfo') &&
      line.serviceInfo.selectedALPShareList.newAlpShareInfo.length > 0);

  const getSharedDiscountFeature = () => {
    const lineWithSharedFeature = lineInfo?.find(
      (line) =>
        has(line, 'serviceInfo.selectedFeaturesList.visFeature') &&
        line.serviceInfo.selectedFeaturesList.visFeature.length > 0 &&
        line.lineActivityType !== 'FEA' &&
        line.serviceInfo.selectedFeaturesList.visFeature.some((feature) => feature.level && feature.level === 'A'),
    );
    const visFeatures =
      has(lineWithSharedFeature, 'serviceInfo.selectedFeaturesList.visFeature') &&
      lineWithSharedFeature.serviceInfo.selectedFeaturesList.visFeature.filter(
        (feature) =>
          feature.level === 'A' &&
          (feature.addDeleteInd === 'Z' || feature.addDeleteInd === 'K') &&
          feature.categoryCodes.includes('DISCPROMO') &&
          feature.categoryCodes.includes('AUTOPAY') &&
          feature.categoryCodes.includes('PAPERFREE') &&
          parseFloat(feature.featurePrice) < 0,
      );
    return visFeatures.length > 0 ? visFeatures[0] : null;
  };

  const planDetail = getPlanDetail(getAccPlanLine(lineInfo));
  const { isCPC, newPlanId, oldPlanId, planDetails } = planDetail || {};

  const planInfo = planReferences || [];
  let newPlan = {};
  let oldPlan = {};
  let planPrice = '';
  let discountedPlanPrice = '';
  let newPlanPrice = '';
  const sharedDiscountFeature = getSharedDiscountFeature();
  if (planInfo && planInfo.length > 0) {
    planInfo.forEach((plan) => {
      const currentPlanId = !oldPlanId ? newPlanId : oldPlanId;
      if (isCPC) {
        if (plan.planId === newPlanId) {
          planPrice = has(plan, 'monthlyAccessCharge') ? plan.monthlyAccessCharge : '';
          discountedPlanPrice = has(planDetails, 'discountedPrice') ? planDetails.discountedPrice : '';
          newPlanPrice =
            discountedPlanPrice !== '' && planPrice !== discountedPlanPrice ? discountedPlanPrice : planPrice;
          newPlan = plan;
        } else if (plan.planId === oldPlanId) {
          oldPlan = plan;
        }
      } else if (plan.planId === currentPlanId) {
        planPrice = has(plan, 'monthlyAccessCharge') ? plan.monthlyAccessCharge : '';
        discountedPlanPrice = has(planDetails, 'discountedPrice') ? planDetails.discountedPrice : '';
        newPlanPrice =
          discountedPlanPrice !== '' && planPrice !== discountedPlanPrice ? discountedPlanPrice : planPrice;
        newPlan = plan;
      }
    });
  }
  const promos = has(planDetails, 'planPromotions.promos') ? planDetails.planPromotions.promos : [];

  const changePlan = () => {
    const isPlansMFEEnabled = JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.isPlansMFEEnabled === 'TRUE';
    if (isPrepay) {
      window.location.href = `/sales/assisted/shop-plans.html`;
    } else if (isPlansMFEEnabled) {
      window.location.href = `/sales/assisted/new/gridwall.html?activeMtn=${mtn}&isPlanTabSelect=true`;
    } else {
      window.location.href = `/sales/assisted/plan-selection.html`;
    }
  };

  const changeEffectiveDate = () => {
    if (isLandingRedesignFlow === 'TRUE') {
      window.location.href = `/sales/assisted/landing.html`;
    } else {
      window.location.href = `/sales/assisted/home.html`;
    }
  };

  const getOrderDetailLabel = () => {
    if (orderEffectiveDate.isFutureDate) return 'Your new plan will take effect on : ';
    if (orderEffectiveDate.isPastDate) return 'Your new plan has been activated and backdated to : ';
    return 'Your new plan will take effect on : ';
  };

  const planDiscount = (featureTotal, discountedPrice) => (
    <div className='u-text15'>
      <PlanContent>
        <div>Retail Price</div>
        <Body size='large' bold>
          {formatCurrency(featureTotal)}
        </Body>
      </PlanContent>
      {promos?.map(({ description, amountOff }) => (
        <PlanContent key={description}>
          <div>{description}</div>
          <Body size='large' bold>
            -{formatCurrency(amountOff)}
          </Body>
        </PlanContent>
      ))}
      <PlanContent>
        <Body size='large' bold>
          Discounted Price
        </Body>
        <Body size='large' bold>
          {formatCurrency(discountedPrice || featureTotal)}
        </Body>
      </PlanContent>
    </div>
  );

  return (
    <>
      <ComponentStyle />
      <div data-testId='accountDetailsModal'>
        <Modal
          id='accountDetailsModal'
          opened={opened}
          fullScreenDialog
          surface='light'
          onOpenedChange={toggleModal}
          disableAnimation={false}
          disableOutsideClick={false}
          width='100%'
        >
          <MarginSides>
            <ModalTitle>
              <Title size='small' bold>
                Plan ( {getTitlePrice()} / monthly)
              </Title>
            </ModalTitle>
            <ModalBody>
              <ModalContentWrapper>
                <div className='plan-details '>
                  <div className='custom-modal-body'>
                    {isCPC && renderAccountContainer()}
                    {!isCPC && newPlan && renderNewPlanContainer()}
                  </div>
                </div>
              </ModalContentWrapper>
            </ModalBody>
            <ModalFooter
              buttonData={{
                primary: {
                  children: 'Done',
                  width: '225px',
                  onClick: () => toggleModal(false),
                },
                close: {
                  children: 'Change Plan',
                  width: '225px',
                  onClick: () => changePlan(),
                },
              }}
            />
          </MarginSides>
        </Modal>
      </div>
    </>
  );

  function getTitlePrice() {
    const titlePrice = has(newPlan, 'monthlyAccessCharge') ? getMonthlyCharge() : formatCurrency('');
    return titlePrice;
  }

  function getMonthlyCharge() {
    return has(sharedDiscountFeature, 'featurePrice')
      ? formatCurrency(newPlan.monthlyAccessCharge + Number(sharedDiscountFeature.featurePrice))
      : formatCurrency(newPlan.monthlyAccessCharge);
  }

  function renderAccountContainer() {
    return (
      <AccountContainer>
        <Body size='large' bold>
          Account
        </Body>
        <TileWrapper>
          <TileItems>
            {oldPlan && (
              <>
                <PlanTitle>
                  <Body size='large' bold>
                    Old plan
                  </Body>
                </PlanTitle>
                <Line type='secondary' />
                <PlanContent>
                  <img
                    alt=''
                    src={has(oldPlan, 'image') ? `https://ss7.vzw.com/is/image/VerizonWireless/${oldPlan.image}` : ''}
                    style={{ maxHeight: '150px' }}
                  />
                  <div>
                    <Body size='large' bold>
                      {' '}
                      {has(oldPlan, 'description') ? oldPlan.description : ' '}
                    </Body>
                    <div
                      dangerouslySetInnerHTML={{
                        __html: newPlan.displayName ? newPlan.displayName : '',
                      }}
                    />
                  </div>
                  <Body size='large' bold>
                    {formatCurrency(has(oldPlan, 'monthlyAccessCharge') ? oldPlan.monthlyAccessCharge : '')}
                  </Body>
                </PlanContent>
                <PlanContent>
                  <div />
                  <div>Retail Price</div>
                  <Body size='large' bold>
                    {formatCurrency(has(oldPlan, 'monthlyAccessCharge') ? oldPlan.monthlyAccessCharge : '')}
                  </Body>
                </PlanContent>
                <Line type='secondary' />
                <PlanFooter>
                  <Body size='large' bold>
                    Includes
                  </Body>
                  <div
                    dangerouslySetInnerHTML={{
                      __html: has(oldPlan, 'featureText') ? oldPlan.featureText : '',
                    }}
                  />
                </PlanFooter>
                <Line type='secondary' />

                {has(oldPlan, 'dataOverageAllowance') && (
                  <PlanFooter>
                    {`Overages are ${formatCurrency(oldPlan.dataOverateAmount)} per ${
                      oldPlan.dataOverageAllowance
                    }${' '}${oldPlan.dataUnitOfMeasure} of data.`}
                  </PlanFooter>
                )}
              </>
            )}
          </TileItems>
          <TileItems backgroundColor>
            <PlanTitle>
              <Body size='large' bold>
                New plan
              </Body>
            </PlanTitle>
            <Line type='secondary' />
            {newPlan && (
              <>
                <PlanContent>
                  <ImageContainer>
                    <img
                      src={has(newPlan, 'image') ? `https://ss7.vzw.com/is/image/VerizonWireless/${newPlan.image}` : ''}
                      alt=''
                    />
                  </ImageContainer>
                  <div>
                    <Body size='large' bold>
                      {has(newPlan, 'description') ? newPlan.description : ' '}
                    </Body>
                    <div
                      dangerouslySetInnerHTML={{
                        __html: newPlan.displayName ? newPlan.displayName : '',
                      }}
                    />
                  </div>
                  <Body size='large' bold>
                    {formatCurrency(has(newPlan, 'monthlyAccessCharge') ? newPlan.monthlyAccessCharge : '')}
                  </Body>
                </PlanContent>

                {planPrice === newPlanPrice ? (
                  <PlanContent>
                    <div />
                    <div>Retail Price</div>
                    <Body size='large' bold>
                      {formatCurrency(newPlanPrice)}
                    </Body>
                  </PlanContent>
                ) : (
                  <PlanContent>
                    <div />
                    <div>Discounted Price</div>
                    <InfoIconContainer>
                      <Tooltip placement='left' size='medium' surface='light'>
                        {planDiscount(planPrice, newPlanPrice)}
                      </Tooltip>
                      <div className='discount-price'>
                        <Body size='large' bold>
                          {formatCurrency(discountedPlanPrice)}
                        </Body>
                      </div>
                    </InfoIconContainer>
                  </PlanContent>
                )}
              </>
            )}
            <Line type='secondary' />
            <PlanFooter>
              <Body size='large' bold>
                Includes
              </Body>
              <div>
                {newPlan && (
                  <div
                    dangerouslySetInnerHTML={{
                      __html: has(newPlan, 'featureText') ? newPlan.featureText : '',
                    }}
                  />
                )}
              </div>
            </PlanFooter>
            <Line type='secondary' />

            {has(newPlan, 'dataOverageAllowance') && (
              <PlanFooter>
                {`Overages are ${formatCurrency(newPlan.dataOverateAmount)} per ${newPlan.dataOverageAllowance}${' '}${
                  newPlan.dataUnitOfMeasure
                } of data.`}
              </PlanFooter>
            )}
            <PlanContent>
              <OrderLabelText>
                <div>{getOrderDetailLabel()}</div>
                <span>{effectiveDate}</span>
              </OrderLabelText>
              <ChangeLink
                type='standAlone'
                data-testid='change-date'
                surface='light'
                disabled={false}
                size='medium'
                onClick={() => changeEffectiveDate()}
              >
                Change
              </ChangeLink>
            </PlanContent>
          </TileItems>
        </TileWrapper>
      </AccountContainer>
    );
  }

  function renderNewPlanContainer() {
    const monthlyCharge = has(newPlan, 'monthlyAccessCharge') ? getMonthlyCharge() : formatCurrency('');

    return (
      <NewPlanContainer>
        <div>
          <img
            src={has(newPlan, 'image') ? `https://ss7.vzw.com/is/image/VerizonWireless/${newPlan.image}` : ''}
            alt=''
            width='70'
          />
        </div>
        <NewPlanRightSection>
          <PlanContent>
            <Body size='large' bold>
              {has(newPlan, 'description') ? newPlan.description : ' '}
            </Body>
            <div />
          </PlanContent>
          <PlanContent>
            <Body size='medium' bold>
              <div
                dangerouslySetInnerHTML={{
                  __html: newPlan.displayName ? newPlan.displayName : '',
                }}
              />
            </Body>
            <div />
          </PlanContent>

          {planPrice === newPlanPrice ? (
            <>
              <PlanContent>
                <div>Retail Price</div>
                <Body size='large' bold>
                  {monthlyCharge} /month
                </Body>
              </PlanContent>
              <Line type='secondary' />
            </>
          ) : (
            <>
              <PlanContent>
                <div>Discounted Price</div>
              </PlanContent>
              <Line type='secondary' />
            </>
          )}
          <PlanFooter>
            <Body size='large' bold>
              Includes
            </Body>
            <div>
              {newPlan && (
                <div
                  dangerouslySetInnerHTML={{
                    __html: has(newPlan, 'featureText') ? newPlan.featureText : '',
                  }}
                />
              )}
            </div>
          </PlanFooter>
          <Line type='secondary' />

          {has(newPlan, 'dataOverageAllowance') &&
            newPlan.dataOverateAmount !== 0 &&
            newPlan.dataOverageAllowance !== '9999' && (
              <PlanFooter>
                {`Overages are ${formatCurrency(newPlan.dataOverateAmount)} per ${newPlan.dataOverageAllowance}${' '}${
                  newPlan.dataUnitOfMeasure
                } of data.`}
              </PlanFooter>
            )}
        </NewPlanRightSection>
      </NewPlanContainer>
    );
  }
};
AccountDetailsModal.propTypes = {
  opened: PropTypes.object,
  toggleModal: PropTypes.func,
  isPrepay: PropTypes.bool,
  lineInfo: PropTypes.object,
  mtn: PropTypes.string,
  cart: PropTypes.object,
  planReferences: PropTypes.object,
};

export default AccountDetailsModal;
