import { fireEvent, render, screen } from '@testing-library/react';
import AccessoryFinanceOption from './AccessoryFinanceOption';
import * as ViewTogetherApiCallHook from '../../modules/services/APIService/ViewTogetherApiCallHook';

const mocckFunc = jest.fn();
const mockData = {
  requestBodyGenerateInspicioId: mocckFunc,
  getResultGenerateInspicioId: { data: {} },
  requestBodySendMessage: mocckFunc,
  getResultSendMessage: { data: {} },
  requestBodySendEmail: mocckFunc,
  getResultSendEmail: { data: {} },
};

const props = {
  customerMtns: ['123456789', '147852369', '753912864'],
  showRepGuidedScreen: true,
  setShowRepGuidedScreen: mocckFunc,
  setVerizonVisaCardLinkSent: mocckFunc,
  cartDetailsResult: {
    cart: {
      cartHeader: {
        cartCreatorChannelId: 'OMNI-RETAIL',
        cartCreator: '7046545112',
        caseId: 'SOP-17628215-E01',
      },
      orderDetails: {
        accessoryFinancingOfferInfo: {
          disclosureAgreementSent: false,
        },
      },
      lineDetails: {
        lineInfo: [
          {
            itemsInfo: [
              {
                shipping: {
                  firstName: 'Sample anme',
                  email: 'sample@verizon.com,',
                },
              },
            ],
          },
        ],
      },
    },
    meta: {
      cxpCorrelationId:
        -'ick-ClrSuZPeM-UmBI-2SFB6t1zB_dFDy3IfCcConCuwmPSIXyrD!1375284084!obsneocgzap08!5106!-1!1564408961747',
      timestamp: '2019-07-29T10:25:59.791-04:00',
    },
  },
  getCartDetailsDataBody: mocckFunc,
};

describe('Accessory finance', () => {
  window.mfe={scmCheckoutMfeEnable:true};
  test('resend button clicked', () => {
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData);
    render(<AccessoryFinanceOption {...props} />);
    const resendButton = screen.getByText('Re-send');
    expect(resendButton).toBeInTheDocument();
    fireEvent.click(resendButton);
  });
  test('xcontinue btn clicked', () => {
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData);
    render(<AccessoryFinanceOption {...props} />);
    const continueButton = screen.getByText('Continue');
    expect(continueButton).toBeInTheDocument();
    fireEvent.click(continueButton);
  });

  test('dropdown clicked', () => {
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData);
    render(<AccessoryFinanceOption {...props} />);
    const dropdown = screen.getByTestId('reason-dropdown');
    expect(dropdown).toBeInTheDocument();
    fireEvent.change(dropdown);
  });

  test('dropdown clicked', () => {
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData);
    render(<AccessoryFinanceOption {...props} />);
    const minusIcon = screen.getByTestId('charges-minus');
    expect(minusIcon).toBeInTheDocument();
    fireEvent.click(minusIcon);
  });
  test('isDark true', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] ,isDark: true, themeProps: {background: '#eeeeee'}};
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData);
    render(<AccessoryFinanceOption {...props} />);
    const minusIcon = screen.getByTestId('charges-minus');
    expect(minusIcon).toBeInTheDocument();
    fireEvent.click(minusIcon);
  });
});

describe('Accessory finance1', () => {
  window.mfe={scmCheckoutMfeEnable:false};
  test('xcontinue btn clicked', () => {
    jest.spyOn(ViewTogetherApiCallHook, 'default').mockImplementation(() => mockData);
    render(<AccessoryFinanceOption {...props} />);
    const continueButton = screen.getByText('Continue');
    expect(continueButton).toBeInTheDocument();
    fireEvent.click(continueButton);
  });
});
