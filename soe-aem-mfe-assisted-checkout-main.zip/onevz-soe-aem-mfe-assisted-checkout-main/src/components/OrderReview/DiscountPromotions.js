import PropTypes from 'prop-types';
import styled from 'styled-components';
import { has } from 'lodash';
import { formatCurrency } from '../../utils/common';
import PriceInfo from './PriceInfo';
import { humDeviceConstants } from '../../appconfig';

const TelematicsHeading = styled.div`
  font-family: BrandFontBold, Sans-serif !important;
  font-size: 18px;
  font-weight: bold;
  padding-bottom: 0.4375rem;
`;

const TelematicsMainWrapper = styled.div`
  padding-right: 0.875rem;
  padding-left: 0.875rem;
`;

const PaddingBotomWrapper = styled.div`
  padding-bottom: 0.4375rem;
`;

const TelematicsDesp = styled.div`
  font-family: BrandFont-Text, Arial, sans-serif !important;
  font-size: 12px;
`;

const DiscountPromotions = ({ fetchPriceSnapshot, isPrepay, cartItem, lineData }) => {
  let lineFeaturesInfo = [];
  const isFromReadOrder = sessionStorage.getItem('readOrder');
  fetchPriceSnapshot?.map((lineFeatures) => {
    lineFeaturesInfo = lineFeatures?.addons?.filter(
      (addon) => addon?.isDisplayable && (addon?.isPromoDiscount || addon?.isPlanDiscount),
    );
    return lineFeaturesInfo;
  });

  const lineLevelPromotions = [];
  lineFeaturesInfo?.map((item) =>
    lineLevelPromotions.push({
      payment: item?.skuName,
      price: formatCurrency(item?.price?.discountedPrice),
      description: item?.description,
    }),
  );

  return (
    <div data-testId='discountPromotions'>
      {!isPrepay && lineLevelPromotions && lineLevelPromotions.length > 0 && (
        <PriceInfo
          line
          title='Discounts and promotions'
          info={lineLevelPromotions}
          hideMonthly
          readOrder={isFromReadOrder}
        />
      )}
      {has(lineData, 'lineActivityType') &&
      lineData?.lineActivityType !== 'CPC' &&
      cartItem?.description?.toLowerCase().indexOf('hum') !== -1 ? (
        <TelematicsMainWrapper>
          <TelematicsHeading>{humDeviceConstants.telematics}</TelematicsHeading>
          <PaddingBotomWrapper>
            <TelematicsDesp>{humDeviceConstants.vehicleInfo}</TelematicsDesp>
            <TelematicsDesp>{`${cartItem.year} ${cartItem.make} ${cartItem.model} ${
              cartItem.connectedCarColor ? cartItem.connectedCarColor : 'NA'
            } `}</TelematicsDesp>
          </PaddingBotomWrapper>
          <PaddingBotomWrapper>
            <TelematicsDesp>{humDeviceConstants.emailAddress}</TelematicsDesp>
            <TelematicsDesp>{`${cartItem.connectedCarEmailAddress} `}</TelematicsDesp>
          </PaddingBotomWrapper>
          <PaddingBotomWrapper>
            <TelematicsDesp>{humDeviceConstants.registeredMtn}</TelematicsDesp>
            <TelematicsDesp>{cartItem.connectedCarMobile ? cartItem.connectedCarMobile : 'NA'}</TelematicsDesp>
          </PaddingBotomWrapper>
        </TelematicsMainWrapper>
      ) : (
        ''
      )}
    </div>
  );
};

DiscountPromotions.propTypes = {
  fetchPriceSnapshot: PropTypes.object,
  isPrepay: PropTypes.bool,
  cartItem: PropTypes.array,
  lineData: PropTypes.object,
};

export default DiscountPromotions;
