import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import StoreTradein from './StoreTradein';
import { useLazyGetStoreTradeInformationQuery } from '../../modules/services/APIService/APIServiceHooks';

jest.mock('../../utils/common', () => ({
  isEnabledTradeReturnOptionsInContactCenterApps: () => true, // Mock to return true
  isSDDInCart: () => false, // Mock to return false
}));
// Mock the API hook
jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  useLazyGetStoreTradeInformationQuery: jest.fn(),
}));

jest.mock('@vds/modals', () => ({
  ...jest.requireActual('@vds/modals'),
  // eslint-disable-next-line react/button-has-type, react/prop-types
  Modal: ({ children, ...props }) => (
    // eslint-disable-next-line react/prop-types
    <div {...props} data-testid={props.id}>
      {children}
    </div>
  ),
}));

jest.mock('onevzsoemfecommon/APIService', () => ({
  useLazyGetManagerApprovalQuery: jest.fn(),
  useLazyGetFetchDownpaymentQuery: jest.fn(),
  useLazyLovupdatecaseQuery: jest.fn(),
  useAddRemoveAccessoriesMutation: () => ({
    addAccessories: jest.fn(),
    addAccessoriesSuccess: jest.fn(),
  }),
}));

describe('StoreTradein Component', () => {
  const mockStoreInfoReq = jest.fn();
  const mockStoreInfoResponse = {
    isSuccess: true,
    data: {
      data: {
        storeInformation: {
          storeName: 'Test Store',
          address1: '123 Test St',
          city: 'Test City',
          state: 'TS',
          phoneNumber: '123-456-7890',
          hoursMon: '10:00 AM 07:00 PM',
          hoursTue: '10:00 AM 07:00 PM',
          hoursWed: '10:00 AM 07:00 PM',
          hoursThu: '10:00 AM 07:00 PM',
          hoursFri: '10:00 AM 07:00 PM',
          hoursSat: '10:00 AM 07:00 PM',
          hoursSun: '11:00 AM 06:00 PM',
        },
      },
    },
  };

  beforeEach(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;

    useLazyGetStoreTradeInformationQuery.mockReturnValue([mockStoreInfoReq, mockStoreInfoResponse]);
    sessionStorage.setItem('customerType', 'BUSINESS');
    sessionStorage.setItem('channel', 'OMNI-RETAIL-CHANNEL');
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        enableReturnAnywhereAssisted: 'TRUE',
        blockRTSForBEWithoutEcpdCustomers: 'TRUE',
        enableReturnOptionsForNewCustomerInRetail: 'TRUE',
      }),
    );
  });

  afterEach(() => {
    jest.clearAllMocks();
    sessionStorage.clear();
  });

  it('should call toggleStoreInfoModal when "View store details" is clicked', () => {
    const props = {
      cartDetails: {
        lineDetails: {
          tradeInDetail: {
            tradeInType: 'home',
            tradeInShippingType: 'return_store',
            tradeInItems: [{ preferredStoreId: '123' }],
          },
        },
        cartHeader: { status: 'active' },
      },
    };

    render(<StoreTradein {...props} />);

    // Click the "View store details" link
    fireEvent.click(screen.getByText('View store details'));

    // Check if the modal is opened
  });

  it('should render "Edit location" if cartHeader status is "s"', () => {
    const props = {
      cartDetails: {
        lineDetails: {
          tradeInDetail: {
            tradeInType: 'home',
            tradeInShippingType: 'return_store',
            tradeInItems: [{ preferredStoreId: '123' }],
          },
        },
        cartHeader: { status: 'A' },
      },
    };

    render(<StoreTradein {...props} />);

    // Check that "Edit location" is not rendered
    const editLocation = screen.queryByText('Edit location');
    expect(editLocation).toBeInTheDocument();
    fireEvent.click(editLocation);
  });

  it('should call the API when tradeInItems has a preferredStoreId', () => {
    const props = {
      cartDetails: {
        lineDetails: {
          tradeInDetail: {
            tradeInType: 'home',
            tradeInShippingType: 'return_store',
            tradeInItems: [{ preferredStoreId: '123' }],
          },
        },
      },
    };

    render(<StoreTradein {...props} />);

    // Check if the API was called with the correct payload
    expect(mockStoreInfoReq).toHaveBeenCalledWith({
      body: {
        storeId: '123',
      },
      mock: false,
    });
  });
});

describe('StoreTradein Component Negative scenario', () => {
  const mockStoreInfoReq = jest.fn();
  const mockStoreInfoResponse = {
    isSuccess: true,
    data: {
      data: {
        storeInformation: {
          storeName: 'Test Store',
          address1: '123 Test St',
          city: 'Test City',
          state: 'TS',
          phoneNumber: '123-456-7890',
          hoursMon: '10:00 AM 07:00 PM',
          hoursTue: '10:00 AM 07:00 PM',
          hoursWed: '10:00 AM 07:00 PM',
          hoursThu: '10:00 AM 07:00 PM',
          hoursFri: '10:00 AM 07:00 PM',
          hoursSat: '10:00 AM 07:00 PM',
          hoursSun: '11:00 AM 06:00 PM',
        },
      },
    },
  };

  beforeEach(() => {
    useLazyGetStoreTradeInformationQuery.mockReturnValue([mockStoreInfoReq, mockStoreInfoResponse]);
    sessionStorage.setItem('customerType', 'n');
    sessionStorage.setItem('channel', 'OMNI-TEL');
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        enableReturnAnywhereAssisted: 'TRUE',
        blockRTSForBEWithoutEcpdCustomers: 'TRUE',
        enableReturnOptionsForNewCustomerInRetail: 'TRUE',
      }),
    );
  });

  afterEach(() => {
    jest.clearAllMocks();
    sessionStorage.clear();
    delete window.mfe;
  });

  it('should call toggleStoreInfoModal when "View store details" is clicked', () => {
    window.mfe = {
      scmCheckoutMfeEnable: true,
      isDark: true,
    };
    const props = {
      cartDetails: {
        lineDetails: {
          tradeInDetail: {
            tradeInType: 'home',
            tradeInShippingType: 'return_store',
            tradeInItems: [{ preferredStoreId: '123' }],
          },
        },
        cartHeader: { status: 'active' },
      },
    };

    render(<StoreTradein {...props} />);

    // Click the "View store details" link
    fireEvent.click(screen.getByText('View store details'));

    // Check if the modal is opened
  });
});

describe('StoreTradein Component Negative scenario with vb data', () => {
  const mockStoreInfoReq = jest.fn();
  const mockStoreInfoResponse = {
    isSuccess: true,
    data: {
      data: {
        storeInformation: {
          storeName: 'Test Store',
          address1: '123 Test St',
          city: 'Test City',
          state: 'TS',
          phoneNumber: '123-456-7890',
          hoursMon: '10:00 AM 07:00 PM',
          hoursTue: '10:00 AM 07:00 PM',
          hoursWed: '10:00 AM 07:00 PM',
          hoursThu: '10:00 AM 07:00 PM',
          hoursFri: '10:00 AM 07:00 PM',
          hoursSat: '10:00 AM 07:00 PM',
          hoursSun: '11:00 AM 06:00 PM',
        },
      },
    },
  };

  beforeEach(() => {
    useLazyGetStoreTradeInformationQuery.mockReturnValue([mockStoreInfoReq, mockStoreInfoResponse]);
    sessionStorage.setItem('customerType', 'N');
    sessionStorage.setItem('channel', 'OMNI-TEL');
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        enableReturnAnywhereAssisted: 'TRUE',
        blockRTSForBEWithoutEcpdCustomers: 'TRUE',
        enableReturnOptionsForNewCustomerInRetail: 'TRUE',
      }),
    );
  });

  afterEach(() => {
    jest.clearAllMocks();
    sessionStorage.clear();
  });

  it('billingsystem is vb', () => {
    const props = {
      cartDetails: {
        lineDetails: {
          tradeInDetail: {
            tradeInType: 'home',
            tradeInShippingType: 'return_store',
            tradeInItems: [{ preferredStoreId: '123' }],
          },
        },
        cartHeader: { status: 'active' },

        orderDetails: {
          billingSystem: 'vb',
        },
      },
    };

    render(<StoreTradein {...props} />);
  });
});
