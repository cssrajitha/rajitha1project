import { fireEvent, render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../modules/store';
import retriveCartJson from '../../__mock__/newcustomer-retriveCart.json';
import PaperlessBilling from './PaperlessBilling';

describe('PaperlessBilling Component', () => {
  beforeEach(() => {
    Object.defineProperty(window, 'location', {
      value: {
        pathname: '/read-order.html',
      },
      configurable: true,
    });
  });

  const mockFn = jest.fn();

  const props = {
    cart: retriveCartJson.data,
    setPaperLessBilling: mockFn,
    setUpdatedEmail: mockFn,
  };

  test('renders PaperlessBilling', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <PaperlessBilling {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByText(/Enroll in paper free billing/i);
    expect(titleElement).toBeInTheDocument();
  });

  test('If readorder then trigger API call ', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <PaperlessBilling
            {...props}
            cart={{
              ...retriveCartJson.data,
              cart: {
                ...retriveCartJson.data.cart,
                orderDetails: {
                  ...retriveCartJson.data.cart.orderDetails,
                  customerType: 'Y',
                  orderChannelId: 'OMNI-INDIRECT',
                },
              },
            }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const paperLessCheckbox = screen.getByText('Enroll in paper free billing');
    fireEvent.click(paperLessCheckbox);
  });

  test('On click of edit functionality ', () => {
    delete window.location.pathname;
    render(
      <BrowserRouter>
        <StoreProvider>
          <PaperlessBilling {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const editBtn = screen.getByRole('button', { name: 'Edit' });
    fireEvent.click(editBtn);
    const email = 'VQNROOVI70@VZW.COM';
    const emailValidationInput = screen.getByTestId('paperless-test');
    fireEvent.change(emailValidationInput, { target: { value: '' } });
    fireEvent.change(emailValidationInput, { target: { value: email } });

    const doneBtn = screen.getByRole('button', { name: 'Done' });
    fireEvent.click(doneBtn);
  });

  test('On Click of checkbox functionlaity', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <PaperlessBilling {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const paperLessCheckbox = screen.getByText('Enroll in paper free billing');
    fireEvent.click(paperLessCheckbox);
  });

  test('On Click of checkbox functionlaity for new customer flow -cutomerType N', () => {
    const newCustomerProps = { ...props };
    newCustomerProps.cart.cart.orderDetails.customerType = 'N';
    render(
      <BrowserRouter>
        <StoreProvider>
          <PaperlessBilling {...newCustomerProps} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const paperLessCheckbox = screen.getByText('Enroll in paper free billing');
    fireEvent.click(paperLessCheckbox);
  });
});
