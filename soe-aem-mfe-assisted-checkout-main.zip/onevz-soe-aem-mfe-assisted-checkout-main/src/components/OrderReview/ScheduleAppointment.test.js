import React from 'react';
import { fireEvent, render, screen, waitFor } from '../../utils/test-utils/renderHelper';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import ScheduleAppointment from './ScheduleAppointment';
import * as AppointmentAPICallHook from '../../modules/services/APIService/AppointmentAPICallHook';
import { mockget5GAppointments, retriveCartJson } from './__mock__/mockScheduleAppointment';

const dt = new Date();
dt.setDate(dt.getDate() + 4);

const selectedYear = dt.getFullYear();
const selectedMonth = dt.getMonth();
const selectedDate = dt.getDate();
const date = new Date(selectedYear, selectedMonth, selectedDate);

jest.mock('../../modules/services/APIService/AppointmentAPICallHook', () => ({
  __esModule: true,
  default: jest.fn(() => ({
    get5GAppointments: jest.fn(),
    get5GAppointmentsResult: mockget5GAppointments,
    save5GAppointment: jest.fn(),
    save5GAppointmentResult: { data: { appointmentUpdated: true, updateMessage: 'SUCCESS' } },
  })),
}));
const mockData = {
  get5GAppointments: jest.fn(),
  get5GAppointmentsResult: {},
  save5GAppointment: jest.fn(),
  save5GAppointmentResult: { data: { appointmentUpdated: true, updateMessage: 'SUCCESS' } },
};
const mockCloseAppointment = jest.fn();

const defaultProps = {
  showscheduleAppointmentModal: true,
  setShowScheduleAppointmentModal: jest.fn(),
  lineInfo: retriveCartJson().data.cart.lineDetails.lineInfo,
  cartHeader: retriveCartJson().data.cart.cartHeader,
  closeAppointment: mockCloseAppointment,
};

const testEnvironment = async (isIpad) => {
  render(<ScheduleAppointment {...defaultProps} isIpad={isIpad} />, {
    reducers: rootReducer,
    sagas: rootSaga,
  });
  const ipadBtn = screen.getByTestId('ipad-btn');

  expect(ipadBtn).toBeInTheDocument();
  fireEvent.click(ipadBtn);
};

describe('ScheduleAppointment Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
    window.sessionStorage.setItem('acssMfeCartId', '9f2de639-ec62-488c-8512-05e19eb3762e');
    window.mfe = { scmUpgradeMfeEnable: true };
  });
  beforeEach(() => {
    AppointmentAPICallHook.default.mockImplementation(() => {
      const mockResult = { ...mockData, get5GAppointmentsResult: mockget5GAppointments };
      return mockResult;
    });
    render(<ScheduleAppointment {...defaultProps} isIpad={false} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  const setupCommonActions = async () => {
    const datePicker = screen.getByTestId('followUpDate');
    fireEvent.click(datePicker);
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const monthName = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];

    await waitFor(() => {
      const dateString = `${dayNames[date.getDay()]}, ${
        monthName[date.getMonth()]
      } ${date.getDate()}, ${date.getFullYear()}`;
      const selectedDateBtn = screen.getByRole('button', { name: dateString });
      fireEvent.click(selectedDateBtn);
    });

    const preferredContactMethod = screen.getByTestId('preferred-contact-method');
    fireEvent.change(preferredContactMethod, { target: { value: 'Email' } });
    await waitFor(() => {
      const timeSlotDropdown = screen.getByTestId('time-slot-dropdown');
      fireEvent.change(timeSlotDropdown, { target: { value: '8AM - 10AM' } });
    });

    const continueButton = screen.getByTestId('continue-btn');
    expect(continueButton).not.toBeDisabled();
    fireEvent.click(continueButton);
  };

  it('renders the component with initial elements', () => {
    expect(screen.getByText('Schedule Appointment')).toBeInTheDocument();
    expect(screen.getByText('View availability')).toBeInTheDocument();
  });

  it('calls close function on close icon click', () => {
    const closeButton = screen.getByTestId('close-btn-icon');
    fireEvent.click(closeButton);
    expect(defaultProps.setShowScheduleAppointmentModal).toHaveBeenCalledWith(false);
  });

  it('updates primary phone field and validates input', () => {
    const primaryPhone = screen.getByTestId('primaryPhone');
    fireEvent.change(primaryPhone, { target: { value: 'Mobile' } });
    const primaryMdnInput = screen.getByTestId('primaryMdn');
    fireEvent.change(primaryMdnInput, { target: { value: '1234567890' } });
    expect(primaryMdnInput.value).toBe('1234567890');
  });

  it('click on link for desktop', () => {
    const link = screen.getByTestId('appointment-url-link');
    fireEvent.click(link);
  });

  it('click on back button', () => {
    const backButton = screen.getByTestId('btn-back');
    fireEvent.click(backButton);
  });

  it('change some values', () => {
    const secondaryPhone = screen.getByTestId('secondaryPhone');
    fireEvent.change(secondaryPhone, { target: { value: 'Home' } });
    const secondaryMdnInput = screen.getByTestId('secondaryMdn');
    fireEvent.change(secondaryMdnInput, { target: { value: '1234567890' } });
    expect(secondaryMdnInput.value).toBe('1234567890');
    fireEvent.change(secondaryPhone, { target: { value: 'Select' } });

    const emailInput = screen.getByTestId('emailInput');
    fireEvent.change(emailInput, { target: { value: 'test@gmail.com' } });
    expect(emailInput.value).toBe('test@gmail.com');

    const preferredcontactMethod = screen.getByTestId('preferred-contact-method');
    fireEvent.change(preferredcontactMethod, { target: { value: 'Email' } });

    const instructionsInput = screen.getByTestId('special-instructions');
    fireEvent.change(instructionsInput, { target: { value: 'test' } });
    expect(instructionsInput.value).toBe('test');
  });

  it('invalid email', () => {
    const emailInput = screen.getByTestId('emailInput');
    fireEvent.change(emailInput, { target: { value: 'test' } });
    expect(emailInput.value).toBe('test');
    expect(screen.getByText('Please enter valid email')).toBeInTheDocument();
  });

  it('enables and clicks the continue button after setting required fields', async () => {
    const datePicker = screen.getByTestId('followUpDate');
    fireEvent.click(datePicker);
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const monthName = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];

    await waitFor(() => {
      const dateString = `${dayNames[date.getDay()]}, ${monthName[selectedMonth]} ${selectedDate}, ${selectedYear}`;
      const selectedDateBtn = screen.getByRole('button', { name: dateString });
      fireEvent.click(selectedDateBtn);
    });

    const preferredcontactMethod = screen.getByTestId('preferred-contact-method');
    fireEvent.change(preferredcontactMethod, { target: { value: 'Email' } });
    await waitFor(() => {
      const timeSlotDropdown = screen.getByTestId('time-slot-dropdown');
      fireEvent.change(timeSlotDropdown, { target: { value: '8AM - 10AM' } });
    });

    const continueButton = screen.getByTestId('continue-btn');
    expect(continueButton).not.toBeDisabled();
    fireEvent.click(continueButton);
  });

  it('enables and clicks the continue button after setting required fields', async () => {
    await setupCommonActions();
  });
  it('processes Work primary and Home secondary phone selections', async () => {
    const primaryPhone = screen.getByTestId('primaryPhone');
    fireEvent.change(primaryPhone, { target: { value: 'Work' } });
    const secondaryPhone = screen.getByTestId('secondaryPhone');
    fireEvent.change(secondaryPhone, { target: { value: 'Home' } });
    const secondaryMdnInput = screen.getByTestId('secondaryMdn');
    fireEvent.change(secondaryMdnInput, { target: { value: '1234567890' } });
    await setupCommonActions();
  });

  it('processes Mobile primary and Work secondary phone selections', async () => {
    const primaryPhone = screen.getByTestId('primaryPhone');
    fireEvent.change(primaryPhone, { target: { value: 'Mobile' } });
    const secondaryPhone = screen.getByTestId('secondaryPhone');
    fireEvent.change(secondaryPhone, { target: { value: 'Work' } });
    const secondaryMdnInput = screen.getByTestId('secondaryMdn');
    fireEvent.change(secondaryMdnInput, { target: { value: '1234567890' } });
    await setupCommonActions();
  });

  it('processes any primary and Mobile secondary phone selections', async () => {
    const primaryPhone = screen.getByTestId('primaryPhone');
    fireEvent.change(primaryPhone, { target: { value: 'Home' } });
    const secondaryPhone = screen.getByTestId('secondaryPhone');
    fireEvent.change(secondaryPhone, { target: { value: 'Mobile' } });
    const secondaryMdnInput = screen.getByTestId('secondaryMdn');
    fireEvent.change(secondaryMdnInput, { target: { value: '1234567890' } });
    await setupCommonActions();
  });
  it('renders correctly on iPad', async () => {
    await testEnvironment(true);
  });

    it('renders Modal with fullScreenDialog=false and width=100% when scmUpgradeMfeEnable is true', () => {
    window.mfe = { scmUpgradeMfeEnable: true };
    render(<ScheduleAppointment {...defaultProps} isIpad={false} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    const modal = document.querySelector('.schedule-Appointment-Modal');
    expect(modal).toBeInTheDocument();
    const computedStyle = window.getComputedStyle(modal);
    expect(computedStyle.width === '100%' || computedStyle.width === '100vw').toBeTruthy();
    expect(modal.className).not.toMatch(/fullscreen/i);
  });

  it('renders Modal with fullScreenDialog=true and width=100% when scmUpgradeMfeEnable is false', () => {
    window.mfe = { scmUpgradeMfeEnable: false };
    render(<ScheduleAppointment {...defaultProps} isIpad={false} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    const modal = document.querySelector('.schedule-Appointment-Modal');
    expect(modal).toBeInTheDocument();
    const computedStyle = window.getComputedStyle(modal);
    expect(computedStyle.width === '100%' || computedStyle.width === '100vw').toBeTruthy();
    expect(modal.className).toContain('schedule-Appointment-Modal');
  });
});
