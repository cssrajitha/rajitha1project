import { render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import Emitter from 'onevzsoemfeframework/Emitter';
import StoreProvider from '../../modules/store';
import ShippingDetailsModal from './ShippingDetailsModal';

jest.mock('onevzsoemfeframework/Emitter', () => ({
  on: jest.fn(),
  off: jest.fn(),
}));

describe('ShippingDetailsModal Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
    global.window = Object.create(window);
  });
  let closeModalMock;
  beforeEach(() => {
    window.mfe = { scmDeviceMfeEnable: true };
    window.mfe.historyRef = jest.fn();
    window.mfe.historyRef.push = jest.fn();
    global.window.mfe = {
      scmCheckoutMfeEnable: true,
      isDark: true,
      themeProps: {
        background: '#000000',
      },
    };
    closeModalMock = jest.fn();
    jest.clearAllMocks();
  });

  test('renders ShippingDetailsModal', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ShippingDetailsModal opened closeModal={closeModalMock} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const modalHeader = screen.getByTestId('shippingDetailsModal');
    expect(modalHeader).toBeInTheDocument();
  });

  test('should call closeModal when CLOSE_SHIPPING_DETAILS_MODAL event is emitted', () => {
    global.window.mfe = {
      scmCheckoutMfeEnable: true,
      isDark: false,
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <ShippingDetailsModal opened closeModal={closeModalMock} />
        </StoreProvider>
      </BrowserRouter>,
    );
    Emitter.on.mock.calls[0][1]();
    expect(closeModalMock).toHaveBeenCalled();
  });
});
