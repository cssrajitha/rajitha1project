import { isIpad } from 'onevzsoemfeframework/DomService';

export const executeDealy = (callback, delay, ...params) =>
  setTimeout(() => {
    callback(...params);
  }, delay);

export const dataSetter = (setData, data, newData) =>
  setData(data?.map((each) => (each?.sorSkuId === newData?.sorSkuId ? newData : each)));

export const getClientAppName = () => {
  const channel = sessionStorage.getItem("channel");
  let clienAppName;
  if (channel === "OMNI-TELESALES" || channel === "CHAT-STORE") {
      clienAppName = "ATG-TELE-ONEPOS";
  } else if (channel === 'OMNI-RETAIL-TAB' || (channel === "OMNI-RETAIL" && isIpad())) {
      clienAppName = "ATG-RTL-NTAB";
  } else if (channel === "OMNI-RETAIL") {
      clienAppName = "ATG-RTL-NETACE";
  } else {
      clienAppName = "ATG-RTL-NETACE";
  }
  return clienAppName;
}
