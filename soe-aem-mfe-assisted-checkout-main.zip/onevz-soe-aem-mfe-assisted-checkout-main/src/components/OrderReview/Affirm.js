import React, { useEffect } from 'react';
import { TextLink } from '@vds/buttons';
import styled from 'styled-components';
import PropTypes from 'prop-types';

const AnchorText = styled(TextLink)`
  [class^='Wrapper-VDS'] {
    font-weight: bold;
  }
  margin-left: 30px;
`;
const affirmConfig = {
  devPublicKey: process.env.REACT_APP_AFFIRM_DEV_PUBLIC_KEY,
  prodPublicKey: process.env.REACT_APP_AFFIRM_PROD_PUBLIC_KEY,
  devScript: process.env.REACT_APP_AFFIRM_DEV_SCRIPT,
  prodScript: process.env.REACT_APP_AFFIRM_PROD_SCRIPT,
};

const Affirm = ({ affirmConfirmationButton, originalPrice = 1 }) => {
  const isProd = sessionStorage.getItem('isProd');
  let public_api_key = '';
  let script = '';
  if (isProd === 'true') {
    public_api_key = affirmConfig ? affirmConfig.prodPublicKey : '';
    script = affirmConfig ? affirmConfig.prodScript : '';
  } else {
    public_api_key = affirmConfig ? affirmConfig.devPublicKey : '';
    script = affirmConfig ? affirmConfig.devScript : '';
  }
  useEffect(() => {
    /* eslint-disable */
    const affirm_config = {
      public_api_key: public_api_key, // Affirm public api key
      script: script,
    };
    (function (l, g, m, e, a, f, b) {
      let d;
      const c = l[m] || {};
      const h = document.createElement(f);
      const n = document.getElementsByTagName(f)[0];
      const k = function (a, b, c) {
        return function () {
          a[b]._.push([c, arguments]);
        };
      };
      c[e] = k(c, e, 'set');
      d = c[e];
      c[a] = {};
      c[a]._ = [];
      d._ = [];
      c[a][b] = k(c, a, b);
      a = 0;
      for (b = 'set add save post open empty reset on off trigger ready setProduct'.split(' '); a < b.length; a++)
        d[b[a]] = k(c, e, b[a]);
      a = 0;
      for (b = ['get', 'token', 'url', 'items']; a < b.length; a++) d[b[a]] = function () {};
      h.async = !0;
      h.src = g[f];
      n.parentNode.insertBefore(h, n);
      delete g[f];
      d(g);
      l[m] = c;
    })(window, affirm_config, 'affirm', 'checkout', 'ui', 'script', 'ready');
    /* eslint-disable */
  }, []);

  return (
    <AnchorText className='affirm-product-modal' data-amount={originalPrice * 100} data-page-type='product'>
      <span>{affirmConfirmationButton}</span>
    </AnchorText>
  );
};

Affirm.propTypes = {
  affirmConfirmationButton: PropTypes.string,
  originalPrice: PropTypes.number,
};

export default Affirm;
