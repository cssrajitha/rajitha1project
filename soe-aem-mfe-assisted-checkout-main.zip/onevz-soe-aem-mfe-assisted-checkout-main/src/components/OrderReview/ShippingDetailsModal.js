import styled, { createGlobalStyle } from 'styled-components';
import { Modal, ModalBody } from '@vds/modals';
import PropTypes from 'prop-types';
import Emitter from 'onevzsoemfeframework/Emitter';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR } from '../constants/constants';
import ShippingDetails from '../../pages/ShippingDetails/container/ShippingDetails';

const ComponentStyle = createGlobalStyle`
  #shippingDetailsModal {
    [class^='Overlay-VDS'] {
      background-color: rgba(0, 0, 0, 0.8);
    }
    [class^='ModalDialog-VDS'] {
      max-width:1064px; 
      border-radius: 0;
      padding: 0;
    }
    [class^='ModalDialogWrapper-VDS'] {
        max-width:${({ scmUpgradeMfeEnable }) => (scmUpgradeMfeEnable ? '1064px' : 'auto')};
        padding-left:${({ scmUpgradeMfeEnable }) => (scmUpgradeMfeEnable ? '0px' : 'auto')};
        > span {
          width: 100%;
          height: 100%;

        > div {
          width:100% !important;
          height: 100% !important;

          > div {
            padding:0 !important;
          }
        }
      }
    }

    [class^='IconWrapper-VDS'] {
      z-index: 99999;
      top: 5px;
      display: none;
    }

    [class^='StyledModalBody-VDS'] {
      height: 80vh;
      padding-top: 3rem;
    }

    [class^='StyledHeader-VDS'] {
      border-bottom: 1px solid #ccc;
      position: sticky;
      top:0;
      z-index: 999;
      padding: 1rem 0;
    }
  }
`;

const MarginSides = styled.div`
  padding: 0 1rem;
`;

const ShippingDetailsModal = ({ opened, closeModal }) => {
  const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable;

  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;
  const bgColor = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.themeProps?.background;

  Emitter.off('CLOSE_SHIPPING_DETAILS_MODAL');
  Emitter.on('CLOSE_SHIPPING_DETAILS_MODAL', () => {
    closeModal();
  });

  return (
    <>
      <ComponentStyle scmUpgradeMfeEnable={scmUpgradeMfeEnable} />
      <div
        data-testId='shippingDetailsModal'
        style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR, backgroundColor: isDark ? bgColor : '' }}
      >
        <Modal
          id='shippingDetailsModal'
          fullScreenDialog
          opened={opened}
          surface={isDark ? 'dark' : 'light'}
          width='100%'
          disableAnimation={false}
          disableOutsideClick={false}
          onOpenedChange={(open) => {
            if (!open) closeModal();
          }}
        >
          <MarginSides>
            <ModalBody surface={isDark ? 'dark' : 'light'}>
              <ShippingDetails closeModal={closeModal} isDark={isDark} />
            </ModalBody>
          </MarginSides>
        </Modal>
      </div>
    </>
  );
};

ShippingDetailsModal.propTypes = {
  opened: PropTypes.object,
  closeModal: PropTypes.func,
};

export default ShippingDetailsModal;
