/* eslint-disable no-nested-ternary */
import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';
import { Body, Title } from '@vds/typography';
import { Icon } from '@vds/icons';
import { Line } from '@vds/lines';
import { TextLink } from '@vds/buttons';
import PropTypes from 'prop-types';
import LOVPageTracker from 'onevzsoemfecommon/LOVPageTracker';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import { isIpad } from 'onevzsoemfeframework/DomService';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR } from '../constants/constants';
import { BackClickable } from '../../StyledConstants';
import { formatCurrency, getTotalMonthlyBill } from '../../utils/common';
import { getPartialNbsData } from './store/selectors';

const FlexBoxGrowOne = styled.div`
  display: flex;
  flex-grow: 1;
  height: 4rem;
`;
const ShopWrapper = styled.div`
  width: ${(props) => props.width || '50%'};
  padding: 1.5rem 0.5rem 1.5rem 1.5rem;
  display: flex;
  justify-content: space-between;
`;

export const FlexAlignContainerItemsCenter = styled.div`
  display: flex;
  align-items: center !important;
  justify-content: space-between;
`;
const LineSeperator = styled.div`
  // width: 1px;
  height: 50px;
  // background: #000000;
  top: 1rem;
  border-right: 1px solid #d8dada;
  position: relative;
`;
const scmCheckoutMfeEnabled = window?.mfe?.scmCheckoutMfeEnable;
const FixedHeader = styled.div`
  max-width: 64rem;
  background-color: rgb(255, 255, 255);
  z-index: ${scmCheckoutMfeEnabled ? 2 : 1};
  top: ${scmCheckoutMfeEnabled ? (window?.mfe?.isProspectNewCustomerTab ? 0 : '3rem') : 0};
  width: 100%;
  position: ${window?.mfe?.isProspectNewCustomerTab ? 'absolute' : 'fixed'};
`;

const CloseIconWrapper = styled.div`
  display: flex;
  margin-right: 30px;
  margin-top: 10px;
`;

const Header = ({
  data,
  showModal,
  onBackClick,
  readOrder,
  readOrderData,
  receivedLovPollRessponse,
  setExitLovData,
  isQAFlow = false,
  nextBillSummaryData,
  setIsNewCustomer,
}) => {
  const header1 = 'Order review';
  const [newCost, setNewCost] = useState();
  const line2 = 'Due today';
  const [dueToday, setDueToday] = useState();
  const closeIcon = true;
  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;
  const bgColor = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.themeProps?.background;
  const status = readOrderData?.cart?.cartHeader?.status !== 'P' || readOrderData?.cart?.cartHeader?.status !== 'C';
  const readOrderStatus = readOrderData?.orderStatus === 'CR';
  const orderStatusCR = status && readOrderStatus;
  const [isReadOrderFlag] = getAssistedCradlePropertyV2(['readOrderMfeFFlag']);
  const [nbsFFlagState] = getAssistedCradlePropertyV2(['enablePartialNbsPosFFlag']);
  const isPartialNbs =
    /true/i.test(nbsFFlagState) ||
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.enablePartialNbsPosFFlag === 'TRUE';
  const line1 = isPartialNbs ? 'Est. ongoing monthly' : 'Est. new monthly';

  const isReadOrderFlagEnabled = /true/i.test(isReadOrderFlag);

  const isViewOnlyOrder = getQueryParamByName('viewOnlyOrder') === 'true';
  const channel = readOrderData?.cart?.orderDetails?.orderChannelId ?? '';
  const subAccountInfo = readOrderData?.cart?.orderDetails?.subAccountInfo ?? [];
  const lineActivityType = readOrderData?.cart?.lineDetails?.lineInfo?.map((line) => line.lineActivityType);
  const hasToDisplayHeaderPrices = !subAccountInfo?.length > 0 && !channel?.includes('OMNI-INDIRECT');
  const isDwosIsOrder = lineActivityType?.includes('DEO');

  // after testing will include isIpad condition
  const isReceivePoll = window?.sessionStorage?.getItem('receivePoll') && isIpad();
  const isPaxAuth = window?.sessionStorage?.getItem('paxAuth') && true;
  const radioSelected = window?.sessionStorage.getItem('vtRadioSelected');
  const [totalMonthlyBill, setTotalMonthlyBill] = useState(0);

  let navigate = '';
  function useNavigateMFE() {
    navigate = useNavigate();
  }
  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }

  const nav2HandOff = () => {
    if (!window?.mfe?.scmCheckoutMfeEnable) {
      navigate(`/sales/assisted/new/handoff.html`);
    } else {
      window?.mfe?.historyRef.push(`/sales/assisted/new/handoff.html`);
    }
  };

  const renderBackButton = (dataTestId) => (
    <>
      <BackClickable data-testId={dataTestId} onClick={() => (onBackClick ? onBackClick() : nav2HandOff())}>
        <Icon name='left-caret' size='XLarge' medium='true' surface={isDark ? 'dark' : 'light'} />
      </BackClickable>
      <LineSeperator />
    </>
  );

  const enableFullBlownMfeNbsPosFFlag = JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.enableFullBlownMfeNbsPosFFlag === 'TRUE';
  const partialNbsaData = useSelector(getPartialNbsData)
  const checkoutState = useSelector(state => state);
  useEffect(() => {
    if (enableFullBlownMfeNbsPosFFlag) {
      setNewCost(partialNbsaData?.nbsVo?.monthlyTotalsInfo?.newMonthCharge);
    }
  }, [checkoutState]);

  useEffect(() => {
    if (data) {
      const {
        data: { cart },
      } = data;

      setDueToday(cart?.orderDetails?.totalDueToday);
      setNewCost(cart?.orderDetails?.totalDueMonthly);

      if (cart?.lineDetails?.subAccountNBSInfo?.[0]?.billAccounts) {
        const billAccount = cart?.lineDetails?.subAccountNBSInfo?.[0]?.billAccounts;
        const monthlyTotals = nextBillSummaryData?.nbsVo;

        setTotalMonthlyBill(getTotalMonthlyBill(billAccount, monthlyTotals));
      }
      if (isQAFlow && !cart?.cartHeader?.cartCreator) {
        setIsNewCustomer(true);
      }
    }
  }, [data, nextBillSummaryData]);

  return (
    <FixedHeader
      data-testid='header'
      style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR, backgroundColor: isDark ? bgColor : '' }}
    >
      {isReceivePoll && receivedLovPollRessponse && (
        <LOVPageTracker
          pageName='orderReview'
          lovMilestone={receivedLovPollRessponse?.value}
          isDisplayButtons
          isPAXQRCodeFlow={isPaxAuth}
          selectedMode={radioSelected}
          setExitLovData={setExitLovData}
        />
      )}
      <FlexAlignContainerItemsCenter>
        <FlexBoxGrowOne>
          {!isQAFlow &&
            (isReadOrderFlagEnabled
              ? (readOrder && !orderStatusCR) || isViewOnlyOrder
                ? ''
                : renderBackButton('btn-back-readorder')
              : renderBackButton('btn-back'))}
          <ShopWrapper width='170px'>
            <Title size='small' bold primitive='h1' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
              {isReadOrderFlagEnabled ? (readOrder ? '' : `${header1} `) : `${header1} `}
              <div style={{ display: 'none' }}>
                <Body size='small'>(MFE)</Body>
              </div>
            </Title>
          </ShopWrapper>
          {!isQAFlow && <LineSeperator />}
          <ShopWrapper width={window?.mfe?.isProspectNewCustomerTab ? '400px' : '354px'}>
            {!isQAFlow && (
              <Title size='small' bold primitive='h1' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                {line1}
              </Title>
            )}
            {!isQAFlow && (
              <Title size='small' bold primitive='h1' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                {readOrder && isReadOrderFlagEnabled ? formatCurrency(totalMonthlyBill) : `${formatCurrency(newCost)}`}
              </Title>
            )}
          </ShopWrapper>
          <LineSeperator />
          <ShopWrapper width={window?.mfe?.isProspectNewCustomerTab ? '375px' : '286px'}>
            <Title size='small' bold primitive='h1' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
              {line2}
            </Title>
            <Title size='small' bold primitive='h1' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
              {(isReadOrderFlagEnabled && readOrder) ||
              !hasToDisplayHeaderPrices ||
              (channel?.includes('OMNI-INDIRECT') > -1 && isDwosIsOrder)
                ? ''
                : formatCurrency(dueToday)}
            </Title>
          </ShopWrapper>
        </FlexBoxGrowOne>
        {closeIcon && window?.mfe?.isProspectNewCustomerTab && (
          <CloseIconWrapper data-testid='close-btn-icon' onClick={showModal}>
            <span>
              <Icon name='close' size='large' surface={isDark ? 'dark' : 'light'} />
            </span>
          </CloseIconWrapper>
        )}
        {closeIcon && !window?.mfe?.scmCheckoutMfeEnable ? (
          <CloseIconWrapper data-testid='close-btn-icon' onClick={showModal}>
            <span>
              <Icon name='close' size='large' surface={isDark ? 'dark' : 'light'} />
            </span>
          </CloseIconWrapper>
        ) : (
          !window?.mfe?.scmCheckoutMfeEnable && (
            <CloseIconWrapper>
              <TextLink type='standAlone' onClick={() => {}} surface={isDark ? 'dark' : 'light'}>
                More options
              </TextLink>
            </CloseIconWrapper>
          )
        )}
      </FlexAlignContainerItemsCenter>
      <Line type='secondary' surface={isDark ? 'dark' : 'light'} />
    </FixedHeader>
  );
};
Header.propTypes = {
  data: PropTypes.any,
  showModal: PropTypes.func,
  onBackClick: PropTypes.func,
  readOrder: PropTypes.bool,
  readOrderData: PropTypes.object,
  receivedLovPollRessponse: PropTypes.object,
  setExitLovData: PropTypes.func,
  isQAFlow: PropTypes.bool,
  nextBillSummaryData: PropTypes.object,
  setIsNewCustomer: PropTypes.func,
};

export default Header;
