import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import StoreProvider from '../../modules/store';
import cartJson from '../../__mock__/fetchPrice-retriveCart.json';
import fetchPriceSnapshotJSON from '../../__mock__/fetchPricingSnapshot.json';
import fetchPriceServiceinEffectLaterJSON from '../../__mock__/fetchPricingSnapshotWithServiceinEffectLater.json';
import ExistingServicePerks from './ExistingServicePerks';

describe('ExistingServicePerks Component', () => {
  const compteDPJson = {
    isSuccess: true,
    data: {
      firstMonthPrice: 28.64,
      remainingMonthPrice: 28.61,
      dpTerm: 36,
      downPayment: 200,
    },
  };
  const handlers = [
    rest.post(`*/devicepricingservice/computeDPPrices`, (req, res, ctx) =>
      res(ctx.status(200), ctx.json(compteDPJson)),
    ),
  ];
  const server = setupServer(...handlers);

  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;

    server.listen();
  });

  test('View Devices', async () => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const list = fetchPriceSnapshotJSON?.data?.data?.subAccounts?.[0]?.lines?.[0]?.addons;
    render(
      <BrowserRouter>
        <StoreProvider>
          <ExistingServicePerks
            line={line}
            element={element}
            features={list}
            existingFeatures={list}
            newFeatures={list}
            oldFeatures={list}
            defaultImageLabel='https://ss7.vzw.com/is/image/VerizonWireless/device_protection_120817?$pngalpha$'
            fpsReferences={fetchPriceServiceinEffectLaterJSON?.data?.data?.reference}
            fetchPriceSnapshotSubAccount={fetchPriceServiceinEffectLaterJSON?.data?.data?.subAccounts}
            opened
            closeModal={() => {}}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const link = screen.getByTestId('view-devices');
    expect(link).toBeInTheDocument();
    fireEvent.click(link, {});
    expect(window.vzdl.page.detail).toEqual('Line Level Features');
    await waitFor(() => {
      const DoneBtn = screen.getByText(/Done/i);
      expect(DoneBtn).toBeInTheDocument();
      fireEvent.click(DoneBtn, {});
      expect(window.vzdl.page.detail).toEqual('');
    });
  });

  test('Display Service in effect later message', () => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const list = fetchPriceSnapshotJSON?.data?.data?.subAccounts?.[0]?.lines?.[0]?.addons;

    render(
      <BrowserRouter>
        <StoreProvider>
          <ExistingServicePerks
            line={line}
            element={element}
            features={list}
            existingFeatures={list}
            newFeatures={list}
            oldFeatures={list}
            defaultImageLabel='https://ss7.vzw.com/is/image/VerizonWireless/device_protection_120817?$pngalpha$'
            fpsReferences={fetchPriceServiceinEffectLaterJSON?.data?.data?.reference}
            fetchPriceSnapshotSubAccount={fetchPriceServiceinEffectLaterJSON?.data?.data?.subAccounts}
            opened
            closeModal={() => {}}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const msg = screen.getByTestId('view-serviceInEffectLaterMsg');
    expect(msg).toBeInTheDocument();
  });

  test('isDark true', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] ,isDark: true, themeProps: {background: '#eeeeee'}};
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const list = fetchPriceSnapshotJSON?.data?.data?.subAccounts?.[0]?.lines?.[0]?.addons;

    render(
      <BrowserRouter>
        <StoreProvider>
          <ExistingServicePerks
            line={line}
            element={element}
            features={list}
            existingFeatures={list}
            newFeatures={list}
            oldFeatures={list}
            defaultImageLabel='https://ss7.vzw.com/is/image/VerizonWireless/device_protection_120817?$pngalpha$'
            fpsReferences={fetchPriceServiceinEffectLaterJSON?.data?.data?.reference}
            fetchPriceSnapshotSubAccount={fetchPriceServiceinEffectLaterJSON?.data?.data?.subAccounts}
            opened
            closeModal={() => {}}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const msg = screen.getByTestId('view-serviceInEffectLaterMsg');
    expect(msg).toBeInTheDocument();
  });

  test('isDark false', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] ,isDark: false, themeProps: {background: '#eeeeee'}};
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const list = fetchPriceSnapshotJSON?.data?.data?.subAccounts?.[0]?.lines?.[0]?.addons;

    render(
      <BrowserRouter>
        <StoreProvider>
          <ExistingServicePerks
            line={line}
            element={element}
            features={list}
            existingFeatures={list}
            newFeatures={list}
            oldFeatures={list}
            defaultImageLabel='https://ss7.vzw.com/is/image/VerizonWireless/device_protection_120817?$pngalpha$'
            fpsReferences={fetchPriceServiceinEffectLaterJSON?.data?.data?.reference}
            fetchPriceSnapshotSubAccount={fetchPriceServiceinEffectLaterJSON?.data?.data?.subAccounts}
            opened
            closeModal={() => {}}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const msg = screen.getByTestId('view-serviceInEffectLaterMsg');
    expect(msg).toBeInTheDocument();
  });
});
