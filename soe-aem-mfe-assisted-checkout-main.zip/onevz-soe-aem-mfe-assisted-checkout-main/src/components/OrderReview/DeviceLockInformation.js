import styled from 'styled-components';
import { Title } from '@vds/typography';
import { Line } from '@vds/lines';
import PropTypes from 'prop-types';
import { Icon } from '@vds/icons';
import { BackClickable, PaddingBot24, Padding48 } from '../../StyledConstants';

const LineSeperator = styled.div`
  height: 30px;

  top: 1.4rem;
  border-right: 1px solid #000000;
  position: relative;
`;

const FlexBoxGrowOne = styled.div`
  display: flex;
  flex-grow: 1;
  height: 4rem;
`;
const ShopWrapper = styled.div`
  padding: 1.5rem 2rem;
`;

const MaxWidth64 = styled.div`
  max-width: 64rem;
  margin: 0px auto;
`;

const DevicePolicy = styled.div`
  font-size: 14px;
`;

const DeviceLockInformation = ({ closeDeviceInformation, data }) => {
  const onBack = () => {
    closeDeviceInformation();
  };

  return (
    <MaxWidth64>
      <div data-testid='device-lock-info-modal'>
        <FlexBoxGrowOne>
          <BackClickable data-testid='btn-back' onClick={onBack}>
            <Icon name='left-caret' size='XLarge' medium='true' />
          </BackClickable>
          <LineSeperator />
          <ShopWrapper>
            <Title size='small' bold primitive='h1' data-testid='deviceLock'>
              Important device lock Information
            </Title>
          </ShopWrapper>
        </FlexBoxGrowOne>
        <Line type='secondary' />
        <PaddingBot24 />
      </div>
      <div>
        <Padding48>
          <DevicePolicy>
            <div dangerouslySetInnerHTML={{ __html: data }} />
          </DevicePolicy>
        </Padding48>
      </div>
    </MaxWidth64>
  );
};

DeviceLockInformation.propTypes = {
  closeDeviceInformation: PropTypes.func,
  data: PropTypes.string,
};

export default DeviceLockInformation;
