import { fireEvent, render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../modules/store';
import StandAloneTrade from './StandAloneTrade';
import standaloneTradein from './__mock__/standaloneTradein.json';
import mfipResponse from './__mock__/mfipResponse.json';
import cartJson from '../../__mock__/retrive-cart.json';
import alternateCartJson from '../../__mock__/alternateRetrive-cart.json';
import CPCAlternateMock from '../../__mock__/CPC_retrieveCart.json';
import retrieveCustomerJson from '../../__mock__/retrieve-customer.json';
import getOrderwriteStandalonetradein from '../../__mock__/getOrderwriteStandalonetradein.json';
import * as GetStandAlonetradein from '../../modules/services/APIService/GetStandAlonetradein';
import { returnMethodCartDetails } from '../../__mock__/returnMethodCart';

const mockNavigate = jest.fn();
const mockSaveOrder = jest.fn();
const mockData = {
  getOrderWrite: mockSaveOrder,
  getOrderWriteResult: { data: getOrderwriteStandalonetradein, status: 'fulfilled' },
  getMFIPrequest: mockSaveOrder,
  getMFIPResult: { data: mfipResponse, status: 'fulfilled' },
};
const props = {
  data: standaloneTradein.data,
  cartDetailsResult: cartJson,
  customer: retrieveCustomerJson?.data?.customer,
  landing: {
    activeCartandCase: {
      cartId: 'f9a102c8-bd94-476b-8c36-f867597dc8ca',
      caseId: 'SOP-15788985-E01',
    },
    quoteDetails: [{ cartId: 'f9a102c8-bd94-476b-8c36-f867597dc8ca' }],
  },
};
jest.mock('@vds/modals', () => {
  const RealModal = jest.requireActual('@vds/modals');
  const MockModal = {
    ...RealModal,
    Modal: ({ children }) => children,
  };
  return MockModal;
});
describe('Stand Alone Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  beforeEach(() => {
    sessionStorage.setItem(
      'geoFenceResponse',
      JSON.stringify({ geoFenceCheck: 'false', ipadLatitude: '12.34', ipadLongitude: '56.78', reason: 'Out of range' }),
    );
  });

  it('renders Modal', () => {
    const { getAllByTestId } = render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const openModalButton = getAllByTestId('StandaloneTradein');
    expect(openModalButton[0]).toBeInTheDocument();
  });
  it('Left caret Icon Click', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const leftCareticon = screen.getByTestId('btn-back');
    fireEvent.click(leftCareticon);
    setTimeout(() => {
      expect(mockNavigate).toHaveBeenCalledWith(`/sales/assisted/landing.html`);
    }, 3000);
  });
  it('Left caret Icon Click', () => {
    window.mfe = { scmDeviceMfeEnable: true, historyRef: { push: jest.fn() } };
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const StandaloneTradein = screen.getByTestId('StandaloneTradein');
    const leftCareticon = screen.getByTestId('btn-back');
    fireEvent.click(leftCareticon);
    expect(StandaloneTradein).not.toBeInTheDocument();
    window.mfe = { scmDeviceMfeEnable: false, historyRef: { push: jest.fn() } };
  });
  it('close icon button Click', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
  });
  it('renders continue to shopping button for Stand Alone', async () => {
    jest.mock('onevzsoemfecommon/Helpers', () => ({
      getUIContextPathBAU: jest.fn(() => {}),
    }));
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const continueShoppingbtn = screen.getByText(/Continue Shopping/i);
    fireEvent.click(continueShoppingbtn);
    expect(continueShoppingbtn).toBeInTheDocument();
  });
  it('renders continue to shopping button for Stand Alone', async () => {
    window.mfe = { scmDeviceMfeEnable: true, historyRef: { push: jest.fn() } };
    jest.mock('onevzsoemfecommon/Helpers', () => ({
      getUIContextPathBAU: jest.fn(() => {}),
    }));
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const continueShoppingbtn = screen.getByText(/Continue Shopping/i);
    fireEvent.click(continueShoppingbtn);
    expect(continueShoppingbtn).toBeInTheDocument();
    window.mfe = { scmDeviceMfeEnable: false, historyRef: { push: jest.fn() } };
  });
  it('renders Edit button', async () => {
    jest.mock('onevzsoemfecommon/Helpers', () => ({
      getUIContextPathBAU: jest.fn(() => {}),
    }));
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const editBtn = screen.getByTestId('Edit-btn');
    fireEvent.click(editBtn);
    expect(editBtn).toBeInTheDocument();
    setTimeout(() => {
      const backBtn = screen.getByTestId('btn-back');
      expect(backBtn).toBeInTheDocument();
    }, 3000);
  });
  it('renders proceed to checkout button for Stand Alone', async () => {
    mockData.getOrderWriteResult.data.availablePaths = [
      {
        path: 'Payment-agreements',
      },
      {
        path: 'Payment-agreements',
      },
    ];
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
    setTimeout(() => {
      const messageShown = screen.getAllByText(
        /Devices cannot be returned to Verizon with Anti-theft lock turned ON. Please back up your device, then perform a Factory Data Reset to turn OFF/i,
      );
      expect(messageShown).toBeInTheDocument();
    }, 3000);
    setTimeout(() => {
      const okBtn = screen.getByTestId('ok-button');
      fireEvent.click(okBtn);
    }, 3000);
  });
  it('renders proceed to checkout button for Stand Alone', async () => {
    mockData.getOrderWriteResult.data.availablePaths = [
      {
        path: 'Confirmation',
      },
      {
        path: 'Confirmation',
      },
    ];
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
    setTimeout(() => {
      const messageShown = screen.getAllByText(
        /Devices cannot be returned to Verizon with Anti-theft lock turned ON. Please back up your device, then perform a Factory Data Reset to turn OFF/i,
      );
      expect(messageShown).toBeInTheDocument();
    }, 3000);
    setTimeout(() => {
      const okBtn = screen.getByTestId('ok-button');
      fireEvent.click(okBtn);
    }, 3000);
  });
  it('renders proceed to checkout button for Stand Alone', async () => {
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
    setTimeout(() => {
      const messageShown = screen.getAllByText(
        /Devices cannot be returned to Verizon with Anti-theft lock turned ON. Please back up your device, then perform a Factory Data Reset to turn OFF/i,
      );
      expect(messageShown).toBeInTheDocument();
    }, 3000);
    setTimeout(() => {
      const okBtn = screen.getByTestId('ok-button');
      fireEvent.click(okBtn);
    }, 3000);
  });
  it('renders proceed to checkout button for Stand Alone', async () => {
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData);
    window.mfe = { scmDeviceMfeEnable: true, historyRef: { push: jest.fn() } };
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
    setTimeout(() => {
      const messageShown = screen.getAllByText(
        /Devices cannot be returned to Verizon with Anti-theft lock turned ON. Please back up your device, then perform a Factory Data Reset to turn OFF/i,
      );
      expect(messageShown).toBeInTheDocument();
    }, 3000);
    setTimeout(() => {
      const okBtn = screen.getByTestId('ok-button');
      fireEvent.click(okBtn);
    }, 3000);
  });
  it('renders proceed to checkout button for Stand Alone to order confirmation', async () => {
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
    setTimeout(() => {
      expect(mockNavigate).toHaveBeenCalledWith(`/sales/assisted/new/order-confirmation.html`);
    }, 3000);
  });
  test('Change in the props, intent type will be Inline-CPC in payload', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);
    sessionStorage.setItem('customerType', 'N');
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade
            {...props}
            cartDetailsResult={{
              data: {
                cart: {
                  lineDetails: {
                    acctMcsSubscription: [
                      {
                        isTrue: true,
                      },
                    ],
                  },
                },
              },
            }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
    setTimeout(() => {
      expect(mockNavigate).toHaveBeenCalledWith(`/sales/assisted/new/order-confirmation.html`);
    }, 3000);
  });
  test('lineactivitytype = EUPBYOD && email = null', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);
    const appData = '{"isMitekSimSwapEnabled": "TRUE"}';
    sessionStorage.setItem('APP_PROPERTIES', appData);
    sessionStorage.setItem('customerType', 'N');
    const newProps = {
      landing: {},
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} {...newProps} cartDetailsResult={alternateCartJson} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
    setTimeout(() => {
      expect(mockNavigate).toHaveBeenCalledWith(`/sales/assisted/new/order-confirmation.html`);
    }, 3000);
  });
  test('lineactivitytype = CPC && email = null', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);
    sessionStorage.setItem('customerType', 'N');
    const newProps = {
      landing: {
        activeCartandCase: {
          cartId: 'f9a102c8-bd94-476b-8c36-f867597dc8ca',
          caseId: 'SOP-15788985-E01',
        },
        quoteDetails: [{ cartId: '147852369' }],
      },
      customer: {
        cartId: '147852369',
      },
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} {...newProps} cartDetailsResult={CPCAlternateMock} />
        </StoreProvider>
      </BrowserRouter>,
    );
  });
  test('lineactivitytype = CPC && email = null', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    const data = [
      { dispositionOptionId: '18', rank: 1, propositionId: 41, soiEngagementId: 4125, offerContainerId: 741 },
      { dispositionOptionId: '18' },
    ];
    const responseData = JSON.stringify(data);
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);
    sessionStorage.setItem('customerType', 'N');
    sessionStorage.setItem('responseList', responseData);
    const newProps = {
      landing: {},
      customer: {},
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} {...newProps} cartDetailsResult={CPCAlternateMock} />
        </StoreProvider>
      </BrowserRouter>,
    );
  });
  test('fmiSwitch: ON', () => {
    const newMockData = {
      ...mockData,
      getMFIPResult: {
        data: {
          response: [
            {
              message:
                'Devices cannot be returned to Verizon with Anti-theft lock turned ON. Please back up your device, then perform a Factory Data Reset to turn  OFF',
              type: 'WARNING',
              fmiSwitch: 'ON',
            },
          ],
        },
        status: 'fulfilled',
      },
    };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => newMockData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} cartDetailsResult={CPCAlternateMock} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const okayBtn = screen.getByTestId('ok-button');
    fireEvent.click(okayBtn);
  });
  test('Change in the props, intent type will be StandAloneTradeIn in payload', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);
    sessionStorage.setItem('customerType', 'N');
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade
            {...props}
            cartDetailsResult={{
              data: {
                cart: {
                  lineDetails: {
                    lineInfo: [],
                    tradeInDetail: {
                      tradeInItems: [
                        {
                          equipModel: 'Samsung Galaxy S10 128GB in Prism Black',
                          imgUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/samsung-galaxy-s10-black?$device-lg$',
                          color: 'Black',
                          size: '128GB',
                          recycleSeqNum: '1',
                          creditType: 'ACT',
                          emailAddress: 'AVISEKH.CHAKRABORTY@VERIZON.COM',
                          tradeDeviceMDN: '6122193526',
                          submissionId: '807753849913581',
                          buyoutDevice: 'false',
                          tradeInAutoPull: false,
                          tradeInStatus: 'Complete',
                          fmiLocked: 'false',
                        },
                      ],
                    },
                  },
                },
              },
            }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
    setTimeout(() => {
      expect(mockNavigate).toHaveBeenCalledWith(`/sales/assisted/new/order-confirmation.html`);
    }, 3000);
  });
  test('Change in the props, regNo being 51 in payload', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);
    sessionStorage.setItem('customerType', 'N');
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade
            {...props}
            retrieveCustomerJson={{
              data: {
                customer: {
                  regNo: '51',
                },
              },
            }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
    setTimeout(() => {
      expect(mockNavigate).toHaveBeenCalledWith(`/sales/assisted/new/order-confirmation.html`);
    }, 3000);
  });
  test('Change in the props, gift card branch', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);
    sessionStorage.setItem('customerType', 'N');
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade
            {...props}
            data={{
              tradeInItems: [
                {
                  appliedPrice: '67.00',
                  creditType: '',
                },
              ],
            }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
    setTimeout(() => {
      expect(mockNavigate).toHaveBeenCalledWith(`/sales/assisted/new/order-confirmation.html`);
    }, 3000);
  });
  test('Change in the props, itemPrice making true', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);
    sessionStorage.setItem('customerType', 'N');
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade
            {...props}
            data={{
              tradeInItems: [
                {
                  itemPrice: '67.00',
                  creditType: '',
                },
              ],
            }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
    setTimeout(() => {
      expect(mockNavigate).toHaveBeenCalledWith(`/sales/assisted/new/order-confirmation.html`);
    }, 3000);
  });

  it('renders return method type for return store', async () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);
    sessionStorage.setItem('customerType', 'N');
    jest.mock('onevzsoemfecommon/Helpers', () => ({
      getUIContextPathBAU: jest.fn(() => {}),
    }));
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade
            {...props}
            cartDetailsResult={returnMethodCartDetails({ tradeInShippingType: 'return_store', tradeInType: 'home' })}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const returnMethod = screen.getByText(/Trade the device later/i);
    expect(returnMethod).toBeInTheDocument();
  });

  it('renders return method type for upsdrop off qrcode', async () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);
    sessionStorage.setItem('customerType', 'N');
    jest.mock('onevzsoemfecommon/Helpers', () => ({
      getUIContextPathBAU: jest.fn(() => {}),
    }));
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade
            {...props}
            cartDetailsResult={returnMethodCartDetails({ tradeInShippingType: 'upsdrop-off_qrcode' })}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const returnMethod = screen.getByText(/UPS QR code/i);
    expect(returnMethod).toBeInTheDocument();
  });

  it('renders return method type for prepaid label', async () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);
    sessionStorage.setItem('customerType', 'N');
    jest.mock('onevzsoemfecommon/Helpers', () => ({
      getUIContextPathBAU: jest.fn(() => {}),
    }));
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade
            {...props}
            cartDetailsResult={returnMethodCartDetails({ tradeInShippingType: 'prepaidlabel' })}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const returnMethod = screen.getByText(/Prepaid Label/i);
    expect(returnMethod).toBeInTheDocument();
  });

  it('renders return method type for tradein type home', async () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);
    sessionStorage.setItem('customerType', 'N');
    jest.mock('onevzsoemfecommon/Helpers', () => ({
      getUIContextPathBAU: jest.fn(() => {}),
    }));
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} cartDetailsResult={returnMethodCartDetails({ tradeInType: 'home' })} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const returnMethod = screen.getByText(/Trade at home/i);
    expect(returnMethod).toBeInTheDocument();
  });

  it('renders return method type for tradein now', async () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);
    sessionStorage.setItem('customerType', 'N');
    jest.mock('onevzsoemfecommon/Helpers', () => ({
      getUIContextPathBAU: jest.fn(() => {}),
    }));
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const returnMethod = screen.getByText(/Trade the device now/i);
    expect(returnMethod).toBeInTheDocument();
  });

  it('renders return method type for trade at home shipping type', async () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);
    sessionStorage.setItem('customerType', 'N');
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade
            {...props}
            cartDetailsResult={returnMethodCartDetails({ tradeInShippingType: 'trade_at_home' })}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const returnMethod = screen.getByText(/Trade at home/i);
    expect(returnMethod).toBeInTheDocument();
  });

  it('renders return method with empty shipping type and no tradein items', async () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);
    sessionStorage.setItem('customerType', 'N');
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade
            {...props}
            cartDetailsResult={returnMethodCartDetails({
              tradeInShippingType: '',
              tradeInType: '',
              tradeInItems: [],
            })}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    // Should render empty return method
    expect(screen.getByText(/Return Method:/i)).toBeInTheDocument();
  });

  // it('handles navigation error gracefully', () => {
  //   const consoleSpy = jest.spyOn(console, 'error').mockImplementation(() => {});

  //   // Simply render the component and verify it doesn't crash
  //   // The navigation error handling is tested through the component's try-catch block
  //   const { getByTestId } = render(
  //     <BrowserRouter>
  //       <StoreProvider>
  //         <StandAloneTrade {...props} />
  //       </StoreProvider>
  //     </BrowserRouter>,
  //   );

  //   // Verify the component renders successfully despite potential navigation errors
  //   expect(getByTestId('StandaloneTradein')).toBeInTheDocument();

  //   consoleSpy.mockRestore();
  // });

  it('calculates total applied price when itemPrice has NaN values', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);

    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade
            {...props}
            data={{
              tradeInItems: [
                {
                  itemPrice: 'invalid',
                  creditType: 'ACT',
                  equipModel: 'Test Device',
                  deviceId: '123',
                  tradeDeviceMDN: '1234567890',
                  imgUrl: 'test.jpg',
                },
              ],
              customerName: 'Test Customer',
            }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    expect(screen.getByText(/Test Customer/i)).toBeInTheDocument();
  });

  it('calculates total applied price when appliedPrice has NaN values', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);

    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade
            {...props}
            data={{
              tradeInItems: [
                {
                  appliedPrice: 'invalid',
                  creditType: 'ACT',
                  equipModel: 'Test Device',
                  deviceId: '123',
                  tradeDeviceMDN: '1234567890',
                  imgUrl: 'test.jpg',
                },
              ],
              customerName: 'Test Customer',
            }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    expect(screen.getByText(/Test Customer/i)).toBeInTheDocument();
  });

  it('handles service only order detection with CPC line type and cart items', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);

    const cartWithCPCItems = {
      data: {
        cart: {
          ...cartJson.data.cart,
          lineDetails: {
            ...cartJson.data.cart.lineDetails,
            lineInfo: [
              {
                lineActivityType: 'CPC',
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: [{ id: 'item1', name: 'Test Item' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} cartDetailsResult={cartWithCPCItems} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
  });

  it('handles service only order detection with FEA line type and cart items', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);

    const cartWithFEAItems = {
      data: {
        cart: {
          ...cartJson.data.cart,
          lineDetails: {
            ...cartJson.data.cart.lineDetails,
            lineInfo: [
              {
                lineActivityType: 'FEA',
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: [{ id: 'item1', name: 'Test Feature' }],
                    },
                  },
                ],
              },
            ],
          },
        },
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} cartDetailsResult={cartWithFEAItems} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
  });

  it('handles EUPBYOD line type without SIM CPE items', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);
    sessionStorage.setItem('channelId', 'OMNI-DIRECT');

    const cartWithEUPBYOD = {
      data: {
        cart: {
          ...cartJson.data.cart,
          cartHeader: {
            ...cartJson.data.cart.cartHeader,
            sourceSystem: 'OMNI-DIRECT',
          },
          lineDetails: {
            ...cartJson.data.cart.lineDetails,
            lineInfo: [
              {
                lineActivityType: 'EUPBYOD',
                itemsInfo: [
                  {
                    cartItems: {
                      cartItem: [{ cartItemType: 'DEVICE', isCustomerProvidedSIM: false }],
                    },
                  },
                ],
              },
            ],
          },
        },
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} cartDetailsResult={cartWithEUPBYOD} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
  });

  it('handles case when geoFenceResponse reason is not out of range', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);

    sessionStorage.setItem(
      'geoFenceResponse',
      JSON.stringify({
        geoFenceCheck: 'false',
        ipadLatitude: '12.34',
        ipadLongitude: '56.78',
        reason: 'Different reason',
      }),
    );

    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
  });

  it('handles case when currentEmail equals previousEmail', () => {
    const mockData2 = {
      ...mockData,
      getOrderWriteResult: { data: {}, status: 'fulfilled' },
    };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);

    const cartWithSameEmail = {
      data: {
        cart: {
          ...cartJson.data.cart,
          orderDetails: {
            ...cartJson.data.cart.orderDetails,
            spocs: {
              notificationOptions: {
                primaryEmailId: 'test@example.com',
              },
            },
          },
        },
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} cartDetailsResult={cartWithSameEmail} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
  });

  it('handles case when APP_PROPERTIES is not available', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);

    sessionStorage.removeItem('APP_PROPERTIES');

    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
  });

  it('handles case when locationData is not available', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);

    sessionStorage.removeItem('locationData');
    sessionStorage.setItem('APP_PROPERTIES', '{"isMitekSimSwapEnabled": "TRUE"}');

    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
  });

  it('tests allowOnlyNumbers function with valid numbers', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);

    const cartWithValidMtn = {
      data: {
        cart: {
          ...cartJson.data.cart,
          cartHeader: {
            ...cartJson.data.cart.cartHeader,
            cartCreator: '1234567890',
          },
        },
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} cartDetailsResult={cartWithValidMtn} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
  });

  it('tests allowOnlyNumbers function with invalid characters', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);

    const cartWithInvalidMtn = {
      data: {
        cart: {
          ...cartJson.data.cart,
          cartHeader: {
            ...cartJson.data.cart.cartHeader,
            cartCreator: 'abc123def',
          },
        },
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} cartDetailsResult={cartWithInvalidMtn} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
  });

  it('tests isServiceOnlyOrder function with empty lines array', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);

    const cartWithEmptyLines = {
      data: {
        cart: {
          ...cartJson.data.cart,
          lineDetails: {
            ...cartJson.data.cart.lineDetails,
            lineInfo: [],
          },
        },
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} cartDetailsResult={cartWithEmptyLines} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
  });

  it('tests isServiceOnlyOrder function with non-CPC/FEA line types', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);

    const cartWithOtherLineTypes = {
      data: {
        cart: {
          ...cartJson.data.cart,
          lineDetails: {
            ...cartJson.data.cart.lineDetails,
            lineInfo: [
              {
                lineActivityType: 'DEVICE',
                itemsInfo: [],
              },
            ],
          },
        },
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} cartDetailsResult={cartWithOtherLineTypes} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
  });

  it('handles case when STORE-LOCATION-DETAIL is not in sessionStorage', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);

    sessionStorage.removeItem('STORE-LOCATION-DETAIL');
    sessionStorage.setItem(
      'geoFenceResponse',
      JSON.stringify({
        geoFenceCheck: 'false',
        ipadLatitude: '12.34',
        ipadLongitude: '56.78',
        reason: 'out of range',
      }),
    );

    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
  });

  it('handles case when quoteId is 0000', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);

    const cartWithZeroQuoteId = {
      data: {
        cart: {
          ...cartJson.data.cart,
          quote: {
            quoteId: '0000',
          },
        },
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} cartDetailsResult={cartWithZeroQuoteId} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
  });

  it('handles case when quoteId is empty string', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);

    const cartWithEmptyQuoteId = {
      data: {
        cart: {
          ...cartJson.data.cart,
          quote: {
            quoteId: '',
          },
        },
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} cartDetailsResult={cartWithEmptyQuoteId} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
  });

  it('handles case when customerType is N and creditAppNum is available', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);

    // Mock getQueryParamByName to return creditAppNum
    jest.mock('onevzsoemfecommon/Helpers', () => ({
      getQueryParamByName: jest.fn((param) => {
        if (param === 'creditAppNum') return 'CREDIT123';
        if (param === 'customerType') return 'N';
        return null;
      }),
    }));

    sessionStorage.setItem('customerType', 'N');

    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
  });

  it('handles case when responseList is null', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData2);

    sessionStorage.removeItem('responseList');

    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const checkOutbtn = screen.getByText(/Proceed To Checkout/i);
    fireEvent.click(checkOutbtn);
  });
});
describe('Stand Alone Component acss', () => {
  

  beforeEach(() => {
    sessionStorage.setItem(
      'geoFenceResponse',
      JSON.stringify({ geoFenceCheck: 'false', ipadLatitude: '12.34', ipadLongitude: '56.78', reason: 'Out of range' }),
    );
  });

  it('renders proceed to checkout button for Stand Alone', async () => {
    window.mfe = { scmDeviceMfeEnable: true, acssVtPerksEnabled: true, historyRef: { push: jest.fn() } };
    mockData.getOrderWriteResult.data.availablePaths = [
      {
        path: 'Payment-agreements',
      },
      {
        path: 'Payment-agreements',
      },
    ];
    jest.spyOn(GetStandAlonetradein, 'default').mockImplementation(() => mockData);
    const mockCart = { id: 'CART123' };
    props.ViewTogetherProps = {
      showAccordion: true,
      openAccordian: true,
      handleToggleChange: jest.fn(),
      data: { data: { cart: mockCart } },
      spanishSelected: false,
      customerProfile: {},
      handleShowViewTogether: jest.fn(),
      onAccordianToggle: jest.fn(),
      setShowSendMessageError: jest.fn(),
      setSelectedReviewMode: jest.fn(),
          setSelectedReason: jest.fn(),
          subReasonSelected: '',
          onChangeSubReason: jest.fn(),
          selectedRadio: '',
          autoSelectRC: false,
          onChangeRadio: jest.fn(),
          handleHideContinueShowViewTogether: jest.fn(),
          orderReviewResponse: {},
          fetchPriceSnapshot: jest.fn(),
          setReceivedLovPollResponse: jest.fn(),
          exitLovData: {}}
    render(
      <BrowserRouter>
        <StoreProvider>
          <StandAloneTrade {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    setTimeout(() => {
      const messageShown = screen.getAllByText(
        /Devices cannot be returned to Verizon with Anti-theft lock turned ON. Please back up your device, then perform a Factory Data Reset to turn OFF/i,
      );
      expect(messageShown).toBeInTheDocument();
    }, 3000);
    setTimeout(() => {
      const okBtn = screen.getByTestId('ok-button');
      fireEvent.click(okBtn);
    }, 3000);
    window.mfe = { };
  });
})
