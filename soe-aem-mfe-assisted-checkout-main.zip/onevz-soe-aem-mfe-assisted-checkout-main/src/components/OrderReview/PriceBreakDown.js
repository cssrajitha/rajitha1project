/* eslint-disable no-nested-ternary */
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { Checkbox } from '@vds/checkboxes';
import { TileContainer } from '@vds/tiles';
import { TextLink } from '@vds/buttons';
import { Line } from '@vds/lines';
import { isIpad, isTelesales } from 'onevzsoemfeframework/DomService';
import { acssMfeBasePath } from 'onevzsoemfecommon/Helpers';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import Emitter from 'onevzsoemfeframework/Emitter';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { FlexBox, Padding16 } from '../../StyledConstants';
import PriceInfo from './PriceInfo';
import MonthlyChargesModal from './MonthlyChargesModal';
import SalesTax from './SalesTax';
import monthlyChargesApiCallHook from '../../pages/home/container/monthlyChargesApiCallHook';
import {
  formatCurrency,
  scmCheckoutMfeEnabled,
  scmOnlyDeviceMfeEnabled,
  getTotalMonthlyBill,
  getEstimatedNextBillWithBillAccountNo,
} from '../../utils/common';
// import PaperlessBilling from './PaperlessBilling';
import InStorePickUpNotification from './InStorePickUpNotification/InStorePickUpNotification';
import { invokeTagging } from '../../utils/test-utils/utils';
import InfoApiCallHook from '../../modules/services/APIService/InfoAPICallHook';
import DFOPriceInfo from './DFOPriceInfo';
import { isSplitFulfillmentEnabled, dFillItemPresent, showShippingAddressQA } from '../../utils/orderreviewUtil';
import ManualDiscountView from './ManualDiscountView';
import StoreTradein from './StoreTradein';
import { requestBodyRetrieveCart } from '../../modules/services/APIService/APIRequestBody';
import { useLazyGetCartDetailsQuery } from '../../modules/services/APIService/APIServiceCallHook';
import { isNSEQAFlow } from '../ShippingDetails/FormUtils';
import { getPartialNbsData } from './store/selectors';

const ImgWrapper = styled.div`
  display: flex;
  width: 250px;
`;

const CheckboxWrapper = styled.div`
  display: flex;
  width: 234px;
`;

const LeftSideWrapper = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  min-width: 236px;
  padding: 0px 10px;
`;

const InfoWrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
`;

const BreakdownWrapper = styled.div`
  display: flex;
  flex-direction: ${(props) => (props.isQAMSF2NSAFFlag || props.isReadOrderMfeFFlag ? '' : 'column')};
  align-items: ${(props) => (props.isQAMSF2NSAFFlag || props.isReadOrderMfeFFlag ? 'flex-start' : 'flex-end')};
  border-bottom: ${(props) => (props.blackBorder ? '1px solid rgb(0, 0, 0)' : '1px solid rgb(216, 218, 218)')};
`;

const NotificationInformationContainer = styled.div`
  margin-top: 30px;
`;

const TileWrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
`;
const PriceWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 0.25rem;
  padding: 12px 8px 8px 8px;
`;

const Title = styled.div`
  font-size: 20px;
  font-weight: 700;
  line-height: 1.25rem;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  letter-spacing: 0.03125rem;
  margin: 0px;
  text-decoration: none;
  width: 178px;
`;

const DisclosureTitle = styled.div`
  font-size: 17px;
  font-weight: 700;
  line-height: 1.25rem;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  letter-spacing: 0.03125rem;
  margin: 0px;
  text-decoration: none;
  width: 178px;
`;

const DisclosureLink = styled.div`
  font-size: 17px;
  font-weight: 700;
  line-height: 1.25rem;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  letter-spacing: 0.03125rem;
  margin: 0px;
  text-decoration: none;
`;

const Value = styled.div`
  font-size: 20px;
  font-weight: 700;
  line-height: 1.25rem;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  letter-spacing: 0.03125rem;
  margin: 0px;
  text-decoration: none;
`;

const LinkWrapper = styled.div`
  text-align: left;
  padding-left: 8px;
  padding-bottom: 1rem;
`;

const TileContainerWrapper = styled.div`
  [class^='OuterTileContainer'] {
    border-radius: 0px !important;
    height: 100%;
  }
`;

const PriceBreakDown = ({
  data,
  fetchPriceSnapshot,
  // setPaperLessBilling,
  // setUpdatedEmail,
  hideShippingDetails,
  customerProfile,
  selectedReviewMode,
  selectedReason,
  isLovEnabled,
  fetchUnifiedNbsData,
  readOrderData,
  pageContext,
  readOrder,
  isQAFlow = false,
  nextBillSummaryData,
  showManagerApprovalView = false,
  setUpdatedCartDeatilsResult,
  setShowManagerApprovalView,
}) => {
  const dispatch = useDispatch();
  const [cartData, setCartData] = useState({});
  const [customerType, setCustomerType] = useState();
  const [montlyDue, setMontlyDue] = useState();
  const [discountTotal, setDiscountTotal] = useState();
  const [dueToday, setDueToday] = useState();
  const [subTotalDueToday, setSubTotalDueToday] = useState();
  const [subTotalOtherLines, setSubTotalOtherLines] = useState(0);
  const [totalTax, setTotalTax] = useState();
  const [shippingCost, setShippingCost] = useState();
  const [estimatedNextBill, setEstimatedNextBill] = useState();
  const [showMonthlyCharges, setShowMonthlyCharges] = useState(false);
  const [lineInfo, setLineInfo] = useState();
  const [cartId, setCartId] = useState();
  const [mtnCount, setMtnCount] = useState(0);
  const [depletionType, setDepletionType] = useState('');
  const { getEnrollGiftPurchase } = monthlyChargesApiCallHook();
  const { getActiveMTNRequest, getActiveMTNResponse } = InfoApiCallHook();
  const [getCartDetailsDataBody, getCartDetailsResults] = useLazyGetCartDetailsQuery();
  const activeMTNList = getActiveMTNResponse?.data || {};
  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;
  const bgColor = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.themeProps?.background;
  const [nbsFFlagState] = getAssistedCradlePropertyV2(['enablePartialNbsPosFFlag']);
  const isPartialNbs =
    /true/i.test(nbsFFlagState) ||
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.enablePartialNbsPosFFlag === 'TRUE';
  const orderStatus = readOrderData?.orderStatus;
  const [isReadOrderMfe] = getAssistedCradlePropertyV2(['readOrderMfeFFlag']);
  const isReadOrderMfeFFlag = /true/i.test(isReadOrderMfe);
  const orderDetailsDFO = data?.data?.cart?.orderDetails;
  const isDFo =
    orderDetailsDFO?.accessoryFinancingOfferInfo?.splitPaymentInfo &&
    orderDetailsDFO?.accessoryFinancingOfferInfo?.splitPaymentInfo.filter((info) => info.isDfo).length > 0;
  const dfoCart = data?.data?.cart;
  const [isDiscountsModalVisible, setisDiscountsModalVisible] = useState(false);
  const [toggle, setToggle] = useState('');
  const [isOpenModal, setisOpenModal] = useState(false);
  const [totalMonthlyBill, setTotalMonthlyBill] = useState(0);
  const [totalEstimatedNextBill, setTotalEstimatedNextBill] = useState(0);
  const [managerApprovalOnLoad, setManagerApprovalOnLoad] = useState(false);
  const enableFullBlownMfeNbsPosFFlag =
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.enableFullBlownMfeNbsPosFFlag === 'TRUE';

  const flag = readOrder || isPartialNbs;
  const estNextBill = flag ? 'Est. next bill' : 'Estimated next bill';
  const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable || false;
  const partialNbsaData = useSelector(getPartialNbsData);

  const showConsumerDisclosure = isQAFlow && isTelesales();

  const getActiveMtnCount = () => {
    const billAccount = activeMTNList?.customer?.billAccounts?.find((billaccount) => billaccount?.mtns) || [];
    return billAccount?.mtns?.length || 0;
  };

  const handleDeviceTradeinClick = () => {
    if (scmCheckoutMfeEnabled) {
      window?.mfe?.historyRef.push(`${acssMfeBasePath}/shop-tradein.html`);
    } else {
      window.location.href = `/sales/assisted/landing.html`;
    }
  };

  const getSubTitleText = () => {
    let estimatedBillMessage = '';
    const orderDetails = data?.data?.cart?.orderDetails;
    const lineDetails = data?.data?.cart?.lineDetails?.lineInfo;
    const hasDueTodayActivationFee = !!lineDetails?.find((line) =>
      line?.itemsInfo?.[0]?.cartItems?.cartItem?.find((item) => item?.cartItemType === 'ACTIVATION_FEE'),
    );
    orderDetails?.chargeSummary?.map((charge) => {
      if (charge.chargeType === 'ActivationFee' && charge.amount > 0 && !hasDueTodayActivationFee) {
        estimatedBillMessage = `A one-time activation fee of ${formatCurrency(
          charge.amount,
        )} will appear on your next bill.`;
      }
      return charge;
    });
    return estimatedBillMessage;
  };

  const getImpactedLinesCount = (cart) => {
    const { lineDetails, orderDetails } = cart || {};
    const impactedLinesCount =
      (lineDetails?.numOfLines || 0) -
      ((lineDetails?.numofLinesAAL || 0) +
        (lineDetails?.lineInfo?.reduce((n, line) => {
          const count = n + (line?.lineActivityType === 'ACC' ? 1 : 0);
          return count;
        }, 0) || 0));

    return orderDetails?.customerType !== 'N' ? impactedLinesCount : 0;
  };

  const handleDiscounts = (managerApproval = false) => {
    setManagerApprovalOnLoad(managerApproval);
    const qaDiscountsDisabledWithoutShipping =
      isNSEQAFlow(isQAFlow, data?.data?.cart) &&
      showShippingAddressQA(data?.data?.cart?.lineDetails?.lineInfo) &&
      !data?.data?.cart?.lineDetails?.lineInfo?.[0]?.itemsInfo?.[0]?.shipping?.address?.zipCode;
    if (qaDiscountsDisabledWithoutShipping) {
      dispatch(
        appMessageActions.addAppMessage(
          'Please update the shipping details before adding manual discount',
          'error',
          true,
          true,
        ),
      );
    } else {
      setisDiscountsModalVisible(true);
      setToggle('discounts');
    }
  };

  useEffect(() => {
    if (
      data?.data?.cart &&
      data?.data?.cart?.orderDetails &&
      data?.data?.cart?.orderDetails?.customerType !== 'N' &&
      !isQAFlow &&
      getActiveMTNResponse.status === 'uninitialized'
    ) {
      getActiveMTNRequest({ body: {}, spinner: true });
    }
  }, [data]);

  useEffect(() => {
    if (data) {
      const {
        data: { cart },
      } = data;
      const count = getActiveMtnCount() - getImpactedLinesCount(cart);
      setMtnCount(count);
    }
  }, [data, activeMTNList]);

  Emitter.off('UPDATE_SHIPPING_ADDRESS');
  Emitter.on('UPDATE_SHIPPING_ADDRESS', (newCartdata) => {
    console.log('UPDATE_SHIPPING_ADDRESS', newCartdata);
    setCartData(newCartdata);
  });
  useEffect(() => {
    if (data) {
      if (isQAFlow && getCartDetailsResults?.data) {
        setUpdatedCartDeatilsResult(getCartDetailsResults);
      }
      const updateCartDetails = getCartDetailsResults?.data || data;
      const {
        data: { cart },
      } = updateCartDetails;
      setCartData(cart);
      if (nextBillSummaryData && isReadOrderMfeFFlag && readOrder) {
        const monthlyTotalsInfo = nextBillSummaryData?.nbsVo?.monthlyTotalsInfo;

        // Handle monthly due
        if (monthlyTotalsInfo?.newMonthSubtotal) {
          setMontlyDue(
            monthlyTotalsInfo?.newMonthNoChangeMdnsTotal
              ? parseFloat(monthlyTotalsInfo.newMonthSubtotal) - parseFloat(monthlyTotalsInfo.newMonthNoChangeMdnsTotal)
              : monthlyTotalsInfo.newMonthSubtotal,
          );
        }

        // Handle total tax
        setTotalTax(
          monthlyTotalsInfo?.newMonthTotalTax ||
            cart?.lineDetails?.subAccountNBSInfo?.[0]?.billAccounts?.[0]?.billSummary?.taxesAndFees?.newMonthCharge,
        );
      } else {
        // Fallback for monthly due and total tax
        setMontlyDue(cart?.orderDetails?.subTotalDueMonthly);
        setTotalTax(
          cart?.lineDetails?.subAccountNBSInfo?.[0]?.billAccounts?.[0]?.billSummary?.taxesAndFees?.newMonthCharge,
        );
      }

      if (cart?.lineDetails?.subAccountNBSInfo?.[0]?.billAccounts) {
        const billAccount = cart?.lineDetails?.subAccountNBSInfo?.[0]?.billAccounts;
        const monthlyTotals = nextBillSummaryData?.nbsVo;
        const billAccountSubAccount = !!(cart?.orderDetails?.subAccountInfo?.length > 0);

        setTotalMonthlyBill(getTotalMonthlyBill(billAccount, monthlyTotals));

        const estimatedNextBillWithBillAccountNo = getEstimatedNextBillWithBillAccountNo(
          billAccount,
          monthlyTotals,
          billAccountSubAccount,
        );
        let estBill = 0;
        if (estimatedNextBillWithBillAccountNo.length > 0) {
          estBill = estimatedNextBillWithBillAccountNo[0].nextMonthCharge;
        } else {
          estBill = cart?.orderDetails?.estimatedNextMonthCharge;
        }
        setTotalEstimatedNextBill(estBill);
      }
      setCustomerType(cart?.orderDetails?.customerType);
      setDueToday(
        (cart?.orderDetails?.totalDueTodayFlag
          ? cart?.orderDetails?.runningTotalDueToday
          : cart?.orderDetails?.totalDueToday) || '',
      );

      setShippingCost(cart?.orderDetails?.totalShippingCost);
      if (isQAFlow) {
        setSubTotalDueToday(cart?.orderDetails?.subTotalDueTodayWithoutDiscount);
        const discount = cart?.lineDetails?.lineInfo?.[0]?.itemsInfo?.[0]?.cartItems?.cartItem?.reduce(
          (sum, item) => sum + (item.discountAmount ? item.discountAmount : 0.0),
          0,
        );
        setDiscountTotal(discount);
      } else {
        setSubTotalDueToday(cart?.orderDetails?.subTotalDueToday);
      }
      setEstimatedNextBill(cart?.orderDetails?.estimatedNextMonthCharge);
      setLineInfo(cart?.lineDetails?.lineInfo);
      setCartId(cart?.cartHeader?.cartId || customerProfile?.data?.customer?.cartId);
      setSubTotalOtherLines(cart?.orderDetails?.subTotalOtherLines);
      if (
        isSplitFulfillmentEnabled(cart?.orderDetails?.itemLevelShipment) &&
        dFillItemPresent(cart?.lineDetails?.lineInfo)
      ) {
        setDepletionType('F');
      } else {
        setDepletionType(data?.data?.cart?.lineDetails?.lineInfo?.[0]?.itemsInfo?.[0]?.depletionType);
      }
    }
  }, [data, nextBillSummaryData, getCartDetailsResults]);

  useEffect(() => {
    if (showManagerApprovalView) {
      handleDiscounts(true);
      setShowManagerApprovalView(false);
    }
  }, [showManagerApprovalView]);

  const callAPi = (giftPurchaseFlag) => {
    if (cartId) {
      const payload = { cartId, intendType: 'AAL', action: 'UPDATE', giftPurchaseFlag };
      getEnrollGiftPurchase({ body: payload, spinner: false, mock: false });
    }
  };

  const readOrderEstbill = () => {
    if (!cartData?.orderDetails?.subAccountInfo) {
      return formatCurrency(totalEstimatedNextBill);
    }
    return formatCurrency(0);
  };

  const openMonthlyChargesDialog = (isShow) => {
    setShowMonthlyCharges(isShow);
  };

  const getISPUFlage = (lines) => {
    const isISPUItemOnCart = lines?.length > 0 ? lines.map((line) => line?.ispuItem || false) : false;
    return isISPUItemOnCart;
  };

  const surCharges = fetchPriceSnapshot?.subAccounts?.[0]?.totals?.surcharges?.regularPrice;
  const totalDueMonthly = enableFullBlownMfeNbsPosFFlag
    ? partialNbsaData?.nbsVo?.monthlyTotalsInfo?.newMonthCharge
    : data?.data?.cart?.orderDetails?.totalDueMonthly;
  const pastDueBalance = data?.data?.cart?.lineDetails?.pastDueBalance;
  // console.log(nextBillSummaryData)
  // console.log('test')
  const checkoutState = useSelector((state) => state);
  useEffect(() => {
    if (enableFullBlownMfeNbsPosFFlag) {
      setEstimatedNextBill(partialNbsaData?.nbsVo?.monthlyTotalsInfo?.nextMonthCharge);
    }
  }, [checkoutState]);
  const ispuInfo = getISPUFlage(lineInfo);
  const ispuItemOnCart = !!(ispuInfo?.length > 0 && ispuInfo?.filter((boolVal) => boolVal).length > 0);

  const device = data?.data?.cart?.lineDetails?.lineInfo?.find((item) => item?.deviceTypeSelected === '5G Internet');
  const is5GInternetSelected = device?.deviceTypeSelected === '5G Internet';

  const serviceShippingAddress = () => {
    let streetAddress = '';
    let addressUnit = '';
    let city = '';
    let state = '';
    let zipCode = '';
    const lineDetails = data?.data?.cart?.lineDetails;
    if (lineDetails?.lineInfo?.length > 0) {
      const line = lineDetails?.lineInfo;
      line.forEach((ele) => {
        if (ele?.lineActivityType === 'AAL_5G' || ele?.lineActivityType === 'NSE_5G') {
          streetAddress = ele?.serviceInfo?.cart5GAddress?.addressLine1 || '';
          addressUnit =
            ele?.serviceInfo?.cart5GAddress?.addressLine2 || ele?.serviceInfo?.cart5GAddress?.apartmentNo || '';
          city = ele?.serviceInfo?.cart5GAddress?.city || '';
          state = ele?.serviceInfo?.cart5GAddress?.state || '';
          zipCode = ele?.serviceInfo?.cart5GAddress?.zipCode || '';
        }
      });
    }
    const phoneNumber = lineDetails?.lineInfo?.[0]?.serviceInfo?.primaryUserInfo?.address?.phoneNumber || '';

    const address = {
      addressLine1: streetAddress,
      city,
      state,
      zipCode,
      phoneNumber,
    };
    return {
      firstName: '',
      lastName: '',
      addressUnit,
      address,
    };
  };

  return (
    <>
      <FlexBox>
        <LeftSideWrapper>
          <ImgWrapper />
        </LeftSideWrapper>
        <InfoWrapper>
          <Padding16>
            <Line type='secondary' />
          </Padding16>
          {pastDueBalance && (
            <BreakdownWrapper>
              <PriceInfo padding='0' />
              <PriceInfo title='Bill amount due' bgColor='white' price={formatCurrency(pastDueBalance)} padding='0' />
            </BreakdownWrapper>
          )}
          <BreakdownWrapper isQAMSF2NSAFFlag={!isQAFlow}>
            {!isQAFlow && (
              <PriceInfo
                padding='0px'
                title='Subtotal due monthly'
                price={formatCurrency(montlyDue)}
                titleWidth='146px'
              />
            )}
            <PriceInfo
              padding='0px'
              title='Subtotal due today'
              bgColor='white'
              price={formatCurrency(subTotalDueToday)}
              titleWidth='146px'
            />
          </BreakdownWrapper>
          {!isQAFlow && mtnCount > 0 && (
            <BreakdownWrapper isQAMSF2NSAFFlag={!isQAFlow}>
              <PriceInfo
                title={`Charges for your other ${mtnCount || 0} lines`}
                price={formatCurrency(subTotalOtherLines || 0)}
                onLinkClick={() => {
                  if (isReadOrderMfeFFlag && readOrder === true) {
                    invokeTagging('openView', 'monthlyCharges');
                  } else {
                    invokeTagging('openView', 'Line Charges');
                  }
                  openMonthlyChargesDialog(true);
                }}
                linkName='View'
                titleWidth='204px'
                padding='0px'
              />
              <PriceInfo bgColor='white' padding='0px' />
            </BreakdownWrapper>
          )}
          {!isQAFlow && (
            <BreakdownWrapper isQAMSF2NSAFFlag={!isQAFlow}>
              <PriceInfo padding='0px' titleWidth='146px' />
              {isReadOrderMfeFFlag && readOrder === true ? (
                <PriceInfo
                  padding='0px'
                  title='Device trade-in credit'
                  bgColor='white'
                  deviceCreditinfo={cartData?.lineDetails?.tradeInDetail?.tradeInItems}
                  address={cartData?.lineDetails?.tradeInDetail}
                  orderStatus={orderStatus}
                  cartDetails={cartData}
                  linkName='ViewTrade'
                  readOrder={readOrder}
                />
              ) : (
                !scmOnlyDeviceMfeEnabled() && (
                  <PriceInfo
                    padding='0px'
                    title='Device trade-in credit'
                    bgColor='white'
                    deviceCreditinfo={cartData?.lineDetails?.tradeInDetail?.tradeInItems}
                    address={cartData?.lineDetails?.tradeInDetail}
                    cartDetails={cartData}
                    linkName='Add'
                    onLinkClick={() => {
                      handleDeviceTradeinClick();
                    }}
                  />
                )
              )}
            </BreakdownWrapper>
          )}
          <BreakdownWrapper isQAMSF2NSAFFlag={!isQAFlow}>
            {isQAFlow && (
              <TileContainerWrapper data-testId='discounts'>
                <TileContainer padding='0' height='auto' width='384px' backgroundColor={isDark ? bgColor : 'white'}>
                  <TileWrapper>
                    <PriceWrapper>
                      <Title>Discounts</Title>
                      <Value>{formatCurrency(discountTotal)}</Value>
                    </PriceWrapper>
                    {orderStatus !== 'CO' && (
                      <LinkWrapper>
                        <TextLink
                          type='standAlone'
                          data-testId='add-discounts'
                          surface={isDark ? 'dark' : 'light'}
                          disabled={false}
                          size='small'
                          onClick={() => {
                            handleDiscounts();
                          }}
                        >
                          {' '}
                          {discountTotal ? `Edit` : `Add`}
                        </TextLink>
                      </LinkWrapper>
                    )}
                  </TileWrapper>
                </TileContainer>
              </TileContainerWrapper>
            )}
            {isDiscountsModalVisible && toggle === 'discounts' && (
              <ManualDiscountView
                handleClose={() => {
                  setToggle('');
                  setisOpenModal(!!isOpenModal);
                  getCartDetailsDataBody({ body: requestBodyRetrieveCart, spinner: true, mock: false });
                }}
                cart={cartData}
                customer={customerProfile?.data?.customer}
                isQAFlow={isQAFlow}
                managerApprovalOnLoad={managerApprovalOnLoad}
              />
            )}
          </BreakdownWrapper>
          <BreakdownWrapper isQAMSF2NSAFFlag={!isQAFlow}>
            {!isQAFlow && <PriceInfo title='Surcharges' price={formatCurrency(surCharges)} padding='0px' />}
            {cartData.lineDetails && cartData.orderDetails && (
              <SalesTax cart={cartData} readOrder={readOrder} isReadOrderMfeFFlag={isReadOrderMfeFFlag} />
            )}
          </BreakdownWrapper>
          {!isQAFlow && (
            <BreakdownWrapper isQAMSF2NSAFFlag={!isQAFlow}>
              <PriceInfo title='Taxes & gov fees' price={formatCurrency(totalTax)} padding='0px' />
              <PriceInfo bgColor='white' padding='0px' />
            </BreakdownWrapper>
          )}
          {isReadOrderMfeFFlag && readOrder && Object.keys(cartData).length > 0 && (
            <StoreTradein cartDetails={cartData} />
          )}
          <BreakdownWrapper blackBorder isQAMSF2NSAFFlag={scmUpgradeMfeEnable}>
            {!ispuItemOnCart &&
              !isQAFlow &&
              !readOrder &&
              (scmUpgradeMfeEnable || isIpad() ? (
                <NotificationInformationContainer>
                  <InStorePickUpNotification
                    cart={cartData}
                    customerProfile={customerProfile}
                    selectedMode={selectedReviewMode}
                    selectedReason={selectedReason}
                    m
                    isLovEnabled={isLovEnabled}
                  />
                </NotificationInformationContainer>
              ) : (
                !isQAFlow && <PriceInfo bgColor='white' />
              ))}
            {depletionType !== 'L' && !hideShippingDetails && (
              <div>
                {pageContext === 'ReadOrder' && isReadOrderMfeFFlag
                  ? !ispuItemOnCart &&
                    !isQAFlow && (
                      <BreakdownWrapper blackBorder isReadOrderMfeFFlag>
                        <InStorePickUpNotification
                          cart={cartData}
                          customerProfile={customerProfile}
                          selectedMode={selectedReviewMode}
                          selectedReason={selectedReason}
                          m
                          isLovEnabled={isLovEnabled}
                          padding='30px 10px 10px 10px'
                        />

                        <PriceInfo
                          title='Shipping'
                          bgColor='white'
                          price={formatCurrency(shippingCost)}
                          shippingAddress
                          linkName='Edit'
                          padding='1rem 0 0'
                          cartDetails={cartData}
                          isQAFlow={isQAFlow}
                        />
                      </BreakdownWrapper>
                    )
                  : !ispuItemOnCart && (
                      <PriceInfo
                        title='Shipping'
                        bgColor='white'
                        price={formatCurrency(shippingCost)}
                        shippingAddress
                        linkName='Edit'
                        padding='1rem 0 0'
                        cartDetails={cartData}
                        isQAFlow={isQAFlow}
                      />
                    )}
                {is5GInternetSelected && (
                  <PriceInfo
                    title='Service Install Address'
                    bgColor='white'
                    shippingAddress
                    address
                    shippingDetails={serviceShippingAddress()}
                    padding='0px'
                  />
                )}
              </div>
            )}
          </BreakdownWrapper>
          {ispuItemOnCart && !isQAFlow && (
            <BreakdownWrapper blackBorder>
              <PriceInfo bgColor='white' />
              <InStorePickUpNotification
                cart={cartData}
                customerProfile={customerProfile}
                selectedMode={selectedReviewMode}
                selectedReason={selectedReason}
                m
                isLovEnabled={isLovEnabled}
              />
            </BreakdownWrapper>
          )}
          <BreakdownWrapper blackBorder isQAMSF2NSAFFlag={!isQAFlow}>
            {!isQAFlow && (
              <PriceInfo
                title={isPartialNbs ? 'Est. ongoing monthly' : 'Est. new monthly'}
                price={
                  readOrder && isReadOrderMfeFFlag ? formatCurrency(totalMonthlyBill) : formatCurrency(totalDueMonthly)
                }
                padding='0'
              />
            )}
            {isDFo ? (
              <DFOPriceInfo
                id='dfoDevice'
                title='Total Payment'
                bgColor={isDark ? bgColor : 'white'}
                price={formatCurrency(dueToday)}
                padding='0'
                dfoCart={dfoCart}
                info={[
                  {
                    payment: 'Paid Today',
                    price: formatCurrency(orderDetailsDFO?.payTodayWithoutDfo),
                    hideMonthly: true,
                    isBold: false,
                    key: 'totalAmount',
                    hasSubText: false,
                  },
                  {
                    payment: `Financed on Verizon Visa Card `,
                    price: formatCurrency(
                      orderDetailsDFO?.accessoryFinancingOfferInfo?.dfoInstallmentInfo?.dfoDevicesTotal,
                    ),
                    key: 'monthlyAmount',
                    hideMonthly: true,
                  },
                  {
                    payment: `Estimated monthly Verizon Visa Card payment (inclusive of tax)`,
                    price: formatCurrency(
                      orderDetailsDFO?.accessoryFinancingOfferInfo?.dfoInstallmentInfo?.monthlyInstallment,
                    ),
                    key: 'estimated',
                  },
                ]}
              />
            ) : (
              <PriceInfo title='Total Payment' bgColor='white' price={formatCurrency(dueToday)} padding='0' />
            )}
            {showConsumerDisclosure && (
              <TileContainerWrapper data-testId='consumerDisclosure'>
                <TileContainer padding='0' height='auto' width='384px' backgroundColor={isDark ? bgColor : 'white'}>
                  <TileWrapper>
                    <PriceWrapper>
                      <DisclosureTitle>Consumer disclosure</DisclosureTitle>
                      <DisclosureLink>
                        <TextLink
                          type='standAlone'
                          data-testId='consumer-disclosure'
                          surface={isDark ? 'dark' : 'light'}
                          disabled={false}
                          size='small'
                          onClick={() =>
                            window.open(
                              'https://infomanager.verizon.com/content/km/categories/account-support/356920.html#/content/km/categories/account-support/356920/overview/356925',
                              '_blank',
                              'noopener',
                            )
                          }
                        >
                          Launch
                        </TextLink>
                      </DisclosureLink>
                    </PriceWrapper>
                  </TileWrapper>
                </TileContainer>
              </TileContainerWrapper>
            )}
          </BreakdownWrapper>
        </InfoWrapper>
      </FlexBox>
      <FlexBox>
        {!isQAFlow && (
          <LeftSideWrapper>
            <CheckboxWrapper>
              {!readOrder && (
                <Checkbox
                  name='default'
                  width='auto'
                  label='Gift Purchase'
                  data-testid='GiftPurchaseId'
                  disabled={false}
                  error={false}
                  errorText='Please agree to the terms and conditions.'
                  onChange={(e) => callAPi(e?.currentTarget?.checked)}
                  surface={isDark ? 'dark' : 'light'}
                >
                  Supress email notifications for order.
                </Checkbox>
              )}
            </CheckboxWrapper>
          </LeftSideWrapper>
        )}

        <InfoWrapper>
          {cartData?.orderDetails?.subAccountInfo?.length > 0 &&
            cartData?.orderDetails?.subAccountInfo?.map((rec) => (
              <PriceInfo
                title={`Total due monthly for ${rec?.subAccountDisplayName}`}
                price={formatCurrency(rec?.totalDueMonthly)}
                variant='blue'
                padding='0px'
              />
            ))}
          {!isQAFlow && (
            <BreakdownWrapper isQAMSF2NSAFFlag={!isQAFlow}>
              <PriceInfo
                title={customerType === 'N' ? '' : estNextBill}
                price={
                  customerType === 'N'
                    ? ''
                    : readOrder && isReadOrderMfeFFlag
                      ? readOrderEstbill()
                      : formatCurrency(estimatedNextBill)
                }
                linkName={customerType === 'N' ? '' : 'Preview your next bill'}
                variant='blue'
                padding='0px'
                cartDetails={cartData}
                subtitle={getSubTitleText()}
                fetchUnifiedNbsData={fetchUnifiedNbsData}
              />
            </BreakdownWrapper>
          )}
        </InfoWrapper>
      </FlexBox>

      {/* <PaperlessBilling cart={data?.data} setPaperLessBilling={setPaperLessBilling} setUpdatedEmail={setUpdatedEmail} /> */}

      {showMonthlyCharges ? (
        <MonthlyChargesModal
          lineInfo={lineInfo}
          opened={showMonthlyCharges}
          toggleModal={(isOpen) => openMonthlyChargesDialog(isOpen)}
        />
      ) : null}
    </>
  );
};

PriceBreakDown.propTypes = {
  data: PropTypes.any,
  customerProfile: PropTypes.any,
  fetchPriceSnapshot: PropTypes.object,
  // setPaperLessBilling: PropTypes.func,
  // setUpdatedEmail: PropTypes.func,
  hideShippingDetails: PropTypes.bool,
  selectedReviewMode: PropTypes.string,
  selectedReason: PropTypes.string,
  isLovEnabled: PropTypes.bool,
  fetchUnifiedNbsData: PropTypes.string,
  readOrderData: PropTypes.object,
  pageContext: PropTypes.string,
  readOrder: PropTypes.bool,
  isQAFlow: PropTypes.bool,
  nextBillSummaryData: PropTypes.object,
  showManagerApprovalView: PropTypes.bool,
  setUpdatedCartDeatilsResult: PropTypes.func,
  setShowManagerApprovalView: PropTypes.func,
};

export default PriceBreakDown;
