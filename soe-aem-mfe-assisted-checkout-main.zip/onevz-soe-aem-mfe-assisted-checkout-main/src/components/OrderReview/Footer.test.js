import React from 'react';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { useGetOffersPdpMutation } from 'onevzsoemfecommon/AccountAPIService';
import StoreProvider from '../../modules/store';
import Footer from './Footer';
import orderWrite from '../../__mock__/getOrderWrite.json';
import cartJson from '../../__mock__/retrive-cart.json';
import mtnsJson from '../../__mock__/getCustomerByMtns.json';
import getRetrieveInstallmentAgreementJson from '../../__mock__/getRetrieveInstallmentAgreement.json';
import retrieveAEMInfoManagerDataJson from '../../__mock__/retrieveAEMInfoManagerDataJson.json';
import * as orderWriteAPICallHook from '../../modules/services/APIService/AgreementsAPICallHook';
import * as GetNextBillSummaryHook from '../../modules/services/APIService/GetNextBillSummary';
import mockNextBillSummary from '../../__mock__/getNextBillSummary.json';
import { scmCheckoutMfeEnabled, scmVtMultitaskMode, isServiceChangeFlag } from '../../utils/common';

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => jest.fn(),
}));

jest.mock('../../utils/common');

jest.mock('./Affirm', () => ({
  __esModule: true,
  default: ({ showAccessoryVvcModal }) => (
    <div>
      <button type='button' data-testid='mocked-giftcard-manual' onClick={showAccessoryVvcModal}>
        Show Verizon Modal
      </button>
    </div>
  ),
}));

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradlePropertyV2: () => ['FALSE'],
  }),
  { virtual: true },
);

jest.mock('./Agreements', () => ({
  __esModule: true,
  default: ({ setShowAgreementModal, handleAgreementData }) => (
    <div>
      <button type='button' data-testid='mocked-agreement-modal' onClick={setShowAgreementModal}>
        Agreement Modal
      </button>
      <button type='button' data-testid='mocked-agreement-data' onClick={handleAgreementData}>
        Agreement data
      </button>
    </div>
  ),
}));

jest.mock('./VerizonOrAffirmFooter', () => ({
  __esModule: true,
  default: ({ setAffirmFinanceChecked, showAccessoryVvcModal }) => (
    <div>
      <button type='button' data-testid='mocked-giftcard-manual' onClick={setAffirmFinanceChecked}>
        verizon Checkbox
      </button>
      <button type='button' data-testid='mocked-giftcard-manual' onClick={showAccessoryVvcModal}>
        show vcc modal
      </button>
    </div>
  ),
}));

jest.mock('onevzsoemfecommon/Helpers', () => ({
  getQueryParamByName: jest.fn(() => 'N'),
}));

jest.mock('onevzsoemfecommon/Helpers/validation', () => ({
  trainingFlag: jest.fn(() => false),
}));

jest.mock('../../modules/services/APIService/GetNextBillSummary', () => () => ({
  // GetNextBillSummaryHook: () => ({
  getNextBillSummaryReq: jest.fn(),
  getNextBillSummaryRes: { data: mockNextBillSummary },
  // }),
}));

jest.mock('onevzsoemfecommon/AccountAPIService', () => ({
  useGetOffersPdpMutation: jest.fn(),
}));

jest.mock('onevzsoemfecommon/PreviewBill', () => ({
  __esModule: true,
  default: ({ closeModal }) => (
    <div>
      <button type='button' data-testid='mocked-closeModal' onClick={closeModal}>
        closeModal PreviewBill Mock
      </button>
    </div>
  ),
}));

const mockSaveOrder = jest.fn();

const mockData = {
  getOrderWrite: mockSaveOrder,
  getOrderWriteResult: { data: orderWrite },
  getRetrieveInstallmentAgreement: mockSaveOrder,
  getRetrieveInstallmentAgreementResult: { data: getRetrieveInstallmentAgreementJson },
  retrieveAEMInfoManagerDataRequest: mockSaveOrder,
  retrieveAEMInfoManagerDataResponse: { data: retrieveAEMInfoManagerDataJson },
  updateAFOInfo: mockSaveOrder,
  getCustomerByMtns: mockSaveOrder,
  getCustomerByMtnsResult: { data: mtnsJson },
};

const mockFunc = {
  getOrderWrite: mockSaveOrder,
  getCustomerByMtns: mockSaveOrder,
};

const props = {
  isDark: true,
  cartDetailsResult: cartJson,
  customer: { regNo: '89878' },
  landing: {
    activeCartandCase: {
      cartId: 'f9a102c8-bd94-476b-8c36-f867597dc8ca',
      caseId: 'SOP-15788985-E01',
    },
    quoteDetails: [{ cartId: 'f9a102c8-bd94-476b-8c36-f867597dc8ca' }],
  },
  showAffirmModal: false,
  isAffirmLoanApproved: false,
  setShowAffirmModal: jest.fn(),
  setContinueBtnDisabled: jest.fn(),
  setShowAffirmAccordion: jest.fn(),
  getCartDetailsDataBody: jest.fn(),
  setEmailValue: jest.fn(),
  verizonVisaCardLinkSent: true,
  setCustomerMtns: jest.fn(),

  customerMtns: [
    {
      mtn: '147852369',
    },
    {
      mtn: '874963512',
    },
    {
      mtn: '785498785',
    },
  ],
  setShowRepGuidedScreen: jest.fn(),
  paperLessBilling: {},
};

const propswithoutmtn = {
  cartDetailsResult: cartJson,
  customer: {},
  landing: {
    activeCartandCase: {
      cartId: 'f9a102c8-bd94-476b-8c36-f867597dc8ca',
      caseId: 'SOP-15788985-E01',
    },
    quoteDetails: [{ cartId: 'f9a102c8-bd94-476b-8c36-f867597dc8ca' }],
  },
  showAffirmModal: false,
  isAffirmLoanApproved: false,
  setShowAffirmModal: jest.fn(),
  setContinueBtnDisabled: jest.fn(),
  setShowAffirmAccordion: jest.fn(),
  getCartDetailsDataBody: jest.fn(),
  setEmailValue: jest.fn(),
  verizonVisaCardLinkSent: true,
  setCustomerMtns: jest.fn(),

  customerMtns: [],
  setShowRepGuidedScreen: jest.fn(),
};

beforeAll(() => {
  class ResizeObserver {
    constructor() {
      this.observe = () => jest.fn();
      this.unobserve = () => jest.fn();
      this.disconnect = () => jest.fn();
    }
  }
  window.ResizeObserver = ResizeObserver;
});

let getOffersMock;
let getOffersResultsMock;

beforeEach(() => {
  getOffersMock = jest.fn();
  getOffersResultsMock = {
    data: null,
    error: null,
    isLoading: false,
    isSuccess: false,
    isError: false,
  };
  useGetOffersPdpMutation.mockReturnValue([getOffersMock, getOffersResultsMock]);
});

beforeEach(() => {
  sessionStorage.setItem('channel', 'OMNI-RETAIL');
});

describe('Footer Component Tests', () => {
  // let getOffersMock;
  // let getOffersResultsMock;

  beforeEach(() => {
    getOffersMock = jest.fn();
    getOffersResultsMock = {
      data: null,
      error: null,
      isLoading: false,
      isSuccess: false,
      isError: false,
    };

    useGetOffersPdpMutation.mockReturnValue([getOffersMock, getOffersResultsMock]);
  });

  test('should call getOffers and handle response', async () => {
    // Update the mock response
    getOffersResultsMock = {
      data: { offers: ['Offer1', 'Offer2'] },
      error: null,
      isLoading: false,
      isSuccess: true,
      isError: false,
    };

    useGetOffersPdpMutation.mockReturnValue([getOffersMock, getOffersResultsMock]);

    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...props} isDark />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('isDark true', async () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const titleElement = screen.getByTestId('ContinueBtn');
    expect(titleElement).toBeInTheDocument();
  });

  test('should handle error response', async () => {
    // Update the mock response to simulate an error
    getOffersResultsMock = {
      data: null,
      error: { message: 'Error fetching offers' },
      isLoading: false,
      isSuccess: false,
      isError: true,
    };

    useGetOffersPdpMutation.mockReturnValue([getOffersMock, getOffersResultsMock]);

    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
  });
});

describe('Footer Component', () => {
  beforeEach(() => {
    sessionStorage.setItem(
      'geoFenceResponse',
      JSON.stringify({ geoFenceCheck: 'false', ipadLatitude: '12.34', ipadLongitude: '56.78', reason: 'Out of range' }),
    );
  });

  test('renders Footer', async () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...propswithoutmtn} />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const titleElement = screen.getByTestId('ContinueBtn');
    expect(titleElement).toBeInTheDocument();
  });
  test('renders Footer', async () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const titleElement = screen.getByTestId('ContinueBtn');
    expect(titleElement).toBeInTheDocument();
  });

  test('Continue CTA click event check - 01', async () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const continueButton = screen.getByText('Continue');
    expect(continueButton).toBeInTheDocument();
    fireEvent.click(continueButton);
  });
  test('Continue CTA click event check - 01', async () => {
    window.mfe = {
      isProspectNewCustomerTab: true,
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const continueButton = screen.getByTestId('footer-area');
    expect(continueButton).toBeInTheDocument();
  });

  test('Continue CTA click event check - 02 OMNI-INDIRECT', () => {
    sessionStorage.setItem('channel', 'OMNI-INDIRECT');
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const continueButton = screen.getByText('Continue');
    expect(continueButton).toBeInTheDocument();
    fireEvent.click(continueButton);
  });

  test('Should open ccd modal after Continue CTA clicked', () => {
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const CcdModal = screen.getByTestId('CcdModal');
    expect(CcdModal).toBeInTheDocument();
  });

  test('Check `I confirm I have read the CCDs to the customer` CTA clicked - 01', () => {
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);
    window.mfe = {
      scmmultitask: true,
      scmCheckoutMfeEnabled: true,
      historyRef: [],
      isDark: true,
      themeProps: { background: '#eeeeee' },
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...props} profInstallappointmentFlag />
        </StoreProvider>
      </BrowserRouter>,
    );
    const CcdModal = screen.getByTestId('CcdModal');
    expect(CcdModal).toBeInTheDocument();
    const ccdModalBtn = screen.getByTestId('CcdModalBtn');
    expect(ccdModalBtn).toBeInTheDocument();
    fireEvent.click(ccdModalBtn);
    const agreementModal = screen.getByTestId('mocked-agreement-modal');
    fireEvent.click(agreementModal);

    const agreementData = screen.getByTestId('mocked-agreement-data');
    fireEvent.click(agreementData);
  });

  test('Check `I confirm I have read the CCDs to the customer` CTA clicked - 02', () => {
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);
    window.mfe = { scmCheckoutMfeEnable: true, historyRef:[] };
    props.cartDetailsResult.data.cart.flow = 'STANDALONETRADEIN';
    props.cartDetailsResult.data.cart.orderDetails.orderChannelId = 'VZW-ACSS'
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const CcdModal = screen.getByTestId('CcdModal');
    expect(CcdModal).toBeInTheDocument();
    const ccdModalBtn = screen.getByTestId('CcdModalBtn');
    expect(ccdModalBtn).toBeInTheDocument();
    fireEvent.click(ccdModalBtn);
  });

  test('Check `I confirm I have read the CCDs to the customer` CTA clicked - 03', () => {
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);

    const newProps = {
      ...props,
      profInstallappointmentFlag: false,
      isAllSetDoneFlow: true,
      onAllSetDoneClick: jest.fn(),
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...newProps} isAllSetDone />
        </StoreProvider>
      </BrowserRouter>,
    );
    const CcdModal = screen.getByTestId('CcdModal');
    expect(CcdModal).toBeInTheDocument();
  });

  test('CCD Cta checked and verizon visa checked', () => {
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);
    const newProps = {
      ...props,
      verizonVisaCardLinkSent: false,
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...newProps} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const CcdModal = screen.getByTestId('CcdModal');
    expect(CcdModal).toBeInTheDocument();
    const ccdModalBtn = screen.getByTestId('CcdModalBtn');
    expect(ccdModalBtn).toBeInTheDocument();
    fireEvent.click(ccdModalBtn);
  });

  test('CCD Cta checked and verizon visa checked 2', () => {
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);
    const newProps = {
      ...props,
      profInstallappointmentFlag: true,
      isAllSetDoneFlow: false,
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...newProps} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const CcdModal = screen.getByTestId('CcdModal');
    expect(CcdModal).toBeInTheDocument();
    const ccdModalBtn = screen.getByTestId('CcdModalBtn');
    expect(ccdModalBtn).toBeInTheDocument();
    fireEvent.click(ccdModalBtn);
  });

  test('CCD Cta checked and verizon visa checked 3', () => {
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);
    const newProps = {
      ...props,
      profInstallappointmentFlag: false,
      isAllSetDoneFlow: true,
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...newProps} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const CcdModal = screen.getByTestId('CcdModal');
    expect(CcdModal).toBeInTheDocument();
    const ccdModalBtn = screen.getByTestId('CcdModalBtn');
    expect(ccdModalBtn).toBeInTheDocument();
    fireEvent.click(ccdModalBtn);
  });

  test('Check `I confirm I have read the CCDs to the customer` CTA clicked - 02', () => {
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);
    sessionStorage.setItem('customerType', 'N');
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const CcdModal = screen.getByTestId('CcdModal');
    expect(CcdModal).toBeInTheDocument();
    const ccdModalBtn = screen.getByTestId('CcdModalBtn');
    expect(ccdModalBtn).toBeInTheDocument();
    fireEvent.click(ccdModalBtn);
  });

  test('Change in the props, intent type will be Inline-CPC in payload', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData2);
    sessionStorage.setItem('customerType', 'N');
    window.mfe = { scmCheckoutMfeEnable: false };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            cartDetailsResult={{
              data: {
                cart: {
                  lineDetails: {
                    acctMcsSubscription: [
                      {
                        isTrue: true,
                      },
                    ],
                  },
                },
              },
            }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const CcdModal = screen.getByTestId('CcdModal');
    expect(CcdModal).toBeInTheDocument();
    const ccdModalBtn = screen.getByTestId('CcdModalBtn');
    expect(ccdModalBtn).toBeInTheDocument();
    fireEvent.click(ccdModalBtn);
  });

  test('Change in the props, intent type will be Inline-CPC in payload 1', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData2);
    sessionStorage.setItem('customerType', 'N');
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] };
    scmCheckoutMfeEnabled.mockImplementation(() => true);
    scmVtMultitaskMode.mockImplementation(() => true);
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ cpcChargebackFFlag: 'TRUE' }));
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            cartDetailsResult={{
              data: {
                cart: {
                  lineDetails: {
                    lineInfo: [
                      {
                        lineActivityType: 'CPC',
                        tanglewoodSelected: 'Y',
                        itemsInfo: [
                          {
                            cartItems: {
                              cartItem: [{ id: 1 }],
                            },
                          },
                        ],
                        "disqualifiedPropositions": [
                                {
                                    "versionId": "5059350",
                                    "description": "NFL Sunday Ticket on us - Mobile AAL or New or Upgrade ANDROID DEVICES",
                                    "offerTypeCd": "3PO",
                                    "name": "NFL Sunday Ticket on us - Mobile AAL/New/Upgrade",
                                    "id": "603262",
                                    "actionCode": "D",
                                    "priorDQ": "N",
                                    "amount": 0.0,
                                    "chargeBackAmount": "449",
                                    "chargeBackBillDesc": "NFL Sunday Ticket on us - Mobile AAL or New or Upgrade ANDROID DEVICES"
                                }
                            ],
                      },
                      {
                        lineActivityType: 'FEA',
                        itemsInfo: [
                          {
                            cartItems: {
                              cartItem: [{ id: 1 }],
                            },
                          },
                        ],
                      },
                    ],
                  },
                  cartHeader: {
                    sourceSystem: 'SomeSource',
                  },
                },
              },
            }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const CcdModal = screen.getByTestId('CcdModal');
    expect(CcdModal).toBeInTheDocument();
    const ccdModalBtn = screen.getByTestId('CcdModalBtn');
    expect(ccdModalBtn).toBeInTheDocument();
    fireEvent.click(ccdModalBtn);
  });

  test('Change in the props, intent type will be Inline-CPC in payload 2', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData2);
    sessionStorage.setItem('customerType', 'N');
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] };
    scmCheckoutMfeEnabled.mockImplementation(() => true);
    scmVtMultitaskMode.mockImplementation(() => true);
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            cartDetailsResult={{
              data: {
                cart: {
                  lineDetails: {
                    acctMcsSubscription: [
                      {
                        isTrue: true,
                      },
                    ],
                  },
                },
              },
            }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const CcdModal = screen.getByTestId('CcdModal');
    expect(CcdModal).toBeInTheDocument();
    const ccdModalBtn = screen.getByTestId('CcdModalBtn');
    expect(ccdModalBtn).toBeInTheDocument();
    fireEvent.click(ccdModalBtn);
  });
  test('Change in the props, intent type will be Inline-CPC in payload 2', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData2);
    sessionStorage.setItem('customerType', 'N');
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] };
    scmCheckoutMfeEnabled.mockImplementation(() => true);
    scmVtMultitaskMode.mockImplementation(() => false);
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            cartDetailsResult={{
              data: {
                cart: {
                  lineDetails: {
                    acctMcsSubscription: [
                      {
                        isTrue: true,
                      },
                    ],
                  },
                },
              },
            }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const CcdModal = screen.getByTestId('CcdModal');
    expect(CcdModal).toBeInTheDocument();
    const ccdModalBtn = screen.getByTestId('CcdModalBtn');
    expect(ccdModalBtn).toBeInTheDocument();
    fireEvent.click(ccdModalBtn);
  });

  test('Change in the props, intent type will be Inline-CPC in payload 3', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData2);
    sessionStorage.setItem('customerType', 'N');
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] };
    scmCheckoutMfeEnabled.mockImplementation(() => true);
    scmVtMultitaskMode.mockImplementation(() => true);
    const modifiedCartDetailsResult = {
      ...cartJson,
      data: {
        ...cartJson.data,
        cart: {
          ...cartJson.data.cart,
          cartHeader: {
            ...cartJson.data.cart.cartHeader,
            cartId: undefined,
          },
        },
      },
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...props} cartDetailsResult={modifiedCartDetailsResult} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const CcdModal = screen.getByTestId('CcdModal');
    expect(CcdModal).toBeInTheDocument();
    const ccdModalBtn = screen.getByTestId('CcdModalBtn');
    expect(ccdModalBtn).toBeInTheDocument();
    fireEvent.click(ccdModalBtn);
  });

  test('Change in the props, intent type will be StandAloneTradeIn in payload', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData2);
    sessionStorage.setItem('customerType', 'N');
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            cartDetailsResult={{
              data: {
                cart: {
                  lineDetails: {
                    lineInfo: [],
                    tradeInDetail: {
                      tradeInItems: [
                        {
                          equipModel: 'Samsung Galaxy S10 128GB in Prism Black',
                          imgUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/samsung-galaxy-s10-black?$device-lg$',
                          color: 'Black',
                          size: '128GB',
                          recycleSeqNum: '1',
                          creditType: 'ACT',
                          emailAddress: 'AVISEKH.CHAKRABORTY@VERIZON.COM',
                          tradeDeviceMDN: '6122193526',
                          submissionId: '807753849913581',
                          buyoutDevice: 'false',
                          tradeInAutoPull: false,
                          tradeInStatus: 'Complete',
                          fmiLocked: 'false',
                          status: 'A',
                        },
                      ],
                    },
                  },
                },
              },
            }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const CcdModal = screen.getByTestId('CcdModal');
    expect(CcdModal).toBeInTheDocument();
    const ccdModalBtn = screen.getByTestId('CcdModalBtn');
    expect(ccdModalBtn).toBeInTheDocument();
    fireEvent.click(ccdModalBtn);
  });

  test('Change in the Customer Type', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData2);
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            cartDetailsResult={{
              data: {
                cart: {
                  orderDetails: {
                    customerType: 'N',
                    spocs: {
                      notificationOptions: {
                        contactPhoneNumber: '9703050307',
                        primaryEmailId: 'ABHISEKH.PATRO@ONE.VERIZON.COM',
                      },
                    },
                  },
                },
              },
            }}
            updatedEmail={null}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const CcdModal = screen.getByTestId('CcdModal');
    expect(CcdModal).toBeInTheDocument();
    const ccdModalBtn = screen.getByTestId('CcdModalBtn');
    expect(ccdModalBtn).toBeInTheDocument();
    fireEvent.click(ccdModalBtn);
  });

  test('Should close modal onclick of modal close button', () => {
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData);
    const response = [
      {
        rank: '1',
        propositionId: '107610',
        dispositionOptionId: '18',
        offerContainerId: '500020498',
        soiEngagementId: '555733',
        isPromoBundleEligible: 'N',
        offerSubType: 'Multi Line BOGO',
        offerId: '555733',
        mtn: '6037679700',
        itemCode: '',
        tacticLocation: 'ETR_Promotions_National',
        timeStamp: '2024-02-16T11:25:55+05:30',
        buyGetSku: 'MTU63LL/A',
        isSaveOffer: 'N',
        isHomeOffer: 'N',
      },
      {
        rank: '3',
        propositionId: '103239',
        dispositionOptionId: '25',
        offerContainerId: '500020498',
        soiEngagementId: '594560',
        isPromoBundleEligible: 'N',
        offerSubType: 'Simple',
        offerId: '594560',
        mtn: '6037679700',
        itemCode: '',
        tacticLocation: 'ETR_Promotions_National',
        timeStamp: '2024-02-16T11:25:55+05:30',
        buyGetSku: '',
        isSaveOffer: 'N',
        isHomeOffer: 'N',
      },
    ];

    sessionStorage.setItem('responseList', JSON.stringify(response));
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ isMitekSimSwapEnabled: 'TRUE' }));
    sessionStorage.setItem(
      'locationData',
      JSON.stringify({
        city: 'Schaumburg',
        state: 'IL',
      }),
    );
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            landing={{
              activeCartandCase: {
                cartId: 'f9a102c8-bd94-476b-8c36-f867597dc8ca',
                caseId: 'SOP-15788985-E01',
              },
            }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const modalCloseBtn = screen.getAllByTestId('modal-close-button');
    fireEvent.click(modalCloseBtn[0]);
    expect(window.vzdl.page.detail).toEqual('');
  });

  test('Error scenario', () => {
    const mockData2 = {
      getOrderWrite: mockSaveOrder,
      getOrderWriteResult: { data: { errors: [{ id: '3251' }], errorMessage: 'eror' } },
      getRetrieveInstallmentAgreement: mockSaveOrder,
      getRetrieveInstallmentAgreementResult: { data: getRetrieveInstallmentAgreementJson },
      retrieveAEMInfoManagerDataRequest: mockSaveOrder,
      retrieveAEMInfoManagerDataResponse: { data: retrieveAEMInfoManagerDataJson },
      getCustomerByMtns: mockSaveOrder,
    };
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] };
    scmCheckoutMfeEnabled.mockImplementation(() => true);
    scmVtMultitaskMode.mockImplementation(() => false);
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData2);
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const ccdModalBtn = screen.getByTestId('CcdModalBtn');
    fireEvent.click(ccdModalBtn);
  });
  test('Error scenario', () => {
    const mockData2 = {
      getOrderWrite: mockSaveOrder,
      getOrderWriteResult: { data: { errors: [{ id: '3251' }], errorMessage: 'eror' } },
      getRetrieveInstallmentAgreement: mockSaveOrder,
      getRetrieveInstallmentAgreementResult: { data: getRetrieveInstallmentAgreementJson },
      retrieveAEMInfoManagerDataRequest: mockSaveOrder,
      retrieveAEMInfoManagerDataResponse: { data: retrieveAEMInfoManagerDataJson },
      getCustomerByMtns: mockSaveOrder,
    };
    window.mfe = { scmCheckoutMfeEnable: true };
    scmCheckoutMfeEnabled.mockImplementation(() => true);
    scmVtMultitaskMode.mockImplementation(() => true);
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData2);
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const ccdModalBtn = screen.getByTestId('CcdModalBtn');
    fireEvent.click(ccdModalBtn);
  });
  test('Error scenario', () => {
    const mockData2 = {
      getOrderWrite: mockSaveOrder,
      getOrderWriteResult: { data: { errors: [{ id: '3251' }], errorMessage: 'eror' } },
      getRetrieveInstallmentAgreement: mockSaveOrder,
      getRetrieveInstallmentAgreementResult: { data: getRetrieveInstallmentAgreementJson },
      retrieveAEMInfoManagerDataRequest: mockSaveOrder,
      retrieveAEMInfoManagerDataResponse: { data: retrieveAEMInfoManagerDataJson },
      getCustomerByMtns: mockSaveOrder,
    };
    window.mfe = { scmCheckoutMfeEnable: false };
    scmCheckoutMfeEnabled.mockImplementation(() => false);
    scmVtMultitaskMode.mockImplementation(() => true);
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData2);
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const ccdModalBtn = screen.getByTestId('CcdModalBtn');
    fireEvent.click(ccdModalBtn);
  });

  test('If props are not passed to componet', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData2);
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            setEmailValue={jest.fn()}
            getCartDetailsDataBody={jest.fn()}
            cartDetailsResult={{
              data: {
                cart: {
                  orderDetails: {
                    customerType: 'N',
                  },
                },
              },
            }}
            updatedEmail={null}
            setCustomerMtns={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const CcdModal = screen.getByTestId('CcdModal');
    expect(CcdModal).toBeInTheDocument();
    const ccdModalBtn = screen.getByTestId('CcdModalBtn');
    expect(ccdModalBtn).toBeInTheDocument();
    fireEvent.click(ccdModalBtn);
  });

  test('If props are not passed to componet 1', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData2);
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            setEmailValue={jest.fn()}
            getCartDetailsDataBody={jest.fn()}
            cartDetailsResult={{
              data: {
                cart: {
                  orderDetails: {
                    customerType: 'y',
                  },
                },
              },
            }}
            updatedEmail={null}
            setCustomerMtns={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const CcdModal = screen.getByTestId('CcdModal');
    expect(CcdModal).toBeInTheDocument();
    const ccdModalBtn = screen.getByTestId('CcdModalBtn');
    expect(ccdModalBtn).toBeInTheDocument();
    fireEvent.click(ccdModalBtn);
  });
  test('check credit application button', () => {
    sessionStorage.setItem('channel', 'OMNI-RETAIL');

    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockFunc);
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const checkboxButton = screen.getByText('verizon Checkbox');
    expect(checkboxButton).toBeInTheDocument();
    fireEvent.click(checkboxButton);
    const creditCheckButton = screen.getByText('Affirm credit application');
    expect(creditCheckButton).toBeInTheDocument();
    fireEvent.click(creditCheckButton);
    sessionStorage.getItem('channel');
  });
  test('show vccmodal and close the modal', () => {
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockFunc);
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const checkboxButton = screen.getByText('show vcc modal');
    expect(checkboxButton).toBeInTheDocument();
    fireEvent.click(checkboxButton);
    const creditCheckButton = screen.getByText('Close');
    expect(creditCheckButton).toBeInTheDocument();
    fireEvent.click(creditCheckButton);
  });

  test('Should open ccd modal after all set done CTA clicked', () => {
    const nextBillSumaryMockData = {};
    const nextBillSummary = {};

    jest
      .spyOn(orderWriteAPICallHook, 'default')
      .mockImplementation(() => ({ ...mockData, retrieveAEMInfoManagerDataResponse: null }));
    jest
      .spyOn(GetNextBillSummaryHook, 'default')
      .mockImplementation(() => ({ ...nextBillSumaryMockData, getNextBillSummaryRes: { data: nextBillSummary } }));
    scmCheckoutMfeEnabled.mockReturnValue(false);
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...props} isAllSetDone />
        </StoreProvider>
      </BrowserRouter>,
    );

    const AllSetDoneBtn = screen.getByTestId('AllSetDoneBtn');
    expect(AllSetDoneBtn).toBeInTheDocument();

    fireEvent.click(AllSetDoneBtn);
  });

  test('Should open ccd modal after all set done CTA clicked 1', async () => {
    const nextBillSumaryMockData = {};
    const nextBillSummary = {};
    jest
      .spyOn(orderWriteAPICallHook, 'default')
      .mockImplementation(() => ({ ...mockData, retrieveAEMInfoManagerDataResponse: null }));
    jest
      .spyOn(GetNextBillSummaryHook, 'default')
      .mockImplementation(() => ({ ...nextBillSumaryMockData, getNextBillSummaryRes: { data: nextBillSummary } }));
    scmCheckoutMfeEnabled.mockReturnValue(true);
    scmVtMultitaskMode.mockReturnValue(true);
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...props} isAllSetDone />
        </StoreProvider>
      </BrowserRouter>,
    );

    const AllSetDoneBtn = screen.getByTestId('AllSetDoneBtn');
    expect(AllSetDoneBtn).toBeInTheDocument();

    fireEvent.click(AllSetDoneBtn);

    waitFor(() => {
      const CcdModalBtn = screen.getByTestId('CcdModalBtn');
      fireEvent.click(CcdModalBtn);
      expect(CcdModalBtn).toBeInTheDocument();
    });
  });
  test('get offers api call not called for acss checout page', async () => {
    const nextBillSumaryMockData = {};
    const nextBillSummary = {};
    jest
      .spyOn(orderWriteAPICallHook, 'default')
      .mockImplementation(() => ({ ...mockData, retrieveAEMInfoManagerDataResponse: null }));
    jest
      .spyOn(GetNextBillSummaryHook, 'default')
      .mockImplementation(() => ({ ...nextBillSumaryMockData, getNextBillSummaryRes: { data: nextBillSummary } }));
    scmCheckoutMfeEnabled.mockReturnValue(false);
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...props} isAllSetDone />
        </StoreProvider>
      </BrowserRouter>,
    );

    const AllSetDoneBtn = screen.getByTestId('AllSetDoneBtn');
    expect(AllSetDoneBtn).toBeInTheDocument();

    fireEvent.click(AllSetDoneBtn);

    waitFor(() => {
      const CcdModalBtn = screen.getByTestId('CcdModalBtn');
      fireEvent.click(CcdModalBtn);
      expect(CcdModalBtn).toBeInTheDocument();
    });

    const mockedCloseModal = screen.getByTestId('mocked-closeModal');
    expect(mockedCloseModal).toBeInTheDocument();
    fireEvent.click(mockedCloseModal);
  });

  test('Should open ccd modal after all set done CTA clicked with ccdForServiceChange Flag', () => {
    const nextBillSumaryMockData = {};
    const nextBillSummary = {};
    sessionStorage.setItem('assistedFlags', JSON.stringify({ ccdForServiceChange: 'TRUE' }));
    jest
      .spyOn(orderWriteAPICallHook, 'default')
      .mockImplementation(() => ({ ...mockData, retrieveAEMInfoManagerDataResponse: null }));
    jest
      .spyOn(GetNextBillSummaryHook, 'default')
      .mockImplementation(() => ({ ...nextBillSumaryMockData, getNextBillSummaryRes: { data: nextBillSummary } }));
    window.mfe = { scmCheckoutMfeEnable: true };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...props} isAllSetDone />
        </StoreProvider>
      </BrowserRouter>,
    );

    const AllSetDoneBtn = screen.getByTestId('AllSetDoneBtn');
    expect(AllSetDoneBtn).toBeInTheDocument();

    fireEvent.click(AllSetDoneBtn);
  });
  test('Continue button should be disabled when QA NSE flow and no shipping address', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} } };
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData2);
    const newCartJson = JSON.parse(JSON.stringify(cartJson));
    newCartJson.data.cart.lineDetails.lineInfo[0].itemsInfo[0].shipping.address = null;
    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer {...props} cartDetailsResult={newCartJson} hideContinue={false} isQAFlow />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('Continue button when QA flow - no manager approval required on discount', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} }, retrieveAEMInfoManagerDataResponse: null };
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData2);
    const newCartJson = JSON.parse(JSON.stringify(cartJson));
    newCartJson.data.cart.orderDetails.accessoryFinancingOfferInfo = null;
    newCartJson.data.cart.orderDetails.affirmFinancingOfferInfo = null;

    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            cartDetailsResult={newCartJson}
            hideContinue={false}
            showViewTogether={false}
            hideViewTogether
            isAllSetDone={false}
            hideOrderDetails={false}
            isQAFlow
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const ContinueBtn = screen.getByTestId('ContinueBtn');
    expect(ContinueBtn).toBeInTheDocument();

    fireEvent.click(ContinueBtn);
  });

  test('Continue button when QA flow - manager approval required on discount', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} }, retrieveAEMInfoManagerDataResponse: null };
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData2);
    const newCartJson = JSON.parse(JSON.stringify(cartJson));
    newCartJson.data.cart.orderDetails.accessoryFinancingOfferInfo = null;
    newCartJson.data.cart.orderDetails.affirmFinancingOfferInfo = null;
    newCartJson.data.cart.orderDetails.orderList[0].managerApprovalRequired = true;

    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            cartDetailsResult={newCartJson}
            hideContinue={false}
            showViewTogether={false}
            hideViewTogether
            isAllSetDone={false}
            hideOrderDetails={false}
            isQAFlow
            setShowManagerApprovalView={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const ContinueBtn = screen.getByTestId('ContinueBtn');
    expect(ContinueBtn).toBeInTheDocument();

    fireEvent.click(ContinueBtn);
  });
});

describe('Footer Component - ispu new customer', () => {
  beforeEach(() => {
    sessionStorage.setItem(
      'geoFenceResponse',
      JSON.stringify({ geoFenceCheck: 'false', ipadLatitude: '12.34', ipadLongitude: '56.78', reason: 'Out of range' }),
    );
  });

  test('Continue button when QA flow - no manager approval required on discount', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} }, retrieveAEMInfoManagerDataResponse: null };
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData2);
    const newCartJson = JSON.parse(JSON.stringify(cartJson));
    newCartJson.data.cart.cartHeader.cartCreator = '';
    newCartJson.data.cart.lineDetails ={
      lineInfo:[{
        ispuItem : true
      }]
    }
    newCartJson.data.cart.orderDetails.accessoryFinancingOfferInfo = null;
    newCartJson.data.cart.orderDetails.affirmFinancingOfferInfo = null;

    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            cartDetailsResult={newCartJson}
            hideContinue={false}
            showViewTogether={false}
            hideViewTogether
            isAllSetDone={false}
            hideOrderDetails={false}
            isQAFlow
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const ContinueBtn = screen.getByTestId('ContinueBtn');
    expect(ContinueBtn).toBeInTheDocument();

    fireEvent.click(ContinueBtn);
  });

  test('Continue button when QA flow - manager approval required on discount', () => {
    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} }, retrieveAEMInfoManagerDataResponse: null };
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData2);
    const newCartJson = JSON.parse(JSON.stringify(cartJson));
    newCartJson.data.cart.orderDetails.accessoryFinancingOfferInfo = null;
    newCartJson.data.cart.orderDetails.affirmFinancingOfferInfo = null;
    newCartJson.data.cart.orderDetails.orderList[0].managerApprovalRequired = true;

    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            cartDetailsResult={newCartJson}
            hideContinue={false}
            showViewTogether={false}
            hideViewTogether
            isAllSetDone={false}
            hideOrderDetails={false}
            isQAFlow
            setShowManagerApprovalView={jest.fn()}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const ContinueBtn = screen.getByTestId('ContinueBtn');
    expect(ContinueBtn).toBeInTheDocument();

    fireEvent.click(ContinueBtn);
  });

  test('Continue button should be disabled when trainingFlag returns true', () => {
    const { trainingFlag } = require('onevzsoemfecommon/Helpers/validation');
    trainingFlag.mockReturnValue(true);

    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} }, retrieveAEMInfoManagerDataResponse: null };
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData2);
    const newCartJson = JSON.parse(JSON.stringify(cartJson));
    newCartJson.data.cart.orderDetails.accessoryFinancingOfferInfo = null;
    newCartJson.data.cart.orderDetails.affirmFinancingOfferInfo = null;

    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            cartDetailsResult={newCartJson}
            hideContinue={false}
            showViewTogether={false}
            hideViewTogether
            isAllSetDone={false}
            hideOrderDetails={false}
            continueBtnDisabled={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const ContinueBtn = screen.getByTestId('ContinueBtn');
    expect(ContinueBtn).toBeInTheDocument();
    expect(ContinueBtn).toBeDisabled();
  });

  test('Continue button should be enabled when trainingFlag returns false', () => {
    const { trainingFlag } = require('onevzsoemfecommon/Helpers/validation');
    trainingFlag.mockReturnValue(false);

    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} }, retrieveAEMInfoManagerDataResponse: null };
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData2);
    const newCartJson = JSON.parse(JSON.stringify(cartJson));
    newCartJson.data.cart.orderDetails.accessoryFinancingOfferInfo = null;
    newCartJson.data.cart.orderDetails.affirmFinancingOfferInfo = null;

    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            cartDetailsResult={newCartJson}
            hideContinue={false}
            showViewTogether={false}
            hideViewTogether
            isAllSetDone={false}
            hideOrderDetails={false}
            continueBtnDisabled={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const ContinueBtn = screen.getByTestId('ContinueBtn');
    expect(ContinueBtn).toBeInTheDocument();
    expect(ContinueBtn).not.toBeDisabled();
  });

  test('Continue button should be disabled when isPosTrainingEnabled is true in QA flow', () => {
    const { trainingFlag } = require('onevzsoemfecommon/Helpers/validation');
    trainingFlag.mockReturnValue(true);

    const mockData2 = { ...mockData, getOrderWriteResult: { data: {} }, retrieveAEMInfoManagerDataResponse: null };
    jest.spyOn(orderWriteAPICallHook, 'default').mockImplementation(() => mockData2);
    const newCartJson = JSON.parse(JSON.stringify(cartJson));
    newCartJson.data.cart.orderDetails.accessoryFinancingOfferInfo = null;
    newCartJson.data.cart.orderDetails.affirmFinancingOfferInfo = null;

    render(
      <BrowserRouter>
        <StoreProvider>
          <Footer
            {...props}
            cartDetailsResult={newCartJson}
            hideContinue={false}
            showViewTogether={false}
            hideViewTogether
            isAllSetDone={false}
            hideOrderDetails={false}
            isQAFlow
            continueBtnDisabled={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const ContinueBtn = screen.getByTestId('ContinueBtn');
    expect(ContinueBtn).toBeInTheDocument();
    expect(ContinueBtn).toBeDisabled();
  });
});
