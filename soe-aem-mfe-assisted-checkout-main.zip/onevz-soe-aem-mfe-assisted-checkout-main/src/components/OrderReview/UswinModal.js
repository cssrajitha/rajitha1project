import { Modal, ModalTitle, ModalBody, ModalFooter } from '@vds/modals';
import { Input } from '@vds/inputs';
import { Body } from '@vds/typography';
import styled from 'styled-components';
import PropTypes from 'prop-types';

const InputWrap = styled(Input)`
  height: 60% !important;
  margin-bottom: -4px;
`;

const UswinModal = ({
  uswinModalEnable,
  uswinCloseModal,
  CustomerProfileResult,
  uswinStatus,
  handleUswinChange,
  uswinStatusMessage,
  handleSubmitUswin,
}) => {
  console.log('123');
  return (
    <div data-testid='uswin_modal'>
      <Modal
        opened={uswinModalEnable}
        surface='light'
        fullScreenDialog={false}
        disableAnimation={false}
        disableOutsideClick={false}
        ariaLabel='Testing Modal'
        width='55rem'
        maxHeight
        onOpenedChange={uswinCloseModal}
      >
        <ModalTitle>Secondary Verification For High Risk Transaction</ModalTitle>
        <ModalBody>
          <InputWrap
            type='text'
            label='USWIN'
            readOnly
            required
            value={CustomerProfileResult?.data?.data?.customer?.loggedInUser}
          />
          <InputWrap
            data-testid='uswin_authentication'
            type='password'
            label='Password'
            disabled={/true/i.test(sessionStorage.getItem('uswinAuthFailed')) || uswinStatus.limit >= 5}
            readOnly={false}
            required
            error={false}
            errorText='Password does not match.'
            onChange={handleUswinChange}
          />
          {uswinStatus.limit > 0 && (
            <Body size='large' bold>
              {uswinStatusMessage}
            </Body>
          )}
        </ModalBody>
        <ModalFooter
          data-testid='uswin_authentication_footer'
          buttonData={{
            primary: {
              width: '12rem',
              children: 'Continue',
              onClick: handleSubmitUswin,
              disabled:
                /true/i.test(sessionStorage.getItem('uswinAuthFailed')) ||
                uswinStatus.limit >= 5 ||
                uswinStatus?.disableContinueBtn,
            },
          }}
        />
        <Body size='large' color='red' bold>
          Note: You are about to complete a high risk transaction. A secondary verification is required to proceed
        </Body>
      </Modal>
    </div>
  );
};

export default UswinModal;

UswinModal.propTypes = {
  uswinModalEnable: PropTypes.any,
  uswinCloseModal: PropTypes.any,
  CustomerProfileResult: PropTypes.any,
  uswinStatus: PropTypes.any,
  handleUswinChange: PropTypes.any,
  uswinStatusMessage: PropTypes.any,
  handleSubmitUswin: PropTypes.any,
};
