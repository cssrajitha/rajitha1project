import { fireEvent, render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../modules/store';
import retriveCartJson from '../../__mock__/retrive-cart.json';
import multiCartJson from '../../__mock__/cart_multiple.json';
import PriceInfo from './PriceInfo';
import { useLazyGetCartDetailsQuery } from '../../modules/services/APIService/APIServiceCallHook';
import { readOrderResponse } from './Refund/__mock__/readOrderResponse';

jest.mock('./EditTradein', () => ({
  __esModule: true,
  default: ({ onRemove, closeModal }) => (
    <div>
      <button type='button' data-testid='mocked-giftcard-manual' onClick={onRemove}>
        Remove button
      </button>
      <button type='button' data-testid='mocked-giftcard-manual' onClick={closeModal}>
        close modal
      </button>
    </div>
  ),
}));

jest.mock('./CompareToCurrentPlan', () => ({
  __esModule: true,
  default: ({ compareToCurrentRequest }) => (
    <div>
      <button type='button' data-testid='mocked-comapreTocurrentRq-manual' onClick={compareToCurrentRequest}>
        load New Modal{' '}
      </button>
    </div>
  ),
}));

jest.mock('./PreviewBill', () => ({
  __esModule: true,
  default: ({ closeModal }) => (
    <div>
      <button type='button' data-testid='mocked-giftcard-manual' onClick={closeModal}>
        Close preview modal
      </button>
    </div>
  ),
}));

jest.mock('../../modules/services/APIService/GetNextBillSummary', () => () => ({
  getNextBillSummaryReq: jest.fn(),
  getNextBillSummaryRes: { data: { nbsVo: 1 } },
}));

jest.mock('../../modules/services/APIService/APIServiceCallHook', () => ({
  useLazyGetCartDetailsQuery: jest.fn(),
}));
beforeAll(() => {
  sessionStorage.setItem(
    'APP_PROPERTIES',
    JSON.stringify({ readOrderMfeFFlag: 'TRUE', isCheckoutMFEFlowEnabled: 'TRUE' }),
  );
});

describe('PriceInfo Component with onLinkClick', () => {
  beforeAll(() => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
  });
  beforeEach(() => {
    window.mfe = { scmUpgradeMfeEnable: false };
    useLazyGetCartDetailsQuery.mockReturnValue([jest.fn().mockResolvedValue({ data: readOrderResponse })]);
  });

  test('Plans for viewplans', () => {
    sessionStorage.setItem('readOrder', 'true');
    const {
      data: {
        cart: {
          lineDetails: { lineInfo },
        },
      },
    } = retriveCartJson;
    const [lineInfo1] = lineInfo;
    const { itemsInfo } = lineInfo1;
    const { shipping } = itemsInfo[0];
    const onLinkClick = jest.fn();
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceInfo
            line={{
              serviceInfo: {
                newPricePlanInfo: {
                  pricePlanCode: '12345',
                },

                pricePlanInfo: {
                  pricePlanCode: '12345',
                },
              },
            }}
            title='Shipping'
            bgColor='white'
            price='$99.00'
            shippingAddress
            shippingDetails={shipping}
            cartDetails={multiCartJson}
            linkName='Edit'
            address={{
              tradeInShippingType: 'upsdrop-off_qrcode',
            }}
            onLinkClick={onLinkClick}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const link = screen.getByTestId('link');
    fireEvent.click(link);
    const comapreTocurrentRq = screen.getByTestId('mocked-comapreTocurrentRq-manual');
    fireEvent.click(comapreTocurrentRq);
  });
  test('Plans for catch block', () => {
    useLazyGetCartDetailsQuery.mockReturnValue([
      jest.fn().mockRejectedValue(new Error('API request failed')), // Mock a rejected promise
    ]);
    sessionStorage.setItem('readOrder', 'true');
    const {
      data: {
        cart: {
          lineDetails: { lineInfo },
        },
      },
    } = retriveCartJson;
    const [lineInfo1] = lineInfo;
    const { itemsInfo } = lineInfo1;
    const { shipping } = itemsInfo[0];
    const onLinkClick = jest.fn();
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceInfo
            line={{
              serviceInfo: {
                pricePlanInfo: {
                  pricePlanCode: '12345',
                },
              },
            }}
            title='Shipping'
            bgColor='white'
            price='$99.00'
            shippingAddress
            shippingDetails={shipping}
            cartDetails={multiCartJson}
            linkName='Edit'
            address={{
              tradeInShippingType: 'upsdrop-off_qrcode',
            }}
            onLinkClick={onLinkClick}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const link = screen.getByTestId('link');
    fireEvent.click(link);
    const comapreTocurrentRq = screen.getByTestId('mocked-comapreTocurrentRq-manual');
    fireEvent.click(comapreTocurrentRq);
  });
});
