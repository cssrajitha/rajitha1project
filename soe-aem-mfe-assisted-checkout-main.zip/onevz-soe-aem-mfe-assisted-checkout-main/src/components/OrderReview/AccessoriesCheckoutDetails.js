import { useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useInjectReducer } from 'redux-injectors';
import { isEmpty } from 'lodash';
import PropTypes from 'prop-types';
import Emitter from 'onevzsoemfeframework/Emitter';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import styled from 'styled-components';
import '../../App.css';
import { Line } from '@vds/lines';
import { Icon } from '@vds/icons';
import { TextLink } from '@vds/buttons';
import { Title } from '@vds/typography';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import DownPaymentPage from 'onevzsoemfecommon/DownPaymentDevice';
import { TileContainer } from '@vds/tiles';
import moment from 'moment';
import ViewAddRemark from 'onevzsoemfecommon/ViewAddRemark';
import ClickToCall from 'onevzsoemfecommon/ClickToCall';
import { Modal, ModalBody, ModalTitle } from '@vds/modals';
import { checkoutMfe } from './store/reducer';
import ItemsAtGlance from '../ItemsAtGlance/ItemsAtGlance';
import CollateralInfo from '../CollateralInfo/CollateralInfo';
import EditAccessories from './EditAccessories';
import GetAccessApiCallHook from '../../modules/services/APIService/GetAccessAPICallHook';
import InfoApiCallHook from '../../modules/services/APIService/InfoAPICallHook';
import ViewTogether from '../ViewTogether/ViewTogether';
import { formatCurrency, formatPhoneNumberWithSymbol, getCamelCasePronoun, useCradleState } from '../../utils/common';
import { TileWrapper } from '../../StyledConstants';
import { clickToCallDepartment, clickToCallReason, clickToCallSubReason } from './ClickToCall/Constants';
import ClickToCallAPICallHook from '../../modules/services/APIService/ClickToCallAPICallHook';
import ScheduleAppointment from './ScheduleAppointment';
import creditCardIcon from '../../assests/credit_card.png';
import { requestBodyRetriveCart } from '../../modules/services/APIService/APIRequestBody';
import { invokeTagging } from '../../utils/test-utils/utils';
import GetNextBillSummaryHook from '../../modules/services/APIService/GetNextBillSummary';
import { themeIconColor, themeBgColor, themeTextColor } from '../constants/constants';
import ManualDiscountViewModal from './ManualdiscountViewModal';
import ManualDiscountView from './ManualDiscountView';
import CreditCheckout from './CreditCheckout';
import OrderSummaryLine from './OrderSummaryLine/OrderSummaryLine';
import SpecialistFunction from '../ReadOrder/SpecialistFunction';
import DevicePaymentModal from '../ReadOrder/DevicePaymentModal/DevicePaymentModal';
import TrackIt from '../TrackIt/TrackIt';
import ViewOrderDocument from './ViewOrderDocument/ViewOrderDocument';
import getConfirmationAssisted from './ViewOrderDocument/__mocks__/checkout.json';
import { posNbsFlowType, getAccessRole, nbsMfeModuleProps, showGiftCardData } from './ViewOrderDocument/commonUtils';
import PaymentHistoryModal from '../PaymentHistory/PaymentHistory';
import { useLazySendSecurePaymentEmailQuery } from '../../modules/services/APIService/APIServiceCallHook';
import { useLazyNextbillestimateQuery } from '../../modules/services/APIService/APIServiceHooks';
import { GIF_PROD_CODE } from './Refund/constants';
import { updateOneUINbsRespSuccess, updatePartialNbsData } from './store/actions';
import { getUnifiedNbsData } from './store/selectors';
import { reqSendMessage } from '../ViewTogether/ViewTogetherRequest';
import ViewTogetherApiCallHook from '../../modules/services/APIService/ViewTogetherApiCallHook';

const scmCheckoutMfeEnabled = window?.mfe?.scmCheckoutMfeEnable;

// eslint-disable-next-line no-unused-vars
const ClickToCallIconWrapper = styled.div`
  cursor: pointer;
  color: #000000 !important;
`;

const ShowMenuWrapper = styled.div`
  position: absolute;
  right: ${({ scmCheckoutMfeEnable }) => (scmCheckoutMfeEnable ? '3px' : '-13px')};
  top: ${({ scmCheckoutMfeEnable }) => (scmCheckoutMfeEnable ? '20px' : '-103px')};
  z-index: 2;
  img {
    cursor: pointer;
  }
`;

const LinkWrapper = styled.div`
  display: flex;
  flex-direction: column;
  margin-bottom: 2rem;
  margin-left: 10px;

  a[aria-label='Delete all accessories'] {
    font-size: 14px;
  }
`;

const LinkItem = styled.div`
  margin: 1rem 0px;
`;

const LinkItemAdd = styled.div`
  margin: 1rem 8px;
`;

const ProductContainer = styled.div`
  display: flex;
  flex-direction: ${({ alignHorizontal }) => (alignHorizontal ? 'row' : 'column')};
  flex-wrap: wrap;
  margin-top: 15px;
  margin-left: 10px;
`;

const FlexBoxThreeColumn = styled.div`
  display: flex;
  flex-direction: column;
  align-items: start;
  width: 29%;
  margin-bottom: 20px;
  padding-right: 3%;

  p {
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
    width: 100%;
    margin-top: 10px;

    font-size: 14px;
    font-weight: 400;
    color: #959595;
  }
`;

const HeaderContainer = styled.div`
  display: flex;
  align-items: center !important;
  padding: ${({ isFromCheckout }) => (isFromCheckout ? '4px 1rem' : '1.5rem 1rem')};
  justify-content: space-between;
`;

const Rotate90Degree = styled.div`
  transform: rotate(90deg);
  margin-left: 10px;
  margin-right: 10px;
  svg path {
    fill: ${({ isDark }) => (isDark ? '#fff' : '#000')};
  }
`;

const SupportSection = styled.div`
  display: flex;
  justify-content: end;
  align-items: center;
  padding: 0.5rem 0;
  position: fixed;
  width: 1024px;
  background: white;
  z-index: 1;
  top: ${({ isLovTrackerEnabled }) => (isLovTrackerEnabled ? '145px' : '65px')};
  border-bottom: 1px solid #d8dada;
`;

const Container = styled.div`
  display: flex;
`;

const padding = () => {
  if (window?.mfe?.isProspectNewCustomerTab) return '24%';
  if (window?.mfe?.scmCheckoutMfeEnable) return '2%';
  return '17%';
};

const bottom = () => {
  if (window?.mfe?.isProspectNewCustomerTab) return '40%';
  return '0%';
};

const height = () => {
  if (window?.mfe?.isProspectNewCustomerTab) return '40%';
  return '88%';
};

const getBgColor = (scmUpgradeMfeEnable, isDark) => {
  const mfeBgColor = isDark ? '#000' : '#fff';
  const bgColor = !scmUpgradeMfeEnable ? '#fff' : mfeBgColor;
  return bgColor;
};

const getBackDrop = () => {
  if (window?.mfe?.isProspectNewCustomerTab) return 'transparent';
  return 'rgba(0, 0, 0, 0.8)';
};

const Menu = styled.div`
  position: fixed;
  top: 15;
  right: ${({ isOpen }) => (isOpen ? padding : '-300px')};
  width: 384px;
  bottom: ${bottom};
  height: ${height};
  background-color: ${({ scmUpgradeMfeEnable, isDark }) => getBgColor(scmUpgradeMfeEnable, isDark)};
  opacity: 0.9;
  transition: right 0.3s ease-in-out;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
  z-index: 2;
  transition: bottom 0.3s ease;
`;

const MenuContent = styled.div`
  display: block;
  flex-direction: column;
  justify-content: center;
  aligh-items: center;
  height: 100%;
  padding-top: 50px;
`;

const Backdrop = styled.div`
  inset: 0px !important;
  position: fixed;
  top: 15;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: ${getBackDrop};
  overflow: hidden;
  z-index: 2;
  display: ${({ isOpen }) => (isOpen ? 'block' : 'none')};
`;

const CloseIconWrapper = styled.div`
  position: absolute;
  top: 15;
  right: 0;
  margin: 10px;
  cursor: pointer;
  border: none;
  background: none;
  svg path {
    fill: ${({ scmUpgradeMfeEnable, isDark }) => (scmUpgradeMfeEnable && isDark ? '#fff' : '#000')};
  }
`;

const MenuItem = styled.div`
  list-style-type: none;
  border-bottom: 1px solid #ccc;
  margin-bottom: 20px;
  white-space: nowrap;
`;

const MenuModalWarp = styled.div`
  list-style-type: none;
  border-bottom: 1px solid #ccc;
  margin-bottom: 20px;
  white-space: nowrap;
  cursor: pointer;
  color: #000000 !important;
`;

const TransperantButton = styled.button`
  background: none;
  border: 0;
`;

const LeftSideWrapper = styled.div`
  display: flex;
  flex-direction: column;
  min-width: 236px;
  padding: 0 10px;
  justify-content: center;
`;

const RightSideWrapper = styled.div`
  display: flex;
  width: 100%;
  padding: 0 10px;
  justify-content: space-between;
  align-items: center;
  font-size: 18px;
  font-family: BrandFont-Text, Arial, sans-serif;
  > div:first-child {
    width: 50%;
  }
`;

const SetupAndGoWrapper = styled.div`
  display: flex;
  min-height: 100px;
  margin-top: 15px;
`;

const SetupAndGoTitle = styled.div`
  font-size: 18px;
  font-weight: 700;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  letter-spacing: 0.03125rem;
  text-transform: capitalize;
`;

const SubTitle = styled(SetupAndGoTitle)`
  color: #878989;
  font-size: 18px;
  font-weight: 300;
  margin-top: 5px;
`;

const AppointmentWrapper = styled.div`
  margin-left: 1rem;
`;
const AppointmentText = styled.div`
  display: inline;
  font-size: 1rem;
  font-weight: 400;
  line-height: 1.25rem;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  letter-spacing: 0.03125rem;
  color: rgb(0, 0, 0);
  margin: 0px;
  text-decoration: none;
`;

const VVCHeader = styled.div`
  font-size: 18px;
  font-weight: bold;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
`;

const VVCBodyWrapper = styled.div`
  margin-left: 10px;
  display: flex;
  align-items: center;
  gap: 10px;
  > span {
    font-family: BrandFont-Text, Arial, sans-serif;
  }
`;

const VVCFinanceWrapper = styled.div`
  margin-left: 10px;
  gap: 5px;
`;

const ImageWrap = styled.img`
  height: 30px;
  width: 46px;
  margin-left: 7px;
  margin-right: 0px;
`;

const AffirmHeader = styled.span`
  height: 20px;
  width: 97px;
  color: #000000;
  font-family: 'Verizon NHG eDS', Sans-serif;
  font-size: 16px;
  letter-spacing: 0.5px;
  line-height: 20px;
`;

function AccessoriesCheckoutDetails({
  data,
  lines,
  showAccordion,
  handleToggleChange,
  hideSupport,
  isFromCheckout,
  showAccessories = true,
  spanishSelected,
  customerProfile,
  handleShowViewTogether,
  onAccordianToggle,
  itemsInfo,
  lineInfoData,
  mtn,
  customerInfo,
  setSetupAndGoVisiblity,
  hideSetUpAndGo,
  showRepGuidedScreen,
  openAccordian,
  showAffirmAccordion,
  setShowSendMessageError,
  setSelectedReviewMode,
  setSelectedReason,
  onChangeSubReason,
  subReasonSelected,
  onChangeRadio,
  selectedRadio,
  autoSelectRC,
  handleHideContinueShowViewTogether,
  readOrderResponse,
  orderReviewResponse,
  getCartDetailsResults,
  setProfInstallappointmentFlag = () => {},
  fetchPriceSnapshot,
  locationCode,
  hideViewTogether,
  setReceivedLovPollResponse,
  exitLovData,
  setViewdiscountOpen,
  isQAFlow,
  readOrderFlag,
  showModal,
  setIsNewCustomer,
  refetchCartDetails,
  readOrderStatus = '',
}) {
  const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable;
  const scmDeviceMfeEnable = window?.mfe?.scmDeviceMfeEnable;

  const [isReadOrderFlag] = getAssistedCradlePropertyV2(['readOrderMfeFFlag']);
  const isReadOrderFlagEnabled = /true/i.test(isReadOrderFlag);
  const containerRef = useRef(null);

  // const FixedMargin = styled.div`
  //   position: fixed;
  //   width: 1024px;
  //   background: ${!scmCheckoutMfeEnabled ? 'white' : 'unset'};
  //   z-index: 0; // div has no content & z = 1 places a white line through the screen when a long Order Number causes wrapping
  //   top: 114px;
  //   height: 10px;
  // `;
  const isIpad = !!navigator.userAgent.match(/iPad|iPhone/i);
  const dispatch = useDispatch();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [cart, setCart] = useState([]);
  const [accessoryCount, setAccessoryCount] = useState(0);
  const [count, setCount] = useState();
  const [total, setTotal] = useState();
  const [userInfo, setuserInfo] = useState({});
  const [subTotalDueToday, setSubTotalDueToday] = useState(0);
  const [mtnDetails, setMtnDetails] = useState('');
  const [clickToCall, setClickToCall] = useState(false);
  const [setupGoAmount, setSetupGoAmount] = useState(false);
  const [lineActivityType, setLineActivityType] = useState('');
  const [showsetupGo, setShowsetupGo] = useState(false);
  const [toggle, setToggle] = useState('');
  const [showEditAccessories, setShowEditAccessories] = useState(false);
  const [isGamingConsole, setIsGamingConsole] = useState(false);
  const [resendPaymentEmail, setResendPaymentEmail] = useState(false);
  const [isAffirmCreditEligibilityIsDone, setIsAffirmCreditEligibilityIsDone] = useState(false);

  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;
  const scmCheckoutMfeEnable = window?.mfe?.scmCheckoutMfeEnable || false;
  const isFromReadOrder = sessionStorage.getItem('readOrder');
  // posmfe-2484 Add order summary

  const tradeinDetails = readOrderResponse?.store?.data?.cart;
  const [orderNumberAry, setOrderNumberAry] = useState([]);
  const [orderStatus, setOrderStatus] = useState('');
  const [cartHeaderStatus, setCartHeaderStatus] = useState('');
  const [lovIndicator, setLovIndicator] = useState('');
  const [customerId, setCustomerId] = useState('');
  const [sendSecurePayment] = useLazySendSecurePaymentEmailQuery();
  // isViewTogether FLow
  const isReceivePoll = window?.sessionStorage?.getItem('receivePoll') && isIpad;
  const [nbeRequestBody, setNbeReq] = useState(null);
  const [locationCodeData, setLocationCodeData] = useState('');
  const [creditAppNumberData, setCreditAppNumberData] = useState('');
  const [cartCreatorData, setCartCreatorData] = useState('');
  const [accountNumberData, setAccountNumberData] = useState('');
  const issetUpAndGoQA =
    (isQAFlow && setupGoAmount && lineActivityType === 'ACC' && showsetupGo) ||
    !(setupGoAmount && lineActivityType === 'ACC' && showsetupGo);
  const [imageUrl, setImageUrl] = useState(null);
  const qATFeatureF =
    /true/i.test(JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.quickAccessoryCheckoutTaggingFFlag) || false;
  const showDownPayment = itemsInfo?.[0]?.cartItems?.cartItem?.some((item) => item?.priceType === 'VERIZON_EDGE');

  const salesId = data?.data?.cart?.orderDetails?.salesRepId;

  useEffect(() => {
    setIsGamingConsole(
      data?.data?.cart?.lineDetails?.lineInfo[0]?.itemsInfo[0]?.cartItems?.cartItem[0]?.deviceDisplayName
        ?.toLowerCase()
        ?.includes('xbox'),
    );
    setIsAffirmCreditEligibilityIsDone(data?.data?.cart?.orderDetails?.affirmCreditCheckFailed);
  }, [data]);

  useInjectReducer({
    key: 'checkoutMfe',
    reducer: checkoutMfe,
  });

  useEffect(() => {
    if (isReadOrderFlagEnabled) containerRef.current.style.display = 'none';
  }, []);

  useEffect(() => {
    /* istanbul ignore else */
    if (readOrderResponse) {
      const rsp = readOrderResponse;
      const customerIdValue =
        rsp?.cart?.cartHeader?.fullAccountNumber?.split('-')[0] ||
        rsp?.cart?.cartHeader?.shellAccountNumber?.split('-')[0];
      setOrderStatus(rsp?.orderStatus);
      setCartHeaderStatus(rsp?.cart?.cartHeader?.status);
      setCustomerId(customerIdValue);
      setOrderNumberAry(rsp?.cart?.orderDetails?.orderList?.map((order) => order.orderNumber));
      setLovIndicator(rsp?.lovIndicator);
      setLocationCodeData(rsp?.cart?.orderDetails?.locationCode);
      setCreditAppNumberData(rsp?.cart?.orderDetails?.orderList?.[0]?.creditApplication?.creditApplicationNum);
      const MTNValue = rsp?.cart?.cartHeader?.cartCreator || rsp?.cart?.lineDetails?.lineInfo?.[0]?.mobileNumber;
      setCartCreatorData(MTNValue);
      setAccountNumberData(rsp?.cart?.lineDetails?.subAccountNBSInfo?.[0]?.billAccounts?.[0]?.nbs?.accountNumber);
    } // if readOrderResponse
  }, [readOrderResponse]);

  useEffect(() => {
    if (toggle === 'resendPaymentLink') {
      sendSecurePayment({ body: {}, showErrorBanner: false }).then((res) => {
        setResendPaymentEmail(res?.data?.data?.emailId);
      });
    }
    if (toggle === 'discounts' && setViewdiscountOpen !== undefined) {
      setViewdiscountOpen(true);
    }
    if (toggle === '' && setViewdiscountOpen !== undefined) {
      setViewdiscountOpen(false);
    }
  }, [toggle]);

  const { addAccessories, addAccessoriesSuccess, getCustomerByMtn } = GetAccessApiCallHook();

  const { getCartRequest, fetchPricingSnapRequest, getActiveMTNRequest, getCartResponse } = InfoApiCallHook();
  const { getNextBillSummaryReq, getNextBillSummaryRes } = GetNextBillSummaryHook();
  const lineInfo = lineInfoData || data?.data?.cart?.lineDetails?.lineInfo[0];
  const depletionType = lineInfo?.itemsInfo[0]?.depletionType;

  const Appointment =
    getCartResponse?.data?.data?.cart?.lineDetails?.lineInfo[0]?.serviceInfo?.cart5GAppointment
      ?.installApptSelectedDate ??
    lineInfo?.serviceInfo?.cart5GAppointment?.installApptSelectedDate ??
    {};
  const [showScheduleAppointmentModal, setShowScheduleAppointmentModal] = useState(false);
  const { availableDate = null, slotStartTime = null, slotLength = 0 } = Appointment;
  const formattedAvailableDate = moment(availableDate).format('YYYYMMDD');
  const mDateTime =
    availableDate !== null && slotStartTime !== null ? moment(`${formattedAvailableDate} ${slotStartTime}`) : null;
  const lastScheduledDate = mDateTime !== null ? `${mDateTime.format('MM/DD/YYYY')}` : '';
  const lastScheduledTime =
    mDateTime !== null ? `${mDateTime.format('LT')} - ${mDateTime.add(slotLength, 'hours').format('LT')}` : '';
  const { getClickToCallDetailsRequest, getClickToCallDetailsResult } = ClickToCallAPICallHook();

  const isTGWSelected = lineInfo?.tanglewoodSelected === 'Y';
  const cradleState = useCradleState();
  const nbsFFlagState = cradleState?.data?.enablePartialNbsPosFFlag === 'TRUE';
  const isPartialNbs =
    nbsFFlagState || JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.enablePartialNbsPosFFlag === 'TRUE';
  const enableFullBlownMfeNbsPosFFlag =
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.enableFullBlownMfeNbsPosFFlag === 'TRUE';
  const isViewOnlyOrder = getQueryParamByName('viewOnlyOrder') === 'true';
  const [getNbeRequestBody, getNbeResult] = useLazyNextbillestimateQuery();
  const fetchUnifiedNbsDataStore = useSelector(getUnifiedNbsData);

  useEffect(() => {
    /* istanbul ignore next */
    if (getNextBillSummaryRes && getNextBillSummaryRes.data) {
      let preparePayload = {};
      if (isTGWSelected) {
        preparePayload = {
          nseFlow: true,
          unifiedNbsFlag: isPartialNbs,
          enableVzdlFlow: true,
          tanglewoodQualified: true,
        };
      } else {
        preparePayload = { nseFlow: true, unifiedNbsFlag: isPartialNbs, enableVzdlFlow: true };
      }

      const vzwRoleVal = getAccessRole(customerInfo?.lookupMtn, getCartDetailsResults);
      const unifiedMfeRequest = { ...preparePayload, vzwRole: vzwRoleVal };
      const nbsProps = nbsMfeModuleProps(getNextBillSummaryRes, unifiedMfeRequest);

      const nbsType = posNbsFlowType(nbsProps);
      const readOrder = nbsProps?.nbsTypeFlags?.isReadOrder;
      const posNbsBody = {
        ...nbsProps?.mfeRequestPayload,
        nbsType,
        ...(readOrder ? { readOrder } : {}),
        returnCurrentAndNewMonthlyComparison: 'N',
      };

      const nbsApiReq = {
        isNosFlow: false,
        unifiedNbsFlag: true,
        unifiedNbsData: fetchUnifiedNbsDataStore || '',
        posNbsBody,
        vzwRoles: nbsProps?.vzwRole,
        unifiedNbsCartId: customerProfile?.data?.customer?.cartId || sessionStorage.getItem('acssMfeCartId') || '',
      };
      if (nbeRequestBody == null) {
        setNbeReq(nbsApiReq);
      }
    }
  }, [
    getNextBillSummaryRes,
    fetchUnifiedNbsDataStore,
    getCartDetailsResults?.data?.data?.cart?.customerProfile,
    customerInfo?.lookupMtn,
    hideViewTogether,
  ]);

  useEffect(() => {
    /* istanbul ignore next */
    if (enableFullBlownMfeNbsPosFFlag && !isEmpty(fetchUnifiedNbsDataStore)) {
      getNbeRequestBody({
        body: nbeRequestBody,
        spinner: false,
        refetchOnMountOrArgChange: true,
        skip: hideViewTogether || !enableFullBlownMfeNbsPosFFlag || isQAFlow,
      });
    }
  }, [nbeRequestBody, fetchUnifiedNbsDataStore]);

  useEffect(() => {
    if (getClickToCallDetailsResult?.data) {
      setuserInfo(getClickToCallDetailsResult?.data);
    }
    if (!isQAFlow) {
      if (isTGWSelected) {
        getNextBillSummaryReq({
          body: { nseFlow: true, unifiedNbsFlag: isPartialNbs, enableVzdlFlow: true, tanglewoodQualified: true },
          spinner: false,
        });
      } else {
        getNextBillSummaryReq({
          body: { nseFlow: true, unifiedNbsFlag: isPartialNbs, enableVzdlFlow: true },
          spinner: false,
        });
      }
      getNextBillSummaryReq({
        body: { nseFlow: true, unifiedNbsFlag: isPartialNbs, enableVzdlFlow: true },
        spinner: false,
      });
    }
  }, [getClickToCallDetailsResult]);

  console.log(getNextBillSummaryRes);
  useEffect(() => {
    if (getNextBillSummaryRes?.status === 'fulfilled') {
      dispatch(updatePartialNbsData(getNextBillSummaryRes?.data));
    }
  }, [getNextBillSummaryRes?.status]);

  const { requestBodySendMessage } = ViewTogetherApiCallHook();
  useEffect(() => {
    /* istanbul ignore next */
    if (
      sessionStorage.getItem('isViewTogether') === 'true' &&
      getNextBillSummaryRes?.data &&
      data?.data &&
      customerProfile?.data &&
      fetchPriceSnapshot
    ) {
      const customerType = sessionStorage.getItem('customerType') ? sessionStorage.getItem('customerType') : '';
      const lookUpMTN = sessionStorage.getItem('tagActiveMTN')
        ? sessionStorage.getItem('tagActiveMTN')
        : customerProfile?.data?.data?.customer?.lookupMtn;

      const token = sessionStorage.getItem('sendInspicioToken');
      const orderReviewbody = {};

      const requestSendMessage = reqSendMessage(
        data?.data?.cart,
        getNextBillSummaryRes,
        customerProfile?.data,
        null,
        null,
        orderReviewbody,
        null,
        fetchPriceSnapshot,
        customerType,
        lookUpMTN,
        null,
      );
      requestBodySendMessage({ body: { ...requestSendMessage, clientId: token } });
    }
  }, [getNextBillSummaryRes?.data, customerProfile?.data, fetchPriceSnapshot]);

  const toggleMenu = () => {
    if (isReadOrderFlagEnabled) {
      if (!isMenuOpen === false) {
        containerRef.current.style.display = 'none';
      }
      if (
        (containerRef.current.style.display === 'none' && !isMenuOpen === false) ||
        (containerRef.current.style.display === 'block' && !isMenuOpen)
      )
        setIsMenuOpen(!isMenuOpen);
    } else {
      setIsMenuOpen(!isMenuOpen);
    }
  };

  const handleGetClickToCallDetails = () => {
    getClickToCallDetailsRequest({ body: {}, spinner: true, mock: false });
    setClickToCall(true);
  };

  const showClickToCall = () => {
    setClickToCall(!clickToCall);
  };

  const closeModal = () => {
    invokeTagging('closeView', '');
    setShowEditAccessories(false);
  };

  const deleteAccessories = async () => {
    const accesoryList = [];
    const cartItemData =
      lineInfoData?.itemsInfo?.[0]?.cartItems?.cartItem ||
      data?.data?.cart?.lineDetails?.lineInfo?.[0]?.itemsInfo?.[0]?.cartItems?.cartItem;
    cartItemData?.forEach((item) => {
      if (item?.cartItemType === 'ACCESSORY') {
        accesoryList.push({
          id: item?.itemCode,
          qty: item?.qty,
          isSoftSku: false,
          accessoryBundle: false,
        });
      }
    });
    if (isQAFlow) {
      if (!data?.data?.cart?.cartHeader?.cartCreator) {
        setIsNewCustomer(true);
      }
      showModal(true);
    } else {
      const payload = {
        cartInfo: {
          cartId: !scmUpgradeMfeEnable
            ? customerProfile?.data?.customer?.cartId || ''
            : sessionStorage.getItem('acssMfeCartId'),
          caseId: customerProfile?.data?.customer?.caseId || sessionStorage.getItem('caseId') || '',
          accountNumber: customerProfile?.data?.customer?.accountNo || '',
          cartCreator: data?.data?.cart?.cartHeader?.cartCreator || sessionStorage.getItem('creditAppNum') || '',
          processingMTN:
            customerProfile?.data?.customer?.lookupMtn ||
            (sessionStorage.getItem('activeMTN') !== 'null' || sessionStorage.getItem('activeMTN') !== undefined
              ? sessionStorage.getItem('activeMTN')
              : '') ||
            '',
          processStep: 'ShoppingCart',
          processAction: 'addAccessory',
          intendType: sessionStorage.getItem('customerType') === 'N' ? 'NSE' : 'ACC',
        },
        data: {
          depletionType: data?.data?.cart?.lineDetails?.lineInfo?.[0]?.itemsInfo?.[0]?.depletionType,
          lines: [
            {
              mtn: customerProfile?.data?.customer?.lookupMtn || sessionStorage.getItem('activeMTN') || '',
              removeAccessories: accesoryList,
              addAccessories: [],
              ispuFlow: false,
              depletionLocationCode:
                data?.data?.cart?.lineDetails?.lineInfo?.[0]?.itemsInfo?.[0]?.depletionLocation || '',
            },
          ],
        },
      };
      addAccessories({ body: payload, spinner: false });
      setCart([]);
      setCount(0);
      setTotal(0);

      getCartRequest({ body: requestBodyRetriveCart, spinner: false });
      fetchPricingSnapRequest({ body: {}, spinner: false });
      /* istanbul ignore next */
      if (!window?.mfe?.isProspectNewCustomerTab) {
        getActiveMTNRequest({ body: {}, spinner: false });
        getCustomerByMtn({ body: {}, spinner: false });
      }
    }
  };

  const handleEditOnImageClick = () => {
    if (readOrderStatus !== 'CO') {
      invokeTagging('openView', 'Accessories');
      setShowEditAccessories(true);
    }
  };

  useEffect(() => {
    if (data) {
      const {
        data: {
          cart: { lineDetails },
        },
      } = data;
      const item = itemsInfo ? itemsInfo?.[0] : lineDetails?.lineInfo?.[0]?.itemsInfo?.[0];
      // needed for multiple lines
      // const accessoryTotal =
      // lineDetails?.orderDetails?.accessoryFinancingOfferInfo?.installmentInfo?.accessoryTotal || 0;
      const cartData = item?.cartItems?.cartItem;
      if (isQAFlow) {
        setCart(cartData?.filter((i) => i?.cartItemType !== 'SHIPPING'));
      } else {
        setCart(item?.cartItems?.cartItem?.filter((i) => i?.newPurchasedQty) || []);
      }

      const isSplAccessoryAdded = cartData?.filter(
        (items) =>
          items.prodCode2 === GIF_PROD_CODE ||
          (items.prodCode1 === 'LAB' && items.prodCode2 === 'SER') ||
          (items.prodCode1 === 'TAX' && items.prodCode2 === 'SPC') ||
          (items.prodCode1 === 'TAX' && items.prodCode2 === 'BAG'),
      );
      let accCount = 0;
      item?.cartItems?.cartItem?.forEach((items) => {
        accCount = items.qty + accCount;
        setAccessoryCount(accCount);
      });

      setCount(
        isSplAccessoryAdded?.length > 0
          ? accessoryCount
          : item?.cartItems?.cartItem?.filter((i) => i?.newPurchasedQty).reduce((p, c) => p + c.qty, 0) || 0,
      );
      setTotal(
        isSplAccessoryAdded?.length > 0
          ? data?.data?.cart?.orderDetails?.subTotalDueToday
          : item?.cartItems?.cartItem
              ?.filter((i) => i?.newPurchasedQty)
              ?.reduce((p, c) => p + c.totalPriceWithDiscount, 0),
      );
      setSubTotalDueToday(data?.data?.cart?.orderDetails?.subTotalDueToday);
      setMtnDetails(mtn || lineDetails?.lineInfo?.[0]?.serviceInfo?.mtn);
      const isSoftSku = item?.cartItems?.cartItem?.find(
        (cartItem) =>
          cartItem?.cartItemType === 'SOFT_SKU' &&
          ((cartItem?.prodCode1 === 'LAB' && cartItem?.prodCode2 === 'SER') ||
            (cartItem?.prodCode1 === 'TAX' && cartItem?.prodCode2 === 'SPC') ||
            cartItem?.prodCode2 === 'GIF' ||
            (cartItem.prodCode1 === 'TAX' && cartItem.prodCode2 === 'SPC') ||
            (cartItem.prodCode1 === 'TAX' && cartItem.prodCode2 === 'BAG')),
      );
      if (isSoftSku && isQAFlow) {
        setImageUrl('https://ss7.vzw.com/is/image/VerizonWireless/$device-mini$');
      }
      const setupAmount = item?.cartItems?.cartItem?.find(
        (cartItem) =>
          cartItem?.cartItemType === 'SOFT_SKU' &&
          cartItem?.prodCode1 === 'LAB' &&
          cartItem?.prodCode2 === 'SER' &&
          cartItem?.prodCode4 === 'SUG',
      );
      setSetupGoAmount(setupAmount);

      setLineActivityType(lineDetails?.lineInfo[0]?.lineActivityType);
      setShowsetupGo(item?.cartItems?.cartItem?.length === 1);

      const setupAndGoVisibility =
        setupAmount && lineDetails?.lineInfo[0]?.lineActivityType && item?.cartItems?.cartItem?.length === 1;

      if (setSetupAndGoVisiblity && setupAndGoVisibility) {
        setSetupAndGoVisiblity(setupAndGoVisibility);
      }
    }
  }, [data]);

  useEffect(() => {
    if (addAccessoriesSuccess?.data) {
      dispatch(appMessageActions.addAppMessage('Accessories Deleted Successfully', 'success', true, true));
      if (scmCheckoutMfeEnable) {
        Emitter.emit('ADD_SELECTED_DEVICE_TO_CART', {});
      }
      setTimeout(() => {
        dispatch(appMessageActions.clearAppMessages());
      }, 3000);
    }
  }, [addAccessoriesSuccess]);

  const getSetupGoCartItemType = (cartDevice, mtnNumber, customer) => {
    const { firstName = '', preferPronoun = '' } = customer?.customerName || {};
    return (
      <>
        <SetupAndGoWrapper>
          <LeftSideWrapper>
            <SetupAndGoTitle>
              {firstName && firstName !== '' ? firstName.toLowerCase() : ''}
              {firstName && preferPronoun && ` (${getCamelCasePronoun(preferPronoun)})`}
            </SetupAndGoTitle>
            <SubTitle> {formatPhoneNumberWithSymbol(mtnNumber, '-')}</SubTitle>
          </LeftSideWrapper>
          <TileContainer padding='1.5rem 0 0 0' height='auto' width='384px'>
            <TileWrapper />
          </TileContainer>
          <RightSideWrapper>
            <div>Setup & Go Service Charge</div>

            <div>
              {cartDevice?.discountedPrice >= 0 ? (
                <div>{formatCurrency(cartDevice.discountedPrice)} </div>
              ) : (
                <div>{formatCurrency(cartDevice.itemPrice)} </div>
              )}
            </div>
          </RightSideWrapper>
        </SetupAndGoWrapper>
        <Line type='primary' />
      </>
    );
  };

  const closeAppointment = () => {
    setShowScheduleAppointmentModal(false);
    getCartRequest({ body: requestBodyRetriveCart, spinner: true });
  };

  useEffect(() => {
    const cart5GAppointment =
      getCartResponse?.data?.data?.cart?.lineDetails?.lineInfo?.[0]?.serviceInfo?.cart5GAppointment;
    if (cart5GAppointment) {
      setProfInstallappointmentFlag(false);
    } else {
      setProfInstallappointmentFlag(true);
    }
  }, [setProfInstallappointmentFlag, getCartResponse]);
  const handleViewAccessories = (acc) => {
    if (acc?.length > 0) {
      if (isFromReadOrder && isReadOrderFlagEnabled) {
        invokeTagging('openView', 'Accessories');
      }
      setShowEditAccessories(true);
    } else {
      window.location.href = `/sales/assisted/landing.html`;
    }
  };

  const handleEdit = () => {
    setShowEditAccessories(true);
    if (isFromReadOrder && isReadOrderFlagEnabled) {
      invokeTagging('openView', 'Accessories');
    }
    if (isQAFlow && qATFeatureF) {
      invokeTagging('openView', 'Accessories');
    }
  };
  const showDeleteAccessoryLink = (lineActType) => {
    // For Accessory only change hide delete all accessories link
    if (scmCheckoutMfeEnable) {
      return lineActType !== 'ACC';
    }
    return true;
  };

  useEffect(() => {
    if (getNbeResult?.isSuccess) {
      dispatch(updateOneUINbsRespSuccess(getNbeResult?.data));
    }
  }, [getNbeResult.data]);

  const downPaymentHeaderProps = {
    header: 'Down Payments',
  };
  /* istanbul ignore next */
  const handleDownPaymentClose = () => setToggle('');

  return (
    <>
      {(!showAffirmAccordion || !showRepGuidedScreen) && (
        <>
          {scmUpgradeMfeEnable && (
            <ShowMenuWrapper scmCheckoutMfeEnable={scmCheckoutMfeEnable}>
              <Rotate90Degree
                onClick={toggleMenu}
                scmUpgradeMfeEnable={scmUpgradeMfeEnable}
                isDark={isDark}
                data-testid='three-dot-menu'
              >
                <Icon color={themeIconColor()} name='more-horizontal' size='large' />
              </Rotate90Degree>
            </ShowMenuWrapper>
          )}
          <Backdrop
            ref={isReadOrderFlagEnabled ? containerRef : null}
            isOpen={isMenuOpen}
            onClick={() => !scmUpgradeMfeEnable && toggleMenu()}
            data-testid='back-drop'
          >
            <Container data-testid='ModalSideNav' id='ModalSideNav'>
              {isMenuOpen && (
                <Menu
                  isOpen={isMenuOpen}
                  scmUpgradeMfeEnable={scmUpgradeMfeEnable}
                  isDark={isDark}
                  style={{ backgroundColor: themeBgColor() }}
                >
                  <CloseIconWrapper onClick={toggleMenu} scmUpgradeMfeEnable={scmUpgradeMfeEnable} isDark={isDark}>
                    <span>
                      <Icon name='close' size='large' color={themeIconColor()} />
                    </span>
                  </CloseIconWrapper>
                  <MenuContent>
                    <ul>
                      {!isFromReadOrder && (
                        <>
                          {window?.mfe?.isProspectNewCustomerTab && (
                            <MenuModalWarp
                              onClick={() => {
                                invokeTagging('openView', 'Apply Mobile+ Home Discount');
                                Emitter.emit('SHOW_OR_HIDE_APPLY_MOBILE_HOME_DISCOUNT', true);
                              }}
                              data-testid='is_apply_mh_discount'
                            >
                              <Title size='small' color={themeTextColor()}>
                                {' '}
                                Apply Mobile+ Home Discount{' '}
                              </Title>
                            </MenuModalWarp>
                          )}
                          {!scmDeviceMfeEnable && (
                            <>
                              <MenuItem>
                                <Title size='small' color={themeTextColor()}>
                                  {' '}
                                  Apply Mobile+ Home Discount{' '}
                                </Title>
                              </MenuItem>
                              <MenuItem>
                                <Title bold size='small' color={themeTextColor()}>
                                  Manage client account
                                </Title>
                              </MenuItem>
                            </>
                          )}
                          <MenuModalWarp
                            onClick={() => {
                              invokeTagging('openView', 'Items At A Glance');
                              setToggle('glance');
                              setIsMenuOpen(false);
                            }}
                            data-testid='glance'
                          >
                            <Title size='small' color={themeTextColor()}>
                              View items at a glance
                            </Title>
                          </MenuModalWarp>
                          <MenuModalWarp
                            onClick={() => {
                              invokeTagging('openView', 'Collateral');
                              setToggle('collateral');
                              toggleMenu();
                            }}
                            data-testid='collateral'
                          >
                            <Title size='small' color={themeTextColor()}>
                              View collateral
                            </Title>
                          </MenuModalWarp>
                          {showDownPayment && window?.mfe?.isProspectNewCustomerTab && (
                            <MenuModalWarp
                              onClick={() => {
                                setToggle('DownPayment');
                                toggleMenu();
                              }}
                              data-testid='downPayment'
                            >
                              <Title size='small' color={themeTextColor()}>
                                Manage down payment
                              </Title>
                            </MenuModalWarp>
                          )}
                          <MenuModalWarp
                            onClick={() => {
                              invokeTagging('openView', 'Manual Discount Credentials Manager Exception');
                              setToggle('discounts');
                              toggleMenu();
                            }}
                            data-testid='discounts'
                          >
                            <Title size='small' color={themeTextColor()}>
                              View discounts & promos
                            </Title>
                          </MenuModalWarp>

                          {/* <MenuModalWarp
                            onClick={() => {
                              invokeTagging('openView', 'View/Print receipt');
                              setToggle('printreceipt');
                            }}
                            data-testid='ViewPrintReceiept'
                          >
                            <Title size='small' color={themeTextColor()}>
                              View/print receipt
                            </Title>
                          </MenuModalWarp> */}

                          {scmUpgradeMfeEnable && (
                            <MenuModalWarp
                              onClick={() => {
                                invokeTagging('openView', 'Credit Approval Status');
                                Emitter.emit('SHOW_OR_HIDE_CREDIT_APP_STATUS', true);
                                toggleMenu();
                              }}
                              data-testid='creditApproval'
                            >
                              <Title size='small' color={themeTextColor()}>
                                Credit approval status
                              </Title>
                            </MenuModalWarp>
                          )}
                          {window?.mfe?.isProspectNewCustomerTab && (
                            <div className='sales-rep-display-mode'>
                              <Icon
                                name='my-account'
                                size='large'
                                color='#000000'
                                style={{ height: '2.5rem', width: '2rem' }}
                              />
                              &nbsp;&nbsp;<span className='sales-rep-id-display'>{salesId}</span>
                            </div>
                          )}
                        </>
                      )}
                      {isReadOrderFlagEnabled && isFromReadOrder && (
                        <SpecialistFunction
                          cartData={data?.data}
                          readOrderData={readOrderResponse}
                          customerProfile={customerProfile}
                          setToggle={setToggle}
                          setClickToCall={handleGetClickToCallDetails}
                          toggleMenu={() => {
                            if (containerRef.current) {
                              containerRef.current.style.display = 'none';
                            }
                            toggleMenu();
                          }}
                        />
                      )}
                    </ul>
                  </MenuContent>
                </Menu>
              )}

              {toggle === 'viewAddRemarks' && (
                <div data-testid='viewAddRemarks-modal'>
                  <ViewAddRemark
                    cartDetails={getCartDetailsResults?.data?.data}
                    orderConfirmation={readOrderResponse}
                    isFromCheckout
                    setToggle={setToggle}
                  />
                </div>
              )}

              {toggle === 'resendPaymentLink' && (
                <div data-testid='resendPaymentLink-modal'>
                  <Modal
                    opened
                    surface='light'
                    fullScreenDialog={false}
                    disableAnimation
                    disableOutsideClick={false}
                    ariaLabel='Email Sent Notification'
                    onOpenedChange={(opened) => !opened && setToggle('')}
                  >
                    <ModalTitle>Email sent Notification</ModalTitle>
                    <ModalBody>Email Sent Successfully to {resendPaymentEmail}</ModalBody>
                  </Modal>
                </div>
              )}
              {toggle === 'glance' && (
                <div data-testid='glance-modal'>
                  <ItemsAtGlance
                    value
                    handleToggle={(val) => {
                      invokeTagging('closeView', '');
                      setToggle(val);
                    }}
                    cartDetails={data?.data}
                  />
                </div>
              )}
              {toggle === 'collateral' && (
                <div data-testid='collateral-modal'>
                  <CollateralInfo
                    value
                    handleToggle={() => {
                      invokeTagging('closeView', '');
                      setToggle('');
                    }}
                  />
                </div>
              )}

              {/* start View Print Receipt */}

              {toggle === 'printreceipt' && (
                <div data-testid='ViewPrintReceiept-modal'>
                  <ViewOrderDocument
                    value
                    handleToggle={() => {
                      invokeTagging('closeView', '');
                      setToggle('');
                    }}
                    readorder
                    data={data}
                    readOrderData={readOrderResponse}
                    orderNo={orderNumberAry}
                    customerInfo={customerInfo}
                    customerProfile={customerProfile}
                    orderConfirmationData={getConfirmationAssisted}
                    locationCode={data?.data?.cart?.orderDetails?.locationCode}
                    emailId={readOrderResponse?.cart?.orderDetails?.spocs?.notificationOptions?.primaryEmailId || ''}
                    tradeInDetail={tradeinDetails?.lineDetails?.tradeInItems}
                    regeneratedReceiptEnabled
                    cartDetails={data?.data}
                  />
                  {/* )} */}
                </div>
              )}
              {toggle === 'CreditStatus' && (
                <div data-testid='credit-modal'>
                  <CreditCheckout handleClose={() => setToggle('')} readOrderResponse={readOrderResponse} />
                </div>
              )}
              {toggle === 'PaymentHistory' && (
                <div data-testid='paymenthistory-modal'>
                  <PaymentHistoryModal
                    readOrderResponse={readOrderResponse}
                    value
                    readOrder={readOrderFlag}
                    handleToggle={() => {
                      invokeTagging('closeView', '');
                      setToggle('');
                    }}
                  />
                </div>
              )}
              {toggle === 'DownPayment' && (
                <DownPaymentPage
                  CustomerData={customerProfile?.data?.customer}
                  mtn={mtn}
                  fromPage=''
                  closeClickHandler={handleDownPaymentClose}
                  closeIcon
                  cartHeader={cart?.cartHeader}
                  CartLineInfo={cart?.lineDetails?.lineInfo}
                  headerData={downPaymentHeaderProps}
                />
              )}
            </Container>
          </Backdrop>
        </>
      )}

      {/* end View Print Receipt */}

      {!(window?.mfe?.isProspectNewCustomerTab ? true : hideSupport) && (
        <>
          <SupportSection isLovTrackerEnabled={isReceivePoll} id='accessoriesCheckoutDetails676'>
            {readOrderResponse && (
              <OrderSummaryLine
                id='OrderSummaryLine677'
                orderNumberAry={orderNumberAry}
                orderStatus={orderStatus}
                cartHeaderStatus={cartHeaderStatus}
                lovIndicator={lovIndicator}
                customerId={customerId}
              />
            )}
            {!readOrderResponse && (
              <ClickToCallIconWrapper data-testid='clicktocall' onClick={handleGetClickToCallDetails}>
                <Icon name='support' size='XLarge' />
              </ClickToCallIconWrapper>
            )}
            <Rotate90Degree
              data-testid='hamburger-icon'
              onClick={() => {
                if (containerRef?.current) containerRef.current.style.display = 'block';
                toggleMenu();
              }}
            >
              <Icon name='more-horizontal' size='large' />
            </Rotate90Degree>
          </SupportSection>
          {/* <FixedMargin /> */}
        </>
      )}

      {showAffirmAccordion || showRepGuidedScreen ? null : (
        <>
          {showAccordion && (
            <ViewTogether
              showAccordion={showAccordion}
              openAccordian={openAccordian}
              handleToggleChange={handleToggleChange}
              getCartResponse={data?.data?.cart}
              spanishSelected={spanishSelected}
              customerProfile={customerProfile}
              handleShowViewTogether={handleShowViewTogether}
              onAccordianToggle={onAccordianToggle}
              getNextBillSummaryRes={getNextBillSummaryRes}
              setShowSendMessageError={setShowSendMessageError}
              setSelectedReviewMode={setSelectedReviewMode}
              setSelectedReason={setSelectedReason}
              subReasonSelected={subReasonSelected}
              onChangeSubReason={onChangeSubReason}
              selectedRadio={selectedRadio}
              autoSelectRC={autoSelectRC}
              onChangeRadio={onChangeRadio}
              handleHideContinueShowViewTogether={handleHideContinueShowViewTogether}
              orderReviewResponse={orderReviewResponse}
              fetchPriceSnapshot={fetchPriceSnapshot}
              unifiedNbsData={getNbeResult}
              setReceivedLovPollResponse={setReceivedLovPollResponse}
              exitLovData={exitLovData}
            />
          )}
          {isQAFlow && readOrderStatus === 'CO' && (
            <div>
              <HeaderContainer>
                <Title bold data-testid='ordernumber' color={themeTextColor()}>
                  Completed Order Number:{orderNumberAry}
                </Title>
                <Title bold color={themeTextColor()}>
                  Order Status:CO
                </Title>
              </HeaderContainer>
            </div>
          )}
          {showAccessories && issetUpAndGoQA ? (
            <div>
              <HeaderContainer isFromCheckout={isFromCheckout}>
                <Title bold data-testid='accessories-title' color={themeTextColor()}>
                  Accessories ({count})
                </Title>
                <Title bold color={themeTextColor()}>
                  {formatCurrency(total && total > 0 ? total : 0)}
                </Title>
              </HeaderContainer>
              <Line type='secondary' surface={isDark ? 'dark' : 'light'} />
              <ProductContainer alignHorizontal>
                {cart.map((item, i) => (
                  <>
                    <FlexBoxThreeColumn key={item.deviceDisplayName}>
                      <TransperantButton onClick={handleEditOnImageClick} data-testid={`edit-accessories-image-${i}`}>
                        <img
                          src={item.imageUrlMap?.thumbImage ? item.imageUrlMap?.thumbImage : imageUrl}
                          alt={item.deviceDisplayName ? item.deviceDisplayName : item.description}
                          height={!isFromCheckout ? 'auto' : '84px'}
                        />
                      </TransperantButton>
                      <p size='small' color='#a7a7a7' style={{ whiteSpace: 'pre-wrap', marginBottom: '0px' }}>
                        {item.deviceDisplayName ? item.deviceDisplayName : item.description}
                      </p>
                      {scmUpgradeMfeEnable && (
                        <Title bold color={themeTextColor()}>
                          {formatCurrency(item?.totalPriceWithDiscount)}
                        </Title>
                      )}

                      {showGiftCardData(isQAFlow, item)}
                    </FlexBoxThreeColumn>
                    {data?.data?.cart?.orderDetails?.accessoryFinancingOfferInfo?.offerAccepted &&
                      lineActivityType === 'ACC' &&
                      i === 0 && (
                        <VVCFinanceWrapper>
                          <VVCHeader>Offers</VVCHeader>
                          <VVCBodyWrapper>
                            <img width={45} alt='credit' src={creditCardIcon} />
                            <span>Financing offer applied</span>
                          </VVCBodyWrapper>
                        </VVCFinanceWrapper>
                      )}
                  </>
                ))}
              </ProductContainer>
              {isGamingConsole && isAffirmCreditEligibilityIsDone && (
                <div>
                  <AffirmHeader>Payment with</AffirmHeader>
                  <ImageWrap
                    src='https://ss7.vzw.com/is/image/VerizonWireless/affirm-2-color-hex-2022?scl=3'
                    className='paymentWithAffirmImage'
                    alt='affirm'
                  />
                </div>
              )}

              {readOrderStatus !== 'CO' &&
                lineInfo?.lineActivityType !== 'AAL_5G' &&
                lineInfo?.lineActivityType !== 'NSE_5G' && (
                  <LinkWrapper>
                    {cart?.length > 0 && !(isReadOrderFlagEnabled && isFromReadOrder) && (
                      <>
                        {showDeleteAccessoryLink(lineInfo?.lineActivityType) && (
                          <LinkItem>
                            <TextLink
                              type='standAlone'
                              data-testid='delete-accessories-link'
                              size='medium'
                              onClick={deleteAccessories}
                            >
                              Delete all accessories
                            </TextLink>
                          </LinkItem>
                        )}
                        <LinkItem>
                          <TextLink
                            type='standAlone'
                            data-testid='edit-accessories-link'
                            size='small'
                            onClick={handleEdit}
                          >
                            Edit
                          </TextLink>
                        </LinkItem>
                      </>
                    )}
                    {!scmCheckoutMfeEnabled
                      ? cart?.length <= 0 &&
                        !(isReadOrderFlagEnabled && isFromReadOrder) && (
                          <LinkItemAdd>
                            <TextLink
                              type='standAlone'
                              size='small'
                              onClick={() => {
                                window.location.href = `/sales/assisted/landing.html`;
                              }}
                            >
                              Add
                            </TextLink>
                          </LinkItemAdd>
                        )
                      : null}
                    {isReadOrderFlagEnabled &&
                      isFromReadOrder &&
                      data?.data?.cart?.orderDetails?.flowType !== '5G_EXCHANGE_EXT' && (
                        <div>
                          {!(orderStatus === 'CR' && cartHeaderStatus !== 'P' && cartHeaderStatus !== 'C') ||
                          isViewOnlyOrder ? (
                            <LinkItem>
                              {cart?.length > 0 && (
                                <TextLink
                                  type='standAlone'
                                  data-testid='view-accessories-link'
                                  size='small'
                                  onClick={handleEdit}
                                >
                                  View
                                </TextLink>
                              )}
                            </LinkItem>
                          ) : (
                            <LinkItem>
                              <TextLink
                                type='standAlone'
                                data-testid='viewadd-accessories-link'
                                size='small'
                                onClick={() => handleViewAccessories(cart)}
                              >
                                {cart?.length > 0 ? 'View' : 'Add'}
                              </TextLink>
                            </LinkItem>
                          )}
                        </div>
                      )}
                  </LinkWrapper>
                )}
              {(lineInfo?.lineActivityType === 'AAL_5G' || lineInfo?.lineActivityType === 'NSE_5G') &&
                depletionType === 'O' && (
                  <AppointmentWrapper>
                    <Line type='secondary' />
                    <Title bold color={themeTextColor()}>
                      Appointment Details
                    </Title>
                    <Title bold size='small' color={themeTextColor()}>
                      Last Scheduled Date : <AppointmentText>{lastScheduledDate}</AppointmentText>
                    </Title>
                    <Title bold size='small' color={themeTextColor()}>
                      Last Scheduled Time Slot : <AppointmentText>{lastScheduledTime}</AppointmentText>
                    </Title>
                    <TextLink
                      type='standAlone'
                      data-testId='schedule-appointment'
                      surface='light'
                      disabled={false}
                      size='small'
                      onClick={() => {
                        setShowScheduleAppointmentModal(true);
                      }}
                    >
                      Schedule Appointment
                    </TextLink>
                  </AppointmentWrapper>
                )}

              {!isFromCheckout && <Line type='primary' />}
            </div>
          ) : (
            ''
          )}
          {clickToCall && (
            <div data-testId='clicktocall-modal'>
              <ClickToCall
                clickToCallDepartment={clickToCallDepartment}
                clickToCallSubReason={clickToCallSubReason}
                clickToCallReason={clickToCallReason}
                clickToCall={clickToCall}
                hideClickToCall={showClickToCall}
                userDetails={userInfo}
                creditInfo={data?.data?.cart?.orderDetails}
                ClickToCallDetailsResult={getClickToCallDetailsResult}
                locationCode={isReadOrderFlagEnabled ? locationCodeData : ''}
                accountNum={isReadOrderFlagEnabled ? accountNumberData : customerInfo?.accountNo}
                lookupMtn={isReadOrderFlagEnabled ? cartCreatorData : customerInfo?.lookupMtn}
                cbrNumber={customerInfo?.customerCbrInfo?.cbrNos?.[0]?.phoneNumber.replace(/[^0-9]/g, '')}
                lineDetails={customerInfo?.billAccounts?.[0]?.mtns || []}
                appNumber={
                  isReadOrderFlagEnabled
                    ? creditAppNumberData
                    : data?.data?.cart?.orderDetails?.orderList?.[0].creditApplication?.creditApplicationNum
                }
              />
            </div>
          )}
          <EditAccessories
            mtn={mtnDetails}
            cart={cart}
            total={subTotalDueToday}
            opened={showEditAccessories}
            closeModal={closeModal}
            isQAFlow={isQAFlow}
            imageUrl={imageUrl}
          />

          {toggle === 'discounts' && scmUpgradeMfeEnable && !isReadOrderFlagEnabled && !isFromReadOrder && (
            <ManualDiscountViewModal
              value
              handleToggle={(val) => {
                invokeTagging('closeView', '');
                setToggle(val);
              }}
              cartDetails={data?.data}
              refetchCartDetails={refetchCartDetails}
            />
          )}

          {toggle === 'discounts' && (!scmUpgradeMfeEnable || (isReadOrderFlagEnabled && isFromReadOrder)) && (
            <div data-testid='discounts-modal'>
              <ManualDiscountView
                cart={data?.data?.cart}
                handleClose={() => setToggle('')}
                customer={customerInfo}
                cartDetails={data?.data?.cart?.cartHeader}
              />
            </div>
          )}

          {toggle === 'CreditStatus' && (
            <div data-testid='credit-status-modal'>
              <CreditCheckout
                landing={customerProfile}
                customerInfo={customerInfo}
                appNumber={data?.data?.cart?.orderDetails?.orderList?.[0].creditApplication?.creditApplicationNum}
                handleClose={() => setToggle('')}
                data={data?.data}
              />
            </div>
          )}
        </>
      )}
      {/* rendering devicePaymentModal for readOrder */}
      {toggle === 'devicePayment' && (
        <div data-testid='devicePayment-modal'>
          <DevicePaymentModal
            lines={lines}
            handleToggle={(val) => {
              setToggle(val);
            }}
          />
        </div>
      )}

      {toggle === 'trackit' && (
        <div data-testid='trackit'>
          <TrackIt
            handleToggle={() => {
              setToggle('');
            }}
            locationCode={locationCode}
            orderStatus={orderStatus}
            readOrderResponse={readOrderResponse}
          />
        </div>
      )}
      {!hideSetUpAndGo &&
        setupGoAmount &&
        lineActivityType === 'ACC' &&
        showsetupGo &&
        !isQAFlow &&
        getSetupGoCartItemType(setupGoAmount, mtnDetails, customerInfo)}
      {showScheduleAppointmentModal && (
        <ScheduleAppointment
          showscheduleAppointmentModal={showScheduleAppointmentModal}
          setShowScheduleAppointmentModal={setShowScheduleAppointmentModal}
          lineInfo={data?.data?.cart?.lineDetails?.lineInfo}
          cartHeader={data?.data?.cart?.cartHeader}
          closeAppointment={closeAppointment}
          isIpad={isIpad}
        />
      )}
    </>
  );
}

AccessoriesCheckoutDetails.propTypes = {
  data: PropTypes.any,
  lines: PropTypes.any,
  showAccordion: PropTypes.bool,
  handleToggleChange: PropTypes.func,
  spanishSelected: PropTypes.bool,
  hideSupport: PropTypes.bool,
  isFromCheckout: PropTypes.bool,
  showAccessories: PropTypes.bool,
  customerProfile: PropTypes.any,
  handleShowViewTogether: PropTypes.func,
  onAccordianToggle: PropTypes.func,
  itemsInfo: PropTypes.array,
  mtn: PropTypes.string,
  customerInfo: PropTypes.any,
  setSetupAndGoVisiblity: PropTypes.func,
  hideSetUpAndGo: PropTypes.bool,
  showRepGuidedScreen: PropTypes.bool,
  openAccordian: PropTypes.bool,
  showAffirmAccordion: PropTypes.bool,
  setShowSendMessageError: PropTypes.func,
  setSelectedReviewMode: PropTypes.func,
  setSelectedReason: PropTypes.func,
  onChangeSubReason: PropTypes.func,
  subReasonSelected: PropTypes.any,
  onChangeRadio: PropTypes.func,
  selectedRadio: PropTypes.any,
  autoSelectRC: PropTypes.any,
  handleHideContinueShowViewTogether: PropTypes.func,
  orderReviewResponse: PropTypes.any,
  readOrderResponse: PropTypes.any,
  lineInfoData: PropTypes.object,
  getCartDetailsResults: PropTypes.object,
  setProfInstallappointmentFlag: PropTypes.func,
  fetchPriceSnapshot: PropTypes.any,
  locationCode: PropTypes.string,
  hideViewTogether: PropTypes.bool,
  setReceivedLovPollResponse: PropTypes.func,
  exitLovData: PropTypes.any,
  setViewdiscountOpen: PropTypes.func,
  isQAFlow: PropTypes.bool,
  readOrderFlag: PropTypes.bool,
  showModal: PropTypes.func,
  setIsNewCustomer: PropTypes.func,
  readOrderStatus: PropTypes.string,
  refetchCartDetails: PropTypes.func,
};

export default AccessoriesCheckoutDetails;
