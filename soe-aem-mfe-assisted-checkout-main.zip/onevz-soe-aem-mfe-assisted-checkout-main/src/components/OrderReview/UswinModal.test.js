import React from 'react';
import { render, screen } from '@testing-library/react';
import UswinModal from './UswinModal';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';

describe('test', () => {
  const props = {
    uswinModalEnable: true,
    closeModal: jest.fn(),
    CustomerProfileResult: jest.fn(),
    uswinStatus: {
      limit: 2,
      errStatus: false,
      disableContinueBtn: false,
      uPassword: '',
    },
    handleUswinChange: jest.fn(),
    uswinStatusMessage: jest.fn(),
    handleSubmitUswin: jest.fn(),
  };
  test('component mount', async () => {
    render(<UswinModal opened {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    expect(screen.getByTestId('uswin_modal')).toBeInTheDocument();
  });
});
