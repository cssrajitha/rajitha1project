import { Modal, ModalBody } from '@vds/modals';
import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { Button } from '@vds/buttons';
import styled from 'styled-components';
import { requestBodyRetriveCart } from '../../modules/services/APIService/APIRequestBody';

const Title = styled.div`
  padding: 10px 0;
  font-weight: 700;
  font-size: 32px;
  color: green;
`;

const SubTitle = styled.div`
  padding: 10px 0;
  font-size: 20px;
  font-weight: 300;
`;

const Wrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
`;
const ButtomWrapper = styled.div`
  [class^='StyledButton-VDS'] {
    margin: 20px 0;
    padding: 0 20px;
  }
`;

const AffirmPaymentConfirmationModal = ({
  getCartDetailsDataBody,
  setShowAffirmPaymentConfirmation,
  setShowAffirmModal,
  cartDetails,
  setContinueBtnDisabled,
  setShowAffirmAccordion,
}) => {
  const [isGamingConsole, setIsGamingConsole] = useState(false);
  useEffect(() => {
    setIsGamingConsole(
      cartDetails?.lineDetails?.lineInfo[0]?.itemsInfo[0]?.cartItems?.cartItem[0]?.deviceDisplayName
        .toLowerCase()
        .includes('xbox'),
    );
  }, [cartDetails]);
  const handleClose = () => {
    getCartDetailsDataBody({ body: requestBodyRetriveCart, spinner: true, mock: false });
    setShowAffirmPaymentConfirmation(false);
    setShowAffirmModal(false);
    setContinueBtnDisabled(false);
    setShowAffirmAccordion(false);
  };
  return (
    <Modal
      id='Verizonvisacard'
      surface='light'
      width='1200px'
      fullScreenDialog
      hideCloseButton
      disableOutsideClick
      closeButton={null}
      ariaLabel='Testing Modal'
      opened
    >
      <ModalBody>
        <Wrapper>
          <Title>Approved</Title>
          <SubTitle>
            {isGamingConsole
              ? 'Customer is eligible for XAA, please continue with order placement.'
              : 'Customer is eligible for financing, please continue with order placement.'}
          </SubTitle>
          <ButtomWrapper>
            <Button use='primary' data-track='Continue' data-testid='Continue' onClick={handleClose}>
              Continue
            </Button>
          </ButtomWrapper>
        </Wrapper>
      </ModalBody>
    </Modal>
  );
};

AffirmPaymentConfirmationModal.propTypes = {
  setShowAffirmPaymentConfirmation: PropTypes.func,
  setShowAffirmModal: PropTypes.func,
  cartDetails: PropTypes.object,
  getCartDetailsDataBody: PropTypes.func,
  setContinueBtnDisabled: PropTypes.func,
  setShowAffirmAccordion: PropTypes.func,
};

export default AffirmPaymentConfirmationModal;
