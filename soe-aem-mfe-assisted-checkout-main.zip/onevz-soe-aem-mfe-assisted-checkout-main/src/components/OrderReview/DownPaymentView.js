import { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { Icon } from '@vds/icons';
import { Line } from '@vds/lines';
import { Button } from '@vds/buttons';
import { Title } from '@vds/typography';
import Emitter from 'onevzsoemfeframework/Emitter';
import DownPayment from 'onevzsoemfecommon/DownPayment';
import DOMPurify from 'dompurify';
import { BackClickable, Padding36 } from '../../StyledConstants';
import orderreviewApiCallHook from '../../pages/home/container/orderreviewApiCallHook';

const DividerTop = styled.div`
  margin-top: 50px;
`;

const Divider = styled.div`
  margin: 64px 0;
  border-bottom: 1px solid rgb(0, 0, 0);
`;

const FooterArea = styled.div`
  max-width: 64rem;
  background-color: rgb(255, 255, 255);
  z-index: 1;
  bottom: 0px;
  position: fixed;
  width: 100%;
  display: flex;
  border-top: 1px solid rgb(0, 0, 0);
  justify-content: center;
`;

const FixedHeader = styled.div`
  max-width: 64rem;
  background-color: rgb(255, 255, 255);
  z-index: 1;
  top: 0;
  width: 100%;
  position: absolute;
  height: 100%;
`;

export const FlexAlignContainerItemsCenter = styled.div`
  display: flex;
  align-items: center !important;
  justify-content: space-between;

  position: fixed;
  height: 4rem;
  width: 100%;
  max-width: 64rem;
  background: white;
  border-bottom: 1px solid #d8dada;
  z-index: 2;
`;

const FlexBoxGrowOne = styled.div`
  display: flex;
  flex-grow: 1;
  height: 4rem;
  align-items: center;
`;

const CloseIconWrapper = styled.div`
  display: flex;

  a {
    padding: 1rem !important;
  }
`;

const Marginleft = styled.div`
  margin-left: 20px;
`;

const DownpaymentViewWrapper = styled.div`
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0;
  left: 0;
  background: #fff;
  z-index: 99;
  display: flex;
  justify-content: center;
  overflow: auto;
`;

const DownpaymentBodyWrapper = styled.div`
  padding: 50px 0 100px 0;
`;

const DownPaymentView = ({
  handleDPClose,
  CustomerProfileResult,
  cart,
  setDownPayment,
  handleDPDone,
  downpayment,
  fetchDownPaymentResult,
}) => {
  const { updateDownpaymentBody } = orderreviewApiCallHook();

  useEffect(() => {
    const details = {
      PAGE_LOADED: 'true',
      CUSTOM_EVENT: 'Pageview',
    };
    Emitter.emit('PAGE_LOADED', details);
  }, []);

  // const [dpAmount, setDpAmount] = useState(0);
  const [dpResult, setDpResult] = useState({});
  const setDownPaymentHandler = (amount, type, mtn) => {
    // setDpAmount(amount);
    setDownPayment(amount);
    if (typeof amount === 'number' && mtn) {
      setDpResult({ ...dpResult, [mtn]: amount });
    }
  };
  const getDpAmount = (dp) => {
    if (dpResult[dp.mtn] !== undefined) {
      return dpResult[dp.mtn];
    }
    const dpAmount = parseFloat(dp.downPayment);
    if (Number.isNaN(dpAmount)) {
      return 0;
    }
    return dpAmount;
  };
  const handleDPDoneClick = async () => {
    const customerType =
      new URLSearchParams(DOMPurify.sanitize(window.location.search))?.get('customerType') ||
      sessionStorage.getItem('customerType') ||
      cart?.orderDetails?.customerType;

    const addDpRequest = {
      cartInfo: {
        clientAppName: `VZW-${cart?.cartHeader?.vendorId}`,
        cartId: cart?.cartHeader?.cartId || sessionStorage.getItem('cartId'),
        caseId: CustomerProfileResult?.data?.data?.customer?.caseId,
        accountNumber: CustomerProfileResult?.data?.data?.customer?.accountNo ?? '',
        cartCreator: cart?.cartHeader?.cartCreator,
        processStep: 'DownPayment',
        intendType: customerType === 'N' ? 'NSE' : 'EUP',
      },
      data: {
        lines: fetchDownPaymentResult?.map((dp) => ({
          mtn: dp.mtn,
          lineDeviceDollar: 0,
          downPayment: {
            amount: getDpAmount(dp),
            percentage: 0,
          },
        })),
      },
    };
    await updateDownpaymentBody({ body: addDpRequest });
    handleDPDone();
  };
  return (
    <DownpaymentViewWrapper>
      <FixedHeader data-testId='downpaymentView'>
        <FlexAlignContainerItemsCenter>
          <FlexBoxGrowOne>
            <Title size='small' bold>
              Down Payments
            </Title>
          </FlexBoxGrowOne>
          <CloseIconWrapper>
            <Marginleft>
              <BackClickable data-testId='btn-exit-dialog' onClick={handleDPClose}>
                <Icon name='close' size='large' />
              </BackClickable>
            </Marginleft>
          </CloseIconWrapper>
        </FlexAlignContainerItemsCenter>
        <Line type='secondary' />
        <DownpaymentBodyWrapper>
          {CustomerProfileResult?.data?.data?.customer &&
            fetchDownPaymentResult?.map((dp, i) => (
              <DividerTop data-testid='downpayment-content'>
                {i > 0 && <Divider />}
                <DownPayment
                  CustomerData={CustomerProfileResult?.data?.data?.customer}
                  selectedSku={{ sorId: dp.sorId }}
                  mtn={dp.mtn || ''}
                  setDownPayment={setDownPaymentHandler}
                  spendingLimitAmountExceededBy={cart?.lineDetails?.spendingLimitAmountExceededBy || 0}
                  downPaymentAmount={downpayment || 0}
                  hideLimits={i > 0}
                />
              </DividerTop>
            ))}
        </DownpaymentBodyWrapper>
        <FooterArea>
          <Padding36>
            <Button data-testid='handleDPDone-button' size='large' disabled={false} onClick={handleDPDoneClick}>
              Done
            </Button>
          </Padding36>
        </FooterArea>
      </FixedHeader>
    </DownpaymentViewWrapper>
  );
};

DownPaymentView.propTypes = {
  handleDPClose: PropTypes.func,
  CustomerProfileResult: PropTypes.object,
  setDownPayment: PropTypes.func,
  handleDPDone: PropTypes.func,
  cart: PropTypes.object,
  downpayment: PropTypes.any,
  fetchDownPaymentResult: PropTypes.any,
};

export default DownPaymentView;
