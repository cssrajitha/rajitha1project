import React, { useState } from 'react';
import styled from 'styled-components';
import { TileContainer } from '@vds/tiles';
import { Body } from '@vds/typography';
import { TextLink } from '@vds/buttons';
import PropTypes from 'prop-types';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR } from '../constants/constants';
import { StyledPaddingLeft8 } from '../../StyledConstants';
import DFOPaymentModal from './DFOPaymentModal';

const TileContainerWrapper = styled.div`
  [class^='OuterTileContainer'] {
    border-radius: 0px !important;
    height: 100%;
  }
`;

const TileWrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  padding: 8px;
`;
const Title = styled.div`
  font-weight: 700;
  line-height: 1.25rem;
  letter-spacing: 0.03125rem;
  margin: 0px;
  text-decoration: none;
  width: 220px;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  font-size: 20px;
  color: rgb(0, 0, 0);
  padding-bottom: 10px;
`;
const PriceWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 0.25rem;
  padding: 4px 0;
  &.clickable {
    cursor: pointer;
  }
  p {
    font-family: BrandFont-Text, Helvetica, Arial, sans-serif;
    font-size: 18px
    line-height: normal;
  }
`;

const AmountWrapper = styled.div`
  p {
    font-family: BrandFont-Text, Helvetica, Arial, sans-serif;
    font-size: 18px;
    line-height: normal;
  }
`;
const PriceImageWrapper = styled.div`
  display: flex;
`;
const LinkWrapper = styled.div`
  text-align: left;
  padding-bottom: 1rem;
  padding-top: 1rem;
  padding-left: 0;
`;

const Value = styled.div`
  font-size: 20px;
  font-weight: 700;
  line-height: 1.25rem;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  letter-spacing: 0.03125rem;
  color: rgb(0, 0, 0);
  margin: 0px;
  text-decoration: none;
`;
const DFOPriceInfo = (props) => {
  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;
  const bgColor = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.themeProps?.background;

  const [showDFOPaymentDetails, setShowDFOPaymentDetails] = useState(false);
  return (
    <React.Fragment>
      <TileContainerWrapper>
        <TileContainer
          padding='1.5rem 0 0 0'
          height='auto'
          width='384px'
          backgroundColor={props?.bgColor}
          surface={isDark ? 'dark' : 'light'}
        >
          <TileWrapper
            id={props.id}
            line={props.line}
            style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR, backgroundColor: isDark ? bgColor : '' }}
          >
            <PriceWrapper>
              <Title
                fullwidth
                id={props?.id}
                titleWidth={props?.titleWidth}
                style={{
                  color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                  backgroundColor: isDark ? bgColor : '',
                }}
              >
                {props?.title}
              </Title>
              <Value
                style={{
                  color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                  backgroundColor: isDark ? bgColor : '',
                }}
              >
                {props?.title === 'Total Payment' ? props?.price : ''}
              </Value>
            </PriceWrapper>

            {props?.info?.map((pay) => (
              <PriceWrapper
                key={pay?.payment}
                style={{
                  color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                  backgroundColor: isDark ? bgColor : '',
                }}
              >
                <PriceImageWrapper
                  style={{
                    color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                    backgroundColor: isDark ? bgColor : '',
                  }}
                >
                  <AmountWrapper
                    style={{
                      color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                      backgroundColor: isDark ? bgColor : '',
                    }}
                    key={`${pay?.payment}right`}
                  >
                    <Body size='small' color={isDark ? DARK_THEME_COLOR : ''} key={`${pay?.payment}rBody`}>
                      {pay?.isBold ? (
                        <b style={{ fontSize: '17px' }}>{pay?.payment}</b>
                      ) : (
                        <div style={{ fontSize: '16px' }}>{pay?.payment}</div>
                      )}
                      {pay?.hasSubText && <div style={{ fontSize: '14px' }}>(exclusive of tax)</div>}
                    </Body>
                  </AmountWrapper>
                </PriceImageWrapper>
                <StyledPaddingLeft8>
                  <AmountWrapper
                    style={{
                      color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                      backgroundColor: isDark ? bgColor : '',
                    }}
                    key={`${pay.payment}left`}
                  >
                    <Body size='small' color={isDark ? DARK_THEME_COLOR : ''} key={`${pay.payment}lBody`}>
                      {pay?.hideMonthly ? pay?.price : `${pay?.price}/mo`}
                    </Body>
                  </AmountWrapper>
                </StyledPaddingLeft8>
              </PriceWrapper>
            ))}

            <LinkWrapper>
              {props?.title === 'Device' ? (
                <TextLink
                  type='standAlone'
                  data-testId='deviceLink'
                  surface={isDark ? 'dark' : 'light'}
                  disabled={false}
                  size='small'
                  onClick={props?.handleViewDevices}
                >
                  View
                </TextLink>
              ) : (
                <TextLink
                  type='standAlone'
                  data-testId='paymentLink'
                  surface={isDark ? 'dark' : 'light'}
                  disabled={false}
                  size='small'
                  onClick={() => {
                    setShowDFOPaymentDetails(true);
                  }}
                >
                  View Details
                </TextLink>
              )}
            </LinkWrapper>
          </TileWrapper>
        </TileContainer>
      </TileContainerWrapper>
      {showDFOPaymentDetails && (
        <DFOPaymentModal
          opened={showDFOPaymentDetails}
          setShowDFOPaymentDetails={setShowDFOPaymentDetails}
          {...props}
        />
      )}
    </React.Fragment>
  );
};
DFOPriceInfo.propTypes = {
  padding: PropTypes.string,
  bgColor: PropTypes.string,
  id: PropTypes.string,
  line: PropTypes.string,
  titleWidth: PropTypes.string,
  title: PropTypes.string,
  price: PropTypes.string,
  info: PropTypes.string,
  handleViewDevices: PropTypes.func,
};
export default DFOPriceInfo;
