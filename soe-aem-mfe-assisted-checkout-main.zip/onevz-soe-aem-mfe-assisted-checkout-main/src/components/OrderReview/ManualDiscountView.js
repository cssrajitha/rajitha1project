import React, { useEffect, useRef, useState } from 'react';
import { useDispatch } from 'react-redux';
import { isErtUser, isPactUser } from 'onevzsoemfecommon/Helpers/common_functions';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import { Icon } from '@vds/icons';
import { Line } from '@vds/lines';
import { Button } from '@vds/buttons';
import { Body, Title } from '@vds/typography';
import { Notification } from '@vds/notifications';
import { Input as VdsInput } from '@vds/inputs';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { isIpad, executeShellFunction } from 'onevzsoemfeframework/DomService';
import ManagerApprovalView from 'onevzsoemfecommon/ManagerApprovalView';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { Loader } from '@vds/loaders';
import { BackClickable, Padding36 } from '../../StyledConstants';
import orderreviewApiCallHook from '../../pages/home/container/orderreviewApiCallHook';
import { allowOnlyAlphaNumeric } from '../../utils/common';
import ManulDiscountItem from './ManulDiscountItem';
import { DARK_THEME_BGCOLOR, DARK_THEME_COLOR, isDark } from '../constants/constants';
import { isNSEQAFlow } from '../ShippingDetails/FormUtils';

export const Padding24 = styled.div`
  padding: 1.5rem;
`;

const DividerTop = styled.div`
  margin-top: 50px;
`;

const FooterArea = styled.div`
  max-width: ${(props) => props?.maxWidth || '64rem'};
  background-color: ${(props) => (props?.isDark ? '#000000' : 'rgb(255, 255, 255)')};
  z-index: 1;
  bottom: 0px;
  position: ${(props) => props?.position || 'fixed'};
  width: 100%;
  display: flex;
  border-top: ${(props) => (props?.isDark ? '1px solid #ffffff' : '1px solid rgb(0, 0, 0)')};
  justify-content: center;
`;

const ManualDiscountContainer = styled.div`
  height: ${(props) => props?.height || '85%'};
  padding-bottom: ${(props) => props?.pb || '100px'};
`;

const Wrapper = styled.div`
  margin-bottom: 100px;
`;

/* istanbul ignore next */
const FixedHeader = styled.div`
  max-width: ${(props) => (props?.scmUpgradeMfeEnable ? '100%' : '64rem')};
  background-color: rgb(255, 255, 255);
  z-index: 99;
  top: 0;
  width: 100%;
  position: ${(props) => {
    const positionFFlag = JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.positionFFlag === 'TRUE';
    const discountItems = document.getElementsByClassName('discount-items-container');
    const promoModalPosition = positionFFlag && props?.containerName === 'add_discounts' && discountItems?.length > 1;

    /* istanbul ignore next */
    return props?.scmUpgradeMfeEnable ? 'initital' : (promoModalPosition && 'absolute') || 'fixed';
  }};
  height: ${(props) => (props?.promoPaddingFFlag ? 'auto' : '100%')};
`;

export const FlexAlignContainerItemsCenter = styled.div`
  display: flex;
  align-items: center !important;
  justify-content: space-between;
  ${(props) =>
    props.scmUpgradeMfeEnable &&
    `
    position: sticky;
    top: 0;
    z-index: 5;
    background-color: ${props?.isDark ? '#000000' : 'rgb(255, 255, 255)'};
  `}
`;

const FlexBoxGrowOne = styled.div`
  display: flex;
  flex-grow: 1;
  height: 4rem;
  align-items: center;
`;

const ContentTitle = styled.div`
  font-size: 18px;
  font-weight: bold;
  line-height: 56px;
`;

const CloseIconWrapper = styled.div`
  display: flex;

  a {
    padding: 1rem !important;
  }
`;

const Marginleft = styled.div`
  margin-left: 20px;
`;

/* istanbul ignore next */
const ManualDiscount = styled.div`
  .row.content {
    &.scmUpgradeMfeEnable {
      margin: 0;
    }
    display: flex;
    margin-bottom: 10px;
    > div {
      padding: 10px 0;
    }
    padding-right: 0.875rem !important;
    padding-left: 0.875rem !important;
    padding-top: 1.3125rem !important;
    padding-bottom: 1.3125rem !important;
    p {
      font-size: 18px !important;
    }
    .col-1 {
      align-items: center;
      display: flex;
      text-align: left;
      justify-content: flex-start;
      flex-basis: 25%;
      gap: 5px;
    }
    .col-2 {
      flex-basis: 15%;
      align-items: center;
      display: flex;
      text-align: left;
      justify-content: center;
    }
    .col-3 {
      flex-basis: 35%;
      align-items: center;
      display: flex;
      text-align: left;
      justify-content: center;
    }
    .col-4 {
      flex-basis: 25%;
      align-items: center;
      display: flex;
      text-align: left;
      justify-content: center;
    }
  }
  .row.header {
    display: flex;
    &.scmUpgradeMfeEnable {
      margin: 0;
    }
    > div {
      padding: 10px 0;
    }
    p {
      font-size: 20px !important;
    }
    .col-1 {
      flex-basis: 30%;
    }
    .col-2 {
      flex-basis: 16%;
    }
    .col-3 {
      flex-basis: 25%;
      text-align: center;
    }
    .col-4 {
      flex-basis: 25%;
      text-align: center;
    }
  }
  .header,
  .body {
    border-bottom: 1px solid #d8dada;
  }
  .buttons {
    justify-content: flex-start;
    &.scmUpgradeMfeEnable {
      margin: 0;
    }
    button {
      background: transparent;
      color: #000;
      font-size: 14px;
      font-weight: normal;
    }
  }

  .promo-codes {
    font-size: 16px;
  }

  .link-btn {
    border: 0;
    background: none;
    margin-left: 50px;
    font-size: 14px;
    text-decoration: underline;
    cursor: pointer;
  }

  .promoCodeSection {
    padding-bottom: ${(props) => (props.promoPaddingFFlag ? '17rem' : '0px')};
  }
`;

const AddPromoCodeContent = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;

  input {
    border: 1px solid #d8dada;
    border-bottom: 1px solid #000;
    box-shadow: none;
    border-radius: 0;
    width: 530px;
    font-weight: bold;
    text-transform: uppercase;
  }
  button {
    font-size: 16px;
    border: 0;
    background: transparent;
    text-decoration: underline;
    margin-top: 25px;
  }

  label {
    color: #959595 !important;
  }
`;

const NotificationWrapper = styled.div`
  position: fixed;
  z-index: 99999;
  top: 5px;
  width: 98%;
`;

const ManualDiscountView = ({
  handleClose,
  cart,
  customer,
  handleCloseIconModal,
  cartDetails,
  refetchCartDetails,
  isQAFlow = false,
  managerApprovalOnLoad = false,
}) => {
  const themeSurface = () => (isDark() ? 'dark' : 'light');
  const themeTextColor = () => (isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR);
  const themeBgColor = () => (isDark() ? DARK_THEME_BGCOLOR : DARK_THEME_COLOR);
  const [isReadOrderFlag] = getAssistedCradlePropertyV2(['readOrderMfeFFlag']);
  const isReadOrderFlagEnabled = /true/i.test(isReadOrderFlag);
  const promoPaddingFFlag = /true/i.test(getAssistedCradlePropertyV2(['paddingFFlag'])?.[0]);
  const isReadOrder = sessionStorage.getItem('readOrder');
  const dispatch = useDispatch();
  const {
    manualDiscountBody,
    ManualDiscountResult,
    updateManualDiscountBody,
    updateManualDiscountResult,
    updateBarCodeBody,
    updateBarCodeResult,
    getValidateCartAndCheckoutBody,
    getValidateCartAndCheckoutResult,
  } = orderreviewApiCallHook();
  const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable;
  const [loaded, setLoaded] = useState(false);
  const [showLoader, setShowLoader] = useState(false);
  const [showManagerApproval, setShowManagerApproval] = useState(false);
  const discountViewRef = useRef();

  const [data, setData] = useState([]);
  const [discountTotal, setDiscountTotal] = useState(0);
  const [showNotification, setShowNotification] = useState(false);
  const [notificationTitle, setNotificationTitle] = useState('');
  const [notificationType, setNotificationType] = useState('');
  const [hasDiscounts, setHasDiscounts] = useState(false);
  const [showPromoCode, setShowPromoCode] = useState(false);
  const [promoCode, setPromoCode] = useState('');
  const [promoCodeError, setPromoCodeError] = useState(false);
  const [doneClicked, setDoneClicked] = useState(false);
  const [showManagerLogins, setShowManagerLogins] = useState(false);
  const [giftSorSkuId, setGiftSorSkuId] = useState();
  let cartId = customer?.cartId || sessionStorage.getItem('cartId');
  if (scmUpgradeMfeEnable) {
    cartId = sessionStorage.getItem('acssMfeCartId');
  }

  const isNSEQA = isNSEQAFlow(isQAFlow, cart);

  const init = () => {
    if (!loaded) {
      const request = {
        data: {
          cartId: isReadOrderFlagEnabled && isReadOrder ? cartDetails?.cartId : cartId,
          locationCode:
            isReadOrderFlagEnabled && isReadOrder
              ? getQueryParamByName('locationCode')
              : cart?.orderDetails?.locationCode,
        },
      };
      manualDiscountBody({ body: request, mock: false });
      setLoaded(true);
    }
  };
  init();

  const { reasonCodeList = [] } = ManualDiscountResult?.data?.data?.manualDiscountInfo || {};
  const { barcode = [] } = ManualDiscountResult?.data?.data || [];
  const mountRef = useRef(true);

  useEffect(() => {
    const cartItemsData = cart?.lineDetails?.lineInfo?.[0]?.itemsInfo?.[0]?.cartItems;
    const isGiftItem = cartItemsData?.cartItem.filter((item) => item.prodCode2 === 'GIF');
    const skuId = cartItemsData?.cartItem.filter((item) => item.prodCode2 === 'GIF' && item.sorId);
    if (isQAFlow && isGiftItem && skuId) {
      setGiftSorSkuId(skuId);
    }
  }, []);

  const itemHaveAppliedDiscount = data
    ?.filter((item) => item?.manualDiscountPrice > 0)
    ?.map((item) => item.manualDiscountPrice)
    .join(',');

  useEffect(() => {
    if (scmUpgradeMfeEnable && typeof refetchCartDetails === 'function') {
      if (!mountRef?.current) {
        refetchCartDetails();
      } else {
        mountRef.current = false;
      }
    }
  }, [itemHaveAppliedDiscount?.length]);

  useEffect(() => {
    const discountedItems = ManualDiscountResult?.data?.data?.manualDiscountInfo?.items;
    const totalDiscount = ManualDiscountResult?.data?.data?.manualDiscountInfo?.discountTotal;
    const showDiscountModalOnRemove = (isQAFlow && totalDiscount !== 0.0) || !isQAFlow;
    if (discountedItems) {
      if (discountedItems?.some((discItem) => Number(discItem?.manualDiscountPrice) > 0) && showDiscountModalOnRemove) {
        setDiscountTotal(totalDiscount);
        setShowManagerApproval(true);

        /* istanbul ignore next */

        if (
          (!scmUpgradeMfeEnable || (scmUpgradeMfeEnable && (isErtUser() || isPactUser()))) &&
          (doneClicked || managerApprovalOnLoad)
        ) {
          setShowManagerLogins(true);
        }
      } else {
        setShowManagerApproval(false);
      }

      setShowLoader(false);
      setData(discountedItems);
    }
  }, [ManualDiscountResult?.data?.data]);

  useEffect(() => {
    if (getValidateCartAndCheckoutResult?.isSuccess) {
      handleClose();
    }
  }, [getValidateCartAndCheckoutResult]);

  const handleAddCoupon = () => {
    setShowNotification(false);
    setShowPromoCode(true);

    if (scmUpgradeMfeEnable && discountViewRef?.current) {
      discountViewRef.current.style.display = 'none';
    }
  };

  useEffect(() => {
    setHasDiscounts(
      data.every((item) => {
        if (item?.dType === '%') {
          if (!item?.discountPercent || item?.discountPercent === null) return true;
          if (item?.discountPercent > 0 && (!item?.reason || item?.reason === 'select')) return false;
          return item?.discountPercent > 0 && item?.reason && item?.reason !== 'select';
        }
        if (!item?.discountAmount || item?.discountAmount === null) return true;
        if (item?.discountAmount > 0 && (!item?.reason || item?.reason === 'select')) return false;
        return item?.discountAmount > 0 && item?.reason && item?.reason !== 'select';
      }),
    );
  }, [data]);

  const isDiscountAdded = data?.some((each) => each.discountedPrice);

  const handleDone = () => {
    setDoneClicked(true);
    const promoCodes = ManualDiscountResult?.data?.data?.barcode || [];
    if (!isDiscountAdded && promoCodes.length === 0) {
      const accountNo = customer?.accountNo;
      const lookupMtn = customer?.lookupMtn;
      const cartCreator = cart?.cartHeader?.cartCreator || sessionStorage.getItem('creditAppNum') || '';
      const caseId = customer?.caseId;
      const orderLocationCode = customer?.orderLocationCode;

      const requestValidateCartAndCheckoutBody = {
        cartInfo: {
          correlationId: '69a66ef4d7e344dfb2db299209ea8333',
          cartId,
          caseId,
          accountNumber: accountNo,
          cartCreator: scmUpgradeMfeEnable ? cartCreator : lookupMtn,
          processingMTN: lookupMtn,
          locationCode: orderLocationCode,
          intendType: '',
          processStep: 'ShoppingCart',
          processAction: '',
          creditAppNum: '',
          skipValidationErrorCodes: '',
          quoteWithoutCredit: false,
        },
      };
      if (isNSEQA) {
        requestValidateCartAndCheckoutBody.cartInfo.intendType = 'NSEACC';
        requestValidateCartAndCheckoutBody.cartInfo.accountNumber = null;
        requestValidateCartAndCheckoutBody.cartInfo.cartCreator = '9999999999';
      }
      getValidateCartAndCheckoutBody({ body: requestValidateCartAndCheckoutBody, mock: false });
    } else {
      const linesData = [];
      const filteredData = data?.filter((each) => each?.discountPercent > 0 || each?.discountAmount > 0);
      filteredData?.forEach((item) => {
        linesData.push({
          mtn: item.mtn,
          manualDiscount: [
            {
              skuId: item.sorSkuId,
              discountReasonCode: parseInt(item?.reason, 10),
              discountPercent: item?.discountPercent || 0,
              discountAmount: item?.discountAmount || 0,
            },
          ],
        });
      });

      const request = {
        cartInfo: {
          processingMTN: linesData?.[0]?.mtn,
          intendType: isNSEQA ? 'NSEACC' : cart?.orderDetails?.orderList?.[0]?.orderActivityType,
          processStep: 'OrderReview-Shipping',
          action: 'ADD',
        },
        data: {
          lines: [...linesData],
        },
      };

      setShowLoader(true);
      updateManualDiscountBody({ body: request, mock: false });
    }
  };

  useEffect(() => {
    if (updateManualDiscountResult?.status === 'fulfilled') {
      const request = {
        data: {
          cartId,
          locationCode: cart?.orderDetails?.locationCode,
        },
      };
      const message = updateManualDiscountResult?.data?.serviceBody?.serviceResponse?.context?.cartInfo?.statusMsg;
      dispatch(appMessageActions.addAppMessage(message, 'success', true, true));

      manualDiscountBody({ body: request, mock: false });
    } else if (!['pending', 'uninitialised'].includes(updateManualDiscountResult?.status)) {
      setShowLoader(false);
    }
  }, [updateManualDiscountResult]);

  const handlePromoClose = () => {
    setShowPromoCode(false);

    if (scmUpgradeMfeEnable && discountViewRef?.current) {
      discountViewRef.current.style.display = 'block';
    }
  };

  const handleSubmit = () => {
    setShowNotification(false);
    const request = {
      cartInfo: {
        clientAppName: 'VZW-NETACE',
        cartId,
        caseId: cart.cartHeader.caseId,
        accountNumber: cart.cartHeader.fullAccountNumber,
        cartCreator: cart.cartHeader.cartCreator,
        processingMTN: cart.lineDetails.lineInfo[0].mtn,
        processStep: 'ShoppingCart',
        barCodeIds: [
          {
            barCodeId: promoCode,
          },
        ],
        creditAppNum: '',
      },
      data: {
        includeExpiryBarcodeStatus: 'Y',
        lines: [
          {
            mtn: cart.lineDetails.lineInfo[0].mtn,
          },
        ],
      },
    };
    updateBarCodeBody({ body: request });
  };

  useEffect(() => {
    if (updateBarCodeResult?.data?.errors) {
      setPromoCodeError(true);
      setNotificationTitle(updateBarCodeResult?.data?.errors[0].message);
      setNotificationType('error');
      setShowNotification(true);
    } else if (updateBarCodeResult?.data?.serviceBody) {
      setNotificationType('success');
      setPromoCode('');
      setShowNotification(true);
      setLoaded(false);
      const message = updateBarCodeResult?.data?.serviceBody?.serviceResponse?.context?.cartInfo.statusMsg;
      if (message) {
        setNotificationTitle(message);
        setShowPromoCode(false);
      }
      init();
    }
  }, [updateBarCodeResult?.data]);

  const promoCodeScannerCallback = (scannedData) => {
    if (allowOnlyAlphaNumeric(scannedData.dataset.barcode)) {
      setPromoCode(scannedData.dataset.barcode);
    }
  };

  const handleScanBarCode = () => {
    window[promoCode] = promoCodeScannerCallback.bind(this);
    if (isIpad()) {
      const promoCodeCallback = 'promoCodeScannerCallback';
      executeShellFunction('HolsterManager', 'activateBarcode', promoCodeCallback);
    }
  };
  const handlePromoCodeChange = (e) => {
    setPromoCode(e.target.value);
  };

  const handleRemovePromoCode = () => {
    setShowNotification(false);
    const request = {
      cartInfo: {
        clientAppName: 'VZW-NETACE',
        cartId,
        caseId: cart.cartHeader.caseId,
        accountNumber: cart.cartHeader.fullAccountNumber,
        cartCreator: cart.cartHeader.cartCreator,
        processingMTN: cart.lineDetails.lineInfo[0].mtn,
        processStep: 'ShoppingCart',
        creditAppNum: '',
      },
      data: {
        includeExpiryBarcodeStatus: 'Y',
        lines: [
          {
            mtn: cart.lineDetails.lineInfo[0].mtn,
          },
        ],
      },
    };
    updateBarCodeBody({ body: request });
  };

  const handleRemoveDiscount = (payload) => {
    if (scmUpgradeMfeEnable) {
      setShowLoader(true);
    }
    manualDiscountBody(payload);
  };

  return (
    <>
      {showNotification && (
        <NotificationWrapper>
          <Notification
            type={notificationType}
            title={notificationTitle}
            fullBleed={false}
            inline={false}
            disableFocus
            layout='horizontal'
            onCloseButtonClick={() => {
              setShowNotification(false);
            }}
          />
        </NotificationWrapper>
      )}

      {scmUpgradeMfeEnable && showLoader && <Loader active surface='light' />}

      {(!showPromoCode || scmUpgradeMfeEnable) && !showManagerApproval && (
        <FixedHeader
          ref={discountViewRef}
          scmUpgradeMfeEnable={scmUpgradeMfeEnable}
          data-testId='manualDiscountView'
          containerName='add_discounts'
          style={{ backgroundColor: themeBgColor(), color: themeTextColor() }}
          promoPaddingFFlag={promoPaddingFFlag}
        >
          <FlexAlignContainerItemsCenter scmUpgradeMfeEnable={scmUpgradeMfeEnable} isDark={isDark()}>
            <FlexBoxGrowOne>
              <Title size='small' bold color={themeTextColor()}>
                Add Discounts
              </Title>
            </FlexBoxGrowOne>
            <CloseIconWrapper onClick={handleCloseIconModal}>
              <Marginleft>
                <BackClickable data-testId='btn-exit-dialog' onClick={handleClose}>
                  <Icon name='close' size='large' color={isDark() ? '#fff' : '#000'} />
                </BackClickable>
              </Marginleft>
            </CloseIconWrapper>
          </FlexAlignContainerItemsCenter>

          <Line type='secondary' />
          <ManualDiscountContainer
            {...(scmUpgradeMfeEnable && {
              height: 'auto',
              pb: '50px',
            })}
          >
            <Wrapper>
              <DividerTop data-testid='downpayment-content'>
                <ManualDiscount
                  className={scmUpgradeMfeEnable ? 'scmUpgradeMfeEnable' : ''}
                  promoPaddingFFlag={promoPaddingFFlag}
                >
                  <div className={`row header ${scmUpgradeMfeEnable ? 'scmUpgradeMfeEnable' : ''}`}>
                    <div className='col-1'>
                      <Body color={themeTextColor()}>Item</Body>
                    </div>
                    <div className='col-2'>
                      <Body color={themeTextColor()}>Quantity</Body>
                    </div>
                    <div className='col-3'>
                      <Body color={themeTextColor()}>Discount</Body>
                    </div>
                    <div className='col-4'>
                      <Body color={themeTextColor()}>Reason</Body>
                    </div>
                  </div>

                  {data?.map(
                    (item, index) =>
                      item.sorSkuId !== giftSorSkuId && (
                        <ManulDiscountItem
                          key={item?.sorSkuId}
                          item={item}
                          index={index}
                          reasonCodeList={reasonCodeList}
                          data={data}
                          setData={setData}
                          cart={cart}
                          refreshManulaDiscountBody={handleRemoveDiscount}
                          setNotificationTitle={setNotificationTitle}
                          setNotificationType={setNotificationType}
                          setShowNotification={setShowNotification}
                          themeTextColor={themeTextColor()}
                        />
                      ),
                  )}
                  {barcode.length > 0 && (
                    <div className='row promo-codes' style={{ color: themeTextColor() }}>
                      <div>
                        <Body>
                          <strong>Bill incentive Credit: {barcode.map((code) => code)}</strong>{' '}
                          <button
                            data-testId='promo-remove-btn'
                            type='button'
                            className='link-btn'
                            onClick={handleRemovePromoCode}
                          >
                            Remove
                          </button>
                        </Body>
                      </div>
                    </div>
                  )}
                  <div className={`row buttons promoCodeSection ${scmUpgradeMfeEnable ? 'scmUpgradeMfeEnable' : ''}`}>
                    <div>
                      <Button
                        data-testid='handleAddCoupon-button'
                        size='large'
                        disabled={false}
                        onClick={handleAddCoupon}
                        surface={themeSurface()}
                        style={{ backgroundColor: themeBgColor(), color: themeTextColor() }}
                      >
                        Add Promo Code
                      </Button>
                    </div>
                  </div>
                </ManualDiscount>
              </DividerTop>
            </Wrapper>
          </ManualDiscountContainer>

          <FooterArea {...(scmUpgradeMfeEnable && { position: 'sticky', maxWidth: '100%' })} isDark={isDark()}>
            <Padding36 {...(scmUpgradeMfeEnable && { style: { paddingBottom: '0px' } })}>
              <Button
                style={{ backgroundColor: themeTextColor(), color: themeBgColor(), opacity: !hasDiscounts ? 0.5 : 1 }}
                data-testid='handleDPDone-button'
                size='large'
                disabled={!hasDiscounts}
                onClick={handleDone}
              >
                Done
              </Button>
            </Padding36>
          </FooterArea>
        </FixedHeader>
      )}

      {showPromoCode && !showManagerApproval && (
        <FixedHeader
          scmUpgradeMfeEnable={scmUpgradeMfeEnable}
          data-testId='manualDiscountView'
          containerName='promo_code'
          style={{ backgroundColor: themeBgColor(), color: themeTextColor() }}
        >
          <FlexAlignContainerItemsCenter>
            <FlexBoxGrowOne>
              <ContentTitle color={themeTextColor()}>Add Discounts</ContentTitle>
            </FlexBoxGrowOne>
            <CloseIconWrapper>
              <Marginleft>
                <BackClickable data-testId='btn-exit-dialog-promo' onClick={handlePromoClose}>
                  <Icon name='close' size='large' color={isDark() ? '#fff' : '#000'} />
                </BackClickable>
              </Marginleft>
            </CloseIconWrapper>
          </FlexAlignContainerItemsCenter>
          <Line type='secondary' />
          <DividerTop data-testid='promoCode-content'>
            <AddPromoCodeContent>
              <div>
                <VdsInput
                  data-testId='addpromo-input'
                  label='Add Promo Code'
                  iconName=''
                  id='promoCode'
                  type='text'
                  name='promoCode'
                  className=''
                  value={promoCode}
                  onChange={handlePromoCodeChange}
                  placeholder=''
                  maxLength='50'
                  error={false}
                  surface={themeSurface()}
                />
                {promoCodeError && (
                  <Body className='error' color={themeTextColor()}>
                    Please, enter valid promo code.
                  </Body>
                )}
              </div>
              <div>
                <button type='button' data-testid='scanBarBtn' onClick={handleScanBarCode}>
                  Scan
                </button>
              </div>
            </AddPromoCodeContent>
          </DividerTop>
          <FooterArea {...(scmUpgradeMfeEnable && { position: 'sticky', maxWidth: '100%' })}>
            <Padding36>
              <Button
                style={{ backgroundColor: themeBgColor(), color: themeTextColor() }}
                disabled={!promoCode}
                data-testid='handlePromoSubmit-button'
                size='large'
                onClick={handleSubmit}
              >
                Submit
              </Button>
            </Padding36>
          </FooterArea>
        </FixedHeader>
      )}
      {showManagerApproval && (
        <ManagerApprovalView
          cart={cart}
          data-testid='manager-approver-view'
          customer={customer}
          showDiscountDetails
          discountArray={data}
          discountTotal={discountTotal}
          manualDiscountItems={data}
          setData={setData}
          handleBack={() => {
            setDoneClicked(false);
            setShowManagerApproval(false);
          }}
          handleClose={() => {
            setShowManagerApproval(false);
            setDoneClicked(false);
            if (!scmUpgradeMfeEnable) {
              handleClose();
            }
          }}
          showManagerLogins={showManagerLogins}
          isNSEQA={isNSEQA}
          isQAFlow={isQAFlow}
          scmHandleSubmit={handleClose}
          scmEnableSubmitButton={scmUpgradeMfeEnable}
        />
      )}
    </>
  );
};

ManualDiscountView.propTypes = {
  handleClose: PropTypes.func,
  cart: PropTypes.object,
  customer: PropTypes.object,
  handleCloseIconModal: PropTypes.func,
  cartDetails: PropTypes.object,
  isQAFlow: PropTypes.bool,
  managerApprovalOnLoad: PropTypes.bool,
  refetchCartDetails: PropTypes.func,
};

export default ManualDiscountView;
