import { createSlice } from '@reduxjs/toolkit';
import { useSelector } from 'react-redux';
import { render, screen, waitFor, fireEvent } from '../../utils/test-utils/renderHelper';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import ComparePlans from './ComparePlans';
import {
  ComparePlanFlowMockData,
  ComparePlanProps,
  ComparePlanProps1,
  ComparePlanProps11,
  ComparePlanProps12,
  ComparePlansNewMock,
  ComparePlansNewMock1,
} from '../../__mock__/CompareToCurrentPlanMock';
import accordionRedux1 from '../TAccordion/__mocks__/accordionRedux1.json';
import accordionRedux2 from '../TAccordion/__mocks__/accordionRedux2.json';

const AccordionMockData = {
  title: 'Plan Details',
  content: 'This plan includes unlimited calls, free cloud storage, and 24/7 customer support.',
};

const AccordionProps = {
  title: AccordionMockData.title,
  isOpen: false,
  onToggle: jest.fn(),
  selectBundle: jest.fn(),
  label: 'mtnExpanded',
};

const AccordionProps1 = {
  title: AccordionMockData.title,
  isOpen: false,
  onToggle: jest.fn(),
  selectBundle: jest.fn(),
};

const AccordionProps2 = {
  title: AccordionMockData.title,
  isOpen: false,
  onToggle: jest.fn(),
  selectBundle: jest.fn(),
  label: 'Popular',
};

const AccordionProps3 = {
  title: AccordionMockData.title,
  isOpen: false,
  onToggle: jest.fn(),
  selectBundle: jest.fn(),
  label: 'Recommended',
};

const mockState = {
  plans: {
    data: accordionRedux1,
  },
};

const mockState1 = {
  plans: {
    data: accordionRedux2,
  },
};

jest.mock('react-redux', () => ({
  ...jest.requireActual('react-redux'),
  useSelector: jest.fn(),
}));

describe(`<ComparePlans/> component mount`, () => {
  ComparePlansNewMock.isDark = false;
  beforeEach(() => {
    useSelector.mockImplementation((selector) => selector(mockState));
    render(<ComparePlans {...ComparePlansNewMock} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('component should mount', () => {
    expect(screen.getByText('Current')).toBeInTheDocument();
  });
  test('should mount', () => {});
});

describe(`<ComparePlans/> component mount`, () => {
  ComparePlansNewMock.isDark = false;
  beforeEach(() => {
    useSelector.mockImplementation((selector) => selector(mockState1));
    render(<ComparePlans {...ComparePlansNewMock} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('component should mount', () => {
    expect(screen.getByText('Current')).toBeInTheDocument();
  });
  test('should mount', () => {});
});

describe(`<ComparePlans/> component mount`, () => {
  ComparePlansNewMock1.isDark = false;
  beforeEach(() => {
    useSelector.mockImplementation((selector) => selector(mockState));
    render(<ComparePlans {...ComparePlansNewMock1} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('component should mount', () => {
    expect(screen.getByText('Current')).toBeInTheDocument();
  });
  test('should mount', () => {});
});

describe(`<ComparePlans/> component mount`, () => {
  ComparePlansNewMock1.isDark = false;
  beforeEach(() => {
    useSelector.mockImplementation((selector) => selector(mockState1));
    render(<ComparePlans {...ComparePlansNewMock1} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('component should mount', () => {
    expect(screen.getByText('Current')).toBeInTheDocument();
  });
  test('should mount', () => {});
});

describe(`<ComparePlans/> component mount for New`, () => {
  ComparePlansNewMock.isDark = true;
  beforeEach(() => {
    useSelector.mockImplementation((selector) => selector(mockState));
    render(<ComparePlans {...ComparePlansNewMock} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('component should mount for New', () => {
    expect(screen.getByText('New')).toBeInTheDocument();
  });
});

describe(`<ComparePlans/> component mount for New`, () => {
  ComparePlansNewMock1.isDark = true;
  beforeEach(() => {
    useSelector.mockImplementation((selector) => selector(mockState1));
    render(<ComparePlans {...ComparePlansNewMock1} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('component should mount for New', () => {
    expect(screen.getByText('New')).toBeInTheDocument();
  });
});

describe(`<ComparePlans/> component mount`, () => {
  beforeEach(() => {
    useSelector.mockImplementation((selector) => selector(mockState));
    render(<ComparePlans {...ComparePlansNewMock} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should test Close CompareToCurrentPlan 2', async () => {
    render(<ComparePlans {...ComparePlansNewMock} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
});

describe(`<ComparePlans/> component mount`, () => {
  beforeEach(() => {
    useSelector.mockImplementation((selector) => selector(mockState1));
    render(<ComparePlans {...ComparePlansNewMock} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should test Close CompareToCurrentPlan 2', async () => {
    render(<ComparePlans {...ComparePlansNewMock} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
});

describe(`<ComparePlans/> component mount`, () => {
  beforeEach(() => {
    useSelector.mockImplementation((selector) => selector(mockState));
    render(<ComparePlans {...ComparePlansNewMock1} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should test Close CompareToCurrentPlan 2', async () => {
    render(<ComparePlans {...ComparePlansNewMock1} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
});

describe(`<ComparePlans/> component mount`, () => {
  beforeEach(() => {
    useSelector.mockImplementation((selector) => selector(mockState1));
    render(<ComparePlans {...ComparePlansNewMock1} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should test Close CompareToCurrentPlan 2', async () => {
    render(<ComparePlans {...ComparePlansNewMock1} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
});

describe(`<ComparePlans/> component mount with dark theme1`, () => {
  const plansSlice = createSlice({
    name: 'plans',
    initialState: accordionRedux1,
    reducers: {
      plansdata: (state, action) => action.payload,
    },
  });
  beforeEach(() => {
    useSelector.mockImplementation((selector) => selector(mockState));
    ComparePlansNewMock.isDark = false;
    ComparePlansNewMock.label = 'Recommended';
    ComparePlansNewMock.mtn = '3023843563';
    ComparePlanFlowMockData.getNewPlanAndPerksCost = [
      {
        mtn: '3023843563',
        perkOptionsPrice: {
          perkSpoList: [{ spoId: '123', totalAmountOff: '40' }],
        },
      },
    ];
    render(<ComparePlans {...ComparePlansNewMock} />, {
      reducers: { plans: plansSlice.reducer },
      sagas: rootSaga,
    });
  });
  test('should test Close CompareToCurrentPlan 2', async () => {
    ComparePlanFlowMockData.isDark = false;
    render(<ComparePlans {...ComparePlansNewMock} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('Should check Customize Perks click event- Edit', async () => {
    const ButtonCheck = screen.getByText('Recommended');
    fireEvent.click(ButtonCheck);
  });
});

describe(`<ComparePlans/> component mount with dark theme1`, () => {
  const plansSlice = createSlice({
    name: 'plans',
    initialState: accordionRedux1,
    reducers: {
      plansdata: (state, action) => action.payload,
    },
  });
  beforeEach(() => {
    useSelector.mockImplementation((selector) => selector(mockState1));
    ComparePlansNewMock.isDark = false;
    ComparePlansNewMock.label = 'Recommended';
    ComparePlansNewMock.mtn = '3023843563';
    ComparePlanFlowMockData.getNewPlanAndPerksCost = [
      {
        mtn: '3023843563',
        perkOptionsPrice: {
          perkSpoList: [{ spoId: '123', totalAmountOff: '40' }],
        },
      },
    ];
    render(<ComparePlans {...ComparePlansNewMock} />, {
      reducers: { plans: plansSlice.reducer },
      sagas: rootSaga,
    });
  });
  test('should test Close CompareToCurrentPlan 2', async () => {
    ComparePlanFlowMockData.isDark = false;
    render(<ComparePlans {...ComparePlansNewMock} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('Should check Customize Perks click event- Edit', async () => {
    const ButtonCheck = screen.getByText('Recommended');
    fireEvent.click(ButtonCheck);
  });
});

describe(`<ComparePlans/> component mount with dark theme1`, () => {
  const plansSlice = createSlice({
    name: 'plans',
    initialState: accordionRedux1,
    reducers: {
      plansdata: (state, action) => action.payload,
    },
  });
  beforeEach(() => {
    useSelector.mockImplementation((selector) => selector(mockState));
    ComparePlansNewMock1.isDark = false;
    ComparePlansNewMock1.label = 'Recommended';
    ComparePlansNewMock1.mtn = '3023843563';
    ComparePlanFlowMockData.getNewPlanAndPerksCost = [
      {
        mtn: '3023843563',
        perkOptionsPrice: {
          perkSpoList: [{ spoId: '123', totalAmountOff: '40' }],
        },
      },
    ];
    render(<ComparePlans {...ComparePlansNewMock1} />, {
      reducers: { plans: plansSlice.reducer },
      sagas: rootSaga,
    });
  });
  test('should test Close CompareToCurrentPlan 2', async () => {
    ComparePlanFlowMockData.isDark = false;
    render(<ComparePlans {...ComparePlansNewMock1} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('Should check Customize Perks click event- Edit', async () => {
    const ButtonCheck = screen.getByText('Recommended');
    fireEvent.click(ButtonCheck);
  });
});

describe(`<ComparePlans/> component mount with dark theme1`, () => {
  const plansSlice = createSlice({
    name: 'plans',
    initialState: accordionRedux1,
    reducers: {
      plansdata: (state, action) => action.payload,
    },
  });
  beforeEach(() => {
    useSelector.mockImplementation((selector) => selector(mockState1));
    ComparePlansNewMock1.isDark = false;
    ComparePlansNewMock1.label = 'Recommended';
    ComparePlansNewMock1.mtn = '3023843563';
    ComparePlanFlowMockData.getNewPlanAndPerksCost = [
      {
        mtn: '3023843563',
        perkOptionsPrice: {
          perkSpoList: [{ spoId: '123', totalAmountOff: '40' }],
        },
      },
    ];
    render(<ComparePlans {...ComparePlansNewMock1} />, {
      reducers: { plans: plansSlice.reducer },
      sagas: rootSaga,
    });
  });
  test('should test Close CompareToCurrentPlan 2', async () => {
    ComparePlanFlowMockData.isDark = false;
    render(<ComparePlans {...ComparePlansNewMock1} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('Should check Customize Perks click event- Edit', async () => {
    const ButtonCheck = screen.getByText('Recommended');
    fireEvent.click(ButtonCheck);
  });
});

describe('<ComparePlans/> component mtnExpanded', () => {
  const plansSlice = createSlice({
    name: 'plans',
    initialState: accordionRedux1,
    reducers: {
      plansdata: (state, action) => action.payload,
    },
  });
  beforeEach(() => {
    useSelector.mockImplementation((selector) => selector(mockState));
    render(<ComparePlans {...ComparePlanProps} {...AccordionProps} />, {
      reducers: plansSlice.reducer,
      sagas: rootSaga,
    });
  });

  test('should mount component', () => {
    expect(screen.getByText('Current')).toBeInTheDocument();
  });

  test('should check Edit button click event', async () => {
    await waitFor(() => {
      const EditButton = screen.getByTestId('buildPlan_Select');
      expect(EditButton).toBeInTheDocument();
      fireEvent.click(EditButton);
    });
  });

  test('should display correct price', async () => {
    await waitFor(() => {
      expect(screen.getAllByText(/\$[0-9]+\/mo/i)[0]).toBeInTheDocument();
    });
  });

  test('should display correct savings amount', async () => {
    await waitFor(() => {
      expect(
        screen.getByText(
          'Google Play Pass is your ticket to hundreds of awesome games and apps, completely free of ads and in-app purchases. Explore a curated collection with favorites like Stardew Valley and the Monument Valley series to award-winning indies like LIMBO and Dead Cells. $4.99/mo plus tax after offer ends. Cancel anytime.',
        ),
      ).toBeInTheDocument();
    });
  });

  test('should close modal when clicking close', async () => {
    await waitFor(() => {
      expect(screen.queryByText(/Compare Plans/i)).not.toBeInTheDocument();
    });
    fireEvent.click(screen.getByText(/Data & Network/i));

    const startIcon = screen.getAllByRole('img', { name: /star icon/i });
    expect(startIcon[0]).toBeInTheDocument();
  });
});

describe('<ComparePlans/> component mtnExpanded', () => {
  const plansSlice = createSlice({
    name: 'plans',
    initialState: accordionRedux1,
    reducers: {
      plansdata: (state, action) => action.payload,
    },
  });
  beforeEach(() => {
    useSelector.mockImplementation((selector) => selector(mockState1));
    render(<ComparePlans {...ComparePlanProps} {...AccordionProps} />, {
      reducers: plansSlice.reducer,
      sagas: rootSaga,
    });
  });

  test('should mount component', () => {
    expect(screen.getByText('Current')).toBeInTheDocument();
  });

  test('should check Edit button click event', async () => {
    await waitFor(() => {
      const EditButton = screen.getByTestId('buildPlan_Select');
      expect(EditButton).toBeInTheDocument();
      fireEvent.click(EditButton);
    });
  });

  test('should display correct price', async () => {
    await waitFor(() => {
      expect(screen.getAllByText(/\$[0-9]+\/mo/i)[0]).toBeInTheDocument();
    });
  });

  test('should display correct savings amount', async () => {
    await waitFor(() => {
      expect(
        screen.getByText(
          'Google Play Pass is your ticket to hundreds of awesome games and apps, completely free of ads and in-app purchases. Explore a curated collection with favorites like Stardew Valley and the Monument Valley series to award-winning indies like LIMBO and Dead Cells. $4.99/mo plus tax after offer ends. Cancel anytime.',
        ),
      ).toBeInTheDocument();
    });
  });

  test('should close modal when clicking close', async () => {
    await waitFor(() => {
      expect(screen.queryByText(/Compare Plans/i)).not.toBeInTheDocument();
    });
    fireEvent.click(screen.getByText(/Data & Network/i));

    const startIcon = screen.getAllByRole('img', { name: /star icon/i });
    expect(startIcon[0]).toBeInTheDocument();
  });
});

describe('<ComparePlans/> component Popular', () => {
  const plansSlice = createSlice({
    name: 'plans',
    initialState: accordionRedux1,
    reducers: {
      plansdata: (state, action) => action.payload,
    },
  });
  beforeEach(() => {
    useSelector.mockImplementation((selector) => selector(mockState));
    render(<ComparePlans {...ComparePlanProps11} {...AccordionProps2} />, {
      reducers: plansSlice.reducer,
      sagas: rootSaga,
    });
  });

  test('should mount component', () => {
    expect(screen.getByText('Current')).toBeInTheDocument();
  });

  test('should check Edit button click event', async () => {
    await waitFor(() => {
      const BuildButton = screen.getByTestId('popularPlan_Select');
      expect(BuildButton).toBeInTheDocument();
      fireEvent.click(BuildButton);
    });
  });

  test('should display correct price', async () => {
    await waitFor(() => {
      expect(screen.getAllByText(/\$[0-9]+\/mo/i)[0]).toBeInTheDocument();
    });
  });

  test('should display correct savings amount', async () => {
    await waitFor(() => {
      expect(
        screen.getByText(
          'Google Play Pass is your ticket to hundreds of awesome games and apps, completely free of ads and in-app purchases. Explore a curated collection with favorites like Stardew Valley and the Monument Valley series to award-winning indies like LIMBO and Dead Cells. $4.99/mo plus tax after offer ends. Cancel anytime.',
        ),
      ).toBeInTheDocument();
    });
  });

  test('should close modal when clicking close', async () => {
    await waitFor(() => {
      expect(screen.queryByText(/Compare Plans/i)).not.toBeInTheDocument();
    });
    fireEvent.click(screen.getByText(/Data & Network/i));

    const startIcon = screen.getAllByRole('img', { name: /star icon/i });
    expect(startIcon[0]).toBeInTheDocument();
  });
});

describe('<ComparePlans/> component Popular', () => {
  const plansSlice = createSlice({
    name: 'plans',
    initialState: accordionRedux1,
    reducers: {
      plansdata: (state, action) => action.payload,
    },
  });
  beforeEach(() => {
    useSelector.mockImplementation((selector) => selector(mockState1));
    render(<ComparePlans {...ComparePlanProps11} {...AccordionProps2} />, {
      reducers: plansSlice.reducer,
      sagas: rootSaga,
    });
  });

  test('should mount component', () => {
    expect(screen.getByText('Current')).toBeInTheDocument();
  });

  test('should check Edit button click event', async () => {
    await waitFor(() => {
      const BuildButton = screen.getByTestId('popularPlan_Select');
      expect(BuildButton).toBeInTheDocument();
      fireEvent.click(BuildButton);
    });
  });

  test('should display correct price', async () => {
    await waitFor(() => {
      expect(screen.getAllByText(/\$[0-9]+\/mo/i)[0]).toBeInTheDocument();
    });
  });

  test('should display correct savings amount', async () => {
    await waitFor(() => {
      expect(
        screen.getByText(
          'Google Play Pass is your ticket to hundreds of awesome games and apps, completely free of ads and in-app purchases. Explore a curated collection with favorites like Stardew Valley and the Monument Valley series to award-winning indies like LIMBO and Dead Cells. $4.99/mo plus tax after offer ends. Cancel anytime.',
        ),
      ).toBeInTheDocument();
    });
  });

  test('should close modal when clicking close', async () => {
    await waitFor(() => {
      expect(screen.queryByText(/Compare Plans/i)).not.toBeInTheDocument();
    });
    fireEvent.click(screen.getByText(/Data & Network/i));

    const startIcon = screen.getAllByRole('img', { name: /star icon/i });
    expect(startIcon[0]).toBeInTheDocument();
  });
});

describe('<ComparePlans/> component Recomended', () => {
  const plansSlice = createSlice({
    name: 'plans',
    initialState: accordionRedux1,
    reducers: {
      plansdata: (state, action) => action.payload,
    },
  });
  beforeEach(() => {
    useSelector.mockImplementation((selector) => selector(mockState));
    render(<ComparePlans {...ComparePlanProps12} {...AccordionProps3} />, {
      reducers: plansSlice.reducer,
      sagas: rootSaga,
    });
  });

  test('should mount component', () => {
    expect(screen.getByText('Current')).toBeInTheDocument();
  });

  test('should check Recomended button click event', async () => {
    await waitFor(() => {
      const BuildButton = screen.getByTestId('recommendedPlan_Select');
      expect(BuildButton).toBeInTheDocument();
      fireEvent.click(BuildButton);
    });
  });

  test('should check Recommendationtab button click event', async () => {
    await waitFor(() => {
      const RecommendationtabButton = screen.getByTestId('recommendationtab_Customize');
      expect(RecommendationtabButton).toBeInTheDocument();
      fireEvent.click(RecommendationtabButton);
    });
  });

  test('should display correct price', async () => {
    await waitFor(() => {
      expect(screen.getAllByText(/\$[0-9]+\/mo/i)[0]).toBeInTheDocument();
    });
  });

  test('should display correct savings amount', async () => {
    await waitFor(() => {
      expect(
        screen.getByText(
          'Google Play Pass is your ticket to hundreds of awesome games and apps, completely free of ads and in-app purchases. Explore a curated collection with favorites like Stardew Valley and the Monument Valley series to award-winning indies like LIMBO and Dead Cells. $4.99/mo plus tax after offer ends. Cancel anytime.',
        ),
      ).toBeInTheDocument();
    });
  });

  test('should close modal when clicking close', async () => {
    await waitFor(() => {
      expect(screen.queryByText(/Compare Plans/i)).not.toBeInTheDocument();
    });
    fireEvent.click(screen.getByText(/Data & Network/i));

    const startIcon = screen.getAllByRole('img', { name: /star icon/i });
    expect(startIcon[0]).toBeInTheDocument();
  });
});

describe('<ComparePlans/> component Recomended', () => {
  const plansSlice = createSlice({
    name: 'plans',
    initialState: accordionRedux1,
    reducers: {
      plansdata: (state, action) => action.payload,
    },
  });
  beforeEach(() => {
    useSelector.mockImplementation((selector) => selector(mockState1));
    render(<ComparePlans {...ComparePlanProps12} {...AccordionProps3} />, {
      reducers: plansSlice.reducer,
      sagas: rootSaga,
    });
  });

  test('should mount component', () => {
    expect(screen.getByText('Current')).toBeInTheDocument();
  });

  test('should check Recomended button click event', async () => {
    await waitFor(() => {
      const BuildButton = screen.getByTestId('recommendedPlan_Select');
      expect(BuildButton).toBeInTheDocument();
      fireEvent.click(BuildButton);
    });
  });

  test('should check Recommendationtab button click event', async () => {
    await waitFor(() => {
      const RecommendationtabButton = screen.getByTestId('recommendationtab_Customize');
      expect(RecommendationtabButton).toBeInTheDocument();
      fireEvent.click(RecommendationtabButton);
    });
  });

  test('should display correct price', async () => {
    await waitFor(() => {
      expect(screen.getAllByText(/\$[0-9]+\/mo/i)[0]).toBeInTheDocument();
    });
  });

  test('should display correct savings amount', async () => {
    await waitFor(() => {
      expect(
        screen.getByText(
          'Google Play Pass is your ticket to hundreds of awesome games and apps, completely free of ads and in-app purchases. Explore a curated collection with favorites like Stardew Valley and the Monument Valley series to award-winning indies like LIMBO and Dead Cells. $4.99/mo plus tax after offer ends. Cancel anytime.',
        ),
      ).toBeInTheDocument();
    });
  });

  test('should close modal when clicking close', async () => {
    await waitFor(() => {
      expect(screen.queryByText(/Compare Plans/i)).not.toBeInTheDocument();
    });
    fireEvent.click(screen.getByText(/Data & Network/i));

    const startIcon = screen.getAllByRole('img', { name: /star icon/i });
    expect(startIcon[0]).toBeInTheDocument();
  });
});

describe('<ComparePlans/> component', () => {
  const plansSlice = createSlice({
    name: 'plans',
    initialState: accordionRedux1,
    reducers: {
      plansdata: (state, action) => action.payload,
    },
  });
  beforeEach(() => {
    useSelector.mockImplementation((selector) => selector(mockState));
    render(<ComparePlans {...ComparePlanProps1} {...AccordionProps1} />, {
      reducers: plansSlice.reducer,
      sagas: rootSaga,
    });
  });

  test('should mount component', () => {
    expect(screen.getByText('Current')).toBeInTheDocument();
  });

  test('should render plan title', () => {
    expect(screen.getByText(/Recommended/i)).toBeInTheDocument();
  });

  test('should check Select button click event', async () => {
    await waitFor(() => {
      const selectButton = screen.getByTestId('recommendedPlan_Select');
      expect(selectButton).toBeInTheDocument();
      fireEvent.click(selectButton);
    });
  });

  test('should display correct price', async () => {
    await waitFor(() => {
      expect(screen.getAllByText(/\$[0-9]+\/mo/i)[0]).toBeInTheDocument();
    });
  });

  test('should display correct savings amount', async () => {
    await waitFor(() => {
      expect(
        screen.getByText(
          'Google Play Pass is your ticket to hundreds of awesome games and apps, completely free of ads and in-app purchases. Explore a curated collection with favorites like Stardew Valley and the Monument Valley series to award-winning indies like LIMBO and Dead Cells. $4.99/mo plus tax after offer ends. Cancel anytime.',
        ),
      ).toBeInTheDocument();
    });
  });

  test('should close modal when clicking close', async () => {
    await waitFor(() => {
      expect(screen.queryByText(/Compare Plans/i)).not.toBeInTheDocument();
    });
    fireEvent.click(screen.getByText(/Data & Network/i));

    const startIcon = screen.getAllByRole('img', { name: /star icon/i });
    expect(startIcon[0]).toBeInTheDocument();
  });

  test('should check Recommendationtab button click event', async () => {
    await waitFor(() => {
      const RecommendationtabButton = screen.getByTestId('recommendationtab_Customize');
      expect(RecommendationtabButton).toBeInTheDocument();
      fireEvent.click(RecommendationtabButton);
    });
  });
});

describe('<ComparePlans/> component', () => {
  const plansSlice = createSlice({
    name: 'plans',
    initialState: accordionRedux1,
    reducers: {
      plansdata: (state, action) => action.payload,
    },
  });
  beforeEach(() => {
    useSelector.mockImplementation((selector) => selector(mockState1));
    render(<ComparePlans {...ComparePlanProps1} {...AccordionProps1} />, {
      reducers: plansSlice.reducer,
      sagas: rootSaga,
    });
  });

  test('should mount component', () => {
    expect(screen.getByText('Current')).toBeInTheDocument();
  });

  test('should render plan title', () => {
    expect(screen.getByText(/Recommended/i)).toBeInTheDocument();
  });

  test('should check Select button click event', async () => {
    await waitFor(() => {
      const selectButton = screen.getByTestId('recommendedPlan_Select');
      expect(selectButton).toBeInTheDocument();
      fireEvent.click(selectButton);
    });
  });

  test('should display correct price', async () => {
    await waitFor(() => {
      expect(screen.getAllByText(/\$[0-9]+\/mo/i)[0]).toBeInTheDocument();
    });
  });

  test('should display correct savings amount', async () => {
    await waitFor(() => {
      expect(
        screen.getByText(
          'Google Play Pass is your ticket to hundreds of awesome games and apps, completely free of ads and in-app purchases. Explore a curated collection with favorites like Stardew Valley and the Monument Valley series to award-winning indies like LIMBO and Dead Cells. $4.99/mo plus tax after offer ends. Cancel anytime.',
        ),
      ).toBeInTheDocument();
    });
  });

  test('should close modal when clicking close', async () => {
    await waitFor(() => {
      expect(screen.queryByText(/Compare Plans/i)).not.toBeInTheDocument();
    });
    fireEvent.click(screen.getByText(/Data & Network/i));

    const startIcon = screen.getAllByRole('img', { name: /star icon/i });
    expect(startIcon[0]).toBeInTheDocument();
  });

  test('should check Recommendationtab button click event', async () => {
    await waitFor(() => {
      const RecommendationtabButton = screen.getByTestId('recommendationtab_Customize');
      expect(RecommendationtabButton).toBeInTheDocument();
      fireEvent.click(RecommendationtabButton);
    });
  });
});
