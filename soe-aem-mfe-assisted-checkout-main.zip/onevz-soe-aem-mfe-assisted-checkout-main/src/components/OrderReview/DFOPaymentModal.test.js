import { fireEvent, render, screen } from '@testing-library/react';
import DFOPaymentModal from './DFOPaymentModal';
import retriveCartJson from '../../__mock__/retrive-cart.json';

describe('DFOPaymentModal with DFO', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  const renderDFOPaymentModal = (props = {}) => {
    const dfoCart = retriveCartJson.data.cart;
    const setShowDFOPaymentDetails = () => jest.fn();
    render(<DFOPaymentModal opened dfoCart={dfoCart} setShowDFOPaymentDetails={setShowDFOPaymentDetails} {...props} />);
  };

  test('test DFO Title with DFO true', () => {
    renderDFOPaymentModal();
    const title = screen.getByText('Verizon Visa® Card Financing');
    expect(title).toBeInTheDocument();
  });
  test('test DFO Title undefined Tax amount', () => {
    const dfoCart = { ...retriveCartJson.data.cart };
    dfoCart.lineDetails.lineInfo[0].itemsInfo[0].cartItems.cartItem[0].taxAmount = undefined;
    renderDFOPaymentModal({ dfoCart });
    const title = screen.getByText('Verizon Visa® Card Financing');
    expect(title).toBeInTheDocument();
  });
  test('it should click cross mark', () => {
    renderDFOPaymentModal();
    const closeBtn = screen.getByRole('button', { id: 'close-button' });
    fireEvent.click(closeBtn);
  });
  test('test DFO Title with DFO false', () => {
    const dfoCart = { ...retriveCartJson.data.cart };
    dfoCart.lineDetails.lineInfo[0].itemsInfo[0].cartItems.cartItem[0].cartItemType = 'ACC';
    renderDFOPaymentModal({ dfoCart });
    const title = screen.getByText('Verizon Visa® Card Financing');
    expect(title).toBeInTheDocument();
  });
  test('test DFO Title with DFO false', () => {
    const dfoCart = { ...retriveCartJson.data.cart };
    dfoCart.lineDetails.lineInfo[0].itemsInfo[0].cartItems.cartItem[0].taxAmount = 0;
    renderDFOPaymentModal({ dfoCart });
    const title = screen.getByText('Verizon Visa® Card Financing');
    expect(title).toBeInTheDocument();
  });
  test('test DFO Title with DFO false MTHN Not match', () => {
    const dfoCart = { ...retriveCartJson.data.cart };
    dfoCart.orderDetails.accessoryFinancingOfferInfo.splitPaymentInfo = [];
    renderDFOPaymentModal({ dfoCart });
    const title = screen.getByText('Verizon Visa® Card Financing');
    expect(title).toBeInTheDocument();
  });
  test('test DFO Title with DFO false MTHN Not match empty', () => {
    const dfoCart = { ...retriveCartJson.data.cart };
    dfoCart.orderDetails.accessoryFinancingOfferInfo.splitPaymentInfo = [
      {
        orderNumber: '12003748',
        nonAccessoryTotal: 0,
        accessoryTotal: 272.18,
        vdPaymentAmount: 0,
        isDfo: true,
        mtn: '234566',
      },
    ];
    renderDFOPaymentModal({ dfoCart });
    const title = screen.getByText('Verizon Visa® Card Financing');
    expect(title).toBeInTheDocument();
  });
});
