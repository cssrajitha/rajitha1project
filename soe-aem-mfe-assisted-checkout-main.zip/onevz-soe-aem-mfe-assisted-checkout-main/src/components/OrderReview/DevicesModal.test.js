import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import { ThemeProvider } from 'styled-components';
import StoreProvider from '../../modules/store';
import cartJson from '../../__mock__/cart.json';
import cartDPFlow from '../../__mock__/cartDPFlow.json';
import cartBYODFlow from '../../__mock__/cartBYODFlow.json';
import cart5GFlow from '../../__mock__/cart5GFlow.json';
import DevicesModal from './DevicesModal';
import { scmCheckoutMfeEnabled } from '../../utils/common';
import * as orderreviewApiCallHook from '../../pages/home/container/orderreviewApiCallHook';
import * as InfoApiCallHook from '../../modules/services/APIService/InfoAPICallHook';

const compteDPJson = {
  isSuccess: true,
  data: {
    firstMonthPrice: 28.64,
    remainingMonthPrice: 28.61,
    dpTerm: 36,
    downPayment: 200,
  },
};
jest.mock('../../utils/common');

jest.mock('onevzsoemfeframework/AssistedCradleService', () => ({
  __esModule: true,
  ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
  getAssistedCradlePropertyV2: jest.fn(), // Ensure it's a Jest mock function
}));

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
  useLazyComputeDPPricesQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: compteDPJson,
    },
  ],
}));
describe('Devices Component', () => {
  const handlers = [
    rest.post(`*/devicepricingservice/computeDPPrices`, (req, res, ctx) =>
      res(ctx.status(200), ctx.json(compteDPJson))
    ),
  ];
  const server = setupServer(...handlers);
  scmCheckoutMfeEnabled.mockImplementation(() => false);
  const CustomerProfileRefetch = jest.fn();
  const CartDetailsRefetch = jest.fn();
  const fetchPriceSnapshotRefetch = jest.fn();
  const renderDeviceModel = (props = {}) => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const sbdOffer = line?.serviceInfo?.sbdOffer || [];
    const setMonthlyInstallmentAmount = jest.fn();
    // window.mfe = { scmCheckoutMfeEnable: true };

    render(
      <BrowserRouter>
        <StoreProvider>
          <DevicesModal
            line={line}
            element={element}
            opened
            sbdOffer={sbdOffer}
            setMonthlyInstallmentAmount={setMonthlyInstallmentAmount}
            closeModal={() => {}}
            CustomerProfileRefetch={CustomerProfileRefetch}
            CartDetailsRefetch={CartDetailsRefetch}
            fetchPriceSnapshotRefetch={fetchPriceSnapshotRefetch}
            {...props}
          />
        </StoreProvider>
      </BrowserRouter>
    );
  };

  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;

    server.listen();
  });
  afterAll(() => {
    server.close();
  });

  test('renders Devices', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

    scmCheckoutMfeEnabled.mockImplementation(() => true);
    renderDeviceModel();
    const titleElement = screen.getByTestId('devicesModal');
    expect(titleElement).toBeInTheDocument();
  });

  test('renders Devices with scmUpgradeMfeEnable = true', () => {
     window.mfe = { scmUpgradeMfeEnable : true };
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

    scmCheckoutMfeEnabled.mockImplementation(() => true);
    renderDeviceModel();
    const titleElement = screen.getByTestId('devicesModal');
    expect(titleElement).toBeInTheDocument();
    window.mfe = { scmUpgradeMfeEnable : false};
  });

  test('Edit and Cancel DP', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

    renderDeviceModel();
    const EditLink = screen.getByTestId('dp-edit');
    expect(EditLink).toBeInTheDocument();
    fireEvent.mouseDown(EditLink, {});

    const CancelLink = screen.getByTestId('dp-cancel');
    expect(CancelLink).toBeInTheDocument();
    fireEvent.mouseDown(CancelLink, {});
  });

  test('Edit and blur DP', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

    renderDeviceModel();
    const EditLink = screen.getByTestId('dp-edit');
    expect(EditLink).toBeInTheDocument();
    fireEvent.mouseDown(EditLink, {});

    const Input = screen.getByTestId('dp-input');
    expect(Input).toBeInTheDocument();
    fireEvent.change(Input, { target: { value: 100 } });
    fireEvent.blur(Input);
  });

  test('Modal done click', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

    renderDeviceModel();
    const DoneBtn = screen.getByText(/Done/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
  });

  test('Modal Change Devices click', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

    renderDeviceModel();
    global.window.vzdl = { page: { detail: '' } };
    const DoneBtn = screen.getByText(/Change Device/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
    expect(window.vzdl.page.detail).toEqual('Edit Device');
  });

  test('Modal Change Devices click read order', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']);
    renderDeviceModel({ readOrder: true, orderStatus: 'CR', cartHeader: { status: 'D' } });
    global.window.vzdl = { page: { detail: '' } };
    const DoneBtn = screen.getByTestId('change-device');
    fireEvent.click(DoneBtn, {});
    expect(DoneBtn).toBeInTheDocument();
  });

  test('Modal Change Devices click with mfe true', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

    renderDeviceModel();
    global.window.vzdl = { page: { detail: '' } };
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ isPDPMFEEnabled: 'TRUE' }));
    const DoneBtn = screen.getByText(/Change Device/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
    expect(window.vzdl.page.detail).toEqual('Edit Device');
  });

  test('BYOD flow', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

    const line = cartBYODFlow.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const { cart } = cartBYODFlow.data;
    renderDeviceModel({ line, element, cart });
    const DoneBtn = screen.getByText(/Change Device/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
    expect(window.vzdl.page.detail).toEqual('Edit Device');
  });

  test('5G Flow', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

    const line = cart5GFlow.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const { cart } = cart5GFlow.data;
    renderDeviceModel({ line, element, cart });
    const DoneBtn = screen.getByText(/Change Device/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
    expect(window.vzdl.page.detail).toEqual('Edit Device');
  });

  test('Show tax basis F', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    let element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    element = { ...element, taxBasis: 'F' };
    renderDeviceModel({ element });
    expect(screen.getByTestId('tax-f')).toBeInTheDocument();
  });

  test('Show tax basis P', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    let element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    element = { ...element, taxBasis: 'P' };
    renderDeviceModel({ element });
    expect(screen.getByTestId('tax-p')).toBeInTheDocument();
  });

  test('Show Device ID and SIM ID', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

    const line = cartDPFlow.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    renderDeviceModel({ line, element });
    const deviceIDText = screen.getByText('Device ID');
    expect(deviceIDText).toBeInTheDocument();
    const deviceIDValue = screen.getByText('350390271611486');
    expect(deviceIDValue).toBeInTheDocument();

    const simIDText = screen.getByText('SIM ID');
    expect(simIDText).toBeInTheDocument();
    const simIDValue = screen.getByText('89148000009738442336');
    expect(simIDValue).toBeInTheDocument();
  });

  test('Edit and blur DP to lower price', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

    const line = cartDPFlow.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    renderDeviceModel({ line, element });

    const EditLink = screen.getByTestId('dp-edit');
    expect(EditLink).toBeInTheDocument();
    fireEvent.mouseDown(EditLink, {});

    const Input = screen.getByTestId('dp-input');
    expect(Input).toBeInTheDocument();
    fireEvent.change(Input, { target: { value: 100 } });
    fireEvent.blur(Input);

    expect(EditLink).toBeInTheDocument();
  });

  test('Edit and blur DP to higher price - 01', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

    const line = cartDPFlow.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    renderDeviceModel({ line, element });

    const EditLink = screen.getByTestId('dp-edit');
    expect(EditLink).toBeInTheDocument();
    fireEvent.mouseDown(EditLink, {});

    const Input = screen.getByTestId('dp-input');
    expect(Input).toBeInTheDocument();
    fireEvent.change(Input, { target: { value: 900 } });
    fireEvent.blur(Input);

    const maxDpLimitError = screen.getByText('Maximum downpayment allowed is : 829.63');
    expect(maxDpLimitError).toBeInTheDocument();
  });

  test('Edit and blur DP to higher price - 02', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

    const renderDeviceModel1 = (props = {}) => {
      const line = cartJson.data.cart.lineDetails.lineInfo[0];
      const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
      const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
      const sbdOffer = line?.serviceInfo?.sbdOffer || [];
      const setMonthlyInstallmentAmount = jest.fn();
      scmCheckoutMfeEnabled.mockImplementation(() => true);
      render(
        <BrowserRouter>
          <StoreProvider>
            <DevicesModal
              line={line}
              element={element}
              opened
              sbdOffer={sbdOffer}
              setMonthlyInstallmentAmount={setMonthlyInstallmentAmount}
              closeModal={() => {}}
              {...props}
            />
          </StoreProvider>
        </BrowserRouter>
      );
    };
    renderDeviceModel1();
  });

  test('Edit and blur DP to higher price - 02', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

    const line = cartDPFlow.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const { cart } = cartDPFlow.data;
    cart.orderDetails.orderChannelId = 'OMNI-INDIRECT';
    renderDeviceModel({ line, element, cart });

    const EditLink = screen.getByTestId('dp-edit');
    expect(EditLink).toBeInTheDocument();
    fireEvent.mouseDown(EditLink, {});

    const Input = screen.getByTestId('dp-input');
    expect(Input).toBeInTheDocument();
    fireEvent.change(Input, { target: { value: 900 } });
    fireEvent.blur(Input);

    const maxDpLimitError = screen.getByText('Maximum downpayment allowed is : 829.63');
    expect(maxDpLimitError).toBeInTheDocument();
  });

  test('Edit and blur DP to higher price - 03', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

    const line = cartDPFlow.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    let element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    element = { ...element, sellerPrice: 829.99 };
    const { cart } = cartDPFlow.data;
    cart.orderDetails.orderChannelId = 'OMNI-INDIRECT';
    renderDeviceModel({ line, element, cart });

    const EditLink = screen.getByTestId('dp-edit');
    expect(EditLink).toBeInTheDocument();
    fireEvent.mouseDown(EditLink, {});

    const Input = screen.getByTestId('dp-input');
    expect(Input).toBeInTheDocument();
    fireEvent.change(Input, { target: { value: 900 } });
    fireEvent.blur(Input);

    const maxDpLimitError = screen.getByText('Maximum downpayment allowed is : 829.63');
    expect(maxDpLimitError).toBeInTheDocument();
  });

  test('Edit Downpayment and save downpayment', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      updateDownpaymentBody: jest.fn(),
    }));

    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => ({
      getActiveMTNRequest: jest.fn(),
      orderReviewRequest: jest.fn(),
    }));

    const line = cartDPFlow.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const { cart } = cartDPFlow.data;
    cart.orderDetails.orderChannelId = 'OMNI-INDIRECT';
    renderDeviceModel({ line, element, cart });

    const EditLink = screen.getByTestId('dp-edit');
    expect(EditLink).toBeInTheDocument();
    fireEvent.mouseDown(EditLink, {});

    const Input = screen.getByTestId('dp-input');
    expect(Input).toBeInTheDocument();
    fireEvent.change(Input, { target: { value: 90 } });
    fireEvent.blur(Input);

    const DoneBtn = screen.getByText(/Done/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});

    waitFor(() => {
      expect(CustomerProfileRefetch).toHaveBeenCalled();
      expect(CartDetailsRefetch).toHaveBeenCalled();
      expect(fetchPriceSnapshotRefetch).toHaveBeenCalled();
    });
  });

  test('Edit Downpayment and save downpayment with customerType = N', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      updateDownpaymentBody: jest.fn(),
    }));

    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => ({
      getActiveMTNRequest: jest.fn(),
      orderReviewRequest: jest.fn(),
    }));

    const line = cartDPFlow.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const { cart } = cartDPFlow.data;
    cart.orderDetails.orderChannelId = 'OMNI-INDIRECT';
    cart.orderDetails.customerType = 'N';
    renderDeviceModel({ line, element, cart });

    const EditLink = screen.getByTestId('dp-edit');
    expect(EditLink).toBeInTheDocument();
    fireEvent.mouseDown(EditLink, {});

    const Input = screen.getByTestId('dp-input');
    expect(Input).toBeInTheDocument();
    fireEvent.change(Input, { target: { value: 90 } });
    fireEvent.blur(Input);

    const DoneBtn = screen.getByText(/Done/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});

    waitFor(() => {
      expect(CustomerProfileRefetch).toHaveBeenCalled();
      expect(CartDetailsRefetch).toHaveBeenCalled();
      expect(fetchPriceSnapshotRefetch).toHaveBeenCalled();
    });
  });

  test('isDark true', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);

    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    const renderDeviceModel1 = (props = {}) => {
      const line = cartJson.data.cart.lineDetails.lineInfo[0];
      const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
      const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
      const sbdOffer = line?.serviceInfo?.sbdOffer || [];
      const setMonthlyInstallmentAmount = jest.fn();
      scmCheckoutMfeEnabled.mockImplementation(() => true);
      jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
        updateDownpaymentBody: jest.fn(),
      }));
      jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => ({
        getActiveMTNRequest: jest.fn(),
      }));

      render(
        <BrowserRouter>
          <StoreProvider>
            <ThemeProvider theme={{ isDark: true }}>
              <DevicesModal
                line={line}
                element={element}
                opened
                sbdOffer={sbdOffer}
                setMonthlyInstallmentAmount={setMonthlyInstallmentAmount}
                closeModal={() => {}}
                isDark
                {...props}
              />
            </ThemeProvider>
          </StoreProvider>
        </BrowserRouter>
      );
    };
    renderDeviceModel1();
  });
});
