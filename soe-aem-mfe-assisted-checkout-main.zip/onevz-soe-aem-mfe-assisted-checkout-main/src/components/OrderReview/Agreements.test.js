import React from 'react';
import { act, fireEvent, render, screen } from '@testing-library/react';
import * as pdfjsLib from 'pdfjs-dist/es5/build/pdf';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../modules/store';
import Agreements from './Agreements';
import { setUserAgentIPad } from '../../utils/test-utils/utils';
import getRetrieveInstallmentAgreementJson from '../../__mock__/getRetrieveInstallmentAgreement.json';

jest.mock('../../utils/tagging');

window.HTMLCanvasElement.prototype.getContext = () => ({
  fillRect() {},
  clearRect() {},
  getImageData(x, y, w, h) {
    return {
      data: new Array(w * h * 4),
    };
  },
  putImageData() {},
  createImageData() {
    return [];
  },
  setTransform() {},
  drawImage() {},
  save() {},
  fillText() {},
  restore() {},
  beginPath() {},
  moveTo() {},
  lineTo() {},
  closePath() {},
  stroke() {},
  translate() {},
  scale() {},
  rotate() {},
  arc() {},
  fill() {},
  measureText() {
    return { width: 0 };
  },
  transform() {},
  rect() {},
  clip() {},
});

window.HTMLCanvasElement.prototype.toDataURL = () => '';
jest.mock('../../utils/viewPlan');
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useState: jest.fn(),
}));
const mockFn = jest.fn();

const props = {
  showAgreementModal: true,
  setShowAgreementModal: mockFn,
  navigate: jest.fn(),
  agreementModalData: {
    type: getRetrieveInstallmentAgreementJson.type,
    title: '',
    body: getRetrieveInstallmentAgreementJson.response[0].installmentContractData,
    isFirstPdf: false,
  },
  handleAgreementData: mockFn,
  installmentAgreementResult: getRetrieveInstallmentAgreementJson,
};

beforeAll(() => {
  class ResizeObserver {
    constructor() {
      this.observe = () => jest.fn();
      this.unobserve = () => jest.fn();
      this.disconnect = () => jest.fn();
    }
  }
  window.ResizeObserver = ResizeObserver;
});

describe('Agreements Component', () => {
  test('renders Agreements', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <Agreements {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByText(/Agreement Details/i);
    expect(titleElement).toBeInTheDocument();
  });

  test('should enable ok button on scroll to buttom', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Agreements
            {...props}
            agreementModalData={{
              type: getRetrieveInstallmentAgreementJson.type,
              title: 'title',
              body: getRetrieveInstallmentAgreementJson.response[0].installmentContractData,
              isFirstPdf: false,
            }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const scrollContainer = screen.getByTestId('pdf-content');
    fireEvent.scroll(scrollContainer, { target: { scrollLeft: 500 } });
    const okButton = screen.getByText(/Ok/i);
    fireEvent.click(okButton);
  });

  test('should enable ok button on scroll to buttom 2', () => {
    window.mfe = { scmCheckoutMfeEnable: false };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Agreements
            {...props}
            agreementModalData={{
              type: getRetrieveInstallmentAgreementJson.type,
              title: 'title',
              body: getRetrieveInstallmentAgreementJson.response[0].installmentContractData,
              isFirstPdf: false,
            }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const scrollContainer = screen.getByTestId('pdf-content');
    fireEvent.scroll(scrollContainer, { target: { scrollLeft: 500 } });
    const okButton = screen.getByText(/Ok/i);
    fireEvent.click(okButton);
  });

  test('should enable ok button on scroll to buttom 2', () => {
    window.mfe = { scmCheckoutMfeEnable: null };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Agreements
            {...props}
            agreementModalData={{
              type: getRetrieveInstallmentAgreementJson.type,
              title: 'title',
              body: getRetrieveInstallmentAgreementJson.response[0].installmentContractData,
              isFirstPdf: false,
            }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const scrollContainer = screen.getByTestId('pdf-content');
    fireEvent.scroll(scrollContainer, { target: { scrollLeft: 500 } });
    const okButton = screen.getByText(/Ok/i);
    fireEvent.click(okButton);
  });

  test('renders no data', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <Agreements {...props} agreementModalData={undefined} channel='OMNI-RETAIL' />
        </StoreProvider>
      </BrowserRouter>,
    );
    const scrollContainer = screen.queryByTestId('pdf-content');
    expect(scrollContainer).toBeNull();
  });

  test('renders second pdf on click of first pdf Agree and continue ', async () => {
    const installmentAgreementResult = {
      ...getRetrieveInstallmentAgreementJson,
      response: [...getRetrieveInstallmentAgreementJson.response, ...getRetrieveInstallmentAgreementJson.response],
    };
    const props2 = {
      showAgreementModal: true,
      setShowAgreementModal: mockFn,
      agreementModalData: {
        type: getRetrieveInstallmentAgreementJson.type,
        title: '',
        body: getRetrieveInstallmentAgreementJson.response[0].installmentContractData,
        isFirstPdf: true,
      },
      handleAgreementData: mockFn,
      installmentAgreementResult,
    };

    jest.useFakeTimers();

    render(
      <BrowserRouter>
        <StoreProvider>
          <Agreements {...props2} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const scrollContainer = screen.getByTestId('pdf-content');
    fireEvent.scroll(scrollContainer, { target: { scrollLeft: 500 } });
    const okButton = screen.getByText(/Ok/i);
    await fireEvent.click(okButton);

    act(() => {
      jest.runAllTimers();
    });

    const titleElement = screen.getByText(/Agreement Details/i);
    expect(titleElement).toBeInTheDocument();

    jest.useRealTimers();
  });

  test('renders html content', () => {
    const props1 = {
      showAgreementModal: true,
      setShowAgreementModal: mockFn,
      agreementModalData: {
        type: 'html',
        title: '',
        body: '<ul> <li>Device payment device id correction</li><li>Device payment override (VZ Error)</li></ul><div>Below are excluded,</div><ul> <li>Customer with ONE-BILL</li><li>Early device upgrade date changes</li><li>New customer activations</li><li>Promotions Support</li><li>Business > 1 year complete override form</li></ul>',
        isFirstPdf: false,
      },
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Agreements {...props1} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const scrollContainer = screen.queryByTestId('html-content');
    expect(scrollContainer).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('modal-close-button'), {});
  });
});

describe('Agreements Component IPAD mode', () => {
  setUserAgentIPad(pdfjsLib);

  test('renders Agreements', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <Agreements {...props} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const pdfView = screen.getAllByTestId('pdf-view')[0];
    expect(pdfView).toBeInTheDocument();
  });
});

describe('Agreements Component [isRxOrderReview] flow', () => {
  sessionStorage.setItem('APP_PROPERTIES', '{"refundReadOrderMfeFFlag":"TRUE"}');
  test('should enable ok button on scroll to buttom', () => {
    window.mfe = {scmmultitask:true  ,scmCheckoutMfeEnable: true, historyRef: [] };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Agreements
            {...props}
            agreementModalData={{
              type: getRetrieveInstallmentAgreementJson.type,
              title: 'title',
              body: getRetrieveInstallmentAgreementJson.response[0].installmentContractData,
              isFirstPdf: false,
            }}
            isRxOrderReview
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const scrollContainer = screen.getByTestId('pdf-content');
    fireEvent.scroll(scrollContainer, { target: { scrollLeft: 500 } });
    const okButton = screen.getByText(/Ok/i);
    fireEvent.click(okButton);
  });
  test('should enable ok button on scroll to buttom', () => {
    window.mfe = {scmmultitask:false  ,scmCheckoutMfeEnable: true, historyRef: [] };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Agreements
            {...props}
            agreementModalData={{
              type: getRetrieveInstallmentAgreementJson.type,
              title: 'title',
              body: getRetrieveInstallmentAgreementJson.response[0].installmentContractData,
              isFirstPdf: false,
            }}
            isRxOrderReview
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const scrollContainer = screen.getByTestId('pdf-content');
    fireEvent.scroll(scrollContainer, { target: { scrollLeft: 500 } });
    const okButton = screen.getByText(/Ok/i);
    fireEvent.click(okButton);
  });
  test('should enable ok button on scroll to buttom', () => {
    window.mfe = { scmCheckoutMfeEnable: false, historyRef: [] };
    render(
      <BrowserRouter>
        <StoreProvider>
          <Agreements
            {...props}
            agreementModalData={{
              type: getRetrieveInstallmentAgreementJson.type,
              title: 'title',
              body: getRetrieveInstallmentAgreementJson.response[0].installmentContractData,
              isFirstPdf: false,
            }}
            isRxOrderReview
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const scrollContainer = screen.getByTestId('pdf-content');
    fireEvent.scroll(scrollContainer, { target: { scrollLeft: 500 } });
    const okButton = screen.getByText(/Ok/i);
    fireEvent.click(okButton);
  });
});
