import React from 'react';
import * as pdfjsLib from 'pdfjs-dist/es5/build/pdf';
import { CHANNELS, setupChannel } from '../../utils/test-utils/utils';
import { render, screen, waitFor } from '../../utils/test-utils/renderHelper';
import PDFView from './PDFView';
import getRetrieveInstallmentAgreementJson from '../../__mock__/getRetrieveInstallmentAgreement.json';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';

window.HTMLCanvasElement.prototype.getContext = () => ({
  fillRect() {},
  clearRect() {},
  getImageData(x, y, w, h) {
    return {
      data: new Array(w * h * 4),
    };
  },
  putImageData() {},
  createImageData() {
    return [];
  },
  setTransform() {},
  drawImage() {},
  save() {},
  fillText() {},
  restore() {},
  beginPath() {},
  moveTo() {},
  lineTo() {},
  closePath() {},
  stroke() {},
  translate() {},
  scale() {},
  rotate() {},
  arc() {},
  fill() {},
  measureText() {
    return { width: 0 };
  },
  transform() {},
  rect() {},
  clip() {},
});

window.HTMLCanvasElement.prototype.toDataURL = () => '';

const Test = (channel) => {
  setupChannel(channel, pdfjsLib);
  describe(`PDF View component - ${channel}`, () => {
    beforeEach(() => {
      const onError = jest.fn().mockName('onError');
      render(<PDFView onError={onError} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });
    });

    test('it should mount', () => {
      const pdfView = screen.getAllByTestId('pdf-view')[0];
      expect(pdfView).toBeInTheDocument();
    });
  });

  describe(`PDF View component - ${channel}`, () => {
    test('it should renders a pages if loading PDF succeeds', async () => {
      render(
        <PDFView
          src={getRetrieveInstallmentAgreementJson.response[0]?.installmentContractData}
          viewOnlyFlag
          onError={jest.fn()}
          onScroll={jest.fn()}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      await waitFor(() => {
        const canvas = screen.getAllByTestId('pdf-view')[0];
        expect(canvas).toBeInTheDocument();
      });
    });
  });
};

Test(CHANNELS.OMNI_RETAIL);
