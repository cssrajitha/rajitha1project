import { Body, Title } from '@vds/typography';
import styled, { createGlobalStyle } from 'styled-components';
import { useEffect } from 'react';
import PropTypes from 'prop-types';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import { Modal, ModalBody, ModalFooter, ModalTitle } from '@vds/modals';
import { useLazyGetReferencesQuery } from '../../modules/services/APIService/APIServiceHooks';
import { invokeTagging } from '../../utils/test-utils/utils';
import { scmCheckoutMfeEnabled } from '../../utils/common';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR, isDark, bgColor } from '../constants/constants';

const MarginSides = styled.div`
  margin: 0 1rem;
`;

const FlexBox = styled.div`
  display: flex;
`;

const FlexBoxColumn = styled.div`
  display: flex;
  flex-direction: column;
  align-items: left;
  width: 100%;
`;

const ModaBodyTop = styled.div`
  display: flex;
  align-items: center;
  justify-content: left;
  width: 50%;
  height: -100px;
  margin-top: -75px;
  font-weight: bold;
`;

const AlignRight = styled.div`
  text-align: right;
  font-weight: bold;
`;

const MaxWidth = styled.div`
  [class^='ModalDialog-VDS-'] {
    max-width: 1133px;
  }
`;

const ModalContentWrapper = styled.div`
  display: flex;
  > div:first-child {
    flex: 1;
  }
  > div:last-child {
    flex: 2;
  }
`;

const ModalBodyContent = styled.div`
  width: 100%;
  margin-left: auto;
  margin-right: auto;
  margin-top: 100px;
`;

const ComponentStyle = createGlobalStyle`
  #viewPlansModal {
    [id^='scrollbar-view'] {
      padding-right: 0px !important;
    }
    [class^='Overlay-VDS'] {
      background-color: rgba(0, 0, 0, 0.8);
    }
    [class^='ModalDialog-VDS'] {
      max-width:1024px; 
      border-radius: 0;
      padding: 0;
    }
    [class^='ModalDialogWrapper-VDS'] {
      padding: 0;
      overflow: hidden;
        > span {
          width: 100%;
          height: 100%;

        > div {
          width:100% !important;
          height: 100% !important;
          margin: 0px;
        }
      }
    }

    [class^='StyledModalBody-VDS'] {
      height: 80vh;
      overflow: auto;
      padding: 0 1rem;
    }

    [class^='IconWrapper-VDS'] {
      z-index: 99999;
    }
    
    [class^='StyledHeader-VDS'] {
      border-bottom: 1px solid #ccc;
      position: sticky;
      top:0;
      z-index: 999;
      padding: 1rem;
    }
    [class^='StyledFooter-VDS'] {
      border-top: 1px solid #ccc;
      position: sticky;
      bottom:0;
      padding: 1rem;
    }
  }
`;

const ViewPlansModal = ({
  opened,
  planId,
  planRefResp,
  setPlanRefResp,
  setViewPlansModal,
  mtn,
  price,
  orderStatusCR,
}) => {
  const [getReferences, getReferencesResult] = useLazyGetReferencesQuery();
  let planRefs = {};
  planRefs = planRefResp?.length > 0 && planRefResp;
  const isTysFlow = getQueryParamByName('isTysFlow');

  useEffect(() => {
    if (getReferencesResult.status === 'uninitialized' && !planRefs) {
      const planIds = Array.isArray(planId) ? planId : [planId];
      if (planId) {
        const params = {
          isPrepayFlow: false,
          planIds,
        };
        getReferences({
          body: params,
          spinner: false,
          mock: false,
        });
      }
    }
  }, [getReferencesResult]);

  if (getReferencesResult.status === 'fulfilled') {
    planRefs = getReferencesResult?.data?.data?.planReferences;
    setPlanRefResp(planRefs);
  }

  return (
    planRefs && (
      <>
        <ComponentStyle />
        <MaxWidth data-testId='viewPlans'>
          <Modal
            id='viewPlansModal'
            fullScreenDialog
            opened={opened}
            surface={isDark() ? 'dark' : 'light'}
            width='100%'
            disableAnimation={false}
            disableOutsideClick={false}
            onOpenedChange={(opened_1) => {
              if (!opened_1) setViewPlansModal(false);
            }}
            ariaLabel='Testing Modal'
          >
            <MarginSides>
              <ModalTitle>
                <Title size='small' bold color={isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                  {planRefs.map(() => (
                    <>Plan details ({price}/month)</>
                  ))}
                </Title>
              </ModalTitle>
              <ModalBody>
                <ModalContentWrapper
                  style={{
                    color: isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR,
                    backgroundColor: isDark() ? bgColor() : 'inherit',
                  }}
                >
                  {planRefs.map((planRef) => (
                    <ModalBodyContent key={planRef}>
                      <ModaBodyTop>
                        {planRef.description} (Plan Id: {planRef.planId ? `${planRef.planId}` : ''})
                      </ModaBodyTop>
                      <br />
                      <br />
                      <div>
                        <FlexBox>
                          <FlexBoxColumn>
                            <FlexBoxColumn>Retail Price</FlexBoxColumn>
                          </FlexBoxColumn>
                          <FlexBoxColumn>
                            <FlexBoxColumn>
                              <AlignRight>{price}/month</AlignRight>
                            </FlexBoxColumn>
                          </FlexBoxColumn>
                        </FlexBox>
                      </div>
                      <br />
                      <hr />
                      <Body size='large' color={isDark() ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        <div>Includes</div>
                        <div dangerouslySetInnerHTML={{ __html: planRef.featureText }} />
                      </Body>
                    </ModalBodyContent>
                  ))}
                </ModalContentWrapper>
              </ModalBody>
              <ModalFooter
                surface={isDark() ? 'dark' : 'light'}
                buttonData={{
                  close: {
                    children: 'Done',
                    width: '225px',
                    'data-track': 'Done_track',
                    onClick: (opened_2) => {
                      invokeTagging('closeView', '');
                      if (!opened_2) setViewPlansModal(false);
                    },
                  },
                  primary: {
                    children: 'Change Plan',
                    width: '225px',
                    'data-track': 'Change Plan',
                    disabled: !orderStatusCR || isTysFlow,
                    onClick: () => {
                      if (!scmCheckoutMfeEnabled()) {
                        window.location.href = `/sales/assisted/combinedgridwall.html?activeMtn=${mtn}&isPlanTabSelect=true`;
                      } else {
                        window.Emitter.emit('ACSS_SCM_SWITCH_TAB', { type: 'SWITCH_TAB', targetTab: 'PLAN_TAB' });
                      }
                      invokeTagging('openView', 'Line Plan');
                    },
                    close: true,
                  },
                }}
              />
            </MarginSides>
          </Modal>
        </MaxWidth>
      </>
    )
  );
};
ViewPlansModal.propTypes = {
  setViewPlansModal: PropTypes.func,
  planId: PropTypes.any,
  setPlanRefResp: PropTypes.func,
  planRefResp: PropTypes.object,
  opened: PropTypes.bool,
  mtn: PropTypes.string,
  price: PropTypes.any,
  orderStatusCR: PropTypes.any,
};
export default ViewPlansModal;
