/* eslint-disable */
import { render, screen, fireEvent } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import StoreProvider from '../../modules/store';
import cartJson from '../../__mock__/fetchPrice-retriveCart.json';
import fetchPriceSnapshotJSON from '../../__mock__/fetchPricingSnapshot.json';
import ServicePerksModal from './ServicePerksModal';
import * as commonUtils from '../../utils/common';

describe('ServicePerksModal Component', () => {
  const compteDPJson = {
    isSuccess: true,
    data: {
      firstMonthPrice: 28.64,
      remainingMonthPrice: 28.61,
      dpTerm: 36,
      downPayment: 200,
    },
  };
  const handlers = [
    rest.post(`*/devicepricingservice/computeDPPrices`, (req, res, ctx) =>
      res(ctx.status(200), ctx.json(compteDPJson)),
    ),
  ];
  const server = setupServer(...handlers);

  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;

    server.listen();
  });

  beforeEach(() => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const list = fetchPriceSnapshotJSON?.data?.data?.subAccounts?.[0]?.lines?.[0]?.addons;
    const scmCheckoutMfeEnabledMock = jest.spyOn(commonUtils, 'scmCheckoutMfeEnabled');
    scmCheckoutMfeEnabledMock.mockReturnValue(true);
    render(
      <BrowserRouter>
        <StoreProvider>
          <ServicePerksModal
            line={line}
            element={element}
            features={list}
            existingFeatures={list}
            newFeatures={list}
            oldFeatures={list}
            defaultImageLabel='https://ss7.vzw.com/is/image/VerizonWireless/device_protection_120817?$pngalpha$'
            fpsReferences={fetchPriceSnapshotJSON?.data?.data?.reference}
            fetchPriceSnapshotSubAccount={fetchPriceSnapshotJSON?.data?.data?.subAccounts}
            opened
            closeModal={() => {}}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('renders Devices', () => {
    const titleElement = screen.getByTestId('perksModal');
    expect(titleElement).toBeInTheDocument();
  });

  test('Modal done click', async () => {
    const DoneBtn = screen.getByText(/Done/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
  });

  test('isDark true', async () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const list = fetchPriceSnapshotJSON?.data?.data?.subAccounts?.[0]?.lines?.[0]?.addons;
    const scmCheckoutMfeEnabledMock = jest.spyOn(commonUtils, 'scmCheckoutMfeEnabled');
    scmCheckoutMfeEnabledMock.mockReturnValue(true);
    render(
      <BrowserRouter>
        <StoreProvider>
          <ServicePerksModal
            line={line}
            element={element}
            features={list}
            existingFeatures={list}
            newFeatures={list}
            oldFeatures={list}
            defaultImageLabel='https://ss7.vzw.com/is/image/VerizonWireless/device_protection_120817?$pngalpha$'
            fpsReferences={fetchPriceSnapshotJSON?.data?.data?.reference}
            fetchPriceSnapshotSubAccount={fetchPriceSnapshotJSON?.data?.data?.subAccounts}
            opened
            closeModal={() => {}}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });
});

describe('ServicePerksModal Component 1', () => {
  const compteDPJson = {
    isSuccess: true,
    data: {
      firstMonthPrice: 28.64,
      remainingMonthPrice: 28.61,
      dpTerm: 36,
      downPayment: 200,
    },
  };
  const handlers = [
    rest.post(`*/devicepricingservice/computeDPPrices`, (req, res, ctx) =>
      res(ctx.status(200), ctx.json(compteDPJson)),
    ),
  ];
  const server = setupServer(...handlers);

  beforeAll(() => {
    server.listen();
  });

  beforeEach(() => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const list = fetchPriceSnapshotJSON?.data?.data?.subAccounts?.[0]?.lines?.[0]?.addons;
    window.mfe = { scmCheckoutMfeEnabled: false };
    const scmCheckoutMfeEnabledMock = jest.spyOn(commonUtils, 'scmCheckoutMfeEnabled');
    scmCheckoutMfeEnabledMock.mockReturnValue(false);
    render(
      <BrowserRouter>
        <StoreProvider>
          <ServicePerksModal
            line={line}
            element={element}
            features={list}
            existingFeatures={list}
            newFeatures={list}
            oldFeatures={list}
            defaultImageLabel='https://ss7.vzw.com/is/image/VerizonWireless/device_protection_120817?$pngalpha$'
            fpsReferences={fetchPriceSnapshotJSON?.data?.data?.reference}
            fetchPriceSnapshotSubAccount={fetchPriceSnapshotJSON?.data?.data?.subAccounts}
            opened
            closeModal={() => {}}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('renders Devices', () => {
    const titleElement = screen.getByTestId('perksModal');
    expect(titleElement).toBeInTheDocument();
  });
});

describe('ServicePerksModal Component 1', () => {
  const compteDPJson = {
    isSuccess: true,
    data: {
      firstMonthPrice: 28.64,
      remainingMonthPrice: 28.61,
      dpTerm: 36,
      downPayment: 200,
    },
  };
  const handlers = [
    rest.post(`*/devicepricingservice/computeDPPrices`, (req, res, ctx) =>
      res(ctx.status(200), ctx.json(compteDPJson)),
    ),
  ];
  const server = setupServer(...handlers);

  beforeAll(() => {
    server.listen();
  });

  beforeEach(() => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const list = fetchPriceSnapshotJSON?.data?.data?.subAccounts?.[0]?.lines?.[0]?.addons;
    const readOrderData = {
      cart: {
        orderDetails: {
          effectiveDateDetails: {
            selectedDate: '04/03/2025',
          },
        },
      },
    };
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ readOrderMfeFFlag: 'TRUE' }));
    window.mfe = { scmCheckoutMfeEnabled: false };
    const scmCheckoutMfeEnabledMock = jest.spyOn(commonUtils, 'scmCheckoutMfeEnabled');
    scmCheckoutMfeEnabledMock.mockReturnValue(false);
    render(
      <BrowserRouter>
        <StoreProvider>
          <ServicePerksModal
            line={line}
            element={element}
            features={list}
            existingFeatures={list}
            newFeatures={list}
            oldFeatures={list}
            defaultImageLabel='https://ss7.vzw.com/is/image/VerizonWireless/device_protection_120817?$pngalpha$'
            fpsReferences={fetchPriceSnapshotJSON?.data?.data?.reference}
            fetchPriceSnapshotSubAccount={fetchPriceSnapshotJSON?.data?.data?.subAccounts}
            opened
            closeModal={() => {}}
            readOrderData={readOrderData}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('renders Devices', () => {
    const titleElement = screen.getByTestId('perksModal');
    expect(titleElement).toBeInTheDocument();
    fireEvent.click(
      screen.getByRole('link', {
        name: /change/i,
      }),
    );
  });
});

describe('ServicePerksModal Component 1', () => {
  const compteDPJson = {
    isSuccess: true,
    data: {
      firstMonthPrice: 28.64,
      remainingMonthPrice: 28.61,
      dpTerm: 36,
      downPayment: 200,
    },
  };
  const handlers = [
    rest.post(`*/devicepricingservice/computeDPPrices`, (req, res, ctx) =>
      res(ctx.status(200), ctx.json(compteDPJson)),
    ),
  ];
  const server = setupServer(...handlers);

  beforeAll(() => {
    server.listen();
  });

  beforeEach(() => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const list = fetchPriceSnapshotJSON?.data?.data?.subAccounts?.[0]?.lines?.[0]?.addons;
    const readOrderData = {
      cart: {
        orderDetails: {
          effectiveDateDetails: {
            selectedDate: '04/03/2125',
          },
        },
      },
    };
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ readOrderMfeFFlag: 'TRUE' }));
    window.mfe = { scmCheckoutMfeEnabled: false };
    const scmCheckoutMfeEnabledMock = jest.spyOn(commonUtils, 'scmCheckoutMfeEnabled');
    scmCheckoutMfeEnabledMock.mockReturnValue(false);
    render(
      <BrowserRouter>
        <StoreProvider>
          <ServicePerksModal
            line={line}
            element={element}
            features={list}
            existingFeatures={list}
            newFeatures={list}
            oldFeatures={list}
            defaultImageLabel='https://ss7.vzw.com/is/image/VerizonWireless/device_protection_120817?$pngalpha$'
            fpsReferences={fetchPriceSnapshotJSON?.data?.data?.reference}
            fetchPriceSnapshotSubAccount={fetchPriceSnapshotJSON?.data?.data?.subAccounts}
            closeModal={() => {}}
            readOrderData={readOrderData}
            isRefundReadOrder
            refundfeatureflag
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('renders Devices', () => {
    const titleElement = screen.getByTestId('perksModal');
    expect(titleElement).toBeInTheDocument();
  });
});

describe('ServicePerksModal Component - onOpenedChange', () => {
  const compteDPJson = {
    isSuccess: true,
    data: {
      firstMonthPrice: 28.64,
      remainingMonthPrice: 28.61,
      dpTerm: 36,
      downPayment: 200,
    },
  };
  const handlers = [
    rest.post(`*/devicepricingservice/computeDPPrices`, (req, res, ctx) =>
      res(ctx.status(200), ctx.json(compteDPJson)),
    ),
  ];
  const server = setupServer(...handlers);

  beforeAll(() => {
    server.listen();
  });

  afterAll(() => {
    server.close();
  });

  beforeEach(() => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const list = fetchPriceSnapshotJSON?.data?.data?.subAccounts?.[0]?.lines?.[0]?.addons;
    const readOrderData = {
      cart: {
        orderDetails: {
          effectiveDateDetails: {
            selectedDate: '04/03/2025',
          },
        },
      },
    };
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ readOrderMfeFFlag: 'TRUE' }));
    window.mfe = { scmCheckoutMfeEnabled: false };
    const scmCheckoutMfeEnabledMock = jest.spyOn(commonUtils, 'scmCheckoutMfeEnabled');
    scmCheckoutMfeEnabledMock.mockReturnValue(false);
    render(
      <BrowserRouter>
        <StoreProvider>
          <ServicePerksModal
            line={line}
            element={element}
            features={list}
            existingFeatures={list}
            newFeatures={list}
            oldFeatures={list}
            defaultImageLabel='https://ss7.vzw.com/is/image/VerizonWireless/device_protection_120817?$pngalpha$'
            fpsReferences={fetchPriceSnapshotJSON?.data?.data?.reference}
            fetchPriceSnapshotSubAccount={fetchPriceSnapshotJSON?.data?.data?.subAccounts}
            opened
            closeModal={jest.fn()} // Mock closeModal function
            readOrderData={readOrderData}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('should call closeModal when onOpenedChange is triggered with open=false', () => {
    const closeModalMock = jest.fn(); // Mock closeModal function
    render(
      <BrowserRouter>
        <StoreProvider>
          <ServicePerksModal
            line={cartJson.data.cart.lineDetails.lineInfo[0]}
            existingFeatures={[]}
            newFeatures={[]}
            oldFeatures={[]}
            fpsReferences={fetchPriceSnapshotJSON?.data?.data?.reference}
            fetchPriceSnapshotSubAccount={fetchPriceSnapshotJSON?.data?.data?.subAccounts}
            opened
            closeModal={closeModalMock} // Pass the mock function
          />
        </StoreProvider>
      </BrowserRouter>,
    );
  });
});
describe('ServicePerksModal Component - fpsReferences else path', () => {
  const mockLine = {
    mobileNumber: '1234567890',
  };

  const mockReadOrderData = {
    cart: {
      orderDetails: {
        effectiveDateDetails: {
          selectedDate: '04/03/2025',
        },
      },
    },
  };

  beforeEach(() => {
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ readOrderMfeFFlag: 'TRUE' }));
    window.mfe = { scmCheckoutMfeEnabled: false };
  });

  afterEach(() => {
    jest.clearAllMocks();
    sessionStorage.clear();
  });

  test('should handle the else path when fpsReferences.skus is empty', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ServicePerksModal
            line={mockLine}
            existingFeatures={[]}
            newFeatures={[]}
            oldFeatures={[]}
            fpsReferences={{ skus: [] }}
            fetchPriceSnapshotSubAccount={[]}
            opened
            closeModal={jest.fn()}
            readOrderData={mockReadOrderData}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    expect(screen.getByTestId('perksModal')).toBeInTheDocument();
  });

  test('should handle the else path when fpsReferences.skus is null', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ServicePerksModal
            line={mockLine}
            existingFeatures={[]}
            newFeatures={[]}
            oldFeatures={[]}
            fpsReferences={{ skus: null }}
            fetchPriceSnapshotSubAccount={[]}
            opened
            closeModal={jest.fn()}
            readOrderData={mockReadOrderData}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    expect(screen.getByTestId('perksModal')).toBeInTheDocument();
  });
  test('should handle the else path when fpsReferences.skus is null', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ServicePerksModal
            line={mockLine}
            existingFeatures={[]}
            newFeatures={[]}
            oldFeatures={[]}
            fetchPriceSnapshotSubAccount={[]}
            opened
            closeModal={jest.fn()}
            readOrderData={mockReadOrderData}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    expect(screen.getByTestId('perksModal')).toBeInTheDocument();
  });
});
