import { fireEvent, render, screen } from '@testing-library/react';
import AffirmPaymentConfirmationModal from './AffirmPaymentConfirmationModal';

const props = {
  getCartDetailsDataBody: jest.fn(),
  setShowAffirmPaymentConfirmation: jest.fn(),
  setShowAffirmModal: jest.fn(),
  setContinueBtnDisabled: jest.fn(),
  setShowAffirmAccordion: jest.fn(),
};

const airpodsCart = {
  cartDetails: {
    lineDetails: {
      lineInfo: [
        {
          itemsInfo: [
            {
              cartItems: {
                cartItem: [
                  {
                    deviceDisplayName: 'Air pods',
                  },
                ],
              },
            },
          ],
        },
      ],
    },
  },
};

const XboxCart = {
  cartDetails: {
    lineDetails: {
      lineInfo: [
        {
          itemsInfo: [
            {
              cartItems: {
                cartItem: [
                  {
                    deviceDisplayName: 'Xbox',
                  },
                ],
              },
            },
          ],
        },
      ],
    },
  },
};

describe('AffirmPaymentConfirmationModal', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  test('happy flow', () => {
    render(<AffirmPaymentConfirmationModal {...props} {...XboxCart} />);
  });
  test('happy flow with continue clicked', () => {
    render(<AffirmPaymentConfirmationModal {...props} {...airpodsCart} />);
    const continueButton = screen.getByText('Continue');
    expect(continueButton).toBeInTheDocument();
    fireEvent.click(continueButton);
  });
});
