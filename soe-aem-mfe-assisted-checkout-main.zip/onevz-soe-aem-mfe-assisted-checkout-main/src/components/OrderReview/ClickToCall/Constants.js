//  constant data of /sales/assisted.model.json, remove onces implemented
export const clickToCallSubReason = [
  {
    departmentName: 'Porting, Activation & Credit (PACT)',
    callReason: 'Order Activation Support',
    callSubReason: 'Activation Failure',
  },
  {
    departmentName: 'Porting, Activation & Credit (PACT)',
    callReason: 'Order Activation Support',
    callSubReason: 'Contract date Changes',
  },
  {
    departmentName: 'Porting, Activation & Credit (PACT)',
    callReason: 'Order Activation Support',
    callSubReason: 'Upgrade eligibility Correction',
  },
  {
    departmentName: 'Porting, Activation & Credit (PACT)',
    callReason: 'Order Activation Support',
    callSubReason: 'Disconnect within WFG',
  },
  {
    departmentName: 'Porting, Activation & Credit (PACT)',
    callReason: 'Order Activation Support',
    callSubReason: 'Returning to Original plan within WFG',
  },
  {
    departmentName: 'Porting, Activation & Credit (PACT)',
    callReason: 'Order Activation Support',
    callSubReason: 'Other',
  },
];

export const clickToCallDepartment = [
  {
    departmentName: 'Customer Service',
    callReasonDecription: '',
  },
  {
    departmentName: 'Fraud',
    callReasonDecription: 'Fraud Credit App holds or order holds',
  },
  {
    departmentName: 'Porting, Activation & Credit (PACT)',
    callReasonDecription: '',
  },
  {
    departmentName: 'Technical Support',
    callReasonDecription: '<ul> <li>Network Activation Issues</li> <li>Device Troubleshooting</li> </ul>',
  },
];

export const clickToCallReason = [
  {
    departmentName: 'Customer Service',
    callReasonDecription: 'Billing Support Account Maintenance',
    callReasonCode: 'CARE',
    callReason: 'General support',
  },
  {
    departmentName: 'Customer Service',
    callReasonDecription: 'Disconnect Request after the WFG Period',
    callReasonCode: 'Disconnect',
    callReason: 'Customer Service Loyalty /Save',
  },
  {
    departmentName: 'Customer Service',
    callReasonDecription: 'Transfer your service issues not including credit application issues',
    callReasonCode: 'Transfer Your Service',
    callReason: 'Transfer Your Service (TYS)',
  },
  {
    departmentName: 'Fraud',
    callReasonDecription: '',
    callReasonCode: 'Fraud',
    callReason: 'Fraud support',
  },
  {
    departmentName: 'Porting, Activation & Credit (PACT)',
    callReasonDecription: 'Credit applications in Hold status',
    callReasonCode: 'CreditApp Consumer',
    callReason: 'Credit Application Review',
  },
  {
    departmentName: 'Porting, Activation & Credit (PACT)',
    callReasonDecription:
      '<ul> <li>Activation failures</li> <li>Contract date changes</li> <li>Upgrade eligibility Corrections</li> <li>Disconnect within WFG (New Lines)</li> <li>Returning to original plan within WFG</li> </ul>',
    callReasonCode: 'NonTech Support Consumer',
    callReason: 'Order Activation Support',
  },
  {
    departmentName: 'Porting, Activation & Credit (PACT)',
    callReasonDecription: 'General Porting Support',
    callReasonCode: 'PortCenter',
    callReason: 'Porting Support',
  },
  {
    departmentName: 'Porting, Activation & Credit (PACT)',
    callReasonDecription:
      '<ul> <li>Device payment device id correction</li><li>Device payment override (VZ Error)</li></ul><div>Below are excluded,</div><ul> <li>Customer with ONE-BILL</li><li>Early device upgrade date changes</li><li>New customer activations</li><li>Promotions Support</li><li>Business > 1 year complete override form</li></ul>',
    callReasonCode: 'OverrideRequests',
    callReason: 'Device Payment/BTA Override Support',
  },
  {
    departmentName: 'Technical Support',
    callReasonDecription: '',
    callReasonCode: 'TechSup SmartPhone 4G',
    callReason: 'Phone, Broadband, Jetpack and Tablets',
  },
  {
    departmentName: 'Technical Support',
    callReasonDecription: '',
    callReasonCode: 'TechSup NwkExtender',
    callReason: 'Network Extender',
  },
  {
    departmentName: 'Technical Support',
    callReasonDecription: '',
    callReasonCode: 'TechSup LTE Internet',
    callReason: 'LTE Internet Installed',
  },
  {
    departmentName: 'Technical Support',
    callReasonDecription: '',
    callReasonCode: 'TechSup Connected Device',
    callReason: 'Connected Devices',
  },
  {
    departmentName: 'Technical Support',
    callReasonDecription: '',
    callReasonCode: 'TechSup TechGuru',
    callReason: 'Tech Coach',
  },
];

export const covidBannerFiveGAppointment = {
  covidBannerFiveGAppointment1:
    'We will be resuming in-home activity with precautions for you, our customer, as well as our technicians. Our technicians will be wearing gloves, sanitizing Verizon equipment, and conducting COVID-19 pre-screening calls 24 hours and 2 hours prior to entering your home. Before we can finalize your appointment, we need to ask a few questions for your safety and our technicians (Required: review questions on OST ',
  covidBannerFiveGAppointment2: '222399',
  covidBannerFiveGAppointment3: ')',
  covidBannerFiveGAppointmentLinkUrl:
    'https://infomanager.vzwcorp.com/content/km/categories/features/222399.component.html?componentPath=/jcrcontent/pagecontent/contents/content-section/blockcontent_1527533',
};
