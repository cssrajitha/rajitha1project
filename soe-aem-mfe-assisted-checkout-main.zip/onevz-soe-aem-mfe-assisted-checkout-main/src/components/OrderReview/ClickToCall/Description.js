import { useEffect, useRef } from 'react';
import DOMPurify from 'dompurify';
import PropTypes from 'prop-types';

const Description = ({ message }) => {
  const messageRef = useRef(null);

  useEffect(() => {
    if (messageRef.current) {
      const santizedHTML = DOMPurify.sanitize(message);
      messageRef.current.innerHTML = santizedHTML;
    }
  }, [message]);

  return <span ref={message ? messageRef : null} />;
};

Description.propTypes = {
  message: PropTypes.string,
};

export default Description;
