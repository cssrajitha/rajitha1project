import PropTypes from 'prop-types';
import { Modal, ModalTitle, ModalBody, ModalFooter } from '@vds/modals';
import { Body, Title } from '@vds/typography';
import { RadioButtonGroup } from '@vds/radio-buttons';
import { Input } from '@vds/inputs';
import { DropdownSelect } from '@vds/selects';
import { Button } from '@vds/buttons';
import { useEffect, useState } from 'react';
import { Icon } from '@vds/icons';
import styled from 'styled-components';
import { useDispatch } from 'react-redux';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import Description from './Description';
import { allowOnlyNumbers, formatMtnWithHyphen } from '../../../utils/common';

const ModalBodyFooterContainer = styled.div`
  padding: 0 18px;
`;

const DetailsContainer = styled.div`
  margin-top: 20px;
  padding: 14px 0;

  h6 {
    margin-bottom: 10px;
  }

  p {
    margin-bottom: 5px;
  }
  grid-area: 3 / 1 / 4 / 2;
  grid-area: ${(props) => (props.isSubReasonDisplayed ? ` 3 / 1 / 4 / 2` : ` 2 / 1 / 3 / 2`)};
`;

const InputWrapper = styled.div`
  width: 50%;
  margin-bottom: 20px;
  [class^='InputContainer-VDS'] {
    border-bottom: 2px solid black;
  }
`;

const CallDepartmentContainer = styled.div`
  display: flex;
  gap: 10px;
`;

const ListWrapper = styled.div`
  ul {
    padding-left: 18px;
    margin: 0;
  }

  div {
    font-weight: bold;
    margin-bottom: 5px;
  }
`;

const DescriptionContainer = styled.div`
  display: flex;
  margin-top: ${(props) => (props.isCallReason ? `40px` : `auto`)};
`;

const SelectWrapper = styled.div`
  width: ${(props) => (props.isDepartment ? `50%` : `auto`)};
  [class^='SelectContainer-VDS'] {
    border-bottom: 2px solid black;
  }
`;

const SelectTitleWrapper = styled.div`
  padding: 14px 0;
  [class^='StyledTypography-VDS'] {
    font-size: 16px;
    font-weight: 600;
    font-family: BrandFont-Text, Arial, sans-serif !important;
  }
`;

const AgentWrapper = styled.div`
  padding: 21px 0;
  [class^='StyledTypography-VDS'] {
    font-size: 20px;
  }
`;

const RadioWrapper = styled.div`
  margin-bottom: 12px;
`;

const ContactNumberWrapper = styled.div`
  margin-bottom: 9px;
`;

const GridParent = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  grid-template-rows: ${(props) => (props.isSubReasonDisplayed ? `0.6fr 0.6fr 1fr` : `0.5fr 1fr`)};
`;

const ReasonTitleSelectContainer = styled.div`
  grid-area: 1 / 1 / 2 / 2;
`;

const SubReasonContainer = styled.div`
  grid-area: 2 / 1 / 3 / 2;
`;

const ReasonDescriptionContainer = styled.div`
  padding-left: 10px;
  grid-area: ${(props) => (props.isSubReasonDisplayed ? `1 / 2 / 4 / 3` : ` 1 / 2 / 3 / 3`)};
`;

const DescriptionBodyWrapper = styled.div`
  margin-left: 5px;
`;

const TitleWrapper = styled.div`
  [class^='StyledTypography-VDS'] {
    font-weight: 500;
  }
`;

const FontTitleWrapper = styled.div`
  [class^='StyledTypography-VDS'] {
    font-size: ${(props) => (props.isModalBody ? `40px` : `16px`)};
  }
`;

const BodyWrapper = styled.div`
  [class^='StyledTypography-VDS'] {
    padding-left: 10px;
    padding-bottom: 5px;
    font-size: 14px;
  }
`;

const ClickToCall = (props) => {
  const dispatch = useDispatch();
  const [data, setData] = useState({
    inputPhoneNumber: '',
    isIputPhoneNumber: '',
    currentPhoneNumber: '',
    isInvalidNumber: null,
    isProceedToStartDisabled: true,
    callStatusMessage: null,
    callBackMsg: '',
    lastCallRequestSubmitted: '',
    userDetails: {},
    departSelected: {
      label: '',
      value: '',
      description: '',
    },
    reasonSelected: {
      label: '',
      value: '',
      description: '',
    },
    reasonList: [],
    clickToCallInfo: {},
    isSubReasonDisplayed: false,
    subReasonSelected: '',
  });

  useEffect(() => {
    const userData = props.userDetails || {};
    const cbrNumber = props.userDetails?.cbrNumber?.replace(/\D/g, '') ?? '';
    setData({ ...data, currentPhoneNumber: cbrNumber, userDetails: userData });
  }, []);

  useEffect(() => {
    if (props?.getClickToCallResult?.data?.data) {
      const todayDate = new Date();
      const callStatus = props?.getClickToCallResult?.data?.data?.callStatus ?? '';
      dispatch(appMessageActions.addAppMessage(callStatus, 'success', true, true));
      setData({
        ...data,
        callBackMsg: '',
        clickToCallInfo: props?.getClickToCallResult?.data?.data ?? {},
        lastCallRequestSubmitted: todayDate.getTime(),
      });
    }
  }, [props.getClickToCallResult]);

  const mobileNumberTypeCheck = (e) => {
    const input = e.target.value;
    const isIputPhoneNum = input === 'inputPhoneNumber' ? 'true' : 'false';
    setData({ ...data, isIputPhoneNumber: isIputPhoneNum });
  };

  const handlePhoneNumberUpdate = (e) => {
    const input = e.target.value.replace(/\D/g, '');
    if (allowOnlyNumbers(input)) {
      setData({ ...data, inputPhoneNumber: input, isInvalidNumber: false });
    }
  };

  const handlePhoneNumberValidation = (e) => {
    const contactNum = e.target.value;
    setData({ ...data, isInvalidNumber: !(contactNum.match(/^\d{10}$/) && !/^(\d)\1*$/.test(contactNum)) });
  };

  const validateCallDetails = () => {
    const isComboOrder = props?.credit?.length > 1;
    const creditStatus = props?.credit?.filter((item) => item !== null);
    const orderTypeEUP = creditStatus?.find((orderActivity) => orderActivity.orderActivityType === 'EUP');
    const orderTypeAAL = creditStatus?.find(
      (orderActivity) =>
        orderActivity.orderActivityType.includes('AAL') || orderActivity.orderActivityType.includes('NSE'),
    );
    const upgradeApprovalStatusCode = orderTypeEUP?.creditApplication?.creditApprovalStatus;
    const approvalStatusCode = orderTypeAAL?.creditApplication?.creditApprovalStatus;

    const upgradeSecurityDeposit = orderTypeEUP?.creditApplication?.securityDepositAmount !== '0';
    const securityDeposit = orderTypeAAL?.creditApplication?.securityDepositAmount !== '0';
    const upgradeCreditStatusReasonCode = orderTypeEUP?.creditApplication?.creditStatusReason?.substring(0, 2);
    const creditStatusReasonCode = orderTypeAAL?.creditApplication?.creditStatusReason?.substring(0, 2);

    const creditApplicationNumAAL = orderTypeAAL?.creditApplication?.creditApplicationNum;
    const creditApplicationNumEUP = orderTypeEUP?.creditApplication?.creditApplicationNum;
    const appLicationNumber = creditApplicationNumAAL || creditApplicationNumEUP;

    let initiateClicktoCall = true;
    const lastCallRequestTime = data.lastCallRequestSubmitted;

    if (data?.reasonSelected?.value === 'CreditApp Business' || data?.reasonSelected?.value === 'CreditApp Consumer') {
      if (isComboOrder === false) {
        if (upgradeApprovalStatusCode === 'PQ' || upgradeApprovalStatusCode === 'FQ') {
          const callBackMsg = 'Continue with a hard credit check, call cannot be completed for Credit App inquiry.';
          setData({ ...data, callStatusMessage: true, callBackMsg });
          initiateClicktoCall = false;
        } else if (upgradeApprovalStatusCode === 'AP' && upgradeSecurityDeposit === false) {
          const callBackMsg =
            'The Credit App is approved, please refresh your application as your call cannot be completed. Choose another menu option.';
          setData({ ...data, callStatusMessage: true, callBackMsg });
          initiateClicktoCall = false;
        } else if (['MR', 'PD', 'VR', 'ST', 'RU', 'PR'].includes(upgradeApprovalStatusCode)) {
          // To implement the Timer logic for MR status
          const reqTime = Math.floor(Date.now() / 1000) / 60;
          const initialCheckTime = lastCallRequestTime;
          const diffInchkTime = reqTime - initialCheckTime;

          if (diffInchkTime > 5) {
            const callBackMsg =
              'Your Credit Application may still be in review. When your call is connected, let the representative know that your application has been pending for more than 5 minutes';
            setData({ ...data, callStatusMessage: true, callBackMsg });
          } else {
            const callBackMsg =
              'The Credit Application is still being reviewed. Please refresh your application status and wait for a credit decision, your call cannot be completed at this time';
            setData({ ...data, callStatusMessage: true, callBackMsg });
            initiateClicktoCall = false;
          }
        } else if (approvalStatusCode === 'HD') {
          if (creditStatusReasonCode.match(/F[1-9]/)) {
            const callBackMsg = 'Your credit application is on hold by the Customer Protection Team.';
            setData({ ...data, callStatusMessage: true, callBackMsg });
          }
        } else if (approvalStatusCode === 'RV' && creditStatusReasonCode.indexOf('FR') >= 0) {
          const callBackMsg = 'Your credit application is on hold by the Customer Protection Team.';
          setData({ ...data, callStatusMessage: true, callBackMsg });
        }
      } else if (['PQ', 'FQ'].includes(approvalStatusCode) || ['PQ', 'FQ'].includes(upgradeApprovalStatusCode)) {
        const callBackMsg = 'Continue with a hard credit check, call cannot be completed for Credit App inquiry.';
        setData({ ...data, callStatusMessage: true, callBackMsg });
        initiateClicktoCall = false;
      } else if (
        (approvalStatusCode === 'AP' || upgradeApprovalStatusCode === 'AP') &&
        (upgradeSecurityDeposit === false || securityDeposit === false)
      ) {
        const callBackMsg =
          'The Credit App is approved, please refresh your application as your call cannot be completed. Choose another menu option.';
        setData({ ...data, callStatusMessage: true, callBackMsg });
        initiateClicktoCall = false;
      } else if (
        ['MR', 'PD', 'VR', 'ST', 'RU', 'PR'].includes(approvalStatusCode) ||
        ['MR', 'PD', 'VR', 'ST', 'RU', 'PR'].includes(upgradeApprovalStatusCode)
      ) {
        // To implement the Timer logic for MR status
        const reqTime = Math.floor(Date.now() / 1000) / 60;
        const initialCheckTime = lastCallRequestTime;
        const diffInchkTime = reqTime - initialCheckTime;

        if (diffInchkTime > 5) {
          const callBackMsg =
            'Your Credit Application may still be in review. When your call is connected, let the representative know that your application has been pending for more than 5 minutes';
          setData({ ...data, callStatusMessage: true, callBackMsg });
        } else {
          const callBackMsg =
            'The Credit Application is still being reviewed. Please refresh your application status and wait for a credit decision, your call cannot be completed at this time';
          setData({ ...data, callStatusMessage: true, callBackMsg });
          initiateClicktoCall = false;
        }
      } else if (approvalStatusCode === 'HD' || upgradeApprovalStatusCode === 'HD') {
        const invalidReasonCodes = ['F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8', 'F9'];
        const isInvalidReasonCode = invalidReasonCodes.some(
          (code) => creditStatusReasonCode.includes(code) || upgradeCreditStatusReasonCode.includes(code),
        );

        if (isInvalidReasonCode) {
          const callBackMsg = 'Your credit application is on hold by the Customer Protection Team.';
          setData({ ...data, callStatusMessage: true, callBackMsg });
        }
      } else if (
        (approvalStatusCode === 'RV' || upgradeApprovalStatusCode === 'RV') &&
        (creditStatusReasonCode.indexOf('FR') >= 0 || upgradeCreditStatusReasonCode.indexOf('FR') >= 0)
      ) {
        const callBackMsg = 'Your credit application is on hold by the Customer Protection Team.';
        setData({ ...data, callStatusMessage: true, callBackMsg });
      }
    }

    if (initiateClicktoCall) {
      const cbr =
        data.isIputPhoneNumber === 'true' || data.currentPhoneNumber === ''
          ? data.inputPhoneNumber
          : data.currentPhoneNumber;
      const request = {
        cbr: cbr.replace(/\D/g, ''),
        agentUserName: '',
        agentLocationId: props?.userDetails?.locationCode ?? '',
        callRsn:
          data.reasonSelected && data.isSubReasonDisplayed && data.subReasonSelected
            ? data.subReasonSelected
            : data.reasonSelected.value,
        agentLocationName: '',
        ccANum: appLicationNumber,
      };
      props.getClickToCallRequest({ body: request, spinner: true, mock: false });
    }
  };

  const handleDepartChange = (event) => {
    const { value } = event.target;
    const clickToCallDepart = props?.clickToCallDepartment?.map((depart) => ({
      label: depart.departmentName,
      value: depart.departmentName,
      description: depart.callReasonDecription,
    }));
    const { customerType } = props.landing.customerInfo.customerAttributes;
    const selectedDept = clickToCallDepart.find((dept) => dept.value === value);

    const clickToCallReasonData = props?.clickToCallReason?.filter((depart) => depart.departmentName === value);
    let reasonList = [];
    if (clickToCallReasonData?.length > 0) {
      reasonList = clickToCallReasonData?.map((reason) => {
        let callReason = reason?.callReasonCode;
        if (customerType === 'BE') {
          if (reason.callReason === 'Credit Application Review') {
            callReason = 'CreditApp Business';
          } else if (reason.callReason === 'Order Activation Support') {
            callReason = 'NonTech Support Business';
          }
        }
        return {
          label: reason.callReason,
          value: callReason,
          description: reason.callReasonDecription,
        };
      });
    }
    setData({
      ...data,
      departSelected: selectedDept,
      reasonSelected: {
        label: '',
        value: '',
        description: '',
      },
      isSubReasonDisplayed: false,
      subReasonSelected: '',
      reasonList,
    });
  };

  const handleReasonChange = (event) => {
    const selectedReason = data?.reasonList?.find((reason) => reason.value === event.target.value);

    if (
      selectedReason?.label === 'Order Activation Support' &&
      data?.departSelected?.value === 'Porting, Activation & Credit (PACT)' &&
      props?.clickToCallSubReason?.length > 0
    ) {
      setData({ ...data, isSubReasonDisplayed: true, isProceedToStartDisabled: true, reasonSelected: selectedReason });
    } else {
      setData({
        ...data,
        isSubReasonDisplayed: false,
        subReasonSelected: '',
        isProceedToStartDisabled: false,
        reasonSelected: selectedReason,
      });
    }
  };

  const handleSubReasonChange = (event) => {
    setData({ ...data, subReasonSelected: event.target.value, isProceedToStartDisabled: false });
  };

  const { accountNo, lookupMtn } = props.landing.customerInfo;
  const creditStatus = props?.credit?.filter((item) => item !== null);
  const orderTypeNSE = creditStatus?.find((orderActivityType) => orderActivityType?.orderActivityType === 'NSE');
  const creditApplicationNumNSE = orderTypeNSE?.creditApplication?.creditApplicationNum;
  const orderTypeEUP = creditStatus?.find((orderActivityType) => orderActivityType?.orderActivityType === 'EUP');
  const orderTypeAAL = creditStatus?.find((orderActivityType) => orderActivityType.orderActivityType === 'AAL');
  const creditApplicationNumAAL = orderTypeAAL?.creditApplication?.creditApplicationNum;
  const creditApplicationNumEUP = orderTypeEUP?.creditApplication?.creditApplicationNum;

  let appLicationNumber;
  if (orderTypeNSE && orderTypeNSE.orderActivityType === 'NSE') {
    appLicationNumber = creditApplicationNumNSE;
  } else if (orderTypeAAL && orderTypeAAL.orderActivityType === 'AAL') {
    appLicationNumber = creditApplicationNumAAL;
  } else {
    appLicationNumber = creditApplicationNumEUP;
  }

  const firstName = props?.userDetails?.firstName ?? '';
  const lastName = props?.userDetails?.lastName ?? '';
  const iscbrFromRecords = Boolean(props?.userDetails?.cbrNumber);
  const locationCode = props?.userDetails?.locationCode ?? '';
  const clickToCallDepartOptions = props?.clickToCallDepartment?.map((depart) => ({
    label: depart.departmentName,
    value: depart.departmentName,
    description: depart.callReasonDecription,
  }));

  const clickToCallSubReasonOptions = props?.clickToCallSubReason?.map((depart) => ({
    label: depart.callSubReason,
    value: depart.callSubReason,
    description: depart.callSubReason,
  }));

  return (
    <Modal
      opened={props.clickToCall}
      onOpenedChange={(opened) => {
        if (!opened) props.showClickToCall();
      }}
      width={100}
    >
      <ModalTitle primitive='h1'>
        <TitleWrapper>
          <Title primitive='h1' size='large'>
            Speak with an Agent Now
          </Title>
        </TitleWrapper>
      </ModalTitle>
      <ModalBodyFooterContainer>
        <ModalBody>
          <FontTitleWrapper isModalBody>
            <Title bold size='large'>
              Hello {firstName} {lastName} !
            </Title>
          </FontTitleWrapper>
          <AgentWrapper>
            <Body size='large'>Speak with an Agent Now</Body>
          </AgentWrapper>

          <ContactNumberWrapper>
            Please select/enter your contact number and we will call you right back.
          </ContactNumberWrapper>
          <RadioWrapper>
            <RadioButtonGroup
              defaultValue={iscbrFromRecords === false ? 'inputPhoneNumber' : data.currentPhoneNumber}
              onChange={mobileNumberTypeCheck}
              data={[
                {
                  name: 'phoneNumber',
                  children: `Your phone number from our records :  ${
                    data.currentPhoneNumber === '' ? '' : formatMtnWithHyphen(data.currentPhoneNumber)
                  }`,
                  id: 'phonenumber-mode-one',
                  value: data.currentPhoneNumber,
                  ariaLabel: 'Phone number from records',
                  disabled: iscbrFromRecords === false,
                },
                {
                  name: 'phoneNumber',
                  children: 'A different phone number:',
                  id: 'phonenumber-mode-two',
                  value: 'inputPhoneNumber',
                  ariaLabel: 'Different phone number',
                },
              ]}
            />
          </RadioWrapper>

          <InputWrapper>
            <Input
              type='text'
              data-testid='inputPhoneNumber'
              value={data.inputPhoneNumber}
              maxLength='10'
              onChange={handlePhoneNumberUpdate}
              onBlur={(e) => handlePhoneNumberValidation(e)}
              error={data.isInvalidNumber}
              errorText='Please enter a valid phone number'
              required={false}
            />
          </InputWrapper>

          <SelectTitleWrapper>
            <Body bold>Call Department:</Body>
          </SelectTitleWrapper>
          <CallDepartmentContainer>
            <SelectWrapper isDepartment>
              <DropdownSelect
                data-testid='departmentSelect'
                error={false}
                value={data.departSelected?.value}
                onChange={handleDepartChange}
              >
                <option>{}</option>
                {clickToCallDepartOptions.map((ele, i) => (
                  <option key={ele.value} data-testid={`departmentSelect-option${i}`} value={ele.value}>
                    {ele.label}
                  </option>
                ))}
              </DropdownSelect>
            </SelectWrapper>
            <div>
              {data.departSelected.description !== '' && (
                <DescriptionContainer>
                  <Icon name='info' />
                  <DescriptionBodyWrapper>
                    <Body size='large' bold>
                      {data.departSelected.label}
                    </Body>
                    <ListWrapper>
                      <Description message={data.departSelected.description} />
                    </ListWrapper>
                  </DescriptionBodyWrapper>
                </DescriptionContainer>
              )}
            </div>
          </CallDepartmentContainer>

          <GridParent isSubReasonDisplayed={data.isSubReasonDisplayed}>
            <ReasonTitleSelectContainer>
              <SelectTitleWrapper>
                <Body bold>Call Reason:</Body>
              </SelectTitleWrapper>
              <SelectWrapper>
                <DropdownSelect
                  error={false}
                  value={data.reasonSelected?.value}
                  onChange={handleReasonChange}
                  data-testid='reason-select'
                >
                  <option>{}</option>
                  {data.reasonList.map((ele, i) => (
                    <option key={ele.value} data-testid={`reason-option${i}`} value={ele.value}>
                      {ele.label}
                    </option>
                  ))}
                </DropdownSelect>
              </SelectWrapper>
            </ReasonTitleSelectContainer>

            <ReasonDescriptionContainer isSubReasonDisplayed={data.isSubReasonDisplayed}>
              {data.reasonSelected?.description !== '' && (
                <DescriptionContainer isCallReason>
                  <Icon name='info' />
                  <DescriptionBodyWrapper>
                    <Body size='large' bold>
                      {data.reasonSelected?.label}
                    </Body>
                    <ListWrapper>
                      <Description message={data.reasonSelected?.description} />
                    </ListWrapper>
                  </DescriptionBodyWrapper>
                </DescriptionContainer>
              )}
            </ReasonDescriptionContainer>

            {data.isSubReasonDisplayed && (
              <SubReasonContainer>
                <SelectTitleWrapper>
                  <Body bold>Call Sub Reason:</Body>
                </SelectTitleWrapper>
                <SelectWrapper>
                  <DropdownSelect
                    error={false}
                    value={data.subReasonSelected}
                    onChange={handleSubReasonChange}
                    data-testid='subreason-select'
                  >
                    <option>{}</option>
                    {clickToCallSubReasonOptions.map((ele, i) => (
                      <option key={ele.value} data-testid={`subreason-option${i}`} value={ele.value}>
                        {ele.label}
                      </option>
                    ))}
                  </DropdownSelect>
                </SelectWrapper>
              </SubReasonContainer>
            )}

            <DetailsContainer isSubReasonDisplayed={data.isSubReasonDisplayed}>
              <FontTitleWrapper>
                <Body primitive='h6'>Following details will be sent to the Agent:</Body>
              </FontTitleWrapper>
              <Body primitive='p'>Location: {locationCode}</Body>
              <Body primitive='p'> Customers Account Number: {accountNo}</Body>
              <Body primitive='p'>Customer&apos;s MTN: {lookupMtn}</Body>
              <Body primitive='p'>Credit App: {appLicationNumber}</Body>
            </DetailsContainer>
          </GridParent>
        </ModalBody>
        <ModalFooter>
          {data.isInvalidNumber && (
            <BodyWrapper>
              <Body bold primitive='p'>
                Please enter a valid phone number
              </Body>
            </BodyWrapper>
          )}
          {data.callStatusMessage && data.callBackMsg && (
            <BodyWrapper>
              <Body bold primitive='p'>
                {data.callBackMsg}
              </Body>
            </BodyWrapper>
          )}
          <Button disabled={data.isProceedToStartDisabled} onClick={validateCallDetails}>
            Start Now
          </Button>
        </ModalFooter>
      </ModalBodyFooterContainer>
    </Modal>
  );
};

ClickToCall.propTypes = {
  clickToCall: PropTypes.bool,
  showClickToCall: PropTypes.func,
  clickToCallDepartment: PropTypes.array,
  clickToCallReason: PropTypes.array,
  clickToCallSubReason: PropTypes.array,
  userDetails: PropTypes.object,
  landing: PropTypes.object,
  credit: PropTypes.object,
  getClickToCallRequest: PropTypes.func,
  getClickToCallResult: PropTypes.func,
};

export default ClickToCall;
