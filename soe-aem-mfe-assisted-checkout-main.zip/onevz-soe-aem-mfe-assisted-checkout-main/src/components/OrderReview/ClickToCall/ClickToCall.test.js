import { fireEvent, render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import ClickToCall from './ClickToCall';
import StoreProvider from '../../../modules/store';
import { clickToCallDepartment, clickToCallReason, clickToCallSubReason } from './Constants';
import retriveCartJson from '../../../__mock__/retrive-cart.json';
import retrieveCustomerJson from '../../../__mock__/retrieve-customer.json';
import initiateClickToCallJson from '../../../__mock__/initiateClickToCall.json';

describe('ClickToCall Modal Component', () => {
  const userDetailsProps = {
    firstName: 'TAB',
    lastName: 'MGR',
    locationCode: '0026301',
    storeName: 'Atlantic City',
  };
  const mockSaveOrder = jest.fn();

  const clickToCallProps = {
    clickToCall: true,
    showClickToCall: jest.fn(),
    clickToCallDepartment,
    clickToCallReason,
    clickToCallSubReason,
    userDetails: userDetailsProps,
    landing: {
      lineDetails: retriveCartJson.data.cart?.lineDetails?.lineInfo,
      customerInfo: {
        lookupMtn: retrieveCustomerJson.data.customer?.lookupMtn,
        customerAttributes: retrieveCustomerJson.data.customer?.customerAttributes,
        accountNo: retrieveCustomerJson.data.customer?.accountNo,
      },
    },
    credit: retriveCartJson.data.cart?.orderDetails?.orderList,
    getClickToCallRequest: mockSaveOrder,
    getClickToCallResult: { data: initiateClickToCallJson },
  };

  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  test('renders ClickToCall modal', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ClickToCall {...clickToCallProps} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const modalHeader = screen.getByTestId('modal-header');
    expect(modalHeader).toBeInTheDocument();
  });

  test('should display the input field with empty field', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ClickToCall {...clickToCallProps} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const inputField = screen.getByTestId('inputPhoneNumber');
    expect(inputField).toBeInTheDocument();
  });

  test('should display the number on in input field', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ClickToCall {...clickToCallProps} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const inputField = screen.getByTestId('inputPhoneNumber');
    fireEvent.change(inputField, { target: { value: '1234567890' } });
    expect(inputField).toHaveValue('1234567890');
  });

  test('should validate the user input field and show the error, if field is empty', async () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ClickToCall {...clickToCallProps} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const inputField = screen.getByTestId('inputPhoneNumber');
    fireEvent.change(inputField, { target: { value: '' } });
    fireEvent.blur(inputField);
    setTimeout(() => {
      const error = screen.findByRole('alert');
      expect(error).toBeVisible();
    }, 3000);
  });

  test('should validate the user input field and show the error, if field is empty', () => {
    const userDetailsProps2 = {
      tmpSFOList: ['81496', '81500', '81497', '81498', '81501'],
      storeName: 'Atlantic City',
      cbrNumber: '1234567890',
    };
    render(
      <BrowserRouter>
        <StoreProvider>
          <ClickToCall {...clickToCallProps} userDetails={userDetailsProps2} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const radioButton = screen.getByLabelText('Different phone number');
    fireEvent.click(radioButton);
    const radioButton2 = screen.getByLabelText('Phone number from records');
    fireEvent.click(radioButton2);
    expect(radioButton).toBeInTheDocument();
  });

  test('should select from department dropdown list', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ClickToCall {...clickToCallProps} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const departmentSelect = screen.getByTestId('departmentSelect');

    fireEvent.change(departmentSelect, { target: { value: 'Fraud' } });

    const optionOnne = screen.getByTestId('departmentSelect-option0');
    const optionTwo = screen.getByTestId('departmentSelect-option1');
    expect(optionTwo.selected).toBeTruthy();
    expect(optionOnne.selected).toBeFalsy();
  });

  test('should select from department dropdown list (For customer type is BE) ', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ClickToCall
            {...clickToCallProps}
            landing={{
              lineDetails: retriveCartJson.data.cart?.lineDetails?.lineInfo,
              customerInfo: {
                lookupMtn: retrieveCustomerJson.data.customer?.lookupMtn,
                customerAttributes: {
                  customerType: 'BE',
                },
                accountNo: retrieveCustomerJson.data.customer?.accountNo,
              },
            }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const departmentSelect = screen.getByTestId('departmentSelect');

    fireEvent.change(departmentSelect, { target: { value: 'Porting, Activation & Credit (PACT)' } });

    const optionOnne = screen.getByTestId('departmentSelect-option0');
    const optionTwo = screen.getByTestId('departmentSelect-option2');
    expect(optionTwo.selected).toBeTruthy();
    expect(optionOnne.selected).toBeFalsy();
  });

  test('should select from reason from dropdown list (For customer type is BE) and department should be selected', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ClickToCall
            {...clickToCallProps}
            landing={{
              lineDetails: retriveCartJson.data.cart?.lineDetails?.lineInfo,
              customerInfo: {
                lookupMtn: retrieveCustomerJson.data.customer?.lookupMtn,
                customerAttributes: {
                  customerType: 'BE',
                },
                accountNo: retrieveCustomerJson.data.customer?.accountNo,
              },
            }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const departmentSelect = screen.getByTestId('departmentSelect');
    fireEvent.change(departmentSelect, { target: { value: 'Porting, Activation & Credit (PACT)' } });

    const reasonSelect = screen.getByTestId('reason-select');
    fireEvent.change(reasonSelect, { target: { value: 'NonTech Support Business' } });

    const options = screen.getByTestId('reason-option1');
    expect(options).toBeInTheDocument();
  });

  test('should select from subreason from dropdown list (For customer type is BE) and department & reason should be selected', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ClickToCall
            {...clickToCallProps}
            landing={{
              lineDetails: retriveCartJson.data.cart?.lineDetails?.lineInfo,
              customerInfo: {
                lookupMtn: retrieveCustomerJson.data.customer?.lookupMtn,
                customerAttributes: {
                  customerType: 'BE',
                },
                accountNo: retrieveCustomerJson.data.customer?.accountNo,
              },
            }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const departmentSelect = screen.getByTestId('departmentSelect');
    fireEvent.change(departmentSelect, { target: { value: 'Porting, Activation & Credit (PACT)' } });

    const reasonSelect = screen.getByTestId('reason-select');
    fireEvent.change(reasonSelect, { target: { value: 'NonTech Support Business' } });

    const subReasonSelect = screen.getByTestId('subreason-select');
    fireEvent.change(subReasonSelect, { target: { value: 'Activation Failure' } });

    const options = screen.getByTestId('subreason-option0');
    expect(options).toBeInTheDocument();
  });

  test('should select from reason dropdown list normal flow', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ClickToCall {...clickToCallProps} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const departmentSelect = screen.getByTestId('departmentSelect');
    fireEvent.change(departmentSelect, { target: { value: 'Fraud' } });

    const reasonSelect = screen.getByTestId('reason-select');
    fireEvent.change(reasonSelect, { target: { value: 'Fraud' } });

    const options = screen.getAllByTestId('reason-option0');
    expect(options[0].selected).toBeTruthy();
  });

  test('should not display error message on giving required input and dropdown selection', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ClickToCall {...clickToCallProps} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const departmentSelect = screen.getByTestId('departmentSelect');
    const inputField = screen.getByTestId('inputPhoneNumber');

    fireEvent.change(inputField, { target: { value: '1234567890' } });
    fireEvent.change(departmentSelect, { target: { value: 'Fraud' } });

    const buttonClick = screen.getByText('Start Now');
    fireEvent.click(buttonClick);

    const errorMsg = screen.queryByText(/Please enter a valid phone number/i);
    expect(errorMsg).toBeNull();
  });

  test('should able to click on Start Now', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ClickToCall
            {...clickToCallProps}
            landing={{
              lineDetails: retriveCartJson.data.cart?.lineDetails?.lineInfo,
              customerInfo: {
                lookupMtn: retrieveCustomerJson.data.customer?.lookupMtn,
                customerAttributes: {
                  customerType: 'BE',
                },
                accountNo: retrieveCustomerJson.data.customer?.accountNo,
              },
            }}
            credit={[
              {
                creditApplication: {
                  creditApplicationNum: 423220266,
                  creditApprovalStatus: 'AP',
                  creditStatusReason: 'CA Customer Systematic Approval',
                  securityDepositAmount: '0',
                },
                orderActivityType: 'AAL',
                orderNumber: 12352009,
              },
            ]}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const departmentSelect = screen.getByTestId('departmentSelect');
    fireEvent.change(departmentSelect, { target: { value: 'Porting, Activation & Credit (PACT)' } });

    const reasonSelect = screen.getByTestId('reason-select');
    fireEvent.change(reasonSelect, { target: { value: 'NonTech Support Business' } });

    const subReasonSelect = screen.getByTestId('subreason-select');
    fireEvent.change(subReasonSelect, { target: { value: 'Activation Failure' } });

    const submitBtn = screen.getByText('Start Now');
    fireEvent.click(submitBtn);
  });

  test('if credit orderActivityType - EUP  and creditApprovalStatus is FQ', () => {
    const creditProps = [
      {
        creditApplication: {
          creditApplicationNum: 423220266,
          creditApprovalStatus: 'FQ',
          creditStatusReason: 'CA Customer Systematic Approval',
          securityDepositAmount: '0',
        },
        orderActivityType: 'EUP',
        orderNumber: 12352009,
      },
    ];
    render(
      <BrowserRouter>
        <StoreProvider>
          <ClickToCall
            {...clickToCallProps}
            landing={{
              lineDetails: retriveCartJson.data.cart?.lineDetails?.lineInfo,
              customerInfo: {
                lookupMtn: retrieveCustomerJson.data.customer?.lookupMtn,
                customerAttributes: {
                  customerType: 'BE',
                },
                accountNo: retrieveCustomerJson.data.customer?.accountNo,
              },
            }}
            credit={creditProps}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const departmentSelect = screen.getByTestId('departmentSelect');
    fireEvent.change(departmentSelect, { target: { value: 'Porting, Activation & Credit (PACT)' } });

    const reasonSelect = screen.getByTestId('reason-select');
    fireEvent.change(reasonSelect, { target: { value: 'CreditApp Business' } });

    const submitBtn = screen.getByText('Start Now');
    fireEvent.click(submitBtn);
  });

  test('if credit orderActivityType - EUP  and creditApprovalStatus is AP', () => {
    const creditProps = [
      {
        creditApplication: {
          creditApplicationNum: 423220266,
          creditApprovalStatus: 'AP',
          creditStatusReason: 'CA Customer Systematic Approval',
          securityDepositAmount: '0',
        },
        orderActivityType: 'EUP',
        orderNumber: 12352009,
      },
    ];
    render(
      <BrowserRouter>
        <StoreProvider>
          <ClickToCall
            {...clickToCallProps}
            landing={{
              lineDetails: retriveCartJson.data.cart?.lineDetails?.lineInfo,
              customerInfo: {
                lookupMtn: retrieveCustomerJson.data.customer?.lookupMtn,
                customerAttributes: {
                  customerType: 'BE',
                },
                accountNo: retrieveCustomerJson.data.customer?.accountNo,
              },
            }}
            credit={creditProps}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const departmentSelect = screen.getByTestId('departmentSelect');
    fireEvent.change(departmentSelect, { target: { value: 'Porting, Activation & Credit (PACT)' } });

    const reasonSelect = screen.getByTestId('reason-select');
    fireEvent.change(reasonSelect, { target: { value: 'CreditApp Business' } });

    const submitBtn = screen.getByText('Start Now');
    fireEvent.click(submitBtn);
  });

  test('if credit orderActivityType - EUP  and creditApprovalStatus is MR', () => {
    const creditProps = [
      {
        creditApplication: {
          creditApplicationNum: 423220266,
          creditApprovalStatus: 'MR',
          creditStatusReason: 'CA Customer Systematic Approval',
          securityDepositAmount: '0',
        },
        orderActivityType: 'EUP',
        orderNumber: 12352009,
      },
    ];
    render(
      <BrowserRouter>
        <StoreProvider>
          <ClickToCall
            {...clickToCallProps}
            landing={{
              lineDetails: retriveCartJson.data.cart?.lineDetails?.lineInfo,
              customerInfo: {
                lookupMtn: retrieveCustomerJson.data.customer?.lookupMtn,
                customerAttributes: {
                  customerType: 'BE',
                },
                accountNo: retrieveCustomerJson.data.customer?.accountNo,
              },
            }}
            credit={creditProps}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const departmentSelect = screen.getByTestId('departmentSelect');
    fireEvent.change(departmentSelect, { target: { value: 'Porting, Activation & Credit (PACT)' } });

    const reasonSelect = screen.getByTestId('reason-select');
    fireEvent.change(reasonSelect, { target: { value: 'CreditApp Business' } });

    const submitBtn = screen.getByText('Start Now');
    fireEvent.click(submitBtn);
  });

  test('if credit orderActivityType - AAL  and creditApprovalStatus is HD', () => {
    const creditProps = [
      {
        creditApplication: {
          creditApplicationNum: 423220266,
          creditApprovalStatus: 'HD',
          creditStatusReason: 'F1 Customer Systematic Approval',
          securityDepositAmount: '0',
        },
        orderActivityType: 'AAL',
        orderNumber: 12352009,
      },
    ];
    render(
      <BrowserRouter>
        <StoreProvider>
          <ClickToCall
            {...clickToCallProps}
            landing={{
              lineDetails: retriveCartJson.data.cart?.lineDetails?.lineInfo,
              customerInfo: {
                lookupMtn: retrieveCustomerJson.data.customer?.lookupMtn,
                customerAttributes: {
                  customerType: 'BE',
                },
                accountNo: retrieveCustomerJson.data.customer?.accountNo,
              },
            }}
            credit={creditProps}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const departmentSelect = screen.getByTestId('departmentSelect');
    fireEvent.change(departmentSelect, { target: { value: 'Porting, Activation & Credit (PACT)' } });

    const reasonSelect = screen.getByTestId('reason-select');
    fireEvent.change(reasonSelect, { target: { value: 'CreditApp Business' } });

    const submitBtn = screen.getByText('Start Now');
    fireEvent.click(submitBtn);
  });

  test('if credit more than 2 and orderActivityType - AAL, EUP  and creditApprovalStatus is FQ, AP', () => {
    const creditProps = [
      {
        creditApplication: {
          creditApplicationNum: 423220266,
          creditApprovalStatus: 'FQ',
          creditStatusReason: 'F1 Customer Systematic Approval',
          securityDepositAmount: '0',
        },
        orderActivityType: 'AAL',
        orderNumber: 12352009,
      },
      {
        creditApplication: {
          creditApplicationNum: 423220266,
          creditApprovalStatus: 'AP',
          creditStatusReason: 'CA Customer Systematic Approval',
          securityDepositAmount: '0',
        },
        orderActivityType: 'EUP',
        orderNumber: 12352009,
      },
    ];
    render(
      <BrowserRouter>
        <StoreProvider>
          <ClickToCall
            {...clickToCallProps}
            landing={{
              lineDetails: retriveCartJson.data.cart?.lineDetails?.lineInfo,
              customerInfo: {
                lookupMtn: retrieveCustomerJson.data.customer?.lookupMtn,
                customerAttributes: {
                  customerType: 'BE',
                },
                accountNo: retrieveCustomerJson.data.customer?.accountNo,
              },
            }}
            credit={creditProps}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const departmentSelect = screen.getByTestId('departmentSelect');
    fireEvent.change(departmentSelect, { target: { value: 'Porting, Activation & Credit (PACT)' } });

    const reasonSelect = screen.getByTestId('reason-select');
    fireEvent.change(reasonSelect, { target: { value: 'CreditApp Business' } });

    const submitBtn = screen.getByText('Start Now');
    fireEvent.click(submitBtn);
  });

  test('if credit more than 2 and orderActivityType - AAL  and creditApprovalStatus is AP', () => {
    const creditProps = [
      {
        creditApplication: {
          creditApplicationNum: 423220266,
          creditApprovalStatus: 'AP',
          creditStatusReason: 'F1 Customer Systematic Approval',
          securityDepositAmount: '0',
        },
        orderActivityType: 'AAL',
        orderNumber: 12352009,
      },
      {
        creditApplication: {
          creditApplicationNum: 423220266,
          creditApprovalStatus: 'AP',
          creditStatusReason: 'CA Customer Systematic Approval',
          securityDepositAmount: '0',
        },
        orderActivityType: 'AAL',
        orderNumber: 12352009,
      },
    ];
    render(
      <BrowserRouter>
        <StoreProvider>
          <ClickToCall
            {...clickToCallProps}
            landing={{
              lineDetails: retriveCartJson.data.cart?.lineDetails?.lineInfo,
              customerInfo: {
                lookupMtn: retrieveCustomerJson.data.customer?.lookupMtn,
                customerAttributes: {
                  customerType: 'BE',
                },
                accountNo: retrieveCustomerJson.data.customer?.accountNo,
              },
            }}
            credit={creditProps}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const departmentSelect = screen.getByTestId('departmentSelect');
    fireEvent.change(departmentSelect, { target: { value: 'Porting, Activation & Credit (PACT)' } });

    const reasonSelect = screen.getByTestId('reason-select');
    fireEvent.change(reasonSelect, { target: { value: 'CreditApp Business' } });

    const submitBtn = screen.getByText('Start Now');
    fireEvent.click(submitBtn);
  });

  test('if credit more than 2 and orderActivityType - AAL  and creditApprovalStatus is MR', () => {
    const creditProps = [
      {
        creditApplication: {
          creditApplicationNum: 423220266,
          creditApprovalStatus: 'MR',
          creditStatusReason: 'F1 Customer Systematic Approval',
          securityDepositAmount: '0',
        },
        orderActivityType: 'AAL',
        orderNumber: 12352009,
      },
      {
        creditApplication: {
          creditApplicationNum: 423220266,
          creditApprovalStatus: 'MR',
          creditStatusReason: 'CA Customer Systematic Approval',
          securityDepositAmount: '0',
        },
        orderActivityType: 'AAL',
        orderNumber: 12352009,
      },
    ];
    render(
      <BrowserRouter>
        <StoreProvider>
          <ClickToCall
            {...clickToCallProps}
            landing={{
              lineDetails: retriveCartJson.data.cart?.lineDetails?.lineInfo,
              customerInfo: {
                lookupMtn: retrieveCustomerJson.data.customer?.lookupMtn,
                customerAttributes: {
                  customerType: 'BE',
                },
                accountNo: retrieveCustomerJson.data.customer?.accountNo,
              },
            }}
            credit={creditProps}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const departmentSelect = screen.getByTestId('departmentSelect');
    fireEvent.change(departmentSelect, { target: { value: 'Porting, Activation & Credit (PACT)' } });

    const reasonSelect = screen.getByTestId('reason-select');
    fireEvent.change(reasonSelect, { target: { value: 'CreditApp Business' } });

    const submitBtn = screen.getByText('Start Now');
    fireEvent.click(submitBtn);
  });

  test('if credit more than 2 and orderActivityType - AAL  and creditApprovalStatus is HD', () => {
    const creditProps = [
      {
        creditApplication: {
          creditApplicationNum: 423220266,
          creditApprovalStatus: 'HD',
          creditStatusReason: 'F1 Customer Systematic Approval',
          securityDepositAmount: '0',
        },
        orderActivityType: 'AAL',
        orderNumber: 12352009,
      },
      {
        creditApplication: {
          creditApplicationNum: 423220266,
          creditApprovalStatus: 'HD',
          creditStatusReason: 'CA Customer Systematic Approval',
          securityDepositAmount: '0',
        },
        orderActivityType: 'AAL',
        orderNumber: 12352009,
      },
    ];
    render(
      <BrowserRouter>
        <StoreProvider>
          <ClickToCall
            {...clickToCallProps}
            landing={{
              lineDetails: retriveCartJson.data.cart?.lineDetails?.lineInfo,
              customerInfo: {
                lookupMtn: retrieveCustomerJson.data.customer?.lookupMtn,
                customerAttributes: {
                  customerType: 'BE',
                },
                accountNo: retrieveCustomerJson.data.customer?.accountNo,
              },
            }}
            credit={creditProps}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const departmentSelect = screen.getByTestId('departmentSelect');
    fireEvent.change(departmentSelect, { target: { value: 'Porting, Activation & Credit (PACT)' } });

    const reasonSelect = screen.getByTestId('reason-select');
    fireEvent.change(reasonSelect, { target: { value: 'CreditApp Business' } });

    const submitBtn = screen.getByText('Start Now');
    fireEvent.click(submitBtn);
  });

  test('if credit more than 2 and orderActivityType - AAL  and creditApprovalStatus is RV', () => {
    const creditProps = [
      {
        creditApplication: {
          creditApplicationNum: 423220266,
          creditApprovalStatus: 'RV',
          creditStatusReason: 'FR Customer Systematic Approval',
          securityDepositAmount: '0',
        },
        orderActivityType: 'AAL',
        orderNumber: 12352009,
      },
      {
        creditApplication: {
          creditApplicationNum: 423220266,
          creditApprovalStatus: 'RV',
          creditStatusReason: 'FR Customer Systematic Approval',
          securityDepositAmount: '0',
        },
        orderActivityType: 'AAL',
        orderNumber: 12352009,
      },
    ];
    render(
      <BrowserRouter>
        <StoreProvider>
          <ClickToCall
            {...clickToCallProps}
            landing={{
              lineDetails: retriveCartJson.data.cart?.lineDetails?.lineInfo,
              customerInfo: {
                lookupMtn: retrieveCustomerJson.data.customer?.lookupMtn,
                customerAttributes: {
                  customerType: 'BE',
                },
                accountNo: retrieveCustomerJson.data.customer?.accountNo,
              },
            }}
            credit={creditProps}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const departmentSelect = screen.getByTestId('departmentSelect');
    fireEvent.change(departmentSelect, { target: { value: 'Porting, Activation & Credit (PACT)' } });

    const reasonSelect = screen.getByTestId('reason-select');
    fireEvent.change(reasonSelect, { target: { value: 'CreditApp Business' } });

    const submitBtn = screen.getByText('Start Now');
    fireEvent.click(submitBtn);
  });
});
