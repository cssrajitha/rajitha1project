import { render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import Description from './Description';
import StoreProvider from '../../../modules/store';

describe('Description Component', () => {
  const descriptionProps = {
    message: '<ul> <li>Network Activation Issues</li> <li>Device Troubleshooting</li> </ul>',
  };

  test('renders Description component, should show the list items', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <Description {...descriptionProps} />
        </StoreProvider>
      </BrowserRouter>,
    );

    const listItem = screen.getByText('Network Activation Issues');
    expect(listItem).toBeInTheDocument();
  });

  test('should not render the list items', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <Description />
        </StoreProvider>
      </BrowserRouter>,
    );

    const listItem = screen.queryByText('Network Activation Issues');
    expect(listItem).toBeNull();
  });
});
