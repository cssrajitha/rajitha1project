import { Accordion } from '@vds/accordions';
import { Button } from '@vds/buttons';
import { Modal, ModalBody, ModalTitle } from '@vds/modals';
import { Body, Title } from '@vds/typography';
import BauNbs from 'onevzsoemfecommon/PreviewBill';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import RemoteLoader from 'onevzsoemfeframework/RemoteLoader';
import PropTypes from 'prop-types';
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import styled, { createGlobalStyle } from 'styled-components';
import { useNavigate } from 'react-router';
import { has, isEmpty } from 'lodash';
import { PaddingBottom16, PaddingTop24 } from '../../StyledConstants';
import { PreviewBillCol6, PreviewBillCol3, PreviewBillCol2 } from './NextBillSummary/CommonStyles';
import { convertDateRange, formatCurrency } from '../../utils/common';
import AccountLevelAccordion from './NextBillSummary/AccountLevelAccordion';
import ChargesAccordion from './NextBillSummary/ChargesAccordion';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR } from '../constants/constants';
import { getOneUINbsResp } from './store/selectors';

const InnerPadd = styled.div`
  padding: 0 28px;
`;

const OneUiPadd = styled.div`
  padding: 0 16px !important;
`;

const MarginSides = styled.div`
  padding: 0;
`;

const NextBillEstimateWrapper = styled.div`
  display: flex;
  flex-direction: column;
`;
const NextBillEstimateTitleContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 8px;
  h1 {
    font-size: 34px;
    letter-spacing: 0.4px;
  }
  h3 {
    font-size: 18px;
    letter-spacing: 0.4px;
  }
`;
const NextBillEstimateSubTextContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  gap: 21px;
  padding: 28px 0;
  h2 {
    font-size: 20px;
    letter-spacing: 0.4px;
    padding-right: 24px;
  }
  @media screen and (min-width: 991px) {
    width: 50%;
  }
  @media screen and (min-width: 1200px) {
    width: 41.66667%;
  }
`;
const ExpandAll = styled.div`
  cursor: pointer;
  text-decoration: underline;
`;

const EstimatedChargesWrapper = styled.div`
  display: flex;
  padding-bottom: 21px;
  margin-top: 35px;
`;

const EstimatedChargesSubText = styled.div`
  padding: 7px 0;
  width: 350px;
  line-height: 1.2;
`;

const HowToLowerYourMonthlyBillWrapper = styled.div`
  padding-top: 21px;
  h2 {
    font-size: 20px;
    letter-spacing: 0.4px;
  }
`;

const HowToLowerYourMonthlyBillPaperlessAmountContainer = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 10px;
  margin-top: 14px;
  border-top: 4px solid;
  border-bottom: 1px solid #d8dada;
  div > h4 {
    font-size: 16px;
    letter-spacing: 0.4px;
  }
  #apoPaperlessAmountTitle {
    min-width: 160px;
  }
  #apoPaperlessAmountDescription {
    min-width: 626px;
  }
  #apoPaperlessAmount {
    min-width: 145px;
    text-align: right;
  }
`;
const HowToLowerYourMonthlyBillPendingDiscountsContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 5px;
  padding-top: 14px;
  padding-right: 21px;
  h3 {
    font-size: 18px;
    letter-spacing: 0.4px;
  }
`;

const BillBreakDownWrapper = styled.div`
  width: 50%;
  margin: 28px 0;
  h1 {
    font-size: 34px;
    letter-spacing: 0.4px;
    line-height: 1.5;
  }
`;
const BillBreakDownContainer = styled.div`
  display: flex;
  width: 100%;
  justify-content: space-between;
  margin-top: ${(p) => (p?.addMargin ? '7px' : '0')};
  h3 {
    font-size: 18px;
    letter-spacing: 0.4px;
  }
`;

const TotalUnbilledContainer = styled(BillBreakDownContainer)`
  margin: 14px 0 0 0;
  border-top: solid 1px #000;
  padding-top: 14px;
  h2 {
    font-size: 20px;
    letter-spacing: 0.4px;
  }
`;
const DateRange = styled.span`
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  font-size: 18px;
  color: #747676;
  font-weight: normal;
  margin-left: 7px;
`;

const FooterContainer = styled.div`
  position: sticky;
  bottom: 0px;
  margin: auto;
  padding: 10px;
`;

const PreviewBill = ({
  opened,
  closeModal,
  billData,
  cartInfo,
  navigateTo,
  isNbsMfe,
  isFooter,
  fetchUnifiedNbsData,
}) => {
  const checkIsDarkMode = () => window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark && !isNbsMfe;

  const scmCheckoutMfeEnabled = window?.mfe?.scmCheckoutMfeEnable;
  const isDark = checkIsDarkMode();
  const ComponentStyle = createGlobalStyle`
  #previewBillModel {
    [class^='Overlay-VDS'] {
      width: ${scmCheckoutMfeEnabled ? '76.5%' : 'inherit'};
    }
    [class^='Overlay-VDS'] {
      background-color: rgba(0, 0, 0, 0.8);
    }
    [class^='ModalDialog-VDS'] {
      max-width:${scmCheckoutMfeEnabled ? '800px' : '1024px'};
      border-radius: 0;
      padding: 0;
    }
    [class^='ModalDialogWrapper-VDS'] {
      width: 65% !important;
      padding: 0;
    }
    [class^='ModalDialogWrapper-VDS'] > [class^='ModalDialogWrapper-VDS'] {
      width: 100% !important;
    }
    [class^='ModalDialogWrapper-VDS'] {
      padding:0;
        > span {
          width: 100%;
          height: 100%;

        > div {
          width:100% !important;
          height: 100% !important;

          > div {
            padding:0 !important;

            > span {
              padding:0 !important;
            }
          }
        }
      }
    }

    [class^='IconWrapper-VDS'] {
      z-index: 99999;
    }
    
    [class^='StyledHeader-VDS'] {
      border-bottom: 1px solid #ccc;
      position: ${isNbsMfe ? 'static' : 'sticky'};
      top:0;
      z-index: 999;
      padding: 1rem 0;
      background-color: #FFFFFF;
    }
    [class^='StyledFooter-VDS'] {
      border-top: 1px solid #ccc;
      position: static;
      bottom:0;
      padding-top: 2rem;
    }
  }

  [class^='ButtonGroupRow-VDS']{
    flex-direction:row-reverse;
    > div {
      padding-right:0.75rem;
    }
  }

  .preview-bill-body [class^='TriggerIconWrapper-VDS']{
    display: none;
  }
  [class^='InnerElementWrapper-VDS']{
    padding: ${isNbsMfe ? '2rem 2.5rem 2rem 0rem !important' : 0};
    min-height: auto;
  }
  .preview-bill-body [class^='StyledLine-VDS']{
    background-color: #000;
  }
`;

  let navigate = '';
  function useNavigateMFE() {
    navigate = useNavigate();
  }
  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }
  const { balancePastDue } = billData?.accountLevelChargesVo || {};
  const { totUnpaidBalance = 0, unbilledPayment = '' } = balancePastDue || { thisMonthCharge: 0, nextMonthCharge: 0 };
  const [expandAll, setExpandAll] = useState(false);
  const apiState = useSelector(
    (state) => state?.APIService?.queries['fetchUnifiedNbsData({"body":{"unifiednbsflag":true},"mock":false})'],
  );
  const encyptedCartIdPost = apiState?.data?.unifiedNbsData;

  const toggleExpand = () => {
    setExpandAll(!expandAll);
  };

  const typeOfTransaction = has(billData, 'nbsIndicators.typeOfTransaction')
    ? billData?.nbsIndicators?.typeOfTransaction
    : '';
  const customerType = getQueryParamByName('customerType') || sessionStorage.getItem('customerType');
  const isPostNbs = !!isFooter;
  const isScm = window.location.origin.includes('ccare-soe');
  const oneUINbsRespFromState = useSelector(getOneUINbsResp);

  const unifiedNBSLoadRoute = {
    scope: 'unifiednbs',
    app: 'onevzsoemfeassistedhost',
    module: './unifiednbs',
    moduleProps: {
      pageContext: 'unifiednbs',
      applicationType: 'POS_ORDERING',
      unifiedNbsData: isFooter ? encyptedCartIdPost : fetchUnifiedNbsData,
      showSuspenseLoader: true,
      isCheckoutMfe: true,
      isPostNbs,
      oneUINbsRespFromScmFlow: isScm ? oneUINbsRespFromState : null,
    },
  };

  useEffect(() => {}, [opened]);
  if (isFooter && !isNbsMfe)
    return <BauNbs opened={opened} billData={billData} navigateTo={navigateTo} closeModal={closeModal} />;
  return (
    <div>
      <ComponentStyle />
      <div data-testId='previewBillModel'>
        <Modal
          id='previewBillModel'
          fullScreenDialog
          opened={opened}
          surface={isDark ? 'dark' : 'light'}
          width='100%'
          disableAnimation={false}
          disableOutsideClick
          onOpenedChange={(open) => {
            if (!open) closeModal();
          }}
        >
          <MarginSides>
            <ModalTitle>
              <InnerPadd>
                <Title
                  size='small'
                  bold
                  primitive='h1'
                  data-testid='bill-data-title'
                  color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}
                >
                  {typeOfTransaction === 'C' || typeOfTransaction === 'Y' ? 'First Bill Summary' : 'Next Bill Summary'}
                </Title>
              </InnerPadd>
            </ModalTitle>
            <ModalBody>
              {isNbsMfe ? (
                <OneUiPadd>
                  <RemoteLoader {...unifiedNBSLoadRoute} />
                </OneUiPadd>
              ) : (
                <InnerPadd className='preview-bill-body'>
                  <NextBillEstimateWrapper>
                    <NextBillEstimateTitleContainer style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                      <Title size='large' bold primitive='h1' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        {typeOfTransaction === 'C' || typeOfTransaction === 'Y'
                          ? 'Your first bill estimate is'
                          : 'Your next bill estimate is'}{' '}
                        {formatCurrency(billData?.monthlyTotalsInfo?.nextMonthGrandTotal)}
                      </Title>
                      <Title size='small' bold primitive='h3' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        <ExpandAll data-testid='expandall-text-btn' onClick={toggleExpand}>
                          {' '}
                          {expandAll ? 'Collapse' : 'Expand All'}
                        </ExpandAll>
                      </Title>
                    </NextBillEstimateTitleContainer>
                    <NextBillEstimateSubTextContainer style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
                      <Title size='medium' primitive='h2' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        {typeOfTransaction === 'C' || typeOfTransaction === 'Y'
                          ? `Your first bill is usually higher due to one-time costs associated with becoming a customer. You're also charged for next month's plan because you're billed a month in advance.`
                          : `Thank you for being a Verizon Wireless customer. Below are the estimated charges and credits for your next bill.`}
                      </Title>
                      <Title size='medium' primitive='h2' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        {customerType !== 'N' && `Account #${billData?.accountLevelChargesVo?.accountNumber}`}
                      </Title>
                    </NextBillEstimateSubTextContainer>
                  </NextBillEstimateWrapper>

                  <EstimatedChargesWrapper>
                    <PreviewBillCol6>
                      <Title size='large' bold primitive='h1' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        Estimated charges as of {billData?.currentFormattedDate}
                      </Title>
                      {typeOfTransaction === 'Y' && (
                        <Title size='small' primitive='h4' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                          Your first bill cycle will begin once you activate a device. <br />
                          The dates shown below are based on the expected delivery date.
                        </Title>
                      )}
                    </PreviewBillCol6>
                    <PreviewBillCol3>
                      <Title size='medium' bold primitive='h2' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        {typeOfTransaction === 'C' || typeOfTransaction === 'Y' ? 'First bill' : 'Next Bill'}
                      </Title>
                      <Title size='small' primitive='h3' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        ({convertDateRange(billData?.monthlyTotalsInfo?.nextMonthChargeDateRange.split('-')[0])})
                      </Title>
                    </PreviewBillCol3>
                    <PreviewBillCol2>
                      <Title size='medium' bold primitive='h2' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        {typeOfTransaction === 'C' || typeOfTransaction === 'Y' ? 'Monthly bill' : 'New Monthly'}
                      </Title>
                    </PreviewBillCol2>
                  </EstimatedChargesWrapper>

                  <Accordion bottomLine={false} surface={isDark ? 'dark' : 'light'}>
                    {billData?.accountLevelChargesVo && (
                      <AccountLevelAccordion
                        accountLvlData={billData?.accountLevelChargesVo}
                        expandAll={expandAll}
                        cartInfo={cartInfo}
                      />
                    )}
                    {billData?.lineLevelChargesVo?.mtnLevelChargeDetails?.map((mtnData) => (
                      <ChargesAccordion key={mtnData} mtnData={mtnData} expandAll={expandAll} cartInfo={cartInfo} />
                    ))}
                  </Accordion>

                  <EstimatedChargesWrapper>
                    <PreviewBillCol6>
                      <Title size='large' bold primitive='h1' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        Your estimated bill
                      </Title>
                      <Title size='small' primitive='h4' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        <EstimatedChargesSubText>
                          {typeOfTransaction === 'C' || typeOfTransaction === 'Y'
                            ? `Taxes, fees and surcharges are estimated and will be itemized once your bill is ready.`
                            : `Taxes, fees and surcharges are estimated and will be itemized in your next bill.`}
                        </EstimatedChargesSubText>
                      </Title>
                    </PreviewBillCol6>
                    <PreviewBillCol3>
                      <Title size='medium' bold primitive='h2' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        {formatCurrency(billData?.monthlyTotalsInfo?.nextMonthCharge)}
                      </Title>
                    </PreviewBillCol3>
                    <PreviewBillCol2>
                      <Title size='medium' bold primitive='h2' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        {formatCurrency(billData?.monthlyTotalsInfo?.newMonthCharge)}
                      </Title>
                    </PreviewBillCol2>
                  </EstimatedChargesWrapper>

                  {billData?.pendingChargesAndDiscounts &&
                    (billData?.pendingChargesAndDiscounts?.totalPendingCharges ||
                      billData?.pendingChargesAndDiscounts?.discountsPendingActionDetails?.apoPaperlessAmount ||
                      billData?.pendingChargesAndDiscounts?.discountsPendingActionDetails
                        ?.newMonthlyTotalWithPendingDiscounts) &&
                    billData?.pendingChargesAndDiscounts?.discountsPendingActionDetails &&
                    !isEmpty(billData?.pendingChargesAndDiscounts?.discountsPendingActionDetails) && (
                      <HowToLowerYourMonthlyBillWrapper
                        style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}
                      >
                        <Title size='medium' bold primitive='h2' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                          How to lower your monthly bill
                        </Title>
                        {billData?.pendingChargesAndDiscounts?.discountsPendingActionDetails?.apoPaperlessAmount && (
                          <HowToLowerYourMonthlyBillPaperlessAmountContainer>
                            <div id='apoPaperlessAmountTitle'>
                              <Title
                                size='small'
                                bold
                                primitive='h4'
                                color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}
                              >
                                Auto-pay
                              </Title>
                            </div>
                            <div id='apoPaperlessAmountDescription'>
                              <Title size='small' primitive='h4' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                                {`Don't forget, you can save on your monthly bill by enrolling in paper-free billing and Auto Pay. Learn more on go.vzw.com/gopaperfree`}
                              </Title>
                            </div>
                            <div id='apoPaperlessAmount'>
                              <Title size='small' primitive='h4' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                                {`-${formatCurrency(
                                  Math.abs(
                                    billData?.pendingChargesAndDiscounts?.discountsPendingActionDetails
                                      ?.apoPaperlessAmount,
                                  ),
                                )}/mo`}
                              </Title>
                            </div>
                          </HowToLowerYourMonthlyBillPaperlessAmountContainer>
                        )}
                        {billData?.pendingChargesAndDiscounts?.discountsPendingActionDetails
                          ?.newMonthlyTotalWithPendingDiscounts && (
                          <HowToLowerYourMonthlyBillPendingDiscountsContainer>
                            <Title
                              size='small'
                              bold
                              primitive='h3'
                              color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}
                            >
                              New monthly bill estimate if promotions are applied
                            </Title>
                            <Title
                              size='small'
                              bold
                              primitive='h3'
                              color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}
                            >
                              $
                              {
                                billData?.pendingChargesAndDiscounts?.discountsPendingActionDetails
                                  ?.newMonthlyTotalWithPendingDiscounts
                              }{' '}
                            </Title>
                          </HowToLowerYourMonthlyBillPendingDiscountsContainer>
                        )}
                      </HowToLowerYourMonthlyBillWrapper>
                    )}

                  <BillBreakDownWrapper>
                    <Title size='large' bold primitive='h1' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                      Account balance breakdown
                    </Title>
                    <PaddingBottom16 />
                    <BillBreakDownContainer>
                      <Title size='small' bold primitive='h3' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        Last bill
                        {billData?.monthlyTotalsInfo?.previousCycleFormattedDateRange?.trim() !== '-' && (
                          <DateRange>({billData?.monthlyTotalsInfo?.previousCycleFormattedDateRange})</DateRange>
                        )}
                      </Title>
                      <Title size='small' primitive='h3' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        {formatCurrency(billData?.prevBalance)}
                      </Title>
                    </BillBreakDownContainer>
                    <BillBreakDownContainer addMargin>
                      <Title size='small' bold primitive='h3' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        Total paid
                      </Title>
                      <Title size='small' primitive='h3' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        {formatCurrency(unbilledPayment)}
                      </Title>
                    </BillBreakDownContainer>
                    <TotalUnbilledContainer>
                      <Title size='medium' bold primitive='h2' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        {parseFloat(totUnpaidBalance) === 0 && 'Current balance'}
                        {parseFloat(totUnpaidBalance) !== 0 &&
                          parseFloat(totUnpaidBalance) > 0 &&
                          'Total unpaid balance'}
                        {parseFloat(totUnpaidBalance) !== 0 &&
                          parseFloat(totUnpaidBalance) < 0 &&
                          'Total credit balance'}
                      </Title>
                      <Title size='medium' bold primitive='h2' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        {formatCurrency(billData?.accountLevelChargesVo?.balancePastDue?.totUnpaidBalance)}
                      </Title>
                    </TotalUnbilledContainer>
                    <PaddingTop24 />
                    {typeOfTransaction !== 'C' && typeOfTransaction !== 'Y' && (
                      <Body size='medium' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        {billData?.accountLevelChargesVo?.balancePastDue?.paymentMessage}
                      </Body>
                    )}
                  </BillBreakDownWrapper>
                </InnerPadd>
              )}
            </ModalBody>
          </MarginSides>
          {navigateTo && (
            <FooterContainer style={{ color: isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR }}>
              <Button
                surface={isDark ? 'dark' : 'light'}
                data-testid='continue-confirmation'
                onClick={() =>
                  !scmCheckoutMfeEnabled ? navigate(navigateTo) : window?.mfe?.historyRef.push(navigateTo)
                }
              >
                Continue Confirmation
              </Button>
            </FooterContainer>
          )}
        </Modal>
      </div>
    </div>
  );
};

PreviewBill.propTypes = {
  billData: PropTypes.shape({
    accountLevelChargesVo: PropTypes.shape({
      accountNumber: PropTypes.string,
      balancePastDue: PropTypes.shape({
        paymentMessage: PropTypes.string,
        totUnpaidBalance: PropTypes.string,
      }),
    }),
    currentFormattedDate: PropTypes.string,
    lineLevelChargesVo: PropTypes.shape({
      mtnLevelChargeDetails: PropTypes.object,
    }),
    monthlyTotalsInfo: PropTypes.shape({
      newMonthCharge: PropTypes.string,
      nextMonthCharge: PropTypes.string,
      nextMonthChargeDateRange: PropTypes.string,
      nextMonthGrandTotal: PropTypes.string,
      previousCycleFormattedDateRange: PropTypes.string,
    }),
    nbsIndicators: PropTypes.shape({
      typeOfTransaction: PropTypes.string,
    }),
    pendingChargesAndDiscounts: PropTypes.shape({
      totalPendingCharges: PropTypes.string,
      discountsPendingActionDetails: PropTypes.shape({
        apoPaperlessAmount: PropTypes.string,
        newMonthlyTotalWithPendingDiscounts: PropTypes.string,
      }),
    }),
    prevBalance: PropTypes.string,
  }),
  closeModal: PropTypes.func,
  navigateTo: PropTypes.string,
  opened: PropTypes.bool,
  cartInfo: PropTypes.any,
  isNbsMfe: PropTypes.bool,
  isFooter: PropTypes.bool,
  fetchUnifiedNbsData: PropTypes.string,
};

export default PreviewBill;
