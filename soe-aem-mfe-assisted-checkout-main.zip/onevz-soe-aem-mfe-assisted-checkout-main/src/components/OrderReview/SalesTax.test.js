import { render, screen, fireEvent } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../modules/store';
import cartJson from '../../__mock__/retrive-cart.json';
import SalesTax from './SalesTax';

describe('Sales Tax Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  test('renders Sales Tax', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <SalesTax cart={cartJson.data.cart} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByTestId('salesTax');
    expect(titleElement).toBeInTheDocument();
  });

  test('renders modal', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <SalesTax cart={cartJson.data.cart} />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const viewBtn = screen.getByTestId('view-salesTax');
    expect(viewBtn).toBeInTheDocument();
    fireEvent.click(viewBtn, {});
    expect(window.vzdl.page.detail);
  });

  test('renders modal for readorder flow', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <SalesTax cart={cartJson.data.cart} readOrder isReadOrderMfeFFlag />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const viewBtn = screen.getByTestId('view-salesTax');
    expect(viewBtn).toBeInTheDocument();
    fireEvent.click(viewBtn, {});
    expect(window.vzdl.page.detail);
  });

  test('isDark true', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    render(
      <BrowserRouter>
        <StoreProvider>
          <SalesTax cart={cartJson.data.cart} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByTestId('salesTax');
    expect(titleElement).toBeInTheDocument();
  });

  test('renders idDark false', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: false, themeProps: { background: '#eeeeee' } };
    render(
      <BrowserRouter>
        <StoreProvider>
          <SalesTax cart={cartJson.data.cart} />
        </StoreProvider>
      </BrowserRouter>,
    );
  });
});
