import styled, {createGlobalStyle} from 'styled-components';
import { Modal } from '@vds/modals';
import { useState } from 'react';
import PropTypes from 'prop-types';
import DownPaymentView from './DownPaymentView';

const ModalWrapper = styled.div`
  background-color: #fff;
`;
const ComponentStyle = createGlobalStyle`

    [class^='ModalDialog-VDS'] {
      padding-top: 0;
      width: 100%;
      max-width: 1133px !important;
    }

    [class^='Overlay-VDS']{
    background: rgb(0 0 0 / 70%);
    }

    [id="close-button"]{
    opacity: 0;
    }

`;

const DownPaymentViewModal = ({
  handleDPClose,
  CustomerProfileResult,
  cart,
  setDownPayment,
  handleDPDone,
  requestBodyDeviceDetails,
  downpayment,
  fetchDownPaymentResult,
}) => {
    const [open, setOpen] = useState(true);
    return (
    <>
    <ComponentStyle />
    <ModalWrapper data-testid='downpayment-modal'>
      <Modal
        surface='light'
        disableAnimation={false}
        disableOutsideClick={false}
        fullScreenDialog
        width='100%'
        ariaLabel='Manage Downpayment'
        opened={open}
        onOpenedChange={(opened) => !opened && setOpen(false)}
        closeButton={null}
      >
      <DownPaymentView 
        handleDPClose = {handleDPClose}
        CustomerProfileResult = {CustomerProfileResult}
        cart = {cart}
        setDownPayment = {setDownPayment}
        handleDPDone = {handleDPDone}
        requestBodyDeviceDetails = {requestBodyDeviceDetails}
        downpayment = {downpayment}
        fetchDownPaymentResult = {fetchDownPaymentResult}
      />
      </Modal>
    </ModalWrapper>
  </>
  )
}

  DownPaymentViewModal.propTypes = {
    handleDPClose: PropTypes.func,
    CustomerProfileResult: PropTypes.object,
    setDownPayment: PropTypes.func,
    handleDPDone: PropTypes.func,
    requestBodyDeviceDetails: PropTypes.object,
    cart: PropTypes.object,
    downpayment: PropTypes.any,
    fetchDownPaymentResult: PropTypes.any,
  };
  
  export default DownPaymentViewModal;