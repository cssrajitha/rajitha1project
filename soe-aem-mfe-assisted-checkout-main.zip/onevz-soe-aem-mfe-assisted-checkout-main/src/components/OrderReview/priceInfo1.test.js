import { fireEvent, render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../modules/store';
import retriveCartJson from '../../__mock__/retrive-cart.json';
import multiCartJson from '../../__mock__/cart_multiple.json';
import PriceInfo from './PriceInfo';

jest.mock('./EditTradein', () => ({
  __esModule: true,
  default: ({ onRemove, closeModal }) => (
    <div>
      <button type='button' data-testid='mocked-giftcard-manual' onClick={onRemove}>
        Remove button
      </button>
      <button type='button' data-testid='mocked-giftcard-manual' onClick={closeModal}>
        close modal
      </button>
    </div>
  ),
}));

jest.mock('./PreviewBill', () => ({
  __esModule: true,
  default: ({ closeModal }) => (
    <div>
      <button type='button' data-testid='mocked-giftcard-manual' onClick={closeModal}>
        Close preview modal
      </button>
    </div>
  ),
}));

jest.mock('./StoreTradein', () => ({
  __esModule: true,
  default: () => <div>Store trade in modal</div>,
}));

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradlePropertyV2: () => ['TRUE'],
  }),
  { virtual: true }
);

jest.mock('../../modules/services/APIService/GetNextBillSummary', () => () => ({
  // GetNextBillSummaryHook: () => ({
  getNextBillSummaryReq: jest.fn(),
  getNextBillSummaryRes: { data: { nbsVo: 1 } },
  // }),
}));

describe('PriceInfo testcase', () => {
  beforeEach(() => {
    window.mfe = { scmUpgradeMfeEnable: false };
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ readOrderMfeFFlag: 'TRUE' }));
  });

  beforeAll(() => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ readOrderMfeFFlag: 'TRUE' }));
  });

  test('Should redirect to shipping details Page once user click on link (view/edit)', () => {
    const {
      data: {
        cart: {
          lineDetails: { lineInfo },
        },
      },
    } = retriveCartJson;
    const [lineInfo1] = lineInfo;
    const { itemsInfo } = lineInfo1;
    const { shipping } = itemsInfo[0];
    const onLinkClick = jest.fn();
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceInfo
            title='Device trade-in credit'
            bgColor='white'
            price='$99.00'
            shippingAddress
            shippingDetails={shipping}
            cartDetails={multiCartJson}
            linkName='ViewTrade'
            address={{
              tradeInShippingType: 'upsdrop-off_qrcode',
            }}
            onLinkClick={onLinkClick}
            readOrder
            orderStatus='CR'
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const link = screen.getByTestId('addLink');
    fireEvent.click(link);
  });

  test('view button', () => {
    const {
      data: {
        cart: {
          lineDetails: {
            tradeInDetail: { tradeInItems },
          },
        },
      },
    } = retriveCartJson;
    const onLinkClick = jest.fn();
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceInfo
            title='Device trade-in credit'
            bgColor='white'
            price='$99.00'
            shippingAddress
            cartDetails={multiCartJson}
            deviceCreditinfo={tradeInItems}
            linkName='ViewTrade'
            address={{
              tradeInShippingType: 'upsdrop-off_qrcode',
            }}
            onLinkClick={onLinkClick}
            readOrder
          />
        </StoreProvider>
      </BrowserRouter>
    );
    const vlink = screen.getByTestId('viewLink');
    fireEvent.click(vlink);
  });

  test('store trade in', () => {
    const {
      data: { cart },
    } = retriveCartJson;
    const onLinkClick = jest.fn();
    render(
      <BrowserRouter>
        <StoreProvider>
          <PriceInfo
            title='Store drop-off point for Trade-in'
            padding='0px'
            cartTradeinDetails={cart}
            onLinkClick={onLinkClick}
            readOrder
          />
        </StoreProvider>
      </BrowserRouter>
    );
  });
});
