import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import Header from './index';
import { showDpAgreement } from '../../../../utils/test-utils/utils';
import customerProfile from '../__mock__/customerProfile.json';

jest.mock('../../../../utils/test-utils/utils', () => ({
  showDpAgreement: jest.fn(),
  invokeTagging: jest.fn(),
}));

jest.mock('onevzsoemfecommon/Helpers', () => ({
  getQueryParamByName: jest.fn(),
}));

describe('Header Component', () => {
  const defaultProps = {
    hqUser: false,
    fiveGHomeOrder: false,
    isReadOrder: true,
    isAccessoryFlow: true,
    landing: {},
    priceType: {},
    readOrder: {},
    retrieveCart: {},
    title: 'Refund Exchange',
    options: {},
    intentType: '',
    hemburgerMenuPopup: jest.fn(),
    openExitModel: jest.fn(),
    OpenViewTagging: jest.fn(),
  };

  const defaultPropspositive = {
    hqUser: true,
    fiveGHomeOrder: true,
    isReadOrder: true,
    isAccessoryFlow: false,
    landing: {
      channelSpecific: {
        commonInfo: {
          showManageDownPayments: {},
        },
      },
    },
    priceType: true,
    readOrder: {},
    retrieveCart: {},
    title: 'Refund Exchange',
    options: {},
    intentType: '',
    hemburgerMenuPopup: jest.fn(),
    OpenViewTagging: jest.fn(),
  };

  test('renders Header with default title', () => {
    render(<Header {...defaultProps} />);
    expect(screen.getByText('Refund Exchange')).toBeInTheDocument();
  });

  test('toggles menu visibility on hamburger icon click', () => {
    render(<Header {...defaultProps} />);
    const hamburgerIcon = screen.getByTestId('hamburger');
    fireEvent.click(hamburgerIcon);
    expect(screen.getByTestId('ModalSideNav')).toBeVisible();
    fireEvent.click(hamburgerIcon);
    expect(screen.getByTestId('ModalSideNav')).not.toBeVisible();
  });

  test('displays order details when props are provided', () => {
    const props = {
      ...defaultProps,
      isReadOrder: true,
      options: {
        subTitle: 'Order',
        orderNumber: '12345',
        refundOrderNumber: '54321',
        orderStatus: 'Completed',
      },
    };
    render(<Header {...props} />);
    // expect(screen.getByText('Order 12345')).toBeInTheDocument();
    expect(screen.getByText('Refund order 54321')).toBeInTheDocument();
    expect(screen.getByText('Order status Completed')).toBeInTheDocument();
  });

  test('renders BackClickable and triggers navigation on click', () => {
    render(<Header {...defaultProps} />);
    const backClickable = screen.getByTestId('btn-back');
    fireEvent.click(backClickable);
    // expect(window.location.href).toBe('/sales/assisted/landing.html');
  });

  test('renders LineSeperator', () => {
    render(<Header {...defaultProps} />);
    expect(screen.getByTestId('order-summary-line')).toBeInTheDocument();
  });

  test('renders Menu items and triggers hemburgerMenuPopup on click', () => {
    window.mfe = { isDark: true, scmCheckoutMfeEnable: true };
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    getQueryParamByName.mockReturnValue('isReadOrder');
    Object.defineProperty(window, 'sessionStorage', {
      value: {
        getItem: jest.fn((key) => {
          if (key === 'channel') {
            return 'OMNI-RETAIL';
          }
          return null;
        }),
        setItem: jest.fn(),
        removeItem: jest.fn(),
        clear: jest.fn(),
      },
      writable: true,
    });
    render(<Header {...defaultProps} />);
    const hamburgerIcon = screen.getByTestId('hamburger');
    fireEvent.click(hamburgerIcon);
    // const menuItem = screen.getByTestId('items-at-glance');
    // fireEvent.click(menuItem);
    // expect(defaultProps.hemburgerMenuPopup).toHaveBeenCalledWith('ITEMS_AT_GLANCE');
  });

  test('renders Menu items and triggers hemburgerMenuPopup on click positive', () => {
    window.mfe = { isDark: true, scmCheckoutMfeEnable: true };
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    getQueryParamByName.mockReturnValue('isReadOrder');
    Object.defineProperty(window, 'sessionStorage', {
      value: {
        getItem: jest.fn((key) => {
          if (key === 'channel') {
            return 'OMNI-RETAIL';
          }
          return null;
        }),
        setItem: jest.fn(),
        removeItem: jest.fn(),
        clear: jest.fn(),
      },
      writable: true,
    });
    render(<Header {...defaultPropspositive} />);
    const hamburgerIcon = screen.getByTestId('hamburger');
    fireEvent.click(hamburgerIcon);
    const menuItem = screen.getByTestId('items-at-glance');
    fireEvent.click(menuItem);
  });

  test('renders discounts & promos and triggers hemburgerMenuPopup on click', () => {
    window.mfe = { isDark: true, scmCheckoutMfeEnable: true };
    render(<Header {...defaultProps} />);
    const hamburgerIcon = screen.getByTestId('hamburger');
    fireEvent.click(hamburgerIcon);
    const menuItem = screen.getByTestId('view-discounts-promos');
    fireEvent.click(menuItem);
    expect(defaultProps.hemburgerMenuPopup).toHaveBeenCalledWith('MANUAL_DISCOUNT');
  });

  test('renders manual price correction and triggers hemburgerMenuPopup on click', () => {
    window.mfe = { isDark: true, scmCheckoutMfeEnable: true };
    render(<Header {...defaultProps} />);
    const hamburgerIcon = screen.getByTestId('hamburger');
    fireEvent.click(hamburgerIcon);
    const menuItem = screen.getByTestId('manual-charges');
    fireEvent.click(menuItem);
    expect(defaultProps.hemburgerMenuPopup).toHaveBeenCalledWith('MANUAL_CHARGES');
  });

  test('renders manual price correction and triggers hemburgerMenuPopup on click positive', () => {
    window.mfe = { isDark: true, scmCheckoutMfeEnable: true };
    render(<Header {...defaultPropspositive} />);
    const hamburgerIcon = screen.getByTestId('hamburger');
    fireEvent.click(hamburgerIcon);
    // const menuItem = screen.getByTestId('manual-charges');
    // fireEvent.click(menuItem);
    // expect(defaultPropspositive.hemburgerMenuPopup).toHaveBeenCalledWith('MANUAL_CHARGES');
  });

  test('renders Device Balance /Down Payment and triggers hemburgerMenuPopup on click', () => {
    window.mfe = { isDark: true, scmCheckoutMfeEnable: true };
    render(<Header {...defaultProps} />);
    const hamburgerIcon = screen.getByTestId('hamburger');
    fireEvent.click(hamburgerIcon);
    // const menuItem = screen.getByTestId('device-balance-down-payment');
    // fireEvent.click(menuItem);
    // expect(defaultProps.hemburgerMenuPopup).toHaveBeenCalledWith('DOWN_PAYMENT');
  });

  test('renders Device Balance /Down Payment and triggers hemburgerMenuPopup on click positive', () => {
    window.mfe = { isDark: true, scmCheckoutMfeEnable: true };
    showDpAgreement.mockReturnValue(true);
    render(<Header {...{ ...defaultPropspositive, retrieveCart: customerProfile }} />);
    const hamburgerIcon = screen.getByTestId('hamburger');
    fireEvent.click(hamburgerIcon);
    const menuItem = screen.getByTestId('device-balance-down-payment');
    fireEvent.click(menuItem);
    expect(defaultPropspositive.hemburgerMenuPopup).toHaveBeenCalledWith('DOWN_PAYMENT');
  });

  test('renders View/Print receipt and triggers hemburgerMenuPopup on click', () => {
    window.mfe = { isDark: true, scmCheckoutMfeEnable: true };
    render(<Header {...defaultProps} />);
    const hamburgerIcon = screen.getByTestId('hamburger');
    fireEvent.click(hamburgerIcon);
    // const menuItem = screen.getByTestId('view-print-receipt');
    // fireEvent.click(menuItem);
    // expect(defaultProps.hemburgerMenuPopup).toHaveBeenCalledWith('VIEW_PRINT_RECEIPT');
  });

  test('renders View/Print receipt and triggers hemburgerMenuPopup on click positive', () => {
    window.mfe = { isDark: true, scmCheckoutMfeEnable: true };
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    getQueryParamByName.mockReturnValue('isReadOrder');
    Object.defineProperty(window, 'sessionStorage', {
      value: {
        getItem: jest.fn((key) => {
          if (key === 'channel') {
            return 'OMNI-RETAIL';
          }
          return null;
        }),
        setItem: jest.fn(),
        removeItem: jest.fn(),
        clear: jest.fn(),
      },
      writable: true,
    });
    render(<Header {...defaultPropspositive} />);
    const hamburgerIcon = screen.getByTestId('hamburger');
    fireEvent.click(hamburgerIcon);
    const menuItem = screen.getByTestId('view-print-receipt');
    fireEvent.click(menuItem);
    expect(defaultPropspositive.hemburgerMenuPopup).toHaveBeenCalledWith('VIEW_PRINT_RECEIPT');
  });

  test('renders Payment History and triggers hemburgerMenuPopup on click', () => {
    window.mfe = { isDark: true, scmCheckoutMfeEnable: true };
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    getQueryParamByName.mockReturnValue('isReadOrder');
    Object.defineProperty(window, 'sessionStorage', {
      value: {
        getItem: jest.fn((key) => {
          if (key === 'channel') {
            return 'OMNI-RETAIL';
          }
          return null;
        }),
        setItem: jest.fn(),
        removeItem: jest.fn(),
        clear: jest.fn(),
      },
      writable: true,
    });
    render(<Header {...defaultProps} />);
    const hamburgerIcon = screen.getByTestId('hamburger');
    fireEvent.click(hamburgerIcon);
    const menuItem = screen.getByTestId('payment-history');
    fireEvent.click(menuItem);
    expect(defaultProps.hemburgerMenuPopup).toHaveBeenCalledWith('PAYMENT_HISTORY');
  });

  test('renders Exit and triggers hemburgerMenuPopup on click', () => {
    window.mfe = { isDark: true, scmCheckoutMfeEnable: true };
    render(<Header {...defaultProps} />);
    const hamburgerIcon = screen.getByTestId('hamburger');
    fireEvent.click(hamburgerIcon);
    const menuItem = screen.getByTestId('exit');
    fireEvent.click(menuItem);
    expect(defaultProps.hemburgerMenuPopup).toHaveBeenCalledWith('EXIT');
  });

  test('renders Backdrop and toggles visibility on click', () => {
    render(<Header {...defaultProps} />);
    const hamburgerIcon = screen.getByTestId('hamburger');
    fireEvent.click(hamburgerIcon);
    const backdrop = screen.getByTestId('back-drop');
    fireEvent.click(backdrop);
    expect(screen.getByTestId('ModalSideNav')).not.toBeVisible();
  });
});

describe('Header Component', () => {
  const defaultProps = {
    hqUser: false,
    fiveGHomeOrder: false,
    isReadOrder: false,
    landing: {},
    priceType: {},
    readOrder: {},
    retrieveCart: {},
    title: 'Refund Exchange',
    options: {},
    intentType: '',
    hemburgerMenuPopup: jest.fn(),
    openExitModel: jest.fn(),
    OpenViewTagging: jest.fn(),
  };

  it('should render Header component with default props', () => {
    const { getByText } = render(<Header {...defaultProps} />);
    expect(getByText('Refund Exchange')).toBeInTheDocument();
  });

  it('should toggle menu on hamburger icon click', () => {
    const { getByTestId } = render(<Header {...defaultProps} />);
    const hamburgerIcon = getByTestId('hamburger');
    fireEvent.click(hamburgerIcon);
    expect(getByTestId('ModalSideNav')).toBeInTheDocument();
  });

  it('should show down payment option if showDpAgreement returns true', () => {
    showDpAgreement.mockReturnValue(true);
    const { getByTestId } = render(<Header {...defaultProps} />);
    const hamburgerIcon = getByTestId('hamburger');
    fireEvent.click(hamburgerIcon);
    expect(getByTestId('device-balance-down-payment')).toBeInTheDocument();
  });

  it('should call hemburgerMenuPopup with correct argument on menu item click', () => {
    const { getByTestId } = render(<Header {...defaultProps} />);
    const hamburgerIcon = getByTestId('hamburger');
    fireEvent.click(hamburgerIcon);
    const menuItem = getByTestId('exit');
    fireEvent.click(menuItem);
    expect(defaultProps.hemburgerMenuPopup).toHaveBeenCalledWith('EXIT');
  });

  it('should display tooltip on view button click', () => {
    const props = {
      ...defaultProps,
      options: { orderNumber: '12345', subTitle: 'Sub Title' },
    };
    const { getByTestId, getByText } = render(<Header {...props} />);
    const viewButton = getByTestId('viewbutton');
    fireEvent.click(viewButton);
    expect(getByText('Location')).toBeInTheDocument();
  });
});
