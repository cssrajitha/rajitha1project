import { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import _ from 'lodash';
import { Icon } from '@vds/icons';
import { Title } from '@vds/typography';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import { invokeTagging, showDpAgreement } from '../../../../utils/test-utils/utils';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR } from '../../../constants/constants';
import './index.css';

const ShowMenuWrapper = styled.div`
  position: absolute;
  // right: 210px;
  top: 30px;
  z-index: 2;
  img {
    cursor: pointer;
  }
`;

const View = styled.a`
  cursor: pointer;
  font-size: 18px;
  text-decoration: #d84a4a;
  color: inherit;
  text-decoration: underline;
  padding-left: 5px;
`;

const scmCheckoutMfeEnabled = window?.mfe?.scmCheckoutMfeEnable;
const scmCheckoutMfeEnable = window?.mfe?.scmCheckoutMfeEnable || false;
const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;

const Rotate90Degree = styled.div`
  transform: rotate(90deg);
  margin-left: 10px;
  margin-right: 10px;
`;

const Backdrop = styled.div`
  inset: 0px !important;
  position: fixed;
  top: 15;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.8);
  overflow: hidden;
  z-index: 2;
  display: ${({ isOpen }) => (isOpen ? 'block' : 'none')};
`;

const Container = styled.div`
  display: flex;
`;

const padding = scmCheckoutMfeEnabled ? '2%' : '17%';

const Menu = styled.div`
  position: fixed;
  top: 15;
  right: ${({ isOpen }) => (isOpen ? padding : '-300px')};
  width: 384px;
  bottom: 0px;
  height: 88%;
  background-color: rgba(0, 0, 0, 0.5);
  background-color: #fff;
  opacity: 0.9;
  transition: right 0.3s ease-in-out;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
  z-index: 2;
  transition: bottom 0.3s ease;
`;

const MenuContent = styled.div`
  display: block;
  flex-direction: column;
  justify-content: center;
  aligh-items: center;
  height: 100%;
  padding-top: 50px;
`;

const CloseIconWrapper = styled.div`
  position: absolute;
  top: 15;
  right: 0;
  margin: 10px;
  cursor: pointer;
  border: none;
  background: none;
`;

const MenuModalWarp = styled.div`
  list-style-type: none;
  border-bottom: 1px solid #ccc;
  margin-bottom: 20px;
  white-space: nowrap;
  cursor: pointer;
  color: #000000 !important;
`;

const FlexRow = styled.div`
  font-family: BrandFontBold, Sans-serif !important;
  font-family: BrandFontBold, sans-serif;
  font-size: 1.2rem !important;
  display: block;
  margin: 0;
  // padding: 7px 8px;
  // width: 1024px;
  width: 100%;
`;

const Section = styled.span`
  display: inline-block;
  float: left;
  flex: 1 1 auto; /* Grow and shrink as needed */
  justify-content: space-between;
  line-height: 24px;
  max-width: 100%;
  vertical-align: baseline;
  margin: 0;
  padding-left: 12px;
  b {
    font-size: 15px;
    white-space: nowrap;
    margin-left: 7px;
    line-height: 24px;
  }
`;

const BackClickable = styled.a`
  cursor: pointer;
  color: #000000 !important;
  align-items: center;
  padding: 1.5rem 1.5rem 1.5rem 0;
`;

const LineSeperator = styled.div`
  width: 1px;
  // height: 50px;
  background: #000000;
  // top: 1rem;
  border-right: 1px solid #d8dada;
  position: relative;
  margin-right: 10px;
  margin-top: 20px;
  margin-bottom: 20px;
`;

const FlexBoxGrowOne = styled.div`
  display: flex;
  // flex-grow: 1;
  // position: sticky;
  top: 0;
  z-index: 9999;
  // background-color: #fff;
`;

// This is for tooltip alignment fix POSMFE-3133
const ToolTipParent = styled.div`
  width: 281px;
  visibility: visible;
  position: absolute;
  z-index: 1;
  @media only screen and (min-width: 768px) and (max-width: 1024px) {
    left: 135px;
    top: 70px;
  }
  @media only screen and (min-width: 1024px) and (max-width: 1400px) {
    left: 160px;
    top: 70px;
  }
  @media only screen and (min-width: 1280px) and (max-width: 1400px) {
    left: 230px;
    top: 60px;
  }
  @media only screen and (min-width: 1401px) and (max-width: 2559px) {
    left: 350px;
    top: 70px;
  }
  @media only screen and (min-width: 2560px) {
    left: 900px;
    top: 75px;
  }
  left: 211px;
  top: 50px;
  color: #000000;
  font-weight: normal;
  border: 1px solid #000000;
  background-color: #ffffff;
  :before,
  :after {
    bottom: 100%;
    left: 85%;
    border: solid transparent;
    content: ' ';
    height: 0;
    width: 0;
    position: absolute;
    pointer-events: none;
  }
  :after {
    border-color: rgba(136, 183, 213, 0);
    border-bottom-color: #ffffff;
    border-width: 9px;
    margin-left: -9px;
  }
  :before {
    border-color: rgba(194, 225, 245, 0);
    border-bottom-color: #000000;
    border-width: 10px;
    margin-left: -10px;
  }
  .nc-noCreditCheck {
    right: -23px;
    top: 35px;
  }
`;

function Header(props) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isReadOrder, setisReadOrder] = useState(false);
  const [title, setTitle] = useState('');
  const [subTitle, setsubTitle] = useState('');
  const [orderNumber, setorderNumber] = useState('');
  const [refundOrderNumber, setrefundOrderNumber] = useState('');
  const [orderStatus, setorderStatus] = useState('');
  const [locationCode, setLocationCode] = useState('');
  const [salesRepId, setsalesRepId] = useState('');
  const [transactionDate, settransactionDate] = useState('');
  const [orderToolTip, setOrderToolTip] = useState(false);

  useEffect(() => {
    const isReadOrderVal = !!(getQueryParamByName('isReadOrder') || props.isReadOrder);
    const titleVal = props?.title || '';
    const subTitleVal = props?.options?.subTitle || '';
    const orderNumberVal = props?.options?.orderNumber || '';
    const refundOrderNumberVal = props?.options?.refundOrderNumber || '';
    const orderStatusVal = props?.options?.orderStatus || '';
    const locationCodeVal = props?.options?.locationCode || '';
    const salesRepIdVal = props?.options?.salesRepId || '';
    const transactionDateVal = props?.options?.transactionDate || '';

    setisReadOrder(isReadOrderVal);
    setTitle(titleVal);
    setsubTitle(subTitleVal);
    setorderNumber(orderNumberVal);
    setrefundOrderNumber(refundOrderNumberVal);
    setorderStatus(orderStatusVal);
    setLocationCode(locationCodeVal);
    setsalesRepId(salesRepIdVal);
    settransactionDate(transactionDateVal);
  }, [props]);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const isIndirect = sessionStorage.getItem('channel')?.includes('OMNI-INDIRECT');
  const hqUserValue = props?.hqUser || false;
  const { isAccessoryFlow } = { ...props };

  const isAccessoryTypeVisible = () => {
    if (isIndirect || isAccessoryFlow) {
      return false;
    }
    return true;
  };

  const isManualCorrectionVisible = () => {
    if (hqUserValue || isIndirect) {
      return false;
    }
    return true;
  };

  const showDownPayment = () => {
    // eslint-disable-next-line you-dont-need-lodash-underscore/get
    const lineInfo = _.get(props.retrieveCart, 'lineDetails.lineInfo', []);
    const hasDp = showDpAgreement(lineInfo);
    const { priceType, CustomerProfileResult } = props;
    const commonInfo = CustomerProfileResult?.data?.data?.commonInfo;
    if ((commonInfo?.showManageDownPayments && priceType) || hasDp) {
      return commonInfo?.showManageDownPayments || hasDp;
    }
  };

  const isPrintVisisble = () => {
    const roPrintReciptFlagInd = sessionStorage.getItem('roPrintReciptFlagInd')
      ? sessionStorage.getItem('roPrintReciptFlagInd') === 'true'
      : false;
    console.log(`AppropertyValue >> ${roPrintReciptFlagInd}`);
    const printReciptFlag = !!(sessionStorage.getItem('channel')?.includes('OMNI-INDIRECT') && roPrintReciptFlagInd);
    const processStep = props?.readOrder?.processStep || '';
    const orderStatusVal = props?.readOrder?.orderStatus || '';
    if (
      (!isIndirect || printReciptFlag) &&
      isReadOrder &&
      (processStep === 'CLOSE' || processStep === '' || orderStatusVal === 'CO')
    ) {
      return true;
    }
    return false;
  };

  const openToolTipModal = () => {
    setOrderToolTip(!orderToolTip);
  };

  const displayToolTip = () => (
    <ToolTipParent>
      <div className='Grid Grid--gapless font-15'>
        <div className='Col u-paddingAllMedium border-bottom-grey-light lite'>
          Location <span className='float-right lite'>{locationCode}</span>
        </div>
        <div className='Col u-paddingAllMedium border-bottom-grey-light lite'>
          Rep number <span className='float-right lite'>{salesRepId}</span>
        </div>
        <div className='Col u-paddingAllMedium border-bottom-grey-light lite'>
          Transaction date <span className='float-right lite'>{transactionDate}</span>
        </div>
      </div>
    </ToolTipParent>
  );

  return (
    <>
      <div
        style={{
          display: 'flex',
          width: '100%',
          flexDirection: 'row',
          justifyContent: 'center',
          alignItems: 'center',
          borderBottom: '1px solid rgb(204, 204, 204)',
          borderWidth: '1px',
        }}
      >
        <div style={{ flex: 1, width: '100%', justifyContent: 'center', alignItems: 'center' }}>
          <FlexBoxGrowOne>
            <BackClickable
              data-testId='btn-back'
              onClick={() => {
                window.location.href = `/sales/assisted/landing.html`;
              }}
            >
              <Icon name='left-caret' size='XLarge' medium='true' />
            </BackClickable>
            <LineSeperator />
          </FlexBoxGrowOne>
        </div>
        <div style={{ flex: 12, width: '100%', justifyContent: 'center', alignItems: 'center' }}>
          <FlexRow data-testid='order-summary-line'>
            <Section>
              <h2>{title}</h2>
            </Section>
            {subTitle !== '' && props?.intentType !== '5GHomeRetailRFEX' && (
              <Section>
                <h2>
                  {subTitle}
                  <View
                    type='button'
                    data-testid='viewbutton'
                    data-track={`Original Order_${props?.options?.orderNumber || ''}`}
                    onMouseOver={() => setOrderToolTip(true)}
                    onMouseOut={() => setOrderToolTip(false)}
                    onClick={openToolTipModal}
                  >
                    {orderNumber}
                  </View>
                </h2>
              </Section>
            )}
            {orderToolTip && <div>{displayToolTip()}</div>}
            {refundOrderNumber !== '' && props?.isReadOrder && (
              <Section>
                <h2>Refund order {refundOrderNumber}</h2>
              </Section>
            )}
            {orderStatus !== '' && props?.isReadOrder && (
              <Section>
                <h2>Order status {orderStatus}</h2>
              </Section>
            )}
          </FlexRow>
        </div>
        <div style={{ flex: 2, width: '100%', justifyContent: 'center', alignItems: 'center' }}>
          <ShowMenuWrapper scmCheckoutMfeEnable={scmCheckoutMfeEnable}>
            <Rotate90Degree onClick={toggleMenu} data-testid='hamburger'>
              <Icon name='more-horizontal' size='large' />
            </Rotate90Degree>
          </ShowMenuWrapper>
        </div>
      </div>
      <Backdrop isOpen={isMenuOpen} onClick={toggleMenu} data-testid='back-drop'>
        <Container data-testid='ModalSideNav' id='ModalSideNav'>
          {isMenuOpen && (
            <Menu isOpen={isMenuOpen}>
              <CloseIconWrapper onClick={toggleMenu}>
                <span>
                  <Icon name='close' size='large' />
                </span>
              </CloseIconWrapper>
              <MenuContent>
                <ul>
                  {isAccessoryTypeVisible() && (
                    <MenuModalWarp
                      onClick={() => {
                        props?.OpenViewTagging(
                          'itemsAtAGlance',
                          'itemsAtAGlance',
                          'EUP|RFEX-read-order',
                          'orderReview',
                          props.rspFetchReadOrder,
                        );
                        props.hemburgerMenuPopup('ITEMS_AT_GLANCE');
                      }}
                      data-testid='items-at-glance'
                      data-track='ViewItemsAtGlance'
                    >
                      <Title size='small' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        View items at a glance
                      </Title>
                    </MenuModalWarp>
                  )}
                  {!isIndirect && (
                    <MenuModalWarp
                      onClick={() => {
                        invokeTagging('openView', 'View discounts & promos');
                        props.hemburgerMenuPopup('MANUAL_DISCOUNT');
                      }}
                      data-testid='view-discounts-promos'
                      data-track='View discounts & promos'
                    >
                      <Title size='small' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        View discounts & promos
                      </Title>
                    </MenuModalWarp>
                  )}
                  {isManualCorrectionVisible() && (
                    <MenuModalWarp
                      onClick={() => {
                        props?.OpenViewTagging(
                          'manualCharges',
                          'manualCharges',
                          'EUP|RFEX-read-order',
                          'orderReview',
                          props.rspFetchReadOrder,
                        );
                        props.hemburgerMenuPopup('MANUAL_CHARGES');
                      }}
                      data-testid='manual-charges'
                      data-track='View manual price correction'
                    >
                      <Title size='small' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        View manual price correction
                      </Title>
                    </MenuModalWarp>
                  )}
                  {showDownPayment() && (
                    <MenuModalWarp
                      onClick={() => {
                        invokeTagging('openView', 'Device Balance /Down Payment');
                        props.hemburgerMenuPopup('DOWN_PAYMENT');
                      }}
                      data-testid='device-balance-down-payment'
                      data-track='Device Balance /Down Payment'
                    >
                      <Title size='small' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        Device Balance /Down Payment
                      </Title>
                    </MenuModalWarp>
                  )}
                  {isPrintVisisble() && (
                    <MenuModalWarp
                      onClick={() => {
                        invokeTagging('openView', 'View/Print receipt');
                        props.hemburgerMenuPopup('VIEW_PRINT_RECEIPT');
                      }}
                      data-testid='view-print-receipt'
                      data-track='View/Print receipt'
                    >
                      <Title size='small' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        View/Print receipt
                      </Title>
                    </MenuModalWarp>
                  )}
                  {!isIndirect && isReadOrder && (
                    <MenuModalWarp
                      onClick={() => {
                        props?.OpenViewTagging(
                          'viewPaymentHistory',
                          'viewPaymentHistory',
                          'EUP|RFEX-read-order',
                          'orderReview',
                          props.rspFetchReadOrder,
                        );
                        props.hemburgerMenuPopup('PAYMENT_HISTORY');
                      }}
                      data-testid='payment-history'
                      data-track='Payment History'
                    >
                      <Title size='small' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                        Payment History
                      </Title>
                    </MenuModalWarp>
                  )}
                  <MenuModalWarp
                    onClick={() => {
                      props.OpenViewTagging(
                        'exitOrder',
                        'Exit',
                        'EUP|RFEX-read-order',
                        'orderReview',
                        props.rspFetchReadOrder,
                      );
                      props.hemburgerMenuPopup('EXIT');
                      props.openExitModel();
                    }}
                    data-testid='exit'
                    data-track='Exit'
                  >
                    <Title size='small' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
                      Exit
                    </Title>
                  </MenuModalWarp>
                </ul>
              </MenuContent>
            </Menu>
          )}
        </Container>
      </Backdrop>
    </>
  );
}

Header.defaultProps = {
  title: 'Refund Exchange',
};

Header.propTypes = {
  hqUser: PropTypes.bool,
  isReadOrder: PropTypes.bool,
  priceType: PropTypes.object,
  readOrder: PropTypes.object,
  retrieveCart: PropTypes.object,
  title: PropTypes.string,
  options: PropTypes.object,
  intentType: PropTypes.string,
  hemburgerMenuPopup: PropTypes.func,
  openExitModel: PropTypes.func,
  OpenViewTagging: PropTypes.func,
  rspFetchReadOrder: PropTypes.object,
  CustomerProfileResult: PropTypes.object,
};

export default Header;
