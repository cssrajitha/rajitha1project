// utils.test.js
import { isDfill, getDiscountAmount, getItemCost, getDownPaymentAmount } from './utils';

jest.mock('onevzsoemfecommon/Helpers', () => ({
  formatCurrency: jest.fn((value) => `$${value}`),
}));

describe('utils', () => {
  describe('getDiscountAmount', () => {
    it('should return formatted discount amount with hyphen for refund type and TRADE_IN cartItemType', () => {
      const order = {
        cartItemType: 'TRADE_IN',
        type: 'refund',
        discAmt: 50,
      };
      const result = getDiscountAmount(order);
      expect(result);
    });

    it('should return formatted discount amount without hyphen for non-refund type and TRADE_IN cartItemType', () => {
      const order = {
        cartItemType: 'TRADE_IN',
        type: 'purchase',
        discAmt: 50,
      };
      const result = getDiscountAmount(order);
      expect(result);
    });

    it('should return formatted discount amount from sedOfferList with hyphen for refund type', () => {
      const order = {
        cartItemType: 'DEVICE',
        type: 'refund',
        sedOfferList: {
          sedOffer: [{ discAmt: 30 }],
        },
      };
      const result = getDiscountAmount(order);
      expect(result);
    });

    it('should return formatted discount amount from sedOfferList without hyphen for non-refund type', () => {
      const order = {
        cartItemType: 'DEVICE',
        type: 'purchase',
        sedOfferList: {
          sedOffer: [{ discAmt: 30 }],
        },
      };
      const result = getDiscountAmount(order);
      expect(result);
    });

    it('should return formatted 0 if no discount amount is present', () => {
      const order = {
        cartItemType: 'DEVICE',
        type: 'purchase',
      };
      const result = getDiscountAmount(order);
      expect(result);
    });

    it('should return formatted 0 if discAmt is not present for TRADE_IN cartItemType', () => {
      const order = {
        cartItemType: 'TRADE_IN',
        type: 'refund',
        discAmt: null,
      };
      const result = getDiscountAmount(order);
      expect(result);
    });

    it('should return formatted 0 if discAmt is undefined for TRADE_IN cartItemType', () => {
      const order = {
        cartItemType: 'TRADE_IN',
        type: 'refund',
        discAmt: undefined,
      };
      const result = getDiscountAmount(order);
      expect(result);
    });
  });

  describe('getItemCost', () => {
    it('should return formatted discounted price for RESTOCKFEE cartItemType', () => {
      const order = {
        cartItemType: 'RESTOCKFEE',
        discountedPrice: 20,
      };
      const result = getItemCost(order);
      expect(result);
    });

    it('should return formatted item price for RESTOCKFEE cartItemType if discounted price is not present', () => {
      const order = {
        cartItemType: 'RESTOCKFEE',
        itemPrice: 25,
      };
      const result = getItemCost(order);
      expect(result);
    });

    it('should return formatted item cost if cartItemType is not RESTOCKFEE', () => {
      const order = {
        cartItemType: 'DEVICE',
        itemCost: 100,
      };
      const result = getItemCost(order);
      expect(result);
    });

    it('should return formatted 0 if item cost is not present', () => {
      const order = {
        cartItemType: 'DEVICE',
      };
      const result = getItemCost(order);
      expect(result);
    });
  });

  describe('getDownPaymentAmount', () => {
    it('should return formatted down payment amount with hyphen for refund type and DEVICE cartItemType', () => {
      const order = {
        cartItemType: 'DEVICE',
        downPaymentAmount: 100,
        type: 'refund',
      };
      const result = getDownPaymentAmount(order);
      expect(result);
    });

    it('should return formatted down payment amount without hyphen for non-refund type and DEVICE cartItemType', () => {
      const order = {
        cartItemType: 'DEVICE',
        downPaymentAmount: 100,
        type: 'purchase',
      };
      const result = getDownPaymentAmount(order);
      expect(result);
    });

    it('should return formatted 0 if downPaymentAmount is not present', () => {
      const order = {
        cartItemType: 'DEVICE',
        type: 'purchase',
      };
      const result = getDownPaymentAmount(order);
      expect(result);
    });

    it('should return formatted 0 if cartItemType is not DEVICE or ACCESSORY', () => {
      const order = {
        cartItemType: 'SERVICE',
        downPaymentAmount: 100,
        type: 'purchase',
      };
      const result = getDownPaymentAmount(order);
      expect(result);
    });
  });
});

describe('isDfill', () => {
  test('should return false for empty lineInfo', () => {
    const result = isDfill([]);
    expect(result).toBe(false);
  });

  test('should return false for lineInfo with no matching lineActivityType', () => {
    const lineInfo = [{ lineActivityType: 'OTHER', itemsInfo: [] }];
    const result = isDfill(lineInfo);
    expect(result).toBe(false);
  });

  test('should return false for lineInfo with matching lineActivityType but no itemsInfo', () => {
    const lineInfo = [{ lineActivityType: 'EXC', itemsInfo: [] }];
    const result = isDfill(lineInfo);
    expect(result).toBe(false);
  });

  test('should return false for lineInfo with matching lineActivityType and itemsInfo but no cartItems', () => {
    const lineInfo = [{ lineActivityType: 'EXC', itemsInfo: [{ cartItems: null }] }];
    const result = isDfill(lineInfo);
    expect(result).toBe(false);
  });

  test('should return false for lineInfo with matching lineActivityType and itemsInfo but no cartItem', () => {
    const lineInfo = [{ lineActivityType: 'EXC', itemsInfo: [{ cartItems: { cartItem: [] } }] }];
    const result = isDfill(lineInfo);
    expect(result).toBe(false);
  });

  test('should return false for lineInfo with matching lineActivityType and itemsInfo but no matching cartItemType', () => {
    const lineInfo = [
      {
        lineActivityType: 'EXC',
        itemsInfo: [{ cartItems: { cartItem: [{ cartItemType: 'OTHER', depletionType: 'F' }] } }],
      },
    ];
    const result = isDfill(lineInfo);
    expect(result).toBe(false);
  });

  test('should return false for lineInfo with matching lineActivityType and itemsInfo but no matching depletionType', () => {
    const lineInfo = [
      {
        lineActivityType: 'EXC',
        itemsInfo: [{ cartItems: { cartItem: [{ cartItemType: 'ACCESSORY', depletionType: 'OTHER' }] } }],
      },
    ];
    const result = isDfill(lineInfo);
    expect(result).toBe(false);
  });

  test('should return true for lineInfo with matching lineActivityType, itemsInfo, cartItemType, and depletionType', () => {
    const lineInfo = [
      {
        lineActivityType: 'EXC',
        itemsInfo: [{ cartItems: { cartItem: [{ cartItemType: 'ACCESSORY', depletionType: 'F' }] } }],
      },
    ];
    const result = isDfill(lineInfo);
    expect(result).toBe(true);
  });

  test('should return true for lineInfo with multiple lines and at least one matching', () => {
    const lineInfo = [
      { lineActivityType: 'OTHER', itemsInfo: [] },
      {
        lineActivityType: 'EXC',
        itemsInfo: [{ cartItems: { cartItem: [{ cartItemType: 'DEVICE', depletionType: 'F' }] } }],
      },
    ];
    const result = isDfill(lineInfo);
    expect(result).toBe(true);
  });
});
