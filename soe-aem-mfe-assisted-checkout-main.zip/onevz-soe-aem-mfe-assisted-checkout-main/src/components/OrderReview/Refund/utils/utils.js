import { formatCurrency } from 'onevzsoemfecommon/Helpers';

export function isDfill(lineInfo) {
  let isDfil = false;
  if (lineInfo?.length > 0) {
    lineInfo.forEach((line) => {
      if (line.lineActivityType === 'EXC' || line.lineActivityType === 'REX') {
        if (line.itemsInfo && line.itemsInfo.length > 0) {
          line.itemsInfo.forEach((itemInfo) => {
            if (itemInfo.cartItems && itemInfo.cartItems.cartItem) {
              itemInfo.cartItems.cartItem.forEach((item) => {
                if (['ACCESSORY', 'DEVICE'].includes(item.cartItemType) && item.depletionType === 'F') {
                  isDfil = true;
                }
              });
            }
          });
        }
      }
    });
  }
  return isDfil;
}

export const getDiscountAmount = (order) => {
  if (order.cartItemType === 'TRADE_IN') {
    return `${order.type === 'refund' ? '-' : ''}${formatCurrency(order.discAmt ?? '0')}`;
  }
  if (order.sedOfferList?.sedOffer?.[0]?.discAmt) {
    return `${order.type === 'refund' ? '-' : ''}${formatCurrency(order.sedOfferList.sedOffer[0].discAmt)}`;
  }
  return formatCurrency('0');
};

export const getItemCost = (order) => {
  if (order.cartItemType === 'RESTOCKFEE') {
    return order.discountedPrice ? formatCurrency(order.discountedPrice) : formatCurrency(order.itemPrice);
  }
  return order.itemCost ? formatCurrency(order.itemCost) : formatCurrency('0');
};

export const getDownPaymentAmount = (order) => {
  if (order.cartItemType === 'DEVICE' || order.cartItemType === 'ACCESSORY') {
    if (order.downPaymentAmount) {
      return `${order.type === 'refund' ? '-' : ''}${formatCurrency(order.downPaymentAmount)}`;
    }
    return formatCurrency('0');
  }
  return formatCurrency('0');
};
