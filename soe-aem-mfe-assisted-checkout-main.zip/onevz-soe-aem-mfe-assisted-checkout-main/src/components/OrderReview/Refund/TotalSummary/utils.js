import styled from 'styled-components';
import { Body } from '@vds/typography';
import { Col } from '@vds/grids';
import { ListGroup, ListGroupItem } from '@vds/lists';
import { formatCurrency, formatPhoneNumber } from 'onevzsoemfecommon/Helpers/validation';

export const renderElement = (element, style) => (
  <StyledDiv top={style?.top} bottom={style?.bottom}>
    <Body size='medium' color='#000000' bold primitive='h2'>
      {element?.title}
    </Body>
    <span> {formatCurrency(element?.value || 0)}</span>
  </StyledDiv>
);

export const renderEmptyLst = (id) => (
  <Col id={id} size={{ desktop: 6, tablet: 6 }}>
    <ListGroup topLine={false} bottomLine={false} surface='light'>
      <ListGroupItem id='Empty-List' actionElement='none' bottomLine={false} />
      <ListGroupItem id='Empty-List' actionElement='none' bottomLine={false} />
      <ListGroupItem id='Empty-List' actionElement='none' bottomLine={false} />
    </ListGroup>
  </Col>
);

export const renderNumberAndImage = (numbersAndImages) =>
  numbersAndImages.map((currNumberAndImage, i) => {
    const j = `MobileNumber_${i}`;
    return (
      <div key={j} className='u-paddingRightMedium'>
        <img alt='img' style={{ width: '31px', height: '44px' }} src={currNumberAndImage?.miniImage} />
        <div style={{ 'font-size': '9px' }}>
          {currNumberAndImage?.mobileNumber && formatPhoneNumber(currNumberAndImage?.mobileNumber)}
        </div>
      </div>
    );
  });

export const getMobileNumbersForAddress = (addressdata, lineInfoData) => {
  if (!lineInfoData) return [];
  // Filter lines that contain DEVICE or ACCESSORY items
  const linertnData = lineInfoData.filter((line) =>
    line?.itemsInfo?.[0]?.cartItems?.cartItem?.some(
      (item) => item?.cartItemType === 'DEVICE' || item?.cartItemType === 'ACCESSORY',
    ),
  );

  const numbersAndImages = [];

  linertnData.forEach((xlineInfo) => {
    const { mobileNumber } = xlineInfo;
    xlineInfo?.itemsInfo?.forEach((itemInfo) => {
      const {
        shipping: { address },
        cartItems: { cartItem },
      } = itemInfo;
      const miniImage = cartItem[0]?.imageUrlMap?.miniImage;

      if (
        JSON.stringify(address) === JSON.stringify(addressdata) &&
        !numbersAndImages.some((entry) => entry?.mobileNumber === mobileNumber)
      ) {
        numbersAndImages.push({ mobileNumber, miniImage });
      }
    });
  });

  return numbersAndImages;
};

export const getFillteredProps = (lineInfo) => {
  let showDueMonthly = false;
  let showShippingSection = false;
  let showManualPrice = false;
  let isAccFlow;
  let manualPriceCorrection = 0;
  lineInfo.forEach((element) => {
    const cartItem = element?.itemsInfo?.[0]?.cartItems?.cartItem || [];
    const refundCartItem = element?.itemsInfo?.[0]?.refundCartItems?.cartItem || [];
    const accFlow = !refundCartItem.some((item) => item.cartItemType === 'DEVICE');
    isAccFlow = isAccFlow === undefined ? accFlow : isAccFlow && accFlow;
    if (element?.lineActivityType !== 'REF' && element?.lineActivityType !== 'DIS' && !isAccFlow) {
      showDueMonthly = true;
    }
    cartItem.forEach((item) => {
      if (element?.lineActivityType === 'EXC') {
        if (['ACCESSORY', 'DEVICE'].includes(item?.cartItemType) && item?.depletionType === 'F') {
          showShippingSection = true;
        }
      }
      if (item?.itemCode === 'ADJ90081001') {
        showManualPrice = true;
        manualPriceCorrection = item?.itemPrice;
      }
    });
  });

  return {
    showDueMonthly,
    showShippingSection,
    showManualPrice,
    isAccFlow,
    manualPriceCorrection,
  };
};

export const getLineCount = (lineDetails) => {
  let rtnCnt = 0;
  const mtnLevelChargeDetails =
    lineDetails?.subAccountNBSInfo?.[0]?.billAccounts?.[0]?.nbs?.monthlyChargesInfo?.mtnLevelChargeDetails || [];
  const numOfLines = lineDetails?.numOfLines || 0;
  const numofLinesAAL = lineDetails.numofLinesAAL || 0;
  const accCount =
    lineDetails?.lineInfo?.reduce((count, line) => count + (line.lineActivityType === 'ACC' ? 1 : 0), 0) || 0;
  const getActiveMtnCount = mtnLevelChargeDetails?.length;
  const getImpactedLinesCount = numOfLines - numofLinesAAL + accCount;
  rtnCnt = getActiveMtnCount - getImpactedLinesCount;
  return rtnCnt;
};

const StyledDiv = styled.div`
  display: flex;
  padding-top: ${({ top }) => top};
  padding-bottom: ${({ bottom }) => bottom};

  span {
    font-size: 20px;
    font-weight: bold;
    line-height: 18px;
    margin-left: auto;
  }
`;
