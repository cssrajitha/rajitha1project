import { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { Col, Grid, Row } from '@vds/grids';
import { Body } from '@vds/typography';
import { TextLink } from '@vds/buttons';
import { Line } from '@vds/lines';
import { Modal } from '@vds/modals';
import { ListGroup, ListGroupItem, ListGroupItemTitle } from '@vds/lists';
import { formatCurrency } from 'onevzsoemfecommon/Helpers/validation';
import CommonHeader from '../Modals/CommonHeader';
import { MODEL_POPUP } from '../constants';
import ShippingDetails from './ShippingDetail';
import './index.css';
import { getFillteredProps, renderEmptyLst, renderElement, getLineCount } from './utils';
import { OpenViewTagging } from '../../../../utils/tagging';
import ViewAdjustmentModal from './ViewAdjustmentModal';

function TotalSummary(props) {
  const {
    cartOrderDetail,
    refundOrderDetails,
    lineInfo,
    cartType,
    modeOfPay,
    lineDetails,
    originalLines,
    rspFetchReadOrder,
  } = props;
  const [state, setState] = useState({
    showToggle: false,
    showDueMonthly: false,
    showManualPrice: false,
    showShippingSection: false,
    manualPriceCorrection: 0,
    adjustmentModal: false,
    isAccFlow: false,
  });

  const row2_left = [
    { title: 'Original due paid', value: refundOrderDetails?.subTotalDueToday, type: 'type1' },
    { title: 'Total taxes/fees', value: refundOrderDetails?.totalTaxAmount, type: 'type1' },
    { title: 'Original paid total', value: refundOrderDetails?.totalDueToday, type: 'type2' },
  ];

  const row2_right = [
    { title: 'Due today', value: cartOrderDetail?.subTotalDueToday, type: 'type1' },
    { title: 'Total taxes/fees', value: cartOrderDetail?.totalTaxAmount, type: 'type1' },
  ];

  const [modelHeaderName] = useState([
    'Item info',
    'Qty',
    'Price / Unit',
    'Down Payment',
    'Offer Amt',
    'Offer ID',
    'Manual Discount',
    'Reb Ind',
    'Tax',
    'Due Today',
    'Ware House',
  ]);
  const [lineCount, setLineCount] = useState(0);
  const [open, setOpen] = useState(true);
  const [toggle, setToggle] = useState('');

  useEffect(() => {
    if (lineInfo?.length > 0) {
      const { isAccFlow, manualPriceCorrection, showDueMonthly, showManualPrice, showShippingSection } =
        getFillteredProps(lineInfo);
      setState((prev) => ({
        ...prev,
        showDueMonthly,
        showManualPrice,
        showShippingSection,
        isAccFlow: !isAccFlow,
        manualPriceCorrection,
      }));
    }
  }, [lineInfo]);

  useEffect(() => {
    if (lineDetails) {
      const cnt = getLineCount(lineDetails);
      setLineCount(cnt);
    }
  }, [lineDetails]);

  const closeModal = () => {
    setOpen(false);
    setToggle('');
    OpenViewTagging('orderDueToday', 'Done', 'EUP|RFEX-read-order', 'orderReview', rspFetchReadOrder);
  };

  const openAdjustedModal = () => {
    setOpen(true);
    setToggle('viewadjustedmodal');
  };

  const openOriginalModal = () => {
    setOpen(true);
    setToggle('vieworiginalmodal');
  };

  const renderTextLink = (linkName, id) => (
    <Col id={id} size={{ desktop: 6, tablet: 6 }}>
      <TextLink
        type='standAlone'
        size='large'
        data-testid={`view${id}`}
        onClick={() => {
          if (id?.includes('left')) {
            openOriginalModal();
            OpenViewTagging('orderDueToday', 'View', 'EUP|RFEX-read-order', 'orderReview', rspFetchReadOrder);
          } else {
            openAdjustedModal();
            OpenViewTagging('orderDueToday', 'View', 'EUP|RFEX-read-order', 'orderReview', rspFetchReadOrder);
          }
        }}
      >
        {linkName}
      </TextLink>
      <StyledLine type='secondary' />
    </Col>
  );

  const renderRow2 = (lst) => (
    <ListGroup topLine={false} bottomLine={false} surface='light'>
      {lst?.map((element, index) => {
        const k = `row2-${index}`;
        return (
          <ListGroupItem
            key={k}
            id={element.type}
            actionElement='textLink'
            bottomLine={false}
            textLink={{
              text: formatCurrency(element?.value || 0),
              role: 'button',
            }}
          >
            <ListGroupItemTitle bold>{element?.title}</ListGroupItemTitle>
          </ListGroupItem>
        );
      })}
    </ListGroup>
  );

  return (
    <div id='TotalSummary' data-testid='TotalSummary'>
      <StyledGridContainer bleed='1272' colSizes={{ desktop: 6, tablet: 6 }}>
        <Row>
          <Col id='head_left' size={{ desktop: 6, tablet: 6 }}>
            <Body id='gridHead' size='medium' color='#000000' bold primitive='h2'>
              Total
            </Body>
            <TextLink
              type='standAlone'
              size='small'
              data-testid={state.showToggle ? 'HideToggle' : 'ShowToggle'}
              data-track={state.showToggle ? 'hideOriginalTotal' : 'viewOriginalTotal'}
              onClick={() => {
                setState((prev) => ({ ...prev, showToggle: !prev.showToggle }));
              }}
            >
              {state.showToggle ? 'Hide Original Total' : 'View Original Total'}
            </TextLink>
          </Col>
          <Col id='head_right' size={{ desktop: 6, tablet: 6 }} />
        </Row>
        <Row>
          {state.showToggle && (
            <Col id='col1_left' size={{ desktop: 6, tablet: 6 }}>
              {state.showDueMonthly && (
                <ListGroup topLine={false} bottomLine={false} surface='light'>
                  <ListGroupItem
                    id='type1'
                    actionElement='textLink'
                    bottomLine={false}
                    textLink={{
                      text: formatCurrency(cartOrderDetail?.subTotalDueMonthlyOnProfile || 0),
                      role: 'button',
                    }}
                  >
                    <ListGroupItemTitle bold>Due Monthly</ListGroupItemTitle>
                  </ListGroupItem>
                  {lineCount > 0 ? (
                    <ListGroupItem
                      id='type1'
                      bottomLine={false}
                      actionElement='textLink'
                      textLink={{
                        text: formatCurrency(cartOrderDetail?.subTotalOtherLinesOnProfile || 0),
                        role: 'button',
                      }}
                    >
                      <ListGroupItemTitle bold>Charges for other {lineCount} lines</ListGroupItemTitle>
                    </ListGroupItem>
                  ) : (
                    <ListGroupItem id='no-data' actionElement='none' bottomLine={false} />
                  )}
                  <ListGroupItem
                    id='type1'
                    actionElement='textLink'
                    bottomLine={false}
                    textLink={{
                      text: formatCurrency(cartOrderDetail?.totalMonthlyTaxesOnProfile || 0),
                      role: 'button',
                    }}
                  >
                    <ListGroupItemTitle bold>Total taxes/fees</ListGroupItemTitle>
                  </ListGroupItem>
                  <ListGroupItem
                    id='type2'
                    actionElement='textLink'
                    bottomLine={false}
                    textLink={{
                      text: formatCurrency(cartOrderDetail?.totalDueMonthlyOnProfile || 0),
                      role: 'button',
                    }}
                  >
                    <ListGroupItemTitle bold>Original due monthly</ListGroupItemTitle>
                  </ListGroupItem>
                </ListGroup>
              )}
            </Col>
          )}
          {!state.showToggle && renderEmptyLst('col1_left')}
          <Col id='col1_right' size={{ desktop: 6, tablet: 6 }}>
            <ListGroup topLine={false} bottomLine={false} surface='light'>
              {state.showManualPrice ? (
                <ListGroupItem
                  id='type1'
                  actionElement='textLink'
                  bottomLine={false}
                  textLink={{
                    text: formatCurrency(state.manualPriceCorrection || 0),
                    role: 'button',
                  }}
                >
                  <ListGroupItemTitle bold>Manual Price Correction</ListGroupItemTitle>
                </ListGroupItem>
              ) : (
                <ListGroupItem id='no-data' actionElement='none' bottomLine={false} />
              )}
              {state.showDueMonthly && state.isAccFlow ? (
                <ListGroupItem
                  id='type1'
                  actionElement='textLink'
                  bottomLine={false}
                  textLink={{
                    text: formatCurrency(cartOrderDetail?.subTotalDueMonthly?.toString() || 0),
                    role: 'button',
                  }}
                >
                  <ListGroupItemTitle bold>Due Monthly</ListGroupItemTitle>
                </ListGroupItem>
              ) : (
                <ListGroupItem id='no-data' actionElement='none' bottomLine={false} />
              )}
              {state.showDueMonthly && state.isAccFlow && lineCount > 0 ? (
                <ListGroupItem
                  id='type1'
                  actionElement='textLink'
                  bottomLine={false}
                  textLink={{
                    text: formatCurrency(cartOrderDetail?.subTotalOtherLines?.toString() || 0),
                    role: 'button',
                  }}
                >
                  <ListGroupItemTitle bold>Charges for other {lineCount} lines</ListGroupItemTitle>
                </ListGroupItem>
              ) : (
                <ListGroupItem id='no-data' actionElement='none' bottomLine={false} />
              )}
              {state.showDueMonthly && state.isAccFlow ? (
                <ListGroupItem
                  id='type1'
                  actionElement='textLink'
                  bottomLine={false}
                  textLink={{
                    text: formatCurrency(cartOrderDetail?.totalMonthlyTaxes || 0),
                    role: 'button',
                  }}
                >
                  <ListGroupItemTitle bold>Total taxes/fees</ListGroupItemTitle>
                </ListGroupItem>
              ) : (
                <ListGroupItem id='no-data' actionElement='none' bottomLine={false} />
              )}
              {state.showDueMonthly && state.isAccFlow ? (
                <ListGroupItem
                  id='type2'
                  actionElement='textLink'
                  bottomLine={false}
                  textLink={{
                    text: formatCurrency(cartOrderDetail?.totalDueMonthly?.toString() || 0),
                    role: 'button',
                  }}
                >
                  <ListGroupItemTitle bold>Adjusted due monthly</ListGroupItemTitle>
                </ListGroupItem>
              ) : (
                <ListGroupItem id='no-data' actionElement='none' bottomLine={false} />
              )}
            </ListGroup>
          </Col>
        </Row>
        {cartOrderDetail?.totalAdjustmentAmount > 0 && (
          <Row>
            <Col id='col4_left' size={{ desktop: 6, tablet: 6 }} />
            <Col id='col4_right' size={{ desktop: 6, tablet: 6 }}>
              {renderElement(
                { title: 'Original item adjustments', value: cartOrderDetail?.totalAdjustmentAmount },
                { top: '0.875rem', bottom: '0.4375rem' },
              )}
              <TextLink
                type='standAlone'
                size='small'
                data-testid='viewAdjustment'
                data-track='view_Original item adjustment'
                onClick={() => {
                  OpenViewTagging(
                    'Recalculated original charges',
                    '',
                    'EUP|RFEX-read-order',
                    'orderReview',
                    rspFetchReadOrder,
                  );
                  setState((prev) => ({ ...prev, adjustmentModal: true }));
                }}
              >
                View
              </TextLink>
            </Col>
          </Row>
        )}
        <Row>
          {state.showToggle && (
            <Col id='col2_left' size={{ desktop: 6, tablet: 6 }}>
              {renderRow2(row2_left)}
            </Col>
          )}
          {!state.showToggle && renderEmptyLst('col2_left')}
          <Col id='col2_right' size={{ desktop: 6, tablet: 6 }}>
            {renderRow2(row2_right)}
            {state.showShippingSection && <ShippingDetails cartOrderDetail={cartOrderDetail} lineInfo={lineInfo} />}
            {renderElement(
              { title: 'Adjusted due today', value: cartOrderDetail?.totalDueToday },
              { top: '0.875rem', bottom: '0.4375rem' },
            )}
          </Col>
        </Row>
        <Row>
          {renderTextLink('View', 'col3_left')}
          {renderTextLink('View', 'col3_right')}
        </Row>
        <Row>
          <Col id='col5_left' size={{ desktop: 6, tablet: 6 }}>
            {state.showDueMonthly &&
              renderElement(
                { title: 'Original Next Bill Total', value: cartOrderDetail?.estimatedNextMonthChargeOnProfile },
                { top: '0.875rem', bottom: '0.4375rem' },
              )}
            <StyledDivInfo>
              {cartType === 'GAMINGCONSOLE' && modeOfPay === 'AF'
                ? 'After your return is processed, your Affirm account will be credited appropriately. If you have already made payments to Affirm for Xbox All Access, you will receive a refund for the amount that has been paid.'
                : '*These charges are going to be applied at the next bill cycle'}
            </StyledDivInfo>
          </Col>
          <Col id='col5_right' size={{ desktop: 6, tablet: 6 }}>
            {state.showDueMonthly &&
              renderElement(
                { title: 'Adjusted  Next Bill Total', value: cartOrderDetail?.estimatedNextMonthCharge },
                { top: '0.875rem', bottom: '0.4375rem' },
              )}
          </Col>
        </Row>
      </StyledGridContainer>

      {/* Modal */}
      {state.adjustmentModal && (
        <Modal
          opened={state.adjustmentModal}
          fullScreenDialog
          closeButton={null}
          disableAnimation={false}
          disableOutsideClick
        >
          <ViewAdjustmentModal
            lineInfo={lineInfo}
            closeModal={() => {
              setState((prev) => ({ ...prev, adjustmentModal: false }));
            }}
          />
        </Modal>
      )}
      {toggle === 'viewadjustedmodal' && (
        <Modal
          className='view adjusted modal'
          surface='light'
          disableAnimation={false}
          disableOutsideClick
          fullScreenDialog
          width='100%'
          ariaLabel='Adjusted modal'
          opened={open}
          onOpenedChange={(opened) => !opened && setOpen(false)}
          closeButton={null}
        >
          <CommonHeader
            lineInfo={lineInfo}
            ModelName={MODEL_POPUP.ADJUSTED_DUE_TODAY}
            modelHeaderName={modelHeaderName}
            lineDetails={lineDetails}
            closeModal={closeModal}
          />
        </Modal>
      )}

      {toggle === 'vieworiginalmodal' && (
        <Modal
          className='view original modal'
          surface='light'
          disableAnimation={false}
          disableOutsideClick
          fullScreenDialog
          width='100%'
          ariaLabel='Original modal'
          opened={open}
          onOpenedChange={(opened) => !opened && setOpen(false)}
          closeButton={null}
        >
          <CommonHeader
            lineInfo={lineInfo}
            ModelName={MODEL_POPUP.ORGINAL_PAID}
            modelHeaderName={modelHeaderName}
            lineDetails={lineDetails}
            closeModal={closeModal}
            originalLines={originalLines}
          />
        </Modal>
      )}
    </div>
  );
}

TotalSummary.propTypes = {
  cartOrderDetail: PropTypes.object,
  refundOrderDetails: PropTypes.object,
  cartType: PropTypes.string,
  modeOfPay: PropTypes.string,
  lineInfo: PropTypes.any,
  lineDetails: PropTypes.any,
  originalLines: PropTypes.any,
  rspFetchReadOrder: PropTypes.object,
};

export default TotalSummary;

const StyledGridContainer = styled(Grid)`
  border-top: 2px solid #000;
`;
const StyledLine = styled(Line)`
  margin-top: 0.4375rem;
`;

const StyledDivInfo = styled.div`
  font-size: 12px;
  padding-botton: 100px;
  padding-top: 1.75rem;
`;
