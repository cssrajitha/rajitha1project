import { fireEvent, render, screen } from '../../../../utils/test-utils/renderHelper';
import { rootSaga } from '../../../../modules/store/saga';
import rootReducer from '../../../../modules/store/reducer';
import TotalSummary from '.';

jest.mock('@vds/modals', () => ({
  ...jest.requireActual('@vds/modals'),
  // eslint-disable-next-line react/button-has-type, react/prop-types
  Modal: ({ children, ...props }) => (
    // eslint-disable-next-line react/prop-types
    <div {...props} data-testid={props.id}>
      {children}
    </div>
  ),
}));

jest.mock('./ViewAdjustmentModal', () =>
  // eslint-disable-next-line react/button-has-type, react/prop-types
  ({ closeModal }) => {
    closeModal();
    return <div data-testid='ViewAdjustmentModal'>viewAdjustmentmodal</div>;
  },
);
jest.mock('../../../../utils/tagging');
const mockOpenViewTag = jest.fn();
const mockLineDetails = {
  subAccountNBSInfo: [
    {
      billAccounts: [
        {
          nbs: {
            monthlyChargesInfo: {
              mtnLevelChargeDetails: [{ charge: 10 }, { charge: 20 }],
            },
          },
        },
      ],
    },
  ],
  numOfLines: 5,
  numofLinesAAL: 2,
  lineInfo: [{ lineActivityType: 'ACC' }, { lineActivityType: 'NON_ACC' }, { lineActivityType: 'ACC' }],
};

const mockProps = {
  cartOrderDetail: {
    subTotalDueToday: 100.0,
    totalTaxAmount: 10.0,
    totalDueToday: 110.0,
    subTotalDueMonthlyOnProfile: 50.0,
    subTotalOtherLinesOnProfile: null,
    totalMonthlyTaxesOnProfile: 5.0,
    totalDueMonthlyOnProfile: 75.0,
    subTotalDueMonthly: 50.0,
    subTotalOtherLines: null,
    totalMonthlyTaxes: 5.0,
    totalDueMonthly: 75.0,
    totalAdjustmentAmount: 15.0,
    estimatedNextMonthChargeOnProfile: 80.0,
    estimatedNextMonthCharge: 70.0,
  },
  refundOrderDetails: {
    subTotalDueToday: 90.0,
    totalTaxAmount: 9.0,
    totalDueToday: 99.0,
  },
  lineInfo: [
    {
      lineActivityType: 'EXC',
      itemsInfo: [
        {
          cartItems: {
            cartItem: [{ cartItemType: 'ACCESSORY', depletionType: 'F', itemCode: 'ADJ90081001', itemPrice: null }],
          },
          refundCartItems: {
            cartItem: [{ cartItemType: 'DEVICE' }],
          },
        },
      ],
    },
    {
      lineActivityType: 'REF',
      itemsInfo: [
        {
          cartItems: {
            cartItem: [{ cartItemType: 'ACCESSORY', depletionType: 'F', itemCode: 'ADJ90081001', itemPrice: null }],
          },
          refundCartItems: {
            cartItem: [{ cartItemType: 'DEVICE' }],
          },
        },
      ],
    },
    {
      lineActivityType: 'EXC',
      itemsInfo: [
        {
          cartItems: {
            cartItem: [{ cartItemType: 'ACCESSORY', depletionType: '', itemCode: 'ADJ90081000', itemPrice: null }],
          },
          refundCartItems: {
            cartItem: [{ cartItemType: 'DEVICE' }],
          },
        },
      ],
    },
  ],
  lineDetails: mockLineDetails,
  cartType: 'GAMINGCONSOLE',
  modeOfPay: 'AF',
  lineCount: 2,
  openViewTag: mockOpenViewTag,
};
describe('TotalSummary', () => {
  beforeEach(() => {
    jest.spyOn(console, 'error').mockImplementation(() => {});
    jest.spyOn(console, 'warn').mockImplementation(() => {});
  });
  test('should render TotalSummary component', async () => {
    render(<TotalSummary {...mockProps} />, {
      initialState: {},
      reducers: rootReducer,
      sagas: rootSaga,
    });
    expect(screen.getByTestId('TotalSummary')).toBeInTheDocument();
    // show Toggle
    fireEvent.click(
      screen.getByRole('link', {
        name: /view original total/i,
      }),
    );
    // hide Toggle
    fireEvent.click(
      screen.getByRole('link', {
        name: /hide original total/i,
      }),
    );
    // view AdjustmentModal
    fireEvent.click(screen.getByTestId('viewAdjustment'));
  });
  test('should render TotalSummary component >> View Link', async () => {
    const props = {
      ...mockProps,
      lineDetails: {},
      modeOfPay: 'test',
      cartOrderDetail: {},
      refundOrderDetails: {
        subTotalDueToday: null,
        totalTaxAmount: 9.0,
        totalDueToday: 99.0,
      },
      lineCount: 0,
    };
    render(<TotalSummary {...props} />, {
      initialState: {},
      reducers: rootReducer,
      sagas: rootSaga,
    });
    expect(screen.getByTestId('TotalSummary')).toBeInTheDocument();
    // show Toggle
    fireEvent.click(
      screen.getByRole('link', {
        name: /view original total/i,
      }),
    );
    fireEvent.click(screen.getByTestId('viewcol3_left'));
    fireEvent.click(screen.getByTestId('viewcol3_right'));
  });
  test('should render TotalSummary component >> ShippingDetail >> Edit', async () => {
    render(<TotalSummary {...mockProps} />, {
      initialState: {},
      reducers: rootReducer,
      sagas: rootSaga,
    });
    expect(screen.getByTestId('TotalSummary')).toBeInTheDocument();
    fireEvent.click(
      screen.getByRole('link', {
        name: /edit/i,
      }),
    );
  });
  test('should render with emoty cart & refund exchange', async () => {
    render(<TotalSummary lineInfo={[{ itemsInfo: [] }]} />, {
      initialState: {},
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should render with emoty props', async () => {
    render(<TotalSummary />, {
      initialState: {},
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
});
