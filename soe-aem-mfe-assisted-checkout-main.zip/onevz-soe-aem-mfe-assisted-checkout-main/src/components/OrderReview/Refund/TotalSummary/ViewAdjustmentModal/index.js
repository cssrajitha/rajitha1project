import { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { isIpad } from 'onevzsoemfeframework/DomService';
import { Col, Grid, Row } from '@vds/grids';
import { Body, Title } from '@vds/typography';
import { Button } from '@vds/buttons';
import { ModalBody, ModalTitle } from '@vds/modals';
import ModalHeader from '../../../../ReadOrder/common/ModalHeader';
import { formatCurrency, formatMtnWithDecimals } from '../../../../../utils/common';

function ViewAdjustmentModal({ lineInfo, closeModal }) {
  const [displayData, setDisplayData] = useState([]);

  useEffect(() => {
    const lstData = [];

    lineInfo?.forEach((line) => {
      line.itemsInfo?.forEach((itemInfo) => {
        const cartItems = itemInfo.cartItems?.cartItem || [];
        const refundCartItems = itemInfo.refundCartItems?.cartItem || [];

        [...cartItems, ...refundCartItems].forEach((item) => {
          const obj = { ...item };
          if (+item.adjustmentAmount > 0.0) {
            obj.mobileNumber = line.mobileNumber;
            lstData.push(obj);
          }
        });
      });
    });
    setDisplayData(lstData);
  }, []);

  const getModalContent = (item, k) => {
    const mobileNumber = (formatMtnWithDecimals(item?.mobileNumber) && item?.mobileNumber) || '';
    return (
      <StyledRow key={k}>
        <Col
          colSizes={{
            tablet: 2,
            desktop: 2,
          }}
        >
          <StyledDivLeft>
            <img className='popup-device-image' src={item?.imageUrlMap?.defaultImage} alt='img' />
          </StyledDivLeft>
        </Col>
        <Col
          colSizes={{
            tablet: 10,
            desktop: 10,
          }}
        >
          <StyledDivRight>
            <Title id='mobileNumber_info' bold>
              {mobileNumber}
            </Title>
            <div>
              <div
                id='cart_description'
                dangerouslySetInnerHTML={{
                  __html: `${item?.deviceDisplayName || ''}`,
                }}
              />
              <Body id='price_info'>Original price: {formatCurrency(item?.itemPrice || 0)}</Body>
              <Body id='price_info'>Adj amont: {formatCurrency(item?.adjustmentAmount)}</Body>
              <Body id='price_info'>Final price: {formatCurrency(item?.itemPrice || 0)}</Body>
            </div>
          </StyledDivRight>
        </Col>
      </StyledRow>
    );
  };

  return (
    <div data-testid='viewAdjustmentModal'>
      <ModalTitle>
        <ModalHeader modalTitle='Recalculated original charges' isOnlyClose closeModal={closeModal} />
      </ModalTitle>
      <ModalBody>
        <Grid bleed='full' rowGutter='5px'>
          {displayData?.map((item, index) => {
            const k = `ViewAdjustmentModal_${index}`;
            return getModalContent(item, k);
          })}
        </Grid>
        <div style={{ height: '8vh' }} />
      </ModalBody>
      <FixedFooter bottom={isIpad() ? '25px' : '0px'}>
        <CenteredBox>
          <Button use='primary' onClick={closeModal}>
            Done
          </Button>
        </CenteredBox>
      </FixedFooter>
    </div>
  );
}

ViewAdjustmentModal.propTypes = {
  lineInfo: PropTypes.array,
  closeModal: PropTypes.func,
};

export default ViewAdjustmentModal;

const StyledDivLeft = styled.div`
  .popup-device-image {
    padding: 0px 20px 0px 0px;
    width: 140px;
    height: 220px;
  }
`;
const StyledDivRight = styled.div`
  padding-left: 0.875rem !important;
  #mobileNumber_info {
    font-size: 24px;
    line-height: 22px;
    color: #0088ce;
    padding-bottom: 1.3125rem !important;
    padding-top: 1.75rem !important;
  }
  #cart_description {
    font-size: 24px;
    line-height: 22px;
    padding-bottom: 0.4375rem !important;
    font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
    font-weight: bold;
  }
  #price_info {
    line-height: 22px;
    padding-top: 0.4375rem !important;
    padding-bottom: 0.4375rem !important;
    font-size: 20px;
  }
`;

const StyledRow = styled(Row)`
  width: 100%;
  overflow: auto;
  padding: 1.3125rem 36px 1.75rem 36px;
  margin-left: 0px !important;
`;

const FixedFooter = styled.footer`
  position: fixed;
  bottom: ${(opt) => opt?.bottom};
  text-align: center;
  width: 100%;
  border-top: 1px solid #d8dada !important;
  left: 0;
  right: 0;
  display: inline-flex;
  background-color: #fff;
  z-index: 1;
`;
const CenteredBox = styled.div`
  margin: auto;
  padding: 21px;
`;
