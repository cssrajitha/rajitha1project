import { isIpad } from 'onevzsoemfeframework/DomService';
import { fireEvent, render, screen } from '../../../../../utils/test-utils/renderHelper';
import { rootSaga } from '../../../../../modules/store/saga';
import rootReducer from '../../../../../modules/store/reducer';
import ViewAdjustmentModal from '.';

jest.mock('onevzsoemfeframework/DomService', () => ({
  isIpad: jest.fn(),
}));

const mockProps = {
  lineInfo: [
    {
      itemsInfo: [
        {
          cartItems: {
            cartItem: [
              {
                adjustmentAmount: 10,
                mobileNumber: 3313431007,
                imageUrlMap: {
                  defaultImage: 'image',
                },
                deviceDisplayName: 'device',
                itemPrice: 100,
              },
              {
                adjustmentAmount: 0,
                mobileNumber: null,
                imageUrlMap: {
                  defaultImage: null,
                },
                deviceDisplayName: null,
                itemPrice: null,
              },
            ],
          },
          refundCartItems: {
            cartItem: [
              {
                adjustmentAmount: 10,
                mobileNumber: 9087654321,
                imageUrlMap: {
                  defaultImage: 'image',
                },
                deviceDisplayName: 'device',
                itemPrice: 100,
              },
              {
                adjustmentAmount: 10,
                mobileNumber: null,
                imageUrlMap: {
                  defaultImage: null,
                },
                deviceDisplayName: null,
                itemPrice: null,
              },
            ],
          },
        },
      ],
    },
  ],
  closeModal: jest.fn(),
};

describe('ViewAdjustmentModal', () => {
  beforeEach(() => {
    jest.spyOn(console, 'error').mockImplementation(() => {});
    jest.spyOn(console, 'warn').mockImplementation(() => {});
  });
  test('should render View device modal component', async () => {
    isIpad.mockReturnValue(true);
    render(<ViewAdjustmentModal {...mockProps} />, {
      initialState: {},
      reducers: rootReducer,
      sagas: rootSaga,
    });
    const done = screen.getByRole('button', {
      name: /done/i,
    });
    expect(screen.getByTestId('viewAdjustmentModal')).toBeInTheDocument();
    fireEvent.click(done);
  });
  test('should render View device modal component', async () => {
    isIpad.mockReturnValue(false);
    render(
      <ViewAdjustmentModal
        closeModal={jest.fn()}
        lineInfo={[
          {
            itemsInfo: [
              {
                cartItems: { cartItem: null },
                refundCartItems: { cartItem: null },
              },
            ],
          },
        ]}
      />,
      {
        initialState: {},
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });
});
