import { fireEvent, render, screen } from '../../../../../utils/test-utils/renderHelper';
import { rootSaga } from '../../../../../modules/store/saga';
import rootReducer from '../../../../../modules/store/reducer';
import ShippingDetails from '.';
import { getMobileNumbersForAddress } from '../utils';

const mockProps = {
  cartOrderDetail: {
    totalShippingCost: 15.0,
    splitShipmentIndicator: true,
  },
  lineInfo: [
    {
      lineActivityType: 'ACC',
      mobileNumber: '1234567890',
      itemsInfo: [
        {
          shipping: {
            address: null,
            agentAddress: {
              customerName: 'Jane Smith',
              firstName: 'Jane',
              lastName: 'Smith',
              addressLine1: '789 Agent Ave',
              streetNumber: '789',
              streetName: 'Agent Ave',
              aptNum: null,
              apartmentNo: '101',
              city: 'Agent City',
              state: 'NY',
              zipCode: '10001',
              phoneNumber: '0987654321',
            },
            shippingDescription: null,
          },
          cartItems: {
            cartItem: [
              {
                cartItemType: 'DEVICE',
                imageUrlMap: {
                  miniImage: 'http://example.com/device.jpg',
                },
                mobileNumber: '1234567890',
                depletionType: 'F',
              },
            ],
          },
        },
      ],
    },
  ],
};

const mockProps1 = {
  cartOrderDetail: {
    totalShippingCost: 15.0,
    splitShipmentIndicator: true,
  },
  lineInfo: [
    {
      lineActivityType: 'ACC',
      mobileNumber: '1234567890',
      itemsInfo: [
        {
          shipping: {
            address: {
              firmName: 'Tech Corp',
              customerName: 'John Doe',
              firstName: 'John',
              lastName: 'Doe',
              addressLine1: '123 Tech Street',
              streetNumber: '123',
              streetName: 'Tech Street',
              aptNum: '456',
              apartmentNo: '456',
              city: 'Tech City',
              state: 'CA',
              zipCode: '90001',
              phoneNumber: '1234567890',
            },
            agentAddress: null,
            shippingDescription: null,
          },
          cartItems: {
            cartItem: [
              {
                cartItemType: 'DEVICE',
                imageUrlMap: {
                  miniImage: 'http://example.com/device.jpg',
                },
                mobileNumber: null,
                depletionType: 'F',
              },
            ],
          },
        },
        {
          shipping: {
            address: {
              firmName: 'Tech Corp1',
              customerName: 'John Doe1',
              firstName: 'John1',
              lastName: 'Doe1',
              addressLine1: '123 Tech Street1',
              streetNumber: '1231',
              streetName: 'Tech Street1',
              aptNum: '456',
              apartmentNo: '456',
              city: 'Tech City',
              state: 'CA',
              zipCode: '90001',
              phoneNumber: '1234567890',
            },
            agentAddress: null,
            shippingDescription: null,
          },
          cartItems: {
            cartItem: [
              {
                cartItemType: 'ACCESSORY',
                imageUrlMap: {
                  miniImage: 'http://example.com/device.jpg',
                },
                mobileNumber: '1234567890',
                depletionType: 'F',
              },
            ],
          },
        },
      ],
    },
  ],
};

const mockProps2 = {
  cartOrderDetail: {
    totalShippingCost: 15.0,
    splitShipmentIndicator: true,
  },
  lineInfo: [
    {
      lineActivityType: 'ACC',
      mobileNumber: '1234567890',
      itemsInfo: [
        {
          shipping: {
            address: {
              type: 'B',
              firmName: null,
              customerName: null,
              firstName: null,
              lastName: null,
              addressLine1: null,
              streetNumber: '123',
              streetName: 'Tech Street',
              aptNum: null,
              apartmentNo: '456',
              city: null,
              state: null,
              zipCode: null,
              phoneNumber: '1234567890',
            },
            agentAddress: null,
            shippingDescription: null,
          },
          cartItems: {
            cartItem: [
              {
                cartItemType: 'DEVICE',
                imageUrlMap: {
                  miniImage: 'http://example.com/device.jpg',
                },
                mobileNumber: null,
                depletionType: 'F',
              },
            ],
          },
        },
      ],
    },
  ],
};

describe('TotalSummary', () => {
  beforeEach(() => {
    jest.spyOn(console, 'error').mockImplementation(() => {});
    jest.spyOn(console, 'warn').mockImplementation(() => {});
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ refundReadOrderMfeFFlag: 'TRUE' }));
  });

  test('should render  shippingDetails', async () => {
    render(<ShippingDetails {...mockProps} />, {
      initialState: {},
      reducers: rootReducer,
      sagas: rootSaga,
    });
    fireEvent.click(screen.getByTestId('shippingDetailsLink'));
  });
  test('should render  shippingDetails', async () => {
    render(<ShippingDetails {...mockProps1} />, {
      initialState: {},
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should render  shippingDetails', async () => {
    render(<ShippingDetails {...mockProps2} />, {
      initialState: {},
      reducers: rootReducer,
      sagas: rootSaga,
    });
    fireEvent.click(
      screen.getByRole('link', {
        name: /edit/i,
      }),
    );
  });
  test('should render  shippingDetails with empty props', async () => {
    render(<ShippingDetails />, {
      initialState: {},
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('utils getMobileNumbersForAddress', async () => {
    const mockAddressData = {
      type: 'B',
      firmName: 'Tech Corp',
      customerName: 'John Doe',
      firstName: 'John',
      lastName: 'Doe',
      addressLine1: '123 Tech Street',
      streetNumber: '123',
      streetName: 'Tech Street',
      aptNum: '456',
      apartmentNo: '456',
      city: 'Tech City',
      state: 'CA',
      zipCode: '90001',
      phoneNumber: '1234567890',
    };
    const mockLineInfoData = [
      {
        mobileNumber: '1234567890',
        itemsInfo: [
          {
            shipping: {
              address: {
                type: 'B',
                firmName: 'Tech Corp',
                customerName: 'John Doe',
                firstName: 'John',
                lastName: 'Doe',
                addressLine1: '123 Tech Street',
                streetNumber: '123',
                streetName: 'Tech Street',
                aptNum: '456',
                apartmentNo: '456',
                city: 'Tech City',
                state: 'CA',
                zipCode: '90001',
                phoneNumber: '1234567890',
              },
            },
            cartItems: {
              cartItem: [
                {
                  cartItemType: 'ACCESSORY',
                  imageUrlMap: {
                    miniImage: 'http://example.com/device.jpg',
                  },
                },
              ],
            },
          },
        ],
      },
      {
        mobileNumber: '1234567890',
        itemsInfo: [
          {
            shipping: {
              address: {
                type: 'B',
                firmName: 'Tech Corp',
                customerName: 'John Doe',
                firstName: 'John',
                lastName: 'Doe',
                addressLine1: '123 Tech Street',
                streetNumber: '123',
                streetName: 'Tech Street',
                aptNum: '456',
                apartmentNo: '456',
                city: 'Tech City',
                state: 'CA',
                zipCode: '90001',
                phoneNumber: '1234567890',
              },
            },
            cartItems: {
              cartItem: [
                {
                  cartItemType: 'DEVICE',
                  imageUrlMap: {
                    miniImage: 'http://example.com/device.jpg',
                  },
                },
              ],
            },
          },
        ],
      },
    ];
    const result = getMobileNumbersForAddress(mockAddressData, mockLineInfoData);
    expect(result).toEqual([{ mobileNumber: '1234567890', miniImage: 'http://example.com/device.jpg' }]);
    const nonMatchingAddress = { ...mockAddressData, zipCode: '99999' };
    const result1 = getMobileNumbersForAddress(nonMatchingAddress, mockLineInfoData);
    expect(result1).toEqual([]);
    expect(getMobileNumbersForAddress(mockAddressData, null)).toEqual([]);
    expect(getMobileNumbersForAddress(mockAddressData, undefined)).toEqual([]);
  });
});
