import { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { TextLink } from '@vds/buttons';
import { Icon } from '@vds/icons';
import { Body } from '@vds/typography';
import { getUIContextPath } from 'onevzsoemfecommon/Helpers/common_functions';
import { formatPhoneNumber } from 'onevzsoemfecommon/Helpers/validation';
import { getCamelCaseName } from '../../../../../utils/common';
import { getMobileNumbersForAddress, renderElement, renderNumberAndImage } from '../utils';

function ShippingDetails(props) {
  const { cartOrderDetail, lineInfo } = props;
  const [uniqueShippingAddress, setUniqueShippingAddress] = useState([]);
  const [uniqueAgentAddress, setUniqueAgentAddress] = useState([]);
  const agentAddress = lineInfo?.[0]?.itemsInfo?.[0]?.shipping?.agentAddress;
  const isAgentAddressFlag = agentAddress && Object.keys(agentAddress).length > 0;
  let shippingUrl = `${getUIContextPath()}/shipping-details.html?isRfexFlow=Y`;
  shippingUrl = shippingUrl.replace('/refundexchange', '');

  useEffect(() => {
    if (lineInfo?.length > 0) {
      const lineInfoData = lineInfo?.filter(
        (line) => line?.lineActivityType === 'EXC' || line?.lineActivityType === 'ACC',
      );
      const lst = [];
      const agentLst = [];
      if (
        lineInfoData?.[0]?.itemsInfo?.[0]?.shipping?.address ||
        (isAgentAddressFlag && lineInfoData?.[0]?.itemsInfo?.[0]?.shipping?.agentAddress)
      ) {
        lineInfoData.forEach((i) => {
          const itemInfo = i?.itemsInfo;
          itemInfo.forEach((item) => {
            const obj = {
              address: item?.shipping?.address,
              shippingDescription: item?.shipping?.shippingDescription || '',
            };
            lst.push(JSON.stringify(obj));
            if (isAgentAddressFlag) {
              const agentObj = {
                address: item?.shipping?.agentAddress,
                shippingDescription: item?.shipping?.shippingDescription || '',
              };
              agentLst.push(JSON.stringify(agentObj));
            }
          });
        });
      }
      const uniqShipAddress = [...new Set(lst)];
      const uniqAgentAddress = [...new Set(agentLst)];
      setUniqueShippingAddress(uniqShipAddress);
      setUniqueAgentAddress(uniqAgentAddress);
    }
  }, [lineInfo]);

  const renderShippingAddress = (uniqueLst) =>
    uniqueLst.map((uniqaddress, index, arr) => {
      const k = `ShippingList_${index}`;
      const { address, shippingDescription } = JSON.parse(uniqaddress);
      return (
        <div key={k} className='u-paddingTopMedium'>
          {renderAddressUI(address, shippingDescription, arr)}
        </div>
      );
    });

  const renderAddressUI = (address, shippingDescription, arr) => {
    const lineInfoData = lineInfo?.filter(
      (line) => line?.lineActivityType === 'EXC' || line?.lineActivityType === 'ACC',
    );
    const numbersAndImages = arr.length > 1 && getMobileNumbersForAddress(address, lineInfoData);

    return (
      <>
        {arr?.length > 1 && renderNumberAndImage(numbersAndImages)}
        <div>
          {(address?.type === 'B' && address?.firmName) ||
            (isAgentAddressFlag && address?.customerName) ||
            `${address?.firstName || ' '}  ${address?.lastName || ''}`}
        </div>
        <div>
          {address?.addressLine1
            ? getCamelCaseName(address?.addressLine1)
            : `${address?.streetNumber} ${getCamelCaseName(address?.streetName)}`}{' '}
        </div>
        <div>
          {(address?.aptNum || address?.apartmentNo) &&
            !isAgentAddressFlag &&
            `${address?.type === 'B' ? 'Suite' : 'Apt'}  ${getCamelCaseName(address?.aptNum || address?.apartmentNo)}`}
          {(address?.aptNum || address?.apartmentNo) &&
            isAgentAddressFlag &&
            `Apt  ${getCamelCaseName(address?.aptNum || address?.apartmentNo)}`}
        </div>
        <div>
          <span>{getCamelCaseName(address?.city || '')} </span>
          <span>{address?.state || ''} </span>
          <span>{address?.zipCode || ''} </span>
          <div>{formatPhoneNumber(address?.phoneNumber)} </div>
        </div>
        <div className='Col u-text15 u-paddingTopMedium'> {shippingDescription}</div>
      </>
    );
  };
  return (
    <div id='shippingDetail' data-testid='shippingDetails'>
      {renderElement(
        { title: 'Shipping', value: cartOrderDetail?.totalShippingCost },
        { top: '0.875rem', bottom: '0.875rem' },
      )}
      <StyledDivInfo>
        <Icon name='warning' size='medium' color='#FFFFFF' />
        <Body color='#000000' bold primitive='h3'>
          Please review addresses for any errors.
        </Body>
      </StyledDivInfo>
      {isAgentAddressFlag ? renderShippingAddress(uniqueAgentAddress) : renderShippingAddress(uniqueShippingAddress)}
      <div>
        <StyledSpan>
          {cartOrderDetail?.splitShipmentIndicator && (
            <StyledLinkDiv>
              <Icon lineColor='black' name='checkmarkAlt' size='20' style={{ marginRight: '10px' }} />
              Split shipment selected
            </StyledLinkDiv>
          )}
          {isAgentAddressFlag && (
            <StyledLinkDiv>
              <StylesTextLink href={shippingUrl} data-testid='shippingDetailsLink' type='standAlone' size='large'>
                CustomerEmail/ Ship Address Details
              </StylesTextLink>
            </StyledLinkDiv>
          )}
          {!isAgentAddressFlag && (
            <StyledLinkDiv>
              <StylesTextLink href={shippingUrl} type='standAlone' size='large'>
                Edit
              </StylesTextLink>
            </StyledLinkDiv>
          )}
        </StyledSpan>
      </div>
    </div>
  );
}

ShippingDetails.propTypes = {
  cartOrderDetail: PropTypes.object,
  lineInfo: PropTypes.any,
};

export default ShippingDetails;

const StyledDivInfo = styled.div`
  background-color: rgb(248, 211, 98);
  display: flex;
  padding-top: 0.875rem !important;
  padding-bottom: 0.875rem !important;
  padding: 0 8px 16px;
  position: relative;

  h3 {
    font-size: 14px;
    align-self: center;
    padding-left: 5px;
  }
`;
const StyledSpan = styled.span`
  cursor: pointer;
  padding-top: 0.875rem;
  font-size: 14px;
`;
const StyledLinkDiv = styled.div`
    cursor:pointer;
    padding-bottom: 1.3125rem 
    font-size: 14px;
    font-weight: bold;
`;
const StylesTextLink = styled(TextLink)`
  border-width: 0px 0px 0.0909091rem !important;
  font-weight: 400 !important;
  font-size: 14px;
  cursor: pointer;
  padding-top: 0.4375rem;
`;
