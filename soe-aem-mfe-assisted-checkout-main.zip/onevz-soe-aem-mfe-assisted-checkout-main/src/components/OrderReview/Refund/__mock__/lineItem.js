export const LineItem = {
  itemsInfo: {
    cartItems: {
      cartItem: [
        {
          cartItemType: 'ACCESSORY',
          priceAdjustment: false,
          prodCode1: 'ACC',
          tradeInAutoPull: false,
        },
        {
          cartItemType: 'ACCESSORY',
          priceAdjustment: true,
          prodCode1: 'ACC',
          tradeInAutoPull: false,
        },
        {
          cartItemType: 'NON_ACCESSORY',
          priceAdjustment: false,
          prodCode1: 'NON_ACC',
          tradeInAutoPull: false,
        },
        {
          cartItemType: 'ACCESSORY',
          priceAdjustment: false,
          prodCode1: 'ACC',
          tradeInAutoPull: true,
        },
        {
          cartItemType: 'ACCESSORY',
          priceAdjustment: true,
          prodCode1: 'NON_ACC',
          tradeInAutoPull: false,
        },
      ],
    },
  },
};
