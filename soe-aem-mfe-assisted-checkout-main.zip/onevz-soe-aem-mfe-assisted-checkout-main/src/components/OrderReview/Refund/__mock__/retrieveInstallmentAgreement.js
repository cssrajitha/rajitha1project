export const retrieveInstallmentAgreementResponse = {
  data: {
    response: [
      {
        orderNumber: '12001054',
        orderActivityType: 'REX',
        installmentContractData:
          'JVBERi0xLjQKJfbkN8KMSAwIG9iago8PAovVHlwZSAvQ2F0YWxvZwovVmVyc2lvbiAvMS40i9QYWdlcyAyIDAgUgo',
      },
    ],
    type: 'PDF',
  },
};
