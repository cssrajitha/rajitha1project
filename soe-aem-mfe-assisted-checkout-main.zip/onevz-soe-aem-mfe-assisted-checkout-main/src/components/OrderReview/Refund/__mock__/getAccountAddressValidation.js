export const getAccountAdressValidationResult = {
  meta: {
    timestamp: '2025-03-11T09:05:54Z',
    cxpCorrelationId: '2025-03-11T09:05:54.+0000:cadf7a5e838985ea:cxp-shipment-services-74c44f7f86-gqgcb:nssit2',
  },
  data: { shipAddress: [{ multiLineSeqNumber: '1', shipAddressValid: true }] },
};
