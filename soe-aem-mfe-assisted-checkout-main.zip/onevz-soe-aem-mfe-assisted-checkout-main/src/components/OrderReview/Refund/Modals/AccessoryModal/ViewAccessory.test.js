import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import ViewAccessory from './ViewAccessory';
import accessoryData from './ViewAccessoryJSON.json';

describe('ViewAccessory Component', () => {
  const commonProps = {
    closeModal: jest.fn(),
    lineInfo: { mobileNumber: '8134692060' },
    history: {
      navigatePage: jest.fn(),
    },
  };

  test('should render properly', () => {
    const props = {
      ...commonProps,
      isNewItemSection: false,
      isReadOrder: false,
      refundAccessoryCartItems: accessoryData.refundAccessoryCartItems,
      rightSideAccessories: accessoryData.rightSideAccessories,
    };
    render(<ViewAccessory {...props} />);
    expect(screen.getByTestId('view-accessory-header')).toBeInTheDocument();
    expect(screen.getByTestId('view-accessory-title')).toBeInTheDocument();
  });

  test('should have Accessories for and Accessories present', () => {
    const props = {
      ...commonProps,
      isNewItemSection: false,
      isReadOrder: false,
      refundAccessoryCartItems: accessoryData.refundAccessoryCartItems,
      rightSideAccessories: accessoryData.rightSideAccessories,
    };
    render(<ViewAccessory {...props} />);
    expect(screen.getByText(/Accessories for/)).toBeInTheDocument();
    expect(screen.getByText(/Accessories changes/)).toBeInTheDocument();
  });

  test('should display the data from refundAccessoryCartItems', () => {
    const props = {
      ...commonProps,
      isNewItemSection: false,
      isReadOrder: false,
      refundAccessoryCartItems: accessoryData.refundAccessoryCartItems,
      rightSideAccessories: accessoryData.rightSideAccessories,
    };
    render(<ViewAccessory {...props} />);
    const airPodsElements = screen.getAllByText('AirPods Max - Sky Blue');
    expect(airPodsElements[0]).toBeInTheDocument();
    expect(airPodsElements[1]).toBeInTheDocument();

    accessoryData.refundAccessoryCartItems.forEach((item) => {
      expect(screen.getByText(`SKU: ${item.sorId}`)).toBeInTheDocument();
      expect(screen.getByText(`Retail price`)).toBeInTheDocument();
      expect(screen.getByTestId('accessory_price')).toBeInTheDocument();
    });
  });

  test('should render properly with isNewItemSection true and isReadOrder false', () => {
    const props = {
      ...commonProps,
      isNewItemSection: true,
      isReadOrder: false,
      refundAccessoryCartItems: accessoryData.refundAccessoryCartItems,
      rightSideAccessories: accessoryData.rightSideAccessories,
    };
    render(<ViewAccessory {...props} />);
    expect(screen.getByTestId('view-accessory-header')).toBeInTheDocument();
    expect(screen.getByTestId('view-accessory-title')).toBeInTheDocument();
  });

  test('should display the data from refundAccessoryCartItems and rightSideAccessories with isNewItemSection true', () => {
    const props = {
      ...commonProps,
      isNewItemSection: true,
      isReadOrder: false,
      refundAccessoryCartItems: accessoryData.refundAccessoryCartItems,
      rightSideAccessories: accessoryData.rightSideAccessories,
    };
    render(<ViewAccessory {...props} />);
    const airPodsElements = screen.getAllByText('AirPods Max - Sky Blue');
    expect(airPodsElements[0]).toBeInTheDocument();
    expect(airPodsElements[1]).toBeInTheDocument();

    accessoryData.refundAccessoryCartItems.forEach((item) => {
      expect(screen.getByText(`SKU: ${item.sorId}`)).toBeInTheDocument();
      const retailPriceElements = screen.getAllByText('Retail price');
      expect(retailPriceElements[0]).toBeInTheDocument();
      const accessoryPriceElements = screen.getAllByTestId('accessory_price');
      expect(accessoryPriceElements[0]).toBeInTheDocument();
    });

    accessoryData.rightSideAccessories.forEach((item, index) => {
      const deviceDisplayNameElements = screen.getAllByText(item.deviceDisplayName);
      expect(deviceDisplayNameElements[index]).toBeInTheDocument();
      const descriptionElements = screen.getAllByText(item.description);
      expect(descriptionElements[index]).toBeInTheDocument();
      const skuElements = screen.getAllByText(`SKU: ${item.sorId}`);
      expect(skuElements[index]).toBeInTheDocument();
      const qtyElements = screen.getAllByText(`Qty: ${item.qty}`);
      expect(qtyElements[index]).toBeInTheDocument();
    });
  });

  test('should call closeModal with correct argument for refund', () => {
    const props = {
      ...commonProps,
      isNewItemSection: false,
      isReadOrder: false,
      refundAccessoryCartItems: accessoryData.refundAccessoryCartItems,
    };
    render(<ViewAccessory {...props} />);

    const doneButtons = screen.getAllByTestId('done-button');
    doneButtons[0].click();

    expect(props.closeModal).toHaveBeenCalledWith('refund');
  });

  test('should call closeModal with correct argument for exchange', () => {
    const props = {
      ...commonProps,
      isNewItemSection: true,
      isReadOrder: false,
      refundAccessoryCartItems: accessoryData.refundAccessoryCartItems,
    };
    render(<ViewAccessory {...props} />);

    const doneButtons = screen.getAllByTestId('done-button');
    doneButtons[0].click();

    expect(props.closeModal).toHaveBeenCalledWith('exchange');
  });

  test('should call closeModal with correct argument when Close icon is clicked - refund', () => {
    const props = {
      ...commonProps,
      isNewItemSection: false,
      isReadOrder: false,
      refundAccessoryCartItems: accessoryData.refundAccessoryCartItems,
    };
    render(<ViewAccessory {...props} />);

    const closeIcons = screen.getAllByTestId('ViewAccessory Modal is Closed');
    closeIcons[0].click();

    expect(props.closeModal).toHaveBeenCalledWith('refund');
  });

  test('should call closeModal with correct argument when Close icon is clicked - exchange', () => {
    const props = {
      ...commonProps,
      isNewItemSection: true,
      isReadOrder: false,
      refundAccessoryCartItems: accessoryData.refundAccessoryCartItems,
    };
    render(<ViewAccessory {...props} />);

    const closeIcons = screen.getAllByTestId('ViewAccessory Modal is Closed');
    closeIcons[0].click();

    expect(props.closeModal).toHaveBeenCalledWith('exchange');
  });

  test('should display the data for price adjustment ', () => {
    const props = {
      ...commonProps,
      isNewItemSection: true,
      isReadOrder: false,
      refundAccessoryCartItems: accessoryData.refundAccessoryAutopull[0],
      rightSideAccessories: accessoryData.rightSideAccessoryAutopull[0],
    };
    render(<ViewAccessory {...props} />);

    expect(screen.getByText('Price adjustment')).toBeInTheDocument();
  });

  test('should display "Price adjustment" for autopull items', () => {
    const props = {
      ...commonProps,
      refundAccessoryCartItems: accessoryData.refundAccessoryAutopull[0],
      rightSideAccessories: accessoryData.rightSideAccessoryAutopull[0],
    };
    render(<ViewAccessory {...props} />);

    expect(screen.getByText('Price adjustment')).toBeInTheDocument();
  });

  test('should render itemPrice when catalogPrice is undefined', () => {
    const modifiedAccessoryData = {
      ...accessoryData,
      refundAccessoryCartItemsWithSedOffer: accessoryData.refundAccessoryCartItemsWithSedOffer.map((item) => ({
        ...item,
        catalogPrice: undefined,
        itemPrice: item.itemPrice || 0,
      })),
    };

    const props = {
      ...commonProps,
      isNewItemSection: false,
      isReadOrder: false,
      refundAccessoryCartItems: modifiedAccessoryData.refundAccessoryCartItemsWithSedOffer,
      rightSideAccessories: accessoryData.rightSideAccessories,
    };

    render(<ViewAccessory {...props} />);

    const accessoryPrices = screen.getAllByTestId('accessory_price');
    accessoryPrices.forEach((element, index) => {
      expect(element).toHaveTextContent(modifiedAccessoryData.refundAccessoryCartItemsWithSedOffer[index].itemPrice);
    });
  });

  test('should render with empty mobile number when lineInfo is not provided', () => {
    const props = {
      ...commonProps,
      isNewItemSection: false,
      isReadOrder: false,
      refundAccessoryCartItems: accessoryData.refundAccessoryCartItems,
      rightSideAccessories: accessoryData.rightSideAccessories,
      lineInfo: null,
    };

    render(<ViewAccessory {...props} />);

    const headerElement = screen.getByTestId('view-accessory-header');
    expect(headerElement).toBeInTheDocument();
    expect(headerElement).toHaveTextContent('Accessories for');
  });

  test('should set refundAccessoriesExcludingAutopull to an empty array when refundAccessoryCartItems is null', () => {
    const props = {
      ...commonProps,
      isNewItemSection: true,
      isReadOrder: false,
      refundAccessoryCartItems: null,
      rightSideAccessories: accessoryData.rightSideAccessories,
    };

    render(<ViewAccessory {...props} />);

    const headerElement = screen.getByTestId('view-accessory-header');
    expect(headerElement).toBeInTheDocument();
    expect(headerElement).toHaveTextContent('Accessories for');

    const totalItemsList = screen.queryAllByTestId('accessory-title');
    expect(totalItemsList.length).toBe(1);
  });

  test('should set refundAccessoriesExcludingAutopull to an empty array when refundAccessoryCartItems is an empty array', () => {
    const props = {
      ...commonProps,
      isNewItemSection: true,
      isReadOrder: false,
      refundAccessoryCartItems: [],
      rightSideAccessories: accessoryData.rightSideAccessories,
    };

    render(<ViewAccessory {...props} />);

    const headerElement = screen.getByTestId('view-accessory-header');
    expect(headerElement).toBeInTheDocument();
    expect(headerElement).toHaveTextContent('Accessories for');

    const totalItemsList = screen.queryAllByTestId('accessory-title');
    expect(totalItemsList.length).toBe(1);
  });
});

describe('ViewAccessory Component with refundAccessoryCartItemsWithSedOffer', () => {
  const commonProps = {
    closeModal: jest.fn(),
    lineInfo: { mobileNumber: '8134692060' },
  };

  test('should render properly with refundAccessoryCartItemsWithSedOffer', () => {
    const props = {
      ...commonProps,
      isNewItemSection: false,
      isReadOrder: false,
      refundAccessoryCartItems: accessoryData.refundAccessoryCartItemsWithSedOffer,
      rightSideAccessories: accessoryData.rightSideAccessories,
    };
    render(<ViewAccessory {...props} />);
    expect(screen.getByTestId('view-accessory-header')).toBeInTheDocument();
    expect(screen.getByTestId('view-accessory-title')).toBeInTheDocument();
  });

  test('should call closeModal with correct argument when Done button is clicked', () => {
    const props = {
      ...commonProps,
      isNewItemSection: true,
      isReadOrder: false,
      refundAccessoryCartItems: accessoryData.refundAccessoryCartItemsWithSedOffer,
    };
    render(<ViewAccessory {...props} />);

    const doneButtons = screen.getAllByTestId('done-button');
    doneButtons[0].click();

    expect(props.closeModal).toHaveBeenCalledWith('exchange');
  });

  test('should call closeModal with correct argument when Close icon is clicked', () => {
    const props = {
      ...commonProps,
      isNewItemSection: false,
      isReadOrder: false,
      refundAccessoryCartItems: accessoryData.refundAccessoryCartItemsWithSedOffer,
    };
    render(<ViewAccessory {...props} />);

    const closeIcons = screen.getAllByTestId('ViewAccessory Modal is Closed');
    closeIcons[0].click();

    expect(props.closeModal).toHaveBeenCalledWith('refund');
  });
});
