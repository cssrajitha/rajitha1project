import React from 'react';
import PropTypes from 'prop-types';
import styled, { createGlobalStyle } from 'styled-components';
import { formatCurrency } from 'onevzsoemfecommon/Helpers';
import { Icon } from '@vds/icons';
import { Title } from '@vds/typography';
import { Button as VdsButton } from '@vds/buttons';
import _ from 'lodash';
import { formatMtnWithDecimals } from '../../../../../utils/common';

const Button = styled(VdsButton)`
  padding: 0 1.5rem 0 1.5rem;
`;

const ComponentStyle = createGlobalStyle`
  [class^='ModalDialog-VDS'] {
    padding-top: 0;
    width: 100%;
    max-width: 1133px !important;
    border-radius: 0 !important;
    padding-left: 0;
  }

  [class^='Overlay-VDS'] {
    background: rgb(0 0 0 / 70%);
  }

  [id="close-button"] {
    opacity: 0;
  }
`;

const ModalWrapper = styled.div`
  padding-left: 50px;
  width: 100%;
  max-width: 1133px;
  margin: 0 auto;
`;

const BackClickable = styled.a`
  cursor: pointer;
  color: #000000 !important;
  align-items: center;
  padding: 1.5rem 3rem 1.5rem 0;
  svg {
    width: 2.5rem;
    height: 2.5rem;
  }
`;

const Padding36 = styled.div`
  padding: 1.5rem 2rem;
`;

const HeaderSection = styled.div`
  max-width: 1133px;
  background-color: rgb(255, 255, 255);
  z-index: 2;
  position: sticky;
  top: 0;
  width: 100%;
  display: flex;
  justify-content: center;
  left: 0;
  right: 0;
  top: 0;
  margin: 0 auto;
`;

const FlexAlignContainerItemsCenter = styled.div`
  display: flex;
  align-items: center !important;
  justify-content: space-between;
  width: 100%;
`;

const LineDiv = styled.div`
  position: fixed;
  border-bottom: 1px solid #ccc;
  width: 100%;
  max-width: 1133px;
  left: 0;
  right: 0;
  margin: 0 auto;
  color: #ccc;
`;

const FooterArea = styled.div`
  max-width: 1133px;
  background-color: rgb(255, 255, 255);
  z-index: 1;
  bottom: 0px;
  position: fixed;
  width: 100%;
  display: flex;
  border-top: 1px solid;
  justify-content: center;
  left: 0;
  right: 0;
  margin: 0 auto;
`;

const FlexBoxGrowOne = styled.div`
  display: flex;
  flex-grow: 1;
  height: 7rem;
  align-items: center;
  gap: 0.3rem;
`;

const CloseIconWrapper = styled.div`
  display: flex;
  align-items: center;
`;

const BodyWrapper = styled.div`
  padding-top: 1px;
  width: 100%;
  max-width: 1133px;
  margin: 0 auto;
`;
const Marginleft = styled.div`
  margin-left: 20px;
`;

const Header = styled.div`
  padding-top: 20px;
  padding-bottom: 20px;
`;

const AccessoryItemContainer = styled.div`
  display: flex;
  padding: 0.5rem 0;
  margin-top: 0.5rem;
  margin-bottom: 50px;

  &:last-child {
    border-bottom: none;
  }
`;

const AccessoryImage = styled.img`
  width: 140px;
  height: 180px;
`;

const AccessoryDetails = styled.div`
  flex: 1;
  padding-left: 1.5rem;
`;

const AccessoryTitle = styled.div`
  font-size: 24px;
  padding-bottom: 20px;
`;

const AccessoryDescription = styled.div`
  padding-bottom: 10px;
`;

const AccessorySKU = styled.div`
  padding-bottom: 1.5rem;
`;

const AccessoryQty = styled.div`
  padding-top: 0.5rem;
  padding-bottom: 1.5rem;
`;

const AccessoryPriceContainer = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 0.5rem 0;
  margin-top: 0.5rem;
  border-top: 1px solid #ccc;
  width: 90%;
`;

const Col = styled.div`
  flex: 1;
  padding-left: 2rem;
  &.u-textRight {
    text-align: right;
  }
`;

const ViewAccessory = (props) => {
  const mobileNumber = props.lineInfo ? props.lineInfo.mobileNumber : '';
  let refundAccessoriesExcludingAutopull;
  if (props.isNewItemSection) {
    refundAccessoriesExcludingAutopull = props.refundAccessoryCartItems
      ? props.refundAccessoryCartItems.filter((accessory) => !accessory.priceAdjustment)
      : [];
  }

  let totalItemsList;
  if (props.isNewItemSection) {
    if (props.rightSideAccessories) {
      totalItemsList = props.rightSideAccessories.concat(refundAccessoriesExcludingAutopull);
    } else {
      totalItemsList = props.refundAccessoryCartItems;
    }
  } else {
    totalItemsList = props.refundAccessoryCartItems;
  }

  const getAccessoryTitle = (type) => {
    switch (type) {
      case 'refund':
        return 'Refunded';
      case 'autopull':
        return 'Price adjustment';
      default:
        return 'New';
    }
  };

  const getFormattedPrice = (price) => formatCurrency(price ? parseFloat(price) : 0);

  const getAccessoryPrice = (accessoryItem) =>
    getFormattedPrice(
      (_.has(accessoryItem, 'discountedPrice') ? accessoryItem.discountedPrice : accessoryItem.catalogPrice) ||
        accessoryItem.itemPrice,
    );

  return (
    <>
      <ComponentStyle />
      <div>
        <ModalWrapper>
          <HeaderSection>
            <FlexAlignContainerItemsCenter>
              <FlexBoxGrowOne>
                <Title size='small' bold data-testid='view-accessory-header'>
                  Accessories for {formatMtnWithDecimals(mobileNumber)}
                </Title>
              </FlexBoxGrowOne>
              <CloseIconWrapper>
                <Marginleft>
                  <BackClickable
                    data-testid='ViewAccessory Modal is Closed'
                    data-track='ViewAccessory Modal is Closed'
                    onClick={() => props.closeModal(props.isNewItemSection ? 'exchange' : 'refund')}
                  >
                    <Icon name='close' size='large' />
                  </BackClickable>
                </Marginleft>
              </CloseIconWrapper>
            </FlexAlignContainerItemsCenter>
          </HeaderSection>
          <LineDiv />
          <BodyWrapper>
            <Header>
              <Title size='medium' bold data-testid='view-accessory-title'>
                Accessories changes
              </Title>
            </Header>
            {totalItemsList.map((accessoryItem) => (
              <AccessoryItemContainer key={accessoryItem.sorId}>
                {/* section 1 */}
                {(!props.isNewItemSection ||
                  (props.isNewItemSection && !accessoryItem.priceAdjustment) ||
                  (props.isNewItemSection && accessoryItem.priceAdjustment && accessoryItem.newPurchasedQty === 0)) && (
                  <>
                    <AccessoryImage
                      src={accessoryItem.imageUrlMap && accessoryItem.imageUrlMap.defaultImage}
                      alt='img'
                    />
                    <AccessoryDetails>
                      <AccessoryTitle>
                        <Title bold color='#0088ce' data-testid='accessory-title'>
                          {getAccessoryTitle(accessoryItem.type)}
                        </Title>
                      </AccessoryTitle>
                      <AccessoryDescription>
                        <Title bold>{accessoryItem.deviceDisplayName}</Title>
                      </AccessoryDescription>
                      <AccessoryDescription>
                        <Title bold>{accessoryItem.description}</Title>
                      </AccessoryDescription>
                      <AccessorySKU>
                        <Title>SKU: {accessoryItem.sorId}</Title>
                      </AccessorySKU>
                      {props.isNewItemSection && (
                        <AccessoryQty>
                          <Title>Qty: {accessoryItem.qty}</Title>
                        </AccessoryQty>
                      )}
                      <AccessoryPriceContainer>
                        <Title bold>Retail price</Title>
                        <Col className='u-textRight'>
                          <Title bold data-testid='accessory_price'>
                            {`${accessoryItem.type === 'refund' ? '-' : ''}${getAccessoryPrice(accessoryItem)}`}
                          </Title>
                        </Col>
                      </AccessoryPriceContainer>
                    </AccessoryDetails>
                  </>
                )}

                {/* section 2 */}
                {props.isNewItemSection && accessoryItem.priceAdjustment && accessoryItem.newPurchasedQty > 0 && (
                  <>
                    <AccessoryItemContainer key={`new-${accessoryItem.sorId}`}>
                      <AccessoryImage
                        src={accessoryItem.imageUrlMap && accessoryItem.imageUrlMap.defaultImage}
                        alt='img'
                      />
                      <AccessoryDetails>
                        <AccessoryTitle>
                          <Title bold color='#0089EC'>
                            New
                          </Title>
                        </AccessoryTitle>
                        <AccessoryDescription>
                          <Title bold>{accessoryItem.deviceDisplayName}</Title>
                        </AccessoryDescription>
                        <AccessoryDescription>
                          <Title bold>{accessoryItem.description}</Title>
                        </AccessoryDescription>
                        <AccessorySKU>
                          <Title>SKU: {accessoryItem.sorId}</Title>
                        </AccessorySKU>
                        <AccessoryQty>
                          <Title data-testid='quantity'>Qty: {accessoryItem.newPurchasedQty}</Title>
                        </AccessoryQty>
                        <AccessoryPriceContainer>
                          <Title bold>Retail price</Title>
                          <Col className='u-textRight'>
                            <Title bold data-testid='accessory_price'>
                              {`${getAccessoryPrice(accessoryItem)}`}
                            </Title>
                          </Col>
                        </AccessoryPriceContainer>
                      </AccessoryDetails>
                    </AccessoryItemContainer>

                    <AccessoryItemContainer>
                      <AccessoryImage
                        src={accessoryItem.imageUrlMap && accessoryItem.imageUrlMap.defaultImage}
                        alt='img'
                      />
                      <AccessoryDetails>
                        <AccessoryTitle>
                          <Title bold color='#0089EC'>
                            Price adjustment
                          </Title>
                        </AccessoryTitle>
                        <AccessoryDescription>
                          <Title bold>{accessoryItem.deviceDisplayName}</Title>
                        </AccessoryDescription>
                        <AccessoryDescription>
                          <Title bold>{accessoryItem.description}</Title>
                        </AccessoryDescription>
                        <AccessorySKU>
                          <Title>SKU: {accessoryItem.sorId}</Title>
                        </AccessorySKU>
                        <AccessoryQty>
                          <Title>Qty: {accessoryItem.priceAdjustmentQty}</Title>
                        </AccessoryQty>
                        <AccessoryPriceContainer>
                          <Title bold>Retail price</Title>
                          <Col className='u-textRight'>
                            <Title bold>{`${getAccessoryPrice(accessoryItem)}`}</Title>
                          </Col>
                        </AccessoryPriceContainer>
                      </AccessoryDetails>
                    </AccessoryItemContainer>
                  </>
                )}
              </AccessoryItemContainer>
            ))}
          </BodyWrapper>
        </ModalWrapper>

        <FooterArea>
          <Padding36>
            <Button
              size='large'
              data-testid='done-button'
              data-track='done-button'
              onClick={() => props.closeModal(props.isNewItemSection ? 'exchange' : 'refund')}
            >
              Done
            </Button>
          </Padding36>
        </FooterArea>
      </div>
    </>
  );
};

ViewAccessory.propTypes = {
  closeModal: PropTypes.func.isRequired,
  isNewItemSection: PropTypes.bool.isRequired,
  refundAccessoryCartItems: PropTypes.array.isRequired,
  rightSideAccessories: PropTypes.array,
  lineInfo: PropTypes.object,
};

export default ViewAccessory;
