import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { Icon } from '@vds/icons';
import { Line } from '@vds/lines';
import { Button } from '@vds/buttons';
import { ModalBody } from '@vds/modals';
import { Title } from '@vds/typography';
import { Col, Grid, Row } from '@vds/grids';
import { formatCurrency } from '../../../../../utils/common';
import { FlexJustify, PaddingTop16, StyledFooterWrapper, StyledPaddingRight8 } from '../../../../../StyledConstants';

const AccountSectionModel = ({ lineInfo, closeModal, planReferences, changePlan }) => {
  const price = lineInfo?.[0]?.serviceInfo?.selectedALPShareList?.alpShareInfo?.[0]?.accessFee ?? '0.00';
  const pricePlanDesc = lineInfo?.[0]?.serviceInfo?.selectedALPShareList?.alpShareInfo?.[0]?.servicePlanDesc ?? '';
  const formattedPlanName =
    lineInfo?.[0]?.serviceInfo?.selectedALPShareList?.alpShareInfo?.[0]?.formattedPlanName ?? '';
  const featureText = planReferences?.[0]?.featureText ?? '';
  const dataOverageAllowance = planReferences?.[0]?.dataOverageAllowance ?? '';
  const dataUnitOfMeasure = planReferences?.[0]?.dataUnitOfMeasure ?? '';
  const dataOverateAmount = planReferences?.[0]?.dataOverateAmount ?? '';

  const getPlanImageURL = () => {
    const imageUrl =
      lineInfo?.[0]?.serviceInfo?.selectedALPShareList?.alpShareInfo?.[0]?.imageUrlMap?.defaultImage ?? '';
    return imageUrl ? <img src={imageUrl} alt='img' style={{ width: '80px' }} /> : '';
  };

  return (
    <div className='RefundExchange viewAccessory' data-testid='account-section-model'>
      <Header>
        <TitleWrapperHeader>
          <Title size='small' color='#000000' bold>
            <span>Plan({`${formatCurrency(price)}/monthly`})</span>
          </Title>
          <IconWrapper onClick={closeModal} data-testid='close-button' name='close-glance'>
            <Icon name='close' size='medium' />
          </IconWrapper>
        </TitleWrapperHeader>
        <Divider />
      </Header>
      <ModalBody>
        <div>
          <div>
            <Grid bleed='1272' rowGutter='10px'>
              <Row>
                <Col colSizes={{ desktop: 2, tablet: 2 }}>{getPlanImageURL()}</Col>
                <Col colSizes={{ desktop: 10, tablet: 10 }}>
                  <div className='u-paddingLeftExtraLarge'>
                    <div>
                      <Title bold size='small'>
                        {pricePlanDesc}
                      </Title>
                      <PaddingTop16
                        className='u-paddingTopLarge u-paddingBottomLarge'
                        dangerouslySetInnerHTML={{ __html: `${formattedPlanName}` }}
                      />
                      <FlexJustify>
                        <span className='font-20'>Retail Price</span>
                        <Title bold size='small'>
                          {formatCurrency(price)}
                        </Title>
                      </FlexJustify>

                      <Line type='secondary' surface='light' />
                    </div>
                    <PaddingTop16 className='u-paddingTopMedium u-paddingBottom100'>
                      <Title bold size='small'>
                        Includes
                      </Title>
                      <div className='u-paddingBottomLarge'>
                        <div className='u-paddingLeftExtraLarge u-paddingTopLarge u-paddingBottomLarge'>
                          {featureText}
                        </div>
                      </div>
                      {dataOverageAllowance && (
                        <div className='u-paddingTopSmall u-paddingBottomMedium'>
                          {' '}
                          {`Overages are ${
                            dataOverateAmount && formatCurrency(dataOverateAmount)
                          } per ${dataOverageAllowance}${dataUnitOfMeasure} of data.`}
                        </div>
                      )}
                    </PaddingTop16>
                  </div>
                </Col>
              </Row>
            </Grid>
          </div>
        </div>
      </ModalBody>
      <StyledFooterWrapper className='accountsection-footer'>
        <FlexJustify>
          <StyledPaddingRight8>
            <Button use='primary' onClick={closeModal}>
              Done
            </Button>
          </StyledPaddingRight8>

          <Button use='primary' onClick={changePlan}>
            Change Plan
          </Button>
        </FlexJustify>
      </StyledFooterWrapper>
    </div>
  );
};

AccountSectionModel.propTypes = {
  closeModal: PropTypes.func.isRequired,
  planReferences: PropTypes.array,
  changePlan: PropTypes.func.isRequired,
  lineInfo: PropTypes.object.isRequired,
};

const IconWrapper = styled.div`
  cursor: pointer;
  color: #000000 !important;
`;

export const Header = styled.div`
  box-sizing: border-box;
  margin: 0 -8px;
  padding: 0;
`;

export const Divider = styled.div`
  border-bottom: 1px solid #d8dada;
`;

export const TitleWrapperHeader = styled.div`
  display: flex;
  justify-content: space-between;
  margin: 10px;
`;

export default AccountSectionModel;
