import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import AccountSectionModel from './AccountSection';

const mockCloseModal = jest.fn();
const mockChangePlan = jest.fn();

const defaultProps = {
  closeModal: mockCloseModal,
  changePlan: mockChangePlan,
  lineInfo: [
    {
      serviceInfo: {
        selectedALPShareList: {
          alpShareInfo: [
            {
              accessFee: '50.00',
              servicePlanDesc: 'Test Plan Description',
              formattedPlanName: 'Test Plan Name',
              imageUrlMap: {
                defaultImage: 'test-image-url',
              },
            },
          ],
        },
      },
    },
  ],
  planReferences: [
    {
      featureText: 'Test Feature Text',
      dataOverageAllowance: '10',
      dataUnitOfMeasure: 'GB',
      dataOverateAmount: '15.00',
    },
  ],
};

describe('AccountSectionModel', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders correctly with given props', () => {
    render(<AccountSectionModel {...defaultProps} />);
    expect(screen.getByTestId('account-section-model')).toBeInTheDocument();
    expect(screen.getByText('Plan($50.00/monthly)')).toBeInTheDocument();
    expect(screen.getByText('Test Plan Description')).toBeInTheDocument();
    expect(screen.getByText('Retail Price')).toBeInTheDocument();
    expect(screen.getByText('$50.00')).toBeInTheDocument();
    expect(screen.getByText('Includes')).toBeInTheDocument();
    expect(screen.getByText('Test Feature Text')).toBeInTheDocument();
    expect(screen.getByText('Overages are $15.00 per 10GB of data.')).toBeInTheDocument();
    expect(screen.getByAltText('img')).toHaveAttribute('src', 'test-image-url');
  });

  it('renders correctly without props', () => {
    render(<AccountSectionModel />);
    expect(screen.getByTestId('account-section-model')).toBeInTheDocument();
  });

  it('calls closeModal when close button is clicked', () => {
    render(<AccountSectionModel {...defaultProps} />);
    fireEvent.click(screen.getByTestId('close-button'));
    expect(mockCloseModal).toHaveBeenCalled();
  });

  it('calls changePlan when Change Plan button is clicked', () => {
    render(<AccountSectionModel {...defaultProps} />);
    fireEvent.click(screen.getByText('Change Plan'));
    expect(mockChangePlan).toHaveBeenCalled();
  });

  it('renders correctly without optional props', () => {
    const props = {
      closeModal: mockCloseModal,
      changePlan: mockChangePlan,
      lineInfo: [
        {
          serviceInfo: {
            selectedALPShareList: {
              alpShareInfo: [
                {
                  accessFee: '0.00',
                  servicePlanDesc: '',
                  formattedPlanName: '',
                  imageUrlMap: {
                    defaultImage: '',
                  },
                },
              ],
            },
          },
        },
      ],
      planReferences: [{}],
    };
    render(<AccountSectionModel {...props} />);
    expect(screen.getByTestId('account-section-model')).toBeInTheDocument();
    expect(screen.getByText('Plan($0.00/monthly)')).toBeInTheDocument();
    expect(screen.queryByText('Retail Price')).toBeInTheDocument();
    expect(screen.queryByText('$0.00')).toBeInTheDocument();
    expect(screen.queryByText('Includes')).toBeInTheDocument();
    expect(screen.queryByText('Overages are $ per of data.')).not.toBeInTheDocument();
    expect(screen.queryByAltText('img')).not.toBeInTheDocument();
  });
});
