import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { Table as VdsTable, TableHeader as VdsTableHeader } from '@vds/tables';
import { formatCurrency } from 'onevzsoemfecommon/Helpers';
import { getDiscountAmount, getItemCost, getDownPaymentAmount } from '../../utils/utils';

const AdjustedDueModelWrapper = styled.div`
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  margin: 1rem;
`;

const CustomerDetails = styled.div`
  display: flex;
  flex-wrap: wrap;
`;

const Details = styled.div``;

const Table = styled(VdsTable)`
  width: 100%;
  border-collapse: collapse;
`;

const TableHead = styled.thead``;

const TableBody = styled.tbody``;

const TableHeader = styled(VdsTableHeader)`
  padding: 1rem 0rem 1rem 0rem !important;
  font-size: 14px;
  text-align: left;
  font-weight: bold;
  border-bottom: 1px solid #d8dada;
  line-height: 1.2;
`;

const TableRow = styled.tr`
  border-bottom: 1px solid #d8dada;
  max-width: 100%;
`;

const TableCell = styled.td`
  span {
    display: inline !important;
    align-items: center !important;
    white-space: nowrap !important;
  }
`;

const Item = styled.div`
  font-size: 14px;
  font-weight: bold;
`;

const Name = styled.div`
  font-size: 20px;
  font-weight: bold;
`;

const HeaderXPadding = styled.div``;

const HeaderGrid = styled.div`
  display: flex;
  flex-wrap: nowrap;
  width: 100%;
`;

const processTradeInItems = (line, tradeInItems, type, displayData) => {
  tradeInItems?.forEach((item) => {
    const tradeInItem = {};
    const recycleDeviceOffer = item?.recycleDeviceOffer ?? null;
    const offerId = item?.recycleDeviceOffer?.offerId ?? '';
    const promoValue = Number(item?.deviceRecycleIn?.promoValue ?? '0');
    const bicLoanTerm = Number(item?.deviceRecycleIn?.bicLoanTerm ?? '0');
    let tradeInOfferPrice;
    if (recycleDeviceOffer && offerId > 0 && bicLoanTerm > 0) {
      if (promoValue && bicLoanTerm) {
        tradeInOfferPrice = Math.abs(promoValue / bicLoanTerm).toFixed(2);
      } else {
        tradeInOfferPrice = 0;
      }
    } else {
      tradeInOfferPrice = item.computedPrice;
    }
    tradeInItem.mobileNumber = line.mobileNumber;
    tradeInItem.type = type;
    tradeInItem.description = item.equipModel;
    tradeInItem.downPaymentAmount = line?.rfexInstallmentContractDetail?.downPaymentAmount;
    tradeInItem.agreement = line?.rfexInstallmentContractDetail?.installmentLoanNumber ?? '';
    tradeInItem.cartItemType = 'TRADE_IN';
    tradeInItem.sorId = item.recycleDeviceSku;
    tradeInItem.qty = '1';
    tradeInItem.itemPrice = tradeInOfferPrice;
    tradeInItem.discAmt = offerId > 0 ? tradeInOfferPrice : 0;
    tradeInItem.offerId = offerId;
    tradeInItem.itemCost = tradeInOfferPrice;
    displayData.push(tradeInItem);
  });
};

const cartItemInfo = (displayData, line, item, ItemType) => {
  const newItem = { ...item };
  newItem.downPaymentAmount =
    ItemType === 'refund'
      ? line?.rfexInstallmentContractDetail?.downPaymentAmount
      : line?.installmentContractDetail?.downPaymentAmount;
  newItem.agreement = line?.rfexInstallmentContractDetail?.installmentLoanNumber;
  newItem.type = ItemType;
  newItem.mobileNumber = line.mobileNumber;
  displayData.push(newItem);
};

const AdjustedDueModel = ({ lineInfo, lineDetails, modelHeaderName, modalName, selectedValue, allLines, hqUser }) => {
  const displayData = [];

  const allLinesSelectedItems = allLines.filter((item) => {
    if (selectedValue === 'ALL') {
      return true;
    }
    return item.value === selectedValue;
  });

  lineInfo?.forEach((line) => {
    processTradeInItems(line, lineDetails?.refundTradeInDetail?.tradeInItems, 'refund', displayData);
    processTradeInItems(line, lineDetails?.tradeInDetail?.tradeInItems, 'exchange', displayData);

    line.itemsInfo?.forEach((itemInfo) => {
      if (modalName === 'ADJUSTED_DUE_TODAY') {
        itemInfo.refundCartItems?.cartItem?.forEach((item) => {
          if (['ACCESSORY', 'DEVICE', 'RESTOCKFEE', 'UPGRADE_FEE'].includes(item.cartItemType)) {
            cartItemInfo(displayData, line, item, 'refund');
          }
        });
        itemInfo.cartItems?.cartItem?.forEach((item) => {
          if (['ACCESSORY', 'DEVICE', 'RESTOCKFEE', 'UPGRADE_FEE', 'SOFT_SKU'].includes(item.cartItemType)) {
            cartItemInfo(displayData, line, item, 'exchange');
          }
        });
      } else {
        itemInfo.refundCartItems?.cartItem?.forEach((item) => {
          if (['ACCESSORY', 'DEVICE', 'RESTOCKFEE', 'UPGRADE_FEE', 'WARRANTY'].includes(item.cartItemType)) {
            cartItemInfo(displayData, line, item, 'refund');
          }
        });
        itemInfo.cartItems?.cartItem?.forEach((item) => {
          if (['ACCESSORY', 'DEVICE', 'RESTOCKFEE', 'UPGRADE_FEE', 'WARRANTY'].includes(item.cartItemType)) {
            cartItemInfo(displayData, line, item, 'exchange');
          }
        });
      }
    });
  });

  return (
    <AdjustedDueModelWrapper data-testid='Adjusted-due-model'>
      {allLinesSelectedItems.map((line) => {
        const lineDisplayData = displayData.filter((fil) => fil.mobileNumber === line.value);
        return (
          lineDisplayData.length > 0 && (
            <div key={`AdjustedDueModel-${line.value}`}>
              <CustomerDetails>
                <Details>
                  <Name data-testid='name'>{line?.serviceInfo?.primaryUserInfo?.firstName ?? ''}</Name>
                  <Item data-testid='number'>{line?.serviceInfo?.mtn ?? ''}</Item>
                </Details>
              </CustomerDetails>
              <HeaderXPadding>
                <HeaderGrid data-testid='headercol'>
                  <Table>
                    <TableHead>
                      <TableRow data-testid='tablerow'>
                        {modelHeaderName.map((headerName) => (
                          <TableHeader data-testid='tableheader' key={`modelHeaderName-${headerName}`}>
                            {headerName}
                          </TableHeader>
                        ))}
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {lineDisplayData.map((order, index) => (
                        <TableRow key={`AdjustedDueModel--${order.sorId ?? index}`}>
                          <TableCell>
                            <Item>
                              {order.cartItemType === 'DEVICE' || order.cartItemType === 'ACCESSORY'
                                ? (order.deviceDisplayName ?? '')
                                : (order.description ?? '')}
                            </Item>
                            {order.sorId && <span>Item #:&nbsp;{order.sorId}</span>}
                            {order.cartItemType === 'DEVICE' && modalName === 'ITEMS_AT_GLANCE' && hqUser ? (
                              <div>
                                {order.deviceId ? (
                                  <div>DeviceId: :&nbsp; {order.deviceId ? order.deviceId : ''}</div>
                                ) : (
                                  ''
                                )}
                              </div>
                            ) : null}
                          </TableCell>
                          <TableCell>{order.qty ?? '-'}</TableCell>
                          <TableCell>
                            <span>
                              {order.itemPrice
                                ? `${order.type === 'refund' ? '-' : ''}${formatCurrency(order.itemPrice)}`
                                : formatCurrency('0')}
                            </span>
                          </TableCell>
                          <TableCell>{getDownPaymentAmount(order)}</TableCell>
                          <TableCell>{getDiscountAmount(order)}</TableCell>
                          <TableCell>
                            <span>
                              {order.cartItemType === 'TRADE_IN'
                                ? (order.offerId ?? '')
                                : (order.sedOfferList?.sedOffer?.[0]?.offerId ?? '0')}
                            </span>
                          </TableCell>
                          <TableCell>
                            <span>
                              {order.manualDiscount?.discountAmount
                                ? `${order.type === 'refund' ? '-' : ''}${formatCurrency(
                                    order.manualDiscount.discountAmount,
                                  )}`
                                : formatCurrency('0')}
                            </span>
                          </TableCell>
                          <TableCell>-</TableCell>
                          <TableCell>
                            <span>
                              {order.taxAmount
                                ? `${order.type === 'refund' ? '-' : ''}${formatCurrency(order.taxAmount)}`
                                : formatCurrency('0')}
                            </span>
                          </TableCell>
                          <TableCell>
                            <span>
                              {order.type === 'refund' ? '-' : ''}
                              {getItemCost(order)}
                            </span>
                          </TableCell>
                          <TableCell>
                            <span>
                              {order.cartItemType === 'DEVICE' || order.cartItemType === 'ACCESSORY'
                                ? (sessionStorage.getItem('location') ?? '-')
                                : '-'}
                            </span>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </HeaderGrid>
              </HeaderXPadding>
            </div>
          )
        );
      })}
    </AdjustedDueModelWrapper>
  );
};

AdjustedDueModel.propTypes = {
  lineInfo: PropTypes.array.isRequired,
  lineDetails: PropTypes.object,
  modelHeaderName: PropTypes.array.isRequired,
  modalName: PropTypes.string.isRequired,
  selectedValue: PropTypes.string.isRequired,
  allLines: PropTypes.array.isRequired,
  hqUser: PropTypes.bool,
};

export default AdjustedDueModel;
