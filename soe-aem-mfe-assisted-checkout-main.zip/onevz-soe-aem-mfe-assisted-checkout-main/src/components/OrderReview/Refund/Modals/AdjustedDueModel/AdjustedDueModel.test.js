import React from 'react';
import { render, screen } from '@testing-library/react';
import { formatCurrency } from 'onevzsoemfecommon/Helpers';
import AdjustedDueModel from './AdjustedDueModel';

jest.mock('onevzsoemfecommon/Helpers', () => ({
  formatCurrency: jest.fn((value) => `$${value}`),
}));

jest.mock('../../utils/utils');

const mockLineInfo = [
  {
    mobileNumber: '1234567890',
    serviceInfo: {
      primaryUserInfo: {
        firstName: 'John',
      },
      mtn: '1234567890',
    },
    itemsInfo: [
      {
        refundCartItems: {
          cartItem: [
            {
              cartItemType: 'DEVICE',
              deviceDisplayName: 'Device 1',
              downPaymentAmount: 100,
              itemPrice: 200,
              deviceId: '123456789',
              qty: 1,
              sorId: '123',
              type: 'refund',
              offerId: '12789',
              manualDiscount: {
                discountAmount: 50,
              },
              taxAmount: 10,
              sedOfferList: {
                sedOffer: [
                  {
                    discAmt: 100,
                  },
                ],
              },
            },
            {
              cartItemType: 'WARRANTY',
              deviceDisplayName: 'Device 1',
              downPaymentAmount: 100,
              itemPrice: 200,
              sorId: '123',
              type: 'refund',
              sedOfferList: {
                sedOffer: [{}],
              },
            },
          ],
        },
        cartItems: {
          cartItem: [
            {
              cartItemType: 'ACCESSORY',
              deviceDisplayName: 'Accessory 1',
              itemPrice: 100,
              qty: 1,
              sorId: '456',
              offerId: '789',
              type: 'refund',
              manualDiscount: {
                discountAmount: 50,
              },
              taxAmount: 10,
              sedOfferList: {
                sedOffer: [
                  {
                    discAmt: 100,
                  },
                ],
              },
            },
            {
              cartItemType: 'TRADE_IN',
              deviceDisplayName: 'Accessory 1',
              downPaymentAmount: 50,
              itemPrice: 100,
              qty: 1,
              sorId: '456',
              type: 'exchange',
            },
            {
              cartItemType: 'ACCESSORY',
              downPaymentAmount: 50,
              itemPrice: 100,
              type: 'refund',
            },
            {
              cartItemType: 'WARRANTY',
              deviceDisplayName: 'Accessory 1',
              downPaymentAmount: 50,
              itemPrice: 100,
              qty: 1,
              sorId: '456',
              type: 'exchange',
            },
            {
              cartItemType: 'RESTOCKFEE',
              deviceDisplayName: 'Accessory 1',
              downPaymentAmount: 50,
              itemPrice: 100,
              qty: 1,
              sorId: '456',
              type: 'exchange',
            },
            {
              cartItemType: 'RESTOCKFEE',
              deviceDisplayName: 'Accessory 1',
              downPaymentAmount: 50,
              discountedPrice: 100,
              qty: 1,
              sorId: '456',
              type: 'exchange',
            },
          ],
        },
      },
    ],
  },
];

const mockLineDetails = {
  refundTradeInDetail: {
    tradeInItems: [
      {
        recycleDeviceOffer: {
          offerId: '789',
        },
        deviceRecycleIn: {
          promoValue: '50',
          bicLoanTerm: '10',
        },
        computedPrice: 500,
        equipModel: 'Model 1',
        recycleDeviceSku: 'SKU1',
      },
    ],
  },
  tradeInDetail: {
    tradeInItems: [
      {
        recycleDeviceOffer: {
          offerId: '101112',
        },
        deviceRecycleIn: {
          promoValue: '100',
          bicLoanTerm: '20',
        },
        computedPrice: 1000,
        equipModel: 'Model 2',
        recycleDeviceSku: 'SKU2',
      },
      {
        recycleDeviceOffer: {
          offerId: '101112',
        },
        deviceRecycleIn: {
          bicLoanTerm: '20',
        },
        computedPrice: 1000,
        equipModel: 'Model 2',
        recycleDeviceSku: 'SKU2',
      },
      {
        deviceRecycleIn: {},
        computedPrice: 1000,
        equipModel: 'Model 2',
        recycleDeviceSku: 'SKU2',
      },
    ],
  },
};

const mockModelHeaderName = [
  'Item info',
  'Qty',
  'Price / Unit',
  'Down Payment',
  'Offer Amt',
  'Offer ID',
  'Manual Discount',
  'Reb Ind',
  'Tax',
  'Due Today',
  'Ware House',
];

const mockAllLines = [
  { value: '1234567890', label: 'Line 1' },
  { value: 'ALL', label: 'All Lines' },
];

describe('AdjustedDueModel Component', () => {
  test('renders AdjustedDueModel with selected value', () => {
    render(
      <AdjustedDueModel
        lineInfo={mockLineInfo}
        lineDetails={mockLineDetails}
        modelHeaderName={mockModelHeaderName}
        modalName='ADJUSTED_DUE_TODAY'
        selectedValue='1234567890'
        allLines={mockAllLines}
        hqUser
      />,
    );

    const adjustedDueModel = screen.getByTestId('Adjusted-due-model');
    expect(adjustedDueModel).toBeInTheDocument();
  });

  test('renders unknownModel with selected value', () => {
    render(
      <AdjustedDueModel
        lineInfo={mockLineInfo}
        lineDetails={mockLineDetails}
        modelHeaderName={mockModelHeaderName}
        modalName='UNKNOWN'
        selectedValue='1234567890'
        allLines={mockAllLines}
        hqUser
      />,
    );

    const adjustedDueModel = screen.getByTestId('Adjusted-due-model');
    expect(adjustedDueModel).toBeInTheDocument();
  });

  test('renders AdjustedDueModel with all lines selected', () => {
    render(
      <AdjustedDueModel
        lineInfo={mockLineInfo}
        lineDetails={mockLineDetails}
        modelHeaderName={mockModelHeaderName}
        modalName='ADJUSTED_DUE_TODAY'
        selectedValue='ALL'
        allLines={mockAllLines}
        hqUser
      />,
    );

    const adjustedDueModel = screen.getByTestId('Adjusted-due-model');
    expect(adjustedDueModel).toBeInTheDocument();
  });

  test('formats currency correctly', () => {
    render(
      <AdjustedDueModel
        lineInfo={mockLineInfo}
        lineDetails={mockLineDetails}
        modelHeaderName={mockModelHeaderName}
        modalName='ADJUSTED_DUE_TODAY'
        selectedValue='1234567890'
        allLines={mockAllLines}
      />,
    );

    expect(formatCurrency).toHaveBeenCalled();
  });

  test('handles empty lineInfo and lineDetails gracefully', () => {
    render(
      <AdjustedDueModel
        lineInfo={[]}
        lineDetails={{}}
        modelHeaderName={mockModelHeaderName}
        modalName='ADJUSTED_DUE_TODAY'
        selectedValue='1234567890'
        allLines={mockAllLines}
      />,
    );

    const adjustedDueModel = screen.getByTestId('Adjusted-due-model');
    expect(adjustedDueModel).toBeInTheDocument();
  });

  test('renders AdjustedDueModel with all functions covered', () => {
    render(
      <AdjustedDueModel
        lineInfo={mockLineInfo}
        lineDetails={mockLineDetails}
        modelHeaderName={mockModelHeaderName}
        modalName='ADJUSTED_DUE_TODAY'
        selectedValue='1234567890'
        allLines={mockAllLines}
      />,
    );

    const adjustedDueModel = screen.getByTestId('Adjusted-due-model');
    expect(adjustedDueModel).toBeInTheDocument();
  });

  test('renders AdjustedDueModel with all functions covered', () => {
    render(
      <AdjustedDueModel
        lineInfo={mockLineInfo}
        lineDetails={mockLineDetails}
        modelHeaderName={mockModelHeaderName}
        modalName='ITEMS_AT_GLANCE'
        selectedValue='1234567890'
        allLines={mockAllLines}
        hqUser
      />,
    );

    const adjustedDueModel = screen.getByTestId('Adjusted-due-model');
    expect(adjustedDueModel).toBeInTheDocument();
  });
  test('sets tradeInOfferPrice to 0 when promoValue and bicLoanTerm are not provided', () => {
    const mockLineDetailsWithNoPromoValue = {
      refundTradeInDetail: {
        tradeInItems: [
          {
            recycleDeviceOffer: {
              offerId: '789',
            },
            deviceRecycleIn: {},
            equipModel: 'Model 1',
            recycleDeviceSku: 'SKU1',
          },
        ],
      },
    };

    render(
      <AdjustedDueModel
        lineInfo={mockLineInfo}
        lineDetails={mockLineDetailsWithNoPromoValue}
        modelHeaderName={mockModelHeaderName}
        modalName='ADJUSTED_DUE_TODAY'
        selectedValue='1234567890'
        allLines={mockAllLines}
      />,
    );

    const adjustedDueModel = screen.getByTestId('Adjusted-due-model');
    expect(adjustedDueModel).toBeInTheDocument();
  });

  test('sets tradeInOfferPrice to computedPrice when recycleDeviceOffer is not provided', () => {
    const mockLineDetailsWithNoRecycleDeviceOffer = {
      refundTradeInDetail: {
        tradeInItems: [
          {
            recycleDeviceOffer: null,
            deviceRecycleIn: {
              promoValue: '50',
              bicLoanTerm: '10',
            },
            computedPrice: 500,
            equipModel: 'Model 1',
            recycleDeviceSku: 'SKU1',
          },
        ],
      },
    };

    render(
      <AdjustedDueModel
        lineInfo={mockLineInfo}
        lineDetails={mockLineDetailsWithNoRecycleDeviceOffer}
        modelHeaderName={mockModelHeaderName}
        modalName='ADJUSTED_DUE_TODAY'
        selectedValue='1234567890'
        allLines={mockAllLines}
      />,
    );

    const adjustedDueModel = screen.getByTestId('Adjusted-due-model');
    expect(adjustedDueModel).toBeInTheDocument();
  });

  test('sets tradeInOfferPrice to 0 when promoValue and bicLoanTerm are not provided', () => {
    const mockLineDetailsWithNoPromoValue = {
      refundTradeInDetail: {
        tradeInItems: [
          {
            recycleDeviceOffer: {
              offerId: '789',
            },
            deviceRecycleIn: {
              promoValue: null,
              bicLoanTerm: 10,
            },
            computedPrice: 500,
            equipModel: 'Model 1',
            recycleDeviceSku: 'SKU1',
          },
        ],
      },
    };

    render(
      <AdjustedDueModel
        lineInfo={mockLineInfo}
        lineDetails={mockLineDetailsWithNoPromoValue}
        modelHeaderName={mockModelHeaderName}
        modalName='ADJUSTED_DUE_TODAY'
        selectedValue='1234567890'
        allLines={mockAllLines}
      />,
    );

    const adjustedDueModel = screen.getByTestId('Adjusted-due-model');
    expect(adjustedDueModel).toBeInTheDocument();
  });
});
