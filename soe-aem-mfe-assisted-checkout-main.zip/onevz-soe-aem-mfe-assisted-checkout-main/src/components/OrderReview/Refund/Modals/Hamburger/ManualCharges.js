import React, { useState } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { Input } from '@vds/inputs';

const Grid = styled.div`
  display: flex;
  box-sizing: border-box;
  padding: 28px 36px;
`;

const Column = styled.div`
  grid-column: span 3 / span 4;
  padding-top: 0.5rem;
  padding-right: 2rem;
`;

const FormGroupStyled = styled.div`
  margin-bottom: 1rem;
`;

const InputWrapper = styled.div`
  [class^='InputContainer-VDS'] {
    border-radius: 0px;
  }
`;

const FormTextStyled = styled.label`
  display: block;
  margin-top: 0.5rem;
  font-size: 0.75rem;
  font-family: BrandFont-Text, Helvetica, Arial, sans-serif;
  color: rgb(116, 118, 118);
`;

const ManualCharges = (props) => {
  const [manualPrice, setManualPrice] = useState('');

  const handlePriceChange = (e) => {
    const { value } = e.target;
    props.handleManualPriceCorrection(value);
    setManualPrice(value);
  };

  return (
    <Grid data-testid='manualCharges'>
      <Column>
        <FormGroupStyled>
          <FormTextStyled>Manual price correction</FormTextStyled>
          <InputWrapper>
            <Input
              type='number'
              placeholder='$0.00'
              style={{ width: '100%' }}
              value={manualPrice}
              data-testid='manual-price-correction'
              onChange={handlePriceChange}
              errorText='Please enter a valid price'
            />
          </InputWrapper>
        </FormGroupStyled>
      </Column>
    </Grid>
  );
};
ManualCharges.propTypes = {
  handleManualPriceCorrection: PropTypes.func.isRequired,
};

export default ManualCharges;
