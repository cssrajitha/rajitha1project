import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import ManualCharges from './ManualCharges';

describe('ManualCharges Component', () => {
  let handleManualPriceCorrection;

  beforeEach(() => {
    handleManualPriceCorrection = jest.fn();
  });

  test('renders ManualCharges component', () => {
    const { getByTestId } = render(<ManualCharges handleManualPriceCorrection={handleManualPriceCorrection} />);
    expect(getByTestId('manualCharges')).toBeInTheDocument();
  });

  test('initial state of manualPrice is empty', () => {
    const { getByTestId } = render(<ManualCharges handleManualPriceCorrection={handleManualPriceCorrection} />);
    const input = getByTestId('manual-price-correction');
    expect(input.value).toBe('');
  });

  test('handlePriceChange function updates state and calls handleManualPriceCorrection', () => {
    const { getByTestId } = render(<ManualCharges handleManualPriceCorrection={handleManualPriceCorrection} />);
    const input = getByTestId('manual-price-correction');

    fireEvent.change(input, { target: { value: '100' } });
    expect(input.value).toBe('100');
    expect(handleManualPriceCorrection).toHaveBeenCalledWith('100');
  });

  test('handlePriceChange function handles empty input', () => {
    const { getByTestId } = render(<ManualCharges handleManualPriceCorrection={handleManualPriceCorrection} />);
    const input = getByTestId('manual-price-correction');

    fireEvent.change(input, { target: { value: '' } });
    expect(input.value).toBe('');
  });
});
