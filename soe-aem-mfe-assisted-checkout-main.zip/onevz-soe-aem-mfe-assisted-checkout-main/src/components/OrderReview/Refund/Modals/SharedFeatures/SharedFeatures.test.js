import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import SharedFeatureModal from './SharedFeatures';

describe('SharedFeatureModal', () => {
  const closeModalMock = jest.fn();

  const renderComponent = () => render(<SharedFeatureModal closeModal={closeModalMock} />);

  it('renders the modal with correct structure', () => {
    const { getByText, getByTestId } = renderComponent();

    // Check header
    expect(getByText('Shared Features')).toBeInTheDocument();
    expect(getByTestId('close-button')).toBeInTheDocument();

    // Check modal body
    expect(getByText('Existing Shared Features')).toBeInTheDocument();

    // Check footer
    expect(getByText('Done')).toBeInTheDocument();
  });

  it('calls closeModal when close button is clicked', () => {
    const { getByTestId } = renderComponent();
    fireEvent.click(getByTestId('close-button'));
    expect(closeModalMock).toHaveBeenCalled();
  });

  it('calls closeModal when Done button is clicked', () => {
    const { getByText } = renderComponent();
    fireEvent.click(getByText('Done'));
    expect(closeModalMock).toHaveBeenCalled();
  });
});
