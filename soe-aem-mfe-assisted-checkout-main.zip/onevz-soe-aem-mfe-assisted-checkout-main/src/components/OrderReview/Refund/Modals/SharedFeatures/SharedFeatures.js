import React from 'react';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import { ModalBody } from '@vds/modals';
import { Icon } from '@vds/icons';
import { Title } from '@vds/typography';
import { Button } from '@vds/buttons';
import { Divider, Header, TitleWrapperHeader } from '../AccountSection/AccountSection';

const FooterArea = styled.div`
  background-color: rgb(255, 255, 255);
  z-index: 1;
  bottom: 0px;
  position: fixed;
  width: 100%;
  display: flex;
  border-top: 1px solid rgb(204, 204, 204);
  justify-content: center;
`;

const Padding36 = styled.div`
  padding: 1.5rem 2rem;
`;
const SharedFeatureModal = (props) => (
  <div>
    <Header>
      <TitleWrapperHeader>
        <Title size='small' color='#000000' bold>
          <span className='bold font-18'>Shared Features</span>
        </Title>
        <IconWrapper onClick={props.closeModal} data-testid='close-button' name='close-glance'>
          <Icon name='close' size='medium' />
        </IconWrapper>
      </TitleWrapperHeader>
      <Divider />
    </Header>
    <ModalBody>
      <div>
        <div>
          <div>
            <div>
              <Title bold size='medium' className='u-paddingXExtraLarge u-paddingTopExtraLarge'>
                Existing Shared Features {}
              </Title>
            </div>
          </div>
        </div>
      </div>
    </ModalBody>

    <FooterArea>
      <Padding36>
        <Button use='primary' onClick={props.closeModal}>
          Done
        </Button>
      </Padding36>
    </FooterArea>
  </div>
);

SharedFeatureModal.propTypes = {
  closeModal: PropTypes.func,
};

export default SharedFeatureModal;

const IconWrapper = styled.div`
  cursor: pointer;
  color: #000000 !important;
`;
