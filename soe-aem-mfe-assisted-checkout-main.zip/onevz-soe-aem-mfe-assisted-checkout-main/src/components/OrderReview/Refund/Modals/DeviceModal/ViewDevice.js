import React from 'react';
import PropTypes from 'prop-types';
import styled, { createGlobalStyle } from 'styled-components';
import { formatCurrency } from 'onevzsoemfecommon/Helpers';
import { Icon } from '@vds/icons';
import { Title } from '@vds/typography';
import { Button as VdsButton } from '@vds/buttons';
import { formatMtnWithDecimals } from '../../../../../utils/common';

const Button = styled(VdsButton)`
  padding: 0 1.5rem 0 1.5rem;
`;

const ComponentStyle = createGlobalStyle`
  [class^='ModalDialog-VDS'] {
    padding-top: 0;
    width: 100%;
    max-width: 1133px !important;
    border-radius: 0 !important;
    padding-left: 0;
  }

  [class^='Overlay-VDS'] {
    background: rgb(0 0 0 / 70%);
  }

  [id="close-button"] {
    opacity: 0;
  }
`;

const ModalWrapper = styled.div`
  width: 100%;
  margin: 0 auto;
  position: relative;
`;

const ContentWrapper = styled.div`
  position: fixed;
  top: 150px;
  bottom: 60px;
  left: 52%;
  transform: translateX(-50%);
  width: 80%;
  max-width: 1133px;
  overflow-y: auto;
`;

const BackClickable = styled.a`
  cursor: pointer;
  color: #000000 !important;
  align-items: center;
  padding: 1.5rem 3rem 1.5rem 0;
  svg {
    width: 2.5rem;
    height: 2.5rem;
  }
`;

const Padding36 = styled.div`
  padding: 1.5rem 2rem;
`;

const HeaderSection = styled.div`
  max-width: 1133px;
  background-color: rgb(255, 255, 255);
  z-index: 2;
  position: fixed;
  width: 100%;
  display: flex;
  border-bottom: 1px solid #ccc;
  justify-content: center;
  left: 0;
  right: 0;
  top: 0;
  margin: 0 auto;
`;

const FlexAlignContainerItemsCenter = styled.div`
  display: flex;
  align-items: center !important;
  justify-content: space-between;
  width: 100%;
`;

const FooterArea = styled.div`
  max-width: 1133px;
  background-color: rgb(255, 255, 255);
  z-index: 1;
  bottom: 0px;
  position: fixed;
  width: 100%;
  display: flex;
  border-top: 1px solid;
  justify-content: center;
  left: 0;
  right: 0;
  margin: 0 auto;
`;

const FlexBoxGrowOne = styled.div`
  display: flex;
  flex-grow: 1;
  height: 7rem;
  align-items: center;
  gap: 0.3rem;
  padding-left: 50px;
`;

const CloseIconWrapper = styled.div`
  display: flex;
`;

const Marginleft = styled.div`
  margin-left: 20px;
`;

const ImageWrapper = styled.div`
  width: 140px;
  height: 220px;
`;

const DeviceImage = styled.img`
  width: 140px;
  height: 220px;
`;

const BodyWrapper = styled.div`
  padding-bottom: 60px;
`;

const DeviceTitle = styled.div`
  padding-bottom: 15px;
`;

const DeviceDetails = styled.div`
  flex: 1;
  padding-left: 2rem;
  padding-top: 30px;
`;

const DeviceDescription = styled.div`
  padding-bottom: 10px;
`;

const Grid = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
`;

const Col = styled.div`
  flex: 1;
`;

const ViewDevice = (props) => {
  const mobileNumber = formatMtnWithDecimals(props.deviceItem?.mobileNumber ?? '');
  const financeAmount = props.isNewItemSection
    ? props.lineInfo?.installmentContractDetail?.loanAmount
    : props.lineInfo?.rfexInstallmentContractDetail?.loanAmount;
  const channel = sessionStorage.getItem('channel');

  const getModalContent = (device, sim) => {
    const cartDescriptionName = () => ({ __html: `${device.deviceDisplayName || ''}` });
    const cartDescription = () => <div dangerouslySetInnerHTML={cartDescriptionName()} />;
    const rebates = device?.rebateOffer?.[0]?.rebateOffer ?? [];
    const sedOffers = device?.sedOfferList?.sedOffer ?? [];
    const getFinancedAmount = () => {
      if (device.type === 'exchange') {
        return financeAmount ? `${formatCurrency(financeAmount)}` : `${formatCurrency(device.itemPrice)}`;
      }
      return financeAmount ? `-${formatCurrency(financeAmount)}` : `-${formatCurrency(device.itemPrice)}`;
    };

    return (
      <BodyWrapper>
        <Grid>
          <ImageWrapper>
            <DeviceImage src={device?.imageUrlMap?.defaultImage} alt='img' />
          </ImageWrapper>
          <DeviceDetails>
            <DeviceTitle>
              <Title bold color='#0088ce'>
                {device.type === 'refund' ? 'Returned' : 'New Line'}
              </Title>
            </DeviceTitle>
            <DeviceDescription>
              <Title bold data-testid='cart-description'>
                {cartDescription()}
              </Title>
            </DeviceDescription>
            <DeviceDescription>
              <Title>SKU: {device.sorId}</Title>
            </DeviceDescription>
            {device?.deviceId && (
              <DeviceDescription>
                <Title>Device ID: {device?.deviceId}</Title>
              </DeviceDescription>
            )}
            {device?.type === 'refund' && sim?.deviceId && (
              <DeviceDescription>
                <Title>SIM ID: {sim?.deviceId}</Title>
              </DeviceDescription>
            )}
            {device.upgradeReasonDesc && (
              <DeviceDescription>
                <Title>Upgrade: {device.upgradeReasonDesc}</Title>
              </DeviceDescription>
            )}
            {props.lineInfo?.installmentInfo?.upgradeOptionCode === 'UO' && (
              <Title>Upgrade After - {props.lineInfo?.installmentInfo?.percentage} %</Title>
            )}
            {!channel?.includes('OMNI-INDIRECT') && device?.refundExchangeDetails?.itemRefundInd === 'P' && (
              <>
                <Grid>
                  <Col>
                    <Title>Financed amount</Title>
                  </Col>
                  <Col>
                    <Title>{getFinancedAmount()}</Title>
                  </Col>
                </Grid>
                {rebates.length > 0 &&
                  rebates.map((item) => (
                    <Grid key={item.id}>
                      <Col>
                        <Title>Rebate: {item.description} NO LONGER ELIGIBLE</Title>
                      </Col>
                      <Col>
                        <Title>{`(${formatCurrency(item.rebateAmount)})`}</Title>
                      </Col>
                    </Grid>
                  ))}
                {sedOffers.length > 0 &&
                  sedOffers.map((sedOffer) => (
                    <Grid key={sedOffer.id}>
                      <Col>
                        <Title>
                          {'SED_Offer : '}
                          {sedOffer.description}
                        </Title>
                      </Col>
                      <Col>
                        <Title>{formatCurrency(sedOffer.discAmt)}</Title>
                      </Col>
                    </Grid>
                  ))}
              </>
            )}
          </DeviceDetails>
        </Grid>
      </BodyWrapper>
    );
  };

  return (
    <>
      <ComponentStyle />
      <div>
        <ModalWrapper>
          <HeaderSection>
            <FlexAlignContainerItemsCenter>
              <FlexBoxGrowOne>
                <Title size='small' bold data-testid='view-device-header'>
                  Device for {mobileNumber}
                </Title>
              </FlexBoxGrowOne>
              <CloseIconWrapper>
                <Marginleft>
                  <BackClickable
                    data-testid='ViewDevice Modal is Closed'
                    data-track='ViewDevice Modal is Closed'
                    onClick={() => props.closeModal(props.isNewItemSection ? 'exchange' : 'refund')}
                  >
                    <Icon name='close' size='large' />
                  </BackClickable>
                </Marginleft>
              </CloseIconWrapper>
            </FlexAlignContainerItemsCenter>
          </HeaderSection>
          <ContentWrapper>
            {channel?.includes('OMNI-RETAIL')
              ? getModalContent(props.deviceItem, props.refundSIMCartItems?.[0])
              : getModalContent(props.deviceItem)}
            {props.isNewItemSection && channel?.includes('OMNI-RETAIL')
              ? getModalContent(
                  props.refundDeviceCartItems && props.refundDeviceCartItems[0],
                  props.refundSIMCartItems && props.refundSIMCartItems[0],
                )
              : ''}
          </ContentWrapper>
        </ModalWrapper>

        <FooterArea>
          <Padding36>
            <Button
              size='large'
              data-testid='done-button'
              data-track='done-button'
              onClick={() => props.closeModal(props.isNewItemSection ? 'exchange' : 'refund')}
            >
              Done
            </Button>
          </Padding36>
        </FooterArea>
      </div>
    </>
  );
};

ViewDevice.propTypes = {
  closeModal: PropTypes.func.isRequired,
  isNewItemSection: PropTypes.bool,
  deviceItem: PropTypes.object,
  lineInfo: PropTypes.object,
  refundDeviceCartItems: PropTypes.array,
  refundSIMCartItems: PropTypes.array,
};

export default ViewDevice;
