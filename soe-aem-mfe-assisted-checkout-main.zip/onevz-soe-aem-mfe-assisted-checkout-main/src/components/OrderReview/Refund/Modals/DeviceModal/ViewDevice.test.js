import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import { formatCurrency } from 'onevzsoemfecommon/Helpers';
import * as CommonUtils from '../../../../../utils/common';
import { formatMtnWithDecimals } from '../../../../../utils/common';
import ViewDevice from './ViewDevice';

jest.mock('../../../../../utils/common', () => ({
  ...jest.requireActual('../../../../../utils/common'),
  formatMtnWithDecimals: jest.fn(),
}));

beforeAll(() => {
  Storage.prototype.getItem = jest.fn((key) => {
    if (key === 'channel') return 'OMNI-RETAIL';
    return null;
  });
});

const mockProps = {
  closeModal: jest.fn(),
  isNewItemSection: true,
  deviceItem: {
    deviceDisplayName: 'Apple iPhone 15 Pro 1TB in Blue Titanium',
    mobileNumber: '2482417544',
    sorId: 'MTU63LL/A',
    itemPrice: '1499.99',
    deviceId: '352400477205377',
    imageUrlMap: {
      defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-pro-256gb-blue-titanium-mtqv3ll-a-a',
    },
    rebateOffer: [
      {
        count: 1,
        rebateOffer: [
          {
            code: 'ELIGIBLE',
            description: 'Test offer for Jenita Keran',
            sponsor: 'VZW',
            rebateAmount: '25.00',
            eligibilityInd: 'E',
            instantRebateFlag: '*',
            ruleId: '5054651',
            revokeRebate: false,
          },
        ],
      },
    ],
    sedOfferList: {
      sedOffer: [
        {
          id: '1',
          description: 'SED Offer 1',
          discAmt: '50.00',
        },
        {
          id: '2',
          description: 'SED Offer 2',
          discAmt: '75.00',
        },
      ],
    },
    priceType: 'VERIZON_EDGE',
    type: 'exchange',
    refundExchangeDetails: {
      itemRefundInd: 'P',
    },
  },
  lineInfo: {
    installmentContractDetail: {
      downPaymentAmount: 100,
      loanAmount: 1400,
    },
    rfexInstallmentContractDetail: {
      downPaymentAmount: 100,
      loanAmount: 1400,
    },
    installmentInfo: {
      upgradeOptionCode: 'UO',
      percentage: 50,
      installmentTerm: 24,
      monthlyInstallment: 58.33,
    },
    lineActivityType: 'EXC',
  },
  isReadOrder: false,
  history: {
    navigatePage: jest.fn(),
  },
  refundDeviceCartItems: [
    {
      deviceDisplayName: 'Apple iPhone 15 Pro 1TB in Blue Titanium',
      sorId: 'MTU63LL/A',
      itemPrice: '1499.99',
      deviceId: '352400477205377',
      imageUrlMap: {
        defaultImage:
          'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-pro-256gb-blue-titanium-mtqv3ll-a-a',
      },
      type: 'refund',
    },
  ],
  refundSIMCartItems: [
    {
      sorId: 'UNIVESIM5G-SAB-A',
      itemPrice: '0.00',
      type: 'refund',
      simId: '1234567890',
    },
  ],
};

describe('ViewDevice Component', () => {
  test('renders ViewDevice component', () => {
    render(<ViewDevice {...mockProps} />);
    expect(screen.getByTestId('view-device-header')).toHaveTextContent('Device for');
  });

  test('renders device details correctly', () => {
    render(<ViewDevice {...mockProps} />);
    expect(screen.getByText('Apple iPhone 15 Pro 1TB in Blue Titanium')).toBeInTheDocument();
    expect(screen.getByText('SKU: MTU63LL/A')).toBeInTheDocument();
    expect(screen.getByText('Device ID: 352400477205377')).toBeInTheDocument();
  });

  test('calls closeModal on Done button click when isNewItemSection is true', () => {
    render(<ViewDevice {...mockProps} />);
    fireEvent.click(screen.getByTestId('done-button'));
    expect(mockProps.closeModal).toHaveBeenCalledWith('exchange');
  });

  test('calls closeModal on Done button click when isNewItemSection is false', () => {
    const props = { ...mockProps, isNewItemSection: false };
    render(<ViewDevice {...props} />);
    fireEvent.click(screen.getByTestId('done-button'));
    expect(mockProps.closeModal).toHaveBeenCalledWith('refund');
  });

  test('calls closeModal on close icon click when isNewItemSection is true', () => {
    render(<ViewDevice {...mockProps} />);
    fireEvent.click(screen.getByTestId('ViewDevice Modal is Closed'));
    expect(mockProps.closeModal).toHaveBeenCalledWith('exchange');
  });

  test('calls closeModal on close icon click when isNewItemSection is false', () => {
    const props = { ...mockProps, isNewItemSection: false };
    render(<ViewDevice {...props} />);
    fireEvent.click(screen.getByTestId('ViewDevice Modal is Closed'));
    expect(mockProps.closeModal).toHaveBeenCalledWith('refund');
  });

  test('renders SIM ID when channel does not include OMNI-INDIRECT and sim has deviceId', () => {
    Storage.prototype.getItem = jest.fn((key) => {
      if (key === 'channel') return 'OMNI-RETAIL';
      return null;
    });
    const props = {
      ...mockProps,
      refundSIMCartItems: [
        {
          sorId: 'UNIVESIM5G-SAB-A',
          itemPrice: '0.00',
          type: 'refund',
          deviceId: '0987654321',
        },
      ],
    };
    render(<ViewDevice {...props} />);
    expect(screen.getAllByText('SIM ID: 0987654321')).toHaveLength(1);
  });

  test('does not render SIM ID when channel does not include OMNI-INDIRECT and sim does not have deviceId', () => {
    const props = {
      ...mockProps,
      refundSIMCartItems: [
        {
          sorId: 'UNIVESIM5G-SAB-A',
          itemPrice: '0.00',
          type: 'refund',
        },
      ],
    };
    render(<ViewDevice {...props} />);
    expect(screen.queryByText('SIM ID: 0987654321')).not.toBeInTheDocument();
  });

  test('renders upgrade reason description when device has upgradeReasonDesc', () => {
    const props = {
      ...mockProps,
      deviceItem: {
        ...mockProps.deviceItem,
        upgradeReasonDesc: 'Eligible for upgrade',
      },
    };
    render(<ViewDevice {...props} />);
    expect(screen.getByText('Upgrade: Eligible for upgrade')).toBeInTheDocument();
  });

  test('renders modal content with only device when channel does not include OMNI-INDIRECT', () => {
    render(<ViewDevice {...mockProps} />);
    expect(screen.queryByText('SIM ID: 1234567890')).not.toBeInTheDocument();
    expect(screen.getAllByText('Apple iPhone 15 Pro 1TB in Blue Titanium')).toHaveLength(1);
    expect(screen.getAllByText('SKU: MTU63LL/A')).toHaveLength(1);
    expect(screen.getAllByText('Device ID: 352400477205377')).toHaveLength(1);
  });

  test('formats mobile number correctly when mobile number is empty', () => {
    const propsWithEmptyMobileNumber = {
      ...mockProps,
      deviceItem: {
        ...mockProps.deviceItem,
        mobileNumber: '',
      },
    };
    render(<ViewDevice {...propsWithEmptyMobileNumber} />);
    expect(CommonUtils.formatMtnWithDecimals).toHaveBeenCalledWith('');
    expect(screen.getByText('Device for')).toBeInTheDocument();
  });

  test('renders correct amount for exchange when financeAmount is not present', () => {
    const props = {
      ...mockProps,
      deviceItem: {
        ...mockProps.deviceItem,
        type: 'exchange',
        itemPrice: 500,
      },
      lineInfo: {
        ...mockProps.lineInfo,
        installmentContractDetail: {
          downPaymentAmount: 100,
        },
        rfexInstallmentContractDetail: {
          downPaymentAmount: 100,
        },
      },
    };
    delete props.lineInfo.installmentContractDetail.loanAmount;
    delete props.lineInfo.rfexInstallmentContractDetail.loanAmount;

    render(<ViewDevice {...props} />);
    const expectedAmount = formatCurrency(props.deviceItem.itemPrice);
    expect(screen.getByText(expectedAmount)).toBeInTheDocument();
  });

  test('renders formatted mobile number when mobileNumber is an empty string', () => {
    const props = {
      ...mockProps,
      deviceItem: {
        ...mockProps.deviceItem,
      },
    };
    delete props.deviceItem.mobileNumber;

    render(<ViewDevice {...props} />);
    expect(formatMtnWithDecimals).toHaveBeenCalledWith(props.deviceItem?.mobileNumber ?? '');
  });

  test('renders empty string when deviceDisplayName is deleted', () => {
    const props = {
      ...mockProps,
      deviceItem: {
        ...mockProps.deviceItem,
      },
    };
    delete props.deviceItem.deviceDisplayName;

    render(<ViewDevice {...props} />);

    const cartDescriptionElements = screen.getAllByTestId('cart-description');
    expect(cartDescriptionElements[0]).toBeInTheDocument();
    expect(cartDescriptionElements[0].innerHTML).toBe('<div></div>');
  });

  test('renders correct amount for refund when financeAmount is not present', () => {
    const props = {
      ...mockProps,
      deviceItem: {
        ...mockProps.deviceItem,
        type: 'refund',
        itemPrice: 500,
      },
      lineInfo: {
        ...mockProps.lineInfo,
        installmentContractDetail: {
          downPaymentAmount: 100,
        },
        rfexInstallmentContractDetail: {
          downPaymentAmount: 100,
        },
      },
    };
    delete props.lineInfo.installmentContractDetail.loanAmount;
    delete props.lineInfo.rfexInstallmentContractDetail.loanAmount;

    render(<ViewDevice {...props} />);
    const expectedAmount = `-${formatCurrency(props.deviceItem.itemPrice)}`;
    expect(screen.getByText(expectedAmount)).toBeInTheDocument();
  });

  test('renders correct amount for refund when financeAmount is present', () => {
    const props = {
      ...mockProps,
      deviceItem: {
        ...mockProps.deviceItem,
        type: 'refund',
      },
      lineInfo: {
        ...mockProps.lineInfo,
        installmentContractDetail: {
          downPaymentAmount: 100,
          loanAmount: 300,
        },
        rfexInstallmentContractDetail: {
          downPaymentAmount: 100,
          loanAmount: 300,
        },
      },
    };

    render(<ViewDevice {...props} />);
    const expectedAmount = `-${formatCurrency(props.lineInfo.installmentContractDetail.loanAmount)}`;
    expect(screen.getByText(expectedAmount)).toBeInTheDocument();
  });

  test('renders SED offers correctly', () => {
    const props = {
      ...mockProps,
      deviceItem: {
        ...mockProps.deviceItem,
        sedOfferList: {
          sedOffer: [
            {
              id: '1',
              description: 'SED Offer 1',
              discAmt: '50.00',
            },
            {
              id: '2',
              description: 'SED Offer 2',
              discAmt: '75.00',
            },
          ],
        },
      },
    };

    render(<ViewDevice {...props} />);
    expect(screen.getByText('SED_Offer : SED Offer 1')).toBeInTheDocument();
    expect(screen.getByText(formatCurrency('50.00'))).toBeInTheDocument();
    expect(screen.getByText('SED_Offer : SED Offer 2')).toBeInTheDocument();
    expect(screen.getByText(formatCurrency('75.00'))).toBeInTheDocument();
  });
});
