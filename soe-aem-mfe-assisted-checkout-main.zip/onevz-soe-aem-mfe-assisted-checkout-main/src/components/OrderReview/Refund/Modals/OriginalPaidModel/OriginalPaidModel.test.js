import React from 'react';
import { render, screen } from '@testing-library/react';
import { formatCurrency } from 'onevzsoemfecommon/Helpers';
import OriginalPaidModel from './OriginalPaidModel';

jest.mock('onevzsoemfecommon/Helpers', () => ({
  formatCurrency: jest.fn((value) => `$${value}`),
}));

jest.mock('../../utils/utils');

const mockOriginalItem = [
  {
    mobileNumber: '1234567890',
    displayName: 'Device 1',
    itemCode: '123',
    qty: 1,
    itemPrice: 200,
    downPayment: 100,
    discAmt: 50,
    offerId: '789',
    manualDiscount: {
      discountAmount: 10,
    },
    downPaymentAmount: 50,
    taxAmount: 20,
    itemCost: 150,
    cartItemType: 'DEVICE',
    type: 'refund',
    sedOfferList: {
      sedOffer: [
        {
          discAmt: 100,
        },
      ],
    },
  },
  {
    mobileNumber: '1234567890',
    displayName: 'Device 1',
    itemCode: '123',
    qty: 1,
    itemPrice: 200,
    downPayment: 100,
    discAmt: 50,
    offerId: '789',
    manualDiscount: {
      discountAmount: 10,
    },
    downPaymentAmount: 50,
    taxAmount: 20,
    itemCost: 150,
    cartItemType: 'DEVICE',
    type: 'exchange',
    sedOfferList: {
      sedOffer: [
        {
          discAmt: 100,
        },
      ],
    },
  },
  {
    mobileNumber: '1234567890',
    displayName: 'Accessory 1',
    itemCode: '456',
    qty: 1,
    itemPrice: 100,
    downPayment: null,
    discAmt: null,
    offerId: null,
    manualDiscount: {
      discountAmount: null,
    },
    taxAmount: null,
    itemCost: null,
    cartItemType: 'ACCESSORY',
    type: 'exchange',
  },
  {
    mobileNumber: '1234567890',
    displayName: 'Trade-In 1',
    itemCode: '789',
    qty: 1,
    itemPrice: 300,
    downPayment: null,
    discAmt: 75,
    offerId: '101112',
    manualDiscount: {
      discountAmount: 15,
    },
    taxAmount: 25,
    itemCost: 275,
    cartItemType: 'TRADE_IN',
    type: 'refund',
    sedOfferList: {
      sedOffer: [
        {
          discAmt: 100,
        },
      ],
    },
  },
  {
    mobileNumber: '1234567890',
    displayName: 'Trade-In 1',
    itemCode: '789',
    qty: 1,
    itemPrice: 300,
    downPayment: null,
    discAmt: 75,
    offerId: '101112',
    manualDiscount: {
      discountAmount: 15,
    },
    taxAmount: 25,
    itemCost: 275,
    cartItemType: 'TRADE_IN',
    type: 'exchange',
    sedOfferList: {
      sedOffer: [
        {
          discAmt: 100,
        },
      ],
    },
  },
  {
    mobileNumber: '1234567890',
    displayName: 'Trade-In 1',
    itemCode: '789',
    itemPrice: 300,
    downPayment: null,
    discAmt: 75,
    manualDiscount: {
      discountAmount: 15,
    },
    taxAmount: 25,
    itemCost: 275,
    cartItemType: 'TRADE_IN',
    type: 'exchange',
    sedOfferList: {
      sedOffer: [
        {
          discAmt: 100,
        },
      ],
    },
  },
  {
    mobileNumber: '1234567890',
    displayName: 'Trade-In 1',
    itemCode: '789',
    qty: 1,
    itemPrice: 300,
    downPayment: null,
    discAmt: 75,
    offerId: '101112',
    manualDiscount: {
      discountAmount: 15,
    },
    taxAmount: 25,
    itemCost: 275,
    type: 'exchange',
    sedOfferList: {
      sedOffer: [
        {
          discAmt: 100,
        },
      ],
    },
  },
  {
    mobileNumber: '1234567890',
    displayName: 'Restock Fee 1',
    itemCode: '012',
    qty: 1,
    discountedPrice: 40,
    cartItemType: 'RESTOCKFEE',
  },
  {
    mobileNumber: '1234567890',
    displayName: 'Restock Fee 1',
    itemCode: '012',
    qty: 1,
    itemPrice: 50,
    cartItemType: 'RESTOCKFEE',
  },
];

const mockLineInfo = [
  {
    mobileNumber: '1234567890',
    serviceInfo: {
      primaryUserInfo: {
        firstName: 'John',
      },
      mtn: '1234567890',
    },
  },
];

const mockLineDetails = {
  refundTradeInDetail: {
    tradeInItems: [
      {
        recycleDeviceOffer: {
          offerId: '789',
        },
        deviceRecycleIn: {
          promoValue: '50',
          bicLoanTerm: '10',
        },
        computedPrice: 500,
        equipModel: 'Model 1',
        recycleDeviceSku: 'SKU1',
      },
    ],
  },
};

const mockModelHeaderName = [
  'Item info',
  'Qty',
  'Price / Unit',
  'Down Payment',
  'Offer Amt',
  'Offer ID',
  'Manual Discount',
  'Reb Ind',
  'Tax',
  'Due Today',
  'Ware House',
];

const mockAllLines = [
  { value: '1234567890', label: 'Line 1' },
  { value: 'ALL', label: 'All Lines' },
];

describe('OriginalPaidModel Component', () => {
  test('renders OriginalPaidModel with selected value', () => {
    render(
      <OriginalPaidModel
        originalItem={mockOriginalItem}
        lineInfo={mockLineInfo}
        lineDetails={mockLineDetails}
        modelHeaderName={mockModelHeaderName}
        selectedValue='1234567890'
        allLines={mockAllLines}
      />,
    );

    const originalPaidModel = screen.getByTestId('originalPaidModel');
    expect(originalPaidModel).toBeInTheDocument();
  });

  test('renders OriginalPaidModel with all lines selected', () => {
    render(
      <OriginalPaidModel
        originalItem={mockOriginalItem}
        lineInfo={mockLineInfo}
        lineDetails={mockLineDetails}
        modelHeaderName={mockModelHeaderName}
        selectedValue='ALL'
        allLines={mockAllLines}
      />,
    );

    const originalPaidModel = screen.getByTestId('originalPaidModel');
    expect(originalPaidModel).toBeInTheDocument();
  });

  test('formats currency correctly', () => {
    render(
      <OriginalPaidModel
        originalItem={mockOriginalItem}
        lineInfo={mockLineInfo}
        lineDetails={mockLineDetails}
        modelHeaderName={mockModelHeaderName}
        selectedValue='1234567890'
        allLines={mockAllLines}
      />,
    );

    expect(formatCurrency).toHaveBeenCalled();
  });

  test('handles empty lineInfo and lineDetails gracefully', () => {
    render(
      <OriginalPaidModel
        originalItem={[]}
        lineInfo={[]}
        lineDetails={{}}
        modelHeaderName={mockModelHeaderName}
        selectedValue='1234567890'
        allLines={mockAllLines}
      />,
    );

    const originalPaidModel = screen.getByTestId('originalPaidModel');
    expect(originalPaidModel).toBeInTheDocument();
  });
  test('renders OriginalPaidModel with all functions covered', () => {
    render(
      <OriginalPaidModel
        originalItem={mockOriginalItem}
        lineInfo={mockLineInfo}
        lineDetails={mockLineDetails}
        modelHeaderName={mockModelHeaderName}
        selectedValue='1234567890'
        allLines={mockAllLines}
      />,
    );

    const originalPaidModel = screen.getByTestId('originalPaidModel');
    expect(originalPaidModel).toBeInTheDocument();
  });
  test('sets tradeInOfferPrice to 0 when promoValue and bicLoanTerm are not provided', () => {
    const mockLineDetailsWithNoPromoValue = {
      refundTradeInDetail: {
        tradeInItems: [
          {
            recycleDeviceOffer: {
              offerId: '789',
            },
            deviceRecycleIn: {},
            equipModel: 'Model 1',
            recycleDeviceSku: 'SKU1',
          },
        ],
      },
    };

    render(
      <OriginalPaidModel
        originalItem={mockOriginalItem}
        lineInfo={mockLineInfo}
        lineDetails={mockLineDetailsWithNoPromoValue}
        modelHeaderName={mockModelHeaderName}
        selectedValue='1234567890'
        allLines={mockAllLines}
      />,
    );

    const originalPaidModel = screen.getByTestId('originalPaidModel');
    expect(originalPaidModel).toBeInTheDocument();
  });

  test('sets tradeInOfferPrice to computedPrice when recycleDeviceOffer is not provided', () => {
    const mockLineDetailsWithNoRecycleDeviceOffer = {
      refundTradeInDetail: {
        tradeInItems: [
          {
            recycleDeviceOffer: null,
            deviceRecycleIn: {
              promoValue: '50',
              bicLoanTerm: '10',
            },
            computedPrice: 500,
            equipModel: 'Model 1',
            recycleDeviceSku: 'SKU1',
          },
        ],
      },
    };

    render(
      <OriginalPaidModel
        originalItem={mockOriginalItem}
        lineInfo={mockLineInfo}
        lineDetails={mockLineDetailsWithNoRecycleDeviceOffer}
        modelHeaderName={mockModelHeaderName}
        selectedValue='1234567890'
        allLines={mockAllLines}
      />,
    );

    const originalPaidModel = screen.getByTestId('originalPaidModel');
    expect(originalPaidModel).toBeInTheDocument();
  });
  test('sets tradeInOfferPrice to 0 when promoValue and bicLoanTerm are not provided', () => {
    const mockLineDetailsWithNoPromoValue = {
      refundTradeInDetail: {
        tradeInItems: [
          {
            recycleDeviceOffer: {
              offerId: '789',
            },
            deviceRecycleIn: {
              promoValue: null,
              bicLoanTerm: 10,
            },
            computedPrice: 500,
            equipModel: 'Model 1',
            recycleDeviceSku: 'SKU1',
          },
        ],
      },
    };

    render(
      <OriginalPaidModel
        originalItem={mockOriginalItem}
        lineInfo={mockLineInfo}
        lineDetails={mockLineDetailsWithNoPromoValue}
        modelHeaderName={mockModelHeaderName}
        selectedValue='1234567890'
        allLines={mockAllLines}
      />,
    );

    const originalPaidModel = screen.getByTestId('originalPaidModel');
    expect(originalPaidModel).toBeInTheDocument();
  });
});
