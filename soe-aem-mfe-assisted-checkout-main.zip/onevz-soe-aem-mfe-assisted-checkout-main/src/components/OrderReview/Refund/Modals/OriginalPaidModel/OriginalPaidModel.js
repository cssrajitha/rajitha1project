import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { formatCurrency } from 'onevzsoemfecommon/Helpers';
import { getDiscountAmount, getItemCost, getDownPaymentAmount } from '../../utils/utils';

const OriginalPaidModelWrapper = styled.div`
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  margin: 1rem;
`;

const CustomerDetails = styled.div`
  display: flex;
  flex-wrap: wrap;
`;

const Details = styled.div``;

const Table = styled.div`
  width: 100%;
  border-collapse: collapse;
`;

const TableHead = styled.div`
  display: flex;
`;

const TableBody = styled.div``;

const TableHeader = styled.div`
  padding: 1rem 1rem 1rem 0rem !important;
  font-size: 14px;
  text-align: left;
  font-weight: bold;
  border-bottom: 1px solid #d8dada;
  line-height: 1.2;
  flex: 1;
`;

const TableRow = styled.div`
  display: flex;
  border-bottom: 1px solid #d8dada;
  max-width: 100%;
`;

const TableCell = styled.div`
  flex: 1;
  padding: 0.5rem;
`;

const Item = styled.div`
  font-size: 14px;
  font-weight: bold;
`;

const Name = styled.div`
  font-size: 20px;
  font-weight: bold;
`;

const HeaderXPadding = styled.div``;

const HeaderGrid = styled.div`
  display: flex;
  flex-wrap: nowrap;
  width: 100%;
`;

const getOfferId = (order) => {
  if (order.cartItemType === 'TRADE_IN') {
    return order.offerId ?? '';
  }
  return order.sedOfferList?.sedOffer?.[0]?.offerId ?? '0';
};

const getLocation = (order) => {
  if (order.cartItemType === 'DEVICE' || order.cartItemType === 'ACCESSORY') {
    return sessionStorage.getItem('location') ?? '-';
  }
  return '-';
};

const OriginalPaidModel = ({ originalItem, lineInfo, lineDetails, modelHeaderName, selectedValue, allLines }) => {
  const displayData = originalItem;
  const allLinesSelectedItems = allLines.filter((item) => {
    if (selectedValue === 'ALL') {
      allLines.pop();
      return item;
    }
    return item.value === selectedValue;
  });

  lineInfo?.forEach((line) => {
    lineDetails?.refundTradeInDetail?.tradeInItems?.forEach((item) => {
      const tradeInItem = {};
      const recycleDeviceOffer = item.recycleDeviceOffer ?? null;
      const offerId = item.recycleDeviceOffer?.offerId ?? '';
      const promoValue = Number(item.deviceRecycleIn?.promoValue ?? '0');
      const bicLoanTerm = Number(item.deviceRecycleIn?.bicLoanTerm ?? '0');
      let tradeInOfferPrice;
      if (recycleDeviceOffer && offerId > 0 && bicLoanTerm > 0) {
        if (promoValue && bicLoanTerm) {
          tradeInOfferPrice = Math.abs(promoValue / bicLoanTerm).toFixed(2);
        } else {
          tradeInOfferPrice = 0;
        }
      } else {
        tradeInOfferPrice = item.computedPrice;
      }
      tradeInItem.mobileNumber = line.mobileNumber;
      tradeInItem.type = 'refund';
      tradeInItem.description = item.equipModel;
      tradeInItem.downPaymentAmount = line.rfexInstallmentContractDetail?.downPaymentAmount;
      tradeInItem.cartItemType = 'TRADE_IN';
      tradeInItem.sorId = item.recycleDeviceSku;
      tradeInItem.qty = '1';
      tradeInItem.itemPrice = tradeInOfferPrice;

      tradeInItem.discAmt = offerId > 0 ? tradeInOfferPrice : 0;
      tradeInItem.offerId = offerId;

      tradeInItem.itemCost = tradeInOfferPrice;
      displayData.push(tradeInItem);
    });
  });

  return (
    <OriginalPaidModelWrapper data-testid='originalPaidModel'>
      {allLinesSelectedItems.map((line) => (
        <div key={`OriginalPaidModal-${line.value}`}>
          <CustomerDetails>
            <Details>
              <Name data-testid='name'>{line.serviceInfo?.primaryUserInfo?.firstName ?? ''}</Name>
              <Item data-testid='number'>{line.serviceInfo?.mtn ?? ''}</Item>
            </Details>
          </CustomerDetails>
          <HeaderXPadding>
            <HeaderGrid data-testid='headercol'>
              <Table>
                <TableHead>
                  {modelHeaderName.map((headerName) => (
                    <TableHeader key={`modelHeaderName-${headerName}`}>{headerName}</TableHeader>
                  ))}
                </TableHead>
                <TableBody>
                  {displayData
                    .filter((fil) => fil.mobileNumber === line.value)
                    .map((order, index) => (
                      <TableRow key={`AdjustedDueModel--${order.itemCode ?? index}`}>
                        <TableCell>
                          <Item>{order.displayName ?? ''}</Item>
                          <div>Item #: {order.itemCode ?? ''}</div>
                          <div>Status:</div>
                        </TableCell>
                        <TableCell>{order.qty ?? '-'}</TableCell>
                        <TableCell>{order.itemPrice ? formatCurrency(order.itemPrice) : formatCurrency('0')}</TableCell>
                        <TableCell>{getDownPaymentAmount(order)}</TableCell>
                        <TableCell>{getDiscountAmount(order)}</TableCell>
                        <TableCell>{getOfferId(order)}</TableCell>
                        <TableCell>
                          {order.manualDiscount?.discountAmount
                            ? formatCurrency(order.manualDiscount.discountAmount)
                            : formatCurrency('0')}
                        </TableCell>
                        <TableCell>-</TableCell>
                        <TableCell>{order.taxAmount ? formatCurrency(order.taxAmount) : formatCurrency('0')}</TableCell>
                        <TableCell>{getItemCost(order)}</TableCell>
                        <TableCell>{getLocation(order)}</TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </HeaderGrid>
          </HeaderXPadding>
        </div>
      ))}
    </OriginalPaidModelWrapper>
  );
};

OriginalPaidModel.propTypes = {
  originalItem: PropTypes.array,
  lineInfo: PropTypes.array,
  lineDetails: PropTypes.object,
  modelHeaderName: PropTypes.array,
  selectedValue: PropTypes.string,
  allLines: PropTypes.array,
};

export default OriginalPaidModel;
