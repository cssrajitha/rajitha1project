import React from 'react';
import { render, fireEvent, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import { addAppMessage } from 'onevzsoemfecommon/AppMessageActions';
import { useDispatch } from 'react-redux';
import CommonHeader from './index';
import { MODEL_POPUP } from '../../constants';

jest.mock('react-redux', () => ({
  useDispatch: jest.fn(),
}));

jest.mock('onevzsoemfeframework/DomService', () => ({
  isIpad: jest.fn(),
}));

jest.mock('onevzsoemfecommon/AppMessageActions', () => ({
  addAppMessage: jest.fn(),
}));

describe('CommonHeader Component', () => {
  let dispatch;

  const mockLineInfo = [
    {
      mobileNumber: '1234567890',
      serviceInfo: {
        primaryUserInfo: {
          firstName: 'John',
        },
        mtn: '1234567890',
      },
    },
  ];

  const mockLineDetails = {
    refundTradeInDetail: {
      tradeInItems: [
        {
          recycleDeviceOffer: {
            offerId: '789',
          },
          deviceRecycleIn: {
            promoValue: '50',
            bicLoanTerm: '10',
          },
          computedPrice: 500,
          equipModel: 'Model 1',
          recycleDeviceSku: 'SKU1',
        },
      ],
    },
  };

  const mockModelHeaderName = [
    'Item info',
    'Qty',
    'Price / Unit',
    'Down Payment',
    'Offer Amt',
    'Offer ID',
    'Manual Discount',
    'Reb Ind',
    'Tax',
    'Due Today',
    'Ware House',
  ];

  beforeEach(() => {
    dispatch = jest.fn();
    useDispatch.mockReturnValue(dispatch);
  });

  const defaultProps = {
    modelHeaderName: mockModelHeaderName,
    originalLines: [],
    lineInfo: [],
    ModelName: MODEL_POPUP.MANUAL_CHARGES,
    closeModal: jest.fn(),
    lineDetails: [],
    cartOrderHeader: {},
  };

  test('renders CommonHeader component with default case', () => {
    const props = { ...defaultProps, ModelName: 'UNKNOWN_MODEL' };
    render(<CommonHeader {...props} />);
  });

  test('renders CommonHeader component', () => {
    const { getByText } = render(<CommonHeader {...defaultProps} />);
    expect(getByText('Manual charges')).toBeInTheDocument();
  });

  test('closeModal function is called with correct arguments', () => {
    const props = { ...defaultProps, ModelName: MODEL_POPUP.ORGINAL_PAID };
    render(<CommonHeader {...props} />);
    const doneButton = screen.getByText('Done');
    fireEvent.click(doneButton);
  });

  test('initial state of manualPrice is empty and disableDone is false', () => {
    const { getByText } = render(<CommonHeader {...defaultProps} />);
    const doneButton = getByText('Done');
    expect(doneButton).not.toBeDisabled();
  });

  test('handleManualPriceCorrection function updates state and calls dispatch', () => {
    render(<CommonHeader {...defaultProps} />);
    const input = screen.getByTestId('manual-price-correction');

    fireEvent.change(input, { target: { value: '100' } });
    expect(input.value).toBe('100');
    expect(dispatch).not.toHaveBeenCalled();

    fireEvent.change(input, { target: { value: '2001' } });
    expect(dispatch).toHaveBeenCalledWith(
      addAppMessage('Adjustment Quantity cannot be greater than 2000', 'error', true, true),
    );
  });

  test('handleDoneVisibility function updates disableDone state', () => {
    render(<CommonHeader {...defaultProps} />);
    const input = screen.getByTestId('manual-price-correction');
    const doneButton = screen.getByText('Done');
    fireEvent.change(input, { target: { value: '100' } });
    expect(doneButton).not.toBeDisabled();
  });

  test('closeModal function is called with correct arguments', () => {
    const { getByText } = render(<CommonHeader {...defaultProps} />);
    const doneButton = getByText('Done');
    fireEvent.click(doneButton);
  });

  test('renders CommonHeader with ORGINAL_PAID model', () => {
    render(
      <CommonHeader
        modelHeaderName={mockModelHeaderName}
        ModelName={MODEL_POPUP.ORGINAL_PAID}
        lineInfo={mockLineInfo}
        lineDetails={mockLineDetails}
        closeModal={jest.fn()}
      />,
    );

    const title = screen.getByText('Order Due Today');
    expect(title).toBeInTheDocument();
  });

  test('renders CommonHeader with ADJUSTED_DUE_TODAY model', () => {
    render(
      <CommonHeader
        modelHeaderName={mockModelHeaderName}
        ModelName={MODEL_POPUP.ADJUSTED_DUE_TODAY}
        lineInfo={mockLineInfo}
        lineDetails={mockLineDetails}
        closeModal={jest.fn()}
      />,
    );

    const title = screen.getByText('Order Due Today');
    expect(title).toBeInTheDocument();
  });

  test('renders CommonHeader with ITEMS_AT_GLANCe model', () => {
    render(
      <CommonHeader
        modelHeaderName={mockModelHeaderName}
        ModelName={MODEL_POPUP.ITEMS_AT_GLANCE}
        lineInfo={mockLineInfo}
        lineDetails={mockLineDetails}
        closeModal={jest.fn()}
        hqUser
      />,
    );

    const title = screen.getByText('Items at a glance');
    expect(title).toBeInTheDocument();
  });

  test('calls closeModal on Done button click', () => {
    const closeModal = jest.fn();
    render(
      <CommonHeader
        modelHeaderName={mockModelHeaderName}
        ModelName={MODEL_POPUP.ADJUSTED_DUE_TODAY}
        lineInfo={mockLineInfo}
        lineDetails={mockLineDetails}
        closeModal={closeModal}
      />,
    );

    const doneButton = screen.getByText('Done');
    fireEvent.click(doneButton);
  });
});
