import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import styled, { createGlobalStyle } from 'styled-components';
import { Icon } from '@vds/icons';
import { useDispatch } from 'react-redux';
import { Title } from '@vds/typography';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { Modal, ModalTitle, ModalBody, ModalFooter } from '@vds/modals';
import OrderDetailsModel from '../OrderDetailsModel';
import { MODEL_POPUP } from '../../constants';

const ComponentStyle = createGlobalStyle`
  [class^='ModalDialogWrapper-VDS'][class*='view adjusted modal'] {
    padding:0rem 0rem 0rem 1.5rem !important;
  }

  [class^='ModalDialogWrapper-VDS'][class*='view original modal'] {
    padding:0rem 0rem 0rem 1.5rem !important;
  }

  [class^='StyledFooter-VDS'] {
      border-top: 1px solid #000;
      position: sticky;
      bottom:0;
      background: #fff;
      padding-top: 1.5rem;
      padding-bottom: 1.5rem;
    }
`;

const TitleWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const HorizontalDivider = styled.div`
  margin-top: 20px;
  border-bottom: 1px solid black;
  width: 100%;
`;

const ManualFooter = styled.div`
  width: 100%;
`;

const ManualChargesFooter = styled.div`
  position: fixed;
  bottom: 0px;
  justify-content: center;
  width: 100%;
  left: 0px;
  right: 0px;
  display: inline-flex;
  background-color: #fff;
  z-index: 1 !important;
  padding-top: 0.5rem;
`;

const CloseIconWrapper = styled.a`
  cursor: pointer;
  color: #000000 !important;
`;

function CommonHeader({ modelHeaderName, ModelName, originalLines, lineInfo, lineDetails, closeModal, hqUser }) {
  const [manualPrice, setManualPrice] = useState('');
  const [disableDone, setDisableDone] = useState(false);
  const dispatch = useDispatch();
  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;

  useEffect(() => {
    handleDoneVisibility();
  }, []);

  let defaultHeaderName;

  switch (ModelName) {
    case MODEL_POPUP.ORGINAL_PAID:
      defaultHeaderName = 'Order Due Today';
      break;
    case MODEL_POPUP.ADJUSTED_DUE_TODAY:
      defaultHeaderName = 'Order Due Today';
      break;
    case MODEL_POPUP.MANUAL_CHARGES:
      defaultHeaderName = 'Manual charges';
      break;
    case MODEL_POPUP.ITEMS_AT_GLANCE:
      defaultHeaderName = 'Items at a glance';
      break;
    default:
      break;
  }

  const handleManualPriceCorrection = (value) => {
    let newValue = value;
    if (newValue > 2000) {
      newValue = 0;
      dispatch(appMessageActions.addAppMessage('Adjustment Quantity cannot be greater than 2000', 'error', true, true));
    }
    setManualPrice(newValue);
    handleDoneVisibility(newValue);
  };

  const handleDoneVisibility = (value) => {
    let enableDoneButton = false;

    if (ModelName === MODEL_POPUP.MANUAL_CHARGES) {
      if (!value) {
        enableDoneButton = true;
      } else {
        enableDoneButton = false;
      }
    }

    setDisableDone(enableDoneButton);
    return enableDoneButton;
  };

  const handleRenderSearchBy = (Modelname) => {
    switch (Modelname) {
      case MODEL_POPUP.ORGINAL_PAID:
        return (
          <OrderDetailsModel
            lineInfo={lineInfo}
            modelHeaderName={modelHeaderName}
            ModelName={MODEL_POPUP.ORGINAL_PAID}
            lineDetails={lineDetails}
            originalLines={originalLines}
          />
        );
      case MODEL_POPUP.ADJUSTED_DUE_TODAY:
        return (
          <OrderDetailsModel
            lineInfo={lineInfo}
            modelHeaderName={modelHeaderName}
            ModelName={MODEL_POPUP.ADJUSTED_DUE_TODAY}
            lineDetails={lineDetails}
          />
        );
      case MODEL_POPUP.MANUAL_CHARGES:
        return (
          <OrderDetailsModel
            lineInfo={lineInfo}
            modelHeaderName={modelHeaderName}
            ModelName={MODEL_POPUP.MANUAL_CHARGES}
            handleManualPriceCorrection={handleManualPriceCorrection}
          />
        );
      case MODEL_POPUP.ITEMS_AT_GLANCE:
        return (
          <OrderDetailsModel
            lineInfo={lineInfo}
            modelHeaderName={modelHeaderName}
            ModelName={MODEL_POPUP.ITEMS_AT_GLANCE}
            lineDetails={lineDetails}
            hqUser={hqUser}
          />
        );
      default:
        return;
    }
  };

  return (
    <>
      <ComponentStyle />
      <Modal
        id='commonheader'
        opened
        fullScreenDialog
        surface='light'
        disableAnimation={false}
        disableOutsideClick={false}
        closeButton={null}
        width='100%'
      >
        <ModalTitle>
          <TitleWrapper>
            <Title size='small' bold>
              {defaultHeaderName}
            </Title>
            <CloseIconWrapper onClick={closeModal} data-testid='modal-close-button' data-track='modal-close-button'>
              <Icon name='close' size='large' />
            </CloseIconWrapper>
          </TitleWrapper>
        </ModalTitle>
        <HorizontalDivider />
        <ModalBody style={{ minHeight: '100vh' }}>
          <div>
            {ModelName !== MODEL_POPUP.MANUAL_CHARGES ? (
              <div>{handleRenderSearchBy(ModelName)}</div>
            ) : (
              handleRenderSearchBy(ModelName)
            )}
          </div>
        </ModalBody>
        {ModelName === MODEL_POPUP.MANUAL_CHARGES ? (
          <ManualChargesFooter>
            <ModalFooter
              surface={isDark ? 'dark' : 'light'}
              buttonData={{
                primary: {
                  children: 'Done',
                  width: 'auto',
                  onClick: () => closeModal('Done', manualPrice),
                  disabled: disableDone,
                },
              }}
            />
          </ManualChargesFooter>
        ) : (
          <>
            <ManualFooter />
            <ModalFooter
              surface={isDark ? 'dark' : 'light'}
              buttonData={{
                primary: {
                  children: 'Done',
                  width: 'auto',
                  onClick: closeModal,
                },
              }}
            />
          </>
        )}
      </Modal>
    </>
  );
}

CommonHeader.propTypes = {
  modelHeaderName: PropTypes.array.isRequired,
  originalLines: PropTypes.array,
  lineInfo: PropTypes.array.isRequired,
  ModelName: PropTypes.string.isRequired,
  closeModal: PropTypes.func.isRequired,
  lineDetails: PropTypes.array,
  hqUser: PropTypes.bool,
};

export default CommonHeader;
