import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import OrderDetailsModel from './OrderDetailsModel';
import { MODEL_POPUP } from '../constants';

jest.mock('./AdjustedDueModel/AdjustedDueModel', () => jest.fn(() => <div />));
jest.mock('./OriginalPaidModel/OriginalPaidModel', () => jest.fn(() => <div />));
jest.mock('./Hamburger/ManualCharges', () => jest.fn(() => <div />));

const mockLineInfo = [
  {
    mobileNumber: '1234567890',
    serviceInfo: {
      primaryUserInfo: {
        firstName: 'John',
      },
      mtn: '1234567890',
    },
    itemsInfo: [
      {
        refundCartItems: {
          cartItem: [
            {
              cartItemType: 'DEVICE',
              deviceDisplayName: 'Device 1',
              downPaymentAmount: 100,
              itemPrice: 200,
              deviceId: '1234567890',
              qty: 1,
              sorId: '123',
              type: 'refund',
            },
          ],
        },
        cartItems: {
          cartItem: [
            {
              cartItemType: 'ACCESSORY',
              deviceDisplayName: 'Accessory 1',
              downPaymentAmount: 50,
              itemPrice: 100,
              qty: 1,
              sorId: '456',
              type: 'exchange',
            },
          ],
        },
      },
    ],
  },
  {
    mobileNumber: '0987654321',
    serviceInfo: {
      primaryUserInfo: {
        firstName: 'Doe',
      },
      mtn: '0987654321',
    },
    itemsInfo: [
      {
        refundCartItems: {
          cartItem: [
            {
              cartItemType: 'DEVICE',
              deviceDisplayName: 'Device 2',
              downPaymentAmount: 150,
              itemPrice: 250,
              qty: 1,
              sorId: '789',
              type: 'refund',
            },
          ],
        },
        cartItems: {
          cartItem: [
            {
              cartItemType: 'ACCESSORY',
              deviceDisplayName: 'Accessory 2',
              downPaymentAmount: 75,
              itemPrice: 150,
              qty: 1,
              sorId: '012',
              type: 'exchange',
            },
          ],
        },
      },
    ],
  },
];

const mockOriginalLines = [
  {
    mobileNumber: '1234567890',
    itemOrderDetails: {
      items: {
        item: [
          {
            itemCode: '123',
            displayName: 'Device 1',
            qty: 1,
            itemPrice: 200,
            deviceId: '1234567890',
            downPayment: 100,
            discAmt: 50,
            offerId: '789',
            manualDiscount: {
              discountAmount: 10,
            },
            taxAmount: 20,
            itemCost: 150,
            cartItemType: 'DEVICE',
            type: 'refund',
          },
        ],
      },
    },
  },
  {
    mobileNumber: '0987654321',
    itemOrderDetails: {
      items: {
        item: [
          {
            itemCode: '123',
            displayName: 'Device 2',
            qty: 1,
            itemPrice: 200,
            downPayment: 100,
            discAmt: 50,
            offerId: '789',
            manualDiscount: {
              discountAmount: 10,
            },
            taxAmount: 20,
            itemCost: 150,
            cartItemType: 'DEVICE',
            type: 'exchange',
          },
        ],
      },
    },
  },
];

const mockLineDetails = {
  refundTradeInDetail: {
    tradeInItems: [
      {
        recycleDeviceOffer: {
          offerId: '789',
        },
        deviceRecycleIn: {
          promoValue: '50',
          bicLoanTerm: '10',
        },
        computedPrice: 500,
        equipModel: 'Model 1',
        recycleDeviceSku: 'SKU1',
      },
      {
        deviceRecycleIn: {
          bicLoanTerm: '10',
        },
        computedPrice: 500,
        equipModel: 'Model 2',
        recycleDeviceSku: 'SKU2',
      },
    ],
  },
};

const mockModelHeaderName = [
  'Item info',
  'Qty',
  'Price / Unit',
  'Down Payment',
  'Offer Amt',
  'Offer ID',
  'Manual Discount',
  'Reb Ind',
  'Tax',
  'Due Today',
  'Ware House',
];

const mockRefundOrderDetails = {};

describe('OrderDetailsModel Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  test('renders OrderDetailsModel with AdjustedDueModel', () => {
    render(
      <OrderDetailsModel
        modelHeaderName={mockModelHeaderName}
        lineDetails={mockLineDetails}
        lineInfo={mockLineInfo}
        ModelName={MODEL_POPUP.ADJUSTED_DUE_TODAY}
        refundOrderDetails={mockRefundOrderDetails}
      />,
    );

    const orderDetailsModel = screen.getByTestId('order-details-model');
    expect(orderDetailsModel).toBeInTheDocument();
  });

  test('renders OrderDetailsModel with OriginalPaidModel', () => {
    render(
      <OrderDetailsModel
        modelHeaderName={mockModelHeaderName}
        originalLines={mockOriginalLines}
        lineDetails={mockLineDetails}
        lineInfo={mockLineInfo}
        ModelName={MODEL_POPUP.ORGINAL_PAID}
        refundOrderDetails={mockRefundOrderDetails}
      />,
    );

    const orderDetailsModel = screen.getByTestId('order-details-model');
    expect(orderDetailsModel).toBeInTheDocument();

    const dropdownButton = screen.getByTestId('select');
    expect(dropdownButton).toBeInTheDocument();

    fireEvent.click(dropdownButton);
    expect(screen.getByText('All Lines')).toBeInTheDocument();

    fireEvent.keyDown(dropdownButton, { key: 'Enter' });
    expect(screen.getByText('All Lines')).toBeInTheDocument();

    fireEvent.keyDown(dropdownButton, { key: ' ' });
    expect(screen.getByText('All Lines')).toBeInTheDocument();

    fireEvent.keyDown(dropdownButton, { key: 'something' });
  });

  test('renders OrderDetailsModel with empty data', () => {
    const emptyString = '';
    render(
      <OrderDetailsModel
        modelHeaderName={mockModelHeaderName}
        originalLines={[]}
        lineDetails={[]}
        lineInfo={[]}
        ModelName={emptyString}
        refundOrderDetails={[]}
      />,
    );

    const orderDetailsModel = screen.getByTestId('order-details-model');
    expect(orderDetailsModel).toBeInTheDocument();
  });

  test('handles empty lineInfo and lineDetails 1', () => {
    render(
      <OrderDetailsModel
        modelHeaderName={mockModelHeaderName}
        lineDetails={[]}
        lineInfo={[]}
        ModelName={MODEL_POPUP.ADJUSTED_DUE_TODAY}
        refundOrderDetails={[]}
      />,
    );

    const orderDetailsModel = screen.getByTestId('order-details-model');
    expect(orderDetailsModel).toBeInTheDocument();
  });

  test('handles empty lineInfo and lineDetails 1', () => {
    render(
      <OrderDetailsModel
        modelHeaderName={mockModelHeaderName}
        lineDetails={[]}
        lineInfo={[]}
        ModelName={MODEL_POPUP.ITEMS_AT_GLANCE}
        refundOrderDetails={[]}
        hqUser
      />,
    );

    const orderDetailsModel = screen.getByTestId('order-details-model');
    expect(orderDetailsModel).toBeInTheDocument();
  });

  test('handles empty lineInfo and lineDetails 2', () => {
    render(
      <OrderDetailsModel
        modelHeaderName={mockModelHeaderName}
        originalLines={[]}
        lineDetails={[]}
        lineInfo={[]}
        ModelName={MODEL_POPUP.ORGINAL_PAID}
        refundOrderDetails={[]}
      />,
    );

    const orderDetailsModel = screen.getByTestId('order-details-model');
    expect(orderDetailsModel).toBeInTheDocument();
  });

  test('handles click outside to close dropdown', () => {
    render(
      <OrderDetailsModel
        modelHeaderName={mockModelHeaderName}
        originalLines={mockOriginalLines}
        lineDetails={mockLineDetails}
        lineInfo={mockLineInfo}
        ModelName={MODEL_POPUP.ADJUSTED_DUE_TODAY}
        refundOrderDetails={mockRefundOrderDetails}
      />,
    );

    expect(screen.queryByText('Line 1')).not.toBeInTheDocument();
  });

  test('renders null for unknown ModelName', () => {
    render(
      <OrderDetailsModel
        modelHeaderName={mockModelHeaderName}
        originalLines={mockOriginalLines}
        lineDetails={mockLineDetails}
        lineInfo={mockLineInfo}
        ModelName='UNKNOWN_MODEL'
        refundOrderDetails={mockRefundOrderDetails}
      />,
    );

    const orderDetailsModel = screen.getByTestId('order-details-model');
    expect(orderDetailsModel).toBeInTheDocument();
  });

  test('handles dropdown option change', () => {
    render(
      <OrderDetailsModel
        modelHeaderName={mockModelHeaderName}
        originalLines={mockOriginalLines}
        lineDetails={[]}
        lineInfo={mockLineInfo}
        ModelName={MODEL_POPUP.ORGINAL_PAID}
      />,
    );

    const dropdown = screen.getByTestId('select');
    fireEvent.change(dropdown, { target: { value: '0987654321' } });
  });
  test('renders OrderDetailsModel with ManualCharges', () => {
    render(
      <OrderDetailsModel
        handleManualPriceCorrection={jest.fn()}
        ModelName={MODEL_POPUP.MANUAL_CHARGES}
        lineInfo={mockLineInfo}
      />,
    );
  });

  test('renders OrderDetailsModel with ManualCharges with empty lineInfo', () => {
    render(
      <OrderDetailsModel
        handleManualPriceCorrection={jest.fn()}
        ModelName={MODEL_POPUP.MANUAL_CHARGES}
        lineInfo={[]}
      />,
    );
  });
  test('sets defaultOptionsvalue for MANUAL_CHARGES', () => {
    render(
      <OrderDetailsModel
        handleManualPriceCorrection={jest.fn()}
        ModelName={MODEL_POPUP.MANUAL_CHARGES}
        lineInfo={mockLineInfo}
      />,
    );
  });
});
