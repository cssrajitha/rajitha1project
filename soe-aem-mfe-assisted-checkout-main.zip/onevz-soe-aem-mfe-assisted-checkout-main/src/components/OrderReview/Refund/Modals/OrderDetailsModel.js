import React, { useState } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { DropdownSelect } from '@vds/selects';
import { Body } from '@vds/typography';
import AdjustedDueModel from './AdjustedDueModel/AdjustedDueModel';
import OriginalPaidModel from './OriginalPaidModel/OriginalPaidModel';
import ManualCharges from './Hamburger/ManualCharges';
import { MODEL_POPUP } from '../constants';

const CustomerDetails = styled.div`
  display: flex;
  flex-wrap: wrap;
  margin-left: 0.5rem;
`;

const Details = styled.div`
  font-weight: bold;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
`;

const Item = styled.div`
  font-size: 14px;
`;

const Name = styled.div`
  font-size: 20px;
`;

const Container = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0;
  margin-top: 1rem;
`;

const Column = styled.div`
  width: 100%;
  &.col-4 {
    width: 18%;
  }
  margin-left: 0.5rem;
`;

const Divider = styled.div`
  border-bottom: 1px solid #d8dada;
`;

const OrderDetailsModel = ({
  modelHeaderName,
  originalLines,
  lineDetails,
  lineInfo,
  ModelName,
  handleManualPriceCorrection,
  hqUser,
}) => {
  const firstName = lineInfo?.[0]?.serviceInfo?.primaryUserInfo?.firstName ?? '';

  // dropdown defaultOptions value
  let defaultOptionsvalue;

  switch (ModelName) {
    case MODEL_POPUP.ORGINAL_PAID:
      defaultOptionsvalue = lineInfo?.[0]?.mobileNumber ?? '';
      break;
    case MODEL_POPUP.ADJUSTED_DUE_TODAY:
      defaultOptionsvalue = lineInfo?.[0]?.mobileNumber ?? '';
      break;
    case MODEL_POPUP.MANUAL_CHARGES:
      defaultOptionsvalue = lineInfo[0]?.mobileNumber || '';
      break;
    case MODEL_POPUP.ITEMS_AT_GLANCE:
      defaultOptionsvalue = lineInfo[0]?.mobileNumber || '';
      break;
    default:
      break;
  }

  const defaultOptions = { label1: firstName, label2: defaultOptionsvalue, value: defaultOptionsvalue };
  const [itemsAllines, setItemsAllines] = useState(defaultOptions);
  const [showMenu, setShowMenu] = useState(true);

  console.log(showMenu);

  const onAllLinesChange = (e) => {
    // dropdown onchange event
    setItemsAllines({ label1: e.label1, label2: e.label2, value: e.value });
  };

  // Order Due Today Mapping details start
  const allLinesOrderDueToday = [];
  const originalItem = [];
  originalLines?.forEach((originalLine) => {
    const allLinesOrderDueTodayData = { value: originalLine.mobileNumber, label: firstName };
    allLinesOrderDueToday.push(allLinesOrderDueTodayData);
    originalLine.itemOrderDetails.items.item.forEach((originalItemMap) => {
      const newItemMap = { ...originalItemMap, mobileNumber: originalLine.mobileNumber };
      originalItem.push(newItemMap);
    });
  });
  // Order Due Today Mapping details end

  // Here start review cart
  let AllLines = [];

  lineInfo?.forEach((item, index) => {
    item.itemsInfo?.forEach(() => {
      const AllLinesData = { value: lineInfo[index].mobileNumber, label: firstName };
      AllLines.push(AllLinesData);
    });
  });

  // Model Based on change dropdown Binding values and hidden start
  if (ModelName === MODEL_POPUP.ORGINAL_PAID) {
    AllLines = allLinesOrderDueToday.map((item) => ({ label1: firstName, label2: item.value, value: item.value }));
  } else if (ModelName === MODEL_POPUP.ADJUSTED_DUE_TODAY || ModelName === MODEL_POPUP.ITEMS_AT_GLANCE) {
    AllLines = AllLines.map((item) => ({ label1: firstName, label2: item.value, value: item.value }));
  }
  // Model Based on change dropdown Binding values and hidden end
  if (AllLines.length > 1) {
    AllLines.push({ label1: 'All Lines', label2: '', value: 'ALL' });
  }

  const handleRenderSearchBy = (ModelNames) => {
    switch (ModelNames) {
      case MODEL_POPUP.ADJUSTED_DUE_TODAY:
        return (
          <AdjustedDueModel
            lineInfo={lineInfo}
            modelHeaderName={modelHeaderName}
            selectedValue={itemsAllines.value}
            allLines={AllLines}
            modalName={MODEL_POPUP.ADJUSTED_DUE_TODAY}
            lineDetails={lineDetails}
          />
        );
      case MODEL_POPUP.ORGINAL_PAID:
        return (
          <OriginalPaidModel
            modelHeaderName={modelHeaderName}
            selectedValue={itemsAllines.value}
            allLines={AllLines}
            lineInfo={lineInfo}
            originalItem={originalItem}
            modalName={MODEL_POPUP.ORGINAL_PAID}
            lineDetails={lineDetails}
          />
        );
      case MODEL_POPUP.MANUAL_CHARGES:
        return <ManualCharges handleManualPriceCorrection={handleManualPriceCorrection} />;
      case MODEL_POPUP.ITEMS_AT_GLANCE:
        return (
          <AdjustedDueModel
            lineInfo={lineInfo}
            modelHeaderName={modelHeaderName}
            selectedValue={itemsAllines.value}
            allLines={AllLines}
            modalName={MODEL_POPUP.ITEMS_AT_GLANCE}
            lineDetails={lineDetails}
            hqUser={hqUser}
          />
        );
      default:
        return null;
    }
  };

  return ModelName !== MODEL_POPUP.MANUAL_DISCOUNT && ModelName !== MODEL_POPUP.MANUAL_CHARGES ? (
    <Container data-testid='order-details-model'>
      {AllLines.length > 1 ? (
        <Column className='col-12'>
          <Column
            className='col-4'
            role='button'
            tabIndex={0}
            onClick={() => setShowMenu(true)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                setShowMenu(true);
              }
            }}
          >
            <DropdownSelect
              error={false}
              disabled={false}
              readOnly={false}
              inlineLabel
              data-testid='select'
              onChange={(e) => {
                const selectedOption = AllLines.find((option) => option.value === e.target.value);
                onAllLinesChange(selectedOption);
              }}
            >
              <Divider />
              {AllLines.map((line) => (
                <option key={line.value} value={line.value}>
                  <Body size='medium' color='#000000' bold={false}>
                    {line.label1}
                  </Body>
                  <Body size='medium' color='#000000' bold={false}>
                    {line.label2}
                  </Body>
                </option>
              ))}
            </DropdownSelect>
          </Column>
        </Column>
      ) : (
        <CustomerDetails>
          <Details>
            <Name data-testid='name'> {firstName}</Name>
            <Item data-testid='number'>{itemsAllines.value}</Item>
          </Details>
        </CustomerDetails>
      )}
      <div className='u-paddingBottom100'>{handleRenderSearchBy(ModelName)}</div>
    </Container>
  ) : (
    handleRenderSearchBy(ModelName)
  );
};

OrderDetailsModel.propTypes = {
  modelHeaderName: PropTypes.array,
  originalLines: PropTypes.array,
  lineDetails: PropTypes.object,
  lineInfo: PropTypes.array,
  ModelName: PropTypes.string,
  handleManualPriceCorrection: PropTypes.func,
  hqUser: PropTypes.bool,
};

export default OrderDetailsModel;
