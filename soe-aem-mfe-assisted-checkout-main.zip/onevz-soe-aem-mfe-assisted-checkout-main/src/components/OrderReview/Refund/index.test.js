import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
// import { useNavigate } from 'react-router';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';

import { useDispatch } from 'react-redux';
import '@testing-library/jest-dom/extend-expect';
import { isIpad } from 'onevzsoemfeframework/DomService';
import {
  useLazyGetCartDetailsQuery,
  useLazyGetReadOrderQuery,
  useLazyLpRetrieveCompleteOrderDetailsQuery,
  useLazyGetOrderWriteQuery,
  useLazyGetAccountAddressValidationQuery,
  useLazyGetRetrieveInstallmentAgreementQuery,
  useLazyGetRetrievePaymentOptionsQuery,
} from '../../../modules/services/APIService/APIServiceCallHook';
import Refund from './index';
import GetAccessApiCallHook from '../../../modules/services/APIService/GetAccessAPICallHook';
import { readOrderResponse } from './__mock__/readOrderResponse';
import { retrievecompleteOrderResponse } from './__mock__/retrievecompleteOrderResponse';
import { useLazyGetValidateCartAndCheckoutQuery } from '../../../modules/services/APIService/APIServiceHooks';
import { orderWriteResponse } from './__mock__/orderWrite';
import { retrieveInstallmentAgreementResponse } from './__mock__/retrieveInstallmentAgreement';
import { getAccountAdressValidationResult } from './__mock__/getAccountAddressValidation';
import { showShippingAddress } from '../../../utils/orderreviewUtil';
import EmailApiCallHook from '../../../modules/services/APIService/EmailApiCallHook';
import InfoApiCallHook from '../../../modules/services/APIService/InfoAPICallHook';
import { NotificationTagging } from '../../../utils/tagging';

jest.mock('../../../modules/services/APIService/GetAccessAPICallHook', () => jest.fn());
jest.mock('../../../modules/services/APIService/EmailApiCallHook', () => jest.fn());
jest.mock('../../../modules/services/APIService/InfoAPICallHook', () => jest.fn());
jest.mock('../../../pages/home/container/orderreviewApiCallHook', () => jest.fn());

jest.mock('../ViewOrderDocument/ViewOrderDocument', () => () => (
  <div data-testid='mock-ViewOrderDocument'>
    Mocked ViewOrderDocument Component
    <div>value:{true} </div>
    <div>readorder:{true} </div>
    <div>orderNo:{12345}</div>
  </div>
));

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradlePropertyV2: () => ['TRUE'],
  }),
  { virtual: true }
);

jest.mock('onevzsoemfecommon/APIService', () => ({
  ...jest.requireActual('onevzsoemfecommon/APIService'),
  useLazyGetFetchDownpaymentQuery: () => [
    () => {},
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: {
        fetchDownPaymentResponse: [
          {
            mtn: '6037312091',
            customerName: 'BEN MANUEL',
            deviceFinanceLimit: 2500,
            totalFinanceLimit: 7000,
            sorId: 'MTQP3LL/A',
            firstMonthPrice: 28.04,
            remaingingMonthPrice: 27.77,
            dpTerm: 36,
            downPayment: '0.0',
            deviceDescription: 'iPhone 15 Pro',
            devicePrice: '999.99',
            maxDownPaymentAmount: 999.63,
            showSellerPrice: false,
            taxAmount: 0,
            spendingLimitAmountExceededBy: '0.0',
            spendingLimitAmountExceeded: false,
            mandatoryDownPayment: 0,
            userSelectedDownPayment: 0,
            instantCreditDownPayment: 0,
            totalDeviceDollar: 0,
            totalRemainingDeviceDollar: 0,
            totalUsedDeviceDollar: 0,
            deviceDollarDownpayment: 0,
            deviceDownPayment: 0,
            vzDollarTotalAmount: 0,
            vzDollarUsedByLine: 0,
            vzDollarUsedByAllLines: 0,
            discountedPrice: 999.99,
          },
          {
            customerName: 'BEN MANUEL',
            deviceFinanceLimit: 2500,
            totalFinanceLimit: 7000,
            sorId: 'MTQP3LL/A',
            firstMonthPrice: 28.04,
            remaingingMonthPrice: 27.77,
            dpTerm: 36,
            deviceDescription: 'iPhone 15 Pro',
            devicePrice: '999.99',
            maxDownPaymentAmount: 999.63,
            showSellerPrice: false,
            taxAmount: 0,
            spendingLimitAmountExceededBy: '0.0',
            spendingLimitAmountExceeded: false,
            mandatoryDownPayment: 0,
            userSelectedDownPayment: 0,
            instantCreditDownPayment: 0,
            totalDeviceDollar: 0,
            totalRemainingDeviceDollar: 0,
            totalUsedDeviceDollar: 0,
            deviceDollarDownpayment: 0,
            deviceDownPayment: 0,
            vzDollarTotalAmount: 0,
            vzDollarUsedByLine: 0,
            vzDollarUsedByAllLines: 0,
            discountedPrice: 999.99,
          },
        ],
      },
    },
  ],
}));

jest.mock('onevzsoemfeframework/DomService', () => ({
  isIpad: jest.fn(),
}));

jest.mock('onevzsoemfeframework/AssistedCradleService', () => ({
  __esModule: true,
  ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
  getAssistedCradlePropertyV2: jest.fn(), // Ensure it's a Jest mock function
}));

jest.mock('onevzsoemfecommon/ViewExitDialog');

jest.mock('../../PaymentHistory/PaymentHistory', () => () => (
  <div data-testid='payment-history-modal'>
    Mocked PaymentHistoryModal Component
    <div>value:{true} </div>
    <div>readorder:{true} </div>
    <div>orderNo:{12345}</div>
  </div>
));

jest.mock('react-redux', () => ({
  ...jest.requireActual('react-redux'),
  useDispatch: jest.fn(),
}));

const mockNavigate = jest.fn();
jest.mock('react-router', () => ({
  ...jest.requireActual('react-router'),
  useNavigate: () => mockNavigate,
}));
// const navigate = useNavigate();

jest.mock('onevzsoemfecommon/Helpers', () => ({
  getQueryParamByName: jest.fn(),
  setIntentType: jest.fn(),
  getUIContextPath: jest.fn(),
}));
jest.mock('../../../utils/tagging');

jest.mock('../../../modules/services/APIService/APIServiceCallHook', () => ({
  useLazyGetCartDetailsQuery: jest.fn(),
  useLazyGetReadOrderQuery: jest.fn(),
  useLazyLpRetrieveCompleteOrderDetailsQuery: jest.fn().mockResolvedValue({ data: { data: { cart: {} } } }),
  useLazyGetOrderWriteQuery: jest.fn().mockResolvedValue({ data: { data: { cart: {} } } }),
  useLazyGetAccountAddressValidationQuery: jest.fn().mockResolvedValue({ data: { data: { cart: {} } } }),
  useLazyGetRetrieveInstallmentAgreementQuery: jest.fn(),
  useLazyGetRetrievePaymentOptionsQuery: jest.fn(),
}));

jest.mock('../../../modules/services/APIService/APIServiceHooks', () => ({
  useLazyGetValidateCartAndCheckoutQuery: jest.fn(),
}));

jest.mock('../../OrderReview/ManualDiscountView', () => () => (
  // Simulate calling handleBannerShow when the component is rendered

  <div data-testid='manual-discount'>Manual discount</div>
));

jest.mock('../../../modules/services/APIService/APIServiceHooks');

jest.mock('react-redux', () => ({
  useDispatch: jest.fn(),
}));

jest.mock('onevzsoemfecommon/AppMessageActions', () => ({
  addAppMessage: jest.fn(),
}));

jest.mock('onevzsoemfecommon/ViewExitDialog', () => ({
  ViewExitDialog: () => <div data-testid='mock-view-exit-dialog'>Mock ViewExitDialog</div>,
}));

const mockReadOrderResponse = {
  processStep: 'CLOSE',
};

const mockReadOrderResponse1 = {
  processStep: 'ACTIVATE',
};

const mockReadOrderResponse2 = {
  processStep: 'CONTINUE',
  cart: {
    cartHeader: {
      cartId: '12345',
    },
    lineDetails: {
      lineInfo: [
        {
          itemsInfo: [
            {
              shipping: {
                address: {
                  addressLine1: '123 Main St',
                  city: 'New York',
                  state: 'NY',
                  zip: '10001',
                },
              },
            },
          ],
          guestOrInactiveRefundLines: false,
        },
      ],
    },
  },
};

const mockReadOrderResponse23 = {
  processStep: 'CONTINUE',
  cart: {
    cartHeader: {
      cartId: '12345',
    },
    lineDetails: {
      lineInfo: [
        {
          itemsInfo: [
            {
              shipping: {
                address: {
                  addressLine1: '123 Main St',
                  city: 'New York',
                  state: 'NY',
                  zip: '10001',
                },
              },
            },
          ],
          guestOrInactiveRefundLines: true,
        },
      ],
    },
  },
};

const mockReadOrderResponse3 = {
  processStep: 'CONTINUE',
  cart: {
    cartHeader: {
      cartId: '12345',
    },
    lineDetails: {
      lineInfo: [
        {
          itemsInfo: [
            {
              shipping: {
                address: {
                  addressLine1: '123 Main St',
                  city: 'New York',
                  state: 'NY',
                  zip: '10001',
                },
              },
            },
          ],
          guestOrInactiveRefundLines: true,
        },
      ],
    },
  },
};

const mockRetrieveInstallmentAgreementResponse = {
  response: [
    {
      orderNumber: '12001054',
      orderActivityType: 'REX',
      installmentContractData:
        'JVBERi0xLjQKJfbkN8KMSAwIG9iago8PAovVHlwZSAvQ2F0YWxvZwovVmVyc2lvbiAvMS40i9QYWdlcyAyIDAgUgo',
    },
  ],
  type: 'PDF',
};

describe('Refund Component', () => {
  beforeAll(() => {
    jest.clearAllMocks();
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
    window.mfe = { scmDeviceMfeEnable: true };
  });

  let dispatch;
  // let getCartDetailsDataBody = readOrderResponse?.data?.data?.cart;
  let addAccessories;

  const defaultProps1 = {
    isReadOrder: true,
    orderNumber: '12345',
    locationCode: 'LOC123',
    assistedRfexflags: {
      retailFwaSkipOrderReviewFFlag: 'TRUE',
    },
    isBlindFlow: true,
  };

  const mockAddAccessoriesSuccessResponse = {
    data: {
      serviceHeader: {
        clientId: 'OMNI-RETAIL',
        statusMsg: 'SUCCESS',
        serviceName: 'SalesOrderAdjustment',
        userId: '',
        statusCode: '00',
        sessionId: '',
        correlationId: 'soe-cart-2025.02.20.06.37.27-36.3379361709798',
      },
      serviceBody: {
        serviceResponse: {
          context: { status: 1 },
        },
      },
    },
  };
  // test
  const mockAddAccessoriesErrorResponse = {
    data: {
      errors: [
        {
          message: 'Validation Error',
        },
      ],
    },
  };

  const mockValidateCartResponse = {
    showPlanOverageFuturedateMsg: false,
    showPlanOverageBackdateMsg: false,
    serviceHeader: {
      clientId: 'OMNI-RETAIL',
      statusMsg: 'SUCCESS',
      serviceName: 'SalesOrderAdjustment',
      userId: '',
      statusCode: '00',
      sessionId: '',
      correlationId: 'soe-cart-2025.02.20.06.37.30-810.0310238470357',
    },
    serviceBody: {
      serviceResponse: {
        context: {
          status: 1,
        },
      },
    },
    cartReadyForCheckout: true,
  };
  const getReadOrderBody = jest.fn();

  beforeEach(() => {
    useLazyLpRetrieveCompleteOrderDetailsQuery.mockReturnValue([
      jest.fn().mockResolvedValue({ data: retrievecompleteOrderResponse }),
      {},
    ]);
    useLazyGetOrderWriteQuery.mockReturnValue([jest.fn().mockResolvedValue({ data: orderWriteResponse }), {}]);
    useLazyGetAccountAddressValidationQuery.mockReturnValue([
      jest.fn().mockResolvedValue({ data: getAccountAdressValidationResult }),
      {},
    ]);
    dispatch = jest.fn();
    useDispatch.mockReturnValue(dispatch);

    useLazyGetCartDetailsQuery.mockReturnValue([jest.fn().mockResolvedValue({ data: readOrderResponse })]);
    useLazyGetReadOrderQuery.mockReturnValue([jest.fn().mockResolvedValue({ data: readOrderResponse })]);
    useLazyGetValidateCartAndCheckoutQuery.mockReturnValue([
      jest.fn().mockResolvedValue({ data: mockValidateCartResponse }),
    ]);
    useLazyGetRetrieveInstallmentAgreementQuery.mockReturnValue([
      jest.fn().mockResolvedValue({ data: retrieveInstallmentAgreementResponse }),
    ]);
    dispatch = jest.fn();
    useDispatch.mockReturnValue(dispatch);
    useLazyGetRetrievePaymentOptionsQuery.mockReturnValue([
      jest.fn().mockResolvedValue({ data: retrieveInstallmentAgreementResponse }),
    ]);

    addAccessories = jest.fn();

    addAccessories.mockResolvedValue(mockAddAccessoriesSuccessResponse);
    GetAccessApiCallHook.mockReturnValue({ addAccessories });
    EmailApiCallHook.mockReturnValue({ addAccessories });
    InfoApiCallHook.mockReturnValue({ addAccessories });
    GetAccessApiCallHook.mockReturnValue({ addAccessories });
  });

  test('full flow: opens modal, changes price, clicks done, and closes modal', async () => {
    useLazyGetValidateCartAndCheckoutQuery.mockReturnValue([jest.fn(), { data: mockValidateCartResponse }]);
    const { getByText, getByTestId } = render(<Refund {...defaultProps1} />);

    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));

    expect(screen.getByText('View manual price correction')).toBeInTheDocument();
    fireEvent.click(screen.getByText('View manual price correction'));

    const input = getByTestId('manual-price-correction');
    fireEvent.change(input, { target: { value: '100' } });

    const doneButton = getByText('Done');
    fireEvent.click(doneButton);

    await waitFor(() => {
      expect(addAccessories).toHaveBeenCalled();

      expect(dispatch).toHaveBeenCalledWith(
        appMessageActions.addAppMessage('Manual Price updated correctly', 'success', true, true)
      );
    });
  });

  test('full flow: opens modal, changes price, clicks done, and closes modal', async () => {
    const action = { page: 'SHIPPING', history: { navigatePage: jest.fn() } };
    addAccessories.mockResolvedValue(action);
    GetAccessApiCallHook.mockReturnValue({ addAccessories });

    const { getByText, getByTestId } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));

    expect(screen.getByText('View manual price correction')).toBeInTheDocument();
    fireEvent.click(screen.getByText('View manual price correction'));

    const input = getByTestId('manual-price-correction');
    fireEvent.change(input, { target: { value: '100' } });

    const doneButton = getByText('Done');
    fireEvent.click(doneButton);
  });

  test('full flow: opens modal, changes price, clicks done, and closes modal-> 1st api error', async () => {
    addAccessories.mockResolvedValue(mockAddAccessoriesErrorResponse);
    const { getByText, getByTestId } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));

    expect(screen.getByText('View manual price correction')).toBeInTheDocument();
    fireEvent.click(screen.getByText('View manual price correction'));

    const input = getByTestId('manual-price-correction');
    fireEvent.change(input, { target: { value: '100' } });

    const doneButton = getByText('Done');
    fireEvent.click(doneButton);
  });

  test('full flow: opens modal, changes price, clicks done, and closes modal-> 1st api error', async () => {
    addAccessories.mockRejectedValueOnce(new Error('Checkout Error'));
    const { getByText, getByTestId } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));

    expect(screen.getByText('View manual price correction')).toBeInTheDocument();
    fireEvent.click(screen.getByText('View manual price correction'));

    const input = getByTestId('manual-price-correction');
    fireEvent.change(input, { target: { value: '100' } });

    const doneButton = getByText('Done');
    fireEvent.click(doneButton);
  });

  test('full flow: opens modal, changes price, clicks done, and closes modal->handlevalidatecartandcheckout error ', async () => {
    const getValidateCartAndCheckoutBody = jest.fn();
    getValidateCartAndCheckoutBody.mockRejectedValueOnce(new Error('Checkout Error'));
    useLazyGetValidateCartAndCheckoutQuery.mockReturnValue([
      getValidateCartAndCheckoutBody,
      { data: null, error: null },
    ]);

    const { getByText, getByTestId } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));

    expect(screen.getByText('View manual price correction')).toBeInTheDocument();
    fireEvent.click(screen.getByText('View manual price correction'));

    const input = getByTestId('manual-price-correction');
    fireEvent.change(input, { target: { value: '100' } });

    const doneButton = getByText('Done');
    fireEvent.click(doneButton);

    await waitFor(() => {
      expect(addAccessories).toHaveBeenCalled();

      expect(dispatch).toHaveBeenCalledWith(
        appMessageActions.addAppMessage('Manual Price updated correctly', 'success', true, true)
      );
    });
  });

  test('full flow: opens modal, changes price, clicks done, and closes modal->handlevalidatecartandcheckout error -> handleretrievecart error', async () => {
    useLazyGetReadOrderQuery.mockReturnValue([
      jest.fn().mockResolvedValue({ data: { data: { errors: [{ message: 'Validation Error' }] } } }),
    ]);
    const { getByText, getByTestId } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));

    expect(screen.getByText('View manual price correction')).toBeInTheDocument();
    fireEvent.click(screen.getByText('View manual price correction'));

    const input = getByTestId('manual-price-correction');
    fireEvent.change(input, { target: { value: '100' } });

    const doneButton = getByText('Done');
    fireEvent.click(doneButton);
  });

  test('full flow: opens modal, changes price, clicks done, and closes modal->handlevalidatecartandcheckout error -> handleretrievecart error', async () => {
    const { getByText, getByTestId } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));

    expect(screen.getByText('View manual price correction')).toBeInTheDocument();

    fireEvent.click(screen.getByText('View manual price correction'));

    const input = getByTestId('manual-price-correction');
    fireEvent.change(input, { target: { value: '100' } });

    const doneButton = getByText('Done');
    fireEvent.click(doneButton);
  });

  test('handles errors in handleReadOrder', async () => {
    getReadOrderBody.mockReturnValue([jest.fn().mockRejectedValue(new Error('Validation Error'))]);
    const { getByText, getByTestId } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));

    expect(screen.getByText('View manual price correction')).toBeInTheDocument();

    fireEvent.click(screen.getByText('View manual price correction'));

    const input = getByTestId('manual-price-correction');
    fireEvent.change(input, { target: { value: '100' } });

    const doneButton = getByText('Done');
    fireEvent.click(doneButton);
  });

  test('handles hemburgerMenuPopup function manualcharges', () => {
    const { getByTestId } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));
    const menuItem = getByTestId('manual-charges');
    fireEvent.click(menuItem);
  });

  test('handles hemburgerMenuPopup function viewdiscounts', () => {
    const { getByTestId } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));
    const menuItem = getByTestId('view-discounts-promos');
    fireEvent.click(menuItem);
  });

  test('handles hemburgerMenuPopup function itemsatglance', () => {
    const { getByTestId } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));
    const menuItem = getByTestId('items-at-glance');
    fireEvent.click(menuItem);
  });

  test('handles hemburgerMenuPopup function exit', () => {
    const { getByTestId } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));
    const menuItem = getByTestId('exit');
    fireEvent.click(menuItem);
  });

  test('handles hemburgerMenuPopup function paymenthistory', () => {
    const { getByTestId } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));
    const menuItem = getByTestId('payment-history');
    fireEvent.click(menuItem);
    expect(screen.getByTestId('payment-history-modal')).toBeInTheDocument();
  });

  test('handles hemburgerMenuPopup function viewprintreceipt', () => {
    const { getByTestId } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));
    const menuItem = getByTestId('view-print-receipt');
    fireEvent.click(menuItem);
  });
  test('Exit Model should be displayed on trigger of Exit button in hamberger menu', () => {
    render(<Refund value handleToggle={jest.fn()} />);
    const backdrop = screen.getByTestId('back-drop');
    fireEvent.click(backdrop);
    const exitBtn = screen.getByTestId('exit');
    fireEvent.click(exitBtn);
    expect(exitBtn).not.toBeInTheDocument();
  });
  test('handles hemburgerMenuPopup function', () => {
    const { getByTestId } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));

    const menuItem = getByTestId('view-discounts-promos');

    fireEvent.click(menuItem);
  });
  test('handles hemburgerMenuPopup function', () => {
    const { getByTestId } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));

    const menuItem = getByTestId('items-at-glance');

    fireEvent.click(menuItem);
  });

  test('dispatches error message when rspFetchReadOrder.error.status is 500', async () => {
    useLazyGetReadOrderQuery.mockReturnValue([
      jest.fn(),
      {
        error: { status: 500 },
        isError: true,
      },
    ]);

    render(<Refund isReadOrder />);

    await waitFor(() => {
      expect(dispatch).toHaveBeenCalledWith(
        appMessageActions.addAppMessage('Request failed with status code 500', 'error', true, true)
      );
      expect(NotificationTagging).toHaveBeenCalledWith(
        '',
        '',
        'Request failed with status code 500',
        'EUP|RFEX-read-order',
        'orderReview',
        expect.anything()
      );
    });
  });
});

describe('Refund Component for footer', () => {
  let dispatch;
  let addAccessories;

  const defaultProps1 = {
    orderNumber: '12345',
    locationCode: 'LOC123',
  };

  const mockAddAccessoriesSuccessResponse = {
    data: {
      serviceHeader: {
        clientId: 'OMNI-RETAIL',
        statusMsg: 'SUCCESS',
        serviceName: 'SalesOrderAdjustment',
        userId: '',
        statusCode: '00',
        sessionId: '',
        correlationId: 'soe-cart-2025.02.20.06.37.27-36.3379361709798',
      },
      serviceBody: {
        serviceResponse: {
          context: { status: 1 },
        },
      },
    },
  };

  const mockAddAccessoriesErrorResponse = {
    data: {
      errors: [
        {
          message: 'Validation Error',
        },
      ],
    },
  };

  const mockValidateCartResponse = {
    showPlanOverageFuturedateMsg: false,
    showPlanOverageBackdateMsg: false,
    serviceHeader: {
      clientId: 'OMNI-RETAIL',
      statusMsg: 'SUCCESS',
      serviceName: 'SalesOrderAdjustment',
      userId: '',
      statusCode: '00',
      sessionId: '',
      correlationId: 'soe-cart-2025.02.20.06.37.30-810.0310238470357',
    },
    serviceBody: {
      serviceResponse: {
        context: {
          status: 1,
        },
      },
    },
    cartReadyForCheckout: true,
  };
  const getReadOrderBody = jest.fn();
  beforeEach(() => {
    useLazyLpRetrieveCompleteOrderDetailsQuery.mockReturnValue([jest.fn().mockResolvedValue({}), {}]);
    useLazyGetOrderWriteQuery.mockReturnValue([jest.fn().mockResolvedValue({ data: orderWriteResponse }), {}]);
    useLazyGetAccountAddressValidationQuery.mockReturnValue([jest.fn().mockResolvedValue({ data: {} }), {}]);
    dispatch = jest.fn();
    useDispatch.mockReturnValue(dispatch);

    useLazyGetCartDetailsQuery.mockReturnValue([jest.fn().mockResolvedValue({ data: readOrderResponse })]);
    useLazyGetReadOrderQuery.mockReturnValue([jest.fn().mockResolvedValue({ data: readOrderResponse })]);
    useLazyGetRetrieveInstallmentAgreementQuery.mockReturnValue([
      jest.fn().mockResolvedValue({ data: retrieveInstallmentAgreementResponse }),
    ]);
    dispatch = jest.fn();
    useDispatch.mockReturnValue(dispatch);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    sessionStorage.setItem('secondNumberMtns', '123456789');
    sessionStorage.setItem('FAEIntentType', '5GHomeRetailRFEX');
    getQueryParamByName.mockReturnValue('isReadOrder');
    getQueryParamByName.mockReturnValue('intentType');
    getQueryParamByName.mockReturnValue('5GHomeRetailRFE');

    Object.defineProperty(window, 'sessionStorage', {
      value: {
        getItem: jest.fn((key) => {
          if (key === 'channel') {
            return 'OMNI-RETAIL';
          }
          if (key === 'secondNumberMtns') {
            return '123456789';
          }
          if (key === 'FAEIntentType') {
            return '5GHomeRetailRFEX';
          }
          return null;
        }),
        setItem: jest.fn(),
        removeItem: jest.fn(),
        clear: jest.fn(),
      },
      writable: true,
    });
    // useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: mockReadOrderResponse }]);

    addAccessories = jest.fn();

    addAccessories.mockResolvedValue(mockAddAccessoriesSuccessResponse);
    GetAccessApiCallHook.mockReturnValue({ addAccessories });

    useLazyGetValidateCartAndCheckoutQuery.mockReturnValue([jest.fn(), { data: mockValidateCartResponse }]);
  });

  test('full flow: opens modal, changes price, clicks done, and closes modal', async () => {
    const { getByText, getByTestId } = render(<Refund {...defaultProps1} />);

    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));

    expect(screen.getByText('View manual price correction')).toBeInTheDocument();
    fireEvent.click(screen.getByText('View manual price correction'));

    const input = getByTestId('manual-price-correction');
    fireEvent.change(input, { target: { value: '100' } });

    const doneButton = getByText('Done');
    fireEvent.click(doneButton);

    await waitFor(() => {
      expect(addAccessories).toHaveBeenCalled();

      expect(dispatch).toHaveBeenCalledWith(
        appMessageActions.addAppMessage('Manual Price updated correctly', 'success', true, true)
      );
    });
  });

  test('full flow: opens modal, changes price, clicks done, and closes modal', async () => {
    const action = { page: 'SHIPPING', history: { navigatePage: jest.fn() } };
    addAccessories.mockResolvedValue(action);
    GetAccessApiCallHook.mockReturnValue({ addAccessories });

    const { getByText, getByTestId } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));

    expect(screen.getByText('View manual price correction')).toBeInTheDocument();
    fireEvent.click(screen.getByText('View manual price correction'));

    const input = getByTestId('manual-price-correction');
    fireEvent.change(input, { target: { value: '100' } });

    const doneButton = getByText('Done');
    fireEvent.click(doneButton);
    await waitFor(() => {
      expect(addAccessories).toHaveBeenCalled();
    });
  });

  test('full flow: opens modal, changes price, clicks done, and closes modal', async () => {
    const action = { page: 'SHIPPING', history: { navigatePage: jest.fn() } };
    addAccessories.mockResolvedValue(action);
    GetAccessApiCallHook.mockReturnValue({ addAccessories });

    const { getByText } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));

    expect(screen.getByText('View items at a glance')).toBeInTheDocument();
    fireEvent.click(screen.getByText('View items at a glance'));

    const doneButton = getByText('Done');
    fireEvent.click(doneButton);
  });

  test('full flow: opens modal, changes price, clicks done, and closes modal-> 1st api error', async () => {
    addAccessories.mockResolvedValue(mockAddAccessoriesErrorResponse);
    const { getByText, getByTestId } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));

    expect(screen.getByText('View manual price correction')).toBeInTheDocument();
    fireEvent.click(screen.getByText('View manual price correction'));

    const input = getByTestId('manual-price-correction');
    fireEvent.change(input, { target: { value: '100' } });

    const doneButton = getByText('Done');
    fireEvent.click(doneButton);
  });

  test('full flow: opens modal, changes price, clicks done, and closes modal-> 1st api error', async () => {
    addAccessories.mockRejectedValueOnce(new Error('Checkout Error'));
    const { getByText, getByTestId } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));

    expect(screen.getByText('View manual price correction')).toBeInTheDocument();
    fireEvent.click(screen.getByText('View manual price correction'));

    const input = getByTestId('manual-price-correction');
    fireEvent.change(input, { target: { value: '100' } });

    const doneButton = getByText('Done');
    fireEvent.click(doneButton);
  });

  test('full flow: opens modal, changes price, clicks done, and closes modal->handlevalidatecartandcheckout error ', async () => {
    useLazyGetValidateCartAndCheckoutQuery.mockReturnValue([
      jest.fn().mockResolvedValue({ data: { errors: [{ message: 'Validation Error' }] } }),
    ]);

    const { getByText, getByTestId } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));

    expect(screen.getByText('View manual price correction')).toBeInTheDocument();
    fireEvent.click(screen.getByText('View manual price correction'));

    const input = getByTestId('manual-price-correction');
    fireEvent.change(input, { target: { value: '100' } });

    const doneButton = getByText('Done');
    fireEvent.click(doneButton);

    await waitFor(() => {
      expect(addAccessories).toHaveBeenCalled();

      expect(dispatch).toHaveBeenCalledWith(
        appMessageActions.addAppMessage('Manual Price updated correctly', 'success', true, true)
      );
    });
  });

  test('full flow: opens modal, changes price, clicks done, and closes modal->handlevalidatecartandcheckout error -> handleretrievecart error', async () => {
    useLazyGetCartDetailsQuery.mockReturnValue([
      jest.fn().mockResolvedValue({ data: { data: { errors: [{ message: 'Validation Error' }] } } }),
    ]);
    const { getByText, getByTestId } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));

    expect(screen.getByText('View manual price correction')).toBeInTheDocument();
    fireEvent.click(screen.getByText('View manual price correction'));

    const input = getByTestId('manual-price-correction');
    fireEvent.change(input, { target: { value: '100' } });

    const doneButton = getByText('Done');
    fireEvent.click(doneButton);
  });

  test('full flow: opens modal, changes price, clicks done, and closes modal->handlevalidatecartandcheckout error -> handleretrievecart error', async () => {
    const { getByText, getByTestId } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));

    expect(screen.getByText('View manual price correction')).toBeInTheDocument();

    fireEvent.click(screen.getByText('View manual price correction'));

    const input = getByTestId('manual-price-correction');
    fireEvent.change(input, { target: { value: '100' } });

    const doneButton = getByText('Done');
    fireEvent.click(doneButton);
  });

  test('handles errors in handleReadOrder', async () => {
    getReadOrderBody.mockReturnValue([jest.fn().mockRejectedValue(new Error('Validation Error'))]);
    const { getByText, getByTestId } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));

    expect(screen.getByText('View manual price correction')).toBeInTheDocument();

    fireEvent.click(screen.getByText('View manual price correction'));

    const input = getByTestId('manual-price-correction');
    fireEvent.change(input, { target: { value: '100' } });

    const doneButton = getByText('Done');
    fireEvent.click(doneButton);
  });

  test('handles hemburgerMenuPopup function', () => {
    const { getByTestId } = render(<Refund {...defaultProps1} />);
    expect(screen.getByTestId('hamburger')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('hamburger'));

    const menuItem = getByTestId('manual-charges');

    fireEvent.click(menuItem);
  });

  test('renderFooter returns nothing when processStep is undefined', () => {
    const props = {
      isBlindFlow: true,
      isReadOrder: true,
      rspFetchReadOrder: { data: { data: {} } },
      assistedRfexflags: {
        retailFwaDelayCartFFlag: 'TRUE',
      },
    };
    getQueryParamByName.mockReturnValue('intentType');
    const { container } = render(<Refund {...props} />);
    expect(container.querySelector('button')).toBeNull();
  });

  test('renderFooter returns Close button when processStep is CLOSE', () => {
    useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: { data: mockReadOrderResponse } }]);

    render(
      <Refund
        isReadOrder
        rspFetchReadOrder={{ data: { data: mockReadOrderResponse } }}
        getRetrieveInstallmentAgreementResult={{ data: { data: mockRetrieveInstallmentAgreementResponse } }}
      />
    );
    fireEvent.click(screen.getByTestId('close-button'));
    expect(screen.getByTestId('close-button')).toBeInTheDocument();
  });

  test('renderFooter returns Continue button when processStep is CONTINUE', () => {
    const lines = [
      {
        itemsInfo: [{ shipping: { shippingCode: '0001' }, cartItems: { cartItem: [{ cartItemType: 'ACCESSORY' }] } }],
        lineActivityType: 'BYOD',
      },
    ];
    const result = showShippingAddress(lines);
    expect(result).toBe(true);
    const props = {
      skipAddressValidationForGuestCheckout: false,
      isBlindFlow: false,
      isReadOrder: true,
      rspFetchReadOrder: { data: { data: {} } },
      assistedRfexflags: {
        retailFwaDelayCartFFlag: 'TRUE',
      },
    };
    useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: { data: mockReadOrderResponse2 } }]);
    useLazyGetRetrieveInstallmentAgreementQuery.mockReturnValue([
      jest.fn(),
      { data: { data: mockRetrieveInstallmentAgreementResponse } },
    ]);

    render(
      <Refund
        {...props}
        isReadOrder
        rspFetchReadOrder={{ data: { data: mockReadOrderResponse2 } }}
        getRetrieveInstallmentAgreementResult={{ data: { data: mockRetrieveInstallmentAgreementResponse } }}
      />
    );
    fireEvent.click(screen.getByTestId('continue-button'));
    expect(screen.getByTestId('continue-button')).toBeInTheDocument();
  });

  test('renderFooter returns Continue button when processStep is CONTINUE second', () => {
    const lines = [
      {
        itemsInfo: [{ shipping: { shippingCode: '0001' }, cartItems: { cartItem: [{ cartItemType: 'ACCESSORY' }] } }],
        lineActivityType: 'BYOD',
      },
    ];
    const result = showShippingAddress(lines);
    expect(result).toBe(true);
    const props = {
      skipAddressValidationForGuestCheckout: true,
      isBlindFlow: false,
      isReadOrder: true,
      rspFetchReadOrder: { data: { data: {} } },
      assistedRfexflags: {
        retailFwaDelayCartFFlag: 'TRUE',
      },
    };
    useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: { data: mockReadOrderResponse2 } }]);
    useLazyGetRetrieveInstallmentAgreementQuery.mockReturnValue([
      jest.fn(),
      { data: { data: mockRetrieveInstallmentAgreementResponse } },
    ]);

    render(
      <Refund
        {...props}
        isReadOrder
        rspFetchReadOrder={{ data: { data: mockReadOrderResponse2 } }}
        getRetrieveInstallmentAgreementResult={{ data: { data: mockRetrieveInstallmentAgreementResponse } }}
      />
    );
    fireEvent.click(screen.getByTestId('continue-button'));
    expect(screen.getByTestId('continue-button')).toBeInTheDocument();
  });

  test('renderFooter returns Continue button when processStep is CONTINUE positive second', () => {
    const lines = [
      {
        itemsInfo: [{ shipping: { shippingCode: '0001' }, cartItems: { cartItem: [{ cartItemType: 'ACCESSORY' }] } }],
        lineActivityType: 'BYOD',
      },
    ];
    const result = showShippingAddress(lines);
    expect(result).toBe(true);
    const props = {
      skipAddressValidationForGuestCheckout: false,
      isBlindFlow: false,
      isReadOrder: true,
      rspFetchReadOrder: { data: { data: {} } },
      assistedRfexflags: {
        retailFwaDelayCartFFlag: 'TRUE',
      },
    };
    useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: { data: mockReadOrderResponse23 } }]);
    useLazyGetRetrieveInstallmentAgreementQuery.mockReturnValue([
      jest.fn(),
      { data: { data: mockRetrieveInstallmentAgreementResponse } },
    ]);

    render(
      <Refund
        {...props}
        isReadOrder
        rspFetchReadOrder={{ data: { data: mockReadOrderResponse23 } }}
        getRetrieveInstallmentAgreementResult={{ data: { data: mockRetrieveInstallmentAgreementResponse } }}
      />
    );
    fireEvent.click(screen.getByTestId('continue-button'));
    expect(screen.getByTestId('continue-button')).toBeInTheDocument();
  });

  test('renderFooter returns Continue button when processStep is CONTINUE positive secondd', () => {
    const lines = [
      {
        itemsInfo: [{ shipping: { shippingCode: '0001' }, cartItems: { cartItem: [{ cartItemType: 'ACCESSORY' }] } }],
        lineActivityType: 'BYOD',
      },
    ];
    const result = showShippingAddress(lines);
    expect(result).toBe(true);
    const props = {
      skipAddressValidationForGuestCheckout: true,
      isBlindFlow: false,
      isReadOrder: true,
      rspFetchReadOrder: { data: { data: {} } },
      assistedRfexflags: {
        retailFwaDelayCartFFlag: 'TRUE',
      },
    };
    useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: { data: mockReadOrderResponse23 } }]);
    useLazyGetRetrieveInstallmentAgreementQuery.mockReturnValue([
      jest.fn(),
      { data: { data: mockRetrieveInstallmentAgreementResponse } },
    ]);

    render(
      <Refund
        {...props}
        isReadOrder
        rspFetchReadOrder={{ data: { data: mockReadOrderResponse23 } }}
        getRetrieveInstallmentAgreementResult={{ data: { data: mockRetrieveInstallmentAgreementResponse } }}
      />
    );
    fireEvent.click(screen.getByTestId('continue-button'));
    expect(screen.getByTestId('continue-button')).toBeInTheDocument();
  });

  test('renderFooter returns Continue button when processStep is CONTINUE second approach', () => {
    const lines = [
      {
        itemsInfo: [{ shipping: { shippingCode: '0001' }, cartItems: { cartItem: [{ cartItemType: 'ACCESSORY' }] } }],
        lineActivityType: 'BYOD',
      },
    ];
    const result = showShippingAddress(lines);
    expect(result).toBe(true);
    const props = {
      skipAddressValidationForGuestCheckout: false,
      isBlindFlow: true,
      isReadOrder: true,
      rspFetchReadOrder: { data: { data: {} } },
      assistedRfexflags: {
        retailFwaDelayCartFFlag: 'TRUE',
      },
    };
    useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: { data: mockReadOrderResponse3 } }]);
    useLazyGetRetrieveInstallmentAgreementQuery.mockReturnValue([
      jest.fn(),
      { data: { data: mockRetrieveInstallmentAgreementResponse } },
    ]);

    render(
      <Refund
        {...props}
        isReadOrder
        rspFetchReadOrder={{ data: { data: mockReadOrderResponse3 } }}
        getRetrieveInstallmentAgreementResult={{ data: { data: mockRetrieveInstallmentAgreementResponse } }}
      />
    );
    fireEvent.click(screen.getByTestId('continue-button'));
    expect(screen.getByTestId('continue-button')).toBeInTheDocument();
  });

  test('renderFooter returns Continue button when processStep is CONTINUE second approach second', () => {
    const lines = [
      {
        itemsInfo: [{ shipping: { shippingCode: '0001' }, cartItems: { cartItem: [{ cartItemType: 'ACCESSORY' }] } }],
        lineActivityType: 'BYOD',
      },
    ];
    const result = showShippingAddress(lines);
    expect(result).toBe(true);
    const props = {
      skipAddressValidationForGuestCheckout: true,
      isBlindFlow: true,
      isReadOrder: true,
      rspFetchReadOrder: { data: { data: {} } },
      assistedRfexflags: {
        retailFwaDelayCartFFlag: 'TRUE',
      },
    };
    useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: { data: mockReadOrderResponse3 } }]);
    useLazyGetRetrieveInstallmentAgreementQuery.mockReturnValue([
      jest.fn(),
      { data: { data: mockRetrieveInstallmentAgreementResponse } },
    ]);

    render(
      <Refund
        {...props}
        isReadOrder
        rspFetchReadOrder={{ data: { data: mockReadOrderResponse3 } }}
        getRetrieveInstallmentAgreementResult={{ data: { data: mockRetrieveInstallmentAgreementResponse } }}
      />
    );
    fireEvent.click(screen.getByTestId('continue-button'));
    expect(screen.getByTestId('continue-button')).toBeInTheDocument();
  });

  test('renderFooter returns Close button when processStep is empty string', () => {
    useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: { data: readOrderResponse } }]);
    useLazyGetRetrieveInstallmentAgreementQuery.mockReturnValue([
      jest.fn(),
      { data: { data: mockRetrieveInstallmentAgreementResponse } },
    ]);

    screen.debug();

    render(
      <Refund
        isReadOrder
        rspFetchReadOrder={{ data: { data: mockReadOrderResponse } }}
        getRetrieveInstallmentAgreementResult={{ data: { data: mockRetrieveInstallmentAgreementResponse } }}
      />
    );
  });
  test('renderFooter returns Close button when processStep is Activate', () => {
    useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: { data: mockReadOrderResponse1 } }]);
    useLazyGetRetrieveInstallmentAgreementQuery.mockReturnValue([
      jest.fn(),
      { data: { data: mockRetrieveInstallmentAgreementResponse } },
    ]);

    render(
      <Refund
        isReadOrder
        rspFetchReadOrder={{ data: { data: mockReadOrderResponse } }}
        getRetrieveInstallmentAgreementResult={{ data: { data: mockRetrieveInstallmentAgreementResponse } }}
      />
    );
  });
  test('renderFooter returns Close button when processStep is Activate', () => {
    useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: { data: mockReadOrderResponse2 } }]);
    useLazyGetRetrieveInstallmentAgreementQuery.mockReturnValue([
      jest.fn(),
      { data: { data: mockRetrieveInstallmentAgreementResponse } },
    ]);

    render(
      <Refund
        isReadOrder
        rspFetchReadOrder={{ data: { data: mockReadOrderResponse } }}
        getRetrieveInstallmentAgreementResult={{ data: { data: mockRetrieveInstallmentAgreementResponse } }}
      />
    );
  });
});

describe('Refund Component Continue Payment', () => {
  let dispatch;
  let addAccessories;

  const mockAddAccessoriesSuccessResponse = {
    data: {
      serviceHeader: {
        clientId: 'OMNI-RETAIL',
        statusMsg: 'SUCCESS',
        serviceName: 'SalesOrderAdjustment',
        userId: '',
        statusCode: '00',
        sessionId: '',
        correlationId: 'soe-cart-2025.02.20.06.37.27-36.3379361709798',
      },
      serviceBody: {
        serviceResponse: {
          context: { status: 1 },
        },
      },
    },
  };
  const mockValidateCartResponse = {
    showPlanOverageFuturedateMsg: false,
    showPlanOverageBackdateMsg: false,
    serviceHeader: {
      clientId: 'OMNI-RETAIL',
      statusMsg: 'SUCCESS',
      serviceName: 'SalesOrderAdjustment',
      userId: '',
      statusCode: '00',
      sessionId: '',
      correlationId: 'soe-cart-2025.02.20.06.37.30-810.0310238470357',
    },
    serviceBody: {
      serviceResponse: {
        context: {
          status: 1,
        },
      },
    },
    cartReadyForCheckout: true,
  };

  beforeEach(() => {
    useLazyLpRetrieveCompleteOrderDetailsQuery.mockReturnValue([jest.fn().mockResolvedValue({}), {}]);
    useLazyGetOrderWriteQuery.mockReturnValue([jest.fn().mockResolvedValue({ data: orderWriteResponse }), {}]);
    useLazyGetAccountAddressValidationQuery.mockReturnValue([
      jest.fn().mockResolvedValue({ data: { shipAddress: [] } }),
      {},
    ]);
    dispatch = jest.fn();
    useDispatch.mockReturnValue(dispatch);
    useLazyGetValidateCartAndCheckoutQuery.mockReturnValue([
      jest.fn().mockResolvedValue({ data: mockValidateCartResponse }),
    ]);
    useLazyGetCartDetailsQuery.mockReturnValue([jest.fn().mockResolvedValue({ data: readOrderResponse })]);
    useLazyGetReadOrderQuery.mockReturnValue([jest.fn().mockResolvedValue({ data: readOrderResponse })]);
    useLazyGetRetrieveInstallmentAgreementQuery.mockReturnValue([
      jest.fn(),
      { data: { data: mockRetrieveInstallmentAgreementResponse } },
    ]);

    dispatch = jest.fn();
    useDispatch.mockReturnValue(dispatch);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    sessionStorage.setItem('secondNumberMtns', '123456789');
    sessionStorage.setItem('FAEIntentType', '5GHomeRetailRFEX');
    getQueryParamByName.mockReturnValue('isReadOrder');
    getQueryParamByName.mockReturnValue('intentType');
    getQueryParamByName.mockReturnValue('5GHomeRetailRFEX');

    Object.defineProperty(window, 'sessionStorage', {
      value: {
        getItem: jest.fn((key) => {
          if (key === 'channel') {
            return 'OMNI-RETAIL';
          }
          if (key === 'secondNumberMtns') {
            return '123456789';
          }
          if (key === 'FAEIntentType') {
            return '5GHomeRetailRFEX';
          }
          return null;
        }),
        setItem: jest.fn(),
        removeItem: jest.fn(),
        clear: jest.fn(),
      },
      writable: true,
    });
    // useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: mockReadOrderResponse }]);

    addAccessories = jest.fn();

    addAccessories.mockResolvedValue(mockAddAccessoriesSuccessResponse);
    GetAccessApiCallHook.mockReturnValue({ addAccessories });
  });

  test('renderFooter returns Continue button when processStep is CONTINUE', () => {
    const lines = [
      {
        itemsInfo: [{ shipping: { shippingCode: '0001' }, cartItems: { cartItem: [{ cartItemType: 'ACCESSORY' }] } }],
        lineActivityType: 'BYOD',
      },
    ];
    const result = showShippingAddress(lines);
    expect(result).toBe(true);
    const props = {
      skipAddressValidationForGuestCheckout: false,
      isBlindFlow: false,
      isReadOrder: true,
      rspFetchReadOrder: { data: { data: {} } },
      assistedRfexflags: {
        retailFwaDelayCartFFlag: 'TRUE',
      },
    };
    useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: { data: mockReadOrderResponse2 } }]);
    useLazyGetRetrieveInstallmentAgreementQuery.mockReturnValue([
      jest.fn(),
      { data: { data: mockRetrieveInstallmentAgreementResponse } },
    ]);

    render(<Refund {...props} isReadOrder rspFetchReadOrder={{ data: { data: mockReadOrderResponse2 } }} />);
    fireEvent.click(screen.getByTestId('continue-button'));
    expect(screen.getByTestId('continue-button')).toBeInTheDocument();
  });

  test('renderFooter returns Continue button when processStep is CONTINUE second', () => {
    const lines = [
      {
        itemsInfo: [{ shipping: { shippingCode: '0001' }, cartItems: { cartItem: [{ cartItemType: 'ACCESSORY' }] } }],
        lineActivityType: 'BYOD',
      },
    ];
    const result = showShippingAddress(lines);
    expect(result).toBe(true);
    const props = {
      skipAddressValidationForGuestCheckout: true,
      isBlindFlow: false,
      isReadOrder: true,
      rspFetchReadOrder: { data: { data: {} } },
      assistedRfexflags: {
        retailFwaDelayCartFFlag: 'TRUE',
      },
    };
    useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: { data: mockReadOrderResponse2 } }]);
    useLazyGetRetrieveInstallmentAgreementQuery.mockReturnValue([
      jest.fn(),
      { data: { data: mockRetrieveInstallmentAgreementResponse } },
    ]);

    render(<Refund {...props} isReadOrder rspFetchReadOrder={{ data: { data: mockReadOrderResponse2 } }} />);
    fireEvent.click(screen.getByTestId('continue-button'));
    expect(screen.getByTestId('continue-button')).toBeInTheDocument();
  });

  test('renderFooter returns Continue button when processStep is CONTINUE seconddd', () => {
    const lines = [
      {
        itemsInfo: [{ shipping: { shippingCode: '0001' }, cartItems: { cartItem: [{ cartItemType: 'ACCESSORY' }] } }],
        lineActivityType: 'BYOD',
      },
    ];
    const result = showShippingAddress(lines);
    expect(result).toBe(true);
    const props = {
      skipAddressValidationForGuestCheckout: true,
      isBlindFlow: false,
      isReadOrder: true,
      rspFetchReadOrder: { data: { data: {} } },
      assistedRfexflags: {
        retailFwaDelayCartFFlag: 'FALSE',
        retailFwaSkipOrderReviewFFlag: 'TRUE',
      },
    };
    useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: { data: mockReadOrderResponse2 } }]);
    useLazyGetRetrieveInstallmentAgreementQuery.mockReturnValue([
      jest.fn(),
      { data: { data: mockRetrieveInstallmentAgreementResponse } },
    ]);

    render(<Refund {...props} isReadOrder rspFetchReadOrder={{ data: { data: mockReadOrderResponse2 } }} />);
    fireEvent.click(screen.getByTestId('continue-button'));
    expect(screen.getByTestId('continue-button')).toBeInTheDocument();
  });

  test('renderFooter returns Continue button when processStep is CONTINUE positive second', () => {
    const lines = [
      {
        itemsInfo: [{ shipping: { shippingCode: '0001' }, cartItems: { cartItem: [{ cartItemType: 'ACCESSORY' }] } }],
        lineActivityType: 'BYOD',
      },
    ];
    const result = showShippingAddress(lines);
    expect(result).toBe(true);
    const props = {
      skipAddressValidationForGuestCheckout: false,
      isBlindFlow: false,
      isReadOrder: true,
      rspFetchReadOrder: { data: { data: {} } },
      assistedRfexflags: {
        retailFwaDelayCartFFlag: 'TRUE',
      },
    };
    useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: { data: mockReadOrderResponse23 } }]);
    useLazyGetRetrieveInstallmentAgreementQuery.mockReturnValue([
      jest.fn(),
      { data: { data: mockRetrieveInstallmentAgreementResponse } },
    ]);

    render(<Refund {...props} isReadOrder rspFetchReadOrder={{ data: { data: mockReadOrderResponse23 } }} />);
    fireEvent.click(screen.getByTestId('continue-button'));
    expect(screen.getByTestId('continue-button')).toBeInTheDocument();
  });

  test('renderFooter returns Continue button when processStep is CONTINUE positive second', () => {
    const lines = [
      {
        itemsInfo: [{ shipping: { shippingCode: '0001' }, cartItems: { cartItem: [{ cartItemType: 'ACCESSORY' }] } }],
        lineActivityType: 'BYOD',
      },
    ];
    const result = showShippingAddress(lines);
    expect(result).toBe(true);
    const props = {
      skipAddressValidationForGuestCheckout: false,
      isBlindFlow: false,
      isReadOrder: true,
      rspFetchReadOrder: { data: { data: {} } },
      assistedRfexflags: {
        retailFwaDelayCartFFlag: 'FALSE',
        retailFwaSkipOrderReviewFFlag: 'TRUE',
      },
    };
    useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: { data: mockReadOrderResponse23 } }]);
    useLazyGetRetrieveInstallmentAgreementQuery.mockReturnValue([
      jest.fn(),
      { data: { data: mockRetrieveInstallmentAgreementResponse } },
    ]);

    render(<Refund {...props} isReadOrder rspFetchReadOrder={{ data: { data: mockReadOrderResponse23 } }} />);
    fireEvent.click(screen.getByTestId('continue-button'));
    expect(screen.getByTestId('continue-button')).toBeInTheDocument();
  });

  test('renderFooter returns Continue button when processStep is CONTINUE positive secondd', () => {
    const lines = [
      {
        itemsInfo: [{ shipping: { shippingCode: '0001' }, cartItems: { cartItem: [{ cartItemType: 'ACCESSORY' }] } }],
        lineActivityType: 'BYOD',
      },
    ];
    const result = showShippingAddress(lines);
    expect(result).toBe(true);
    const props = {
      skipAddressValidationForGuestCheckout: true,
      isBlindFlow: false,
      isReadOrder: true,
      rspFetchReadOrder: { data: { data: {} } },
      assistedRfexflags: {
        retailFwaDelayCartFFlag: 'TRUE',
      },
    };
    useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: { data: mockReadOrderResponse23 } }]);
    useLazyGetRetrieveInstallmentAgreementQuery.mockReturnValue([
      jest.fn(),
      { data: { data: mockRetrieveInstallmentAgreementResponse } },
    ]);

    render(<Refund {...props} isReadOrder rspFetchReadOrder={{ data: { data: mockReadOrderResponse23 } }} />);
    fireEvent.click(screen.getByTestId('continue-button'));
    expect(screen.getByTestId('continue-button')).toBeInTheDocument();
  });

  test('renderFooter returns Continue button when processStep is CONTINUE positive secondd', () => {
    const lines = [
      {
        itemsInfo: [{ shipping: { shippingCode: '0001' }, cartItems: { cartItem: [{ cartItemType: 'ACCESSORY' }] } }],
        lineActivityType: 'BYOD',
      },
    ];
    const result = showShippingAddress(lines);
    expect(result).toBe(true);
    const props = {
      skipAddressValidationForGuestCheckout: true,
      isBlindFlow: false,
      isReadOrder: true,
      rspFetchReadOrder: { data: { data: {} } },
      assistedRfexflags: {
        retailFwaDelayCartFFlag: 'TRUE',
      },
    };
    useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: { data: mockReadOrderResponse23 } }]);
    useLazyGetRetrieveInstallmentAgreementQuery.mockReturnValue([
      jest.fn(),
      { data: { data: mockRetrieveInstallmentAgreementResponse } },
    ]);

    render(<Refund {...props} isReadOrder rspFetchReadOrder={{ data: { data: mockReadOrderResponse23 } }} />);
    fireEvent.click(screen.getByTestId('continue-button'));
    expect(screen.getByTestId('continue-button')).toBeInTheDocument();
  });

  test('renderFooter returns Continue button when processStep is CONTINUE second approach', () => {
    const lines = [
      {
        itemsInfo: [{ shipping: { shippingCode: '0001' }, cartItems: { cartItem: [{ cartItemType: 'ACCESSORY' }] } }],
        lineActivityType: 'BYOD',
      },
    ];
    const result = showShippingAddress(lines);
    expect(result).toBe(true);
    const props = {
      skipAddressValidationForGuestCheckout: false,
      isBlindFlow: true,
      isReadOrder: true,
      rspFetchReadOrder: { data: { data: {} } },
      assistedRfexflags: {
        retailFwaDelayCartFFlag: 'TRUE',
      },
    };
    useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: { data: mockReadOrderResponse3 } }]);
    useLazyGetRetrieveInstallmentAgreementQuery.mockReturnValue([
      jest.fn(),
      { data: { data: mockRetrieveInstallmentAgreementResponse } },
    ]);

    render(<Refund {...props} isReadOrder rspFetchReadOrder={{ data: { data: mockReadOrderResponse3 } }} />);
    fireEvent.click(screen.getByTestId('continue-button'));
    expect(screen.getByTestId('continue-button')).toBeInTheDocument();
  });

  test('renderFooter returns Continue button when processStep is CONTINUE second approach second', () => {
    const lines = [
      {
        itemsInfo: [{ shipping: { shippingCode: '0001' }, cartItems: { cartItem: [{ cartItemType: 'ACCESSORY' }] } }],
        lineActivityType: 'BYOD',
      },
    ];
    const result = showShippingAddress(lines);
    expect(result).toBe(true);
    const props = {
      skipAddressValidationForGuestCheckout: true,
      isBlindFlow: true,
      isReadOrder: true,
      rspFetchReadOrder: { data: { data: {} } },
      assistedRfexflags: {
        retailFwaDelayCartFFlag: 'TRUE',
      },
    };
    useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: { data: mockReadOrderResponse3 } }]);
    useLazyGetRetrieveInstallmentAgreementQuery.mockReturnValue([
      jest.fn(),
      { data: { data: mockRetrieveInstallmentAgreementResponse } },
    ]);

    render(<Refund {...props} isReadOrder rspFetchReadOrder={{ data: { data: mockReadOrderResponse3 } }} />);
    fireEvent.click(screen.getByTestId('continue-button'));
    expect(screen.getByTestId('continue-button')).toBeInTheDocument();
  });

  test('renderFooter returns Continue button when processStep is CONTINUE second approach second', () => {
    const lines = [
      {
        itemsInfo: [{ shipping: { shippingCode: '0001' }, cartItems: { cartItem: [{ cartItemType: 'ACCESSORY' }] } }],
        lineActivityType: 'BYOD',
      },
    ];
    const result = showShippingAddress(lines);
    expect(result).toBe(true);
    const props = {
      skipAddressValidationForGuestCheckout: true,
      isBlindFlow: true,
      isReadOrder: true,
      rspFetchReadOrder: { data: { data: {} } },
      assistedRfexflags: {
        retailFwaDelayCartFFlag: 'TRUE',
      },
    };
    useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: { data: mockReadOrderResponse3 } }]);
    useLazyGetRetrieveInstallmentAgreementQuery.mockReturnValue([
      jest.fn(),
      { data: { data: mockRetrieveInstallmentAgreementResponse } },
    ]);

    render(<Refund {...props} isReadOrder rspFetchReadOrder={{ data: { data: mockReadOrderResponse3 } }} />);
    fireEvent.click(screen.getByTestId('continue-button'));
    expect(screen.getByTestId('continue-button')).toBeInTheDocument();
  });

  test('renderFooter returns Activate button and opens ActivationStatus modal when processStep is ACTIVATE', () => {
    const mockReadOrderResponse233 = {
      data: {
        data: {
          processStep: 'ACTIVATE',
          cart: {
            cartHeader: {
              cartId: '12345',
            },
          },
        },
      },
    };

    useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: mockReadOrderResponse233 }]);

    <Refund isReadOrder rspFetchReadOrder={{ data: mockReadOrderResponse }} />;
  });

  test('opens ActivationStatus modal when Activate button is clicked', () => {
    const mockReadOrderResponse24 = {
      data: {
        data: {
          processStep: 'ACTIVATE',
        },
      },
    };

    useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: mockReadOrderResponse24 }]);

    render(<Refund isReadOrder rspFetchReadOrder={{ data: mockReadOrderResponse }} />);
  });

  test('ipad', () => {
    isIpad.mockReturnValue(true);
    const mockReadOrderResponse24 = {
      data: {
        data: {
          processStep: 'ACTIVATE',
        },
      },
    };

    useLazyGetReadOrderQuery.mockReturnValue([jest.fn(), { data: mockReadOrderResponse24 }]);

    render(<Refund isReadOrder rspFetchReadOrder={{ data: mockReadOrderResponse }} />);
  });
});
