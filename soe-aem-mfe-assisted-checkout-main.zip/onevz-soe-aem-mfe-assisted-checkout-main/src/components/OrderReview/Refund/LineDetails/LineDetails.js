/* eslint-disable react/no-array-index-key */
import React from 'react';
import PropTypes from 'prop-types';
import LineDetailsItem from './LineDetailsItem';

const LineDetails = ({
  lineInfo,
  history,
  setFeatureMtn,
  manualDiscount,
  customerProfile,
  isReadOrder,
  isBlindFlow,
  refundOrderDetails,
  cartOrderDetail,
  subAccountNBSInfo,
  cartType,
  appPropertiesFromSessionStorage,
  isDfil,
  readOrderData,
}) => (
  <div>
    {lineInfo &&
      lineInfo.map((line, lineIndex) => (
        <div style={{ padding: '0px' }} key={`line-${lineIndex}`} data-testid='lineDetails'>
          <div>
            {line.itemsInfo.map((itemInfo, index) => (
              <div key={index} data-testid='lineDetailsItem'>
                <LineDetailsItem
                  key={`details-${index}`}
                  lineItem={itemInfo}
                  lineInfo={line}
                  history={history}
                  lineLength={lineInfo.length}
                  lineIndex={lineIndex}
                  setFeatureMtn={setFeatureMtn}
                  manualDiscount={manualDiscount}
                  customerProfile={customerProfile}
                  isReadOrder={isReadOrder}
                  isBlindFlow={isBlindFlow}
                  refundOrderDetails={refundOrderDetails}
                  cartOrderDetail={cartOrderDetail}
                  subAccountNBSInfo={subAccountNBSInfo}
                  cartType={cartType}
                  appPropertiesFromSessionStorage={appPropertiesFromSessionStorage}
                  isDfil={isDfil}
                  readOrderData={readOrderData}
                />
              </div>
            ))}
          </div>
        </div>
      ))}
  </div>
);

export default LineDetails;
LineDetails.propTypes = {
  lineInfo: PropTypes.object.isRequired,
  history: PropTypes.object.isRequired,
  setFeatureMtn: PropTypes.func.isRequired,
  manualDiscount: PropTypes.number.isRequired,
  customerProfile: PropTypes.object.isRequired,
  isReadOrder: PropTypes.bool.isRequired,
  isBlindFlow: PropTypes.bool.isRequired,
  refundOrderDetails: PropTypes.object.isRequired,
  cartOrderDetail: PropTypes.object.isRequired,
  subAccountNBSInfo: PropTypes.object.isRequired,
  cartType: PropTypes.string.isRequired,
  appPropertiesFromSessionStorage: PropTypes.object.isRequired,
  isDfil: PropTypes.bool,
  readOrderData: PropTypes.object,
};
