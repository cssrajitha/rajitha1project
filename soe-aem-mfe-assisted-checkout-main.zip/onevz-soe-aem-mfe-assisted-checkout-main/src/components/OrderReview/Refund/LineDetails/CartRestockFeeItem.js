import React from 'react';
import PropTypes from 'prop-types';
import { Title } from '@vds/typography';
import '../Style/style.css';
import { formatCurrency } from 'onevzsoemfecommon/Helpers';
import { FlexJustify } from '../../../../StyledConstants';

const CartRestockFeeItems = ({ restockFeeItem }) => (
  <div
    className='u-paddingRightSmall u-paddingTopSmall u-paddingBottomSmall border-top-grey-light'
    data-testId='CartRestockFeeItems'
  >
    <FlexJustify className='u-paddingRightSmall'>
      <Title size='small' className='font-20 line-height-18'>
        Restocking fee
      </Title>
      <Title size='small' className='font-20 float-right line-height-18'>
        {formatCurrency(restockFeeItem?.discountedPrice ?? restockFeeItem?.itemPrice)}
      </Title>
    </FlexJustify>
  </div>
);

CartRestockFeeItems.propTypes = {
  restockFeeItem: PropTypes.object.isRequired,
};

export default CartRestockFeeItems;
