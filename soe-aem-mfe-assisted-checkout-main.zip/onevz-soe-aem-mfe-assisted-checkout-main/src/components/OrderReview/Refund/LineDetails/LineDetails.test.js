import { render, screen, fireEvent } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../../../modules/store';
import LineDetails from './LineDetails';
import LineDetailsMock from '../__mock__/LineDetails.json';
import LineDetailsMock2 from '../__mock__/lineDetails2.json';
import LineDetailsMock3 from '../__mock__/lineDetails_lineItem.json';
import LineDetailsMock4 from '../__mock__/lineDetailsRefundAccessoryCartItems.json';
import LineDetailsMock5 from '../__mock__/lineDetailsRefundSetupAndGoCartItems.json';
import LineDetailsMock6 from '../__mock__/lineDetailsManalDiscount.json';
import { OpenViewTagging } from '../../../../utils/tagging';

jest.mock('../../../../utils/tagging', () => ({
  OpenViewTagging: jest.fn(),
}));

describe('LineDetails Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
    window.mfe = { scmDeviceMfeEnable: true };
  });

  beforeEach(() => {
    // Mock sessionStorage.getItem
    Object.defineProperty(window, 'sessionStorage', {
      value: {
        getItem: jest.fn((key) => {
          if (key === 'channel') {
            return 'OMNI-RETAIL';
          }
          return null;
        }),
        setItem: jest.fn(),
        removeItem: jest.fn(),
        clear: jest.fn(),
      },
      writable: true,
    });
  });

  afterEach(() => {
    // Clear all mocks
    jest.clearAllMocks();
  });

  test('renders LineDetails', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <LineDetails {...LineDetailsMock} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const modalHeader = screen.getByTestId('lineDetailsItem');
    expect(modalHeader).toBeInTheDocument();
  });
  test('renders LineDetails with name and mobile number', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <LineDetails {...LineDetailsMock} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const firstName = screen.getByTestId('firstName-lineDetails');
    expect(firstName).toHaveTextContent('RAVI');
    const lastName = screen.getByTestId('mobileNumber-lineDetails');
    expect(lastName).toHaveTextContent('832-851-0087');
  });
});

describe('LineDetails Component', () => {
  beforeEach(() => {
    // Mock sessionStorage.getItem
    Object.defineProperty(window, 'sessionStorage', {
      value: {
        getItem: jest.fn((key) => {
          if (key === 'channel') {
            return 'OMNI-RETAIL';
          }
          return null;
        }),
        setItem: jest.fn(),
        removeItem: jest.fn(),
        clear: jest.fn(),
      },
      writable: true,
    });
  });

  afterEach(() => {
    // Clear all mocks
    jest.clearAllMocks();
  });

  test('renders LineDetails with CartDeviceItems', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <LineDetails {...LineDetailsMock2} />
        </StoreProvider>
      </BrowserRouter>,
    );
  });
  test('renders LineDetails with accessories', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <LineDetails {...LineDetailsMock3} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const modalHeader = screen.getByText('Accessories');
    expect(modalHeader).toBeInTheDocument();
  });

  test('renders LineDetails with refund accessories cart items', async () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <LineDetails {...LineDetailsMock4} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const Accessories = await screen.findAllByText('Accessories');
    expect(Accessories.length).toBeGreaterThan(0);
  });

  test('renders LineDetails with refundSetupAndGoCartItems', async () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <LineDetails {...LineDetailsMock5} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const Accessories = await screen.findAllByText('Accessories');
    expect(Accessories.length).toBeGreaterThan(0);
  });

  test('renders LineDetails with manual discount', async () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <LineDetails {...LineDetailsMock6} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const Accessories = await screen.getByTestId('CartRestockFeeItems');
    expect(Accessories).toBeInTheDocument();
  });
  test('renders LineDetails and opens ViewAccessory modal on View button click', () => {
    const lineInfo = [
      {
        serviceInfo: {
          serviceAddress: {
            zipCode: '12345',
          },
        },
        itemsInfo: [
          {
            refundCartItems: {
              cartItem: [],
            },
            cartItems: {
              cartItem: [],
            },
          },
        ],
      },
    ];
    const { getByTestId } = render(
      <BrowserRouter>
        <StoreProvider>
          <LineDetails
            lineInfo={lineInfo}
            history={{}}
            setFeatureMtn={() => {}}
            manualDiscount={0}
            customerProfile={{}}
            isReadOrder={false}
            isBlindFlow={false}
            refundOrderDetails={{}}
            cartOrderDetail={{}}
            subAccountNBSInfo={{}}
            cartType=''
            appPropertiesFromSessionStorage={{}}
            isDfil={false}
          />
          ,
        </StoreProvider>
      </BrowserRouter>,
    );

    const viewButton = getByTestId('view');
    fireEvent.click(viewButton);
    const modal = screen.getByTestId('view-accessory-header');
    expect(modal).toBeInTheDocument();
  });

  test('renders LineDetails and opens ViewAccessory modal on View button click', () => {
    const lineInfo = [
      {
        lineActivityType: 'CCH',
        serviceInfo: {
          serviceAddress: {
            zipCode: '12345',
          },
          planDiscount: {
            lineAccessFeeAfterDiscount: '20.0',
          },
        },
        itemsInfo: [
          {
            cartItems: {
              cartItem: [
                {
                  cartItemType: 'DEVICE',
                  prodCode1: 'DEVICE',
                  tradeInAutoPull: false,
                },
              ],
            },
          },
        ],
      },
    ];
    render(
      <BrowserRouter>
        <StoreProvider>
          <LineDetails
            lineInfo={lineInfo}
            history={{}}
            setFeatureMtn={() => {}}
            manualDiscount={0}
            customerProfile={{}}
            isReadOrder={false}
            isBlindFlow={false}
            refundOrderDetails={{}}
            cartOrderDetail={{}}
            subAccountNBSInfo={{}}
            cartType=''
            appPropertiesFromSessionStorage={{}}
            isDfil={false}
          />
          ,
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('renders LineDetails and opens ViewAccessory modal on View button click for refund', () => {
    const lineInfo = [
      {
        serviceInfo: {
          serviceAddress: {
            zipCode: '12345',
          },
          primaryUserInfo: {
            firstName: 'John',
          },
          mtn: '1234567890',
        },
        mobileNumber: '1234567890',
        lineRefundTotal: 100,
        lineExchangeTotal: 200,
        itemsInfo: [
          {
            refundCartItems: {
              cartItem: [
                {
                  prodCode1: 'ACC',
                  cartItemType: 'ACCESSORY',
                  priceAdjustment: false,
                  tradeInAutoPull: false,
                },
              ],
            },
            cartItems: {
              cartItem: [],
            },
          },
        ],
      },
    ];

    const { getAllByText, getByText } = render(
      <BrowserRouter>
        <StoreProvider>
          <LineDetails
            lineInfo={lineInfo}
            history={{}}
            setFeatureMtn={() => {}}
            manualDiscount={0}
            customerProfile={{}}
            isReadOrder
            isBlindFlow={false}
            refundOrderDetails={{}}
            cartOrderDetail={{}}
            subAccountNBSInfo={{}}
            cartType=''
            appPropertiesFromSessionStorage={{}}
            isDfil={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const viewButtons = getAllByText('View');
    fireEvent.click(viewButtons[0]);
    const modal = screen.getByTestId('view-accessory-header');
    expect(modal).toBeInTheDocument();
    const doneButton = getByText('Done');
    fireEvent.click(doneButton);
    expect(OpenViewTagging).toHaveBeenCalledWith(
      'viewAccessoriesChanges',
      '',
      'EUP|RFEX-read-order',
      'orderReview',
      {},
    );
  });

  test('calls OpenViewTagging with correct arguments when onCloseModal is called', () => {
    const lineInfo = [
      {
        serviceInfo: {
          serviceAddress: {
            zipCode: '12345',
          },
        },
        itemsInfo: [
          {
            refundCartItems: {
              cartItem: [],
            },
            cartItems: {
              cartItem: [],
            },
          },
        ],
      },
    ];
    const { getByTestId, getByText } = render(
      <BrowserRouter>
        <StoreProvider>
          <LineDetails
            lineInfo={lineInfo}
            history={{}}
            setFeatureMtn={() => {}}
            manualDiscount={0}
            customerProfile={{}}
            isReadOrder={false}
            isBlindFlow={false}
            refundOrderDetails={{}}
            cartOrderDetail={{}}
            subAccountNBSInfo={{}}
            cartType=''
            appPropertiesFromSessionStorage={{}}
            isDfil={false}
          />
          ,
        </StoreProvider>
      </BrowserRouter>,
    );

    const viewButton = getByTestId('view');
    fireEvent.click(viewButton);
    const doneButton = getByText('Done');
    fireEvent.click(doneButton);
    expect(OpenViewTagging).toHaveBeenCalledWith(
      'viewAccessoriesChanges',
      '',
      'EUP|RFEX-read-order',
      'orderReview',
      {},
    );
  });
});
