import { render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../../../modules/store';
import CartAccessoryItems from './CartAccessoryItems';

describe('CartAccessoryItems Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
    window.mfe = { scmDeviceMfeEnable: true };
  });

  beforeEach(() => {
    // Mock sessionStorage.getItem
    Object.defineProperty(window, 'sessionStorage', {
      value: {
        getItem: jest.fn((key) => {
          if (key === 'channel') {
            return 'OMNI-RETAIL';
          }
          return null;
        }),
        setItem: jest.fn(),
        removeItem: jest.fn(),
        clear: jest.fn(),
      },
      writable: true,
    });
  });

  afterEach(() => {
    // Clear all mocks
    jest.clearAllMocks();
  });

  const mockData = {
    accessoryItem: {
      refundExchangeDetails: {
        itemRefundInd: 'P',
      },
      deviceDisplayName: 'Gaming Console',
      priceAdjustment: true,
      newPurchasedQty: 1,
      discountedPrice: 299.99,
      catalogPrice: 349.99,
      itemPrice: 399.99,
      qty: 2,
      sorId: '12345',
      deviceId: '67890',
      prodCode4: 'SUG',
      cartItemType: 'SOFT_SKU',
      description: 'Special Edition',
      sedOfferList: {
        sedOffer: [{ description: 'Offer 1' }, { description: 'Offer 2' }],
      },
    },
    isNewItemSection: true,
    cartType: 'GAMINGCONSOLE',
  };

  const sedOffermockData = {
    accessoryItem: {
      refundExchangeDetails: {
        itemRefundInd: 'P',
      },
      deviceDisplayName: 'Gaming Console',
      priceAdjustment: true,
      newPurchasedQty: 0,
      discountedPrice: 299.99,
      catalogPrice: 349.99,
      itemPrice: 399.99,
      qty: 2,
      sorId: '12345',
      deviceId: '67890',
      prodCode4: 'SUG',
      cartItemType: 'SOFT_SKU',
      description: 'Special Edition',
      sedOfferList: {
        sedOffer: [{ description: 'Offer 1' }, { description: 'Offer 2' }],
      },
    },
    isNewItemSection: true,
    cartType: 'GAMINGCONSOLE',
  };

  test('renders CartAccessoryItems without props', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <CartAccessoryItems />
        </StoreProvider>
      </BrowserRouter>
    );
    const price = screen.getByText('-$0.00');
    expect(price).toBeInTheDocument();
  });
  test('renders CartAccessory items with props', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <CartAccessoryItems {...mockData} />
        </StoreProvider>
      </BrowserRouter>
    );
    const sku = screen.getAllByText('12345');
    expect(sku[0]).toBeInTheDocument();
  });

  test('renders CartAccessory items with sedOffer', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <CartAccessoryItems {...sedOffermockData} />
        </StoreProvider>
      </BrowserRouter>
    );
    const sku = screen.getByText('Offer 1');
    expect(sku).toBeInTheDocument();
  });
});
