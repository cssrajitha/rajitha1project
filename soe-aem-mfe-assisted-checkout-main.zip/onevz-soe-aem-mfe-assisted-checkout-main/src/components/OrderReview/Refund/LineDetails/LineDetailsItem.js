/* eslint-disable react/no-array-index-key */
import React, { useState } from 'react';
import { Grid, Row, Col } from '@vds/grids';
import { Modal } from '@vds/modals';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import { Body, Title } from '@vds/typography';
import { TextLink } from '@vds/buttons';
import { formatCurrency } from 'onevzsoemfecommon/Helpers';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { formatMtnWithHyphen } from '../../../../utils/common';
import CartDeviceItems from './CartDeviceItems';
import CartRestockFeeItems from './CartRestockFeeItem';
import CartAccessoryItems from './CartAccessoryItems';
import ViewAccessory from '../Modals/AccessoryModal/ViewAccessory';
import { FlexJustify, PaddingLeft16 } from '../../../../StyledConstants';
import { OpenViewTagging } from '../../../../utils/tagging';
import ServicePerksModal from '../../ServicePerksModal';

const LineAccessContainer = styled.div`
  padding-right: 0.5rem;
  padding-top: 0.5rem;
  padding-bottom: 0.5rem;
  border-top: 1px solid #d8dada; /* Matches 'border-top-grey-light' */
`;

const LineAccessWrapper = styled.div`
  padding-right: 0.5rem;
`;

const LineAccessLabel = styled.span`
  font-size: 20px;
  line-height: 18px;
`;

const LineAccessValue = styled(LineAccessLabel)`
  float: right;
`;

const LineDetailsItem = ({
  lineItem,
  lineInfo,
  lineIndex,
  history,
  manualDiscount,
  customerProfile,
  isReadOrder,
  isBlindFlow,
  subAccountNBSInfo,
  cartType,
  readOrderData,
}) => {
  const [showAccessoryModal, setAccessoryModal] = useState({ exchange: false, refund: false });
  const channel = sessionStorage.getItem('channel');
  const [isServicePerksModalOpen, setServicePerksModalOpen] = useState(false);

  const handleOpenServicePerksModal = () => {
    setServicePerksModalOpen(true);
  };

  const handleCloseServicePerksModal = () => {
    setServicePerksModalOpen(false);
  };

  const onOpenModal = (type) => {
    setAccessoryModal({ ...showAccessoryModal, [type]: true });
    if (type === 'refund') {
      OpenViewTagging('viewAccessory_ReturnItems', '', 'EUP|RFEX-read-order', 'orderReview', {});
    } else {
      OpenViewTagging('viewAccessory_NewItems', '', 'EUP|RFEX-read-order', 'orderReview', {});
    }
  };

  const onCloseModal = (type) => {
    setAccessoryModal({ ...showAccessoryModal, [type]: false });
    OpenViewTagging('viewAccessoriesChanges', '', 'EUP|RFEX-read-order', 'orderReview', {});
  };

  const refundCartItems = lineItem.refundCartItems && lineItem.refundCartItems.cartItem;
  const exchangeCartItems = lineItem.cartItems && lineItem.cartItems.cartItem;

  const refundAccessoryCartItems =
    refundCartItems &&
    refundCartItems
      .map((item) => {
        const newItem = { ...item };
        const itemType = !item.priceAdjustment ? 'refund' : 'autopull';
        newItem.type = itemType;
        return newItem;
      })
      .filter((item) => (item.prodCode1 === 'ACC' || item.cartItemType === 'ACCESSORY') && !item.tradeInAutoPull);

  const refundDeviceCartItems =
    refundCartItems &&
    refundCartItems
      .map((item) => {
        const newItem = { ...item };
        newItem.type = 'refund';
        return newItem;
      })
      .filter((item) => (item.prodCode1 === 'LTE' || item.cartItemType === 'DEVICE') && !item.tradeInAutoPull);

  const sedOffers = refundDeviceCartItems?.[0]?.sedOfferList?.sedOffer;

  const exchangeAccessoryCartItems =
    exchangeCartItems &&
    exchangeCartItems.filter((item) => {
      if (item.cartItemType === 'ACCESSORY') {
        const newItem = { ...item };
        newItem.type = !item.priceAdjustment ? 'exchange' : 'autopull';
        return newItem;
      }
      return item.prodCode1 === 'ACC' && item.cartItemType === 'ACCESSORY' && !item.tradeInAutoPull;
    });

  const refundSIMCartItems =
    refundCartItems &&
    refundCartItems
      .filter((item) => item.cartItemType === 'SIM' && !item.tradeInAutoPull)
      .map((item) => ({ ...item, type: 'refund' }));

  const exchangeDeviceCartItems =
    exchangeCartItems &&
    exchangeCartItems.filter((item) => {
      const newItem = { ...item };
      if (newItem.cartItemType === 'DEVICE') {
        newItem.type = 'exchange';
      } else {
        newItem.type = newItem.type ? newItem.type : '';
      }
      return (newItem.prodCode1 === 'LTE' || newItem.cartItemType === 'DEVICE') && !newItem.tradeInAutoPull;
    });

  const refundSetupAndGoCartItems =
    refundCartItems &&
    refundCartItems.filter((item) => item.prodCode4 && item.prodCode4 === 'SUG' && item.cartItemType === 'SOFT_SKU');
  const exchangeSetupAndGoCartItems =
    exchangeCartItems &&
    exchangeCartItems.filter((item) => item.prodCode4 && item.prodCode4 === 'SUG' && item.cartItemType === 'SOFT_SKU');

  const refundRestockFeeCartItems =
    exchangeCartItems && exchangeCartItems.filter((item) => item.itemCode === 'RESTOCKFEE');

  const refundSureStartCartItems =
    refundCartItems && refundCartItems.filter((item) => item.cartItemType === 'SOFT_SKU' && isBlindFlow);
  const hasRefundAccInLine =
    refundAccessoryCartItems && refundAccessoryCartItems.length > 0
      ? true
      : !!(refundSetupAndGoCartItems && refundSetupAndGoCartItems.length > 0);
  const hasRefundDeviceInLine = !!(refundDeviceCartItems && refundDeviceCartItems.length > 0);
  const hasExchangeAccInLine =
    exchangeAccessoryCartItems && exchangeAccessoryCartItems.length > 0
      ? true
      : !!(exchangeSetupAndGoCartItems && exchangeSetupAndGoCartItems.length > 0);
  const hasExchangeDeviceInLine = !!(exchangeDeviceCartItems && exchangeDeviceCartItems.length > 0);
  const hasSureStartItem = !!(refundSureStartCartItems && refundSureStartCartItems.length > 0);
  const firstName = lineInfo?.serviceInfo?.primaryUserInfo?.firstName ?? null;
  const mobileNumber = formatMtnWithHyphen(lineInfo?.serviceInfo?.mtn ?? lineInfo?.mobileNumber);
  const mtnLevelChargeDetails =
    subAccountNBSInfo?.[0]?.billAccounts?.[0]?.nbs?.monthlyChargesInfo?.mtnLevelChargeDetails?.find(
      (item) => item.mtn === lineInfo.mobileNumber,
    );
  const promotionDetails =
    customerProfile &&
    customerProfile.billAccounts &&
    customerProfile.billAccounts[0].mtns.filter((item) => item.mtn === (lineInfo?.serviceInfo?.mtn ?? ''));
  const lineLevelTotal = mtnLevelChargeDetails?.thisMonthCharge;
  const sbdOffers = lineInfo?.serviceInfo?.sbdOffer ?? [];
  const lineActivityType = lineInfo?.lineActivityType ?? '';
  const intendTypeFWAFAE = sessionStorage.getItem('FAEIntentType') === '5GHomeRetailREFX';
  const refundSbdOffers = lineInfo?.serviceInfo?.refundSbdOffer?.sbdOfferList;
  const isRfexFlow = sessionStorage.getItem('refundexchange') === 'true' || false;
  const lineAccess =
    channel?.includes('OMNI-INDIRECT') && isRfexFlow && lineInfo?.lineNAF
      ? lineInfo?.lineNAF
      : lineInfo?.serviceInfo?.planDiscount?.lineAccessFeeAfterDiscount;
  const features =
    lineInfo?.serviceInfo?.selectedFeaturesList?.visFeature &&
    lineInfo?.serviceInfo?.selectedFeaturesList?.visFeature.filter((item) => item?.source === 'USER');
  const [isReadOrderFlag] = getAssistedCradlePropertyV2(['refundReadOrderMfeFFlag']);
  const isReadOrderFlagEnabled = /true/i.test(isReadOrderFlag);

  return (
    <Grid bleed='1272' data-testid='Line-Details'>
      {(hasRefundAccInLine ||
        hasRefundDeviceInLine ||
        hasExchangeAccInLine ||
        hasExchangeDeviceInLine ||
        hasSureStartItem ||
        exchangeSetupAndGoCartItems) && (
        <Row>
          <StyledFlexDirectionColumnLeft
            colSizes={{
              desktop: 6,
            }}
            className={`border-right-black-lite ${
              (hasRefundAccInLine || hasRefundDeviceInLine || hasSureStartItem) && lineIndex > 0
                ? 'border-top-black-light'
                : ''
            }`}
          >
            <div>
              <div>
                <div>
                  <MainHeading className='font-24 bold u-paddingTopMedium u-paddingRightMedium contains-PII'>
                    <Title data-testid='firstName-lineDetails' size='medium' color='#000000' bold>
                      {firstName}
                    </Title>{' '}
                  </MainHeading>
                  <SubHeading className='font-20 bold line-height-18 contains-PII'>
                    <Body data-testid='mobileNumber-lineDetails' size='large' color='#000000' bold primitive='h2'>
                      {mobileNumber}
                    </Body>
                  </SubHeading>
                </div>
              </div>
              {/* REFUND ITEMS */}
              {/* REFUND DEVICE */}
              {hasRefundDeviceInLine &&
                refundDeviceCartItems.map((deviceItem, index) => (
                  <CartDeviceItems
                    key={`Device-${index}`}
                    deviceItem={deviceItem}
                    lineInfo={lineInfo}
                    isNewItemSection={false}
                    history={history}
                    showMtoMlabel={!channel?.includes('OMNI-INDIRECT')}
                  />
                ))}

              {hasExchangeDeviceInLine && (lineActivityType === 'EXC' || lineActivityType === 'CCH') && lineAccess ? (
                <LineAccessContainer>
                  <LineAccessWrapper>
                    <LineAccessLabel>Line access</LineAccessLabel>
                    <LineAccessValue>{formatCurrency(lineAccess)}</LineAccessValue>
                  </LineAccessWrapper>
                </LineAccessContainer>
              ) : (
                ''
              )}

              {!hasExchangeDeviceInLine &&
                refundRestockFeeCartItems &&
                refundRestockFeeCartItems.map((restockFeeItem, index) => (
                  <CartRestockFeeItems key={index} restockFeeItem={restockFeeItem} />
                ))}

              {hasRefundDeviceInLine &&
              lineInfo?.rfexInstallmentContractDetail?.downPaymentAmount &&
              lineInfo?.rfexInstallmentContractDetail?.downPaymentAmount !== '0.00' ? (
                <div className='u-paddingRightSmall u-paddingTopSmall u-paddingBottomSmall border-top-grey-light'>
                  <div className='u-paddingRightSmall'>
                    <span className=' font-20 float-right line-height-18'>{`-${formatCurrency(
                      lineInfo?.rfexInstallmentContractDetail?.downPaymentAmount,
                    )}`}</span>
                    <span className=' font-20 line-height-18'>Down payment</span>
                  </div>
                </div>
              ) : null}
              {hasRefundDeviceInLine &&
                sedOffers &&
                sedOffers.length > 0 &&
                sedOffers.map((sedOffer) => (
                  <div className='u-paddingTopSmall u-paddingBottomSmall border-top-grey-light'>
                    <div className='u-paddingRightSmall u-paddingTopMedium u-paddingBottomMedium'>
                      <span className='font-20 line-height-18 text-grey'>
                        {'SED_Offer : '}
                        {sedOffer.description}
                      </span>
                    </div>
                  </div>
                ))}

              {hasRefundDeviceInLine && lineActivityType !== 'PAD' && refundSbdOffers && refundSbdOffers.length > 0 && (
                <div className='u-paddingTopSmall u-paddingBottomSmall'>
                  <div className='u-paddingRightSmall u-paddingTopMedium u-paddingBottomMedium'>
                    <Title size='small' color='#959595' className='font-20 line-height-18 text-grey'>
                      {'Bill Credit Offer Removed : '}
                      {refundSbdOffers[0].offerId || ''}
                      {' : '}
                      {refundSbdOffers[0].description || ''}
                      {refundSbdOffers.map((sbdOffer) => (
                        <span>
                          {sbdOffer.bicBogoType && sbdOffer.bicBogoType === 'BICT' ? ' (BUY) ' : ' (GET) '}
                          {sbdOffer.bicBogoTargetMdn}
                        </span>
                      ))}
                      {' : '}
                      {formatCurrency(refundSbdOffers[0].discAmt || 0)}
                    </Title>
                  </div>
                </div>
              )}

              {/* REFUND ACCESSORIES */}
              {!channel?.includes('OMNI-INDIRECT') && hasRefundAccInLine && (
                <StyledBodyPadding className='u-paddingXNone'>
                  <Body bold primitive='h2'>
                    Accessories
                  </Body>
                </StyledBodyPadding>
              )}
              {!channel?.includes('OMNI-INDIRECT') &&
                hasRefundAccInLine &&
                refundAccessoryCartItems.map((accessoryItem, index) => (
                  <CartAccessoryItems
                    key={index}
                    accessoryItem={accessoryItem}
                    isNewItemSection={false}
                    cartType={cartType}
                  />
                ))}
              {!channel?.includes('OMNI-INDIRECT') &&
                hasRefundAccInLine &&
                refundSetupAndGoCartItems.map((suagItem, index) => (
                  <CartAccessoryItems
                    key={index}
                    accessoryItem={suagItem}
                    isNewItemSection={false}
                    cartType={cartType}
                  />
                ))}

              {!channel?.includes('OMNI-INDIRECT') && hasRefundAccInLine && (
                <div className='font-14 u-paddingBottomMedium'>
                  <TextLink
                    type='standAlone'
                    data-testid='view'
                    surface='light'
                    disabled={false}
                    onClick={() => onOpenModal('refund')}
                    text-align='right'
                  >
                    View
                  </TextLink>
                  <Modal
                    className='viewDeviceModal'
                    opened={showAccessoryModal.refund}
                    fullScreenDialog
                    closeButton={null}
                  >
                    <div>
                      <ViewAccessory
                        ModalName='viewAccessoryModel'
                        refundAccessoryCartItems={refundAccessoryCartItems}
                        history={history}
                        lineInfo={lineInfo}
                        isNewItemSection={false}
                        closeModal={(type) => onCloseModal(type)}
                        isReadOrder={isReadOrder}
                      />
                    </div>
                  </Modal>
                </div>
              )}
            </div>
            <div>
              {!channel?.includes('OMNI-INDIRECT') && (hasRefundDeviceInLine || hasRefundAccInLine) && (
                <div className='full-width  border-top-grey-light'>
                  <div className='u-paddingTopSmall u-paddingBottomSmall'>
                    <FlexJustify className='u-paddingTopMedium u-paddingRightSmall u-paddingBottomMedium '>
                      <Title size='small' bold>
                        Total
                      </Title>
                      <Title size='small' bold>
                        {formatCurrency(lineInfo.lineRefundTotal)}
                      </Title>
                    </FlexJustify>
                  </div>
                </div>
              )}
            </div>
          </StyledFlexDirectionColumnLeft>
          <StyledFlexDirectionColumnRight
            colSizes={{
              desktop: 6,
            }}
            className={`u-paddingLeftMedium u-paddingTopMedium 
                   `}
          >
            <PaddingLeft16>
              {hasExchangeDeviceInLine &&
                exchangeDeviceCartItems.map((deviceItem) => (
                  <CartDeviceItems
                    key={deviceItem?.itemCode}
                    deviceItem={deviceItem}
                    refundDeviceCartItems={refundDeviceCartItems}
                    lineInfo={lineInfo}
                    isNewItemSection
                    history={history}
                    isReadOrder={isReadOrder}
                    showMtoMlabel
                    refundSIMCartItems={refundSIMCartItems}
                    subAccountNBSInfo={subAccountNBSInfo}
                  />
                ))}

              {!channel?.includes('OMNI-INDIRECT') &&
              hasExchangeDeviceInLine &&
              (lineActivityType === 'EXC' || lineActivityType === 'CCH') &&
              lineAccess ? (
                <LineAccessContainer>
                  <LineAccessWrapper>
                    <LineAccessLabel>Line access</LineAccessLabel>
                    <LineAccessValue>{formatCurrency(lineAccess)}</LineAccessValue>
                  </LineAccessWrapper>
                </LineAccessContainer>
              ) : (
                ''
              )}

              {hasExchangeDeviceInLine &&
                refundRestockFeeCartItems &&
                refundRestockFeeCartItems.map((restockFeeItem, index) => (
                  <CartRestockFeeItems key={index} restockFeeItem={restockFeeItem} />
                ))}

              {hasExchangeDeviceInLine &&
                sbdOffers &&
                lineActivityType !== 'REF' &&
                sbdOffers.length > 0 &&
                sbdOffers.map((sbdOffer, index) => (
                  <div key={`sbd-offer-${index}`} className='u-paddingTopSmall u-paddingBottomSmall'>
                    <div className='u-paddingRightSmall u-paddingTopMedium u-paddingBottomMedium'>
                      <span className='font-20 line-height-18 text-grey'>
                        {'Bill Credit Offer : '}
                        {sbdOffer.offerId}
                        {' : '}
                        {formatCurrency(sbdOffer.discAmt || 0)}
                      </span>
                    </div>
                    <div className='u-paddingRightSmall u-paddingBottomMedium'>
                      <span className='font-20 line-height-18 text-grey'>{sbdOffer.description}</span>
                    </div>
                  </div>
                ))}

              {hasExchangeDeviceInLine &&
                promotionDetails?.length > 0 &&
                promotionDetails[0]?.promotions &&
                promotionDetails[0].promotions?.length > 0 &&
                promotionDetails[0].promotions?.map((promotionDetail, index) => (
                  <div key={`sbd-offer-${index}`} className='u-paddingTopSmall u-paddingBottomSmall'>
                    <div className='u-paddingRightSmall u-paddingTopMedium u-paddingBottomMedium'>
                      <span className='font-20 line-height-18 text-grey'>
                        {'Promo : '}
                        {promotionDetail.promotionText || ''}
                        {' : '}
                        {formatCurrency(promotionDetail.promotionPrice || 0)}
                      </span>
                    </div>
                  </div>
                ))}

              {/* FEATURES Section */}
              {features?.length &&
              hasExchangeDeviceInLine &&
              lineActivityType !== 'REF' &&
              lineActivityType !== 'DIS' ? (
                <div>
                  <StyledBodyPadding className='u-paddingXNone'>
                    <Body bold primitive='h2'>
                      Services & perks
                    </Body>
                  </StyledBodyPadding>

                  {features &&
                    features.map((item, index) => (
                      <div
                        style={{ marginTop: '0.75rem' }}
                        className='u-paddingBottomMedium'
                        data-testid='cartAccessoryitemTest'
                        key={`Feature-${index}`}
                      >
                        <FlexJustify>
                          <Title size='small' className='font-20 line-height-18'>
                            {item?.featureDesc}
                          </Title>
                          <Title size='small' className='font-20 float-right line-height-18'>
                            {formatCurrency(item?.featurePrice)}
                          </Title>
                        </FlexJustify>
                      </div>
                    ))}
                  <div className='font-14 u-paddingBottomMedium' style={{ marginTop: '0.75rem' }}>
                    <TextLink
                      type='standAlone'
                      data-testid='ViewchangeFeatures'
                      surface='light'
                      size='large'
                      disabled={false}
                      onClick={() => handleOpenServicePerksModal()}
                      text-align='right'
                    >
                      View
                    </TextLink>
                    <ServicePerksModal
                      line={readOrderData?.cart?.lineDetails?.lineInfo[0]}
                      readOrderData={readOrderData}
                      opened={isServicePerksModalOpen}
                      closeModal={handleCloseServicePerksModal}
                      isRefundReadOrder
                      refundfeatureflag={isReadOrderFlagEnabled}
                    />
                  </div>
                </div>
              ) : null}

              {/* RIGHT SIDE ACCESSORIES */}
              {!channel?.includes('OMNI-INDIRECT') &&
                (hasExchangeAccInLine || (lineActivityType !== 'REF' && lineActivityType !== 'DIS')) && (
                  <StyledBodyPadding className='u-paddingXNone'>
                    <Body bold primitive='h2'>
                      Accessories
                    </Body>
                  </StyledBodyPadding>
                )}

              {!channel?.includes('OMNI-INDIRECT') &&
                hasExchangeAccInLine &&
                exchangeAccessoryCartItems.map((accessoryItem, index) => (
                  <CartAccessoryItems key={index} isNewItemSection accessoryItem={accessoryItem} cartType={cartType} />
                ))}

              {!channel?.includes('OMNI-INDIRECT') &&
                hasExchangeAccInLine &&
                exchangeSetupAndGoCartItems.map((accessoryItem, index) => (
                  <CartAccessoryItems key={index} isNewItemSection accessoryItem={accessoryItem} cartType={cartType} />
                ))}

              {hasExchangeDeviceInLine ||
                ((lineActivityType === 'EXC' || lineActivityType === 'CCH' || lineActivityType === 'PAD') &&
                  manualDiscount &&
                  manualDiscount.map((discount) => {
                    if (discount.mtn === lineInfo?.serviceInfo?.mtn) {
                      return (
                        <div className='u-paddingRightSmall u-paddingTopMedium u-paddingBottomMedium border-top-grey-light'>
                          <div className='font-20 line-height-18 text-grey'>
                            Manual Discount: {discount.manualDiscountDescription}
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }))}

              {!channel?.includes('OMNI-INDIRECT') &&
                (hasExchangeAccInLine ||
                  (lineActivityType !== 'REF' && lineActivityType !== 'DIS' && !intendTypeFWAFAE)) && (
                  <div className='font-14 u-paddingBottomMedium'>
                    <TextLink
                      type='standAlone'
                      data-testid='view'
                      surface='light'
                      disabled={false}
                      onClick={() => {
                        onOpenModal('exchange');
                      }}
                      text-align='right'
                      data-track='view'
                    >
                      View
                    </TextLink>
                    <Modal
                      className='viewdeviceModal1'
                      opened={showAccessoryModal.exchange}
                      fullScreenDialog
                      closeButton={null}
                      ariaLabel="A label describing the Modal's current content"
                    >
                      <div>
                        <ViewAccessory
                          ModalName='viewAccessoryModel'
                          refundAccessoryCartItems={refundAccessoryCartItems}
                          rightSideAccessories={exchangeAccessoryCartItems}
                          history={history}
                          isNewItemSection
                          lineInfo={lineInfo}
                          closeModal={(type) => onCloseModal(type)}
                          isReadOrder
                        />
                      </div>
                    </Modal>
                  </div>
                )}
            </PaddingLeft16>
            <div>
              {(hasExchangeAccInLine || hasExchangeDeviceInLine) && (
                <div className=' u-paddingXNone border-top-grey-light u-paddingRightMedium'>
                  <PaddingLeft16 className='u-paddingTopSmall u-paddingBottomSmall'>
                    <FlexJustify className='u-paddingRightSmall u-paddingTopMedium u-paddingBottomMedium'>
                      <Title bold size='small'>
                        Total
                      </Title>

                      <Title bold size='small'>
                        {channel?.includes('OMNI-INDIRECT')
                          ? formatCurrency(lineLevelTotal)
                          : formatCurrency(lineInfo.lineExchangeTotal)}
                      </Title>
                    </FlexJustify>
                  </PaddingLeft16>
                </div>
              )}
            </div>

            {/* RIGHT SIDE DEVICES */}
          </StyledFlexDirectionColumnRight>
        </Row>
      )}
    </Grid>
  );
};

LineDetailsItem.propTypes = {
  lineItem: PropTypes.object,
  lineInfo: PropTypes.object,
  lineIndex: PropTypes.number,
  history: PropTypes.object,
  manualDiscount: PropTypes.number,
  customerProfile: PropTypes.object,
  isReadOrder: PropTypes.bool,
  isBlindFlow: PropTypes.bool,
  subAccountNBSInfo: PropTypes.object,
  cartType: PropTypes.string,
  readOrderData: PropTypes.object,
};

const MainHeading = styled.div`
  font-family: BrandFontBold, Sans-serif !important;
  font-size: 24px;
  font-weight: 700;
`;
const SubHeading = styled.div`
  font-family: BrandFontBold, Sans-serif !important;
  font-size: 20px;
  font-weight: 700;
`;

const StyledBodyPadding = styled.div`
  h2 {
    padding: 16px 0px !important;
  }
`;

const StyledFlexDirectionColumnLeft = styled(Col)`
  display: flex;
  justify-content: space-between;
  flex-direction: column;
  padding: 0px !important;
`;

const StyledFlexDirectionColumnRight = styled(Col)`
  display: flex;
  justify-content: space-between;
  flex-direction: column;
  padding: 0px !important;
`;

export default LineDetailsItem;
