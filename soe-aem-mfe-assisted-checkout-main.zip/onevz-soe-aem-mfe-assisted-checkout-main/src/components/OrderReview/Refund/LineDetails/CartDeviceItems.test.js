import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import { getQueryParamByName, formatCurrency } from 'onevzsoemfecommon/Helpers';
import CartDeviceItems from './CartDeviceItems';
import ViewDevice from '../Modals/DeviceModal/ViewDevice';
import { OpenViewTagging } from '../../../../utils/tagging';

jest.mock('onevzsoemfecommon/Helpers', () => ({
  getQueryParamByName: jest.fn(),
  formatCurrency: jest.fn(),
}));

jest.mock('../../../../utils/tagging', () => ({
  OpenViewTagging: jest.fn(),
}));

describe('CartDeviceItems', () => {
  const defaultProps = {
    isNewItemSection: true,
    deviceItem: {
      imageUrlMap: { defaultImage: 'image.jpg' },
      deviceDisplayName: 'Device Name',
      deviceId: '12345',
      sorId: 'SKU123',
      priceType: 'VERIZON_EDGE',
      itemPrice: 100,
      sellerPrice: 200,
      isDfoSelected: false,
    },
    lineInfo: {
      serviceInfo: { pricePlanInfo: { pricePlanCode: 'PPC', pricePlanDesc: 'Plan Description', planPrice: 50 } },
      itemsInfo: [{ cartItems: { cartItem: [{ discountedPrice: 80, itemPrice: 100 }] } }],
      installmentInfo: { downPayment: 20, monthlyInstallment: 30, installmentTerm: 24 },
      rfexInstallmentContractDetail: {
        loanMonthlyPaymentAmount: 25,
        loanAmount: 600,
        loanTerm: 24,
        installmentLoanNumber: 'ILN123',
      },
      lineActivityType: 'EXC',
      mobileNumber: '1234567890',
    },
    showMtoMlabel: true,
    subAccountNBSInfo: [
      {
        billAccounts: [
          {
            nbs: {
              monthlyChargesInfo: {
                mtnLevelChargeDetails: [
                  { mtn: '1234567890', chargeDetails: [{ description: 'device payment', thisMonthCharge: 30 }] },
                ],
              },
            },
          },
        ],
      },
    ],
  };

  const defaultPropsPriceTypeAsVerizon = {
    isNewItemSection: true,
    deviceItem: {
      imageUrlMap: { defaultImage: 'image.jpg' },
      deviceDisplayName: 'Device Name',
      deviceId: '12345',
      sorId: 'SKU123',
      priceType: 'VERIZON',
      itemPrice: 100,
      sellerPrice: 200,
      isDfoSelected: false,
    },
    lineInfo: {
      serviceInfo: { pricePlanInfo: { pricePlanCode: 'PPC', pricePlanDesc: 'Plan Description', planPrice: 50 } },
      itemsInfo: [{ cartItems: { cartItem: [{ discountedPrice: 80, itemPrice: 100 }] } }],
      installmentInfo: { downPayment: 20, monthlyInstallment: 30, installmentTerm: 24 },
      rfexInstallmentContractDetail: {
        loanMonthlyPaymentAmount: 25,
        loanAmount: 600,
        loanTerm: 24,
        installmentLoanNumber: 'ILN123',
      },
      lineActivityType: 'EXC',
      mobileNumber: '1234567890',
    },
    showMtoMlabel: true,
    subAccountNBSInfo: [
      {
        billAccounts: [
          {
            nbs: {
              monthlyChargesInfo: {
                mtnLevelChargeDetails: [
                  { mtn: '1234567890', chargeDetails: [{ description: 'device payment', thisMonthCharge: 30 }] },
                ],
              },
            },
          },
        ],
      },
    ],
  };

  beforeEach(() => {
    sessionStorage.setItem('assistedFlags', JSON.stringify({ isVVCFlowEnabled: 'true' }));
    sessionStorage.setItem('channel', 'OMNI-INDIRECT');
    getQueryParamByName.mockReturnValue('5GHomeRetailRFE');
    formatCurrency.mockReturnValue('$30.00');
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  afterEach(() => {
    sessionStorage.clear();
    jest.clearAllMocks();
  });

  it('renders correctly with default props', () => {
    const { getByTestId, getByText } = render(<CartDeviceItems {...defaultProps} />);
    expect(getByTestId('cart-device-items')).toBeInTheDocument();
    expect(getByText('Device Name')).toBeInTheDocument();
    expect(getByText('Device ID:')).toBeInTheDocument();
    expect(getByText('SKU:')).toBeInTheDocument();
  });

  it('displays the correct line activity description', () => {
    const { getByText } = render(<CartDeviceItems {...defaultProps} />);
    expect(getByText('Return and Exchange')).toBeInTheDocument();
  });

  it('displays the correct discounted price for VERIZON_EDGE', () => {
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    const { getByText } = render(<CartDeviceItems {...defaultProps} />);
    expect(getByText('$30.00*')).toBeInTheDocument();
    expect(getByText('Device Payment')).toBeInTheDocument();
    expect(getByText('$30.00/24 months')).toBeInTheDocument();
  });

  it('displays the correct discounted price for non-VERIZON_EDGE', () => {
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    const props = {
      ...defaultProps,
      deviceItem: { ...defaultProps.deviceItem, priceType: 'NON_EDGE', itemPrice: 150 },
    };
    const { getByText } = render(<CartDeviceItems {...props} />);
    expect(getByText('$30.00*')).toBeInTheDocument();
  });

  it('displays Verizon Visa Card Financing when isDfoSelected is true', () => {
    const props = {
      ...defaultProps,
      deviceItem: { ...defaultPropsPriceTypeAsVerizon.deviceItem, isDfoSelected: true },
    };
    const { getByText } = render(<CartDeviceItems {...props} />);
    expect(getByText('Verizon Visa Card Financing')).toBeInTheDocument();
    expect(
      getByText('Your device financing loan on your Verizon Visa Card will be cancelled after payment'),
    ).toBeInTheDocument();
  });

  it('displays Verizon Visa Card Financing when isDfoSelected is true and isNewItemSection is false', () => {
    const props = {
      ...defaultProps,
      isNewItemSection: false,
      deviceItem: { ...defaultPropsPriceTypeAsVerizon.deviceItem, isDfoSelected: true, priceType: 'VERIZON_EDGE' },
    };
    const { getByText } = render(<CartDeviceItems {...props} />);
    expect(getByText('Device Upgrade Agreement # ILN123 will be canceled after payment')).toBeInTheDocument();
  });

  it('displays the correct plan info', () => {
    const { getByText } = render(<CartDeviceItems {...defaultProps} />);
    expect(getByText('PPC-Plan Description : Individual Plan - Device Payment - Contract')).toBeInTheDocument();
    expect(getByText('$30.00')).toBeInTheDocument();
  });

  it('handles null and undefined values gracefully', () => {
    const props = {
      ...defaultProps,
      deviceItem: null,
      lineInfo: null,
      subAccountNBSInfo: null,
    };
    const { getByTestId } = render(<CartDeviceItems {...props} />);
    expect(getByTestId('cart-device-items')).toBeInTheDocument();
  });

  it('returns "Refund" when lineActivityType is "REF" and isNewItemSections is false', () => {
    const props = {
      ...defaultProps,
      isNewItemSection: false,
      deviceItem: null,
      lineInfo: {
        lineActivityType: 'REF',
      },
      subAccountNBSInfo: null,
    };
    const { getByTestId } = render(<CartDeviceItems {...props} />);
    expect(getByTestId('cart-device-items')).toBeInTheDocument();
  });
  it('returns "Return and Exchange" when lineActivityType is "EXC" and isNewItemSections is true', () => {
    const props = {
      ...defaultProps,

      deviceItem: null,
      lineInfo: {
        lineActivityType: 'EXC',
      },
      subAccountNBSInfo: null,
    };
    const { getByTestId } = render(<CartDeviceItems {...props} />);
    expect(getByTestId('cart-device-items')).toBeInTheDocument();
  });
  it('returns "Refund due to disconnect" when lineActivityType is "DIS" and isNewItemSections is false', () => {
    const props = {
      ...defaultProps,
      isNewItemSection: false,
      deviceItem: null,
      lineInfo: {
        lineActivityType: 'DIS',
      },
      subAccountNBSInfo: null,
    };
    const { getByTestId } = render(<CartDeviceItems {...props} />);
    expect(getByTestId('cart-device-items')).toBeInTheDocument();
  });
  it('returns "Same Device Exchange" when lineActivityType is "PAD", isNewItemSections is true, and channel includes "OMNI-INDIRECT"', () => {
    sessionStorage.setItem('channel', 'OMNI-INDIRECT');
    const props = {
      ...defaultProps,
      isNewItemSection: true,
      deviceItem: null,
      lineInfo: {
        lineActivityType: 'PAD',
      },
      subAccountNBSInfo: null,
    };
    const { getByTestId } = render(<CartDeviceItems {...props} />);
    expect(getByTestId('cart-device-items')).toBeInTheDocument();
  });
  it('returns "Price adjustment" when lineActivityType is "PAD", isNewItemSections is true, and channel does not include "OMNI-INDIRECT"', () => {
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    const props = {
      ...defaultProps,
      isNewItemSection: true,
      deviceItem: null,
      lineInfo: {
        lineActivityType: 'PAD',
      },
      subAccountNBSInfo: null,
    };
    const { getByTestId } = render(<CartDeviceItems {...props} />);
    expect(getByTestId('cart-device-items')).toBeInTheDocument();
  });
  it('returns "Contract change" when lineActivityType is "CCH" and isNewItemSections is true', () => {
    const props = {
      ...defaultProps,
      isNewItemSection: true,
      deviceItem: null,
      lineInfo: {
        lineActivityType: 'CCH',
      },
      subAccountNBSInfo: null,
    };
    const { getByTestId } = render(<CartDeviceItems {...props} />);
    expect(getByTestId('cart-device-items')).toBeInTheDocument();
  });

  it('returns "Exchange (Customer provided device)" when lineActivityType is "EXCBYOD" and isNewItemSections is true', () => {
    const props = {
      ...defaultProps,
      isNewItemSection: true,
      deviceItem: null,
      lineInfo: {
        lineActivityType: 'EXCBYOD',
      },
      subAccountNBSInfo: null,
    };
    const { getByTestId } = render(<CartDeviceItems {...props} />);
    expect(getByTestId('cart-device-items')).toBeInTheDocument();
  });

  it('returns null for any other combination of lineActivityType and isNewItemSections', () => {
    const props = {
      ...defaultProps,
      isNewItemSection: true,
      deviceItem: null,
      lineInfo: {
        lineActivityType: 'UNKNOWN',
      },
      subAccountNBSInfo: null,
    };
    const { getByTestId } = render(<CartDeviceItems {...props} />);
    expect(getByTestId('cart-device-items')).toBeInTheDocument();
  });
  it('returns null for any other combination of lineActivityType and isNewItemSections', () => {
    const props = {
      ...defaultProps,
      isNewItemSection: false,
      deviceItem: null,
      lineInfo: {
        lineActivityType: 'EXC',
      },
      subAccountNBSInfo: null,
    };
    const { getByTestId } = render(<CartDeviceItems {...props} />);
    expect(getByTestId('cart-device-items')).toBeInTheDocument();
  });

  it('opens ViewDevice modal on clicking View button', async () => {
    const { getByText, findAllByTestId } = render(<CartDeviceItems {...defaultProps} />);
    const viewButton = getByText('View');
    fireEvent.click(viewButton);
    render(<ViewDevice {...defaultProps} />);
    const headers = await findAllByTestId('view-device-header');
    expect(headers.length).toBeGreaterThan(0);
  });

  it('calls OpenViewTagging with correct arguments when onCloseModal is called', () => {
    const { getByText } = render(<CartDeviceItems {...defaultProps} />);
    const viewButton = getByText('View');
    fireEvent.click(viewButton);
    const doneButton = getByText('Done');
    fireEvent.click(doneButton);
    expect(OpenViewTagging).toHaveBeenCalledWith('viewDeviceChanges', '', 'EUP|RFEX-read-order', 'orderReview', {});
  });
});
