import React, { useState } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { Modal } from '@vds/modals';
import { TextLink } from '@vds/buttons';
import { getQueryParamByName, formatCurrency } from 'onevzsoemfecommon/Helpers';
import '../Style/style.css';
import { Body, Title } from '@vds/typography';
import { FlexBox, FlexJustify } from '../../../../StyledConstants';
import ViewDevice from '../Modals/DeviceModal/ViewDevice';
import { OpenViewTagging } from '../../../../utils/tagging';

const CartDeviceItems = ({
  isNewItemSection,
  deviceItem,
  lineInfo,
  refundDeviceCartItems,
  showMtoMlabel,
  refundSIMCartItems,
  subAccountNBSInfo,
}) => {
  // Todo: define featureFlag
  const featureFlag = {};
  const planInfo = lineInfo?.serviceInfo?.pricePlanInfo ?? {};
  const rfexEligibilityForDfoFFlag = featureFlag?.rfexEligibilityForDfoFFlag || false;
  const isVVCFlowEnabled =
    !!/true/i.test(JSON.parse(sessionStorage.getItem('assistedFlags'))?.isVVCFlowEnabled) ||
    !!/true/i.test(JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.isVVCFlowEnabled);
  const channel = sessionStorage.getItem('channel');
  const [open, setOpen] = useState(false);
  const onOpenModal = () => {
    setOpen(true);
    OpenViewTagging('viewDeviceChanges', '', 'EUP|RFEX-read-order', 'orderReview', {});
  };
  const onCloseModal = () => {
    setOpen(false);
    OpenViewTagging('viewDeviceChanges', '', 'EUP|RFEX-read-order', 'orderReview', {});
  };
  const getLineActivityDescription = (lineActivityType, isNewItemSections) => {
    if (!isNewItemSections && lineActivityType === 'REF') {
      return 'Refund';
    }
    if (lineActivityType === 'EXC' && isNewItemSections) {
      return 'Return and Exchange';
    }
    if (lineActivityType === 'DIS' && !isNewItemSections) {
      return 'Refund due to disconnect';
    }
    if (lineActivityType === 'PAD' && isNewItemSections) {
      if (channel?.includes('OMNI-INDIRECT')) {
        return 'Same Device Exchange';
      }
      return 'Price adjustment';
    }
    if (lineActivityType === 'CCH' && isNewItemSections) {
      return 'Contract change';
    }
    if (lineActivityType === 'EXCBYOD' && isNewItemSections) {
      return 'Exchange (Customer provided device)';
    }

    return null;
  };

  const getDiscountedPrice = () => {
    const isIndirect = sessionStorage.getItem('channel')?.includes('OMNI-INDIRECT');
    const itemPrice =
      lineInfo?.itemsInfo?.[0]?.cartItems?.cartItem?.[0]?.discountedPrice &&
      lineInfo?.itemsInfo?.[0]?.cartItems?.cartItem?.[0]?.discountedPrice > 0
        ? parseFloat(lineInfo?.itemsInfo?.[0]?.cartItems?.cartItem?.[0]?.discountedPrice)
        : lineInfo?.itemsInfo?.[0]?.cartItems?.cartItem?.[0]?.itemPrice;
    const downPayment = lineInfo?.installmentInfo?.downPayment ? parseFloat(lineInfo?.installmentInfo?.downPayment) : 0;
    const sellerPrice = (deviceItem?.sellerPrice && parseFloat(deviceItem?.sellerPrice)) || 0;
    const isDfoSelected = ((rfexEligibilityForDfoFFlag || isVVCFlowEnabled) && deviceItem?.isDfoSelected) || false;
    const indirectFinanceAmt = sellerPrice - downPayment;
    const financedAmount = isIndirect ? indirectFinanceAmt : itemPrice - downPayment;
    const devicePayment =
      subAccountNBSInfo?.[0]?.billAccounts?.[0]?.nbs?.monthlyChargesInfo?.mtnLevelChargeDetails?.find(
        (item) => item.mtn === lineInfo.mobileNumber,
      );
    const chargeDetails =
      devicePayment?.chargeDetails?.length &&
      devicePayment?.chargeDetails?.find((chargeItem) => chargeItem?.description?.toLowerCase() === 'device payment');

    if (deviceItem?.priceType === 'VERIZON_EDGE') {
      return (
        <>
          <FlexJustify>
            <Title size='small' bold className='bold font-20'>
              Device Payment
            </Title>
            <Title size='small' bold className='order-2 bold font-20'>{`${isNewItemSection ? '' : '-'}${
              isIndirect
                ? formatCurrency(chargeDetails?.thisMonthCharge)
                : formatCurrency(
                    isNewItemSection
                      ? lineInfo?.installmentInfo?.monthlyInstallment
                      : (lineInfo?.rfexInstallmentContractDetail?.loanMonthlyPaymentAmount ?? '0'),
                  )
            }*`}</Title>
          </FlexJustify>
          <Body size='large' color='#747676'>{`${formatCurrency(
            isNewItemSection ? financedAmount : (lineInfo?.rfexInstallmentContractDetail?.loanAmount ?? '0'),
          )}/${
            isNewItemSection
              ? lineInfo?.installmentInfo?.installmentTerm
              : (lineInfo?.rfexInstallmentContractDetail?.loanTerm ?? '')
          } months`}</Body>
          {!isNewItemSection && (
            <Body size='large' color='#747676'>{`Device Upgrade Agreement # ${
              lineInfo?.rfexInstallmentContractDetail?.installmentLoanNumber ?? ''
            } will be canceled after payment`}</Body>
          )}
        </>
      );
    }
    // displaying month to month for INDIRECT with return and exchange field
    return (
      <>
        <FlexJustify>
          {showMtoMlabel && !isDfoSelected && (
            <Body bold primitive='h2'>
              {deviceItem?.priceType ? deviceItem?.priceType : ''}
            </Body>
          )}
          {!isIndirect && (
            <Body bold primitive='h2' className='float-right order-2 bold font-20'>{`${
              isNewItemSection ? '' : '-'
            }${formatCurrency(deviceItem?.itemPrice ? deviceItem?.itemPrice : '')}*`}</Body>
          )}
        </FlexJustify>

        {isDfoSelected && (
          <>
            <span data-testId='vvc-selected' className='bold font-20'>
              Verizon Visa Card Financing
            </span>
            <p>(exclusive of tax)</p>
            <br />
            <span className='font-16 text-grey'>
              Your device financing loan on your Verizon Visa Card will be cancelled after payment
            </span>
          </>
        )}
      </>
    );
  };

  const intendTypeFWAFAE = getQueryParamByName('intentType') === '5GHomeRetailRFEX';

  return (
    <StyledMarginTop35 data-testid='cart-device-items'>
      <FlexBox className='u-marginTop32 u-paddingBottomSmall'>
        <div>
          <img
            src={deviceItem?.imageUrlMap && deviceItem?.imageUrlMap?.defaultImage}
            alt='img'
            style={{ width: '80px' }}
          />
          {/* View model pop-up */}
          {showMtoMlabel && !intendTypeFWAFAE && (
            <div className='font-14 u-paddingTopMedium'>
              <TextLink type='standAlone' data-testid='view' onClick={onOpenModal}>
                View
              </TextLink>
              <Modal
                className='viewdeviceModal'
                opened={open}
                fullScreenDialog
                closeButton={null}
                ariaLabel="A label describing the Modal's current content"
              >
                <div>
                  <ViewDevice
                    ModalName='viewDeviceModel'
                    isNewItemSection={isNewItemSection}
                    lineInfo={lineInfo}
                    refundDeviceCartItems={refundDeviceCartItems}
                    deviceItem={deviceItem}
                    closeModal={onCloseModal}
                    refundSIMCartItems={refundSIMCartItems}
                  />
                </div>
              </Modal>
            </div>
          )}
        </div>
        <div className='u-paddingLeftLarge'>
          <div className='font-24 bold u-paddingTopSmall full-width blue-color u-paddingBottomMedium font-weight-700'>
            {' '}
            <Body color='#0088ce' bold primitive='h1'>
              {' '}
              {!intendTypeFWAFAE && getLineActivityDescription(lineInfo?.lineActivityType, isNewItemSection)}
            </Body>
          </div>
          <StyledLineHeight>
            <Body primitive='h2' bold>
              {deviceItem?.deviceDisplayName}
            </Body>
          </StyledLineHeight>

          {deviceItem?.deviceId && (
            <Body bold size='medium' className='font-14 bold u-paddingTopSmall full-width inline'>
              <InlineSpan>
                Device ID:{' '}
                <Body size='medium' className='lite contains-PII inline'>
                  {deviceItem?.deviceId}
                </Body>
              </InlineSpan>
            </Body>
          )}
          <Body bold size='medium' className='font-14 bold contains-PII inline'>
            <InlineSpan>
              SKU:{' '}
              <Body size='medium' className='lite inline'>
                {deviceItem?.sorId}
              </Body>
            </InlineSpan>
          </Body>
        </div>
      </FlexBox>
      {showMtoMlabel && (
        <div className='u-paddingXNone '>
          <div className='u-paddingRightSmall u-paddingTopSmall u-paddingBottomMedium'>{getDiscountedPrice()}</div>
        </div>
      )}
      {planInfo && Object.keys(planInfo)?.length > 0 && lineInfo?.lineActivityType !== 'DISC' && isNewItemSection && (
        <FlexJustify className='u-paddingRightMedium u-paddingTopSmall u-paddingBottomLarge border-top-grey-light'>
          <Title size='small' className='font-20'>
            {planInfo?.pricePlanCode}-{planInfo?.pricePlanDesc} : Individual Plan
            {deviceItem?.priceType === 'VERIZON_EDGE' ? ' - Device Payment' : ''} -{' '}
            {lineInfo?.lineActivityType === 'CCH' ? 'No Contract' : 'Contract'}
          </Title>
          <Title size='small' className='float-right font-20'>
            {formatCurrency(planInfo?.planPrice)}
          </Title>
        </FlexJustify>
      )}
    </StyledMarginTop35>
  );
};

CartDeviceItems.propTypes = {
  isNewItemSection: PropTypes.bool,
  deviceItem: PropTypes.object,
  lineInfo: PropTypes.object,
  showMtoMlabel: PropTypes.bool,
  subAccountNBSInfo: PropTypes.object,
  refundDeviceCartItems: PropTypes.array,
  refundSIMCartItems: PropTypes.array,
};

const StyledLineHeight = styled.div`
  h2 {
    line-height: 20px !important;
  }
`;

const StyledMarginTop35 = styled.div`
  margin-top: 35px !important;
`;

const InlineSpan = styled.span`
  p {
    display: inline;
  }
`;

export default CartDeviceItems;
