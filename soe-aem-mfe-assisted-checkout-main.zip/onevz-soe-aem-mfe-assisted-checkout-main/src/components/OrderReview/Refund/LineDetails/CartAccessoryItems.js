/* eslint-disable react/no-array-index-key */
import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import _ from 'lodash';
import { Body, Title } from '@vds/typography';
import { formatCurrency } from 'onevzsoemfecommon/Helpers';
import { FlexBox, FlexJustify, Padding8 } from '../../../../StyledConstants';

const CartAccessoryItems = ({ accessoryItem, isNewItemSection, cartType }) => {
  const itemRefundInd = accessoryItem?.refundExchangeDetails?.itemRefundInd ?? '';
  const isManagedSubscription = cartType === 'GAMINGCONSOLE';
  return (
    <>
      {(!isNewItemSection ||
        (isNewItemSection && !accessoryItem?.priceAdjustment) ||
        (isNewItemSection && accessoryItem?.priceAdjustment && accessoryItem?.newPurchasedQty === 0)) && (
        <div className='u-paddingBottomMedium' data-testid='cartAccessoryitemTest'>
          <FlexJustify>
            {accessoryItem?.deviceDisplayName && (
              <FlexJustifyFullWidth className='line-height-18 font-20 bold'>
                <Title bold size='small'>
                  {accessoryItem?.deviceDisplayName}
                </Title>
                {((itemRefundInd === 'P' && !accessoryItem?.priceAdjustment) ||
                  (isNewItemSection && accessoryItem?.priceAdjustment)) && (
                  <span className='blue-color'>(price adjust)</span>
                )}
              </FlexJustifyFullWidth>
            )}

            <FlexJustifyFullWidthRight className='u-paddingRightSmall'>
              {accessoryItem?.prodCode4 &&
                accessoryItem?.prodCode4 === 'SUG' &&
                accessoryItem?.cartItemType === 'SOFT_SKU' && (
                  <Body bold primitive='h2'>
                    {accessoryItem?.description}
                  </Body>
                )}
              <Body bold primitive='h2'>{`${isNewItemSection ? '' : '-'}${formatCurrency(
                accessoryItem?.discountedPrice || accessoryItem?.catalogPrice || accessoryItem?.itemPrice || '',
              )}`}</Body>
            </FlexJustifyFullWidthRight>
          </FlexJustify>

          <Padding8 className='line-height-18 font-20 u-paddingBottomExtraSmall'>(qty: {accessoryItem?.qty})</Padding8>
          <FlexBox className='font-14 bold contains-PII ContainsSku'>
            <Body bold>SKU:</Body>
            <span className='lite'>{accessoryItem?.sorId}</span>
            {isManagedSubscription ? (
              <span>
                {' '}
                | Serial No: <span className='lite'>{accessoryItem?.deviceId}</span>{' '}
              </span>
            ) : (
              <span> </span>
            )}
          </FlexBox>
          {accessoryItem?.sedOfferList?.sedOffer?.map((item, index) => (
            <div key={`sedOffer${index}`} className='line-height-18 font-20 line-height-18 text-grey'>
              {item?.description}
            </div>
          ))}
        </div>
      )}

      {isNewItemSection && accessoryItem?.priceAdjustment && accessoryItem?.newPurchasedQty > 0 && (
        <>
          <div className='u-paddingBottomMedium'>
            <div className='line-height-18 font-20 bold'>
              {accessoryItem.deviceDisplayName}
              <span className='blue-color'>(price adjust)</span>
            </div>
            <div className='line-height-18 u-textRight bold font-20 u-paddingRightMedium'>{`${formatCurrency(
              (_.has(accessoryItem, 'discountedPrice') ? accessoryItem?.discountedPrice : accessoryItem.catalogPrice) ||
                accessoryItem.itemPrice,
            )}`}</div>
            <div className='line-height-18 font-20 u-paddingBottomExtraSmall'>
              (qty: {accessoryItem.priceAdjustmentQty})
            </div>
            <FlexBox className='font-14 bold contains-PII ContainsSku'>
              <Body bold> SKU:</Body> <span className='lite'>{accessoryItem.sorId}</span>
            </FlexBox>
            {accessoryItem?.sedOfferList?.sedOffer?.map((item, index) => (
              <div key={`sedOffer${index}`} className='line-height-18 font-20 line-height-18 text-grey'>
                {item.description}
              </div>
            ))}
          </div>
          <div className='u-paddingBottomMedium'>
            <div className='line-height-18 font-20 bold'>{accessoryItem?.deviceDisplayName}</div>
            <div className='line-height-18 u-textRight bold font-20 u-paddingRightMedium'>{`${formatCurrency(
              (_.has(accessoryItem, 'discountedPrice') ? accessoryItem.discountedPrice : accessoryItem.catalogPrice) ||
                accessoryItem.itemPrice,
            )}`}</div>
            <div className='line-height-18 font-20 u-paddingBottomExtraSmall'>
              (qty: {accessoryItem.newPurchasedQty})
            </div>
            <FlexBox className='font-14 bold contains-PII ContainsSku'>
              <Body bold> SKU:</Body> <span className='lite'>{accessoryItem.sorId}</span>
            </FlexBox>
            {accessoryItem?.sedOfferList?.sedOffer?.map((item, index) => (
              <div key={`sedOffer${index}`} className='line-height-18 font-20 line-height-18 text-grey'>
                {item.description}
              </div>
            ))}
          </div>
        </>
      )}
    </>
  );
};

CartAccessoryItems.propTypes = {
  accessoryItem: PropTypes.object.isRequired,
  isNewItemSection: PropTypes.bool.isRequired,
  cartType: PropTypes.string.isRequired,
};

const FlexJustifyFullWidth = styled(FlexJustify)`
  flex: 1;
`;

const FlexJustifyFullWidthRight = styled(FlexJustify)`
  > h2:nth-of-type(2) {
    flex: 1;
    text-align: end;
  }

  > h2:first-of-type:only-of-type {
    flex: 1;
    text-align: end;
  }
  flex: 1;
`;

export default CartAccessoryItems;
