import React from 'react';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import CartRestockFeeItems from './CartRestockFeeItem';

describe('CartRestockFeeItems', () => {
  it('renders with discountedPrice', () => {
    const restockFeeItem = { discountedPrice: 10.0, itemPrice: 20.0 };
    const { getByText, getByTestId } = render(<CartRestockFeeItems restockFeeItem={restockFeeItem} />);

    expect(getByTestId('CartRestockFeeItems')).toBeInTheDocument();
    expect(getByText('Restocking fee')).toBeInTheDocument();
    expect(getByText('$10.00')).toBeInTheDocument();
  });

  it('renders with itemPrice when discountedPrice is not available', () => {
    const restockFeeItem = { itemPrice: 20.0 };
    const { getByText, getByTestId } = render(<CartRestockFeeItems restockFeeItem={restockFeeItem} />);

    expect(getByTestId('CartRestockFeeItems')).toBeInTheDocument();
    expect(getByText('Restocking fee')).toBeInTheDocument();
  });

  it('renders with itemPrice when both discountedPrice and itemPrice are available but discountedPrice is null', () => {
    const restockFeeItem = { discountedPrice: null, itemPrice: 20.0 };
    const { getByText, getByTestId } = render(<CartRestockFeeItems restockFeeItem={restockFeeItem} />);

    expect(getByTestId('CartRestockFeeItems')).toBeInTheDocument();
    expect(getByText('Restocking fee')).toBeInTheDocument();
    expect(getByText('$20.00')).toBeInTheDocument();
  });
});
