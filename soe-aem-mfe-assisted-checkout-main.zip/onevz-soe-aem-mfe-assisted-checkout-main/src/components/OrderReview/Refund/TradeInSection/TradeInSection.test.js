import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import TradeInSection from './TradeInSection';

jest.mock('onevzsoemfecommon/Helpers', () => ({
  formatCurrency: jest.fn((value) => `$${value}`),
}));

describe('TradeInSection', () => {
  const mockLineDetails = {
    tradeInDetail: {
      tradeInItems: [
        {
          deviceId: '12345',
          equipModel: 'Device Model 1',
          recycleDeviceSku: 'SKU123',
          recycleDeviceOffer: {
            dppCredit: '20',
            bicCreditDpTerm: 24,
            offerId: '123',
            offerDesc: 'Promo Description',
          },
          computedPrice: '100',
          tradeInAutoPull: false,
        },
      ],
    },
    refundTradeInDetail: {
      tradeInItems: [
        {
          deviceId: '67890',
          equipModel: 'Device Model 2',
          recycleDeviceSku: 'SKU456',
          recycleDeviceOffer: {
            dppCredit: undefined,
            bicCreditDpTerm: undefined,
            offerId: '456',
            offerDesc: '',
          },
          computedPrice: '200',
          tradeInAutoPull: true,
        },
      ],
    },
    lineInfo: [
      {
        mobileNumber: '1234567890',
        itemsInfo: [
          {
            refundCartItems: {
              cartItem: [
                {
                  cartItemType: 'DEVICE',
                  description: 'Device Description',
                  mobileNumber: '1234567890',
                },
              ],
            },
          },
        ],
      },
    ],
  };

  const defaultProps = {
    lineDetails: mockLineDetails,
    tradeinhome: 'Trade at home',
    viewLabel: 'View',
    deviceTradeInCredit: 'Device trade-in credit',
    deviceTradeInDebit: 'Device trade-in debit',
    instantCreditEligibleLabel: 'Instant credit eligible',
  };

  it('renders the TradeInSection component', () => {
    render(<TradeInSection {...defaultProps} />);
    expect(screen.getByTestId('TradeInSection')).toBeInTheDocument();
  });

  it('renders refund trade-in items with correct details', () => {
    render(<TradeInSection {...defaultProps} />);
    expect(screen.getByText('Device trade-in credit')).toBeInTheDocument();
    expect(screen.getByText('Device Model 2')).toBeInTheDocument();
  });

  it('renders exchange trade-in items with correct details', () => {
    render(<TradeInSection {...defaultProps} />);
    expect(screen.getByText('Device trade-in debit')).toBeInTheDocument();
    expect(screen.getByText('Device Model 1')).toBeInTheDocument();
    expect(screen.getByText('for 24 months')).toBeInTheDocument();
  });

  it('renders promo details correctly', () => {
    render(<TradeInSection {...defaultProps} />);
    expect(screen.getByText('Promo 123 - Promo Description - 100')).toBeInTheDocument();
  });

  it('handles the "View" link click and opens the modal', () => {
    render(<TradeInSection {...defaultProps} />);
    const viewLink = screen.getAllByTestId('viewDeviceTradeInDetails')[0];
    fireEvent.click(viewLink);
  });

  it('handles the modal close action', () => {
    render(<TradeInSection {...defaultProps} />);
    const viewLink = screen.getAllByTestId('viewDeviceTradeInDetails')[0];
    fireEvent.click(viewLink);
  });

  it('handles opening and closing the exchange modal', () => {
    render(<TradeInSection {...defaultProps} />);
    const viewLink = screen.getAllByTestId('viewDeviceTradeInDetails')[1];
    fireEvent.click(viewLink);
  });

  it('renders instant credit eligible label when applicable', () => {
    const propsWithInstantCredit = {
      ...defaultProps,
      lineDetails: {
        ...mockLineDetails,
        tradeInDetail: {
          ...mockLineDetails.tradeInDetail,
          tradeInItems: [
            {
              ...mockLineDetails.tradeInDetail.tradeInItems[0],
            },
          ],
        },
      },
    };

    render(<TradeInSection {...propsWithInstantCredit} />);
  });

  it('renders nothing when lineDetails is empty', () => {
    const propsWithEmptyTradeInItems = {
      ...defaultProps,
      lineDetails: {},
    };

    render(<TradeInSection {...propsWithEmptyTradeInItems} />);
    expect(screen.queryByText('Device trade-in credit')).not.toBeInTheDocument();
    expect(screen.queryByText('Device trade-in debit')).not.toBeInTheDocument();
  });

  it('calculates the promo value correctly when promoValue and bicLoanTerm are provided', () => {
    const propsWithPromoValue = {
      ...defaultProps,
      lineDetails: {
        ...mockLineDetails,
        tradeInDetail: {
          ...mockLineDetails.tradeInDetail,
          tradeInItems: [
            {
              ...mockLineDetails.tradeInDetail.tradeInItems[0],
              deviceRecycleIn: {
                promoValue: 120,
                bicLoanTerm: 12,
              },
            },
          ],
        },
      },
    };

    render(<TradeInSection {...propsWithPromoValue} />);
    expect(screen.getByText('Promo 123 - Promo Description - 10.00')).toBeInTheDocument();
  });

  it('calculates the promo value correctly when promoValue is empty and bicLoanTerm are provided', () => {
    const propsWithPromoValue = {
      ...defaultProps,
      lineDetails: {
        ...mockLineDetails,
        tradeInDetail: {
          ...mockLineDetails.tradeInDetail,
          tradeInItems: [
            {
              ...mockLineDetails.tradeInDetail.tradeInItems[0],
              deviceRecycleIn: {
                bicLoanTerm: 12,
              },
            },
          ],
        },
      },
    };

    render(<TradeInSection {...propsWithPromoValue} />);
    expect(screen.getByText('Promo 123 - Promo Description - 0')).toBeInTheDocument();
  });

  it('handles null recycleDeviceOffer gracefully', () => {
    const propsWithNullRecycleDeviceOffer = {
      ...defaultProps,
      lineDetails: {
        ...mockLineDetails,
        tradeInDetail: {
          ...mockLineDetails.tradeInDetail,
          tradeInItems: [
            {
              ...mockLineDetails.tradeInDetail.tradeInItems[0],
              recycleDeviceOffer: undefined,
            },
          ],
        },
      },
    };

    render(<TradeInSection {...propsWithNullRecycleDeviceOffer} />);
    expect(screen.getByText('Device trade-in credit')).toBeInTheDocument();
  });
});
