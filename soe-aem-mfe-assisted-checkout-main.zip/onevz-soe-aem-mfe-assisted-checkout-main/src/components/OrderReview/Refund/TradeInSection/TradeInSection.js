import React, { useState } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { Modal } from '@vds/modals';
import { formatCurrency } from 'onevzsoemfecommon/Helpers';
import { Title } from '@vds/typography';
import EditTradeIn from '../../EditTradein';

const Container = styled.div`
  display: flex;
  flex-wrap: wrap;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
`;

const Column = styled.div`
  flex: 1;
  border-top: 1px solid #000;
  padding: ${(props) => (props.left ? '0 1rem 0 0' : '0 0 0 1rem')};
  border-right: ${(props) => (props.left ? '1px solid #000' : 'none')};
`;

const Grid = styled.div`
  display: flex;
  flex-wrap: wrap;
  margin-top: ${(props) => (props.marginTop ? props.marginTop : '0')};
`;

const Col = styled.div`
  flex: ${(props) => props.flex || '1'};
  text-align: ${(props) => (props.right ? 'right' : 'left')};
  padding-right: ${(props) => (props.right ? '0.5rem' : '0')};
`;

const UnderlinedText = styled.div`
  text-decoration: underline;
  cursor: pointer;
  font-size: 1rem;
`;

const InfoText = styled.div`
  font-size: 1rem;
  line-height: normal;
  margin-top: ${(props) => props.marginTop || '0'};
`;

const BlueText = styled.div`
  font-weight: bold;
  font-size: 1rem;
  color: blue;
`;

const PromoText = styled.div`
  font-size: 1rem;
  line-height: normal;
  margin: 1.75rem 0rem 2rem 0.5rem;
`;

const TradeInSection = (props) => {
  const [open, setOpen] = useState({ exchange: false, refund: false });

  const onOpenModal = (type) => {
    setOpen({ ...open, [type === 'refund' ? 'refund' : 'exchange']: true });
  };

  const onCloseModal = (type) => {
    setOpen({ ...open, [type === 'refund' ? 'refund' : 'exchange']: false });
  };

  const tradeInItems = props.lineDetails?.tradeInDetail?.tradeInItems ?? [];
  const tradeInDetail = props.lineDetails?.tradeInDetail ?? {};

  const refundTradeInItems = props.lineDetails?.refundTradeInDetail?.tradeInItems ?? [];
  const refundTradeInDetail = props.lineDetails?.refundTradeInDetail ?? {};

  let tradeAtHomeFlag = props.lineDetails?.tradeInDetail?.tradeInItems?.tradeInType ?? '';
  tradeAtHomeFlag =
    tradeAtHomeFlag === null || tradeAtHomeFlag === undefined || tradeAtHomeFlag.length === 0
      ? tradeAtHomeFlag
      : tradeAtHomeFlag.toUpperCase();

  const instantCreditFlag = props.lineDetails?.tradeInDetail?.tradeInItems?.instantCreditEligible;

  const lineInfo = props.lineDetails?.lineInfo ?? [];

  const displayTradeIn = (rfexType, tradeInItem, tradeInType, instantCreditEligible, tradeInDetails) => {
    if (tradeInItem.length > 0) {
      return (
        <div>
          {tradeInType === 'HOME' && (
            <Grid marginTop='1rem'>
              <Title size='1rem' color='#000' bol>
                {props.tradeinhome}
              </Title>
            </Grid>
          )}

          {instantCreditEligible && <BlueText>{props.instantCreditEligibleLabel}</BlueText>}

          {tradeInItem.map((item) => {
            const recycleDeviceOffer = item?.recycleDeviceOffer ?? null;
            const offerId = item?.recycleDeviceOffer?.offerId ?? '';
            const promoValue = Number(item?.deviceRecycleIn?.promoValue ?? '0');
            const bicLoanTerm = Number(item?.deviceRecycleIn?.bicLoanTerm ?? '0');
            const tradeInOfferPrice =
              recycleDeviceOffer && offerId > 0 && bicLoanTerm > 0
                ? (() => {
                    const calculatedValue =
                      promoValue && bicLoanTerm ? Math.abs(promoValue / bicLoanTerm).toFixed(2) : 0;
                    return calculatedValue;
                  })()
                : item?.computedPrice;

            const bicCreditDPTerm = item?.recycleDeviceOffer?.bicCreditDpTerm ?? 24;

            const type =
              item?.recycleDeviceOffer?.dppCredit && parseFloat(item.recycleDeviceOffer.dppCredit) > 0
                ? 'promo'
                : 'credit';

            return (
              <div key={offerId}>
                <Grid marginTop='1rem'>
                  <Col flex='7'>
                    <Title size='1rem' color='#000' bold>
                      {rfexType === 'refund' ? props.deviceTradeInCredit : props.deviceTradeInDebit}
                    </Title>
                  </Col>
                  <Col flex='5' right>
                    <Title size='1rem' color='#000' bold>
                      {rfexType === 'exchange' ? '-' : ''}
                      {type === 'promo'
                        ? `${formatCurrency(parseFloat(item.recycleDeviceOffer.dppCredit))}/mo`
                        : formatCurrency(item?.computedPrice)}
                    </Title>
                  </Col>
                </Grid>

                <Grid>
                  <Col flex='7'>
                    <span>{item?.equipModel}</span>
                  </Col>
                  {type === 'promo' && (
                    <Col flex='5' right>
                      for {bicCreditDPTerm} months
                    </Col>
                  )}
                </Grid>

                <Grid>
                  <Col flex='12'>
                    <InfoText>
                      {item?.tradeInAutoPull === false && rfexType === 'refund'
                        ? 'Traded device returned to customer'
                        : ''}
                    </InfoText>
                  </Col>
                </Grid>

                <Grid>
                  <Col flex='12'>
                    <PromoText>
                      {recycleDeviceOffer && recycleDeviceOffer?.offerDesc !== ''
                        ? `Promo ${recycleDeviceOffer.offerId} - ${recycleDeviceOffer.offerDesc} - ${
                            tradeInOfferPrice || 0
                          }`
                        : ''}
                    </PromoText>
                  </Col>
                </Grid>
              </div>
            );
          })}
          <Grid>
            <Col flex='12'>
              <div style={{ marginBottom: '1rem' }}>
                <UnderlinedText
                  id='ViewTradeInSectionModalBtn'
                  data-testid='viewDeviceTradeInDetails'
                  data-track='viewDeviceTradeInDetails'
                  onClick={() => onOpenModal(rfexType)}
                >
                  {props.viewLabel}
                </UnderlinedText>
              </div>
              <Modal
                className='viewdeviceModal'
                surface='light'
                disableAnimation={false}
                disableOutsideClick
                fullScreenDialog
                width='100%'
                ariaLabel='viewdeviceModal'
                opened={open[rfexType]}
                onOpenedChange={(opened) => setOpen({ ...open, [rfexType]: opened })}
                closeButton={null}
              >
                <div>
                  <EditTradeIn
                    opened={open[rfexType]}
                    closeModal={(type) => onCloseModal(type)}
                    lineInfo={lineInfo}
                    tradeInItemstrade={tradeInItem}
                    tradeInDetailtrade={tradeInDetails}
                    rfexType={rfexType}
                    refundreadOrder
                  />
                </div>
              </Modal>
            </Col>
          </Grid>
        </div>
      );
    }
  };

  return (
    <Container data-testid='TradeInSection'>
      <Column left>
        {refundTradeInItems.length > 0
          ? displayTradeIn('refund', refundTradeInItems, tradeAtHomeFlag, instantCreditFlag, refundTradeInDetail)
          : ''}
      </Column>
      <Column>
        {tradeInItems.length > 0
          ? displayTradeIn('exchange', tradeInItems, tradeAtHomeFlag, instantCreditFlag, tradeInDetail)
          : ''}
      </Column>
    </Container>
  );
};

TradeInSection.defaultProps = {
  tradeinhome: 'Trade at home',
  viewLabel: 'View',
  deviceTradeInCredit: 'Device trade-in credit',
  deviceTradeInDebit: 'Device trade-in debit',
  instantCreditEligibleLabel: 'Instant credit eligible',
};

TradeInSection.propTypes = {
  lineDetails: PropTypes.object.isRequired,
  tradeinhome: PropTypes.string,
  viewLabel: PropTypes.string,
  deviceTradeInCredit: PropTypes.string,
  deviceTradeInDebit: PropTypes.string,
  instantCreditEligibleLabel: PropTypes.string,
};

export default TradeInSection;
