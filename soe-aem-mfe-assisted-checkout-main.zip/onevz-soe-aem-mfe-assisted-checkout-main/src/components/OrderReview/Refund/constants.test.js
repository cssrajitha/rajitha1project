import { MODEL_POPUP } from './constants';

describe('MODEL_POPUP Constants', () => {
  test('should have the correct values', () => {
    expect(MODEL_POPUP.ORGINAL_PAID).toBe('ORGINAL_PAID');
    expect(MODEL_POPUP.ADJUSTED_DUE_TODAY).toBe('ADJUSTED_DUE_TODAY');
    expect(MODEL_POPUP.ITEMS_AT_GLANCE).toBe('ITEMS_AT_GLANCE');
    expect(MODEL_POPUP.MANUAL_DISCOUNT).toBe('MANUAL_DISCOUNT');
    expect(MODEL_POPUP.MANUAL_CHARGES).toBe('MANUAL_CHARGES');
    expect(MODEL_POPUP.DOWN_PAYMENT).toBe('DOWN_PAYMENT');
    expect(MODEL_POPUP.EXIT).toBe('EXIT');
    expect(MODEL_POPUP.ORDER_APPROVAL).toBe('ORDER_APPROVAL');
    expect(MODEL_POPUP.PAYMENT_HISTORY).toBe('PAYMENT_HISTORY');
    expect(MODEL_POPUP.VIEW_PRINT_RECEIPT).toBe('VIEW_PRINT_RECEIPT');
  });

  test('should have all expected keys', () => {
    const expectedKeys = [
      'ORGINAL_PAID',
      'ADJUSTED_DUE_TODAY',
      'ITEMS_AT_GLANCE',
      'MANUAL_DISCOUNT',
      'MANUAL_CHARGES',
      'DOWN_PAYMENT',
      'EXIT',
      'ORDER_APPROVAL',
      'PAYMENT_HISTORY',
      'VIEW_PRINT_RECEIPT',
    ];

    expect(Object.keys(MODEL_POPUP)).toEqual(expectedKeys);
  });
});
