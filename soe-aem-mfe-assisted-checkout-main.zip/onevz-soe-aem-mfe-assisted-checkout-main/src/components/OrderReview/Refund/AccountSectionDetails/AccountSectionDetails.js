import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { Modal } from '@vds/modals';
import { TextLink } from '@vds/buttons';
import styled from 'styled-components';
import { Body, Title } from '@vds/typography';
import { Col, Grid, Row } from '@vds/grids';
import AccountSectionModel from '../Modals/AccountSection/AccountSection';
import SharedFeatureModal from '../Modals/SharedFeatures/SharedFeatures';
import { formatCurrency } from '../../../../utils/common';
import {
  BorderBottomBlack,
  PaddingBottomSmall,
  PaddingRightSmall,
  PaddingTopLarge,
  StyledTextRight,
  ZeroPaddingCol,
} from '../../../../StyledConstants';

const AccountSectionDetails = ({ isPrePayCart, lineInfo, refundOrderDetails, planReferences }) => {
  const [open, setOpen] = useState(false);
  const [openFeatureModal, setOpenFeatureModal] = useState(false);

  const onOpenModal = () => {
    setOpen(true);
  };

  const onCloseModal = () => {
    setOpen(false);
  };

  const onChangePlan = () => {
    const isPlansMFEEnabled = JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.isPlansMFEEnabled === 'TRUE';
    if (isPrePayCart === 'Y') {
      window.location.href = `/sales/assisted/shop-plans.html`;
    } else if (isPlansMFEEnabled) {
      window.location.href = `/sales/assisted/new/gridwall.html?activeMtn=${lineInfo?.[0]?.serviceInfo?.mtn}&isPlanTabSelect=true`;
    } else {
      window.location.href = `/sales/assisted/plan-selection.html`;
    }
  };

  const onOpenFeatureModal = () => {
    setOpenFeatureModal(true);
  };

  const onCloseFeaturesModal = () => {
    setOpenFeatureModal(false);
  };

  const accountNumber = refundOrderDetails?.accountNumber ?? null;
  const price = lineInfo?.[0]?.serviceInfo?.selectedALPShareList?.alpShareInfo?.[0]?.accessFee ?? '0.00';
  const pricePlanDesc = lineInfo?.[0]?.serviceInfo?.selectedALPShareList?.alpShareInfo?.[0]?.servicePlanDesc ?? '';
  const formattedPlanName =
    lineInfo?.[0]?.serviceInfo?.selectedALPShareList?.alpShareInfo?.[0]?.formattedPlanName ?? '';
  const isIndirect = sessionStorage.getItem('channel')?.includes('OMNI-INDIRECT');

  const getPlanImageURL = () => {
    const imageUrl =
      lineInfo?.[0]?.serviceInfo?.selectedALPShareList?.alpShareInfo?.[0]?.imageUrlMap?.defaultImage ?? null;
    return imageUrl ? <img src={imageUrl} alt='' style={{ width: '80px' }} /> : '';
  };

  return (
    <div data-testid='account-section-details'>
      <div>
        <BorderBottomBlack>
          <div>
            <PaddingTopLarge>
              <Title size='medium' bold color='#000000'>
                Account
              </Title>
              <Title size='small' bold color='#000000'>
                {accountNumber}
              </Title>
            </PaddingTopLarge>
            <Grid bleed='1272' rowGutter='10px' className='u-paddingTopLarge u-paddingLeftNone u-paddingRightLarge'>
              <Row>
                <ZeroPaddingCol
                  colSizes={{
                    desktop: 2,
                    tablet: 2,
                  }}
                >
                  {getPlanImageURL()}
                </ZeroPaddingCol>
                {!isIndirect && (
                  <React.Fragment>
                    <Col
                      colSizes={{
                        desktop: 7,
                        tablet: 7,
                      }}
                    >
                      <div>
                        <Title size='small' bold color='#000000'>
                          <div
                            dangerouslySetInnerHTML={{
                              __html: `${pricePlanDesc}`,
                            }}
                          />
                        </Title>
                        <Body size='small' color='#000000'>
                          <div
                            dangerouslySetInnerHTML={{
                              __html: `${formattedPlanName}`,
                            }}
                          />
                        </Body>
                      </div>
                    </Col>
                    <Col
                      colSizes={{
                        desktop: 3,
                        tablet: 3,
                      }}
                    >
                      <div>
                        {price !== (0 || '0.00') && (
                          <StyledTextRight>
                            <Title bold size='small'>
                              {formatCurrency(price)}
                            </Title>
                          </StyledTextRight>
                        )}
                      </div>
                    </Col>
                  </React.Fragment>
                )}
              </Row>
            </Grid>

            {!isIndirect && price !== (0 || '0.00') && (
              <PaddingBottomRightSmall>
                <GridwithBorderBottom className='u-paddingRightSmall'>
                  <Row
                    className='
                   u-paddingRightSmall u-paddingYMedium'
                  >
                    <ZeroPaddingCol
                      colSizes={{
                        desktop: 6,
                        tablet: 6,
                      }}
                    >
                      <Title bold size='small'>
                        Total
                      </Title>
                    </ZeroPaddingCol>
                    <Col
                      colSizes={{
                        desktop: 6,
                        tablet: 6,
                      }}
                    >
                      <StyledTextRight>
                        <Title bold size='small' data-testid='total-currency'>
                          {formatCurrency(price)}
                        </Title>
                      </StyledTextRight>
                    </Col>
                  </Row>
                </GridwithBorderBottom>
              </PaddingBottomRightSmall>
            )}

            <div
              className='u-paddingBottomMedium u-paddingTopMedium'
              style={{ display: 'flex', justifyContent: 'space-between' }}
            >
              <TextLink type='standAlone' data-testid='delete-accessories-link' size='medium' onClick={onOpenModal}>
                view
              </TextLink>

              <TextLink data-testid='viewSharedFeatures' onClick={onOpenFeatureModal}>
                View Shared Features
              </TextLink>
            </div>

            <Modal
              opened={open}
              surface='light'
              fullScreenDialog
              disableAnimation
              disableOutsideClick={false}
              ariaLabel='Account Section'
              closeButton={null}
            >
              <div>
                <AccountSectionModel
                  closeModal={onCloseModal}
                  lineInfo={lineInfo}
                  cartOrderDetail={refundOrderDetails}
                  planReferences={planReferences}
                  changePlan={onChangePlan}
                />
              </div>
            </Modal>

            <ModalWrapper>
              <Modal
                disableAnimation
                disableOutsideClick
                fullScreenDialog
                width='100%'
                ariaLabel='View Shared Features'
                opened={openFeatureModal}
                closeButton={null}
              >
                <div>
                  <SharedFeatureModal closeModal={onCloseFeaturesModal} />
                </div>
              </Modal>
            </ModalWrapper>
          </div>
        </BorderBottomBlack>
      </div>
    </div>
  );
};

AccountSectionDetails.propTypes = {
  lineInfo: PropTypes.array.isRequired,
  refundOrderDetails: PropTypes.object.isRequired,
  planReferences: PropTypes.array,
  isPrePayCart: PropTypes.bool,
};

export const PaddingBottomRightSmall = styled.div`
  ${PaddingBottomSmall}
  ${PaddingRightSmall}
`;

export const GridwithBorderBottom = styled(Grid)`
  padding-bottom: 20px;
  border-bottom: 1px solid #d8dada !important;
`;

const ModalWrapper = styled.div`
  background-color: 'rgb(0 0 0 / 70%)';
`;

export default AccountSectionDetails;
