import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import AccountSectionDetails from './AccountSectionDetails';

jest.mock('@vds/modals', () => ({
  ...jest.requireActual('@vds/modals'),
  // eslint-disable-next-line react/button-has-type, react/prop-types
  Modal: ({ children, ...props }) => (
    // eslint-disable-next-line react/prop-types
    <div {...props} data-testid={props.id}>
      {children}
    </div>
  ),
}));

describe('AccountSectionDetails', () => {
  const lineInfo = [
    {
      serviceInfo: {
        selectedALPShareList: {
          alpShareInfo: [
            {
              accessFee: '10.00',
              servicePlanDesc: 'Plan Description',
              formattedPlanName: 'Formatted Plan Name',
              imageUrlMap: { defaultImage: 'image-url' },
            },
          ],
        },
      },
    },
  ];
  const refundOrderDetails = { accountNumber: '123456' };
  const planReferences = [];
  const handleGetReferences = jest.fn();
  const onOpenModal = jest.fn();

  beforeEach(() => {
    sessionStorage.setItem('channel', 'OMNI-DIRECT');
  });

  test('opens the modal when "view" is clicked and click Done button', async () => {
    render(
      <Router>
        <AccountSectionDetails
          lineInfo={lineInfo}
          refundOrderDetails={refundOrderDetails}
          planReferences={planReferences}
          handleGetReferences={handleGetReferences}
          onOpenModal={onOpenModal}
        />
      </Router>,
    );

    fireEvent.click(screen.getByTestId('delete-accessories-link'));
    expect(screen.getByText('view')).toBeInTheDocument();
    await new Promise((res) => {
      setTimeout(res, 100); // Reduced for CI efficiency
    });
    await screen.findAllByRole('button', { name: 'Done' });

    expect(screen.getByText('view')).toBeInTheDocument();
  });

  it('opens the modal when "view" is clicked and click Done button', async () => {
    render(
      <Router>
        <AccountSectionDetails
          lineInfo={lineInfo}
          refundOrderDetails={refundOrderDetails}
          planReferences={planReferences}
          handleGetReferences={handleGetReferences}
          onOpenModal={onOpenModal}
        />
      </Router>,
    );

    fireEvent.click(screen.getByTestId('delete-accessories-link'));
    expect(screen.getByText('view')).toBeInTheDocument();
    await new Promise((res) => {
      setTimeout(res, 100); // Reduced for CI efficiency
    });
    fireEvent.click(screen.getByText('Change Plan'));

    expect(screen.getByText('view')).toBeInTheDocument();
  });
});
