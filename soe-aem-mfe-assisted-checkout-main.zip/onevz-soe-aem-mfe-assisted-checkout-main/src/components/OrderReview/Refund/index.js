import { useEffect, useState } from 'react';
import styled from 'styled-components';
import { getQueryParamByName, setIntentType, getUIContextPath } from 'onevzsoemfecommon/Helpers';
import { Grid, Row, Col } from '@vds/grids';
import PropTypes from 'prop-types';
import { Modal } from '@vds/modals';
import { useDispatch } from 'react-redux';
import { Button as VdsButton } from '@vds/buttons';
import { Body } from '@vds/typography';
import { useNavigate } from 'react-router-dom';
import { has } from 'lodash';
import { useLazyGetFetchDownpaymentQuery } from 'onevzsoemfecommon/APIService';
import { ViewExitDialog } from 'onevzsoemfecommon/ViewExitDialog';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { isIpad } from 'onevzsoemfeframework/DomService';
import { showShippingAddress } from '../../../utils/orderreviewUtil';
import { NotificationTagging, OpenViewTagging, callPageViewMFE } from '../../../utils/tagging';
import Header from './Header';
import './Style/style.css';
import LineDetails from './LineDetails/LineDetails';
import {
  useLazyGetCartDetailsQuery,
  useLazyGetReadOrderQuery,
  useLazyLpRetrieveCompleteOrderDetailsQuery,
  useLazyGetOrderWriteQuery,
  useLazyGetAccountAddressValidationQuery,
  useLazyGetRetrieveInstallmentAgreementQuery,
} from '../../../modules/services/APIService/APIServiceCallHook';
import { isDfill } from './utils/utils';
import CommonHeader from './Modals/CommonHeader';
import GetAccessApiCallHook from '../../../modules/services/APIService/GetAccessAPICallHook';
import { MODEL_POPUP } from './constants';
import { formatDate } from '../../../utils/common';
import AccountSectionDetails from './AccountSectionDetails/AccountSectionDetails';
import TotalSummary from './TotalSummary';
import Agreements from '../Agreements';
import ActivationStatus from '../../ReadOrder/ActivationStatus';
import PaymentHistoryModal from '../../PaymentHistory/PaymentHistory';
import { useLazyGetValidateCartAndCheckoutQuery } from '../../../modules/services/APIService/APIServiceHooks';
import ViewOrderDocument from '../ViewOrderDocument/ViewOrderDocument';
import ManualDiscountView from '../ManualDiscountView';
import TradeInSection from './TradeInSection/TradeInSection';
import DownPaymentViewModal from '../DownPaymentViewModal';
import orderreviewApiCallHook from '../../../pages/home/container/orderreviewApiCallHook';

const Button = styled(VdsButton)`
  padding: 0 1.5rem 0 1.5rem;
`;

const Padding36 = styled.div`
  padding: 1.5rem 2rem;
`;
const FooterArea = styled.div`
  max-width: 64rem;
  background-color: rgb(255, 255, 255);
  z-index: 1;
  bottom: 0px;
  position: sticky;
  width: 100%;
  display: flex;
  border-top: 1px solid rgb(204, 204, 204);
  justify-content: center;
`;

function Refund(props) {
  const [showCloseModal, setShowCloseModal] = useState(false);
  const [orderConfirmation, setOrderConfirmation] = useState(false);
  const [orderNumber, setorderNumber] = useState('');
  const [locationCode, setlocationCode] = useState('');
  const [isReadOrder, setisReadOrder] = useState(false);
  const [rfOrderNumber, setrfOrderNumber] = useState('');
  // eslint-disable-next-line no-unused-vars
  const [rfLocationCode, setrfLocationCode] = useState('');
  // eslint-disable-next-line no-unused-vars
  const [itemsGlanceModal, setitemsGlanceModal] = useState(false);
  const [manualChargesModal, setmanualChargesModal] = useState(false);
  // eslint-disable-next-line no-unused-vars
  const [manualExitModal, setmanualExitModal] = useState(false);
  // eslint-disable-next-line no-unused-vars
  const [isPaymentHistory, setisPaymentHistory] = useState(false);
  // eslint-disable-next-line no-unused-vars
  const [showViewAndPrintReceipt, setshowViewAndPrintReceipt] = useState(false);
  const [isServiceWriteRequired, setisServiceWriteRequired] = useState(false);
  const [isAccessoryFlow, setisAccessoryFlow] = useState(false);
  const [showAgreements, setshowAgreements] = useState(false);
  const [hqUser, sethqUser] = useState(false);
  const [fiveGHomeOrder, setfiveGHomeOrder] = useState(false);
  const [completeOrderDetails, setCompleteOrderDetails] = useState(null);
  const [faeIntentType, setfaeIntentType] = useState('');
  const [downPaymentModal, setDownPaymentModal] = useState(false);
  const [RetrieveCompleteOrderDetails] = useLazyLpRetrieveCompleteOrderDetailsQuery();
  const [getCartRequest, retrieveCart] = useLazyGetCartDetailsQuery();
  const [fetchReadOrder, rspFetchReadOrder] = useLazyGetReadOrderQuery();
  const [loadsubmitCart] = useLazyGetOrderWriteQuery();
  const [accountaddressValidation] = useLazyGetAccountAddressValidationQuery();
  const [getRetrieveInstallmentAgreement, getRetrieveInstallmentAgreementResult] =
    useLazyGetRetrieveInstallmentAgreementQuery();
  const [fetchDownPaymentBody, fetchDownPaymentResult] = useLazyGetFetchDownpaymentQuery();
  const { CustomerProfileResult } = orderreviewApiCallHook() || {};
  const dispatch = useDispatch();
  const { addAccessories } = GetAccessApiCallHook();

  const [getValidateCartAndCheckoutBody] = useLazyGetValidateCartAndCheckoutQuery();
  const [showActivationModal, setShowActivationModal] = useState(false);
  const [viewPromoDiscount, setViewPromoDiscount] = useState(false);
  const [downpayment, setDownpayment] = useState(0);
  const [modelHeaderName] = useState([
    'Item info',
    'Qty',
    'Price / Unit',
    'Down Payment',
    'Offer Amt',
    'Offer ID',
    'Manual Discount',
    'Reb Ind',
    'Tax',
    'Total',
    'Ware House',
  ]);

  const [agreements] = useState({
    showTradein: false,
    showDp: false,
    showCustomer: false,
  });
  const [agreementData, setAgreementData] = useState({
    type: '',
    title: '',
    body: '',
    isFirstPdf: false,
  });
  const channel = sessionStorage.getItem('channel');

  let navigate = '';
  function useNavigateMFE() {
    navigate = useNavigate();
  }
  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }
  const [enableLead, setEnableLead] = useState(false);
  const [refundSrchOrder, setRefundSrchOrder] = useState(false);

  useEffect(() => {
    fetchDownPaymentBody({ body: { header: {}, cartId: CustomerProfileResult?.data?.data?.customer?.cartId } });
  }, []);

  useEffect(() => {
    setorderNumber(props?.orderNumber);
    setlocationCode(props?.locationCode);
    const isReadOrderValue = !!(getQueryParamByName('isReadOrder') || props.isReadOrder);
    setisReadOrder(isReadOrderValue);
    const cartParams = props.customer?.cartParams;
    const isAccessoryFlowValue = !!(
      cartParams?.isHomeSales &&
      cartParams?.homeSalesAddress &&
      cartParams?.streetAddress
    );

    setisAccessoryFlow(isAccessoryFlowValue);
  }, [props]);

  useEffect(() => {
    const retrieveCartValue = retrieveCart?.data?.data?.cart?.orderDetails?.hqUser || false;
    const fiveGHomeOrderValue = retrieveCart?.data?.data?.cart?.orderDetails?.fiveGHomeOrder || false;
    sethqUser(retrieveCartValue);
    setfiveGHomeOrder(fiveGHomeOrderValue);
  }, [retrieveCart]);

  useEffect(() => {
    const intentType = getQueryParamByName('intentType') || sessionStorage.getItem('FAEIntentType') || '';
    setfaeIntentType(intentType);
    callReadOrder();
  }, []);

  useEffect(() => {
    try {
      if (rspFetchReadOrder?.data?.data?.cart?.cartHeader?.cartId) {
        getCartRequest({
          body: {
            data: {
              cartId: rspFetchReadOrder?.data?.data?.cart?.cartHeader?.cartId || '',
            },
          },
          mock: false,
        });
      }
      if (rspFetchReadOrder?.data) {
        if (isIpad()) {
          sessionStorage.setItem('channel', localStorage.getItem('channel'));
        }
      }

      if (rspFetchReadOrder?.isError && rspFetchReadOrder?.error?.status === 500) {
        dispatch(appMessageActions.addAppMessage('Request failed with status code 500', 'error', true, true));
        NotificationTagging(
          '',
          '',
          'Request failed with status code 500',
          'EUP|RFEX-read-order',
          'orderReview',
          rspFetchReadOrder,
        );
      }
    } catch (error) {
      console.error('Error : ', error);
      dispatch(appMessageActions.addAppMessage(error.message, 'error', true, true));
    }
  }, [rspFetchReadOrder]);

  useEffect(() => {
    if (getRetrieveInstallmentAgreementResult?.data) {
      const { type, response } = getRetrieveInstallmentAgreementResult.data;
      setshowAgreements(true);
      setAgreementData({
        type,
        body: response?.[0]?.installmentContractData || '',
        isFirstPdf: true,
      });
    }
  }, [getRetrieveInstallmentAgreementResult]);

  useEffect(() => {
    setrfOrderNumber(getQueryParamByName('orderNumber'));
    setrfLocationCode(getQueryParamByName('locationCode'));
    RetrieveCompleteOrderDetailsFunc();

    // This is used for MFE Tagging where we are making pageview call
    const accountNumberfromCart = `${retrieveCart?.data?.data?.cart?.refundOrderDetails?.accountNumber}-${retrieveCart?.data?.data?.cart?.refundOrderDetails?.accountSubNumber}`;
    const obj = {
      channel: 'Order',
      detail: '',
      flow: 'EUP|RFEX-read-order',
      name: 'orderReview',
      intent: 'Order',
      cartId: sessionStorage.getItem('cartId') || customerProfile?.data?.customer?.cartId || '',
      accountNumber: accountNumberfromCart || '',
    };
    callPageViewMFE(obj);
  }, []);

  const callReadOrder = () => {
    const bodyReadOrder = {
      meta: { client: 'VZW-NETACE' },
      data: {
        orderNumber: getQueryParamByName('orderNumber'),
        locationCode: getQueryParamByName('locationCode'),
      },
    };
    fetchReadOrder({ body: bodyReadOrder, mock: false });
  };

  const lineInfoList = (lineInfo1, value) => {
    const lineList = [];
    lineInfo1?.map((line) => {
      const itemObj = {
        id: 'ADJ90081001',
        qty: '1',
        adjPrc: value,
        isSoftSku: true,
        accessoryBundle: false,
        customBundleId: '',
        accessoryGiftCardId: '',
        refundType: 'E',
      };

      const lineObj = {
        mtn: line?.mobileNumber,
        mdnFilterValue: line?.mobileNumber,
        addAccessories: itemObj,
        depletionLocationCode: null,
      };
      lineList.push(lineObj);
      return lineObj;
    });

    return lineList;
  };

  const handleRetrieveCartRequest = async (req) => {
    try {
      const response = await getCartRequest({ body: req, mock: false });

      const readOrderResp = response?.data?.data?.cart || {};

      const readOrderErrors = response?.data?.data?.errors || [];
      const errors = [];
      if (readOrderErrors && readOrderErrors?.length > 0) {
        readOrderErrors?.forEach((error) => {
          errors.push(error.message);
        });
      }

      if (errors?.length > 0) {
        dispatch(appMessageActions.addAppMessage(errors[0], 'error', true, true));
      } else {
        let isDfil = false;
        const lineInfo = readOrderResp?.lineDetails?.lineInfo || [];
        lineInfo?.forEach((line) => {
          if (line?.lineActivityType === 'EXC' || line?.lineActivityType === 'REX') {
            line?.itemsInfo?.forEach((itemInfo) => {
              itemInfo?.cartItems?.cartItem?.forEach((item) => {
                if (['ACCESSORY', 'DEVICE'].includes(item?.cartItemType) && item?.depletionType === 'F') {
                  isDfil = true;
                }
              });
            });
          }
        });

        if (isDfil) {
          isDfil = true;
        }
      }
    } catch (error) {
      console.error('Error : ', error);
      dispatch(appMessageActions.addAppMessage(error.message, 'error', true, true));
    }
  };

  const handleValidateCartAndCheckout = async (action) => {
    try {
      const fromOrderReviewPage = action && action?.page === 'OR';
      const fromShippingPage = action && action?.page === 'SHIPPING';
      const request = {
        cartInfo: {
          isInterimValidation: true,
          effectivedate: false,
          intendType: 'REX',
          flow: 'RF', // restrict CXP from over-riding line activity type
          processingMTN: rspFetchReadOrder?.data?.data?.cart?.lineDetails?.lineInfo[0]?.mobileNumber || '',
          processStep: 'ShoppingCart',
          processAction: 'proceedToOrder',
          cartId: rspFetchReadOrder?.data?.data?.cart?.cartHeader?.cartId || '',
          caseId: rspFetchReadOrder?.data?.data?.cart?.cartHeader?.caseId || '',
          accountNumber: '',
        },
        channelId: sessionStorage.getItem('channel'),
      };
      setIntentType(request?.cartInfo?.intendType);

      const response = await getValidateCartAndCheckoutBody({ body: request, mock: false });

      const validateCartErrors = response?.data?.errors || [];
      const errors = [];

      if (validateCartErrors && validateCartErrors?.length > 0) {
        validateCartErrors?.forEach((error) => {
          errors.push(error.message);
        });
      }

      if (errors?.length > 0) {
        dispatch(appMessageActions.addAppMessage(errors[0], 'error', true, true));
      } else if (fromOrderReviewPage || fromShippingPage) {
        action.history.navigatePage(`${getUIContextPath()}/refundexchange/order-review.html`);
      } else {
        const req = {
          data: {
            cartId: rspFetchReadOrder?.data?.data?.cart?.cartHeader?.cartId || '',
          },
        };

        await handleRetrieveCartRequest(req);
      }
    } catch (error) {
      dispatch(appMessageActions.addAppMessage(error?.message, 'error', true, true));
    }
  };

  const handleManualPriceCorrection = async (request) => {
    try {
      const response = await addAccessories({
        body: request,
        customHeaders: { Flowname: 'REX', Intenttype: 'REX' },
        mock: false,
      });

      const priceCorrectionErrors = response?.data?.errors || [];
      const errors = [];

      if (priceCorrectionErrors && priceCorrectionErrors?.length > 0) {
        priceCorrectionErrors?.forEach((error) => {
          errors.push(error?.message);
        });
      }

      if (errors?.length > 0) {
        dispatch(appMessageActions.addAppMessage(errors[0], 'error', true, true));
      } else if (response?.data?.serviceBody) {
        dispatch(appMessageActions.addAppMessage('Manual Price updated correctly', 'success', true, true));
        handleValidateCartAndCheckout();
        NotificationTagging(
          'manualCharges',
          'manualCharges',
          'Manual Price updated correctly',
          'EUP|RFEX-read-order',
          'orderReview',
          rspFetchReadOrder,
        );
      }
    } catch (error) {
      dispatch(appMessageActions.addAppMessage(error?.message, 'error', true, true));
    }
  };

  const closeManualChargesModal = async (buttonName, value) => {
    if (buttonName === 'Done') {
      const lineInfo = rspFetchReadOrder?.data?.data?.cart?.lineDetails?.lineInfo || [];
      let depletionTypeFn;

      if (hqUser) {
        depletionTypeFn = 'F';
      } else if (isDfill) {
        depletionTypeFn = 'F';
      } else {
        depletionTypeFn = 'L';
      }
      const request = {
        cartInfo: {
          processingMTN: lineInfo[0]?.mobileNumber || '',
          processStep: 'OrderReview-Shipping',
          processAction: 'addManualPriceCorrection',
          intent: 'StandAloneAccessory',
          intendType: 'REX',
          pageId: 'PROTECTION',
          clearCart: false,
          cartId: '',
          caseId: '',
        },
        data: {
          multiAccBogoOffer: false,
          depletionType: depletionTypeFn,
          lines: lineInfoList(lineInfo, value),
        },
        validateCartRequest: {
          pageId: 'CART',
          retrieveCurrentFeatures: true,
        },
      };
      setIntentType(request?.cartInfo?.intendType);
      await handleManualPriceCorrection(request);
    }
    OpenViewTagging('manualCharges', 'Done', 'EUP|RFEX-read-order', 'orderReview', rspFetchReadOrder);
    setmanualChargesModal(false);
  };

  const closeItemsGlanceModal = () => {
    setitemsGlanceModal(false);
  };

  const RetrieveCompleteOrderDetailsFunc = async () => {
    const request = {
      orderNum: orderNumber,
      locationCode,
      readWithNoLock: false,
      orderType: '',
      retrieveCredit: true,
      retrieveAceOrder: false,
      retrieveRefundOrder: false,
      retrieveEcpd: false,
      retrieveEcpdInfo: false,
      retrieveServiceAndActivation: false,
      retrievePortIn: false,
      retrieveItems: true,
      retrieveTax: false,
      retrieveInstallment: false,
      retrieveEdgeUp: false,
      retrieveEarlyEdgeUp: false,
      retrieveProductImpacts: false,
      retrievePayments: false,
      retrieveHoldOrder: false,
      retrieveFulfillment: false,
      retrieveRemarks: false,
      retrieveItemRemarks: false,
      retrieveHoldemarks: false,
      retrieveRecycleDevice: false,
      retrieveAutoPaymentDetails: false,
      retrieveSecurePaymentOrderDetails: false,
      retrieveISPUOrderStatus: false,
      retrieveVendorItems: false,
      retrieveLinkedTradeOrders: false,
      retrieveAdditionalDetails: false,
      orderNumber,
    };
    await RetrieveCompleteOrderDetails({ body: request, mock: false }).then((response) => {
      if (response !== undefined) {
        const result = response?.data?.data || response?.data;
        if (result) {
          console.log('RetrieveCompleteOrderDetails Sucess Response : ', result);
          setCompleteOrderDetails(result);
        }
      }
    });
  };

  const hemburgerMenuPopup = (modelName) => {
    console.log('Selected MenuItem is : ', modelName);
    if (modelName === 'ITEMS_AT_GLANCE') {
      setitemsGlanceModal(true);
    } else if (modelName === 'MANUAL_DISCOUNT') {
      console.log('Manual Discount handling');
      setViewPromoDiscount(true);
    } else if (modelName === 'DOWN_PAYMENT') {
      setDownPaymentModal(true);
    } else if (modelName === 'MANUAL_CHARGES') {
      setmanualChargesModal(true);
    } else if (modelName === 'PAYMENT_HISTORY') {
      setisPaymentHistory(true);
    } else if (modelName === 'VIEW_PRINT_RECEIPT') {
      setshowViewAndPrintReceipt(true);
    }
  };

  const openOrderReviewCloseModel = () => {
    setShowCloseModal(true);
    setOrderConfirmation(true);
    setEnableLead(true);
    setRefundSrchOrder(false);
  };

  const openExitModel = () => {
    setShowCloseModal(true);
    setOrderConfirmation(false);
    setEnableLead(false);
    setRefundSrchOrder(true);
  };

  const handleAcceptAndContinue = () => {
    const retailFwaDelayCartFFlag = !!(
      props?.assistedRfexflags?.retailFwaDelayCartFFlag === 'TRUE' ||
      JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.retailFwaDelayCartFFlag === 'TRUE'
    );
    const retailFwaSkipOrderReviewFFlag = !!(
      props?.assistedRfexflags?.retailFwaSkipOrderReviewFFlag === 'TRUE' ||
      JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.retailFwaSkipOrderReviewFFlag === 'TRUE'
    );
    const isBlindFlow = props?.isBlindFlow || false;
    if (sessionStorage.getItem('secondNumberMtns')) {
      sessionStorage.removeItem('secondNumberMtns');
    }
    const lineInfo =
      retrieveCart?.data?.data?.cart?.lineDetails?.lineInfo ||
      rspFetchReadOrder?.data?.data?.cart?.lineDetails?.lineInfo ||
      [];
    const showShippingSection = showShippingAddress(lineInfo);
    const shippingAddress =
      retrieveCart?.data?.data?.cart?.lineDetails?.lineInfo[0]?.itemsInfo[0]?.shipping?.address ||
      rspFetchReadOrder?.data?.data?.cart?.lineDetails?.lineInfo[0]?.itemsInfo[0]?.shipping?.address ||
      '';
    const addressLine1POBOX = has(shippingAddress, 'addressLine1')
      ? shippingAddress?.addressLine1?.replace(/[^\w]/gi, '').toLowerCase().includes('pobox')
      : '';
    const streetNamePOBOX = has(shippingAddress, 'streetName')
      ? shippingAddress?.streetName?.replace(/[^\w]/gi, '').toLowerCase().includes('pobox')
      : '';
    const skipAddressValidation = props?.skipAddressVerification || false;
    const isCurrentAddress = props?.isCurrentAddress || false;
    const keepCurrentAddressWithPOBOX = isCurrentAddress ? addressLine1POBOX || streetNamePOBOX : true;
    const isGuestCheckout =
      retrieveCart?.data?.data?.cart?.orderDetails?.guestOrInactiveRefundLines ||
      rspFetchReadOrder?.data?.data?.cart?.lineDetails?.lineInfo[0]?.guestOrInactiveRefundLines ||
      false;
    const lineActivityType =
      retrieveCart?.data?.data?.cart?.lineDetails?.lineInfo[0]?.lineActivityType ||
      rspFetchReadOrder?.data?.data?.cart?.lineDetails?.lineInfo[0]?.lineActivityType ||
      '';
    const skipAddressValidationForGuestCheckout = props?.skipAddressValidationForGuestCheckout !== false;
    const intentTypeValue = getQueryParamByName('intentType');
    const condoneResult = showShippingSection || (isGuestCheckout && !skipAddressValidationForGuestCheckout);

    if (
      condoneResult &&
      !skipAddressValidation &&
      keepCurrentAddressWithPOBOX &&
      isDfill &&
      !isBlindFlow &&
      lineActivityType !== 'DIS'
    ) {
      const request = {
        cartId: rspFetchReadOrder?.data?.data?.cart?.cartHeader?.cartId || '',
      };
      validateShippingAdress(request, props?.history);
    } else if (isGuestCheckout && skipAddressValidationForGuestCheckout && isDfill && !isBlindFlow) {
      navigate(`${getUIContextPath()?.replace('/refundexchange', '')}/shipping-details.html?isRfexFlow=Y`);
    } else if (isBlindFlow) {
      onOpenApprovalModal();
    } else if (intentTypeValue === '5GHomeRetailRFEX') {
      if (retailFwaDelayCartFFlag) {
        navigate(`${getUIContextPath()?.replace('/refundexchange', '')}/order-review.html?intentType=5GHomeRetailRFEX`);
      } else if (retailFwaSkipOrderReviewFFlag) {
        const FAEOrderWriteReq = {
          locationCode: '',
          accountNumber:
            props?.advExchangeCartDetails?.customerInfo?.accountNumber ||
            sessionStorage.getItem('FAEAccountNumber') ||
            '',
          mtn: props?.advExchangeCartDetails?.customerInfo?.cartCreator || sessionStorage.getItem('FAEMtn') || '',
          cartId: props?.advExchangeCartDetails?.cartInfo?.cartId || sessionStorage.getItem('FAECartId') || '',
          caseId: props?.advExchangeCartDetails?.caseId || sessionStorage.getItem('FAECaseId') || '',
          cartCreator:
            props?.advExchangeCartDetails?.customerInfo?.cartCreator || sessionStorage.getItem('FAEMtn') || '',
          serviceWriteRequired: false,
          smsDestination: '',
          email: '',
          intent: '5GHomeRetailRFEX',
          paperlessIndicator: null,
          paperLessEmail: null,
          header: {
            cartId: props?.advExchangeCartDetails?.cartInfo?.cartId || sessionStorage.getItem('FAECartId') || '',
          },
          nbxSessionId: '',
          regNo: '',
          quoteId: '',
          creditAppNum: '',
          purchaseOrderNumber: '',
          billingSystem: 'VE',
        };
        loadSubmitOrder(FAEOrderWriteReq, props.history);
      }
    } else {
      handleProceedToOrder();
    }
  };

  // eslint-disable-next-line no-unused-vars
  const loadSubmitOrder = async (requestbody, history) => {
    // API call /orderprocessservice/orderwriteapi/orderWrite
    await loadsubmitCart({ body: requestbody, mock: false }).then((response) => {
      if (response !== undefined) {
        const responseData = response?.data || response;
        if (responseData) {
          const successresult = responseData?.data || responseData;
          const processStep = successresult?.processStep || '';
          const availablePaths = successresult?.availablePaths || [];
          const showAgreementsValue = agreements?.showTradein || agreements?.showDp;
          const hasDpAgreement =
            availablePaths?.find((agreement) => agreement?.path === 'DevicePaymentAgreement') || showAgreementsValue;
          if (hasDpAgreement) {
            const request = {
              header: {},
              cartId: rspFetchReadOrder?.data?.data?.cart?.cartHeader?.cartId || '',
            };
            getRetrieveInstallmentAgreement({ body: request, spinner: true, mock: false });
          }

          if (
            !channel?.includes('OMNI-INDIRECT') &&
            (processStep === 'Payment-Agreement' || processStep === 'Confirmation')
          ) {
            setshowAgreements(showAgreementsValue);
            setisServiceWriteRequired(false);
            if (!hasDpAgreement) {
              console.log('faeIntentType value is : ', faeIntentType);
              navigate(`/sales/assisted/new/payment-agreement.html?isRxorderreview=Y`);
            }
          }
        }
      }
    });
  };

  // eslint-disable-next-line no-unused-vars
  const validateShippingAdress = async (requestbody, history) => {
    // API call /shippinghandlingservice/shipping/getAccountAddressValidation
    await accountaddressValidation({ body: requestbody, mock: false }).then((response) => {
      if (response !== undefined) {
        const responseData = response?.data || response;
        if (responseData?.error?.data?.errors?.length > 0) {
          const resulterror = responseData?.error?.data?.errors[0]?.message;
          console.log('Error in accountaddressValidation : ', resulterror);
        } else if (responseData?.data) {
          const successresult = responseData?.data || responseData;
          const shipAddress = successresult?.shipAddress || '';
          const invalidAddress =
            shipAddress &&
            shipAddress.filter(({ shipAddressValid }) => !shipAddressValid).map((address) => ({ ...address }));
          if (invalidAddress?.length === 0) {
            handleProceedToOrder();
          } else {
            navigate(`${getUIContextPath()?.replace('/refundexchange', '')}/shipping-details.html?isRfexFlow=Y`);
          }
        }
      }
    });
  };

  const onOpenApprovalModal = () => {
    console.log('Open Approval Modal');
  };

  const toggleAgreements = () => {
    setshowAgreements(!showAgreements);
  };

  const handleTogglePaymentHistory = (value) => {
    setisPaymentHistory(value);
  };

  const handleProceedToOrder = () => {
    const accountNumber = `${retrieveCart?.data?.data?.cart?.refundOrderDetails?.accountNumber}-${retrieveCart?.data?.data?.cart?.refundOrderDetails?.accountSubNumber}`;
    const request = {
      locationCode:
        retrieveCart?.data?.data?.cart?.orderDetails?.locationCode ||
        rspFetchReadOrder?.data?.data?.cart?.orderDetails?.locationCode ||
        sessionStorage.getItem('location') ||
        '',
      accountNumber: accountNumber || '',
      mtn:
        retrieveCart?.data?.data?.cart?.lineDetails?.lineInfo[0]?.mtnDetails?.mobileNumber ||
        rspFetchReadOrder?.data?.data?.cart?.lineDetails?.lineInfo[0]?.mobileNumber ||
        '',
      cartId: '',
      caseId: '',
      cartCreator:
        retrieveCart?.data?.data?.cart?.lineDetails?.lineInfo[0]?.mtnDetails?.mobileNumber ||
        rspFetchReadOrder?.data?.data?.cart?.lineDetails?.lineInfo[0]?.mobileNumber ||
        '',
      serviceWriteRequired: isServiceWriteRequired,
      email: '',
      intent: 'REX',
      header: { cartId: '' },
      regNo: sessionStorage.getItem('registerNumber') || '',
      quoteId: '',
    };
    console.log('request123456', request);
    if (channel?.includes('OMNI-RETAIL')) {
      request.readOrderRfex = isReadOrder;
    }
    loadSubmitOrder(request, props.history);
  };

  const renderFooter = () => {
    const { processStep } = rspFetchReadOrder?.data?.data || {};

    if (isReadOrder && rspFetchReadOrder && (processStep === 'CLOSE' || processStep === '')) {
      return (
        <Button
          className='Button Button--primary bold'
          data-track='CLOSE'
          data-testid='close-button'
          onClick={() => {
            openOrderReviewCloseModel();
            OpenViewTagging('Close', 'Close', 'EUP|RFEX-read-order', 'orderReview', rspFetchReadOrder);
          }}
        >
          Close
        </Button>
      );
    }

    if (isReadOrder && rspFetchReadOrder && processStep === 'CONTINUE') {
      return (
        <Button
          data-testid='continue-button'
          className='Button Button--primary bold'
          data-track='CONTINUE'
          onClick={() => {
            handleAcceptAndContinue();
            OpenViewTagging('continue', 'continue', 'EUP|RFEX-read-order', 'orderReview', rspFetchReadOrder);
          }}
        >
          Continue
        </Button>
      );
    }
    if (isReadOrder && rspFetchReadOrder && processStep === 'ACTIVATE') {
      return (
        <>
          <Button
            data-testid='Activate-button'
            className='Button Button--primary bold'
            data-track='ACTIVATE'
            onClick={() => {
              setShowActivationModal(true);
              OpenViewTagging(
                'activationStatus',
                'activationStatus',
                'EUP|RFEX-read-order',
                'orderReview',
                rspFetchReadOrder,
              );
            }}
          >
            Activate
          </Button>
          {showActivationModal && (
            <Modal
              opened={showActivationModal}
              fullScreenDialog
              disableOutsideClick
              closeButton={null}
              disableAnimation
            >
              <ActivationStatus
                isFromRefundOrderView
                cartData={retrieveCart?.data?.data}
                closeActivationStatus={() => setShowActivationModal(false)}
                readOrderData={rspFetchReadOrder?.data?.data}
              />
            </Modal>
          )}
        </>
      );
    }
  };

  const appPropertiesFromSessionStorage = JSON.parse(sessionStorage.getItem('APP_PROPERTIES'));
  const readOrderResp = rspFetchReadOrder?.data?.data || {};
  const { cart } = rspFetchReadOrder?.data?.data || [];
  const { data: retrieveCartData } = retrieveCart?.data || {};
  const lineInfo = retrieveCartData?.cart?.lineDetails?.lineInfo || []; // mapped to retrieve-cart API as in BAU
  const tradesection = !!(
    retrieveCartData?.cart?.lineDetails?.tradeInDetail && retrieveCartData?.cart?.lineDetails?.refundTradeInDetail
  );
  const isPrePayCart = retrieveCartData?.cart?.orderDetails?.isPrePayCart;
  const lineDetails = retrieveCartData?.cart?.lineDetails || {};
  const customerProfile = retrieveCartData?.customerProfile || {};
  const refundOrderDetails = retrieveCartData?.cart?.refundOrderDetails || {};
  const cartOrderDetail = retrieveCartData?.cart?.orderDetails || {};
  const subAccountNBSInfo = retrieveCartData?.lineDetails?.subAccountNBSInfo || {};
  const cartType = retrieveCartData?.cartHeader?.cartType;
  const searchParams = new URLSearchParams(window.location.search);
  const isDfil = isDfill(lineInfo);
  const history = {
    location: {
      pathname: window.location.pathname,
      search: searchParams.toString() ? `?${searchParams.toString()}` : '',
      hash: '',
      state: null,
      key: 'default',
    },
  };
  // Alternatively getting data from readorder API as substitute to retrieveCart API to map data
  const orderStatusVal = readOrderResp?.orderStatus || '';
  const orderNumVal =
    retrieveCart?.data?.data?.cart?.refundOrderDetails?.orderNum ||
    readOrderResp?.cart?.orderDetails?.orderList[0]?.orderNumber ||
    '';
  const locationCodeVal =
    retrieveCart?.data?.data?.cart?.refundOrderDetails?.locationCode ||
    readOrderResp?.cart?.orderDetails?.locationCode ||
    '';
  const salesRepIdVal =
    retrieveCart?.data?.data?.cart?.refundOrderDetails?.salesRepId ||
    readOrderResp?.cart?.orderDetails?.salesRepId ||
    '';
  const transactionDateVal = retrieveCart?.data?.data?.cart?.refundOrderDetails?.completeTimestamp
    ? // eslint-disable-next-line no-unsafe-optional-chaining
      formatDate((retrieveCart?.data?.data?.cart?.refundOrderDetails?.completeTimestamp).split('[US')[0])
    : '';
  const refundOrderNumberVal = readOrderResp?.cart?.orderDetails?.orderList[0]?.orderNumber || '';

  const originalOrderHasPlan = lineInfo?.[0]?.serviceInfo?.selectedALPShareList ?? false;
  const CustomerProfile = {
    data: {
      data: {
        customer: CustomerProfileResult?.data?.data?.customer,
      },
    },
  };
  const handleDPClose = () => {
    setDownPaymentModal(false);
  };

  const handleDPDone = () => {
    callReadOrder();
    setDownPaymentModal(false);
  };
  return (
    <div id='refund-read-order-main'>
      <Row>
        <Header
          title={isReadOrder ? '' : 'Review Order'}
          options={{
            subTitle: 'Original order',
            orderNumber: orderNumVal || '',
            locationCode: locationCodeVal || '',
            salesRepId: salesRepIdVal || '',
            transactionDate: transactionDateVal || '',
            orderStatus: orderStatusVal || '',
            refundOrderNumber: rfOrderNumber || refundOrderNumberVal || '',
          }}
          history={props.history}
          readOrder={cart}
          goBackPath={isReadOrder ? '/home.html' : '/transaction-selection.html'}
          menuBar={{ type: 'SECONDARY' }}
          hemburgerMenuPopup={hemburgerMenuPopup}
          isReadOrder={isReadOrder}
          isAccessoryFlow={isAccessoryFlow}
          hqUser={hqUser}
          fiveGHomeOrder={fiveGHomeOrder}
          completeOrderDetails={completeOrderDetails}
          rspFetchReadOrder={rspFetchReadOrder}
          intentType={getQueryParamByName('intentType')}
          isFWAFAEReviewOrder={getQueryParamByName('intentType') === '5GHomeRetailRFEX'}
          openExitModel={openExitModel}
          OpenViewTagging={OpenViewTagging}
          retrieveCart={retrieveCart?.data?.data?.cart}
          CustomerProfileResult={CustomerProfileResult}
        />
      </Row>
      <Grid bleed='1272' rowGutter='10px'>
        <StyledRow>
          <LeftCol
            colSizes={{
              desktop: 6,
            }}
          >
            <Body size='large' color='#000000' bold primitive='h2'>
              Return items
            </Body>
          </LeftCol>
          <RightCol
            colSizes={{
              desktop: 6,
            }}
          >
            <Body size='large' color='#000000' bold primitive='h2'>
              New items
            </Body>
          </RightCol>
        </StyledRow>
      </Grid>

      {viewPromoDiscount && (
        <ManualDiscountView
          cart={rspFetchReadOrder?.data?.data?.cart}
          handleClose={() => setViewPromoDiscount(false)}
          cartDetails={rspFetchReadOrder?.data?.data?.cart.cartHeader}
        />
      )}

      {downPaymentModal && (
        <DownPaymentViewModal
          handleDPClose={handleDPClose}
          CustomerProfileResult={CustomerProfile}
          activeMtn={retrieveCart?.data?.data?.cart?.lineDetails?.lineInfo[0]?.mtnDetails?.mobileNumber}
          setDownPayment={setDownpayment}
          downpayment={downpayment}
          handleDPDone={handleDPDone}
          cart={cart}
          fetchDownPaymentResult={fetchDownPaymentResult?.data?.fetchDownPaymentResponse?.filter(
            (i) => i.mtn === retrieveCart?.data?.data?.cart?.lineDetails?.lineInfo[0]?.mtnDetails?.mobileNumber,
          )}
        />
      )}

      {originalOrderHasPlan && (
        <AccountSectionDetails
          lineInfo={lineInfo}
          isPrePayCart={isPrePayCart}
          history={history}
          refundOrderDetails={refundOrderDetails}
          subAccountNBSInfo={subAccountNBSInfo}
        />
      )}

      <LineDetails
        appPropertiesFromSessionStorage={appPropertiesFromSessionStorage}
        lineInfo={lineInfo}
        history={history}
        customerProfile={customerProfile}
        isReadOrder
        refundOrderDetails={refundOrderDetails}
        cartOrderDetail={cartOrderDetail}
        subAccountNBSInfo={subAccountNBSInfo}
        cartType={cartType}
        isDfil={isDfil}
        cartId={cart?.cartHeader?.cartId}
        readOrderData={retrieveCartData}
      />
      {tradesection && <TradeInSection lineDetails={lineDetails} />}
      <TotalSummary
        originalLines={[]}
        lineDetails={lineDetails}
        lineInfo={lineInfo}
        refundOrderDetails={refundOrderDetails}
        cartOrderDetail={cartOrderDetail}
        cartId={cart?.cartHeader?.cartId}
        isDfill={isDfil}
        cartType={cartType}
        modeOfPay={cart?.lineDetails?.rfexPayments?.[0]?.modeOfPay || ''}
        rspFetchReadOrder={rspFetchReadOrder}
      />

      <Modal
        surface='light'
        disableAnimation={false}
        disableOutsideClick
        fullScreenDialog
        width='100%'
        ariaLabel='Mannual Charges Modal'
        opened={manualChargesModal}
        onOpenedChange={(opened) => !opened && setmanualChargesModal(false)}
        className='manualCharges-modal'
        closeButton={null}
      >
        <CommonHeader
          modelHeaderName={modelHeaderName}
          lineInfo={lineInfo}
          ModelName={MODEL_POPUP.MANUAL_CHARGES}
          closeModal={closeManualChargesModal}
          cartOrderHeader={rspFetchReadOrder?.data?.data?.cart?.cartHeader}
        />
      </Modal>

      <Modal
        surface='light'
        disableAnimation={false}
        disableOutsideClick
        fullScreenDialog
        width='100%'
        ariaLabel='Items at a glance Modal'
        opened={itemsGlanceModal}
        onOpenedChange={(opened) => !opened && setitemsGlanceModal(false)}
        className='itemsAtGlance-modal'
        closeButton={null}
      >
        <CommonHeader
          modelHeaderName={modelHeaderName}
          lineInfo={lineInfo}
          ModelName={MODEL_POPUP.ITEMS_AT_GLANCE}
          closeModal={closeItemsGlanceModal}
          refundOrderDetails={refundOrderDetails}
          lineDetails={lineDetails}
          hqUser={hqUser}
        />
      </Modal>

      {isPaymentHistory && (
        <PaymentHistoryModal
          data-testid='payment-history-modal'
          value={isPaymentHistory}
          handleToggle={handleTogglePaymentHistory}
          readOrderResponse={rspFetchReadOrder?.data?.data}
        />
      )}

      <FooterArea>
        <Padding36>{renderFooter()}</Padding36>
      </FooterArea>
      <ViewExitDialog
        orderNumber={rfOrderNumber}
        showCloseModal={showCloseModal}
        setShowCloseModal={setShowCloseModal}
        enableLead={enableLead}
        orderConfirmation={orderConfirmation}
        refundSrchOrder={refundSrchOrder}
        processStep='ShoppingCart'
      />
      {showAgreements && (
        <Agreements
          showAgreementModal={showAgreements}
          setShowAgreementModal={toggleAgreements}
          handleAgreementData={(data) => {
            setAgreementData(data);
            setshowAgreements(true);
          }}
          installmentAgreementResult={getRetrieveInstallmentAgreementResult?.data}
          agreementModalData={agreementData}
          channel={channel || ''}
          cartid={
            sessionStorage.getItem('acssMfeCartId') ||
            sessionStorage.getItem('cartId') ||
            customerProfile?.data?.customer?.cartId ||
            ''
          }
          accountnumber={
            `${retrieveCart?.data?.data?.cart?.refundOrderDetails?.accountNumber}-${retrieveCart?.data?.data?.cart?.refundOrderDetails?.accountSubNumber}` ||
            ''
          }
          isRxOrderReview
        />
      )}

      {showViewAndPrintReceipt && (
        <div data-testid='ViewPrintReceiept-modal'>
          <ViewOrderDocument
            value
            readorder={isReadOrder}
            data={retrieveCart?.data}
            readOrderData={readOrderResp}
            orderNo={rfOrderNumber}
            customerInfo={props?.advExchangeCartDetails?.customerInfo}
            customerProfile={customerProfile}
            locationCode={locationCode}
            tradeInDetail={cartOrderDetail?.lineDetails?.tradeInItems}
            cartDetails={cart}
            isRefundReadOrder
            setshowViewAndPrintReceipt={setshowViewAndPrintReceipt}
          />
        </div>
      )}
    </div>
  );
}

const LeftCol = styled(Col)`
  margin: 0px !important;
  border-right: 1px solid #000 !important;
  font-size: 20px !important;
  padding: 0.875rem 0px !important;
  font-family: BrandFontBold, Sans-serif !important;
  font-weight: 700 !important;
`;

const RightCol = styled(Col)`
  margin: 0px !important;
  font-size: 20px !important;
  padding-right: 0.875rem !important;
  padding-top: 0.875rem !important;
  padding-bottom: 0.875rem !important;
  font-family: BrandFontBold, Sans-serif !important;
  font-weight: 700 !important;
`;

const StyledRow = styled(Row)`
  border-bottom: 1px solid #000 !important;
`;

Refund.propTypes = {
  orderNumber: PropTypes.string,
  locationCode: PropTypes.string,
  isReadOrder: PropTypes.bool,
  history: PropTypes.object,
  customer: PropTypes.object,
  assistedRfexflags: PropTypes.object,
  advExchangeCartDetails: PropTypes.object,
  isBlindFlow: PropTypes.bool,
  skipAddressVerification: PropTypes.bool,
  isCurrentAddress: PropTypes.bool,
  skipAddressValidationForGuestCheckout: PropTypes.bool,
};
export default Refund;
