import React from 'react';
import { render } from '@testing-library/react';
import Affirm from './Affirm';

describe('Affirmcunit testing', () => {
  const script = document.createElement('script');
  document.body.appendChild(script);
  test('render component', () => {
    render(<Affirm />);
  });
  test('render component', () => {
    sessionStorage.setItem('isProd', 'true');
    render(<Affirm />);
  });
});
