/* eslint-disable */
import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import Emitter from 'onevzsoemfeframework/Emitter';
import { injectAPI } from 'onevzsoemfeframework/APIService';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import AccessoriesCheckoutDetails from './AccessoriesCheckoutDetails';
import StoreProvider from '../../modules/store';
import cartJson from '../../__mock__/retrive-cart.json';
import cartDetails from './__mock__/cartDetails.json';
import getClickToCallDetailsJson from '../../__mock__/getClickToCallDetails.json';
import * as clickToCallAPICallHook from '../../modules/services/APIService/ClickToCallAPICallHook';
import * as GetAccessApiCallHook from '../../modules/services/APIService/GetAccessAPICallHook';
import { getSetupAndGoCart } from '../../__mock__/setup-go-cart';
import scheduleAppointmentJson from './__mock__/scheduleAppointment.json';
import * as InfoApiCallHook from '../../modules/services/APIService/InfoAPICallHook';
import { updateOneUINbsRespSuccess } from './store/actions';

const showRepGuidedScreen = false;

jest.mock('./ViewOrderDocument/ViewOrderDocument', () => () => (
  <div data-testid='mock-ViewOrderDocument'>
    Mocked ViewOrderDocument Component
    <div>value:{true} </div>
    <div>readorder:{true} </div>
    <div>orderNo:{12345}</div>
  </div>
));
jest.mock('onevzsoemfecommon/ViewAddRemark', () => ({
  __esModule: true,
  default: ({ handleBack, handleClose }) => (
    <div>
      <button type='button' data-testid='manager-approval-view-back' onClick={handleBack}>
        back
      </button>
      <button type='button' data-testid='manager-approval-view-close' onClick={handleClose}>
        close
      </button>
    </div>
  ),
  virtual: true,
}));

jest.mock('onevzsoemfecommon/Helpers', () => ({
  ...jest.requireActual('onevzsoemfecommon/Helpers'),
  getQueryParamByName: jest.fn(),
}));

jest.mock('onevzsoemfeframework/AssistedCradleService', () => ({
  __esModule: true,
  ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
  getAssistedCradlePropertyV2: jest.fn(), // Ensure it's a Jest mock function
}));

jest.mock('../../modules/services/APIService/APIServiceCallHook', () => {
  const actualModule = jest.requireActual('../../modules/services/APIService/APIServiceCallHook');
  return {
    ...actualModule,
    useLazySendSecurePaymentEmailQuery: () => [
      jest.fn().mockImplementation(() =>
        Promise.resolve({
          data: {
            data: {
              emailId: 'test@test.com',
            },
          },
        }),
      ),
      {
        status: 'fulfilled',
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: false,
        isFetching: false,
        data: {
          data: {
            emailId: 'test@test.com',
          },
        },
      },
    ],
    useLazySaveUserInfoQuery: () => [
      jest.fn(),
      {
        isLoading: false,
        isSuccess: true,
        data: {},
      },
    ],
    useLazyGetCartDetailsQuery: () => [
      jest.fn(),
      {
        isLoading: false,
        isSuccess: true,
        data: {},
      },
    ],
    useLazyFetchPricingSnapQuery: () => [
      jest.fn(),
      {
        isLoading: false,
        isSuccess: true,
        data: {},
      },
    ],
    useLazyGetAllActiveMtnQuery: () => [
      jest.fn(),
      {
        isLoading: false,
        isSuccess: true,
        data: {},
      },
    ],
    useLazyUpdateVisionRemarkQuery: () => [
      jest.fn(),
      {
        isLoading: false,
        isSuccess: true,
        data: {},
      },
    ],
    useLazyReadOrderRetrieveInstallmentAgreementQuery: () => [
      jest.fn(),
      {
        isLoading: false,
        isSuccess: true,
        data: {},
      },
    ],
    useLazyViewOrPrintEdgeUpReturnLabelQuery: () => [
      jest.fn(),
      {
        isLoading: false,
        isSuccess: true,
        data: {},
      },
    ],
    useLazyReadOrderDocumentsInfoQuery: () => [
      jest.fn(),
      {
        isLoading: false,
        isSuccess: true,
        data: {},
      },
    ],
    useLazyGetNextBillSummaryQuery: () => [
      jest.fn(),
      {
        isLoading: false,
        isSuccess: true,
        data: {},
      },
    ],
    useLazyGetRetrievePaymentOptionsQuery: () => [
      jest.fn(),
      {
        isLoading: false,
        isSuccess: true,
        data: {},
      },
    ],
    useLazyGetTrackShipmentQuery: () => [
      jest.fn(),
      {
        isLoading: false,
        isSuccess: true,
        data: {},
      },
    ],
    useLazyInitiateClickToCallQuery: () => [
      jest.fn(),
      {
        isLoading: false,
        isSuccess: true,
        data: {},
      },
    ],
  };
});

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  useLazyGenerateInspicioIdQuery: () => [
    jest.fn().mockResolvedValue({ data: { inspicioId: 'test-id' } }),
    {
      data: { inspicioId: 'test-id' },
      isLoading: false,
      error: null,
      isSuccess: true,
      status: 'fulfilled',
    },
  ],
  useLazySendEmailQuery: () => [
    jest.fn().mockResolvedValue({ data: { success: true } }),
    {
      data: { success: true },
      isLoading: false,
      error: null,
      isSuccess: true,
      status: 'fulfilled',
    },
  ],
  useLazySendLovLinkQuery: () => [
    jest.fn().mockResolvedValue({ data: { success: true } }),
    {
      data: { success: true },
      isLoading: false,
      error: null,
      isSuccess: true,
      status: 'fulfilled',
    },
  ],
  useLazySendMessageQuery: () => [
    jest.fn().mockResolvedValue({ data: { success: true } }),
    {
      data: { success: true },
      isLoading: false,
      error: null,
      isSuccess: true,
      status: 'fulfilled',
    },
  ],
  useLazyGeneratePaxQRCodeQuery: () => [
    jest.fn().mockResolvedValue({ data: { qrCode: 'test-qr' } }),
    {
      data: { qrCode: 'test-qr' },
      isLoading: false,
      error: null,
      isSuccess: true,
      status: 'fulfilled',
    },
  ],
  useLazyReceiveMessageQuery: () => [
    jest.fn().mockResolvedValue({ data: { message: 'test-message' } }),
    {
      data: { message: 'test-message' },
      isLoading: false,
      error: null,
      isSuccess: true,
      status: 'fulfilled',
    },
  ],
  useLazyUpdateAffirmPaymentQuery: () => [
    jest.fn().mockResolvedValue({ data: { success: true } }),
    {
      data: { success: true },
      isLoading: false,
      error: null,
      isSuccess: true,
      status: 'fulfilled',
    },
  ],
  useLazySendSecurePaymentEmailQuery: () => [
    jest.fn().mockResolvedValue({
      data: {
        data: {
          emailId: 'test@test.com',
        },
      },
    }),
    {
      data: {
        data: {
          emailId: 'test@test.com',
        },
      },
      isLoading: false,
      error: null,
      isSuccess: true,
      status: 'fulfilled',
      isUninitialized: false,
      isError: false,
      isFetching: false,
    },
  ],
  useLazyNextbillestimateQuery: () => [
    jest.fn(),
    {
      isLoading: false,
      isSuccess: true,
      data: {},
    },
  ],
}));

jest.mock('../../modules/services/APIService/ViewTogetherApiCallHook', () => ({
  __esModule: true,
  default: () => ({
    requestBodyGenerateInspicioId: jest.fn().mockResolvedValue({ data: { inspicioId: 'test-id' } }),
    getResultGenerateInspicioId: {
      data: { inspicioId: 'test-id' },
      isLoading: false,
      error: null,
      isSuccess: true,
      status: 'fulfilled',
    },
    requestBodySendMessage: jest.fn().mockResolvedValue({ data: { success: true } }),
    getResultSendMessage: {
      data: { success: true },
      isLoading: false,
      error: null,
      isSuccess: true,
      status: 'fulfilled',
    },
    requestBodySendLovLink: jest.fn().mockResolvedValue({ data: { success: true } }),
    getResultSendLovLink: {
      data: { success: true },
      isLoading: false,
      error: null,
      isSuccess: true,
      status: 'fulfilled',
    },
    requestBodySendEmail: jest.fn().mockResolvedValue({ data: { success: true } }),
    getResultSendEmail: {
      data: { success: true },
      isLoading: false,
      error: null,
      isSuccess: true,
      status: 'fulfilled',
    },
    requestBodyGeneratePaxQRCode: jest.fn().mockResolvedValue({ data: { qrCode: 'test-qr' } }),
    getResultGeneratePaxQRCode: {
      data: { qrCode: 'test-qr' },
      isLoading: false,
      error: null,
      isSuccess: true,
      status: 'fulfilled',
    },
    receiveMessage: jest.fn().mockResolvedValue({ data: { message: 'test-message' } }),
    receiveMessageResult: {
      data: { message: 'test-message' },
      isLoading: false,
      error: null,
      isSuccess: true,
      status: 'fulfilled',
    },
    updateAffirm: jest.fn().mockResolvedValue({ data: { success: true } }),
    updateAffirmResult: {
      data: { success: true },
      isLoading: false,
      error: null,
      isSuccess: true,
      status: 'fulfilled',
    },
  }),
}));

// Mock for API Service functions used in other components
jest.mock('onevzsoemfeframework/APIService', () => ({
  injectAPI: jest.fn(() => ({
    useGetCartDetailsQuery: jest.fn(() => ({
      data: { mockData: 'mockDataValue' },
      isLoading: false,
      isSuccess: true,
      isError: false,
      error: null,
    })),
    useLazyGetCartDetailsQuery: jest.fn(() => [
      jest.fn(),
      {
        data: { mockData: 'mockDataValue' },
        isLoading: false,
        isSuccess: true,
        isError: false,
        error: null,
      },
    ]),
    useLazyNextbillestimateQuery: jest.fn(() => [
      jest.fn(),
      {
        data: { mockData: 'mockDataValue' },
        isLoading: false,
        isSuccess: true,
        isError: false,
        error: null,
      },
    ]),
    useGetCustomerProfileQuery: jest.fn(() => ({
      data: { mockData: 'mockDataValue' },
      isLoading: false,
      isSuccess: true,
      isError: false,
      error: null,
    })),
    useLazyGetRetrievePaymentOptionsQuery: jest.fn(() => [
      jest.fn(),
      {
        data: { mockData: 'mockDataValue' },
        isLoading: false,
        isSuccess: true,
        isError: false,
        error: null,
      },
    ]),
    useLazyGetTrackShipmentQuery: jest.fn(() => [
      jest.fn(),
      {
        data: { mockData: 'mockDataValue' },
        isLoading: false,
        isSuccess: true,
        isError: false,
        error: null,
      },
    ]),
    useLazyInitiateClickToCallQuery: jest.fn(() => [
      jest.fn(),
      {
        data: { mockData: 'mockDataValue' },
        isLoading: false,
        isSuccess: true,
        isError: false,
        error: null,
      },
    ]),
  })),
}));

jest.mock('./ScheduleAppointment', () => ({
  __esModule: true,
  default: ({ closeAppointment }) => (
    <div>
      <button type='button' data-testid='mocked-schedule-appointment' onClick={closeAppointment}>
        Schedule Appointment Component Mock
      </button>
    </div>
  ),
}));

jest.mock('../../utils/tagging');

jest.mock('onevzsoemfeframework/APIService', () => {
  const mockReducerPath = 'APIService';
  const mockMiddleware = jest.fn();

  return {
    baseAPIService: {
      middleware: mockMiddleware,
      reducerPath: mockReducerPath,
    },
    injectAPI: jest.fn(() => ({
      useGetCartDetailsQuery: jest.fn(() => [
        jest.fn(),
        {
          isLoading: false,
          isSuccess: true,
          isError: false,
          data: { mockData: 'test' },
        },
      ]),
      useLazyGetCartDetailsQuery: jest.fn(() => [
        jest.fn(),
        {
          isLoading: false,
          isSuccess: true,
          isError: false,
          data: { mockData: 'test' },
        },
      ]),
      // Add other API hooks that might be used
      endpoints: {},
      reducer: jest.fn(),
      reducerPath: mockReducerPath,
      middleware: mockMiddleware,
    })),
  };
});

describe('Accessories Checkout Details Component', () => {
  const mockSaveOrder = jest.fn();
  const mockAddAccessories = jest.fn();
  const mockGetCustomer = jest.fn();

  const mockReadOrderResponse = {
    orderStatus: 'CR',
    cart: {
      cartHeader: {
        status: 'S',
        fullAccountNumber: '0486957317-1',
      },
      orderDetails: {
        orderList: [{ orderNumber: '20331588' }, { orderNumber: '20331589' }],
      },
    },
    lovIndicator: 'YY',
  };

  const inStorePickupProps = {
    setSelectedReviewMode: jest.fn(),
    setSelectedReason: jest.fn(),
    readOrderResponse: mockReadOrderResponse, // added for common testing
  };
  const mockData = {
    getClickToCallDetailsRequest: mockSaveOrder,
    getClickToCallDetailsResult: { data: getClickToCallDetailsJson },
    requestBodySendMessage: jest.fn(),
  };

  const mockAddAccessoriesData = {
    addAccessories: mockAddAccessories,
    addAccessoriesSuccess: { data: true },
    getCustomerByMtn: mockGetCustomer,
  };

  const mockAddAppMessage = jest.fn();
  const mockClearAppMessage = jest.fn();

  jest.mock('onevzsoemfecommon/AppMessageActions', () => ({
    addAppMessage: mockAddAppMessage,
    clearAppMessages: mockClearAppMessage,
  }));

  beforeEach(() => {
    window.mfe = { scmDeviceMfeEnable: true, scmCheckoutMfeEnable: true, scmUpgradeMfeEnable: true };
    window.mfe.historyRef = jest.fn();
    window.mfe.historyRef.push = jest.fn();
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({ enablePartialNbsPosFFlag: 'TRUE', vtNbsMfeFFlag: 'TRUE' }),
    );
    getQueryParamByName.mockReturnValue('false');
  });

  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
    window.mfe = { scmCheckoutMfeEnable: true };
  });
  test('renders AccessoriesCheckoutDetails', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByText(/Accessories /i);
    expect(titleElement).toBeInTheDocument();
  });

  test('renders AccessoriesCheckoutDetails with getCartDetailsResults prop', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);

    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            getCartDetailsResults={cartDetails}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByText(/Accessories /i);
    expect(titleElement).toBeInTheDocument();
  });

  test('Should open ModalSideNav once user click on icon', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const ModalSideNav = screen.getByTestId('ModalSideNav');
    expect(ModalSideNav).toBeInTheDocument();
  });

  test('Should open Glance Modal once user click of View items at a glance', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('glance');
    fireEvent.click(title);
    const modal = screen.getByTestId('glance-modal');
    expect(modal).toBeInTheDocument();
    expect(window.vzdl.page.detail).toEqual('Items At A Glance');
  });

  test('Should trigger click of credit Status link', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']); // Override mock
    window.mfe = { scmUpgradeMfeEnable: true };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const menu = screen.getByTestId('three-dot-menu');
    fireEvent.click(menu);
    const title = screen.getByTestId('creditApproval');
    expect(title).toBeInTheDocument();
    fireEvent.click(title);
  });

  test('dont render Apply Mobile and Manage client account if scmUpgradeMfe flag is true', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: true };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const backdrop = screen.getByTestId('back-drop');
    const element = screen.queryByText('Apply Mobile');
    expect(element).toBeNull();
    const element2 = screen.queryByText('Manage client account');
    expect(element2).toBeNull();
  });

  test('Should open Collateral Modal once user click of View collateral', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('collateral');
    fireEvent.click(title);
    const modal = screen.getByTestId('collateral-modal');
    expect(modal).toBeInTheDocument();
    expect(window.vzdl.page.detail).toEqual('Collateral');
  });

  test('Should close glance modal on click of X button', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('glance');
    fireEvent.click(title);
    const closeButton = screen.getByTestId('close-button');
    fireEvent.click(closeButton);
    const modal = screen.queryByTestId('glance-modal');
    expect(modal).toBeNull();
    expect(window.vzdl.page.detail).toEqual('');
  });

  test('Should close collateral modal on click of X button', () => {
    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('collateral');
    fireEvent.click(title);
    const closeButton = screen.getByTestId('close-button');
    fireEvent.click(closeButton);
    const modal = screen.queryByTestId('collateral-modal');
    expect(modal).toBeNull();
    expect(window.vzdl.page.detail).toEqual('');
  });

  test('Should have edit & delete accessories link', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ quickAccessoryCheckoutTaggingFFlag: 'TRUE'}));
    sessionStorage.setItem('leadsUserRole', "REP");

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            isQAFlow={true}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    await waitFor(() => {
      const deleteLink = screen.getByTestId('delete-accessories-link');
      expect(deleteLink).toBeInTheDocument();
      const editLink = screen.getByTestId('edit-accessories-link');
      expect(editLink).toBeInTheDocument();
    });
  });

  test('Should open edit  modal on click edit accessories link', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ quickAccessoryCheckoutTaggingFFlag: 'TRUE'}));
    sessionStorage.removeItem('leadsUserRole');

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            isQAFlow={true}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    await waitFor(() => {
      const editLink = screen.getByTestId('edit-accessories-link');
      expect(editLink).toBeInTheDocument();
      fireEvent.click(editLink);
      setTimeout(() => {
        expect(screen.getByTestId('edit-accessories-title')).toBeInTheDocument();
      }, 3000);
    });
  });

  test('Should open edit  modal on click of accessories image', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    await waitFor(() => {
      const editLink = screen.getByTestId('edit-accessories-image-0');
      expect(editLink).toBeInTheDocument();
      fireEvent.click(editLink);
      setTimeout(() => {
        expect(screen.getByTestId('edit-accessories-title')).toBeInTheDocument();
      }, 3000);
      expect(window.vzdl.page.detail).toEqual('Accessories');
    });
  });

  it('Should delete function on click delete accessories link', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    await waitFor(() => {
      const deleteLink = screen.getByTestId('delete-accessories-link');
      expect(deleteLink).toBeInTheDocument();
      fireEvent.click(deleteLink);
      setTimeout(() => {
        expect(screen.getByTestId('accessories-title')).not.toBeInTheDocument();
      }, 2000);
    });
  });

  it('Should delete function on click delete accessories link ACSS', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    await waitFor(() => {
      const deleteLink = screen.getByTestId('delete-accessories-link');
      expect(deleteLink).toBeInTheDocument();
      fireEvent.click(deleteLink);
      Emitter.emit('ADD_SELECTED_DEVICE_TO_CART', {});
      setTimeout(() => {
        expect(screen.getByTestId('accessories-title')).not.toBeInTheDocument();
      }, 3000);
    });
  });

  it('Should render setup and go', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={getSetupAndGoCart(0, 'ACC')}
            customerInfo={{
              customerName: {
                firstName: 'Firstname',
                preferPronoun: 'pronoun name',
              },
            }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    expect(screen.getByText(/Setup & Go Service Charge/i)).toBeInTheDocument();
    expect(screen.getByText(/0.00/i)).toBeInTheDocument();
    expect(screen.getByText(/firstname/i)).toBeInTheDocument();
  });

  it('Should render setup and go with discount price', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails {...inStorePickupProps} data={getSetupAndGoCart(159.88, 'ACC')} />
        </StoreProvider>
      </BrowserRouter>,
    );
    expect(screen.getByText(/159.88/i)).toBeInTheDocument();
  });

  it('schedule appointment details and click on link', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails {...inStorePickupProps} data={scheduleAppointmentJson} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const scheduleAppointmentLink = screen.getByTestId('schedule-appointment');
    expect(scheduleAppointmentLink).toBeInTheDocument();
    fireEvent.click(scheduleAppointmentLink);

    const mockComp = screen.getByTestId('mocked-schedule-appointment');
    expect(mockComp).toBeInTheDocument();
    fireEvent.click(mockComp);
  });

  it('isDark true', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails {...inStorePickupProps} data={scheduleAppointmentJson} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const scheduleAppointmentLink = screen.getByTestId('schedule-appointment');
    expect(scheduleAppointmentLink).toBeInTheDocument();
    fireEvent.click(scheduleAppointmentLink);
  });

  it('should render <OrderSummaryLine />', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails {...inStorePickupProps} data={scheduleAppointmentJson} />
        </StoreProvider>
      </BrowserRouter>,
    );
    const orderSummary = screen.getByTestId('order-summary-line');
    expect(orderSummary).toBeInTheDocument();
    expect(orderSummary).toHaveTextContent('Order number: 20331588/20331589');
    expect(orderSummary).toHaveTextContent(`Order Status: CR`);
    expect(orderSummary).toHaveTextContent(`Acc number: 0486957317`);
  });

  it('Should delete function on click delete accessories link1', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    window.mfe = { scmCheckoutMfeEnable: false };
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    await waitFor(() => {
      const deleteLink = screen.getByTestId('delete-accessories-link');
      expect(deleteLink).toBeInTheDocument();
      fireEvent.click(deleteLink);
      setTimeout(() => {
        expect(screen.getByTestId('accessories-title')).not.toBeInTheDocument();
      }, 2000);
    });
  });
  test('Should open edit  modal on click edit accessories link', async () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock
    let cartMockData = cartJson;
    cartMockData.data.cart.lineDetails.lineInfo[0].itemsInfo[0].cartItems.cartItem[0].prodCode2 = 'GIF';
    cartMockData.data.cart.lineDetails.lineInfo[0].itemsInfo[0].cartItems.cartItem[0].deviceDisplayName = '';
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartMockData}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    await waitFor(() => {
      const editLink = screen.getByTestId('edit-accessories-link');
      expect(editLink).toBeInTheDocument();
      fireEvent.click(editLink);
      setTimeout(() => {
        expect(screen.getByTestId('edit-accessories-title')).toBeInTheDocument();
      }, 3000);
    });
  });
});

describe('Accessories Read Order Component', () => {
  const mockSaveOrder = jest.fn();
  const mockAddAccessories = jest.fn();
  const mockGetCustomer = jest.fn();
  const inStorePickupProps = {
    setSelectedReviewMode: jest.fn(),
    setSelectedReason: jest.fn(),
  };
  const mockData = {
    getClickToCallDetailsRequest: mockSaveOrder,
    getClickToCallDetailsResult: { data: getClickToCallDetailsJson },
  };

  const mockAddAccessoriesData = {
    addAccessories: mockAddAccessories,
    addAccessoriesSuccess: { data: true },
    getCustomerByMtn: mockGetCustomer,
  };

  const mockAddAppMessage = jest.fn();
  const mockClearAppMessage = jest.fn();

  jest.mock('onevzsoemfecommon/AppMessageActions', () => ({
    addAppMessage: mockAddAppMessage,
    clearAppMessages: mockClearAppMessage,
  }));

  beforeEach(() => {
    window.mfe = { scmDeviceMfeEnable: true, scmCheckoutMfeEnable: true };
    window.mfe.historyRef = jest.fn();
    window.mfe.historyRef.push = jest.fn();
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({ enablePartialNbsPosFFlag: 'FALSE', vtNbsMfeFFlag: 'TRUE' }),
    );
    getQueryParamByName.mockReturnValue('false');
  });

  test('renders AccessoriesCheckoutDetails', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    const appointmentMockCartJson = {
      data: {
        data: {
          cart: {
            cartHeader: {
              cartCreator: 'creator',
              caseId: 'caseId',
            },
            orderDetails: {
              customerType: 'N',
              spocs: { notificationOptions: { primaryEmailId: 'email@domain.com' } },
              orderList: [{ creditApplication: { creditApplicationNum: '12345' }, orderNumber: '20331589' }],
            },
            lineDetails: {
              lineInfo: [
                {
                  serviceInfo: {
                    cart5GAppointment: {
                      customerInstructions: '',
                      emailAddress: 'SENTHIL.KUMAR.BHOOPALAN@ONE.VERIZON.COM',
                      eventCorrelationId: '60611_1737642957399_182',
                      firstName: 'BRIAN',
                      homePhone: '9089349238',
                      installApptSelectedDate: {
                        availableDate: '20250201',
                        availableDay: '6',
                        availableType: '0',
                        serviceProviderAccount: '1115183',
                        serviceProviderName: 'ASURION INSTALLER',
                        slotLength: '2',
                        slotStartTime: '0800',
                      },
                      lastName: 'WRIGHT',
                      preferredContactType: 'Email',
                      primaryPhoneType: 'Home',
                    },
                  },
                },
              ],
              tradeInDetail: { tradeInItems: [{ id: 'tradeInItem' }] },
            },
            quote: { quoteId: 'quoteId' },
          },
        },
      },
    };

    const mockInfoApiData = {
      getCartRequest: jest.fn(),
      getCartResponse: appointmentMockCartJson,
      submitUserInfo: jest.fn(),

      fetchPricingSnapRequest: jest.fn(),
      getActiveMTNRequest: jest.fn(),
      orderReviewRequest: jest.fn(),
    };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByText(/Accessories /i);
    expect(titleElement).toBeInTheDocument();
  });
});

describe('Accessories Read Order Component', () => {
  const mockSaveOrder = jest.fn();
  const mockAddAccessories = jest.fn();
  const mockGetCustomer = jest.fn();

  const mockReadOrderResponse = {
    orderStatus: 'CR',
    cart: {
      cartHeader: {
        status: 'S',
        fullAccountNumber: '0486957317-1',
      },
      orderDetails: {
        orderList: [{ orderNumber: '20331588' }, { orderNumber: '20331589' }],
      },
    },
    lovIndicator: 'YY',
  };

  const inStorePickupProps = {
    setSelectedReviewMode: jest.fn(),
    setSelectedReason: jest.fn(),
    readOrderResponse: mockReadOrderResponse, // added for common testing
  };
  const mockData = {
    getClickToCallDetailsRequest: mockSaveOrder,
    getClickToCallDetailsResult: { data: getClickToCallDetailsJson },
  };

  const mockAddAccessoriesData = {
    addAccessories: mockAddAccessories,
    addAccessoriesSuccess: { data: true },
    getCustomerByMtn: mockGetCustomer,
  };

  const mockAddAppMessage = jest.fn();
  const mockClearAppMessage = jest.fn();

  jest.mock('onevzsoemfecommon/AppMessageActions', () => ({
    addAppMessage: mockAddAppMessage,
    clearAppMessages: mockClearAppMessage,
  }));

  beforeEach(() => {
    window.mfe = { scmDeviceMfeEnable: true, scmCheckoutMfeEnable: true, scmUpgradeMfeEnable: true };
    window.mfe.historyRef = jest.fn();
    window.mfe.historyRef.push = jest.fn();
    const appointmentMockCartJson = {
      data: {
        data: {
          cart: {
            cartHeader: {
              cartCreator: 'creator',
              caseId: 'caseId',
            },
            orderDetails: {
              customerType: 'N',
              spocs: { notificationOptions: { primaryEmailId: 'email@domain.com' } },
              orderList: [{ creditApplication: { creditApplicationNum: '12345' }, orderNumber: '20331589' }],
            },
            lineDetails: {
              lineInfo: [
                {
                  serviceInfo: {
                    cart5GAppointment: {
                      customerInstructions: '',
                      emailAddress: 'SENTHIL.KUMAR.BHOOPALAN@ONE.VERIZON.COM',
                      eventCorrelationId: '60611_1737642957399_182',
                      firstName: 'BRIAN',
                      homePhone: '9089349238',
                      installApptSelectedDate: {
                        availableDate: '20250201',
                        availableDay: '6',
                        availableType: '0',
                        serviceProviderAccount: '1115183',
                        serviceProviderName: 'ASURION INSTALLER',
                        slotLength: '2',
                        slotStartTime: '0800',
                      },
                      lastName: 'WRIGHT',
                      preferredContactType: 'Email',
                      primaryPhoneType: 'Home',
                    },
                  },
                },
              ],
              tradeInDetail: { tradeInItems: [{ id: 'tradeInItem' }] },
            },
            quote: { quoteId: 'quoteId' },
          },
        },
      },
    };

    const mockInfoApiData = {
      getCartRequest: jest.fn(),
      getCartResponse: appointmentMockCartJson,
      submitUserInfo: jest.fn(),

      fetchPricingSnapRequest: jest.fn(),
      getActiveMTNRequest: jest.fn(),
      orderReviewRequest: jest.fn(),
    };
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ quickAccessoryCheckoutTaggingFFlag: 'TRUE'}));
    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => mockInfoApiData);
    getQueryParamByName.mockReturnValue('false');
  });

  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  // new iteam added for read-Order
  test('Should open devicePayment Modal once user click of devicePayment', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            lines={cartJson.data.cart.lineDetails.lineInfo}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            readOrderResponse={{ orderStatus: 'CO' }}
            isQAFlow={true}
            isFromReadOrder
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('devicePayment');
    fireEvent.click(title);

    // lines added to check the functionality of handleToggle
    const modal = screen.getByTestId('devicePayment-modal');
    expect(modal).toBeInTheDocument();
    const closeButton = screen.getByTestId('Agreement Status Close Modal');
    fireEvent.click(closeButton);
    // fireEvent.click(screen.getByTestId('viewadd-accessories-link'));
    expect(screen.queryByTestId('devicePayment-modal')).toBeNull();
  });

  test('Should open devicePayment Modal once user click of devicePayment', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            lines={cartJson.data.cart.lineDetails.lineInfo}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            readOrderResponse={{ orderStatus: 'CR' }}
            isFromReadOrder
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    fireEvent.click(screen.getByTestId('viewadd-accessories-link'));
  });

  test('Should open devicePayment Modal once user click of devicePayment', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            lines={cartJson.data.cart.lineDetails.lineInfo}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            readOrderResponse={{ orderStatus: 'CR' }}
            isFromReadOrder
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    fireEvent.click(screen.getByTestId('viewadd-accessories-link'));
  });

  test('Should open remarks Modal once user click of remarks', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            isFromReadOrder
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('remarks');
    fireEvent.click(title);
  });
  test('Should open glance Modal once user click of glance', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            isFromReadOrder
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('glance');
    fireEvent.click(title);
  });
  test('Should open collateral Modal once user click of collateral', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            isFromReadOrder
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('collateral');
    fireEvent.click(title);
  });
  test('Should open printreceipt Modal once user click of printreceipt', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);

    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    window.mfe = { scmUpgradeMfeEnable: false };
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            isFromReadOrder
            customerInfo={{ billAccounts: [{ billAccountNo: '1' }], billingSystem: 'VZB', loggedInUser: 'machakr' }}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('printreceipt');
    fireEvent.click(title);
    waitFor(() => {
      // const title1 = screen.getByTestId('ViewPrintReceiept');
      // fireEvent.click(title1);
      const ViewPrintReceieptModal = screen.getByTestId('ViewPrintReceiept-modal');
      expect(ViewPrintReceieptModal).toBeInTheDocument();
    });
  });

  // test('Should open CreditStatus Modal once user click of CreditStatus', () => {
  //   getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock
  //   jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
  //   jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
  //   sessionStorage.setItem('readOrder', true);
  //   sessionStorage.setItem('channel', 'OMNI-RETAIL');
  //   render(
  //     <BrowserRouter>
  //       <StoreProvider>
  //         <AccessoriesCheckoutDetails
  //           {...inStorePickupProps}
  //           data={cartJson}
  //           showRepGuidedScreen={showRepGuidedScreen}
  //           showAffirmAccordion={false}
  //           isFromReadOrder
  //         />
  //       </StoreProvider>
  //     </BrowserRouter>,
  //   );
  //   global.window.vzdl = { page: { detail: '' } };
  //   const backdrop = screen.getAllByTestId('hamburger-icon')[0];
  //   fireEvent.click(backdrop);
  //   const title = screen.getByTestId('CreditStatus');
  //   fireEvent.click(title);
  // });

  test('Should open trackit Modal once user click of trackit', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ isTrackItEnabled: 'TRUE', vtNbsMfeFFlag: 'TRUE' }));
    window.mfe = { scmDeviceMfeEnable: true, scmCheckoutMfeEnable: true, isDark: true, scmUpgradeMfeEnable: false };
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            isFromReadOrder
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('trackit');
    fireEvent.click(title);
  });

  test('Should open resend paymenmt Modal once user click of resend payment link', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ isTrackItEnabled: 'TRUE', vtNbsMfeFFlag: 'TRUE' }));
    window.mfe = { scmDeviceMfeEnable: true, scmCheckoutMfeEnable: true, isDark: true, scmUpgradeMfeEnable: false };
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...{
              ...inStorePickupProps,
              readOrderResponse: {
                securePaymentOrderDetails: [
                  {
                    orderNumber: '12345',
                    paymentMethod: 'Credit Card',
                    amount: 100.0,
                    currency: 'USD',
                    isSecure: true,
                  },
                  {
                    orderNumber: '67890',
                    paymentMethod: 'PayPal',
                    amount: 50.0,
                    currency: 'USD',
                    isSecure: true,
                  },
                ],
                orderStatus: 'CR',
              },
            }}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            isFromReadOrder
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('resendPaymentLink');
    fireEvent.click(title);
  });

  test('renders AccessoriesCheckoutDetails with getCartDetailsResults prop', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);

    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            getCartDetailsResults={cartDetails}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByText(/Accessories /i);
    expect(titleElement).toBeInTheDocument();
  });

  test('Should open View add remark Modal once user click of View/add remark', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    window.mfe = { scmUpgradeMfeEnable: false };
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('remarks');
    fireEvent.click(title);
    const modal = screen.getByTestId('viewAddRemarks-modal');
    expect(modal).toBeInTheDocument();
  });
});

describe('Accessories Read Order Component', () => {
  const mockSaveOrder = jest.fn();
  const mockAddAccessories = jest.fn();
  const mockGetCustomer = jest.fn();

  const mockReadOrderResponse = {
    orderStatus: 'CR',
    cart: {
      cartHeader: {
        status: 'S',
        fullAccountNumber: '0486957317-1',
      },
      orderDetails: {
        orderList: [{ orderNumber: '20331588' }, { orderNumber: '20331589' }],
      },
    },
    lovIndicator: 'YY',
  };

  const inStorePickupProps = {
    setSelectedReviewMode: jest.fn(),
    setSelectedReason: jest.fn(),
    readOrderResponse: mockReadOrderResponse, // added for common testing
  };
  const mockData = {
    getClickToCallDetailsRequest: mockSaveOrder,
    getClickToCallDetailsResult: { data: getClickToCallDetailsJson },
  };

  const mockAddAccessoriesData = {
    addAccessories: mockAddAccessories,
    addAccessoriesSuccess: { data: true },
    getCustomerByMtn: mockGetCustomer,
  };

  const mockAddAppMessage = jest.fn();
  const mockClearAppMessage = jest.fn();

  jest.mock('onevzsoemfecommon/AppMessageActions', () => ({
    addAppMessage: mockAddAppMessage,
    clearAppMessages: mockClearAppMessage,
  }));

  beforeEach(() => {
    window.mfe = { scmDeviceMfeEnable: true, scmCheckoutMfeEnable: true, scmUpgradeMfeEnable: true };
    window.mfe.historyRef = jest.fn();
    window.mfe.historyRef.push = jest.fn();
    const appointmentMockCartJson = {
      data: {
        data: {
          cart: {
            cartHeader: {
              cartCreator: 'creator',
              caseId: 'caseId',
            },
            orderDetails: {
              customerType: 'N',
              spocs: { notificationOptions: { primaryEmailId: 'email@domain.com' } },
              orderList: [{ creditApplication: { creditApplicationNum: '12345' }, orderNumber: '20331589' }],
            },
            lineDetails: {
              lineInfo: [
                {
                  serviceInfo: {
                    cart5GAppointment: {
                      customerInstructions: '',
                      emailAddress: 'SENTHIL.KUMAR.BHOOPALAN@ONE.VERIZON.COM',
                      eventCorrelationId: '60611_1737642957399_182',
                      firstName: 'BRIAN',
                      homePhone: '9089349238',
                      installApptSelectedDate: {
                        availableDate: '20250201',
                        availableDay: '6',
                        availableType: '0',
                        serviceProviderAccount: '1115183',
                        serviceProviderName: 'ASURION INSTALLER',
                        slotLength: '2',
                        slotStartTime: '0800',
                      },
                      lastName: 'WRIGHT',
                      preferredContactType: 'Email',
                      primaryPhoneType: 'Home',
                    },
                  },
                },
              ],
              tradeInDetail: { tradeInItems: [{ id: 'tradeInItem' }] },
            },
            quote: { quoteId: 'quoteId' },
          },
        },
      },
    };

    const mockInfoApiData = {
      getCartRequest: jest.fn(),
      getCartResponse: appointmentMockCartJson,
      submitUserInfo: jest.fn(),

      fetchPricingSnapRequest: jest.fn(),
      getActiveMTNRequest: jest.fn(),
      orderReviewRequest: jest.fn(),
    };
    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => mockInfoApiData);
    getQueryParamByName.mockReturnValue('true');
  });

  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  // new iteam added for read-Order
  test('Should open devicePayment Modal once user click of devicePayment', () => {
    getAssistedCradlePropertyV2.mockImplementation(() => ['TRUE']); // Override mock

    window.mfe = { scmUpgradeMfeEnable: false };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => mockData);
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => mockAddAccessoriesData);
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ enablePartialNbsPosFFlag: 'TRUE' }));
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...inStorePickupProps}
            data={cartJson}
            lines={cartJson.data.cart.lineDetails.lineInfo}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={false}
            readOrderResponse={{ orderStatus: 'CO' }}
            isFromReadOrder
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    global.window.vzdl = { page: { detail: '' } };
    const backdrop = screen.getAllByTestId('hamburger-icon')[0];
    fireEvent.click(backdrop);
    const title = screen.getByTestId('devicePayment');
    fireEvent.click(title);
  });
});

describe('useEffect for getNbeResult', () => {
  test('should dispatch updateOneUINbsRespSuccess when getNbeResult.isSuccess is true', async () => {
    const mockDispatch = jest.fn();
    const mockGetNbeResult = {
      isSuccess: true,
      data: { mockData: 'test' },
    };

    // Mock the component with the specific getNbeResult
    const TestComponent = () => {
      const dispatch = mockDispatch;
      const getNbeResult = mockGetNbeResult;

      React.useEffect(() => {
        if (getNbeResult?.isSuccess) {
          dispatch(updateOneUINbsRespSuccess(getNbeResult));
        }
      }, [getNbeResult?.isSuccess, dispatch]);

      return <div>Test Component</div>;
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <TestComponent />
        </StoreProvider>
      </BrowserRouter>,
    );

    await waitFor(() => {
      expect(mockDispatch).toHaveBeenCalledWith(updateOneUINbsRespSuccess(mockGetNbeResult));
    });
  });

  //   test("should not dispatch updateOneUINbsRespSuccess when getNbeResult.isSuccess is false", async () => {
  //     const mockDispatch = jest.fn();
  //     const mockGetNbeResult = {
  //       isSuccess: false,
  //       data: null
  //     };

  //     // Mock the component with the specific getNbeResult
  //     const TestComponent = () => {
  //       const dispatch = mockDispatch;
  //       const getNbeResult = mockGetNbeResult;

  //       React.useEffect(() => {
  //         if (getNbeResult?.isSuccess) {
  //           dispatch(updateOneUINbsRespSuccess(getNbeResult));
  //         }
  //       }, [getNbeResult?.isSuccess, dispatch]);

  //       return <div>Test Component</div>;
  //     };

  //     render(
  //       <BrowserRouter>
  //         <StoreProvider>
  //           <TestComponent />
  //         </StoreProvider>
  //       </BrowserRouter>
  //     );

  //     // Wait a bit and verify dispatch was not called
  //     await new Promise(resolve => setTimeout(resolve, 100));
  //     expect(mockDispatch).not.toHaveBeenCalled();
  //   });
});

// Test cases for Sales Rep Display Feature
describe('Sales Rep Display Feature', () => {
  const mockProps = {
    setSelectedReviewMode: jest.fn(),
    setSelectedReason: jest.fn(),
    readOrderResponse: {
      orderStatus: 'CR',
      cart: {
        cartHeader: { status: 'S', fullAccountNumber: '0486957317-1' },
        orderDetails: { orderList: [{ orderNumber: '20331588' }] },
      },
      lovIndicator: 'YY',
    },
  };

  beforeEach(() => {
    jest.clearAllMocks();
    sessionStorage.clear();
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ enablePartialNbsPosFFlag: 'TRUE' }));
    window.mfe = { scmUpgradeMfeEnable: true, isProspectNewCustomerTab: true, scmCheckoutMfeEnable: true };
    jest.spyOn(clickToCallAPICallHook, 'default').mockImplementation(() => ({
      getClickToCallDetailsRequest: jest.fn(),
      getClickToCallDetailsResult: { data: getClickToCallDetailsJson },
    }));
    jest.spyOn(GetAccessApiCallHook, 'default').mockImplementation(() => ({
      addAccessories: jest.fn(),
      addAccessoriesSuccess: { data: true },
      getCustomerByMtn: jest.fn(),
    }));
    jest.spyOn(InfoApiCallHook, 'default').mockImplementation(() => ({
      getCartRequest: jest.fn(),
      getCartResponse: { data: cartJson },
      submitUserInfo: jest.fn(),
      fetchPricingSnapRequest: jest.fn(),
      getActiveMTNRequest: jest.fn(),
      orderReviewRequest: jest.fn(),
    }));
    getAssistedCradlePropertyV2.mockImplementation(() => ['FALSE']);
    getQueryParamByName.mockReturnValue('false');
  });

  test('should display sales rep icon and ID when conditions are met', () => {
    const mockGetItem = jest.spyOn(Storage.prototype, 'getItem').mockImplementation((key) => {
      if (key === 'APP_PROPERTIES') return JSON.stringify({ enablePartialNbsPosFFlag: 'TRUE' });
      return null;
    });

    // Create test data with salesRepId in the correct location
    const testCartData = {
      ...cartJson,
      data: {
        ...cartJson.data,
        cart: {
          ...cartJson.data.cart,
          orderDetails: {
            ...cartJson.data.cart.orderDetails,
            salesRepId: 'REP12',
          },
        },
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...mockProps}
            data={testCartData}
            showRepGuidedScreen={false}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const threeDotMenus = screen.getAllByTestId('three-dot-menu');
    fireEvent.click(threeDotMenus[0]);

    expect(document.querySelector('.sales-rep-display-mode')).toBeInTheDocument();
    expect(document.querySelector('.sales-rep-display-mode svg')).toBeInTheDocument();
    expect(document.querySelector('.sales-rep-id-display')).toHaveTextContent('REP12');

    mockGetItem.mockRestore();
  });

  test('should not display when isProspectNewCustomerTab is false', () => {
    // Create test data with salesRepId in the correct location
    const testCartData = {
      ...cartJson,
      data: {
        ...cartJson.data,
        cart: {
          ...cartJson.data.cart,
          orderDetails: {
            ...cartJson.data.cart.orderDetails,
            salesRepId: 'ABC12',
          },
        },
      },
    };

    window.mfe.isProspectNewCustomerTab = false;
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...mockProps}
            data={testCartData}
            showRepGuidedScreen={false}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const threeDotMenus = screen.getAllByTestId('three-dot-menu');
    fireEvent.click(threeDotMenus[0]);

    expect(document.querySelector('.sales-rep-display-mode')).not.toBeInTheDocument();
  });

  test('should retrieve salesRepId from cart data', () => {
    // Mock sessionStorage.getItem only for APP_PROPERTIES
    const mockGetItem = jest.spyOn(Storage.prototype, 'getItem').mockImplementation((key) => {
      if (key === 'APP_PROPERTIES') return JSON.stringify({ enablePartialNbsPosFFlag: 'TRUE' });
      return null;
    });

    // Create test data with salesRepId in the correct location
    const testCartData = {
      ...cartJson,
      data: {
        ...cartJson.data,
        cart: {
          ...cartJson.data.cart,
          orderDetails: {
            ...cartJson.data.cart.orderDetails,
            salesRepId: 'TEST1',
          },
        },
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...mockProps}
            data={testCartData}
            showRepGuidedScreen={false}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const threeDotMenus = screen.getAllByTestId('three-dot-menu');
    fireEvent.click(threeDotMenus[0]);

    // Verify the sales rep ID is displayed from cart data
    expect(document.querySelector('.sales-rep-id-display')).toHaveTextContent('TEST1');

    mockGetItem.mockRestore();
  });

  test('should handle empty and special character salesRepId values', () => {
    // Test empty value when salesRepId is not in cart data
    const mockGetItem = jest.spyOn(Storage.prototype, 'getItem').mockImplementation((key) => {
      if (key === 'APP_PROPERTIES') return JSON.stringify({ enablePartialNbsPosFFlag: 'TRUE' });
      return null;
    });

    // Create test data without salesRepId
    const testCartDataNoSalesRep = {
      ...cartJson,
      data: {
        ...cartJson.data,
        cart: {
          ...cartJson.data.cart,
          orderDetails: {
            ...cartJson.data.cart.orderDetails,
            // Remove salesRepId completely
          },
        },
      },
    };
    // Ensure salesRepId is actually removed
    delete testCartDataNoSalesRep.data.cart.orderDetails.salesRepId;

    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...mockProps}
            data={testCartDataNoSalesRep}
            showRepGuidedScreen={false}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const threeDotMenus = screen.getAllByTestId('three-dot-menu');
    fireEvent.click(threeDotMenus[0]);
    expect(document.querySelector('.sales-rep-id-display')).toBeEmptyDOMElement();

    mockGetItem.mockRestore();

    // Clean up and re-render for second test
    document.body.innerHTML = '';

    // Test valid alphanumeric characters within 5 char limit
    const mockGetItem2 = jest.spyOn(Storage.prototype, 'getItem').mockImplementation((key) => {
      if (key === 'APP_PROPERTIES') return JSON.stringify({ enablePartialNbsPosFFlag: 'TRUE' });
      return null;
    });

    // Create test data with valid salesRepId
    const testCartDataValid = {
      ...cartJson,
      data: {
        ...cartJson.data,
        cart: {
          ...cartJson.data.cart,
          orderDetails: {
            ...cartJson.data.cart.orderDetails,
            salesRepId: 'REP12',
          },
        },
      },
    };

    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...mockProps}
            data={testCartDataValid}
            showRepGuidedScreen={false}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const threeDotMenus2 = screen.getAllByTestId('three-dot-menu');
    fireEvent.click(threeDotMenus2[0]);
    expect(document.querySelector('.sales-rep-id-display')).toHaveTextContent('REP12');

    mockGetItem2.mockRestore();
  });

  test('should use empty string when salesRepId is not in cart data', () => {
    // Ensure sessionStorage is clear
    sessionStorage.clear();
    const mockGetItem = jest.spyOn(Storage.prototype, 'getItem').mockImplementation((key) => {
      if (key === 'APP_PROPERTIES') return JSON.stringify({ enablePartialNbsPosFFlag: 'TRUE' });
      return null;
    });

    // Create test data without salesRepId
    const testCartDataNoSalesRep = {
      ...cartJson,
      data: {
        ...cartJson.data,
        cart: {
          ...cartJson.data.cart,
          orderDetails: {
            ...cartJson.data.cart.orderDetails,
            // Remove salesRepId completely
          },
        },
      },
    };
    // Ensure salesRepId is actually removed
    delete testCartDataNoSalesRep.data.cart.orderDetails.salesRepId;

    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...mockProps}
            data={testCartDataNoSalesRep}
            showRepGuidedScreen={false}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const threeDotMenus = screen.getAllByTestId('three-dot-menu');
    fireEvent.click(threeDotMenus[0]);

    // Verify that sales rep display still shows but with empty content
    expect(document.querySelector('.sales-rep-display-mode')).toBeInTheDocument();
    expect(document.querySelector('.sales-rep-id-display')).toBeEmptyDOMElement();

    mockGetItem.mockRestore();
  });

  test('should not display when scmUpgradeMfeEnable is false', () => {
    sessionStorage.setItem('salesRepId', 'ABC12');
    window.mfe.scmUpgradeMfeEnable = false;
    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...mockProps}
            data={cartJson}
            showRepGuidedScreen={false}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    expect(screen.queryByTestId('three-dot-menu')).not.toBeInTheDocument();
    expect(document.querySelector('.sales-rep-display-mode')).not.toBeInTheDocument();
  });

  test('should handle various valid salesRepId formats matching regex pattern', () => {
    const validSalesRepIds = ['ABC12', 'XYZ01', 'A1B2C', '12345', 'ABCDE', 'A', ''];

    validSalesRepIds.forEach((salesRepId, index) => {
      // Clean up previous render
      document.body.innerHTML = '';

      const mockGetItem = jest.spyOn(Storage.prototype, 'getItem').mockImplementation((key) => {
        if (key === 'APP_PROPERTIES') return JSON.stringify({ enablePartialNbsPosFFlag: 'TRUE' });
        return null;
      });

      // Create test data with specific salesRepId
      const testCartData = {
        ...cartJson,
        data: {
          ...cartJson.data,
          cart: {
            ...cartJson.data.cart,
            orderDetails: {
              ...cartJson.data.cart.orderDetails,
              salesRepId: salesRepId,
            },
          },
        },
      };

      render(
        <BrowserRouter>
          <StoreProvider>
            <AccessoriesCheckoutDetails
              {...mockProps}
              data={testCartData}
              showRepGuidedScreen={false}
              showAffirmAccordion={false}
            />
          </StoreProvider>
        </BrowserRouter>,
      );

      const threeDotMenus = screen.getAllByTestId('three-dot-menu');
      fireEvent.click(threeDotMenus[0]);

      // Verify the salesRepId matches the regex pattern /^[a-zA-Z0-9]{0,5}$/
      expect(salesRepId).toMatch(/^[a-zA-Z0-9]{0,5}$/);
      expect(document.querySelector('.sales-rep-display-mode')).toBeInTheDocument();
      expect(document.querySelector('.sales-rep-id-display')).toHaveTextContent(salesRepId);

      mockGetItem.mockRestore();
    });
  });

  test('should display sales rep information from cart data structure', () => {
    const mockGetItem = jest.spyOn(Storage.prototype, 'getItem').mockImplementation((key) => {
      if (key === 'APP_PROPERTIES') return JSON.stringify({ enablePartialNbsPosFFlag: 'TRUE' });
      return null;
    });

    // Create test data with multiple salesRepId values to test the data flow
    const testCartDataWithSalesRep = {
      ...cartJson,
      data: {
        ...cartJson.data,
        cart: {
          ...cartJson.data.cart,
          orderDetails: {
            ...cartJson.data.cart.orderDetails,
            salesRepId: 'SALES123',
          },
        },
      },
    };

    window.mfe.isProspectNewCustomerTab = true;

    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...mockProps}
            data={testCartDataWithSalesRep}
            showRepGuidedScreen={false}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const threeDotMenus = screen.getAllByTestId('three-dot-menu');
    fireEvent.click(threeDotMenus[0]);

    // Verify the sales rep display is rendered with correct data
    expect(document.querySelector('.sales-rep-display-mode')).toBeInTheDocument();
    expect(document.querySelector('.sales-rep-id-display')).toHaveTextContent('SALES123');

    // Verify the icon is displayed
    expect(document.querySelector('.sales-rep-display-mode svg')).toBeInTheDocument();

    mockGetItem.mockRestore();
  });

  test('should handle undefined cart data gracefully', () => {
    const mockGetItem = jest.spyOn(Storage.prototype, 'getItem').mockImplementation((key) => {
      if (key === 'APP_PROPERTIES') return JSON.stringify({ enablePartialNbsPosFFlag: 'TRUE' });
      return null;
    });

    window.mfe.isProspectNewCustomerTab = true;

    render(
      <BrowserRouter>
        <StoreProvider>
          <AccessoriesCheckoutDetails
            {...mockProps}
            data={undefined}
            showRepGuidedScreen={false}
            showAffirmAccordion={false}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const threeDotMenus = screen.getAllByTestId('three-dot-menu');
    fireEvent.click(threeDotMenus[0]);

    // Should still render but with empty content
    expect(document.querySelector('.sales-rep-display-mode')).toBeInTheDocument();
    expect(document.querySelector('.sales-rep-id-display')).toBeEmptyDOMElement();

    mockGetItem.mockRestore();
  });
});
