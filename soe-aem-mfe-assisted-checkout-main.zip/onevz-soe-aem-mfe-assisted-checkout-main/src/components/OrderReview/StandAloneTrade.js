import { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { TextLink, Button } from '@vds/buttons';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import { ViewExitDialog } from 'onevzsoemfecommon/ViewExitDialog';
import { has } from 'lodash';
import styled, { createGlobalStyle } from 'styled-components';
import { Modal, ModalFooter, ModalTitle } from '@vds/modals';
import Emitter from 'onevzsoemfeframework/Emitter';
import { Title } from '@vds/typography';
import { useNavigate } from 'react-router';
import { Icon } from '@vds/icons';
import { BackClickable } from '../../StyledConstants';
import { formatPhoneNumberWithSymbol, formatCurrency } from '../../utils/common';
import EditTradein from './EditTradein';
import GetStandAlonetradein from '../../modules/services/APIService/GetStandAlonetradein';
import AcssViewTogether from '../ViewTogether/AcssViewTogether';

const FlexBoxGrowOne = styled.div`
  display: flex;
  flex-grow: 1;
  position: sticky;
  top: 0;
  z-index: 9999;
  background-color: #fff;
`;
const HorizontalLine = styled.div`
  border: none;
  border-top: 1px solid rgba(0, 0, 0, 0.3);
`;
const MaxWidth = styled.div`
  [class^='ModalDialog-VDS-'] {
    max-width: 1133px;
  }
`;
const LineSeperator = styled.div`
  width: 1px;
  margin-left: 220px;
  height: 50px;
  background: #000000;
  top: 1rem;
  border-right: 1px solid #d8dada;
  position: relative;
  margin-right: 10px;
`;
const BoxContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  z-index: 90;
`;
const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  padding-left: 30px;
`;
const EditRight = styled.div`
  justify-content: flex-end;
  display: flex;
  justify-content: flex-end;
  width: 90%;
`;
const EditFont = styled.div`
  [class^='Wrapper-VDS__'] {
    font-size: 12px !important;
    font-family: BrandFont-Text, Arial, sans-serif !important;
  }
`;
const ContainerPadding = styled.div`
  padding: ${(props) => (props.scmDeviceMfeEnable ? '0' : '20px')};
`;
const AmountRight = styled.div`
  display: flex;
  justify-content: flex-end;
  width: 93%;
`;
const AmountFont = styled.div`
  [class^='StyledTypography-VDS__'] {
    font-size: 18px !important;
    font-family: BrandFontBold, sans-serif !important;
  }
`;
const NameFont = styled.div`
  [class^='StyledTypography-VDS__'] {
    font-size: 18px !important;
    font-family: BrandFontBold, sans-serif !important;
  }
`;
const ReturnMethodContainer = styled(NameFont)`
  display: flex;
  [class^='StyledTypography-VDS__'] {
    font-size: 18px !important;
    font-family: BrandFontBold, sans-serif !important;
  }
`;
const DeviceFont = styled.div`
  [class^='StyledTypography-VDS__'] {
    font-size: 16px !important;
    font-family: BrandFontBold, Arial, sans-serif !important;
  }
`;
const SpaceBetween = styled.div`
  margin-bottom: ${(props) => (props.scmDeviceMfeEnable ? '0' : '20px')};
`;
const SelectTitleWrapper = styled.div`
  padding: 14px 0;
  [class^='StyledTypography-VDS'] {
    background-color: #f0f0f0;
    padding: inherit;
    display: flex;
    padding: 10px;
  }
`;
const Styledspan = styled.div`
  margin-right: 60px;
`;

const GiftCard = styled.div`
  font-weight: 100;
  font-size: 12px;
`;

const GiftCard2 = styled.div`
  font-size: 12px;
`;

const DialogContainer = styled.div`
  position: fixed;
  top: 50%;
  left: 50%;
  width: 37%;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: white;
  transform: translate(-50%, -50%);
  padding: 15px;
  z-index: 99;
  box-shadow: 0px 0px 1px 0px;
  flex-direction: column;
  display: flex;
`;
const ComponentStyle = createGlobalStyle`
  #standAloneModl {
  
    [class^='ModalDialog-VDS'] {
      width: 64rem;
      margin: 0 auto;
      border-radius: 0;
      padding: 0;
    }
    [class^='ModalDialogWrapper-VDS'] {
        > span {
          width: 100%;
          height: 100%;
        > div {
          width:100% !important;
          height: 100% !important;
          > div {
            padding:0 !important;
          }
        }
      }
    }
    [class^='StyledModalBody-VDS'] {
      height: 80vh;
      padding: 0.7rem 0px 0px;
      overflow: auto;
    }
    [class^='IconWrapper-VDS'] {
      z-index: 99999;
      padding: 20px;
      right: 10%;
    }
    
    [class^='StyledHeader-VDS'] {
      border-bottom: 1px solid #ccc;
      position: sticky;
      top:0;
      background: #fff;
      z-index: 999;
      padding: 1rem 2rem;
    }
    [class^='StyledFooter-VDS'] {
      border-top: 1px solid #ccc;
      position: sticky;
      padding:20px;
      bottom:0;
      background: #fff;
    }
    [class^='StyledButton-VDS'] {
      [class^='StyledChildWrapper-VDS'] {
        font-size: 12px;
        font-family: BrandFontBold, Sans-serif !important;
      }
    }
  }
`;

const TradeinTitle = styled(Title)`
  font-family: BrandFontBold, Sans-serif !important;
  font-size: 18px;
`;

const isServiceOnlyOrder = (lines) => {
  const hasOtherLines =
    lines.length > 0 &&
    lines.find(
      (line) =>
        (line.lineActivityType !== 'CPC' && line.lineActivityType !== 'FEA') ||
        ((line.lineActivityType === 'FEA' || line.lineActivityType === 'CPC') &&
          has(line, 'itemsInfo[0].cartItems.cartItem') &&
          line.itemsInfo[0].cartItems.cartItem.length > 0),
    );
  return !hasOtherLines;
};
const allowOnlyNumbers = (value) => {
  const rE = /^[0-9\b]+$/;
  return value === '' || rE.test(value);
};
const labels = {
  tradeinhome: 'Trade at home',
  tradePrepaidLabel: 'Prepaid Label',
  tradeQRCode: 'UPS QR code',
  tradeinLater: 'Trade the device later',
  tradeinNow: 'Trade the device now',
};
const StandAloneTrade = ({ data, cartDetailsResult, customer, landing, ViewTogetherProps }) => {
  const { getMFIPrequest, getMFIPResult, getOrderWrite, getOrderWriteResult } = GetStandAlonetradein();
  const [previousEmail, setPreviousEmail] = useState('');
  const [showModal, setShowModal] = useState(true);
  const [showVT, setShowVT] = useState(false);
  const [showEditTradein, setShowEditTradein] = useState(false);
  const [showDialogue, setshowDialogue] = useState(false);
  const [showMessageMFIP, setShowMessageMFIP] = useState('');
  const [returnMethod, setReturnMethod] = useState('');
  const scmDeviceMfeEnable = window?.mfe?.scmDeviceMfeEnable;
  let navigate = '';
  function useNavigateMFE() {
    navigate = useNavigate();
  }
  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.error('Navigation error:-', e);
  }
  const tradeInitems = data?.tradeInItems;
  const customerName = data?.customerName;
  const deviceID = data?.tradeInItems?.find((item) => item?.deviceId);
  const tradeIndetail = data;
  const cartDetails = cartDetailsResult?.data?.cart;
  let totalAppliedPrice = 0;
  for (const item of tradeInitems) {
    if (item.appliedPrice !== undefined) {
      const price = parseFloat(item.appliedPrice);
      if (!Number.isNaN(price)) {
        totalAppliedPrice += price;
      }
    } else if (item.itemPrice !== undefined) {
      const price = parseFloat(item.itemPrice);
      if (!Number.isNaN(price)) {
        totalAppliedPrice += price;
      }
    }
  }
  const handleEditclick = () => {
    setShowEditTradein(true);
  };
  const handleClickOK = () => {
    setshowDialogue(false);
  };
  const handleContinueShopping = () => {
    if (scmDeviceMfeEnable) {
      Emitter.emit('ACSS_SCM_DEVICE_SUBTAB', { subTab: 'DEVICE_TAB' });
    } else {
      window.location.href = `/sales/assisted/landing.html`;
    }
  };
  const handleCheckoutClick = () => {
    // handling 2 API calls here
    const params = { deviceInInfo: [{ deviceId: deviceID?.deviceId }] };
    getMFIPrequest({
      body: params,
      spinner: false,
      mock: false,
    });
  };
  const closeModalPopup = () => {
    setShowEditTradein(false);
  };
  useEffect(() => {
    if (getMFIPResult.status === 'fulfilled') {
      setShowMessageMFIP(getMFIPResult?.data?.response?.map((item) => item.message));
      setshowDialogue(getMFIPResult?.data?.response?.map((item) => item.fmiSwitch)?.[0] === 'ON' || false);
      if (getMFIPResult?.data?.response?.map((item) => item.fmiSwitch)?.[0] === 'OFF') {
        const activeMtn = cartDetails?.cartHeader?.cartCreator ?? '';
        const currentEmail = cartDetails?.orderDetails?.spocs?.notificationOptions?.primaryEmailId;
        let isServiceWriteRequired = false;
        if (currentEmail !== previousEmail) {
          isServiceWriteRequired = true;
        }
        let emailId = cartDetails?.orderDetails?.spocs?.notificationOptions?.primaryEmailId ?? '';
        const customerType = getQueryParamByName('customerType') || sessionStorage.getItem('customerType');
        if (customerType === 'N' && currentEmail !== null) {
          emailId = currentEmail;
        } else if (customerType === 'N') {
          emailId = cartDetails?.lineDetails?.lineInfo[0].primaryUserInfo?.emailId ?? emailId;
        }
        const creditAppNum = getQueryParamByName('creditAppNum');
        const lineInfoLength = !!(
          has(cartDetails, 'lineDetails.lineInfo') && cartDetails?.lineDetails?.lineInfo?.length
        );
        const tradeinItemsLength = !!(
          has(cartDetails, 'lineDetails.tradeInDetail.tradeInItems') &&
          cartDetails?.lineDetails?.tradeInDetail?.tradeInItems.length
        );
        const lines = has(cartDetails, 'lineDetails.lineInfo') && cartDetails?.lineDetails?.lineInfo;
        const channel = has(cartDetails, 'cartHeader.sourceSystem')
          ? cartDetails?.cartHeader?.sourceSystem
          : sessionStorage.getItem('channelId');
        const hasEupByodWithSimCpe =
          lines.length > 0 &&
          lines.every((line) =>
            line.lineActivityType !== ' ' && line.lineActivityType === 'EUPBYOD' && !channel?.includes('OMNI-INDIRECT')
              ? line?.itemsInfo[0]?.cartItems?.cartItem?.some(
                  (item) => item.cartItemType === 'SIM' && item.isCustomerProvidedSIM === true,
                )
              : line.lineActivityType === 'EUPBYOD',
          );
        const standAloneTradeIn = !!(!lineInfoLength && tradeinItemsLength);
        const isCPCorFEAonlyOrder = lines.length > 0 ? isServiceOnlyOrder(lines) : false;
        const isAccLevelSubItemPresent = () => {
          const accSubInCart = cartDetails?.lineDetails?.acctMcsSubscription ?? [];
          let isAccSubInCart = false;
          if (accSubInCart?.[0]) {
            isAccSubInCart = true;
          }
          return isAccSubInCart;
        };
        const isAccLevelSubItemPresentValue = isAccLevelSubItemPresent();
        let intentType;
        if (standAloneTradeIn) {
          intentType = 'StandAloneTradeIn';
        } else if (hasEupByodWithSimCpe) {
          intentType = 'EUPBYOD';
        } else if (isCPCorFEAonlyOrder || isAccLevelSubItemPresentValue) {
          intentType = 'Inline-CPC';
        } else {
          intentType = '';
        }
        const response = sessionStorage.getItem('responseList');
        const responseList = JSON.parse(response);
        const responses = responseList?.filter((res) => res.dispositionOptionId === '18');
        const resList = responses?.map((res) => ({
          rank: res?.rank ? res.rank : '',
          propositionId: res?.propositionId ? res.propositionId : '',
          soiEngagementId: res?.soiEngagementId ? res.soiEngagementId : '',
          offerContainerId: res?.offerContainerId ? res.offerContainerId : '',
        }));
        const quoteId = cartDetails?.quote?.quoteId ?? '';
        const currentQuoteId = () => {
          const activeCartId = customer?.cartId ?? '';
          const isQuoteDetailsAvailable = landing?.quoteDetails ?? [];
          if (isQuoteDetailsAvailable.length > 0) {
            const currentQuote = isQuoteDetailsAvailable.filter((item) => item.cartId === activeCartId);
            return currentQuote.length > 0 ? currentQuote[0].quoteId : '';
          }
          return '';
        };
        const billingSystem = cartDetails?.orderDetails?.billingSystem || '';
        let noOfTradeItems = 0;
        if (tradeinItemsLength) {
          noOfTradeItems = cartDetails?.lineDetails?.tradeInDetail?.tradeInItems.length;
        }
        const tradeInShippingType = tradeinItemsLength && cartDetails?.lineDetails?.tradeInDetail?.tradeInShippingType;

        const geoFenceResponse =
          sessionStorage.getItem('geoFenceResponse') && JSON.parse(sessionStorage.getItem('geoFenceResponse'));
        const inGeoFenceRange =
          geoFenceResponse?.geoFenceCheck === 'false' && geoFenceResponse?.reason?.toLowerCase() === 'out of range';
        const outOfGeoFenceObj = {
          outOfGeoFence: inGeoFenceRange,
          ipadLatitude: geoFenceResponse?.ipadLatitude,
          ipadLongitude: geoFenceResponse?.ipadLongitude,
          storeName: JSON.parse(sessionStorage.getItem('STORE-LOCATION-DETAIL'))?.data?.storeInfo?.storeName,
        };
        const params1 = {
          mtn: activeMtn && allowOnlyNumbers(activeMtn) ? activeMtn : '',
          locationCode: cartDetails?.orderDetails?.locationCode ?? '',
          accountNumber: customer?.accountNo ?? '',
          cartId: cartDetails?.cartHeader?.cartId ?? '',
          cartCreator: cartDetails?.cartHeader?.cartCreator ?? '',
          caseId: cartDetails?.cartHeader?.caseId ?? '',
          creditAppNum: customerType === 'N' ? creditAppNum : '',
          serviceWriteRequired: isServiceWriteRequired,
          smsDestination: '',
          email: emailId ?? '',
          intent: customerType && customerType === 'N' ? 'NSE' : intentType,
          paperlessIndicator: null,
          paperLessEmail: customerType && customerType === 'N' ? emailId : null,
          header: {
            cartId: cartDetails?.cartHeader?.cartId ?? '',
          },
          responseList: resList,
          regNo: customer?.regNo ?? '51',
          quoteId: quoteId !== '' && quoteId !== '0000' ? quoteId : currentQuoteId(),
          purchaseOrderNumber: '',
          billingSystem,
          ...(inGeoFenceRange && { ...outOfGeoFenceObj }),
        };
        if (
          params1.email === '' ||
          params1.email === cartDetails?.orderDetails?.spocs?.notificationOptions?.primaryEmailId
        ) {
          params1.serviceWriteRequired = false;
        }
        if (tradeinItemsLength) {
          params1.tradeinCount = noOfTradeItems;
          params1.tradeinShippingTypeForAssistedFlows = tradeInShippingType ?? '';
        }
        const appProperties = JSON.parse(sessionStorage.getItem('APP_PROPERTIES')) || {};
        const isMitekSimSwapEnabled = appProperties?.isMitekSimSwapEnabled === 'TRUE';
        const locationData = JSON.parse(sessionStorage.getItem('locationData'));
        if (isMitekSimSwapEnabled) {
          params1.storeCity = locationData?.city ?? '';
          params1.storeState = locationData?.state ?? '';
        }
        if (scmDeviceMfeEnable && window?.mfe?.acssVtPerksEnabled) {
          setShowVT(true);
        } else {
          getOrderWrite({
            body: params1,
            spinner: true,
            mock: false,
          });
        }
        
      }
    }
  }, [getMFIPResult]);
  useEffect(() => {
    if (getOrderWriteResult?.status === 'fulfilled') {
      const currentEmail1 = cartDetails?.orderDetails?.spocs?.notificationOptions?.primaryEmailId;
      setPreviousEmail(currentEmail1);
      if (
        scmDeviceMfeEnable ||
        getOrderWriteResult?.data?.availablePaths?.find((agreement) => agreement.path === 'Confirmation')
      ) {
        if (scmDeviceMfeEnable) {
          window?.mfe?.historyRef?.push('/content/vcg/assisted/care-order-confirmation.html');
        } else {
          navigate(`/sales/assisted/confirmation.html`);
        }
      }
    }
  }, [getOrderWriteResult]);

  useEffect(() => {
    const tradeInItemFromCart = cartDetails?.lineDetails?.tradeInDetail?.tradeInItems || null;
    const tradeInTypeFromCart = cartDetails?.lineDetails?.tradeInDetail?.tradeInType || null;
    const tradeInShippingType = cartDetails?.lineDetails?.tradeInDetail?.tradeInShippingType || null;
    setReturnMethod(getShippingText(tradeInShippingType, tradeInTypeFromCart, tradeInItemFromCart));
  }, [cartDetails]);

  const getShippingText = (tradeInShippingType, tradeInType, tradeInItem) => {
    let shipText = '';

    if (tradeInShippingType?.toLowerCase() === 'return_store' && tradeInType?.toLowerCase() === 'home') {
      shipText = labels.tradeinLater;
    } else if (tradeInShippingType?.toLowerCase() === 'upsdrop-off_qrcode') {
      shipText = labels.tradeQRCode;
    } else if (tradeInShippingType?.toLowerCase() === 'prepaidlabel') {
      shipText = labels.tradePrepaidLabel;
    } else if (tradeInShippingType?.toLowerCase() === 'trade_at_home') {
      shipText = labels.tradeinhome;
    } else if (tradeInType?.toLowerCase() === 'home') {
      shipText = labels.tradeinhome;
    } else if (tradeInItem?.length > 0) {
      shipText = labels.tradeinNow;
    }
    return shipText;
  };

  return (
    <>
      {' '}
      {!scmDeviceMfeEnable && !showModal && (
        <ViewExitDialog
          showCloseModal={!showModal}
          enableStandalone
          setShowCloseModal={() => {
            setShowModal(true);
          }}
          processStep='ShoppingCart'
        />
      )}
      {showModal && (
        <>
          <ComponentStyle />
          <MaxWidth data-testId='StandaloneTradein'>
            <Modal
              id='standAloneModl'
              fullScreenDialog={!scmDeviceMfeEnable}
              closeButton={scmDeviceMfeEnable ? null : true}
              modalHeight='100%'
              disableFocusLock
              disableOutsideClick
              width='100%'
              opened={showModal}
              onOpenedChange={(opened) => {
                if (!opened) {
                  setShowModal(false);
                }
              }}
            >
              <div>
                <FlexBoxGrowOne>
                  <BackClickable
                    data-testId='btn-back'
                    onClick={() => {
                      if (scmDeviceMfeEnable) {
                        Emitter.emit('ACSS_SCM_DEVICE_SUBTAB', {subTab: 'DEVICE_TAB' });
                        setShowModal(false);
                      } else {
                        window.location.href = `/sales/assisted/landing.html`;
                      }
                    }}
                  >
                    <Icon name='left-caret' size='XLarge' medium='true' />
                  </BackClickable>
                  {scmDeviceMfeEnable && <ModalTitle>Trade-in review</ModalTitle>}
                  <LineSeperator />
                </FlexBoxGrowOne>
                <HorizontalLine />
                <SpaceBetween scmDeviceMfeEnable={scmDeviceMfeEnable} />
                {!showVT && <BoxContainer>
                  {tradeInitems?.map((item) => (
                    <div key={item?.deviceId}>
                      <Container>
                        <ReturnMethodContainer>
                          <TradeinTitle size='small' bold primitive='h1'>
                            Return Method:
                          </TradeinTitle>
                          <TradeinTitle size='small' primitive='h1'>
                            {returnMethod}
                          </TradeinTitle>
                        </ReturnMethodContainer>
                        <SpaceBetween scmDeviceMfeEnable={scmDeviceMfeEnable} />
                        <img src={item?.imgUrl} alt='Iphone' width='160px' />
                        <SpaceBetween scmDeviceMfeEnable={scmDeviceMfeEnable} />
                        <ContainerPadding scmDeviceMfeEnable={scmDeviceMfeEnable}>
                          <NameFont>
                            <TradeinTitle size='small' bold primitive='h1'>
                              {customerName}
                            </TradeinTitle>
                          </NameFont>
                          {/* <SpaceBetween /> */}
                          <AmountFont>
                            <TradeinTitle size='small' bold primitive='h1'>
                              {item?.equipModel}
                            </TradeinTitle>
                            <SpaceBetween scmDeviceMfeEnable={scmDeviceMfeEnable} />
                            <TradeinTitle size='small' bold primitive='h1'>
                              {formatPhoneNumberWithSymbol(item?.tradeDeviceMDN, '-')}
                            </TradeinTitle>
                          </AmountFont>
                          <DeviceFont>
                            <TradeinTitle size='small' primitive='h1'>
                              Device Id : {item?.deviceId}
                            </TradeinTitle>
                          </DeviceFont>
                        </ContainerPadding>
                      </Container>
                    </div>
                  ))}
                  <EditRight>
                    <EditFont>
                      <TextLink
                        type='standAlone'
                        surface='light'
                        disabled={false}
                        size='small'
                        data-testId='Edit-btn'
                        onClick={handleEditclick}
                      >
                        Edit
                      </TextLink>
                    </EditFont>
                  </EditRight>
                  <SpaceBetween />
                  {totalAppliedPrice > 0 && (
                    <AmountRight>
                      <AmountFont>
                        <SelectTitleWrapper>
                          <TradeinTitle bold size='small' primitive='h1'>
                            <Styledspan>
                              {tradeInitems[0].creditType === 'ACT' ? 'Account credit' : 'Gift card credit'}
                            </Styledspan>{' '}
                            {formatCurrency(totalAppliedPrice)}
                          </TradeinTitle>
                          {tradeInitems[0].creditType !== 'ACT' && (
                            <TradeinTitle bold size='small' primitive='h1'>
                              <GiftCard>
                                <Styledspan>Gift card email</Styledspan>
                              </GiftCard>
                              <GiftCard2>{tradeInitems[0]?.emailAddress}</GiftCard2>
                            </TradeinTitle>
                          )}
                        </SelectTitleWrapper>
                      </AmountFont>
                    </AmountRight>
                  )}
                  {showDialogue && (
                    <DialogContainer>
                      <Icon name='warning' size={150} />
                      <TradeinTitle bold size='small' primitive='h1'>
                        {showMessageMFIP}
                      </TradeinTitle>
                      <Button
                        data-testid='ok-button'
                        size='large'
                        use='primary'
                        inverted
                        surface='light'
                        onClick={handleClickOK}
                      >
                        OK
                      </Button>
                    </DialogContainer>
                  )}
                  <ModalFooter
                    buttonData={{
                      close: {
                        children: 'Continue Shopping',
                        width: '225px',
                        onClick: () => handleContinueShopping(),
                        'data-track': 'Continue Shopping',
                      },
                      primary: {
                        children: 'Proceed To Checkout',
                        width: '225px',
                        'data-track': 'Proceed To Checkout',
                        onClick: () => handleCheckoutClick(),
                      },
                    }}
                  />
                  {showEditTradein && (
                    <EditTradein
                      popupInfo={tradeInitems}
                      addressPopup={tradeIndetail}
                      opened
                      closeModal={closeModalPopup}
                    />
                  )}
                </BoxContainer>}
                {scmDeviceMfeEnable && showVT && <AcssViewTogether ViewTogetherProps={ViewTogetherProps} />}
              </div>
            </Modal>
          </MaxWidth>
        </>
      )}
    </>
  );
};
StandAloneTrade.propTypes = {
  data: PropTypes.object,
  cartDetailsResult: PropTypes.object,
  customer: PropTypes.object,
  landing: PropTypes.object,
  ViewTogetherProps: PropTypes.object,
};
export default StandAloneTrade;
