import { render, screen, fireEvent } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../modules/store';
import ManualDiscountViewModal from './ManualdiscountViewModal';

describe('ManualDiscountViewModal Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  beforeEach(() => {
    window.mfe = { scmDeviceMfeEnable: true, scmUpgradeMfeEnable: true };
    window.mfe.historyRef = jest.fn();
    window.mfe.historyRef.push = jest.fn();
  });
  
  test('renders ManualDiscountViewModal', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountViewModal value handleToggle={jest.fn()} />
        </StoreProvider>
      </BrowserRouter>
    );
    const modalHeader = screen.getByTestId('discounts-modal');
    expect(modalHeader).toBeInTheDocument();
  });

  test('should close Modal on click of X Icon', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountViewModal value handleToggle={jest.fn()} />
        </StoreProvider>
      </BrowserRouter>
    );
    const closeButton = screen.getByTestId('btn-exit-dialog');
    fireEvent.click(closeButton);
    expect(closeButton).toBeInTheDocument();
  });

  test('renders ManualDiscountViewModal when scmUpgradeMfeEnable = false', () => {
    window.mfe.scmUpgradeMfeEnable = false;
    render(
      <BrowserRouter>
        <StoreProvider>
          <ManualDiscountViewModal value handleToggle={jest.fn()} />
        </StoreProvider>
      </BrowserRouter>
    );
    const modalHeader = screen.getByTestId('discounts-modal');
    expect(modalHeader).toBeInTheDocument();
  });

  it('renders without crashing', async () => {
    // Mock cartDetails object
    const cartDetails = {
      cart: {
        lineDetails: {
          lineInfo: [
            {
              itemsInfo: [
                {
                  cartItems: {
                    cartItem: [
                      {
                        description: 'Item description',
                        itemCode: '12345',
                        itemPrice: 10,
                        qty: 1,
                        taxAmount: 1,
                        discountedPrice: 9,
                        manualDiscount: 0,
                      },
                    ],
                  },
                },
              ],
            },
          ],
        },
      },
    };
    // Render the component with the mocked cartDetails
    render(<ManualDiscountViewModal cartDetails={cartDetails} />);
  });
});
