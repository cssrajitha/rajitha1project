import { rest } from 'msw';
import { setupServer } from 'msw/node';
import nextBillSummary from '../../__mock__/getNextBillSummary.json';
import getNextBillSummaryNewCustomer from '../../__mock__/getNextBillSummaryNewCustomer.json';
import PreviewBill from './PreviewBill';
import { fireEvent, render, screen } from '../../utils/test-utils/renderHelper';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';

const mockedUsedNavigate = jest.fn();

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockedUsedNavigate,
}));

describe('Preview Bill Component', () => {
  const mockCloseModalFn = jest.fn();
  const compteDPJson = nextBillSummary;
  const handlers = [
    rest.post(`*/orderprocessservice/nbsapi/nextbillsummary`, (req, res, ctx) =>
      res(ctx.status(200), ctx.json(compteDPJson)),
    ),
  ];
  const server = setupServer(...handlers);

  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;

    server.listen();
  });

  beforeEach(() => {
    const mtnData = nextBillSummary.nbsVo;
    render(<PreviewBill billData={mtnData} opened closeModal={mockCloseModalFn} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('renders Bill Data Title', () => {
    const titleElement = screen.getByTestId('previewBillModel');
    expect(titleElement).toBeInTheDocument();
  });
  test('Render Expand All Button', () => {
    const ExpandAllTextBtn = screen.getByTestId('expandall-text-btn');
    expect(ExpandAllTextBtn).toBeInTheDocument();
    fireEvent.click(ExpandAllTextBtn);
    expect(screen.getByText('Collapse')).toBeInTheDocument();
  });

  test('close preview bill modal', () => {
    expect(screen.getByTestId('modal-close-button')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('modal-close-button'), {});
    expect(mockCloseModalFn).toHaveBeenCalledTimes(1);
  });
});

describe('Preview Bill Component with navigate button', () => {
  const mockCloseModalFn = jest.fn();
  const compteDPJson = nextBillSummary;
  const handlers = [
    rest.post(`*/orderprocessservice/nbsapi/nextbillsummary`, (req, res, ctx) =>
      res(ctx.status(200), ctx.json(compteDPJson)),
    ),
  ];
  const server = setupServer(...handlers);

  beforeAll(() => {
    server.listen();
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] };
  });

  beforeEach(() => {
    const mtnData = nextBillSummary.nbsVo;
    render(
      <PreviewBill
        billData={mtnData}
        opened
        closeModal={mockCloseModalFn}
        navigateTo='sales/assisted/new/shipping-details.html'
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });

  test('click continue-confirmation button', () => {
    expect(screen.getByTestId('continue-confirmation')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('continue-confirmation'), {});
  });
});

describe('Preview Bill Component with navigate button 2', () => {
  const mockCloseModalFn = jest.fn();
  const compteDPJson = nextBillSummary;
  const handlers = [
    rest.post(`*/orderprocessservice/nbsapi/nextbillsummary`, (req, res, ctx) =>
      res(ctx.status(200), ctx.json(compteDPJson)),
    ),
  ];
  const server = setupServer(...handlers);

  beforeAll(() => {
    server.listen();
    window.mfe = { scmCheckoutMfeEnable: false };
  });

  beforeEach(() => {
    const mtnData = nextBillSummary.nbsVo;
    render(
      <PreviewBill
        billData={mtnData}
        opened
        closeModal={mockCloseModalFn}
        navigateTo='sales/assisted/new/shipping-details.html'
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });

  test('click continue-confirmation button', () => {
    expect(screen.getByTestId('continue-confirmation')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('continue-confirmation'), {});
  });
});

describe('Preview Bill Component with New User', () => {
  const mockCloseModalFn = jest.fn();
  const compteDPJson = getNextBillSummaryNewCustomer;
  const handlers = [
    rest.post(`*/orderprocessservice/nbsapi/nextbillsummary`, (req, res, ctx) =>
      res(ctx.status(200), ctx.json(compteDPJson)),
    ),
  ];
  const server = setupServer(...handlers);

  beforeAll(() => {
    server.listen();
  });

  beforeEach(() => {
    const mtnData = getNextBillSummaryNewCustomer.nbsVo;
    render(<PreviewBill billData={mtnData} opened closeModal={mockCloseModalFn} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('renders Bill Data Title', () => {
    const titleElement = screen.getByText('First Bill Summary');
    expect(titleElement).toBeInTheDocument();
  });

  test('isDark true', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    const mtnData = getNextBillSummaryNewCustomer.nbsVo;
    render(<PreviewBill billData={mtnData} opened closeModal={mockCloseModalFn} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('renders with ccare-soe environment and isNbsMfe true', () => {
    // Mock window.location.origin to contain ccare-soe
    Object.defineProperty(window, 'location', {
      value: {
        origin: 'https://ccare-soe.verizon.com',
      },
      writable: true,
    });

    const mtnData = getNextBillSummaryNewCustomer.nbsVo;
    render(<PreviewBill billData={mtnData} opened closeModal={mockCloseModalFn} isNbsMfe />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
});
