import React from 'react';
import { render, screen } from '../../utils/test-utils/renderHelper';
import MonthlyChargesModal from './MonthlyChargesModal';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import * as monthlyChargesApiCallHook from '../../pages/home/container/monthlyChargesApiCallHook';
import * as commonUtils from '../../utils/common';
// import { scmCheckoutMfeEnabled } from '../../utils/common';

describe('MonthlyChargesModal', () => {
  const mockGetOtherLineCharges = jest.fn();
  const MOCKMonthlyCharges = [
    {
      thisMonthCharge: '15.00',
      description: 'NUMBER SHARE',
      itemType: 'PLAN',
    },
    {
      description: '50% ACCESS FEE DISCOUNT FROM 256.609.9760',
      itemType: 'PROMO',
    },
  ];
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  const mockOtherLineChargesResult = ({ monthlyCharges = [], oneTimeCharges = [], addOnsCharges = [] } = {}) => ({
    mtnLevelChargeDetails: [
      {
        mtn: '1234567890',
        monthlyCharges,
        oneTimeCharges,
        addOnsCharges,
      },
    ],
    totalOtherLinesCharges: 50,
  });
  test('renders modal with correct title', async () => {
    window.mfe = { scmCheckoutMfeEnabled: true };
    const scmCheckoutMfeEnabledMock = jest.spyOn(commonUtils, 'scmCheckoutMfeEnabled');
    scmCheckoutMfeEnabledMock.mockReturnValue(true);

    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: { data: mockOtherLineChargesResult({ monthlyCharges: MOCKMonthlyCharges }) },
    }));
    const lineInfo = [{ mobileNumber: '1234567890' }];
    render(<MonthlyChargesModal opened toggleModal={() => {}} lineInfo={lineInfo} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    const monthlyChargesModal = screen.getByTestId('monthlyChargesModal');
    expect(monthlyChargesModal).toBeInTheDocument();

    const titleElement = screen.getByText('Monthly Charges for your other 1 lines');
    expect(titleElement).toBeInTheDocument();
  });

  test('renders modal with correct title 2', async () => {
    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: { data: mockOtherLineChargesResult({ monthlyCharges: MOCKMonthlyCharges }) },
    }));
    const lineInfo = [{ mobileNumber: '1234567890' }];
    render(<MonthlyChargesModal opened toggleModal={() => {}} lineInfo={lineInfo} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    const monthlyChargesModal = screen.getByTestId('monthlyChargesModal');
    expect(monthlyChargesModal).toBeInTheDocument();

    const titleElement = screen.getByText('Monthly Charges for your other 1 lines');
    expect(titleElement).toBeInTheDocument();
  });

  test('renders modal with no Other line charges', async () => {
    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: { data: mockOtherLineChargesResult(), status: 'uninitialized' },
    }));
    const lineInfo = [{ mobileNumber: '1234567890' }];
    render(<MonthlyChargesModal opened toggleModal={() => {}} lineInfo={lineInfo} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    screen.debug();
    expect(mockGetOtherLineCharges).toHaveBeenCalled();
  });

  test('Line info uninitialized status', () => {
    const lineInfo = [{ mobileNumber: '1234567890' }];
    const monthlyCharges = [{ itemType: 'EQUIPMENT', description: 'Monthly Plan Charge', thisMonthCharge: 100 }];

    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: { data: mockOtherLineChargesResult({ monthlyCharges }) },
    }));
    render(<MonthlyChargesModal opened toggleModal={() => {}} lineInfo={lineInfo} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    const phoneNumberElement = screen.getByText(/123-456-7890/i);
    expect(phoneNumberElement).toBeInTheDocument();

    const planChargeElement = screen.getByText(/Monthly Plan Charge/i);
    expect(planChargeElement).toBeInTheDocument();
    const thisMonthCharge = screen.getByTestId('monthlyCharges');
    expect(thisMonthCharge.textContent).toEqual('$100.00');

    const totalChargesElement = screen.getByText(/Total/i);
    expect(totalChargesElement).toBeInTheDocument();

    const totalAmountElement = screen.getByTestId('total-amount');
    expect(totalAmountElement.textContent).toEqual('$50.00');

    const itemTypeElement = screen.getByTestId('itemType');
    expect(itemTypeElement.textContent).toEqual('Equipment Charges');
  });

  test('displays one time charge items correctly', () => {
    const lineInfo = [{ mobileNumber: '1234567890' }];
    const mockOneTimeCharges = [{ description: 'One Time Charges', thisMonthCharge: 70 }];

    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: { data: mockOtherLineChargesResult({ oneTimeCharges: mockOneTimeCharges }) },
    }));

    render(<MonthlyChargesModal opened toggleModal={() => {}} lineInfo={lineInfo} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    const planChargeElement = screen.getByText(/One Time Charges/i);
    expect(planChargeElement).toBeInTheDocument();
    const thisMonthCharge = screen.getByTestId('oneTimeCharges');
    expect(thisMonthCharge.textContent).toEqual('$70.00');
  });

  test('displays one time charge items correctly', () => {
    const lineInfo = [{ mobileNumber: '1234567890' }];
    const mockAddOnsCharges = [{ description: 'Add On Charges', thisMonthCharge: 80 }];
    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: { data: mockOtherLineChargesResult({ addOnsCharges: mockAddOnsCharges }) },
    }));

    render(<MonthlyChargesModal opened toggleModal={() => {}} lineInfo={lineInfo} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    const planChargeElement = screen.getByText(/Add On Charges/i);
    expect(planChargeElement).toBeInTheDocument();
    const thisMonthCharge = screen.getByTestId('addOnsCharges');
    expect(thisMonthCharge.textContent).toEqual('$80.00');
  });

  test('isDark true', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] ,isDark: true, themeProps: {background: '#eeeeee'}};
    const lineInfo = [{ mobileNumber: '1234567890' }];
    const mockAddOnsCharges = [{ description: 'Add On Charges', thisMonthCharge: 80 }];
    jest.spyOn(monthlyChargesApiCallHook, 'default').mockImplementation(() => ({
      getOtherLineCharges: mockGetOtherLineCharges,
      otherLineChargesResult: { data: mockOtherLineChargesResult({ addOnsCharges: mockAddOnsCharges }) },
    }));

    render(<MonthlyChargesModal opened toggleModal={() => {}} lineInfo={lineInfo} isDark/>, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

  });
});
