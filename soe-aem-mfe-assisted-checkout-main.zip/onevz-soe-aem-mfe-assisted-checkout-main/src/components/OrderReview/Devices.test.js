import { render, screen, fireEvent } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../modules/store';
import cartJson from '../../__mock__/retrive-cart.json';
import Devices from './Devices';

describe('Devices Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  test('renders Devices', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const monthlyInstallmentAmount = line?.installmentInfo?.monthlyInstallment || 0;
    const handleViewDevices = jest.fn();
    render(
      <BrowserRouter>
        <StoreProvider>
          <Devices
            line={line}
            element={element}
            monthlyInstallmentAmount={monthlyInstallmentAmount}
            handleViewDevices={handleViewDevices}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getByTestId('devices');
    expect(titleElement).toBeInTheDocument();
  });

  test('renders modal', () => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const monthlyInstallmentAmount = line?.installmentInfo?.monthlyInstallment || 0;
    const handleViewDevices = jest.fn();
    render(
      <BrowserRouter>
        <StoreProvider>
          <Devices
            line={line}
            element={element}
            monthlyInstallmentAmount={monthlyInstallmentAmount}
            handleViewDevices={handleViewDevices}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const viewBtn = screen.getByTestId('view-devices');
    expect(viewBtn).toBeInTheDocument();
    fireEvent.click(viewBtn, {});
  });

  test('Modal close click', async () => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const monthlyInstallmentAmount = line?.installmentInfo?.monthlyInstallment || 0;
    const handleViewDevices = jest.fn();

    render(
      <BrowserRouter>
        <StoreProvider>
          <Devices
            line={line}
            element={element}
            monthlyInstallmentAmount={monthlyInstallmentAmount}
            handleViewDevices={handleViewDevices}
          />
        </StoreProvider>
      </BrowserRouter>,
    );
    const viewBtn = screen.getByTestId('view-devices');
    expect(viewBtn).toBeInTheDocument();
    fireEvent.click(viewBtn, {});
  });

  test('selling price', () => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    delete element.discountedPrice;
    const monthlyInstallmentAmount = line?.installmentInfo?.monthlyInstallment || 0;
    const handleViewDevices = jest.fn();

    render(
      <BrowserRouter>
        <StoreProvider>
          <Devices
            line={line}
            element={element}
            monthlyInstallmentAmount={monthlyInstallmentAmount}
            handleViewDevices={handleViewDevices}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const titleElement = screen.getByTestId('devices');
    expect(titleElement).toBeInTheDocument();
  });

  test('item price', () => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    delete element.discountedPrice;
    delete element.sellerPrice;
    const monthlyInstallmentAmount = line?.installmentInfo?.monthlyInstallment || 0;
    const handleViewDevices = jest.fn();

    render(
      <BrowserRouter>
        <StoreProvider>
          <Devices
            line={line}
            element={element}
            monthlyInstallmentAmount={monthlyInstallmentAmount}
            handleViewDevices={handleViewDevices}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const titleElement = screen.getByTestId('devices');
    expect(titleElement).toBeInTheDocument();
  });

  test('Line Access', () => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    delete element.discountedPrice;
    delete element.sellerPrice;
    const monthlyInstallmentAmount = line?.installmentInfo?.monthlyInstallment || 0;
    const handleViewDevices = jest.fn();

    render(
      <BrowserRouter>
        <StoreProvider>
          <Devices
            line={line}
            element={element}
            monthlyInstallmentAmount={monthlyInstallmentAmount}
            handleViewDevices={handleViewDevices}
            planDetail={{ isJaxPlan: false }}
            lineAccessFee={234}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    // expect(screen.getByText(/Line access/i)).toBeInTheDocument();
    expect(screen.getByText(/1st Device Payment/i)).toBeInTheDocument();
    expect(screen.getByText(/25.94/i)).toBeInTheDocument();
    // expect(screen.getByText(/234.00/i)).toBeInTheDocument();
  });

  test('Empty Wrapper for Full Retail', () => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    delete line.installmentInfo;
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const monthlyInstallmentAmount = line?.installmentInfo?.monthlyInstallment || 0;
    const handleViewDevices = jest.fn();

    render(
      <BrowserRouter>
        <StoreProvider>
          <Devices
            line={line}
            element={element}
            monthlyInstallmentAmount={monthlyInstallmentAmount}
            handleViewDevices={handleViewDevices}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    expect(screen.getByTestId('empty-wrapper')).toBeInTheDocument();
  });
  test('isDark false', () => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    delete line.installmentInfo;
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    const monthlyInstallmentAmount = line?.installmentInfo?.monthlyInstallment || 0;
    const handleViewDevices = jest.fn();
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: false, themeProps: { background: '#eeeeee' } };

    render(
      <BrowserRouter>
        <StoreProvider>
          <Devices
            line={line}
            element={element}
            monthlyInstallmentAmount={monthlyInstallmentAmount}
            handleViewDevices={handleViewDevices}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    expect(screen.getByTestId('empty-wrapper')).toBeInTheDocument();
  });
  test('DFO true price', () => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    const cartItems = line?.itemsInfo[0]?.cartItems ? line.itemsInfo[0].cartItems : {};
    const element = cartItems?.cartItem?.filter((item) => item.cartItemType === 'DEVICE')[0];
    delete element.discountedPrice;
    delete element.sellerPrice;
    const monthlyInstallmentAmount = line?.installmentInfo?.monthlyInstallment || 0;
    const handleViewDevices = jest.fn();
    element.isDfoSelected = true;
    element.eMIVerizonPayment = 'hello';
    render(
      <BrowserRouter>
        <StoreProvider>
          <Devices
            line={line}
            element={element}
            monthlyInstallmentAmount={monthlyInstallmentAmount}
            handleViewDevices={handleViewDevices}
          />
        </StoreProvider>
      </BrowserRouter>,
    );

    const titleElement = screen.getByTestId('devices');
    expect(titleElement).toBeInTheDocument();
  });
});
