import { render, screen, fireEvent } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
// import * as assisstedCradle from 'onevzsoemfeframework/AssistedCradleService';
import StoreProvider from '../../modules/store';
import cartJson from '../../__mock__/retrive-cart.json';
import SharedDetailsModal from './SharedDetailsModal';
import { scmCheckoutMfeEnabled } from '../../utils/common';

const mockToggleModal = jest.fn();

window = Object.create(window);
const url = 'http://localhost';
Object.defineProperty(window, 'location', {
  value: {
    href: url,
  },
  writable: true, // possibility to override
});
jest.mock('../../utils/common');
describe('AccountDetailsModal Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  const pricedSnapshot = {
    shared: {
      addons: [
        {
          sorId: '732',
          skuName: 'CDMA-LESS ROAM TIER OVERRIDE',
          type: 'SPO',
          isSPO: true,
          actionIndicator: 'Z',
          isExisting: true,
          price: {
            regularPrice: 0,
            discountedPrice: 0,
            actualDiscount: 0,
            promos: [],
          },
          isGeneralAddon: true,
          isDisplayable: true,
          isNotRemovable: true,
          isPerk: false,
          spoMethodCode: 'A',
        },
        {
          sorId: '732',
          skuName: 'CDMA-LESS ROAM TIER OVERRIDE',
          type: 'SPO',
          isSPO: true,
          actionIndicator: 'A',
          isExisting: true,
          price: {
            regularPrice: 0,
            discountedPrice: 0,
            actualDiscount: 0,
            promos: [],
          },
          isGeneralAddon: true,
          isDisplayable: true,
          isNotRemovable: true,
          isPerk: false,
          spoMethodCode: 'A',
        },
        {
          sorId: '732',
          skuName: 'CDMA-LESS ROAM TIER OVERRIDE',
          type: 'SPO',
          isSPO: true,
          actionIndicator: 'D',
          isExisting: true,
          price: {
            regularPrice: 0,
            discountedPrice: 0,
            actualDiscount: 0,
            promos: [],
          },
          isGeneralAddon: true,
          isUserSelected: true,
          isNotRemovable: true,
          isPerk: false,
          spoMethodCode: 'A',
        },
      ],
    },
  };
  const renderComponent = (orderDetails = cartJson.data.cart.orderDetails) => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <SharedDetailsModal
            orderDetails={orderDetails}
            opened
            toggleModal={mockToggleModal}
            pricedSnapshot={pricedSnapshot}
          />
        </StoreProvider>
      </BrowserRouter>
    );
  };
  test('renders shareDetails', () => {
    scmCheckoutMfeEnabled.mockImplementation(() => true);
    renderComponent();
    const titleElement = screen.getByTestId('sharedDetailsModal');
    expect(titleElement).toBeInTheDocument();
  });
  test('Modal done click', async () => {
    renderComponent();
    const DoneBtn = screen.getByText(/Done/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
    expect(mockToggleModal).toHaveBeenCalledWith(false);
  });
  test('Modal Change Plans click with isPrepay false', async () => {
    scmCheckoutMfeEnabled.mockImplementation(() => false);
    renderComponent();
    const DoneBtn = screen.getByText(/Add shared Services & perks/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
    expect(window.location.href).toBe(`/sales/assisted/landing.html`);
  });
  jest.mock('onevzsoemfecommon/Helpers', () => ({
    getQueryParamByName: jest.fn(() => ({
      isByodUpdate: true,
    })),
    getUIContextPath: jest.fn(() => {}),
    getUIContextPathBAU: jest.fn(() => {}),
  }));
  test('Modal Change effective date click', async () => {
    renderComponent();
    const DoneBtn = screen.getByTestId('change-date');
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
    expect(window.location.href).toBe(`/sales/assisted/home.html`);
  });
  test('Validate showRemoveFeature', async () => {
    renderComponent();
    const ShowBtn = screen.getByTestId('show-feature');
    expect(ShowBtn).toBeInTheDocument();
    fireEvent.click(ShowBtn, {});
    const HideBtn = screen.getByTestId('hide-feature');
    expect(HideBtn).toBeInTheDocument();
    fireEvent.click(HideBtn, {});
    expect(screen.getByTestId('show-feature')).toBeInTheDocument();
  });
});
describe('AccountDetailsModal Component 2', () => {
  beforeAll(() => {});
  const pricedSnapshot = {
    shared: {
      addons: [
        {
          sorId: '732',
          skuName: 'CDMA-LESS ROAM TIER OVERRIDE',
          type: 'SPO',
          isSPO: true,
          actionIndicator: 'Z',
          isExisting: true,
          price: {
            regularPrice: 0,
            discountedPrice: 0,
            actualDiscount: 0,
            promos: [],
          },
          isGeneralAddon: true,
          isDisplayable: true,
          isNotRemovable: true,
          isPerk: false,
          spoMethodCode: 'A',
        },
        {
          sorId: '732',
          skuName: 'CDMA-LESS ROAM TIER OVERRIDE',
          type: 'SPO',
          isSPO: true,
          actionIndicator: 'A',
          isExisting: true,
          price: {
            regularPrice: 0,
            discountedPrice: 0,
            actualDiscount: 0,
            promos: [],
          },
          isGeneralAddon: true,
          isDisplayable: true,
          isNotRemovable: true,
          isPerk: false,
          spoMethodCode: 'A',
        },
        {
          sorId: '732',
          skuName: 'CDMA-LESS ROAM TIER OVERRIDE',
          type: 'SPO',
          isSPO: true,
          actionIndicator: 'D',
          isExisting: true,
          price: {
            regularPrice: 0,
            discountedPrice: 0,
            actualDiscount: 0,
            promos: [],
          },
          isGeneralAddon: true,
          isUserSelected: true,
          isNotRemovable: true,
          isPerk: false,
          spoMethodCode: 'A',
        },
      ],
    },
  };
  const renderComponent = (orderDetails = cartJson.data.cart.orderDetails) => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <SharedDetailsModal
            orderDetails={orderDetails}
            opened
            toggleModal={mockToggleModal}
            pricedSnapshot={pricedSnapshot}
          />
        </StoreProvider>
      </BrowserRouter>
    );
  };
  test('Modal Change Plans click with isPrepay false', async () => {
    scmCheckoutMfeEnabled.mockImplementation(() => true);
    console.log(scmCheckoutMfeEnabled);
    window.Emitter = { emit: jest.fn() };
    renderComponent();
    const DoneBtn = screen.getByText(/Add shared Services & perks/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
  });

  test('isDark true', async () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], isDark: true, themeProps: { background: '#eeeeee' } };
    scmCheckoutMfeEnabled.mockImplementation(() => true);
    console.log(scmCheckoutMfeEnabled);
    window.Emitter = { emit: jest.fn() };
    renderComponent();
    const DoneBtn = screen.getByText(/Add shared Services & perks/i);
    expect(DoneBtn).toBeInTheDocument();
    fireEvent.click(DoneBtn, {});
  });
});
