import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import ModalHeader from './index';

describe('ModalHeader Component', () => {
  const mockCloseModal = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('renders ModalHeader component with only close icon', () => {
    render(<ModalHeader closeModal={mockCloseModal} backCloseModal={jest.fn()} isOnlyClose modalTitle='Test Title' />);
  });

  test('renders ModalHeader component with title and left icon', () => {
    render(
      <ModalHeader
        closeModal={mockCloseModal}
        backCloseModal={mockCloseModal}
        isOnlyClose={false}
        modalTitle='Test Title'
      />,
    );

    expect(screen.getByTestId('left-icon')).toBeInTheDocument();
    expect(screen.getByText('Test Title')).toBeInTheDocument();
  });

  test('calls closeModal when left icon is clicked', () => {
    render(
      <ModalHeader
        closeModal={mockCloseModal}
        backCloseModal={mockCloseModal}
        isOnlyClose={false}
        modalTitle='Test Title'
      />,
    );

    const leftIcon = screen.getByTestId('left-icon');
    fireEvent.click(leftIcon);

    expect(mockCloseModal).toHaveBeenCalled();
  });

  test('left icon is focusable and triggers closeModal on key press', () => {
    render(<ModalHeader closeModal={mockCloseModal} isOnlyClose={false} modalTitle='Test Title' />);

    const leftIcon = screen.getByTestId('left-icon');
    leftIcon.focus();
    fireEvent.keyDown(leftIcon, { key: 'Enter', code: 'Enter' });
  });
});
