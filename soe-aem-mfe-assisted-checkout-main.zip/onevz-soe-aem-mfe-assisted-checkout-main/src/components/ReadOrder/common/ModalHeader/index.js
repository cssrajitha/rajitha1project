import PropTypes from 'prop-types';
import styled from 'styled-components';
import { Title } from '@vds/typography';
import { Icon } from '@vds/icons';

function ModalHeader(props) {
  const { closeModal, backCloseModal, isOnlyClose, modalTitle } = props;

  return (
    <StyleFullpageMainTitle>
      {isOnlyClose ? (
        <StyledFullPageModalTitle>
          <div style={{ width: '100%', display: 'flex' }}>
            {modalTitle && (
              <Title data-testid='renderApplywithPrequal_Label' color='black' bold size='small'>
                {modalTitle}
              </Title>
            )}
            <StyledCol onClick={closeModal} data-track='activationStatus_Close'>
              <Icon name='close' size='large' id='close-Icon' />
            </StyledCol>
          </div>
        </StyledFullPageModalTitle>
      ) : (
        <StyledFullPageModalTitle className='common-header-container'>
          <LinkPointer data-testid='left-icon' tabIndex='0' onClick={backCloseModal} data-track='PageHeader-back'>
            <Icon name='left-caret' size='XLarge' color='#000000' />
          </LinkPointer>
          <div style={{ marginLeft: 20, borderLeft: '3px solid #000000' }}>
            <div style={{ marginLeft: 20 }}>
              <Title data-testid='renderApplywithPrequal_Label' color='black' bold size='small'>
                {modalTitle}
              </Title>
            </div>
          </div>
          {closeModal && (
            <StyledCol onClick={closeModal}>
              <Icon name='close' size='large' id='close-Icon' />
            </StyledCol>
          )}
        </StyledFullPageModalTitle>
      )}
    </StyleFullpageMainTitle>
  );
}

ModalHeader.propTypes = {
  modalTitle: PropTypes.string,
  isOnlyClose: PropTypes.bool,
  closeModal: PropTypes.func,
  backCloseModal: PropTypes.func,
};

export default ModalHeader;

const StyleFullpageMainTitle = styled.div`
  padding: 15px 0px 15px 0px;
`;

const StyledFullPageModalTitle = styled.div`
  position: relative;
  text-align: left;
  display: flex;
  border-bottom: 1px solid gray;
  .backbutton {
    margin: 20px;
    border: 1px solid red;
  }
  h1 {
    font-weight: 600;
    font-size: 18px;
    font-family: BrandFontBold, sans-serif !important;
  }
  padding-bottom: 15px;
  font-weight: bold;
`;

const StyledCol = styled.div`
  margin-left: auto;
  float: right;
`;

const LinkPointer = styled.a`
  cursor: pointer !important;
  text-decoration: none;
  color: #000000;
  &:focus {
    outline: 1px dotted #000000 !important;
  }
`;
