import { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { Button } from '@vds/buttons';
import { Modal } from '@vds/modals';
import { useNavigate } from 'react-router-dom';
import { isIpad } from 'onevzsoemfeframework/DomService';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import { ViewExitDialog } from 'onevzsoemfecommon/ViewExitDialog';
import { userRole } from '../constants';
import AgreementsAPICallHook from '../../../modules/services/APIService/AgreementsAPICallHook';
import { useLazyRetrieveRemarksQuery } from '../../../modules/services/APIService/APIServiceHooks';
// import { useLazyGetReadOrderQuery } from '../../../modules/services/APIService/APIServiceCallHook';
import ActivationStatus from '../ActivationStatus';

import { invokeTagging } from '../../../utils/test-utils/utils';

const allowOnlyNumbers = (value) => {
  const rE = /^[0-9\b]+$/;
  return value === '' || rE.test(value);
};
function FooterReadOrder(props) {
  const { readOrderData, cartDataRsp, customerProfileRsp, selectedReviewMode, viewdiscountOpen, isQAClosedOrder,cartDetailsResult,
    paperLessBilling, landing,customerProfile
   } =
    props;
    
  const channel = sessionStorage.getItem('channel');
  const isQAFlow = getQueryParamByName('isQAFlow') || false;
  const cartId = readOrderData?.cart?.cartHeader?.cartId;
  const orderList = readOrderData?.cart?.orderDetails?.orderList || [];
  const orderNumbers = orderList.map((order) => order.orderNumber).filter((orderNumber) => orderNumber !== 0);
  const orderNumber = isQAClosedOrder ? getQueryParamByName('orderNumber') : orderNumbers?.join('/');
  const [showCloseComponent, setShowCloseComponent] = useState(false);
  const [orderConfirmation, setOrderConfirmation] = useState(false);
  const [showCloseModal, setShowCloseModal] = useState(true);
  const [retrieveRemarks, retrieveRemarksRsp] = useLazyRetrieveRemarksQuery();
  const [remarkDesc, setRemarkDesc] = useState([]);
  const [showActivationModal, setShowActivationModal] = useState(false);
  const [indirectNewCustomerIncompleteOrder, setIndirectNewCustomerIncompleteOrder] = useState(false);
  const checkLovEligibility =
  !isQAFlow && channel?.includes('OMNI-RETAIL') &&
    /true/i.test(JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.vtReadOrderForRetailFFlag);
  const isViewOnlyOrder = getQueryParamByName('viewOnlyOrder') === 'true';
  const [isNewCustomer,setIsNewCustomer] = useState(false);
  const [previousEmail, setPreviousEmail] = useState('');
  const {
    getOrderWrite,
    getOrderWriteResult
  } = AgreementsAPICallHook();

  let navigate = '';
  function useNavigateMFE() {
    navigate = useNavigate();
  }

  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }

  useEffect(() => {
    if (readOrderData?.cart) {
      const cartData = readOrderData?.cart;
      const customerType = cartData?.orderDetails?.customerType;
      const email = cartData?.orderDetails?.spocs?.notificationOptions?.primaryEmailId;
      const depletionType = cartData?.lineDetails?.lineInfo?.[0]?.itemsInfo?.[0]?.depletionType;
      const isIncompleteOrder = readOrderData?.orderStatus !== 'CO';
      const showBannerForEmailSkipFFlag = /true/i.test(
        JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.showBannerForEmailSkipFFlag,
      );
      const isNSECustomer = !readOrderData?.cart?.cartHeader?.cartCreator;
      if(isQAFlow && isNSECustomer){
        setIsNewCustomer(true);
      }
      if (
        customerType === 'N' &&
        email === '' &&
        depletionType === 'L' &&
        isIncompleteOrder &&
        showBannerForEmailSkipFFlag
      ) {
        setIndirectNewCustomerIncompleteOrder(true);
      }
      const cartid = cartData?.cartId;
      const req = {
        meta: {
          function: 'retrieveRemarks',
          cartid,
        },
      };
      retrieveRemarks({ body: req, mock: false });
    }
  }, [readOrderData?.cart]);

  useEffect(() => {
    if (retrieveRemarksRsp?.status === 'fulfilled' && retrieveRemarksRsp?.data?.data) {
      // set remarks desc
      const remarkLst = retrieveRemarksRsp?.data?.data?.[0]?.remarks || [];
      const desc = remarkLst?.filter((rmks) => rmks?.description?.includes('Order Placed on Confirmation Hold'));
      setRemarkDesc(desc);
    }
  }, [retrieveRemarksRsp?.data]);

  useEffect(() => {
    const currentEmail = cartDetailsResult?.data?.cart?.orderDetails?.spocs?.notificationOptions?.primaryEmailId;
      setPreviousEmail(currentEmail);

    if (isQAFlow && getOrderWriteResult?.data) {
          navigate(`/sales/assisted/new/payment-agreement.html?isQAFlow=true`);
    }
  }, [getOrderWriteResult?.data]);

  const readOrderLovEligibilityCheck = () => {
    let isLovEligible = checkLovEligibility;

    if (checkLovEligibility) {
      sessionStorage.setItem('viewTogetherEnabled', 'true');
    } else {
      isLovEligible = false;
    }

    if (cartDataRsp?.orderDetails?.orderType === 'IS') {
      isLovEligible = false;
    }
    return isLovEligible && checkLovEligibility;
  };

  const getLiveReviewText = (text) => {
    const isVTEnabled = sessionStorage.getItem('viewTogetherEnabled');
    let txt = text;
    if (isVTEnabled === 'true') {
      const regeX = /Live Review/i;
      txt = text.replace(regeX, 'View Together');
    }
    return txt;
  };

  const processStepBtn = () => {
    if (isQAClosedOrder) {
      return 'Close';
    }
    const loggedInUserRole = readOrderData?.loggedInUserRole;
    const orderStatus = readOrderData?.orderStatus;
    const processStp = readOrderData?.processStep;
    const processStepText = processStp ? processStp.charAt(0) + processStp.slice(1).toLowerCase() : 'Close';
    let Btn =
      readOrderLovEligibilityCheck() && selectedReviewMode === '' && orderStatus !== 'CO'
        ? getLiveReviewText('Live Review')
        : processStepText;
    Btn =
      indirectNewCustomerIncompleteOrder ||
      isViewOnlyOrder ||
      (!userRole.includes(loggedInUserRole) && remarkDesc?.length > 0)
        ? 'Close'
        : Btn;
    return Btn;
  };

  const handleButtonClick = () => {
    if (processStepBtn() === 'Close') {
      setShowCloseComponent(true);
      setOrderConfirmation(true);
      setShowCloseModal(true);
      invokeTagging('openView', 'Close');
    } else {
      allSetDone();
    }
  };

  const continueBtnRO = () => {
    // we can directly route to PA
    const geoFenceResponse =
      sessionStorage.getItem('geoFenceResponse') && JSON.parse(sessionStorage.getItem('geoFenceResponse'));
    const inGeoFenceRange =
      geoFenceResponse?.geoFenceCheck === 'false' && geoFenceResponse?.reason?.toLowerCase() === 'out of range';
    const outOfGeoFenceObj = {
      outOfGeoFence: inGeoFenceRange,
      ipadLatitude: geoFenceResponse?.ipadLatitude,
      ipadLongitude: geoFenceResponse?.ipadLongitude,
      storeName: JSON.parse(sessionStorage.getItem('STORE-LOCATION-DETAIL'))?.data?.storeInfo?.storeName,
    };

    
    const activeMtn = cartDetailsResult?.data?.cart?.cartHeader?.cartCreator ?? '';
    const customerType =
    cartDetailsResult?.data?.cart?.orderDetails?.customerType || sessionStorage.getItem('customerType');
    // const {customer} = customerProfileRsp;
    console.log(customerProfile);
    
    const customerN = customerProfile?.customer;
    const creditAppNum = getQueryParamByName('creditAppNum') || sessionStorage.getItem('creditAppNum');
    const currentEmail = cartDetailsResult?.data?.cart?.orderDetails?.spocs?.notificationOptions?.primaryEmailId;
    const emailId = cartDetailsResult?.data?.cart?.orderDetails?.spocs?.notificationOptions?.primaryEmailId ?? '';
    
    let isServiceWriteRequired = false;
    if (currentEmail !== previousEmail) {
      isServiceWriteRequired = true;
    }
    const response = sessionStorage.getItem('responseList');
    const responseList = JSON.parse(response);
    const responses = responseList?.filter((res) => res.dispositionOptionId === '18');
    const resList = responses?.map((res) => ({
      rank: res?.rank ? res.rank : '',
      propositionId: res?.propositionId ? res.propositionId : '',
      soiEngagementId: res?.soiEngagementId ? res.soiEngagementId : '',
      offerContainerId: res?.offerContainerId ? res.offerContainerId : '',
    }));
    const quoteId = cartDetailsResult?.data?.cart?.quote?.quoteId ?? '';
    const currentQuoteId = () => {
      const activeCartId = customerN?.cartId ?? '';
      const isQuoteDetailsAvailable = landing?.quoteDetails ?? [];
      if (isQuoteDetailsAvailable.length > 0) {
        const currentQuote = isQuoteDetailsAvailable.filter((item) => item.cartId === activeCartId);
        return currentQuote.length > 0 ? currentQuote[0].quoteId : '';
      }
      return '';
    };
    const billingSystem = cartDetailsResult?.data?.cart?.orderDetails?.billingSystem || '';
   
    const params = {
      mtn: activeMtn && allowOnlyNumbers(activeMtn) ? activeMtn : '',
      locationCode: cartDetailsResult?.data?.cart?.orderDetails?.locationCode ?? '',
      accountNumber: customerN?.accountNo,
      cartId: cartDetailsResult?.data?.cart?.cartHeader?.cartId ?? '',
      cartCreator:
        customerType && customerType === 'N'
          ? creditAppNum
          : (cartDetailsResult?.data?.cart?.cartHeader?.cartCreator ?? ''),
      caseId: cartDetailsResult?.data?.cart?.cartHeader?.caseId ?? '',
      creditAppNum: customerType === 'N' ? creditAppNum : '',
      serviceWriteRequired: isServiceWriteRequired,
      smsDestination: '',
      email: emailId ?? '',
      intent: customerType && customerType === 'N' ? 'NSE' : '',
      paperlessIndicator: customerType && customerType === 'N' ? paperLessBilling : null,
      paperLessEmail: customerType && customerType === 'N' && paperLessBilling ? emailId : null,
      header: {
        cartId: cartDetailsResult?.data?.cart?.cartHeader?.cartId ?? '',
      },
      responseList: resList,
      regNo: (customerN?.regNo ?? isIpad()) ? '51' : '10',
      quoteId: quoteId !== '' && quoteId !== '0000' ? quoteId : currentQuoteId(),
      purchaseOrderNumber: '',
      billingSystem,
      ...(inGeoFenceRange && { ...outOfGeoFenceObj }),
    };
    if (
      params.email === '' ||
      params.email === cartDetailsResult?.data?.cart?.orderDetails?.spocs?.notificationOptions?.primaryEmailId
    ) {
      params.serviceWriteRequired = false;
    }
    const appProperties = JSON.parse(sessionStorage.getItem('APP_PROPERTIES')) || {};
    const isMitekSimSwapEnabled = appProperties?.isMitekSimSwapEnabled === 'TRUE';
    const locationData = JSON.parse(sessionStorage.getItem('locationData'));

    if (isMitekSimSwapEnabled) {
      params.storeCity = locationData?.city ?? '';
      params.storeState = locationData?.state ?? '';
    }
  getOrderWrite({
    body: params,
    spinner: true,
    mock: false,
  });

    
  }

  const allSetDone = () => {
    const msfToNsaQAFFlag =
    /true/i.test(JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.msfToNsaQuickAccessoriesFFlag) || false;
    const processStep = readOrderData?.processStep;
    if (processStep === 'ACTIVATE') {
      invokeTagging('openView', 'activationStatus');
      setShowActivationModal(true);
    } else if(msfToNsaQAFFlag && isQAFlow && processStep === 'CONTINUE' ){
      continueBtnRO()
    }
  };

  return (
    <div className='footer-read-order'>
      <FixedFooter viewdiscountOpen={viewdiscountOpen}>
        <CenteredBox>
          <Button
            data-testid='process-step-btn'
            data-track={processStepBtn() === 'ACTIVATE' && 'Activate'}
            onClick={handleButtonClick}
          >
            {processStepBtn()}
          </Button>
        </CenteredBox>
      </FixedFooter>

      {showActivationModal && (
        <Modal
          opened={showActivationModal}
          onClose={() => setShowActivationModal(false)}
          fullScreenDialog
          disableOutsideClick
          closeButton={null}
          disableAnimation
        >
          <ActivationStatus
            cartData={cartDataRsp}
            closeActivationStatus={() => setShowActivationModal(false)}
            viewOnlyActivationStatusFlag={false}
            customerProfile={customerProfileRsp}
            readOrderData={readOrderData}
          />
        </Modal>
      )}
      {showCloseComponent && (
        <ViewExitDialog
          orderConfirmation={orderConfirmation}
          orderNumber={orderNumber}
          showCloseModal={showCloseModal}
          setShowCloseModal={setShowCloseModal}
          enableLead
          processStep='ShoppingCart'
          cartId={cartId}
          isNewCustomer={isNewCustomer}
        />
      )}
    </div>
  );
}

FooterReadOrder.propTypes = {
  cartDetailsResult: PropTypes.object,
  readOrderData: PropTypes.object,
  cartDataRsp: PropTypes.object,
  customerProfileRsp: PropTypes.object,
  selectedReviewMode: PropTypes.string,
  viewdiscountOpen: PropTypes.bool,
  isQAClosedOrder: PropTypes.bool,
  paperLessBilling: PropTypes.string,
  landing: PropTypes.object,
  customerProfile: PropTypes.object,
};

export default FooterReadOrder;

const CenteredBox = styled.div`
  margin: auto;
  padding: 21px;
`;

const FixedFooter = styled.footer`
  position: fixed;
  bottom: 0px;
  text-align: center;
  width: 100%;
  border-top: 1px solid #d8dada !important;
  left: ${(props) => (props.viewdiscountOpen ? '10%' : '0px')};
  right: 0;
  display: inline-flex;
  background-color: #fff;
  z-index: ${(props) => (props.viewdiscountOpen ? 0 : 1)};
  max-width: ${(props) => (props.viewdiscountOpen ? 'calc(62.25rem)' : '100%')};
`;
