/* eslint-disable */
import { fireEvent, render, screen } from '../../../utils/test-utils/renderHelper';
import { rootSaga } from '../../../modules/store/saga';
import rootReducer from '../../../modules/store/reducer';
import FooterReadOrder from './index';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import { useLazyRetrieveRemarksQuery,useLazyUpdateShippingAddressAndOptionsQuery,useLazyGetAccountAddressesQuery,useLazyValidateAddressQuery } from '../../../modules/services/APIService/APIServiceHooks';
import { useLazyGetOrderWriteQuery,
         useLazyGetRetrieveInstallmentAgreementQuery,
         useLazyPostRetrieveAemInfoManagerDataQuery,
         useUpdateAFOInfoMutation,
         useLazyGetCustomerByMtnsQuery
 } from '../../../modules/services/APIService/APIServiceCallHook';
 import cartJson from '../../../__mock__/retrive-cart.json';
 import cartJsonNew from '../../../__mock__/retrive-cart-new.json';

jest.mock('../../../modules/services/APIService/APIServiceHooks', () => ({
  useLazyRetrieveRemarksQuery: jest.fn(),
  useLazyGetAccountAddressesQuery: jest.fn(),
  useLazyValidateAddressQuery: jest.fn(),
  useLazyUpdateShippingAddressAndOptionsQuery: jest.fn(),
}));

jest.mock('../../../modules/services/APIService/APIServiceCallHook', () => ({
  useLazyGetOrderWriteQuery: jest.fn().mockResolvedValue({ data: { data: { cart: {} } } }),
  useLazyGetRetrieveInstallmentAgreementQuery: jest.fn(),
  useLazyPostRetrieveAemInfoManagerDataQuery: jest.fn(),
  useUpdateAFOInfoMutation: jest.fn(),
  useLazyGetCustomerByMtnsQuery: jest.fn(),
}));

jest.mock('@vds/modals', () => ({
  ...jest.requireActual('@vds/modals'),
  // eslint-disable-next-line react/button-has-type, react/prop-types
  Modal: ({ children, ...props }) => (
    // eslint-disable-next-line react/prop-types
    <div {...props} data-testid={props.id}>
      {children}
    </div>
  ),
}));

jest.mock('../ActivationStatus', () => {
  return ({ closeActivationStatus }) => {
    closeActivationStatus();
    return <div>Activation status...</div>;
  };
});


jest.mock('onevzsoemfecommon/Helpers', () => ({
  getQueryParamByName: jest.fn(),
}));

describe('FooterReadOrder Component', () => {
  let retrieveRemarksMock;
  let accountAddressesMock;
  let validateAddressMock;
  let updateShippingAddressMock;
  let orderWriteMock;
  let retrieveInstallmentAgreementMock;
  let postRetrieveAemInfoManagerDataMock;
  let updateAFOInfoMutationMock;
  let getCustomerByMtnsMock;

  beforeEach(() => {
    retrieveInstallmentAgreementMock = jest.fn();
    postRetrieveAemInfoManagerDataMock = jest.fn();
    updateAFOInfoMutationMock = jest.fn();
    getCustomerByMtnsMock = jest.fn();
    const orderWriteResponse = {
      data: {
        fivegOrder: 'false',
        edgeOrder: 'false',
        mgrApprovalReq: 'false',
        twoYear: 'false',
        customerAgreement: 'false',
        renderType: 'html',
        creditApp: '',
        billingSys: 'VE',
        fullAccountNumber: '0000000000-00000',
        salesRep: 'ENC01',
        btaEligibleAmount: '',
        btaEligible: 'false',
        orderNum: '',
        locationCode: '',
        orderDetails: [
          {
            orderType: 'RF',
            orderNum: '12001282',
            orderTotal: '776.34',
            orderBalanceAmount: '776.34',
            digitalOrderId: '0',
            preOrderNumber: '',
            creditApplicationNum: '',
            fullAuthSuccess: false,
          },
        ],
        paymentOptions: [],
        mobileNumber: '6319428060',
        processStep: 'Payment-Agreement',
        status: 0,
        fullAuthCounterErrorCount: 0,
        availablePaths: [
          {
            path: 'DevicePaymentAgreement',
          },
        ],
        confirmationRedesign: false,
        bookSdrAppointmentErrorMessage: '',
        eligibilityEnabled: true,
      },
    };
    getQueryParamByName.mockReturnValue('isQAFlow');
    getQueryParamByName.mockReturnValue('creditAppNum');
    retrieveRemarksMock = jest.fn();
    useLazyRetrieveRemarksQuery.mockReturnValue([
      retrieveRemarksMock,
      {
        status: 'fulfilled',
        data: {
          data: [
            {
              remarks: [{ description: 'Order Placed on Confirmation Hold' }],
            },
          ],
        },
      },
    ]);
    accountAddressesMock = jest.fn();
    useLazyGetAccountAddressesQuery.mockReturnValue([
      accountAddressesMock,
      {
        status: 'fulfilled',
        data: {
          data: [
            {
              remarks: [{ description: 'Order Placed on Confirmation Hold' }],
            },
          ],
        },
      },
    ]);
    validateAddressMock = jest.fn();
    useLazyValidateAddressQuery.mockReturnValue([
      validateAddressMock,
      {
        status: 'fulfilled',
        data: {
          data: [
            {
              remarks: [{ description: 'Order Placed on Confirmation Hold' }],
            },
          ],
        },
      },
    ]);
    updateShippingAddressMock = jest.fn();
    useLazyUpdateShippingAddressAndOptionsQuery.mockReturnValue([
      updateShippingAddressMock,
      {
        status: 'fulfilled',
        data: {
          data: [
            {
              remarks: [{ description: 'Order Placed on Confirmation Hold' }],
            },
          ],
        },
      },
    ]);
    orderWriteMock = jest.fn();
    useLazyGetOrderWriteQuery.mockReturnValue([
      orderWriteMock,
      {
        status: 'fulfilled',
        data: {
          data: [
            {
              remarks: [{ description: 'Order Placed on Confirmation Hold' }],
            },
          ],
        },
      },
    ]);
    useLazyGetRetrieveInstallmentAgreementQuery.mockReturnValue([retrieveInstallmentAgreementMock,{status: 'fulfilled',data: {data: [{remarks: [{ description: 'Order Placed on Confirmation Hold' }],},],},},]);
    useLazyPostRetrieveAemInfoManagerDataQuery.mockReturnValue([postRetrieveAemInfoManagerDataMock,{status: 'fulfilled',data: {data: [{remarks: [{ description: 'Order Placed on Confirmation Hold' }],},],},},]);
    useUpdateAFOInfoMutation.mockReturnValue([updateAFOInfoMutationMock,{status: 'fulfilled',data: {data: [{remarks: [{ description: 'Order Placed on Confirmation Hold' }],},],},},]);
    useLazyGetCustomerByMtnsQuery.mockReturnValue([getCustomerByMtnsMock,{status: 'fulfilled',data: {data: [{remarks: [{ description: 'Order Placed on Confirmation Hold' }],},],},},]);
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        vtReadOrderForRetailFFlag: 'true',
        showBannerForEmailSkipFFlag: 'true',
        viewTogetherEnabled: 'true',
        msfToNsaQuickAccessoriesFFlag: 'true',
        isMitekSimSwapEnabled: 'TRUE',
      })
    );
    sessionStorage.setItem(
      'geoFenceResponse',
      JSON.stringify({ geoFenceCheck: 'false', ipadLatitude: '12.34', ipadLongitude: '56.78', reason: 'Out of range' }),
    );
  });

  afterEach(() => {
    jest.clearAllMocks();
    sessionStorage.clear();
  });

  it('should render FooterReadOrder component', () => {
    const props = {
      readOrderData: {
        cart: {
          orderDetails: {
            customerType: 'N',
            spocs: {
              notificationOptions: {
                primaryEmailId: '',
              },
            },
          },
          lineDetails: {
            lineInfo: [
              {
                itemsInfo: [
                  {
                    depletionType: 'L',
                  },
                ],
              },
            ],
          },
          cartId: '12345',
        },
        orderStatus: 'IN',
        loggedInUserRole: 'user',
        processStep: 'ACTIVATE',
      },
      cartDataRsp: {
        orderDetails: {
          orderType: 'IS',
        },
      },
      customerProfileRsp: {
        profileId: 'profile123',
        name: 'John Doe',
      },
      selectedReviewMode: '',
    };
    render(<FooterReadOrder {...props} />, {
      initialState: {},
      reducers: rootReducer,
      sagas: rootSaga,
    });
    fireEvent.click(screen.getByTestId('process-step-btn'));
  });

  it('should render FooterReadOrder component', () => {
    const props = {
      readOrderData: {
        cart: {
          orderDetails: {
            customerType: 'N',
            spocs: {
              notificationOptions: {
                primaryEmailId: '',
              },
            },
          },
          lineDetails: {
            lineInfo: [
              {
                itemsInfo: [
                  {
                    depletionType: 'L',
                  },
                ],
              },
            ],
          },
          cartId: '12345',
        },
        orderStatus: 'IN',
        loggedInUserRole: 'user',
        processStep: null,
      },
      cartDataRsp: {
        orderDetails: {
          orderType: 'PS',
        },
      },
      customerProfileRsp: {
        profileId: 'profile123',
        name: 'John Doe',
      },
      selectedReviewMode: '',
    };
    render(<FooterReadOrder {...props} />, {
      initialState: {},
      reducers: rootReducer,
      sagas: rootSaga,
    });
    fireEvent.click(screen.getByTestId('process-step-btn'));
  });

  it('should render FooterReadOrder component with viewdiscount open', () => {
    const props = {
      viewdiscountOpen: true,
      readOrderData: {
        cart: {
          orderDetails: {
            customerType: 'N',
            spocs: {
              notificationOptions: {
                primaryEmailId: '',
              },
            },
          },
          lineDetails: {
            lineInfo: [
              {
                itemsInfo: [
                  {
                    depletionType: 'L',
                  },
                ],
              },
            ],
          },
          cartId: '12345',
        },
        orderStatus: 'IN',
        loggedInUserRole: 'user',
        processStep: null,
      },
      cartDataRsp: {
        orderDetails: {
          orderType: 'PS',
        },
      },
      customerProfileRsp: {
        profileId: 'profile123',
        name: 'John Doe',
      },
      selectedReviewMode: '',
    };
    render(<FooterReadOrder {...props} />, {
      initialState: {},
      reducers: rootReducer,
      sagas: rootSaga,
    });
    fireEvent.click(screen.getByTestId('process-step-btn'));
  });

  it('should render FooterReadOrder component', () => {
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        vtReadOrderForRetailFFlag: 'false',
        showBannerForEmailSkipFFlag: 'true',
        viewTogetherEnabled: 'true',
      })
    );
    useLazyRetrieveRemarksQuery.mockReturnValue([
      retrieveRemarksMock,
      {
        status: 'rejected',
        data: {},
      },
    ]);
    const props = {
      readOrderData: {
        cart: null,
      },
      cartDataRsp: {
        orderDetails: {
          orderType: 'PS',
        },
      },
      customerProfileRsp: {
        profileId: 'profile123',
        name: 'John Doe',
      },
      selectedReviewMode: '',
    };
    render(<FooterReadOrder {...props} />, {
      initialState: {},
      reducers: rootReducer,
      sagas: rootSaga,
    });
    fireEvent.click(screen.getByTestId('process-step-btn'));
  });

  it('should render FooterReadOrder component', () => {
   
    useLazyRetrieveRemarksQuery.mockReturnValue([
      retrieveRemarksMock,
      {
        status: 'fulfilled',
        data: {
          data: {},
        },
      },
    ]);
    const props = {
      readOrderData: {
        cart: {
          orderDetails: {
            customerType: '',
            spocs: {
              notificationOptions: {
                primaryEmailId: '',
              },
            },
          },
          lineDetails: {
            lineInfo: [
              {
                itemsInfo: [
                  {
                    depletionType: 'L',
                  },
                ],
              },
            ],
          },
          cartId: '12345',//sridhar
        },
        orderStatus: 'IN',
        loggedInUserRole: 'user',
        processStep: null,
      },
      cartDataRsp: {
        orderDetails: {
          orderType: 'PS',
        },
      },
      customerProfileRsp: {
        profileId: 'profile123',
        name: 'John Doe',
      },
      selectedReviewMode: '',
    };
    render(<FooterReadOrder {...props} />, {
      initialState: {},
      reducers: rootReducer,
      sagas: rootSaga,
    });
    fireEvent.click(screen.getByTestId('process-step-btn'));
  });
  it('should render FooterReadOrder component 22222', () => {
    useLazyRetrieveRemarksQuery.mockReturnValue([
      retrieveRemarksMock,
      {
        status: 'fulfilled',
        data: {
          data: {},
        },
      },
    ]);
    
    const props = {
      readOrderData: {
        cart: {
          orderDetails: {
            customerType: '',
            spocs: {
              notificationOptions: {
                primaryEmailId: '',
              },
            },
          },
          lineDetails: {
            lineInfo: [
              {
                itemsInfo: [
                  {
                    depletionType: 'L',
                  },
                ],
              },
            ],
          },
          cartId: '12345',//sridhar
        },
        orderStatus: 'IN',
        loggedInUserRole: 'user',
        processStep: "CONTINUE",
      },
      cartDataRsp: {
        orderDetails: {
          orderType: 'PS',
        },
      },
      customerProfileRsp: {
        profileId: 'profile123',
        name: 'John Doe',
      },
      selectedReviewMode: '',
    };
    render(<FooterReadOrder {...props} />, {
      initialState: {},
      reducers: rootReducer,
      sagas: rootSaga,
    });
    fireEvent.click(screen.getByTestId('process-step-btn'));
  });
  it('should render FooterReadOrder component continue btn', () => {
    const response = [
      {
        rank: '1',
        propositionId: '107610',
        dispositionOptionId: '18',
        offerContainerId: '500020498',
        soiEngagementId: '555733',
        isPromoBundleEligible: 'N',
        offerSubType: 'Multi Line BOGO',
        offerId: '555733',
        mtn: '6037679700',
        itemCode: '',
        tacticLocation: 'ETR_Promotions_National',
        timeStamp: '2024-02-16T11:25:55+05:30',
        buyGetSku: 'MTU63LL/A',
        isSaveOffer: 'N',
        isHomeOffer: 'N',
      },
      {
        rank: '3',
        propositionId: '103239',
        dispositionOptionId: '25',
        offerContainerId: '500020498',
        soiEngagementId: '594560',
        isPromoBundleEligible: 'N',
        offerSubType: 'Simple',
        offerId: '594560',
        mtn: '6037679700',
        itemCode: '',
        tacticLocation: 'ETR_Promotions_National',
        timeStamp: '2024-02-16T11:25:55+05:30',
        buyGetSku: '',
        isSaveOffer: 'N',
        isHomeOffer: 'N',
      },
    ];

    sessionStorage.setItem('responseList', JSON.stringify(response));
    useLazyRetrieveRemarksQuery.mockReturnValue([
      retrieveRemarksMock,
      {
        status: 'fulfilled',
        data: {
          data: {},
        },
      },
    ]);

    const props = {
      cartDetailsResult: cartJson,
      customerProfile:{
        customer: { regNo: '89878', cartId: 'f9a102c8-bd94-476b-8c36-f867597dc8ca' },
      },
      landing: {
        activeCartandCase: {
          cartId: 'f9a102c8-bd94-476b-8c36-f867597dc8ca',
          caseId: 'SOP-15788985-E01',
        },
        quoteDetails: [{ cartId: 'f9a102c8-bd94-476b-8c36-f867597dc8ca' }],
      },
      readOrderData: {
        cart: {
          orderDetails: {
            customerType: '',
            spocs: {
              notificationOptions: {
                primaryEmailId: '',
              },
            },
          },
          lineDetails: {
            lineInfo: [
              {
                itemsInfo: [
                  {
                    depletionType: 'L',
                  },
                ],
              },
            ],
          },
          cartId: '12345',//sridhar
        },
        orderStatus: 'IN',
        loggedInUserRole: 'user',
        processStep: "CONTINUE",
      },
      cartDataRsp: {
        orderDetails: {
          orderType: 'PS',
        },
      },
      customerProfileRsp: {
        profileId: 'profile123',
        name: 'John Doe',
      },
      selectedReviewMode: '',
    };
    const props2 = {
      cartDetailsResult: cartJsonNew,
      customerProfile:{
        customer: { regNo: '89878', cartId: 'f9a102c8-bd94-476b-8c36-f867597dc8ca' },
      },
      landing: {
        activeCartandCase: {
          cartId: 'f9a102c8-bd94-476b-8c36-f867597dc8ca',
          caseId: 'SOP-15788985-E01',
        },
        quoteDetails: [{ cartId: 'f9a102c8-bd94-476b-8c36-f867597dc8ca' }],
      },
      readOrderData: {
        cart: {
          orderDetails: {
            customerType: '',
            spocs: {
              notificationOptions: {
                primaryEmailId: '',
              },
            },
          },
          lineDetails: {
            lineInfo: [
              {
                itemsInfo: [
                  {
                    depletionType: 'L',
                  },
                ],
              },
            ],
          },
          cartId: '12345',//sridhar
        },
        orderStatus: 'IN',
        loggedInUserRole: 'user',
        processStep: "CONTINUE",
      },
      cartDataRsp: {
        orderDetails: {
          orderType: 'PS',
        },
      },
      customerProfileRsp: {
        profileId: 'profile123',
        name: 'John Doe',
      },
      selectedReviewMode: '',
    };
    const { rerender } = render(<FooterReadOrder {...props} />, {
      initialState: {},
      reducers: rootReducer,
      sagas: rootSaga,
    });
      rerender(<FooterReadOrder {...props2} />, {
        initialState: {},
        reducers: rootReducer,
        sagas: rootSaga,
      });
    // render(<FooterReadOrder {...props} />, {
    //   initialState: {},
    //   reducers: rootReducer,
    //   sagas: rootSaga,
    // });

    fireEvent.click(screen.getByTestId('process-step-btn'));
  });
  it('should cover the orderNumbers condition ', () => {
    const props = {
      readOrderData: {
        cart: {
          orderDetails: {
            orderList: [{ orderNumber: 30044626 }, { orderNumber: 0 }, { orderNumber: 12345678 }],
          },
        },
      },
      cartDataRsp: {},
      customerProfileRsp: {},
      selectedReviewMode: '',
    };

    render(<FooterReadOrder {...props} />, {
      initialState: {},
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  it('should cover the orderNumbers condition ', () => {
    const props = {
      readOrderData: {},
      cartDataRsp: {},
      customerProfileRsp: {},
      selectedReviewMode: '',
    };

    render(<FooterReadOrder {...props} isQAClosedOrder={true} />, {
      initialState: {},
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  it('should render FooterReadOrder component', () => {
    getQueryParamByName.mockReturnValue('true');
    useLazyRetrieveRemarksQuery.mockReturnValue([
      retrieveRemarksMock,
      {
        status: 'fulfilled',
        data: {
          data: {},
        },
      },
    ]);
    const props = {
      readOrderData: {
        cart: {
          orderDetails: {
            customerType: '',
            spocs: {
              notificationOptions: {
                primaryEmailId: '',
              },
            },
          },
          lineDetails: {
            lineInfo: [
              {
                itemsInfo: [
                  {
                    depletionType: 'L',
                  },
                ],
              },
            ],
          },
          cartId: '12345',
        },
        orderStatus: 'IN',
        loggedInUserRole: 'user',
        processStep: null,
      },
      cartDataRsp: {
        orderDetails: {
          orderType: 'PS',
        },
      },
      customerProfileRsp: {
        profileId: 'profile123',
        name: 'John Doe',
      },
      selectedReviewMode: '',
    };
    render(<FooterReadOrder {...props} />, {
      initialState: {},
      reducers: rootReducer,
      sagas: rootSaga,
    });
    fireEvent.click(screen.getByTestId('process-step-btn'));
  });
  it('should render FooterReadOrder component qa em', () => {
    getQueryParamByName.mockReturnValue('');
    sessionStorage.setItem('creditAppNum', '123456');
    useLazyRetrieveRemarksQuery.mockReturnValue([
      retrieveRemarksMock,
      {
        status: 'fulfilled',
        data: {
          data: {},
        },
      },
    ]);
     
    const props = {
      readOrderData: {
        cart: {
          orderDetails: {
            customerType: '',
            spocs: {
              notificationOptions: {
                primaryEmailId: '',
              },
            },
          },
          lineDetails: {
            lineInfo: [
              {
                itemsInfo: [
                  {
                    depletionType: 'L',
                  },
                ],
              },
            ],
          },
          cartId: '12345',
        },
        orderStatus: 'IN',
        loggedInUserRole: 'user',
        processStep: null,
      },
      cartDataRsp: {
        orderDetails: {
          orderType: 'PS',
        },
      },
      customerProfileRsp: {
        profileId: 'profile123',
        name: 'John Doe',
      },
      selectedReviewMode: '',
    };
    render(<FooterReadOrder {...props} />, {
      initialState: {},
      reducers: rootReducer,
      sagas: rootSaga,
    });
    fireEvent.click(screen.getByTestId('process-step-btn'));
  });
});


