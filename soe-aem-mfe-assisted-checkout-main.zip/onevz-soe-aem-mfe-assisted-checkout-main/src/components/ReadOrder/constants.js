export const CHANNELS = {
  OMNI_RETAIL: 'OMNI-RETAIL',
  OMNI_RETAIL_TAB: 'OMNI-RETAIL-TAB',
};

export const specialistMenus = [
  {
    name: 'devicePayment',
    title: 'View device payment status',
    tag_name: 'View device payment status',
    track: 'devicePayment',
  },
  { name: 'remarks', title: 'View/add remarks', tag_name: 'View/add remarks', track: 'View/add remarks' },
  { name: 'glance', title: 'View items at a glance', tag_name: 'Items At A Glance', track: 'View items at a glance' },
  { name: 'collateral', title: 'View collateral', tag_name: 'Collateral', track: 'View collateral' },
  { name: 'printreceipt', title: 'View/print receipt', tag_name: 'View/print receipt', track: 'View/print receipt' },
  {
    name: 'PaymentHistory',
    title: 'View Payment History',
    tag_name: 'View Payment History',
    track: 'View Payment History',
  },
  { name: 'CreditStatus', title: 'Credit status', tag_name: 'Credit status', track: 'Credit status' },
  {
    name: 'resendPaymentLink',
    title: 'Resend Payment Link',
    tag_name: 'Resend Payment Link',
    track: 'resendPaymentLink',
  },
  { name: 'clicktocall', title: 'Click to Call', tag_name: 'Click to Call', track: 'Click to Call' },
  { name: 'trackit', title: 'Track It', tag_name: 'Track it', track: 'Track It' },
  {
    name: 'discountsAndPromos',
    title: 'View Discounts and Promos',
    tag_name: 'View Discounts and Promos',
    track: 'View Discounts and Promos',
  },
];

// activation status constants start...

export const activationStatusTitle = 'Activation Status';

export const activationStatusBtns = [
  { name: 'Activate All', testId: 'resubmitActivation', track: 'Activate All' },
  { name: 'Refresh', testId: 'refreshActivationStatus', track: 'Refresh' },
  { name: 'Continue', testId: 'redirectToOrderConfirmation', track: 'Continue' },
];
export const activationstatusItems = [
  {
    title: 'Line name',
  },
  {
    title: 'Type',
  },
  {
    title: 'Line number',
  },
  {
    title: 'Detail',
  },
];

export const confirm = {
  contentWithoutPaymentLabel: 'Exit Order:',
  contentWithPaymentLabel: 'Do you want to exit this order?',
  orderNumberLabel: 'Order Number: ',
  continueWithoutPaymentLabel: 'Continue',
  continueWithPaymentLabel: 'Yes',
  goBackButtonLabel: 'Go back to order',
};

export const userRole = ['ISACSC', 'ISACSCMGR'];
