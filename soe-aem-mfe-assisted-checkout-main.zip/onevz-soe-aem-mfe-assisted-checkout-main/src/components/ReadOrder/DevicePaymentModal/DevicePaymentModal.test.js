import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import DevicePaymentModal from './DevicePaymentModal';

jest.mock('../../../utils/tagging');

describe('DevicePaymentModal Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  const handleToggleMock = jest.fn();

  const defaultProps = {
    value: true,
    handleToggle: handleToggleMock,
    lines: [
      {
        serviceInfo: {
          primaryUserInfo: {
            firstName: 'BRIAN',
            lastName: 'BONDS',
          },
        },
        installmentContractDetail: {
          installmentLoanNumber: '123456789',
          loanStatus: 'A',
        },
        installmentInfo: true,
        mobileNumber: '1234567890',
      },
    ],
  };

  it('renders the modal with correct content', () => {
    render(<DevicePaymentModal {...defaultProps} />);
    expect(screen.getByText('Agreement Status')).toBeInTheDocument();
    expect(screen.getByText('Brian')).toBeInTheDocument();
    expect(screen.getByText('123-456-7890')).toBeInTheDocument();
    expect(screen.getByText('Agreement Number: 123456789')).toBeInTheDocument();
    expect(screen.getByText('Active')).toBeInTheDocument();
  });

  it('should close Modal on click of X Icon', () => {
    render(<DevicePaymentModal {...defaultProps} />);
    const closeButton = screen.getByTestId('Agreement Status Close Modal');
    fireEvent.click(closeButton);
    expect(handleToggleMock).toHaveBeenCalledWith('');
  });

  it('should close Modal on click of Done button', () => {
    render(<DevicePaymentModal {...defaultProps} />);
    const doneButton = screen.getByTestId('Done');
    fireEvent.click(doneButton);
    expect(handleToggleMock).toHaveBeenCalledWith('');
  });

  it('renders multiple lines correctly', () => {
    const multipleLinesProps = {
      ...defaultProps,
      lines: [
        ...defaultProps.lines,
        {
          serviceInfo: {
            primaryUserInfo: {
              firstName: 'JANE',
              lastName: 'DOE',
            },
          },
          installmentContractDetail: {
            installmentLoanNumber: '987654321',
            loanStatus: 'P',
          },
          installmentInfo: true,
          mobileNumber: '0987654321',
        },
      ],
    };

    render(<DevicePaymentModal {...multipleLinesProps} />);
    expect(screen.getByText('Jane')).toBeInTheDocument();
    expect(screen.getByText('098-765-4321')).toBeInTheDocument();
    expect(screen.getByText('Agreement Number: 987654321')).toBeInTheDocument();
  });

  it('should handle empty customerName, agreementStatus, and loanStatus', () => {
    const emptyProps = {
      ...defaultProps,
      lines: [
        {
          serviceInfo: null,
          installmentContractDetail: null,
          installmentInfo: true,
          mobileNumber: '1234567890',
        },
      ],
    };

    render(<DevicePaymentModal {...emptyProps} />);
  });
});
