import React, { useState } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { Modal } from '@vds/modals';
import { Button as VdsButton } from '@vds/buttons';
import { Icon } from '@vds/icons';
import { Title } from '@vds/typography';
import { Padding36 } from '../../../StyledConstants';
import { formatPhoneNumberWithSymbol } from '../../../utils/common';

const Button = styled(VdsButton)`
  padding: 5px 50px 5px 50px;
`;

const ModalHeader = styled.div`
  box-sizing: border-box;
  width: 100%;
`;

const CloseIconWrapper = styled.a`
  cursor: pointer;
  color: #000000 !important;
`;

const HorizontalDivider = styled.div`
  border-bottom: 1px solid #d8dada;
  max-width: 100%;
`;

const ModalBodyContent = styled.div`
  margin: 2.5rem;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
`;

const PaymentModalWrapper = styled.div`
  background-color: #fff;
`;

const PaymentFooter = styled.div`
  max-width: 64rem;
  z-index: 1;
  bottom: 0;
  position: fixed;
  width: 100%;
  display: flex;
  border-top: 1px solid #d8dada;
  justify-content: center;
`;

const TitleWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  margin: 20px;
`;

const CustomerName = styled.div`
  font-size: 18px;
  font-weight: 550;
  color: #4a4a4a;
  margin-bottom: 25px;
`;

const MobileNumber = styled.div`
  font-size: 24px;
  color: rgb(135, 137, 137);
  margin: 0px 20px 10px 0px;
`;

const AgreementInfo = styled.div`
  font-size: 24px;
  color: rgb(135, 137, 137);
  font-weight: 500;
  margin-top: 2px;
`;

const ActiveStatusWrapper = styled.div`
  display: flex;
  justify-content: center;
  width: 100%;
  margin-top: -12px; /* margin to position ActiveStatus between the lines */
`;

const ActiveStatus = styled.span`
  font-size: 24px;
  color: rgb(135, 137, 137);
  display: flex;
  align-items: center;
`;

const capitalizeFirstLetter = (string) => string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();

const DevicePaymentModal = ({ handleToggle, lines }) => {
  const [open, setOpen] = useState(true);
  return (
    <PaymentModalWrapper data-testid='device-payment-modal'>
      <Modal
        surface='light'
        disableAnimation={false}
        disableOutsideClick
        fullScreenDialog
        width='100%'
        ariaLabel='Device Payment Status'
        opened={open}
        onOpenedChange={(opened) => !opened && setOpen(false)}
        className='devicePayment-modal'
        closeButton={null}
      >
        <ModalHeader>
          <TitleWrapper>
            <Title size='small' color='#4a4a4a' bold>
              Agreement Status
            </Title>
            <CloseIconWrapper
              onClick={() => {
                setOpen(false);
                handleToggle('');
              }}
              data-testid='Agreement Status Close Modal'
              data-track='Agreement Status Close Modal'
            >
              <Icon name='close' size='medium' />
            </CloseIconWrapper>
          </TitleWrapper>
          <HorizontalDivider />
        </ModalHeader>
        {lines?.map((line) => {
          console.log(line, 'line');
          const customerName = line.serviceInfo ? line.serviceInfo.primaryUserInfo : '';
          const agreementStatus =
            line && line.installmentContractDetail && line.installmentContractDetail.installmentLoanNumber
              ? line.installmentContractDetail.installmentLoanNumber
              : '';
          const loanStatus =
            line && line.installmentContractDetail && line.installmentContractDetail.loanStatus
              ? line.installmentContractDetail.loanStatus
              : '';
          return (
            line &&
            line.installmentInfo && (
              <ModalBodyContent key={line.mobileNumber}>
                <CustomerName>
                  {customerName && customerName.firstName ? capitalizeFirstLetter(customerName.firstName) : ''}
                </CustomerName>
                <MobileNumber>{formatPhoneNumberWithSymbol(line.mobileNumber, '-')}</MobileNumber>
                <ActiveStatusWrapper>
                  {loanStatus === 'A' && (
                    <ActiveStatus>
                      <Icon name='checkmark-alt' size='large' lineColor='green' />
                      &nbsp; Active
                    </ActiveStatus>
                  )}
                </ActiveStatusWrapper>
                <AgreementInfo>
                  {'Agreement Number: '}&nbsp;
                  {agreementStatus}
                </AgreementInfo>
              </ModalBodyContent>
            )
          );
        })}
        <PaymentFooter>
          <Padding36>
            <Button
              aria-label='Done-button'
              data-testid='Done'
              data-track='Done'
              size='small'
              onClick={() => {
                setOpen(false);
                handleToggle('');
              }}
            >
              Done
            </Button>
          </Padding36>
        </PaymentFooter>
      </Modal>
    </PaymentModalWrapper>
  );
};

DevicePaymentModal.propTypes = {
  lines: PropTypes.array,
  handleToggle: PropTypes.func.isRequired,
};

export default DevicePaymentModal;
