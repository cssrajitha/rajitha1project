import { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { isIpad } from 'onevzsoemfeframework/DomService';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import { Title } from '@vds/typography';
import { Icon } from '@vds/icons';
import { CHANNELS, specialistMenus } from '../constants';
import { DARK_THEME_COLOR, DARK_THEME_BGCOLOR } from '../../constants/constants';
import { callOpenViewMFE, OpenViewTagging } from '../../../utils/tagging';

function SpecialistFunction(props) {
  const { cartData, readOrderData, customerProfile, setToggle, setClickToCall, toggleMenu } = props;
  const isDark = window?.mfe?.scmCheckoutMfeEnable && window?.mfe?.isDark;
  const commonInfo = customerProfile?.data?.commonInfo;
  const orderDetailsReview = cartData?.cart?.orderDetails;
  const channel = sessionStorage.getItem('channel');
  const [isTrackItEnabled] = getAssistedCradlePropertyV2(['isTrackItEnabled']);
  const isViewOnlyOrder = getQueryParamByName('viewOnlyOrder') === 'true';
  const [selectedMenus, setSelectedMenus] = useState([]);
  const repId = readOrderData?.cart?.orderDetails?.salesRepId || '';
  const isOrderWithSecurePayment =
    readOrderData?.securePaymentOrderDetails?.length > 0 &&
    readOrderData?.securePaymentOrderDetails?.some((paymentNode) => paymentNode.orderNumber > 0);
  useEffect(() => {
    const menuArr = fetchSelectedMenus();
    setSelectedMenus(menuArr);
  }, []);

  const fetchSelectedMenus = () => {
    const menuArr = [];
    specialistMenus.forEach((menu) => {
      const { name } = menu;
      if (checkMenuConditions(name) || name === 'printreceipt' || name === 'clicktocall' || name === 'CreditStatus') {
        menuArr.push(menu);
      }
    });
    return menuArr;
  };

  const checkMenuConditions = (menuName) => {
    const cartLineInfo = cartData?.cart?.lineDetails?.lineInfo;
    const paymentStatus = cartLineInfo?.map((line) => line?.installmentInfo)?.filter((info) => info !== undefined);
    const orderType = orderDetailsReview?.orderType;
    const subAccountInfo = orderDetailsReview?.subAccountInfo || [];
    const orderStatus = readOrderData?.orderStatus;
    const isIndirectChannel = commonInfo?.isIndirect;
    const isCostcoAgent = false;
    const isPrePayCart = sessionStorage.getItem('newPostToPreIndicator') === 'true';
    const doorTodoorExitingCustomer = channel?.indexOf('OMNI-D2D') > -1;
    console.log('paymentStatus: ', paymentStatus, ' orderStatus: ', orderStatus, ' channel : ', channel);
    switch (menuName) {
      case 'remarks':
        return !isIndirectChannel;
      case 'PaymentHistory':
        return !isIndirectChannel;
      case 'glance':
        return !isIndirectChannel;
      case 'collateral':
        return !isIndirectChannel && orderType !== 'RF' && !isPrePayCart && subAccountInfo?.length <= 0;
      case 'trackit':
        return !isCostcoAgent && (isIpad() || isTrackItEnabled === 'TRUE');
      case 'devicePayment':
        return (
          paymentStatus?.length > 0 &&
          orderStatus === 'CO' &&
          (channel === CHANNELS.OMNI_RETAIL_TAB || channel === CHANNELS.OMNI_RETAIL)
        );
      case 'discountsAndPromos':
        return !isViewOnlyOrder && !isCostcoAgent && !isIndirectChannel && !doorTodoorExitingCustomer;
      case 'resendPaymentLink':
        return isOrderWithSecurePayment && orderStatus === 'CR';
      default:
        return false;
    }
  };

  const onMenuClick = (menu) => {
    if (
      menu.name === 'glance' ||
      menu.name === 'collateral' ||
      menu.name === 'discounts' ||
      menu.name === 'PaymentHistory' ||
      menu.name === 'printreceipt' ||
      menu.name === 'trackit' ||
      menu.name === 'devicePayment'
    ) {
      setToggle(menu.name);
    } else if (menu.name === 'resendPaymentLink') {
      OpenViewTagging('', '', 'EUP|read-order', readOrderData);
      setToggle(menu.name);
    } else if (menu.name === 'clicktocall') {
      setClickToCall();
    } else if (menu.name === 'remarks') {
      setToggle('viewAddRemarks');
    } else if (menu.name === 'CreditStatus') {
      setToggle(menu.name);
    } else if (menu.name === 'discountsAndPromos') {
      setToggle('discounts');
    } else {
      console.log('Yet to dev..');
    }

    const data = {
      channel: 'Order',
      detail: menu.tag_name,
      flow: 'EUP|read-order',
      name: 'read-order',
      intent: 'Order',
      cartId: sessionStorage?.getItem('cartId') || readOrderData?.cart?.cartHeader?.cartId || '',
      eligibleLines: readOrderData?.cart?.lineDetails?.numOfLinesNSE || '',
      isAutoPayEnrolled: readOrderData?.cart?.lineDetails?.isAutoPayEnrolled || '',
      accountNumber: readOrderData?.cart?.lineDetails?.subAccountNBSInfo?.billAccounts?.nbs?.accountNumber || '',
      accountAddress: {
        zipCode: readOrderData?.cart?.lineDetails?.lineInfo?.serviceInfo?.cart5GAddress?.zipCode || '',
      },
    };
    callOpenViewMFE(data);
  };

  return (
    <>
      <MenuItem>
        <Title bold size='small' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
          Manage order details
        </Title>
      </MenuItem>
      {selectedMenus.map((menu, index) => {
        const key = `menu-${index}`;
        return (
          <MenuModalWarp
            key={key}
            onClick={() => {
              onMenuClick(menu);
              toggleMenu();
            }}
            data-testid={menu.name}
            data-track={menu?.track}
          >
            <Title size='small' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
              {menu.title}
            </Title>
          </MenuModalWarp>
        );
      })}
      <MenuProfileWarp>
        <Icon
          name='stakeholder'
          size={30}
          id='stakeholder'
          backgroundColor='#f6f6f6'
          lineColor='black'
          style={{ marginRight: '10px', marginLeft: '-11px' }}
        />
        <Title size='small' color={isDark ? DARK_THEME_COLOR : DARK_THEME_BGCOLOR}>
          {`REP : ${repId}`}
        </Title>
      </MenuProfileWarp>
    </>
  );
}

SpecialistFunction.propTypes = {
  cartData: PropTypes.any,
  readOrderData: PropTypes.any,
  customerProfile: PropTypes.any,
  setToggle: PropTypes.func,
  setClickToCall: PropTypes.func,
  toggleMenu: PropTypes.func,
};

export default SpecialistFunction;

const MenuModalWarp = styled.div`
  list-style-type: none;
  border-bottom: 1px solid #ccc;
  margin-bottom: 20px;
  white-space: nowrap;
  cursor: pointer;
  color: #000000 !important;
`;

const MenuProfileWarp = styled.div`
  display: flex;
  border-bottom: 1px solid #ccc;
  margin-bottom: 20px;
  white-space: nowrap;
  cursor: pointer;
  color: #000000 !important;
  background-color: #f6f6f6;
  height: 40px;
  margin-top: -20px;
  align-items: end;

  #stakeholder {
    margin-bottom: -3px;
  }
`;

const MenuItem = styled.div`
  list-style-type: none;
  border-bottom: 1px solid #ccc;
  margin-bottom: 20px;
  white-space: nowrap;
`;
