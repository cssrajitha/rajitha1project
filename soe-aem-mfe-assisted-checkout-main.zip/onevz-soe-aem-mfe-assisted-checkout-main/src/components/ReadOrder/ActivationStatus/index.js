import PropTypes from 'prop-types';
import { useEffect, useState } from 'react';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';
import { logInfoToKibana } from 'onevzsoemfecommon/Helpers';
import { ViewExitDialog } from 'onevzsoemfecommon/ViewExitDialog';
import { Button } from '@vds/buttons';
import { Cell, Table, TableBody, TableHead, TableHeader, TableRow } from '@vds/tables';
import ModalHeader from '../common/ModalHeader';
import {
  useLazyOcActivationQuery,
  useLazyResubmitActivationApiQuery,
} from '../../../modules/services/APIService/APIServiceHooks';
import { activationStatusBtns, activationstatusItems, activationStatusTitle } from '../constants';
import { formatAccountNumber } from '../../../utils/common';
import { callOpenViewMFE, OpenViewTagging } from '../../../utils/tagging';

function ActivationStatus(props) {
  // props
  const {
    customerProfile,
    readOrderData,
    cartData,
    viewOnlyActivationStatusFlag,
    closeActivationStatus,
    isFromRefundOrderView = false,
  } = props;
  const cartId = readOrderData?.cart?.cartId;
  const navigate = useNavigate();
  // state
  const [orderNumbers, setOrderNumbers] = useState('');
  const [activationStatusList, setActivationStatusList] = useState([]);
  const [showActivateButton, setShowActivateButton] = useState(false);
  const [showViewExistModal, setShowViewExistModal] = useState(false);
  const [getOcActivation, getOcActivationRes] = useLazyOcActivationQuery();
  const [getResubmitActivation, getResubmitActivationRsp] = useLazyResubmitActivationApiQuery();

  useEffect(() => {
    getOcActivation({ body: { cartId }, mock: false });
  }, []);

  useEffect(() => {
    if (getOcActivationRes?.status === 'fulfilled' && getOcActivationRes?.data) {
      const rsp = getOcActivationRes?.data?.orderActivationStatusInfo;
      let strOrderList = '';
      const tmpLst = [];
      if (rsp?.length) {
        rsp?.forEach((data, index) => {
          const length = rsp.length - 1;
          const Onumber = data?.orderNumber || '';
          if (length !== index) {
            strOrderList = `${Onumber}/`;
          } else {
            strOrderList += Onumber;
          }
          data?.activationInfoList?.forEach((l) => tmpLst.push(l));
        });
      }
      const showResubmitButton =
        (tmpLst?.length > 0 && tmpLst?.filter((item) => item.activationStatus === 'FAILED')) || [];
      const isConfirmationScreen = window.location.pathname.includes('order-confirmation');
      const showActivateBtn = isConfirmationScreen ? showResubmitButton.length > 0 : true;
      setOrderNumbers(strOrderList);
      setActivationStatusList(tmpLst);
      setShowActivateButton(showActivateBtn);
    }
  }, [getOcActivationRes]);

  const renderTable = () => {
    const customerInfo = customerProfile?.customer || cartData?.data?.customerProfile;
    const mtnLst = customerInfo?.billAccounts?.[0]?.mtns;
    const accountOwnerMtn =
      (mtnLst?.length > 0 &&
        mtnLst.find(
          (mtns) => mtns?.mobileInfoAttributes?.accountOwner || mtns?.mobileInfoAttributes?.accessRoles?.owner,
        )?.mtn) ||
      '';
    const isPrepayCart = cartData?.cart?.orderDetails?.isPrePayCart;
    return (
      <Table striped={false} surface='light' id='activationStatus-table' padding='compact'>
        <TableHead bottomLine='primary' padding='standard'>
          {activationstatusItems?.map((item, index) => {
            const k = `activationstatusHeaders-${index}`;
            return (
              <TableHeader key={k} id='actiationT-head'>
                {item.title}
              </TableHeader>
            );
          })}
        </TableHead>
        <TableBody>
          {activationStatusList?.map((item, index) => {
            const k = `activationStatusList-${index}`;
            let preferCustomerName = '';
            if (accountOwnerMtn === item?.mobileNumber && item?.preferFirstName && item?.preferLastName) {
              preferCustomerName = `${item?.preferFirstName}  ${item?.preferLastName}`;
            } else if (accountOwnerMtn === item?.mobileNumber && item?.preferFirstName) {
              preferCustomerName = item?.preferFirstName;
            } else {
              preferCustomerName = item?.fullName;
            }
            return (
              <TableRow
                key={k}
                bottomLine={index === activationStatusList.length - 1 ? 'none' : 'secondary'}
                id='activationStatus-row'
              >
                <Cell>
                  <strong>{preferCustomerName}</strong>
                </Cell>
                <Cell>{isPrepayCart !== 'Y' ? item?.transactionLineType : ''}</Cell>
                <Cell>{item?.mobileNumber}</Cell>
                <Cell>{item?.activationStatusMessage || item?.message}</Cell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    );
  };

  const renderFooter = () => (
    <FixedFooter>
      {activationStatusBtns?.map((btn, index) => {
        const k = `activationStatusBtns-${index}`;
        return (
          <CenteredBox key={k}>
            {((btn.name === 'Activate All' && showActivateButton) || btn.name !== 'Activate All') && (
              <Button
                data-testid={btn.testId}
                ariaLabel={btn.testId}
                onClick={() => {
                  onBtnClick(btn.name);
                }}
                data-track={isFromRefundOrderView && btn.name === 'Activate All' ? 'Activation' : btn.track}
                width={215}
              >
                {isFromRefundOrderView && btn.name === 'Activate All' ? 'Activation' : btn.name}
              </Button>
            )}
          </CenteredBox>
        );
      })}
    </FixedFooter>
  );

  const onBtnClick = (btnName) => {
    if (btnName === 'Activate All') {
      resubmitActivation();
    } else if (btnName === 'Refresh') {
      getOcActivation({ body: { cartId } });
    } else {
      redirectToOrderConfirmation();
    }
  };

  const resubmitActivation = () => {
    const cartHeader = readOrderData?.cart?.cartHeader;
    const orderDetails = readOrderData?.cart?.orderDetails;
    const customerType = orderDetails?.customerType || '';
    const creditAppNum = orderDetails?.orderList?.[0]?.creditApplication?.creditApplicationNum || '';
    const orderActivityType = orderDetails?.orderList?.[0]?.orderActivityType;
    const splitCaseID = cartHeader?.caseId?.substr(0, 3);
    logInfoToKibana(`Printing orderActivityType = ${orderActivityType} for data`, '');
    let data = {
      caseId: cartHeader?.caseId,
      cartCreator: '',
      processingMtn: '',
      cartId: cartHeader?.cartId,
      intent: '',
    };

    if (cartHeader?.fullAccountNumber && cartHeader?.fullAccountNumber !== '') {
      const accNo = formatAccountNumber(cartHeader?.fullAccountNumber);
      data = {
        ...data,
        accountNumber: accNo,
        cartCreator: cartHeader?.cartCreator,
        processingMtn: cartHeader?.cartCreator,
        intent: splitCaseID === 'SOA' || orderActivityType === 'CLNR' ? 'CLNR' : '',
      };
      if (isFromRefundOrderView) {
        data = {
          ...data,
          intent: 'REX',
        };
      }
      logInfoToKibana(`Print intent Type =${JSON.stringify(data)} for data`);
    } else if (customerType === 'N') {
      data = {
        ...data,
        cartCreator: creditAppNum,
        processingMtn: creditAppNum,
        intent: 'NSE',
      };
    }
    getResubmitActivation({ body: data, mock: false });
  };

  useEffect(() => {
    if (getResubmitActivationRsp?.status === 'fulfilled' && getResubmitActivationRsp?.data) {
      const arrlst = [];
      const OrderLst = getResubmitActivationRsp?.data?.orderDetails || [];
      OrderLst?.forEach((item) => {
        const activationInfoList = item?.activationDetails || [];
        activationInfoList?.forEach((l) => arrlst.push(l));
      });
      if (arrlst.length > 0) {
        setActivationStatusList(arrlst);
        setShowActivateButton(false);
      }
    }
  }, [getResubmitActivationRsp]);

  const redirectToOrderConfirmation = () => {
    setShowActivateButton(false);
    const obj = {
      channel: 'Order',
      detail: '',
      flow: isFromRefundOrderView ? 'EUP|rREFEX-read-order' : 'EUP|read-order',
      name: 'retail-order-confirmation',
      intent: 'Order',
      value: 'purchase',
      cartId,
      orderType: readOrderData?.cart?.orderDetails?.orderType,
      category: '',
      productId: '',
      productName: '',
      productOrderType: 'EUP',
      quantity: '',
      shared: '',
      sku: '',
    };
    callOpenViewMFE(obj);
    navigate(`/sales/assisted/new/order-confirmation.html?readOrder=true`);
    closeActivationStatus();
  };

  const onCloseModal = () => {
    if (viewOnlyActivationStatusFlag || isFromRefundOrderView) {
      closeActivationStatus();
    } else {
      OpenViewTagging('exitOrder', '', 'EUP|read-order', readOrderData);
      setShowViewExistModal(true);
    }
  };

  return (
    <div id='ActivationStatus' data-testid='ActivationStatus'>
      <ModalHeader
        modalTitle={activationStatusTitle}
        isOnlyClose={viewOnlyActivationStatusFlag}
        backCloseModal={closeActivationStatus}
        closeModal={onCloseModal}
      />
      {showViewExistModal && (
        <ViewExitDialog
          showCloseModal={showViewExistModal}
          setShowCloseModal={setShowViewExistModal}
          orderConfirmation
          orderNumber={orderNumbers}
        />
      )}
      {orderNumbers && renderTable()}
      {!viewOnlyActivationStatusFlag && renderFooter()}
    </div>
  );
}

ActivationStatus.propTypes = {
  viewOnlyActivationStatusFlag: PropTypes.bool,
  customerProfile: PropTypes.object,
  readOrderData: PropTypes.object,
  cartData: PropTypes.object,
  closeActivationStatus: PropTypes.func,
  isFromRefundOrderView: PropTypes.bool,
};
export default ActivationStatus;

const CenteredBox = styled.div`
  margin: auto;
  padding: 21px;
`;

const FixedFooter = styled.footer`
  position: fixed;
  bottom: 0px;
  text-align: center;
  width: 100%;
  border-top: 1px solid #d8dada !important;
  left: 0;
  right: 0;
  display: inline-flex;
  background-color: #fff;
  z-index: 1;
`;
