import { fireEvent, render, screen, waitFor } from '../../../utils/test-utils/renderHelper';
import { rootSaga } from '../../../modules/store/saga';
import rootReducer from '../../../modules/store/reducer';
import ActivationStatus from '.';
import {
  useLazyOcActivationQuery,
  useLazyResubmitActivationApiQuery,
} from '../../../modules/services/APIService/APIServiceHooks';

const OcAtivation = {
  cartId: '2bc91eb3-91b7-47fc-aac4-5a3d7fd96278',
  rpsDeviceFlowType: 'Numbershare',
  rpsLoggedinDeviceMtn: '5756266763',
  orderActivationStatusInfo: [
    {
      orderNumber: 12016639,
      orderStatus: 'U',
      creditApplicationNum: '465956007',
      activationInfoList: [
        {
          mobileNumber: '',
          activationStatus: '',
          message: '',
          visionOrderNumber: '0',
          visionLineItemNumber: '0',
          accountNumber: '',
          accountSubNumber: '',
          fullName: 'RAVI DARLING',
          preferFirstName: '',
          preferLastName: '',
          preferPronoun: '',
          ICCID: '',
          odaActivationCode: '',
          activationCode: '',
        },
      ],
    },
  ],
};
const resubmitData = {
  orderDetails: [
    {
      orderNumber: 0,
      creditApplicationNum: '460957200',
      activationDetails: [
        {
          mobileNumber: '7132487561',
          activationStatus: 'SENT',
          transactionLineType: 'EUP_FEA',
          activationStatusMessage: 'MTN:7132487561 - Activation request sent to billing.',
          multiLineSeqNumber: '1',
          fullName: '',
          isPreinquiryFailed: 'false',
          serviceOnlyEligibleLine: '',
          activationRequired: 'false',
          lineActivityType: 'EUP',
          odaActivationCode: '1$RPS.STUBBED.RESPONSE.COM$7132487561-0884139880$$1',
          serviceOnlyActivation: 'false',
        },
      ],
    },
  ],
  contextInfo: {
    callReason: 'SalesOrderPurchase',
    processStep: 'Confirmation',
  },
};

const mockProps = {
  viewOnlyActivationStatusFlag: false,
  customerProfile: {
    customer: {
      billAccounts: [
        {
          mtns: [
            {
              mobileInfoAttributes: {
                accountOwner: false,
              },
              mtn: '1234567890',
            },
          ],
        },
      ],
    },
  },
  readOrderData: {
    cart: {
      cartId: 'mockCartId',
      cartHeader: {
        caseId: 'mockCaseId',
        cartCreator: 'mockCartCreator',
        fullAccountNumber: '0000-90123456',
      },
      orderDetails: {
        isPrePayCart: 'N',
        customerType: null,
        orderList: [
          {
            creditApplication: {
              creditApplicationNum: null,
            },
            orderActivityType: 'CLNR',
          },
        ],
      },
    },
  },
  closeActivationStatus: jest.fn(),
};

jest.mock('../../..//modules/services/APIService/APIServiceHooks', () => ({
  useLazyOcActivationQuery: jest.fn(),
  useLazyResubmitActivationApiQuery: jest.fn(),
}));
describe('ActivationStatus', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    useLazyOcActivationQuery.mockReturnValue([jest.fn(), { status: 'fulfilled', data: OcAtivation }]);
    useLazyResubmitActivationApiQuery.mockReturnValue([jest.fn(), {}]);
  });

  it('should render correctly with empty activationInfoList', async () => {
    useLazyOcActivationQuery.mockReturnValue([
      jest.fn(),
      { status: 'fulfilled', data: { orderActivationStatusInfo: [] } },
    ]);
    render(<ActivationStatus {...mockProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  it('should handle activation status with multiple orders', async () => {
    const multipleOrdersData = {
      ...OcAtivation,
      orderActivationStatusInfo: [
        ...OcAtivation.orderActivationStatusInfo,
        {
          orderNumber: '1234568',
          orderStatus: 'U',
          creditApplicationNum: '465956008',
          activationInfoList: [
            {
              mobileNumber: '9876543210',
              activationStatus: 'SUCCESS',
              message: 'Activation successful',
              visionOrderNumber: '1',
              visionLineItemNumber: '1',
              accountNumber: '123456',
              accountSubNumber: '01',
              fullName: 'JOHN DOE',
              preferFirstName: 'John',
              preferLastName: 'Doe',
              preferPronoun: 'He/Him',
              ICCID: '12345678901234567890',
              odaActivationCode: '1234',
              activationCode: '5678',
            },
          ],
        },
      ],
    };
    useLazyOcActivationQuery.mockReturnValue([jest.fn(), { status: 'fulfilled', data: multipleOrdersData }]);
    render(<ActivationStatus {...mockProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await waitFor(
      () => {
        expect(screen.getByText(/john doe/i)).toBeInTheDocument();
      },
      { timeout: 3000 },
    );
  });

  it('should handle activation status with failed activation', async () => {
    const failedActivationData = {
      ...OcAtivation,
      orderActivationStatusInfo: [
        {
          orderNumber: '1234569',
          orderStatus: 'U',
          creditApplicationNum: '465956009',
          activationInfoList: [
            {
              mobileNumber: '1234567890',
              activationStatus: 'FAILED',
              message: 'Activation failed',
              visionOrderNumber: '2',
              visionLineItemNumber: '2',
              accountNumber: '654321',
              accountSubNumber: '02',
              fullName: 'JANE DOE',
              preferFirstName: 'Jane',
              preferLastName: 'Doe',
              preferPronoun: 'She/Her',
              ICCID: '09876543210987654321',
              odaActivationCode: '4321',
              activationCode: '8765',
            },
          ],
        },
      ],
    };
    useLazyOcActivationQuery.mockReturnValue([jest.fn(), { status: 'fulfilled', data: failedActivationData }]);
    render(<ActivationStatus {...mockProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await waitFor(
      () => {
        expect(screen.getByText(/jane doe/i)).toBeInTheDocument();
        expect(screen.getByText(/activation failed/i)).toBeInTheDocument();
      },
      { timeout: 3000 },
    );
  });

  it('should handle activation status with pending activation', async () => {
    const pendingActivationData = {
      ...OcAtivation,
      orderActivationStatusInfo: [
        {
          orderNumber: '1234570',
          orderStatus: 'U',
          creditApplicationNum: '465956010',
          activationInfoList: [
            {
              mobileNumber: '0987654321',
              activationStatus: 'PENDING',
              message: 'Activation pending',
              visionOrderNumber: '3',
              visionLineItemNumber: '3',
              accountNumber: '789012',
              accountSubNumber: '03',
              fullName: 'ALICE SMITH',
              preferFirstName: 'Alice',
              preferLastName: 'Smith',
              preferPronoun: 'They/Them',
              ICCID: '11223344556677889900',
              odaActivationCode: '5678',
              activationCode: '1234',
            },
          ],
        },
      ],
    };
    useLazyOcActivationQuery.mockReturnValue([jest.fn(), { status: 'fulfilled', data: pendingActivationData }]);
    render(<ActivationStatus {...mockProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await waitFor(
      () => {
        expect(screen.getByText(/alice smith/i)).toBeInTheDocument();
        expect(screen.getByText(/activation pending/i)).toBeInTheDocument();
      },
      { timeout: 2000 },
    );
  });

  it('should handle activation status with partial data', async () => {
    const partialData = {
      ...OcAtivation,
      orderActivationStatusInfo: [
        {
          orderNumber: '1234571',
          orderStatus: 'U',
          creditApplicationNum: '465956011',
          activationInfoList: [
            {
              mobileNumber: '',
              activationStatus: '',
              message: '',
              visionOrderNumber: '4',
              visionLineItemNumber: '4',
              accountNumber: '',
              accountSubNumber: '',
              fullName: 'BOB JOHNSON',
              preferFirstName: 'Bob',
              preferLastName: 'Johnson',
              preferPronoun: '',
              ICCID: '',
              odaActivationCode: '',
              activationCode: '',
            },
          ],
        },
      ],
    };
    useLazyOcActivationQuery.mockReturnValue([jest.fn(), { status: 'fulfilled', data: partialData }]);
    render(<ActivationStatus {...mockProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await waitFor(() => {
      expect(screen.getByText(/Activation Status/i)).toBeInTheDocument();
    });
  });

  it('should render correctly ', async () => {
    useLazyOcActivationQuery.mockReturnValue([jest.fn(), { status: 'fulfilled', data: OcAtivation }]);
    useLazyResubmitActivationApiQuery.mockReturnValue([jest.fn(), { status: 'rejected', data: {} }]);
    const props = {
      viewOnlyActivationStatusFlag: false,
      customerProfile: {
        customer: {
          billAccounts: [
            {
              mtns: [
                {
                  mobileInfoAttributes: {
                    accountOwner: true,
                  },
                  mtn: '',
                },
              ],
            },
          ],
        },
      },
      readOrderData: {
        cart: {
          cartId: 'mockCartId',
          cartHeader: {
            caseId: 'mockCaseId',
            cartCreator: 'mockCartCreator',
            fullAccountNumber: '0000-90123456',
          },
          orderDetails: {
            isPrePayCart: 'N',
            customerType: 'N',
            orderList: [
              {
                creditApplication: {
                  creditApplicationNum: null,
                },
                orderActivityType: null,
              },
            ],
          },
        },
      },
      closeActivationStatus: jest.fn(),
    };
    render(<ActivationStatus {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await waitFor(() => {
      expect(screen.getByText(/Activation Status/i)).toBeInTheDocument();
    });
    const activationBtn = await waitFor(
      () =>
        screen.findByRole('button', {
          name: /resubmitActivation/i,
        }),
      { timeout: 2000 },
    );
    await waitFor(() => fireEvent.click(activationBtn));
  });
  it('should render correctly ', async () => {
    useLazyOcActivationQuery.mockReturnValue([jest.fn(), { status: 'fulfilled', data: OcAtivation }]);
    useLazyResubmitActivationApiQuery.mockReturnValue([
      jest.fn(),
      {
        status: 'rejected',
        data: {
          orderDetails: [
            {
              activationDetails: null,
            },
          ],
        },
      },
    ]);
    const props = {
      viewOnlyActivationStatusFlag: false,
      customerProfile: {
        customer: {
          billAccounts: [
            {
              mtns: [
                {
                  mobileInfoAttributes: {
                    accountOwner: true,
                  },
                  mtn: '',
                },
              ],
            },
          ],
        },
      },
      readOrderData: {
        cart: {
          cartId: 'mockCartId',
          cartHeader: {
            caseId: 'mockCaseId',
            cartCreator: 'mockCartCreator',
            fullAccountNumber: '',
          },
          orderDetails: {
            isPrePayCart: 'N',
            customerType: 'N',
            orderList: [
              {
                creditApplication: {
                  creditApplicationNum: null,
                },
                orderActivityType: null,
              },
            ],
          },
        },
      },
      closeActivationStatus: jest.fn(),
    };
    render(<ActivationStatus {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await waitFor(() => {
      expect(screen.getByText(/Activation Status/i)).toBeInTheDocument();
    });
    const activationBtn = await screen.findByRole('button', {
      name: /resubmitActivation/i,
    });
    fireEvent.click(activationBtn);
  });
  it('should render correctly ', async () => {
    useLazyOcActivationQuery.mockReturnValue([jest.fn(), { status: 'fulfilled', data: OcAtivation }]);
    useLazyResubmitActivationApiQuery.mockReturnValue([jest.fn(), { status: 'rejected' }]);
    const props = {
      viewOnlyActivationStatusFlag: false,
      customerProfile: {
        customer: {
          billAccounts: [
            {
              mtns: [
                {
                  mobileInfoAttributes: {
                    accountOwner: true,
                  },
                  mtn: '',
                },
              ],
            },
          ],
        },
      },
      readOrderData: {
        cart: {
          cartId: 'mockCartId',
          cartHeader: {
            caseId: 'mockCaseId',
            cartCreator: 'mockCartCreator',
            fullAccountNumber: '',
          },
          orderDetails: {
            isPrePayCart: 'N',
            customerType: null,
            orderList: [
              {
                creditApplication: {
                  creditApplicationNum: null,
                },
                orderActivityType: null,
              },
            ],
          },
        },
      },
      closeActivationStatus: jest.fn(),
    };
    render(<ActivationStatus {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await waitFor(() => {
      expect(screen.getByText(/Activation Status/i)).toBeInTheDocument();
    });
    const activationBtn = await screen.findByRole('button', {
      name: /resubmitActivation/i,
    });
    fireEvent.click(activationBtn);
  });
  it('should render correctly', async () => {
    render(<ActivationStatus {...mockProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await waitFor(
      () => {
        expect(screen.getByText('Activation Status')).toBeInTheDocument();
      },
      { timeout: 3000 },
    );
    const activationBtn = await screen.findByRole('button', {
      name: /resubmitActivation/i,
    });
    fireEvent.click(activationBtn);
    const refresh = screen.getByRole('button', {
      name: /refreshactivationstatus/i,
    });
    fireEvent.click(refresh);
    const continueBtn = screen.getByRole('button', {
      name: /redirecttoorderconfirmation/i,
    });
    fireEvent.click(continueBtn);
    screen.debug(screen.getByTestId('ActivationStatus'));
  });
  it('should render correctly backButton', async () => {
    useLazyOcActivationQuery.mockReturnValue([jest.fn(), { status: 'rejected', data: {} }]);
    useLazyResubmitActivationApiQuery.mockReturnValue([jest.fn(), { status: 'fulfilled', data: resubmitData }]);
    render(<ActivationStatus {...mockProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    const backbtn = screen.getByTestId('left-icon');
    fireEvent.click(backbtn);
  });
  it('should render correctly backButton', async () => {
    useLazyOcActivationQuery.mockReturnValue([jest.fn(), { status: 'fulfilled', data: {} }]);
    render(<ActivationStatus {...mockProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    const backbtn = screen.getAllByRole('img');
    fireEvent.click(backbtn[1]);
  });
  it('should render correctly backButton', async () => {
    useLazyOcActivationQuery.mockReturnValue([
      jest.fn(),
      {
        status: 'fulfilled',
        data: {
          orderActivationStatusInfo: [
            {
              orderNumber: null,
              orderStatus: 'U',
              creditApplicationNum: '465956007',
              activationInfoList: [
                {
                  mobileNumber: '',
                  activationStatus: '',
                  message: '',
                  visionOrderNumber: '0',
                  visionLineItemNumber: '0',
                  accountNumber: '',
                  accountSubNumber: '',
                  fullName: 'RAVI DARLING',
                  preferFirstName: 'test',
                  preferLastName: 'test',
                  preferPronoun: '',
                  ICCID: '',
                  odaActivationCode: '',
                  activationCode: '',
                },
                {
                  mobileNumber: '',
                  activationStatus: '',
                  message: '',
                  visionOrderNumber: '0',
                  visionLineItemNumber: '0',
                  accountNumber: '',
                  accountSubNumber: '',
                  fullName: 'RAVI DARLING',
                  preferFirstName: 'test',
                  preferLastName: '',
                  preferPronoun: '',
                  ICCID: '',
                  odaActivationCode: '',
                  activationCode: '',
                },
              ],
            },
            {
              orderNumber: '1234567',
              orderStatus: 'U',
              creditApplicationNum: '465956007',
              activationInfoList: [
                {
                  mobileNumber: '',
                  activationStatus: '',
                  message: '',
                  visionOrderNumber: '0',
                  visionLineItemNumber: '0',
                  accountNumber: '',
                  accountSubNumber: '',
                  fullName: 'RAVI DARLING',
                  preferFirstName: 'test',
                  preferLastName: '',
                  preferPronoun: '',
                  ICCID: '',
                  odaActivationCode: '',
                  activationCode: '',
                },
              ],
            },
          ],
        },
      },
    ]);
    render(
      <ActivationStatus
        viewOnlyActivationStatusFlag
        closeActivationStatus={jest.fn()}
        cartData={{
          cart: {
            orderDetails: { isPrePayCart: 'Y' },
          },
        }}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    const backbtn = screen.getAllByRole('img');
    fireEvent.click(backbtn[0]);
  });

  it('should render correctly with isFromRefundOrderView', async () => {
    useLazyOcActivationQuery.mockReturnValue([jest.fn(), { status: 'fulfilled', data: OcAtivation }]);
    useLazyResubmitActivationApiQuery.mockReturnValue([jest.fn(), { status: 'rejected' }]);
    const props = {
      viewOnlyActivationStatusFlag: false,
      customerProfile: {
        customer: {
          billAccounts: [
            {
              mtns: [
                {
                  mobileInfoAttributes: {
                    accountOwner: true,
                  },
                  mtn: '',
                },
              ],
            },
          ],
        },
      },
      readOrderData: {
        cart: {
          cartId: 'mockCartId',
          cartHeader: {
            caseId: 'mockCaseId',
            cartCreator: 'mockCartCreator',
            fullAccountNumber: '',
          },
          orderDetails: {
            isPrePayCart: 'N',
            customerType: null,
            orderList: [
              {
                creditApplication: {
                  creditApplicationNum: null,
                },
                orderActivityType: null,
              },
            ],
          },
        },
      },
      closeActivationStatus: jest.fn(),
      isFromRefundOrderView: true,
    };
    render(<ActivationStatus {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  it('should render correctly with isFromRefundOrderView and set intent to REX', async () => {
    useLazyOcActivationQuery.mockReturnValue([jest.fn(), { status: 'fulfilled', data: OcAtivation }]);
    useLazyResubmitActivationApiQuery.mockReturnValue([jest.fn(), { status: 'rejected' }]);
    const props = {
      viewOnlyActivationStatusFlag: false,
      customerProfile: {
        customer: {
          billAccounts: [
            {
              mtns: [
                {
                  mobileInfoAttributes: {
                    accountOwner: true,
                  },
                  mtn: '',
                },
              ],
            },
          ],
        },
      },
      readOrderData: {
        cart: {
          cartId: 'mockCartId',
          cartHeader: {
            caseId: 'mockCaseId',
            cartCreator: 'mockCartCreator',
            fullAccountNumber: '',
          },
          orderDetails: {
            isPrePayCart: 'N',
            customerType: null,
            orderList: [
              {
                creditApplication: {
                  creditApplicationNum: null,
                },
                orderActivityType: null,
              },
            ],
          },
        },
      },
      closeActivationStatus: jest.fn(),
      isFromRefundOrderView: true,
    };

    render(<ActivationStatus {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    const expectedData = {
      ...props.readOrderData,
      intent: 'REX',
    };
    expect(expectedData.intent).toBe('REX');
  });
});
