import { useState } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { Modal } from '@vds/modals';
import { Button } from '@vds/buttons';
import { Icon } from '@vds/icons';
import { Input } from '@vds/inputs';
import { Title } from '@vds/typography';
// import { DropdownSelect } from '@vds/selects';
import { Divider, Header, IconWrapper, TitleWrapper } from '../../ItemsAtGlance/ItemsAtGlance';

const ModalWrapper = styled.div`
  background-color: #fff;
  width: 100%;
  [class^='ModalDialogWrapper-VDS'] {
    padding: 20px 0px 20px 0px !important;
  }
`;

const HeadingWrapper = styled.div`
  display: grid;
  grid-template-columns: 4fr 2fr repeat(2, 3fr);
  grid-template-rows: 1fr;
  grid-column-gap: 0px;
  grid-row-gap: 0px;
  margin-top: 35px;
  margin-bottom: 20px;
`;

const ItemWrapper = styled.div`
  grid-area: 1 / 1 / 2 / 2;
`;

const QuantityWrapper = styled.div`
  grid-area: 1 / 2 / 2 / 3;
  font-size: '24px';
`;
const DiscountWrapper = styled.div`
  grid-area: 1 / 3 / 2 / 4;
  font-size: '24px';
`;
const ReasonWrapper = styled.div`
  grid-area: 1 / 4 / 2 / 5;
  font-size: '24px';
`;

const ContentWrapper = styled.div`
  display: grid;
  grid-template-columns: 1fr 3fr 1fr repeat(2, 3fr);
  grid-template-rows: 1fr;
  grid-column-gap: 0px;
  grid-row-gap: 0px;
`;

const ContentImageWrapper = styled.div`
  grid-area: 1 / 1 / 2 / 2;
  margin-left: 10px;
  margin-top: 50px;
`;

const ContentItemWrapper = styled.div`
  grid-area: 1 / 2 / 2 / 3;
  margin-top: 57px;
`;

const ContentQuantityWrapper = styled.div`
  grid-area: 1 / 3 / 2 / 4;
  margin-top: 60px;
`;

const ContentDiscountWrapper = styled.div`
  grid-area: 1 / 4 / 2 / 5;
  margin-top: 35px;
  margin-bottom: 30px;
`;

const ContentReasonWrapper = styled.div`
  grid-area: 1 / 5 / 2 / 6;
`;

const SelectWrapper = styled.div`
  margin-top: 50px;
  [class^='SelectContainer-VDS'] {
    border-radius: 0px;
    width: 70%;
  }
`;

const BoxWrapper = styled.div`
  width: 11.8rem;
  border: 1px solid #d8dada;
  padding-top: 0.875rem !important;
  padding-right: 0.875rem !important;
  padding-bottom: 0.875rem !important;
  padding-left: 0.875rem !important;
  display: flex;
  flex-direction: column;
`;

const InputWrapper = styled.div`
  [class^='InputContainer-VDS'] {
    border-radius: 0px;
  }
`;

const BtnWrapper = styled.div`
  display: flex;
  [class^='StyledButton-VDS'] {
    border-radius: 0px;
    width: 100%;
  }
`;

const Btn1Wrapper = styled.div`
  width: 100%;
  [class^='StyledButton-VDS'] {
    background-color: ${(props) => (props.discountType === '$' ? `#959595` : `#f6f6f6 `)};
    color: ${(props) => (props.discountType === '$' ? `#ffffff` : `#000 `)};
    border: none;
  }
`;

const Btn2Wrapper = styled.div`
  width: 100%;
  [class^='StyledButton-VDS'] {
    background-color: ${(props) => (props.discountType === '%' ? `#959595` : `#f6f6f6`)};
    color: ${(props) => (props.discountType === '%' ? `#ffffff` : `#000`)};
    border: none;
  }
`;

const AddPromoBtnWrapper = styled.div`
  margin-top: 20px;
`;

// const reasons = [];

// Pending: API Call: soe/assisted/auth/interimservice/manual-discount
const totalAmount = '-';
const finalAmount = '-';

const DiscountsSection = ({ value, handleToggle }) => {
  const [open, setOpen] = useState(value);
  const [discount, setDiscount] = useState(0);
  const [discountType, setDiscountType] = useState('$');

  const content = (
    <div>
      <Header>
        <TitleWrapper>
          <Title size='small' color='#000000' bold>
            Add Discounts
          </Title>
          <IconWrapper
            onClick={() => {
              setOpen(false);
              handleToggle('');
            }}
            data-testid='close-button'
          >
            <Icon name='close' size='medium' />
          </IconWrapper>
        </TitleWrapper>
        <Divider />
      </Header>

      <HeadingWrapper>
        <ItemWrapper>
          <Title size='medium' color='#000000'>
            Item
          </Title>
        </ItemWrapper>
        <QuantityWrapper>
          <Title size='medium' color='#000000'>
            Quantity
          </Title>
        </QuantityWrapper>
        <DiscountWrapper>
          <Title size='medium' color='#000000'>
            Discount
          </Title>
        </DiscountWrapper>
        <ReasonWrapper>
          <Title size='medium' color='#000000'>
            Reason
          </Title>
        </ReasonWrapper>
      </HeadingWrapper>
      <Divider />

      <ContentWrapper>
        <ContentImageWrapper>
          <img src='' alt='Device' height='100px' />
        </ContentImageWrapper>

        <ContentItemWrapper>
          <Title size='small' color='#000000' bold={false}>
            UPGRADE FEE
          </Title>
          <Title size='small' color='#000000' bold={false}>
            {totalAmount}
          </Title>
          <Title size='small' color='#000000' bold={false}>
            {finalAmount}
          </Title>
          <Title size='small' color='#000000' bold={false}>
            Line -
          </Title>
        </ContentItemWrapper>

        <ContentQuantityWrapper>
          <Title size='medium' color='#000000' bold={false}>
            1
          </Title>
        </ContentQuantityWrapper>

        <ContentDiscountWrapper>
          <BoxWrapper>
            <InputWrapper>
              <Input
                type='number'
                label='Discounts'
                value={discount}
                errorText=''
                helperText=''
                onChange={(e) => setDiscount(e.target.value)}
                placeholder={discountType === '$' ? '$0.00' : '%0.00'}
                data-testid='discount'
              />
            </InputWrapper>

            <BtnWrapper>
              <Btn1Wrapper discountType={discountType}>
                <Button data-testid='dollar-button' onClick={() => setDiscountType('$')}>
                  $
                </Button>
              </Btn1Wrapper>
              <Btn2Wrapper discountType={discountType}>
                <Button data-testid='percent-button' onClick={() => setDiscountType('%')}>
                  %
                </Button>
              </Btn2Wrapper>
            </BtnWrapper>
          </BoxWrapper>
        </ContentDiscountWrapper>

        <ContentReasonWrapper>
          <SelectWrapper>
            {/* <DropdownSelect label='Select Reason' data-testid='select'>
              {reasons.map((ele) => (
                <option key={ele.id}>{ele.reason}</option>
              ))}
            </DropdownSelect> */}
          </SelectWrapper>
        </ContentReasonWrapper>
      </ContentWrapper>
      <Divider />

      <AddPromoBtnWrapper>
        <Button className='button' use='secondary'>
          Add Promo Code
        </Button>
      </AddPromoBtnWrapper>
    </div>
  );

  return (
    <ModalWrapper data-testid='discount-section'>
      <Modal
        surface='light'
        disableAnimation={false}
        disableOutsideClick={false}
        ariaLabel='Items At Glance'
        opened={open}
        onOpenedChange={(opened) => !opened && setOpen(false)}
        closeButton={null}
        className='my-custom-modal'
      >
        {content}
      </Modal>
    </ModalWrapper>
  );
};

DiscountsSection.propTypes = {
  value: PropTypes.bool,
  handleToggle: PropTypes.func,
};

export default DiscountsSection;
