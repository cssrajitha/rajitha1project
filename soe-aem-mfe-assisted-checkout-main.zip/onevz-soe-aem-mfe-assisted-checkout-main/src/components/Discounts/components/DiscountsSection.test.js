import { render, screen, fireEvent } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../../modules/store';
import DiscountsSection from './DiscountsSection';

describe('DiscountsSection Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  test('renders DiscountsSection', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <DiscountsSection value handleToggle={jest.fn()} />
        </StoreProvider>
      </BrowserRouter>
    );
    const modalHeader = screen.getByTestId('discount-section');
    expect(modalHeader).toBeInTheDocument();
  });

  test('should display the input field with empty field', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <DiscountsSection value handleToggle={jest.fn()} />
        </StoreProvider>
      </BrowserRouter>
    );
    const inputField = screen.getByTestId('discount');
    expect(inputField).toBeInTheDocument();
  });

  test('should display the number on in input field', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <DiscountsSection value handleToggle={jest.fn()} />
        </StoreProvider>
      </BrowserRouter>
    );
    const inputField = screen.getByTestId('discount');
    fireEvent.change(inputField, { target: { value: 2 } });
    expect(inputField).toHaveValue(2);
  });

  test('should close Modal on click of X Icon', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <DiscountsSection value handleToggle={jest.fn()} />
        </StoreProvider>
      </BrowserRouter>
    );
    const closeButton = screen.getByTestId('close-button');
    fireEvent.click(closeButton);
    expect(closeButton).toBeInTheDocument();
  });

  test('should change color on click of $ button', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <DiscountsSection value handleToggle={jest.fn()} />
        </StoreProvider>
      </BrowserRouter>
    );
    const dollarButton = screen.getByTestId('dollar-button');
    fireEvent.click(dollarButton);
    expect(dollarButton).toBeInTheDocument();
  });

  test('should change color on click of % button', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <DiscountsSection value handleToggle={jest.fn()} />
        </StoreProvider>
      </BrowserRouter>
    );
    const percentButton = screen.getByTestId('percent-button');
    fireEvent.click(percentButton);
    expect(percentButton).toBeInTheDocument();
  });
});
