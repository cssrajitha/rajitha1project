import { render, screen, fireEvent } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../modules/store';
import CollateralInfo from './CollateralInfo';

describe('CollateralInfo Component', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  test('renders CollateralInfo', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <CollateralInfo value handleToggle={jest.fn()} />
        </StoreProvider>
      </BrowserRouter>
    );
    const modalHeader = screen.getByTestId('collateral-info');
    expect(modalHeader).toBeInTheDocument();
  });

  test('should close Modal on click of X Icon', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <CollateralInfo value handleToggle={jest.fn()} />
        </StoreProvider>
      </BrowserRouter>
    );
    const closeButton = screen.getByTestId('close-button');
    fireEvent.click(closeButton);
    expect(closeButton).toBeInTheDocument();
  });
});
