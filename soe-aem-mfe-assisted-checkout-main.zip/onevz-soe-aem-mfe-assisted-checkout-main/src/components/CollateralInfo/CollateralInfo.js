import { useState } from 'react';
import PropTypes from 'prop-types';
import { Modal } from '@vds/modals';
import { Table, TableHead, TableHeader, TableBody, TableRow, Cell } from '@vds/tables';
import { Title } from '@vds/typography';
import { Icon } from '@vds/icons';
import { Header, TitleWrapper, IconWrapper, Divider, ModalWrapper, TableWrapper } from '../ItemsAtGlance/ItemsAtGlance';
import { themeIconColor, themeSurface, themeTableHeaderBgColor, themeTextColor } from '../constants/constants';

const headerData = [
  { id: 1, item: 'Line Number' },
  { id: 1, item: 'Item Code' },
  { id: 1, item: 'Description' },
];
// Pending: API call fetch the data: "orderprocessservice/retrievecollateralapi/retrieve-collateral-items"
const detailsData = [{ id: 1, mobileNumber: '-', itemCode: '-', description: '-' }];

const CollateralInfo = ({ value, handleToggle }) => {
  const [open, setOpen] = useState(value);

  const content = (
    <>
      <Header>
        <TitleWrapper>
          <Title size='small' bold color={themeTextColor()}>
            Collateral Info DATA
          </Title>
          <IconWrapper
            onClick={() => {
              setOpen(false);
              handleToggle('');
            }}
            data-testid='close-button'
          >
            <Icon name='close' size='medium' color={themeIconColor()} />
          </IconWrapper>
        </TitleWrapper>
        <Divider />
      </Header>
      <TableWrapper data-testid='table'>
        <Table striped={false}>
          <TableHead bottomLine='primary'>
            {headerData.map((data) => (
              <TableHeader
                key={data.id}
                style={{ color: themeTextColor(), backgroundColor: themeTableHeaderBgColor() }}
              >
                {data.item}
              </TableHeader>
            ))}
          </TableHead>
          <TableBody>
            {detailsData.map((item) => (
              <TableRow key={item.id}>
                <Cell style={{ color: themeTextColor() }}>{item.mobileNumber}</Cell>
                <Cell style={{ color: themeTextColor() }}>{item.itemCode}</Cell>
                <Cell style={{ color: themeTextColor() }}>{item.description}</Cell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableWrapper>
    </>
  );

  return (
    <div>
      <ModalWrapper data-testid='collateral-info'>
        <Modal
          className='my-custom-modal'
          surface={themeSurface()}
          disableAnimation={false}
          disableOutsideClick={false}
          ariaLabel='ColleteralInfo'
          opened={open}
          onOpenedChange={(opened) => !opened && setOpen(false)}
          closeButton={null}
        >
          {content}
        </Modal>
      </ModalWrapper>
    </div>
  );
};

CollateralInfo.propTypes = {
  value: PropTypes.bool,
  handleToggle: PropTypes.func,
};

export default CollateralInfo;
