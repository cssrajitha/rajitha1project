import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import StoreProvider from './modules/store';
import OrderReview from './pages/home/container/orderreview';
import Handoff from './pages/home/container/Handoff/handoff';
import ShippingDetails from './pages/ShippingDetails/container/ShippingDetails';
import TradeInMoreDevice from './pages/TradeInMoreDevice/container/TradeInMoreDevice';
import Ispu from './pages/Ispu/container/Ispu';
import Refund from './components/OrderReview/Refund';

function App() {
  return (
    <div className='App'>
      <StoreProvider>
        <Router>
          <Routes>
            <Route exact path='/sales/assisted/new/handoff.html' element={<Handoff />} />
            <Route exact path='/sales/assisted/new/order-review.html' element={<OrderReview />} />{' '}
            <Route exact path='/sales/assisted/new/qa-order-review.html' element={<OrderReview isQAFlow />} />{' '}
            <Route exact path='/sales/assisted/new/read-order.html' element={<OrderReview readOrder />} />
            <Route exact path='/sales/assisted/new/refund-order-review.html' element={<Refund readOrder />} />
            <Route exact path='/sales/assisted/new/shipping-details.html' element={<ShippingDetails />} />
            <Route exact path='/sales/assisted/new/shop-tradein.html' element={<TradeInMoreDevice />} />
            <Route exact path='/sales/assisted/new/ispustorefinder.html' element={<Ispu />} />
          </Routes>
        </Router>
      </StoreProvider>
    </div>
  );
}

export default App;
