import { useSelector } from 'react-redux';
import {
  formatPhoneNumberWithSymbol,
  getCamelCaseName,
  formatCurrency,
  getPlanDetail,
  getDisplayableFeatures,
  getDiscountedFeatures,
  getSharedFeatures,
  formatMtnWithHyphen,
  allowOnlyAlphaNumeric,
  getCamelCasePronoun,
  formatMtnWithDecimals,
  formatDate,
  isEnabledTradeReturnOptionsInContactCenterApps,
  isSDDInCart,
  formatAccountNumber,
  allowOnlyNumbers,
  getDate,
  convertDateRange,
  financedAmount,
  scmCheckoutMfeEnabled,
  scmOnlyDeviceMfeEnabled,
  getTotalMonthlyBill,
  getEstimatedNextBillWithBillAccountNo,
  useCradleState,
  getMTNList,
  formatDateOrdinal,
  scmVtMultitaskMode,
  isServiceChangeFlag,
  isNullOrEmpty
} from './common';
import cartJson from '../__mock__/retrive-cart.json';
import fetchPricingSnapshotJson from '../__mock__/fetchPricingSnapshot.json';
import moment from 'moment';

jest.mock('react-redux', () => ({
  useSelector: jest.fn(),
}));

describe('Common Methods', () => {
  test('test formatPhoneNumberWithSymbol', () => {
    const data = formatPhoneNumberWithSymbol();
    expect(data).toBeUndefined();
  });
  test('test formatPhoneNumberWithSymbol', () => {
    const data = formatPhoneNumberWithSymbol('23');
    expect(data).toBeTruthy();
  });
  test('test formatPhoneNumberWithSymbol', () => {
    const data = formatPhoneNumberWithSymbol('2345');
    expect(data).toBeTruthy();
  });
  test('test formatPhoneNumberWithSymbol', () => {
    const data = formatPhoneNumberWithSymbol('23423232');
    expect(data).toBeTruthy();
  });

  test('test getCamelCaseName', () => {
    const data = getCamelCaseName('test');
    expect(data).toEqual('Test');
  });

  test('test getCamelCasePronoun', () => {
    const data = getCamelCasePronoun('test,pronoun');
    expect(data).toEqual('Test,Pronoun');
  });

  test('formatCurrency for positive value', () => {
    const result = formatCurrency('5');
    expect(result).toEqual('$5.00');
  });

  test('formatCurrency for negative value', () => {
    const result = formatCurrency('-5');
    expect(result).toEqual('-$5.00');
  });

  test('formatCurrency for not a number', () => {
    const result = formatCurrency('check');
    expect(result).toEqual('$NaN');
  });

  test('test getPlanDetail', () => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    line.serviceInfo.newPricePlanId = '50431';
    line.serviceInfo.newPlanFlag = 'A';
    const data = getPlanDetail(line);
    expect(Object.keys(data).length).toEqual(12);
  });

  test('test getPlanDetail', () => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    line.serviceInfo.newPricePlanId = '50431';
    line.serviceInfo.newPlanFlag = 'L';
    const data = getPlanDetail(line);
    expect(Object.keys(data).length).toEqual(12);
  });

  test('test getPlanDetail', () => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    line.serviceInfo.newPricePlanId = '50431';
    delete line.serviceInfo.oldPricePlanId;
    line.serviceInfo.oldPlanFlag = 'A';
    const data = getPlanDetail(line);
    expect(Object.keys(data).length).toEqual(12);
  });

  test('test getPlanDetail', () => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    delete line.serviceInfo.oldPricePlanId;
    delete line.serviceInfo.newPricePlanId;
    const data = getPlanDetail(line);
    expect(Object.keys(data).length).toEqual(12);
  });

  test('test formatDate with default format', () => {
    const date = '2023-10-10';
    const formattedDate = formatDate(date);
    expect(formattedDate).toEqual('10/10/2023');
  });

  test('test formatDate with custom format', () => {
    const date = '2023-10-10';
    const formatPattern = 'YYYY-MM-DD';
    const formattedDate = formatDate(date, formatPattern);
    expect(formattedDate).toEqual('2023-10-10');
  });

  test('test formatDate with invalid date', () => {
    const date = 'invalid-date';
    const formattedDate = formatDate(date);
    expect(formattedDate).toEqual('Invalid date');
  });

  test('test formatMtnWithDecimals', () => {
    const data = formatMtnWithDecimals(1234567890);
    expect(data).toEqual('123.456.7890');
  });

  test('test formatMtnWithDecimals', () => {
    const data = formatMtnWithDecimals();
    expect(data).toEqual();
  });

  test('test getPlanDetail', () => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    line.serviceInfo.newPricePlanId = '50431';
    delete line.serviceInfo.oldPricePlanId;
    line.serviceInfo.newPlanFlag = 'A';
    const data = getPlanDetail(line);
    expect(Object.keys(data).length).toEqual(12);
  });

  test('test getPlanDetail', () => {
    const line = cartJson.data.cart.lineDetails.lineInfo[0];
    line.serviceInfo.oldPlanFlag = 'A';
    const data = getPlanDetail(line);
    expect(Object.keys(data).length).toEqual(12);
  });

  test('test getDisplayableFeatures', () => {
    const line = fetchPricingSnapshotJson.data.data.subAccounts[0].lines[0];
    const data = getDisplayableFeatures(line);
    expect(Object.keys(data).length).toEqual(4);
  });

  test('test getDiscountedFeatures', () => {
    const line = fetchPricingSnapshotJson.data.data.subAccounts[0].lines[0];
    const data = getDiscountedFeatures(line);
    expect(Object.keys(data).length).toEqual(0);
  });
  test('test getSharedFeatures', () => {
    const line = fetchPricingSnapshotJson.data.data.subAccounts[0].lines;
    const data = getSharedFeatures(line, 'existing');
    expect(Object.keys(data).length).toEqual(0);
  });
  test('test getSharedFeatures', () => {
    const line = fetchPricingSnapshotJson.data.data.subAccounts[0].lines;
    const data = getSharedFeatures(line, 'new');
    expect(Object.keys(data).length).toEqual(0);
  });

  test('test formatMtnWithHyphen', () => {
    const mtn = formatMtnWithHyphen('1234567890');
    const emptyMtn = formatMtnWithHyphen('');
    const newLineMtn = formatMtnWithHyphen('NewLine1');
    const mtn2 = formatMtnWithHyphen('1234-567890');
    const mtn3 = formatMtnWithHyphen('1234/567890');
    expect(mtn).toEqual('123-456-7890');
    expect(emptyMtn).toEqual(undefined);
    expect(newLineMtn).toEqual('NewLine1');
    expect(mtn2).toEqual('123-4-5-6789');
    expect(mtn3).toEqual('123-456-7890');
  });

  test('test allow only alphanumeric', () => {
    const data = allowOnlyAlphaNumeric('ABCxc');
    expect(data).toEqual(true);
  });
  test('test allow only alphanumeric', () => {
    const data = allowOnlyAlphaNumeric('');
    expect(data).toEqual(true);
  });
  test('test allow only alphanumeric', () => {
    const data = allowOnlyAlphaNumeric('!@#');
    expect(data).toEqual(false);
  });
});

describe('isEnabledTradeReturnOptionsInContactCenterApps', () => {
  afterEach(() => {
    // Clear sessionStorage after each test
    sessionStorage.clear();
  });

  it('should return true when all conditions are met', () => {
    // Mock sessionStorage values
    sessionStorage.setItem('channel', 'OMNI-TELESALES');
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        enableReturnAnywhereAssisted: 'true',
        enableReturnOptionsForTelesales: 'true',
      })
    );

    const result = isEnabledTradeReturnOptionsInContactCenterApps(true, false);

    expect(result).toBe(true);
  });

  it('should return false when showTradeAnywhereForBEWithoutEcpdCustomers is false', () => {
    sessionStorage.setItem('channel', 'OMNI-TELESALES');
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        enableReturnAnywhereAssisted: 'true',
        enableReturnOptionsForTelesales: 'true',
      })
    );

    const result = isEnabledTradeReturnOptionsInContactCenterApps(false, false);

    expect(result).toBe(false);
  });

  it('should return false when isCostcoAgent is true', () => {
    sessionStorage.setItem('channel', 'OMNI-TELESALES');
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        enableReturnAnywhereAssisted: 'true',
        enableReturnOptionsForTelesales: 'true',
      })
    );

    const result = isEnabledTradeReturnOptionsInContactCenterApps(true, true);

    expect(result).toBe(false);
  });

  it('should return false when channel does not match any eligible channels', () => {
    sessionStorage.setItem('channel', 'OTHER-CHANNEL');
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        enableReturnAnywhereAssisted: 'true',
        enableReturnOptionsForTelesales: 'true',
      })
    );

    const result = isEnabledTradeReturnOptionsInContactCenterApps(true, false);

    expect(result).toBe(false);
  });
});

describe('isSDDInCart', () => {
  it('should return true when SDD_SAMEDAY shipping code is present', () => {
    const props = {
      cartDetails: {
        lineDetails: {
          lineInfo: [
            {
              itemsInfo: [
                {
                  shipping: {
                    shippingCode: 'SDD_SAMEDAY',
                  },
                },
              ],
            },
          ],
        },
      },
    };

    const result = isSDDInCart(props);

    expect(result).toBe(true);
  });

  it('should return true when SDD_SAMEDAY_NVMP shipping code is present', () => {
    const props = {
      cartDetails: {
        lineDetails: {
          lineInfo: [
            {
              itemsInfo: [
                {
                  shipping: {
                    shippingCode: 'SDD_SAMEDAY_NVMP',
                  },
                },
              ],
            },
          ],
        },
      },
    };

    const result = isSDDInCart(props);

    expect(result).toBe(true);
  });

  it('should return false when no SDD shipping codes are present', () => {
    const props = {
      cartDetails: {
        lineDetails: {
          lineInfo: [
            {
              itemsInfo: [
                {
                  shipping: {
                    shippingCode: 'OTHER_CODE',
                  },
                },
              ],
            },
          ],
        },
      },
    };

    const result = isSDDInCart(props);

    expect(result).toBe(false);
  });

  it('should return false when lineInfo is empty', () => {
    const props = {
      cartDetails: {
        lineDetails: {
          lineInfo: [],
        },
      },
    };

    const result = isSDDInCart(props);

    expect(result).toBe(false);
  });

  it('should return false when cartDetails is undefined', () => {
    const props = {};

    const result = isSDDInCart(props);

    expect(result).toBe(false);
  });
});

describe('formatAccountNumber', () => {
  it('should format account number with 1-digit second part', () => {
    const fullAccountNumber = '12345-7';
    const result = formatAccountNumber(fullAccountNumber);
    expect(result).toBe('12345-00007');
  });

  it('should format account number with 2-digit second part', () => {
    const fullAccountNumber = '12345-12';
    const result = formatAccountNumber(fullAccountNumber);
    expect(result).toBe('12345-00012');
  });

  it('should return the account number as is if the second part has more than 2 digits', () => {
    const fullAccountNumber = '12345-123';
    const result = formatAccountNumber(fullAccountNumber);
    expect(result).toBe('12345-123');
  });

  it('should handle account numbers without a dash', () => {
    const fullAccountNumber = '12345';
    const result = formatAccountNumber(fullAccountNumber);
    expect(result).toBe('12345-undefined');
  });

  it('should handle empty strings gracefully', () => {
    const fullAccountNumber = '';
    const result = formatAccountNumber(fullAccountNumber);
    expect(result).toBe('-undefined');
  });
});

describe('allowOnlyNumbers', () => {
  it('should return true for numeric values', () => {
    expect(allowOnlyNumbers('12345')).toBe(true);
  });

  it('should return false for non-numeric values', () => {
    expect(allowOnlyNumbers('123a')).toBe(false);
  });

  it('should return true for an empty string', () => {
    expect(allowOnlyNumbers('')).toBe(true);
  });
});

describe('allowOnlyAlphaNumeric', () => {
  it('should return true for alphanumeric values', () => {
    expect(allowOnlyAlphaNumeric('abc123')).toBe(true);
  });

  it('should return false for non-alphanumeric values', () => {
    expect(allowOnlyAlphaNumeric('abc@123')).toBe(false);
  });

  it('should return true for an empty string', () => {
    expect(allowOnlyAlphaNumeric('')).toBe(true);
  });
});

describe('getDate', () => {
  it('should return formatted date for valid inputs', () => {
    expect(getDate('03', '05', '2023')).toBe('Mar 05');
  });

  it("should return today's date if inputs are missing", () => {
    const today = new Date();
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const expectedDate = `${monthNames[today.getMonth()]} ${today.getDate().toString().padStart(2, '0')}`;
    expect(getDate()).toBe(expectedDate);
  });
});

describe('convertDateRange', () => {
  it('should convert a date range to formatted string', () => {
    expect(convertDateRange('03/05/2023-03/10/2023')).toBe('Mar 05 - Mar 10');
  });

  it('should return the input if dateRange is null', () => {
    expect(convertDateRange(null)).toBe(null);
  });
});

describe('financedAmount', () => {
  it('should calculate the financed amount correctly', () => {
    const cartInfo = {
      lineDetails: {
        lineInfo: [
          {
            mobileNumber: '1234567890',
            itemsInfo: [
              {
                cartItems: {
                  cartItem: [
                    {
                      cartItemType: 'DEVICE',
                      discountedPrice: 500,
                      itemPrice: 600,
                    },
                  ],
                },
              },
            ],
            installmentInfo: {
              downPayment: 100,
            },
          },
        ],
      },
    };
    expect(financedAmount(cartInfo, '1234567890')).toBe(400);
  });

  it('should return 0 if cartInfo is null', () => {
    expect(financedAmount(null, '1234567890')).toBe(0);
  });

  it('should return 0 if no matching mobile number is found', () => {
    const cartInfo = {
      lineDetails: {
        lineInfo: [
          {
            mobileNumber: '0987654321',
          },
        ],
      },
    };
    expect(financedAmount(cartInfo, '1234567890')).toBe(0);
  });
});

describe('scmCheckoutMfeEnabled', () => {
  afterEach(() => {
    delete window.mfe;
  });

  it('should return true if scmCheckoutMfeEnable is true', () => {
    window.mfe = { scmCheckoutMfeEnable: true };
    expect(scmCheckoutMfeEnabled()).toBe(true);
  });

  it('should return undefined if window.mfe is undefined', () => {
    expect(scmCheckoutMfeEnabled()).toBeUndefined();
  });
});

describe('scmOnlyDeviceMfeEnabled', () => {
  afterEach(() => {
    delete window.mfe;
  });

  it('should return true if scmCheckoutMfeEnable is true and scmUpgradeMfeEnable is false', () => {
    window.mfe = { scmCheckoutMfeEnable: true, scmUpgradeMfeEnable: false };
    expect(scmOnlyDeviceMfeEnabled()).toBe(true);
  });

  it('should return false if scmCheckoutMfeEnable is false', () => {
    window.mfe = { scmCheckoutMfeEnable: false, scmUpgradeMfeEnable: false };
    expect(scmOnlyDeviceMfeEnabled()).toBe(false);
  });

  it('should return false if scmUpgradeMfeEnable is true', () => {
    window.mfe = { scmCheckoutMfeEnable: true, scmUpgradeMfeEnable: true };
    expect(scmOnlyDeviceMfeEnabled()).toBe(false);
  });

  it('should return undefined if window.mfe is undefined', () => {
    expect(scmOnlyDeviceMfeEnabled()).toBeUndefined();
  });
});

describe('formatDateOrdinal', () => {
  it('should test the method for different dates', () => {
    expect(formatDateOrdinal(new Date(moment('06/11/2025').format('MM/DD/YYYY')))).toBe('Jun 11th');

    expect(formatDateOrdinal(new Date(moment('06/03/2025').format('MM/DD/YYYY')))).toBe('Jun 3rd');

    expect(formatDateOrdinal(new Date(moment('06/02/2025').format('MM/DD/YYYY')))).toBe('Jun 2nd');

    expect(formatDateOrdinal(new Date(moment('06/01/2025').format('MM/DD/YYYY')))).toBe('Jun 1st');

    expect(formatDateOrdinal(new Date(moment('06/29/2025').format('MM/DD/YYYY')))).toBe('Jun 29th');

    expect(formatDateOrdinal(null)).toBe(null);
  });
});

describe('Common Utility Functions', () => {
  describe('getTotalMonthlyBill', () => {
    it('should calculate the total from billAccountData if monthlyTotals are not available', () => {
      const billAccount = [
        [
          { billSummary: { grandTotal: { newMonthCharge: '50' } } },
          { billSummary: { grandTotal: { newMonthCharge: '30' } } },
        ],
      ];
      const monthlyTotals = {};
      expect(getTotalMonthlyBill(billAccount, monthlyTotals)).toBe(80);
    });

    it('should calculate the total from billAccountData', () => {
      const billAccount = [
        [
          { billSummary: { grandTotal: { newMonthCharge: '50' } } },
          { billSummary: { grandTotal: { newMonthCharge: '30' } } },
        ],
      ];
      const monthlyTotals = { monthlyTotalsInfo: { newMonthCharge: 100 } };
      expect(getTotalMonthlyBill(billAccount, monthlyTotals)).toBe(100);
    });

    it('should calculate the total from billAccountData', () => {
      const billAccount = [
        [
          { billSummary: { grandTotal: { newMonthCharge: '50' } } },
          { billSummary: { grandTotal: { newMonthCharge: '30' } } },
        ],
      ];
      const monthlyTotals = { accountLevelChargesVo: { accountLevelTotalVo: { thisMonthCharge: 100 } } };
      expect(getTotalMonthlyBill(billAccount, monthlyTotals)).toBe(100);
    });

    it('should return an empty string if billAccountData is empty', () => {
      const billAccount = [];
      const monthlyTotals = {};
      expect(getTotalMonthlyBill(billAccount, monthlyTotals)).toBe('');
    });
  });

  describe('getEstimatedNextBillWithBillAccountNo', () => {
    it('should return nextMonthCharge from monthlyTotals if available and not in sub-account flow', () => {
      const billAccount = [[{ billAccountNo: '1234' }]];
      const monthlyTotals = {
        monthlyTotalsInfo: { nextMonthCharge: 150 },
      };
      const isSubAccountFlow = false;
      const expectedOutput = [{ billAccountNo: '1234', nextMonthCharge: 150 }];
      expect(getEstimatedNextBillWithBillAccountNo(billAccount, monthlyTotals, isSubAccountFlow)).toEqual(
        expectedOutput
      );
    });

    it('should calculate nextMonthCharge from billAccountData if monthlyTotals are not available', () => {
      const billAccount = [
        [
          {
            billAccountNo: '1234',
            billSummary: { grandTotal: { nextMonthCharge: '75' } },
          },
        ],
      ];
      const monthlyTotals = {};
      const isSubAccountFlow = false;
      const expectedOutput = [{ billAccountNo: '1234', nextMonthCharge: '75' }];
      expect(getEstimatedNextBillWithBillAccountNo(billAccount, monthlyTotals, isSubAccountFlow)).toEqual(
        expectedOutput
      );
    });

    it('should return an empty array if billAccountData is empty and no monthlyTotals are available', () => {
      const billAccount = [];
      const monthlyTotals = {};
      const isSubAccountFlow = false;
      expect(getEstimatedNextBillWithBillAccountNo(billAccount, monthlyTotals, isSubAccountFlow)).toEqual([]);
    });

    it('should return a default billAccountNo if no billAccountData is available but nextMonthCharge exists', () => {
      const billAccount = [];
      const monthlyTotals = {
        monthlyTotalsInfo: { nextMonthCharge: 150 },
      };
      const isSubAccountFlow = false;
      const expectedOutput = [{ billAccountNo: '0000', nextMonthCharge: 150 }];
      expect(getEstimatedNextBillWithBillAccountNo(billAccount, monthlyTotals, isSubAccountFlow)).toEqual(
        expectedOutput
      );
    });
  });
});

describe('useCradleState', () => {
  it('should return the correct cradle state when data exists', () => {
    // Mock the Redux state structure
    const mockState = {
      APIService: {
        queries: {
          'getCradleService({"body":{"properties":[{"name":"applicationId","value":"assisted"},{"name":"locationCode","value":"2777301"},{"name":"pageName","value":"SOEORDERSPRINT1"},{"name":"uswin","value":"mastral"},{"name":"platform","value":"desktop"},{"name":"locationSubType","value":""}]}, "spinner":false})':
            {
              data: {
                enableFullBlownMfeNbsPosFFlag: 'TRUE',
              },
            },
        },
      },
    };

    // Mock the return value of useSelector
    useSelector.mockImplementation((selector) => selector(mockState));

    // Call the hook
    const result = useCradleState();

    // Assert the result
    expect(result).toEqual(undefined);
  });
});
describe('getMTNList', () => {
  it('should render empty accounts', () => {
    getMTNList([{}]);
  });
  it('should render empty accounts', () => {
    getMTNList([]);
  });
  it('should render empty accounts', () => {
    getMTNList([{ mtns: {} }]);
  });
  it('should render empty mtns', () => {
    getMTNList([
      {
        mtns: {
          mtn: '3147522091',
          equipmentUpgradeEligibility: {
            upgradeEligibilityDate: '10/12/2025',
            upgradeEligible: true,
            twoYearContract: {},
          },
          mobileInfoAttributes: {
            smartFamilyParent: false,
          },
          equipmentInfos: [
            {
              deviceInfo: {
                modelName: 'Verizon Wireless Home Phone',
                deviceId: '354124113432504',
                deviceIdType: 'IME',
                deviceSku: 'WHPLVP2',
                SMSCapable: true,
              },
              simInfo: {
                modelName: 'GTO 4G 5G INTERIM DFILL SIM',
                simId: '89148000009224139750',
                simSku: 'DFILLSIM5G-SA-A',
              },
            },
          ],
          lineSharingIndicator: '',
          pricePlanInfo: {
            planId: '93792',
            planAttributes: {
              sharePlan: false,
            },
          },
        },
      },
    ]);
  });
});

describe('scmViewMultitaskMode',()=>{
  afterEach(()=>{
    delete window.mfe;
  });

  test('should return true',()=>{
    window.mfe={scmmultitask:true};
    expect(scmVtMultitaskMode()).toBe(true);
  })
  test('should return true',()=>{
    window.mfe={scmmultitask:false};
    expect(scmVtMultitaskMode()).toBe(false);
  })
  test('should return true',()=>{
    delete window.mfe;
    expect(scmVtMultitaskMode()).toBe(false);
  })
})

describe('isNullOrEmpty', () => {
  test('should return true for null', () => {
    expect(isNullOrEmpty(null)).toBe(true);
  });

  test('should return true for undefined', () => {
    expect(isNullOrEmpty(undefined)).toBe(true);
  });

  test('should return true for empty string', () => {
    expect(isNullOrEmpty('')).toBe(true);
  });

  test('should return true for string with only spaces', () => {
    expect(isNullOrEmpty('   ')).toBe(true);
  });

  test('should return true for string "null" (case insensitive)', () => {
    expect(isNullOrEmpty('null')).toBe(true);
    expect(isNullOrEmpty('NULL')).toBe(true);
    expect(isNullOrEmpty('Null')).toBe(true);
  });

  test('should return false for valid string', () => {
    expect(isNullOrEmpty('test')).toBe(false);
  });

  test('should return false for number', () => {
    expect(isNullOrEmpty(123)).toBe(false);
  });

  test('should return true for boolean false (falsy value)', () => {
    expect(isNullOrEmpty(false)).toBe(true);
  });

  test('should return false for object', () => {
    expect(isNullOrEmpty({})).toBe(false);
  });

  test('should return false for array', () => {
    expect(isNullOrEmpty([])).toBe(false);
  });
});

describe('isServiceChangeFlag', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  test('should return false when localStorage is empty', () => {
    expect(isServiceChangeFlag()).toBe(false);
  });

  test('should return false when featureEnablement is not set', () => {
    const userProfile = {
      aliasId: 'alias123',
      userId: 'user123',
      trainingEnabled: true
    };
    localStorage.setItem('userprofile', JSON.stringify(userProfile));
    expect(isServiceChangeFlag()).toBe(false);
  });

  test('should return false when featureEnablement is null', () => {
    localStorage.setItem('featureEnablement', null);
    expect(isServiceChangeFlag()).toBe(false);
  });

  test('should return false when featureEnablement is invalid JSON', () => {
    localStorage.setItem('featureEnablement', 'invalid-json');
    expect(isServiceChangeFlag()).toBe(false);
  });

  test('should return false when posTrainingScmFFlag is not "Y"', () => {
    const featureEnablement = {
      posTrainingScmFFlag: 'N'
    };
    const userProfile = {
      aliasId: 'alias123',
      userId: 'user123',
      trainingEnabled: true
    };
    localStorage.setItem('featureEnablement', JSON.stringify(featureEnablement));
    localStorage.setItem('userprofile', JSON.stringify(userProfile));
    expect(isServiceChangeFlag()).toBe(false);
  });

  test('should return false when userprofile is null', () => {
    const featureEnablement = {
      posTrainingScmFFlag: 'Y'
    };
    localStorage.setItem('featureEnablement', JSON.stringify(featureEnablement));
    localStorage.setItem('userprofile', null);
    expect(isServiceChangeFlag()).toBe(false);
  });

  test('should return false when userprofile is invalid JSON', () => {
    const featureEnablement = {
      posTrainingScmFFlag: 'Y'
    };
    localStorage.setItem('featureEnablement', JSON.stringify(featureEnablement));
    localStorage.setItem('userprofile', 'invalid-json');
    expect(isServiceChangeFlag()).toBe(false);
  });

  test('should return true when posTrainingScmFFlag is "Y", trainingEnabled is true and user data is valid', () => {
    const featureEnablement = {
      posTrainingScmFFlag: 'Y'
    };
    const userProfile = {
      aliasId: 'alias123',
      userId: 'user123',
      trainingEnabled: true
    };
    localStorage.setItem('featureEnablement', JSON.stringify(featureEnablement));
    localStorage.setItem('userprofile', JSON.stringify(userProfile));
    expect(isServiceChangeFlag()).toBe(true);
  });

  test('should return true when posTrainingScmFFlag is "Y", trainingEnabled is "Y" (uppercase string) and user data is valid', () => {
    const featureEnablement = {
      posTrainingScmFFlag: 'Y'
    };
    const userProfile = {
      aliasId: 'alias123',
      userId: 'user123',
      trainingEnabled: 'Y'
    };
    localStorage.setItem('featureEnablement', JSON.stringify(featureEnablement));
    localStorage.setItem('userprofile', JSON.stringify(userProfile));
    expect(isServiceChangeFlag()).toBe(true);
  });

  test('should return true when posTrainingScmFFlag is "Y", trainingEnabled is "y" (lowercase string) and user data is valid', () => {
    const featureEnablement = {
      posTrainingScmFFlag: 'Y'
    };
    const userProfile = {
      aliasId: 'alias123',
      userId: 'user123',
      trainingEnabled: 'y'
    };
    localStorage.setItem('featureEnablement', JSON.stringify(featureEnablement));
    localStorage.setItem('userprofile', JSON.stringify(userProfile));
    expect(isServiceChangeFlag()).toBe(true);
  });

  test('should return false when trainingEnabled is false', () => {
    const featureEnablement = {
      posTrainingScmFFlag: 'Y'
    };
    const userProfile = {
      aliasId: 'alias123',
      userId: 'user123',
      trainingEnabled: false
    };
    localStorage.setItem('featureEnablement', JSON.stringify(featureEnablement));
    localStorage.setItem('userprofile', JSON.stringify(userProfile));
    expect(isServiceChangeFlag()).toBe(false);
  });

  test('should return false when trainingEnabled is "N"', () => {
    const featureEnablement = {
      posTrainingScmFFlag: 'Y'
    };
    const userProfile = {
      aliasId: 'alias123',
      userId: 'user123',
      trainingEnabled: 'N'
    };
    localStorage.setItem('featureEnablement', JSON.stringify(featureEnablement));
    localStorage.setItem('userprofile', JSON.stringify(userProfile));
    expect(isServiceChangeFlag()).toBe(false);
  });

  test('should return false when userId is missing', () => {
    const featureEnablement = {
      posTrainingScmFFlag: 'Y'
    };
    const userProfile = {
      aliasId: 'alias123',
      trainingEnabled: true
    };
    localStorage.setItem('featureEnablement', JSON.stringify(featureEnablement));
    localStorage.setItem('userprofile', JSON.stringify(userProfile));
    expect(isServiceChangeFlag()).toBe(false);
  });

  test('should return false when userId is empty string', () => {
    const featureEnablement = {
      posTrainingScmFFlag: 'Y'
    };
    const userProfile = {
      aliasId: 'alias123',
      userId: '',
      trainingEnabled: true
    };
    localStorage.setItem('featureEnablement', JSON.stringify(featureEnablement));
    localStorage.setItem('userprofile', JSON.stringify(userProfile));
    expect(isServiceChangeFlag()).toBe(false);
  });

  test('should return false when aliasId is missing', () => {
    const featureEnablement = {
      posTrainingScmFFlag: 'Y'
    };
    const userProfile = {
      userId: 'user123',
      trainingEnabled: true
    };
    localStorage.setItem('featureEnablement', JSON.stringify(featureEnablement));
    localStorage.setItem('userprofile', JSON.stringify(userProfile));
    expect(isServiceChangeFlag()).toBe(false);
  });

  test('should return false when aliasId is empty string', () => {
    const featureEnablement = {
      posTrainingScmFFlag: 'Y'
    };
    const userProfile = {
      aliasId: '',
      userId: 'user123',
      trainingEnabled: true
    };
    localStorage.setItem('featureEnablement', JSON.stringify(featureEnablement));
    localStorage.setItem('userprofile', JSON.stringify(userProfile));
    expect(isServiceChangeFlag()).toBe(false);
  });

  test('should return false when both userId and aliasId are empty', () => {
    const featureEnablement = {
      posTrainingScmFFlag: 'Y'
    };
    const userProfile = {
      aliasId: '',
      userId: '',
      trainingEnabled: true
    };
    localStorage.setItem('featureEnablement', JSON.stringify(featureEnablement));
    localStorage.setItem('userprofile', JSON.stringify(userProfile));
    expect(isServiceChangeFlag()).toBe(false);
  });

  test('should return false when trainingEnabled is true but userId is null', () => {
    const featureEnablement = {
      posTrainingScmFFlag: 'Y'
    };
    const userProfile = {
      aliasId: 'alias123',
      userId: null,
      trainingEnabled: true
    };
    localStorage.setItem('featureEnablement', JSON.stringify(featureEnablement));
    localStorage.setItem('userprofile', JSON.stringify(userProfile));
    expect(isServiceChangeFlag()).toBe(false);
  });

  test('should return false when trainingEnabled is true but aliasId is null', () => {
    const featureEnablement = {
      posTrainingScmFFlag: 'Y'
    };
    const userProfile = {
      aliasId: null,
      userId: 'user123',
      trainingEnabled: true
    };
    localStorage.setItem('featureEnablement', JSON.stringify(featureEnablement));
    localStorage.setItem('userprofile', JSON.stringify(userProfile));
    expect(isServiceChangeFlag()).toBe(false);
  });

  test('should return false when trainingEnabled is undefined', () => {
    const featureEnablement = {
      posTrainingScmFFlag: 'Y'
    };
    const userProfile = {
      aliasId: 'alias123',
      userId: 'user123'
    };
    localStorage.setItem('featureEnablement', JSON.stringify(featureEnablement));
    localStorage.setItem('userprofile', JSON.stringify(userProfile));
    expect(isServiceChangeFlag()).toBe(false);
  });

  test('should handle localStorage.getItem throwing an error', () => {
    jest.spyOn(Storage.prototype, 'getItem').mockImplementation(() => {
      throw new Error('Storage error');
    });
    expect(isServiceChangeFlag()).toBe(false);
    Storage.prototype.getItem.mockRestore();
  });

  test('should handle JSON.parse throwing an error', () => {
    localStorage.setItem('userprofile', '{invalid json}');
    expect(isServiceChangeFlag()).toBe(false);
  });
})