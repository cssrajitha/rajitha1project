import {
  showShippingAddress,
  dFillItemPresent,
  isSplitFulfillmentEnabled,
  showShippingAddressQA,
  handleDisqualifiedPropositions,
} from './orderreviewUtil';

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: () => ['TRUE'],
  }),
  { virtual: true }
);

describe('showShippingAddress function', () => {
  // beforeEach(() => {
  // });
  it('should return true when shipping details are present and conditions are met', () => {
    const lines = [
      {
        itemsInfo: [
          {
            cartItems: { cartItem: [{ isCustomerProvidedSIM: true, cartItemType: 'SIM' }] },
          },
        ],
        lineActivityType: 'EUPBYOD',
      },
    ];

    const result = showShippingAddress(lines);
    expect(result).toBe(false);
  });
  it('should return true when shipping details are present and conditions are met No itemsInfo', () => {
    const lines = [
      {
        lineActivityType: 'EUPBYOD',
      },
    ];

    const result = showShippingAddress(lines);
    expect(result).toBe(false);
  });
  it('should return true when shipping details are present and conditions are met cartItemType ACCESSORY', () => {
    const lines = [
      {
        itemsInfo: [
          {
            cartItems: { cartItem: [{ isCustomerProvidedSIM: true, cartItemType: 'ACCESSORY' }] },
          },
        ],
        lineActivityType: 'EUPBYOD',
      },
    ];

    const result = showShippingAddress(lines);
    expect(result).toBe(false);
  });

  it('should return false when shipping details are not present', () => {
    const lines = [
      {
        itemsInfo: [
          {
            cartItems: { cartItem: [{ isCustomerProvidedSIM: true, cartItemType: 'SIM' }] },
          },
        ],
        lineActivityType: 'EUPBYOD',
      },
    ];

    const result = showShippingAddress(lines);
    expect(result).toBe(false);
  });

  it('should return true for specific conditions', () => {
    const lines = [
      {
        itemsInfo: [
          {
            cartItems: { cartItem: [{ isCustomerProvidedSIM: false, cartItemType: 'ACCESSORY' }] },
          },
        ],
        lineActivityType: 'EUPBYOD',
      },
    ];

    const result = showShippingAddress(lines);
    expect(result).toBe(false);
  });

  it('should return false for specific conditions', () => {
    const lines = [
      {
        itemsInfo: [
          {
            cartItems: { cartItem: [{ isCustomerProvidedSIM: true, cartItemType: 'SIM' }] },
          },
        ],
        lineActivityType: 'BYOD',
      },
    ];

    const result = showShippingAddress(lines);
    expect(result).toBe(false);
  });
  it('should return false for specific conditions cartItem []', () => {
    const lines = [
      {
        itemsInfo: [
          {
            cartItems: { cartItem: [] },
          },
        ],
        lineActivityType: 'BYOD',
      },
    ];

    const result = showShippingAddress(lines);
    expect(result).toBe(false);
  });
  it('should return false for specific conditions cartItems {}', () => {
    const lines = [
      {
        itemsInfo: [
          {
            cartItems: {},
          },
        ],
        lineActivityType: 'BYOD',
      },
    ];

    const result = showShippingAddress(lines);
    expect(result).toBe(false);
  });
  it('should return false for specific conditions cartItems No', () => {
    const lines = [
      {
        itemsInfo: [{}],
        lineActivityType: 'BYOD',
      },
    ];

    const result = showShippingAddress(lines);
    expect(result).toBe(false);
  });
  it('should return false for specific conditions itemsInfo []', () => {
    const lines = [
      {
        itemsInfo: [],
        lineActivityType: 'BYOD',
      },
    ];

    const result = showShippingAddress(lines);
    expect(result).toBe(false);
  });

  it('should return true for specific conditions with BYOD', () => {
    const lines = [
      {
        itemsInfo: [{ shipping: { shippingCode: '0001' }, cartItems: { cartItem: [{ cartItemType: 'ACCESSORY' }] } }],
        lineActivityType: 'BYOD',
      },
    ];

    const result = showShippingAddress(lines);
    expect(result).toBe(true);
  });

  it('should return true for specific conditions with BYOD and SIM', () => {
    const lines = [
      {
        itemsInfo: [
          {
            shipping: { shippingCode: '0001' },
            cartItems: { cartItem: [{ isCustomerProvidedSIM: true, cartItemType: 'SIM' }] },
          },
        ],
        lineActivityType: 'BYOD',
      },
    ];

    const result = showShippingAddress(lines);
    expect(result).toBe(false);
  });

  it('should return true for QA flow with Shipping', () => {
    const lines = [
      {
        itemsInfo: [
          {
            depletionType: 'F',
            cartItems: { cartItem: [{ cartItemType: 'ACCESSORY' }] },
          },
        ],
      },
    ];

    const result = showShippingAddressQA(lines);
    expect(result).toBe(true);
  });

  it('should return false for QA flow without shipping', () => {
    const lines = [
      {
        itemsInfo: [
          {
            depletionType: 'L',
            cartItems: { cartItem: [{ cartItemType: 'ACCESSORY' }] },
          },
        ],
      },
    ];

    const result = showShippingAddressQA(lines);
    expect(result).toBe(false);
  });

  it('should return false for QA flow with invalid cart 1', () => {
    const lines = [
      {
        itemsInfo: [],
      },
    ];

    const result = showShippingAddressQA(lines);
    expect(result).toBe(false);
  });

  it('should return false for QA flow with invalid cart 2', () => {
    const lines = [
      {
        itemsInfo: [
          {
            depletionType: 'L',
            cartItems: { cartItem: [] },
          },
        ],
      },
    ];

    const result = showShippingAddressQA(lines);
    expect(result).toBe(false);
  });

  it('should return false for QA flow with invalid cart 3', () => {
    const lines = [
      {
        itemsInfo: [
          {
            depletionType: 'L',
            cartItems: {},
          },
        ],
      },
    ];

    const result = showShippingAddressQA(lines);
    expect(result).toBe(false);
  });

  it('should return false for QA flow with invalid cart 4', () => {
    const lines = [{}];

    const result = showShippingAddressQA(lines);
    expect(result).toBe(false);
  });

  it('should return true if dfill item present in cart', () => {
    const lines = [
      {
        itemsInfo: [
          {
            shipping: { shippingCode: '0001' },
            cartItems: { cartItem: [{ depletionType: 'F' }] },
          },
        ],
        lineActivityType: 'AAL',
      },
    ];

    const result = dFillItemPresent(lines);
    expect(result).toBe(true);
  });

  it('should return false if dfill item present in cart', () => {
    const lines = [
      {
        itemsInfo: [
          {
            shipping: { shippingCode: '0001' },
            cartItems: { cartItem: [{ depletionType: 'L' }] },
          },
        ],
        lineActivityType: 'AAL',
      },
    ];

    const result = dFillItemPresent(lines);
    expect(result).toBe(false);
  });

  it('should return false if dfill item present in cart', () => {
    const lines = [
      {
        lineActivityType: 'AAL',
      },
    ];

    const result = dFillItemPresent(lines);
    expect(result).toBe(false);
  });

  it('should return false if dfill item present in cart', () => {
    const lines = [
      {
        itemsInfo: [
          {
            shipping: { shippingCode: '0001' },
            cartItems: {},
          },
        ],
        lineActivityType: 'AAL',
      },
    ];

    const result = dFillItemPresent(lines);
    expect(result).toBe(false);
  });

  it('should return false if dfill item present in cart', () => {
    const lines = [
      {
        itemsInfo: [
          {
            shipping: { shippingCode: '0001' },
          },
        ],
        lineActivityType: 'AAL',
      },
    ];

    const result = dFillItemPresent(lines);
    expect(result).toBe(false);
  });

  it('should return false if dfill item present in cart', () => {
    const lines = [];

    const result = dFillItemPresent(lines);
    expect(result).toBe(false);
  });

  it('should return false if dfill item present in cart', () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'TRUE' }));
    const result = isSplitFulfillmentEnabled(true);
    expect(result).toBe(true);
  });
  it('should return false if dfill item present in cart', () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'TRUE' }));
    const result = isSplitFulfillmentEnabled();
    expect(result).toBe(false);
  });
});

describe('handleDisqualifiedPropositions function', () => {
  let mockUpdateVisionRemark;
  let consoleSpy;

  beforeEach(() => {
    mockUpdateVisionRemark = jest.fn();
    consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('should return early when lineData is null or undefined', () => {
    handleDisqualifiedPropositions(null, {}, mockUpdateVisionRemark);
    expect(mockUpdateVisionRemark).not.toHaveBeenCalled();

    handleDisqualifiedPropositions(undefined, {}, mockUpdateVisionRemark);
    expect(mockUpdateVisionRemark).not.toHaveBeenCalled();
  });

  it('should return early when lineData is not an array', () => {
    handleDisqualifiedPropositions('invalid', {}, mockUpdateVisionRemark);
    expect(mockUpdateVisionRemark).not.toHaveBeenCalled();

    handleDisqualifiedPropositions({}, {}, mockUpdateVisionRemark);
    expect(mockUpdateVisionRemark).not.toHaveBeenCalled();
  });

  it('should return early when updateVisionRemark is not provided', () => {
    const lineData = [{
      mobileNumber: '1234567890',
      disqualifiedPropositions: [{ chargeBackAmount: 10 }]
    }];
    
    handleDisqualifiedPropositions(lineData, {}, null);
    expect(mockUpdateVisionRemark).not.toHaveBeenCalled();

    handleDisqualifiedPropositions(lineData, {}, undefined);
    expect(mockUpdateVisionRemark).not.toHaveBeenCalled();
  });

  it('should not process lines without disqualified propositions', () => {
    const lineData = [
      { mobileNumber: '1234567890' },
      { mobileNumber: '0987654321', disqualifiedPropositions: [] }
    ];
    const customer = {
      customerId: 'CUST123',
      billAccounts: [{ billAccountNo: 'BILL456' }],
      customerName: { firstName: 'John', lastName: 'Doe' },
      billingSystem: 'VISION',
      orderLocationCode: 'LOC001'
    };

    handleDisqualifiedPropositions(lineData, customer, mockUpdateVisionRemark);
    expect(mockUpdateVisionRemark).not.toHaveBeenCalled();
  });

  it('should not process lines with disqualified propositions but chargeBackAmount <= 0', () => {
    const lineData = [{
      mobileNumber: '1234567890',
      disqualifiedPropositions: [
        { chargeBackAmount: 0, chargeBackBillDesc: 'Offer1' },
        { chargeBackAmount: -5, chargeBackBillDesc: 'Offer2' }
      ]
    }];
    const customer = {
      customerId: 'CUST123',
      billAccounts: [{ billAccountNo: 'BILL456' }],
      customerName: { firstName: 'John', lastName: 'Doe' },
      billingSystem: 'VISION',
      orderLocationCode: 'LOC001'
    };

    handleDisqualifiedPropositions(lineData, customer, mockUpdateVisionRemark);
    expect(mockUpdateVisionRemark).not.toHaveBeenCalled();
  });

  it('should process single line with valid disqualified propositions', () => {
    const lineData = [{
      mobileNumber: '1234567890',
      disqualifiedPropositions: [
        { chargeBackAmount: 15.50, chargeBackBillDesc: 'Premium Plan Offer' },
        { chargeBackAmount: 0, chargeBackBillDesc: 'Invalid Offer' }, // Should be filtered out
        { chargeBackAmount: 25.00, chargeBackBillDesc: 'Unlimited Data Offer' }
      ]
    }];
    const customer = {
      customerId: 'CUST123',
      billAccounts: [{ billAccountNo: 'BILL456' }],
      customerName: { firstName: 'John', lastName: 'Doe' },
      billingSystem: 'VISION',
      orderLocationCode: 'LOC001'
    };

    handleDisqualifiedPropositions(lineData, customer, mockUpdateVisionRemark);

    expect(mockUpdateVisionRemark).toHaveBeenCalledTimes(1);
    
    const callArg = mockUpdateVisionRemark.mock.calls[0][0].body;
    expect(callArg.mdn).toBe('1234567890');
    expect(callArg.remarkText).toContain('Plan Change Chargeback MDN 123.456.7890 chargeback applied of $15.5 for offer Premium Plan Offer');
    expect(callArg.remarkText).toContain('Plan Change Chargeback MDN 123.456.7890 chargeback applied of $25 for offer Unlimited Data Offer');
    expect(callArg.customerId).toBe('CUST123');
    expect(callArg.billAccountNumber).toBe('BILL456');
    expect(callArg.contactName).toBe('John Doe');
    expect(callArg.billingSystem).toBe('VISION');
    expect(callArg.location).toBe('LOC001');
  });

  it('should process multiple lines with valid disqualified propositions', () => {
    const lineData = [
      {
        mobileNumber: '1234567890',
        disqualifiedPropositions: [
          { chargeBackAmount: 10.00, chargeBackBillDesc: 'Basic Plan' }
        ]
      },
      {
        mobileNumber: '0987654321',
        disqualifiedPropositions: [
          { chargeBackAmount: 20.00, chargeBackBillDesc: 'Premium Plan' },
          { chargeBackAmount: 5.50, chargeBackBillDesc: 'Add-on Service' }
        ]
      }
    ];
    const customer = {
      customerId: 'CUST789',
      billAccounts: [{ billAccountNo: 'BILL012' }],
      customerName: { firstName: 'Jane', lastName: 'Smith' },
      billingSystem: 'VISION',
      orderLocationCode: 'LOC002'
    };

    handleDisqualifiedPropositions(lineData, customer, mockUpdateVisionRemark);

    expect(mockUpdateVisionRemark).toHaveBeenCalledTimes(2);
    
    // Check first call
    const firstCall = mockUpdateVisionRemark.mock.calls[0][0].body;
    expect(firstCall.mdn).toBe('1234567890');
    expect(firstCall.remarkText).toContain('Plan Change Chargeback MDN 123.456.7890 chargeback applied of $10 for offer Basic Plan');
    
    // Check second call
    const secondCall = mockUpdateVisionRemark.mock.calls[1][0].body;
    expect(secondCall.mdn).toBe('0987654321');
    expect(secondCall.remarkText).toContain('Plan Change Chargeback MDN 098.765.4321 chargeback applied of $20 for offer Premium Plan');
    expect(secondCall.remarkText).toContain('Plan Change Chargeback MDN 098.765.4321 chargeback applied of $5.5 for offer Add-on Service');
  });

  it('should handle missing customer fields gracefully', () => {
    const lineData = [{
      mobileNumber: '1234567890',
      disqualifiedPropositions: [
        { chargeBackAmount: 15.00, chargeBackBillDesc: 'Test Offer' }
      ]
    }];
    const customer = {
      // Missing most fields to test fallbacks
    };

    handleDisqualifiedPropositions(lineData, customer, mockUpdateVisionRemark);

    expect(mockUpdateVisionRemark).toHaveBeenCalledTimes(1);
    
    const callArg = mockUpdateVisionRemark.mock.calls[0][0].body;
    expect(callArg.customerId).toBe('');
    expect(callArg.billAccountNumber).toBe('');
    expect(callArg.contactName).toBe('');
    expect(callArg.billingSystem).toBe('');
    expect(callArg.location).toBe('');
  });

  it('should handle partial customer name correctly', () => {
    const lineData = [{
      mobileNumber: '1234567890',
      disqualifiedPropositions: [
        { chargeBackAmount: 15.00, chargeBackBillDesc: 'Test Offer' }
      ]
    }];

    // Test with only first name
    const customerFirstOnly = {
      customerName: { firstName: 'John' }
    };
    handleDisqualifiedPropositions(lineData, customerFirstOnly, mockUpdateVisionRemark);
    let callArg = mockUpdateVisionRemark.mock.calls[0][0].body;
    expect(callArg.contactName).toBe('John');

    // Reset mock
    mockUpdateVisionRemark.mockClear();

    // Test with only last name
    const customerLastOnly = {
      customerName: { lastName: 'Doe' }
    };
    handleDisqualifiedPropositions(lineData, customerLastOnly, mockUpdateVisionRemark);
    callArg = mockUpdateVisionRemark.mock.calls[0][0].body;
    expect(callArg.contactName).toBe('Doe');
  });

  it('should handle lines with mixed valid and invalid chargeBackAmounts', () => {
    const lineData = [
      {
        mobileNumber: '1234567890',
        disqualifiedPropositions: [
          { chargeBackAmount: 15.00, chargeBackBillDesc: 'Valid Offer' }
        ]
      },
      {
        mobileNumber: '0987654321',
        disqualifiedPropositions: [
          { chargeBackAmount: 0, chargeBackBillDesc: 'Zero Amount' },
          { chargeBackAmount: -5, chargeBackBillDesc: 'Negative Amount' }
        ]
      }
    ];
    const customer = {
      customerId: 'CUST123',
      billAccounts: [{ billAccountNo: 'BILL456' }],
      customerName: { firstName: 'John', lastName: 'Doe' }
    };

    handleDisqualifiedPropositions(lineData, customer, mockUpdateVisionRemark);

    // Should only process the first line, second line should be filtered out
    expect(mockUpdateVisionRemark).toHaveBeenCalledTimes(1);
    const callArg = mockUpdateVisionRemark.mock.calls[0][0].body;
    expect(callArg.mdn).toBe('1234567890');
  });

  it('should handle edge cases with null/undefined values gracefully', () => {
    const lineData = [
      {
        mobileNumber: null, // null mobile number
        disqualifiedPropositions: [
          { chargeBackAmount: 15.00, chargeBackBillDesc: 'Valid Offer' }
        ]
      }
    ];
    const customer = {};

    handleDisqualifiedPropositions(lineData, customer, mockUpdateVisionRemark);

    // Should still process the line even with null mobile number
    expect(mockUpdateVisionRemark).toHaveBeenCalledTimes(1);
    const callArg = mockUpdateVisionRemark.mock.calls[0][0].body;
    expect(callArg.mdn).toBe(null);
    expect(callArg.remarkText).toContain('undefined'); // formatMtnWithDecimals returns undefined for null
  });

  it('should verify all required request properties are set correctly', () => {
    const lineData = [{
      mobileNumber: '5551234567',
      disqualifiedPropositions: [
        { chargeBackAmount: 30.75, chargeBackBillDesc: 'Enterprise Plan' }
      ]
    }];
    const customer = {
      customerId: 'ENTERPRISE123',
      billAccounts: [{ billAccountNo: 'ENT789' }],
      customerName: { firstName: 'Corporate', lastName: 'Account' },
      billingSystem: 'ENTERPRISE',
      orderLocationCode: 'HQ001'
    };

    handleDisqualifiedPropositions(lineData, customer, mockUpdateVisionRemark);

    const req = mockUpdateVisionRemark.mock.calls[0][0].body;
    expect(req).toEqual({
      mdn: '5551234567',
      requestMapping: 'autoRemarksUpdate',
      contactName: 'Corporate Account',
      billAccountType: 'C',
      location: 'HQ001',
      page: '1',
      accessLvl: '1',
      remarkText: 'Plan Change Chargeback MDN 555.123.4567 chargeback applied of $30.75 for offer Enterprise Plan due to moving to an non-qualifying plan',
      customerId: 'ENTERPRISE123',
      billingSystem: 'ENTERPRISE',
      billAccountNumber: 'ENT789',
      remarkType: '',
      remarkLevel: 'A',
    });
  });
});
