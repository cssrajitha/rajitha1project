import { renderHook } from '@testing-library/react';
import { useVbgDetection } from './vbgDetection';

// Mock isVbg before importing the hook
jest.mock('onevzsoemfeframework/VbgAemUtil', () => ({
  isVbg: jest.fn(),
}));
describe('VBG Utils', () => {
  it('should return true when isVbg returns true', () => {
    // eslint-disable-next-line global-require
    const { isVbg } = require('onevzsoemfeframework/VbgAemUtil');
    isVbg.mockReturnValue(true);
    const { result } = renderHook(() => useVbgDetection());
    expect(result.current).toBe(true);
  });
  it('should return false when isVbg returns false', () => {
    // eslint-disable-next-line global-require
    const { isVbg } = require('onevzsoemfeframework/VbgAemUtil');
    isVbg.mockReturnValue(false);
    const { result } = renderHook(() => useVbgDetection());
    expect(result.current).toBe(false);
  });
});