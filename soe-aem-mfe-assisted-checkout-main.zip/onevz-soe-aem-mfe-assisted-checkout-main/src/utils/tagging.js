import { sendCustomEvent } from 'onevzsoemfeframework/Tagging';

// This is for openView Tagging call
export function callOpenViewMFE(data) {
  /* istanbul ignore else */
  if (data && data !== undefined) {
    basicTaggingInfo(data);
    if (window?.vzdl) {
      sendCustomEvent('openView', window.vzdl);
    }
  }
}

// This is for pageView Tagging call
export function callPageViewMFE(data) {
  /* istanbul ignore else */
  if (data && data !== undefined) {
    basicTaggingInfo(data);
    if (window?.vzdl) {
      sendCustomEvent('pageView', window.vzdl);
    }
  }
}

export function callNotificationMFE(data) {
  /* istanbul ignore else */
  if (data && data !== undefined) {
    commonTaggingData(data);
    /* istanbul ignore else */
    if (window?.vzdl) {
      window.vzdl.target = window?.vzdl?.target || {};
      window.vzdl.target.message = data?.message || '';
      sendCustomEvent('notification', window?.vzdl);
    }
  }
}

function commonData(pagedetail, link, flow, name, rspFetchReadOrder, customerProfileResponse) {
  const extractDescriptions = (data) => {
    const descriptionsSet = new Set();

    const traverse = (obj) => {
      if (typeof obj === 'object' && obj !== null) {
        if (obj.pricePlanInfo && obj.pricePlanInfo.description) {
          const { description } = obj.pricePlanInfo;
          if (description) {
            descriptionsSet.add(description);
          }
        }
        Object.values(obj).forEach((value) => traverse(value));
      } else if (Array.isArray(obj)) {
        obj.forEach((item) => traverse(item));
      }
    };

    traverse(data);
    return Array.from(descriptionsSet).join(' | ');
  };

  const planTypeDescriptions = extractDescriptions(customerProfileResponse);
  return {
    channel: 'Order',
    detail: pagedetail || '',
    link: link || '',
    flow: flow || '',
    name: name || 'read-order',
    displayChannel: 'Retail',
    intent: 'Order',
    cartId: sessionStorage?.getItem('cartId') || rspFetchReadOrder?.data?.data?.cart?.cartHeader?.cartId,
    eligibleLines: rspFetchReadOrder?.data?.data?.cart?.lineDetails?.numOfLinesNSE || '',
    isAutoPayEnrolled: rspFetchReadOrder?.data?.data?.cart?.lineDetails?.isAutoPayEnrolled || '',
    accountNumber:
      rspFetchReadOrder?.data?.data?.cart?.lineDetails?.subAccountNBSInfo?.billAccounts?.nbs?.accountNumber || '',
    accountAddress: {
      zipCode: rspFetchReadOrder?.data?.data?.cart?.lineDetails?.lineInfo?.serviceInfo?.cart5GAddress?.zipCode || '',
    },
    customerType: customerProfileResponse?.data?.data?.customer?.customerAttributes?.customerType || '',
    id: customerProfileResponse?.data?.data?.customer?.billAccounts[0]?.mtns[0]?.mtnHashCode || '',
    account: customerProfileResponse?.data?.data?.customer?.customerHash || '',
    planType: planTypeDescriptions || '',
    zipCode: customerProfileResponse?.data?.data?.customer?.address?.zipCode || '',
    accountLast2: customerProfileResponse?.data?.data?.customer?.accountNo?.slice(-2) || '',
    acctId_unhashed: customerProfileResponse?.data?.data?.customer?.accountNo || '',
  };
}

export const OpenViewTagging = (pagedetail, link, flow, name, rspFetchReadOrder) => {
  const data = commonData(pagedetail, link, flow, name, rspFetchReadOrder);
  callOpenViewMFE(data);
};

export const PageViewTagging = (pagedetail, link, flow, name, rspFetchReadOrder, customerProfileResponse) => {
  console.log('PageViewTagging', pagedetail, link, flow, name, rspFetchReadOrder, customerProfileResponse);
  const data = commonData(pagedetail, link, flow, name, rspFetchReadOrder, customerProfileResponse);
  callPageViewMFE(data);
};

export const NotificationTagging = (detail, link, message, flow, name, rspFetchReadOrder, customerProfileResponse) => {
  const data = commonData(detail, link, flow, name, rspFetchReadOrder, customerProfileResponse);
  data.message = message || '';
  callNotificationMFE(data);
};

export function commonTaggingData(data) {
  const numberOfActiveLine = sessionStorage.getItem('numberOfLines') || '';
  const numberOfLine = data?.eligibleLines?.split('/') || [];
  const agentRole = (numberOfActiveLine || numberOfLine[0]) >= 3 ? 'MGR' : 'REP';
  const location = sessionStorage.getItem('location') || '';
  window.vzdl = {};
  if (window?.vzdl) {
    window.vzdl.event = {};
    window.vzdl.env = {};
    window.vzdl.page = {};
    window.vzdl.target = {};
    window.vzdl.txn = {};
    window.vzdl.event.value = '';
    window.vzdl.env.businessUnit = '';
    window.vzdl.page.channel = '';
    window.vzdl.page.link = '';
    window.vzdl.page.detail = '';
    window.vzdl.page.flow = '';
    window.vzdl.page.name = '';
    window.vzdl.page.subFlow = '';
    window.vzdl.page.contentFragments = '';
    window.vzdl.page.repeatCartVisitor = '';
    window.vzdl.page.fireProactiveChat = '';
    window.vzdl.page.language = '';
    window.vzdl.page.url = window?.location?.href || '';
    window.vzdl.target.engagement = {};
    window.vzdl.target.engagement.intent = '';
    window.vzdl.target.message = '';
    window.vzdl.target.offer = '';
    window.vzdl.target.assetsRequested = '';
    window.vzdl.target.assetAttributes = '';
    window.vzdl.target.assetsLeveraged = '';
    window.vzdl.target.abTest = '';
    window.vzdl.target.campaign = '';
    window.vzdl.target.experience = '';
    window.vzdl.target.cloud = '';
    window.vzdl.target.mktgId = '';
    window.vzdl.target.sandBox = '';
    window.vzdl.target.engagement = {};
    window.vzdl.target.engagement.offered = '';
    window.vzdl.target.engagement.id = '';
    window.vzdl.platform = {};
    window.vzdl.platform.call = '';
    window.vzdl.search = {};
    window.vzdl.search.term = '';
    window.vzdl.search.type = '';
    window.vzdl.search.results = '';
    window.vzdl.support = {};
    window.vzdl.support.issueNumber = '';
    window.vzdl.support.tsaIssueName = '';
    window.vzdl.support.tsaStepName = '';
    window.vzdl.cmp = {};
    window.vzdl.cmp.all = '';
    window.vzdl.park = {};
    window.vzdl.park.csFlag = 'true';
    window.vzdl.error = {};
    window.vzdl.error.code = '';
    window.vzdl.error.code = data?.code || '';
    window.vzdl.env.businessUnit = 'Wireless';
    window.vzdl.page.channel = data?.channel || '';
    window.vzdl.page.link = data?.link || '';
    window.vzdl.page.channelSession =
      sessionStorage.getItem('analyticssessionid') ||
      sessionStorage.getItem('soeguisubkey') ||
      sessionStorage.getItem('prevsoeguisubkey') ||
      sessionStorage.getItem('vzdlChannelSession') ||
      '';
    window.vzdl.page.detail = data?.detail || '';
    window.vzdl.page.displayChannel = 'Retail';
    window.vzdl.page.flow = data?.flow || '';
    window.vzdl.page.name = data?.name || '';
    window.vzdl.page.sourceChannel = 'POS';
    window.vzdl.page.throttle = 'MFE';
    window.vzdl.target.engagement.intent = 'order';
    window.vzdl.txn.id = '';
    window.vzdl.txn.offer = '';
    window.vzdl.txn.discountId = '';
    window.vzdl.txn.orderType = '';
    window.vzdl.txn.status = '';
    window.vzdl.txn.quoteId = '';
    window.vzdl.txn.paymentType = '';
    window.vzdl.txn.shippingZip = '';
    window.vzdl.txn.shippingTotal = '';
    window.vzdl.txn.tradeInQty = '';
    window.vzdl.txn.tradeInAmt = '';
    window.vzdl.txn.total = '';
    window.vzdl.txn.taxAmt = '';
    window.vzdl.txn.recurringPrice = '';
    window.vzdl.txn.nonRecurringPrice = '';
    window.vzdl.txn.futurePayment = '';
    window.vzdl.txn.installOptions = '';
    window.vzdl.txn.discount = '';
    window.vzdl.txn.paymentAmt = '';
    window.vzdl.txn.reasonCode = '';
    window.vzdl.txn.reviewOption = '';
    window.vzdl.txn.txnDetail = '';
    window.vzdl.txn.shippingState = '';
    window.vzdl.txn.agent = sessionStorage.getItem('userId') || '';
    window.vzdl.txn.agentRole = agentRole;
    window.vzdl.txn.autoPay = data?.isAutoPayEnrolled === true ? 'Y' : 'N';
    window.vzdl.txn.outletId = location;
    window.vzdl.txn.cartId = sessionStorage.getItem('cartId') || data?.cartId || '';
    window.vzdl.txn.product = {};
    window.vzdl.txn.product.current = [];
    window.vzdl.txn.product.owns = [];
    window.vzdl.txn.product.current.push({
      action: '',
      category: '',
      contractType: '',
      discount: 0,
      group: '',
      id: '',
      lineHash: '',
      merchCat: '',
      name: '',
      nonRecurringPrice: 0,
      offer: '',
      orderType: '',
      path: '',
      propId: '',
      qty: 0,
      recurringPrice: 0,
      shared: '',
      shippingCharge: 0,
      shippingType: '',
      sku: '',
    });
    window.vzdl.txn.product.owns.push({
      category: '',
      id: '',
      name: '',
      recurringPrice: '',
    });
    window.vzdl.utils = {};
    window.vzdl.utils.athenaSession = '';
    window.vzdl.utils.pegaCaseId = '';
    window.vzdl.utils.pegaOffer = '';
    window.vzdl.utils.StrategyApiKey = '';
    window.vzdl.utils.appApiKey = '';
    window.vzdl.utils.outcome = '';
  }
}

export function basicTaggingInfo(data) {
  const numberOfActiveLineData = sessionStorage.getItem('numberOfLines') || '';
  const numberOfLineData = data?.eligibleLines?.split('/') || [];
  const customerRole = (numberOfActiveLineData || numberOfLineData[0]) >= 3 ? 'Account holder' : 'Account owner';
  /* istanbul ignore else */
  if (data && data !== undefined) {
    commonTaggingData(data);
    window.vzdl.user = {};
    if (window?.vzdl?.user) {
      window.vzdl.user.account = data?.account || '';
      window.vzdl.user.accountLast2 = data?.accountLast2 || '';
      window.vzdl.user.acctId_unhashed = data?.acctId_unhashed || '';
      window.vzdl.user.id = data?.id || '';

      window.vzdl.user.accountType = 'Postpaid';
      window.vzdl.user.authStatus = 'Logged in';
      window.vzdl.user.customerRole = customerRole || '';
      window.vzdl.user.customerType = data?.customerType || '';
      window.vzdl.user.numberOfLines = numberOfActiveLineData || numberOfLineData[0] || '';
      window.vzdl.user.tenure = sessionStorage.getItem('tenure') || '';
      window.vzdl.user.zip = data?.zipCode || '';
      window.vzdl.user.session = '';
      window.vzdl.user.existingServices = '';
      window.vzdl.user.userid = '';
      window.vzdl.user.planType = data?.planType || '';
      window.vzdl.user.authType = '';
      window.vzdl.user.prospect = '';
      window.vzdl.user.chatId = sessionStorage.getItem('chatId') || '';
      window.vzdl.user.childId = '';
      window.vzdl.user.creditAppNum = '';
      window.vzdl.user.crmHashEmail = '';
      window.vzdl.user.deviceDollars = '';
      window.vzdl.user.productsQualified = '';
      window.vzdl.user.custId_unhashed = data?.lookupMtn || sessionStorage.getItem('aaAssistMTN') || '';
      window.vzdl.user.visionAcctID_unhashed = '';
      window.vzdl.user.visionCustID_unhashed = '';
      window.vzdl.user.cdUserId = '';
      window.vzdl.user.amid = '';
      window.vzdl.user.agentDeviceId = '';
      window.vzdl.user.deviceDetail = '';
    }
  }
}
