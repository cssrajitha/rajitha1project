import { sendCustomEvent } from 'onevzsoemfeframework/Tagging';
import {
  callOpenViewMFE,
  callPageViewMFE,
  callNotificationMFE,
  commonTaggingData,
  basicTaggingInfo,
  OpenViewTagging,
  NotificationTagging,
  PageViewTagging,
} from './tagging';

jest.mock('onevzsoemfeframework/Tagging');

describe('Tagging Functions', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    window.vzdl = {};
  });

  describe('callOpenViewMFE', () => {
    it('should initialize and populate vzdl and call sendCustomEvent with openView', () => {
      const data = { channel: 'Order', detail: 'testDetail' };
      callOpenViewMFE(data);
      expect(window.vzdl.page.detail).toBe('testDetail');
      expect(sendCustomEvent).toHaveBeenCalledWith('openView', window.vzdl);
    });

    it('should initialize and populate vzdl and call sendCustomEvent with openView', () => {
      const data = { channel: null, detail: null };
      callOpenViewMFE(data);
    });

    it('should handle undefined data gracefully', () => {
      callOpenViewMFE(undefined);
      expect(sendCustomEvent).not.toHaveBeenCalled();
    });
  });

  describe('callPageViewMFE', () => {
    it('should initialize and populate vzdl and call sendCustomEvent with pageView', () => {
      const data = { channel: 'Order', detail: 'testDetail' };
      callPageViewMFE(data);
      expect(window.vzdl.page.detail).toBe('testDetail');
      expect(sendCustomEvent).toHaveBeenCalledWith('pageView', window.vzdl);
    });

    it('should handle undefined data gracefully', () => {
      callPageViewMFE(undefined);
      expect(sendCustomEvent).not.toHaveBeenCalled();
    });
  });

  describe('callNotificationMFE', () => {
    it('should initialize and populate vzdl and call sendCustomEvent with notification', () => {
      const data = { channel: 'Order', detail: 'testDetail', message: 'testMessage' };
      callNotificationMFE(data);
      expect(window.vzdl.page.detail).toBe('testDetail');
      expect(window.vzdl.target.message).toBe('testMessage');
      expect(sendCustomEvent).toHaveBeenCalledWith('notification', window.vzdl);
    });

    it('should handle undefined data gracefully', () => {
      callNotificationMFE(undefined);
      expect(sendCustomEvent).not.toHaveBeenCalled();
    });
  });

  describe('commonTaggingData', () => {
    it('should initialize and populate vzdl with common data', () => {
      const data = { channel: 'Order', detail: 'testDetail' };
      commonTaggingData(data);
      expect(window.vzdl.page.detail).toBe('testDetail');
    });
  });

  describe('basicTaggingInfo', () => {
    const mockData = {
      eligibleLines: '2/3',
      channel: 'Online',
      detail: 'Plan Detail',
      flow: 'Checkout',
      name: 'Plan Name',
      intent: 'order',
      isAutoPayEnrolled: true,
      cartId: '12345',
      accountNumber: '123-456-789',
      accountAddress: { zipCode: '12345' },
    };

    beforeEach(() => {
      sessionStorage.setItem('numberOfLines', '2');
      sessionStorage.setItem('location', 'Store123');
      sessionStorage.setItem('EXISTING_CUST_INFO', JSON.stringify([{ ACCOUNT_NUM: '123-456-789' }]));
      sessionStorage.setItem('analyticssessionid', 'session123');
      sessionStorage.setItem('userId', 'user123');
      sessionStorage.setItem('hashedAccountNo', 'hashed123');
      sessionStorage.setItem('ENCRYPTED_MTN', 'encrypted123');
      sessionStorage.setItem('aaOLDCustType', 'type123');
      sessionStorage.setItem('tenure', '5 years');
      sessionStorage.setItem('zipCode', '12345');
      window.vzdl = {
        env: {},
        page: {},
        target: { engagement: {} },
        txn: {},
        user: {},
      };
    });

    afterEach(() => {
      sessionStorage.clear();
      window.vzdl = undefined;
    });

    it('should populate vzdl object with correct data', () => {
      basicTaggingInfo(mockData);

      expect(window.vzdl.env.businessUnit).toBe('Wireless');
      expect(window.vzdl.page.channel).toBe('Online');
      expect(window.vzdl.page.channelSession).toBe('session123');
      expect(window.vzdl.page.detail).toBe('Plan Detail');
      expect(window.vzdl.page.displayChannel).toBe('Retail');
      expect(window.vzdl.page.flow).toBe('Checkout');
      expect(window.vzdl.page.name).toBe('Plan Name');
      expect(window.vzdl.page.sourceChannel).toBe('POS');
      expect(window.vzdl.page.throttle).toBe('MFE');
      expect(window.vzdl.target.engagement.intent).toBe('order');
      expect(window.vzdl.txn.agent).toBe('user123');
      expect(window.vzdl.txn.agentRole).toBe('REP');
      expect(window.vzdl.txn.autoPay).toBe('Y');
      expect(window.vzdl.txn.outletId).toBe('Store123');
      expect(window.vzdl.txn.cartId).toBe('12345');
      expect(window.vzdl.user.accountType).toBe('Postpaid');
      expect(window.vzdl.user.authStatus).toBe('Logged in');
      expect(window.vzdl.user.customerRole).toBe('Account owner');
      expect(window.vzdl.user.numberOfLines).toBe('2');
      expect(window.vzdl.user.tenure).toBe('5 years');
      expect(window.vzdl.user.session).toBe('');
    });

    it('should handle missing data gracefully', () => {
      basicTaggingInfo(null);

      expect(window.vzdl.user.tenure).toBe(undefined);
      expect(window.vzdl.user.zip).toBe(undefined);
      expect(window.vzdl.user.session).toBe(undefined);
    });
    it('should handle missing data gracefully', () => {
      basicTaggingInfo(null);
      Object.defineProperty(window, 'vzdl', {
        writable: true,
        value: null,
      });
    });
  });

  describe('OpenViewTagging', () => {
    it('should call callOpenViewMFE with correct data', () => {
      const rspFetchReadOrder = {
        data: {
          data: {
            cart: {
              cartHeader: { cartId: '12345' },
              lineDetails: {
                numOfLinesNSE: '2/3',
                isAutoPayEnrolled: true,
                subAccountNBSInfo: { billAccounts: { nbs: { accountNumber: '123-456-789' } } },
                lineInfo: { serviceInfo: { cart5GAddress: { zipCode: '12345' } } },
              },
            },
          },
        },
      };
      OpenViewTagging('testDetail', 'testLink', 'testFlow', rspFetchReadOrder);
      expect(sendCustomEvent).toHaveBeenCalledWith('openView', window.vzdl);
    });
  });

  describe('NotificationTagging', () => {
    it('should call callNotificationMFE with correct data', () => {
      const rspFetchReadOrder = {
        data: {
          data: {
            cart: {
              cartHeader: { cartId: '12345' },
              lineDetails: {
                numOfLinesNSE: '2/3',
                isAutoPayEnrolled: true,
                subAccountNBSInfo: { billAccounts: { nbs: { accountNumber: '123-456-789' } } },
                lineInfo: { serviceInfo: { cart5GAddress: { zipCode: '12345' } } },
              },
            },
          },
        },
      };
      NotificationTagging('testDetail', 'testLink', 'testMessage', 'testFlow', rspFetchReadOrder,[{pricePlanInfo:{description:'testttung'}}]);
      expect(sendCustomEvent).toHaveBeenCalledWith('notification', window.vzdl);
    });
  });
  describe('PAgeView tagging', () => {
    it('should call callOpenViewMFE with correct data', () => {
      const rspFetchReadOrder = {
        data: {
          data: {
            cart: {
              cartHeader: { cartId: '12345' },
              lineDetails: {
                numOfLinesNSE: '2/3',
                isAutoPayEnrolled: true,
                subAccountNBSInfo: { billAccounts: { nbs: { accountNumber: '123-456-789' } } },
                lineInfo: { serviceInfo: { cart5GAddress: { zipCode: '12345' } } },
              },
            },
          },
        },
      };
      PageViewTagging('testDetail', 'testLink', 'testFlow', 'test', rspFetchReadOrder, Object({pricePlanInfo :{description:'testt'},data:[{pricePlanInfo:{description:'testt'}}]}));
      expect(sendCustomEvent).toHaveBeenCalledWith('pageView', window.vzdl);
    });
  });
});
describe('Tagging Functions', () => {
  const rspFetchReadOrder = {
    data: {
      data: {
        cart: {
          cartHeader: {
            cartId: '67890',
          },
          lineDetails: {
            numOfLinesNSE: '3/4',
            isAutoPayEnrolled: false,
            subAccountNBSInfo: {
              billAccounts: {
                nbs: {
                  accountNumber: '987-654-321',
                },
              },
            },
            lineInfo: {
              serviceInfo: {
                cart5GAddress: {
                  zipCode: '54321',
                },
              },
            },
          },
        },
      },
    },
  };

  const customerProfileResponse = {
    data: {
      data: {
        customer: {
          customerAttributes: {
            customerType: 'Postpaid',
          },
          billAccounts: [
            {
              mtns: [
                {
                  mtnHashCode: 'hash123',
                  pricePlanInfo: {
                    description: 'Unlimited Plan', // This satisfies the condition
                  },
                },
              ],
            },
          ],
          customerHash: 'custHash123',
          accountNo: '123456789',
          address: {
            zipCode: '67890',
          },
        },
      },
    },
  };

  beforeEach(() => {
    jest.clearAllMocks();
    sessionStorage.setItem('cartId', '12345');
  });

  afterEach(() => {
    sessionStorage.clear();
  });

  describe('OpenViewTagging', () => {
    it('should call sendCustomEvent with correct data for OpenViewTagging', () => {
      OpenViewTagging('Plan Detail', 'testLink', 'Checkout', 'Plan Name', rspFetchReadOrder, customerProfileResponse);
    });

    it('should handle missing rspFetchReadOrder gracefully', () => {
      OpenViewTagging('Plan Detail', 'testLink', 'Checkout', 'Plan Name', null, customerProfileResponse);
    });

    it('should handle missing customerProfileResponse gracefully', () => {
      OpenViewTagging('Plan Detail', 'testLink', 'Checkout', 'Plan Name', rspFetchReadOrder, null);
    });

    it('should handle missing window.vzdl gracefully (else condition)', () => {
      OpenViewTagging(rspFetchReadOrder, customerProfileResponse);
      NotificationTagging(rspFetchReadOrder);
    });
  });
});
