import { getInspicioRecieveServiceUrl, getPieEnvironment, mapSoeHost } from '.';

jest.mock('onevzsoemfecommon/Helpers/queryParams');

describe('Test - getInspicioRecieveServiceUrl func', () => {
  const orgLocation = window.location;

  beforeAll(() => {
    delete window.location;
    window.location = {
      ...orgLocation,
      host: 'ccare.com',
      hostname: 'ccare',
    };
  });

  afterAll(() => {
    window.location = orgLocation;
  });

  test('Test - cluster with S and PRODUCTION ENV', () => {
    sessionStorage.setItem('vtCluster', 'S');
    const result = getInspicioRecieveServiceUrl();
    expect(result).toBe('https://inspicio.verizonwireless.com/sdc/inspicio/receive');
  });

  test('Test - cluster with T and PRODUCTION ENV', () => {
    sessionStorage.setItem('vtCluster', 'T');
    const result = getInspicioRecieveServiceUrl();
    expect(result).toBe('https://inspicio.verizonwireless.com/tdc/inspicio/receive');
  });

  test('Test - cluster with P and PRODUCTION ENV', () => {
    sessionStorage.setItem('vtCluster', 'P');
    const result = getInspicioRecieveServiceUrl();
    expect(result).toBe('https://inspicio.verizonwireless.com/tpa/inspicio/receive');
  });

  test('Test - cluster without flag and PRODUCTION ENV', () => {
    sessionStorage.removeItem('vtCluster');
    const result = getInspicioRecieveServiceUrl();
    expect(result).toBe('https://inspicio.verizonwireless.com/sdc/inspicio/receive');
  });

  test('Test - cluster and UAT ENV', () => {
    delete window.location;
    window.location = {
      ...orgLocation,
      host: 'sit.com',
      hostname: 'sit',
    };
    const result = getInspicioRecieveServiceUrl();
    expect(result).toBe('https://inspicio-uat.verizonwireless.com/inspicio/receive');
  });

  test('Test - getPieEnvironment for PRODUCTION', () => {
    delete window.location;
    window.location = {
      ...orgLocation,
      host: 'ccare.com',
      hostname: 'ccare',
    };
    const result = getPieEnvironment();
    expect(result).toBe('PRODUCTION');
  });

  test('Test - getPieEnvironment for UAT', () => {
    window.location = {
      ...orgLocation,
      host: 'sit1.com',
      hostname: 'sit1',
    };
    const result = getPieEnvironment();
    expect(result).toBe('UAT');
  });


   test('Test - mapSoeHost for PRODUCTION', () => {
    delete window.location;
    window.location = {
      ...orgLocation,
      host: 'ccare.com',
      hostname: 'ccare',
    };
    const result = mapSoeHost();
    expect(result).toBe('http://ccare.com/soe/assisted/auth');
  });

  test('Test - mapSoeHost for local', () => {
    delete window.location;
    window.location = {
      ...orgLocation,
      host: 'localhost',
      hostname: 'localhost',
    };
    const result = mapSoeHost();
    expect(result).toBe('https://ccare-soe-sit1b.ebiz.verizon.com/soe/assisted/auth');
  });
});
