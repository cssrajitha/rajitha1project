import { useState, useEffect } from 'react';
import { isVbg } from 'onevzsoemfeframework/VbgAemUtil';
/**
 * Custom hook for VBG detection
 * @returns {boolean} VBG customer status
 */
export const useVbgDetection = () => {
  const [isVbgCustomer, setIsVbgCustomer] = useState(false);
  useEffect(() => {
    setIsVbgCustomer(isVbg());
  }, []);
  return isVbgCustomer;
};