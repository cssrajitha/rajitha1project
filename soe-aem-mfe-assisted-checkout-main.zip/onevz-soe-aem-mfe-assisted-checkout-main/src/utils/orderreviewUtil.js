import { formatMtnWithDecimals } from './common';

export const showShippingAddress = (lines) => {
  let showShippingSection = false;
  showShippingSection =
    lines &&
    lines.some(({ itemsInfo = [], lineActivityType }) =>
      itemsInfo.some(
        ({ shipping: { shippingCode } = {}, cartItems: { cartItem = [] } = {} }) =>
          shippingCode &&
          shippingCode.trim() !== '' &&
          (!(
            (lineActivityType === 'EUPBYOD' || lineActivityType === 'BYOD') &&
            cartItem.some(({ isCustomerProvidedSIM, cartItemType }) => isCustomerProvidedSIM && cartItemType === 'SIM')
          ) ||
            ((lineActivityType === 'EUPBYOD' || lineActivityType === 'BYOD') &&
              cartItem.some(({ cartItemType }) => cartItemType === 'ACCESSORY'))),
      ),
    );
  return showShippingSection;
};

export const isSplitFulfillmentEnabled = (itemLevelShipment = false) => itemLevelShipment;

export const showShippingAddressQA = (lines) => {
  let showShippingSection = false;
  showShippingSection =
    lines &&
    lines.some(({ itemsInfo = [] }) =>
      itemsInfo.some(({ cartItems: { cartItem = [] } = {}, depletionType }) =>
        cartItem.some(({ cartItemType }) => cartItemType === 'ACCESSORY' && depletionType === 'F'),
      ),
    );
  return showShippingSection;
};

export const dFillItemPresent = (lines) => {
  let dFillItemInCart = false;
  dFillItemInCart =
    lines &&
    lines?.some(({ itemsInfo = [] }) =>
      itemsInfo.some(({ cartItems: { cartItem = [] } = {} }) =>
        cartItem.some(({ depletionType }) => depletionType === 'F'),
      ),
    );
  return dFillItemInCart;
};

export const viewTogetherOptionsHelper = (
  itemLevelShipment = false,
  lineDetails = false,
  enableRetailCompanionOption = false,
) => {
  const isVTPTAeligible = lineDetails ? isCartEligibleForVTPax(lineDetails) : false;

  let viewTogetherOptions = [
    { name: 'group', children: 'Customer QR Code', value: 'Customer QR Code', ariaLabel: 'radio one', disabled: false },
    {
      name: 'group',
      children: 'View Together using PTA',
      value: 'View Together using PTA',
      ariaLabel: 'radio two',
      disabled: isVTPTAeligible,
    },
    { name: 'group', children: 'SMS', value: 'SMS', ariaLabel: 'send sms' },
    { name: 'group', children: 'Email Address', value: 'Email Address', ariaLabel: 'send email address' },
    { name: 'group', children: 'Customer cannot complete in VT', value: 'VT', ariaLabel: 'customer cannot complete in VT' },
    { name: 'group', children: 'Retail Companion', value: 'Retail Companion', ariaLabel: 'radio six' },
  ];
  if (!enableRetailCompanionOption) {
    viewTogetherOptions = viewTogetherOptions.filter((i) => i.value !== 'Retail Companion');
  }
  const scmCheckoutOptions = ['SMS', 'Email Address', 'Customer cannot complete in VT'];
  const viewTogetherOptionsSCM = viewTogetherOptions.filter((i) => scmCheckoutOptions.includes(i.children));

  if (isSplitFulfillmentEnabled(itemLevelShipment)) {
    viewTogetherOptions = viewTogetherOptions.filter((i) => i.value !== 'View Together using PTA');
  }

  return { viewTogetherOptions, viewTogetherOptionsSCM };
};

export const isCartEligibleForVTPax = (lineDetails) => {
  const isComboOrder = lineDetails && lineDetails?.numofLinesEUP > 0 && lineDetails?.numofLinesAAL > 0;

  return isComboOrder;
};

/**
 * Common utility function to handle disqualified propositions before order write
 * Processes MDN details, filters lines with chargeBackAmount > 0 and triggers updateVisionRemark for each
 * @param {Array} lineData - Array of line data
 * @param {Object} customer - Customer object containing customer details
 * @param {Function} updateVisionRemark - Function to call for updating vision remarks
 */
export const handleDisqualifiedPropositions = (
  lineData,
  customer,
  updateVisionRemark
) => {
  // Return early if feature flag is disabled or invalid inputs
  if (!lineData || !Array.isArray(lineData) || !updateVisionRemark) {
    return;
  }
  
  // Filter lines that have disqualified propositions with chargeBackAmount > 0
  const filteredLines = lineData?.filter((val) =>
    val?.disqualifiedPropositions?.some((v) => v?.chargeBackAmount > 0)
  );
  
  if (filteredLines?.length > 0) {
    // Process each filtered line
    filteredLines.forEach((line) => {

      const filteredData = line?.disqualifiedPropositions?.filter(
        (item) => item?.chargeBackAmount > 0
      );
      
      const formattedChargebacks = filteredData?.map((item) =>
        `Plan Change Chargeback MDN ${formatMtnWithDecimals(line?.mobileNumber)} chargeback applied of $${item?.chargeBackAmount} for offer ${item?.chargeBackBillDesc} due to moving to an non-qualifying plan`
      );

      const cpcRemarkString = formattedChargebacks?.join(', ');
      
      const custId = customer?.customerId || '';
      const billAccNum = customer?.billAccounts?.[0]?.billAccountNo || '';
      const firstName = customer?.customerName?.firstName || '';
      const lastName = customer?.customerName?.lastName || '';
      const contactName = `${firstName} ${lastName}`.trim() || '';
      const propositionBillingSystem = customer?.billingSystem || '';
      const location = customer?.orderLocationCode || '';
      
      const req = {
        mdn: line?.mobileNumber,
        requestMapping: 'autoRemarksUpdate',
        contactName,
        billAccountType: 'C',
        location,
        page: '1',
        accessLvl: '1',
        remarkText: cpcRemarkString,
        customerId: custId,
        billingSystem: propositionBillingSystem,
        billAccountNumber: billAccNum,
        remarkType: '',
        remarkLevel: 'A',
      };
      
      console.log('Triggering updateVisionRemark for line:',  req);
      updateVisionRemark({ body: req });
    });
  }
};
