// import { GetAppConfig } from './GetAppConfig';
const urls = {
    "receiveCall": "/inspicio/receive",
    "sdcrecieveMessage": "https://inspicio.verizonwireless.com/sdc",
    "tdcrecieveMessage": "https://inspicio.verizonwireless.com/tdc",
    "tparecieveMessage": "https://inspicio.verizonwireless.com/tpa",
    "recieveMessage": "https://inspicio-uat.verizonwireless.com",
}

const {
    receiveCall,
    recieveMessage,
    tdcrecieveMessage,
    tparecieveMessage,
    sdcrecieveMessage,
} = urls;

export const getPieEnvironment = () => {
    const uatUrls = [
      'nsd',
      'nsq',
      'localhost',
      'nssit',
      'nstrnge',
      'train',
      'nstr',
      'trng',
      'trn',
      'vzwqa',
      'sit',
      'dit',
    ];
    const pieEnv = uatUrls.filter((word) => window.location.hostname.includes(word)).length > 0 ? 'UAT' : 'PRODUCTION';
    console.log('getPieEnvironment: ', pieEnv);
    return pieEnv;
};

export const getInspicioRecieveServiceUrl = () => {
    const cluster = sessionStorage.getItem('vtCluster');
    let recieveServiceUrl = '';
    /* istanbul ignore else */ 
    if (getPieEnvironment() === 'UAT') {
      recieveServiceUrl = recieveMessage;
    } else if (cluster?.toLowerCase() === 's' && getPieEnvironment() === 'PRODUCTION') {
      recieveServiceUrl = sdcrecieveMessage;
    } else if (cluster?.toLowerCase() === 't' && getPieEnvironment() === 'PRODUCTION') {
      recieveServiceUrl = tdcrecieveMessage;
    } else if (cluster?.toLowerCase() === 'p' && getPieEnvironment() === 'PRODUCTION') {
      recieveServiceUrl = tparecieveMessage;
    } else if (getPieEnvironment() === 'PRODUCTION') {
      recieveServiceUrl = sdcrecieveMessage;
    }
    return recieveServiceUrl + receiveCall;
};

export const mapSoeHost = () => {
  const soePath = '/soe/assisted/auth';
  if (window?.location?.hostname?.includes('localhost')) {
    return `https://ccare-soe-sit1b.ebiz.verizon.com${soePath}`;
  }
  const soeHost =  `${window?.location?.protocol}//${window?.location?.host}${soePath}`;
  return soeHost;
};

// export { GetAppConfig };
