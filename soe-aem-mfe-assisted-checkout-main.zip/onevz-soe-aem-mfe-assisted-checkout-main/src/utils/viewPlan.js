import { sendCustomEvent } from 'onevzsoemfeframework/Tagging';

export function makeOpenViewCall(pageDetail = '') {
  if (!window?.vzdl?.page?.detail || window?.vzdl?.page?.detail !== pageDetail) {
    const vzdl = window?.vzdl || {};
    if (pageDetail && vzdl?.page) {
      vzdl.page.detail = `${pageDetail}`;
      vzdl.page.throttle = 'MFE';
      vzdl.page.name = 'Combined Gridwall_Plans';
      vzdl.event.value = '';
    }
    window.vzdl = vzdl;
    sendCustomEvent('openView', window?.vzdl);
  }
}

export function makeCloseViewCall() {
  const vzdl = window?.vzdl || {};
  if (vzdl?.page) vzdl.page.detail = '';
  window.vzdl = vzdl;
  sendCustomEvent('closeView', window?.vzdl);
}

export function getCurrTabData(Frompage) {
  let tabtext = '';
  if (Frompage?.buildPlanTab) {
    tabtext = 'Build Plan';
  } else if (Frompage?.popularPlanTab) {
    tabtext = 'Popular Plan';
  } else if (Frompage?.recommendedPlanTab) {
    tabtext = 'Recommended Plan';
  }
  return tabtext;
}
