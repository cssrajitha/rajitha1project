import { cloneDeep } from 'lodash';
import { makeOpenViewCall, makeCloseViewCall, getCurrTabData } from './viewPlan';

jest.mock('onevzsoemfeframework/Tagging');
jest.mock('./tagging');

const buildTab = { buildPlanTab: true, popularPlanTab: false, recommendedPlanTab: false };
const popularPlanTab = { buildPlanTab: false, popularPlanTab: true, recommendedPlanTab: false };
const recommendedPlanTab = { buildPlanTab: false, popularPlanTab: false, recommendedPlanTab: true };

jest.mock('onevzsoemfecommon/Helpers/queryParams', () => ({
  getQueryParamByName: jest.fn(() => ({
    p: 'mockClientID',
    i: 's',
    em: 'EM',
  })),
  getQueryParams: jest.fn(() => ({
    p: btoa('LOV-AGENT-'),
    i: 's',
  })),
}));

const Test = () => {
  const mockUrl = window.location;
  delete window.location;
  window.location = { ...mockUrl, hostname: 'http://abc.com' };
  const vzdlMock = window.vzdl;
  delete window.vzdl;
  const vzdlMocked = cloneDeep({ ...vzdlMock, page: { detail: 'Plan' }, event: { value: '' } });

  describe('<Utils functions check>', () => {
    beforeEach(() => {
      window.vzdl = cloneDeep({ ...vzdlMocked });
    });

    test('makeOpenViewCall', () => {
      makeOpenViewCall();
    });

    test('makeOpenViewCall with param', () => {
      makeOpenViewCall('Shop Plans');
    });

    test('makeCloseViewCall', () => {
      makeCloseViewCall();
    });

    test('makeOpenViewCall empty vzdl', () => {
      window.vzdl = undefined;
      makeOpenViewCall();
    });

    test('makeOpenViewCall with param empty vzdl', () => {
      window.vzdl = undefined;
      makeOpenViewCall('Shop Plans');
    });

    test('makeCloseViewCall with empty vzdl', () => {
      window.vzdl = undefined;
      makeCloseViewCall();
    });

    test('getCurrTabData', () => {
      const result = getCurrTabData();
      expect(result).toBe('');
    });

    test('getCurrTabData buildTab', () => {
      const result = getCurrTabData(buildTab);
      expect(result).toBe('Build Plan');
    });

    test('getCurrTabData popular Tab', () => {
      const result = getCurrTabData(popularPlanTab);
      expect(result).toBe('Popular Plan');
    });

    test('getCurrTabData recommended Tab', () => {
      const result = getCurrTabData(recommendedPlanTab);
      expect(result).toBe('Recommended Plan');
    });
  });
};

Test();
