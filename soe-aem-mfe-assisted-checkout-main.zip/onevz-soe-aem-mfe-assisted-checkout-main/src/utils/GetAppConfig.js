import localAppConfig from '../appconfig.json';

export const GetAppConfig = () => {
  const appConfig = localAppConfig;
  return appConfig;
};
