import React from 'react';
import { render as rtlRender } from '@testing-library/react';
import { Provider } from 'react-redux';
import configureAppStore from 'onevzsoemfeframework/Store';
import { BrowserRouter as Router } from 'react-router-dom';

function render(
  ui,
  { reducers = {}, sagas = {}, preloadedState, store = configureAppStore(reducers, sagas), ...renderOptions } = {},
) {
  // eslint-disable-next-line react/prop-types
  function Wrapper({ children }) {
    return (
      <Router>
        <Provider store={store}>{children}</Provider>
      </Router>
    );
  }
  return { store, ...rtlRender(ui, { wrapper: Wrapper, ...renderOptions }) };
}

// re-export everything
export * from '@testing-library/react';

// override render method
export { render };
