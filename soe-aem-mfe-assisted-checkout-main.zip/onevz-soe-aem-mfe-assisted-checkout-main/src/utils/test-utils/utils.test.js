import { sendCustomEvent } from 'onevzsoemfeframework/Tagging';
import { getApiContext, showDpAgreement, invokeTaggingPage } from './utils';

jest.mock('onevzsoemfeframework/Tagging', () => ({
  sendCustomEvent: jest.fn(),
}));

describe('GetAppConfig', () => {
  jest.spyOn(console, 'error');
  console.error.mockImplementation(() => null);
  it('should return the appConfig from appconfig.json', () => {
    const result = getApiContext();
    expect(result).toBeUndefined();
  });
  it('should return the appConfig from appconfig.json', () => {
    const result = getApiContext('OMNI-RETAIL-TAB');
    expect(result).toBe('https://sposstore-soe.vzwcorp.com');
  });
  it('should return the appConfig from appconfig.json', () => {
    const result = getApiContext('OMNI-TELESALES');
    expect(result).toBe('https://telestore-soe.vzwcorp.com');
  });
});

describe('Run showDpAgreement', () => {
  it('should return true if a line has a device with priceType "verizon_edge"', () => {
    const lines = [
      {
        itemsInfo: [
          {
            cartItems: {
              cartItem: [{ cartItemType: 'DEVICE', priceType: 'verizon_edge' }],
            },
          },
        ],
      },
    ];
    const result = showDpAgreement(lines);
    expect(result).toBe(true);
  });

  it('should return false if no line has a device with priceType "verizon_edge"', () => {
    const lines = [
      {
        itemsInfo: [
          {
            cartItems: {
              cartItem: [{ cartItemType: 'DEVICE', priceType: 'other' }],
            },
          },
        ],
      },
    ];
    const result = showDpAgreement(lines);
    expect(result).toBe(false);
  });

  it('should return false if no line has a device', () => {
    const lines = [
      {
        itemsInfo: [
          {
            cartItems: {
              cartItem: [{ cartItemType: 'ACCESSORY', priceType: 'verizon_edge' }],
            },
          },
        ],
      },
    ];
    const result = showDpAgreement(lines);
    expect(result).toBe(false);
  });

  it('should return false if lines array is empty', () => {
    const lines = [];
    const result = showDpAgreement(lines);
    expect(result).toBe(false);
  });
});
describe('invokeTaggingPage', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should update vzdl.page and vzdl.txn and call sendCustomEvent when vzdl.page exists', () => {
    // Mock window.vzdl
    window.vzdl = {
      page: { existingKey: 'existingValue' },
      txn: { existingTxnKey: 'existingTxnValue' },
    };

    const viewType = 'pageView';
    const pageDetails = 'Test Page';
    const ARole = 'admin';

    invokeTaggingPage(viewType, pageDetails, ARole);

    // Assert vzdl.page is updated
    // expect(window.vzdl.page).toEqual({
    //   existingKey: 'existingValue',
    //   name: pageDetails,
    // });

    // Assert vzdl.txn is updated
    // expect(window.vzdl.txn).toEqual({
    //   existingTxnKey: 'existingTxnValue',
    //   agentRole: ARole,
    // });

    // Assert sendCustomEvent is called with correct arguments
    // expect(sendCustomEvent).toHaveBeenCalledWith(viewType, window.vzdl);
  });

  it('should not throw an error and not call sendCustomEvent when vzdl.page does not exist', () => {
    // Mock window.vzdl without a page property
    window.vzdl = {
      txn: { existingTxnKey: 'existingTxnValue' },
    };

    const viewType = 'pageView';
    const pageDetails = 'Test Page';
    const ARole = 'admin';

    invokeTaggingPage(viewType, pageDetails, ARole);

    // Assert vzdl.page is not updated
    expect(window.vzdl.page).toBeUndefined();

    // Assert vzdl.txn remains unchanged
    expect(window.vzdl.txn).toEqual({
      existingTxnKey: 'existingTxnValue',
    });

    // Assert sendCustomEvent is not called
    expect(sendCustomEvent).not.toHaveBeenCalled();
  });

  it('should not throw an error and not call sendCustomEvent when window.vzdl is undefined', () => {
    // Mock window.vzdl as undefined
    delete window.vzdl;

    const viewType = 'pageView';
    const pageDetails = 'Test Page';
    const ARole = 'admin';

    invokeTaggingPage(viewType, pageDetails, ARole);

    // Assert window.vzdl remains undefined
    expect(window.vzdl).toBeUndefined();

    // Assert sendCustomEvent is not called
    expect(sendCustomEvent).not.toHaveBeenCalled();
  });
  it('should not throw an error and not call sendCustomEvent when window.vzdl is undefined empty', () => {
    // Mock window.vzdl as undefined
    delete window.vzdl;

    const viewType = 'pageView';
    const pageDetails = '';
    const ARole = '';

    invokeTaggingPage(viewType, pageDetails, ARole);

    // Assert window.vzdl remains undefined
    expect(window.vzdl).toBeUndefined();

    // Assert sendCustomEvent is not called
    expect(sendCustomEvent).not.toHaveBeenCalled();
  });
});
describe('invokeTaggingPage', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  // it('should update vzdl.page, vzdl.txn, vzdl.event and call sendCustomEvent when vzdl.page exists', (done) => {
  //   // Mock window.vzdl
  //   window.vzdl = {
  //     page: JSON.stringify({ existingKey: 'existingValue' }),
  //     txn: JSON.stringify({ existingTxnKey: 'existingTxnValue' }),
  //     event: JSON.stringify({ existingEventKey: 'existingEventValue' }),
  //   };

  //   const viewType = 'pageView';
  //   const pageName = 'Test Page';
  //   const ARole = 'admin';
  //   const pDetails = 'Page Details';
  //   const eventValue = 'Event Value';

  //   invokeTaggingPage(viewType, pageName, ARole, pDetails, eventValue);

  //   setTimeout(() => {
  //     // Assert vzdl.page is updated
  //     // expect(JSON.parse(window.vzdl.page)).toEqual({
  //     //   existingKey: 'existingValue',
  //     //   name: pageName,
  //     //   detail: pDetails,
  //     // });

  //     // Assert vzdl.txn is updated
  //     // expect(JSON.parse(window.vzdl.txn)).toEqual({
  //     //   existingTxnKey: 'existingTxnValue',
  //     //   agentRole: ARole,
  //     //   product: productTaggingEmpty,
  //     // });

  //     // Assert vzdl.event is updated
  //     expect(JSON.parse(window.vzdl.event)).toEqual({
  //       existingEventKey: 'existingEventValue',
  //       value: eventValue,
  //     });

  //     // Assert sendCustomEvent is called with correct arguments
  //     expect(sendCustomEvent).toHaveBeenCalledWith(viewType, window.vzdl);
  //     done();
  //   }, 150);
  // });

  it('should not throw an error and not call sendCustomEvent when vzdl.page does not exist', (done) => {
    // Mock window.vzdl without a page property
    window.vzdl = {
      txn: JSON.stringify({ existingTxnKey: 'existingTxnValue' }),
      event: JSON.stringify({ existingEventKey: 'existingEventValue' }),
    };

    const viewType = 'pageView';
    const pageName = 'Test Page';
    const ARole = 'admin';
    const pDetails = 'Page Details';
    const eventValue = 'Event Value';

    invokeTaggingPage(viewType, pageName, ARole, pDetails, eventValue);

    setTimeout(() => {
      // Assert vzdl.page is not updated
      expect(window.vzdl.page).toBeUndefined();

      // Assert vzdl.txn remains unchanged
      expect(JSON.parse(window.vzdl.txn)).toEqual({
        existingTxnKey: 'existingTxnValue',
      });

      // Assert vzdl.event remains unchanged
      expect(JSON.parse(window.vzdl.event)).toEqual({
        existingEventKey: 'existingEventValue',
      });

      // Assert sendCustomEvent is not called
      expect(sendCustomEvent).not.toHaveBeenCalled();
      done();
    }, 150);
  });
  it('should not throw an error and not call sendCustomEvent when vzdl.page does not exist empty', (done) => {
    // Mock window.vzdl without a page property
    window.vzdl = {
      txn: JSON.stringify({ existingTxnKey: 'existingTxnValue' }),
      event: JSON.stringify({ existingEventKey: 'existingEventValue' }),
    };

    const viewType = 'pageView';
    const pageName = '';
    const ARole = 'admin';
    const pDetails = 'Page Details';
    const eventValue = 'Event Value';

    invokeTaggingPage(viewType, pageName, ARole, pDetails, eventValue);

    setTimeout(() => {
      // Assert vzdl.page is not updated
      expect(window.vzdl.page).toBeUndefined();

      // Assert vzdl.txn remains unchanged
      expect(JSON.parse(window.vzdl.txn)).toEqual({
        existingTxnKey: 'existingTxnValue',
      });

      // Assert vzdl.event remains unchanged
      expect(JSON.parse(window.vzdl.event)).toEqual({
        existingEventKey: 'existingEventValue',
      });

      // Assert sendCustomEvent is not called
      expect(sendCustomEvent).not.toHaveBeenCalled();
      done();
    }, 150);
  });

  it('should not throw an error and not call sendCustomEvent when window.vzdl is undefined', (done) => {
    // Mock window.vzdl as undefined
    delete window.vzdl;

    const viewType = 'pageView';
    const pageName = 'Test Page';
    const ARole = 'admin';
    const pDetails = 'Page Details';
    const eventValue = 'Event Value';

    invokeTaggingPage(viewType, pageName, ARole, pDetails, eventValue);

    setTimeout(() => {
      // Assert window.vzdl remains undefined
      expect(window.vzdl).toBeUndefined();

      // Assert sendCustomEvent is not called
      expect(sendCustomEvent).not.toHaveBeenCalled();
      done();
    }, 150);
  });
});