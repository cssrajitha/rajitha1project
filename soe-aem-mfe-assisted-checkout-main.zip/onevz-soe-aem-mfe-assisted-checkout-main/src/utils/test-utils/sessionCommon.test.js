import { SetStorageSession, setSession, getSession, ClearStorageSession } from './sessionCommon';

describe(`Session Common `, () => {
  test('SetStorageSession should be function', async () => {
    SetStorageSession('temp', 'temp');
    expect(getSession('temp')).toBe('temp');
  });
  test('SetStorageSession should be function', async () => {
    setSession('temp', 'temp');
    expect(getSession('temp')).toBe('temp');
  });
  test('SetStorageSession should be function', async () => {
    ClearStorageSession('temp');
    expect(getSession('temp')).not.toBe('temp');
  });
});
