import { sendCustomEvent } from 'onevzsoemfeframework/Tagging';
import { has } from 'lodash';

// channel setup utils
export const CHANNELS = {
  OMNI_TELESALES: 'OMNI-TELESALES',
  OMNI_RETAIL: 'OMNI-RETAIL',
  OMNI_RETAIL_TAB: 'OMNI-RETAIL-TAB',
  OMNI_D2D: 'OMNI-D2D',
  OMNI_INDIRECT: 'OMNI-INDIRECT',
  OMNI_CARE: 'OMNI-CARE',
  CHAT_STORE: 'CHAT-STORE',
};

export const setupChannel = (channel) => {
  beforeAll(() => {
    sessionStorage.setItem('channel', channel);
    sessionStorage.setItem('APIContext', getApiContext(channel));
  });

  afterAll(() => {
    sessionStorage.setItem('channel', '');
    sessionStorage.setItem('APIContext', '');
  });
};

export const getApiContext = (channel) => {
  if (channel === CHANNELS.OMNI_TELESALES) {
    return 'https://telestore-soe.vzwcorp.com';
  }
  if (channel === CHANNELS.OMNI_RETAIL || channel === CHANNELS.OMNI_RETAIL_TAB) {
    return 'https://sposstore-soe.vzwcorp.com';
  }
};

export const setUserAgentIPad = () => {
  const { userAgent } = global.navigator;
  beforeAll(() => {
    Object.defineProperty(global.navigator, 'userAgent', {
      get() {
        return 'iPad';
      },
      configurable: true,
    });
  });
  afterAll(() => {
    Object.defineProperty(global.navigator, 'userAgent', {
      get() {
        return userAgent;
      },
      configurable: true,
    });
  });
};

export async function wait(ms = 1000) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

export function invokeTagging(viewType, pageDetails) {
  const vzdl = window?.vzdl || {};
  if (vzdl?.page)
    vzdl.page = {
      ...vzdl.page,
      detail: pageDetails,
    };
  window.vzdl = vzdl;
  sendCustomEvent(viewType, window?.vzdl);
}

export function showDpAgreement(lines) {
  let hasDp = false;
  // eslint-disable-next-line no-unused-expressions
  lines.length > 0 &&
    // eslint-disable-next-line array-callback-return
    lines.map((line) => {
      const deviceCartItems =
        has(line, 'itemsInfo') &&
        line.itemsInfo.length > 0 &&
        line.itemsInfo.find(
          (itemInfo) =>
            has(itemInfo, 'cartItems.cartItem') &&
            itemInfo.cartItems.cartItem.find((cartItem) => cartItem.cartItemType === 'DEVICE'),
        );
      const deviceCartItem =
        deviceCartItems && deviceCartItems.cartItems.cartItem.find((cartItem) => cartItem.cartItemType === 'DEVICE');
      if (deviceCartItem && deviceCartItem.priceType && deviceCartItem.priceType.toLowerCase() === 'verizon_edge') {
        hasDp = true;
      }
    });
  return hasDp;
}
const productTaggingEmpty = {
  current: [
        {
          name: "",
          id: "",
          merchCat: "",
          category: "",
          offer: "",
          discount: "",
          qty: "",
          recurringPrice: "",
          nonRecurringPrice: "",
          line: "",
          sku: "",
          contractType: "",
          shippingCharge: "",
          shippingType: "",
          shared: "",
          action: "",
          group: "",
          path: "",
          propId: "",
          downPayment: 0,
          orderType: "",
          lineHash: "",
          deviceFeatures: "",
          subCategory: ""
        }
  ],
  owns: [
      {
          name: "",
          id: "",
          category: "",
          recurringPrice: "",
          line: "",
          subCategory: ""
      }
  ]
}
export function invokeTaggingPage(viewType, pageName, ARole = '', pDetails = '', eventValue='') {
  setTimeout(() => {
    const vzdl = {...(window?.vzdl || {})};
    const vPage = typeof vzdl?.page === 'string' ? JSON.parse(vzdl.page) : vzdl?.page || {};
    const vTxn = typeof vzdl?.txn === 'string' ? JSON.parse(vzdl.txn) : vzdl?.txn || {};
    const vEvent = typeof vzdl?.event === 'string' ? JSON.parse(vzdl.event) : vzdl?.event || {};
    if (vzdl?.page) {
          vzdl.page = {
            ...vPage,
          }
          if(pageName !== ""){
            vzdl.page.name = pageName
          }
          if(pDetails !== ""){
            vzdl.page.detail = pDetails
          }
          vzdl.txn = {
            ...vTxn,
            agentRole: ARole,
            product: productTaggingEmpty,
          };
          vzdl.event = {
            ...vEvent,
            value: eventValue,
          };
        window.vzdl = vzdl;
        sendCustomEvent(viewType, window?.vzdl);
      }
  }, 100);

}
