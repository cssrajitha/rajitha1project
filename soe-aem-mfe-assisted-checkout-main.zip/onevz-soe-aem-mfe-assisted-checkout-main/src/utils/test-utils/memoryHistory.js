import { createMemoryHistory } from 'history';

let history;
export const createHistory = (initialRoute) => {
  history = createMemoryHistory({
    initialEntries: [`/${initialRoute}`],
  });

  history.navigatePage = (pathname = '/') => {
    history.push(pathname);
  };

  return history;
};
