import { has } from 'lodash';
import { useSelector } from 'react-redux';
import moment from 'moment';

export const formatAccountNumber = (fullAccountNumber) => {
  const acctNumSplit = fullAccountNumber?.split('-');
  const firstAccountNumber = acctNumSplit[0];
  const secondAccNum = acctNumSplit[1];
  let padingZeros = '';
  if (secondAccNum?.length === 1) {
    padingZeros = '0000';
  } else if (secondAccNum?.length === 2) {
    padingZeros = '000';
  }

  return firstAccountNumber.concat('-', padingZeros, secondAccNum);
};

export const formatPhoneNumberWithSymbol = (number, symbol) => {
  if (!number) {
    return number;
  }
  const onlyNums = number.replace(/[^\dxX]/g, '');
  if (onlyNums.length <= 3) {
    return onlyNums;
  }
  if (onlyNums.length <= 6) {
    return onlyNums.slice(0, 3) + symbol + onlyNums.slice(3, 6);
  }
  return onlyNums.slice(0, 3) + symbol + onlyNums.slice(3, 6) + symbol + onlyNums.slice(6, 10);
};

export const getPlanDetail = (line) => {
  if (has(line, 'serviceInfo')) {
    const { serviceInfo } = line;
    const isCPC = has(serviceInfo, 'oldPricePlanId') && has(serviceInfo, 'newPricePlanId');
    let isAccount = false;
    let planInfo = {};
    let planPrice = '';
    let oldPlanId = '';
    let newPlanId = '';
    let planIds = [];
    let isJaxPlan = false;
    let jaxPlanNode = {};
    let oldPlanFlag = '';
    let newPlanFlag = '';
    let planDetails = '';
    if (isCPC) {
      oldPlanId = serviceInfo && has(serviceInfo, 'oldPricePlanId') ? serviceInfo.oldPricePlanId : '';
      newPlanId = serviceInfo && has(serviceInfo, 'newPricePlanId') ? serviceInfo.newPricePlanId : '';
      planIds = [oldPlanId, newPlanId];
      newPlanFlag = has(serviceInfo, 'newPlanFlag') ? serviceInfo.newPlanFlag : '';
      oldPlanFlag = has(serviceInfo, 'oldPlanFlag') ? serviceInfo.oldPlanFlag : '';
      if (has(serviceInfo, 'newPlanFlag') && serviceInfo.newPlanFlag === 'A') {
        isAccount = true;
        planInfo = serviceInfo?.selectedALPShareList?.newAlpShareInfo?.find((plan) => plan?.addDeleteInd !== 'D');
      }
      if (has(serviceInfo, 'newPlanFlag') && serviceInfo.newPlanFlag === 'L') {
        planInfo = serviceInfo?.newPricePlanInfo;
      }
    } else if (has(serviceInfo, 'newPricePlanId')) {
      newPlanId = serviceInfo && has(serviceInfo, 'newPricePlanId') ? serviceInfo.newPricePlanId : '';
      planIds = [newPlanId];
      if (has(serviceInfo, 'oldPlanFlag') && serviceInfo.oldPlanFlag === 'A') {
        isAccount = true;
        planInfo =
          has(serviceInfo, 'selectedALPShareList.alpShareInfo') &&
          serviceInfo.selectedALPShareList.alpShareInfo.find((sharedPlan) => sharedPlan);
      }
      if (has(serviceInfo, 'newPlanFlag') && serviceInfo.newPlanFlag === 'A') {
        isAccount = true;
        planInfo =
          has(serviceInfo, 'selectedALPShareList.newAlpShareInfo') &&
          serviceInfo.selectedALPShareList.newAlpShareInfo.find((plan) => plan.addDeleteInd !== 'D');
      }
      if (has(serviceInfo, 'newPlanFlag') && serviceInfo.newPlanFlag === 'L') {
        planInfo = serviceInfo?.newPricePlanInfo;
      }
    } else {
      oldPlanId = serviceInfo && has(serviceInfo, 'oldPricePlanId') ? serviceInfo.oldPricePlanId : '';
      planIds = [oldPlanId];
      if (has(serviceInfo, 'oldPlanFlag') && serviceInfo.oldPlanFlag === 'A') {
        isAccount = true;
        planInfo =
          has(serviceInfo, 'selectedALPShareList.alpShareInfo') &&
          serviceInfo.selectedALPShareList.alpShareInfo.find((sharedPlan) => sharedPlan);
      }
      if (has(serviceInfo, 'oldPlanFlag') && serviceInfo.oldPlanFlag === 'L') {
        planInfo = serviceInfo?.pricePlanInfo;
      }
    }
    if (isAccount) {
      planPrice = has(planInfo, 'accessFee') ? planInfo.accessFee : '';
      planDetails = has(serviceInfo, 'planDetails') ? serviceInfo.planDetails : '';
      isJaxPlan = has(planInfo, 'categoryCode') && planInfo.categoryCode === '61';
    } else {
      planPrice = isCPC ? serviceInfo?.planDetails?.planPrice || '' : planInfo?.planPrice || '';
    }
    if (isJaxPlan) {
      jaxPlanNode = has(serviceInfo, 'selectedFeaturesList.visFeature')
        ? serviceInfo.selectedFeaturesList.visFeature.length > 0 &&
          serviceInfo.selectedFeaturesList.visFeature.find(
            (feature) => feature.sfopackageGroupCode === 'LC' && feature.addDeleteInd !== 'D',
          )
        : {};
    }
    planDetails = has(serviceInfo, 'planDetails') ? serviceInfo.planDetails : '';
    return {
      isCPC,
      planInfo,
      isAccount,
      planPrice,
      oldPlanId,
      newPlanId,
      planIds,
      isJaxPlan,
      jaxPlanNode,
      newPlanFlag,
      oldPlanFlag,
      planDetails,
    };
  }
};

export const getDisplayableFeatures = (line) => {
  const newFeatures = [];
  const existingFeatures = [];
  const oldFeatures = [];
  const temp =
    has(line, 'addons') &&
    line.addons.length &&
    line.addons.forEach((addon) => {
      if (
        has(addon, 'isDisplayable') &&
        addon.isDisplayable &&
        has(addon, 'isGeneralAddon') &&
        addon.isGeneralAddon === true
      ) {
        if (addon.actionIndicator === 'A') {
          newFeatures.push(addon);
        } else if (addon.actionIndicator === 'K' || addon.actionIndicator === 'Z') {
          existingFeatures.push(addon);
        }
      }
      if (has(addon, 'isUserSelected') && addon.isUserSelected && addon.actionIndicator === 'D') {
        oldFeatures.push(addon);
      }
    });

  return {
    newFeatures,
    existingFeatures,
    oldFeatures,
    temp,
  };
};

export const getCamelCaseName = (color) =>
  typeof color === 'string' &&
  color
    ?.toLowerCase()
    ?.split(' ')
    ?.map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    ?.join(' ');

export function getCamelCasePronoun(pronoun) {
  return (
    pronoun &&
    pronoun
      .toLowerCase()
      .split(',')
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(',')
  );
}

/**
 * Transforms a number to a currency string (ie. 5 => $5.00)
 */
export const formatCurrency = (currencyValue) => {
  const value = !currencyValue || Number.isNaN(currencyValue) ? 0 : currencyValue;
  const sign = value < 0 ? '-' : '';
  const numValue = Number(Math.abs(value)).toFixed(2);
  const currencyString = `${sign}$${numValue}`;
  return currencyString;
};

export function formatMtnWithDecimals(mtn) {
  if (!mtn) {
    return;
  }

  let formattedMtn = mtn.toString();
  formattedMtn = `${formattedMtn.substring(0, 3)}.${formattedMtn.substring(3, 6)}.${formattedMtn.substring(6, 10)}`;
  return formattedMtn;
}

/**
 * Format a date to a particular pattern
 */
export function formatDate(value, formatPattern = 'MM/DD/YYYY') {
  return moment(value).format(formatPattern);
}

export function formatDateOrdinal(dateObj) {
  const monthNames = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];

  const nth = (d) => {
    if (d > 3 && d < 21) return 'th';
    switch (d % 10) {
      case 1:
        return 'st';
      case 2:
        return 'nd';
      case 3:
        return 'rd';
      default:
        return 'th';
    }
  };

  try {
    const date = dateObj && dateObj.getDate();
    return `${monthNames[dateObj.getMonth()].substr(0, 3)} ${date}${nth(date)}`;
  } catch (anyErr) {
    return dateObj;
  }
}

export const getSharedFeatures = (line, activeSubAccountId, subAccountId) => {
  const lineWithSharedFeature = line?.find((lineItem) =>
    subAccountId
      ? (subAccountId === lineItem.subAccountDisplayName || subAccountId === 'existing') &&
        has(lineItem, 'serviceInfo.selectedFeaturesList.visFeature') &&
        lineItem.serviceInfo.selectedFeaturesList.visFeature.length > 0 &&
        lineItem.serviceInfo.selectedFeaturesList.visFeature.some((feature) => feature.level && feature.level === 'A')
      : activeSubAccountId &&
        (activeSubAccountId === 'existing' ||
          activeSubAccountId.includes('SubAccount ') ||
          activeSubAccountId === lineItem.subAccountDisplayName) &&
        has(lineItem, 'serviceInfo.selectedFeaturesList.visFeature') &&
        lineItem.serviceInfo.selectedFeaturesList.visFeature.length > 0 &&
        lineItem.serviceInfo.selectedFeaturesList.visFeature.some((feature) => feature.level && feature.level === 'A'),
  );

  return (
    has(lineWithSharedFeature, 'serviceInfo.selectedFeaturesList.visFeature') &&
    lineWithSharedFeature.serviceInfo.selectedFeaturesList.visFeature.filter(
      (feature) =>
        feature.level === 'A' &&
        feature.addDeleteInd !== 'D' &&
        (feature.source === 'USER' || (feature.source === 'FOM' && parseFloat(feature.featurePrice) > 0)),
    )
  );
};

export const getDiscountedFeatures = (pricedSnapshot) => {
  const { shared: { addons = [] } = {} } = pricedSnapshot || {};

  return addons
    .filter(({ isDisplayable, actionIndicator }) => isDisplayable && actionIndicator !== 'D')
    .map(
      ({
        sorId: visFeatureCode,
        skuName: featureDesc,
        price: { regularPrice, discountedPrice },
        isPromoDiscount,
        isGeneralAddon,
        isSubscription,
      }) => ({
        visFeatureCode,
        featureDesc,
        featurePrice: discountedPrice < regularPrice ? discountedPrice : regularPrice,
        discountedPrice,
        regularPrice,
        isPromoDiscount,
        isGeneralAddon,
        isSubscription,
      }),
    );
};

export const formatMtnWithHyphen = (mtn) => {
  if (!mtn) {
    return;
  }

  if (mtn === 'NewLine1') {
    return mtn;
  }

  let formattedMtn = mtn.toString();

  if (formattedMtn.includes('/' || '-')) {
    formattedMtn = formattedMtn.replaceAll('/', '');
    formattedMtn = formattedMtn.replaceAll('-', '');
  }

  formattedMtn = `${formattedMtn.substring(0, 3)}-${formattedMtn.substring(3, 6)}-${formattedMtn.substring(6, 10)}`;

  return formattedMtn;
};

export const allowOnlyNumbers = (value) => {
  const rE = /^[0-9\b]+$/;
  return value === '' || rE.test(value);
};

export const allowOnlyAlphaNumeric = (value) => {
  const rE = /^[0-9a-zA-Z]+$/;
  return value === '' || rE.test(value);
};

export const getDate = (mm, dd, yyyy) => {
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  let date = dd;
  let month = mm;
  if (mm && dd && yyyy) {
    date = Number(date);
    month = Number(month) - 1;
    if (date < 10) date = `0${date}`;
  } else {
    const today = new Date();
    date = today.getDate();
    month = today.getMonth();
    if (date < 10) date = `0${date}`;
  }
  return `${monthNames[month]} ${date}`;
};

export const convertDateRange = (dateRange, isOCC = false, isAddOn = false, isSubscriptionUpgrade = false) => {
  if (!dateRange) {
    return dateRange;
  }
  const dates = dateRange.split('-');
  const len = dates.length - 1;
  return dates.reduce((accum, date, index) => {
    const mm = date.split('/')[0];
    const dd = date.split('/')[1];
    const yyyy = date.split('/')[2];
    let acc = accum;
    if (index !== len) acc += `${getDate(mm, dd, yyyy)} - `;
    else acc += getDate(mm, dd, yyyy);
    if (isAddOn && isOCC && !isSubscriptionUpgrade) {
      acc = `${acc}, ${yyyy}`;
    }
    return acc;
  }, '');
};

export const financedAmount = (cartInfo, mtn) => {
  let financeAmount = 0;

  if (cartInfo) {
    const lines = has(cartInfo, 'lineDetails.lineInfo') ? cartInfo?.lineDetails?.lineInfo : [];
    const line = lines.filter((tmpLine) => tmpLine?.mobileNumber && tmpLine?.mobileNumber === mtn)[0];
    const item =
      line && Object.keys(line)?.length > 0 && line?.itemsInfo.filter((itemInfo) => has(itemInfo, 'cartItems'))[0];
    const cartItem = (item?.cartItems?.cartItem ?? [])?.find(
      (tmpCartItem) => tmpCartItem && tmpCartItem?.cartItemType === 'DEVICE',
    );
    let itemPrice = 0;
    if (cartItem) {
      itemPrice =
        has(cartItem, 'discountedPrice') && cartItem?.discountedPrice >= 0
          ? parseFloat(cartItem?.discountedPrice)
          : parseFloat(cartItem?.itemPrice);
    }
    const downPayment = has(line, 'installmentInfo.downPayment') ? parseFloat(line?.installmentInfo?.downPayment) : 0;
    financeAmount = itemPrice - downPayment;
  }

  return financeAmount;
};

export const scmCheckoutMfeEnabled = () => window?.mfe?.scmCheckoutMfeEnable;
export const scmOnlyDeviceMfeEnabled = () => window?.mfe?.scmCheckoutMfeEnable && !window?.mfe?.scmUpgradeMfeEnable;
export const scmVtMultitaskMode = () => window?.mfe?.scmmultitask || false;

export const isEnabledTradeReturnOptionsInContactCenterApps = (
  showTradeAnywhereForBEWithoutEcpdCustomers,
  isCostcoAgent,
) => {
  const channel = sessionStorage.getItem('channel');
  const appProperties = JSON.parse(sessionStorage.getItem('APP_PROPERTIES'));
  const enableReturnAnywhereAssisted = appProperties?.enableReturnAnywhereAssisted?.toLowerCase() === 'true';
  const enableReturnOptionsForTelesales = appProperties?.enableReturnOptionsForTelesales?.toLowerCase() === 'true';
  const enableReturnOptionsForChatStore = appProperties?.enableReturnOptionsForChatStore?.toLowerCase() === 'true';
  const enableReturnOptionsForCare = appProperties?.enableReturnOptionsForCare?.toLowerCase() === 'true';
  let enableReturnOptions = false;
  const eligibleforReturnoptions =
    showTradeAnywhereForBEWithoutEcpdCustomers && enableReturnAnywhereAssisted && !isCostcoAgent;
  if (eligibleforReturnoptions) {
    if (
      (channel?.includes('OMNI-TELESALES') && enableReturnOptionsForTelesales) ||
      (channel?.includes('CHAT-STORE') && enableReturnOptionsForChatStore) ||
      (channel?.includes('OMNI-CARE') && enableReturnOptionsForCare)
    ) {
      enableReturnOptions = true;
    }
  }
  return enableReturnOptions;
};

export const isSDDInCart = (props) => {
  let isSDDCart = false;
  const lineInfo = props?.cartDetails?.lineDetails?.lineInfo;
  if (lineInfo && lineInfo.length) {
    lineInfo.forEach((lineItem) => {
      if (lineItem?.itemsInfo && lineItem?.itemsInfo.length) {
        lineItem.itemsInfo.forEach((item) => {
          if (
            item?.shipping?.shippingCode &&
            (item.shipping.shippingCode === 'SDD_SAMEDAY' || item.shipping.shippingCode === 'SDD_SAMEDAY_NVMP')
          ) {
            isSDDCart = true;
          }
        });
      }
    });
  }
  return isSDDCart;
};

export const getTotalMonthlyBill = (billAccount, monthlyTotals) => {
  const billAccountData = billAccount.flat(1);

  const newMonthChargeInNBS = monthlyTotals?.monthlyTotalsInfo?.newMonthCharge ?? '';
  const thisMonthChargeInNBS = monthlyTotals?.accountLevelChargesVo?.accountLevelTotalVo?.thisMonthCharge ?? '';

  if (billAccountData.length) {
    let monthCharge = 0;
    if (newMonthChargeInNBS && newMonthChargeInNBS !== '') {
      monthCharge = newMonthChargeInNBS;
    } else if (thisMonthChargeInNBS && thisMonthChargeInNBS !== '') {
      monthCharge = thisMonthChargeInNBS;
    } else {
      billAccountData.forEach((item) => {
        const charge = parseFloat(item?.billSummary?.grandTotal?.newMonthCharge);
        if (!Number.isNaN(charge)) {
          monthCharge += charge;
        }
      });
    }
    return monthCharge;
  }
  return '';
};

export const getEstimatedNextBillWithBillAccountNo = (billAccount, monthlyTotals, isSubAccountFlow) => {
  const billAccountData = billAccount.flat(1);
  const nextMonthChargeInNBS = monthlyTotals?.monthlyTotalsInfo?.nextMonthCharge ?? '';
  const dueNextBill = [];
  if (billAccountData.length && billAccountData[0].billAccountNo) {
    if (nextMonthChargeInNBS && nextMonthChargeInNBS !== '' && !isSubAccountFlow) {
      dueNextBill.push({
        billAccountNo: billAccountData?.[0]?.billAccountNo ?? '',
        nextMonthCharge: nextMonthChargeInNBS,
      });
    } else {
      billAccountData.map((item) =>
        has(item, 'billSummary.grandTotal.nextMonthCharge')
          ? dueNextBill.push({
              billAccountNo: item.billAccountNo,
              nextMonthCharge: item.billSummary.grandTotal.nextMonthCharge,
            })
          : [],
      );
    }
    return dueNextBill;
  }
  if (!isSubAccountFlow && nextMonthChargeInNBS && nextMonthChargeInNBS !== '') {
    dueNextBill.push({
      billAccountNo: '0000',
      nextMonthCharge: nextMonthChargeInNBS,
    });
    return dueNextBill;
  }
  return [];
};

export const useCradleState = () => 
  useSelector( (state) => state?.APIService?.queries["getCradleService({\"body\":{\"properties\":[{\"name\":\"applicationId\",\"value\":\"assisted\"},{\"name\":\"locationCode\",\"value\":\"2777301\"},{\"name\":\"pageName\",\"value\":\"SOEORDERSPRINT1\"},{\"name\":\"uswin\",\"value\":\"mastral\"},{\"name\":\"platform\",\"value\":\"desktop\"},{\"name\":\"locationSubType\",\"value\":\"\"}]},\"spinner\":false})"]); 



export const getMTNList = (billAccounts) => {
  let activeMtnList = [];
  let tmpMtnData = null;
  let mtnData = null;
  if (billAccounts?.length > 0) {
    billAccounts.forEach((value) => {
      if (value?.mtns?.length >= 0) {
        tmpMtnData = value.mtns;
      }
    });
    let mtns;
    if (tmpMtnData?.length >= 0) {
      mtnData = tmpMtnData.filter(
        (mtnsData) => mtnsData?.equipmentInfos?.length > 0 && mtnsData?.equipmentInfos[0]?.deviceInfo?.SMSCapable && mtnsData?.equipmentInfos[0]?.deviceInfo?.category?.smartphone,
      );
    }
    if (mtnData?.length > 0) {
      activeMtnList = mtnData.reduce((accum, value, index) => {
        if (Number.isNaN(mtnData[index])) {
          mtns = mtnData[index];
        } else {
          mtns = mtnData[index].mtn;
        }
        accum.push({ value: mtns, label: mtns });
        return accum;
      }, []);
    }
  }
  return activeMtnList;
};

export const isNullOrEmpty = (str) =>
  !str ||
  (str &&
    typeof str !== "undefined" &&
    typeof str === "string" &&
    (str.trim() === "" || str.trim().toUpperCase() === "NULL"));

export function isServiceChangeFlag() {
  try {
    const featureEnablementString = localStorage?.getItem('featureEnablement');
    const featureEnablement = JSON.parse(featureEnablementString);
    const acssFFflag = 'posTrainingScmFFlag';
    const flagValue = featureEnablement[acssFFflag];
    if (flagValue === 'Y') {
      const userProfileString = localStorage?.getItem('userprofile');
      const userProfileData = JSON.parse(userProfileString);
      const { aliasId, userId, trainingEnabled } = userProfileData;
      const hasValidUserData = !isNullOrEmpty(userId) && !isNullOrEmpty(aliasId);
      const isTrainingEnabled =
        trainingEnabled === true || (typeof trainingEnabled === 'string' && trainingEnabled.toUpperCase() === 'Y');
      return Boolean(isTrainingEnabled && hasValidUserData);
   }
   return false;
  } catch (error) {
    return false;
  }
}