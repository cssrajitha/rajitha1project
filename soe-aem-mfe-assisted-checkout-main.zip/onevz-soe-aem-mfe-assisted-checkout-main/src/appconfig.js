export const OrderTotalsProps = {
  enrollPaperFree: 'Enroll in paper free billing',
  enrolPaperFreeBillingDesc:
    'My Verizon Registration is required for paper-free billing. By un-checking the box, the customer will receive a paper bill in the mail.',
  tooltipContent:
    'Instead of Receiving a paper bill, the customer will receive a monthly email and/or text reminders when their bill is ready to view and pay on the My Verizon mobile app or My Verizon web site.',
};

export const TAX_SOFT_SKU = 'TAX80070001';

export const vvcModalConstants = {
  headerLabel: 'Verizon Visa® Card: Pre-approved',
  bodyHeaderContent:
    'Get interest-free financing with 12 equal monthly payment on accessory purchases totaling $100 or more (less Verizon Dollars or discounts) made with Verizon Visa® Card<sup>1</sup>',
  conditionsContent:
    'For Verizon Wireless customers only. Valid online, at Verizon-operated stores, inside sales and customer service.',
  descriptionContent:
    '<sup>1</sup><b>Accessory Finance Promotion.</b> Accessory purchases totaling $100 or more must be on one receipt and charged on your Verizon Visa Card. Must have a Verizon Wireless account associated with your Verizon Visa Card. Use of Verizon Dollars or discounts may result in the qualifying purchase amount not being satisfied. No interest will be charged, and equal monthly payments are required on promo purchase balance, including related debt cancellation fees, until it is paid in full. The payments equal the initial total promo purchase amount (including taxes and delivery) divided by the number of months in the promo period, rounded down to the next cent and may be higher than the payments that would be required if this purchase was a non-promo purchase. Any estimated required monthly payments shown (which may including taxes and delivery) in connection with this promotional offer should allow you to pay off the promotional purchase amount within the promo period (with an additional payment that may be required due to prior months’ rounding) if (1) you make your payments by the due date each month and (2) this is the only balance on your account during the promo period. This promo’s equal monthly payment will not be increased to the minimum amount otherwise due on your account but may be included in or will be added to your minimum payment if you have other balances on your account. If your cart also includes other items, this promo only applies to the accessory purchase(s) plus applicable tax and delivery. On your credit card statement, each promo transaction will be displayed separately from each other and other purchases subject to regular credit card account terms. Regular account terms apply to non-promo purchases. <b>Existing Card Holders:</b> See your credit card agreement terms. Subject to credit approval. Verizon reserves the right to discontinue or alter the terms of this offer at any time.',
  licenseContent: 'The Verizon Visa® Card is issued by Synchrony Bank pursuant to a license from Visa USA Inc.',
  moreInfoContent:
    "<b>Already have a card?</b> Click 'Close' below and continue with your purchase.  For more details visit: https://www.verizon.com/support/verizon-visa-card-faqs/#promos",
  closeLabel: 'Close',
};

export const AccessoryFinanceConstants = {
  accordianTitle: 'Rep Guided Digital - Accessory Finance Option',
  linkSentText: 'Link Sent',
  accordionSubText:
    'To get the benefit of the Verizon Visa Card offer for the accessory financing for this purchase of $100+ in accessories, may i have your consent to send a text message with the link to the disclosures for the offer?',
  sendLabel: 'Send SMS',
  resendLabel: 'Re-send',
  continueLable: 'Continue',
};

export const vvcConstants = {
  checkBoxText: 'Use the Verizon visa card for Accessory financing.',
  detailstext: 'Details',
};

export const affirmConstants = {
  checkBoxtext: 'As low as 0% APR when you pay over time with affirm',
  seeDetailsText: 'See Details',
  affirmButton: 'Affirm credit application',
  affinrShiipinglabel:
    'Please confirm shipping address, address cannot be changed after Affirm credit application is complete',
};

export const affirmModalConstants = {
  title: 'Affirm financing credit application',
  checkboxText:
    'To apply for financing through Affirm, may I have your consent to send a text message/email a link to the credit application to complete on your personal device.',
};

export const humDeviceConstants = {
  vehicleInfo: 'Vehicle Info:',
  emailAddress: 'Telematics Email Address:',
  registeredMtn: 'Telematics Registered Mtn:',
  telematics: 'Telematics Info',
};

export const tradeInConstants = {
  creditTowardsTaxLabel: 'Credit towards tax on',
  creditTowardsItemPriceLabel: 'Credit towards item price on',
  creditTowardsAccountLabel: 'Credit towards customer account ',
  creditTowardsActivationFee: 'Credit towards Activation fee',
  creditTowardsActivationFeeSurcharge: 'Credit towards Activation fee taxes and surcharges',
  giftCardTradeInType: 'Gift Card for Trade-in Value',
  accountTradeinType: 'Account Credit for Trade-in Value',
  errorMessage:
    'The number of trade-in devices exceeds the number of devices being purchased. Proceeding will change this to a non-instant credit order and all the trade-in credits will be applied paid upon receipt of all the trade-in devices instead. To keep this order as instant credit, reduce the number of trade-in device(s) so that it is equal to or less than the number of purchased device(s).',
  tradeinhome: 'Trade at home',
  tradePrepaidLabel: 'Prepaid Label',
  tradeQRCode: 'UPS QR code',
  tradeinLater: 'Trade the device later',
  tradeinNow: 'Trade the device now',
  viewLabel: 'View',
  addLabel: 'Add',
  deviceTradeInCredit: 'Device trade-in credit',
  devicePromoCredit: 'Device promotional credit',
  instantCreditEligibleLabel: 'Instant credit eligible',
};

// view order document constants

export const genereatingReceiptTxt = 'There was an issue while generating the receipt.please ';

export const AEM_PATH = window.location.origin;
export const CUSTOMER_AGREEMENT = `${AEM_PATH}/content/dam/vcg/assisted/customer_agreement.pdf`;
export const RING_AGREEMENT = `${AEM_PATH}/content/dam/vcg/assisted/ring_agreement.pdf`;

export const headerTitle = [
  {
    title: 'Line #',
  },
  {
    title: 'Agreement #',
  },
  {
    title: 'Refresh Status',
  },
];
export const documentReceiptsItems = [
  {
    name: 'Gift receipt',
    btn1: 'Email',
    btn2: 'Print',
    id: 'giftReceipt',
    show: 'giftReceipt',
  },
  {
    name: 'Customer agreement ',
    btn1: 'Email',
    btn2: 'Print',
    id: 'customerAgreement',
    show: 'customerAgreement',
  },
  {
    name: 'Device payment agreement ',
    btn1: 'Email',
    btn2: 'Print',
    id: 'devicePaymentAgreement',
    show: 'devicePaymentAgreement',
  },
  {
    name: 'EdgeUp Buyout Payment Receipt',
    btn1: 'View Receipt',
    id: 'buyOutPaymentReceipt',
    show: 'buyOutPaymentReceipt',
  },
  {
    name: 'Purchase receipt',
    btn1: 'Email',
    btn2: 'Print',
    id: 'purchaseReceipt',
    show: 'purchaseReceipt',
  },
  {
    name: 'Trade-In receipt',
    btn1: '',
    btn2: 'Print',
    id: 'tradeInReceipt',
    show: 'tradeInReceipt',
  },
  {
    name: 'Ring agreement',
    btn1: 'Email',
    btn2: 'Print',
    id: 'isRingAgreement',
    show: 'isRingAgreement',
  },
  {
    name: 'QR code',
    btn1: 'Email',
    btn2: 'Print',
    btn3: 'View',
    id: 'isQRCode',
    show: 'isQRCode',
  },
  {
    name: 'Return Label',
    btn1: 'View',
    id: 'IsReturnLabel',
    show: 'IsReturnLabel',
  },
  {
    name: 'Phone/Smart Watch trade in shipping label',
    btn1: 'Email',
    btn2: 'Print',
    id: 'upsShippingLabel',
    show: 'upsShippingLabel',
  },
  {
    name: 'Tablet trade in shipping label',
    btn1: 'Email',
    btn2: 'Print',
    id: 'tabletUpsShippingLabel',
    show: 'tabletUpsShippingLabel',
  },
];
export const orderNumberLabel = 'Completed order number';
export const vieconstAndPrintModalTitle = 'View and print receipt';
export const viewDpAgreement = 'View DP Agreement';

export const QRCODE_VIEW = '/qrcodeview.html';
export const emailReceiptTitle = 'Email Receipt';
export const addEmailText = 'Add email address';
export const sendBtnText = 'Send';
export const emailBtnText = 'Email';
export const receiptText = 'Receipt';
export const printBtnText = 'Print';

export const DARK_THEME_BGCOLOR = '#14161a';
export const LIGHT_THEME_BGCOLOR = '#ffffff';
