import perkImages from './perkIcons';
import PerkIcon_3525 from './perkIcon_3525.png';
import PerkIcon_2621 from './perkIcon_2621.png';
import PerkIcon_2622 from './perkIcon_2622.png';
import PerkIcon_2630 from './perkIcon_2630.png';
import PerkIcon_2632 from './perkIcon_2632.png';
import PerkIcon_2639 from './perkIcon_2639.png';
import PerkIcon_2640 from './perkIcon_2640.png';
import PerkIcon_2641 from './perkIcon_2641.png';
import PerkIcon_2677 from './perkIcon_2677.png';
import PerkIcon_2678 from './perkIcon_2678.png';
import PerkIcon_2679 from './perkIcon_2679.png';
import PerkIcon_2839 from './perkIcon_2839.png';
import PerkIcon_3192 from './perkIcon_3192.png';
import PerkIcon_3199 from './perkIcon_3199.png';
import PerkIcon_3369 from './perkIcon_3369.png';
import PerkIcon_3625 from './perkIcon_3625.png';

describe('perkImages', () => {
  it('should have the correct src for perk ID 2621', () => {
    expect(perkImages[2621].src).toBe(PerkIcon_2621);
  });

  it('should have the correct src for perk ID 2622', () => {
    expect(perkImages[2622].src).toBe(PerkIcon_2622);
  });

  it('should have the correct src for perk ID 2630', () => {
    expect(perkImages[2630].src).toBe(PerkIcon_2630);
  });

  it('should have the correct src for perk ID 2632', () => {
    expect(perkImages[2632].src).toBe(PerkIcon_2632);
  });

  it('should have the correct src for perk ID 2639', () => {
    expect(perkImages[2639].src).toBe(PerkIcon_2639);
  });

  it('should have the correct src for perk ID 2640', () => {
    expect(perkImages[2640].src).toBe(PerkIcon_2640);
  });

  it('should have the correct src for perk ID 2641', () => {
    expect(perkImages[2641].src).toBe(PerkIcon_2641);
  });

  it('should have the correct src for perk ID 2677', () => {
    expect(perkImages[2677].src).toBe(PerkIcon_2677);
  });

  it('should have the correct src for perk ID 2678', () => {
    expect(perkImages[2678].src).toBe(PerkIcon_2678);
  });

  it('should have the correct src for perk ID 2679', () => {
    expect(perkImages[2679].src).toBe(PerkIcon_2679);
  });

  it('should have the correct src for perk ID 2839', () => {
    expect(perkImages[2839].src).toBe(PerkIcon_2839);
  });

  it('should have the correct src for perk ID 3192', () => {
    expect(perkImages[3192].src).toBe(PerkIcon_3192);
  });

  it('should have the correct src for perk ID 3199', () => {
    expect(perkImages[3199].src).toBe(PerkIcon_3199);
  });

  it('should have the correct src for perk ID 3369', () => {
    expect(perkImages[3369].src).toBe(PerkIcon_3369);
  });

  it('should have the correct src for perk ID 3525', () => {
    expect(perkImages[3525].src).toBe(PerkIcon_3525);
  });

  it('should have the correct src for perk ID 3625', () => {
    expect(perkImages[3625].src).toBe(PerkIcon_3625);
  });
});
