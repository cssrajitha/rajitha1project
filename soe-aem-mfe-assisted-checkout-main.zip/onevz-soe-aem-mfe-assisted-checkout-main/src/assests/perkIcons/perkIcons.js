import PerkIcon_2621 from './perkIcon_2621.png';
import PerkIcon_2622 from './perkIcon_2622.png';
import PerkIcon_2630 from './perkIcon_2630.png';
import PerkIcon_2632 from './perkIcon_2632.png';
import PerkIcon_2639 from './perkIcon_2639.png';
import PerkIcon_2640 from './perkIcon_2640.png';
import PerkIcon_2641 from './perkIcon_2641.png';
import PerkIcon_2677 from './perkIcon_2677.png';
import PerkIcon_2678 from './perkIcon_2678.png';
import PerkIcon_2679 from './perkIcon_2679.png';
import PerkIcon_2839 from './perkIcon_2839.png';
import PerkIcon_3192 from './perkIcon_3192.png';
import PerkIcon_3199 from './perkIcon_3199.png';
import PerkIcon_3369 from './perkIcon_3369.png';
import PerkIcon_3525 from './perkIcon_3525.png';
import PerkIcon_3625 from './perkIcon_3625.png';

const perkImages = {
  2621: {
    src: PerkIcon_2621,
  },
  3198: {
    src: PerkIcon_3199,
  },
  3199: {
    src: PerkIcon_3199,
  },
  3192: {
    src: PerkIcon_3192,
  },
  2622: {
    src: PerkIcon_2622,
  },
  2630: {
    src: PerkIcon_2630,
  },
  2632: {
    src: PerkIcon_2632,
  },
  2639: {
    src: PerkIcon_2639,
  },
  2640: {
    src: PerkIcon_2640,
  },
  2641: {
    src: PerkIcon_2641,
  },
  2677: {
    src: PerkIcon_2677,
  },
  2678: {
    src: PerkIcon_2678,
  },
  2679: {
    src: PerkIcon_2679,
  },
  2839: {
    src: PerkIcon_2839,
  },
  3222: {
    src: PerkIcon_3199,
  },
  3223: {
    src: PerkIcon_3199,
  },
  3369: {
    src: PerkIcon_3369,
  },
  3525: {
    src: PerkIcon_3525,
  },
  3625: {
    src: PerkIcon_3625,
  }
};

export default perkImages;
