import { useLazyGetDeviceDetailsQuery } from '../../../../modules/services/APIService/APIServiceHooks';

const handOffApiCallHook = () => {
  const [getDetailsRequestBody, GetDetailsResult] = useLazyGetDeviceDetailsQuery();

  return {
    getDetailsRequestBody,
    GetDetailsResult,
  };
};

export default handOffApiCallHook;
