import React, { useState, useEffect, useRef } from 'react';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import PropTypes from 'prop-types';
import { useNavigate } from 'react-router-dom';
import { Icon } from '@vds/icons';
import { Title, Body } from '@vds/typography';
import { Line } from '@vds/lines';
import { Button } from '@vds/buttons';
import Emitter from 'onevzsoemfeframework/Emitter';
import { ViewExitDialog } from 'onevzsoemfecommon/ViewExitDialog';
import DownPaymentPage from 'onevzsoemfecommon/DownPaymentDevice';
import styled from 'styled-components';
import { BackClickable, Padding36 } from '../../../../StyledConstants';
import orderreviewApiCallHook from '../orderreviewApiCallHook';
import ManualDiscountView from '../../../../components/OrderReview/ManualDiscountView';

const DividerTop = styled.div`
  margin-top: 50px;
`;
const FooterArea = styled.div`
  max-width: 64rem;
  background-color: rgb(255, 255, 255);
  z-index: 1;
  bottom: 0px;
  position: fixed;
  width: 100%;
  display: flex;
  border-top: 1px solid rgb(0, 0, 0);
  justify-content: center;
  button {
    span {
      padding: 0.6875rem 2.75rem;
    }
  }
`;
const FixedHeader = styled.div`
  max-width: 64rem;
  background-color: rgb(255, 255, 255);
  z-index: 1;
  top: 0;
  width: 100%;
  position: fixed;
  h3 {
    font-size: 2.625rem;
  }
`;
export const FlexAlignContainerItemsCenter = styled.div`
  display: flex;
  align-items: center !important;
  justify-content: space-between;
`;
const Rotate90Degree = styled.div`
  transform: rotate(90deg);
  margin-left: 10px;
  cursor: pointer;
`;
const FlexBoxGrowOne = styled.div`
  display: flex;
  flex-grow: 1;
  height: 4rem;
`;
const CloseIconWrapper = styled.div`
  display: flex;
  a {
    padding: 1rem !important;
  }
`;
const Marginleft = styled.div`
  margin-left: 20px;
`;
const Box = styled.div`
  border: 1px solid #ccc;
  box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.2);
  display: flex;
  width: 200px;
  float: right;
  button {
    border: 0;
    background: none;
    padding: 7px 0;
    cursor: pointer;
    width: 100%;
    text-align: left;
  }
`;
const Handoff = ({ showDiscountMenu = false }) => {
  let navigate = '';
  const scmCheckoutMfeEnabled = window?.mfe?.scmCheckoutMfeEnable;
  function useNavigateMFE() {
    navigate = useNavigate();
  }
  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }
  const { CustomerProfileResult, CartDetailsResult } = orderreviewApiCallHook();
  const activeMtn = getQueryParamByName('activeMtn');
  const [showHamburgerMenu, setShowHamburgerMenu] = useState(false);
  const [showCloseModal, setShowCloseModal] = useState(false);
  const boxRef = useRef(null);
  const buttonRef = useRef(null);
  const firstName =
    CartDetailsResult?.data?.data?.cart?.lineDetails?.lineInfo[0]?.serviceInfo?.serviceAddress?.firstName;
  const primaryFirstName =
    CartDetailsResult?.data?.data?.cart?.lineDetails?.lineInfo[0]?.serviceInfo?.primaryUserInfo?.firstName;
  const customerType = CartDetailsResult.data?.data?.cart?.orderDetails?.customerType;
  const isPrepayCart = CartDetailsResult.data?.data?.cart?.orderDetails?.isPrePayCart === 'Y';
  const handleVerticalIcon = () => {
    setShowHamburgerMenu(!showHamburgerMenu);
  };
  const handleOutsideClick = (event) => {
    if (boxRef.current && !boxRef.current.contains(event.target) && !buttonRef.current.contains(event.target)) {
      setShowHamburgerMenu(false);
    }
  };

  // PageView event on initial load
  useEffect(() => {
    if (CartDetailsResult?.data?.data?.cart) {
      const details = {
        PAGE_LOADED: 'true',
        CUSTOM_EVENT: 'Pageview',
      };
      Emitter.emit('PAGE_LOADED', details);
    }
  }, [CartDetailsResult?.data?.data?.cart]);

  useEffect(() => {
    document.addEventListener('click', handleOutsideClick);
    return () => {
      document.removeEventListener('click', handleOutsideClick);
    };
  }, []);
  const openModal = () => {
    setShowCloseModal(!showCloseModal);
  };
  const showDownpaymentLink = () => {
    let priceType = [];
    const itemsInfo = CartDetailsResult?.data?.data?.cart?.lineDetails?.lineInfo[0]?.itemsInfo;
    const cartItem = itemsInfo?.map((itemInfo) => (itemInfo?.cartItems?.cartItem ? itemInfo.cartItems.cartItem : []));
    cartItem?.map((item) => {
      item?.map((itm) => {
        if (itm.priceType) {
          priceType.push(itm.priceType);
        }
        return itm;
      });
      return item;
    });
    priceType = priceType.find((item) => item === 'VERIZON_EDGE');
    return priceType?.length > 0;
  };
  const [showDownpayment, setshowDownpayment] = useState(false);
  const [showManualDiscount, setManualDiscount] = useState(false);
  const handleDownpaymentClick = () => {
    setshowDownpayment(true);
    setShowHamburgerMenu(false);
  };
  const handleDPDone = () => {
    setshowDownpayment(false);
  };
  const handleDiscountClick = () => {
    setManualDiscount(true);
  };
  const handleDiscountClose = () => {
    setManualDiscount(false);
  };
  const handleCloseIcon = () => {
    window.location.href = `/sales/assisted/new/order-review.html`;
  };
  const nav2OrderReiew = () => {
    if (!scmCheckoutMfeEnabled) {
      navigate(`/sales/assisted/new/order-review.html`);
    } else {
      window?.mfe?.historyRef.push(`/sales/assisted/new/order-review.html`);
    }
  };
  const downPaymentHeaderProps = {
    header: 'Down Payments',
  };
  return (
    <>
      {showCloseModal && (
        <ViewExitDialog
          showCloseModal={showCloseModal}
          setShowCloseModal={setShowCloseModal}
          enableLead
          processStep='ShoppingCart'
        />
      )}
      {!showCloseModal && !showDownpayment && !showManualDiscount && (
        <FixedHeader>
          <FlexAlignContainerItemsCenter>
            <FlexBoxGrowOne>
              <BackClickable
                data-testId='btn-back'
                onClick={() => {
                  window.location.href = `/sales/assisted/landing.html`;
                }}
              >
                <Icon name='left-caret' size='XLarge' medium='true' />
              </BackClickable>
            </FlexBoxGrowOne>
            <CloseIconWrapper>
              <span
                ref={buttonRef}
                role='button'
                tabIndex={0}
                data-testId='vertical-icon'
                onClick={handleVerticalIcon}
                onKeyDown={handleVerticalIcon}
              >
                <Rotate90Degree>
                  <Icon name='more-horizontal' size='large' />
                </Rotate90Degree>
              </span>
              <Marginleft>
                <BackClickable data-testId='btn-exit-dialog' onClick={openModal}>
                  <Icon name='close' size='large' />
                </BackClickable>
              </Marginleft>
            </CloseIconWrapper>
          </FlexAlignContainerItemsCenter>
          <Line type='secondary' />
          {showHamburgerMenu && (
            <Box ref={boxRef}>
              <div style={{ margin: '10px 0px 8px 15px' }}>
                <div>
                  <button
                    type='button'
                    onClick={handleDiscountClick}
                    data-testId='discounts-promotions'
                    data-track='Discounts and promotions'
                  >
                    <Body size='medium'>Discounts and promotions</Body>
                  </button>
                </div>
                {(showDownpaymentLink() || showDiscountMenu) && (
                  <>
                    <Line type='secondary' style={{ margin: '5px 0px 2px 0px' }} />
                    <div>
                      <button
                        type='button'
                        onClick={handleDownpaymentClick}
                        data-testId='down-payments'
                        data-track='Down payments'
                      >
                        <Body size='medium'>Down payments</Body>
                      </button>
                    </div>
                  </>
                )}
              </div>
            </Box>
          )}
          <DividerTop data-testid='lets-review-order'>
            <Title bold size='large'>
              Let&apos;s review your order, &nbsp; {customerType !== 'N' && isPrepayCart ? firstName : primaryFirstName}
            </Title>
          </DividerTop>
          <FooterArea>
            <Padding36>
              <Button data-testid='review-order-button' size='large' disabled={false} onClick={nav2OrderReiew}>
                Review order
              </Button>
            </Padding36>
          </FooterArea>
        </FixedHeader>
      )}
      {showDownpayment && (
        <DownPaymentPage
          CustomerData={CustomerProfileResult?.data?.data?.customer}
          mtn={activeMtn || CustomerProfileResult?.data?.data?.customer?.lookupMtn}
          fromPage=''
          closeClickHandler={handleDPDone}
          closeIcon
          cartHeader={CartDetailsResult?.data?.data?.cart?.cartHeader}
          CartLineInfo={CartDetailsResult?.data?.data?.cart?.lineDetails?.lineInfo}
          headerData={downPaymentHeaderProps}
        />
      )}
      {showManualDiscount && (
        <ManualDiscountView
          handleClose={handleDiscountClose}
          customer={CustomerProfileResult?.data?.data?.customer}
          cart={CartDetailsResult?.data?.data?.cart}
          handleCloseIconModal={handleCloseIcon}
        />
      )}
    </>
  );
};
Handoff.propTypes = {
  showDiscountMenu: PropTypes.bool,
};
export default Handoff;
