import { render, fireEvent } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../../../modules/store';
import Handoff from './handoff';
import mockCartJson from '../../../../__mock__/retrive-cart.json';
import mockCustomerJson from '../../../../__mock__/retrieve-customer.json';

const mockedUsedNavigate = jest.fn();

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockedUsedNavigate,
}));

jest.mock('../../../../modules/services/APIService/APIServiceHooks', () => ({
  __esModule: true,
  ...jest.requireActual('../../../../modules/services/APIService/APIServiceHooks'),
  useGetCustomerProfileQuery: () => ({
    status: 'Success',
    isUninitialized: false,
    isLoading: false,
    isSuccess: true,
    isError: false,
    isFetching: false,
    data: mockCustomerJson,
  }),
  useGetCartDetailsQuery: () => ({
    status: 'Success',
    isUninitialized: false,
    isLoading: false,
    isSuccess: true,
    isError: false,
    isFetching: false,
    data: mockCartJson,
  }),
}));

describe('Home page order review', () => {
  test('renders home page', () => {
    const { getByTestId } = render(
      <BrowserRouter>
        <StoreProvider>
          <Handoff />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = getByTestId('lets-review-order');
    expect(titleElement).toBeInTheDocument();
    const backButton = getByTestId('btn-back');
    expect(backButton).toBeInTheDocument();
    const reviewOrderButton = getByTestId('review-order-button');
    expect(reviewOrderButton).toBeInTheDocument();
    fireEvent.click(reviewOrderButton);
    expect(mockedUsedNavigate).toHaveBeenCalled();
    expect(mockedUsedNavigate).toHaveBeenCalledWith('/sales/assisted/new/order-review.html');
    fireEvent.click(backButton);
    expect(titleElement).toBeInTheDocument();
    expect(mockedUsedNavigate).toHaveBeenCalled();
  });

  test('renders home page 01', () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] };
    const { getByTestId } = render(
      <BrowserRouter>
        <StoreProvider>
          <Handoff />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = getByTestId('lets-review-order');
    expect(titleElement).toBeInTheDocument();
    const backButton = getByTestId('btn-back');
    expect(backButton).toBeInTheDocument();
    const reviewOrderButton = getByTestId('review-order-button');
    expect(reviewOrderButton).toBeInTheDocument();
    fireEvent.click(reviewOrderButton);
    fireEvent.click(backButton);
    expect(titleElement).toBeInTheDocument();
  });

  test('click vertical icon', () => {
    const { getByTestId } = render(
      <BrowserRouter>
        <StoreProvider>
          <Handoff showDiscountMenu />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = getByTestId('lets-review-order');
    expect(titleElement).toBeInTheDocument();
    const verticalIcon = getByTestId('vertical-icon');
    expect(verticalIcon).toBeInTheDocument();
    fireEvent.click(verticalIcon);
    const discountsOption = getByTestId('discounts-promotions');
    expect(discountsOption).toBeInTheDocument();
    const downPaymentOption = getByTestId('down-payments');
    expect(downPaymentOption).toBeInTheDocument();
    fireEvent.click(titleElement);
  });

  test('click downpayment option', () => {
    const { getByTestId } = render(
      <BrowserRouter>
        <StoreProvider>
          <Handoff showDiscountMenu />
        </StoreProvider>
      </BrowserRouter>,
    );
    const verticalIcon = getByTestId('vertical-icon');
    expect(verticalIcon).toBeInTheDocument();
    fireEvent.click(verticalIcon);
    const downPaymentOption = getByTestId('down-payments');
    expect(downPaymentOption).toBeInTheDocument();
    fireEvent.click(downPaymentOption);
  });

  test('click close icon', () => {
    const { getByTestId } = render(
      <BrowserRouter>
        <StoreProvider>
          <Handoff />
        </StoreProvider>
      </BrowserRouter>,
    );
    const closeIcon = getByTestId('btn-exit-dialog');
    expect(closeIcon).toBeInTheDocument();
    fireEvent.click(closeIcon);
  });
});
