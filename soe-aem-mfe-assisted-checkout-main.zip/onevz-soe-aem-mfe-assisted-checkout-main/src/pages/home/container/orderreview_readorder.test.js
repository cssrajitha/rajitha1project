import React from 'react';
import { HttpService } from 'onevzsoemfeframework/HTTPService';
import { isIpad, executeShellFunction } from 'onevzsoemfeframework/DomService';
import { useGetOffersPdpMutation } from 'onevzsoemfecommon/AccountAPIService';
import PropTypes from 'prop-types';
import { render, screen, fireEvent } from '../../../utils/test-utils/renderHelper';
import OrderReview from './orderreview';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import customerJson from '../../../__mock__/retrieve-customer.json';
// import newCustRetriveCartJson from '../../../__mock__/newcustomer-retriveCart.json';
import tradeinRetrieveCartJson from '../../../__mock__/tradeinRetrieveCart.json';
import * as orderreviewApiCallHook from './orderreviewApiCallHook';
import { useLazyGetReadOrderQuery } from '../../../modules/services/APIService/APIServiceCallHook';

jest.mock('../../../utils/tagging');

const MockNotificationComponent = ({ onCloseButtonClick, title, buttonData = [], ...props }) => (
  <div {...props} data-testid='notification'>
    {title}{' '}
    {buttonData.map((i) => (
      <button type='button' onClick={i.onClick}>
        {i.children}
      </button>
    ))}
    <button type='button' data-testid='mocked-close-button' onClick={onCloseButtonClick}>
      close
    </button>
  </div>
);

MockNotificationComponent.propTypes = {
  onCloseButtonClick: PropTypes.func,
  title: PropTypes.string,
  buttonData: PropTypes.array,
};

jest.mock('@vds/notifications', () => ({
  __esModule: true,
  Notification: (props) => <MockNotificationComponent {...props} />,
}));
jest.mock('onevzsoemfecommon/AccountAPIService', () => ({
  useGetOffersPdpMutation: jest.fn(),
}));
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: (keys) =>
      keys.map(
        (key) =>
          ({
            isSecondaryUswinAuthEnabled: 'TRUE',
            enableReturnAnywhereAssisted: 'TRUE',
            blockRTSForBEWithoutEcpdCustomers: 'TRUE',
            enableReturnOptionsForNewCustomerInRetail: 'TRUE',
            retailCompanionForVTFFlag: 'TRUE',
            retailCompanionForVTCheckoutMfeFFlag: 'TRUE',
            readOrderMfeFFlag: 'TRUE',
          })[[key]],
      ),
  }),
  { virtual: true },
);
jest.mock(
  '../../../modules/services/APIService/APIServiceHooks',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('../../../modules/services/APIService/APIServiceHooks'),
      useLazyGetFetchDownpaymentQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              serviceHeader: {
                clientId: 'VZW-NETACE',
                statusMsg: 'SUCCESS',
                serviceName: 'SalesOrderPurchase',
                userId: '',
                statusCode: '00',
                sessionId: '',
                correlationId: 'Interim-soe-1c2c2bb8-a8a6-4982-8454-681b14d72b02',
              },
              serviceBody: {
                serviceResponse: {
                  context: {
                    caseId: 'SOP-14936155-C01',
                    contextInfo: {
                      callReason: 'SalesOrderPurchase',
                      processStep: 'ShowHandoff',
                      processAction: '',
                      availablePaths: [
                        {
                          path: 'ShowHandoff',
                        },
                        {
                          path: 'DownPayment',
                        },
                        {
                          path: 'DiscountPage',
                        },
                        {
                          path: 'ShoppingCart',
                        },
                      ],
                    },
                    customerInfo: {
                      nocByod: false,
                      accountNumber: '0325117909-00001',
                      cartCreator: '2489306470',
                      processingMTN: '2489306470',
                      registerNumber: 0,
                      noc: false,
                      myvPage: false,
                    },
                    cartInfo: {
                      cartItemCount: 0,
                      cartId: '7fd39067-703f-4878-8ef4-76a97354821c',
                      discountPromoTotal: 0.0,
                      registerNumber: 0,
                      protectionNotRequired: false,
                      fmiCheck: false,
                      isFlexV2: false,
                      isPrepaidToPostpaidMigration: false,
                      instantCreditAmount: 0,
                    },
                    authenticateApproval: {
                      approved: true,
                      firstName: '',
                      lastName: '',
                      message: 'MGR [dharnvi] test. Approver info saved to cart.',
                    },
                  },
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
    };
  },
  { virtual: true },
);
jest.mock('../../../modules/services/APIService/APIServiceCallHook', () => ({
  ...jest.requireActual('../../../modules/services/APIService/APIServiceCallHook'),
  useLazyGetCartDetailsQuery: () => [() => {}, {}],
  useLazyGetReadOrderQuery: jest.fn(),
  useGetOrderReviewQuery: jest.fn(),
}));

jest.mock('onevzsoemfeframework/DomService', () => ({
  ...jest.requireActual('onevzsoemfeframework/DomService'),
  isIpad: jest.fn(),
  executeShellFunction: jest.fn(),
}));

let getOffersMock;
let getOffersResultsMock;

beforeEach(() => {
  getOffersMock = jest.fn();
  getOffersResultsMock = {
    data: null,
    error: null,
    isLoading: false,
    isSuccess: false,
    isError: false,
  };
  useGetOffersPdpMutation.mockReturnValue([getOffersMock, getOffersResultsMock]);
  useLazyGetReadOrderQuery.mockReturnValue([
    () => jest.fn(),
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
    },
  ]);
  jest.spyOn(HttpService, 'post').mockImplementation(() => Promise.resolve({ mockId: 'ort129' }));
});

beforeEach(() => {
  sessionStorage.setItem('channel', 'OMNI-RETAIL');
  sessionStorage.setItem(
    'APP_PROPERTIES',
    JSON.stringify({
      enableReturnAnywhereAssisted: 'TRUE',
      blockRTSForBEWithoutEcpdCustomers: 'TRUE',
      enableReturnOptionsForNewCustomerInRetail: 'TRUE',
    }),
  );
});

describe('Read Order View', () => {
  beforeEach(() => {
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: tradeinRetrieveCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    jest.spyOn(HttpService, 'post').mockImplementation(() => Promise.resolve({ mockId: 'ort684' }));
  });

  it('order details should be shown', async () => {
    const mockData = [
      {
        lineActivityType: 'EUP',
        itemsInfo: [
          {
            cartItems: {
              cartItem: [
                { cartItemType: 'DEVICE', id: 'device1', name: 'Device A' },
                { cartItemType: 'ACCESSORY', id: 'accessory1', name: 'Accessory A' },
              ],
            },
            installmentInfo: null,
          },
        ],
        selectedFeaturesList: {
          visFeature: [
            {
              addDeleteInd: 'A',
              source: 'USER',
              featurePrice: 10,
              featureName: 'Feature A',
            },
            {
              addDeleteInd: 'D',
              source: 'SYSTEM',
              featurePrice: 0,
              featureName: 'Feature B',
            },
          ],
        },
      },
      {
        lineActivityType: 'FEA',
        itemsInfo: [
          {
            cartItems: {
              cartItem: [{ cartItemType: 'DEVICE', id: 'device2', name: 'Device B' }],
            },
            installmentInfo: null,
          },
        ],
        selectedFeaturesList: {
          visFeature: [
            {
              addDeleteInd: 'A',
              source: 'USER',
              featurePrice: 5,
              featureName: 'Feature C',
            },
          ],
        },
      },
    ];
    useLazyGetReadOrderQuery.mockReturnValue([
      () => {},
      {
        data: {
          data: {
            cart: {
              orderDetails: {
                orderList: [
                  { orderNumer: 1234, orderStatus: 'OM', cartHeaderStatus: 'P' },
                  { orderNumer: 5678, orderStatus: 'OM', cartHeaderStatus: 'P' },
                ],
                locationCode: null,
                orderNumber: '1234567890',
              },
              lineDetails: {
                lineInfo: mockData,
              },
            },
            orderStatus: 'CO',
          },
        },
        isUninitialized: true,
        status: 'fulfilled',
      },
    ]);
    render(<OrderReview readOrder />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  it('order details should be shown', async () => {
    useLazyGetReadOrderQuery.mockReturnValue([
      () => {},
      {
        data: {
          data: {
            cart: {
              orderDetails: {
                orderList: [
                  { orderNumer: 1234, orderStatus: 'OM', cartHeaderStatus: 'P' },
                  { orderNumer: 5678, orderStatus: 'OM', cartHeaderStatus: 'P' },
                ],
                locationCode: null,
                orderNumber: '1234567890',
              },
              lineDetails: {
                lineInfo: [
                  {
                    lineActivityType: 'CPC',
                    itemsInfo: [
                      {
                        cartItems: {
                          cartItem: [{ cartItemType: 'ACCESSORY', id: 'accessory1', name: 'Accessory A' }],
                        },
                      },
                    ],
                  },
                  {
                    lineActivityType: 'EUP',
                    itemsInfo: [
                      {
                        cartItems: {
                          cartItem: [],
                        },
                        installmentInfo: null,
                      },
                    ],
                  },
                ],
              },
            },
            orderStatus: 'CO',
          },
        },
        isUninitialized: true,
        status: 'fulfilled',
      },
    ]);
    render(<OrderReview readOrder />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  it('order details should be shown', async () => {
    useLazyGetReadOrderQuery.mockReturnValue([
      () => {},
      {
        data: {
          data: {
            cart: {
              orderDetails: {
                orderList: [
                  { orderNumer: 1234, orderStatus: 'OM', cartHeaderStatus: 'P' },
                  { orderNumer: 5678, orderStatus: 'OM', cartHeaderStatus: 'P' },
                ],
                locationCode: null,
                orderNumber: '1234567890',
              },
            },
            orderStatus: 'CR',
          },
        },
        isUninitialized: true,
        status: 'fulfilled',
      },
    ]);
    render(<OrderReview readOrder />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
});

describe('PreOrderShipment Functionality', () => {
  sessionStorage.setItem('readOrder', true);
  sessionStorage.setItem(
    'APP_PROPERTIES',
    JSON.stringify({
      enableReturnAnywhereAssisted: 'TRUE',
      blockRTSForBEWithoutEcpdCustomers: 'TRUE',
      enableReturnOptionsForNewCustomerInRetail: 'TRUE',
      readOrderMfeFFlag: 'TRUE',
    }),
  );
  beforeEach(() => {
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: {} },
      CartDetailsResult: { data: {} },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
  });

  it('should display pre-order shipment message when conditions are met', async () => {
    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        enableReturnAnywhereAssisted: 'TRUE',
        blockRTSForBEWithoutEcpdCustomers: 'TRUE',
        enableReturnOptionsForNewCustomerInRetail: 'TRUE',
        readOrderMfeFFlag: 'TRUE',
        preOrderModalFFlag: 'TRUE',
      }),
    );
    const mockReadOrderData = {
      data: {
        cart: {
          lineDetails: {
            lineActivityType: '',
            lineInfo: [
              {
                itemsInfo: [
                  {
                    lineActivityType: '',
                    cartItems: {
                      cartItem: [
                        {
                          cartItemType: 'DEVICE',
                          inventory: { isPreOrder: true },
                          depletionType: 'F',
                        },
                      ],
                    },
                  },
                ],
              },
            ],
          },
          orderDetails: {
            preOrderDetails: [
              {
                ordStatus: 'C',
              },
            ],
          },
        },
        paymentDetails: {
          totalDueToday: 100,
        },
      },
    };
    useLazyGetReadOrderQuery.mockReturnValue([
      () => {},
      {
        data: mockReadOrderData,
        isUninitialized: false,
        status: 'fulfilled',
      },
    ]);

    render(<OrderReview readOrder />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    const preOrderMessage = await screen.findByTestId('preOrderText');
    expect(preOrderMessage).toBeInTheDocument();

    const preOrderStatus = mockReadOrderData.data.cart.orderDetails.preOrderDetails[0].ordStatus.split('-')[0];
    expect(preOrderStatus).toBe('C');
    const closeButton = screen.getByTestId('closeButton');
    fireEvent.click(closeButton);
  });

  it('should call executeShellFunction with correct parameters when isIpad is true', async () => {
    isIpad.mockReturnValue(true);

    sessionStorage.setItem('readOrder', true);
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        enableReturnAnywhereAssisted: 'TRUE',
        blockRTSForBEWithoutEcpdCustomers: 'TRUE',
        enableReturnOptionsForNewCustomerInRetail: 'TRUE',
        readOrderMfeFFlag: 'TRUE',
        preOrderModalFFlag: 'TRUE',
      }),
    );

    const mockReadOrderData = {
      data: {
        cart: {
          lineDetails: {
            lineActivityType: '',
            lineInfo: [
              {
                itemsInfo: [
                  {
                    lineActivityType: '',
                    cartItems: {
                      cartItem: [
                        {
                          cartItemType: 'DEVICE',
                          inventory: { isPreOrder: true },
                          depletionType: 'F',
                        },
                      ],
                    },
                  },
                ],
              },
            ],
          },
          orderDetails: {
            preOrderDetails: [
              {
                ordStatus: 'C',
              },
            ],
          },
        },
        paymentDetails: {
          totalDueToday: 100,
        },
      },
    };

    useLazyGetReadOrderQuery.mockReturnValue([
      () => {},
      {
        data: mockReadOrderData,
        isUninitialized: false,
        status: 'fulfilled',
      },
    ]);

    render(<OrderReview readOrder />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    const closeButton = screen.getByTestId('closeButton');
    fireEvent.click(closeButton);

    const shellParams = {
      name: 'Home',
      path: '',
      replace: 'false',
      params: '',
    };
    const comboParams = {
      params: [
        { class: 'Shell', functionName: 'showScreen', params: shellParams },
        { class: 'Shell', functionName: 'killOrderScreen', params: {} },
        { class: 'Shell', functionName: 'stopTransactionTimeClock', params: {} },
      ],
    };

    expect(isIpad).toHaveBeenCalled();
    expect(executeShellFunction).toHaveBeenCalledWith('Shell', 'executeShellFunctions', 'none', comboParams);
  });
});
