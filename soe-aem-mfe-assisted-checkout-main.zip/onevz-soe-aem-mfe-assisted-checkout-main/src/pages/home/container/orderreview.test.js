import React from 'react';
import Emitter from 'onevzsoemfeframework/Emitter';
import { HttpService } from 'onevzsoemfeframework/HTTPService';
import { useGetOffersPdpMutation } from 'onevzsoemfecommon/AccountAPIService';
import PropTypes from 'prop-types';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers/queryParams';
import { render, screen, fireEvent, waitFor } from '../../../utils/test-utils/renderHelper';
import OrderReview from './orderreview';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import mockCartJson from '../../../__mock__/retrive-cart-orderreview.json';
import appointmentMockCartJson from '../../../__mock__/retrieveCArt5GAppointment.json';
import { getSetupAndGoCart } from '../../../__mock__/setup-go-cart';
import customerJson from '../../../__mock__/retrieve-customer.json';
// import newCustRetriveCartJson from '../../../__mock__/newcustomer-retriveCart.json';
import tradeinRetrieveCartJson from '../../../__mock__/tradeinRetrieveCart.json';
import CheckoutDetails from '../../../components/OrderReview/CheckoutDetails';
import * as orderreviewApiCallHook from './orderreviewApiCallHook';
import { useLazyGetReadOrderQuery } from '../../../modules/services/APIService/APIServiceCallHook';

jest.mock('onevzsoemfecommon/Helpers', () => ({
  ...jest.requireActual('onevzsoemfecommon/Helpers'),
  getQueryParamByName: jest.fn(),
  formatPhoneNumber: jest.fn(),
}));
jest.mock('../../../utils/tagging');
jest.mock('onevzsoemfecommon/LOVPageTracker', () => ({
  __esModule: true,
  default: ({ viewCreditModal }) => (
    <button type='button' data-testid='mocked-closeModal' onClick={viewCreditModal}>
      closeModal PreviewBill Mock
    </button>
  ),
}));

jest.mock('../../../components/OrderReview/Affirm', () => ({
  __esModule: true,
  default: () => <div data-testid='view-together-footer'>mocked Affirm modal</div>,
}));

const MockNotificationComponent = ({ onCloseButtonClick, title, buttonData = [], ...props }) => (
  <div {...props} data-testid='notification'>
    {title}{' '}
    {buttonData.map((i) => (
      <button type='button' onClick={i.onClick}>
        {i.children}
      </button>
    ))}
    <button type='button' data-testid='mocked-close-button' onClick={onCloseButtonClick}>
      close
    </button>
  </div>
);

MockNotificationComponent.propTypes = {
  onCloseButtonClick: PropTypes.func,
  title: PropTypes.string,
  buttonData: PropTypes.array,
};

jest.mock(
  'onevzsoemfecommon/Helpers/queryParams',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/Helpers/queryParams'),
    getQueryParamByName: jest.fn(() => ({
      close: true,
    })),
  }),
  { virtual: true },
);

jest.mock('@vds/notifications', () => ({
  __esModule: true,
  Notification: (props) => <MockNotificationComponent {...props} />,
}));
jest.mock('onevzsoemfecommon/AccountAPIService', () => ({
  useGetOffersPdpMutation: jest.fn(),
}));

// Mock react-redux
const mockDispatch = jest.fn();
jest.mock('react-redux', () => ({
  ...jest.requireActual('react-redux'),
  useDispatch: () => mockDispatch,
}));
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: (keys) =>
      keys.map(
        (key) =>
          ({
            isSecondaryUswinAuthEnabled: 'TRUE',
            enableReturnAnywhereAssisted: 'TRUE',
            blockRTSForBEWithoutEcpdCustomers: 'TRUE',
            enableReturnOptionsForNewCustomerInRetail: 'TRUE',
            retailCompanionForVTFFlag: 'TRUE',
            retailCompanionForVTCheckoutMfeFFlag: 'TRUE',
          })[[key]],
      ),
  }),
  { virtual: true },
);
jest.mock(
  '../../../modules/services/APIService/APIServiceHooks',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('../../../modules/services/APIService/APIServiceHooks'),
      useLazyGetFetchDownpaymentQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              serviceHeader: {
                clientId: 'VZW-NETACE',
                statusMsg: 'SUCCESS',
                serviceName: 'SalesOrderPurchase',
                userId: '',
                statusCode: '00',
                sessionId: '',
                correlationId: 'Interim-soe-1c2c2bb8-a8a6-4982-8454-681b14d72b02',
              },
              serviceBody: {
                serviceResponse: {
                  context: {
                    caseId: 'SOP-14936155-C01',
                    contextInfo: {
                      callReason: 'SalesOrderPurchase',
                      processStep: 'ShowHandoff',
                      processAction: '',
                      availablePaths: [
                        {
                          path: 'ShowHandoff',
                        },
                        {
                          path: 'DownPayment',
                        },
                        {
                          path: 'DiscountPage',
                        },
                        {
                          path: 'ShoppingCart',
                        },
                      ],
                    },
                    customerInfo: {
                      nocByod: false,
                      accountNumber: '0325117909-00001',
                      cartCreator: '2489306470',
                      processingMTN: '2489306470',
                      registerNumber: 0,
                      noc: false,
                      myvPage: false,
                    },
                    cartInfo: {
                      cartItemCount: 0,
                      cartId: '7fd39067-703f-4878-8ef4-76a97354821c',
                      discountPromoTotal: 0.0,
                      registerNumber: 0,
                      protectionNotRequired: false,
                      fmiCheck: false,
                      isFlexV2: false,
                      isPrepaidToPostpaidMigration: false,
                      instantCreditAmount: 0,
                    },
                    authenticateApproval: {
                      approved: true,
                      firstName: '',
                      lastName: '',
                      message: 'MGR [dharnvi] test. Approver info saved to cart.',
                    },
                  },
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
    };
  },
  { virtual: true },
);
jest.mock('../../../modules/services/APIService/APIServiceCallHook', () => ({
  ...jest.requireActual('../../../modules/services/APIService/APIServiceCallHook'),
  useLazyGetCartDetailsQuery: () => [() => {}, {}],
  useLazyGetReadOrderQuery: jest.fn(),
  useGetOrderReviewQuery: () => ({
    status: 0,
    showAccessoriesSection: true,
    showNotificationSection: false,
    showPurchaseOrderSection: false,
    telesalesNegativeReasonList: false,
    retailNegativeReasonList: true,
    showGiftPurchase: true,
    showOnlineOffers: false,
    showTradeInSection: true,
    channelId: 'OMNI-RETAIL',
    mtnCount: 0,
    purchaseOrderNumRequired: false,
    ptechEnabledForRetailLoc: false,
  }),
}));

const mockCartResult = ({ selectedALPShareList = {} } = {}) => ({
  data: {
    data: {
      cart: {
        lineDetails: {
          lineInfo: [
            {
              serviceInfo: {
                selectedALPShareList,
              },
              itemsInfo: [],
            },
          ],
        },
      },
    },
  },
});

const pricedSnapshot = {
  shared: {
    addons: [
      {
        sorId: '732',
        skuName: 'CDMA-LESS ROAM TIER OVERRIDE',
        type: 'SPO',
        isSPO: true,
        actionIndicator: 'Z',
        isExisting: true,
        price: {
          regularPrice: 0,
          discountedPrice: 0,
          actualDiscount: 0,
          promos: [],
        },
        isGeneralAddon: true,
        isDisplayable: true,
        isNotRemovable: true,
        isPerk: false,
        spoMethodCode: 'A',
      },
    ],
  },
  refetch: jest.fn(),
};

let getOffersMock;
let getOffersResultsMock;

beforeEach(() => {
  getOffersMock = jest.fn();
  getOffersResultsMock = {
    data: null,
    error: null,
    isLoading: false,
    isSuccess: false,
    isError: false,
  };
  useGetOffersPdpMutation.mockReturnValue([getOffersMock, getOffersResultsMock]);
  useLazyGetReadOrderQuery.mockReturnValue([
    () => jest.fn(),
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      data: {
        data: {
          cart: {
            orderDetails: {
              orderList: [
                { orderNumer: 1234, orderStatus: 'OM', cartHeaderStatus: 'P' },
                { orderNumer: 5678, orderStatus: 'OM', cartHeaderStatus: 'P' },
              ],
              locationCode: '123456',
              orderNumber: '1234567890',
            },
          },
        },
      },
    },
  ]);
  jest.spyOn(HttpService, 'post').mockImplementation(() => Promise.resolve({ mockId: 'ort129' }));
});

beforeEach(() => {
  sessionStorage.setItem('channel', 'OMNI-RETAIL');
  sessionStorage.setItem(
    'APP_PROPERTIES',
    JSON.stringify({
      enableReturnAnywhereAssisted: 'TRUE',
      blockRTSForBEWithoutEcpdCustomers: 'TRUE',
      enableReturnOptionsForNewCustomerInRetail: 'TRUE',
    }),
  );
});

describe('Footer Component Tests', () => {
  const openDevice = jest.fn();

  beforeEach(() => {
    getOffersMock = jest.fn();
    getOffersResultsMock = {
      data: null,
      error: null,
      isLoading: false,
      isSuccess: false,
      isError: false,
    };

    useGetOffersPdpMutation.mockReturnValue([getOffersMock, getOffersResultsMock]);
    // jest.spyOn(HttpService, 'post').mockImplementation(() => Promise.resolve({ mockId: 'ort150' }));
  });

  test('should call getOffers and handle response', async () => {
    // Update the mock response
    getOffersResultsMock = {
      data: { offers: ['Offer1', 'Offer2'] },
      error: null,
      isLoading: false,
      isSuccess: true,
      isError: false,
    };

    useGetOffersPdpMutation.mockReturnValue([getOffersMock, getOffersResultsMock]);

    render(<CheckoutDetails openDeviceInformation={openDevice} cart={mockCartJson} customer={customerJson} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('should handle error response', async () => {
    // Update the mock response to simulate an error
    getOffersResultsMock = {
      data: null,
      error: { message: 'Error fetching offers' },
      isLoading: false,
      isSuccess: false,
      isError: true,
    };

    useGetOffersPdpMutation.mockReturnValue([getOffersMock, getOffersResultsMock]);

    render(<CheckoutDetails openDeviceInformation={openDevice} cart={mockCartJson} customer={customerJson} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
});

describe('Home page order review', () => {
  it('Post api call for Customer and Retrieve cart', () => {
    const openDevice = jest.fn();
    openDevice.mockReturnValueOnce(true);
    render(
      <CheckoutDetails openDeviceInformation={openDevice} cart={appointmentMockCartJson} customer={customerJson} />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });

  afterAll(() => {
    const openDevice = jest.fn();
    openDevice.mockReturnValueOnce(true);

    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: appointmentMockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
    }));
    render(
      <CheckoutDetails
        openDeviceInformation={() => openDevice(true)}
        cart={appointmentMockCartJson}
        customer={customerJson}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });

  beforeEach(() => {
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: getSetupAndGoCart() },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    Emitter.emit('TAGGING_COMPLETED', true);
    jest.spyOn(HttpService, 'post').mockImplementation(() => Promise.resolve({ mockId: 'ort228' }));
  });

  test('renders home page', async () => {
    window.sessionStorage.setItem('isLovEligibleFromSessionStorage', 'false');
    window.sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'TRUE', sroAppliedBannerFFlag: 'TRUE' }),
    );

    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    screen.debug();
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: mockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    render(<CheckoutDetails cart={mockCartJson} customer={customerJson} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('renders home page render view together with Retail Companion', async () => {
    window.sessionStorage.setItem('isRCCart', 'true');

    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('renders home page render view together with isExpressCheckout', async () => {
    window.mfe = {
      scmCheckoutMfeEnable: true,
      historyRef: [],
      scmVtButtonEnable: true,
      scmUpgradeMfeEnable: true,
      isProspectNewCustomerTab: true,
    };
    window.sessionStorage.setItem('isLovEligibleFromSessionStorage', 'true');

    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    // screen.debug();
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: appointmentMockCartJson },
      FetchPricingSnapshotResult: { data: { data: { flags: { isExpressCheckout: true } } }, refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    render(<CheckoutDetails cart={appointmentMockCartJson} customer={customerJson} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await waitFor(() => {
      const viewTogetherButton = screen.getByTestId('view-together-footer');
      fireEvent.click(viewTogetherButton);

      const titleElement = screen.getByTestId('view-together-accordion');
      expect(titleElement).toBeInTheDocument();

      const spanishToggle = screen.getByTestId('test-hitArea');
      expect(spanishToggle).toBeInTheDocument();
      fireEvent.click(spanishToggle);

      expect(
        screen.getByText(
          'Advise customer certain agreements in the Terms and Conditions page are only available in English.',
        ),
      ).toBeInTheDocument();

      const closeButton = screen.getByTestId('mocked-close-button');
      expect(closeButton).toBeInTheDocument();
      fireEvent.click(closeButton);

      const radioButtonVT = screen.getByLabelText('customer cannot complete in VT');
      expect(radioButtonVT).toBeInTheDocument();
      fireEvent.click(radioButtonVT);

      const selectElement = screen.getByTestId('select-reason-vt');
      fireEvent.change(selectElement, { target: { value: 'Systemic Issue Impeding Transaction' } });

      expect(screen.getByTestId('continue-vt')).toBeInTheDocument();
      fireEvent.click(screen.getByTestId('continue-vt'));

      // test('on back icon', async () => {
      const backButton = screen.getByTestId('btn-back');
      screen.logTestingPlaygroundURL();
      expect(backButton).toBeInTheDocument();
      fireEvent.click(backButton);
      // });
    });
  });
  test('renders home page render view together', async () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], scmVtButtonEnable: true, scmUpgradeMfeEnable: true };
    window.sessionStorage.setItem('isLovEligibleFromSessionStorage', 'true');

    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    // screen.debug();
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: appointmentMockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    render(<CheckoutDetails cart={appointmentMockCartJson} customer={customerJson} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    await waitFor(() => {
      const viewTogetherButton = screen.getByTestId('view-together-footer');
      fireEvent.click(viewTogetherButton);

      const titleElement = screen.getByTestId('view-together-accordion');
      expect(titleElement).toBeInTheDocument();

      const radioButtonVT = screen.getByLabelText('customer cannot complete in VT');
      expect(radioButtonVT).toBeInTheDocument();
      fireEvent.click(radioButtonVT);

      const selectElement = screen.getByTestId('select-reason-vt');
      fireEvent.change(selectElement, { target: { value: 'Systemic Issue Impeding Transaction' } });

      expect(screen.getByTestId('continue-vt')).toBeInTheDocument();
      fireEvent.click(screen.getByTestId('continue-vt'));
    });
  });
  test('renders home page render view together QR-Code Generator', async () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], scmVtButtonEnable: true, scmUpgradeMfeEnable: true };
    window.sessionStorage.setItem('isLovEligibleFromSessionStorage', 'true');

    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    // screen.debug();
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: mockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    render(<CheckoutDetails cart={mockCartJson} customer={customerJson} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await waitFor(() => {
      const viewTogetherButton = screen.getByTestId('view-together-footer');
      fireEvent.click(viewTogetherButton);
    });
    await waitFor(() => {
      // const viewTogetherPTA = screen.getByLabelText('radio two');
      // expect(viewTogetherPTA).toBeInTheDocument();
      // fireEvent.click(viewTogetherPTA);
      // const generateButtonOnPTA = screen.getByLabelText('Generate');
      // expect(generateButtonOnPTA).toBeInTheDocument();
      // fireEvent.click(generateButtonOnPTA);
      // const customerQR = screen.getByLabelText('radio one');
      // expect(customerQR).toBeInTheDocument();
      // fireEvent.click(customerQR);
    });
  });
  test('renders home page render view together', async () => {
    window.sessionStorage.setItem('isViewTogether', false);
    window.sessionStorage.setItem('isLovEligibleFromSessionStorage', 'true');
    const mockhistroyRef = jest.fn();
    window.mfe = {
      scmCheckoutMfeEnable: true,
      historyRef: jest.fn(),
      scmVtButtonEnable: true,
      scmUpgradeMfeEnable: true,
    };
    window.mfe.historyRef.push = mockhistroyRef;
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: getSetupAndGoCart(0, 'NSE_5G', 'O') },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    // screen.debug();
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: mockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    render(<CheckoutDetails cart={mockCartJson} customer={customerJson} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await waitFor(() => {
      const viewTogetherButton = screen.getByTestId('view-together-footer');
      fireEvent.click(viewTogetherButton);

      expect(screen.getByText('Please schedule installation appointment to continue')).toBeInTheDocument();

      const closeButton = screen.getByTestId('mocked-close-button');
      expect(closeButton).toBeInTheDocument();
      fireEvent.click(closeButton);
    });
  });
});

describe('Home page order test', () => {
  beforeEach(() => {
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: mockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    window.mfe = { ...window.mfe, scmCheckoutMfeEnable: false };
    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    jest.spyOn(HttpService, 'post').mockImplementation(() => Promise.resolve({ mockId: 'ort440' }));
  });

  test('on click close icon', async () => {
    const closeButton = screen.getByTestId('close-btn-icon');
    screen.debug();
    expect(closeButton).toBeInTheDocument();
    fireEvent.click(closeButton);
    fireEvent.click(screen.getByRole('button', { name: 'Exit' }));
  });
  test('on click close icon', async () => {
    sessionStorage.setItem('qaCartid', '4987895490768908');
    const closeButton = screen.getByTestId('close-btn-icon');
    screen.debug();
    expect(closeButton).toBeInTheDocument();
    fireEvent.click(closeButton);
    fireEvent.click(screen.getByRole('button', { name: 'Exit' }));
  });

  test('on back icon', async () => {
    const backButton = screen.getByTestId('btn-back');
    screen.logTestingPlaygroundURL();
    expect(backButton).toBeInTheDocument();
    fireEvent.click(backButton);
  });

  test('Show notification if Disney Bundle plan selected', async () => {
    const viewOffersButton = await screen.getByTestId('notification');
    expect(screen.getByText('Added-Disney Bundle Perk Promo - 6 mo promo')).toBeInTheDocument();
    expect(viewOffersButton).toBeInTheDocument();
    fireEvent.click(screen.getByText('View offers'));
  });
});
describe('Home page order test scmenabled', () => {
  test('on back icon with scmenabled', async () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] };
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { isSuccess: true, data: mockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));

    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    const backButton = screen.getByTestId('btn-back');
    screen.logTestingPlaygroundURL();
    expect(backButton).toBeInTheDocument();
    fireEvent.click(backButton);
  });
  test('on back icon with scmenabled', async () => {
    window.mfe = { scmCheckoutMfeEnable: null, historyRef: [] };
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: mockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));

    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    const backButton = screen.getByTestId('btn-back');
    screen.logTestingPlaygroundURL();
    expect(backButton).toBeInTheDocument();
    fireEvent.click(backButton);
  });
  test('on back icon with scmenabled, scmUpgradeMfeEnabled', async () => {
    window.mfe = { scmCheckoutMfeEnable: true, scmUpgradeMfeEnable: true, scmVtButtonEnable: true, historyRef: [] };
    mockCartJson.data.cart.lineDetails.lineInfo[0].lineActivityType = 'EUP';
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { isSuccess: true, data: mockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    const backButton = screen.getByTestId('btn-back');
    screen.logTestingPlaygroundURL();
    expect(backButton).toBeInTheDocument();
    fireEvent.click(backButton);
  });
});
describe('order review with account details', () => {
  test('should render account details', async () => {
    sessionStorage.setItem('isViewTogether', false);
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: mockCartJson },
      FetchPricingSnapshotResult: pricedSnapshot,
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    const accountDetails = screen.queryByTestId('account-details');
    expect(accountDetails).toBeInTheDocument();
  });
  test('should not render account details', () => {
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: mockCartResult({ selectedALPShareList: null }),
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    const accountDetails = screen.queryByTestId('account-details');
    expect(accountDetails).not.toBeInTheDocument();
  });

  test('mock lineinfo details', () => {
    mockCartJson.data.cart.lineDetails.lineInfo[0].lineActivityType = 'EXC';
    mockCartJson.data.cart.lineDetails.lineInfo[0].itemsInfo.cartItems = {
      cartItem: [
        {
          cartItemType: 'DEVICE',
          depletionType: '',
        },
      ],
    };

    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: mockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('mock lineinfo details', async () => {
    window.sessionStorage.setItem('isViewTogether', false);
    mockCartJson.data.cart.lineDetails.lineInfo[0].lineActivityType = 'NSE_5G';
    mockCartJson.data.cart.lineDetails.lineInfo[0].itemsInfo[0].cartItems = {
      cartItem: [
        {
          cartItemType: 'DEVICE',
          depletionType: 'O',
        },
      ],
    };

    mockCartJson.data.cart.lineDetails.lineInfo[0].serviceInfo.cart5GAppointment = {
      installApptSelectedDate: {
        availableDate: '1/1/1978',
        slotStartTime: '12:00:00',
      },
    };

    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: mockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    await waitFor(() => {
      const viewTogetherButton = screen.getByTestId('view-together-footer');
      expect(viewTogetherButton).toBeInTheDocument();
      fireEvent.click(viewTogetherButton);
    });
  });

  test('mock lineinfo details 1', () => {
    mockCartJson.data.cart.lineDetails.tradeInDetail.tradeInItems = [
      {
        tradeInStatus: 'Complete',
        fmiLocked: 'false',
      },
      {
        tradeInStatus: 'Complete',
        fmiLocked: 'false',
      },
    ];
    mockCartJson.data.cart.lineDetails.lineInfo[0].itemsInfo[0].cartItems = {
      cartItem: [
        {
          cartItemType: 'DEVICE',
          depletionType: 'O',
        },
      ],
    };

    mockCartJson.data.cart.lineDetails.lineInfo[0].serviceInfo.cart5GAppointment = {
      installApptSelectedDate: {
        availableDate: '1/1/1978',
        slotStartTime: '12:00:00',
      },
    };

    const props = {
      showAffirmModal: true,
      handleShowViewTogether: jest.fn(),
      onChangeSubReason: jest.fn(),
      handleHideContinueShowViewTogether: jest.fn(),
    };

    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: mockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
      handleToggleChange: jest.fn(),
    }));
    window.mfe = { scmCheckoutMfeEnable: false };
    render(<OrderReview {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
});

// describe('Order review with paper less', () => {
//   beforeEach(() => {
//     sessionStorage.setItem('assistedFlags', JSON.stringify({ orderReview3PORewardTypes: 'FWASTARZ' }));
//     jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
//       CustomerProfileResult: { data: customerJson },
//       CartDetailsResult: { data: newCustRetriveCartJson },
//       FetchPricingSnapshotResult: {},
//       getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
//       getAccAddressValidationBody: jest.fn(),
//     }));
//     render(<OrderReview />, {
//       reducers: rootReducer,
//       sagas: rootSaga,
//     });
//     jest.spyOn(HttpService, 'post').mockImplementation(() => Promise.resolve({ mockId: 'ort660' }));
//   });

//   // test('On click of edit functionality ', () => {
//   //   const editBtn = screen.getByRole('button', { name: 'Edit' });
//   //   fireEvent.click(editBtn);
//   //   const email = 'VQNROOVI70@VZW.COM';
//   //   const emailValidationInput = screen.getByTestId('paperless-test');
//   //   fireEvent.change(emailValidationInput, { target: { value: email } });

//   //   const doneBtn = screen.getByRole('button', { name: 'Done' });
//   //   fireEvent.click(doneBtn);
//   // });

//   // test('On Click of checkbox functionlaity', () => {
//   //   const paperLessCheckbox = screen.getByText('Enroll in paper free billing');
//   //   fireEvent.click(paperLessCheckbox);
//   // });
// });

describe('Read Order View', () => {
  beforeEach(() => {
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: tradeinRetrieveCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    jest.spyOn(HttpService, 'post').mockImplementation(() => Promise.resolve({ mockId: 'ort684' }));
  });

  it('sets readOrder session flag', async () => {
    await render(<OrderReview readOrder isQAFlow />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    expect(sessionStorage.getItem('readOrder')).toEqual('true');
  });

  it('qaflow flag', async () => {
    await render(<OrderReview isQAFlow />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  it('qaflow query param', async () => {
    getQueryParamByName.mockReturnValue('isQAFlow');
    await render(<OrderReview isQAFlow />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  it('sets readOrder session flag', async () => {
    getQueryParamByName.mockReturnValue('close');
    await render(<OrderReview isQAFlow />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  it('sets readOrder session flag', async () => {
    jest.spyOn(HttpService, 'post').mockResolvedValue(() => {
      throw new Error('error');
    });
    await render(<OrderReview readOrder />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    expect(sessionStorage.getItem('readOrder')).toEqual('true');
  });

  it('shows the OrderSummaryLine when readOrder data is loded', async () => {
    jest.spyOn(HttpService, 'post').mockResolvedValue(() =>
      Promise.resolve({
        mockId: 'ort713',
        data: {
          cart: {
            orderDetails: {
              orderList: [[{ orderNumer: 1234, orderStatus: 'OM', cartHeaderStatus: 'P' }]],
            },
          },
        },
      }),
    );
    await render(<OrderReview readOrder />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    expect(sessionStorage.getItem('readOrder')).toEqual('true');
  });
  it('order details should be shown', async () => {
    useLazyGetReadOrderQuery.mockReturnValue([
      () => {},
      {
        data: {
          data: {
            cart: {
              orderDetails: {
                orderList: [
                  { orderNumer: 1234, orderStatus: 'OM', cartHeaderStatus: 'P' },
                  { orderNumer: 5678, orderStatus: 'OM', cartHeaderStatus: 'P' },
                ],
                locationCode: '123456',
                orderNumber: '1234567890',
              },
            },
          },
        },
        isUninitialized: true,
        status: 'rejected',
      },
    ]);
    await render(<OrderReview readOrder />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    screen.debug();
    expect(sessionStorage.getItem('readOrder')).toEqual('true');
  });
  it('order details should be shown1', async () => {
    useLazyGetReadOrderQuery.mockReturnValue([
      () => {},
      {
        data: {
          data: {
            cart: {
              orderDetails: {
                orderList: [
                  { orderNumer: 1234, orderStatus: 'OM', cartHeaderStatus: 'P' },
                  { orderNumer: 5678, orderStatus: 'OM', cartHeaderStatus: 'P' },
                ],
                locationCode: '123456',
                orderNumber: '1234567890',
              },
            },
          },
        },
        isUninitialized: true,
        status: 'fulfilled',
      },
    ]);
    await render(<OrderReview readOrder />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    screen.debug();
    expect(sessionStorage.getItem('readOrder')).toEqual('true');
  });
  it('sets readOrder session flag', async () => {
    await render(<OrderReview readOrder isQAFlow={false} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    expect(sessionStorage.getItem('readOrder')).toEqual('true');
  });
});

describe('Home page order test', () => {
  beforeEach(() => {
    getQueryParamByName.mockReturnValue('true');
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: mockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    render(<OrderReview isQAFlow />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    jest.spyOn(HttpService, 'post').mockImplementation(() => Promise.resolve({ mockId: 'ort440' }));
  });

  afterEach(() => {
    getQueryParamByName.mockReturnValue(false);
    sessionStorage.clear();
  });

  test('on click close icon', async () => {
    const closeButton = screen.getByTestId('close-btn-icon');
    screen.debug();
    expect(closeButton).toBeInTheDocument();
    fireEvent.click(closeButton);
  });
  test('on click close icon', async () => {
    // sessionStorage.setItem('qaCartid','4987895490768908')
    const closeButton = screen.getByTestId('close-btn-icon');
    screen.debug();
    expect(closeButton).toBeInTheDocument();
    fireEvent.click(closeButton);
    fireEvent.click(screen.getByRole('button', { name: 'Yes, exit' }));
  });
});

describe('Unified NBS Data Update Tests', () => {
  beforeEach(() => {
    mockDispatch.mockClear();
  });

  test('should dispatch updateUnifiedNbsData when FetchUnifiedNbsDataResult status is fulfilled', async () => {
    const mockUnifiedNbsData = {
      accountNumber: '123456789',
      billDetails: { amount: 100.5 },
      customerInfo: { name: 'John Doe' },
    };

    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: mockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      FetchUnifiedNbsDataResult: {
        status: 'fulfilled',
        data: {
          unifiedNbsData: mockUnifiedNbsData,
        },
      },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));

    render(<OrderReview isQAFlow={false} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    // Wait for any async operations to complete
    await waitFor(() => {
      // Debug: Check if dispatch was called at all
      console.log('mockDispatch.mock.calls:', mockDispatch.mock.calls);

      // Verify that dispatch was called with the correct action
      expect(mockDispatch).toHaveBeenCalledWith({
        type: 'UPDATE_UNIFIED_NBS_DATA',
        payload: mockUnifiedNbsData,
      });
    });
  });

  test('should not dispatch updateUnifiedNbsData when FetchUnifiedNbsDataResult status is not fulfilled', () => {
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: mockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      FetchUnifiedNbsDataResult: {
        status: 'pending',
        data: {
          unifiedNbsData: { someData: 'test' },
        },
      },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));

    render(<OrderReview isQAFlow={false} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    // Verify that dispatch was not called with updateUnifiedNbsData action
    expect(mockDispatch).not.toHaveBeenCalledWith(
      expect.objectContaining({
        type: 'UPDATE_UNIFIED_NBS_DATA',
      }),
    );
  });

  test('should not dispatch updateUnifiedNbsData when FetchUnifiedNbsDataResult is undefined', () => {
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: mockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      FetchUnifiedNbsDataResult: undefined,
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));

    render(<OrderReview isQAFlow={false} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    // Verify that dispatch was not called with updateUnifiedNbsData action
    expect(mockDispatch).not.toHaveBeenCalledWith(
      expect.objectContaining({
        type: 'UPDATE_UNIFIED_NBS_DATA',
      }),
    );
  });

  test('should handle FetchUnifiedNbsDataResult with error status', () => {
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: mockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      FetchUnifiedNbsDataResult: {
        status: 'rejected',
        error: { message: 'API Error' },
      },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));

    render(<OrderReview isQAFlow={false} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    // Verify that dispatch was not called with updateUnifiedNbsData action
    expect(mockDispatch).not.toHaveBeenCalledWith(
      expect.objectContaining({
        type: 'UPDATE_UNIFIED_NBS_DATA',
      }),
    );
  });
});

describe('Home page order test', () => {
  beforeEach(() => {
    getQueryParamByName.mockReturnValue('false');
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: mockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    render(<OrderReview isQAFlow={false} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    jest.spyOn(HttpService, 'post').mockImplementation(() => Promise.resolve({ mockId: 'ort440' }));
  });

  test('on click close icon', async () => {
    const closeButton = screen.getByTestId('close-btn-icon');
    screen.debug();
    expect(closeButton).toBeInTheDocument();
    fireEvent.click(closeButton);
  });
});
