import React from 'react';
import Emitter from 'onevzsoemfeframework/Emitter';
import { HttpService } from 'onevzsoemfeframework/HTTPService';
import { useGetOffersPdpMutation } from 'onevzsoemfecommon/AccountAPIService';
import {
  useLazyGetManagerApprovalQuery,
  useLazyGetFetchDownpaymentQuery,
  useLazyGetCustomerProfileQuery,
  useLazyGetVerifyEmailQuery,
} from 'onevzsoemfecommon/APIService';
import PropTypes from 'prop-types';
import { render, screen, fireEvent, waitFor } from '../../../utils/test-utils/renderHelper';
import OrderReview from './orderreview';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import appointmentMockCartJson from '../../../__mock__/retrieveCArt5GAppointment.json';
import { getSetupAndGoCart } from '../../../__mock__/setup-go-cart';
import customerJson from '../../../__mock__/retrieve-customer.json';
import CheckoutDetails from '../../../components/OrderReview/CheckoutDetails';
import * as orderreviewApiCallHook from './orderreviewApiCallHook';

jest.mock('../../../utils/tagging');
jest.mock('onevzsoemfecommon/LOVPageTracker', () => ({
  __esModule: true,
  default: ({ viewCreditModal }) => (
    <button type='button' data-testid='mocked-closeModal' onClick={viewCreditModal}>
      closeModal PreviewBill Mock
    </button>
  ),
}));
const useLazyGetManagerApprovalQueryRes = {
  data: {
    status: 'fulfilled',
    isUninitialized: false,
    isLoading: false,
    isSuccess: true,
    isError: false,
    isFetching: false,
    serviceBody: {
      serviceResponse: {
        context: {
          authenticateApproval: {
            approved: true,
          },
        },
      },
    },
  },
};
const useLazyGetManagerApprovalQueryRes2 = {
  data: {
    status: 'error',
    isUninitialized: false,
    isLoading: false,
    isSuccess: true,
    isError: false,
    isFetching: false,
    error: {
      data: {
        errors: [{ name: 'INVALID_USERNAME', message: 'Invalid Username or Password' }],
      },
    },
    serviceBody: {
      serviceResponse: {
        context: {
          authenticateApproval: {
            approved: false,
          },
        },
      },
    },
  },
};
const useLazyGetVerifyEmailQueryRes = {
  data: {
    statusDescription: 'Request has been successfully submitted.',
  },
  error: null,
};
jest.mock('onevzsoemfeframework/DomService', () => ({
  isIpad: () => true,
  isRetail: () => true,
  aesCipher: jest.fn((key, password) => `mocked_${password}_${key}`),
}));
jest.mock('../../../components/OrderReview/AccessoriesCheckoutDetails', () => ({
  __esModule: true,
  default: ({ handleHideContinueShowViewTogether }) => (
    <div>
      <button
        type='button'
        data-testid='handleHideContinueShowViewTogether'
        onClick={() => handleHideContinueShowViewTogether(true)}
      >
        handleHideContinueShowViewTogether
      </button>
    </div>
  ),
}));
jest.mock('../../../components/OrderReview/AffirmAccordion', () => ({
  __esModule: true,
  default: ({ setShowAffirmPaymentConfirmation }) => (
    <div>
      <button
        type='button'
        data-testid='setShowAffirmPaymentConfirmation'
        onClick={() => setShowAffirmPaymentConfirmation(true)}
      >
        setShowAffirmPaymentConfirmation
      </button>
    </div>
  ),
}));
jest.mock('../../../components/OrderReview/Footer', () => ({
  __esModule: true,
  default: ({
    setShowAffirmModal,
    setShowRepGuidedScreen,
    handleViewTogetherResumeClick,
    handleViewTogetherTextClick,
  }) => (
    <div>
      <button type='button' data-testid='setShowAffirmModal' onClick={() => setShowAffirmModal(true)}>
        setShowAffirmModal
      </button>
      <button type='button' data-testid='setShowRepGuidedScreen' onClick={() => setShowRepGuidedScreen(true)}>
        setShowRepGuidedScreen
      </button>
      <button type='button' data-testid='setShowRepGuidedScreenfalse' onClick={() => setShowRepGuidedScreen(false)}>
        setShowRepGuidedScreen
      </button>
      <button
        type='button'
        data-testid='handleViewTogetherResumeClick'
        onClick={() => handleViewTogetherResumeClick(true)}
      >
        handleViewTogetherResumeClick
      </button>
      <button type='button' data-testid='handleViewTogetherTextClick' onClick={() => handleViewTogetherTextClick(true)}>
        handleViewTogetherTextClick
      </button>
    </div>
  ),
}));
jest.mock('../../../components/OrderReview/UswinModal', () => ({
  __esModule: true,
  default: ({ handleSubmitUswin, uswinCloseModal, handleUswinChange }) => (
    <div>
      <button type='button' data-testid='handleSubmitUswin' onClick={handleSubmitUswin}>
        mocked uswin modal
      </button>
      <button type='button' data-testid='uswinCloseModal' onClick={uswinCloseModal}>
        mocked uswin modal
      </button>
      <button type='button' data-testid='handleUswinChange ' onClick={handleUswinChange}>
        mocked uswin modal
      </button>
      <button
        type='button'
        data-testid='handleUswinChangeValue '
        onClick={() => handleUswinChange({ target: { value: '123' } })}
      >
        mocked uswin modal
      </button>
    </div>
  ),
}));
const MockNotificationComponent = ({
  onCloseButtonClick,
  title,
  buttonData = [],
  setShowSendMessageError,
  ...props
}) => (
  <div {...props} data-testid='notification'>
    {title}
    {buttonData.map((i) => (
      <button type='button' onClick={i.onClick}>
        {i.children}
      </button>
    ))}
    <button type='button' data-testid='mocked-close-button' onClick={onCloseButtonClick}>
      close
    </button>
  </div>
);

MockNotificationComponent.propTypes = {
  onCloseButtonClick: PropTypes.func,
  title: PropTypes.string,
  buttonData: PropTypes.array,
  setShowSendMessageError: PropTypes.func, // Add the missing prop type
};
jest.mock('@vds/notifications', () => ({
  __esModule: true,
  Notification: (props) => <MockNotificationComponent {...props} />,
}));
jest.mock('onevzsoemfecommon/AccountAPIService', () => ({
  useGetOffersPdpMutation: jest.fn(),
}));
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    // Add this comment to disable the rule for the line below
    // eslint-disable-next-line global-require
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: (keys) =>
      keys.map(
        (key) =>
          ({
            isSecondaryUswinAuthEnabled: 'TRUE',
          })[[key]],
      ),
  }),
  { virtual: true },
);
jest.mock('onevzsoemfecommon/APIService', () => ({
  useLazyGetManagerApprovalQuery: jest.fn(),
  useLazyGetCustomerProfileQuery: jest.fn(),
  useLazyGetFetchDownpaymentQuery: jest.fn(),
  useLazyGetVerifyEmailQuery: jest.fn(),
}));
jest.mock('../../../modules/services/APIService/APIServiceCallHook', () => ({
  // Add this comment to disable the rule for the line below
  // eslint-disable-next-line global-require
  ...jest.requireActual('../../../modules/services/APIService/APIServiceCallHook'),
  useLazyGetCartDetailsQuery: () => [() => {}, {}],
  useGetOrderReviewQuery: () => ({
    status: 0,
    showAccessoriesSection: true,
    showNotificationSection: false,
    showPurchaseOrderSection: false,
    telesalesNegativeReasonList: false,
    retailNegativeReasonList: true,
    showGiftPurchase: true,
    showOnlineOffers: false,
    showTradeInSection: true,
    channelId: 'OMNI-RETAIL',
    mtnCount: 0,
    purchaseOrderNumRequired: false,
    ptechEnabledForRetailLoc: false,
  }),
  useLazyGetReadOrderQuery: () => [
    () => {},
    {
      data: {
        status: 'fulfilled',
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: false,
        isFetching: false,
      },
    },
  ],
}));
let getOffersMock;
let getOffersResultsMock;
beforeEach(() => {
  getOffersMock = jest.fn();
  getOffersResultsMock = {
    data: null,
    error: null,
    isLoading: false,
    isSuccess: false,
    isError: false,
  };
  useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), { data: customerJson }]);
  useGetOffersPdpMutation.mockReturnValue([getOffersMock, getOffersResultsMock]);
  jest.spyOn(HttpService, 'post').mockImplementation(() => Promise.resolve({ mockId: 'ort129' }));
  sessionStorage.setItem('channel', 'OMNI-RETAIL');
});

jest.mock('../../../components/OrderReview/AccessoriesCheckoutDetails', () => {
  // eslint-disable-next-line global-require
  const MockReact = require('react');
  // eslint-disable-next-line global-require
  const MockPropTypes = require('prop-types');

  const MockedComponent = (props) => {
    MockReact.useEffect(() => {
      if (props.setShowSendMessageError) {
        props.setShowSendMessageError(true);
      }
    }, []);

    return <div data-testid='mock-AccessoriesCheckoutDetails' />;
  };

  MockedComponent.propTypes = {
    setShowSendMessageError: MockPropTypes.func,
  };

  return MockedComponent;
});

describe('Home page order review', () => {
  afterAll(() => {
    const openDevice = jest.fn();
    openDevice.mockReturnValueOnce(true);
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: appointmentMockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
    }));
    render(
      <CheckoutDetails
        openDeviceInformation={() => openDevice(true)}
        cart={appointmentMockCartJson}
        customer={customerJson}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });
  beforeEach(() => {
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: getSetupAndGoCart() },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    Emitter.emit('TAGGING_COMPLETED', true);
    jest.spyOn(HttpService, 'post').mockImplementation(() => Promise.resolve({ mockId: 'ort228' }));
  });
  test('renders home page', async () => {
    window.sessionStorage.setItem('isLovEligibleFromSessionStorage', 'false');
    window.sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'TRUE' }));
    useLazyGetManagerApprovalQuery.mockReturnValue([jest.fn(), { ...useLazyGetManagerApprovalQueryRes }]);
    useLazyGetFetchDownpaymentQuery.mockReturnValue([jest.fn(), { ...useLazyGetManagerApprovalQueryRes }]);
    useLazyGetVerifyEmailQuery.mockReturnValue([jest.fn(), { ...useLazyGetVerifyEmailQueryRes }]);
    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    screen.debug();
    waitFor(() => {
      const handleHideContinueShowViewTogether = screen.getByTestId('handleHideContinueShowViewTogether');
      fireEvent.click(handleHideContinueShowViewTogether);
      const setShowAffirmModal = screen.getByTestId('setShowAffirmModal');
      fireEvent.click(setShowAffirmModal);
      const setShowAffirmPaymentConfirmation = screen.getByTestId('setShowAffirmPaymentConfirmation');
      fireEvent.click(setShowAffirmPaymentConfirmation);
      const setShowRepGuidedScreen = screen.getByTestId('setShowRepGuidedScreen');
      fireEvent.click(setShowRepGuidedScreen);
    });
  });
  test('renders home page', async () => {
    window.sessionStorage.setItem('isLovEligibleFromSessionStorage', 'false');
    window.sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'TRUE' }));
    useLazyGetManagerApprovalQuery.mockReturnValue([jest.fn(), { ...useLazyGetManagerApprovalQueryRes2 }]);
    useLazyGetFetchDownpaymentQuery.mockReturnValue([jest.fn(), { ...useLazyGetManagerApprovalQueryRes }]);
    useLazyGetVerifyEmailQuery.mockReturnValue([jest.fn(), { ...useLazyGetVerifyEmailQueryRes }]);
    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    screen.debug();
    waitFor(() => {
      const setShowAffirmModal = screen.getByTestId('setShowAffirmModalfalse');
      fireEvent.click(setShowAffirmModal);
      const setShowRepGuidedScreen = screen.getByTestId('setShowRepGuidedScreenfalse');
      fireEvent.click(setShowRepGuidedScreen);
    });
  });
  test('renders home page', async () => {
    window.sessionStorage.setItem('isLovEligibleFromSessionStorage', 'false');
    window.sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'TRUE' }));
    useLazyGetManagerApprovalQuery.mockReturnValue([jest.fn(), { ...useLazyGetManagerApprovalQueryRes2 }]);
    useLazyGetFetchDownpaymentQuery.mockReturnValue([jest.fn(), { ...useLazyGetManagerApprovalQueryRes }]);
    useLazyGetVerifyEmailQuery.mockReturnValue([jest.fn(), { ...useLazyGetVerifyEmailQueryRes }]);
    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    screen.debug();
    waitFor(() => {
      const handleViewTogetherResumeClick = screen.getByTestId('handleViewTogetherResumeClick');
      fireEvent.click(handleViewTogetherResumeClick);
      const handleViewTogetherTextClick = screen.getByTestId('handleViewTogetherTextClick');
      fireEvent.click(handleViewTogetherTextClick);
    });
  });
  test('renders home page with error notification', async () => {
    window.sessionStorage.setItem('isLovEligibleFromSessionStorage', 'false');
    window.sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'TRUE' }));
    useLazyGetManagerApprovalQuery.mockReturnValue([jest.fn(), { ...useLazyGetManagerApprovalQueryRes }]);
    useLazyGetFetchDownpaymentQuery.mockReturnValue([jest.fn(), { ...useLazyGetManagerApprovalQueryRes }]);
    useLazyGetVerifyEmailQuery.mockReturnValue([jest.fn(), { ...useLazyGetVerifyEmailQueryRes }]);
    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    screen.debug();
    const closeIcon = screen.getByTestId('mocked-close-button');
    fireEvent.click(closeIcon);
    waitFor(() => {
      const handleHideContinueShowViewTogether = screen.getByTestId('handleHideContinueShowViewTogether');
      fireEvent.click(handleHideContinueShowViewTogether);
      const setShowAffirmModal = screen.getByTestId('setShowAffirmModal');
      fireEvent.click(setShowAffirmModal);
      const setShowAffirmPaymentConfirmation = screen.getByTestId('setShowAffirmPaymentConfirmation');
      fireEvent.click(setShowAffirmPaymentConfirmation);
      const setShowRepGuidedScreen = screen.getByTestId('setShowRepGuidedScreen');
      fireEvent.click(setShowRepGuidedScreen);
    });
  });
});
describe('Page Height and Margin Logic', () => {
  const mockCustomerProfile = {
    data: {
      customer: {
        cartId: 'test-cart-id',
        billAccounts: [],
      },
    },
    status: 'fulfilled',
  };

  const setMfeFlag = (isNewCustomer) => {
    Object.defineProperty(window, 'mfe', {
      value: {
        isProspectNewCustomerTab: isNewCustomer,
        scmCheckoutMfeEnable: false,
      },
      writable: true,
    });
  };

  beforeEach(() => {
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: mockCustomerProfile,
      CartDetailsResult: { data: getSetupAndGoCart() }, // Use your existing cart mock
      FetchPricingSnapshotResult: { refetch: jest.fn(), data: { data: {} } },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
      FetchUnifiedNbsDataResult: { status: 'uninitialized' },
    }));

    useLazyGetManagerApprovalQuery.mockReturnValue([jest.fn(), { ...useLazyGetManagerApprovalQueryRes }]);
    useLazyGetFetchDownpaymentQuery.mockReturnValue([jest.fn(), { ...useLazyGetManagerApprovalQueryRes }]);
    useLazyGetVerifyEmailQuery.mockReturnValue([jest.fn(), { ...useLazyGetVerifyEmailQueryRes }]);
  });

  afterAll(() => {
    jest.restoreAllMocks();
  });

  test('should apply 7.5rem margin-top when showAffirmModal is TRUE and NOT new customer tab', async () => {
    setMfeFlag(false);

    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    const openAffirmBtn = screen.getByTestId('setShowAffirmModal');
    fireEvent.click(openAffirmBtn);

    await waitFor(() => {
      const header = screen.getByTestId('header');
      const pageHeightDiv = header.nextElementSibling;

      expect(pageHeightDiv).toHaveStyle('margin-top: 7.5rem');
    });
  });

  test('should apply 7rem margin-top (default) when showAffirmModal is FALSE', async () => {
    setMfeFlag(false);

    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });


    await waitFor(() => {
      const header = screen.getByTestId('header');
      const pageHeightDiv = header.nextElementSibling;

      expect(pageHeightDiv).toHaveStyle('margin-top: 7rem');
    });
  });

  test('should apply NO margin and specific ID when isProspectNewCustomerTab is TRUE', async () => {
    setMfeFlag(true);

    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    await waitFor(() => {
      const pageHeightContainer = document.getElementById('page-height-container');
      expect(pageHeightContainer).toBeInTheDocument();
      expect(pageHeightContainer).not.toHaveStyle('margin-top: 7rem');
      expect(pageHeightContainer).not.toHaveStyle('margin-top: 7.5rem');
    });
  });
});