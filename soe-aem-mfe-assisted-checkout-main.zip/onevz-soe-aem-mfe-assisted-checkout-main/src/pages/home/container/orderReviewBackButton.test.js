import React from 'react';
import { useNavigate } from 'react-router';
import { useGetOffersPdpMutation } from 'onevzsoemfecommon/AccountAPIService';
import { render, screen, fireEvent, waitFor } from '../../../utils/test-utils/renderHelper';
import OrderReview from './orderreview';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import * as orderreviewApiCallHook from './orderreviewApiCallHook';
import customerJson from '../../../__mock__/retrieve-customer.json';
import { getSetupAndGoCart } from '../../../__mock__/setup-go-cart';

jest.mock('../../../utils/tagging');

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: (keys) =>
      keys.map(
        (key) =>
          ({
            splitFulfilmentUIOrderReviewFFlag: 'TRUE',
          })[[key]],
      ),
  }),
  { virtual: true },
);
jest.mock('onevzsoemfecommon/LOVPageTracker', () => ({
  __esModule: true,
  default: ({ viewCreditModal }) => (
    <button type='button' data-testid='mocked-closeModal' onClick={viewCreditModal}>
      closeModal PreviewBill Mock
    </button>
  ),
}));

// Mock useNavigate from react-router
const mockNavigate = jest.fn();
jest.mock('react-router', () => ({
  ...jest.requireActual('react-router'),
  useNavigate: () => mockNavigate,
}));

jest.mock('../../../components/OrderReview/Affirm', () => ({
  __esModule: true,
  default: () => <div data-testid='view-together-footer'>mocked Affirm modal</div>,
}));
jest.mock('onevzsoemfecommon/AccountAPIService', () => ({
  useGetOffersPdpMutation: jest.fn(),
}));

let getOffersMock;
let getOffersResultsMock;

beforeEach(() => {
  getOffersMock = jest.fn();
  getOffersResultsMock = {
    data: null,
    error: null,
    isLoading: false,
    isSuccess: false,
    isError: false,
  };
  useGetOffersPdpMutation.mockReturnValue([getOffersMock, getOffersResultsMock]);
});

beforeEach(() => {
  sessionStorage.setItem('channel', 'OMNI-RETAIL');
});

describe('Footer Component Tests', () => {
  beforeEach(() => {
    getOffersMock = jest.fn();
    getOffersResultsMock = {
      data: null,
      error: null,
      isLoading: false,
      isSuccess: false,
      isError: false,
    };

    useGetOffersPdpMutation.mockReturnValue([getOffersMock, getOffersResultsMock]);
  });

  test('should call getOffers and handle response', async () => {
    // Update the mock response
    getOffersResultsMock = {
      data: { offers: ['Offer1', 'Offer2'] },
      error: null,
      isLoading: false,
      isSuccess: true,
      isError: false,
    };

    useGetOffersPdpMutation.mockReturnValue([getOffersMock, getOffersResultsMock]);

    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('should handle error response', async () => {
    // Update the mock response to simulate an error
    getOffersResultsMock = {
      data: null,
      error: { message: 'Error fetching offers' },
      isLoading: false,
      isSuccess: false,
      isError: true,
    };

    useGetOffersPdpMutation.mockReturnValue([getOffersMock, getOffersResultsMock]);

    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
});

describe('OrderReview', () => {
  beforeEach(() => {
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: getSetupAndGoCart() },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'TRUE' }));
  });

  it('calls navigate when onBackClick is invoked and clickViewTogether is false', () => {
    const navigate = useNavigate();
    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    screen.debug();
    // Simulate onBackClick when clickViewTogether is false
    fireEvent.click(screen.getByTestId('btn-back'));

    // Ensure navigate is called with correct route
    expect(navigate).toHaveBeenCalledWith('/sales/assisted/new/handoff.html');
  });

  it('toggles states correctly when onBackClick is invoked and clickViewTogether is true', async () => {
    window.sessionStorage.setItem('isLovEligibleFromSessionStorage', 'true');
    window.mfe = { scmCheckoutMfeEnable: true, scmVtButtonEnable: true, scmUpgradeMfeEnable: true };
    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    screen.debug();
    await waitFor(() => {
      fireEvent.click(screen.getByTestId('view-together-footer'));
      // Simulate onBackClick when clickViewTogether is true
      fireEvent.click(screen.getByTestId('btn-back'));
      fireEvent.click(screen.getByTestId('view-together-footer'));
    });
  });
});
