import { useNavigate } from 'react-router';
import React, { useState, useEffect, useMemo } from 'react';
import styled from 'styled-components';
import { Button } from '@vds/buttons';
import { Title } from '@vds/typography';
import { useDispatch } from 'react-redux';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import { isErtUser, isFunctionalityEnabled, isPactUser } from 'onevzsoemfecommon/Helpers/common_functions';
import Emitter from 'onevzsoemfeframework/Emitter';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { isRetail, isIpad, aesCipher, executeShellFunction } from 'onevzsoemfeframework/DomService';
import { ViewExitDialog } from 'onevzsoemfecommon/ViewExitDialog';

import {
  useLazyGetFetchDownpaymentQuery,
  useLazyGetManagerApprovalQuery,
  useLazyGetCustomerProfileQuery,
} from 'onevzsoemfecommon/APIService';
import { Notification } from '@vds/notifications';
// eslint-disable-next-line you-dont-need-lodash-underscore/every
import { isEmpty, every, has } from 'lodash';
import PropTypes from 'prop-types';
import CheckoutDetails from '../../../components/OrderReview/CheckoutDetails';
import Footer from '../../../components/OrderReview/Footer';
import Header from '../../../components/OrderReview/Header';
import PriceBreakDown from '../../../components/OrderReview/PriceBreakDown';
import orderreviewApiCallHook from './orderreviewApiCallHook';
import AccessoriesCheckoutDetails from '../../../components/OrderReview/AccessoriesCheckoutDetails';
import AccountDetails from '../../../components/OrderReview/AccountDetails';
import { formatAccountNumber, getDiscountedFeatures, getPlanDetail, getSharedFeatures } from '../../../utils/common';
import StandAloneTrade from '../../../components/OrderReview/StandAloneTrade';
import {
  useLazyGetCartDetailsQuery,
  useGetOrderReviewQuery,
  useLazyGetSplitFulfillmentOrderQuery,
  useLazyGetReadOrderQuery,
  useLazyDeleteCartQuery,
} from '../../../modules/services/APIService/APIServiceCallHook';
import AccessoryFinanceOption from '../../../components/OrderReview/AccessoryFinanceOption';
import AffirmAccodion from '../../../components/OrderReview/AffirmAccordion';
import AffirmPaymentConfirmationModal from '../../../components/OrderReview/AffirmPaymentConfirmationModal';
import { showShippingAddress, showShippingAddressQA } from '../../../utils/orderreviewUtil';
import { tradeInConstants } from '../../../appconfig';
import ReviewViewAccessories from '../../../components/OrderReview/ReviewViewAccessories/ReviewViewAccessories';
import SplitFulfillmentContainer from '../../../components/OrderReview/SplitFulfillmentContainer';
import UswinModal from '../../../components/OrderReview/UswinModal';
import FooterReadOrder from '../../../components/ReadOrder/FooterReadOrder';
import { PageViewTagging } from '../../../utils/tagging';
import GetNextBillSummaryHook from '../../../modules/services/APIService/GetNextBillSummary';
import { getClientAppName } from '../../../components/OrderReview/utility';
import { updateUnifiedNbsData } from '../../../components/OrderReview/store/actions';
import "./orderreview.css"

const getPageHeightMarginTop = ({ isProspectNewCustomerTab, showAffirmModal }) => {
  if (isProspectNewCustomerTab) return ''; 
  if (showAffirmModal) return '7.5rem';
  return '7rem';
};

const getPageHeightMarginBottom = ({ isProspectNewCustomerTab, isVisaOrAffirmSection }) => {
  if (isProspectNewCustomerTab) return '';
  if (isVisaOrAffirmSection) return '11rem';
  return '5.62rem';
};

const PageHeight = styled.div`
  height: calc(100% + 20rem);
  margin-top: ${getPageHeightMarginTop};
  margin-bottom: ${getPageHeightMarginBottom};
  border-bottom: 1px solid black;
`;

const NotificationWrapper = styled.div`
  position: fixed;
  top: 0;
  z-index: 1200;
  margin-left: 2rem;
  width: 58rem;
`;

const PreOrderContainer = styled.div`
  padding-top: 40px;
  width: 100%;
`;

const PreOrderMessage = styled.div`
  border: 1px solid black;
  text-align: center;
  font-size: 2.4rem;
`;

const FooterContainer = styled.div`
  max-width: 1100px;
  background-color: rgb(255, 255, 255);
  z-index: 1;
  bottom: 0px;
  position: fixed;
  width: 100%;
  display: flex;
  border-top: 1px solid #ccc;
  justify-content: center;
  left: 0;
  right: 0;
  margin: 0 auto;
`;

const FooterGrid = styled.div`
  display: flex;
  flex-grow: 1;
  height: 7rem;
  align-items: center;
  justify-content: center;
  gap: 0.3rem;
`;
const getContainerIds = (isNewCustomer) => {
  if (isNewCustomer) {
    return {
      reviewSectionId: "order-review-section",
      pageHeightId: "page-height-container"
    };
  }
  return {}; 
};

function OrderReview(props) {
  const isRfexFlow = sessionStorage.getItem('refundexchange') === 'true' || false;
  const isQAFlowParam = getQueryParamByName('isQAFlow') || false;
  const isQAFlow = isQAFlowParam || props.isQAFlow;
  if (props.readOrder === true) {
    console.log('OrderReview/readOrder/ flag seen');
    sessionStorage.setItem('readOrder', true);
  } else {
    sessionStorage.removeItem('readOrder');
  }
  const {
    CustomerProfileResult,
    CartDetailsResult,
    FetchPricingSnapshotResult,
    getAccAddressValidationBody,
    FetchUnifiedNbsDataResult,
  } = orderreviewApiCallHook(props.readOrder, isQAFlow);
  const dispatch = useDispatch();
  const [getCartDetailsDataBody, getCartDetailsResults] = useLazyGetCartDetailsQuery();
  const [getCustomerProfileBody, getCustomerProfileResult] = useLazyGetCustomerProfileQuery();
  const [updatedCartDeatilsResult, setUpdatedCartDeatilsResult] = useState([]);
  const [showAccordion, setShowAccordion] = useState(false);
  const [disableButton, setDisableButton] = useState(false);
  const [spanishSelected, setSpanishSelected] = useState(false);
  const [showSendMessageError, setShowSendMessageError] = useState(false);
  const [spanishBannerSelected, setSpanishBannerSelected] = useState(true);
  const [showCloseModal, setShowCloseModal] = useState(false);
  const [showViewTogether, setShowViewTogether] = useState(true);
  const [hideOrderDetails, setHideOrderDetails] = useState(false);
  const [updatedEmail, setUpdatedEmail] = useState(null);
  const [paperLessBilling, setPaperLessBilling] = useState(false);
  const [hideShippingDetails, setHideShippingDetails] = useState(false);
  const [isVisaOrAffirmSection, setIsVisaOrAffirmSection] = useState(false);
  const [showRepGuidedScreen, setShowRepGuidedScreen] = useState(false);
  const [hideContinue, setHideContinue] = useState(true);
  const [hideViewTogether, setHideViewTogether] = useState(true);
  const [openAccordian, setOpenAccordian] = useState(false);
  const [showAffirmModal, setShowAffirmModal] = useState(false);
  const [continueBtnDisabled, setContinueBtnDisabled] = useState(false);
  const [readOrderData, setReadOrderData] = useState(null);
  const [emailValue, setEmailValue] = useState('');
  const [pageViewFlag, setPageViewFlag] = useState(true);
  const [showAffirmPaymentConfirmation, setShowAffirmPaymentConfirmation] = useState(false);
  const [isAffirmLoanApproved, setIsAffirmLoanApproved] = useState(false);
  const [showAffirmAccordion, setShowAffirmAccordion] = useState(false);
  const [showManagerApprovalView, setShowManagerApprovalView] = useState(false);
  const [verizonVisaCardLinkSent, setVerizonVisaCardLinkSent] = useState(false);
  const [isAllSetDone, setIsAllSetDone] = useState(false);
  const [clickViewTogether, setClickViewTogether] = useState(false);
  const [customerMtns, setCustomerMtns] = useState([]);
  const [selectedReviewMode, setSelectedReviewMode] = useState('');
  const [selectedReason, setSelectedReason] = useState('');
  const [isLovEnabled, setIsLovEnabled] = useState(false);
  const [subReasonSelected, setSubReasonSelected] = useState('');
  const [selectedRadio, setSelectedRadio] = useState('Customer QR Code');
  const scmCheckoutMfeEnabled = window?.mfe?.scmCheckoutMfeEnable;
  const scmUpgradeMfeEnabled = window?.mfe?.scmUpgradeMfeEnable;
  const scmVtButtonEnabled = window?.mfe?.scmVtButtonEnable || false;
  const [isCustomEventTriggered, setIsCustomEventTriggered] = useState(false);
  const [viewdiscountOpen, setViewdiscountOpen] = useState(false);
  const [autoSelectRC, setAutoSelectRC] = useState(sessionStorage.getItem('isRCCart')?.toUpperCase() === 'TRUE');
  console.log(autoSelectRC, 'RetailCompanion_log_1');
  const [fetchDownPaymentBody, fetchDownPaymentResult] = useLazyGetFetchDownpaymentQuery();
  const [fetchReadOrder, rspFetchReadOrder] = useLazyGetReadOrderQuery();
  const { getNextBillSummaryReq, getNextBillSummaryRes } = GetNextBillSummaryHook();
  const [showPreOrderMessage, setShowPreOrderMessage] = useState(false);
  const [getManagerApprovalBody, getManagerApprovalResult] = useLazyGetManagerApprovalQuery();
  const appProperties = JSON.parse(sessionStorage.getItem('APP_PROPERTIES')) || {};
  const splitFulfilmentUIOrderReviewFFlag = appProperties?.splitFulfilmentUIOrderReviewFFlag === 'TRUE';
  const sroAppliedBannerFFlag = appProperties?.sroAppliedBannerFFlag === 'TRUE';
  const [sroBanners, setSroBanners] = useState([]);
  const [uswinSuccess, setUswinSuccess] = useState(false);
  const [uswinStatus, setUswinStatus] = useState({
    limit: 0,
    errStatus: false,
    disableContinueBtn: false,
    uPassword: '',
  });
  const [uswinModalEnable, setUswinModalEnable] = useState(false);
  const [receivedLovPollRessponse, setReceivedLovPollResponse] = useState('');
  const [exitLovData, setExitLovData] = useState('');
  const [
    isSecondaryUswinAuthEnabled,
    newPostToPreIndicator,
    retailCompanionForVTFFlag,
    retailCompanionForVTCheckoutMfeFFlag,
    isReadOrderFlag,
  ] = getAssistedCradlePropertyV2([
    'isSecondaryUswinAuthEnabled',
    'newPostToPreIndicator',
    'retailCompanionForVTFFlag',
    'retailCompanionForVTCheckoutMfeFFlag',
    'readOrderMfeFFlag',
  ]);
  const isReadOrderFlagEnabled = JSON.parse(sessionStorage.getItem('readOrder')) || isReadOrderFlag || false;
  const isQAClosedOrder = isQAFlow && getQueryParamByName('close');
  const isProspectNewCustomerTab = window?.mfe?.isProspectNewCustomerTab;
  const { reviewSectionId, pageHeightId } = getContainerIds(isProspectNewCustomerTab);
  const [isNewCustomer, setIsNewCustomer] = useState(false);
  let navigate = '';
  const OrderDetail = props.readOrder ? rspFetchReadOrder : CartDetailsResult;
  const isRetailCompanionEnabled =
    retailCompanionForVTFFlag === 'TRUE' && retailCompanionForVTCheckoutMfeFFlag === 'TRUE';
  function useNavigateMFE() {
    navigate = useNavigate();
  }
  try {
    useNavigateMFE();
  } catch (e) {
    console.log('UseNavigate Exception in orderReview.js', e);
  }

  const memoizedCondition = useMemo(
    () =>
      JSON.stringify({
        readOrder: props.readOrder,
        rspFetchReadOrderStatus: rspFetchReadOrder?.status,
        getCustomerProfileResultStatus: getCustomerProfileResult?.status,
      }),
    [props.readOrder, rspFetchReadOrder?.status, getCustomerProfileResult?.status],
  );

  useEffect(() => {
    if (window?.mfe?.isProspectNewCustomerTab) {
      setIsNewCustomer(true);
    }
  }, []);

  useEffect(() => {
    const condition =
      props.readOrder && rspFetchReadOrder?.status === 'fulfilled' && getCustomerProfileResult?.status === 'fulfilled';
    if (condition && pageViewFlag) {
      PageViewTagging('', '', 'EUP|read-order', 'read-order', rspFetchReadOrder, getCustomerProfileResult);
      setPageViewFlag(false);
    }
    if (autoSelectRC && isRetailCompanionEnabled) {
      onChangeRadio('Retail Companion');
    }
  }, [memoizedCondition]);

  // PageView event on initial load
  useEffect(() => {
    if (!isCustomEventTriggered && OrderDetail?.data && !props.readOrder) {
      const details = {
        PAGE_LOADED: 'true',
        CUSTOM_EVENT: 'Pageview',
      };
      Emitter.emit('PAGE_LOADED', details);
      setIsCustomEventTriggered(true);
    }
  }, [OrderDetail?.data]);

  useEffect(() => {
    if (OrderDetail?.data && (updatedCartDeatilsResult.length === 0 || isQAFlow)) {
      const isVisaOrAffirm =
        OrderDetail?.data?.data?.cart?.orderDetails?.affirmFinancingOfferInfo?.offerAvailable ||
        OrderDetail?.data?.data?.cart?.orderDetails?.accessoryFinancingOfferInfo?.customerEligible;
      setUpdatedCartDeatilsResult(OrderDetail);
      setIsVisaOrAffirmSection(isVisaOrAffirm);
      setIsAffirmLoanApproved(OrderDetail?.data?.data?.cart?.orderDetails?.affirmFinancingOfferInfo?.offerAccepted);
    }

    if (getCartDetailsResults?.data) {
      const isVisaOrAffirm =
        getCartDetailsResults?.data?.data?.cart?.orderDetails?.affirmFinancingOfferInfo?.offerAvailable ||
        getCartDetailsResults?.data?.data?.cart?.orderDetails?.accessoryFinancingOfferInfo?.customerEligible;
      setUpdatedCartDeatilsResult(OrderDetail);
      setIsVisaOrAffirmSection(isVisaOrAffirm);
      setIsAffirmLoanApproved(
        getCartDetailsResults?.data?.data?.cart?.orderDetails?.affirmFinancingOfferInfo?.offerAccepted,
      );
    }
    if (isQAFlow && getQueryParamByName('cartId')) {
      sessionStorage.setItem('cartId', getQueryParamByName('cartId'));
    }
    if (isQAFlow && getQueryParamByName('qaCartid')) {
      sessionStorage.setItem('qaCartid', getQueryParamByName('qaCartid'));
    }
  }, [OrderDetail?.data, getCartDetailsResults?.data]);

  // extracted from AccAddressValidationBody payload to make reusable
  const cartId =
    OrderDetail?.data?.data?.cart?.cartHeader?.cartId || CustomerProfileResult?.data?.data?.customer?.cartId;

  useEffect(() => {
    if (!props.readOrder && !isQAFlow) {
      fetchDownPaymentBody({ body: { header: {}, cartId: CustomerProfileResult?.data?.data?.customer?.cartId } });
    }
  }, [props.readOrder]);
  useEffect(() => {
    if (props.readOrder && isReadOrderFlagEnabled) {
      const CustomerProfileInfo =
        getCustomerProfileResult?.data?.data?.customer?.billAccounts?.[0]?.accountLevelChangeEligibility
          ?.pendingOrderDetail;
      if (CustomerProfileInfo && !isRfexFlow) {
        dispatch(
          appMessageActions.addAppMessage(
            'Account Level Plan change is restricted due to Pending Order. Add a line into Share Plan is restricted for this account.',
            'error',
            true,
            true,
          ),
        );
      }
    }
  }, [getCustomerProfileResult?.data?.data?.customer]);

  const getAffirmOrVisaSectionBool = () => (isVisaOrAffirmSection ? !isAffirmLoanApproved : false);
  const handleShowViewTogether = () => {
    setShowViewTogether(!showViewTogether);
    setShowAccordion(!showViewTogether);
    if (FetchPricingSnapshotResult?.data?.data?.flags?.isExpressCheckout) {
      setIsAllSetDone(true);
      setHideContinue(true);
    } else {
      setHideContinue(false);
    }
  };
  const handleHideContinueShowViewTogether = (value) => {
    setHideContinue(value);
  };

  const handleViewTogetherResumeClick = () => {
    const details = {
      PAGE_LOADED: 'true',
      CUSTOM_EVENT: 'Pageview',
    };
    Emitter.emit('PAGE_LOADED', details);
    setShowViewTogether(!showViewTogether);
    setShowAccordion(!showViewTogether);
    setIsAllSetDone(false);
    setHideOrderDetails(true);
    window.sessionStorage.setItem('isViewTogether', true);
  };

  const showOrhideViewTogetherChange = (hide) => {
    setHideViewTogether(hide);
  };

  const showOrhideContinueChange = (hide) => {
    setHideContinue(hide);
  };

  const handleViewTogetherTextClick = () => {
    setOpenAccordian(true);
  };

  const reqbody = {
    cartId, // extracted from payload & moved above to make reusable
  };

  const handleViewTogetherClick = () => {
    window?.lovEmulatorWindow?.close();
    if (isProfessionalInstall && profInstallappointmentFlag) {
      const slotStartTime =
        !!OrderDetail?.data?.data?.cart?.lineDetails?.lineInfo?.[0]?.serviceInfo?.cart5GAppointment
          ?.installApptSelectedDate?.slotStartTime;
      if (!slotStartTime) {
        setShowAppointmentSchedule(true);
        return 0;
      }
    }
    const isPostToPreExistingCustomer = /true/i.test(newPostToPreIndicator);
    const uswinAuthenticationRequired =
      updatedCartDeatilsResult?.data?.data?.cart?.orderDetails?.uswinAuthenticationRequired;
    const isMaverickLocation = updatedCartDeatilsResult?.data?.data?.cart?.cartHeader?.maverickLocation;
    if (
      isSecondaryUswinAuthEnabled === 'TRUE' &&
      !isPostToPreExistingCustomer &&
      isRetail() &&
      isIpad() &&
      !isMaverickLocation &&
      uswinAuthenticationRequired &&
      !uswinSuccess
    ) {
      setUswinModalEnable(true);
      return;
    }

    if (showViewTogether) {
      const details = {
        PAGE_LOADED: 'true',
        CUSTOM_EVENT: 'Pageview',
      };
      Emitter.emit('PAGE_LOADED', details);
      setShowAccordion(!showAccordion);
      setDisableButton(true);
      setHideOrderDetails(true);
      setClickViewTogether(true);
      window.sessionStorage.setItem('isViewTogether', true);
      if (scmCheckoutMfeEnabled) {
        const reqbodyACSS = {
          cartId: sessionStorage.getItem('acssMfeCartId'),
        };
        getAccAddressValidationBody({ body: reqbodyACSS });
      } else {
        getAccAddressValidationBody({ body: reqbody });
      }
    }
  };

  const handleSubmitUswin = () => {
    const customer = CustomerProfileResult?.data?.data?.customer;
    const uName = customer?.loggedInUser;
    const uPassword = uswinStatus?.uPassword;
    const cipheredPassword = aesCipher(process.env.REACT_APP_CIPHER_KEY, uPassword);
    const cartCreator = updatedCartDeatilsResult?.data?.data?.cart?.cartHeader?.cartCreator;
    const request = {
      cartId: customer?.cartId,
      psword: cipheredPassword,
      userId: uName,
      approvalType: 'USWINAUTHENTICATION',
      remarks: '',
      caseId: customer?.caseId,
      processingMtn: customer?.lookupMtn || '',
      accountNumber: customer?.accountNo || '',
      cartCreator,
    };
    getManagerApprovalBody({ body: request });
  };

  const uswinCloseModal = () => {
    setUswinSuccess(false);
    setUswinStatus({ limit: uswinStatus.limit, errStatus: false, disableContinueBtn: true });
    setUswinModalEnable(false);
  };

  const handleUswinChange = (e) => {
    const uName = CustomerProfileResult?.data?.data?.customer?.loggedInUser;
    const uPassword = e.target.value;
    if (uName !== '' && uPassword !== '') {
      setUswinStatus({
        limit: uswinStatus.limit,
        disableContinueBtn: false,
        uPassword,
      });
    } else {
      setUswinStatus({
        limit: uswinStatus.limit,
        disableContinueBtn: true,
        errStatus: false,
        uPassword,
      });
    }
  };
  useEffect(() => {
    const isApproved =
      getManagerApprovalResult?.data?.serviceBody?.serviceResponse?.context?.authenticateApproval?.approved;
    if (isApproved) {
      setUswinStatus({ limit: 0, errStatus: false, disableContinueBtn: false, uPassword: '' });
      setUswinModalEnable(false);
      setUswinSuccess(true);
    } else if (
      isApproved === false ||
      getManagerApprovalResult?.error?.data?.errors[0]?.name === 'INVALID_USERNAME' ||
      getManagerApprovalResult?.error?.data?.errors[0]?.message === 'Invalid Username or Password'
    ) {
      setUswinSuccess(false);
      const attempt = (uswinStatus?.limit ?? 0) + 1;
      setUswinStatus({ limit: attempt, errStatus: true, disableContinueBtn: true, uPassword: '' });
      if (attempt >= 5) {
        sessionStorage.setItem('uswinAuthFailed', 'true');
      }
    }
  }, [getManagerApprovalResult]);

  useEffect(() => {
    if (!uswinModalEnable && uswinSuccess) {
      handleViewTogetherClick();
    }
  }, [uswinSuccess]);
  let uswinStatusMessage;

  if (uswinStatus.limit <= 2 && uswinStatus.errStatus) {
    uswinStatusMessage = 'Invalid Username or Password';
  } else if (uswinStatus.limit > 2 && uswinStatus.limit < 5 && uswinStatus.errStatus) {
    uswinStatusMessage = 'Different user? Please log out and log in again.';
  } else if (uswinStatus.limit === 5 && uswinStatus.errStatus) {
    uswinStatusMessage = 'Max Failed Attempts. Please logout and reset your password';
  }
  const handleToggleChange = () => {
    setSpanishSelected(!spanishSelected);
  };
  const closeSpanishBanner = () => {
    setSpanishBannerSelected(false);
  };
  const closeSendMessageBanner = () => {
    setShowSendMessageError(false);
  };
  const onBackClick = () => {
    if (clickViewTogether) {
      setShowAccordion(!showAccordion);
      setDisableButton(false);
      setHideOrderDetails(false);
      setClickViewTogether(false);
      if (subReasonSelected) {
        setShowViewTogether(false);
      }
    } else if (!scmCheckoutMfeEnabled) {
      navigate(`/sales/assisted/new/handoff.html`);
    } else if (scmCheckoutMfeEnabled) {
      window?.mfe?.historyRef.push(`planConflicts.html`);
    }
  };
  const onChangeSubReason = (value) => {
    sessionStorage.setItem('isViewTogether', false);
    setSubReasonSelected(value);
  };

  const onChangeRadio = (value) => {
    setSelectedRadio(value);
  };

  const { getLovDetailsBody } = orderreviewApiCallHook(props.readOrder, isQAFlow);

  const request = {
    locationCode: OrderDetail?.data?.data?.cart?.orderDetails?.locationCode ?? '',
    jobCode: '',
    pageName: 'orderReview',
    enableViewTogetherOverride: 'N',
  };

  // watch mount/unmount
  useEffect(() => {
    const lovDetails = async () => {
      const response = await getLovDetailsBody({ body: request, spinner: true, mock: false });
      const lovEnabled = response?.data?.lovEnabled;
      setIsLovEnabled(lovEnabled);
      if (scmCheckoutMfeEnabled) {
        window.sessionStorage.setItem('isLovEligibleFromSessionStorage', 'true');
      }

      const isViewTogether = sessionStorage.getItem('isViewTogether');
      if (isViewTogether === 'true') {
        setShowAccordion(!showAccordion);
        setDisableButton(true);
        setOpenAccordian(false);
        setHideOrderDetails(false);
        setClickViewTogether(true);
      }
    };
    if (!isQAFlow) {
      lovDetails();
    } else {
      showOrhideContinueChange(false);
    }

    // Cleanup/destructor when exiting...
    return () => {
      // POSMFE-2484, make sure the readOrder flag is removed when leaving the view (unmount)
      sessionStorage.removeItem('readOrder');
    };
  }, []);

  useEffect(() => {
    if (spanishSelected) {
      setSpanishBannerSelected(spanishSelected);
    }
  }, [spanishSelected]);

  const showModal = () => {
    setShowCloseModal(!showCloseModal);
  };

  const goToInfoManager = (url) => {
    window.open(`https://infomanager.verizon.com/content/km/categories/promotions/${url}`);
  };
  /* istanbul ignore next */
  const getSroAppliedNotifications = (url) => {
    window.open(url);
  };
  const cartDetails = OrderDetail?.data;
  const [getUpdateSplitFulfillment] = useLazyGetSplitFulfillmentOrderQuery();
  const [deleteCart] = useLazyDeleteCartQuery();
  useEffect(() => {
    if (OrderDetail?.isSuccess && cartDetails?.data?.cart?.orderDetails?.itemLevelShipment) {
      getUpdateSplitFulfillment({ body: {}, spinner: false });
    }

    if (scmCheckoutMfeEnabled && cartDetails?.data?.cart?.lineDetails?.lineInfo) {
      const lineInfo = cartDetails?.data?.cart?.lineDetails?.lineInfo;
      /* istanbul ignore next */
      const cpcFeaOnlyCart = lineInfo?.length > 0 && lineInfo?.every(
        (item) => item.lineActivityType === 'CPC' || item.lineActivityType === 'FEA',
      );
      const eupAal5gInCart = lineInfo?.some(
        (item) =>
          item.lineActivityType === 'EUP' ||
          item.lineActivityType === 'AAL' ||
          item.lineActivityType === 'AAL_5G' ||
          item.lineActivityType === 'AAL_LTE' ||
          item.lineActivityType === 'NSE' ||
          item.lineActivityType === 'NSE_5G',
      );
      const skipVTForERTPact = isFunctionalityEnabled('scmCommonFixFFlag', 'skipVTForERT');

      const enableViewTogetherButton =
        (scmVtButtonEnabled && (cpcFeaOnlyCart || (scmUpgradeMfeEnabled && eupAal5gInCart))) || cpcFeaOnlyCart;
      /* istanbul ignore next */
      if (enableViewTogetherButton && !(skipVTForERTPact && (isErtUser() || isPactUser()))) {
        showOrhideViewTogetherChange(false);
      } else {
        showOrhideContinueChange(false);
      }
    }
  }, [cartDetails]);
  const closeButton = () => {
    const preOrderModalFFlag = JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.preOrderModalFFlag === 'TRUE';
    if (preOrderModalFFlag) {
      if (isIpad()) {
        const shellParams = {
          name: 'Home',
          path: '',
          replace: 'false',
          params: '',
        };
        const comboParams = {
          params: [
            { class: 'Shell', functionName: 'showScreen', params: shellParams },
            { class: 'Shell', functionName: 'killOrderScreen', params: {} },
            { class: 'Shell', functionName: 'stopTransactionTimeClock', params: {} },
          ],
        };
        executeShellFunction('Shell', 'executeShellFunctions', 'none', comboParams);
      } else {
        const homeUrl = `${window.location.protocol}//${window.location.host}/sales/landing-portal/home.html`;
        const message = {
          iframe: 'home',
          path: '',
          replace: true,
          url: homeUrl,
        };
        const target = window.parent;
        target.postMessage(message, window.parent.location.origin);
      }
    }
  };
  const preOrderDetails = OrderDetail?.data?.data?.cart?.preOrderDetails;
  const paymentDetails = OrderDetail?.data?.data?.paymentDetails ?? {};
  const lineInfo = OrderDetail?.data?.data?.cart?.lineDetails?.lineInfo;
  const orderReview3PORewardTypes =
    JSON.parse(sessionStorage.getItem('assistedFlags'))?.orderReview3PORewardTypes ?? '';
  const thirdPartyOffer =
    lineInfo
      ?.flatMap((item) => item?.serviceInfo?.thirdPartyOffer)
      ?.filter(
        (info) => info?.redemptionCode === '3PO' && orderReview3PORewardTypes.split(',').includes(info?.rewardType),
      ) || [];
  const lineActivityType = lineInfo?.[0]?.lineActivityType;
  const purchaseWithTradeIn = cartDetails?.lineDetails?.tradeInDetail?.tradeInItems?.length > 0;
  const ispuItem = lineInfo?.filter((line) => line.ispuItem).length > 0;
  const depletionType = lineInfo?.filter((line) => line.depletionType)?.[0]?.depletionType;
  const orderReviewbody = {
    depletionType,
    customerId: cartDetails?.data?.cart?.cartHeader?.fullAccountNumber,
    ispuItem,
    purchaseWithTradeIn,
  };
  const OrderReviewResult = useGetOrderReviewQuery(
    { body: orderReviewbody },
    { refetchOnMountOrArgChange: true },
    { skip: !OrderDetail.isSuccess },
  );
  const locationCode =
    OrderDetail?.data?.data?.cart?.orderDetails?.locationCode || getQueryParamByName('orderLocationCode') || '';
  const orderNumberAry = cartDetails?.data?.cart?.orderDetails?.orderList?.filter((order) => order.orderNumber);
  const orderNumber =
    orderNumberAry?.[0]?.orderNumber ||
    OrderDetail?.data?.data?.cart?.orderDetails?.orderNumber ||
    getQueryParamByName('orderNumber');
  const [nbsFFlagState] = getAssistedCradlePropertyV2(['enablePartialNbsPosFFlag']);
  const isPartialNbs =
    /true/i.test(nbsFFlagState) ||
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.enablePartialNbsPosFFlag === 'TRUE';
  const isServiceOnlyOrder = (lines) => {
    const hasOtherLines =
      lines?.length > 0 &&
      lines?.find(
        (line) =>
          (line?.lineActivityType !== 'CPC' && line?.lineActivityType !== 'FEA') ||
          ((line?.lineActivityType === 'FEA' || line.lineActivityType === 'CPC') &&
            has(line, 'itemsInfo[0].cartItems.cartItem') &&
            line?.itemsInfo?.[0]?.cartItems?.cartItem?.length > 0),
      );
    return !hasOtherLines;
  };

  const deleteCartApi = async () => {
    const qaCartId = sessionStorage.getItem('qaCartid') || getQueryParamByName('qaCartid');
    const soeRequest = {
      header: {
        clientAppName: getClientAppName(),
        clientAppUserName: sessionStorage.getItem('userId') || '',
        flow: 'QASALES',
        atgCartId: qaCartId,
        cartId: qaCartId,
      },
    };
    const apiResponse = await deleteCart({ body: soeRequest, spinner: false, mock: false });
    return apiResponse;
  };

  useEffect(() => {
    // don't call the API unless not already called & the data is available

    if (props.readOrder && rspFetchReadOrder.isUninitialized && orderNumber && locationCode) {
      const bodyReadOrder = {
        meta: { client: 'VZW-NETACE' },
        data: { orderNumber, locationCode },
      };
      fetchReadOrder({ body: bodyReadOrder, mock: false });
    }
  }, [orderNumber, locationCode, rspFetchReadOrder.isUninitialized]);

  useEffect(() => {
    // if(rspFetchReadOrder.fulfilledTimeStamp && rspFetchReadOrder?.data){
    if (rspFetchReadOrder?.data && rspFetchReadOrder?.status === 'fulfilled') {
      console.log('rspFetchReadOrder/useEffect/fulfilled/', rspFetchReadOrder);
      setReadOrderData(rspFetchReadOrder.data.data);
      if (isIpad()) {
        sessionStorage.setItem('channel', localStorage.getItem('channel'));
      }
      const getPOBOStatus = (lineDetail) => {
        const deviceItem = [];
        lineDetail?.lineInfo?.forEach((line) => {
          if (has(line, 'itemsInfo')) {
            line.itemsInfo.forEach((item) => {
              if (has(item, 'cartItems.cartItem')) {
                item.cartItems.cartItem.forEach((el) => deviceItem.push(el));
              }
            });
          }
        });
        const devices = deviceItem.filter((item) => item.cartItemType === 'DEVICE');
        return (
          devices &&
          devices.length > 0 &&
          devices.every((val) => (val.inventory?.isPreOrder || val.inventory?.isBackorder) && val.depletionType !== 'L')
        );
      };

      let preOrderStatus = has(preOrderDetails?.[0], 'ordStatus') ? preOrderDetails[0].ordStatus.split('-')[0] : '';

      if (!preOrderStatus) {
        preOrderStatus = has(preOrderDetails, 'ordStatus') ? preOrderDetails.ordStatus.split('-')[0] : '';
      }

      const calculatedPreOrderShipment =
        ((preOrderStatus === 'C' || preOrderStatus === 'X' || !preOrderStatus) &&
          getPOBOStatus(OrderDetail?.data?.data?.cart?.lineDetails) &&
          !isEmpty(paymentDetails)) ||
        false;

      if (calculatedPreOrderShipment === true) {
        setShowPreOrderMessage(true);
      }
      const deviceInfo = [];
      if (lineInfo?.length > 0) {
        lineInfo
          .filter(
            (line) =>
              line?.itemsInfo?.length > 0 && line?.lineActivityType === 'EUP' && !line?.itemsInfo?.installmentInfo,
          )
          .flatMap((line) => line?.itemsInfo)
          .flatMap((itemInfo) => itemInfo?.cartItems?.cartItem || [])
          .filter((innerItemInfo) => innerItemInfo?.cartItemType === 'DEVICE')
          .forEach((deviceData) => deviceInfo.push(deviceData));
      }

      const isStandAloneUpgradeDevice = !!(deviceInfo && deviceInfo.length > 0 && deviceInfo[0]);

      const deviceDataFromCart = [];
      if (lineInfo?.length > 0) {
        lineInfo
          .filter(
            (line) =>
              line.itemsInfo?.length > 0 &&
              line.lineActivityType === 'EUP' &&
              line.selectedFeaturesList?.visFeature?.length > 0,
          )
          .flatMap((line) => line.selectedFeaturesList.visFeature)
          .filter(
            (visFeature) =>
              visFeature?.addDeleteInd === 'A' && visFeature?.source === 'USER' && visFeature?.featurePrice > 0,
          )
          .forEach((deviceData) => deviceDataFromCart.push(deviceData));
      }

      const isFeatureChange = !!(deviceDataFromCart && deviceDataFromCart.length > 0 && deviceDataFromCart[0]);
      const checkAllFEAProductLines = lineInfo?.every(
        (line) => line.lineActivityType && line.lineActivityType.includes('FEA'),
      );

      const zeroChargeFeatureOnly =
        lineInfo?.flatMap((line) =>
          line.selectedFeaturesList?.visFeature?.filter(
            (feature) => (feature.addDeleteInd === 'A' || feature.addDeleteInd === 'D') && feature.featurePrice > 0,
          ),
        ).length === 0;

      const fullAccountNumber = rspFetchReadOrder?.data?.data?.cart?.cartHeader?.fullAccountNumber || '';
      const accountNumber = formatAccountNumber(fullAccountNumber);
      const nbsRequest = {
        locationCode: rspFetchReadOrder?.data?.data?.cart?.orderDetails?.locationCode || '',
        onDemand: false,
        accountNumber,
        emailSuppressInd: 'N',
        serviceOnly: false,
        count: 0,
        vzwRole: '',
        cartCreatorMtn: rspFetchReadOrder?.data?.data?.cart?.cartHeader?.cartCreator || '',
        isStandaloneUpgradeDevice: isStandAloneUpgradeDevice && isFeatureChange,
        zeroChargeFeatureOnly: checkAllFEAProductLines && zeroChargeFeatureOnly,
        unifiedNbsFlag: isPartialNbs,
      };

      if (rspFetchReadOrder?.data?.data?.orderStatus === 'CO') {
        nbsRequest.onDemand = true;
      }

      const isCPCorFEAonlyOrder = isServiceOnlyOrder(rspFetchReadOrder?.data?.data?.cart?.lineDetails?.lineInfo);
      if (isCPCorFEAonlyOrder) {
        nbsRequest.serviceOnly = true;
      }
      // Make the API call to nextBillSummary
      if (!isQAFlow) {
        getNextBillSummaryReq({
          body: nbsRequest,
          spinner: false,
        });
      }
    }
  }, [rspFetchReadOrder?.data]);

  const lineDeviceAndSimIds = rspFetchReadOrder?.data?.data?.lineDeviceAndSimIds;
  const activationStatus = rspFetchReadOrder?.data?.data?.activationDtls;
  const orderStatus = rspFetchReadOrder?.data?.data?.orderStatus;
  const cartHeader = rspFetchReadOrder?.data?.data?.cart.cartHeader;
  useEffect(() => {
    if (rspFetchReadOrder?.status === 'rejected') {
      dispatch(
        appMessageActions.addAppMessage(
          'Looks like "View Order" is not available, please use "Show Preview" option on the Home tab',
          'error',
          true,
          true,
        ),
      );
    }
  }, [rspFetchReadOrder?.status]);

  useEffect(() => {
    if (sroAppliedBannerFFlag) {
      const banners = [];
      updatedCartDeatilsResult?.data?.data?.cart?.lineDetails?.lineInfo?.forEach((lineSroDetails) => {
        lineSroDetails?.serviceInfo?.otherPromotions?.forEach((promotions) => {
          promotions?.promos
            ?.filter(
              (promo) =>
                promo?.discountActionCd === 'ADD' &&
                line?.serviceInfo?.sbdOffer?.find(
                  (offer) => offer?.offerId === promo?.id && offer.offerTypeCd === 'SO',
                ),
            )
            ?.forEach((promo) => {
              const bannerMsg = `Added - ${promo?.description} - ${(promo?.noOfDays ?? 0) / 30} mo promo`;
              const url = `https://infomanager.verizon.com/content/km/search-results.query=${promo?.id}.html`;
              banners.push({ bannerMsg, url });
            });
        });
      });
      setSroBanners(banners);
    }
  }, [sroAppliedBannerFFlag, updatedCartDeatilsResult]);

  useEffect(() => {
    if (props.readOrder && isReadOrderFlagEnabled) {
      const payload = { enableAssistedTagging: true };
      getCustomerProfileBody({ body: payload });
    }
  }, [props.readOrder, isReadOrderFlagEnabled]);

  const itemLevelShipment = cartDetails?.data?.cart?.orderDetails?.itemLevelShipment;
  const line = OrderDetail?.data?.data?.cart?.lineDetails?.lineInfo?.[0];
  const feature = FetchPricingSnapshotResult?.data?.data?.subAccounts?.[0];
  const hasSubAccount = cartDetails?.data?.cart?.orderDetails?.subAccountInfo?.length > 0;
  const planDetail = getPlanDetail(line);
  const { isAccount, planInfo } = planDetail || {};
  const sharedFeatures = getSharedFeatures(lineInfo, feature?.subAccountId);
  const discountedFeatures = getDiscountedFeatures(feature);
  const flowTypeExtender = updatedCartDeatilsResult?.data?.data?.cart?.orderDetails?.flowType === '5G_EXCHANGE_EXT';
  const isStandAloneTradeIn = !!(
    updatedCartDeatilsResult?.data?.data?.cart?.lineDetails?.lineInfo?.length === 0 &&
    updatedCartDeatilsResult?.data?.data?.cart?.lineDetails?.tradeInDetail?.tradeInItems?.length >= 1
  );
  const disneyPromo =
    updatedCartDeatilsResult?.data?.data?.cart?.lineDetails?.lineInfo?.filter((lineInfoDetails) =>
      lineInfoDetails?.serviceInfo?.otherPromotions?.some((promotions) =>
        promotions?.promos?.some((promo) => promo?.id === '20804' && promo?.discountActionCd === 'ADD'),
      ),
    ) || false;

  const appointmentLine = updatedCartDeatilsResult?.data?.data?.cart?.lineDetails?.lineInfo?.find(
    (lineObj) => lineObj.lineActivityType === 'AAL_5G' || lineObj.lineActivityType === 'NSE_5G',
  );
  const isProfessionalInstall = appointmentLine?.itemsInfo?.[0]?.cartItems?.cartItem?.[0]?.depletionType === 'O';
  const {
    availableDate = null,
    slotStartTime = null,
    slotLength = 0,
  } = appointmentLine?.serviceInfo?.cart5GAppointment?.installApptSelectedDate || {};

  const [showAppointmentSchedule, setShowAppointmentSchedule] = useState(false);
  const [profInstallappointmentFlag, setProfInstallappointmentFlag] = useState(
    isProfessionalInstall && !(availableDate && slotStartTime && slotLength),
  );

  let showShippingSection = false;

  lineInfo?.forEach((lineDetails) => {
    if (lineDetails?.lineActivityType === 'EXC') {
      lineDetails?.itemsInfo?.forEach((itemInfo) => {
        itemInfo?.cartItems?.cartItem?.forEach((item) => {
          if (['ACCESSORY', 'DEVICE'].includes(item?.cartItemType) && item?.depletionType !== 'L') {
            showShippingSection = true;
          }
        });
      });
    }
  });
  if (!showShippingSection) {
    showShippingSection = showShippingAddress(lineInfo);
  }
  if (isQAFlow) {
    showShippingSection = showShippingAddressQA(lineInfo);
  }
  const showAccessories =
    (!isEmpty(lineInfo) && every(lineInfo, { lineActivityType: 'ACC' })) ||
    (every(lineInfo, { lineActivityType: 'EXC' }) && flowTypeExtender);

  // Capturing prevTotalShippingCost to render Tax details
  const prevTotalShippingCost = updatedCartDeatilsResult?.data?.data?.cart?.orderDetails?.totalShippingCost;
  sessionStorage.setItem('prevTotalShippingCost', prevTotalShippingCost);

  let tradeInMessageFlag = false;
  const tradeInDetail = updatedCartDeatilsResult?.data?.data?.cart?.lineDetails?.tradeInDetail;
  if (tradeInDetail?.tradeInItems && tradeInDetail?.tradeInType === 'Home') {
    let purchaseDeviceCount = 0;
    lineInfo.map((item) => {
      if (
        item.lineActivityType === 'AAL' ||
        item.lineActivityType === 'AAL_LTE' ||
        item.lineActivityType === 'EUP' ||
        item.lineActivityType === 'NSE' ||
        item.lineActivityType === 'NSE_LTE' ||
        item.lineActivityType === 'NSE_5G' ||
        item.lineActivityType === 'AAL_5G' ||
        item.lineActivityType === 'EUPBYOD' ||
        item.lineActivityType === 'BYOD' ||
        item.lineActivityType === 'NESBYOD'
      ) {
        purchaseDeviceCount += 1;
      }
      return;
    });

    if (tradeInDetail.tradeInItems.length > purchaseDeviceCount) {
      tradeInMessageFlag = true;
    }
  }

  useEffect(() => {
    if (FetchUnifiedNbsDataResult?.status === 'fulfilled') {
      dispatch(updateUnifiedNbsData(FetchUnifiedNbsDataResult?.data?.unifiedNbsData));
    }
  }, [FetchUnifiedNbsDataResult?.status]);
  /* istanbul ignore next */
  const ViewTogetherProps = {
    handleToggleChange,
    showAccordion,
    spanishSelected,
    customerProfile:CustomerProfileResult?.data,
    handleShowViewTogether,
    onAccordianToggle:() => setHideOrderDetails(false),
    setShowSendMessageError,
    setSelectedReviewMode,
    setSelectedReason,
    subReasonSelected,
    onChangeSubReason,
    selectedRadio,
    autoSelectRC,
    onChangeRadio,
    handleHideContinueShowViewTogether,
    orderReviewResponse:OrderReviewResult,
    fetchPriceSnapshot:FetchPricingSnapshotResult?.data?.data,
    setReceivedLovPollResponse,
    exitLovData,
    data:cartDetails
  }

  const valReadOrderNumber =
    readOrderData?.cart?.orderDetails?.orderList &&
    readOrderData?.cart?.orderDetails?.orderList?.length >= 1 &&
    readOrderData?.cart?.orderDetails?.orderList
      ?.map((orderNumb) => orderNumb.orderNumber)
      ?.filter((orderNumb) => orderNumb !== 0)
      ?.join('/');
  const hmeSrchOrderProps = props.readOrder
    ? {
        orderConfirmation: true,
        orderNumber: valReadOrderNumber,
        cartId: OrderDetail?.data?.data?.cart?.cartHeader?.cartId ?? '',
      }
    : {};
  // eslint-disable-next-line no-nested-ternary
  return showPreOrderMessage && isReadOrderFlag && props.readOrder ? (
    <PreOrderContainer data-testid='preOrder component'>
      <PreOrderMessage data-testid='preOrderText'>
        <Title bold size='medium'>
          This Iconic Pre-Order has not been sent for Shipment yet
        </Title>
      </PreOrderMessage>
      <FooterContainer>
        <FooterGrid>
          <Button onClick={closeButton} className='btnPaddingOverride' data-testid='closeButton'>
            Close
          </Button>
        </FooterGrid>
      </FooterContainer>
    </PreOrderContainer>
  ) : showCloseModal ? (
    <ViewExitDialog
      showCloseModal={showCloseModal}
      setShowCloseModal={setShowCloseModal}
      enableLead
      processStep='ShoppingCart'
      isQAFlow={isQAFlow}
      deleteCartApi={deleteCartApi}
      {...hmeSrchOrderProps}
      isNewCustomer={isNewCustomer}
      readOrderStatus={rspFetchReadOrder?.data?.data?.orderStatus}
    />
  ) : (
    <div id={reviewSectionId}>
      <NotificationWrapper>
        {tradeInMessageFlag && (
          <Notification
            id='tradeinAlert'
            fullBleed
            type='error'
            title={tradeInConstants.errorMessage}
            layout='vertical'
          />
        )}
        {profInstallappointmentFlag && showAppointmentSchedule && (
          <Notification
            id='contentAlert'
            fullBleed
            type='error'
            title='Please schedule installation appointment to continue'
            layout='vertical'
            onCloseButtonClick={() => setShowAppointmentSchedule(false)}
          />
        )}
        {thirdPartyOffer.length >= 1
          ? thirdPartyOffer.map(
              (val) =>
                val?.marketingDescription && (
                  <Notification
                    id='contentAlert'
                    fullBleed
                    type='info'
                    title={val?.marketingDescription}
                    layout='vertical'
                  />
                ),
            )
          : ''}
        {spanishSelected && spanishBannerSelected && (
          <Notification
            id='contentAlert'
            fullBleed
            type='error'
            title='Advise customer certain agreements in the Terms and Conditions page are only available in English.'
            layout='vertical'
            onCloseButtonClick={closeSpanishBanner}
          />
        )}
        {showSendMessageError && (
          <Notification
            id='contentAlert'
            fullBleed
            type='error'
            title='Error in sending message, Please retry '
            layout='vertical'
            onCloseButtonClick={closeSendMessageBanner}
          />
        )}
        {disneyPromo && disneyPromo.length > 0 && (
          <Notification
            type='info'
            title='Added-Disney Bundle Perk Promo - 6 mo promo'
            surface='light'
            disableAnimation
            fullBleed
            disableFocus
            inline={false}
            buttonData={[
              {
                children: 'View offers',
                onClick: () => goToInfoManager('369665.html'),
              },
            ]}
          />
        )}
        {sroAppliedBannerFFlag &&
          Array.isArray(sroBanners) &&
          sroBanners.map((banner) => (
            <Notification
              key={banner?.bannerMsg}
              type='info'
              title={banner?.bannerMsg}
              surface='light'
              disableAnimation
              fullBleed
              disableFocus
              inline={false}
              buttonData={[
                {
                  children: 'View offers',
                  onClick: () => getSroAppliedNotifications(banner?.url),
                },
              ]}
            />
          ))}
      </NotificationWrapper>
      <Header
        readOrder={props.readOrder}
        data={cartDetails}
        data-testid='header'
        onBackClick={onBackClick}
        showModal={showModal}
        readOrderData={readOrderData}
        receivedLovPollRessponse={receivedLovPollRessponse}
        setExitLovData={setExitLovData}
        isQAFlow={isQAFlow}
        nextBillSummaryData={getNextBillSummaryRes?.data}
        setIsNewCustomer={setIsNewCustomer}
      />
      <PageHeight isVisaOrAffirmSection={getAffirmOrVisaSectionBool()} isProspectNewCustomerTab={window?.mfe?.isProspectNewCustomerTab} showAffirmModal={showAffirmModal} id={pageHeightId}>
        {showAffirmModal && (
          <AffirmAccodion
            showAffirmModal={showAffirmModal}
            customerMtns={customerMtns}
            emailValue={emailValue}
            cartDetails={cartDetails}
            setShowAffirmAccordion={setShowAffirmAccordion}
            setShowAffirmPaymentConfirmation={setShowAffirmPaymentConfirmation}
          />
        )}
        {showAffirmPaymentConfirmation && (
          <AffirmPaymentConfirmationModal
            cartDetails={updatedCartDeatilsResult?.data?.data?.cart}
            getCartDetailsDataBody={getCartDetailsDataBody}
            setShowAffirmModal={setShowAffirmModal}
            setShowAffirmPaymentConfirmation={setShowAffirmPaymentConfirmation}
            setContinueBtnDisabled={setContinueBtnDisabled}
            setShowAffirmAccordion={setShowAffirmAccordion}
          />
        )}
    
        {!isQAFlow && (scmCheckoutMfeEnabled || showAccessories || showViewTogether) && (
          <AccessoriesCheckoutDetails
          {...ViewTogetherProps}
            setViewdiscountOpen={setViewdiscountOpen}
            lines={lineInfo} // passing lineInfo for devicePaymentModal
            data-testid='accessories-checkout-details'
            openAccordian={openAccordian}
            customerInfo={CustomerProfileResult?.data?.data?.customer}
            showAccessories={false}
            setSetupAndGoVisiblity={setHideShippingDetails}
            showRepGuidedScreen={showRepGuidedScreen}
            showAffirmAccordion={showAffirmAccordion}
            setAutoSelectRC={setAutoSelectRC}
            readOrderResponse={readOrderData}
            getCartDetailsResults={OrderDetail}
            setProfInstallappointmentFlag={setProfInstallappointmentFlag}
            locationCode={locationCode}
            fetchUnifiedNbsData={FetchUnifiedNbsDataResult?.data?.unifiedNbsData}
            hideViewTogether={hideViewTogether}
            readOrderFlag={props.readOrder}
          />
        )}
        {showRepGuidedScreen ? (
          <AccessoryFinanceOption
            showRepGuidedScreen={showRepGuidedScreen}
            setShowRepGuidedScreen={setShowRepGuidedScreen}
            setCustomerMtns={setCustomerMtns}
            customerMtns={customerMtns}
            getCartDetailsDataBody={getCartDetailsDataBody}
            cartDetailsResult={updatedCartDeatilsResult?.data}
            setVerizonVisaCardLinkSent={setVerizonVisaCardLinkSent}
          />
        ) : (
          !hideOrderDetails &&
          !showAffirmAccordion && (
            <>
              {!showAccessories &&
                ((isAccount && planInfo && !isEmpty(planInfo)) ||
                  (sharedFeatures && sharedFeatures.length > 0) ||
                  (discountedFeatures && discountedFeatures.length > 0)) &&
                !hasSubAccount && (
                  <AccountDetails
                    data={cartDetails}
                    mtn={CustomerProfileResult?.data?.data?.customer?.lookupMtn}
                    sharedFeatures={sharedFeatures}
                    discountedFeatures={discountedFeatures}
                    fetchPriceSnapshot={FetchPricingSnapshotResult?.data?.data}
                    subAccountId={feature?.subAccountId}
                    readOrder={props.readOrder}
                  />
                )}
              {!isQAFlow && (
                <CheckoutDetails
                  cart={cartDetails?.data?.cart}
                  customer={CustomerProfileResult?.data?.data?.customer}
                  fetchPriceSnapshot={FetchPricingSnapshotResult}
                  setHideShippingDetails={setHideShippingDetails}
                  CustomerProfileRefetch={CustomerProfileResult.refetch}
                  CartDetailsRefetch={props.readOrder ? fetchReadOrder : OrderDetail.refetch}
                  fetchPriceSnapshotRefetch={FetchPricingSnapshotResult.refetch}
                  fetchDownPaymentResult={fetchDownPaymentResult}
                  setProfInstallappointmentFlag={setProfInstallappointmentFlag}
                  readOrder={props.readOrder}
                  lineDeviceAndSimIds={lineDeviceAndSimIds}
                  activationStatus={activationStatus}
                  orderStatus={orderStatus}
                  cartHeader={cartHeader}
                  readOrderData={readOrderData}
                  hasSubAccount={hasSubAccount}
                  rspFetchReadOrder={rspFetchReadOrder}
                />
              )}
              <ReviewViewAccessories
                cartData={cartDetails}
                isQAFlow={isQAFlow}
                showModal={showModal}
                setIsNewCustomer={setIsNewCustomer}
                refetchCartDetails={props.readOrder ? fetchReadOrder : OrderDetail.refetch}
              />
              {splitFulfilmentUIOrderReviewFFlag && /true/i.test(itemLevelShipment) && (
                <SplitFulfillmentContainer cart={cartDetails?.data?.cart} />
              )}
              <PriceBreakDown
                data={cartDetails}
                customerProfile={CustomerProfileResult?.data}
                fetchPriceSnapshot={FetchPricingSnapshotResult?.data?.data}
                setPaperLessBilling={(checked) => setPaperLessBilling(checked)}
                setUpdatedEmail={(email) => setUpdatedEmail(email)}
                data-testid='price-breakdown'
                hideShippingDetails={hideShippingDetails || !showShippingSection}
                selectedReviewMode={selectedReviewMode}
                selectedReason={selectedReason}
                isLovEnabled={isLovEnabled}
                fetchUnifiedNbsData={FetchUnifiedNbsDataResult?.data?.unifiedNbsData}
                readOrderData={readOrderData}
                pageContext={props.pageContext}
                readOrder={props.readOrder}
                isQAFlow={isQAFlow}
                nextBillSummaryData={getNextBillSummaryRes?.data}
                showManagerApprovalView={showManagerApprovalView}
                setUpdatedCartDeatilsResult={setUpdatedCartDeatilsResult}
                setShowManagerApprovalView={setShowManagerApprovalView}
              />
            </>
          )
        )}
      </PageHeight>
      {!showRepGuidedScreen && !props?.readOrder && !isQAClosedOrder && (
        <Footer
          data-testid='footer'
          handleViewTogetherClick={handleViewTogetherClick}
          handleViewTogetherResumeClick={handleViewTogetherResumeClick}
          showViewTogether={showViewTogether}
          disableButton={disableButton}
          spanishSelected={spanishSelected}
          cartDetailsResult={updatedCartDeatilsResult?.data}
          customer={CustomerProfileResult?.data?.data?.customer}
          paperLessBilling={paperLessBilling}
          updatedEmail={updatedEmail}
          hideOrderDetails={hideOrderDetails}
          getCartDetailsDataBody={getCartDetailsDataBody}
          setCustomerMtns={setCustomerMtns}
          customerMtns={customerMtns}
          setShowRepGuidedScreen={setShowRepGuidedScreen}
          hideContinue={hideContinue}
          hideViewTogether={hideViewTogether}
          handleViewTogetherTextClick={handleViewTogetherTextClick}
          showAffirmModal={showAffirmModal}
          setShowAffirmModal={setShowAffirmModal}
          continueBtnDisabled={continueBtnDisabled}
          setContinueBtnDisabled={setContinueBtnDisabled}
          setEmailValue={setEmailValue}
          isAffirmLoanApproved={isAffirmLoanApproved}
          setShowAffirmAccordion={setShowAffirmAccordion}
          verizonVisaCardLinkSent={verizonVisaCardLinkSent}
          isAllSetDone={isAllSetDone}
          profInstallappointmentFlag={isProfessionalInstall && profInstallappointmentFlag}
          lineActivityType={lineActivityType}
          fetchUnifiedNbsData={FetchUnifiedNbsDataResult?.data?.unifiedNbsData}
          isQAFlow={isQAFlow}
          setShowManagerApprovalView={setShowManagerApprovalView}
        />
      )}

      {(props?.readOrder || isQAClosedOrder) && (
        <FooterReadOrder
          cartData={cartDetails?.data?.cart}
          customerProfile={CustomerProfileResult?.data?.data}
          readOrderData={readOrderData}
          selectedReviewMode={selectedReviewMode}
          viewdiscountOpen={viewdiscountOpen}
          reaorderorderTagging={rspFetchReadOrder}
          isQAClosedOrder={isQAClosedOrder}
          cartDetailsResult={updatedCartDeatilsResult?.data}
          paperLessBilling={paperLessBilling}
        />
      )}
      {uswinModalEnable && !uswinSuccess && (
        <UswinModal
          uswinModalEnable={uswinModalEnable}
          uswinCloseModal={uswinCloseModal}
          CustomerProfileResult={CustomerProfileResult}
          uswinStatus={uswinStatus}
          handleUswinChange={handleUswinChange}
          uswinStatusMessage={uswinStatusMessage}
          handleSubmitUswin={handleSubmitUswin}
        />
      )}
      {!props.readOrder && isStandAloneTradeIn && (
        <StandAloneTrade
          data={updatedCartDeatilsResult?.data?.data?.cart?.lineDetails?.tradeInDetail}
          ViewTogetherProps={ViewTogetherProps}
          cartDetailsResult={updatedCartDeatilsResult?.data}
          customer={CustomerProfileResult?.data?.data?.customer}
        />
      )}
    </div>
  );
} // OrderReview

export default OrderReview;

OrderReview.propTypes = {
  readOrder: PropTypes.bool,
  pageContext: PropTypes.string,
  isQAFlow: PropTypes.bool,
};
