import React from 'react';
import Emitter from 'onevzsoemfeframework/Emitter';
import { HttpService } from 'onevzsoemfeframework/HTTPService';
import { useGetOffersPdpMutation } from 'onevzsoemfecommon/AccountAPIService';
import { useLazyGetManagerApprovalQuery, useLazyGetFetchDownpaymentQuery } from 'onevzsoemfecommon/APIService';
import PropTypes from 'prop-types';
import { render, screen, fireEvent, waitFor } from '../../../utils/test-utils/renderHelper';
import OrderReview from './orderreview';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import mockCartJson from '../../../__mock__/retrive-cart-orderreview.json';
import appointmentMockCartJson from '../../../__mock__/retrieveCArt5GAppointment.json';
import { getSetupAndGoCart } from '../../../__mock__/setup-go-cart';
import customerJson from '../../../__mock__/retrieve-customer.json';
import CheckoutDetails from '../../../components/OrderReview/CheckoutDetails';
import * as orderreviewApiCallHook from './orderreviewApiCallHook';

jest.mock('../../../components/ViewTogether/ViewTogether');

jest.mock('../../../utils/tagging');

jest.mock('onevzsoemfecommon/LOVPageTracker', () => ({
  __esModule: true,
  default: ({ viewCreditModal }) => (
    <button type='button' data-testid='mocked-closeModal' onClick={viewCreditModal}>
      closeModal PreviewBill Mock
    </button>
  ),
}));

jest.mock('onevzsoemfecommon/APIService', () => ({
  ...jest.requireActual('onevzsoemfecommon/APIService'),
  useLazyGetManagerApprovalQuery: jest.fn(),
  useLazyGetFetchDownpaymentQuery: jest.fn(),
  useLazyLovupdatecaseQuery: () => [
    jest.fn().mockImplementation(() =>
      Promise.resolve({
        status: 'fulfilled',
        isUninitialized: false,
        isLoading: false,
        isSuccess: true,
        isError: false,
        isFetching: false,
        data: { validationStatus: 'Valid' },
      }),
    ),
    {
      status: 'fulfilled',
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      isFetching: false,
      data: { validationStatus: 'Valid' },
    },
  ],
  // useAddRemoveAccessoriesMutation: () => ({
  //   addAccessories: jest.fn(),
  //   addAccessoriesSuccess: jest.fn(),
  // }),
}));

const useLazyGetManagerApprovalQueryRes = {
  data: {
    status: 'fulfilled',
    isUninitialized: false,
    isLoading: false,
    isSuccess: true,
    isError: false,
    isFetching: false,
    serviceBody: {
      serviceResponse: {
        context: {
          authenticateApproval: {
            approved: true,
          },
        },
      },
    },
  },
};
const useLazyGetManagerApprovalQueryRes2 = {
  data: {
    status: 'error',
    isUninitialized: false,
    isLoading: false,
    isSuccess: true,
    isError: false,
    isFetching: false,
    error: {
      data: {
        errors: [{ name: 'INVALID_USERNAME', message: 'Invalid Username or Password' }],
      },
    },
    serviceBody: {
      serviceResponse: {
        context: {
          authenticateApproval: {
            approved: false,
          },
        },
      },
    },
  },
};
jest.mock('onevzsoemfeframework/DomService', () => ({
  isIpad: () => true,
  isRetail: () => true,
  aesCipher: jest.fn((key, password) => `mocked_${password}_${key}`),
}));

jest.mock('../../../components/OrderReview/Affirm', () => ({
  __esModule: true,
  default: () => <div data-testid='view-together-footer'>mocked Affirm modal</div>,
}));

jest.mock('../../../components/OrderReview/UswinModal', () => ({
  __esModule: true,
  default: ({ handleSubmitUswin, uswinCloseModal, handleUswinChange }) => (
    <div>
      <button type='button' data-testid='handleSubmitUswin' onClick={handleSubmitUswin}>
        mocked uswin modal
      </button>
      <button type='button' data-testid='uswinCloseModal' onClick={uswinCloseModal}>
        mocked uswin modal
      </button>
      <button type='button' data-testid='handleUswinChange ' onClick={handleUswinChange}>
        mocked uswin modal
      </button>
      <button
        type='button'
        data-testid='handleUswinChangeValue '
        onClick={() => handleUswinChange({ target: { value: '123' } })}
      >
        mocked uswin modal
      </button>
    </div>
  ),
}));

const MockNotificationComponent = ({ onCloseButtonClick, title, buttonData = [], ...props }) => (
  <div {...props} data-testid='notification'>
    {title}{' '}
    {buttonData.map((i) => (
      <button type='button' onClick={i.onClick}>
        {i.children}
      </button>
    ))}
    <button type='button' data-testid='mocked-close-button' onClick={onCloseButtonClick}>
      close
    </button>
  </div>
);

MockNotificationComponent.propTypes = {
  onCloseButtonClick: PropTypes.func,
  title: PropTypes.string,
  buttonData: PropTypes.array,
};

jest.mock('@vds/notifications', () => ({
  __esModule: true,
  Notification: (props) => <MockNotificationComponent {...props} />,
}));
jest.mock('onevzsoemfecommon/AccountAPIService', () => ({
  useGetOffersPdpMutation: jest.fn(),
}));
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: (keys) =>
      keys.map(
        (key) =>
          ({
            isSecondaryUswinAuthEnabled: 'TRUE',
          })[[key]],
      ),
  }),
  { virtual: true },
);
// jest.mock('onevzsoemfecommon/APIService', () => ({
//   useLazyGetManagerApprovalQuery: jest.fn(),
//   useLazyGetFetchDownpaymentQuery: jest.fn(),
// }));
jest.mock('../../../modules/services/APIService/APIServiceCallHook', () => ({
  ...jest.requireActual('../../../modules/services/APIService/APIServiceCallHook'),
  useLazyGetCartDetailsQuery: () => [() => {}, {}],
  useGetOrderReviewQuery: () => ({
    status: 0,
    showAccessoriesSection: true,
    showNotificationSection: false,
    showPurchaseOrderSection: false,
    telesalesNegativeReasonList: false,
    retailNegativeReasonList: true,
    showGiftPurchase: true,
    showOnlineOffers: false,
    showTradeInSection: true,
    channelId: 'OMNI-RETAIL',
    mtnCount: 0,
    purchaseOrderNumRequired: false,
    ptechEnabledForRetailLoc: false,
  }),
}));

let getOffersMock;
let getOffersResultsMock;

beforeEach(() => {
  getOffersMock = jest.fn();
  getOffersResultsMock = {
    data: null,
    error: null,
    isLoading: false,
    isSuccess: false,
    isError: false,
  };
  useGetOffersPdpMutation.mockReturnValue([getOffersMock, getOffersResultsMock]);
  jest.spyOn(HttpService, 'post').mockImplementation(() => Promise.resolve({ mockId: 'ort129' }));
});

beforeEach(() => {
  sessionStorage.setItem('channel', 'OMNI-RETAIL');
});

describe('Home page order review', () => {
  it('Post api call for Customer and Retrieve cart', () => {
    const openDevice = jest.fn();
    openDevice.mockReturnValueOnce(true);
    render(
      <CheckoutDetails openDeviceInformation={openDevice} cart={appointmentMockCartJson} customer={customerJson} />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });

  afterAll(() => {
    const openDevice = jest.fn();
    openDevice.mockReturnValueOnce(true);

    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: appointmentMockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
    }));
    render(
      <CheckoutDetails
        openDeviceInformation={() => openDevice(true)}
        cart={appointmentMockCartJson}
        customer={customerJson}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });

  beforeEach(() => {
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: getSetupAndGoCart() },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    Emitter.emit('TAGGING_COMPLETED', true);
    jest.spyOn(HttpService, 'post').mockImplementation(() => Promise.resolve({ mockId: 'ort228' }));
  });

  test('renders home page', async () => {
    window.sessionStorage.setItem('isLovEligibleFromSessionStorage', 'false');
    window.sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'TRUE' }));
    useLazyGetManagerApprovalQuery.mockReturnValue([jest.fn(), { ...useLazyGetManagerApprovalQueryRes }]);
    useLazyGetFetchDownpaymentQuery.mockReturnValue([jest.fn(), { ...useLazyGetManagerApprovalQueryRes }]);
    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    screen.debug();
  });
  test('renders home page', async () => {
    window.sessionStorage.setItem('isLovEligibleFromSessionStorage', 'false');
    window.sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'TRUE' }));
    useLazyGetManagerApprovalQuery.mockReturnValue([jest.fn(), { ...useLazyGetManagerApprovalQueryRes2 }]);
    useLazyGetFetchDownpaymentQuery.mockReturnValue([jest.fn(), { ...useLazyGetManagerApprovalQueryRes }]);
    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    screen.debug();
  });
});

describe('Home page order review', () => {
  it('Post api call for Customer and Retrieve cart', () => {
    const openDevice = jest.fn();
    openDevice.mockReturnValueOnce(true);
    render(
      <CheckoutDetails openDeviceInformation={openDevice} cart={appointmentMockCartJson} customer={customerJson} />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });

  afterAll(() => {
    const openDevice = jest.fn();
    openDevice.mockReturnValueOnce(true);

    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: appointmentMockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
    }));
    render(
      <CheckoutDetails
        openDeviceInformation={() => openDevice(true)}
        cart={appointmentMockCartJson}
        customer={customerJson}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });

  beforeEach(() => {
    useLazyGetManagerApprovalQuery.mockReturnValue([jest.fn(), {}]);
    useLazyGetFetchDownpaymentQuery.mockReturnValue([jest.fn(), { ...useLazyGetManagerApprovalQueryRes }]);
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: getSetupAndGoCart() },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    Emitter.emit('TAGGING_COMPLETED', true);
    jest.spyOn(HttpService, 'post').mockImplementation(() => Promise.resolve({ mockId: 'ort228' }));
  });

  test('renders home page', async () => {
    window.sessionStorage.setItem('isLovEligibleFromSessionStorage', 'false');
    window.sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'TRUE' }));
    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    screen.debug();
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: mockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    render(<CheckoutDetails cart={mockCartJson} customer={customerJson} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('renders home page render view together QR-Code Generator', async () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [], scmVtButtonEnable: true, scmUpgradeMfeEnable: true };
    window.sessionStorage.setItem('isLovEligibleFromSessionStorage', 'true');
    window.sessionStorage.setItem('isViewTogether', false);
    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: mockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    render(<CheckoutDetails cart={mockCartJson} customer={customerJson} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    await waitFor(() => {
      const viewTogetherButton = screen.getByTestId('view-together-footer');
      fireEvent.click(viewTogetherButton);
      const handleSubmitUswin = screen.getByTestId('handleSubmitUswin');
      fireEvent.click(handleSubmitUswin);
      const handleUswinChangeValue = screen.getByTestId('handleUswinChangeValue');
      fireEvent.click(handleUswinChangeValue);
      const uswinCloseModal = screen.getByTestId('uswinCloseModal');
      fireEvent.click(uswinCloseModal);
    });
  });
  test('renders home page render view together QR-Code Generator', async () => {
    window.mfe = { scmCheckoutMfeEnable: true, historyRef: [] };
    window.sessionStorage.setItem('isLovEligibleFromSessionStorage', 'true');
    render(<OrderReview />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: {} },
      CartDetailsResult: { data: mockCartJson },
      FetchPricingSnapshotResult: { refetch: jest.fn() },
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    render(<CheckoutDetails cart={mockCartJson} customer={{}} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
});
