import {
  useLazyEnrollGiftPurchaseQuery,
  useLazyPostLineChargesQuery,
} from '../../../modules/services/APIService/APIServiceHooks';

const monthlyChargesApiCallHook = () => {
  const [getOtherLineCharges, otherLineChargesResult] = useLazyPostLineChargesQuery();
  const [getEnrollGiftPurchase, enrollGiftPurchaseResult] = useLazyEnrollGiftPurchaseQuery();
  return {
    getOtherLineCharges,
    otherLineChargesResult,
    getEnrollGiftPurchase,
    enrollGiftPurchaseResult,
  };
};

export default monthlyChargesApiCallHook;
