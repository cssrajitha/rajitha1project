import { useGetCartDetailsQuery, useGetCustomerProfileQuery } from 'onevzsoemfecommon/APIService';

import {
  requestBodyRetriveCart,
  requestBodyCustomerProfile,
  requestBodyFetchPricingSnapshot,
} from '../../../modules/services/APIService/APIRequestBody';

import {
  useGetPricingSnapshotQuery,
  useLazyGetDeviceDetailsQuery,
  useLazyGetLovDetailsQuery,
  useLazyGetManualDiscountQuery,
  useLazyUpdateManualDiscountQuery,
  useLazyUpdateBarcodeQuery,
  useLazyUpdateTradeinQuery,
  useLazyUpdateAccountDevicesQuery,
  useLazyUpdateDownpaymentQuery,
  useLazyMultiLineFMIPQuery,
  useLazyGetAccAddressValidationQuery,
  useLazyGetValidateCartAndCheckoutQuery,
  useFetchUnifiedNbsDataQuery,
} from '../../../modules/services/APIService/APIServiceHooks';

const orderreviewApiCallHook = (skipCartDetails = false, isQAFlow = false) => {
  const CustomerProfileResult = useGetCustomerProfileQuery(
    { body: requestBodyCustomerProfile },
    { refetchOnMountOrArgChange: true, skip: skipCartDetails },
  );
  const CartDetailsResult = useGetCartDetailsQuery(
    { body: requestBodyRetriveCart },
    { refetchOnMountOrArgChange: true, skip: !CustomerProfileResult.isSuccess || skipCartDetails },
  );
  const FetchPricingSnapshotResult = useGetPricingSnapshotQuery({ body: requestBodyFetchPricingSnapshot });

  const [manualDiscountBody, ManualDiscountResult] = useLazyGetManualDiscountQuery();

  const { getDetailsRequestBody, GetDetailsResult } = useLazyGetDeviceDetailsQuery();

  const [updateManualDiscountBody, updateManualDiscountResult] = useLazyUpdateManualDiscountQuery();

  const [updateBarCodeBody, updateBarCodeResult] = useLazyUpdateBarcodeQuery();

  const [updateTradinBody, updateTradeinResult] = useLazyUpdateTradeinQuery();

  const [updateAccountDevicesBody, updateAccountDevicesResult] = useLazyUpdateAccountDevicesQuery();

  const [updateDownpaymentBody, updateDownpaymentResult] = useLazyUpdateDownpaymentQuery();

  const [getMFIPrequest, getMFIPResult] = useLazyMultiLineFMIPQuery();

  const [getLovDetailsBody, getLovDetailsResult] = useLazyGetLovDetailsQuery();

  const [getAccAddressValidationBody, getAccAddressValidationResult] = useLazyGetAccAddressValidationQuery();

  const [getValidateCartAndCheckoutBody, getValidateCartAndCheckoutResult] = useLazyGetValidateCartAndCheckoutQuery();

  const FetchUnifiedNbsDataResult = useFetchUnifiedNbsDataQuery(
    { body: { unifiednbsflag: true }, mock: false },
    { skip: isQAFlow },
  );

  return {
    CustomerProfileResult,
    CartDetailsResult,
    FetchPricingSnapshotResult,
    getDetailsRequestBody,
    GetDetailsResult,
    manualDiscountBody,
    ManualDiscountResult,
    updateManualDiscountBody,
    updateManualDiscountResult,
    updateBarCodeBody,
    updateBarCodeResult,
    updateTradinBody,
    updateTradeinResult,
    updateAccountDevicesBody,
    updateAccountDevicesResult,
    updateDownpaymentBody,
    updateDownpaymentResult,
    getMFIPrequest,
    getMFIPResult,
    getLovDetailsBody,
    getLovDetailsResult,
    getAccAddressValidationBody,
    getAccAddressValidationResult,
    getValidateCartAndCheckoutBody,
    getValidateCartAndCheckoutResult,
    FetchUnifiedNbsDataResult,
  };
};

export default orderreviewApiCallHook;
