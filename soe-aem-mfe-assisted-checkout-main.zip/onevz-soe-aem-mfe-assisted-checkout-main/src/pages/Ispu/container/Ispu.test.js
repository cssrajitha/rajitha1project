import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { render, screen } from '../../../utils/test-utils/renderHelper';
import * as orderreviewApiCallHook from '../../home/container/orderreviewApiCallHook';
import Ispu from './Ispu';

jest.mock('../../../components/Ispu/IspuStoreSearch', () => ({
  __esModule: true,
  default: () => <div>ISPU</div>,
}));

describe('ISPU test', () => {
  beforeEach(() => {
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: {} },
      CartDetailsResult: { data: {} },
    }));
    render(<Ispu />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('render ISPU', async () => {
    const page = screen.getByTestId('ispu-container');

    expect(page).toBeInTheDocument();
  });
});
