import React from 'react';
import IspuStoreSearch from '../../../components/Ispu/IspuStoreSearch';
import orderreviewApiCallHook from '../../home/container/orderreviewApiCallHook';

export default function Ispu() {
  const { CartDetailsResult, CustomerProfileResult } = orderreviewApiCallHook();
  return (
    <div data-testid='ispu-container'>
      {CartDetailsResult && CustomerProfileResult && (
        <IspuStoreSearch CartDetailsResult={CartDetailsResult} CustomerProfileResult={CustomerProfileResult} />
      )}
    </div>
  );
}
