import React, { useEffect } from 'react';
import { useGetCartDetailsQuery } from 'onevzsoemfecommon/APIService';
import styled from 'styled-components';
import { Icon } from '@vds/icons';
import { Line } from '@vds/lines';
import { Title } from '@vds/typography';
import { TextLinkCaret } from '@vds/buttons';
import { BackClickable } from '../../../StyledConstants';
import orderreviewApiCallHook from '../../home/container/orderreviewApiCallHook';
import { requestBodyRetriveCart } from '../../../modules/services/APIService/APIRequestBody';

const FlexBoxGrowOne = styled.div`
  display: flex;
  flex-grow: 1;
  height: 4rem;
`;

const LineSeperator = styled.div`
  width: 1px;
  height: 50px;
  background: #000000;
  top: 1rem;
  border-right: 1px solid #d8dada;
  position: relative;
  margin-right: 10px;
`;

const MarginSides = styled.div`
  margin-top: 30px;
`;

const ImageContainer = styled.div`
  display: flex;
  justify-content: flex-start;
  gap: 20 px;
  margin-top: 20px;
`;

const ImageItem = styled.div`
  text-align: center;
`;

const Image = styled.img`
  width: 200px;
  height: auto;
`;

const DevideID = styled.div`
  margin-top: 10px;
  color: #333;
`;

const SpaceBetween = styled.div`
  margin-bottom: 20px;
`;

const TradeInMoreDevice = () => {
  const CartDetailsResult = useGetCartDetailsQuery(
    { body: requestBodyRetriveCart, mock: false },
    { refetchOnMountOrArgChange: true },
  );

  const cartData = CartDetailsResult?.data?.data?.cart?.cartHeader;
  let deviceList = [];
  const { updateAccountDevicesBody, updateAccountDevicesResult } = orderreviewApiCallHook();

  useEffect(() => {
    if (updateAccountDevicesResult?.status === 'uninitialized') {
      const params = {
        accountNo: cartData?.fullAccountNumber,
        cartId: cartData?.cartId,
      };

      updateAccountDevicesBody({
        body: params,
        spinner: false,
        mock: false,
      });
    }
  }, [updateAccountDevicesResult]);
  if (updateAccountDevicesResult?.status === 'fulfilled') {
    deviceList = updateAccountDevicesResult?.data?.data?.deviceList;
  }
  return (
    <div>
      <div data-testId='previewBillModel'>
        <FlexBoxGrowOne>
          <BackClickable data-testId='btn-back'>
            <Icon name='left-caret' size='XLarge' medium='true' />
          </BackClickable>
          <LineSeperator />
          <MarginSides>
            <Title size='small' bold primitive='h1'>
              Trade in
            </Title>
          </MarginSides>
        </FlexBoxGrowOne>
        <SpaceBetween />
        <Line type='primary' />
        <ImageContainer>
          {deviceList &&
            deviceList?.map((item) => (
              <ImageItem key={item?.deviceId}>
                <Image src={item?.imageUrl} alt='Iphone' />
                <DevideID>
                  <Title size='small' bold primitive='h1'>
                    {item?.brand}
                    {item?.displayName}
                  </Title>
                </DevideID>
                <DevideID>
                  <Title size='small' bold primitive='h1'>
                    {item?.size}/{item?.color}
                  </Title>
                </DevideID>
                <DevideID>
                  <Title size='small' bold primitive='h1'>
                    {item?.mtn}
                  </Title>
                </DevideID>
                <DevideID>
                  <Title size='small' bold primitive='h1'>
                    Device ID:
                    {item?.deviceId}
                  </Title>
                </DevideID>
              </ImageItem>
            ))}
        </ImageContainer>
        <SpaceBetween />
        <TextLinkCaret
          type='standAlone'
          data-testId='link'
          surface='light'
          disabled={false}
          size='large'
          // onClick={() => handleRemove()} Commented for future purpose
        >
          Show more
        </TextLinkCaret>
        <SpaceBetween />
        <Line type='primary' />
        <SpaceBetween />
        <Title size='small' bold primitive='h1'>
          Trade in a different device
        </Title>
        <SpaceBetween />
        <TextLinkCaret
          type='standAlone'
          data-testId='link'
          surface='light'
          disabled={false}
          size='large'
          // onClick={() => handleRemove()} Commented for future purpose
        >
          Select a device
        </TextLinkCaret>
      </div>
    </div>
  );
};

export default TradeInMoreDevice;
