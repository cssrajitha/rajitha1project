import { render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../../modules/store';
import TradeInMoreDevice from './TradeInMoreDevice';
import updateTradein from '../../../components/OrderReview/__mock__/updateTradein.json';
import * as orderreviewApiCallHook from '../../home/container/orderreviewApiCallHook';

const mockValue = jest.fn();
const mockData = {
  updateAccountDevicesBody: mockValue,
  updateAccountDevicesResult: { data: updateTradein, status: 'fulfilled' },
};
const mockSaveOrder = jest.fn();

describe('TradeInMoreDevice Component', () => {
  test('renders Header of TradeInMoreDevice', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <TradeInMoreDevice />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getAllByText(/Trade in/i);
    expect(titleElement[0]).toBeInTheDocument();
  });

  test('renders Body of TradeInMoreDevice', () => {
    render(
      <BrowserRouter>
        <StoreProvider>
          <TradeInMoreDevice />
        </StoreProvider>
      </BrowserRouter>,
    );
    const titleElement = screen.getAllByText('Trade in a different device');
    expect(titleElement[0]).toBeInTheDocument();
  });

  it('renders Tradein component when status is fulfilled', () => {
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => mockData);
    render(
      <BrowserRouter>
        <StoreProvider>
          <TradeInMoreDevice />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  it('renders Tradein component when status is uninitialised', () => {
    const mockData2 = {
      updateAccountDevicesBody: mockSaveOrder,
      updateAccountDevicesResult: { status: 'uninitialized' },
    };
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => mockData2);

    render(
      <BrowserRouter>
        <StoreProvider>
          <TradeInMoreDevice />
        </StoreProvider>
      </BrowserRouter>,
    );
  });
});
