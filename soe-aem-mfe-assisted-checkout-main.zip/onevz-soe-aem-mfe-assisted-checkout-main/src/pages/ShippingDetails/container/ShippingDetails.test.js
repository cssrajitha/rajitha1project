import { render, screen, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import StoreProvider from '../../../modules/store';
import cartJson from '../../../__mock__/shipping-details-container-retrive-cart.json';
import customerJson from '../../../__mock__/retrieve-customer.json';
import * as orderreviewApiCallHook from '../../home/container/orderreviewApiCallHook';

import ShippingDetails from './ShippingDetails';

const timeout = 10000;
jest.setTimeout(timeout);

describe('Shipping detail Component notification', () => {
  beforeEach(() => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ splitFulfilmentUIOrderReviewFFlag: 'TRUE' }));
    render(
      <BrowserRouter>
        <StoreProvider>
          <ShippingDetails />
        </StoreProvider>
      </BrowserRouter>,
    );
  });

  test('renders shipping details', async () => {
    jest.spyOn(orderreviewApiCallHook, 'default').mockImplementation(() => ({
      CustomerProfileResult: { data: customerJson },
      CartDetailsResult: { data: cartJson },
      FetchPricingSnapshotResult: {},
      getLovDetailsBody: jest.fn().mockResolvedValue({ data: { lovEnabled: true } }),
      getAccAddressValidationBody: jest.fn(),
    }));
    await waitFor(() => {
      const titleElement = screen.getByTestId('shippingDetails');
      expect(titleElement).toBeInTheDocument();
    });
  });
});
