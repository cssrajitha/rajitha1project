import React, { useState } from 'react';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import { getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import EditShippinAddress from '../../../components/ShippingDetails/EditShippingAddress';
import ShippingDetailsHeader from '../../../components/ShippingDetails/ShippingDetailsHeader';
import ShippingOptionsForm from '../../../components/ShippingDetails/ShippingOptionsForm';
import orderreviewApiCallHook from '../../home/container/orderreviewApiCallHook';

const PageHeight = styled.div`
  height: calc(100vh + 10rem);
`;

const Page = styled.div`
  z-index: -2
  display: grid;
  grid-template-rows: auto 1fr;
`;

const HeaderContainer = styled.div`
  const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable;
  grid-row: 1;
  margin-bottom: ${({ scmUpgradeMfeEnable }) => (scmUpgradeMfeEnable ? '0' : '100px')};
`;

const EditFormContainer = styled.div`
  grid-row: 2;
`;

const Container = styled.div`
  display: flex;
  width: auto;
  margin-top: 10px;
  gap: 30px;
  padding-bottom: 10rem;
`;

const FlexContainer = styled.div`
  display: block;
  css-float: left;
  width: 43%;
  margin-left: 0%;
  clear: none;
`;

const LineSeperator = styled.div`
  top: 1rem;
  border-right: 1px solid #d8dada;
  position: relative;
`;

const ShippingDetails = ({ isFromRefundOrderView = false, isDark = false }) => {
  const isQAFlow = /true/i.test(getQueryParamByName('isQAFlow'));
  const { CustomerProfileResult, CartDetailsResult } = orderreviewApiCallHook(false, isQAFlow);
  const [getShippingOptionsOfAllLines, setGetShippingOptionsOfAllLines] = useState([]);
  const [shippingOptionsForQA, setShippingOptionsForQA] = useState(null);

  const customerProfile = CartDetailsResult?.data?.data?.cart?.customerProfile || null;
  const orderDetails = CartDetailsResult?.data?.data?.cart?.orderDetails;
  const lineDetails = CartDetailsResult?.data?.data?.cart?.lineDetails;
  const cartData = CartDetailsResult?.data?.data?.cart?.cartHeader;
  const shippingData = lineDetails?.lineInfo?.[0]?.itemsInfo?.[0]?.shipping;
  const cartId = CartDetailsResult?.data?.data?.cart?.cartHeader?.cartId;
  const mtnList = customerProfile?.billAccounts?.[0]?.mtns.map((mtns) => mtns.mtn);
  const [selectedShippingOption, setSelectedShippingOption] = useState(null);

  return (
    <Page data-testid='shippingDetails'>
      <HeaderContainer>
        <ShippingDetailsHeader
          isFromRefundOrderView={isFromRefundOrderView}
          orderDetails={orderDetails}
          isQAFlow={isQAFlow}
          isDark={isDark}
        />
      </HeaderContainer>
      <EditFormContainer>
        <PageHeight>
          <Container>
            <FlexContainer>
              <EditShippinAddress
                customerProfile={customerProfile}
                orderDetails={orderDetails}
                lineDetails={lineDetails}
                selectedShippingOption={selectedShippingOption}
                cartHeader={cartData}
                mtnList={mtnList}
                CustomerProfileResult={CustomerProfileResult}
                getShippingOptionsOfAllLines={getShippingOptionsOfAllLines}
                CartDetailsResult={CartDetailsResult?.data?.data?.cart}
                isFromRefundOrderView={isFromRefundOrderView}
                isQAFlow={isQAFlow}
                setShippingOptionsForQA={setShippingOptionsForQA}
                isDark={isDark}
              />
            </FlexContainer>
            <LineSeperator />
            <FlexContainer>
              <ShippingOptionsForm
                setSelectedShippingOption={setSelectedShippingOption}
                shippingAddress={shippingData?.address}
                cartId={cartId}
                cartDetails={CartDetailsResult?.data?.data?.cart}
                customerInfo={customerProfile}
                setGetShippingOptionsOfAllLines={setGetShippingOptionsOfAllLines}
                isQAFlow={isQAFlow}
                shippingOptionsQA={shippingOptionsForQA}
                selectedShippingOption={selectedShippingOption}
                isDark={isDark}
              />
            </FlexContainer>
          </Container>
        </PageHeight>
      </EditFormContainer>
    </Page>
  );
};

ShippingDetails.propTypes = {
  isFromRefundOrderView: PropTypes.bool,
  isDark: PropTypes.bool,
};

export default ShippingDetails;
