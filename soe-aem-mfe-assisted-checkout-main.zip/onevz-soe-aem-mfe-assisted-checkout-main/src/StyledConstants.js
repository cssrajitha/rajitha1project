import styled, { css } from 'styled-components';
import { Col } from '@vds/grids';

export const FlexBox = styled.div`
  display: flex;
`;
export const StyledPaddingLeft8 = styled.div`
  padding-left: 0.5rem;
`;
export const PaddingBottom8 = styled.div`
  padding-bottom: 0.5rem;
`;
export const FlexContainerAlignItemsCenter = styled.div`
  display: flex;
  align-items: center !important;
  padding: 0 2rem 0 1rem;
  justify-content: space-between;
`;
export const BackClickable = styled.a`
  cursor: pointer;
  color: #000000 !important;
  align-items: center;
  padding: 1.5rem 1.5rem 1.5rem 0;
`;
export const HeaderBackClickable = styled.a`
  display: flex;
  cursor: pointer;
  color: #000000 !important;
  align-items: center;
  padding: 1.5rem 1.5rem 1.5rem 0;
`;

export const PaddingY24 = styled.div`
  padding: 1.5rem 0 1.5rem 0;
`;
export const Padding24 = styled.div`
  padding: 1.5rem;
`;
export const PaddingLeft24 = styled.div`
  padding: 0 0 0 1.5rem;
`;
export const PaddingRight32 = styled.div`
  padding: 0 2rem 0 0;
`;
export const PaddingRight12 = styled.div`
  padding: 0 0.75rem 0 0;
`;
export const StyledPaddingRight8 = styled.div`
  padding-right: 0.5rem;
`;
export const PaddingBottom16 = styled.div`
  padding: 0 0 1rem 0;
`;
export const FlexAlignCenter = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
`;
export const FlexBaseLine = styled.div`
  display: flex;
  align-items: baseline;
`;
export const FlexJustify = styled.div`
  display: flex;
  justify-content: space-between;
`;
export const FlexJustifyEnd = styled.div`
  display: flex;
  justify-content: end;
`;
export const Padding12 = styled.div`
  padding: 0.75rem 0 0.75rem 0;
`;
export const PaddingTop4 = styled.div`
  padding-top: 0.25rem;
`;
export const PaddingRight20 = styled.div`
  padding-right: 1.25rem;
`;
export const PaddingBottom2 = styled.div`
  padding-bottom: 0.125rem;
`;
export const PaddingTop12 = styled.div`
  padding: 0.75rem 0 0 0;
`;
export const PaddingBottom12 = styled.div`
  padding: 0 0 0.75rem 0;
`;
export const Padding8 = styled.div`
  padding: 0.5rem 0 0.5rem 0;
`;
export const PaddingTop2 = styled.div`
  padding-top: 0.125rem;
`;
export const FlexBoxContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
export const MaxWidth72 = styled.div`
  max-width: 72px;
`;
export const Marginleft6 = styled.div`
  margin-left: -0.375rem;
`;
export const Width20 = styled.div`
  width: 20%;
`;
export const PaddingTop16 = styled.div`
  padding-top: 1rem;
`;
export const PaddingLeft4 = styled.span`
  padding-left: 0.25rem;
`;
export const PaddingLeftRight4 = styled.div`
  padding: 0 0.25rem 0 0.25rem;
`;
export const FlexAlignCenterBox = styled.div`
  display: flex;
  align-items: center;
`;
export const PaddingLeft12 = styled.div`
  padding: 0 0 0 0.75rem;
`;

export const FlexBoxColumn = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
`;
export const Padding36 = styled.div`
  padding: 1.5rem 2rem;
`;
export const TileWrapper = styled.div`
  @media only screen and (min-width: 1401px) {
    flex: 0 1 calc(20% - 1em);
  }
  @media only screen and (min-width: 1201px) and (max-width: 1400px) {
    flex: 0 1 calc(25% - 1em);
  }
  @media only screen and (max-width: 1200px) {
    flex: 0 1 calc(33.33% - 1em);
  }
`;
export const ImgWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 116px;
  margin-top: 2.125rem;
  margin-bottom: 1rem;
`;
export const Padding16 = styled.div`
  padding: 1rem 0 1rem 0;
`;
export const PaddingRight16 = styled.div`
  padding-right: 1rem;
`;
export const Padding70 = styled.div`
  padding: 0 4.375rem 0 4.375rem;
`;
export const Padding32 = styled.div`
  padding: 0 2rem 0 2rem;
`;
export const PaddingAll = styled.div`
  padding: 2rem;
`;
export const PaddingTop6 = styled.div`
  padding: 0.375rem 0 0 0;
`;
export const PaddingTop8 = styled.div`
  padding: 0.5rem 0 0 0;
`;
export const StyledBorder = styled.div`
  flex: 1;
`;
export const PaddingTop20 = styled.div`
  padding-top: 1.25rem;
`;
export const PaddingTop24 = styled.div`
  padding-top: 1.5rem;
`;
export const StyledPaddingTop32 = styled.div`
  padding: 2rem 0 0 0;
`;
export const StyledPaddingBot32 = styled.div`
  padding-bottom: 2rem;
`;
export const StyledPaddingTopBot32 = styled.div`
  padding: 2rem 0;
`;
export const StyledPaddingTop20Bot16 = styled.div`
  padding: 1.25rem 0 1rem;
`;
export const StyledPaddingTop8Bot8 = styled.div`
  padding: 0.5rem 0 0.5rem;
`;
export const StyledPaddingTop8Bot16 = styled.div`
  padding: 0.5rem 0 1rem;
`;
export const PaddingBot24 = styled.div`
  padding: 0 0 1.5rem 0;
`;
export const StyledFlexContainer = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-end;
`;
export const PaddingLeft16 = styled.div`
  padding-left: 1rem;
`;
export const TileIconWrapper = styled.div`
  position: absolute;
  right: 1rem;
  top: 1rem;
`;

export const ShopWrapper = styled.div`
  padding: 1.5rem 0.5rem;
`;
export const StyledTextRight = styled.div`
  text-align: right;
`;
export const IconWrapper = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
  padding-right: 2rem;
`;
export const Padding48 = styled.div`
  padding: 0 3rem 0 3rem;
`;
export const Padding4 = styled.div`
  padding: 0.25rem 0 0.25rem 0;
`;
export const TrashWrapper = styled.span`
  cursor: pointer;
  width: 3rem;
  height: 1.5rem;
  display: flex;
  align-items: center;
  position: absolute;
  bottom: 1rem;
`;
export const MarginRight4 = styled.div`
  margin-right: 0.25rem;
`;

export const StyledHeaderWithClose = styled.div`
  @media (min-width: 1272px) {
    font-size-adjust: 1.25rem;
  }
  width: 100%;
  margin-left: 0;
  margin-right: 0;
  border-bottom: 1px solid #d8dada;
  background: white;
`;
export const HeadFlexContainerAlignItemsCenter = styled.div`
  display: flex;
  align-items: center !important;
  padding-right: 36px;
  padding-left: 36px;
`;
export const LinkPointer = styled.a`
  cursor: pointer !important;
  text-decoration: none;
  color: #000000;
  &:focus {
    outline: 1px dotted #000000 !important;
  }
`;
export const BlackClickable = styled.a`
  cursor: pointer;
  color: #000000 !important;
`;

export const PaddingTopBot32 = styled.div`
  padding: 2rem 0 2rem 0;
`;
export const PaddingTopBot48 = styled.div`
  padding: 3rem 0 3rem 0;
`;
export const PaddingTop28 = styled.div`
  padding: 1.75rem 0 0 0;
`;
export const SmallIconWrapper = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  margin-left: 0.25rem;
  min-width: 20px;
  height: 20px;
  background: #00ac3e;
  border-radius: 20px;
`;

export const CursorPointerWrapper = styled.div`
  cursor: pointer;
`;

export const PaddingTop96 = styled.div`
  padding-top: 6rem;
`;

export const ZeroPaddingCol = styled(Col)`
  padding: 0 !important;
`;

export const PaddingTopLarge = styled.div`
  padding-top: 1.3125rem !important;
`;

export const BorderBottomGreyLight = styled.div`
  border-bottom: 1px solid #d8dada !important;
`;

export const PaddingBottomSmall = styled.div`
  padding-bottom: 0.4375rem !important;
`;

export const PaddingRightSmall = css`
  padding-right: 0.4375rem !important;
`;

export const BorderBottomBlack = styled.div`
  border-bottom: 1px solid #000000 !important;
`;

export const StyledFooterWrapper = styled.div`
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  margin-bottom: 10px;
`;
