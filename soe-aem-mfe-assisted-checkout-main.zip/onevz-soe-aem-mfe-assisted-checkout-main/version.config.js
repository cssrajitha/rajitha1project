module.exports = ['onevzsoemfecommon', 'onevzsoemfeframework'];
