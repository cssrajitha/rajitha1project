/* eslint-disable no-param-reassign */
/* eslint-disable import/no-extraneous-dependencies */
const { whenDev, whenProd } = require('@craco/craco');
// eslint-disable-next-line import/no-extraneous-dependencies
const cracoCommon = require('@onevz-soe-mfe-base/craco-config');
const path = require('path');
const { DedupePlugin } = require('@tinkoff/webpack-dedupe-plugin');
const { dependencies } = require('./package.json');

const branch = 'main';
const appPrefix = 'mfe-checkout';
const timestamp = Date.now();
const mfeName = 'onevzsoemfeassistedcheckout';
const SERVER_PORT = 4012;

const appCracoConfig = {
  mode: whenDev(() => 'development', 'production'),
  devServer: whenDev(() => ({
    host: '::',
    historyApiFallback: {
      disableDotRule: true,
    },
    port: SERVER_PORT,
    static: {
      directory: path.join(__dirname, 'dist'),
    },
    headers: {
      'Access-Control-Allow-Origin': '*',
    },
    liveReload: true,
    proxy: {
      '/api': {
        target: 'https://soe-hivv-nssit2.ebiz.verizon.com/',
        pathRewrite: { '^/api': '' },
        changeOrigin: true,
        secure: false,
      },
      '/generate/jwt': {
        target: 'https://onevzssosoe-east-gz-dit1.ebiz.verizon.com/',
        changeOrigin: true,
        secure: false,
      },
    },
  })),
  // devtool: 'source-map', // Enable source maps
};

const buildParam = process.env.BUILD_PARAM || '';
const pathPrefix = buildParam === 'VBG' ? '/vbg' : '';

const remotes = {
  onevzsoemfeframework: `onevzsoemfeframework@${pathPrefix}/etc/clientlibs/vcg/common/onevzsoemfeframework/100/remoteEntry.js`,
  onevzsoemfecommon: `onevzsoemfecommon@${pathPrefix}/etc/clientlibs/vcg/common/onevzsoemfecommon/100/remoteEntry.js`,
};

const localRemotes = {
  onevzsoemfeframework: 'onevzsoemfeframework@http://localhost:3001/remoteEntry.js',
  onevzsoemfecommon: 'onevzsoemfecommon@http://localhost:4002/remoteEntry.js',
};

// const remotes = {
//   onevzsoemfeframework: 'onevzsoemfeframework@/etc/clientlibs/vcg/common/onevzsoemfeframework/100/remoteEntry.js',
//   onevzsoemfecommon: 'onevzsoemfecommon@/etc/clientlibs/vcg/common/onevzsoemfecommon/100/remoteEntry.js',
// };

const commonConfig = cracoCommon.createCracoConfig({
  appCracoConfig,
  debug: false,
  moduleFederationOptions: {
    dependencies,
    debug: false,
    isShell: whenProd(() => false, true),
    options: {
      name: mfeName,
      filename: 'remoteEntry.js',
      // add the list of components that you wish to expose - so that other MFE can consume
      exposes: {
        './Handoff': './src/pages/home/container/Handoff/handoff',
        './OrderReview': './src/pages/home/container/orderreview',
        './ShippingDetails': './src/pages/ShippingDetails/container/ShippingDetails',
        './TradeInMoreDevice': './src/pages/TradeInMoreDevice/container/TradeInMoreDevice',
        './IspuStoreFinder': './src/pages/Ispu/container/Ispu',
        './RefundOrderReview': './src/components/OrderReview/Refund',
      },
      remotes: whenDev(() => localRemotes, remotes),
      shared: {
        // refer confluence for performance optimization
      },
    },
  },
  moduleFederationTestPluginOptions: {
    branch,
    additionalBundlerConfig: {
      noExternal: [/^@vds\/(.*)$/],
    },
    // localRemotes,
  },
  overrideWebpackConfigure: (webpackConfig) => {
    webpackConfig.output.filename = whenProd(() => `[name].[contenthash]${timestamp}.js`);
    webpackConfig.output.publicPath = whenProd(
      () => `${pathPrefix}/etc/clientlibs/vcg/assisted/soe-assisted-mfe/${mfeName}/100/`, // PROD publicPath
      `http://localhost:${SERVER_PORT}/`, // DEV publicPath
    );

    webpackConfig.plugins.push(
      new DedupePlugin({
        strategy: 'equality',
      }),
    );

    if (webpackConfig?.optimization?.splitChunks?.cacheGroups) {
      webpackConfig.optimization.splitChunks.cacheGroups = {
        ...webpackConfig.optimization.splitChunks.cacheGroups,
        // refer confluence for performance optimization
      };
    }

    return webpackConfig;
  },
  splitChunkOptions: {
    appPrefix,
  },
});

module.exports = commonConfig;
