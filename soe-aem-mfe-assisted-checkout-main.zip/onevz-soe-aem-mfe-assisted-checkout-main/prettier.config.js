/* eslint-disable global-require */
module.exports = {
  ...require('@onevz-soe-mfe-base/prettier-config'),
};
