module.exports = {
  extends: ['@onevz-soe-mfe-base/commitlint-config'],
};
