# onevz-soe-cart-pojos
#naren testing
#naren testing2
This module is dedicated for soe cart pojos.
Pojos are also used by Checkout.  
 
