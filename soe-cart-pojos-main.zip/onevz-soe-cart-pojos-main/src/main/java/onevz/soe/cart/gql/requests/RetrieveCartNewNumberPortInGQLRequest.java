package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.CartHeader;
import onevz.soe.cart.gql.schema.LineDetailsNewNumberPortInCartVO;

@Data
public class RetrieveCartNewNumberPortInGQLRequest {
	private LineDetailsNewNumberPortInCartVO lineDetails;
	private CartHeader cartHeader;
}
