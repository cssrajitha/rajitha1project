package onevz.soe.cart.model.abandonCart;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import onevz.soe.cart.model.retrieveCart.CXPCartItemsVO;
import onevz.soe.cart.model.retrieveCart.CXPShippingVO;
import onevz.soe.cart.model.retrieveCart.LocalNumberPortability;
import onevz.soe.cart.model.retrieveCart.RefundExchangeInfo;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonInclude(Include.NON_NULL)
public class CXPDeviceInfo {

	private String deviceId;

	private String deviceIdType;

	private String deviceSku;

	private String capacity;

	private String modelName;

	private String brandName;

	private String operatingSystem;

	private String deviceUrl;

}
