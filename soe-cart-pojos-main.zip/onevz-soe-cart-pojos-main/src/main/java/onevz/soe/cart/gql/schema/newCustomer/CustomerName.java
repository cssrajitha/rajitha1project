package onevz.soe.cart.gql.schema.newCustomer;

import lombok.Data;

@Data
public class CustomerName {
	private String firstName;
	private String lastName;
}
