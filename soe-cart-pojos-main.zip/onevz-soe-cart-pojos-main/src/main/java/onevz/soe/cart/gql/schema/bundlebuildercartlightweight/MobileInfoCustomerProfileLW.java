package onevz.soe.cart.gql.schema.bundlebuildercartlightweight;

import lombok.Data;

import java.util.List;

@Data
public class MobileInfoCustomerProfileLW {

    private String mtn;
    private List<EquipmentInfoLW> equipmentInfos;
}
