package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude
public class Promotions {
	
	private String promotionType;
	private String promotionText;
	private String legalText;
	private String promotionPrice;
	
}
