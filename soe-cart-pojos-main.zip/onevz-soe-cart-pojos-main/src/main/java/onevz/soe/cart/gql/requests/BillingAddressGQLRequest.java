package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.billingAddress.LineDetails;

@Data
public class BillingAddressGQLRequest {

	private String cartId;	
	private LineDetails lineDetails;
	
}
