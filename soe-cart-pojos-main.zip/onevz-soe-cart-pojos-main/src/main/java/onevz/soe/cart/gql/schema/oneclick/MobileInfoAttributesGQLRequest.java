package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import onevz.wsclient.cxp.annotations.Query;

@Data
@JsonInclude
public class MobileInfoAttributesGQLRequest {
	
	private Boolean hasTabletPromo;
	@Query(namespaces = {"gql-attribute-optimized"})
	private Boolean modCompatible;
	@Query(namespaces = {"gql-attribute-optimized"})
	private Boolean upsellEligible;
	@Query(namespaces = {"gql-attribute-optimized"})
	private Boolean hllp2DiscountLoss;
	private String numberShareParent;
	@Query(namespaces = {"gql-attribute-optimized"})
	private Boolean numberShareTrunk;
	private Boolean hasJustKidsSmartFamilyParentFeature;

}
