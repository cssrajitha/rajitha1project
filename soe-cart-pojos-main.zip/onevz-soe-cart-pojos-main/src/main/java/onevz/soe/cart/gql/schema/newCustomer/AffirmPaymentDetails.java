package onevz.soe.cart.gql.schema.newCustomer;

import lombok.Data;

@Data
public class AffirmPaymentDetails {

	private String chargeId;
	private String successToken;
}
