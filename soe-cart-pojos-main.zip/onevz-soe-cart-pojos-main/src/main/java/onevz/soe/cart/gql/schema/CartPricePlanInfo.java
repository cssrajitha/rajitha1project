package onevz.soe.cart.gql.schema;

import lombok.Data;
import onevz.soe.orderprocess.model.checkoutdetails.PlanAttributes;

@Data
public class CartPricePlanInfo {
        private String planId;
        private String planDisplayName;
        private PlanAttributes planAttributes;
}
