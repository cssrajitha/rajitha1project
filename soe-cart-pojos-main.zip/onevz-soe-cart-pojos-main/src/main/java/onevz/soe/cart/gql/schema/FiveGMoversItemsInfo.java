package onevz.soe.cart.gql.schema;

import onevz.soe.cart.gql.schema.FiveGMoversCartItemVO;
import lombok.Data;

@Data
public class FiveGMoversItemsInfo {

    private FiveGMoversCartItemVO cartItems;
}
