package onevz.soe.cart.gql.schema.newCustomer;

import lombok.Data;

@Data
public class NBXInfo {
    private boolean isPreQualifiedNBX;
    private String syfOfferId;
    private String promotionalSPOCode;
    private String propositionMessage;
    private String propositionName;
    private String propositionId;
    private boolean isVZCCHolder;
    private String sessionId;
}

