package onevz.soe.cart.gql.schema.customerByMtn;

import lombok.Data;

@Data
public class MtnsList {

    private String mtn;
    private MobileInfoAttributes mobileInfoAttributes;
}
