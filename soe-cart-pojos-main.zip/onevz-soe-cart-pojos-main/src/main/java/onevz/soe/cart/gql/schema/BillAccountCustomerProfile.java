package onevz.soe.cart.gql.schema;

import java.util.List;

import lombok.Data;
import onevz.soe.orderprocess.model.checkoutdetails.BillAccountAttributes;

@Data
public class BillAccountCustomerProfile {

	private List<MobileInfoCustomerProfile> mtns;
	private AccountSharePlanInfo sharePlan;
	private String fiosEligibilityCategory;
	private CustomerBillingAddress accountAddress;
	private BillAccountAttributes accountAttributes;
	private CustomerAccountOffers accountOffers;
}
