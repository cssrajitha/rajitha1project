package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.model.retrieveURCForCart.MtnUpgradeReasonCodes;

@Data
public class RetrieveURCForCartGQLRequest {

	private MtnUpgradeReasonCodes mtnUpgradeReasonCodes;
}
