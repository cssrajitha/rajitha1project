package onevz.soe.cart.gql.schema.customerByMtnForParentLines;

import java.util.List;

import lombok.Data;

@Data
public class MtnsList {
	
	private String mtn;
	private MtnStatus mtnStatus;
	private List<EquipmentInfos> equipmentInfos;
	private MobileInfoAttributes mobileInfoAttributes;

}
