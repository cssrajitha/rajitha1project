package onevz.soe.cart.gql.schema.customerByMtnForParentLines;

import lombok.Data;

@Data
public class MobileInfoAttributes {

    private AccessRoles accessRoles;
}
