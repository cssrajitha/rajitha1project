package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.AccountLevelDiscount;
import onevz.soe.cart.gql.schema.VerizonUpToastMessage;
import onevz.soe.cart.gql.schema.*;
import onevz.soe.cart.model.retrieveCart.RefundOrderDetails;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.model.validateCart.CartValidationError;

import java.util.List;

@Data
public class RetrieveCartDigitalGQLRequest {

	private String cartId;
	private CartHeader cartHeader;
	private LineDetailsDigitalVO lineDetails;
	private GlobalPromotions globalPromotions;
	private AutoPayEnrollment autoPayEnrollment;
	private AccountLevelDiscount accountLevelDiscount;
	private CartValidationError cartValidationErrors;
	private ProgramEligibility programEligibility;
	private EcpdProfileInfo ecpdProfile;
}
