package onevz.soe.cart.gql.schema;

import lombok.Data;

/**
 * @author munjra4
 */
@Data
public class CartItemsLWVO {
    private CartItemLWVO cartItem;
}
