package onevz.soe.cart.gql.schema.deviceDetails;

import lombok.Data;

@Data
public class DeviceDetailsLineDetails {

	private DeviceDetailsLineInfo lineInfo;
}
