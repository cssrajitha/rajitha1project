package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class DevicePaymentPrice {

    private String promoBadgeMessage;

}
