package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class PretoPostInfo {
	
	private String newPreToPostIndicator;
	private PreToPostMtns newPreToPostMtns;

}
