package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class Spo {
    String productAttributeName;
    String productAttributeValue;
    String productAttributeDispOrd;
}
