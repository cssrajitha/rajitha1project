package onevz.soe.cart.gql.requests;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import net.minidev.json.annotate.JsonIgnore;
import onevz.soe.cart.gql.schema.AccountLevelDiscount;
import onevz.soe.cart.gql.schema.CartHeader;
import onevz.soe.cart.gql.schema.CustomerProfile;
import onevz.soe.cart.gql.schema.LineDetailsVO;
import onevz.soe.cart.gql.schema.OrderDetails;
import onevz.soe.cart.gql.schema.VendingCoordinates;
import onevz.soe.cart.gql.schema.VerizonUpToastMessage;
import onevz.soe.cart.gql.schema.newCustomer.CustomerProfileForNSE;
import onevz.soe.cart.gql.schema.newCustomer.NSECustomerDOBDetails;
import onevz.soe.cart.model.retrieveCart.AutoPayEnrollment;
import onevz.soe.cart.model.retrieveCart.EcpdProfileInfo;
import onevz.soe.cart.model.retrieveCart.GlobalPromotions;
import onevz.soe.cart.model.retrieveCart.ProgramEligibility;
import onevz.soe.cart.model.retrieveCart.Quote;
import onevz.soe.cart.model.retrieveCart.RefundOrderDetails;
import onevz.soe.cart.model.retrieveCart.SfoLossReferenceDataList;
import onevz.soe.cart.model.retrieveCart.SpoLossReferenceDataList;
import onevz.soe.cart.model.validateCart.CartValidationError;

@Data
public class RetrieveCartGQLRequest {

	private String cartId;
	private CartHeader cartHeader;
	private OrderDetails orderDetails;
	private LineDetailsVO lineDetails;
	private RefundOrderDetails refundOrderDetails;
	private Quote quote;
	private GlobalPromotions globalPromotions;
	private AutoPayEnrollment autoPayEnrollment;
	private AccountLevelDiscount accountLevelDiscount;
	private SfoLossReferenceDataList sfoLossReferenceDataList;
	private SpoLossReferenceDataList spoLossReferenceDataList;
	private VerizonUpToastMessage verizonUpToastMessage;
	private CartValidationError cartValidationErrors;
	private ProgramEligibility programEligibility;
	private EcpdProfileInfo ecpdProfile;
	private List<VendingCoordinates> vendingCoordinatesList;
	private CustomerProfile customerProfile;


	@JsonInclude(JsonInclude.Include.NON_NULL)
	@JsonProperty(value="customerProfileForNSE")
	private NSECustomerDOBDetails customerProfileForNSE;
}
