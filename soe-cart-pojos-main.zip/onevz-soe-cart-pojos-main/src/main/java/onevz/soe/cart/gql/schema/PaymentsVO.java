package onevz.soe.cart.gql.schema;

import lombok.Data;
import onevz.soe.cart.gql.schema.newCustomer.AffirmPaymentDetails;
import onevz.soe.cart.gql.schema.newCustomer.ApplePayPaymentDetailVo;
import onevz.soe.cart.gql.schema.newCustomer.PaypalPaymentDetails;
import onevz.soe.cart.model.retrieveCart.AcPayment;
import onevz.soe.cart.model.retrieveCart.CreditCardDetails;
import onevz.soe.cart.model.retrieveCart.GiftCardDetails;

@Data
public class PaymentsVO {

	private AcPayment acPayment;
	private CreditCardDetails creditCardDetails;
	private GiftCardDetails giftCardDetails;
	private String paymRegisterNum;
	private Double paymentAmount;
	private Integer paymentSequence;
	private String paymentType;
	private String status;
	private String locationCode;
	private Integer orderNumber;
	private PaypalPaymentDetails paypalPaymentDetails;
	private ApplePayPaymentDetailVo applePayPaymentDetails;
	private AffirmPaymentDetails affirmPayment;
}
