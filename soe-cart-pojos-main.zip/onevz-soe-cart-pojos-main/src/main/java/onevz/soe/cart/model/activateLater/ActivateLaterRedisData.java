package onevz.soe.cart.model.activateLater;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Schema(description = "save data in redis for activate later")
public class ActivateLaterRedisData {

    @Schema(description = "List of ActivateLaterRedisInfo objects")
    private List<ActivateLaterRedisInfo> redisData;

}
