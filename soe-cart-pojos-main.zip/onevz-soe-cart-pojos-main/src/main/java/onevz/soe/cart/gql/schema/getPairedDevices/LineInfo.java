package onevz.soe.cart.gql.schema.getPairedDevices;

import java.util.List;

import lombok.Data;


@Data
public class LineInfo {
	
	private ServiceInfo serviceInfo;
	private ItemsInfo[] itemsInfo;
	
}
