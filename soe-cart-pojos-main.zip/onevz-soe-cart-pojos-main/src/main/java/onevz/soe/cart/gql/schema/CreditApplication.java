package onevz.soe.cart.gql.schema;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CreditApplication {

	private String creditAdvisory;
	private Integer creditApplicationNum;
	private String creditApprovalStatus;
	private String creditStatusReason;
	@JsonProperty(value="internationalEligibility")
	private Boolean internationalEligibility;
	private String lineCreditClass;
	private String securityDepositAmount;
	private String fwaSecurityDepositAmount;
	private String serviceClass;
	//SALEONE-158 Flag to check creditApp is already edited or not
	@JsonProperty(value = "creditAppEdited")
	private Boolean creditAppEdited;
}
