package onevz.soe.cart.gql.schema.newCustomer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class NSECustomerDOBDetails {

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value = "customerAge")
    private String customerAge;

}
