package onevz.soe.cart.gql.schema;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import onevz.soe.cart.model.common.McsSubscription;
import onevz.soe.cart.model.marketplaceretrievecart.MarketPlaceProductOrderDetailsVO;
import onevz.soe.cart.model.retrieveCart.RefundTradeInDetail;
import onevz.soe.cart.model.retrieveCart.RcodTradeInDetail;
import onevz.soe.cart.model.submitbtloffers.BTLOfferRC;

@Data
public class LineDetailsVO {

	private String cartId;	
	private Integer numOfLines;
    private BTLOfferRC btlOffer;
	private LineInfo lineInfo;
	private LineInfo linesSavedForLater;
	private Integer numofLinesAAL;
	private Integer numofLinesEUP;	
	private String createTimestamp;
	private String lastUpdateTimestamp;
	private PaymentsVO payments;
	private Integer lineSeq;
	private Integer vlcactivePhoneCount;
	@JsonProperty(value="fivegOrderind")
	private Boolean fivegOrderind;
	@JsonProperty(value="aceOrderCreated")
	private Boolean aceOrderCreated;
	@JsonProperty(value="serviceLinesCreated")
	private Boolean serviceLinesCreated;
	@JsonProperty(value="aceItemsModified")
	private Boolean aceItemsModified;
	private String pastDueBalance;
	@JsonProperty(value="clnrOrderFlag")
	private Boolean clnrOrderFlag;
	@JsonProperty(value="broadbandInd")
	private Boolean broadbandInd;
	@JsonProperty(value="isPaperLessBilling")
	private String isPaperLessBilling;
	private String isAutoPayEnrolled;
	private String isAutoPayPaperLessDiscountEligible;
	private String isPaperLessEnrolled;
	private String totalEligibleAutoPayPaperLessDiscount;
	private String tabletJetpackDiscountMultiLineLoss;
	private McsSubscription acctMcsSubscription;
	private String spendingLimitAmountExceededBy;
	private NBSInfo nbsInfo;
	private Integer numOfAccessoryAndDeviceItemsInCart;
	private Double totalEdgeUpAmount;
	private Double totalEdgeBuyOutAmount;
	private TradeInDetail tradeInDetail;
	private Double totalDownPaymentAmt;
	private Integer numofAccessories;
	private NBSInfo subAccountNBSInfo;
	private NbsDetails subAccountNbsDetails;
	
	private List<CouponDetail> couponDetails;
	 
	
	//new
	private Integer numOfLinesWithDevices;
	private MdnStackingOffer mdnStackingOffer;
	private DiscountReference discountGainIndicators;
	private DiscountReference discountLossIndicators;
	private SubscriptionInfo subscriptionInfos;
	private Integer numofApprovedLines;
	private RefundTradeInDetail refundTradeInDetail;
	private RcodTradeInDetail rcodTradeInDetails;
	private List<RfexPayments> rfexPayments;

	@JsonProperty(value="bagFeeSku")
	private String bagFeeSku;

	@JsonProperty(value="bagTax")
	private Boolean bagTax;

	@Schema(description = "Details of the product order from the marketplace.")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	@JsonProperty("marketPlaceProductOrderDetails")
	private MarketPlaceProductOrderDetailsVO marketPlaceProductOrderDetails;
	
}
