package onevz.soe.cart.gql.schema.bundlebuildercartlightweight;

import lombok.Data;

@Data
public class EquipmentInfoLW {
    private DeviceInfoLW deviceInfo;
}
