package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import onevz.wsclient.cxp.annotations.Query;

@Data
@JsonInclude
public class DeviceTypeInfoGQLRequest {

	@Query(namespaces = {"gql-attribute-optimized"})
	private Boolean backupRouter4G;
	private Boolean device4G;
	@Query(namespaces = {"gql-attribute-optimized"})
	private Boolean device3G;
	private Boolean device5GA;
	private Boolean device5GE;
	@Query(namespaces = {"gql-attribute-optimized"})
	private Boolean antenna5G;
	private Boolean home5G;
	private String deviceType;
	private Boolean home4GLte;


}
