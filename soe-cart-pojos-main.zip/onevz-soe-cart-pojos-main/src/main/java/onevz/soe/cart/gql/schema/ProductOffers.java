package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class ProductOffers {
    private String spoId;
    private String price;
    private String description;
}
