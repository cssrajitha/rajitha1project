package onevz.soe.cart.gql.schema;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class AuthResult {

	private String type;
	@JsonProperty(value = "requested")
    private Boolean requested;
    private String status;
    private String reason;
    private String suspectedFraud;
    private String suspectedFraudReasons;
}
