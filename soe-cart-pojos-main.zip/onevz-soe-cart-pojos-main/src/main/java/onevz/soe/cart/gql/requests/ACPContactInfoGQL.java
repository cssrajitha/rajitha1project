package onevz.soe.cart.gql.requests;

import lombok.Data;

@Data
public class ACPContactInfoGQL {

    private String email;
    private String firstName;
    private String lastName;
    private String contactNumber;
    private ACPAddressGQL address;

}
