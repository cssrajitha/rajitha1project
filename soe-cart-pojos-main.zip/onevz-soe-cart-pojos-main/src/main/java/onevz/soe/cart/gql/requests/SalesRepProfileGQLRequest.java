package onevz.soe.cart.gql.requests;

import lombok.Data;

@Data
public class SalesRepProfileGQLRequest {
    private String salesRepEmpName;
    private boolean validSalesRepId;
}
