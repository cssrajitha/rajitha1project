package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class FiveGMoversCurrentDevice {

    FiveGMoversOldLteVoraEquipInfo oldLteVoraEquipInfo;
}
