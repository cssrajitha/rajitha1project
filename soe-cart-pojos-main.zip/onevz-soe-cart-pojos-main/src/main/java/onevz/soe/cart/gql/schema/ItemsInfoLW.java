package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class ItemsInfoLW {

	private String depletionType;
	private Integer itemCount;
	private Integer itemTabSeqNum;
	private CartItemPBBLW cartItems;
}
