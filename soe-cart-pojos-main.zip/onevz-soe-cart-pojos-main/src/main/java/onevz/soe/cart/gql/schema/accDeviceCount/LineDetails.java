package onevz.soe.cart.gql.schema.accDeviceCount;

import lombok.Data;

@Data
public class LineDetails {

	private Integer numOfAccessoryAndDeviceItemsInCart;
}
