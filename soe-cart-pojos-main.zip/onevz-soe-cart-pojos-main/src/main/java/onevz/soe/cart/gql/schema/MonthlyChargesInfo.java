package onevz.soe.cart.gql.schema;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.ChargeDetails;
import onevz.soe.cart.model.retrieveCart.MtnLevelChargeDetails;

@Data
public class MonthlyChargesInfo {

	private ChargeDetails accountLevelCharges;
    private AccountLevelTotal accountLevelTotal;
    private MtnLevelChargeDetails mtnLevelChargeDetails;

    private String tierFootnote1;
    private String tierFootnote2;
    private String tierFootnote3;
    private Double mtnLevelPlanChargeTotal;
    private ChargeDetails accountLevelOneTimeCharges;
}
