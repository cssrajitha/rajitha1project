package onevz.soe.cart.gql.schema;

import lombok.Data;

import java.util.List;
@Data
public class LineLevelOffers {
    private List<ProductOffers> productOffers;
}
