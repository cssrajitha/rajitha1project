package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.customerByMtn.MobileInfoAttributes;
import onevz.soe.cart.model.deviceSimValidation.ActiveAndPendingDeviceInfo;
import onevz.soe.cart.model.deviceSimValidation.DeviceSimValidationEquipmentInfos;
import onevz.soe.cart.model.deviceSimValidation.PricePlanInfo;

import java.util.List;
@Data
public class MtnsListForCustomer {
    private String mtn;
    private Boolean hasActiveAndPendingDevice;
    private ActiveAndPendingDeviceInfo activeAndPendingDeviceInfo;
    private List<DeviceSimValidationEquipmentInfos> equipmentInfos;
    private MobileInfoAttributes mobileInfoAttributes;
    private PricePlanInfo pricePlanInfo;
}
