package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class PaypalPaymentDetails {
    private String centinelOrderId;
    private String paypalPhone;
    private String paypalEmail;
}
