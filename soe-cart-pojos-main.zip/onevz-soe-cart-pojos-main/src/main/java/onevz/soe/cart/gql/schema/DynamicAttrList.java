package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class DynamicAttrList {
    private String attrId;
    private String value;
}