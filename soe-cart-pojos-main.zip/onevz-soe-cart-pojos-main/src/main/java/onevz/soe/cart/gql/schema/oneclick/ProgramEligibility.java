package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonProperty;

@lombok.Data
public class ProgramEligibility {

	@JsonProperty("RemainingBTAAmount")
	private String remainingBTAAmount;
	@JsonProperty("tradeInCreditEligible")
	private String tradeInCreditEligible;
}
