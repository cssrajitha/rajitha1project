package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class SubscriptionInfo {

	private String name;
	private String nextAction;
	private String nextActionReason;
	private String nextPrice;
	private String contentId;
	private String service;
	private String effectiveDate;
	private String endDate;
	private String perkDropDate;
}
