package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class RecycleTaxDetailType {

	private String recycleCreditAllocated;
	private String recycleStateInd;
	private String prodCode1;
	private String prodCode2;
	private String prodCode3;
	private String recycleCreditAllocatedForTax;
}
