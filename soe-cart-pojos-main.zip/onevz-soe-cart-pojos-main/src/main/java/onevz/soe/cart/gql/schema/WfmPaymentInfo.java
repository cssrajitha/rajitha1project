package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class WfmPaymentInfo {
    private CreditCardDetails creditCardDetails;
    private GiftCardDetails giftCardDetails;
    private PaypalPaymentDetails paypalPaymentDetails;
    private String directBillMDN;
    private String checkOrPONumber;
    private String paymentType;
}
