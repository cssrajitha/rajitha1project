package onevz.soe.cart.gql.schema.newCustomer;

import lombok.Data;

@Data
public class ApplePayPaymentDetailVo {

	private ApplePayAdditionalInfoVo applePayAdditionalInfo;
}
