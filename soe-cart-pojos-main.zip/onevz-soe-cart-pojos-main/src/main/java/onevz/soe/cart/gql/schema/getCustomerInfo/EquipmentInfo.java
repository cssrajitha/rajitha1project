package onevz.soe.cart.gql.schema.getCustomerInfo;

import lombok.Data;

@Data
public class EquipmentInfo {

    private DeviceInfo deviceInfo;
}
