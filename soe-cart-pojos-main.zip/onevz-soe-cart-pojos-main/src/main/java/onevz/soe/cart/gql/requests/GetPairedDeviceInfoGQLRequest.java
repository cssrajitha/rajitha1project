package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.getPairedDevices.LineDetails;
@Data
public class GetPairedDeviceInfoGQLRequest {

	private LineDetails lineDetails;
}
