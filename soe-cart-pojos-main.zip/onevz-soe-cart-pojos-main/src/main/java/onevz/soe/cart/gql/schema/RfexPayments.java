package onevz.soe.cart.gql.schema;

import lombok.Data;


@Data
public class RfexPayments {

	private String paymentSeqNum;
	private String modeOfPay;
	private String cardNumber;
	private String cardType;
	
}

