package onevz.soe.cart.gql.schema.newCustomer;

import lombok.Data;
import onevz.soe.cart.gql.schema.CartItemVO;
import onevz.soe.cart.gql.schema.newCustomer.Shipping;
import onevz.soe.cart.model.retrieveCart.LocalNumberPortability;

@Data
public class ItemsInfo {
	
	private String depletionType;
	private String attention;
	private Shipping shipping;
	private CartItemVO cartItems;
	

}
