package onevz.soe.cart.gql.schema.agreementInfo;

import lombok.Data;


@Data
public class OrderList {
	
	private Integer orderNumber;
	
}
