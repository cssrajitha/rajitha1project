package onevz.soe.cart.gql.schema.newCustomer;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.PromoBadgeMessages;

@Data
public class SbdOffer {

	private String barcodeGroup;
	private String barcodeId;
	private Integer bicBogoSequence;
	private Integer bicBogoTargetItemSequence;
	private String bicBogoTargetLocationCode;
	private String bicBogoTargetMdn;
	private String bicBogoTargetMld;
	private String bicBogoType;
	private Integer bicNoOfOccurences;
	private String description;
	private String discAmt;
	private String discPrcnt;
	private Integer discountReason;
	private String droppedLocaton;
	private Integer droppedOrderNum;
	private String existingOfferApplyInd;
	private Boolean isTargetComboOrBogoOT;
	private String mobileNumber;
	private Integer multiLineSeqNumber;
	private String occCode;
	private String offerId;
	private String offerSubmitRequiredInd;
	private Integer sbdDelay;
	private Integer targetOrderNum;
	private BigDecimal discountedRetailPrice;
	private BigDecimal itemMonthlyDiscountedPrice;
	private BigDecimal itemMonthlyDiscount;
	private BigDecimal itemMonthlyRetailPrice;
	private List<PromoBadgeMessages> promoBadges;
	private String bicBogoTargetContractInd;
	private String contractInd;
	private String droppedTradeLocatonCode;
	private BigInteger droppedTradeOrderNum;
	private String offerBuyEndDate;
	private String rewardType;
	private String redemptionCode;
	private String promoType;
	//private Boolean isStrategicOffer;
	private String offerSubType;
	private String offerFor;
}