package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class DiscountedElements {

	private String actualCost;
	private String elementId;
	private String elementType;
	private String finalCost;
	private DiscountsDetail discountsDetail;
	private IncludedDiscounts includedDiscounts;
	private IncludedDiscounts eligibleIncludedDiscounts;
}
