package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.numberShare.LineDetails;

@Data
public class NumberShareGQLRequest {

	private String cartId;	
	private LineDetails lineDetails;
	
}
