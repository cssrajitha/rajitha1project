package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude
public class MobileInfoAttributes {
	
	private Boolean hasTabletPromo;
	private Boolean modCompatible;
	private Boolean upsellEligible;
	private Boolean hllp2DiscountLoss;
	private String numberShareParent;
	private Boolean numberShareTrunk;
	private Boolean hasJustKidsSmartFamilyParentFeature;

}
