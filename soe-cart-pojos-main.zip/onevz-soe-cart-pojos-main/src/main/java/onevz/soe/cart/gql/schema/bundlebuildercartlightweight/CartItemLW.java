package onevz.soe.cart.gql.schema.bundlebuildercartlightweight;

import lombok.Data;
import onevz.soe.cart.gql.schema.PromoHubOfferNode;
import onevz.soe.cart.model.retrieveCart.ImageUrlMap;

@Data
public class CartItemLW {
    private String itemCode;
    private String sorId;
    private String skuId;
    private String cartItemType;
    private String mobileNumber;
    private String description;
    private String capacity;
    private Integer qty;
    private String priceType;
    private String itemPriceType;
    private int itemSeqNum;
    private ImageUrlMap imageUrlMap;
    private SEDOfferListTypeLW sedOfferList;
    private PromoHubOfferNode promoHubOfferList;
    private String depletionType;
    private String manufacturer;
    private String operatingSystem;
    private String sorDeviceCategory;
    private String productId;
    private String deviceDisplayName;
    private String canonicalUrl;
    private InventoryLW inventory;
    private ColorLW color;
    private String iconicPhone;
}
