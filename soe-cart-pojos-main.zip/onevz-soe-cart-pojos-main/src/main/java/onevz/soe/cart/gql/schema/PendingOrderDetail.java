package onevz.soe.cart.gql.schema;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class PendingOrderDetail {

	@JsonProperty(value = "isCancellable")
	private Boolean isCancellable;
	
	private String pendingOrderNumber;
}
