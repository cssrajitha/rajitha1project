package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import onevz.wsclient.cxp.annotations.Query;

@Data
@JsonInclude
public class TwoYearContractGQLRequest {

	@Query(namespaces = {"gql-attribute-optimized"})
	private String contractTermText;
	private String daysPercentage;
	@Query(namespaces = {"gql-attribute-optimized"})
	private String downpaymentPercentageFor2D;
	private String endDate;
	private String monthsRemainingText;
	private Integer numberOfDays;
	private String description;
	private String daysRemainingText;

}
