package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class UpgradeEligibilityInfo {

	private String upgradeEligibilityDate;
    private Boolean upgradeEligible;
    private TwoYearContract twoYearContract;
    private PendingOrderDetail pendingOrderDetail;
}
