package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class SfoGainReferenceData {

	private String id;
	private String name;
	private String title;
	private String titleMobile;
	private String shortDescription;
	private String longDescription;
}
