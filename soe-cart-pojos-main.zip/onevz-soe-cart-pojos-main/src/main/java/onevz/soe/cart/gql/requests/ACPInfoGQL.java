package onevz.soe.cart.gql.requests;

import lombok.Data;

@Data
public class ACPInfoGQL {

    private String enrollmentNumber;
    private String nladSubscriberId;
    private  String benefit;
    private ACPCustomerInfoGQL customerInfo;

}
