package onevz.soe.cart.gql.schema;

import java.math.BigInteger;

import lombok.Data;

@Data
public class CartHeader {

	private String sourceSystem;
	private String cartId;
	private String emailAddress;
	private String fullAccountNumber;
	private String status;
	private String lockStatus;
	private String lockingSystem;
	private String lastAccessSystem;
	private String createTimestamp;
	private String lastUpdateTimestamp;
	private String businessName;
	private String shellAccountNumber;
	private ECPDInfo ecpdInfo;
	private String userId;
	private String cartCreator;
	private String cartCreatorChannelId;
	private String cartCreatorOrderLocationCode;
	private String cartCreatorSalesRepId;
	private String caseId;
	private String commonCartId;
	private String visionCustomerType;
	private String chatId;
	private Boolean maverickLocation;
    private String preConfiguredCartType;
    private String preConfiguredCartTypeDuringAddDevice;

    private Boolean isCoreRep;
    //new fields
    private String E2erequestid;
    private String winBackAccountNumber;
    private String cartCreatorZipCode;
    private String fpffifId;
    private String referralSaleRepId;
    private String ecpdToken;
    private String adobeId;
    private String vendorId;
    private String referralVendorId;
    //private String accountPin;
    private String d2dFlag;
    private BigInteger ani;
    private String ivrCallerId;
    private String insuranceEligibilityFailureInd;
    private Boolean isERTRep;
    private String repRole;
    private String locationType;
    //XBOX Retail Ordering Changes
  	private String cartType;
	private String redemptionCode;
	private String maid;
	//Act183-505 BestBuy
	private String locationSubType;
}
