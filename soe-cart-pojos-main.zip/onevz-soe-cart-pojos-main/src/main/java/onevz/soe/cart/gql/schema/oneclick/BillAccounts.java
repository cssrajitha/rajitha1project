package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;


@Data
@JsonInclude
public class BillAccounts {
	private String activeMtnCount;
	/*private AccountLevelChangeEligibility accountLevelChangeEligibility;
	private AccountAttributes accountAttributes;*/
	private PaymentInfo paymentInfo;
	private List<Mtn> mtns = null;
	/*private ProgramEligibility programEligibility;*/
	
}