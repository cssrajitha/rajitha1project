package onevz.soe.cart.gql.schema.customerByMtn;

import lombok.Data;

@Data
public class AccountAddress {

    private String zipCode;
}
