package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class GiftCardDetails {
    private String giftCardExpDate;
    private String giftCardPIN;
    private String paymentAccountNumber;
    private Double cardBalanceAmount;
    private String cardBillingZip;
    private String type;
    private String lineID;
}
