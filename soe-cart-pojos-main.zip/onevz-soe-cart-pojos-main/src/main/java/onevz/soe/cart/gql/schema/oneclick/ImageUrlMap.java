package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ImageUrlMap {

	@JsonInclude(Include.NON_NULL)
	private String defaultImage;

	@JsonInclude(Include.NON_NULL)
	private String largeImage;

	@JsonInclude(Include.NON_NULL)
	private String mediumImage;

	@JsonInclude(Include.NON_NULL)
	private String miniImage;

	@JsonInclude(Include.NON_NULL)
	private String thumbImage;
}
