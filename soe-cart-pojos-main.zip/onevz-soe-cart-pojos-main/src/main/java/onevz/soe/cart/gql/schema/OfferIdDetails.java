package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class OfferIdDetails {

	private String offerId;
	private RedemptionId redemptionIds;
	private String barCode;
	private String promoCode;
}
