package onevz.soe.cart.gql.schema.getCustomerInfo;

import lombok.Data;

@Data
public class DeviceInfo {

    private String deviceId;

    private String modelName;
}
