package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude
public class MtnGQLWithoutRTDRequest {
	private String mtnHashCode;
	private PromotionsGQLRequest promotions;
	private String mtn;
//	private String encryptedMtn;
	private String nickName;
	private EquipmentInfoGQLRequest equipmentInfos;
	private PricePlanInfoGQLRequest pricePlanInfo;
	private MobileInfoAttributesGQLRequest mobileInfoAttributes;
	private InstallmentLoansGQLRequest installmentLoans;
	private InstallmentLoanSummaryGQLRequest installmentLoanSummary;
	private UpgradeEligibilityInfoGQLRequest equipmentUpgradeEligibility;
	private LineLevelChangeEligibilityGQLRequest lineLevelChangeEligibility;
	private String deviceMtnIndicator;
	private MtnStatusRequest mtnStatus;
	private String deviceNickName;
}
