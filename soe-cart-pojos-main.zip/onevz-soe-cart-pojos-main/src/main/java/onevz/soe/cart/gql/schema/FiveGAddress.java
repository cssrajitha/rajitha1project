package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class FiveGAddress {

	private String firmName;
	private String apartmentNo;
	private String type;
	private String streetNumber;
	private String streetName;
	private String addressLine2;
	private String addressLine1;
	private String poBoxNo;
	private String ruralRouteNo;
	private String ruralDelNo;
	private String city;
	private String state;
	private String zipCode;
	private String zipCode4;
	private String countryCode;
	private String fipsCode;
	private String firstName;
	private String lastName;	
	private String emailId;
	private String phoneNumber;
	private String attention;
	private String streetType;
	private String streetDirection;
	private Integer floor;
	private String eventCorrelationId;
	//private String launchType;
	private String descriptorInfo;
	private String buildingId;
	private String latitude;
	private String longitude;
	private String techRecommendation;

}
