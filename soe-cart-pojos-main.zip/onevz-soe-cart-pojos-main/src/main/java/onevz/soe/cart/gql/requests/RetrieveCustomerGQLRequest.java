package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.model.retrieveCustomer.BillAccount;
import onevz.soe.cart.model.retrieveCustomer.EcpdProfile;

import java.util.List;

/**
 * The Class RetrieveCustomerGQLRequest.
 */
@Data
public class RetrieveCustomerGQLRequest {
	
	/** The bill accounts. */
	private List<BillAccount> billAccounts;
	private EcpdProfile ecpdProfile;
}
