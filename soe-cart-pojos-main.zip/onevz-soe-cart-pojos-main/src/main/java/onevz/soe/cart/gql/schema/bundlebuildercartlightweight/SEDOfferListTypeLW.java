package onevz.soe.cart.gql.schema.bundlebuildercartlightweight;

import lombok.Data;
import java.util.List;

@Data
public class SEDOfferListTypeLW {
    private List<SEDOfferTypeLW> sedOffer;
    private Integer count;
}
