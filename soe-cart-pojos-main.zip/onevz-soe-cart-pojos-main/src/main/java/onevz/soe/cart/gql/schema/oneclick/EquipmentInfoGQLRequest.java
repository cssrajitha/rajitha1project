package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude
public class EquipmentInfoGQLRequest {
	 private DeviceInfoGQLRequest deviceInfo;
	 private SimInfoGQLRequest simInfo;

}
