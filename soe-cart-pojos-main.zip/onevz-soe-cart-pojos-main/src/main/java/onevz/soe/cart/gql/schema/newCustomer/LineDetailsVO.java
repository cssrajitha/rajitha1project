package onevz.soe.cart.gql.schema.newCustomer;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import onevz.soe.cart.gql.schema.CouponDetail;
import onevz.soe.cart.gql.schema.newCustomer.LineInfo;
import onevz.soe.cart.gql.schema.NBSInfo;
import onevz.soe.cart.gql.schema.PaymentsVO;
import onevz.soe.cart.gql.schema.TradeInDetail;
import onevz.soe.cart.model.common.McsSubscription;
import onevz.soe.cart.model.retrieveCart.FnfDetails;

@Data
public class LineDetailsVO {
	private PlanDiscount planDiscount;
	private FnfDetails fnfDetails;
	private LineInfo lineInfo;
	private Integer numOfAccessoryAndDeviceItemsInCart;
	private TradeInDetail tradeInDetail;
	private Double totalDownPaymentAmt;
	private Integer numofAccessories;
	private NBSInfo subAccountNBSInfo;
	private PaymentsVO payments;
	private Integer lineSeq;
	private McsSubscription acctMcsSubscription;
	private Double totalEdgeUpAmount;
	private Double totalEdgeBuyOutAmount;
	@JsonProperty(value="fivegOrderind")
	private Boolean fivegOrderind;
	private String isAutoPayEnrolled;
	private String isAutoPayPaperLessDiscountEligible;
	private String isPaperLessEnrolled;
	private String totalEligibleAutoPayPaperLessDiscount;
	private NBSInfo nbsInfo;
	private Integer numOfLines;
	private CouponDetail couponDetails;
}
