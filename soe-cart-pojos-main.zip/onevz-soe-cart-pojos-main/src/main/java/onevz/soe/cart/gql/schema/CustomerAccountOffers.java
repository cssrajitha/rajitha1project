package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class CustomerAccountOffers {
    private LineLevelOffers lineLevelOffers;
}
