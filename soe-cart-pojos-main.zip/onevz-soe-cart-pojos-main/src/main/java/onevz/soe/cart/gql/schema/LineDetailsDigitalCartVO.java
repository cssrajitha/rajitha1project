package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class LineDetailsDigitalCartVO {

	private LineDigitalCartInfo lineInfo;
	private TradeInDetail tradeInDetail;
}
