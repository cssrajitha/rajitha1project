package onevz.soe.cart.gql.schema.newCustomer;

import lombok.Data;

@Data
public class ContactInfo {
	private String email;
	private String firstName;
	private String lastName;
	private String contactNumber;
    private BillingAddress billingAddress;
}
