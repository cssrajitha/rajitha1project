package onevz.soe.cart.gql.schema.oneclick;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class DeviceListCartItems {
	private List<CartItem> cartItem;
	
	public DeviceListCartItems(){
		this.cartItem=new ArrayList<>();
	}

}
