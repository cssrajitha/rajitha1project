package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude
public class ContextInfo {
	
	private String callReason;
	private String processStep;
	private String processStepTrail;

}
