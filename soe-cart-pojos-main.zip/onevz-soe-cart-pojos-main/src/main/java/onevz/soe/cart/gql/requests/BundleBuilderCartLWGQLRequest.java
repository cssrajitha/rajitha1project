package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.*;
import onevz.soe.cart.gql.schema.bundlebuildercartlightweight.CustomerProfileLW;
import onevz.soe.orderprocess.model.checkoutdetails.LineDetailsLW;
import onevz.soe.cart.gql.schema.bundlebuildercartlightweight.OrderDetailsLW;

@Data
public class BundleBuilderCartLWGQLRequest {

    private String cartId;
    private CartHeader cartHeader;
    private LineDetailsLW lineDetails;
    private CustomerProfileLW customerProfile;
    private OrderDetailsLW orderDetails;

}
