package onevz.soe.cart.gql.schema.customerByMtn;

import lombok.Data;

@Data
public class MobileInfoAttributes {

    private AccessRole accessRoles;
}
