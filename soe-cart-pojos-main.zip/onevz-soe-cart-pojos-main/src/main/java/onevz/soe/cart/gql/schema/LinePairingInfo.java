package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class LinePairingInfo {
	
	private String newPairedPhone;
	private String currentPairedPhone;
	private String benefitPairType;
	
	private String grantorLineItem;
	private String granteeLineItem;
	

}
