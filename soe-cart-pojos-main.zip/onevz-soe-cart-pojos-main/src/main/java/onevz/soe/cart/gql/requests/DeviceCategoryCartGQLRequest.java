package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.CartHeader;
import onevz.soe.orderprocess.model.checkoutdetails.LineDetailsLW;

@Data
public class DeviceCategoryCartGQLRequest {

    private String cartId;
    private DeviceCategoryLineDetails lineDetails;

}
