package onevz.soe.cart.gql.schema.customerByMtnForParentLines;

import java.util.List;

import lombok.Data;


@Data
public class BillAccount {
	private List<MtnsList> mtns;

}
