package onevz.soe.cart.gql.schema;


import lombok.Data;

@Data
public class RetrievePaymentsVO {

    private String paymentType;
}
