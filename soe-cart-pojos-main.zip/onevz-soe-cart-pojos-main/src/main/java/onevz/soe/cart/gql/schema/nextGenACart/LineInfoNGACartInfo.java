package onevz.soe.cart.gql.schema.nextGenACart;

import lombok.Data;

@Data
public class LineInfoNGACartInfo {
	private String lineActivityType;
	private ServiceInfoNGACart serviceInfo;
	private ItemsNGACartInfo itemsInfo;
}
