package onevz.soe.cart.gql.schema.agreementInfo;

import lombok.Data;


@Data
public class LineDetails {
	
	private LineInfo lineInfo;
	
}
