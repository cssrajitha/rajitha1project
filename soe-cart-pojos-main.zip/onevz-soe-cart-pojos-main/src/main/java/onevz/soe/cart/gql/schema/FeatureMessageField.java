package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class FeatureMessageField {

    private String name;

    private String value;
}
