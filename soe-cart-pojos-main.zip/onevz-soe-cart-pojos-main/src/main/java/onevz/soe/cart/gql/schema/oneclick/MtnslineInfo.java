package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties
public class MtnslineInfo {
	
	private String lineActivityType;
	private MobileNumberMtnDetails mtnDetails;
	private List<DeviceListItemInfo> itemsInfo;
	private String mobileNumber;
	//private SecondNumber secondNumber;
}
