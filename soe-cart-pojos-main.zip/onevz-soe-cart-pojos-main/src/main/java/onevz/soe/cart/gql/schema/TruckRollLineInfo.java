package onevz.soe.cart.gql.schema;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import onevz.soe.cart.model.common.BvoOffers;
import onevz.soe.cart.model.common.Propositions;
import onevz.soe.cart.model.retrieveCart.*;

import java.util.List;

@Data
public class TruckRollLineInfo {

	private TruckRollServiceInfo serviceInfo;
}
