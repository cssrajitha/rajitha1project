package onevz.soe.cart.gql.schema.bundlebuildercartlightweight;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.ALWAYS)
public class DeviceInfoLW {
    private String productName;
    private String modelName;
}
