package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude
public class PricePlanInfoGQLRequest {
	
	private String planId;
	private String planCategoryName;
	private String planSkuName;
	private PlanAttributesGQLRequest planAttributes;

//    private AccessCharge accessCharge;



}
