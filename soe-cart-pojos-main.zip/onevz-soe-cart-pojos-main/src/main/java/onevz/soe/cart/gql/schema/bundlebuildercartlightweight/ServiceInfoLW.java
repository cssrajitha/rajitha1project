package onevz.soe.cart.gql.schema.bundlebuildercartlightweight;

import lombok.Data;

@Data
public class ServiceInfoLW {
    private String mtn;
    private SbdOfferLW sbdOffer;
}
