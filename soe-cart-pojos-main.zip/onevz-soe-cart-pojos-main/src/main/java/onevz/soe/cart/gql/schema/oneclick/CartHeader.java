package onevz.soe.cart.gql.schema.oneclick;

import lombok.Data;

@Data
public class CartHeader {

	private String caseId;
	private String cartCreator;
	private String lastUpdateTimestamp;
	private String fullAccountNumber;
	private String cartId;
    private String prePaidAccountNumber;
    private String sourceSystem;
    

}
