package onevz.soe.cart.model.abandonCart;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.*;
import onevz.soe.cart.gql.schema.DevicePaymentPrice;
import onevz.soe.cart.gql.schema.FullRetailPrice;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonInclude(Include.NON_NULL)
public class CXPRetrieveLatestPlan {

  private String pricePlanDisplayName;

  private Double planPrice;
  private String planId;
}
