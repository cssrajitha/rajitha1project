package onevz.soe.cart.gql.requests;


import lombok.Data;
import onevz.soe.cart.gql.schema.RetrieveMiniCartOrderDetails;
import onevz.soe.cart.gql.schema.newCustomer.RetrieveMiniCartLineDetails;

@Data
public class RetrieveMiniCartGQLRequest {

    private String cartId;
    private RetrieveMiniCartOrderDetails orderDetails;
    private RetrieveMiniCartLineDetails lineDetails;

}
