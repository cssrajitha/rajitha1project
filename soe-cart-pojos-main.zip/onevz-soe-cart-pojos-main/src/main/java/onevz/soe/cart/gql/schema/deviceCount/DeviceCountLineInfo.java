package onevz.soe.cart.gql.schema.deviceCount;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.BundleAccessory;

@Data
public class DeviceCountLineInfo {

	private DeviceCountItemsInfo itemsInfo;

	private String lineActivityType;
}
