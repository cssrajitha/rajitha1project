package onevz.soe.cart.gql.requests;

import lombok.Data;

@Data
public class ItemsInfoGQL {
	
	private String depletionType;
	private CartItemsGQL cartItems;
	private ShippingGQL shipping;

}