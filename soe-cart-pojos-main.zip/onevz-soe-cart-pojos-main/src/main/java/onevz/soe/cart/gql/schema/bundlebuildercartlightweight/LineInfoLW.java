package onevz.soe.cart.gql.schema.bundlebuildercartlightweight;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.ArrayList;

@Data
public class LineInfoLW {
    private Integer multiLineSeqNumber;
    private String lineActivityType;
    private String mobileNumber;
    private String lineNumber;
    private int lineIdentifier;
    private int LineSortingNumber;
    private String DummyMtnForDomain;
    private String DeviceCategoryName;
    private MTNDetailsLW MtnDetails;
    private String lineCreator;
    private String promoType;
    private String deviceTypeSelected;
    private String selectedSedOfferId;
    private String promotionID;
    @JsonProperty(value = "isStrategicOffer")
    private Boolean isStrategicOffer;
    private ServiceInfoLW serviceInfo;
    private ArrayList<ItemsInfoLW> itemsInfo;
}
