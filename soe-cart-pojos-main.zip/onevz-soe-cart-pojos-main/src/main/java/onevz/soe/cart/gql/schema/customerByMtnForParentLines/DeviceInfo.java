package onevz.soe.cart.gql.schema.customerByMtnForParentLines;

import lombok.Data;

@Data
public class DeviceInfo {
	
	private String modelName;
	private Category category;

}
