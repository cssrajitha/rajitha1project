package onevz.soe.cart.gql.schema.newCustomer;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import onevz.soe.cart.gql.schema.NumbershareInfo;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntent;
import onevz.soe.cart.model.common.SecondNumber;
import onevz.soe.cart.model.retrieveCart.BundleAccessory;
import onevz.soe.cart.model.retrieveCart.InstallmentInfo;
import onevz.soe.cart.model.retrieveCart.MtnDetails;
import onevz.soe.cart.model.retrieveCart.OneTimeCharges;

@Data
public class LineInfo {
	
	private Integer multiLineSeqNumber;
	private String lineActivityType;
	private Double totalDueToday;
	private Double totalDueTodayWithoutTax;
	private Double totalDueMonthly;
	private String mobileNumber;
	private Boolean showGlobalChoiceOffer;
	private ServiceInfo serviceInfo;
	private ItemsInfo itemsInfo;
	private String lineNumber;
	private OneTimeCharges oneTimeCharges;
	private MtnDetails mtnDetails;
	private String deviceTypeSelected;
	private SecondNumber secondNumber;
	@JsonProperty(value="preOrBackOrder")
	private Boolean preOrBackOrder;
	@JsonProperty(value="ispuItem")
	private Boolean ispuItem;
	@JsonProperty(value="ispuItemBYOD")
	private Boolean ispuItemBYOD;
	@JsonProperty(value = "isModConnected")
	private Boolean isModConnected;
	@JsonProperty(value = "modDevice")
	private Boolean modDevice;
	@JsonProperty(value = "byodCapable")
	private Boolean byodCapable;
	private String nickName;
	private String currentPlanType;
	@JsonProperty(value = "portinMtnAssignment")
	private Boolean portinMtnAssignment;
	private InstallmentInfo installmentInfo;
	private NumbershareInfo numbershareInfo;
	private double totalDueMonthlyBeforeCredit;
	private String totalDueTodayWithoutAccessory;
	private String securityDepositAmount;

	@JsonProperty(value = "customerProvidedMtn")
	private String customerProvidedMtn;

	@JsonProperty(value = "customerProvidedMtnType")
	private String customerProvidedMtnType;
	 

	private String securityDepositWaiveCode;
	@JsonProperty(value = "ispuDownPaymentAdjstRequired")
	private Boolean ispuDownPaymentAdjstRequired;
	@JsonProperty(value = "ispuDownPaymentAmount")
	private Float ispuDownPaymentAmount;
	
	@JsonProperty(value = "protectionNotRequired")
	private boolean protectionNotRequired;

	private String totalSurchargeAmount;
	private String accountOwner;
	private List<BundleAccessory> bundleAccessoryInfo;
	@JsonProperty(value = "promoIntent")
	private AddPromoIntent promoIntent;

	@JsonProperty(value = "totalPriceOfPlanAndPerks")
	private String totalPriceOfPlanAndPerks;
	
	private String deviceCategoryName;
    private String totalPlanPerksWithAutopay;
	private Boolean payOffYourDevice;
	private PayOffDeviceInfo payOffDeviceInfo;

	@JsonProperty(value = "totalPriceOfPerksAndProtection")
	private String totalPriceOfPerksAndProtection;
}
