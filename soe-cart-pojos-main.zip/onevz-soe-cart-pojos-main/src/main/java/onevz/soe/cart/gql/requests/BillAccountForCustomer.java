package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.customerByMtn.AccountAddress;

import java.util.List;

@Data
public class BillAccountForCustomer {
    private AccountAddress accountAddress;
    private List<MtnsListForCustomer> mtns;
}
