package onevz.soe.cart.gql.requests;

import onevz.soe.cart.gql.schema.AccountLevelDiscount;
import onevz.soe.cart.gql.schema.CartHeader;
import onevz.soe.cart.gql.schema.CustomerProfile;
import onevz.soe.cart.gql.schema.VendingCoordinates;
import onevz.soe.cart.model.retrieve5GCart.*;
import onevz.soe.cart.model.retrieveCart.GlobalPromotions;
import onevz.soe.cart.model.retrieveCart.Quote;
import onevz.soe.cart.model.retrieveCart.RefundOrderDetails;

import java.util.List;

public class FiveGMoversRetrieveCartGQLRequest {

    private String cartId;
    private CartHeader cartHeader;
    private FiveGOrderDetails orderDetails;
    private FiveGMoversLineDetailsVO lineDetails;
    private CustomerProfile customerProfile;
}
