package onevz.soe.cart.gql.schema.customerByMtnList;

import lombok.Data;

@Data
public class TwoYearContract {

	private String endDate;
    private String monthsRemainingText;
}
