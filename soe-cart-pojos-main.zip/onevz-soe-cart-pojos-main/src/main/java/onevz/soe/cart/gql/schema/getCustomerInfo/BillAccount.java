package onevz.soe.cart.gql.schema.getCustomerInfo;

import lombok.Data;

import java.util.List;

@Data
public class BillAccount {

    private AccountAddress accountAddress;

    private List<Mtn> mtns;
}
