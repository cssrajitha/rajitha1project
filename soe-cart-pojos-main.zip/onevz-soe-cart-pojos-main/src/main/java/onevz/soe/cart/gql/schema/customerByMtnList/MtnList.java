package onevz.soe.cart.gql.schema.customerByMtnList;

import lombok.Data;

@Data
public class MtnList {

	private String mtn;
    private String inServiceDate;
    private String lengthOfServiceText;
    private MtnStatus mtnStatus;
    private EquipmentUpgradeEligibility equipmentUpgradeEligibility; 
    private InstallmentLoan installmentLoans;
}
