package onevz.soe.cart.gql.schema;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.BillSummary;

@Data
public class BillAccount {

	private BillSummary billSummary;
    private NBS nbs;
    private String billAccountNo;

}
