package onevz.soe.cart.gql.schema;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import onevz.soe.cart.model.common.McsSubscription;
import onevz.soe.cart.model.retrieveCart.RefundTradeInDetail;

@Data
public class LineDetailsDigitalVO {

	private LineDigitalInfo lineInfo;
	private Integer numofLinesAAL;
	private Integer numofLinesEUP;	
	private String createTimestamp;
	private String lastUpdateTimestamp;
	private Integer lineSeq;
	@JsonProperty(value="fivegOrderind")
	private Boolean fivegOrderind;
	@JsonProperty(value="aceOrderCreated")
	private Boolean aceOrderCreated;
	@JsonProperty(value="serviceLinesCreated")
	private Boolean serviceLinesCreated;
	private String pastDueBalance;
	@JsonProperty(value="broadbandInd")
	private Boolean broadbandInd;
	@JsonProperty(value="isPaperLessBilling")
	private String isPaperLessBilling;
	private String isAutoPayEnrolled;
	private String isAutoPayPaperLessDiscountEligible;
	private String isPaperLessEnrolled;
	private String totalEligibleAutoPayPaperLessDiscount;
	private McsSubscription acctMcsSubscription;
	private Integer numOfAccessoryAndDeviceItemsInCart;
	private Double totalDownPaymentAmt;
	private Integer numofAccessories;
	//new
	private Integer numOfLinesWithDevices;
	private SubscriptionInfo subscriptionInfos;
	private Integer numofApprovedLines;

}
