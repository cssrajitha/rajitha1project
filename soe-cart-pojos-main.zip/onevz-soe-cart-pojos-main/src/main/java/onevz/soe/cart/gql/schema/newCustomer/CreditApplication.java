package onevz.soe.cart.gql.schema.newCustomer;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CreditApplication {
	
	
	private String creditApprovalStatus;
	private String securityDepositAmount;
	private String fwaSecurityDepositAmount;
	private String serviceClass;
	private String lineCreditClass;
	
	

}
