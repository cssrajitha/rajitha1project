package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.deviceDetails.DeviceDetailsLineDetails;

@Data
public class DeviceDetailsGQLRequest {

	private String cartId;
	private DeviceDetailsLineDetails lineDetails;
}
