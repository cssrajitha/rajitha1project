package onevz.soe.cart.gql.schema;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import onevz.soe.cart.model.retrieveCart.*;
import java.math.BigInteger;

@Data
public class RetrieveMiniCart {
    private String itemCode;
    private double totalPriceWithDiscount;
    private String itemPriceAfterVZDollar;
    private String sorId;
    private String skuId;
    private String cartItemType;
    private String mobileNumber;
    private String minNumber;
    private String accountNumber;
    private String accountSubNumber;
    private String billingSystem;
    private String description;
    private String capacity;
    private Integer qty;
    private Double deviceDueMonthly;
    private Double deviceDueToday;
    private int bundleSeqNum;
    private String itemPrice;
    private String deviceId;
    private String dipIndicator;
    private Double discountedPercentage;
    private Double discountedPrice;
    private String isDropshipItem;
    private ImageUrlMap imageUrlMap;
    private String priceType;
    private Double catalogPrice;
    private ItemColorVO color;
    private Double unitTaxBasedPrice;
    private Double itemNrpPrice;
    private Double itemCost;
    private String upgradeReasonCode;
    private String upgradeReasonDesc;
    private String itemPriceType;
    private CartItemDiscount discounts;
    private String availableReasonCode;
    private String dropShipVendorToken;
    @JsonProperty(value = "isCustomerProvidedSIM")
    private Boolean isCustomerProvidedSIM;
    private int itemSeqNum;
    private int year;
    private String macAddress;
    private String sellerPrice;
    private String edgeDeviceCap;
    private String productId;
    private String eSIM;
    @JsonProperty(value = "hasDeviceUnlockPolicy")
    private Boolean hasDeviceUnlockPolicy;
    private String manufacturer;
    private BigInteger quantityOnHand;
    private String preBackDate;
    private Double discountAmount;
    private String bundleAccessorySku;
    private String bundleProductId;
    private String connectedCarColor;
    private String connectedCarMobile;
    private String customBundleId;
    private String taxBasis;
    private Boolean iconicPhone;
    private Boolean ringBell;
    private Double deviceDollarApplied;
    private Boolean isPreconfigureEnabled;
    private String deviceStartDate;
    private String countDownText;
    private String countDownTimerText;
    private Boolean isHumDevice;
    private Boolean isSmartLocator;
    private Boolean isSecurityAlarm;
    private Boolean isMotoMod;
    private Boolean isConnectedCar;
    @JsonProperty(value = "accountLevelAccessory")
    private Boolean accountLevelAccessory;
    private Double itemPriceOnDeviceDollarApplied;
    private Boolean byodESimPhone;
    private Boolean scannedItem;
    private String deviceDisplayName;
    private Double tradeInAmountTowardsUserDPUsed;
    @JsonProperty(value = "appleCareAccessoryFlag")
    private Boolean appleCareAccessoryFlag;
    private String canonicalUrl;
    private Boolean quantityAllowed;

    private CXPFinanceOptionDetails financeOptionDetail;

}