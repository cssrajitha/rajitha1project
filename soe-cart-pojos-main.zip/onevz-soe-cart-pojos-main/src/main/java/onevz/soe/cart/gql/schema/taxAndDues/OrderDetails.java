package onevz.soe.cart.gql.schema.taxAndDues;

import lombok.Data;

@Data
public class OrderDetails {

	private String totalTaxAmount;
	private Double totalDueToday;
	private Double totalDueMonthly;
}
