package onevz.soe.cart.gql.schema.newCustomer;

import lombok.Data;
import lombok.NoArgsConstructor;
    @Data
    @NoArgsConstructor
    public class PromoEndDate {
        private String date;
        private String dateTime;
        private Object dateLong;
    }

