package onevz.soe.cart.gql.schema.customerByMtnList;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class EquipmentUpgradeEligibility {

	@JsonProperty(value = "upgradeEligible")
	private Boolean upgradeEligible;
    private TwoYearContract twoYearContract; 
}
