package onevz.soe.cart.gql.schema.calculateMultiLineTaxForCart;

import lombok.Data;

@Data
public class ZipCodeDetails {

    private String cityStatesFound;
    private String zipCode;
    private Integer numberOfCitiesFound;

}
