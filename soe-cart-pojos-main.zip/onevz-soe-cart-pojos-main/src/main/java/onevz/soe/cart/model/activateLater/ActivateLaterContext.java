package onevz.soe.cart.model.activateLater;

import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;
import onevz.soe.cart.model.common.CartServiceCartInfo;
import onevz.soe.cart.model.common.CartServiceContextInfo;
import onevz.soe.cart.model.common.CartServiceCustomerInfo;
import onevz.soe.cart.model.common.ProcessMTNList;
import onevz.soe.wsclient.bpm.model.Context;

@Data
@EqualsAndHashCode(callSuper = true)
public class ActivateLaterContext extends Context {

	private List<ProcessMTNList> processMTNList;
	private CartServiceCustomerInfo customerInfo;
	private CartServiceCartInfo cartInfo;
	private CartServiceContextInfo contextInfo;
}
