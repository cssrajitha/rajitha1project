package onevz.soe.cart.gql.schema;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.ChargeSummary;
import onevz.soe.cart.model.retrieveCart.MtnInfo;

@Data
public class SubAccountInfo {

    private String subAccountId;
    private String subAccountType;
    private MtnInfo mtnInfo;
    private Double totalDueMonthly;
    private Double totalDueToday;
    private Double totalTax;
    private ChargeSummary chargeSummary;
    private Double subTotalDueToday;
    private Double subTotalDueMonthly;
    private Double estimatedNextMonthCharge;

}
