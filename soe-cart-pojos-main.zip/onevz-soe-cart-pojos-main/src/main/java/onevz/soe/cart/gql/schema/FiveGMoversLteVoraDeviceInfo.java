package onevz.soe.cart.gql.schema;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.ImageUrlMap;

@Data
public class FiveGMoversLteVoraDeviceInfo {

    private ImageUrlMap imageUrlMap;
}
