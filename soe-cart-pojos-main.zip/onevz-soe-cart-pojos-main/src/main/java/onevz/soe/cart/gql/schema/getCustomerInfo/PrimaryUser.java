package onevz.soe.cart.gql.schema.getCustomerInfo;

import lombok.Data;

@Data
public class PrimaryUser {

    private String firstName;

    private String lastName;
}
