package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class RetrieveMiniCartItem {
    private RetrieveMiniCart cartItem;
}
