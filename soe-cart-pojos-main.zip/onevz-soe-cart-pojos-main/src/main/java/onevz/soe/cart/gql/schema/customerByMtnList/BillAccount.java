package onevz.soe.cart.gql.schema.customerByMtnList;

import java.util.List;

import lombok.Data;
import onevz.soe.cart.gql.requests.PaymentInfo;

@Data
public class BillAccount {

	private String billAccountNo;
    private String establishedYears;
    private String establishedMonths;
	private String lengthOfServiceText;
    private List<MtnList> mtns;   

  //Added the property for handling the defects NSADT-52308, NSADT-30424.
    private PaymentInfo paymentInfo;
}
