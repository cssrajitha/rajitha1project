package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL) 	//  ignore all null fields
public class InstallmentLoans {
	private Boolean loanTransferEligibility;
	private String loanAmount;
	private String paidAmountToDate;
	private String totalPrincipalAmountUnpaid;
	private String loanTermMonths;
	private Integer pendingNumberOfInstallments;
	private Integer daysLeftForNextEligibleUpgrade;
	private String loanMonthlyPaymentAmount;
	private String paidAmountPercentage;
	private String edgeUpRequiredPercent;
	private String firstInstallmentAmount;
	private String loanNumber;
	private boolean pastTradeInRestrictionTimePeriod;
	private String edgeUpPrincipalAmountUnpaid;
	private Boolean displayKeepOption;
	private Boolean displayReturnOption;
	private Boolean deviceMismatch;
	private BuyoutQuote buyoutQuote;
    private LoanStatus loanStatus;
	
}
