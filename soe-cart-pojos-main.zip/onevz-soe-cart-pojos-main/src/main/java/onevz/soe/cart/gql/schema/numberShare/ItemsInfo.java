package onevz.soe.cart.gql.schema.numberShare;

import lombok.Data;


@Data
public class ItemsInfo {

	private CartItems cartItems;
	
	
}
