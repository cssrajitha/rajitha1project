package onevz.soe.cart.gql.schema.shippingInfo;

import lombok.Data;

@Data
public class ShippingInfoLineInfo {

	private String mobileNumber;
	private ShippingInfoItemsInfo itemsInfo;
}
