package onevz.soe.cart.gql.requests;

import lombok.Data;

@Data
public class ACPCustomerInfoGQL {

    private String ssn;
    private String dateOfBirth;
    private ACPContactInfoGQL contactInfo;

}
