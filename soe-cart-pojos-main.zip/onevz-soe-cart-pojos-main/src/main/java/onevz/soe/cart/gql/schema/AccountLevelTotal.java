package onevz.soe.cart.gql.schema;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.ChargeTotals;

@Data
public class AccountLevelTotal {

	private String thisMonthCharge;
    private String nextMonthCharge;
    
    private String differenceBetweenThisMonthAndNextMonthCharge;
    private String thisMonthSplanLineAccessTotal;
    private String nextMonthSplanLineAccessTotal;
    private String totalOneTimeCharge;
    private String newMonthMrcWithNoAddOn;
    private String nextMonthMrcWithNoAddOn;
    private String nextMonthAcctLevelSurcharges;
    private String newMonthAcctLevelSurcharges;
    private String nextMonthAccountLevelTax;
    private String newMonthAccountLevelTax;
    
    private ChargeTotals chargeTotals; 
    
}
