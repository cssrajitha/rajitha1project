package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class PlanDiscount {

	private Boolean planEligibleForAutoPayPaperLessDiscount;
	private String eligibleAutoPayPaperlessDiscount;
	private String discountApplied;
	private String autoPayPaperLessDiscount;
	private Boolean discountIncluded;
	private String lineAccessFeeAfterDiscount;
	private String lineAccessFeeWithoutDiscount;
	private String totalPlanCostIncludingLineAccessFee;
}
