package onevz.soe.cart.gql.schema.deviceDetails;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.CurrentDevice;

@Data
public class DeviceDetailsServiceInfo {

	private CurrentDevice currentDevice;
}
