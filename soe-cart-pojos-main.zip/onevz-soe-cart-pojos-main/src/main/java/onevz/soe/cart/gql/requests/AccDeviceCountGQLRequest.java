package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.agreementInfo.LineDetails;

@Data
public class AccDeviceCountGQLRequest {

	private String cartId;	
	private LineDetails lineDetails;
}
