package onevz.soe.cart.gql.schema.customerByMtnForParentLines;

import lombok.Data;

@Data
public class Category {
	
	private String smartphone;

	private String basicphone;

}
