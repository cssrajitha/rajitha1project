package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude
public class DeviceInfo {

    private String deviceId;
    private String deviceUrl;
    private String brandName;
    private String displayName;
    private String deviceSku;
    //private DeviceCategory category;
}
