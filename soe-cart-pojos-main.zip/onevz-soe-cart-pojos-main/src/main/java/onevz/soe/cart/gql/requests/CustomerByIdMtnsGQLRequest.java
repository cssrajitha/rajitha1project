package onevz.soe.cart.gql.requests;

import lombok.Data;

@Data
public class CustomerByIdMtnsGQLRequest {
    String mtnHashCode;
    String mtn;

}
