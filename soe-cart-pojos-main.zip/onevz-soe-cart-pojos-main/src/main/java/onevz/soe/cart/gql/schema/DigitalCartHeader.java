package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class DigitalCartHeader {

    private String cartId;
    private String fullAccountNumber;
    private String createTimestamp;
    private String cartCreator;
    private String caseId;
    private String preConfiguredCartType;
    private String preConfiguredCartTypeDuringAddDevice;
    private String lastUpdateTimestamp;
}
