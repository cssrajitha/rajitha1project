package onevz.soe.cart.gql.schema.customerByMtn;

import lombok.Data;

import java.util.List;

@Data
public class BillAccountForCustomerProfile {

    private AccountAddress accountAddress;
    private List<MtnsListForCustomerProfile> mtns;

}
