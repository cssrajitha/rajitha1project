package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.orderprocess.model.checkoutdetails.LineDetailsLW;

@Data
public class DeviceCategoryLineDetails {


    private DeviceCategoryLineInfo lineInfo;

}
