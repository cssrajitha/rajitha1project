package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.newCustomer.CustomerName;
import onevz.soe.cart.model.initiateValidateDeviceSim.BillAccount;
import onevz.soe.cart.model.initiateValidateDeviceSim.CustomerAttributes;
import onevz.soe.cart.model.retrieveCustomer.EcpdProfile;

import java.util.List;

@Data
public class CustomerNameByMtnGQLRequest {

    //NSADT-129862 changes
    private String customerId;
    private CustomerName customerName;
    private List<BillAccount> billAccounts;
    //VZWYN-21969 changes
    private CustomerAttributes customerAttributes;
    private EcpdProfile ecpdProfile;
}
