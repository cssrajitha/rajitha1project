package onevz.soe.cart.gql.schema;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.AutoPayDiscount;
import onevz.soe.cart.model.retrieveCart.BalancePastDue;
import onevz.soe.cart.model.retrieveCart.BarGraphDetails;
import onevz.soe.cart.model.retrieveCart.DiscountsPendingActionDetails;
import onevz.soe.cart.model.retrieveCart.MonthlyTotalsInfo;
import onevz.soe.cart.model.retrieveCart.NBSIndicators;
import onevz.soe.cart.model.retrieveCart.OccTotals;
import onevz.soe.cart.model.retrieveCart.SurchargesInfo;
import onevz.soe.cart.model.retrieveCart.TaxesAndFeesInfo;
import onevz.soe.cart.model.retrieveCart.PendingChargesAndDiscounts;

@Data
public class NBS {

	private String accountNumber;
    private String nextBillCycleStartDate;
    private BalancePastDue balancePastDue;
    private MonthlyChargesInfo monthlyChargesInfo;
    private MonthlyTotalsInfo monthlyTotalsInfo;
    private SurchargesInfo surchargesInfo;
    private TaxesAndFeesInfo taxesAndFeesInfo;
    private AutoPayDiscount autoPayDiscount;
    private String unbilledOCC;
    
    private String formatterBillCycleEndDate;
    private OccTotals occTotals;
    private BarGraphDetails barGraphDetails;
    private NBSIndicators nbsIndicators;
    //private DiscountsPendingActionDetails discountsPendingActionDetails;
    private PendingChargesAndDiscounts pendingChargesAndDiscounts;
}
