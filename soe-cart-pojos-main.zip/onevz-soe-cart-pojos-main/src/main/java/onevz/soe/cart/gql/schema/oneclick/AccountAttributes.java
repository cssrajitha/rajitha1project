package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude
public class AccountAttributes {
	
	private Boolean trialUnlimitedCustomer;
	private Boolean isCollection;
	private Boolean isCashOnly;
	private Boolean isCashOnlyExceptCC;
	private Boolean isCashOnlyExceptCO;
	private Boolean isOverThreshHold;
	private FraudInfo fraudInfo;
	private Boolean mixedPlanCategories;
}
