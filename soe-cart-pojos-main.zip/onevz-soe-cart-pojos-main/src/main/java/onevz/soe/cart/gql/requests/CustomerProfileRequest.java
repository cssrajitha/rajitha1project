package onevz.soe.cart.gql.requests;

import lombok.Data;

import java.util.List;
@Data
public class CustomerProfileRequest {
    private List<BillAccountForCustomer> billAccounts;
}
