package onevz.soe.cart.gql.requests;

import lombok.Data;

@Data
public class IspuContactInfoGQL {
	
	private String customerEmailId;

}