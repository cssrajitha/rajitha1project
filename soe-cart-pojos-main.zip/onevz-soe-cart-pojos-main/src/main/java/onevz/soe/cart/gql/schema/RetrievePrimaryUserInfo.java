package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class RetrievePrimaryUserInfo {
    private PrimaryUserAddress address;
}
