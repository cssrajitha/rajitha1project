package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class PricePlanInfo {

	private String pricePlanCategory;
	private String ratePlanType;
	private String accessFeeRange;
	private String categoryCode;
	private String contractRange;
	private Integer contractDuration;
	private String pricePlanCode;
	private String pricePlanDesc;
	private String contractTermId;
	private String skuImage;
	private PlanImageUrlMap imageUrlMap;
	private String pricePlanEquipInd;
	private String formattedPlanName;
	private Double planPrice;
	private String pricePlanDisplayName;
	private String pricePlanCategoryName;
}
