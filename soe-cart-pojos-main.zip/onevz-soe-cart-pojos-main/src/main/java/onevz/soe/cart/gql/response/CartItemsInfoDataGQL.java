package onevz.soe.cart.gql.response;

import lombok.Data;
import onevz.soe.cart.gql.requests.CartItemInfoGQLRequest;

@Data
public class CartItemsInfoDataGQL {
	
	private CartItemInfoGQLRequest cart;

}