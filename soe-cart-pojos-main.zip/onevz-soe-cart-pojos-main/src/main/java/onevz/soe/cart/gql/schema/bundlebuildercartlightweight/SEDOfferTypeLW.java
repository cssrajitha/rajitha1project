package onevz.soe.cart.gql.schema.bundlebuildercartlightweight;

import lombok.Data;
import java.util.List;

@Data
public class SEDOfferTypeLW {
    private String offerId;
    private String description;
    private String offerType;
    private String discAmt;
    private String promoType;
    private Integer discPrcnt;
    private String rebatesAllowed;
    private List<PromoBadgeMessagesLW> promoBadges;
    private Boolean isStrategicOffer;
}
