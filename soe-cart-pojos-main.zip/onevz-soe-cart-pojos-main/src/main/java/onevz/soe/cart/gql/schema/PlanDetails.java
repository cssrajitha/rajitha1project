package onevz.soe.cart.gql.schema;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.PlanPromotions;

@Data
public class PlanDetails {

	private Double planPrice;
	private PlanDiscounts planDiscounts;
	private String discountedPrice;
	private PlanPromotions planPromotions;
}
