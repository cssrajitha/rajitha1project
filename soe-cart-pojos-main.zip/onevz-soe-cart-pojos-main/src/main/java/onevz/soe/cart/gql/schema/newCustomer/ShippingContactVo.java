package onevz.soe.cart.gql.schema.newCustomer;

import lombok.Data;

@Data
public class ShippingContactVo {
	private String emailAddress;

}