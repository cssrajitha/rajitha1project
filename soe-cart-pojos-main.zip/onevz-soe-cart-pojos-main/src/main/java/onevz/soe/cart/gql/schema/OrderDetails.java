package onevz.soe.cart.gql.schema;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import onevz.soe.cart.model.common.CompetitorBillInfo;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.orderprocess.model.checkoutdetails.AffirmFinancingOfferInfo;
import onevz.wsclient.cxp.annotations.Query;

@Data
public class OrderDetails {

	private String orderType;
	private String accountType;
	private String locationCode;
	private String homeLocation;
	private String customerType;
	private String billingSystem;
	private String paperlessInd;
	private String creditApprovalStatus;
	private String creditStatusReason;
	private String creditAdvisory;
	private String creditClass;
	private String securityDepositAmount;
	private String totalTaxAmount;
	private ChargeSummary chargeSummary;
	private String fraudLevel;
	private String deviceRecycleAttempted;
	private String explicitSaveInd;
	private SpocsType spocs;
	private Double totalDueToday;
	private Double runningTotalDueToday;
	private Boolean totalDueTodayFlag;
	private Double totalDueMonthly;
	private Double subTotalDueMonthly;
	private Double subTotalDueToday;
	private Double subTotalMonthlyTaxes;
	private Double estimatedNextMonthCharge;
	private Double totalMonthlyTaxes;
	private Double subTotalOtherLines;
	private Double subTotalOtherLinesTaxes;
	private Boolean instantDRCCredit;
	private String tradeAtHome;
	
	@JsonProperty(value = "isAttachmentCompleted")
	private Boolean isAttachmentCompleted;
	private Double nextMonthBillTotal;
	private EffectiveDate effectiveDate;
	private String barCodes;
	private CustomerNotification customerNotification;
	private EffectiveDateDetails effectiveDateDetails;
	private String orderChannelId;
	private OrderList orderList;
	private String outletId;
	private String registerNumber;
	private String saleType;
	private String salesRepId;
	@JsonProperty(value = "enableSplitShipment")
	private Boolean enableSplitShipment;
	@JsonProperty(value = "splitShipmentIndicator")
	private Boolean splitShipmentIndicator;
	@JsonProperty(value = "cartReadyForCheckout")
	private Boolean cartReadyForCheckout;
	private Double totalUpgradeFee; 
	@JsonProperty(value = "isSingleModConnectedDevice")
	private Boolean isSingleModConnectedDevice;
	@JsonProperty(value = "fiveGUpSellAccountLevel")
	private Boolean fiveGUpSellAccountLevel;
	private String earliestShippingDate;
	@JsonProperty(value = "customerOnTrialPlan")
	private Boolean customerOnTrialPlan;
	@JsonProperty(value = "availableSlotsForGrantee")
	private String availableSlotsForGrantee;
	
	@JsonProperty(value = "totalDownPaymentAmt")
	private Double totalDownPaymentAmt;
	@JsonProperty(value = "totalEdgeBuyOutAmount")
	private Double totalEdgeBuyOutAmount;
	@JsonProperty(value = "saveCartEmailId")
	private String saveCartEmailId ;
	@JsonProperty(value = "expressCheckout")
	private Boolean expressCheckout;
	private EnforceSecurityInfo enforceSecurityInfo;
	
	@JsonProperty(value = "nbxInfo")
	private NbxInfo nbxInfo;

	private Double totalDeviceDollar;
	private Double totalRemainingDeviceDollar;
	private Double totalUsedDeviceDollar;
	private String planVersion;
	@JsonProperty(value = "isEQPandPPLOfferApplied")
	private Boolean isEQPandPPLOfferApplied;
	private DiscountSummary cartTotalDiscounts;
	private Double memberTotalDueToday;
	private SubAccountInfo subAccountInfo;

	private WFMOrderInfo wfmOrderInfo;
	private Float totalAccountLevelAccCost;
	private Float totalAccountLevelAccCostWithTax;

	@JsonProperty(value = "customerConsent")
	private String customerConsent ;
	
	@JsonProperty(value="totalDwosCost")
	private String totalDwosCost;

	@JsonProperty(value="billingState")
	private String billingState;

	private Boolean hqUser;
	private Boolean returnException;

	//private VerizonCardPromoOffer verizonCardPromoOffer;
	private List<VerizonCardPromoOffer> verizonCardPromoOfferList;
	
	@JsonProperty(value = "isTradeInOfferSelected")
	private Boolean isTradeInOfferSelected;
	
	private String homePhone;

	private VerizonCardApplicationInfo verizonCardApplicationInfo;
	
	//new
	private String userType;
	private TaxDetailInfo taxDetailsList;
	private Float subTotalDueTodayWithoutUpgradeFee;
	private Float subTotalDueMonthlyForAALBYODEUP;
	private ManagerApproval managerApproval;
	private String resumeCartChannelID;
	private String channelValidated;
	private String masterId;
	private Boolean shipTogetherPref;
	private Boolean assistanceOptedByCustomer;
	private String repAssistanceCBRTN;
	private String httpHeaders;
	private String locationState;
	private String fiosEligibilityCategory;
	
	private String verizonDollarDueTodayAmount;
	private String totalDueTodayBeforeVZDollar;
	private String totalVerizonDollarUsed;
	private String totalVerizonDollar;
	private String masterAgentId;
	private Boolean isShellAccountSelected; 
	private String accountCreateDate;
	private String existingSpeed;
	private String orderDepletionType;
	private String fullfillmentLocation;
	private String eroesViiaCustomer;
	private AuthResult authResults;
	private Agreement agreements;
	private Boolean guestOrInactiveRefundLines;
	private Float totalDueMonthlyOnProfile;
	private Float subTotalDueMonthlyOnProfile;
	private Float totalMonthlyTaxesOnProfile;
	private Float subTotalOtherLinesOnProfile;
	private Float estimatedNextMonthChargeOnProfile;
	@JsonProperty(value = "fiosCapable") 
	private Boolean fiosCapable;
	@JsonProperty(value = "fiosEligible")
	private Boolean fiosEligible; 
	private Double originalSubTotalDueMonthly;
	@JsonProperty(value = "quoteWithoutCredit")
	private Boolean quoteWithoutCredit;
	private String totalAdjustmentAmount;
	private double totalDueMonthlyAfterDiscounts;
	private AccessoryFinancingInfo accessoryFinancingOfferInfo;
	private RefundNotifications refundNotifications;
	private String totalSurchargeAmount;
	private Double totalTaxAdjustmentAmount;
	private Boolean fiveGHomeOrder;
	private Float totalRefundAmount;
	private Float totalExchangeAmount;
	private Float totalRefundTaxAmount;
	private Float totalExchangeTaxAmount;
	private Boolean digitalExchange;
	//XBOX Retail Ordering changes
	private CXPFinanceOptionDetails financeOptionDetail;
	@JsonProperty(value = "uswinAuthenticationRequired")
	private Boolean uswinAuthenticationRequired;
	private PretoPostInfo newPreToPostInfo;
	
	@JsonProperty(value = "fiosAccountInfo")
	private FiosAccountInfo fiosAccountInfo;
	private AffirmFinancingOfferInfo affirmFinancingOfferInfo;
	private double remainingAmountAfterAffirmApplied;

	//Cash option for XBOX
	private Boolean cashOptionEnabled;
	private Boolean affirmCreditCheckFailed;
	
	private String isPrePayCart;
	private PostPayToNewPreMtns postPayToNewPreMtns;

	private double totalDueTodayWithoutDiscount;
	private double subTotalDueTodayWithoutDiscount;
	
	private String isComboOrder;
	
	private String flowType;
	private String totalPerksSavings;
	
	private Boolean repConsentForSUG;

	@Query(ignore = true)
	private Float payTodayWithoutDfo;

	private List<Eligible5GHomeBundle> eligible5GHomeBundle;
	private Boolean itemLevelShipment;

	@Schema(description = "Competitor Bill Info")
	@JsonProperty(value = "competitorBillInfo")
	private CompetitorBillInfo competitorBillInfo;
}
