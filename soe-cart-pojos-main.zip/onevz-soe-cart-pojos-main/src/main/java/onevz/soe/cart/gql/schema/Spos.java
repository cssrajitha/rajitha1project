package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class Spos {
    private Spo nameValue;
}
