package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class AgentAddress {
	
	private String status;
    private String companyCode;
    private String customerCode;
    private String branchCode;
    private String customerType;
    private String customerName;
    private String country;
    private String contact;
    private String billingShortName;
    private String territory;
    private String billingPhoneNumber;
    private String faxNumber;
    private String shBilAddDate;
    private String lastActDate;
    private String brObsoleteDate;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String zipCode;
    private String state;

}
