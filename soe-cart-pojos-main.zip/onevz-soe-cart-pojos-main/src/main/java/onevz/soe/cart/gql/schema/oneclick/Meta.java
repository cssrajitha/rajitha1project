package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 
 * Meta
 *
 */
@Data
public class Meta {

	private String timestamp;
	private String cxpCorrelationId;
	private String cf;
	@JsonProperty(value = "idmsSessionId")
	private String idmsSessionId;
	@JsonProperty(value = "successUrl")
	private String successUrl;
}
