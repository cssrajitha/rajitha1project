package onevz.soe.cart.gql.schema;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class OrderList {

	private CreditApplication creditApplication;
	private String orderActivityType;
	private Integer orderNumber;
	private Integer numOfLinesForOrderActivityType;
	private Long preOrderNumber;
	@JsonProperty(value = "managerApprovalRequired")
	private Boolean managerApprovalRequired;
	private long digitalOrderId ;
}
