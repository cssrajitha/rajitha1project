package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class AccessRolesForProfile {

	private Boolean owner;
	private Boolean manager;
	private Boolean member;
}
