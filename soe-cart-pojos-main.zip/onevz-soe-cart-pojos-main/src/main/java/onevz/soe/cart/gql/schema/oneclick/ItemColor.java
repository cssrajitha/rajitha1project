package onevz.soe.cart.gql.schema.oneclick;

import lombok.Data;

@Data
public class ItemColor {

	private String colorDisplayName;
}
