package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class OfferInfoList {
	
	private String offerId;
	private String offerType;
	private String offerName;
	private Boolean isPlanMatched;
	private Boolean isBuySkuMatched;
	private Boolean isGetSkuMatched;
	private Boolean isTradeSkuMatched;
	private String buyMtn;
	private Boolean isBuySkuContractMatched;
	private Boolean isGetSkuContractMatched;

}
