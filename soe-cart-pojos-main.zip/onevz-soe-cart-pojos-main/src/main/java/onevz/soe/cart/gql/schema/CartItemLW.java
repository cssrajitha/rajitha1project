package onevz.soe.cart.gql.schema;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.ImageUrlMap;
import onevz.soe.cart.model.retrieveCart.ItemColorVO;
import onevz.soe.cart.model.retrieveCart.InventoryVO;
import onevz.soe.cart.model.retrieveCart.PosSEDOfferListType;
import onevz.wsclient.cxp.annotations.Query;

@Data
public class CartItemLW {

	private Double discountAmount;
	private String deviceDisplayName;
	@Query(namespaces = {"gql-attribute-optimized"})
	private String sorDeviceCategory;
	@Query(namespaces = {"gql-attribute-optimized"})
	private String sorDeviceType;
	@Query(namespaces = {"gql-attribute-optimized"})
	private String operatingSystem;
	private String canonicalUrl;
	@Query(namespaces = {"gql-attribute-optimized"})
	private String itemCode;
	private double totalPriceWithDiscount;
	private String sorId;
	private String skuId;
	private String cartItemType;
	private String mobileNumber;
	private String description;
	private String capacity;
	private Integer qty;
	private String itemPrice;
	private Double discountedPercentage;
	private Double discountedPrice;
	private ImageUrlMap imageUrlMap;
	private String priceType;
	private String depletionType;
	private ItemColorVO color;
	private Double itemCost;
	@Query(namespaces = {"gql-attribute-optimized"})
	private String upgradeReasonCode;
	@Query(namespaces = {"gql-attribute-optimized"})
	private String upgradeReasonDesc;
	private String itemPriceType;
	@Query(namespaces = {"gql-attribute-optimized"})
	private InventoryVO inventory;
	private PosSEDOfferListType sedOfferList;
	private int itemSeqNum;
	private String productId;
	private String manufacturer;
	private PromoHubOfferNodePBB promoHubOfferList;
	private String deviceId;
	private String byodProdSubclassSku;
}
