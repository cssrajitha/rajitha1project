package onevz.soe.cart.gql.schema.numberShare;

import lombok.Data;


@Data
public class LineDetails {
	
	private LineInfo lineInfo;
	
}
