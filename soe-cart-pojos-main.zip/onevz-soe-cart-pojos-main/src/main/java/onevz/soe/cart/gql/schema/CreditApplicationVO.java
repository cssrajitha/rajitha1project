package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class CreditApplicationVO {

	private CreditApplication creditApplication;
	private CreditApplication linkedCreditApplication;
}
