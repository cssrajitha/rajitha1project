package onevz.soe.cart.gql.schema.oneclick;

import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class AvailablePath {
	
	private String path;

}
