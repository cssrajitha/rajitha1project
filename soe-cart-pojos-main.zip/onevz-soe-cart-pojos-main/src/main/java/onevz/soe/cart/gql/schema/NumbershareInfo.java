package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class NumbershareInfo {

	private String branchType;
	private E911Address e911Address;
	private Boolean isEditable;
	private String numberShareHostMtn;
	private Boolean standAlone;
}
