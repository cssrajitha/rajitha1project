package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.customerByMtn.BillAccountForCustomerProfile;

import java.util.List;

@Data
public class CustomerProfileGQLRequest {
    private List<BillAccountForCustomerProfile> billAccounts;
}
