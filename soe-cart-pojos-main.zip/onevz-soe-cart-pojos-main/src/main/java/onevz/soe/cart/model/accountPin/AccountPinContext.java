package onevz.soe.cart.model.accountPin;

import lombok.Data;
import lombok.EqualsAndHashCode;
import onevz.soe.cart.model.common.CartServiceCartInfo;
import onevz.soe.cart.model.common.CartServiceContextInfo;
import onevz.soe.cart.model.common.CartServiceCustomerInfo;
import onevz.soe.cart.model.common.ProcessMTNList;
import onevz.soe.wsclient.bpm.model.Context;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = true)
public class AccountPinContext extends Context {

    private String caseId;
    private List<ProcessMTNList> processMTNList;
    private CartServiceCustomerInfo customerInfo;
    private CartServiceCartInfo cartInfo;
    private CartServiceContextInfo contextInfo;

}
