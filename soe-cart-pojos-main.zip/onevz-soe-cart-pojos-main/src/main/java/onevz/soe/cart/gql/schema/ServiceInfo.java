package onevz.soe.cart.gql.schema;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import onevz.soe.cart.model.common.FeatureMessages;
import onevz.soe.cart.model.common.McsSubscription;
import onevz.soe.cart.model.retrieveCart.*;

@Data
public class ServiceInfo {

	private PrimaryUserInfo primaryUserInfo;
	private String activationDate;
	private E911Address cartE911Address;
	private FiveGAddress cart5GAddress;
	private Cart5GAppointment cart5GAppointment;
	private String mtn;
	private String min;	
	private String oldPricePlanId;
	private String newPricePlanId;
	private String contractTermId;	
	private PricePlanInfo pricePlanInfo;
	private PricePlanInfo newPricePlanInfo;
	private SelectedFeaturesList selectedFeaturesList;
	private SelectedALPShareList selectedALPShareList;	
	private PlanDetails planDetails;
	private String correlationID;
	private CurrentDevice currentDevice;
	@JsonProperty(value="isSharePlanAdded")
	private Boolean isSharePlanAdded;
	private String mldTrunkMTN;
	private String lineType;
	private String priceType;
	private String mea;
	private String simCardNumber;	
	private String planPrice;
	private String planDiscPrice;	
	private String dacc;
	private String sacc;
	private String trunkMTN;
	private String numberShareInd;
	private String isAutoPayEnrolled;
	private String isAutoPayPaperLessDiscountEligible;
	@JsonProperty(value="isE911AddressValidated")
	private Boolean isE911AddressValidated;
	private String isFreeAppleMusicLoss;
	private String isPaperLessEnrolled;
	private String newBgsa;
	private String newPlanFlag;
	private String oldPlanFlag;
	private OrderDevice orderDevice;
	private SbdOffer sbdOffer;
	private ThirdPartyOffer[] thirdPartyOffer;
	private RefundSbdOffer refundSbdOffer;
	private String totalEligibleAutoPayPaperLessDiscount;
	private VisAddlServiceInfo visAddlServiceInfo;
	private String tabletJetpackDiscountLoss;
	@JsonProperty(value="kidsPlanParentMtn")
	private Boolean kidsPlanParentMtn;
	private McsSubscription mcsSubscription;
	
	@JsonProperty(value = "activateLaterInd")
	private Boolean activateLaterInd;
	@JsonProperty(value = "setUpLater")
	private Boolean setUpLater;
	@JsonProperty(value = "fiveGUpSell")
	private Boolean fiveGUpSell;
	
	private LinePairingInfo pairingInfo;
	private PlanDiscount planDiscount;
	private OtherPromotions otherPromotions;
	private Boolean e911AddressSameAsServiceAddress;
	@JsonProperty(value = "unpairedGrantor")
	private Boolean unpairedGrantor;
	private List<FeatureMessages> featureMessages;
	private ServiceAddress serviceAddress;
	private String totalAddedFeaturesPrice;
	private List<OfferInfo> offerInfoList;
}
