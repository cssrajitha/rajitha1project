package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class RedemptionId {

	private String redemptionIds;

}
