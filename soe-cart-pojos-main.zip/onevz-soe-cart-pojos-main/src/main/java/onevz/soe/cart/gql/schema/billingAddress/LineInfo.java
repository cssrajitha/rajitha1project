package onevz.soe.cart.gql.schema.billingAddress;

import lombok.Data;


@Data
public class LineInfo {
	
	private ServiceInfo serviceInfo;	
	
}
