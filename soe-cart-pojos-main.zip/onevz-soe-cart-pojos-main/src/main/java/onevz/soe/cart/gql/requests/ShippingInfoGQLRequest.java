package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.shippingInfo.ShippingInfoLineDetailsVO;
import onevz.soe.cart.gql.schema.shippingInfo.ShippingInfoOrderDetails;

@Data
public class ShippingInfoGQLRequest {

	private String cartId;
	private ShippingInfoOrderDetails orderDetails;
	private ShippingInfoLineDetailsVO lineDetails;
}
