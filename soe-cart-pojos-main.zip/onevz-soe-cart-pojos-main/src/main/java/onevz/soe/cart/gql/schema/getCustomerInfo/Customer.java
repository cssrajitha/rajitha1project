package onevz.soe.cart.gql.schema.getCustomerInfo;

import lombok.Data;

import java.util.List;

@Data
public class Customer {

    private String email;

    private List<BillAccount> billAccounts;

    private CustomerCbrInfo customerCbrInfo;
}
