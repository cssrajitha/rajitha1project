package onevz.soe.cart.gql.schema.cartItems;

import lombok.Data;

@Data
public class CartItemsLineDetailsVO {

	private CartItemsLineInfo lineInfo;
}
