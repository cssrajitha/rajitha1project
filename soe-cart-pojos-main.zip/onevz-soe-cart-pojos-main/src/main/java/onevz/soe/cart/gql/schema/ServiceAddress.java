package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class ServiceAddress {

	private String lastName;
	private String firstName;
	private String addressLine1;
	private String addressLine2;
	private String zipCode;
	private String zipCode4;
	private String city;
	private String state;

}
