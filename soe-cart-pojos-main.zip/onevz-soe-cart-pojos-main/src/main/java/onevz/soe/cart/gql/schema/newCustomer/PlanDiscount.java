package onevz.soe.cart.gql.schema.newCustomer;

import lombok.Data;

@Data
public class PlanDiscount {
	
	private Boolean planEligibleForAutoPayPaperLessDiscount;
	private String discountApplied;
	private String autoPayPaperLessDiscount;
	private Boolean discountIncluded;
	private String totalPlanCostIncludingLineAccessFee;
	private String eligibleAutoPayPaperlessDiscount;

}
