package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude
public class AvailableMtns {
	private String displayMtn;
	private String mtn;
	//private String encryptedMTN;
}
