package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import onevz.wsclient.cxp.annotations.Query;

@Data
@JsonInclude
public class PendingOrderDetailGQLRequest {

	@Query(namespaces = {"gql-attribute-optimized"})
	private String createDate;
	private String description;
	private String effectiveDate;
	private String pendingOrderNumber;
	private Boolean isCancellable;
	
	
}
