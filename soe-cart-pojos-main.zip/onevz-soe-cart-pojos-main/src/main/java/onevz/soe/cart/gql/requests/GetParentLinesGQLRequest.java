package onevz.soe.cart.gql.requests;

import java.util.List;

import lombok.Data;
import onevz.soe.cart.gql.schema.customerByMtnForParentLines.BillAccount;

@Data
public class GetParentLinesGQLRequest {
	
	private List<BillAccount> billAccounts;

}
