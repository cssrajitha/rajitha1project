package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class Promotions {

	private String promotionText;
	private String promotionPrice;
}
