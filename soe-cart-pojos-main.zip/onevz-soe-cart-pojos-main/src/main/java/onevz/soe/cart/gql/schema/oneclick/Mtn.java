
package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;
@Data
@JsonInclude
public class Mtn {
	private String mtnHashCode;
	private List<Promotions> promotions;
	private String mtn;
	private NextBestAction nextBestAction;
	private String encryptedMtn;
	private String nickName;
	private List<EquipmentInfo> equipmentInfos = null;
	private PricePlanInfo pricePlanInfo;
	private MobileInfoAttributes mobileInfoAttributes;
	private List<InstallmentLoans> installmentLoans;
	private List<InstallmentLoanSummary> installmentLoanSummary;
	private UpgradeEligibilityInfo equipmentUpgradeEligibility;
	private LineLevelChangeEligibility lineLevelChangeEligibility;
	private String deviceMtnIndicator;
	private String simType;
	private MtnStatus mtnStatus;
	private String mtnActiveOn;
	private String deviceNickName;
	Mtn(){
		this.lineLevelChangeEligibility = new LineLevelChangeEligibility();
	}
}
