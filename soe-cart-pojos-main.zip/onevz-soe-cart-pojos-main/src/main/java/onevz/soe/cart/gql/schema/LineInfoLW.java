package onevz.soe.cart.gql.schema;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import onevz.soe.cart.model.retrieveCart.InstallmentInfo;
import onevz.soe.cart.model.retrieveCart.MtnDetails;
import onevz.wsclient.cxp.annotations.Query;


@Data
public class LineInfoLW {

	private Integer multiLineSeqNumber;
	private String lineActivityType;
	private String mobileNumber;
	@Query(namespaces = {"gql-attribute-optimized"})
	private ServiceInfoLW serviceInfo;
	private ItemsInfoLW itemsInfo;
	private MtnDetails mtnDetails;
	private String lineNumber;
	@JsonProperty(value = "isCartVisitedItem")
	private Boolean isCartVisitedItem;
	private InstallmentInfo installmentInfo;

	private String promotionID;
	private String promoType;
	private boolean isTradeInIntentSelected;
	private	String nbxSessionId;
}
