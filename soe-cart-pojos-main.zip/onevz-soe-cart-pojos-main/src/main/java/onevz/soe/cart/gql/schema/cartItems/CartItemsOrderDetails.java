package onevz.soe.cart.gql.schema.cartItems;

import lombok.Data;

@Data
public class CartItemsOrderDetails {

	private Double nextMonthBillTotal;
	private Double totalDueToday;
	private Double totalDueMonthly;
}
