package onevz.soe.cart.gql.requests;

import onevz.soe.cart.gql.schema.CartHeader;
import onevz.soe.cart.model.retrieve5GCart.*;

public class OrderConfirmationGQLRequest {

    private CartHeader cartHeader;
    private FiveGOrderDetails orderDetails;
    private FiveGLineDetailsVO lineDetails;
}
