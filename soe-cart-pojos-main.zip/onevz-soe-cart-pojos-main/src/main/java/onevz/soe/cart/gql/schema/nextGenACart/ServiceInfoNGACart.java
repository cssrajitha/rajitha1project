package onevz.soe.cart.gql.schema.nextGenACart;

import lombok.Data;

@Data
public class ServiceInfoNGACart {
	private PricePlanNGACartInfo newPricePlanInfo;
	private String newPricePlanId;

}
