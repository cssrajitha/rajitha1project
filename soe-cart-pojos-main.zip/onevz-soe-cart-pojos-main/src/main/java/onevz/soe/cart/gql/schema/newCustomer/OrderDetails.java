package onevz.soe.cart.gql.schema.newCustomer;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import onevz.soe.cart.gql.schema.TaxDetailInfo;
import onevz.soe.cart.model.retrieveCart.*;


@Data
public class OrderDetails {
	
	private String customerType;
	private String totalTaxAmount;
	private Double totalDueToday;
	private Double totalDueMonthly;
	private Double subTotalDueMonthly;
	private Double subTotalDueToday;
	private String billingSystem;
	private OrderList orderList;
	@JsonProperty(value = "enableSplitShipment")
	private Boolean enableSplitShipment;
	@JsonProperty(value = "splitShipmentIndicator")
	private Boolean splitShipmentIndicator;
	@JsonProperty(value = "cartReadyForCheckout")
	private Boolean cartReadyForCheckout;
	@JsonProperty(value = "totalDownPaymentAmt")
	private Double totalDownPaymentAmt;
	private DiscountSummary cartTotalDiscounts;
	private String homePhone;
	private NBXInfo nbxInfo;
	private String visionCustomerId;
	private String accountCreateDate;
	private String existingSpeed;
	//private List<TaxDetails> taxDetailsList;
	private List<TaxDetailInfo> taxDetailsList;
	private List<VerizonCardPromoOffer> verizonCardPromoOfferList;
	private String securityDepositAmount;
	private ChargeSummary chargeSummary;
	private String barCodes;
	private Double originalSubTotalDueMonthly;
	private Double totalDueMonthlyAfterDiscounts;
	private AccessoryFinancingInfo accessoryFinancingOfferInfo;
	private String totalSurchargeAmount;
	private Double totalTaxAdjustmentAmount;
	@JsonProperty(value = "fiosAccountInfo")
	private FiosAccountInfo fiosAccountInfo;
	private Boolean sbdOfferByDefaultSku;
	private String totalPerksSavings;
	private String isComboOrder; //ACT114-1473
	@JsonProperty(value = "flowType")
	private String flowType;
	private List<Eligible5GHomeBundle> eligible5GHomeBundle;
}
