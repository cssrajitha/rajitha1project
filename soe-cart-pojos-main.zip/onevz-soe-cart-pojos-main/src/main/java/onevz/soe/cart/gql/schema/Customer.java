package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class Customer {

    private Tabs tabs;
    private BillSummary billSummary;

}
