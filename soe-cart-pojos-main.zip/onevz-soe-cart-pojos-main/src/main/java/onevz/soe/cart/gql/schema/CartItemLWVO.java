package onevz.soe.cart.gql.schema;

import lombok.Data;

/**
 * @author munjra4
 */
@Data
public class CartItemLWVO {
    private boolean byodESimPhone;
    private boolean smartIMEI;
    private String cartItemType;
    private String deviceId;
}
