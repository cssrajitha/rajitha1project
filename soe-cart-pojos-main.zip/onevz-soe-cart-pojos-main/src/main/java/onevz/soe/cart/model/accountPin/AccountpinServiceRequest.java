package onevz.soe.cart.model.accountPin;

import lombok.Data;
import lombok.EqualsAndHashCode;
import onevz.soe.wsclient.bpm.model.request.ServiceRequest;

@Data
@EqualsAndHashCode(callSuper=true)
public class AccountpinServiceRequest extends ServiceRequest {
    private AccountPinContext context;
}
