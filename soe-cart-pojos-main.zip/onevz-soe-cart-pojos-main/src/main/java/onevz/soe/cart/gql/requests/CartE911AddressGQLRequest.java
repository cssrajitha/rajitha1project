package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.cartE911Address.LineDetails;

@Data
public class CartE911AddressGQLRequest {

	private String cartId;	
	private LineDetails lineDetails;
	
}
