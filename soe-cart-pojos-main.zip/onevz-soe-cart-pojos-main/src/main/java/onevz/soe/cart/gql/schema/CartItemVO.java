package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class CartItemVO {

	private CartItem cartItem;
}
