package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.OrderDetailsNGD;
import onevz.soe.cart.gql.schema.nextGenACart.LineDetailsNGACartVO;
import onevz.soe.cart.model.validateCart.CartValidationError;

import java.util.List;

@Data
public class RetrieveNGACartGQLRequest {
	private LineDetailsNGACartVO lineDetails;
	private OrderDetailsNGD orderDetails;
	private List<CartValidationError> cartValidationErrors;
}
