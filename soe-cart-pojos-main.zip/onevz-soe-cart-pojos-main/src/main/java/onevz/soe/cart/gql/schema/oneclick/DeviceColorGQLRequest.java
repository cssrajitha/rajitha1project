package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;


@Data
@JsonInclude
public class DeviceColorGQLRequest {
	private String description;
	private String displayName;

}
