package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude
public class FraudInfo {
	
	private Boolean fraud;
	private Boolean fraud_C;
	private Boolean fraud_M;
	private Boolean fraud_R;
	private Boolean fraud_S;
	private Boolean fraud_V;
	private Boolean fraud_X;
	private Boolean fraud_Y;
	private Boolean fraud_Z;

}
