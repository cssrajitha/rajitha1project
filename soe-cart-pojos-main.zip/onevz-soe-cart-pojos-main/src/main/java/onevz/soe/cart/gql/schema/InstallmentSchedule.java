package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class InstallmentSchedule {

	private String installmentPaymentScheduleCount;
	private String paymentDate;
}
