package onevz.soe.cart.gql.schema.newCustomer;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;
@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class PromoBadgeMessagesNFL {
    private String badgeText;
    private String oneUnlimitedPlanText;
    private String badgeToolTip;
    private String badgeToolTipUrl;
    private String badgeImage;
    private String placement;
    private String pageId;
    private String masterpageId;
    private String offerType;
    private String simpleDisc;
    private String flow;
    private String[] aemOfferIds;
    private String aalToolTipUrl;
    private String eupToolTipUrl;
    private boolean promoOverlayEnable;
    private String promotionId;
    private String disclaimer;
    private PromoEndDate promoEndDate;
    private Boolean choiceOffer;

}
