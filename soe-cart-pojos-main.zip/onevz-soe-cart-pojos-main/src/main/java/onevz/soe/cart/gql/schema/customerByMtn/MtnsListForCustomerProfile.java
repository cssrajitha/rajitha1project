package onevz.soe.cart.gql.schema.customerByMtn;

import lombok.Data;
import onevz.soe.cart.gql.CurrentProfileSPO;
import onevz.soe.cart.model.deviceSimValidation.ActiveAndPendingDeviceInfo;
import onevz.soe.cart.model.deviceSimValidation.DeviceSimValidationEquipmentInfos;
import onevz.soe.cart.model.deviceSimValidation.PricePlanInfo;

import java.util.List;

@Data
public class MtnsListForCustomerProfile {

    private String mtn;
    private Boolean hasActiveAndPendingDevice;
    private ActiveAndPendingDeviceInfo activeAndPendingDeviceInfo;
    private List<DeviceSimValidationEquipmentInfos> equipmentInfos;
    private MobileInfoAttributes mobileInfoAttributes;
    private PricePlanInfo pricePlanInfo;
    private List<CurrentProfileSPO> currentSpo;

}
