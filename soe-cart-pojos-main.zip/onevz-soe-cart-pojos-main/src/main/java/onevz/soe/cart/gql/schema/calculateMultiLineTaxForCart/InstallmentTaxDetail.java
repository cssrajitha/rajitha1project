package onevz.soe.cart.gql.schema.calculateMultiLineTaxForCart;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class InstallmentTaxDetail {

	private String firstMonthInstallmentAmount;
	private String taxState;
	private String edgeUpTaxAmount;
	private String fipsCode;
	private String taxBasis;
	private String downPaymentAmount;
	private String firstmonthPaymentCollected;
	private String vzwItemCost;
	private String edgeUpAmtFipsCode;
	private String monthlyTaxTotal;
	@JsonProperty(value = "isOrderHaveDPorACC")
	private Boolean isOrderHaveDPorACC;
	private String btaTaxWaiveInd;
}
