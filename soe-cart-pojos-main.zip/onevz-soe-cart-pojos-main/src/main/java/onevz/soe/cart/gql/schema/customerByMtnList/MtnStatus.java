package onevz.soe.cart.gql.schema.customerByMtnList;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class MtnStatus {

	@JsonProperty(value = "isActive")
	private Boolean isActive;
}
