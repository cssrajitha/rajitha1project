package onevz.soe.cart.gql.schema.bundlebuildercartlightweight;

import lombok.Data;

import java.util.List;

@Data
public class PromoHubOfferNode {
    private List<PromoHubOffer> promoHubOfferList;
    private int offerCount;
}
