package onevz.soe.cart.gql.schema.newCustomer;

import lombok.Data;

@Data
public class ApplePayAdditionalInfoVo {
	private ShippingContactVo shippingContact;

}