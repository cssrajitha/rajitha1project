package onevz.soe.cart.gql.schema.bundlebuildercartlightweight;

import lombok.Data;

@Data
public class PromoBadgeMessagesLW {
    private String badgeText;
    private String placement;
    private String pageId;
    private String promotionId;
    private String offerType;
}
