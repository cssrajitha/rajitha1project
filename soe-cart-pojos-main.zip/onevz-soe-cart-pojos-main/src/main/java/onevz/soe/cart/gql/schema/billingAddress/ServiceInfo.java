package onevz.soe.cart.gql.schema.billingAddress;

import lombok.Data;


@Data
public class ServiceInfo {

	private PrimaryUserInfo primaryUserInfo;
	private String newPricePlanId;
	private String numberShareInd;
	private String trunkMTN;
	
}
