package onevz.soe.cart.gql.schema.deviceCount;

import lombok.Data;


@Data
public class DeviceCountItemsInfo {

	private DeviceCountCartItemVO cartItems;
}
