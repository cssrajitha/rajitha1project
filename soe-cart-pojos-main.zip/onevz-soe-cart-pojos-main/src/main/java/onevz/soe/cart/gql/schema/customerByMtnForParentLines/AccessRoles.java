package onevz.soe.cart.gql.schema.customerByMtnForParentLines;

import lombok.Data;

@Data
public class AccessRoles {

    private Boolean manager;

    private Boolean member;

    private Boolean owner;
}
