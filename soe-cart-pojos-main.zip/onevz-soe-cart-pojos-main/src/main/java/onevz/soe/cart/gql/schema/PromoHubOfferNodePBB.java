package onevz.soe.cart.gql.schema;

import lombok.Data;

import java.util.List;

@Data
public class PromoHubOfferNodePBB {
    private List<PromoHubOfferPBB> promoHubOfferList;
    private int offerCount;
}
