package onevz.soe.cart.gql.schema.newCustomer;

import lombok.Data;

@Data
public class PaypalPaymentDetails {

	/** The paypal payment authenticate details. */
	private PaypalPaymentAuthenticateDetails paypalPaymentAuthenticateDetails;
}
