package onevz.soe.cart.gql.schema.shippingInfo;

import lombok.Data;

@Data
public class ShippingInfoOrderList {

	private Integer orderNumber;
}
