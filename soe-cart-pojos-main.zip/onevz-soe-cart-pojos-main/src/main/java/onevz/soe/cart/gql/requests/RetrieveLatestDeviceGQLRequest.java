package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.DevicePaymentPrice;
import onevz.soe.cart.gql.schema.FullRetailPrice;

import java.util.List;

@Data
public class RetrieveLatestDeviceGQLRequest {

  private String deviceId;

  private String deviceIdType;

  private String capacity;

  private String modelName;

  private String brandName;

  private String operatingSystem;

  private String deviceUrl;

  private String canonicalUrl;

  private String productDisplayName;

  private String sorId;

  private String sorDeviceCategory;
  
  private String sorAccessoryType;

  private FullRetailPrice fullRetailPrice;

  private DevicePaymentPrice devicePaymentPrice;

}
