package onevz.soe.cart.gql.schema.newCustomer;

import lombok.Data;
import onevz.soe.cart.gql.schema.newCustomer.VisFeature;

@Data
public class SelectedFeaturesList {
	
	private Integer featuresCount;
	private VisFeature visFeature;

}
