package onevz.soe.cart.gql.schema;

import java.math.BigInteger;
import java.util.List;

import lombok.Data;

@Data
public class MdnStackingOffer {

	private String mtn;
	private String stackMldSequence;
	private BigInteger offerId;
//	private List<String> offerIdList;
	private String allowStackWithTrade;
}
