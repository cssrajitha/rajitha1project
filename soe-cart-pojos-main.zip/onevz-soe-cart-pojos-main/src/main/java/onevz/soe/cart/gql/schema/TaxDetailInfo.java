package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class TaxDetailInfo {

	private Integer taxSequenceNum;
	private Integer taxPassType;
	private Integer taxAmount;
	private Integer taxDescription;
	private Integer taxType;
	private Integer mldSequenceNum;
	private String taxSurcharge;
}
