package onevz.soe.cart.gql.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import onevz.soe.cart.gql.requests.BundleBuilderCartLWGQLRequest;
import onevz.soe.cart.model.retrieveCart.CXPRetrieveCartDataVO;
import onevz.soe.cart.responses.BundleBuilderResponseData;
import onevz.soe.cart.responses.GenericResponse;

import java.util.Map;

@Data
public class BundleBuilderCartLWResponse extends GenericResponse {
    @JsonProperty("meta")
    private Map<String, String> meta;

    @JsonProperty("data")
    private BundleBuilderResponseData data;

}
