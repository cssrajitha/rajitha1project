package onevz.soe.cart.gql.schema.calculateMultiLineTaxForCart;

import java.util.List;

import lombok.Data;

@Data
public class LineTaxDetail {

	private String locationCode;
	private int multiLineSeqNumber;
	private String orderType;
	private String totalTax;
	private String totalPhonePriceForTax;
	private String totalPriceForTax;
	private List<ItemForTax> itemsForTax;
}
