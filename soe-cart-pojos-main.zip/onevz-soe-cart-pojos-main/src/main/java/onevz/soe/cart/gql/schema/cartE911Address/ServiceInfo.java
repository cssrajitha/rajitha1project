package onevz.soe.cart.gql.schema.cartE911Address;

import lombok.Data;
import onevz.soe.cart.gql.schema.E911Address;

@Data
public class ServiceInfo {

	private E911Address cartE911Address;
	
}
