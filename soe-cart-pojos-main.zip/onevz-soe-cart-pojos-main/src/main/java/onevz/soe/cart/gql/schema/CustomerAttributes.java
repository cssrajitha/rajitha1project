package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class CustomerAttributes {

	private String taxExemptCode;
	private String digitalCustomerType;

}
