package onevz.soe.cart.gql.schema.bundlebuildercartlightweight;

import lombok.Data;
import onevz.soe.cart.gql.schema.CartHeaderLW;

@Data
public class CartLW {
    private String cartId;
    private CartHeaderLW cartHeader;
    private LineDetailsLW lineDetails;
    private OrderDetailsLW orderDetails;
}
