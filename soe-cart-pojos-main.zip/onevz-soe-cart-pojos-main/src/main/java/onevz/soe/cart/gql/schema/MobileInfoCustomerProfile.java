package onevz.soe.cart.gql.schema;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import onevz.soe.cart.gql.CurrentProfileSPO;
import onevz.soe.orderprocess.model.checkoutdetails.EquipmentInfo;
import  onevz.soe.cart.gql.ServiceAddress;

@Data
public class MobileInfoCustomerProfile {

	private String mtn;
    private UpgradeEligibilityInfo equipmentUpgradeEligibility;
    private MobileInfoBusinessAttributesForProfile mobileInfoAttributes; 
    //private PricePlanInfo pricePlanInfo;
    private List<EquipmentInfo>	equipmentInfos;
    @JsonProperty("serviceAddress")
    @Schema(description = "Service Address associated with the 5G service")
    private ServiceAddress serviceAddress;
    private List<Promotions> promotions;
    private String lineSharingIndicator;
    private CartPricePlanInfo pricePlanInfo;
    private List<CurrentProfileSPO> currentSpo;
}
