package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class AccountSharePlanInfo {

	private String planId;
	private String description;
	private String planImageUrl;
    private Integer mdnCount;
	private String chargeAmount;
	private String componentType;
}
