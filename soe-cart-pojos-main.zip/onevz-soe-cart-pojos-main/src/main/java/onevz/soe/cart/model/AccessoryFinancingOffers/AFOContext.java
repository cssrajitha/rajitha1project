package onevz.soe.cart.model.AccessoryFinancingOffers;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import onevz.soe.cart.model.common.CartServiceCartInfo;
import onevz.soe.cart.model.common.CartServiceContextInfo;
import onevz.soe.cart.model.common.CartServiceCustomerInfo;
import onevz.soe.wsclient.bpm.model.Context;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper=true)
public class AFOContext extends Context {
	
	@JsonInclude(Include.NON_NULL)
	private CartServiceCustomerInfo customerInfo;
	
	@JsonInclude(Include.NON_NULL)
	private CartServiceCartInfo cartInfo;
	
	@JsonInclude(Include.NON_NULL)
	private String caseId;
	
	@JsonInclude(Include.NON_NULL)
	private CartServiceContextInfo contextInfo;

}
