package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class LineDetailsLightWeightDigitalCartVO {

	private String cartId;
	private Integer numOfLines;
	private Integer numofLinesAAL;
	private Integer numofLinesEUP;
	private Integer lineSeq;
	private Integer numOfLinesWithDevices;
	private LineLightWeightDigitalCartInfo lineInfo;
}
