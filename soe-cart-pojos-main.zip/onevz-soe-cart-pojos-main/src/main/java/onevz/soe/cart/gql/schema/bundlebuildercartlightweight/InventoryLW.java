package onevz.soe.cart.gql.schema.bundlebuildercartlightweight;

import lombok.Data;
import java.math.BigInteger;

@Data
public class InventoryLW {
    private Boolean isAvailable;
    private Boolean isBackorder;
    private Boolean isDeliverBy;
    private Boolean isPreOrder;
    private BigInteger qtyAvailable;
    private Boolean isInStock;
}
