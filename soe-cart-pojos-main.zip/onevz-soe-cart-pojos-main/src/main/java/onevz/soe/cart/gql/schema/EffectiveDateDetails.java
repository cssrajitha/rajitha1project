package onevz.soe.cart.gql.schema;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class EffectiveDateDetails {
	@JsonProperty(value="onDemandAllowed")
	private Boolean onDemandAllowed;
	@JsonProperty(value="backDateAllowed")
	private Boolean backDateAllowed;
	@JsonProperty(value="futureDateAllowed")
	private Boolean futureDateAllowed;	
	private String suggestedBackDate;
	private String suggestedFutureDate;
	private String currentBillCycleBeginDate;
	private String nextBillCycleBeginDate;
	private String onDemandDate;
	private String onDemandRangeInDays;
	private String selectedDate;
	private String onDemandOverageInd;
}
