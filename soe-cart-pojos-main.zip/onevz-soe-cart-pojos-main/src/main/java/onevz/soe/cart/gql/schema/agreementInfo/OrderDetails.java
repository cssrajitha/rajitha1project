package onevz.soe.cart.gql.schema.agreementInfo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class OrderDetails {
	
	private String locationCode;
	private Double totalDueToday;
	private OrderList orderList;
	@JsonProperty(value = "isSingleModConnectedDevice")
	private Boolean isSingleModConnectedDevice;
}
