package onevz.soe.cart.gql.schema;

import lombok.Data;


@Data
public class SelectedFeaturesList {

	private Integer featuresCount;
	private VisFeature visFeature;
}
