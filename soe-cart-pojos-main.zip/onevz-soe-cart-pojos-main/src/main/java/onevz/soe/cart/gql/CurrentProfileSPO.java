package onevz.soe.cart.gql;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CurrentProfileSPO {
    private String spoId;
    private String price;
    private String finalPrice;

}
