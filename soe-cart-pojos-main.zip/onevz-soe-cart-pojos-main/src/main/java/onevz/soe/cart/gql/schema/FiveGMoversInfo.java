package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class FiveGMoversInfo {

	private String moveInDate;
	private String moveOutDate;
}
