package onevz.soe.cart.gql.schema;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import onevz.soe.cart.model.common.Propositions;
import onevz.soe.cart.model.retrieveCart.*;

import java.util.List;

@Data
public class LineDigitalInfo {

	private Integer multiLineSeqNumber;
	private Double totalDueToday;
	private Double totalDueTodayWithoutTax;
	private Double totalDueMonthly;
	private String mobileNumber;
	private InstallmentInfo installmentInfo;
	private ServiceInfo serviceInfo;	
	private ItemsDigitalInfo itemsInfo;
	private String launchType;
	private BuyOutDetail buyOutDetail;
	private String deviceTypeSelected;
}
