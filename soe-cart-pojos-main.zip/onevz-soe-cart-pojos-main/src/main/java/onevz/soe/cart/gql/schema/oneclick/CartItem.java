package onevz.soe.cart.gql.schema.oneclick;

import lombok.Data;

@Data
public class CartItem {
private String description;
private String cartItemType;
private String manufacturer;
private String capacity;
private ItemColor color;
private ImageUrlMap imageUrlMap;
	
}
