package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude
public class PairedImeiDataGQLRequest {
    private String pairedImei;
    private String eid;
    private String sku;
    private String preferredSim;
    private String devicePreferredSoftSim;
    private String simClass4G;
    private boolean euiccCapable;
}
