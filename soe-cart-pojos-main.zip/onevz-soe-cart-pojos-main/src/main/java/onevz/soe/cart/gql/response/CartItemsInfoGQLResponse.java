package onevz.soe.cart.gql.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CartItemsInfoGQLResponse {
	    @JsonInclude(JsonInclude.Include.NON_NULL)
	    @JsonProperty(value = "data")
	    private CartItemsInfoDataGQL data;

}