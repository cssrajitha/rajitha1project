package onevz.soe.cart.gql.schema;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.NbsInfo;

@Data
public class LineDetailsNewNumberPortInCartVO {

	private LineNewNumberPortInCartInfo lineInfo;

	private NbsInfo subAccountNBSInfo;

}
