package onevz.soe.cart.model.AccessoryFinancingOffers;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import onevz.soe.cart.model.common.CartException;
import onevz.soe.cart.model.common.CartServiceServiceHeader;
import onevz.soe.cart.ui.responses.AFOResponseServiceBody;
import onevz.soe.wsclient.bpm.model.response.BPMServiceResponse;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = true)
public class AccessoryFinancingOffersPegaResponse extends BPMServiceResponse {

	@JsonInclude(JsonInclude.Include.NON_NULL)
	@JsonProperty(value = "serviceHeader")
	private CartServiceServiceHeader serviceHeader;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	@JsonProperty(value = "exceptions")
	private CartException[] exceptions;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	@JsonProperty(value = "serviceBody")
	private AFOResponseServiceBody serviceBody;

}
