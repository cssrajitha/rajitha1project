package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude
public class DeviceCategoryInfoGQLRequest {
	
	private Boolean basicphone;
	private Boolean smartphone;
	private Boolean connectedDevice;
	private Boolean internetDevice;
	private Boolean tablet; 
	private Boolean smartwatch;

}
