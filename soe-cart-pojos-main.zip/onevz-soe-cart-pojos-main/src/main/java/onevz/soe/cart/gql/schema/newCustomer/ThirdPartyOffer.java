package onevz.soe.cart.gql.schema.newCustomer;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import java.util.List;

    @Data
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    public class ThirdPartyOffer {
        private String barcodeGroup;

        private String contractInd;

        private String offerRecoveryFeeInd;

        private String rewardType;

        private int droppedOrderNum;

        private String offerType;

        private String offerDesc;

        private int sbdDelay;

        private int bicNoOfOccurences;

        private String loanerOfferInd;

        private String offerID;

        private String offerSubType;

        private String discPrcnt;

        private String redemptionCode;

        private int marketingFamily;

        private String bicBogoOccCode;

        private String discAmt;

        private int redemptionPeriod;

        private String offerName;

        private String marketingDescription;

        private String droppedLocaton;

        private String ccApplicationId;

        private String barcodeId;

        private String offerEndDate;

        private List<PromoBadgeMessagesNFL> promoBadges;

        private String imageName;
    }
