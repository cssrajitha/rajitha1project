package onevz.soe.cart.model;

import lombok.Data;

@Data
public class SalesRepDetails {
    private boolean validSalesRepId;
    private String salesRepGivenName;
    private String redirectUrl;
    private String repId;
    private String status;
}
