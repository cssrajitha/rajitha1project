package onevz.soe.cart.model.AccessoryFinancingOffers;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import onevz.soe.wsclient.bpm.model.ServiceBody;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper=true)
public class AFOServiceBody extends ServiceBody {
	
	@JsonInclude(Include.NON_NULL)
	private AFOServiceRequest serviceRequest;

}
