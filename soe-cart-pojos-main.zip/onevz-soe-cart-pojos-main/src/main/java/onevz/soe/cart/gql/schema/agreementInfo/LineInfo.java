package onevz.soe.cart.gql.schema.agreementInfo;

import lombok.Data;
import onevz.soe.cart.gql.schema.InstallmentContractDetail;
import onevz.soe.cart.model.retrieveCart.InstallmentInfo;


@Data
public class LineInfo {
	
	private String mobileNumber;
	private InstallmentContractDetail installmentContractDetail;
	private InstallmentInfo installmentInfo;
	
}
