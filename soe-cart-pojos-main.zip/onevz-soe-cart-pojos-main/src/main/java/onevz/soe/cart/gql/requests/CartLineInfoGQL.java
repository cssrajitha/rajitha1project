package onevz.soe.cart.gql.requests;

import java.util.ArrayList;

import lombok.Data;

@Data
public class CartLineInfoGQL {
	private ArrayList<ItemsInfoGQL> itemsInfo;

}