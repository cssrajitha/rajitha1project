package onevz.soe.cart.gql.schema.oneclick;

import lombok.Data;
import lombok.EqualsAndHashCode;
import onevz.soe.exception.SOEError;

import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
public class CustomerProfileGraphQLResponse
{

	private List<SOEError> errors;
	private Meta meta;
    private GraphqlData data;
    //private CartLineDetails cartLineDetails;
	private CartHeader cartHeader;
    /*private String recommSkuId;
	private String recommDevId;
    private boolean conflictMtnAvailable;*/
    public CustomerProfileGraphQLResponse()
    {
        this.data = new GraphqlData();
    }
}