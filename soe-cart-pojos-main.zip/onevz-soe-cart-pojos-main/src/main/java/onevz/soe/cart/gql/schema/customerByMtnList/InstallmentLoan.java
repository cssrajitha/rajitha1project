package onevz.soe.cart.gql.schema.customerByMtnList;

import lombok.Data;

@Data
public class InstallmentLoan {

	private Integer pendingNumberOfInstallments;
	private String loanEndDate;
}
