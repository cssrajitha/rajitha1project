package onevz.soe.cart.gql.schema;

import lombok.Data;

import java.util.List;

@Data
public class PromoHubOfferNode {
    private List<PromoHubOffer> promoHubOfferList;
    private int offerCount;
}
