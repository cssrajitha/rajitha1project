package onevz.soe.cart.gql.schema.deviceCount;

import lombok.Data;

@Data
public class DeviceCountLineDetails {

	//private Integer numOfAccessoryAndDeviceItemsInCart;
	private DeviceCountLineInfo lineInfo;
}
