package onevz.soe.cart.gql.schema;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ItemsDigitalInfo {

	private String depletionType;
	private String attention;
	private String addrType;
	private String approvalReason;
	private String fipsCode;
	private Integer itemCount;
	private Integer itemTabSeqNum;
	private CartItemVO cartItems;
	private String mtnLevelEmail;
	private String depletionLocation;
	private String equipPONum;
	@JsonProperty(value = "isPromoSelected")
	private Boolean isPromoSelected;
	private String upgradeInd;

}
