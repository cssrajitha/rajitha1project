package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class EffectiveDate {

	private String backDate;
    private String futureDate;
    private String currentDate;
    private String onDemandDates;
    private String selectedDate;
    private Boolean backDateDisabled;
    private Boolean futureDateDisabled;
}
