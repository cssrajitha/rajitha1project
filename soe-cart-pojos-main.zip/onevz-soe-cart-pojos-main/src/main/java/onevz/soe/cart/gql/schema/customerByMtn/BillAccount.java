package onevz.soe.cart.gql.schema.customerByMtn;

import lombok.Data;

import java.util.List;

/**
 * The Class BillAccount.
 */
@Data
public class BillAccount {

    private AccountAddress accountAddress;
    private List<MtnsList> mtns;

}

