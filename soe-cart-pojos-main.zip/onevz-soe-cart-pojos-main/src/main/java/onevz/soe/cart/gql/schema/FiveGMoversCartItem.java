package onevz.soe.cart.gql.schema;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.orderprocess.model.checkoutdetails.ReturnMethodDetails;

import java.math.BigInteger;

@Data
public class FiveGMoversCartItem {

    private String itemCode;
    private double totalPriceWithDiscount;
    private String sorId;
    private String skuId;
    private String cartItemType;
    private String mobileNumber;
    private String minNumber;
    private String accountNumber;
    private String accountSubNumber;
    private String billingSystem;
    private String description;
    private String capacity;
    private Integer qty;
    private Double deviceDueMonthly;
    private Double deviceDueToday;
    private int bundleSeqNum;
    private String itemPrice;
    private String deviceId;
    private String dipIndicator;
    private Double discountedPercentage;
    private Double discountedPrice;
    private double buyOutTaxAmountUnbilled;
    private double buyOutAmountWithoutTax;
    private Double taxAmount;
    private Double localTax;
    private Double stateTax;
    private String groupDiscInd;
    private String isDropshipItem;
    private String dropshipProviderDesc;
    private ImageUrlMap imageUrlMap;
    private String prodCode1;
    private String prodCode2;
    private String prodCode3;
    private String prodCode4;
    private String prodCode5;
    private String priceType;
    private String btaEligible;
    private String approvingMgrId;
    private String connectedCarEmailAddress;
    private String depletionType;
    private Double catalogPrice;
    private Double instantCreditAmountUsed;
    private Double instantCreditAmountUsedForTaxes;
    private ManualDiscount manualDiscount;
    private ItemColorVO color;
    private Double unitTaxBasedPrice;
    private Double itemNrpPrice;
    private Double itemCost;
    private String upgradeReasonCode;
    private String upgradeReasonDesc;
    private String itemPriceType;
    private CartItemDiscount discounts;
    private String availableReasonCode;
    private String dropShipVendorToken;
    private InventoryVO inventory;
    @JsonProperty(value = "isCustomerProvidedSIM")
    private Boolean isCustomerProvidedSIM;
    private PosSEDOfferListType sedOfferList;
    private RebateOffer rebateOffers;
    private RebateOfferListType rebateOffer;
    private ThirdPartyPromoOffer thirdPartyPromo;
    @JsonProperty(value = "isNetworkExtender")
    private Boolean isNetworkExtender;
    @JsonProperty(value = "ispuEligible")
    private Boolean ispuEligible;
    private int itemSeqNum;
    private String make;
    private String mgrIdForDisc;
    private String mgrIdForUpgr;
    private String model;
    private String mtnOOWReasonCode;
    private String newInUnOpenedBox;
    @JsonProperty(value = "numberShareEligible")
    private Boolean numberShareEligible;
    private String rebateEligibilityInd;
    private RefundExchangeDetails refundExchangeDetails;
    private Double repCapAmount;
    @JsonProperty(value = "sddEligible")
    private Boolean sddEligible;
    private String simId;
    @JsonProperty(value = "smartIMEI")
    private Boolean smartIMEI;
    private String ssnOOWReasonCode;
    private String taxBasedPriceFlag;
    private int year;
    private String macAddress;
    private String sellerPrice;
    private String edgeDeviceCap;
    private String productId;
    private NumberShareCapabilityInfo numberShareCapabilityInfo;
    private TaxDetailsList taxDetailsList;
    private String eSIM;
    @JsonProperty(value = "hasDeviceUnlockPolicy")
    private Boolean hasDeviceUnlockPolicy;
    private String manufacturer;
    private BigInteger quantityOnHand;
    private String preBackDate;
    private Double discountAmount;
    private String bundleAccessorySku;
    private String bundleProductId;
    private String connectedCarColor;
    private String connectedCarMobile;
    private String customBundleId;
    private String taxBasis;
    private Boolean iconicPhone;
    private Boolean ringBell;
    private Double deviceDollarApplied;
    private Boolean isPreconfigureEnabled;
    private String deviceStartDate;
    private String countDownText;
    private String countDownTimerText;
    private Boolean isHumDevice;
    private Boolean isSmartLocator;
    private Boolean isSecurityAlarm;
    private Boolean isMotoMod;
    private Boolean isConnectedCar;
    @JsonProperty(value = "accountLevelAccessory")
    private Boolean accountLevelAccessory;
    private Double itemPriceOnDeviceDollarApplied;
    private Boolean byodESimPhone;
    private Boolean scannedItem;

    private PromoHubOfferNode promoHubOfferList;
    private Boolean qrScanNeededForEsimActivation;
    private Boolean isPreconfigureDuringAddDevice;
    private String deviceDisplayName;
    private String accessoryGiftCardId;
    private Double accessoryGiftCardAmount;
    private String itemPriceAfterVZDollar;
    private Double tradeInAmountTowardsUserDPUsed;
    private RecycleTaxDetailType recycleTaxDetail;
    @JsonProperty(value = "appleCareAccessoryFlag")
    private Boolean appleCareAccessoryFlag;
    private String sorDeviceCategory;
    private String sorDeviceType;
    private String operatingSystem;

    private String vendingKioskItem;
    private RfexEligibility rfexEligibility;
    private Boolean tradeInAutoPull;
    private String adjustmentAmount;
    private Boolean priceAdjustment;
    private Integer priceAdjustmentQty;
    private Integer newPurchasedQty;
    private String canonicalUrl;
    private String networkBandwidthType;

    private Boolean selectedForRFEX;
    private Boolean selectedForPAD;
    private Boolean bogoItem;
    private Integer refxItemSeqNum;
    private Boolean restrictedAccySku;
    private Boolean maxAccyPurchaseLimit;
    private String exchangeItemSeqNum;
    private String refundType;
    //XBOX Retail Ordering changes
    private CXPFinanceOptionDetails financeOptionDetail;
    private String serialNumber;
    private String eDeviceId;
    private String eDeviceSku;
    private String eDeviceDisplayName;
    private String eDeviceDescription;

    //RFEX Return Anywhere
    private String submissionId;
    private String returnMethod;
    private ReturnMethodDetails returnMethodDetails;
    private String accessoryBMSM;

    private Boolean quantityAllowed;
    private String productDescription;
    private String sorProductFamily;
    private String imei2;

}
