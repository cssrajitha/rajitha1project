package onevz.soe.cart.gql.schema.numberShare;

import lombok.Data;


@Data
public class CartItems {

	private CartItem cartItem;
	
	
}
