package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.requests.PaymentData;

/**
 * @author AVULAN5 
 * //Added the class for handling the defects NSADT-52308,
 *         NSADT-30424.
 *
 * 
 */
@Data
public class PaymentInfo {
	double lastPaymentAmount;
	//private double paymentAmount;


	//private PaymentData paymentData;

}
