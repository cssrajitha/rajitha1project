package onevz.soe.cart.gql.requests;

import java.util.List;

import lombok.Data;
import onevz.soe.cart.gql.schema.calculateMultiLineTaxForCart.LineTaxDetail;
import onevz.soe.cart.gql.schema.calculateMultiLineTaxForCart.ZipCodeDetails;

@Data
public class CalculateMultilineTaxGQLRequest {

	private int count;
	private String orderTotalTax;
	private ZipCodeDetails zipCodeDetails;
	private List<LineTaxDetail> lineTaxDetails;
}
