package onevz.soe.cart.gql.schema.newCustomer;

import lombok.Data;
import onevz.soe.cart.gql.schema.RetrieveMiniCartItem;

@Data
public class RetrieveMiniCartItemsInfo {
    private Shipping shipping;
    private RetrieveMiniCartItem cartItems;
}