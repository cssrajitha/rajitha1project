package onevz.soe.cart.model.accountPin;

import lombok.Data;
import lombok.EqualsAndHashCode;
import onevz.soe.wsclient.bpm.model.response.ServiceResponse;

@Data
@EqualsAndHashCode(callSuper = true)
public class AccountpinServiceResponse extends ServiceResponse {

    private AccountPinContext context;
}
