package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class AccountLevelDiscountedElements {

	private String actualCost;
	private String elementId;
	private String elementType;
	private String finalCost;
	private DiscountsDetail discountsDetail;
}
