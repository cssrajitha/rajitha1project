package onevz.soe.cart.gql.schema;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import onevz.soe.cart.model.common.FeatureMessages;
import onevz.soe.cart.model.common.McsSubscription;
import onevz.soe.cart.model.retrieveCart.*;

import java.util.List;

@Data
public class TruckRollServiceInfo {

	private Cart5GAppointment cart5GAppointment;
}
