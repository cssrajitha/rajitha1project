package onevz.soe.cart.gql.schema.cartItems;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.BundleAccessory;

@Data
public class CartItemsLineInfo {

	private CartItems_ItemsInfo itemsInfo; 
	@JsonProperty(value="preOrBackOrder")
	private Boolean preOrBackOrder;
	private Double totalDueToday;
	private Double totalDueMonthly;
	private List<BundleAccessory> bundleAccessoryInfo;
	@JsonProperty(value = "isModConnected")
	private Boolean isModConnected;
	@JsonProperty(value = "modDevice")
	private Boolean modDevice;
}
