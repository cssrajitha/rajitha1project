package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import onevz.wsclient.cxp.annotations.Query;

@Data
@JsonInclude
public class InEligibilityGQLRequest {
	
	private Boolean votPendingOrder;
	private Boolean mtnPermanentlyInactive;
	private Boolean mtnSuspended;
	private Boolean starIndicator;
	private Boolean hubDevice;
	@Query(namespaces = {"gql-attribute-optimized"})
	private Boolean mtnInstallment;
	private Boolean pricePlanPendingOrder;
	private Boolean iconicPendingOrder;
	private Boolean equipmentUpgradeWithSpoPendingOrder;
	private Boolean lineLevelPendingOrder;
	private Boolean pendingOrder;
	@Query(namespaces = {"gql-attribute-optimized"})
	private Boolean humDevice;

}
