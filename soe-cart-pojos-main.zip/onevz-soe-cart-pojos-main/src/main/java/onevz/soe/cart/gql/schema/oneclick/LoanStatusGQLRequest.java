package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude
public class LoanStatusGQLRequest {
	private boolean active;
	private boolean AOL;
	private boolean buyout;
	private boolean canceled;
	private boolean earlyUpgrade;
	private boolean edgeUp;
	private boolean forceBuyout;
	private boolean indirectPendingApproval;
	private boolean indirectRejectedFinal;
	private boolean indirectRejectedInitial;
	private boolean indirectWaitingForFax;
	private boolean paid;
	private boolean pending;
	private boolean reassign;
	private boolean suspendedForMilitaryService;
	private boolean transferedToAnotherLoan;

}
