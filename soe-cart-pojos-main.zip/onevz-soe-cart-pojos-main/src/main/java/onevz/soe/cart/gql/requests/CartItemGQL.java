package onevz.soe.cart.gql.requests;

import lombok.Data;

@Data
public class CartItemGQL {
	 private String cartItemType;
	 private int qty;
	 private String sorId;

}