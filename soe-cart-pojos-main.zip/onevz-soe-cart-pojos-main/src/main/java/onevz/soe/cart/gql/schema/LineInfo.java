package onevz.soe.cart.gql.schema;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntent;
import onevz.soe.cart.model.common.SecondNumber;
import onevz.soe.cart.model.retrieveCart.BundleAccessory;
import onevz.soe.cart.model.retrieveCart.BuyOutDetail;
import onevz.soe.cart.model.retrieveCart.EdgeUpDetail;
import onevz.soe.cart.model.retrieveCart.InstallmentInfo;
import onevz.soe.cart.model.retrieveCart.MtnDetails;
import onevz.soe.cart.model.retrieveCart.OneTimeCharges;
import onevz.soe.cart.model.common.BvoOffers;
import onevz.soe.cart.model.common.Propositions;
import onevz.soe.cart.model.retrieveCart.RefundExchangeInfo;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class LineInfo {

	private Boolean isCommonPDP;
	private Boolean isTradeInIntentSelected;
	private Integer multiLineSeqNumber;
	private String lineActivityType;
	@JsonProperty(value="isCpe")
	private Boolean isCpe;
	private String saleType;
	private Double totalDueToday;
	private Double totalDueTodayWithoutTax;
	private Double totalDueTodayWithoutTaxWithoutDiscount;
	private Double totalDueMonthly;
	private String mobileNumber;
	private Boolean showGlobalChoiceOffer;
	private ServiceInfo serviceInfo;
	@JsonProperty(value="selectedOffers")
	private List<BvoOffers> selectedOffers;
	private ItemsInfo itemsInfo;
	@JsonProperty(value="isDevicePlanCompatible")
	private Boolean isDevicePlanCompatible;
	@JsonProperty(value="portinMtnAssignment")
	private Boolean portinMtnAssignment;	
	private String assignMTNIndicator;
	@JsonProperty(value="impactedLine")
	private Boolean impactedLine;
	private String costCenterCode;
	@JsonProperty(value="preOrBackOrder")
	private Boolean preOrBackOrder;
	@JsonProperty(value="ispuItem")
	private Boolean ispuItem;
	@JsonProperty(value="ispuItemBYOD")
	private Boolean ispuItemBYOD;
	private InstallmentInfo installmentInfo;
	private InstallmentInfo rfexInstallmentInfo;
	private EdgeUpDetail edgeUpDetail;
	private BuyOutDetail buyOutDetail;
	private InstallmentContractDetail installmentContractDetail;
	private InstallmentContractDetail rfexInstallmentContractDetail;

	private LineLevelDiscount lineLevelDiscount;
	private MtnDetails mtnDetails;
	private NumbershareInfo numbershareInfo; 
	private String securityDepositAmount;
	private String securityDepositWaiveCode;
	private String restrictedProductType;
	private String restricted;
	private String lineNumber;
	private Boolean portInLater;
	private OneTimeCharges oneTimeCharges;
	@JsonProperty(value = "ispuRepAssisted")
	private Boolean ispuRepAssisted;
	private List<BundleAccessory> bundleAccessoryInfo;
	private Boolean fiveGToFourGDownGrade;
	@JsonProperty(value = "isModConnected")
	private Boolean isModConnected;
	@JsonProperty(value = "modDevice")
	private Boolean modDevice;
	private String modAccessFee;
	private String deviceTypeSelected;
	@JsonProperty(value = "byodCapable")
	private Boolean byodCapable;
	private String reasonCode;
	@JsonProperty(value = "selectedEUPDeviceForBYOD")
	private Boolean selectedEUPDeviceForBYOD;
	
	@JsonProperty(value = "isCarLine")
	private Boolean isCarLine;
	private String nickName;
	@JsonProperty(value = "buySimOnly")
	private Boolean buySimOnly;
	private String donorMtn;
	private String launchType;
	private Propositions disqualifiedPropositions;
	private Propositions qualifiedPropositions;
	private String lineCreator;
	private String amRole;
	private String managerComments;

	private RefundExchangeInfo refundExchangeInfo;
	
	private double lineRefundTotal;
	private double lineExchangeTotal;
	private String lineNAF;
	
	@JsonProperty(value = "ispuDownPaymentAdjstRequired")
	private Boolean ispuDownPaymentAdjstRequired;
	@JsonProperty(value = "ispuDownPaymentAmount")
	private Float ispuDownPaymentAmount;
	@JsonProperty(value = "lineWithSkipMDN")
	private Boolean lineWithSkipMDN; 
	@JsonProperty(value = "protectionNotRequired")
	private boolean protectionNotRequired;
	
	private OfferInfoList offerInfoList;
	
	private String totalSurchargeAmount;

	private Boolean sugAllowed;
	
	private String addedReplenishmentAmt;
	
	private String autoAddedReplenishmentAmt;

	private String totalDueAddOnMonthly;

	private String deviceCategoryName;

	private String totalPriceOfPlanAndPerks;

	private SecondNumber secondNumber;
	private Boolean payOffYourDevice;
	private String payOffYourDeviceOfferType;
	private String[] pyodEligibleTradeItems;
	private PayOffDeviceInfo payOffDeviceInfo;
	
	@JsonProperty(value="accountOwner")
	private String accountOwner;
	private AddPromoIntent[] promoIntent;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String upc;

	@JsonProperty(value = "activateLaterDate")
	@Schema(name = "activateLaterDate", description = "Date selected for activate later option")
	private String activateLaterDate;

	@JsonProperty(value="oneTalkLine")
	@Schema(name = "oneTalkLine", description = "Line selected for OneTalk Device")
	private String oneTalkLine;
	@JsonProperty(value="oneTalkGroupId")
	@Schema(name = "oneTalkGroupId", description = "GroupId for OneTalk Device")
	private String oneTalkGroupId;
	@JsonProperty(value="oneTalkGroupName")
	@Schema(name = "oneTalkGroupName", description = "GroupName for OneTalk Device")
	private String oneTalkGroupName;
}
