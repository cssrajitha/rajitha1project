package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class ECPDInfo {

	private String accessDiscountPercent;
	private String accessDiscountReturnCode;
	private String ecpdEmailId;
	private String ecpdGroupId;
	private String ecpdReservationNum;
	private String emailValidated;
	private String imagesCapturedInd;
	private String multiLineSeqNumber;
	private String planRulesReturnCode;
	private String profileId;
	private String profileInd;
	private String salesRepIdInd;
	private String serviceInd;
	private String splitCompInd;
}
