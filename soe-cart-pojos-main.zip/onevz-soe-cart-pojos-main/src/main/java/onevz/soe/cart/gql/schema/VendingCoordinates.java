package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class VendingCoordinates {
	
	private String sku;
	private String skuDesc;
	private String vendColumn;
	private String vendRow;
	private String mobileNumber;
	private String cartItemType;

}
