package onevz.soe.cart.gql.schema.getPairedDevices;

import lombok.Data;


@Data
public class CartItems {

	private CartItem[] cartItem;
	
	
}
