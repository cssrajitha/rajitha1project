package onevz.soe.cart.gql.requests;

import java.util.List;

import lombok.Data;
import onevz.soe.cart.gql.schema.AccountLevelDiscount;
import onevz.soe.cart.gql.schema.VendingCoordinates;
import onevz.soe.cart.gql.schema.newCustomer.CartHeader;
import onevz.soe.cart.gql.schema.newCustomer.CustomerProfileForNSE;
import onevz.soe.cart.gql.schema.newCustomer.LineDetailsVO;
import onevz.soe.cart.gql.schema.newCustomer.OrderDetails;
import onevz.soe.cart.gql.schema.VerizonUpToastMessage;
import onevz.soe.cart.model.retrieveCart.EcpdProfileInfo;
import onevz.soe.cart.model.retrieveCart.GlobalPromotions;
import onevz.soe.cart.model.validateCart.CartValidationError;

@Data
public class ValidateCartNewCustomerGQLRequest {

	private String cartId;
	private CartHeader cartHeader;
	private OrderDetails orderDetails;
	private LineDetailsVO lineDetails;
	private GlobalPromotions globalPromotions;
	private AccountLevelDiscount accountLevelDiscount;
	private VerizonUpToastMessage verizonUpToastMessage;
	private CartValidationError cartValidationErrors;
	private EcpdProfileInfo ecpdProfile;
	private List<VendingCoordinates> vendingCoordinatesList;
	private CustomerProfileForNSE customerProfileForNSE;
	private ACPInfoGQL acpInfo;
}
