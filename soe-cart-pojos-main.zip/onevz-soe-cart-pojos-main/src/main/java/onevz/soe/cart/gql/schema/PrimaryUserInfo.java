package onevz.soe.cart.gql.schema;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class PrimaryUserInfo {

	private String firstName;
	private String lastName;
	private String preferFirstName;
	private String preferLastName;
	private String preferPronoun;
	private PrimaryUserAddress address;
	@JsonProperty(value="isValidAddress")
	private Boolean isValidAddress;
	private String altBsnsName;
	private String attention;
	private String bsnsName;
	private String bsnsTitle;
	private String caAgreementEmailId;
	private String caAgreementEmailInd;
	private String contactPersonName;
	private String contactPersonPhone;
	private String courtesyCode;
	private String dpAgreementEmailId;
	private String dpAgreementEmailInd;
	private String emailId;
	private String eventCorrelationId;
	@JsonProperty(value="isNameUpdated")
	private Boolean isNameUpdated;
	private String prefix;
	private String midInitials;
	private String myVerizonInd;
	private String printLocally;
	private String suffix;
	private String titleName;
	private String workEmailId;
}
