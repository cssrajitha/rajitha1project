package onevz.soe.cart.gql.schema;

import lombok.Data;

import java.util.List;

@Data
public class WFMOrderInfo {

    private String wfmId;
    private String wfmOrderId;
    private String wfmUserId;
    private String wfmOrderType;
    private List<WfmPaymentInfo> wfmPaymentInfo;

}
