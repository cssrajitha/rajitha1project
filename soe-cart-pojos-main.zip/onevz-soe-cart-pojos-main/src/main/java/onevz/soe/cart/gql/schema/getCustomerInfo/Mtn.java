package onevz.soe.cart.gql.schema.getCustomerInfo;

import lombok.Data;

import java.util.List;

@Data
public class Mtn {

    private String mtn;

    private PrimaryUser primaryUser;

    private List<EquipmentInfo> equipmentInfos;

    private PricePlanInfo pricePlanInfo;
}
