package onevz.soe.cart.gql.schema.numberShare;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.ImageUrlMap;
import onevz.soe.cart.model.retrieveCart.ItemColorVO;


@Data
public class CartItem {

	private String cartItemType;
	private String description;
	private String depletionType;
	private ItemColorVO color;
	private ImageUrlMap imageUrlMap;
	private String simId;
	private Boolean smartIMEI;
	private String sorId;
	private Boolean numberShareEligible;
	
}
