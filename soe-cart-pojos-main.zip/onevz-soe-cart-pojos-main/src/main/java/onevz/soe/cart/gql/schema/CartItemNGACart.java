package onevz.soe.cart.gql.schema;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.ImageUrlMap;

@Data
public class CartItemNGACart {
	private ImageUrlMap imageUrlMap;
	private String canonicalUrl;
	private String description;
	private String sorDeviceCategory;
	private double totalPriceWithDiscount;
	private String cartItemType;
	private Integer qty;
	private String sorId;
}
