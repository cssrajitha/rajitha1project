package onevz.soe.cart.gql.schema;

import lombok.Data;

/**
 * @author munjra4
 */
@Data
public class MtnDetailsLWVO {
    private String lineNumber;
}
