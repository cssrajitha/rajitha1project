package onevz.soe.cart.gql.schema.bundlebuildercartlightweight;

import lombok.Data;

@Data
public class ColorLW {
    private String color;
    private String colorDisplayName;
}
