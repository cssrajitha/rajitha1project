package onevz.soe.cart.gql.requests;

import java.util.List;

import lombok.Data;
@Data
public class CartLineDetailsGQL {
	 private List<CartLineInfoGQL> lineInfo;

}