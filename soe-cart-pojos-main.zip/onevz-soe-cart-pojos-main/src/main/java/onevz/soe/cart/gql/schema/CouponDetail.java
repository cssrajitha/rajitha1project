package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class CouponDetail {
	
	private String couponCode;
	private String referrerCustId;
	private String referrerAcctNo;
	private String referrerMtn;
	private String promoStatus;
	private String associationDate;
	private String couponType;
	private String couponValid;
	

}
