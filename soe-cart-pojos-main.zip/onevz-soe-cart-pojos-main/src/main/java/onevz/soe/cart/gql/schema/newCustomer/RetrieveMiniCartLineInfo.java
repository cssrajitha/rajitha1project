package onevz.soe.cart.gql.schema.newCustomer;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import onevz.soe.cart.gql.schema.NumbershareInfo;
import onevz.soe.cart.model.retrieveCart.BundleAccessory;
import onevz.soe.cart.model.retrieveCart.InstallmentInfo;
import onevz.soe.cart.model.retrieveCart.OneTimeCharges;
import java.util.List;

@Data
public class RetrieveMiniCartLineInfo {
    private Integer multiLineSeqNumber;
    private String lineActivityType;
    private Double totalDueToday;
    private String mobileNumber;
    private RetrieveMiniCartItemsInfo itemsInfo;
    private String lineNumber;
    private OneTimeCharges oneTimeCharges;
    private String deviceTypeSelected;
    @JsonProperty(value="preOrBackOrder")
    private Boolean preOrBackOrder;
    private List<BundleAccessory> bundleAccessoryInfo;
    private InstallmentInfo installmentInfo;
    private NumbershareInfo numbershareInfo;
    private double totalDueMonthlyBeforeCredit;
    private String totalDueTodayWithoutAccessory;
}