package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class FiveGMoversSelectedOffers {

    private String id;

    private String subType;

    private String description;
}
