package onevz.soe.cart.gql.schema.bundlebuildercartlightweight;

import lombok.Data;

import java.util.ArrayList;

@Data
public class LineDetailsLW {
    private Integer numOfLines;
    private Integer numofLinesAAL;
    private Integer numofLinesEUP;
    private Integer numOfAccessoryAndDeviceItemsInCart;
    private ArrayList<LineInfoLW> lineInfo;
}
