package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class LineDiscounts {

	private String amount;
	private String description;
	private String id;
	private String noOfDays;
	private String type;
}
