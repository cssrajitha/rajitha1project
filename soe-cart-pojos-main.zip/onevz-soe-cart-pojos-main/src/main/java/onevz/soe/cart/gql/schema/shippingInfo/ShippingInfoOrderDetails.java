package onevz.soe.cart.gql.schema.shippingInfo;

import lombok.Data;

@Data
public class ShippingInfoOrderDetails {

	private String locationCode;
	private Double totalDueToday;
	private ShippingInfoOrderList orderList;
}
