package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class PreToPostMtns {

	private String accountOwner;
	private String accountMembers;
	
}
