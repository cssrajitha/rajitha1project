package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.taxAndDues.OrderDetails;

@Data
public class TaxAndDuesGQLRequest {

	private String cartId;
	private OrderDetails orderDetails;
}
