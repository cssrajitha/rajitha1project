package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class DispositionOptionList {
    private String behavior;
    private int id;
    private String label;
}
