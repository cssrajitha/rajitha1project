package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class NbsDetails {

	private Customer customer;
}
