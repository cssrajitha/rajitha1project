package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude
public class PaymentInfo {
	
	private String pastDueBalance;
	private String arPastDueBalance;
	private Boolean isBalancePastDue;

}
