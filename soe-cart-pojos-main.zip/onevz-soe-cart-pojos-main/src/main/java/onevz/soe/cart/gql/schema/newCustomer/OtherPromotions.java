package onevz.soe.cart.gql.schema.newCustomer;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.Promos;

@Data
public class OtherPromotions {
	
	private String elementId;
	private String elementType;
	private String actualPrice;
	private String finalPrice;
	private Promos promos;

}
