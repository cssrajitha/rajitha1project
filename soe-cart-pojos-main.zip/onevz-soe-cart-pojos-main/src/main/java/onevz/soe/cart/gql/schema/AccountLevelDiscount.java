package onevz.soe.cart.gql.schema;

import lombok.Data;


@Data
public class AccountLevelDiscount {

	private AccountLevelDiscountedElements discountedElements;
}
