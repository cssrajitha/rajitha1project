package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class CreditCardDetails {
    private String creditCardType;
    private String cardNumber;
    private String cardAddressZip;
    private String cardExpDate;
    private String type;
    private String lineID;

}
