package onevz.soe.cart.initiatecart;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.wsclient.bpm.model.ServiceBody;
import onevz.soe.wsclient.bpm.model.ServiceHeader;

import java.util.List;

@Data
public class InitiateCartUIResponse {

    private ServiceHeader serviceHeader;
    private ServiceBody serviceBody;
    @JsonProperty("errors")
    private List<CartError> errors;

}
