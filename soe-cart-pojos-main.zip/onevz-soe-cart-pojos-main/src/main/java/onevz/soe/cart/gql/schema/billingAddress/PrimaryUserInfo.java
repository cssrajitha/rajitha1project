package onevz.soe.cart.gql.schema.billingAddress;

import lombok.Data;
import onevz.soe.cart.gql.schema.PrimaryUserAddress;

@Data
public class PrimaryUserInfo {
	
	private PrimaryUserAddress address;
	
}
