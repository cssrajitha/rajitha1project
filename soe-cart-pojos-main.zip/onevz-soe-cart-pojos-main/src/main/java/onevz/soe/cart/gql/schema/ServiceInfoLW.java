package onevz.soe.cart.gql.schema;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.SbdOffer;

@Data
public class ServiceInfoLW {

	private String mtn;
	private SbdOffer sbdOffer;
}
