package onevz.soe.cart.gql.schema.numberShare;

import lombok.Data;


@Data
public class ServiceInfo {

	private PrimaryUserInfo primaryUserInfo;
	private String trunkMTN;
	
}
