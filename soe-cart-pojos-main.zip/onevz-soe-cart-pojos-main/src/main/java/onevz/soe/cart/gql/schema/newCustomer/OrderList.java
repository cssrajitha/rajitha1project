package onevz.soe.cart.gql.schema.newCustomer;

import lombok.Data;
import onevz.soe.cart.gql.schema.newCustomer.CreditApplication;

@Data
public class OrderList {
	
	private CreditApplication creditApplication;
	private String orderActivityType;
	private Integer orderNumber;
	private Integer numOfLinesForOrderActivityType;
	private Long preOrderNumber;
	

}
