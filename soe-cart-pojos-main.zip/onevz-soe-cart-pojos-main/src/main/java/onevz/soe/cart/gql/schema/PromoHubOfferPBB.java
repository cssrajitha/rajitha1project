package onevz.soe.cart.gql.schema;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import onevz.soe.cart.model.retrieveCart.PromoBadgeMessages;
import onevz.wsclient.cxp.annotations.Query;

import java.util.List;

@Data
public class PromoHubOfferPBB {
    private String offerId;
    private String offerName;
    private String promoType;
    private String promotionId;
    private String availableFlows;
    private List<PromoBadgeMessages> promoBadges;
    private String currentPlanQualifies;
    private String online;
    private String lineRequired;
    private String flashSale;
    private double discAmt;
    private double getProductMaxPurch;
    private String upto;
    private String planReqmt;
    private String selectPlan;
    private String getProductsCategory;
    private String getProductName;
    private String accessoryId;
    private Boolean isStrategicOffer;
    private String devProdId;
    private String canonicalUrl;
    private String[] compatibleOffers;
    private StrategicOfferDetails strategicOfferDetails;
    @Schema(description = "imageName", example = "imageName")
    private String imageName;
    private Boolean isCachedOffer;
    private Boolean isEntryPointOffer;
    private String pctSubHeader;
    private Boolean isOfferStackableWithAll;
    private Boolean selectedOffer;
}

