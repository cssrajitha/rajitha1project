package onevz.soe.cart.gql.schema;

import lombok.Data;
import java.math.BigInteger;

@Data
public class CartHeaderLW {
    private String sourceSystem;
    private String cartCreator;
    private String cartId;
    private String fullAccountNumber;
    private String caseId;
    private String cartCreatorSalesRepId;
    private String cartCreatorChannelId;
    private String vendorId;
    private String visionCustomerType;
    private String preConfiguredCartType;
    private String preConfiguredCartTypeDuringAddDevice;
}
