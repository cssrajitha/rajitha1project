package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class TwoYearContract {

	private String endDate;
}
