package onevz.soe.cart.gql.schema.newCustomer;

import lombok.Data;

@Data
public class CartHeader {
	
	private String visionCustomerType;
	private Boolean isERTRep;
	private Boolean isCoreRep;

}
