package onevz.soe.cart.gql.requests;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import onevz.soe.cart.gql.schema.LineDetailsLightWeightDigitalCartVO;
import onevz.soe.cart.model.validateCart.CartValidationError;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RetrieveCartLightWeightDigitalGQLRequest {

	private String cartId;

	private LineDetailsLightWeightDigitalCartVO lineDetails;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	@JsonProperty(value = "cartValidationErrors")
	private List<CartValidationError> cartValidationErrors;

}
