package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude
public class TransferUpgradeEligibilityGQLRequest {
	
	private Boolean giverEligible;
	private Boolean takerEligible;
	private String takerMtns;

}
