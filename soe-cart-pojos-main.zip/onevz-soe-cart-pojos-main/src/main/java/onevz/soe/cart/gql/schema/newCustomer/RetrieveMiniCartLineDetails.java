package onevz.soe.cart.gql.schema.newCustomer;

import lombok.Data;

@Data
public class RetrieveMiniCartLineDetails {
    private PlanDiscount planDiscount;
    private RetrieveMiniCartLineInfo lineInfo;
    private Integer numOfAccessoryAndDeviceItemsInCart;
    private Double totalDownPaymentAmt;
    private Integer numofAccessories;
    private Integer numOfLines;
}