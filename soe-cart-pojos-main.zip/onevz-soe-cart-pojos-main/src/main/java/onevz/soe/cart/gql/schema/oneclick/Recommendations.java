package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;

@Data
@JsonInclude
public class Recommendations {
	
	private String rank;
	private String propositionID;
	private String externalID;
	private String propositionName;
	private String propositionMessage;
	private String dispositionListID;
	private List<String> eligibleMtns;
	private List<AvailableMtns> availableMtns;

}
