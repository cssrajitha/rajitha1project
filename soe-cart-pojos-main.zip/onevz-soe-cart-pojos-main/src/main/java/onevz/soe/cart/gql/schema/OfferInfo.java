package onevz.soe.cart.gql.schema;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OfferInfo {
    private String originalOrderNumber;
    private String originalLocationCode;
    private String dbTimestamp;
    private String currentOfferID;
    private String offerTypeCd;
    private String priorDQ;
    private String wfgStatus;
    private String bicOccurencesApplied;
    private String bicBogoType;
    private String offerProdId;
    private String offerDescription;
    private String recurringCreditAmount;
    private String bicOccurencesRemaining;
    private String creditsEndDate;
    private String actionCode;
    private String sedOfferCategoryCode;
    private String recycleDeviceStatus;
}
