package onevz.soe.cart.gql;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ServiceAddress {
    @Schema(description = "Service Address zipCode")
    private String zipCode;
    @Schema(description = "Service Address zipCodePlus4")
    private String zipCodePlus4;
    @Schema(description = "Service Address addressLine1")
    private String addressLine1;
    @Schema(description = "Service Address addressLine2")
    private String addressLine2;
    @Schema(description = "Service Address city")
    private String city;
    @Schema(description = "Service Address state ")
    private String state;
}
