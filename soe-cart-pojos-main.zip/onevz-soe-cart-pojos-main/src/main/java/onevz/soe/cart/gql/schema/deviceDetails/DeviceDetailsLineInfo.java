package onevz.soe.cart.gql.schema.deviceDetails;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class DeviceDetailsLineInfo {

	private String mobileNumber;
	private String lineActivityType;
	@JsonProperty(value="isCpe")
	private Boolean isCpe;
	private DeviceDetailsServiceInfo serviceInfo;
	private DeviceDetailsItemsInfo itemsInfo;
	private String deviceCategoryName;
	
}
