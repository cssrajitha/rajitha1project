package onevz.soe.cart.model.abandonCart;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonInclude(Include.NON_NULL)
public class CXPRetriveNextGenAbandonCartData {
	private CXPRetrieveLatestDevice retrieveLatestDevice;
	private CXPRetrieveLatestPlan retrieveLatestPlan;
	private String flowName;
    private String flowType;
}
