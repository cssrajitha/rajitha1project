package onevz.soe.cart.gql.schema.getPairedDevices;

import lombok.Data;


@Data
public class ServiceInfo {

	private String mldTrunkMTN;
	private String mtn;
	private String numberShareInd;

}
