package onevz.soe.cart.gql.schema;

import java.util.List;

import lombok.Data;
@Data
public class PromoHubOffer {
    private String offerId;
    private String offerName;
    private String promoType;
    private double discAmt;
    private String[] eligibleSkuList;
    private String productDisplayName;
    private String promotionId;
    private String availableFlows;
    private List<PromoBadgeMessages> promoBadges;
    private String currentPlanQualifies;
    private String accessoryId;
    private String getProductsCategory;
}
