package onevz.soe.cart.gql.schema.deviceDetails;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.ImageUrlMap;
import onevz.soe.cart.model.retrieveCart.ItemColorVO;

@Data
public class DeviceDetailsCartItem {

	private String cartItemType;
	private String deviceId;
	private String sorId;
	private String skuId;
	private String simId;
	@JsonProperty(value = "isCustomerProvidedSIM")
	private Boolean isCustomerProvidedSIM;
	private String description;
	private String depletionType;
	private String sellerPrice;
	private String edgeDeviceCap;
	private ItemColorVO color;
	private ImageUrlMap imageUrlMap;
	private Double discountAmount;
	private String productId;
}
