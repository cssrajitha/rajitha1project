package onevz.soe.cart.gql.schema;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.PayPalDetail;
import onevz.soe.cart.model.retrieveCart.TradeInAddress;
import onevz.soe.cart.model.retrieveCart.TradeInItem;
@Data
public class TradeInDetail {

    private List<TradeInItem> tradeInItems;
    private TradeInAddress address;
    private PayPalDetail payPalDetail;
    @JsonProperty(value = "instantCreditEligible")
    private Boolean instantCreditEligible;
    private String instantBIC;
    private Double instantCreditAmount;
    private String tradeInType;
    private Double totalInstantCreditAmount;
    private Double totalInstantCreditAmountUsed;
    private Double instantCreditAmountRemaining;
    private Boolean showICPage;
    private String customerName;
    
	private Double totalInstantCreditAmountForDevices;
	private Double totalInstantCreditAmountForAccessories;
	private Double totalInstantCreditAmountForTaxes;
	private Double totalInstantCreditAmountUsedForDueToday;
	
	//VZWYZDD-1411
	private String tradeInShippingType;

}
