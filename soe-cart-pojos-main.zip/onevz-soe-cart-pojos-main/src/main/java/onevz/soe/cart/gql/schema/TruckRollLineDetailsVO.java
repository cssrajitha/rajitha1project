package onevz.soe.cart.gql.schema;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import onevz.soe.cart.model.common.McsSubscription;
import onevz.soe.cart.model.retrieveCart.RefundTradeInDetail;

import java.util.List;

@Data
public class TruckRollLineDetailsVO {

	private TruckRollLineInfo lineInfo;

}
