package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.getCustomerInfo.BillAccount;
import onevz.soe.cart.gql.schema.getCustomerInfo.CustomerCbrInfo;

import java.util.List;

@Data
public class GetCustomerInfoGQLRequest {

    private String email;

    private List<BillAccount> billAccounts;

    private CustomerCbrInfo customerCbrInfo;
}