package onevz.soe.cart.gql.schema.bundlebuildercartlightweight;

import lombok.Data;

import java.util.List;

@Data
public class SbdOfferLW {
    private String multiLineSeqNumber;
    private String mobileNumber;
    private String offerId;
    private String description;
    private String discAmt;
    private String bicNoOfOccurences;
    private String promoType;
    private String isStrategicOffer;
    private List<PromoBadgeMessagesLW> promoBadges;
}
