package onevz.soe.cart.model.AccessoryFinancingOffers;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import onevz.soe.cart.model.addAccessory.AddAccServiceBody;
import onevz.soe.cart.model.common.CartServiceServiceHeader;
import onevz.soe.wsclient.bpm.model.request.BPMServiceRequest;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper=true)
public class AccessoryFinancingOffersPegaRequest extends BPMServiceRequest {

	@JsonInclude(Include.NON_NULL)
	private CartServiceServiceHeader serviceHeader;
	
	@JsonInclude(Include.NON_NULL)
	private AFOServiceBody serviceBody;

}
