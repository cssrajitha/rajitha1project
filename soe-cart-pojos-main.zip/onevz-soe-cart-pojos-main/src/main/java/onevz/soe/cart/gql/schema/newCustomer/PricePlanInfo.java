package onevz.soe.cart.gql.schema.newCustomer;

import lombok.Data;

@Data
public class PricePlanInfo {
	
	private String categoryCode;
	private String pricePlanCode;
	private String pricePlanDesc;
	private Double planPrice;
	private String dataAllowance;
	private String featureText;
	private String pricePlanDisplayName;
	private String pricePlanCategoryName;

}
