package onevz.soe.cart.gql.requests;

import lombok.Data;

@Data
public class CustomerGQLRequest {

	private String accountNum;
	private String ecode;
}
