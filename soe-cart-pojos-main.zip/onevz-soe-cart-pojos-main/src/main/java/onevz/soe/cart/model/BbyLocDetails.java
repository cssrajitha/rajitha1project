package onevz.soe.cart.model;

import lombok.Data;

@Data
public class BbyLocDetails {
    private String lcLocationCode;
    private String lcLocSubtype;
    private String agRetailCode;
    private String agRealAgentCode;
    private String masterAgentId;
    private String agVisionOutletId;
    private String lcFipsCode;
    private String lcClusture;
}
