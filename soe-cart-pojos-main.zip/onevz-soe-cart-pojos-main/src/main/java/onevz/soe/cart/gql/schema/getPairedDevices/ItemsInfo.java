package onevz.soe.cart.gql.schema.getPairedDevices;

import lombok.Data;


@Data
public class ItemsInfo {

	private CartItems cartItems;
	
	
}
