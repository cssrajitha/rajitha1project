package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.cartItems.CartItemsLineDetailsVO;
import onevz.soe.cart.gql.schema.cartItems.CartItemsOrderDetails;

@Data
public class CartItemsGQLRequest {

	private String cartId;
	private CartItemsOrderDetails orderDetails;
	private CartItemsLineDetailsVO lineDetails;
}
