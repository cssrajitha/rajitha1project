package onevz.soe.cart.gql.schema;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.AccessoryFinancingInfo;

@Data
public class RetrieveMiniCartOrderDetails {

    private Double totalDueToday;
    private AccessoryFinancingInfo accessoryFinancingOfferInfo;
}
