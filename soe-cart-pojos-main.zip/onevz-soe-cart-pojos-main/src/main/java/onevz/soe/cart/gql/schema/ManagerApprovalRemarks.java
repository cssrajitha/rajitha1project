package onevz.soe.cart.gql.schema;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ManagerApprovalRemarks {

	private String userId;
	private String name;
	private String approvalMethod;
	private String timeStamp;
	private String remarkLine;
	@JsonProperty(value = "managerApprovalReasonCode")
    private Boolean managerApprovalReasonCode;
}
