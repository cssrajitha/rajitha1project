package onevz.soe.cart.gql.schema;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.MtnDetails;

@Data
public class LineDigitalCartInfo {

	private Integer multiLineSeqNumber;
	private String lineActivityType;
	private Double totalDueToday;
	private Double totalDueTodayWithoutTax;
	private Double totalDueMonthly;
	private String mobileNumber;
	private ItemsInfo itemsInfo;
	private MtnDetails mtnDetails;

}
