package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class CustomerBillingAddress {

	private String zipCode;
	private String zipCodePlus4;
	private String fipsCode;
	private String addressLine1;
	private String addressLine2;
	private String city;
	private String state;
    private ScrubbedAddressInfo scrubbedAddress; 
}
