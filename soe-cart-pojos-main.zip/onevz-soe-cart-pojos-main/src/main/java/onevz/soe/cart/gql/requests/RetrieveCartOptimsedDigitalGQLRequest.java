package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.DigitalCartHeader;
import onevz.soe.cart.gql.schema.DigitalOrderDetails;
import onevz.soe.cart.gql.schema.LineDetailsDigitalCartVO;

@Data
public class RetrieveCartOptimsedDigitalGQLRequest {

	private String cartId;
	private DigitalCartHeader cartHeader;
	private DigitalOrderDetails orderDetails;
	private LineDetailsDigitalCartVO lineDetails;
}
