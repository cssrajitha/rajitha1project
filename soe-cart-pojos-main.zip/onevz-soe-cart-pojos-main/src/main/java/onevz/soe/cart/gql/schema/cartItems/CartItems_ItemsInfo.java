package onevz.soe.cart.gql.schema.cartItems;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import onevz.soe.cart.gql.schema.CartItemVO;

@Data
public class CartItems_ItemsInfo {

	private CartItemVO cartItems;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String estimatedReadyByDate;
}
