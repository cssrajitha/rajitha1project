package onevz.soe.cart.gql.schema.getCustomerInfo;

import lombok.Data;

@Data
public class AccountAddress {

    private String addressLine1;

    private String addressLine2;

    private String city;

    private String countryCode;

    private String county;

    private String state;

    private String zipCode;
}
