package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class SameDayDeliveryDetails {

	private String deliverWindowEndTime;
	private String deliverWindowKey;
	private String deliverWindowStartTime;
	private String sddDeliveryDate;
	private String userTimeZone;
}
