package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude
public class PlanAttributesGQLRequest {
	private Boolean is5GPlan;
	private Boolean sharePlan;
	private Boolean hasStandardPlan;
	private Boolean hasSecondNumPlan;

}
