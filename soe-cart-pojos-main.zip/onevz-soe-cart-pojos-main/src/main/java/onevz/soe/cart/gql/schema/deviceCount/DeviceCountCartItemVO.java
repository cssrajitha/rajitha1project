package onevz.soe.cart.gql.schema.deviceCount;

import lombok.Data;

@Data
public class DeviceCountCartItemVO {

	private DeviceCountCartItem cartItem;
}
