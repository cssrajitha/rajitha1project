package onevz.soe.cart.gql.schema;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class Agreement {

	private String type;
	@JsonProperty(value = "accepted")
	private Boolean accepted;
}
