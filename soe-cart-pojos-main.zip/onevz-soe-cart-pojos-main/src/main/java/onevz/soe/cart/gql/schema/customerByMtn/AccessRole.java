package onevz.soe.cart.gql.schema.customerByMtn;

import lombok.Data;

@Data
public class AccessRole {

    private boolean manager;

    private boolean member;

    private boolean owner;
}
