package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.effectiveDateDetails.OrderDetails;


@Data
public class EffectiveDateDetailsGQLRequest {

	private OrderDetails orderDetails;
	
}
