package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class DiscountReference {

	private String discountIndicator;
	private String discountPrice;
}
