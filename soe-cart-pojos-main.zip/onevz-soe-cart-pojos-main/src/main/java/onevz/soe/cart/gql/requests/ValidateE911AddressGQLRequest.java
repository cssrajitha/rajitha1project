package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.model.numberlinkE911Address.AlternateAddress;
import onevz.soe.cart.model.numberlinkE911Address.E911Address;
import onevz.soe.cart.model.numberlinkE911Address.ScrubbedAddress;

@Data
public class ValidateE911AddressGQLRequest {

    private ScrubbedAddress scrubbedAddress;
    private E911Address e911Address;
}
