package onevz.soe.cart.gql.schema;

import java.math.BigInteger;

import lombok.Data;

@Data
public class InstallmentContractDetail {

	private String agreementPercentage;
	private String approvalStatus;
	private String approvalStatusUpdateTimestamp;
	private String balanceLoanAmount;
	private String btaTaxWaiveInd;
	private String buyGetBogoInd;
	private String calculatedAPR;
	private int creditApplicationNum;
	private String creditClass;
	private String depletionType;
	private String deviceDescription;
	private String deviceId;
	private String deviceTaxOnContract;
	private String deviceTaxPrice;
	private String deviceType;
	private String downPaymentAmount;
	private String downPaymentTaxCollectedAmount;
	private String eroesContractType;
	private String financeChargeAmount;
	private String financeChargedCollectedAmount;
	private String financeChargedTaxAmount;
	private String financeChargedTaxCollectedAmount;
	private String firstCollectedAmount;
	private String firstMonthPaymentAmount;
	private String firstmonthPaymentCollected;
	private String installmentLoanNumber;
	private InstallmentSchedule installmentPaymentSchedule;
	private String installmentType;
	private String itemCode;
	private Integer itemSeqNum;
	private String liabilityType;
	private String loanAmount;
	private String loanMonthlyPaymentAmount;
	private String loanStatus;
	private String loanTaxCollectedAmount;
	private String loanTaxableBaseAmount;
	private String loanTerm;
	private String loanTotalFinancialChargeAmount;
	private String locationCode;
	private String machineType;
	private String mirAmount;
	private String mobileNumber;
	private String mtnEffectiveDate;
	private Integer multiLineSeqNumber;
	private BigInteger orderNum;
	private String outletId;
	private String previousInstallmentLoanNumber;
	private String productId;
	private String refundAppliedInd;
	private String rejectReason;
	private String requiredDownPayment;
	private String requiredDownPaymentPercentage;
	private String signatureIndicator;
	private String sourceSystem;
	private String stateOverrideTaxBasisAmount;
	private String taxAmount;
	private String taxBasis;
	private String taxGeoAddressType;
	private String taxGroupID;
	private String taxItemID;
	private String taxOnContractForDisplay;
	private String totalCreditAmount;
	private String upgradeDeviceCategoryText;
	private String upgradeOptionCode;
}
