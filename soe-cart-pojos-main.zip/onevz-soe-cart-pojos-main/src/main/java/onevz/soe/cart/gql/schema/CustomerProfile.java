package onevz.soe.cart.gql.schema;

import java.util.List;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.EcpdProfileInfo;

@Data
public class CustomerProfile {

	private List<BillAccountCustomerProfile> billAccounts;
//	private EcpdProfileInfo ecpdProfile;
	private CustomerAttributes customerAttributes;
}
