package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class DigitalOrderDetails {

    private String orderType;
    private OrderList orderList;

}
