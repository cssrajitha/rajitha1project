package onevz.soe.cart.gql.schema.shippingInfo;

import lombok.Data;

@Data
public class ShippingInfoLineDetailsVO {

	private ShippingInfoLineInfo lineInfo;
}
