package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class RefundNotifications {

	private String notificationEmail;
	private String notificationPhoneNum;
	private String[] emailIds;
	private String[] phoneNumbers;
}
