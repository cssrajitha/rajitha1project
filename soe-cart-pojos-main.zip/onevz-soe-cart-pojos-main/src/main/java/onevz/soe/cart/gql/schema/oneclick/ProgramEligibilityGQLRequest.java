package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude
public class ProgramEligibilityGQLRequest {
	
	private String RemainingBTAAmount;
	private String tradeInCreditEligible;

}
