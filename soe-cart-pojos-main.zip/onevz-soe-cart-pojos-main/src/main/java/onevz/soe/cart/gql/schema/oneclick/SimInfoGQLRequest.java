package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import onevz.wsclient.cxp.annotations.Query;

@Data
@JsonInclude
public class SimInfoGQLRequest {
	private String simId;
	@Query(namespaces = {"gql-attribute-optimized"})
	private String simSku;

}