package onevz.soe.cart.gql.schema.newCustomer;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Data
@JsonInclude(Include.NON_NULL)
public class PayOffDeviceInfo {

	private String payOffValue;
	private Boolean billUploaded;
	private String[] documentList;
}
