package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.AccountLevelDiscount;
import onevz.soe.cart.gql.schema.*;
import onevz.soe.cart.gql.schema.RefundOrderDetails;
import onevz.soe.cart.gql.schema.VerizonUpToastMessage;
import onevz.soe.cart.gql.schema.newCustomer.CustomerProfileForNSE;
import onevz.soe.cart.model.retrieve5GCart.*;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.model.validateCart.CartValidationError;

import java.util.List;

@Data
public class DigitalValidateCartGQLRequest {

	private String cartId;
	private ACPInfoGQL acpInfo;
	private FiveGCartHeader cartHeader;
	private FiveGOrderDetails orderDetails;
	private FiveGLineDetailsVO lineDetails;
	private onevz.soe.cart.model.retrieveCart.RefundOrderDetails refundOrderDetails;
	private Quote quote;
	private GlobalPromotions globalPromotions;
	private FiveGAutoPayEnrollment autoPayEnrollment;
	private AccountLevelDiscount accountLevelDiscount;
	private FiveGCartValidationError cartValidationErrors;
	private FiveGProgramEligibility programEligibility;
	private FiveGEcpdProfileInfo ecpdProfile;
	private List<VendingCoordinates> vendingCoordinatesList;
	private SfoLossReferenceDataList sfoLossReferenceDataList;
	private SpoLossReferenceDataList spoLossReferenceDataList;
	private VerizonUpToastMessage verizonUpToastMessage;
	private CustomerProfileForNSE customerProfileForNSE;
	private CustomerProfile	customerProfile;
}
