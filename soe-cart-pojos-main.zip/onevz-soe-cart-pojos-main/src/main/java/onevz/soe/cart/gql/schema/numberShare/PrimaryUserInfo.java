package onevz.soe.cart.gql.schema.numberShare;

import lombok.Data;


@Data
public class PrimaryUserInfo {

	private String firstName;
	private String lastName;
	
}
