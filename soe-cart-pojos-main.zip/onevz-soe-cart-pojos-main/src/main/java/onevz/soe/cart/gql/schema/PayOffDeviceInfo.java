package onevz.soe.cart.gql.schema;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Data
@JsonInclude(Include.NON_NULL)
public class PayOffDeviceInfo {

	private String payOffValue;
	private Boolean billUploaded;
	private String noOfRemainingMonths;
	private String submissionId;
	private String[] documentList;
}
