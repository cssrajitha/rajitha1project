package onevz.soe.cart.gql.schema.newCustomer;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import onevz.soe.cart.gql.schema.PrimaryUserAddress;

@Data
public class PrimaryUserInfo {
	
	private String firstName;
	private String lastName;
	private PrimaryUserAddress address;
	@JsonProperty(value="isValidAddress")
	private Boolean isValidAddress;
	private String contactPersonPhone;
	private String emailId;
	

}
