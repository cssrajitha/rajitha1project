package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class PromoBadgeMessages {

    private String badgeText;
    private String badgeToolTip;
    private String badgeToolTipUrl;
    private String badgeImage;
    private String placement;
    private String pageId;
    private String masterpageId;
}
