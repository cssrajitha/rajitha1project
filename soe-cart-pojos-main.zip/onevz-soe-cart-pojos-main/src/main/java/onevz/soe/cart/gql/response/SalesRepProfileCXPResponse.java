package onevz.soe.cart.gql.response;

import lombok.*;
import onevz.soe.cart.model.custProfile.CustomerData;

import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Data

public class SalesRepProfileCXPResponse {
    private Map<String , Object> meta;
    private CustomerData data;
}
