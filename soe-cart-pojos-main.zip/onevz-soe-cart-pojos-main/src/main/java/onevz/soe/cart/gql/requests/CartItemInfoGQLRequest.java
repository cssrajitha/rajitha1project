package onevz.soe.cart.gql.requests;

import lombok.Data;
@Data
public class CartItemInfoGQLRequest {
    private CartLineDetailsGQL lineDetails;
    private CartHeaderGQL cartHeader;

}