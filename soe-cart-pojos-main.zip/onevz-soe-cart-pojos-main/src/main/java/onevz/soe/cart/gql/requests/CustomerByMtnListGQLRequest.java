package onevz.soe.cart.gql.requests;

import java.util.List;

import lombok.Data;
import onevz.soe.cart.gql.schema.customerByMtnList.BillAccount;

@Data
public class CustomerByMtnListGQLRequest {

	 private String customerId;
	 private List<BillAccount> billAccounts;
}
