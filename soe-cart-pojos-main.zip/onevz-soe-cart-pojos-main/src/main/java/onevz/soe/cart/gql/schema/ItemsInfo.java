package onevz.soe.cart.gql.schema;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.CXPClnrInfoVO;
import onevz.soe.cart.model.retrieveCart.CXPFinanceOptionDetails;
import onevz.soe.cart.model.retrieveCart.LocalNumberPortability;
import onevz.soe.cart.model.retrieveCart.RefundExchangeInfo;

@Data
public class ItemsInfo {

	private String depletionType;
	private String attention;
	private String addrType;
	private String approvalReason;
	private Shipping shipping;
	private String fipsCode;
	private Integer itemCount;
	private Integer itemTabSeqNum;
	private LocalNumberPortability localNumberPortability;
	private CartItemVO cartItems;
	private CartItemVO refundCartItems;
	private String mtnLevelEmail;
	private String depletionLocation;
	private String dsmDesign;
	private String equipPONum;
	@JsonProperty(value = "isPromoSelected")
	private Boolean isPromoSelected;
	@JsonProperty(value = "isTradeInSelected")
	private Boolean isTradeInSelected;
	private String orderLevelEmail;
	private String orderLevelEmailCC;
	private String pricingLocation;
	private String recycleCreditApplied;
	private String smsDestination;
	private String smsLanguage;
	private String taxExemptId;
	private String taxExemptRsn;
	private String taxExemptionTypes;
	private String upgradeInd;
	private RefundExchangeInfo refundItemExchangeInfo;
	private CXPClnrInfoVO clnrInfo;
	private String estimatedReadyByDate;
}
