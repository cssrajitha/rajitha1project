package onevz.soe.cart.gql.requests;


import lombok.Data;
import onevz.soe.cart.gql.schema.customerByMtn.BillAccount;


import java.util.List;


/**
 * The Class CustomerByMtnGQLRequest
 */
@Data
public class CustomerByMtnGQLRequest {

    private List<BillAccount> billAccounts;

}

