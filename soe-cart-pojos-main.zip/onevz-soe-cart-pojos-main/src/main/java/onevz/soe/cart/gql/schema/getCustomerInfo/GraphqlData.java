package onevz.soe.cart.gql.schema.getCustomerInfo;

import lombok.Data;

@Data
public class GraphqlData {

    private Customer customer;
}