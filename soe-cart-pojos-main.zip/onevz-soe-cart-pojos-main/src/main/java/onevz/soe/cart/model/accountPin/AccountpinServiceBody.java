package onevz.soe.cart.model.accountPin;

import lombok.Data;
import lombok.EqualsAndHashCode;
import onevz.soe.wsclient.bpm.model.ServiceBody;

@Data
@EqualsAndHashCode(callSuper = true)
public class AccountpinServiceBody extends ServiceBody{
    private AccountpinServiceRequest serviceRequest;
    private AccountpinServiceResponse serviceResponse;

}
