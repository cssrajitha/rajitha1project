package onevz.soe.cart.gql.schema.oneclick;

import lombok.Data;
import onevz.wsclient.cxp.annotations.Query;

@Data
public class AddressGQLRequest {
	
	private String area;
	private String state;
	private String zipCode;
	@Query(namespaces = {"gql-attribute-optimized"})
	private String zipCodePlus4;

}
