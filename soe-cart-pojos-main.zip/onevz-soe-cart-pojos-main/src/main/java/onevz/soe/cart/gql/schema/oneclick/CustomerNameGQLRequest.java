package onevz.soe.cart.gql.schema.oneclick;

import lombok.Data;

@Data
public class CustomerNameGQLRequest {
	
	private String firstName;
    private String lastName;

}
