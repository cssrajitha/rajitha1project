package onevz.soe.cart.gql.schema.deviceDetails;

import lombok.Data;

@Data
public class DeviceDetailsCartItemsVO {

	private DeviceDetailsCartItem cartItem;
}
