package onevz.soe.cart.gql.schema.numberShare;

import lombok.Data;


@Data
public class LineInfo {
	
	private String mobileNumber;	
	private ServiceInfo serviceInfo;
	private NumbershareInfo numbershareInfo;
	private String lineActivityType;
	private ItemsInfo itemsInfo;
	
}
