package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class RefundOrderDetails {

	private String locationCode;
	private String homeLocation;
	private String salesRepId;
	private String userName;
	private String loginUserName;
	private String saleType;
	private String customerType;
	private Integer orderNum;
	private String orderType;
	private String accountNumber;
	private String accountSubNumber;
	private String linkApplicationNum;
	private String prepayApplicationNum;
	private String broadbandIndicator;
	private String ordConv;
	private String bogoCheck;
	private String installmentType;
	private String orderStatus;
	private String completeTimestamp;
	private String drcInstantCreditIndicator;
	private String tradeAtHomeIndicator;
	private String billingSystem;
	private String zipCode;
	private Integer creditApplicationNum;
	private String paperlessIndicator;
	private String fulfillmentMldIndicator;
	private String channelType;
	private String taxExemptRsn;
	private String reassignIndicator;
	private String splitBillTcAccepted;
	private String createTimestamp;
	private String telemktg;
	private String orderI2KMktId;
	private String familyShare;
	private String splitBillTcRequired;
	private String taxExemptId;
	private String pricingLocation;
	private String state;
	private String catalogNum;
	private String taxExemptInd;
	private String sfaomNumber;
	private String shellAcctInd;
	private String lastModifiedTimestamp;
	private String c2bSubCartId;
	private String splitBillIndicator;
	private String confNum;
	private String vztBillCycle;
	private String regionId;
	private String custTrialGrpCd;
	private String totalDueToday;
	private String subTotalDueToday;
	private String totalTaxAmount;
	private String ispuStatus;
}
