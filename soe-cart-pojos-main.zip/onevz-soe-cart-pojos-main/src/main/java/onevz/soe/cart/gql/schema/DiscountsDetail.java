package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class DiscountsDetail {

	private LineDiscounts discounts;
	private String totalDiscount;
}
