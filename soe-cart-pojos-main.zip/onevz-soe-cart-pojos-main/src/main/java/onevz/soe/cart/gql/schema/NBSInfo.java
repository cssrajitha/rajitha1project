package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class NBSInfo {

	private BillAccount billAccounts;
}
