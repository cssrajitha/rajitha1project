package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class FeatureMessages {

    private String name;

    private String action;

    private String nextPrice;

    private FeatureMessageField fields;

}
