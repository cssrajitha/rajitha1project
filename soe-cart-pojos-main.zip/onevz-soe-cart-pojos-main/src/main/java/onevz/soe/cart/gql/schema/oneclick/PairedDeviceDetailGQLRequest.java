package onevz.soe.cart.gql.schema.oneclick;

import lombok.Data;

@Data
public class PairedDeviceDetailGQLRequest {
    private String pairedImei;
    private String pairedImeiMtn;
    private Boolean isPairedImeiActive;
    private Boolean isPairedMTNSameAccount;

    private String eid;
    private String deviceSku;
    private String preferredSim;
    private String devicePreferredSoftSim;

}
