package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties
public class MobileNumberMtnDetails {

	private String mobileNumber;
}
