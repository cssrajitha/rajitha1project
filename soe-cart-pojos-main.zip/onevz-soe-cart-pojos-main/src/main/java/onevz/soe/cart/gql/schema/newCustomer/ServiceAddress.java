package onevz.soe.cart.gql.schema.newCustomer;

import lombok.*;

@Data
public class ServiceAddress {
	
    private String apartmentNo;
    private String addressLine1;
    private String addressLine2;
    private String zipCode;
    private String zipCode4;
    private String countryCode;
    private String firstName;
    private String lastName;
    private Integer floor;
    private String city;
    private String state;
    private String addressIdNumber;
    private String county;
}
