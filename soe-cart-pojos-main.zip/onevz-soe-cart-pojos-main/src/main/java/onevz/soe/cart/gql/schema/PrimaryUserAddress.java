package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class PrimaryUserAddress {

	private String firmName;
	private String apartmentNo;
	private String type;
	private String streetNumber;
	private String streetName;
	private String streetType;
	private String streetDirection;
	private String addressLine1;
	private String addressLine2;
	private String poBoxNo;
	private String ruralRouteNo;
	private String ruralDelNo;
	private String city;
	private String state;
	private String zipCode;
	private String zipCode4;
	private String county;
	private String countryCode;
	private String secondaryAddress;
	private String fipsCode;
	private String firstName;
	private String lastName;	
	private String emailId;
	private String phoneNumber;
	private String attention;
}
