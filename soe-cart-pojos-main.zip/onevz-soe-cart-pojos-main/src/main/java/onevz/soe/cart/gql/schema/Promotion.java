package onevz.soe.cart.gql.schema;

public class Promotion {

	private String promotionType;
	private String promotionText;
	private String promotionPrice;
}
