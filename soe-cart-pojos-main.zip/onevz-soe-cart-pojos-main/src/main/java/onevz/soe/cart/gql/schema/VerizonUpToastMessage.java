package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class VerizonUpToastMessage {

	private ToastMessage toastMessages;
	private EligibleProduct eligibleProducts;
}
