package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class LineLevelDiscount {

	private DiscountedElements discountedElements;
}
