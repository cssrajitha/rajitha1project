package onevz.soe.cart.gql.response;

import lombok.Data;
import onevz.soe.cart.gql.requests.GetPairedDeviceInfoGQLRequest;
@Data
public class GetPairedDeviceInfoGQL {

	private GetPairedDeviceInfoGQLRequest cart;
}
