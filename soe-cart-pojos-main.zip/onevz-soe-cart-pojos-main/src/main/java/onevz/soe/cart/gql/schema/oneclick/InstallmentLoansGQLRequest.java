package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import onevz.wsclient.cxp.annotations.Query;

@Data
@JsonInclude
public class InstallmentLoansGQLRequest {
	@Query(namespaces = {"gql-attribute-optimized"})
	private Boolean loanTransferEligibility;
	private String loanAmount;
	private String paidAmountToDate;
	private String totalPrincipalAmountUnpaid;
	@Query(namespaces = {"gql-attribute-optimized"})
	private String loanTermMonths;
	private Integer pendingNumberOfInstallments;
	private Integer daysLeftForNextEligibleUpgrade;
	private String loanMonthlyPaymentAmount;
	private String paidAmountPercentage;
	private String edgeUpRequiredPercent;
	@Query(namespaces = {"gql-attribute-optimized"})
	private String firstInstallmentAmount;
	@Query(namespaces = {"gql-attribute-optimized"})
	private String loanNumber;
	@Query(namespaces = {"gql-attribute-optimized"})
	private boolean pastTradeInRestrictionTimePeriod;
	private String edgeUpPrincipalAmountUnpaid;
	private Boolean displayKeepOption;
	private Boolean displayReturnOption;
	private Boolean deviceMismatch;
//	private BuyoutQuoteGQLRequest buyoutQuote;
	private LoanStatusGQLRequest loanStatus;

}
