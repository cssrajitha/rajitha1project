package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;


@Data
@JsonInclude
public class DeviceInfoGQLRequest {
	
	private String tradeInValue;
	private String deviceId;
	private String deviceUrl;
	private String brandName;
	private String displayName;
	private Boolean appleDevice;
	private String operatingSystem;
	private DeviceCategoryInfoGQLRequest category;
	private DeviceTypeInfoGQLRequest deviceType;
	private boolean ringDevice;

	private DeviceColorGQLRequest color;
	private String capacity;
	private String deviceProdId;

	private boolean euiccCapable;
	private String simClass4G;
	private String eid;
	private String preferredSoftSim;
	//private String preferredSim;
	private String deviceSku;
	private PairedImeiDataGQLRequest pairedImeiData;

	private boolean cdmaRestrictedDevice;
	private boolean cdmaSuspended;
	private PairedDeviceDetailGQLRequest pairedDeviceDetails;
}
