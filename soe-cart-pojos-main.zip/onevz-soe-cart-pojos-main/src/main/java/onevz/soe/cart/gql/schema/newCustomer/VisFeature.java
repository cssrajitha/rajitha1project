package onevz.soe.cart.gql.schema.newCustomer;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import onevz.soe.cart.gql.schema.Spos;
import onevz.soe.cart.gql.schema.VisFeatureDiscounts;

@Data
public class VisFeature {
	
	private String visFeatureCode;
	private String featureDesc;
	private String customerSelected;
	private String type;
	private String featurePrice;
	@JsonProperty(value="protection")
	private Boolean protection;
	@JsonProperty(value="callFilter")
	private Boolean callFilter;
	@JsonProperty(value="declinedProtection")
	private Boolean declinedProtection;
	private VisFeatureDiscounts featureDiscounts;
	private Integer minEligibleLines;
	private Integer maxEligibleLines;
	private Spos attributeNameValue;

}
