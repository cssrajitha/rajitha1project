package onevz.soe.cart.gql.schema.newCustomer;

import lombok.Data;

@Data
public class ProfileAttributes {
    private boolean paperLessBilling;
    private boolean receiveSpecialOfferUpdates;
}
