package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import onevz.wsclient.cxp.annotations.Query;

@Data
@JsonInclude
public class AccountLevelChangeEligibilityGQLRequest {
	private Boolean isAddNewLineAllowed;
	@Query(namespaces = {"gql-attribute-optimized"})
	private Boolean isBundleChangeAllowed;
	@Query(namespaces = {"gql-attribute-optimized"})
	private Boolean isSharePlanChangeAllowed;
	private PendingOrderDetailGQLRequest pendingOrderDetail;

}
