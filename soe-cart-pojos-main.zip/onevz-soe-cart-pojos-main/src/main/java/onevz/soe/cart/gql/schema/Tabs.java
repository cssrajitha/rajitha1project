package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class Tabs {

	private String tabType;
	private String totalAmount;

}
