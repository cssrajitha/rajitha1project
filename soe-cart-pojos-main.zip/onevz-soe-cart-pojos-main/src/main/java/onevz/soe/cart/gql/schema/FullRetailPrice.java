package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class FullRetailPrice {

    private double originalPrice;




}
