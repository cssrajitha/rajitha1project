package onevz.soe.cart.gql.schema.bundlebuildercartlightweight;

import lombok.Data;
import java.util.List;

@Data
public class CartItemsLW {
    private List<CartItemLW> cartItem;
}
