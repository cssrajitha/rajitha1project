package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Customer {
	private String caseId;
	private String cartId;
	private String processStep;
	private String existingCase;
	private List<AvailablePath> availablePaths;
	private String customerId;
	private String email;
	private String customerHash;
	private CustomerName customerName;
	private CustomerAttributes customerAttributes;
	private List<BillAccounts> billAccounts;
	private Address address;
	private EcpdProfile ecpdProfile;
	private String intent;
	private String lob;
	private String mtnFlow;
	private String repId;
	private String loggedInUser;
	private String channel;
	private String selectedMtn;
	private String loginMtn;
	private String loginCustId;
	private String selectedDeviceType;
	private String selectedDeviceCategoryType;
	private String donorMtn;
	private String sessionId;
	private String globalSessionId;
	private String globalId;
	private String bucketAllocator;
	private String throttleList;
	private Boolean selectedAnnualEligibleDevice;
	private String vzwRole;
	private Boolean explicitLock;
	private String lockedChannelID;
	private Boolean standAloneTradein;
	public Customer() {
		this.customerName = new CustomerName();

	}
}
