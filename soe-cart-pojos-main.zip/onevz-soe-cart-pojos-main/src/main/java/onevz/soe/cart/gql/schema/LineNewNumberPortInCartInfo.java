package onevz.soe.cart.gql.schema;

import lombok.Data;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntent;
import onevz.soe.cart.model.common.SecondNumber;
import onevz.soe.cart.model.common.ServiceInfo;

@Data
public class LineNewNumberPortInCartInfo {

	private String lineActivityType;
	private Integer multiLineSeqNumber;
	private ItemsInfo itemsInfo;
	private String mobileNumber;
	private String currentPlanType;
	private SecondNumber secondNumber;
	private ServiceInfo serviceInfo;
	private AddPromoIntent[] promoIntent;
}
