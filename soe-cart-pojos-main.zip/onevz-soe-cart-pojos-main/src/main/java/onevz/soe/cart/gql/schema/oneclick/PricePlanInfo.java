
package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL) 	//  ignore all null fields
public class PricePlanInfo {
	
	private String planId;
	private String planCategoryName;
	private String planSkuName;
	//private PlanAttributes planAttributes;
//    private AccessCharge accessCharge;
}
