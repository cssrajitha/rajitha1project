package onevz.soe.cart.gql.schema.oneclick;

import lombok.Data;

@Data
public class CustomerProfileGraphQLRequest {
	
	private String email;
	private String customerId;
	private String customerHash;
	private CustomerNameGQLRequest customerName;
	private CustomerAttributesGQLRequest customerAttributes;
	private BillAccountsGQLWithoutRTDRequest billAccounts;
	private AddressGQLRequest address;

}
