package onevz.soe.cart.gql.schema.getCustomerInfo;

import lombok.Data;

@Data
public class CbrNos {

    private String phoneNumber;

    private String type;
}
