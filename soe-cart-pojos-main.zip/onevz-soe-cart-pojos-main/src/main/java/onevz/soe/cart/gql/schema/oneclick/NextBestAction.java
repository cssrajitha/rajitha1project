package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;

@Data
@JsonInclude
public class NextBestAction {
	
	private String athenaSessionID;
	private ContextInfo contextInfo; 
	private List<Recommendations> recommendations;

}
