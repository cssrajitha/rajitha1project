package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL) 	//  ignore all null fields
public class GraphqlData
{
	@JsonAlias({"customer", "customerByMtnList"})
    private Customer customer;
    public GraphqlData() {
        this.customer = new Customer();
    }
}
