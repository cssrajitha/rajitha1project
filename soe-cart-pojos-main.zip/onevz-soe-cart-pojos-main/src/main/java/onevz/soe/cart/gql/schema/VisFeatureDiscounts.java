package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class VisFeatureDiscounts {

	private String barCodeId;
	private String discountId;
	private String discountName;
	private Double discountPrice;
	private String discountType;
	private String discountdescription;
	private String instantRebateFlag;
	private String rebateAllowedFlag;
	private String rebateCode;
	private String rebateEligibilityInd;
	private String rebateRuleId;
	private String rebateSponsor;
	private String sedOfferType;

}
