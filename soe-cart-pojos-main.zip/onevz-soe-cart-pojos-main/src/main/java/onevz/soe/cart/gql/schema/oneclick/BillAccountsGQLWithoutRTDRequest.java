package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import onevz.wsclient.cxp.annotations.Query;

@Data
@JsonInclude
public class BillAccountsGQLWithoutRTDRequest {
	private AccountLevelChangeEligibilityGQLRequest accountLevelChangeEligibility;
	private AccountAttributesGQLRequest accountAttributes;
	private PaymentInfoGQLRequest paymentInfo;
	private MtnGQLWithoutRTDRequest mtns;
	@Query(namespaces = {"feature-flag-optimized"})
	private ProgramEligibilityGQLRequest programEligibility;
}
