package onevz.soe.cart.gql.schema.oneclick;

import lombok.Data;

@Data
public class Address {
	
	private String addressLine1;
	private String addressLine2;
	private String city;
	private String fipsCode;
	private String geoCode;
	private String scrubberdAddress;
	private String area;
	private String state;
	private String zipCode;
	private String zipCodePlus4;

}
