package onevz.soe.cart.gql.schema.newCustomer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class
CustomerProfileForNSE {

    private ProfileAttributes profileAttributes;
    private CustomerName customerName;
    private ContactInfo contactInfo;
    private String ssn;
    private String dob;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value = "customerAge")
    private String customerAge;

}



