package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class MobileInfoBusinessAttributesForProfile {

	private Boolean smartFamilyParent;
    private AccessRolesForProfile accessRoles;
}
