package onevz.soe.cart.gql.schema.bundlebuildercartlightweight;

import lombok.Data;

@Data
public class MTNDetailsLW {

    private String npaNXX;
    private String mobileNumber;
    private String lineNumber;
    private String dummyMTNForDomain;
}
