package onevz.soe.cart.gql.schema.newCustomer;

import lombok.Data;

@Data
public class PaypalPaymentAuthenticateDetails {

	/** The paypal processor user email. */
	private String paypal_processorUserEmail;
}
