package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class OrderDetailsNGD {
	private String flowType;
}
