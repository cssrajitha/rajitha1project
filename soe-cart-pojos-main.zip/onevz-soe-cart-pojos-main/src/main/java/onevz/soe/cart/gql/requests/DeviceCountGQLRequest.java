package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.deviceCount.DeviceCountLineDetails;
import onevz.soe.cart.model.validateCart.CartValidationError;

import java.util.List;

@Data
public class DeviceCountGQLRequest {

	private String cartId;
	private List<CartValidationError> cartValidationErrors;
	private DeviceCountLineDetails lineDetails;
}
