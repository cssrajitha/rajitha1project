package onevz.soe.cart.gql.schema.getCustomerInfo;

import lombok.Data;

@Data
public class PricePlanInfo {

    private String planId;

    private String description;

    private String chargeAmount;
}
