package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonInclude
public class MtnStatus {
    private String mtnStatusReasonCode;
    private Boolean isMtnSuspended;
    private Boolean mtnSuspendAllowed;
    @JsonProperty("isActive")
    private boolean isActive;
}
