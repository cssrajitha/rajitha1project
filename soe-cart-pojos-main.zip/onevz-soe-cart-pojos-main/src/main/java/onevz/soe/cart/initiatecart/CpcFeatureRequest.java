package onevz.soe.cart.initiatecart;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import onevz.soe.wsclient.bpm.model.ServiceBody;
import onevz.soe.wsclient.bpm.model.ServiceHeader;
import onevz.soe.wsclient.bpm.model.request.BPMServiceRequest;
@Data
public class CpcFeatureRequest  extends BPMServiceRequest {

    @JsonProperty("serviceHeader")
    private ServiceHeader serviceHeader;

    @JsonProperty("serviceBody")
    private ServiceBody serviceBody;
}
