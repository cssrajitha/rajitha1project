package onevz.soe.cart.gql.schema;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import onevz.soe.cart.model.common.AddOnIot;
import onevz.soe.cart.model.retrieveCart.ImageUrlMap;

@Data
public class VisFeature {

	private String visFeatureCode;
	private String featureDesc;
	private String featureBillDesc;
	private String addDeleteInd;
	private Boolean currentDeviceCompatible;
	private String customerSelected;
	private String featureDiscPrice;
	private String level;
	private String type;
	private String featurePrice;
	private String source;
	private String sfopackageGroupCode;
	@JsonProperty(value="protection")
	private Boolean protection;
	@JsonProperty(value="callFilter")
	private Boolean callFilter;
	private String conflictMessage;
	@JsonProperty(value="declinedProtection")
	private Boolean declinedProtection;
	private ImageUrlMap imageUrlMap;
	private VisFeatureDiscounts featureDiscounts;
	private String categoryCodes;
	private String displayReceiptIndicator;
	private Integer minEligibleLines;
	private Integer maxEligibleLines;
	private String defaultPrice;
	private String featureStatus;
	private boolean sddSetupEligible;
	private String perkOriginalPrice;
	private int rank;
	private boolean homeProtect;
	private Spos attributeNameValue;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	@JsonProperty(value="addOnIotDetails")
	@JsonIgnoreProperties(ignoreUnknown = true)
	@Schema(description = "addOnIotDetails", example = "addOnIotDetails details")
	private AddOnIot addOnIotDetails;

}
