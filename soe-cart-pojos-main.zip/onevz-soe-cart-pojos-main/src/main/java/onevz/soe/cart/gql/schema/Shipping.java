package onevz.soe.cart.gql.schema;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.IspuContactInfo;
import onevz.soe.cart.model.retrieveCart.StoreInfo;

@Data
public class Shipping {

	private ShippingAddress address;
	private String bsnsName;
	private String shippingCode;
	private String shippingCost;
	private String shippingDescription;
	private String cbrPhone;	
	private StoreInfo storeinfo ;
	private String altBsnsName;
	private String bsnsTitle;
	private String courtesyCode;
	private String firstName;
	private String lastName;
	private String midInitials;
	@JsonProperty(value = "isUseUnVerifiedAddress")
	private Boolean isUseUnVerifiedAddress;
	@JsonProperty(value = "isValidAddress")
	private Boolean isValidAddress;
	private String prefix;
	private SameDayDeliveryDetails sameDayDeliveryDetails;
	private String shippingTax;
	private String suffix;
	private String taxExemptionTypes;
	private String titleName;
	private String email;
	private IspuContactInfo ispuContactInfo;
	private String locationSalesIdForSDD;
	private String shipmentType;
	private String sddZipCode;
	private AgentAddress agentAddress;
	private Boolean shipToCustomerAddress;

}
