package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.agreementInfo.LineDetails;
import onevz.soe.cart.gql.schema.agreementInfo.OrderDetails;

@Data
public class AgreementInfoGQLRequest {

	private String cartId;	
	private OrderDetails orderDetails;
	private LineDetails lineDetails;
	
}
