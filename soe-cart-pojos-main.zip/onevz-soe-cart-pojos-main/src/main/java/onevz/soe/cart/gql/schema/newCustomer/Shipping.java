package onevz.soe.cart.gql.schema.newCustomer;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import onevz.soe.cart.gql.schema.SameDayDeliveryDetails;
import onevz.soe.cart.gql.schema.ShippingAddress;
import onevz.soe.cart.model.retrieveCart.IspuContactInfo;
import onevz.soe.cart.model.retrieveCart.StoreInfo;

@Data
public class Shipping {
	
	private ShippingAddress address;
	private String shippingCode;
	private String shippingCost;
	private String shippingDescription;
	private String cbrPhone;
	private String firstName;
	private String lastName;
	private String midInitials;
	@JsonProperty(value = "isUseUnVerifiedAddress")
	private Boolean isUseUnVerifiedAddress;
	@JsonProperty(value = "isValidAddress")
	private Boolean isValidAddress;
	private String email;
	private SameDayDeliveryDetails sameDayDeliveryDetails;
	private String deliveryDate;
	private StoreInfo storeinfo ;
	private IspuContactInfo ispuContactInfo;
	private String sddSetupIncluded;
}
