package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude
public class UpgradeEligibilityInfo {
	private Boolean upgradeEligible;
	private Boolean annualUpgradeEligible;
	private Boolean buyoutEligible;
	private Boolean buyoutRestricted;
	private String upgradeEligibilityDate;
	private Boolean alwaysUpgradeEligible;
	private Boolean edgeUpEligible;
	private String upgradeEligibilityLabel;
}
