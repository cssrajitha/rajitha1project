package onevz.soe.cart.gql.schema.getPairedDevices;

import lombok.Data;
import onevz.soe.cart.model.retrieveCart.ImageUrlMap;


@Data
public class CartItem {

	private String deviceDisplayName;
	private ImageUrlMap imageUrlMap;

}
