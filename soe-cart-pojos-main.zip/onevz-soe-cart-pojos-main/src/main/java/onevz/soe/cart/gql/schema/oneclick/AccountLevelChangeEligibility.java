package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude
public class AccountLevelChangeEligibility
{
	private Boolean isAddNewLineAllowed;
	private Boolean isBundleChangeAllowed;
	private Boolean isSharePlanChangeAllowed;
	private Object pendingOrderDetail;

	public AccountLevelChangeEligibility()
	{
		this.pendingOrderDetail = new Object();
	}
}