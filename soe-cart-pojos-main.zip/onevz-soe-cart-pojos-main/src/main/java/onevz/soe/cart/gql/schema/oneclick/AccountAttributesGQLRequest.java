package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import onevz.wsclient.cxp.annotations.Query;

@Data
@JsonInclude
public class AccountAttributesGQLRequest {
	private Boolean trialUnlimitedCustomer;
	private Boolean isCollection;
	private Boolean isCashOnly;
	private Boolean isCashOnlyExceptCC;
	private Boolean isCashOnlyExceptCO;
	private Boolean isOverThreshHold;
	private FraudInfo fraudInfo;
	@Query(namespaces = {"gql-attribute-optimized"})
	private Boolean mixedPlanCategories;

}
