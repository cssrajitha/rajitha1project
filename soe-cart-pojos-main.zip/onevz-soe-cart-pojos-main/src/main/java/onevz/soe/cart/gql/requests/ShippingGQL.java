package onevz.soe.cart.gql.requests;

import lombok.Data;
import onevz.soe.cart.gql.schema.AgentAddress;

@Data
public class ShippingGQL {
	
	private AddressGQL address;
	private AgentAddress agentAddress;
	private IspuContactInfoGQL ispuContactInfo;

}