package onevz.soe.cart.gql.requests;

import onevz.soe.cart.gql.schema.*;
import onevz.soe.cart.gql.schema.AccountLevelDiscount;
import onevz.soe.cart.gql.schema.newCustomer.CustomerProfileForNSE;
import onevz.soe.cart.model.retrieve5GCart.*;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.model.retrieveCart.RefundOrderDetails;
import java.util.List;

public class FiveGRetrieveCartGQLRequest {

    private String cartId;
    private ACPInfoGQL acpInfo;
    private FiveGCartHeader cartHeader;
    private FiveGOrderDetails orderDetails;
    private FiveGLineDetailsVO lineDetails;
    private RefundOrderDetails refundOrderDetails;
    private Quote quote;
    private GlobalPromotions globalPromotions;
    private FiveGAutoPayEnrollment autoPayEnrollment;
    private AccountLevelDiscount accountLevelDiscount;
    private FiveGCartValidationError cartValidationErrors;
    private FiveGProgramEligibility programEligibility;
    private FiveGEcpdProfileInfo ecpdProfile;
    private List<VendingCoordinates> vendingCoordinatesList;
    private CustomerProfile customerProfile;
    private CustomerProfileForNSE customerProfileForNSE;
}
