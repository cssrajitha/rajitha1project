package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties
public class CartLineDetails {

	private List<MtnslineInfo> lineInfo;
}
