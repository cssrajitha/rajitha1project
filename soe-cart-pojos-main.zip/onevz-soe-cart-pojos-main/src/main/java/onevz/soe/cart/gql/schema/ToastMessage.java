package onevz.soe.cart.gql.schema;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class ToastMessage {

	private String toastMessageKey;
	private String toastMessage;
	private BigDecimal dollarValue;
	private String expiryDate;
	private String barCode;
	private OfferIdDetails offerIdDetailsList;
	private BigDecimal cassandraDollarValue;
	private BigDecimal kobieBarCodeDollarValue;
	private BigDecimal expiredSoonDollarValue;
	private String promoCode;
	private Boolean barCodeapplied;
	private String offerId;
	private RedemptionId redemptionIds;
	private Boolean displayOfferMessage;
	private String eligibleDeviceCategoryList;
}
