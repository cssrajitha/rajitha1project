package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import onevz.wsclient.cxp.annotations.Query;

@Data
@JsonInclude
public class UpgradeEligibilityInfoGQLRequest {
	
	private Boolean upgradeEligible;
	private Boolean annualUpgradeEligible;
	private Boolean buyoutEligible;
	private Boolean buyoutRestricted;
	//private Boolean transferUpgradeEligible;
	//private Boolean transferUpgradeRecepientEligible;
	private String upgradeEligibilityDate;
	private Boolean alwaysUpgradeEligible;
	@Query(namespaces = {"gql-attribute-optimized"})
	private Boolean earlyUpgradeEligible;
	private Boolean edgeUpEligible;
	private String upgradeEligibilityLabel;
	@Query(namespaces = {"gql-attribute-optimized"})
	private Boolean devicePaymentEligible;
	private InEligibilityGQLRequest inEligibility;
	private TwoYearContractGQLRequest twoYearContract;
	private PendingOrderDetailGQLRequest pendingOrderDetail;
	private Boolean lineUpgradedwithin24Hrs;
	private TransferUpgradeEligibilityGQLRequest transferUpgradeEligibility;

}
