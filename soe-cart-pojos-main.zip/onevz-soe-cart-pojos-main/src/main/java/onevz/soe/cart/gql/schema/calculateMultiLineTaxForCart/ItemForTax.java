package onevz.soe.cart.gql.schema.calculateMultiLineTaxForCart;

import java.util.List;

import lombok.Data;

@Data
public class ItemForTax {

	private int mldSeqNum;
	private int itemSequence;
	private String itemCode;
	private String itemPrice;
	private String unitTaxBasedPrice;
	private String downPaymentAmount;
	private int qty;
	private String discountAmount;
	private String e911Fee;
	private String state911Fee;
	private String eWasteFee;
	private String vzwSurcharges;
	private String priceType;
	private String taxAmount;
	private int taxBasedPriceFlag;
	private InstallmentTaxDetail installmentTaxDetail;
	private RecycleTaxDetail recycleTaxDetail;
	private List<TaxDetails> taxDetailsList;
}
