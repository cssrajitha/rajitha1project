package onevz.soe.cart.gql.schema.getCustomerInfo;

import lombok.Data;

import java.util.List;

@Data
public class CustomerCbrInfo {

    private List<CbrNos> cbrNos;
}
