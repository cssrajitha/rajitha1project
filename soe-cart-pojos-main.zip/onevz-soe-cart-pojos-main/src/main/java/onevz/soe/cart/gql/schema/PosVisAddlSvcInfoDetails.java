package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class PosVisAddlSvcInfoDetails {

	private String customerType;
	private  PosVisAddlSvcInfo posVisAddlSvcInfo;
}
