package onevz.soe.cart.gql.requests;

import java.util.List;

import lombok.Data;
@Data
public class CartItemsGQL {

	private List<CartItemGQL> cartItem;

}