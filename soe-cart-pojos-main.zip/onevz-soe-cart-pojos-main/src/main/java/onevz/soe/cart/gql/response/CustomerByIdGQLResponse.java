package onevz.soe.cart.gql.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import onevz.soe.cart.gql.requests.CustomerByIdGQLRequest;

@Data
public class CustomerByIdGQLResponse {
	    @JsonInclude(JsonInclude.Include.NON_NULL)
	    @JsonProperty(value = "customer")
	    private CustomerByIdGQLRequest customer;

}