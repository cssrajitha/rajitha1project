package onevz.soe.cart.gql.schema.numberShare;

import lombok.Data;


@Data
public class NumbershareInfo {

	private String branchType;
	private Boolean isEditable;
	private String numberShareHostMtn;
	private Boolean standAlone;
	
}
