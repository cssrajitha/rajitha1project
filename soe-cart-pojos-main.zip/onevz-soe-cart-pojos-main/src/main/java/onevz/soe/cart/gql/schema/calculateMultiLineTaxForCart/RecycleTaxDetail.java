package onevz.soe.cart.gql.schema.calculateMultiLineTaxForCart;

import lombok.Data;

@Data
public class RecycleTaxDetail {

	private String prodCode1;
	private String prodCode2;
	private String prodCode3;
	private String recycleCreditAllocated;
	private String recycleCreditAllocatedForTax;
	private String recycleStateInd;
}
