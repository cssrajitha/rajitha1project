package onevz.soe.cart.gql.schema.newCustomer;

import lombok.Data;

@Data
public class BillingAddress {
	private boolean e911AddressSharingOptIn;
	private String apartmentNo;
	private String type;
	private String firstName;
	private String lastName;
	private String emailId;
	private String attention;
	private String addressLine1;
	private String zipCode;
	private String zipCode4;
	private String streetNumber;
	private String streetDirection;
	private String countryCode;
	private String fipsCode;
	private Integer floor;
	private String city;
	private String state;
	private String addressIdNumber;
	private String county;
	private String streetName;

}
