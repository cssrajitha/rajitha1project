package onevz.soe.cart.gql.schema.shippingInfo;

import lombok.Data;
import onevz.soe.cart.gql.schema.Shipping;

@Data
public class ShippingInfoItemsInfo {

	private Shipping shipping;
}
