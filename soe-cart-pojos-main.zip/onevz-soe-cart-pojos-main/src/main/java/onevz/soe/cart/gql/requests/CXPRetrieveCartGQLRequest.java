package onevz.soe.cart.gql.requests;


import onevz.soe.cart.model.retrieve5GCart.RetrieveFiveGLineDetailsVO;
import onevz.soe.cart.model.retrieve5GCart.RetrieveFiveGOrderDetails;


public class CXPRetrieveCartGQLRequest {
        private RetrieveFiveGOrderDetails orderDetails;
        private RetrieveFiveGLineDetailsVO lineDetails;
}
