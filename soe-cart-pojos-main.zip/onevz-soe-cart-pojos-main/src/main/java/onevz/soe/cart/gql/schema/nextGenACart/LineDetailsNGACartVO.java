package onevz.soe.cart.gql.schema.nextGenACart;

import lombok.Data;

@Data
public class LineDetailsNGACartVO {
	private LineInfoNGACartInfo lineInfo;
}
