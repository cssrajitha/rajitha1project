package onevz.soe.cart.gql.schema.cartE911Address;

import lombok.Data;


@Data
public class LineDetails {
	
	private LineInfo lineInfo;
	
}
