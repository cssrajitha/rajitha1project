package onevz.soe.cart.gql.schema.oneclick;

import lombok.Data;

@Data
public class DeviceListItemInfo {

	private DeviceListCartItems cartItems;
}
