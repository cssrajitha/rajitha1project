package onevz.soe.cart.gql.requests;

import lombok.Data;

@Data
public class AddressGQL {
	
	private String emailId;

}