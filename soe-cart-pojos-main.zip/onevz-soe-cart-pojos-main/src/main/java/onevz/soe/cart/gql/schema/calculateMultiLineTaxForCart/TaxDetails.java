package onevz.soe.cart.gql.schema.calculateMultiLineTaxForCart;

import lombok.Data;

@Data
public class TaxDetails {

	private int mldSequenceNum;
	private int taxSequenceNum;
	private String taxPassType;
	private String taxAmount;
	private String taxDescription;
	private String taxType;
	
}
