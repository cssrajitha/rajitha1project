package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class EligibleProduct {

	private String productType;
	private ToastMessage toastMessages;
}
