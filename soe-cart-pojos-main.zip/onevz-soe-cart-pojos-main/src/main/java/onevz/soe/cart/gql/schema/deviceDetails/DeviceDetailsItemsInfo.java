package onevz.soe.cart.gql.schema.deviceDetails;

import lombok.Data;

@Data
public class DeviceDetailsItemsInfo {

	private DeviceDetailsCartItemsVO cartItems;
}
