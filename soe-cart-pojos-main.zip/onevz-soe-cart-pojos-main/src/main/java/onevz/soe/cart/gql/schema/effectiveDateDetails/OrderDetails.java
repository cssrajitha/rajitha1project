package onevz.soe.cart.gql.schema.effectiveDateDetails;

import lombok.Data;
import onevz.soe.cart.gql.schema.EffectiveDateDetails;


@Data
public class OrderDetails {
	
	private EffectiveDateDetails effectiveDateDetails;
	
}
