package onevz.soe.cart.model.AccessoryFinancingOffers;

import lombok.Data;

@Data
public class AccessoryFinancingOffers {
	
	private boolean offerAccepted;
	
	private boolean disclosureAgreementSent;

}
