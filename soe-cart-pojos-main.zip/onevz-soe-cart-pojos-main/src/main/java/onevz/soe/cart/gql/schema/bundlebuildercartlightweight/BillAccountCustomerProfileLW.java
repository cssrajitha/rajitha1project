package onevz.soe.cart.gql.schema.bundlebuildercartlightweight;

import lombok.Data;

import java.util.List;

@Data
public class BillAccountCustomerProfileLW {
    private List<MobileInfoCustomerProfileLW> mtns;
}
