package onevz.soe.cart.gql.schema.bundlebuildercartlightweight;

import lombok.Data;

@Data
public class ItemsInfoLW {
    private String depletionType;
    private Integer itemCount;
    private Integer itemTabSeqNum;
    private CartItemsLW cartItems;
}
