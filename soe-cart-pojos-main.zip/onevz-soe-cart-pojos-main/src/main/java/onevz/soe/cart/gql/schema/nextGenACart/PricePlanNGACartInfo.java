package onevz.soe.cart.gql.schema.nextGenACart;

import lombok.Data;

@Data
public class PricePlanNGACartInfo {
	private Double planPrice;
	private String pricePlanDisplayName;

}
