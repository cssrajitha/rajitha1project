package onevz.soe.cart.gql.schema.deviceCount;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;


@Data
public class DeviceCountCartItem {
	
	private String cartItemType;
	private Boolean isPreconfigureEnabled;
	
}
