package onevz.soe.cart.gql.schema.customerByMtnForParentLines;

import lombok.Data;

@Data
public class MtnStatus {

    private Boolean isActive;
}
