package onevz.soe.cart.gql.schema.nextGenACart;

import lombok.Data;
import onevz.soe.cart.gql.schema.CartItemNGACartVO;

@Data
public class ItemsNGACartInfo {
	private CartItemNGACartVO cartItems;

}
