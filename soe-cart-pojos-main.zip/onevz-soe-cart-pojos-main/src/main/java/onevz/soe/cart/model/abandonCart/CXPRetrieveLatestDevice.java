package onevz.soe.cart.model.abandonCart;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.*;
import onevz.soe.cart.gql.schema.DevicePaymentPrice;
import onevz.soe.cart.gql.schema.FullRetailPrice;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonInclude(Include.NON_NULL)
public class CXPRetrieveLatestDevice {

  private String deviceId;

  private String deviceIdType;

  private String capacity;

  private String modelName;

  private String brandName;

  private String operatingSystem;

  private String deviceUrl;

  private String canonicalUrl;

  private String productDisplayName;

  private String sorId;

  private String sorDeviceCategory;
  
  private String sorAccessoryType;

  private FullRetailPrice fullRetailPrice;

  private DevicePaymentPrice devicePaymentPrice;

}
