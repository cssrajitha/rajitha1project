package onevz.soe.cart.gql.schema;

import java.util.List;

import lombok.Data;
import onevz.soe.orderprocess.model.checkoutdetails.EquipmentInfo;

@Data
public class PosVisAddlSvcInfo {

	private String mtn;
	private String mea;
	private String bgsa;
    private List<Promotion> promotions;
    private List<EquipmentInfo> equipmentInfos;
    private UpgradeEligibilityInfo equipmentUpgradeEligibility; 
}
