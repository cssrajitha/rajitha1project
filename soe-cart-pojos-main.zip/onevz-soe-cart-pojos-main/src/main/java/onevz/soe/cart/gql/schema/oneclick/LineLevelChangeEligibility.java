package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude
public class LineLevelChangeEligibility
{
	
	private Object pendingOrderDetail;

	public LineLevelChangeEligibility()
	{
		this.pendingOrderDetail = new Object();
	}
}
