package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class BillSummary {

    private NBSAmount surcharges;
    private NBSAmount taxesAndFees;
}
