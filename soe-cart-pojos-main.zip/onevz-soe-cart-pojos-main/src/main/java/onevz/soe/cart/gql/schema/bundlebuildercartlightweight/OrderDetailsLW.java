package onevz.soe.cart.gql.schema.bundlebuildercartlightweight;

import lombok.Data;

@Data
public class OrderDetailsLW {
    private String flowType;

}
