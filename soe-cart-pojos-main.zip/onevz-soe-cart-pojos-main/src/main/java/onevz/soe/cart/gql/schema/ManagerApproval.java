package onevz.soe.cart.gql.schema;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ManagerApproval {

	private String userId;
	private String name;
	private String approvalMethod;
	private String approvalRemarks;
	private String remarks;
	private String timeStamp;
	@JsonProperty(value = "managerApprovalReasonCode")
    private Boolean managerApprovalReasonCode;
    private List<ManagerApprovalRemarks> remarkLines;
}
