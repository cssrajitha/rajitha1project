package onevz.soe.cart.gql.requests;

import lombok.Data;

@Data
public class ValidateBYODToolGQLRequest {

    private String deviceSku;
    private Boolean lostOrStolen;
    private Boolean verizonsDMD;
    private Boolean nonPay;
    private Boolean appleCarrierLock;
    private Boolean fmipLock;
    private Boolean premiumVisualVoiceMail;
    private Boolean voiceOverWifi;
    private String travelPass;
    private String tradeInValueUpTo;

}
