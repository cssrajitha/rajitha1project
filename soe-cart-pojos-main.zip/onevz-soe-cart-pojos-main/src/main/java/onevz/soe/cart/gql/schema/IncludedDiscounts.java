package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class IncludedDiscounts {

	private String discountType;
	private String discountAmount;
}
