package onevz.soe.cart.gql.requests;

import lombok.Data;

@Data
public class CartHeaderGQL {

	private String cartId;
	private String caseId;
	private String cartCreator;
	private String fullAccountNumber;
}