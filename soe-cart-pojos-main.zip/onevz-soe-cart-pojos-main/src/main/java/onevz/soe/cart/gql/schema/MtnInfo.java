package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class MtnInfo {
    //private String encryptedMtn; Removed as part of ACT42-667 story
    private String plainMtn;
}
