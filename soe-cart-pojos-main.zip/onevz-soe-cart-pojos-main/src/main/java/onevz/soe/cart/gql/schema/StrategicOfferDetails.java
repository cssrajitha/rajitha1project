package onevz.soe.cart.gql.schema;

import lombok.Data;

/**
 * StrategicOfferDetails
 *
 */
@Data
public class StrategicOfferDetails {
	    private String mtn;
	    private String rank;
	    private String propositionID;
	    private String propositionName;
	    //private String[] eligibleMtns; Removed as part of ACT42-667 story
		private MtnInfo[] eligibleMtnMap;
	    private String reqCompliance;
	    private String fulFillmentCode;
	    private String soiEngagementId;
	    private String dispositionOptionId;
		private DispositionOptionList[] dispositionOptionList;
		private DynamicAttrList[] dynamicAttrList;
		private String externalId;
		private String restricted;
}
