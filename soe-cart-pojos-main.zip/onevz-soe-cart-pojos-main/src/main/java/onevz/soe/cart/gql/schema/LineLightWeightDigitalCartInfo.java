package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class LineLightWeightDigitalCartInfo {

	private String lineActivityType;
	private String transactionType;
	private MtnDetailsLWVO mtnDetails;
	private ItemsInfoLWVO itemsInfo;
	private String deviceCategoryName;
}
