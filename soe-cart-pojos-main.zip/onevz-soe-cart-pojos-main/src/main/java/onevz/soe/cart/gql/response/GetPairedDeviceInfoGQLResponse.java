package onevz.soe.cart.gql.response;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.CartWarning;
@Data
public class GetPairedDeviceInfoGQLResponse {

	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value = "meta")
	private Map<String, String> meta;
	
	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value = "errors")
	private CartError[] errors;
	
	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value = "warnings")
	private CartWarning[] warnings;
	
	private GetPairedDeviceInfoGQL data;
}
