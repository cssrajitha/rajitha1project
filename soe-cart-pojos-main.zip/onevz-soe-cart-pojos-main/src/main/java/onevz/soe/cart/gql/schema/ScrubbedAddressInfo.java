package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class ScrubbedAddressInfo {

	private String streetName;
	private String streetNumber;
	private String streetType;
	private String streetDirection;
	private String apartmentNo;
	private String pobox;
	private String ruralDeliveryNo;
	private String ruralRouteNo;
	private String city;
	private String state;
	private String country;
	private String zipCode;
	private String zipCodePlus4;
}
