package onevz.soe.cart.gql.schema.oneclick;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude
public class CustomerAttributes {
	private String customerType;
	private Boolean ecpdConcession;
	private String digitalCustomerType;
//	private Boolean consumerAccount;
	private Boolean businessAccount;
//	private boolean VZWEmployeeAccount;
	private Boolean agentAccount;
//	private Boolean salesMakerAccount;

}
