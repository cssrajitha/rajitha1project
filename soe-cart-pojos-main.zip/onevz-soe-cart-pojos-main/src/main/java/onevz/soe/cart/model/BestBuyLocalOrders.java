package onevz.soe.cart.model;

import lombok.Data;

@Data
public class BestBuyLocalOrders {

    private String upc;

    private String priceId;

    private String taxBasis;

    private String regularPrice;

    private String currentPrice;

    private String bbyDownPayment;

    private String mtn;
}
