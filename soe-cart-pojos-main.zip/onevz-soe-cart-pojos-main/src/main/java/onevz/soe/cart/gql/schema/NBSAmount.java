package onevz.soe.cart.gql.schema;

import lombok.Data;

@Data
public class NBSAmount {

    private String ongoingBillAmount;
}
