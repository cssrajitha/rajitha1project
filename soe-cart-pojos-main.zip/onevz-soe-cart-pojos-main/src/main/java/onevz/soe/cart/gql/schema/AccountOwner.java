package onevz.soe.cart.gql.schema;

import lombok.Data;
import onevz.soe.cart.model.deviceIdValidation.DeviceInfo;
import onevz.soe.cart.model.deviceIdValidation.SimInfo;

@Data
public class AccountOwner {

	private String mtn;
	  
	private SimInfo sim;

	private DeviceInfo device;
}
