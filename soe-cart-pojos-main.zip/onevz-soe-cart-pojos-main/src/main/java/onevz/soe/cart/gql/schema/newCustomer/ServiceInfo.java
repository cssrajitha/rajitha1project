package onevz.soe.cart.gql.schema.newCustomer;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import onevz.soe.cart.gql.schema.FiveGAddress;
import onevz.soe.cart.gql.schema.LinePairingInfo;
import onevz.soe.cart.gql.schema.SelectedFeaturesList;
import onevz.soe.cart.model.common.FeatureMessages;
import onevz.soe.cart.model.common.McsSubscription;
import onevz.soe.cart.model.retrieveCart.SelectedALPShareList;

@Data
public class ServiceInfo {
	
	private PlanDiscount planDiscount;
	private OtherPromotions otherPromotions;
	private PrimaryUserInfo primaryUserInfo;
	private String mtn;
	private PricePlanInfo newPricePlanInfo;
	private SelectedFeaturesList selectedFeaturesList;
	private PlanDetails planDetails;
	@JsonProperty(value="isSharePlanAdded")
	private Boolean isSharePlanAdded;
	private SbdOffer sbdOffer;
	private ThirdPartyOffer[] thirdPartyOffer;
	@JsonProperty(value="kidsPlanParentMtn")
	private Boolean kidsPlanParentMtn;
	private McsSubscription mcsSubscription;
	private SelectedALPShareList selectedALPShareList;
	private ServiceAddress serviceAddress;
	@Schema(description = "Cart 5G Address", example = "1315 tucker st 27701")
	private FiveGAddress cart5GAddress;
	private String mldTrunkMTN;
	private String trunkMTN;
	private String numberShareInd;
	private LinePairingInfo pairingInfo;
	@JsonProperty(value = "unpairedGrantor")
	private Boolean unpairedGrantor;
	private List<FeatureMessages> featureMessages;

}
