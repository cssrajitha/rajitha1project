package onevz.aem.request;

import lombok.Builder;
import lombok.Data;
import onevz.aem.response.ProspectDeviceModelMapResponse;
import onevz.aem.response.ProspectDeviceModelMappingResponse;
import onevz.soe.wsclient.aem.AEMRequest;

/**
 * The type prospect device model mapping request.
 */
@Data
@Builder
public class ProspectDeviceModelMappingRequest implements AEMRequest<ProspectDeviceModelMapResponse> {

    private String queryString;
    @Override
    public Class<ProspectDeviceModelMapResponse> getResponseType() {
        return ProspectDeviceModelMapResponse.class;
    }
}
