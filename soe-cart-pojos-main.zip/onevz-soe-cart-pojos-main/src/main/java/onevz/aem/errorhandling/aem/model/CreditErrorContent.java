package onevz.aem.errorhandling.aem.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import onevz.soe.errorhandling.aem.model.AEMCreditExceptionResponse;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Data
@JsonInclude(content = JsonInclude.Include.ALWAYS)
public class CreditErrorContent {

    @JsonProperty("creditHold")
    private java.util.List<AEMCreditExceptionResponse> creditHold;

}