package onevz.aem.response;

import java.io.Serializable;
import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;
import onevz.soe.wsclient.aem.AEMResponse;

/**
 * The type prospect device model mapping response.
 */
@Data
@NoArgsConstructor
public class ProspectDeviceModelMappingResponse implements AEMResponse {
	 private Ddata ddata;
	 private String type;
}
