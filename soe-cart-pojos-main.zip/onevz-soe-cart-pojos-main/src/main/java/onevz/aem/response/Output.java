package onevz.aem.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serializable;
import java.util.List;

/**
 * The type Output.
 */
@Data
@NoArgsConstructor
public class Output implements Serializable {
	private List<DeviceModelMap> deviceModelMap;
}
