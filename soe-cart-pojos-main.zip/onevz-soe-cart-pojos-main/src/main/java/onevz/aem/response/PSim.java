package onevz.aem.response;

import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The type PSim.
 */
@Data
@NoArgsConstructor
public class PSim implements Serializable {
	@JsonProperty("ATT")
	private String ATT;
	@JsonProperty(value = "T-Mobile")
	private String TMobile;
	@JsonProperty("SPRINT")
	private String SPRINT;
	@JsonProperty("VERIZON")
	private String VERIZON;
	@JsonProperty("Other")
	private String Other;
}
