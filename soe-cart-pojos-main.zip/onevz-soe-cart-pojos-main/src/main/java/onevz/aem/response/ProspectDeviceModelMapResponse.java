package onevz.aem.response;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;
import onevz.soe.wsclient.aem.AEMResponse;

/**
 * The type ProspectDeviceModelMapResponse.
 */
@Data
@NoArgsConstructor
public class ProspectDeviceModelMapResponse implements AEMResponse{
	
	private static final long serialVersionUID = 6726176157605356264L;
	
	private List<DeviceModelMap> deviceModelMap;

}
