package onevz.aem.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serializable;

/**
 * The type DeviceModelMap.
 */
@Data
@NoArgsConstructor
public class DeviceModelMap implements Serializable {

	@JsonProperty("Key")
	 private String Key;
    @JsonProperty("Model")
	 private String Model;
    @JsonProperty("Model_NonVZ")
	 private String Model_NonVZ;
    @JsonProperty("eSim")
	 private ESim eSim;
    @JsonProperty("pSim")
	 private PSim pSim;
	 
}
